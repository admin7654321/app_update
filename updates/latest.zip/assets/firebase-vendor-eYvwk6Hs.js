const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x59b785,_0x423383){if(!_0x59b785)throw ht(_0x423383);},ht=function(_0x3cbde9){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3cbde9);},Hr=function(_0xf11b66){const _0xe63515=[];let _0x55ca4f=0x0;for(let _0x38669c=0x0;_0x38669c<_0xf11b66['length'];_0x38669c++){let _0x1faf63=_0xf11b66['charCodeAt'](_0x38669c);_0x1faf63<0x80?_0xe63515[_0x55ca4f++]=_0x1faf63:_0x1faf63<0x800?(_0xe63515[_0x55ca4f++]=_0x1faf63>>0x6|0xc0,_0xe63515[_0x55ca4f++]=_0x1faf63&0x3f|0x80):(_0x1faf63&0xfc00)===0xd800&&_0x38669c+0x1<_0xf11b66['length']&&(_0xf11b66['charCodeAt'](_0x38669c+0x1)&0xfc00)===0xdc00?(_0x1faf63=0x10000+((_0x1faf63&0x3ff)<<0xa)+(_0xf11b66['charCodeAt'](++_0x38669c)&0x3ff),_0xe63515[_0x55ca4f++]=_0x1faf63>>0x12|0xf0,_0xe63515[_0x55ca4f++]=_0x1faf63>>0xc&0x3f|0x80,_0xe63515[_0x55ca4f++]=_0x1faf63>>0x6&0x3f|0x80,_0xe63515[_0x55ca4f++]=_0x1faf63&0x3f|0x80):(_0xe63515[_0x55ca4f++]=_0x1faf63>>0xc|0xe0,_0xe63515[_0x55ca4f++]=_0x1faf63>>0x6&0x3f|0x80,_0xe63515[_0x55ca4f++]=_0x1faf63&0x3f|0x80);}return _0xe63515;},nc=function(_0x12bedc){const _0x172d2e=[];let _0x36e96a=0x0,_0x2638ad=0x0;for(;_0x36e96a<_0x12bedc['length'];){const _0x5311cd=_0x12bedc[_0x36e96a++];if(_0x5311cd<0x80)_0x172d2e[_0x2638ad++]=String['fromCharCode'](_0x5311cd);else{if(_0x5311cd>0xbf&&_0x5311cd<0xe0){const _0x1b09bb=_0x12bedc[_0x36e96a++];_0x172d2e[_0x2638ad++]=String['fromCharCode']((_0x5311cd&0x1f)<<0x6|_0x1b09bb&0x3f);}else{if(_0x5311cd>0xef&&_0x5311cd<0x16d){const _0x2fae21=_0x12bedc[_0x36e96a++],_0x39d664=_0x12bedc[_0x36e96a++],_0x2902a1=_0x12bedc[_0x36e96a++],_0x513343=((_0x5311cd&0x7)<<0x12|(_0x2fae21&0x3f)<<0xc|(_0x39d664&0x3f)<<0x6|_0x2902a1&0x3f)-0x10000;_0x172d2e[_0x2638ad++]=String['fromCharCode'](0xd800+(_0x513343>>0xa)),_0x172d2e[_0x2638ad++]=String['fromCharCode'](0xdc00+(_0x513343&0x3ff));}else{const _0x141548=_0x12bedc[_0x36e96a++],_0x315860=_0x12bedc[_0x36e96a++];_0x172d2e[_0x2638ad++]=String['fromCharCode']((_0x5311cd&0xf)<<0xc|(_0x141548&0x3f)<<0x6|_0x315860&0x3f);}}}}return _0x172d2e['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4fbf2b,_0x5c5086){if(!Array['isArray'](_0x4fbf2b))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3fbb5c=_0x5c5086?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4bf371=[];for(let _0x43d1c2=0x0;_0x43d1c2<_0x4fbf2b['length'];_0x43d1c2+=0x3){const _0x4893c1=_0x4fbf2b[_0x43d1c2],_0x4194a7=_0x43d1c2+0x1<_0x4fbf2b['length'],_0x2fbc61=_0x4194a7?_0x4fbf2b[_0x43d1c2+0x1]:0x0,_0x5f202e=_0x43d1c2+0x2<_0x4fbf2b['length'],_0x2dec6e=_0x5f202e?_0x4fbf2b[_0x43d1c2+0x2]:0x0,_0x599e84=_0x4893c1>>0x2,_0x18faed=(_0x4893c1&0x3)<<0x4|_0x2fbc61>>0x4;let _0x13d581=(_0x2fbc61&0xf)<<0x2|_0x2dec6e>>0x6,_0xc5aef7=_0x2dec6e&0x3f;_0x5f202e||(_0xc5aef7=0x40,_0x4194a7||(_0x13d581=0x40)),_0x4bf371['push'](_0x3fbb5c[_0x599e84],_0x3fbb5c[_0x18faed],_0x3fbb5c[_0x13d581],_0x3fbb5c[_0xc5aef7]);}return _0x4bf371['join']('');},'encodeString'(_0x9a2d59,_0x3f63df){return this['HAS_NATIVE_SUPPORT']&&!_0x3f63df?btoa(_0x9a2d59):this['encodeByteArray'](Hr(_0x9a2d59),_0x3f63df);},'decodeString'(_0x29922e,_0x1ce216){return this['HAS_NATIVE_SUPPORT']&&!_0x1ce216?atob(_0x29922e):nc(this['decodeStringToByteArray'](_0x29922e,_0x1ce216));},'decodeStringToByteArray'(_0x239f65,_0x56fc0b){this['init_']();const _0x51bbc6=_0x56fc0b?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x1a6503=[];for(let _0x1f010e=0x0;_0x1f010e<_0x239f65['length'];){const _0x585fd0=_0x51bbc6[_0x239f65['charAt'](_0x1f010e++)],_0x201ed2=_0x1f010e<_0x239f65['length']?_0x51bbc6[_0x239f65['charAt'](_0x1f010e)]:0x0;++_0x1f010e;const _0x693916=_0x1f010e<_0x239f65['length']?_0x51bbc6[_0x239f65['charAt'](_0x1f010e)]:0x40;++_0x1f010e;const _0x131d6c=_0x1f010e<_0x239f65['length']?_0x51bbc6[_0x239f65['charAt'](_0x1f010e)]:0x40;if(++_0x1f010e,_0x585fd0==null||_0x201ed2==null||_0x693916==null||_0x131d6c==null)throw new ic();const _0x24b797=_0x585fd0<<0x2|_0x201ed2>>0x4;if(_0x1a6503['push'](_0x24b797),_0x693916!==0x40){const _0x1aaef7=_0x201ed2<<0x4&0xf0|_0x693916>>0x2;if(_0x1a6503['push'](_0x1aaef7),_0x131d6c!==0x40){const _0x4f1958=_0x693916<<0x6&0xc0|_0x131d6c;_0x1a6503['push'](_0x4f1958);}}}return _0x1a6503;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x2913fe=0x0;_0x2913fe<this['ENCODED_VALS']['length'];_0x2913fe++)this['byteToCharMap_'][_0x2913fe]=this['ENCODED_VALS']['charAt'](_0x2913fe),this['charToByteMap_'][this['byteToCharMap_'][_0x2913fe]]=_0x2913fe,this['byteToCharMapWebSafe_'][_0x2913fe]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2913fe),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x2913fe]]=_0x2913fe,_0x2913fe>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2913fe)]=_0x2913fe,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x2913fe)]=_0x2913fe);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3b7ed4){const _0x51697b=Hr(_0x3b7ed4);return Fi['encodeByteArray'](_0x51697b,!0x0);},dn=function(_0xfe2958){return $r(_0xfe2958)['replace'](/\./g,'');},fn=function(_0x3f79cf){try{return Fi['decodeString'](_0x3f79cf,!0x0);}catch(_0x312451){console['error']('base64Decode\x20failed:\x20',_0x312451);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x56052b){return Gr(void 0x0,_0x56052b);}function Gr(_0x5e7018,_0x40e671){if(!(_0x40e671 instanceof Object))return _0x40e671;switch(_0x40e671['constructor']){case Date:const _0x48d242=_0x40e671;return new Date(_0x48d242['getTime']());case Object:_0x5e7018===void 0x0&&(_0x5e7018={});break;case Array:_0x5e7018=[];break;default:return _0x40e671;}for(const _0x2dce88 in _0x40e671)!_0x40e671['hasOwnProperty'](_0x2dce88)||!rc(_0x2dce88)||(_0x5e7018[_0x2dce88]=Gr(_0x5e7018[_0x2dce88],_0x40e671[_0x2dce88]));return _0x5e7018;}function rc(_0x750eeb){return _0x750eeb!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x274edd=Ps['__FIREBASE_DEFAULTS__'];if(_0x274edd)return JSON['parse'](_0x274edd);},lc=()=>{if(typeof document>'u')return;let _0x2d3391;try{_0x2d3391=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x230acb=_0x2d3391&&fn(_0x2d3391[0x1]);return _0x230acb&&JSON['parse'](_0x230acb);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x3bb9ec){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3bb9ec);return;}},qr=_0x4bd888=>{var _0x26dcc8,_0x2d2a07;return(_0x2d2a07=(_0x26dcc8=Ui())==null?void 0x0:_0x26dcc8['emulatorHosts'])==null?void 0x0:_0x2d2a07[_0x4bd888];},hc=_0x5e430e=>{const _0x46540a=qr(_0x5e430e);if(!_0x46540a)return;const _0x3eb064=_0x46540a['lastIndexOf'](':');if(_0x3eb064<=0x0||_0x3eb064+0x1===_0x46540a['length'])throw new Error('Invalid\x20host\x20'+_0x46540a+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x16de31=parseInt(_0x46540a['substring'](_0x3eb064+0x1),0xa);return _0x46540a[0x0]==='['?[_0x46540a['substring'](0x1,_0x3eb064-0x1),_0x16de31]:[_0x46540a['substring'](0x0,_0x3eb064),_0x16de31];},zr=()=>{var _0x54881b;return(_0x54881b=Ui())==null?void 0x0:_0x54881b['config'];},jr=_0x492f67=>{var _0x3bcdb9;return(_0x3bcdb9=Ui())==null?void 0x0:_0x3bcdb9['_'+_0x492f67];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x6bd574,_0x594759)=>{this['resolve']=_0x6bd574,this['reject']=_0x594759;});}['wrapCallback'](_0x3318db){return(_0x3ddf62,_0x5b7ae3)=>{_0x3ddf62?this['reject'](_0x3ddf62):this['resolve'](_0x5b7ae3),typeof _0x3318db=='function'&&(this['promise']['catch'](()=>{}),_0x3318db['length']===0x1?_0x3318db(_0x3ddf62):_0x3318db(_0x3ddf62,_0x5b7ae3));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x4b5ba0,_0x19b64e){if(_0x4b5ba0['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3645c2={'alg':'none','type':'JWT'},_0x1fd6d5=_0x19b64e||'demo-project',_0x5c3af5=_0x4b5ba0['iat']||0x0,_0x88be02=_0x4b5ba0['sub']||_0x4b5ba0['user_id'];if(!_0x88be02)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1782f5={'iss':'https://securetoken.google.com/'+_0x1fd6d5,'aud':_0x1fd6d5,'iat':_0x5c3af5,'exp':_0x5c3af5+0xe10,'auth_time':_0x5c3af5,'sub':_0x88be02,'user_id':_0x88be02,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4b5ba0};return[dn(JSON['stringify'](_0x3645c2)),dn(JSON['stringify'](_0x1782f5)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x32a51e=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x32a51e=='object'&&_0x32a51e['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x19dc66=W();return _0x19dc66['indexOf']('MSIE\x20')>=0x0||_0x19dc66['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x37edc3,_0x47c45e)=>{try{let _0x21d6c9=!0x0;const _0x45cc09='validate-browser-context-for-indexeddb-analytics-module',_0x89eb11=self['indexedDB']['open'](_0x45cc09);_0x89eb11['onsuccess']=()=>{_0x89eb11['result']['close'](),_0x21d6c9||self['indexedDB']['deleteDatabase'](_0x45cc09),_0x37edc3(!0x0);},_0x89eb11['onupgradeneeded']=()=>{_0x21d6c9=!0x1;},_0x89eb11['onerror']=()=>{var _0x543f33;_0x47c45e(((_0x543f33=_0x89eb11['error'])==null?void 0x0:_0x543f33['message'])||'');};}catch(_0x4f87cd){_0x47c45e(_0x4f87cd);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x13c8e1,_0x1bba9f,_0x255bfc){super(_0x1bba9f),this['code']=_0x13c8e1,this['customData']=_0x255bfc,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x180f49,_0x28f7fc,_0x499f5c){this['service']=_0x180f49,this['serviceName']=_0x28f7fc,this['errors']=_0x499f5c;}['create'](_0x5525e2,..._0x359707){const _0x5ae649=_0x359707[0x0]||{},_0x2abeef=this['service']+'/'+_0x5525e2,_0x322af6=this['errors'][_0x5525e2],_0x3ce8b6=_0x322af6?vc(_0x322af6,_0x5ae649):'Error',_0x16f20a=this['serviceName']+':\x20'+_0x3ce8b6+'\x20('+_0x2abeef+').';return new Re(_0x2abeef,_0x16f20a,_0x5ae649);}}function vc(_0x377388,_0x55cf5d){return _0x377388['replace'](Ec,(_0x258d1d,_0x476b2c)=>{const _0x30401a=_0x55cf5d[_0x476b2c];return _0x30401a!=null?String(_0x30401a):'<'+_0x476b2c+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x1d7a55){return JSON['parse'](_0x1d7a55);}function O(_0xd6e855){return JSON['stringify'](_0xd6e855);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x21bd33){let _0x1cbb47={},_0x125f25={},_0xfc2b83={},_0x84adbe='';try{const _0x3a9664=_0x21bd33['split']('.');_0x1cbb47=Nt(fn(_0x3a9664[0x0])||''),_0x125f25=Nt(fn(_0x3a9664[0x1])||''),_0x84adbe=_0x3a9664[0x2],_0xfc2b83=_0x125f25['d']||{},delete _0x125f25['d'];}catch{}return{'header':_0x1cbb47,'claims':_0x125f25,'data':_0xfc2b83,'signature':_0x84adbe};},Ic=function(_0x11c1de){const _0x57becf=Yr(_0x11c1de),_0x4596da=_0x57becf['claims'];return!!_0x4596da&&typeof _0x4596da=='object'&&_0x4596da['hasOwnProperty']('iat');},wc=function(_0x4bc502){const _0x381525=Yr(_0x4bc502)['claims'];return typeof _0x381525=='object'&&_0x381525['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x8527a9,_0x32c2ff){return Object['prototype']['hasOwnProperty']['call'](_0x8527a9,_0x32c2ff);}function Le(_0x37c763,_0x58ccc7){if(Object['prototype']['hasOwnProperty']['call'](_0x37c763,_0x58ccc7))return _0x37c763[_0x58ccc7];}function pn(_0xd35393){for(const _0x9dc029 in _0xd35393)if(Object['prototype']['hasOwnProperty']['call'](_0xd35393,_0x9dc029))return!0x1;return!0x0;}function _n(_0x549098,_0x2fb117,_0x6db2b4){const _0x441d82={};for(const _0x197d9f in _0x549098)Object['prototype']['hasOwnProperty']['call'](_0x549098,_0x197d9f)&&(_0x441d82[_0x197d9f]=_0x2fb117['call'](_0x6db2b4,_0x549098[_0x197d9f],_0x197d9f,_0x549098));return _0x441d82;}function xe(_0x1ac6af,_0x1523f4){if(_0x1ac6af===_0x1523f4)return!0x0;const _0x4c72f2=Object['keys'](_0x1ac6af),_0x172c5b=Object['keys'](_0x1523f4);for(const _0x534af3 of _0x4c72f2){if(!_0x172c5b['includes'](_0x534af3))return!0x1;const _0x424d2f=_0x1ac6af[_0x534af3],_0x1197a7=_0x1523f4[_0x534af3];if(Ns(_0x424d2f)&&Ns(_0x1197a7)){if(!xe(_0x424d2f,_0x1197a7))return!0x1;}else{if(_0x424d2f!==_0x1197a7)return!0x1;}}for(const _0xf4b655 of _0x172c5b)if(!_0x4c72f2['includes'](_0xf4b655))return!0x1;return!0x0;}function Ns(_0x21a22e){return _0x21a22e!==null&&typeof _0x21a22e=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x9a7dec){const _0x585324=[];for(const [_0x1767b7,_0x45d8c3]of Object['entries'](_0x9a7dec))Array['isArray'](_0x45d8c3)?_0x45d8c3['forEach'](_0x542bcd=>{_0x585324['push'](encodeURIComponent(_0x1767b7)+'='+encodeURIComponent(_0x542bcd));}):_0x585324['push'](encodeURIComponent(_0x1767b7)+'='+encodeURIComponent(_0x45d8c3));return _0x585324['length']?'&'+_0x585324['join']('&'):'';}function Ct(_0xbb9db4){const _0x363709={};return _0xbb9db4['replace'](/^\?/,'')['split']('&')['forEach'](_0x423387=>{if(_0x423387){const [_0x318773,_0x6af52c]=_0x423387['split']('=');_0x363709[decodeURIComponent(_0x318773)]=decodeURIComponent(_0x6af52c);}}),_0x363709;}function Tt(_0x18c9ca){const _0x12aa13=_0x18c9ca['indexOf']('?');if(!_0x12aa13)return'';const _0x5e7c4e=_0x18c9ca['indexOf']('#',_0x12aa13);return _0x18c9ca['substring'](_0x12aa13,_0x5e7c4e>0x0?_0x5e7c4e:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x478390=0x1;_0x478390<this['blockSize'];++_0x478390)this['pad_'][_0x478390]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x346ca4,_0x4643f3){_0x4643f3||(_0x4643f3=0x0);const _0x539a40=this['W_'];if(typeof _0x346ca4=='string'){for(let _0xa116af=0x0;_0xa116af<0x10;_0xa116af++)_0x539a40[_0xa116af]=_0x346ca4['charCodeAt'](_0x4643f3)<<0x18|_0x346ca4['charCodeAt'](_0x4643f3+0x1)<<0x10|_0x346ca4['charCodeAt'](_0x4643f3+0x2)<<0x8|_0x346ca4['charCodeAt'](_0x4643f3+0x3),_0x4643f3+=0x4;}else{for(let _0x2eea64=0x0;_0x2eea64<0x10;_0x2eea64++)_0x539a40[_0x2eea64]=_0x346ca4[_0x4643f3]<<0x18|_0x346ca4[_0x4643f3+0x1]<<0x10|_0x346ca4[_0x4643f3+0x2]<<0x8|_0x346ca4[_0x4643f3+0x3],_0x4643f3+=0x4;}for(let _0x133cc9=0x10;_0x133cc9<0x50;_0x133cc9++){const _0x2d7dba=_0x539a40[_0x133cc9-0x3]^_0x539a40[_0x133cc9-0x8]^_0x539a40[_0x133cc9-0xe]^_0x539a40[_0x133cc9-0x10];_0x539a40[_0x133cc9]=(_0x2d7dba<<0x1|_0x2d7dba>>>0x1f)&0xffffffff;}let _0x2d0656=this['chain_'][0x0],_0xe60d59=this['chain_'][0x1],_0x202fa9=this['chain_'][0x2],_0x119fc9=this['chain_'][0x3],_0x547243=this['chain_'][0x4],_0x1c6857,_0x4b1901;for(let _0x33b537=0x0;_0x33b537<0x50;_0x33b537++){_0x33b537<0x28?_0x33b537<0x14?(_0x1c6857=_0x119fc9^_0xe60d59&(_0x202fa9^_0x119fc9),_0x4b1901=0x5a827999):(_0x1c6857=_0xe60d59^_0x202fa9^_0x119fc9,_0x4b1901=0x6ed9eba1):_0x33b537<0x3c?(_0x1c6857=_0xe60d59&_0x202fa9|_0x119fc9&(_0xe60d59|_0x202fa9),_0x4b1901=0x8f1bbcdc):(_0x1c6857=_0xe60d59^_0x202fa9^_0x119fc9,_0x4b1901=0xca62c1d6);const _0x5bdd6b=(_0x2d0656<<0x5|_0x2d0656>>>0x1b)+_0x1c6857+_0x547243+_0x4b1901+_0x539a40[_0x33b537]&0xffffffff;_0x547243=_0x119fc9,_0x119fc9=_0x202fa9,_0x202fa9=(_0xe60d59<<0x1e|_0xe60d59>>>0x2)&0xffffffff,_0xe60d59=_0x2d0656,_0x2d0656=_0x5bdd6b;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2d0656&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xe60d59&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x202fa9&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x119fc9&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x547243&0xffffffff;}['update'](_0x2e4e97,_0x5036c8){if(_0x2e4e97==null)return;_0x5036c8===void 0x0&&(_0x5036c8=_0x2e4e97['length']);const _0x3aafb0=_0x5036c8-this['blockSize'];let _0x53084c=0x0;const _0x1af22d=this['buf_'];let _0x5a81f6=this['inbuf_'];for(;_0x53084c<_0x5036c8;){if(_0x5a81f6===0x0){for(;_0x53084c<=_0x3aafb0;)this['compress_'](_0x2e4e97,_0x53084c),_0x53084c+=this['blockSize'];}if(typeof _0x2e4e97=='string'){for(;_0x53084c<_0x5036c8;)if(_0x1af22d[_0x5a81f6]=_0x2e4e97['charCodeAt'](_0x53084c),++_0x5a81f6,++_0x53084c,_0x5a81f6===this['blockSize']){this['compress_'](_0x1af22d),_0x5a81f6=0x0;break;}}else{for(;_0x53084c<_0x5036c8;)if(_0x1af22d[_0x5a81f6]=_0x2e4e97[_0x53084c],++_0x5a81f6,++_0x53084c,_0x5a81f6===this['blockSize']){this['compress_'](_0x1af22d),_0x5a81f6=0x0;break;}}}this['inbuf_']=_0x5a81f6,this['total_']+=_0x5036c8;}['digest'](){const _0x2fc9c5=[];let _0x1442e0=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1f03df=this['blockSize']-0x1;_0x1f03df>=0x38;_0x1f03df--)this['buf_'][_0x1f03df]=_0x1442e0&0xff,_0x1442e0/=0x100;this['compress_'](this['buf_']);let _0x29902a=0x0;for(let _0xe2c53d=0x0;_0xe2c53d<0x5;_0xe2c53d++)for(let _0x209558=0x18;_0x209558>=0x0;_0x209558-=0x8)_0x2fc9c5[_0x29902a]=this['chain_'][_0xe2c53d]>>_0x209558&0xff,++_0x29902a;return _0x2fc9c5;}}function Tc(_0xc1d468,_0x5d102c){const _0x85219d=new Sc(_0xc1d468,_0x5d102c);return _0x85219d['subscribe']['bind'](_0x85219d);}class Sc{constructor(_0x30ef11,_0xc84946){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xc84946,this['task']['then'](()=>{_0x30ef11(this);})['catch'](_0x3bcf6f=>{this['error'](_0x3bcf6f);});}['next'](_0x46882a){this['forEachObserver'](_0x39f185=>{_0x39f185['next'](_0x46882a);});}['error'](_0x4f5cd0){this['forEachObserver'](_0x1a3a58=>{_0x1a3a58['error'](_0x4f5cd0);}),this['close'](_0x4f5cd0);}['complete'](){this['forEachObserver'](_0x17a731=>{_0x17a731['complete']();}),this['close']();}['subscribe'](_0x58148b,_0xbb60b8,_0xbf945d){let _0x145d77;if(_0x58148b===void 0x0&&_0xbb60b8===void 0x0&&_0xbf945d===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x58148b,['next','error','complete'])?_0x145d77=_0x58148b:_0x145d77={'next':_0x58148b,'error':_0xbb60b8,'complete':_0xbf945d},_0x145d77['next']===void 0x0&&(_0x145d77['next']=ti),_0x145d77['error']===void 0x0&&(_0x145d77['error']=ti),_0x145d77['complete']===void 0x0&&(_0x145d77['complete']=ti);const _0x617947=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x145d77['error'](this['finalError']):_0x145d77['complete']();}catch{}}),this['observers']['push'](_0x145d77),_0x617947;}['unsubscribeOne'](_0x5cd395){this['observers']===void 0x0||this['observers'][_0x5cd395]===void 0x0||(delete this['observers'][_0x5cd395],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x381b9a){if(!this['finalized']){for(let _0x1e437d=0x0;_0x1e437d<this['observers']['length'];_0x1e437d++)this['sendOne'](_0x1e437d,_0x381b9a);}}['sendOne'](_0x27ce2f,_0x4ff047){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x27ce2f]!==void 0x0)try{_0x4ff047(this['observers'][_0x27ce2f]);}catch(_0x6f786c){typeof console<'u'&&console['error']&&console['error'](_0x6f786c);}});}['close'](_0x2be4d7){this['finalized']||(this['finalized']=!0x0,_0x2be4d7!==void 0x0&&(this['finalError']=_0x2be4d7),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x4aafdc,_0x5a9d0a){if(typeof _0x4aafdc!='object'||_0x4aafdc===null)return!0x1;for(const _0x4b8253 of _0x5a9d0a)if(_0x4b8253 in _0x4aafdc&&typeof _0x4aafdc[_0x4b8253]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x3702a9,_0x3548a1){return _0x3702a9+'\x20failed:\x20'+_0x3548a1+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x3fc670){const _0x30538f=[];let _0x241803=0x0;for(let _0x3ebe5f=0x0;_0x3ebe5f<_0x3fc670['length'];_0x3ebe5f++){let _0x236a5d=_0x3fc670['charCodeAt'](_0x3ebe5f);if(_0x236a5d>=0xd800&&_0x236a5d<=0xdbff){const _0x20c83f=_0x236a5d-0xd800;_0x3ebe5f++,f(_0x3ebe5f<_0x3fc670['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x532eac=_0x3fc670['charCodeAt'](_0x3ebe5f)-0xdc00;_0x236a5d=0x10000+(_0x20c83f<<0xa)+_0x532eac;}_0x236a5d<0x80?_0x30538f[_0x241803++]=_0x236a5d:_0x236a5d<0x800?(_0x30538f[_0x241803++]=_0x236a5d>>0x6|0xc0,_0x30538f[_0x241803++]=_0x236a5d&0x3f|0x80):_0x236a5d<0x10000?(_0x30538f[_0x241803++]=_0x236a5d>>0xc|0xe0,_0x30538f[_0x241803++]=_0x236a5d>>0x6&0x3f|0x80,_0x30538f[_0x241803++]=_0x236a5d&0x3f|0x80):(_0x30538f[_0x241803++]=_0x236a5d>>0x12|0xf0,_0x30538f[_0x241803++]=_0x236a5d>>0xc&0x3f|0x80,_0x30538f[_0x241803++]=_0x236a5d>>0x6&0x3f|0x80,_0x30538f[_0x241803++]=_0x236a5d&0x3f|0x80);}return _0x30538f;},Ln=function(_0x3c83b4){let _0x337859=0x0;for(let _0x4e4629=0x0;_0x4e4629<_0x3c83b4['length'];_0x4e4629++){const _0x6eb3c1=_0x3c83b4['charCodeAt'](_0x4e4629);_0x6eb3c1<0x80?_0x337859++:_0x6eb3c1<0x800?_0x337859+=0x2:_0x6eb3c1>=0xd800&&_0x6eb3c1<=0xdbff?(_0x337859+=0x4,_0x4e4629++):_0x337859+=0x3;}return _0x337859;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x505297){return _0x505297&&_0x505297['_delegate']?_0x505297['_delegate']:_0x505297;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x2bfba8){try{return(_0x2bfba8['startsWith']('http://')||_0x2bfba8['startsWith']('https://')?new URL(_0x2bfba8)['hostname']:_0x2bfba8)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x852185){return(await fetch(_0x852185,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x48549c,_0x4c98cd,_0x2d31fc){this['name']=_0x48549c,this['instanceFactory']=_0x4c98cd,this['type']=_0x2d31fc,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2f8b6f){return this['instantiationMode']=_0x2f8b6f,this;}['setMultipleInstances'](_0x214825){return this['multipleInstances']=_0x214825,this;}['setServiceProps'](_0x380226){return this['serviceProps']=_0x380226,this;}['setInstanceCreatedCallback'](_0x283161){return this['onInstanceCreated']=_0x283161,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x179169,_0x151332){this['name']=_0x179169,this['container']=_0x151332,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5787b6){const _0x13d1c6=this['normalizeInstanceIdentifier'](_0x5787b6);if(!this['instancesDeferred']['has'](_0x13d1c6)){const _0x5f5898=new H();if(this['instancesDeferred']['set'](_0x13d1c6,_0x5f5898),this['isInitialized'](_0x13d1c6)||this['shouldAutoInitialize']())try{const _0x2dfa62=this['getOrInitializeService']({'instanceIdentifier':_0x13d1c6});_0x2dfa62&&_0x5f5898['resolve'](_0x2dfa62);}catch{}}return this['instancesDeferred']['get'](_0x13d1c6)['promise'];}['getImmediate'](_0x1f06de){const _0x272962=this['normalizeInstanceIdentifier'](_0x1f06de==null?void 0x0:_0x1f06de['identifier']),_0x889479=(_0x1f06de==null?void 0x0:_0x1f06de['optional'])??!0x1;if(this['isInitialized'](_0x272962)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x272962});}catch(_0xbc0c36){if(_0x889479)return null;throw _0xbc0c36;}else{if(_0x889479)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x403a55){if(_0x403a55['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x403a55['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x403a55,!!this['shouldAutoInitialize']()){if(Pc(_0x403a55))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x5a640c,_0x10c9d9]of this['instancesDeferred']['entries']()){const _0x24f0a9=this['normalizeInstanceIdentifier'](_0x5a640c);try{const _0x281089=this['getOrInitializeService']({'instanceIdentifier':_0x24f0a9});_0x10c9d9['resolve'](_0x281089);}catch{}}}}['clearInstance'](_0x58b6a6=Ne){this['instancesDeferred']['delete'](_0x58b6a6),this['instancesOptions']['delete'](_0x58b6a6),this['instances']['delete'](_0x58b6a6);}async['delete'](){const _0x16b056=Array['from'](this['instances']['values']());await Promise['all']([..._0x16b056['filter'](_0x3ae5c6=>'INTERNAL'in _0x3ae5c6)['map'](_0xbccf58=>_0xbccf58['INTERNAL']['delete']()),..._0x16b056['filter'](_0x11bba4=>'_delete'in _0x11bba4)['map'](_0x37ea98=>_0x37ea98['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1ea785=Ne){return this['instances']['has'](_0x1ea785);}['getOptions'](_0x2ed550=Ne){return this['instancesOptions']['get'](_0x2ed550)||{};}['initialize'](_0xe07f62={}){const {options:_0x6afd7c={}}=_0xe07f62,_0x4f1c22=this['normalizeInstanceIdentifier'](_0xe07f62['instanceIdentifier']);if(this['isInitialized'](_0x4f1c22))throw Error(this['name']+'('+_0x4f1c22+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x555787=this['getOrInitializeService']({'instanceIdentifier':_0x4f1c22,'options':_0x6afd7c});for(const [_0x1eb154,_0x1ac4e6]of this['instancesDeferred']['entries']()){const _0x471d62=this['normalizeInstanceIdentifier'](_0x1eb154);_0x4f1c22===_0x471d62&&_0x1ac4e6['resolve'](_0x555787);}return _0x555787;}['onInit'](_0x552f89,_0x14ced5){const _0x17753d=this['normalizeInstanceIdentifier'](_0x14ced5),_0x5686c3=this['onInitCallbacks']['get'](_0x17753d)??new Set();_0x5686c3['add'](_0x552f89),this['onInitCallbacks']['set'](_0x17753d,_0x5686c3);const _0xc00914=this['instances']['get'](_0x17753d);return _0xc00914&&_0x552f89(_0xc00914,_0x17753d),()=>{_0x5686c3['delete'](_0x552f89);};}['invokeOnInitCallbacks'](_0x4d9377,_0x48abdb){const _0x1f6106=this['onInitCallbacks']['get'](_0x48abdb);if(_0x1f6106){for(const _0x41ac00 of _0x1f6106)try{_0x41ac00(_0x4d9377,_0x48abdb);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x37c0a7,options:_0x417be2={}}){let _0x45cc6f=this['instances']['get'](_0x37c0a7);if(!_0x45cc6f&&this['component']&&(_0x45cc6f=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x37c0a7),'options':_0x417be2}),this['instances']['set'](_0x37c0a7,_0x45cc6f),this['instancesOptions']['set'](_0x37c0a7,_0x417be2),this['invokeOnInitCallbacks'](_0x45cc6f,_0x37c0a7),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x37c0a7,_0x45cc6f);}catch{}return _0x45cc6f||null;}['normalizeInstanceIdentifier'](_0x34d037=Ne){return this['component']?this['component']['multipleInstances']?_0x34d037:Ne:_0x34d037;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x4c2cd2){return _0x4c2cd2===Ne?void 0x0:_0x4c2cd2;}function Pc(_0x310d78){return _0x310d78['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x219078){this['name']=_0x219078,this['providers']=new Map();}['addComponent'](_0x15a54c){const _0x6a8b9a=this['getProvider'](_0x15a54c['name']);if(_0x6a8b9a['isComponentSet']())throw new Error('Component\x20'+_0x15a54c['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x6a8b9a['setComponent'](_0x15a54c);}['addOrOverwriteComponent'](_0x1a7eb8){this['getProvider'](_0x1a7eb8['name'])['isComponentSet']()&&this['providers']['delete'](_0x1a7eb8['name']),this['addComponent'](_0x1a7eb8);}['getProvider'](_0x2f75eb){if(this['providers']['has'](_0x2f75eb))return this['providers']['get'](_0x2f75eb);const _0x460731=new Ac(_0x2f75eb,this);return this['providers']['set'](_0x2f75eb,_0x460731),_0x460731;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x11e942){_0x11e942[_0x11e942['DEBUG']=0x0]='DEBUG',_0x11e942[_0x11e942['VERBOSE']=0x1]='VERBOSE',_0x11e942[_0x11e942['INFO']=0x2]='INFO',_0x11e942[_0x11e942['WARN']=0x3]='WARN',_0x11e942[_0x11e942['ERROR']=0x4]='ERROR',_0x11e942[_0x11e942['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x540d17,_0x47cc3a,..._0xf92221)=>{if(_0x47cc3a<_0x540d17['logLevel'])return;const _0x4d1818=new Date()['toISOString'](),_0x1b6d0d=Mc[_0x47cc3a];if(_0x1b6d0d)console[_0x1b6d0d]('['+_0x4d1818+']\x20\x20'+_0x540d17['name']+':',..._0xf92221);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x47cc3a+')');};class Bi{constructor(_0x55447a){this['name']=_0x55447a,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3a9a27){if(!(_0x3a9a27 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3a9a27+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3a9a27;}['setLogLevel'](_0x57c758){this['_logLevel']=typeof _0x57c758=='string'?Oc[_0x57c758]:_0x57c758;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x348a0b){if(typeof _0x348a0b!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x348a0b;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x33a423){this['_userLogHandler']=_0x33a423;}['debug'](..._0x7908e0){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x7908e0),this['_logHandler'](this,T['DEBUG'],..._0x7908e0);}['log'](..._0x3bf87d){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x3bf87d),this['_logHandler'](this,T['VERBOSE'],..._0x3bf87d);}['info'](..._0x6d8dad){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x6d8dad),this['_logHandler'](this,T['INFO'],..._0x6d8dad);}['warn'](..._0x1dcf6e){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1dcf6e),this['_logHandler'](this,T['WARN'],..._0x1dcf6e);}['error'](..._0x18fddf){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x18fddf),this['_logHandler'](this,T['ERROR'],..._0x18fddf);}}const xc=(_0x57bdb8,_0x339917)=>_0x339917['some'](_0x5ccda0=>_0x57bdb8 instanceof _0x5ccda0);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x50fafc){const _0x4195eb=new Promise((_0x280b3c,_0x2eda3b)=>{const _0xc64e61=()=>{_0x50fafc['removeEventListener']('success',_0x3f6af5),_0x50fafc['removeEventListener']('error',_0x26aaae);},_0x3f6af5=()=>{_0x280b3c(ge(_0x50fafc['result'])),_0xc64e61();},_0x26aaae=()=>{_0x2eda3b(_0x50fafc['error']),_0xc64e61();};_0x50fafc['addEventListener']('success',_0x3f6af5),_0x50fafc['addEventListener']('error',_0x26aaae);});return _0x4195eb['then'](_0x4f2afb=>{_0x4f2afb instanceof IDBCursor&&Jr['set'](_0x4f2afb,_0x50fafc);})['catch'](()=>{}),Vi['set'](_0x4195eb,_0x50fafc),_0x4195eb;}function Bc(_0x31a206){if(_i['has'](_0x31a206))return;const _0x38c8ac=new Promise((_0x1cdc17,_0x4017e8)=>{const _0x50801e=()=>{_0x31a206['removeEventListener']('complete',_0x708db),_0x31a206['removeEventListener']('error',_0x30eb7b),_0x31a206['removeEventListener']('abort',_0x30eb7b);},_0x708db=()=>{_0x1cdc17(),_0x50801e();},_0x30eb7b=()=>{_0x4017e8(_0x31a206['error']||new DOMException('AbortError','AbortError')),_0x50801e();};_0x31a206['addEventListener']('complete',_0x708db),_0x31a206['addEventListener']('error',_0x30eb7b),_0x31a206['addEventListener']('abort',_0x30eb7b);});_i['set'](_0x31a206,_0x38c8ac);}let gi={'get'(_0x4893c3,_0x4b0176,_0x2712ec){if(_0x4893c3 instanceof IDBTransaction){if(_0x4b0176==='done')return _i['get'](_0x4893c3);if(_0x4b0176==='objectStoreNames')return _0x4893c3['objectStoreNames']||Xr['get'](_0x4893c3);if(_0x4b0176==='store')return _0x2712ec['objectStoreNames'][0x1]?void 0x0:_0x2712ec['objectStore'](_0x2712ec['objectStoreNames'][0x0]);}return ge(_0x4893c3[_0x4b0176]);},'set'(_0x19ad1a,_0xa31720,_0xbcd335){return _0x19ad1a[_0xa31720]=_0xbcd335,!0x0;},'has'(_0x4d8ba7,_0x10e40f){return _0x4d8ba7 instanceof IDBTransaction&&(_0x10e40f==='done'||_0x10e40f==='store')?!0x0:_0x10e40f in _0x4d8ba7;}};function Vc(_0x31f2a0){gi=_0x31f2a0(gi);}function Hc(_0x62d9b7){return _0x62d9b7===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x93b0e3,..._0x4caf4b){const _0x2da3e9=_0x62d9b7['call'](ii(this),_0x93b0e3,..._0x4caf4b);return Xr['set'](_0x2da3e9,_0x93b0e3['sort']?_0x93b0e3['sort']():[_0x93b0e3]),ge(_0x2da3e9);}:Uc()['includes'](_0x62d9b7)?function(..._0x8fcaab){return _0x62d9b7['apply'](ii(this),_0x8fcaab),ge(Jr['get'](this));}:function(..._0x4aa60b){return ge(_0x62d9b7['apply'](ii(this),_0x4aa60b));};}function $c(_0x2f8119){return typeof _0x2f8119=='function'?Hc(_0x2f8119):(_0x2f8119 instanceof IDBTransaction&&Bc(_0x2f8119),xc(_0x2f8119,Fc())?new Proxy(_0x2f8119,gi):_0x2f8119);}function ge(_0x47b82b){if(_0x47b82b instanceof IDBRequest)return Wc(_0x47b82b);if(ni['has'](_0x47b82b))return ni['get'](_0x47b82b);const _0x4ce3d2=$c(_0x47b82b);return _0x4ce3d2!==_0x47b82b&&(ni['set'](_0x47b82b,_0x4ce3d2),Vi['set'](_0x4ce3d2,_0x47b82b)),_0x4ce3d2;}const ii=_0x5dffc3=>Vi['get'](_0x5dffc3);function Gc(_0x112f95,_0x1af505,{blocked:_0x265e80,upgrade:_0x1fad05,blocking:_0x422d00,terminated:_0xfe3fda}={}){const _0x1f4845=indexedDB['open'](_0x112f95,_0x1af505),_0x40115f=ge(_0x1f4845);return _0x1fad05&&_0x1f4845['addEventListener']('upgradeneeded',_0x51c3d3=>{_0x1fad05(ge(_0x1f4845['result']),_0x51c3d3['oldVersion'],_0x51c3d3['newVersion'],ge(_0x1f4845['transaction']),_0x51c3d3);}),_0x265e80&&_0x1f4845['addEventListener']('blocked',_0x740e39=>_0x265e80(_0x740e39['oldVersion'],_0x740e39['newVersion'],_0x740e39)),_0x40115f['then'](_0x1a90a0=>{_0xfe3fda&&_0x1a90a0['addEventListener']('close',()=>_0xfe3fda()),_0x422d00&&_0x1a90a0['addEventListener']('versionchange',_0x139563=>_0x422d00(_0x139563['oldVersion'],_0x139563['newVersion'],_0x139563));})['catch'](()=>{}),_0x40115f;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x43fc8e,_0x25f004){if(!(_0x43fc8e instanceof IDBDatabase&&!(_0x25f004 in _0x43fc8e)&&typeof _0x25f004=='string'))return;if(si['get'](_0x25f004))return si['get'](_0x25f004);const _0x19d4ef=_0x25f004['replace'](/FromIndex$/,''),_0x4e273e=_0x25f004!==_0x19d4ef,_0x31113b=zc['includes'](_0x19d4ef);if(!(_0x19d4ef in(_0x4e273e?IDBIndex:IDBObjectStore)['prototype'])||!(_0x31113b||qc['includes'](_0x19d4ef)))return;const _0x2a0c55=async function(_0x908b1e,..._0x27b6c1){const _0x39f434=this['transaction'](_0x908b1e,_0x31113b?'readwrite':'readonly');let _0x39f890=_0x39f434['store'];return _0x4e273e&&(_0x39f890=_0x39f890['index'](_0x27b6c1['shift']())),(await Promise['all']([_0x39f890[_0x19d4ef](..._0x27b6c1),_0x31113b&&_0x39f434['done']]))[0x0];};return si['set'](_0x25f004,_0x2a0c55),_0x2a0c55;}Vc(_0x2e3629=>({..._0x2e3629,'get':(_0x2716af,_0x52b00d,_0x48d5dc)=>Ms(_0x2716af,_0x52b00d)||_0x2e3629['get'](_0x2716af,_0x52b00d,_0x48d5dc),'has':(_0x5c1e5d,_0x6df18b)=>!!Ms(_0x5c1e5d,_0x6df18b)||_0x2e3629['has'](_0x5c1e5d,_0x6df18b)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x62729d){this['container']=_0x62729d;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x28ae8e=>{if(Kc(_0x28ae8e)){const _0x4b06a9=_0x28ae8e['getImmediate']();return _0x4b06a9['library']+'/'+_0x4b06a9['version'];}else return null;})['filter'](_0x2a411d=>_0x2a411d)['join']('\x20');}}function Kc(_0x4a75ea){const _0xcac5e4=_0x4a75ea['getComponent']();return(_0xcac5e4==null?void 0x0:_0xcac5e4['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x32d128,_0x5d97d4){try{_0x32d128['container']['addComponent'](_0x5d97d4);}catch(_0x5f3859){oe['debug']('Component\x20'+_0x5d97d4['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x32d128['name'],_0x5f3859);}}function st(_0x30bb27){const _0x15bcd0=_0x30bb27['name'];if(Ei['has'](_0x15bcd0))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x15bcd0+'.'),!0x1;Ei['set'](_0x15bcd0,_0x30bb27);for(const _0x43e32e of Ue['values']())xs(_0x43e32e,_0x30bb27);for(const _0x52ef51 of vi['values']())xs(_0x52ef51,_0x30bb27);return!0x0;}function Hi(_0x607b85,_0x2743ed){const _0x133135=_0x607b85['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x133135&&_0x133135['triggerHeartbeat'](),_0x607b85['container']['getProvider'](_0x2743ed);}function $(_0x2c3b5a){return _0x2c3b5a==null?!0x1:_0x2c3b5a['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5058c5,_0x5aafe1,_0x5101e8){this['_isDeleted']=!0x1,this['_options']={..._0x5058c5},this['_config']={..._0x5aafe1},this['_name']=_0x5aafe1['name'],this['_automaticDataCollectionEnabled']=_0x5aafe1['automaticDataCollectionEnabled'],this['_container']=_0x5101e8,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x424a57){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x424a57;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x4dc080){this['_isDeleted']=_0x4dc080;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x247e0c,_0x51bb47={}){let _0x3a0e77=_0x247e0c;typeof _0x51bb47!='object'&&(_0x51bb47={'name':_0x51bb47});const _0x81fdc3={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x51bb47},_0x3c8917=_0x81fdc3['name'];if(typeof _0x3c8917!='string'||!_0x3c8917)throw me['create']('bad-app-name',{'appName':String(_0x3c8917)});if(_0x3a0e77||(_0x3a0e77=zr()),!_0x3a0e77)throw me['create']('no-options');const _0x403786=Ue['get'](_0x3c8917);if(_0x403786){if(xe(_0x3a0e77,_0x403786['options'])&&xe(_0x81fdc3,_0x403786['config']))return _0x403786;throw me['create']('duplicate-app',{'appName':_0x3c8917});}const _0x49f745=new Nc(_0x3c8917);for(const _0x6461af of Ei['values']())_0x49f745['addComponent'](_0x6461af);const _0x156cd7=new Tl(_0x3a0e77,_0x81fdc3,_0x49f745);return Ue['set'](_0x3c8917,_0x156cd7),_0x156cd7;}function Zr(_0x1d6236=yi){const _0x29eacb=Ue['get'](_0x1d6236);if(!_0x29eacb&&_0x1d6236===yi&&zr())return Sl();if(!_0x29eacb)throw me['create']('no-app',{'appName':_0x1d6236});return _0x29eacb;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x140521){let _0x21f685=!0x1;const _0x304d5a=_0x140521['name'];Ue['has'](_0x304d5a)?(_0x21f685=!0x0,Ue['delete'](_0x304d5a)):vi['has'](_0x304d5a)&&_0x140521['decRefCount']()<=0x0&&(vi['delete'](_0x304d5a),_0x21f685=!0x0),_0x21f685&&(await Promise['all'](_0x140521['container']['getProviders']()['map'](_0x59218f=>_0x59218f['delete']())),_0x140521['isDeleted']=!0x0);}function ye(_0x46f489,_0x4af852,_0x4acc38){let _0x3109d3=wl[_0x46f489]??_0x46f489;_0x4acc38&&(_0x3109d3+='-'+_0x4acc38);const _0x40390d=_0x3109d3['match'](/\s|\//),_0x15c5af=_0x4af852['match'](/\s|\//);if(_0x40390d||_0x15c5af){const _0x3a089f=['Unable\x20to\x20register\x20library\x20\x22'+_0x3109d3+'\x22\x20with\x20version\x20\x22'+_0x4af852+'\x22:'];_0x40390d&&_0x3a089f['push']('library\x20name\x20\x22'+_0x3109d3+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x40390d&&_0x15c5af&&_0x3a089f['push']('and'),_0x15c5af&&_0x3a089f['push']('version\x20name\x20\x22'+_0x4af852+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x3a089f['join']('\x20'));return;}st(new Fe(_0x3109d3+'-version',()=>({'library':_0x3109d3,'version':_0x4af852}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x59879,_0x2b1352)=>{switch(_0x2b1352){case 0x0:try{_0x59879['createObjectStore'](Ot);}catch(_0x492c76){console['warn'](_0x492c76);}}}})['catch'](_0x5e9c89=>{throw me['create']('idb-open',{'originalErrorMessage':_0x5e9c89['message']});})),ri;}async function Al(_0x44eefc){try{const _0x16e98b=(await eo())['transaction'](Ot),_0x3abdd2=await _0x16e98b['objectStore'](Ot)['get'](to(_0x44eefc));return await _0x16e98b['done'],_0x3abdd2;}catch(_0x5b6933){if(_0x5b6933 instanceof Re)oe['warn'](_0x5b6933['message']);else{const _0x41175f=me['create']('idb-get',{'originalErrorMessage':_0x5b6933==null?void 0x0:_0x5b6933['message']});oe['warn'](_0x41175f['message']);}}}async function Fs(_0x4d8d16,_0x4ee3bc){try{const _0x477830=(await eo())['transaction'](Ot,'readwrite');await _0x477830['objectStore'](Ot)['put'](_0x4ee3bc,to(_0x4d8d16)),await _0x477830['done'];}catch(_0xff154){if(_0xff154 instanceof Re)oe['warn'](_0xff154['message']);else{const _0x372c09=me['create']('idb-set',{'originalErrorMessage':_0xff154==null?void 0x0:_0xff154['message']});oe['warn'](_0x372c09['message']);}}}function to(_0x15c9a7){return _0x15c9a7['name']+'!'+_0x15c9a7['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x37f446){this['container']=_0x37f446,this['_heartbeatsCache']=null;const _0x4f1c26=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x4f1c26),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2b733e=>(this['_heartbeatsCache']=_0x2b733e,_0x2b733e));}async['triggerHeartbeat'](){var _0x22d5bf,_0x39f204;try{const _0x3f4267=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xb5d37b=Us();if(((_0x22d5bf=this['_heartbeatsCache'])==null?void 0x0:_0x22d5bf['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x39f204=this['_heartbeatsCache'])==null?void 0x0:_0x39f204['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xb5d37b||this['_heartbeatsCache']['heartbeats']['some'](_0x59c2d5=>_0x59c2d5['date']===_0xb5d37b))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xb5d37b,'agent':_0x3f4267}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x27a91f=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x27a91f,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x169102){oe['warn'](_0x169102);}}async['getHeartbeatsHeader'](){var _0x141f1f;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x141f1f=this['_heartbeatsCache'])==null?void 0x0:_0x141f1f['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x51754a=Us(),{heartbeatsToSend:_0x2b9f06,unsentEntries:_0x65be5f}=Ol(this['_heartbeatsCache']['heartbeats']),_0x4c21e9=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2b9f06}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x51754a,_0x65be5f['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x65be5f,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4c21e9;}catch(_0x39dc69){return oe['warn'](_0x39dc69),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x42e7a7,_0x346fb5=kl){const _0x3f7693=[];let _0x4b4a07=_0x42e7a7['slice']();for(const _0x499658 of _0x42e7a7){const _0x1a21c5=_0x3f7693['find'](_0x5f4da7=>_0x5f4da7['agent']===_0x499658['agent']);if(_0x1a21c5){if(_0x1a21c5['dates']['push'](_0x499658['date']),Ws(_0x3f7693)>_0x346fb5){_0x1a21c5['dates']['pop']();break;}}else{if(_0x3f7693['push']({'agent':_0x499658['agent'],'dates':[_0x499658['date']]}),Ws(_0x3f7693)>_0x346fb5){_0x3f7693['pop']();break;}}_0x4b4a07=_0x4b4a07['slice'](0x1);}return{'heartbeatsToSend':_0x3f7693,'unsentEntries':_0x4b4a07};}class Dl{constructor(_0x4c61e0){this['app']=_0x4c61e0,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x51ab3e=await Al(this['app']);return _0x51ab3e!=null&&_0x51ab3e['heartbeats']?_0x51ab3e:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x37d5cb){if(await this['_canUseIndexedDBPromise']){const _0x5a06e8=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x37d5cb['lastSentHeartbeatDate']??_0x5a06e8['lastSentHeartbeatDate'],'heartbeats':_0x37d5cb['heartbeats']});}else return;}async['add'](_0x5cc84b){if(await this['_canUseIndexedDBPromise']){const _0x52cf56=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5cc84b['lastSentHeartbeatDate']??_0x52cf56['lastSentHeartbeatDate'],'heartbeats':[..._0x52cf56['heartbeats'],..._0x5cc84b['heartbeats']]});}else return;}}function Ws(_0x566e37){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x566e37}))['length'];}function Ml(_0x5a3dd1){if(_0x5a3dd1['length']===0x0)return-0x1;let _0x537018=0x0,_0x2fefa7=_0x5a3dd1[0x0]['date'];for(let _0x9959fa=0x1;_0x9959fa<_0x5a3dd1['length'];_0x9959fa++)_0x5a3dd1[_0x9959fa]['date']<_0x2fefa7&&(_0x2fefa7=_0x5a3dd1[_0x9959fa]['date'],_0x537018=_0x9959fa);return _0x537018;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x15ba46){st(new Fe('platform-logger',_0x4840fc=>new jc(_0x4840fc),'PRIVATE')),st(new Fe('heartbeat',_0x4bdbd9=>new Nl(_0x4bdbd9),'PRIVATE')),ye(mi,Ls,_0x15ba46),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x42a618){no=_0x42a618;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0xe8815d){this['domStorage_']=_0xe8815d,this['prefix_']='firebase:';}['set'](_0x30256f,_0x4eeffc){_0x4eeffc==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x30256f)):this['domStorage_']['setItem'](this['prefixedName_'](_0x30256f),O(_0x4eeffc));}['get'](_0x37b40f){const _0x383fb1=this['domStorage_']['getItem'](this['prefixedName_'](_0x37b40f));return _0x383fb1==null?null:Nt(_0x383fb1);}['remove'](_0x5c27f5){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5c27f5));}['prefixedName_'](_0x385ac8){return this['prefix_']+_0x385ac8;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x145734,_0x576718){_0x576718==null?delete this['cache_'][_0x145734]:this['cache_'][_0x145734]=_0x576718;}['get'](_0x461193){return Q(this['cache_'],_0x461193)?this['cache_'][_0x461193]:null;}['remove'](_0x37608b){delete this['cache_'][_0x37608b];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x42f0d5){try{if(typeof window<'u'&&typeof window[_0x42f0d5]<'u'){const _0x4b7aa1=window[_0x42f0d5];return _0x4b7aa1['setItem']('firebase:sentinel','cache'),_0x4b7aa1['removeItem']('firebase:sentinel'),new Wl(_0x4b7aa1);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x3e9db8=0x1;return function(){return _0x3e9db8++;};}()),ro=function(_0x117bfb){const _0x445682=Rc(_0x117bfb),_0x108d70=new Cc();_0x108d70['update'](_0x445682);const _0xb87ddc=_0x108d70['digest']();return Fi['encodeByteArray'](_0xb87ddc);},zt=function(..._0x4e36dd){let _0x37ae7d='';for(let _0x4d4c02=0x0;_0x4d4c02<_0x4e36dd['length'];_0x4d4c02++){const _0x16b105=_0x4e36dd[_0x4d4c02];Array['isArray'](_0x16b105)||_0x16b105&&typeof _0x16b105=='object'&&typeof _0x16b105['length']=='number'?_0x37ae7d+=zt['apply'](null,_0x16b105):typeof _0x16b105=='object'?_0x37ae7d+=O(_0x16b105):_0x37ae7d+=_0x16b105,_0x37ae7d+='\x20';}return _0x37ae7d;};let St=null,$s=!0x0;const Hl=function(_0x449cbf,_0x1ea109){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x9cd5b6){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x5ac068=zt['apply'](null,_0x9cd5b6);St(_0x5ac068);}},jt=function(_0x1941c9){return function(..._0x855453){L(_0x1941c9,..._0x855453);};},Ii=function(..._0x158d4b){const _0x25d12b='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x158d4b);Ze['error'](_0x25d12b);},ae=function(..._0x15528b){const _0x472285='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x15528b);throw Ze['error'](_0x472285),new Error(_0x472285);},U=function(..._0x4c2d8b){const _0x1bf977='FIREBASE\x20WARNING:\x20'+zt(..._0x4c2d8b);Ze['warn'](_0x1bf977);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x3b6163){return typeof _0x3b6163=='number'&&(_0x3b6163!==_0x3b6163||_0x3b6163===Number['POSITIVE_INFINITY']||_0x3b6163===Number['NEGATIVE_INFINITY']);},Gl=function(_0x184987){if(document['readyState']==='complete')_0x184987();else{let _0x593497=!0x1;const _0x16f1f2=function(){if(!document['body']){setTimeout(_0x16f1f2,Math['floor'](0xa));return;}_0x593497||(_0x593497=!0x0,_0x184987());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x16f1f2,!0x1),window['addEventListener']('load',_0x16f1f2,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x16f1f2();}),window['attachEvent']('onload',_0x16f1f2));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0xe73b38,_0x56f079){if(_0xe73b38===_0x56f079)return 0x0;if(_0xe73b38===We||_0x56f079===we)return-0x1;if(_0x56f079===We||_0xe73b38===we)return 0x1;{const _0x1bbe1a=Gs(_0xe73b38),_0x2a32b0=Gs(_0x56f079);return _0x1bbe1a!==null?_0x2a32b0!==null?_0x1bbe1a-_0x2a32b0===0x0?_0xe73b38['length']-_0x56f079['length']:_0x1bbe1a-_0x2a32b0:-0x1:_0x2a32b0!==null?0x1:_0xe73b38<_0x56f079?-0x1:0x1;}},ql=function(_0x75720d,_0x3c3efd){return _0x75720d===_0x3c3efd?0x0:_0x75720d<_0x3c3efd?-0x1:0x1;},vt=function(_0x3bd61b,_0xa36452){if(_0xa36452&&_0x3bd61b in _0xa36452)return _0xa36452[_0x3bd61b];throw new Error('Missing\x20required\x20key\x20('+_0x3bd61b+')\x20in\x20object:\x20'+O(_0xa36452));},$i=function(_0x1e8f66){if(typeof _0x1e8f66!='object'||_0x1e8f66===null)return O(_0x1e8f66);const _0x6ec253=[];for(const _0x5ecfe4 in _0x1e8f66)_0x6ec253['push'](_0x5ecfe4);_0x6ec253['sort']();let _0x4dff4e='{';for(let _0x5046be=0x0;_0x5046be<_0x6ec253['length'];_0x5046be++)_0x5046be!==0x0&&(_0x4dff4e+=','),_0x4dff4e+=O(_0x6ec253[_0x5046be]),_0x4dff4e+=':',_0x4dff4e+=$i(_0x1e8f66[_0x6ec253[_0x5046be]]);return _0x4dff4e+='}',_0x4dff4e;},oo=function(_0x36b2c9,_0x5cda2d){const _0x59c6e7=_0x36b2c9['length'];if(_0x59c6e7<=_0x5cda2d)return[_0x36b2c9];const _0x4f9b83=[];for(let _0x38f2a9=0x0;_0x38f2a9<_0x59c6e7;_0x38f2a9+=_0x5cda2d)_0x38f2a9+_0x5cda2d>_0x59c6e7?_0x4f9b83['push'](_0x36b2c9['substring'](_0x38f2a9,_0x59c6e7)):_0x4f9b83['push'](_0x36b2c9['substring'](_0x38f2a9,_0x38f2a9+_0x5cda2d));return _0x4f9b83;};function x(_0x2b72f9,_0x3b98e4){for(const _0x1fa269 in _0x2b72f9)_0x2b72f9['hasOwnProperty'](_0x1fa269)&&_0x3b98e4(_0x1fa269,_0x2b72f9[_0x1fa269]);}const ao=function(_0x25d72d){f(!xn(_0x25d72d),'Invalid\x20JSON\x20number');const _0x1f4edc=0xb,_0x8419c4=0x34,_0x487eb0=(0x1<<_0x1f4edc-0x1)-0x1;let _0x2e9e89,_0x2e1147,_0x53eba9,_0x38096c,_0x5caf43;_0x25d72d===0x0?(_0x2e1147=0x0,_0x53eba9=0x0,_0x2e9e89=0x1/_0x25d72d===-0x1/0x0?0x1:0x0):(_0x2e9e89=_0x25d72d<0x0,_0x25d72d=Math['abs'](_0x25d72d),_0x25d72d>=Math['pow'](0x2,0x1-_0x487eb0)?(_0x38096c=Math['min'](Math['floor'](Math['log'](_0x25d72d)/Math['LN2']),_0x487eb0),_0x2e1147=_0x38096c+_0x487eb0,_0x53eba9=Math['round'](_0x25d72d*Math['pow'](0x2,_0x8419c4-_0x38096c)-Math['pow'](0x2,_0x8419c4))):(_0x2e1147=0x0,_0x53eba9=Math['round'](_0x25d72d/Math['pow'](0x2,0x1-_0x487eb0-_0x8419c4))));const _0x5ef5c9=[];for(_0x5caf43=_0x8419c4;_0x5caf43;_0x5caf43-=0x1)_0x5ef5c9['push'](_0x53eba9%0x2?0x1:0x0),_0x53eba9=Math['floor'](_0x53eba9/0x2);for(_0x5caf43=_0x1f4edc;_0x5caf43;_0x5caf43-=0x1)_0x5ef5c9['push'](_0x2e1147%0x2?0x1:0x0),_0x2e1147=Math['floor'](_0x2e1147/0x2);_0x5ef5c9['push'](_0x2e9e89?0x1:0x0),_0x5ef5c9['reverse']();const _0x934b06=_0x5ef5c9['join']('');let _0x392292='';for(_0x5caf43=0x0;_0x5caf43<0x40;_0x5caf43+=0x8){let _0x54d753=parseInt(_0x934b06['substr'](_0x5caf43,0x8),0x2)['toString'](0x10);_0x54d753['length']===0x1&&(_0x54d753='0'+_0x54d753),_0x392292=_0x392292+_0x54d753;}return _0x392292['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x19c27c,_0x2cf84e){let _0x748ec1='Unknown\x20Error';_0x19c27c==='too_big'?_0x748ec1='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x19c27c==='permission_denied'?_0x748ec1='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x19c27c==='unavailable'&&(_0x748ec1='The\x20service\x20is\x20unavailable');const _0x37a333=new Error(_0x19c27c+'\x20at\x20'+_0x2cf84e['_path']['toString']()+':\x20'+_0x748ec1);return _0x37a333['code']=_0x19c27c['toUpperCase'](),_0x37a333;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x49548c){if(Yl['test'](_0x49548c)){const _0x56b9d3=Number(_0x49548c);if(_0x56b9d3>=Ql&&_0x56b9d3<=Jl)return _0x56b9d3;}return null;},ft=function(_0x3b494e){try{_0x3b494e();}catch(_0x113dda){setTimeout(()=>{const _0x24c8b5=_0x113dda['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x24c8b5),_0x113dda;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0xfe02d7,_0x32f1c7){const _0x568549=setTimeout(_0xfe02d7,_0x32f1c7);return typeof _0x568549=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x568549):typeof _0x568549=='object'&&_0x568549['unref']&&_0x568549['unref'](),_0x568549;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x54064e,_0x1a09f4){this['appCheckProvider']=_0x1a09f4,this['appName']=_0x54064e['name'],$(_0x54064e)&&_0x54064e['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x54064e['settings']['appCheckToken']),this['appCheck']=_0x1a09f4==null?void 0x0:_0x1a09f4['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1a09f4==null||_0x1a09f4['get']()['then'](_0x254fe4=>this['appCheck']=_0x254fe4);}['getToken'](_0xb844a2){if(this['serverAppAppCheckToken']){if(_0xb844a2)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0xb844a2):new Promise((_0x23e9c3,_0x7618b9)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0xb844a2)['then'](_0x23e9c3,_0x7618b9):_0x23e9c3(null);},0x0);});}['addTokenChangeListener'](_0x340b69){var _0x2da79f;(_0x2da79f=this['appCheckProvider'])==null||_0x2da79f['get']()['then'](_0xf96b06=>_0xf96b06['addTokenListener'](_0x340b69));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0xe2000e,_0x3a3c18,_0x5ab950){this['appName_']=_0xe2000e,this['firebaseOptions_']=_0x3a3c18,this['authProvider_']=_0x5ab950,this['auth_']=null,this['auth_']=_0x5ab950['getImmediate']({'optional':!0x0}),this['auth_']||_0x5ab950['onInit'](_0x418451=>this['auth_']=_0x418451);}['getToken'](_0x325a2f){return this['auth_']?this['auth_']['getToken'](_0x325a2f)['catch'](_0x42c080=>_0x42c080&&_0x42c080['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x42c080)):new Promise((_0x54f4e5,_0x1e2b40)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x325a2f)['then'](_0x54f4e5,_0x1e2b40):_0x54f4e5(null);},0x0);});}['addTokenChangeListener'](_0x483f31){this['auth_']?this['auth_']['addAuthTokenListener'](_0x483f31):this['authProvider_']['get']()['then'](_0x5c9635=>_0x5c9635['addAuthTokenListener'](_0x483f31));}['removeTokenChangeListener'](_0x364534){this['authProvider_']['get']()['then'](_0xf0c62e=>_0xf0c62e['removeAuthTokenListener'](_0x364534));}['notifyForInvalidToken'](){let _0x4adb38='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4adb38+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4adb38+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4adb38+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4adb38);}}class an{constructor(_0x130d7a){this['accessToken']=_0x130d7a;}['getToken'](_0x47943e){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x19d8fa){_0x19d8fa(this['accessToken']);}['removeTokenChangeListener'](_0x556783){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x1649f2,_0x510e7c,_0x428d07,_0x4ebf27,_0x13368f=!0x1,_0x260453='',_0x5bad8b=!0x1,_0x5068a4=!0x1,_0x187f23=null){this['secure']=_0x510e7c,this['namespace']=_0x428d07,this['webSocketOnly']=_0x4ebf27,this['nodeAdmin']=_0x13368f,this['persistenceKey']=_0x260453,this['includeNamespaceInQueryParams']=_0x5bad8b,this['isUsingEmulator']=_0x5068a4,this['emulatorOptions']=_0x187f23,this['_host']=_0x1649f2['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x1649f2)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x103612){_0x103612!==this['internalHost']&&(this['internalHost']=_0x103612,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0xf09bab=this['toURLString']();return this['persistenceKey']&&(_0xf09bab+='<'+this['persistenceKey']+'>'),_0xf09bab;}['toURLString'](){const _0x4f7c89=this['secure']?'https://':'http://',_0x5ea44b=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4f7c89+this['host']+'/'+_0x5ea44b;}}function th(_0x599a89){return _0x599a89['host']!==_0x599a89['internalHost']||_0x599a89['isCustomHost']()||_0x599a89['includeNamespaceInQueryParams'];}function vo(_0x202181,_0x347ebe,_0x4f3f7f){f(typeof _0x347ebe=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4f3f7f=='object','typeof\x20params\x20must\x20==\x20object');let _0x4a7629;if(_0x347ebe===go)_0x4a7629=(_0x202181['secure']?'wss://':'ws://')+_0x202181['internalHost']+'/.ws?';else{if(_0x347ebe===mo)_0x4a7629=(_0x202181['secure']?'https://':'http://')+_0x202181['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x347ebe);}th(_0x202181)&&(_0x4f3f7f['ns']=_0x202181['namespace']);const _0x496a87=[];return x(_0x4f3f7f,(_0x4f8d29,_0x165479)=>{_0x496a87['push'](_0x4f8d29+'='+_0x165479);}),_0x4a7629+_0x496a87['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x3a7b69,_0x4033cb=0x1){Q(this['counters_'],_0x3a7b69)||(this['counters_'][_0x3a7b69]=0x0),this['counters_'][_0x3a7b69]+=_0x4033cb;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x21a237){const _0x2e1429=_0x21a237['toString']();return oi[_0x2e1429]||(oi[_0x2e1429]=new nh()),oi[_0x2e1429];}function ih(_0x5903b3,_0x43879b){const _0x385a4b=_0x5903b3['toString']();return ai[_0x385a4b]||(ai[_0x385a4b]=_0x43879b()),ai[_0x385a4b];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4ab1e5){this['onMessage_']=_0x4ab1e5,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2bf1e0,_0x464534){this['closeAfterResponse']=_0x2bf1e0,this['onClose']=_0x464534,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x288cc9,_0x3dd7a7){for(this['pendingResponses'][_0x288cc9]=_0x3dd7a7;this['pendingResponses'][this['currentResponseNum']];){const _0x3dfda0=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1a0ccd=0x0;_0x1a0ccd<_0x3dfda0['length'];++_0x1a0ccd)_0x3dfda0[_0x1a0ccd]&&ft(()=>{this['onMessage_'](_0x3dfda0[_0x1a0ccd]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x1d8f45,_0x621ea1,_0x4b2438,_0x42f3a1,_0x2490a1,_0x2dcf64,_0x5bf520){this['connId']=_0x1d8f45,this['repoInfo']=_0x621ea1,this['applicationId']=_0x4b2438,this['appCheckToken']=_0x42f3a1,this['authToken']=_0x2490a1,this['transportSessionId']=_0x2dcf64,this['lastSessionId']=_0x5bf520,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x1d8f45),this['stats_']=qi(_0x621ea1),this['urlFn']=_0x4697af=>(this['appCheckToken']&&(_0x4697af[wi]=this['appCheckToken']),vo(_0x621ea1,mo,_0x4697af));}['open'](_0x36dbe5,_0x1072cb){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1072cb,this['myPacketOrderer']=new sh(_0x36dbe5),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x38c29b)=>{const [_0x195b95,_0x1b0dfa,_0x3b40d3,_0x8bb6e1,_0x53f684]=_0x38c29b;if(this['incrementIncomingBytes_'](_0x38c29b),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x195b95===qs)this['id']=_0x1b0dfa,this['password']=_0x3b40d3;else{if(_0x195b95===rh)_0x1b0dfa?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1b0dfa,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x195b95);}}},(..._0x20d5c7)=>{const [_0x16d45b,_0x4597be]=_0x20d5c7;this['incrementIncomingBytes_'](_0x20d5c7),this['myPacketOrderer']['handleResponse'](_0x16d45b,_0x4597be);},()=>{this['onClosed_']();},this['urlFn']);const _0x12183e={};_0x12183e[qs]='t',_0x12183e[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x12183e[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x12183e[co]=Gi,this['transportSessionId']&&(_0x12183e[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x12183e[po]=this['lastSessionId']),this['applicationId']&&(_0x12183e[_o]=this['applicationId']),this['appCheckToken']&&(_0x12183e[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x12183e[ho]=uo);const _0x5cf1d8=this['urlFn'](_0x12183e);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5cf1d8),this['scriptTagHolder']['addTag'](_0x5cf1d8,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4a284c){const _0x429ad6=O(_0x4a284c);this['bytesSent']+=_0x429ad6['length'],this['stats_']['incrementCounter']('bytes_sent',_0x429ad6['length']);const _0x169c75=$r(_0x429ad6),_0x481089=oo(_0x169c75,fh);for(let _0x3b4049=0x0;_0x3b4049<_0x481089['length'];_0x3b4049++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x481089['length'],_0x481089[_0x3b4049]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x435969,_0x4abca9){this['myDisconnFrame']=document['createElement']('iframe');const _0x530d59={};_0x530d59[dh]='t',_0x530d59[Eo]=_0x435969,_0x530d59[Io]=_0x4abca9,this['myDisconnFrame']['src']=this['urlFn'](_0x530d59),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x553515){const _0x345437=O(_0x553515)['length'];this['bytesReceived']+=_0x345437,this['stats_']['incrementCounter']('bytes_received',_0x345437);}}class zi{constructor(_0x4fbb56,_0x2a529b,_0x2895cb,_0x34e670){this['onDisconnect']=_0x2895cb,this['urlFn']=_0x34e670,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x4fbb56,window[ah+this['uniqueCallbackIdentifier']]=_0x2a529b,this['myIFrame']=zi['createIFrame_']();let _0x3bd32e='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3bd32e='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3e35c2='<html><body>'+_0x3bd32e+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3e35c2),this['myIFrame']['doc']['close']();}catch(_0x40a221){L('frame\x20writing\x20exception'),_0x40a221['stack']&&L(_0x40a221['stack']),L(_0x40a221);}}}static['createIFrame_'](){const _0x3a1880=document['createElement']('iframe');if(_0x3a1880['style']['display']='none',document['body']){document['body']['appendChild'](_0x3a1880);try{_0x3a1880['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0xa77f17=document['domain'];_0x3a1880['src']='javascript:void((function(){document.open();document.domain=\x27'+_0xa77f17+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3a1880['contentDocument']?_0x3a1880['doc']=_0x3a1880['contentDocument']:_0x3a1880['contentWindow']?_0x3a1880['doc']=_0x3a1880['contentWindow']['document']:_0x3a1880['document']&&(_0x3a1880['doc']=_0x3a1880['document']),_0x3a1880;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x57f23f=this['onDisconnect'];_0x57f23f&&(this['onDisconnect']=null,_0x57f23f());}['startLongPoll'](_0x14cac9,_0x256450){for(this['myID']=_0x14cac9,this['myPW']=_0x256450,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x379c04={};_0x379c04[Eo]=this['myID'],_0x379c04[Io]=this['myPW'],_0x379c04[wo]=this['currentSerial'];let _0x2a4939=this['urlFn'](_0x379c04),_0x4504e2='',_0x1d2d94=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x4504e2['length']<=Co;){const _0x1c50f0=this['pendingSegs']['shift']();_0x4504e2=_0x4504e2+'&'+lh+_0x1d2d94+'='+_0x1c50f0['seg']+'&'+hh+_0x1d2d94+'='+_0x1c50f0['ts']+'&'+uh+_0x1d2d94+'='+_0x1c50f0['d'],_0x1d2d94++;}return _0x2a4939=_0x2a4939+_0x4504e2,this['addLongPollTag_'](_0x2a4939,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x22838a,_0x4127b1,_0x2708c9){this['pendingSegs']['push']({'seg':_0x22838a,'ts':_0x4127b1,'d':_0x2708c9}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4ed059,_0x2ae15e){this['outstandingRequests']['add'](_0x2ae15e);const _0x30040c=()=>{this['outstandingRequests']['delete'](_0x2ae15e),this['newRequest_']();},_0x1c3985=setTimeout(_0x30040c,Math['floor'](ph)),_0x3431ea=()=>{clearTimeout(_0x1c3985),_0x30040c();};this['addTag'](_0x4ed059,_0x3431ea);}['addTag'](_0x2dc79d,_0x3c8476){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x55db88=this['myIFrame']['doc']['createElement']('script');_0x55db88['type']='text/javascript',_0x55db88['async']=!0x0,_0x55db88['src']=_0x2dc79d,_0x55db88['onload']=_0x55db88['onreadystatechange']=function(){const _0x23fc2d=_0x55db88['readyState'];(!_0x23fc2d||_0x23fc2d==='loaded'||_0x23fc2d==='complete')&&(_0x55db88['onload']=_0x55db88['onreadystatechange']=null,_0x55db88['parentNode']&&_0x55db88['parentNode']['removeChild'](_0x55db88),_0x3c8476());},_0x55db88['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2dc79d),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x55db88);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x192f95,_0x12e64f,_0x36215b,_0x260f33,_0x442496,_0x51500a,_0x295cc6){this['connId']=_0x192f95,this['applicationId']=_0x36215b,this['appCheckToken']=_0x260f33,this['authToken']=_0x442496,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x12e64f),this['connURL']=q['connectionURL_'](_0x12e64f,_0x51500a,_0x295cc6,_0x260f33,_0x36215b),this['nodeAdmin']=_0x12e64f['nodeAdmin'];}static['connectionURL_'](_0x101d91,_0x257726,_0xfb8d2b,_0x52f188,_0x38bb64){const _0x4580ad={};return _0x4580ad[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4580ad[ho]=uo),_0x257726&&(_0x4580ad[lo]=_0x257726),_0xfb8d2b&&(_0x4580ad[po]=_0xfb8d2b),_0x52f188&&(_0x4580ad[wi]=_0x52f188),_0x38bb64&&(_0x4580ad[_o]=_0x38bb64),vo(_0x101d91,go,_0x4580ad);}['open'](_0x3d7f1f,_0x186f02){this['onDisconnect']=_0x186f02,this['onMessage']=_0x3d7f1f,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x25f74e;_c(),this['mySock']=new gn(this['connURL'],[],_0x25f74e);}catch(_0x4a2a5c){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1dbab6=_0x4a2a5c['message']||_0x4a2a5c['data'];_0x1dbab6&&this['log_'](_0x1dbab6),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1a474b=>{this['handleIncomingFrame'](_0x1a474b);},this['mySock']['onerror']=_0x2160da=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1a03d7=_0x2160da['message']||_0x2160da['data'];_0x1a03d7&&this['log_'](_0x1a03d7),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x31ff04=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x182581=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x15261d=navigator['userAgent']['match'](_0x182581);_0x15261d&&_0x15261d['length']>0x1&&parseFloat(_0x15261d[0x1])<4.4&&(_0x31ff04=!0x0);}return!_0x31ff04&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x218da0){if(this['frames']['push'](_0x218da0),this['frames']['length']===this['totalFrames']){const _0x19e115=this['frames']['join']('');this['frames']=null;const _0x2658da=Nt(_0x19e115);this['onMessage'](_0x2658da);}}['handleNewFrameCount_'](_0x297d71){this['totalFrames']=_0x297d71,this['frames']=[];}['extractFrameCount_'](_0x33e200){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x33e200['length']<=0x6){const _0x2ed6a8=Number(_0x33e200);if(!isNaN(_0x2ed6a8))return this['handleNewFrameCount_'](_0x2ed6a8),null;}return this['handleNewFrameCount_'](0x1),_0x33e200;}['handleIncomingFrame'](_0x3b2e64){if(this['mySock']===null)return;const _0x13d8ba=_0x3b2e64['data'];if(this['bytesReceived']+=_0x13d8ba['length'],this['stats_']['incrementCounter']('bytes_received',_0x13d8ba['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x13d8ba);else{const _0x1fab6f=this['extractFrameCount_'](_0x13d8ba);_0x1fab6f!==null&&this['appendFrame_'](_0x1fab6f);}}['send'](_0x40ef66){this['resetKeepAlive']();const _0x153125=O(_0x40ef66);this['bytesSent']+=_0x153125['length'],this['stats_']['incrementCounter']('bytes_sent',_0x153125['length']);const _0x5537ff=oo(_0x153125,gh);_0x5537ff['length']>0x1&&this['sendString_'](String(_0x5537ff['length']));for(let _0x3b3170=0x0;_0x3b3170<_0x5537ff['length'];_0x3b3170++)this['sendString_'](_0x5537ff[_0x3b3170]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x4be37d){try{this['mySock']['send'](_0x4be37d);}catch(_0x320255){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x320255['message']||_0x320255['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x47c9e9){this['initTransports_'](_0x47c9e9);}['initTransports_'](_0xaba06b){const _0x444e93=q&&q['isAvailable']();let _0x536dbe=_0x444e93&&!q['previouslyFailed']();if(_0xaba06b['webSocketOnly']&&(_0x444e93||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x536dbe=!0x0),_0x536dbe)this['transports_']=[q];else{const _0x5039bc=this['transports_']=[];for(const _0x11298d of Dt['ALL_TRANSPORTS'])_0x11298d&&_0x11298d['isAvailable']()&&_0x5039bc['push'](_0x11298d);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x3bcc66,_0x2fde57,_0x133920,_0x5d9a95,_0x4187f8,_0x5eaf5a,_0x3dba7c,_0x37a52e,_0x430aac,_0x5e1e59){this['id']=_0x3bcc66,this['repoInfo_']=_0x2fde57,this['applicationId_']=_0x133920,this['appCheckToken_']=_0x5d9a95,this['authToken_']=_0x4187f8,this['onMessage_']=_0x5eaf5a,this['onReady_']=_0x3dba7c,this['onDisconnect_']=_0x37a52e,this['onKill_']=_0x430aac,this['lastSessionId']=_0x5e1e59,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x2fde57),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2681c2=this['transportManager_']['initialTransport']();this['conn_']=new _0x2681c2(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2681c2['responsesRequiredToBeHealthy']||0x0;const _0x3eb4d5=this['connReceiver_'](this['conn_']),_0x13d142=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3eb4d5,_0x13d142);},Math['floor'](0x0));const _0xc594b7=_0x2681c2['healthyTimeout']||0x0;_0xc594b7>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xc594b7)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1eeb54){return _0x16ed6b=>{_0x1eeb54===this['conn_']?this['onConnectionLost_'](_0x16ed6b):_0x1eeb54===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x11caab){return _0x4595d3=>{this['state_']!==0x2&&(_0x11caab===this['rx_']?this['onPrimaryMessageReceived_'](_0x4595d3):_0x11caab===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4595d3):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x167cd9){const _0x1e4d95={'t':'d','d':_0x167cd9};this['sendData_'](_0x1e4d95);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2a2ee7){if(ci in _0x2a2ee7){const _0x281039=_0x2a2ee7[ci];_0x281039===Ys?this['upgradeIfSecondaryHealthy_']():_0x281039===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x281039===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x1bae1f){const _0x3a51cf=vt('t',_0x1bae1f),_0xf2fab5=vt('d',_0x1bae1f);if(_0x3a51cf==='c')this['onSecondaryControl_'](_0xf2fab5);else{if(_0x3a51cf==='d')this['pendingDataMessages']['push'](_0xf2fab5);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3a51cf);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2f1bf1){const _0x4c2aa1=vt('t',_0x2f1bf1),_0x2e4ff6=vt('d',_0x2f1bf1);_0x4c2aa1==='c'?this['onControl_'](_0x2e4ff6):_0x4c2aa1==='d'&&this['onDataMessage_'](_0x2e4ff6);}['onDataMessage_'](_0x4cd14){this['onPrimaryResponse_'](),this['onMessage_'](_0x4cd14);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4495b9){const _0x570de1=vt(ci,_0x4495b9);if(zs in _0x4495b9){const _0x3f1edd=_0x4495b9[zs];if(_0x570de1===Th){const _0x21d66d={..._0x3f1edd};this['repoInfo_']['isUsingEmulator']&&(_0x21d66d['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x21d66d);}else{if(_0x570de1===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x504b90=0x0;_0x504b90<this['pendingDataMessages']['length'];++_0x504b90)this['onDataMessage_'](this['pendingDataMessages'][_0x504b90]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x570de1===wh?this['onConnectionShutdown_'](_0x3f1edd):_0x570de1===js?this['onReset_'](_0x3f1edd):_0x570de1===Ch?Ii('Server\x20Error:\x20'+_0x3f1edd):_0x570de1===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x570de1);}}}['onHandshake_'](_0x17f8ee){const _0x459a88=_0x17f8ee['ts'],_0xc578e7=_0x17f8ee['v'],_0x809ab9=_0x17f8ee['h'];this['sessionId']=_0x17f8ee['s'],this['repoInfo_']['host']=_0x809ab9,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x459a88),Gi!==_0xc578e7&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2ed405=this['transportManager_']['upgradeTransport']();_0x2ed405&&this['startUpgrade_'](_0x2ed405);}['startUpgrade_'](_0x4f188c){this['secondaryConn_']=new _0x4f188c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4f188c['responsesRequiredToBeHealthy']||0x0;const _0x344765=this['connReceiver_'](this['secondaryConn_']),_0x1e1aba=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x344765,_0x1e1aba),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0xed2a32){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xed2a32),this['repoInfo_']['host']=_0xed2a32,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x33b4d7,_0x4f4100){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x33b4d7,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4f4100,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x432084=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x432084||this['rx_']===_0x432084)&&this['close']();}['onConnectionLost_'](_0x548207){this['conn_']=null,!_0x548207&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4637ac){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4637ac),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2409fb){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2409fb);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x206f2c,_0x59ce8c,_0x1a2ab0,_0x4ed5b6){}['merge'](_0x49d8f1,_0x4063ab,_0x306a01,_0x5f5564){}['refreshAuthToken'](_0x48a05b){}['refreshAppCheckToken'](_0x5c034d){}['onDisconnectPut'](_0x45bfc1,_0x44b3c1,_0x3a9756){}['onDisconnectMerge'](_0x393d9a,_0xbbee0c,_0x203b53){}['onDisconnectCancel'](_0x465e25,_0x4baa6a){}['reportStats'](_0xc054fe){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1a7d47){this['allowedEvents_']=_0x1a7d47,this['listeners_']={},f(Array['isArray'](_0x1a7d47)&&_0x1a7d47['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3a8f14,..._0x4aeac6){if(Array['isArray'](this['listeners_'][_0x3a8f14])){const _0x3a61e9=[...this['listeners_'][_0x3a8f14]];for(let _0x470182=0x0;_0x470182<_0x3a61e9['length'];_0x470182++)_0x3a61e9[_0x470182]['callback']['apply'](_0x3a61e9[_0x470182]['context'],_0x4aeac6);}}['on'](_0x36861f,_0x33d3ba,_0x48639a){this['validateEventType_'](_0x36861f),this['listeners_'][_0x36861f]=this['listeners_'][_0x36861f]||[],this['listeners_'][_0x36861f]['push']({'callback':_0x33d3ba,'context':_0x48639a});const _0x33136b=this['getInitialEvent'](_0x36861f);_0x33136b&&_0x33d3ba['apply'](_0x48639a,_0x33136b);}['off'](_0x4a1bc7,_0x14c9fa,_0x20b9ea){this['validateEventType_'](_0x4a1bc7);const _0x410259=this['listeners_'][_0x4a1bc7]||[];for(let _0x397373=0x0;_0x397373<_0x410259['length'];_0x397373++)if(_0x410259[_0x397373]['callback']===_0x14c9fa&&(!_0x20b9ea||_0x20b9ea===_0x410259[_0x397373]['context'])){_0x410259['splice'](_0x397373,0x1);return;}}['validateEventType_'](_0x1945cf){f(this['allowedEvents_']['find'](_0xe2bfd1=>_0xe2bfd1===_0x1945cf),'Unknown\x20event:\x20'+_0x1945cf);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2fe206){return f(_0x2fe206==='online','Unknown\x20event\x20type:\x20'+_0x2fe206),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x3c8c1a,_0x3530f7){if(_0x3530f7===void 0x0){this['pieces_']=_0x3c8c1a['split']('/');let _0x4938b5=0x0;for(let _0xe751fe=0x0;_0xe751fe<this['pieces_']['length'];_0xe751fe++)this['pieces_'][_0xe751fe]['length']>0x0&&(this['pieces_'][_0x4938b5]=this['pieces_'][_0xe751fe],_0x4938b5++);this['pieces_']['length']=_0x4938b5,this['pieceNum_']=0x0;}else this['pieces_']=_0x3c8c1a,this['pieceNum_']=_0x3530f7;}['toString'](){let _0x3fb20b='';for(let _0x4d0eff=this['pieceNum_'];_0x4d0eff<this['pieces_']['length'];_0x4d0eff++)this['pieces_'][_0x4d0eff]!==''&&(_0x3fb20b+='/'+this['pieces_'][_0x4d0eff]);return _0x3fb20b||'/';}}function w(){return new C('');}function y(_0x195c7b){return _0x195c7b['pieceNum_']>=_0x195c7b['pieces_']['length']?null:_0x195c7b['pieces_'][_0x195c7b['pieceNum_']];}function Ce(_0x715b6a){return _0x715b6a['pieces_']['length']-_0x715b6a['pieceNum_'];}function S(_0x4602d0){let _0x54cd75=_0x4602d0['pieceNum_'];return _0x54cd75<_0x4602d0['pieces_']['length']&&_0x54cd75++,new C(_0x4602d0['pieces_'],_0x54cd75);}function ji(_0x312405){return _0x312405['pieceNum_']<_0x312405['pieces_']['length']?_0x312405['pieces_'][_0x312405['pieces_']['length']-0x1]:null;}function bh(_0x38d545){let _0x32e60e='';for(let _0x55a1fd=_0x38d545['pieceNum_'];_0x55a1fd<_0x38d545['pieces_']['length'];_0x55a1fd++)_0x38d545['pieces_'][_0x55a1fd]!==''&&(_0x32e60e+='/'+encodeURIComponent(String(_0x38d545['pieces_'][_0x55a1fd])));return _0x32e60e||'/';}function Mt(_0x45db32,_0x26b3da=0x0){return _0x45db32['pieces_']['slice'](_0x45db32['pieceNum_']+_0x26b3da);}function Ro(_0x1d5dd4){if(_0x1d5dd4['pieceNum_']>=_0x1d5dd4['pieces_']['length'])return null;const _0x43bba7=[];for(let _0x6d73a0=_0x1d5dd4['pieceNum_'];_0x6d73a0<_0x1d5dd4['pieces_']['length']-0x1;_0x6d73a0++)_0x43bba7['push'](_0x1d5dd4['pieces_'][_0x6d73a0]);return new C(_0x43bba7,0x0);}function k(_0xcf64c3,_0x41af24){const _0x37d100=[];for(let _0x5edfcc=_0xcf64c3['pieceNum_'];_0x5edfcc<_0xcf64c3['pieces_']['length'];_0x5edfcc++)_0x37d100['push'](_0xcf64c3['pieces_'][_0x5edfcc]);if(_0x41af24 instanceof C){for(let _0x1d90a8=_0x41af24['pieceNum_'];_0x1d90a8<_0x41af24['pieces_']['length'];_0x1d90a8++)_0x37d100['push'](_0x41af24['pieces_'][_0x1d90a8]);}else{const _0x3128f9=_0x41af24['split']('/');for(let _0x241b53=0x0;_0x241b53<_0x3128f9['length'];_0x241b53++)_0x3128f9[_0x241b53]['length']>0x0&&_0x37d100['push'](_0x3128f9[_0x241b53]);}return new C(_0x37d100,0x0);}function v(_0x16a4d0){return _0x16a4d0['pieceNum_']>=_0x16a4d0['pieces_']['length'];}function F(_0x139a24,_0x487840){const _0x47ecf1=y(_0x139a24),_0x175490=y(_0x487840);if(_0x47ecf1===null)return _0x487840;if(_0x47ecf1===_0x175490)return F(S(_0x139a24),S(_0x487840));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x487840+')\x20is\x20not\x20within\x20outerPath\x20('+_0x139a24+')');}function Rh(_0x123402,_0x4561b8){const _0x5e1a38=Mt(_0x123402,0x0),_0x156f60=Mt(_0x4561b8,0x0);for(let _0x5dc89f=0x0;_0x5dc89f<_0x5e1a38['length']&&_0x5dc89f<_0x156f60['length'];_0x5dc89f++){const _0x2b333f=qe(_0x5e1a38[_0x5dc89f],_0x156f60[_0x5dc89f]);if(_0x2b333f!==0x0)return _0x2b333f;}return _0x5e1a38['length']===_0x156f60['length']?0x0:_0x5e1a38['length']<_0x156f60['length']?-0x1:0x1;}function Ki(_0x5b55ee,_0x33b294){if(Ce(_0x5b55ee)!==Ce(_0x33b294))return!0x1;for(let _0x41d136=_0x5b55ee['pieceNum_'],_0x26b3f9=_0x33b294['pieceNum_'];_0x41d136<=_0x5b55ee['pieces_']['length'];_0x41d136++,_0x26b3f9++)if(_0x5b55ee['pieces_'][_0x41d136]!==_0x33b294['pieces_'][_0x26b3f9])return!0x1;return!0x0;}function G(_0x478271,_0x41c04d){let _0xa2f647=_0x478271['pieceNum_'],_0x4d649a=_0x41c04d['pieceNum_'];if(Ce(_0x478271)>Ce(_0x41c04d))return!0x1;for(;_0xa2f647<_0x478271['pieces_']['length'];){if(_0x478271['pieces_'][_0xa2f647]!==_0x41c04d['pieces_'][_0x4d649a])return!0x1;++_0xa2f647,++_0x4d649a;}return!0x0;}class Ah{constructor(_0x432923,_0x1a38b0){this['errorPrefix_']=_0x1a38b0,this['parts_']=Mt(_0x432923,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2bf95a=0x0;_0x2bf95a<this['parts_']['length'];_0x2bf95a++)this['byteLength_']+=Ln(this['parts_'][_0x2bf95a]);Ao(this);}}function kh(_0x485457,_0x2befdf){_0x485457['parts_']['length']>0x0&&(_0x485457['byteLength_']+=0x1),_0x485457['parts_']['push'](_0x2befdf),_0x485457['byteLength_']+=Ln(_0x2befdf),Ao(_0x485457);}function Ph(_0x10bab1){const _0x26e283=_0x10bab1['parts_']['pop']();_0x10bab1['byteLength_']-=Ln(_0x26e283),_0x10bab1['parts_']['length']>0x0&&(_0x10bab1['byteLength_']-=0x1);}function Ao(_0x4d6f55){if(_0x4d6f55['byteLength_']>Zs)throw new Error(_0x4d6f55['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x4d6f55['byteLength_']+').');if(_0x4d6f55['parts_']['length']>Xs)throw new Error(_0x4d6f55['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x4d6f55));}function Oe(_0x24cb54){return _0x24cb54['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x24cb54['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x350c41,_0x3def40;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3def40='visibilitychange',_0x350c41='hidden'):typeof document['mozHidden']<'u'?(_0x3def40='mozvisibilitychange',_0x350c41='mozHidden'):typeof document['msHidden']<'u'?(_0x3def40='msvisibilitychange',_0x350c41='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3def40='webkitvisibilitychange',_0x350c41='webkitHidden')),this['visible_']=!0x0,_0x3def40&&document['addEventListener'](_0x3def40,()=>{const _0x4ce618=!document[_0x350c41];_0x4ce618!==this['visible_']&&(this['visible_']=_0x4ce618,this['trigger']('visible',_0x4ce618));},!0x1);}['getInitialEvent'](_0x28a766){return f(_0x28a766==='visible','Unknown\x20event\x20type:\x20'+_0x28a766),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x217d8c,_0x55d3ff,_0x5468ad,_0x1b56f9,_0x2eb514,_0x5a04ec,_0x457608,_0x5db019){if(super(),this['repoInfo_']=_0x217d8c,this['applicationId_']=_0x55d3ff,this['onDataUpdate_']=_0x5468ad,this['onConnectStatus_']=_0x1b56f9,this['onServerInfoUpdate_']=_0x2eb514,this['authTokenProvider_']=_0x5a04ec,this['appCheckTokenProvider_']=_0x457608,this['authOverride_']=_0x5db019,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x5db019)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x217d8c['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x50f84f,_0x30ff56,_0x58e222){const _0x11f1cd=++this['requestNumber_'],_0x439cfe={'r':_0x11f1cd,'a':_0x50f84f,'b':_0x30ff56};this['log_'](O(_0x439cfe)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x439cfe),_0x58e222&&(this['requestCBHash_'][_0x11f1cd]=_0x58e222);}['get'](_0x33b944){this['initConnection_']();const _0x249877=new H(),_0x2072d4={'action':'g','request':{'p':_0x33b944['_path']['toString'](),'q':_0x33b944['_queryObject']},'onComplete':_0x50ce99=>{const _0xbd2fd6=_0x50ce99['d'];_0x50ce99['s']==='ok'?_0x249877['resolve'](_0xbd2fd6):_0x249877['reject'](_0xbd2fd6);}};this['outstandingGets_']['push'](_0x2072d4),this['outstandingGetCount_']++;const _0x49facb=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x49facb),_0x249877['promise'];}['listen'](_0x305991,_0x393d1b,_0x483e44,_0x17240c){this['initConnection_']();const _0x2ddb55=_0x305991['_queryIdentifier'],_0x5e673e=_0x305991['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5e673e+'\x20'+_0x2ddb55),this['listens']['has'](_0x5e673e)||this['listens']['set'](_0x5e673e,new Map()),f(_0x305991['_queryParams']['isDefault']()||!_0x305991['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x5e673e)['has'](_0x2ddb55),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2ac0aa={'onComplete':_0x17240c,'hashFn':_0x393d1b,'query':_0x305991,'tag':_0x483e44};this['listens']['get'](_0x5e673e)['set'](_0x2ddb55,_0x2ac0aa),this['connected_']&&this['sendListen_'](_0x2ac0aa);}['sendGet_'](_0x5c5d3b){const _0x4aa632=this['outstandingGets_'][_0x5c5d3b];this['sendRequest']('g',_0x4aa632['request'],_0x4ca327=>{delete this['outstandingGets_'][_0x5c5d3b],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x4aa632['onComplete']&&_0x4aa632['onComplete'](_0x4ca327);});}['sendListen_'](_0x41f177){const _0x307c51=_0x41f177['query'],_0x1c45ef=_0x307c51['_path']['toString'](),_0x3c7c86=_0x307c51['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1c45ef+'\x20for\x20'+_0x3c7c86);const _0x3048fb={'p':_0x1c45ef},_0x72706e='q';_0x41f177['tag']&&(_0x3048fb['q']=_0x307c51['_queryObject'],_0x3048fb['t']=_0x41f177['tag']),_0x3048fb['h']=_0x41f177['hashFn'](),this['sendRequest'](_0x72706e,_0x3048fb,_0x4fd521=>{const _0x51a30d=_0x4fd521['d'],_0x3589aa=_0x4fd521['s'];se['warnOnListenWarnings_'](_0x51a30d,_0x307c51),(this['listens']['get'](_0x1c45ef)&&this['listens']['get'](_0x1c45ef)['get'](_0x3c7c86))===_0x41f177&&(this['log_']('listen\x20response',_0x4fd521),_0x3589aa!=='ok'&&this['removeListen_'](_0x1c45ef,_0x3c7c86),_0x41f177['onComplete']&&_0x41f177['onComplete'](_0x3589aa,_0x51a30d));});}static['warnOnListenWarnings_'](_0x1bf317,_0x570c04){if(_0x1bf317&&typeof _0x1bf317=='object'&&Q(_0x1bf317,'w')){const _0x207065=Le(_0x1bf317,'w');if(Array['isArray'](_0x207065)&&~_0x207065['indexOf']('no_index')){const _0x1102f7='\x22.indexOn\x22:\x20\x22'+_0x570c04['_queryParams']['getIndex']()['toString']()+'\x22',_0xde03e0=_0x570c04['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1102f7+'\x20at\x20'+_0xde03e0+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2e9a74){this['authToken_']=_0x2e9a74,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2e9a74);}['reduceReconnectDelayIfAdminCredential_'](_0x45a227){(_0x45a227&&_0x45a227['length']===0x28||wc(_0x45a227))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x47f0ad){this['appCheckToken_']=_0x47f0ad,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4688d1=this['authToken_'],_0x2b7438=Ic(_0x4688d1)?'auth':'gauth',_0x126f40={'cred':_0x4688d1};this['authOverride_']===null?_0x126f40['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x126f40['authvar']=this['authOverride_']),this['sendRequest'](_0x2b7438,_0x126f40,_0x429a73=>{const _0x350e46=_0x429a73['s'],_0xa9da14=_0x429a73['d']||'error';this['authToken_']===_0x4688d1&&(_0x350e46==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x350e46,_0xa9da14));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x29181a=>{const _0x2a4128=_0x29181a['s'],_0x28702b=_0x29181a['d']||'error';_0x2a4128==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2a4128,_0x28702b);});}['unlisten'](_0x41940f,_0x1bf42d){const _0x39eafc=_0x41940f['_path']['toString'](),_0x2bf4cd=_0x41940f['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x39eafc+'\x20'+_0x2bf4cd),f(_0x41940f['_queryParams']['isDefault']()||!_0x41940f['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x39eafc,_0x2bf4cd)&&this['connected_']&&this['sendUnlisten_'](_0x39eafc,_0x2bf4cd,_0x41940f['_queryObject'],_0x1bf42d);}['sendUnlisten_'](_0x315f68,_0x73cc68,_0x188761,_0x51d72d){this['log_']('Unlisten\x20on\x20'+_0x315f68+'\x20for\x20'+_0x73cc68);const _0x51c066={'p':_0x315f68},_0x26dc31='n';_0x51d72d&&(_0x51c066['q']=_0x188761,_0x51c066['t']=_0x51d72d),this['sendRequest'](_0x26dc31,_0x51c066);}['onDisconnectPut'](_0x5b04c4,_0x209175,_0x2c6b27){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5b04c4,_0x209175,_0x2c6b27):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5b04c4,'action':'o','data':_0x209175,'onComplete':_0x2c6b27});}['onDisconnectMerge'](_0x43afb6,_0x179390,_0x5711b1){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x43afb6,_0x179390,_0x5711b1):this['onDisconnectRequestQueue_']['push']({'pathString':_0x43afb6,'action':'om','data':_0x179390,'onComplete':_0x5711b1});}['onDisconnectCancel'](_0x208659,_0x5dfe12){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x208659,null,_0x5dfe12):this['onDisconnectRequestQueue_']['push']({'pathString':_0x208659,'action':'oc','data':null,'onComplete':_0x5dfe12});}['sendOnDisconnect_'](_0x5b452e,_0x3f951e,_0x4e3f94,_0x5c8731){const _0x171b15={'p':_0x3f951e,'d':_0x4e3f94};this['log_']('onDisconnect\x20'+_0x5b452e,_0x171b15),this['sendRequest'](_0x5b452e,_0x171b15,_0x8817cd=>{_0x5c8731&&setTimeout(()=>{_0x5c8731(_0x8817cd['s'],_0x8817cd['d']);},Math['floor'](0x0));});}['put'](_0x55a8a7,_0x5db692,_0x58e72c,_0x55b294){this['putInternal']('p',_0x55a8a7,_0x5db692,_0x58e72c,_0x55b294);}['merge'](_0xc70e7,_0x36e9ef,_0x3c6418,_0x40b736){this['putInternal']('m',_0xc70e7,_0x36e9ef,_0x3c6418,_0x40b736);}['putInternal'](_0x3d8c72,_0xf9b3e1,_0x2d06ba,_0x3c55c1,_0x1b913b){this['initConnection_']();const _0x332059={'p':_0xf9b3e1,'d':_0x2d06ba};_0x1b913b!==void 0x0&&(_0x332059['h']=_0x1b913b),this['outstandingPuts_']['push']({'action':_0x3d8c72,'request':_0x332059,'onComplete':_0x3c55c1}),this['outstandingPutCount_']++;const _0x2d8d8d=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2d8d8d):this['log_']('Buffering\x20put:\x20'+_0xf9b3e1);}['sendPut_'](_0x4e219e){const _0x3df1a6=this['outstandingPuts_'][_0x4e219e]['action'],_0x5d7d2d=this['outstandingPuts_'][_0x4e219e]['request'],_0x1dc6a3=this['outstandingPuts_'][_0x4e219e]['onComplete'];this['outstandingPuts_'][_0x4e219e]['queued']=this['connected_'],this['sendRequest'](_0x3df1a6,_0x5d7d2d,_0x1c1837=>{this['log_'](_0x3df1a6+'\x20response',_0x1c1837),delete this['outstandingPuts_'][_0x4e219e],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1dc6a3&&_0x1dc6a3(_0x1c1837['s'],_0x1c1837['d']);});}['reportStats'](_0x281978){if(this['connected_']){const _0x36249e={'c':_0x281978};this['log_']('reportStats',_0x36249e),this['sendRequest']('s',_0x36249e,_0x190b42=>{if(_0x190b42['s']!=='ok'){const _0x1578b=_0x190b42['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x1578b);}});}}['onDataMessage_'](_0x308105){if('r'in _0x308105){this['log_']('from\x20server:\x20'+O(_0x308105));const _0x524f86=_0x308105['r'],_0x54025e=this['requestCBHash_'][_0x524f86];_0x54025e&&(delete this['requestCBHash_'][_0x524f86],_0x54025e(_0x308105['b']));}else{if('error'in _0x308105)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x308105['error'];'a'in _0x308105&&this['onDataPush_'](_0x308105['a'],_0x308105['b']);}}['onDataPush_'](_0x590f53,_0x5b5582){this['log_']('handleServerMessage',_0x590f53,_0x5b5582),_0x590f53==='d'?this['onDataUpdate_'](_0x5b5582['p'],_0x5b5582['d'],!0x1,_0x5b5582['t']):_0x590f53==='m'?this['onDataUpdate_'](_0x5b5582['p'],_0x5b5582['d'],!0x0,_0x5b5582['t']):_0x590f53==='c'?this['onListenRevoked_'](_0x5b5582['p'],_0x5b5582['q']):_0x590f53==='ac'?this['onAuthRevoked_'](_0x5b5582['s'],_0x5b5582['d']):_0x590f53==='apc'?this['onAppCheckRevoked_'](_0x5b5582['s'],_0x5b5582['d']):_0x590f53==='sd'?this['onSecurityDebugPacket_'](_0x5b5582):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x590f53)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3fb86b,_0x472714){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3fb86b),this['lastSessionId']=_0x472714,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0xca55cd){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0xca55cd));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4f180d){_0x4f180d&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4f180d;}['onOnline_'](_0x151199){_0x151199?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4ae977=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x12982a=Math['max'](0x0,this['reconnectDelay_']-_0x4ae977);_0x12982a=Math['random']()*_0x12982a,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x12982a+'ms'),this['scheduleConnect_'](_0x12982a),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x266006=this['onDataMessage_']['bind'](this),_0x523e67=this['onReady_']['bind'](this),_0x599ff1=this['onRealtimeDisconnect_']['bind'](this),_0x4cdacb=this['id']+':'+se['nextConnectionId_']++,_0x27f054=this['lastSessionId'];let _0x584060=!0x1,_0x89359=null;const _0x3d7a7e=function(){_0x89359?_0x89359['close']():(_0x584060=!0x0,_0x599ff1());},_0x2c240f=function(_0x1f75e8){f(_0x89359,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x89359['sendRequest'](_0x1f75e8);};this['realtime_']={'close':_0x3d7a7e,'sendRequest':_0x2c240f};const _0x2049d7=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x7352c0,_0x33e985]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2049d7),this['appCheckTokenProvider_']['getToken'](_0x2049d7)]);_0x584060?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x7352c0&&_0x7352c0['accessToken'],this['appCheckToken_']=_0x33e985&&_0x33e985['token'],_0x89359=new Sh(_0x4cdacb,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x266006,_0x523e67,_0x599ff1,_0x3eac5b=>{U(_0x3eac5b+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x27f054));}catch(_0x4474c6){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4474c6),_0x584060||(this['repoInfo_']['nodeAdmin']&&U(_0x4474c6),_0x3d7a7e());}}}['interrupt'](_0x2b5c18){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x2b5c18),this['interruptReasons_'][_0x2b5c18]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x415fb7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x415fb7),delete this['interruptReasons_'][_0x415fb7],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3ecc29){const _0x55b7d7=_0x3ecc29-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x55b7d7});}['cancelSentTransactions_'](){for(let _0x8ff901=0x0;_0x8ff901<this['outstandingPuts_']['length'];_0x8ff901++){const _0x39620d=this['outstandingPuts_'][_0x8ff901];_0x39620d&&'h'in _0x39620d['request']&&_0x39620d['queued']&&(_0x39620d['onComplete']&&_0x39620d['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x8ff901],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3521b5,_0x243ed5){let _0x5aa363;_0x243ed5?_0x5aa363=_0x243ed5['map'](_0x381046=>$i(_0x381046))['join']('$'):_0x5aa363='default';const _0x230e28=this['removeListen_'](_0x3521b5,_0x5aa363);_0x230e28&&_0x230e28['onComplete']&&_0x230e28['onComplete']('permission_denied');}['removeListen_'](_0x1a4200,_0x2a7186){const _0x2b94f7=new C(_0x1a4200)['toString']();let _0x569fa6;if(this['listens']['has'](_0x2b94f7)){const _0x2c74bf=this['listens']['get'](_0x2b94f7);_0x569fa6=_0x2c74bf['get'](_0x2a7186),_0x2c74bf['delete'](_0x2a7186),_0x2c74bf['size']===0x0&&this['listens']['delete'](_0x2b94f7);}else _0x569fa6=void 0x0;return _0x569fa6;}['onAuthRevoked_'](_0x769b77,_0x2d7be9){L('Auth\x20token\x20revoked:\x20'+_0x769b77+'/'+_0x2d7be9),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x769b77==='invalid_token'||_0x769b77==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x22308e,_0x5877d1){L('App\x20check\x20token\x20revoked:\x20'+_0x22308e+'/'+_0x5877d1),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x22308e==='invalid_token'||_0x22308e==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x20e4ce){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x20e4ce):'msg'in _0x20e4ce&&console['log']('FIREBASE:\x20'+_0x20e4ce['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0xce44f0 of this['listens']['values']())for(const _0x3a0d56 of _0xce44f0['values']())this['sendListen_'](_0x3a0d56);for(let _0x57dd59=0x0;_0x57dd59<this['outstandingPuts_']['length'];_0x57dd59++)this['outstandingPuts_'][_0x57dd59]&&this['sendPut_'](_0x57dd59);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4b7ba6=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4b7ba6['action'],_0x4b7ba6['pathString'],_0x4b7ba6['data'],_0x4b7ba6['onComplete']);}for(let _0x2c8384=0x0;_0x2c8384<this['outstandingGets_']['length'];_0x2c8384++)this['outstandingGets_'][_0x2c8384]&&this['sendGet_'](_0x2c8384);}['sendConnectStats_'](){const _0x860713={};let _0x4de184='js';_0x860713['sdk.'+_0x4de184+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x860713['framework.cordova']=0x1:Kr()&&(_0x860713['framework.reactnative']=0x1),this['reportStats'](_0x860713);}['shouldReconnect_'](){const _0x2fa7e1=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x2fa7e1;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x8bf651,_0x44e011){this['name']=_0x8bf651,this['node']=_0x44e011;}static['Wrap'](_0x54ad16,_0x333b87){return new E(_0x54ad16,_0x333b87);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2d0410,_0x11fe71){const _0x22dafb=new E(We,_0x2d0410),_0x1166b4=new E(We,_0x11fe71);return this['compare'](_0x22dafb,_0x1166b4)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x4c54ac){sn=_0x4c54ac;}['compare'](_0x3c5d07,_0x49cfde){return qe(_0x3c5d07['name'],_0x49cfde['name']);}['isDefinedOn'](_0x529d4a){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x244bb1,_0x433c71){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x5755aa,_0x5c9722){return f(typeof _0x5755aa=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x5755aa,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x285996,_0x4a6722,_0x270a0b,_0x21f0eb,_0x13de76=null){this['isReverse_']=_0x21f0eb,this['resultGenerator_']=_0x13de76,this['nodeStack_']=[];let _0x308057=0x1;for(;!_0x285996['isEmpty']();)if(_0x285996=_0x285996,_0x308057=_0x4a6722?_0x270a0b(_0x285996['key'],_0x4a6722):0x1,_0x21f0eb&&(_0x308057*=-0x1),_0x308057<0x0)this['isReverse_']?_0x285996=_0x285996['left']:_0x285996=_0x285996['right'];else{if(_0x308057===0x0){this['nodeStack_']['push'](_0x285996);break;}else this['nodeStack_']['push'](_0x285996),this['isReverse_']?_0x285996=_0x285996['right']:_0x285996=_0x285996['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4b5f01=this['nodeStack_']['pop'](),_0x5adfdd;if(this['resultGenerator_']?_0x5adfdd=this['resultGenerator_'](_0x4b5f01['key'],_0x4b5f01['value']):_0x5adfdd={'key':_0x4b5f01['key'],'value':_0x4b5f01['value']},this['isReverse_']){for(_0x4b5f01=_0x4b5f01['left'];!_0x4b5f01['isEmpty']();)this['nodeStack_']['push'](_0x4b5f01),_0x4b5f01=_0x4b5f01['right'];}else{for(_0x4b5f01=_0x4b5f01['right'];!_0x4b5f01['isEmpty']();)this['nodeStack_']['push'](_0x4b5f01),_0x4b5f01=_0x4b5f01['left'];}return _0x5adfdd;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4bf791=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4bf791['key'],_0x4bf791['value']):{'key':_0x4bf791['key'],'value':_0x4bf791['value']};}}class M{constructor(_0x363ee3,_0xece8a9,_0x4c43f1,_0x4c0695,_0x1c4c35){this['key']=_0x363ee3,this['value']=_0xece8a9,this['color']=_0x4c43f1??M['RED'],this['left']=_0x4c0695??B['EMPTY_NODE'],this['right']=_0x1c4c35??B['EMPTY_NODE'];}['copy'](_0x5f246e,_0x2b9857,_0x18b093,_0x523bc9,_0xc77c61){return new M(_0x5f246e??this['key'],_0x2b9857??this['value'],_0x18b093??this['color'],_0x523bc9??this['left'],_0xc77c61??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x25f6f9){return this['left']['inorderTraversal'](_0x25f6f9)||!!_0x25f6f9(this['key'],this['value'])||this['right']['inorderTraversal'](_0x25f6f9);}['reverseTraversal'](_0x23b74b){return this['right']['reverseTraversal'](_0x23b74b)||_0x23b74b(this['key'],this['value'])||this['left']['reverseTraversal'](_0x23b74b);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3dabb0,_0x2c9034,_0x518316){let _0x475fbe=this;const _0xb68929=_0x518316(_0x3dabb0,_0x475fbe['key']);return _0xb68929<0x0?_0x475fbe=_0x475fbe['copy'](null,null,null,_0x475fbe['left']['insert'](_0x3dabb0,_0x2c9034,_0x518316),null):_0xb68929===0x0?_0x475fbe=_0x475fbe['copy'](null,_0x2c9034,null,null,null):_0x475fbe=_0x475fbe['copy'](null,null,null,null,_0x475fbe['right']['insert'](_0x3dabb0,_0x2c9034,_0x518316)),_0x475fbe['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x73dc0=this;return!_0x73dc0['left']['isRed_']()&&!_0x73dc0['left']['left']['isRed_']()&&(_0x73dc0=_0x73dc0['moveRedLeft_']()),_0x73dc0=_0x73dc0['copy'](null,null,null,_0x73dc0['left']['removeMin_'](),null),_0x73dc0['fixUp_']();}['remove'](_0x463379,_0x486cfe){let _0x3cbe25,_0x3eaf34;if(_0x3cbe25=this,_0x486cfe(_0x463379,_0x3cbe25['key'])<0x0)!_0x3cbe25['left']['isEmpty']()&&!_0x3cbe25['left']['isRed_']()&&!_0x3cbe25['left']['left']['isRed_']()&&(_0x3cbe25=_0x3cbe25['moveRedLeft_']()),_0x3cbe25=_0x3cbe25['copy'](null,null,null,_0x3cbe25['left']['remove'](_0x463379,_0x486cfe),null);else{if(_0x3cbe25['left']['isRed_']()&&(_0x3cbe25=_0x3cbe25['rotateRight_']()),!_0x3cbe25['right']['isEmpty']()&&!_0x3cbe25['right']['isRed_']()&&!_0x3cbe25['right']['left']['isRed_']()&&(_0x3cbe25=_0x3cbe25['moveRedRight_']()),_0x486cfe(_0x463379,_0x3cbe25['key'])===0x0){if(_0x3cbe25['right']['isEmpty']())return B['EMPTY_NODE'];_0x3eaf34=_0x3cbe25['right']['min_'](),_0x3cbe25=_0x3cbe25['copy'](_0x3eaf34['key'],_0x3eaf34['value'],null,null,_0x3cbe25['right']['removeMin_']());}_0x3cbe25=_0x3cbe25['copy'](null,null,null,null,_0x3cbe25['right']['remove'](_0x463379,_0x486cfe));}return _0x3cbe25['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x43329b=this;return _0x43329b['right']['isRed_']()&&!_0x43329b['left']['isRed_']()&&(_0x43329b=_0x43329b['rotateLeft_']()),_0x43329b['left']['isRed_']()&&_0x43329b['left']['left']['isRed_']()&&(_0x43329b=_0x43329b['rotateRight_']()),_0x43329b['left']['isRed_']()&&_0x43329b['right']['isRed_']()&&(_0x43329b=_0x43329b['colorFlip_']()),_0x43329b;}['moveRedLeft_'](){let _0x4f9bf6=this['colorFlip_']();return _0x4f9bf6['right']['left']['isRed_']()&&(_0x4f9bf6=_0x4f9bf6['copy'](null,null,null,null,_0x4f9bf6['right']['rotateRight_']()),_0x4f9bf6=_0x4f9bf6['rotateLeft_'](),_0x4f9bf6=_0x4f9bf6['colorFlip_']()),_0x4f9bf6;}['moveRedRight_'](){let _0x458b42=this['colorFlip_']();return _0x458b42['left']['left']['isRed_']()&&(_0x458b42=_0x458b42['rotateRight_'](),_0x458b42=_0x458b42['colorFlip_']()),_0x458b42;}['rotateLeft_'](){const _0x4f5bac=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4f5bac,null);}['rotateRight_'](){const _0x48b1ee=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x48b1ee);}['colorFlip_'](){const _0x97f4cc=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x459e2d=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x97f4cc,_0x459e2d);}['checkMaxDepth_'](){const _0x23b8d5=this['check_']();return Math['pow'](0x2,_0x23b8d5)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x81976=this['left']['check_']();if(_0x81976!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x81976+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x102bb0,_0xf5e7a2,_0x3a5f23,_0x1445cb,_0xa47451){return this;}['insert'](_0x400430,_0x3d5723,_0x2a522c){return new M(_0x400430,_0x3d5723,null);}['remove'](_0x4f8733,_0x4feb83){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x13cab4){return!0x1;}['reverseTraversal'](_0x48c21b){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x487037,_0x18154e=B['EMPTY_NODE']){this['comparator_']=_0x487037,this['root_']=_0x18154e;}['insert'](_0x2445fa,_0x4d555f){return new B(this['comparator_'],this['root_']['insert'](_0x2445fa,_0x4d555f,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x41128e){return new B(this['comparator_'],this['root_']['remove'](_0x41128e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x551af6){let _0x4c9c99,_0x58d632=this['root_'];for(;!_0x58d632['isEmpty']();){if(_0x4c9c99=this['comparator_'](_0x551af6,_0x58d632['key']),_0x4c9c99===0x0)return _0x58d632['value'];_0x4c9c99<0x0?_0x58d632=_0x58d632['left']:_0x4c9c99>0x0&&(_0x58d632=_0x58d632['right']);}return null;}['getPredecessorKey'](_0x257c1e){let _0x9136da,_0x5a5f4b=this['root_'],_0x5bf7a7=null;for(;!_0x5a5f4b['isEmpty']();)if(_0x9136da=this['comparator_'](_0x257c1e,_0x5a5f4b['key']),_0x9136da===0x0){if(_0x5a5f4b['left']['isEmpty']())return _0x5bf7a7?_0x5bf7a7['key']:null;for(_0x5a5f4b=_0x5a5f4b['left'];!_0x5a5f4b['right']['isEmpty']();)_0x5a5f4b=_0x5a5f4b['right'];return _0x5a5f4b['key'];}else _0x9136da<0x0?_0x5a5f4b=_0x5a5f4b['left']:_0x9136da>0x0&&(_0x5bf7a7=_0x5a5f4b,_0x5a5f4b=_0x5a5f4b['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0xed91){return this['root_']['inorderTraversal'](_0xed91);}['reverseTraversal'](_0x20f795){return this['root_']['reverseTraversal'](_0x20f795);}['getIterator'](_0x348a9e){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x348a9e);}['getIteratorFrom'](_0x198fba,_0x2a94e5){return new rn(this['root_'],_0x198fba,this['comparator_'],!0x1,_0x2a94e5);}['getReverseIteratorFrom'](_0x120765,_0x355c7c){return new rn(this['root_'],_0x120765,this['comparator_'],!0x0,_0x355c7c);}['getReverseIterator'](_0x1930db){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x1930db);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2b4f69,_0x3e66f6){return qe(_0x2b4f69['name'],_0x3e66f6['name']);}function Qi(_0x3ad272,_0xd655e4){return qe(_0x3ad272,_0xd655e4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x24a298){Ci=_0x24a298;}const Po=function(_0x511f4f){return typeof _0x511f4f=='number'?'number:'+ao(_0x511f4f):'string:'+_0x511f4f;},No=function(_0x4eb2cf){if(_0x4eb2cf['isLeafNode']()){const _0x3381de=_0x4eb2cf['val']();f(typeof _0x3381de=='string'||typeof _0x3381de=='number'||typeof _0x3381de=='object'&&Q(_0x3381de,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4eb2cf===Ci||_0x4eb2cf['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4eb2cf===Ci||_0x4eb2cf['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x20f365){nr=_0x20f365;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x92be59,_0x4091ce=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x92be59,this['priorityNode_']=_0x4091ce,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1d5c99){return new D(this['value_'],_0x1d5c99);}['getImmediateChild'](_0x340538){return _0x340538==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0xce62f7){return v(_0xce62f7)?this:y(_0xce62f7)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x411dad,_0x53fdf0){return null;}['updateImmediateChild'](_0x3c812d,_0x2fbcdd){return _0x3c812d==='.priority'?this['updatePriority'](_0x2fbcdd):_0x2fbcdd['isEmpty']()&&_0x3c812d!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x3c812d,_0x2fbcdd)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2b9a61,_0x36f2ab){const _0x480031=y(_0x2b9a61);return _0x480031===null?_0x36f2ab:_0x36f2ab['isEmpty']()&&_0x480031!=='.priority'?this:(f(_0x480031!=='.priority'||Ce(_0x2b9a61)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x480031,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x2b9a61),_0x36f2ab)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x397514,_0x35969c){return!0x1;}['val'](_0x32f178){return _0x32f178&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x24c125='';this['priorityNode_']['isEmpty']()||(_0x24c125+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x4da2a1=typeof this['value_'];_0x24c125+=_0x4da2a1+':',_0x4da2a1==='number'?_0x24c125+=ao(this['value_']):_0x24c125+=this['value_'],this['lazyHash_']=ro(_0x24c125);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2ca0cc){return _0x2ca0cc===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2ca0cc instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2ca0cc['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2ca0cc));}['compareToLeafNode_'](_0x4ac623){const _0x2a4344=typeof _0x4ac623['value_'],_0x2f96fc=typeof this['value_'],_0x40b40a=D['VALUE_TYPE_ORDER']['indexOf'](_0x2a4344),_0x29018e=D['VALUE_TYPE_ORDER']['indexOf'](_0x2f96fc);return f(_0x40b40a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2a4344),f(_0x29018e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2f96fc),_0x40b40a===_0x29018e?_0x2f96fc==='object'?0x0:this['value_']<_0x4ac623['value_']?-0x1:this['value_']===_0x4ac623['value_']?0x0:0x1:_0x29018e-_0x40b40a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x403d10){if(_0x403d10===this)return!0x0;if(_0x403d10['isLeafNode']()){const _0x2cdfab=_0x403d10;return this['value_']===_0x2cdfab['value_']&&this['priorityNode_']['equals'](_0x2cdfab['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x473f72){Oo=_0x473f72;}function Wh(_0x109b9e){Do=_0x109b9e;}class Bh extends Fn{['compare'](_0x1abea2,_0x1eeb03){const _0x2363e5=_0x1abea2['node']['getPriority'](),_0x485dc9=_0x1eeb03['node']['getPriority'](),_0x545229=_0x2363e5['compareTo'](_0x485dc9);return _0x545229===0x0?qe(_0x1abea2['name'],_0x1eeb03['name']):_0x545229;}['isDefinedOn'](_0x2b3e02){return!_0x2b3e02['getPriority']()['isEmpty']();}['indexedValueChanged'](_0xd8a457,_0x54e622){return!_0xd8a457['getPriority']()['equals'](_0x54e622['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x14cfae,_0x3ff7f8){const _0x594998=Oo(_0x14cfae);return new E(_0x3ff7f8,new D('[PRIORITY-POST]',_0x594998));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x6e71c8){const _0x4d06e3=_0x5e33b6=>parseInt(Math['log'](_0x5e33b6)/Vh,0xa),_0x433403=_0x3406f2=>parseInt(Array(_0x3406f2+0x1)['join']('1'),0x2);this['count']=_0x4d06e3(_0x6e71c8+0x1),this['current_']=this['count']-0x1;const _0x282cf3=_0x433403(this['count']);this['bits_']=_0x6e71c8+0x1&_0x282cf3;}['nextBitIsOne'](){const _0x1febb1=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x1febb1;}}const yn=function(_0x5403a4,_0x45be56,_0x36c458,_0x12581d){_0x5403a4['sort'](_0x45be56);const _0xafed1d=function(_0x48fe5c,_0x269b69){const _0x5dd595=_0x269b69-_0x48fe5c;let _0x24a868,_0x74e3f5;if(_0x5dd595===0x0)return null;if(_0x5dd595===0x1)return _0x24a868=_0x5403a4[_0x48fe5c],_0x74e3f5=_0x36c458?_0x36c458(_0x24a868):_0x24a868,new M(_0x74e3f5,_0x24a868['node'],M['BLACK'],null,null);{const _0x5f3381=parseInt(_0x5dd595/0x2,0xa)+_0x48fe5c,_0x1f86ae=_0xafed1d(_0x48fe5c,_0x5f3381),_0x1f7616=_0xafed1d(_0x5f3381+0x1,_0x269b69);return _0x24a868=_0x5403a4[_0x5f3381],_0x74e3f5=_0x36c458?_0x36c458(_0x24a868):_0x24a868,new M(_0x74e3f5,_0x24a868['node'],M['BLACK'],_0x1f86ae,_0x1f7616);}},_0x1d88a5=function(_0x37c691){let _0x44660b=null,_0x1d3489=null,_0x2b4bc4=_0x5403a4['length'];const _0x5926e0=function(_0x481c45,_0x4fc602){const _0x2d9a89=_0x2b4bc4-_0x481c45,_0x4f2c26=_0x2b4bc4;_0x2b4bc4-=_0x481c45;const _0x1857dc=_0xafed1d(_0x2d9a89+0x1,_0x4f2c26),_0x277923=_0x5403a4[_0x2d9a89],_0xc083c9=_0x36c458?_0x36c458(_0x277923):_0x277923;_0x4d8720(new M(_0xc083c9,_0x277923['node'],_0x4fc602,null,_0x1857dc));},_0x4d8720=function(_0x77dcb8){_0x44660b?(_0x44660b['left']=_0x77dcb8,_0x44660b=_0x77dcb8):(_0x1d3489=_0x77dcb8,_0x44660b=_0x77dcb8);};for(let _0x1f6d87=0x0;_0x1f6d87<_0x37c691['count'];++_0x1f6d87){const _0x522a54=_0x37c691['nextBitIsOne'](),_0x4c1687=Math['pow'](0x2,_0x37c691['count']-(_0x1f6d87+0x1));_0x522a54?_0x5926e0(_0x4c1687,M['BLACK']):(_0x5926e0(_0x4c1687,M['BLACK']),_0x5926e0(_0x4c1687,M['RED']));}return _0x1d3489;},_0x338f09=new Hh(_0x5403a4['length']),_0x279c85=_0x1d88a5(_0x338f09);return new B(_0x12581d||_0x45be56,_0x279c85);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x410631,_0x7836d4){this['indexes_']=_0x410631,this['indexSet_']=_0x7836d4;}['get'](_0x298275){const _0x3f21ae=Le(this['indexes_'],_0x298275);if(!_0x3f21ae)throw new Error('No\x20index\x20defined\x20for\x20'+_0x298275);return _0x3f21ae instanceof B?_0x3f21ae:null;}['hasIndex'](_0x56357d){return Q(this['indexSet_'],_0x56357d['toString']());}['addIndex'](_0x1b3f36,_0x4dbcf3){f(_0x1b3f36!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x40a6cd=[];let _0x282802=!0x1;const _0x5bae96=_0x4dbcf3['getIterator'](E['Wrap']);let _0x150393=_0x5bae96['getNext']();for(;_0x150393;)_0x282802=_0x282802||_0x1b3f36['isDefinedOn'](_0x150393['node']),_0x40a6cd['push'](_0x150393),_0x150393=_0x5bae96['getNext']();let _0x2ddec6;_0x282802?_0x2ddec6=yn(_0x40a6cd,_0x1b3f36['getCompare']()):_0x2ddec6=Qe;const _0x2e2d43=_0x1b3f36['toString'](),_0x5470ba={...this['indexSet_']};_0x5470ba[_0x2e2d43]=_0x1b3f36;const _0x1a2629={...this['indexes_']};return _0x1a2629[_0x2e2d43]=_0x2ddec6,new te(_0x1a2629,_0x5470ba);}['addToIndexes'](_0x501b83,_0xc5721f){const _0x4493a7=_n(this['indexes_'],(_0x48ab8d,_0x4da468)=>{const _0x1b0ab1=Le(this['indexSet_'],_0x4da468);if(f(_0x1b0ab1,'Missing\x20index\x20implementation\x20for\x20'+_0x4da468),_0x48ab8d===Qe){if(_0x1b0ab1['isDefinedOn'](_0x501b83['node'])){const _0x24f859=[],_0x5e40a7=_0xc5721f['getIterator'](E['Wrap']);let _0x1a4edf=_0x5e40a7['getNext']();for(;_0x1a4edf;)_0x1a4edf['name']!==_0x501b83['name']&&_0x24f859['push'](_0x1a4edf),_0x1a4edf=_0x5e40a7['getNext']();return _0x24f859['push'](_0x501b83),yn(_0x24f859,_0x1b0ab1['getCompare']());}else return Qe;}else{const _0x2f5540=_0xc5721f['get'](_0x501b83['name']);let _0x40c588=_0x48ab8d;return _0x2f5540&&(_0x40c588=_0x40c588['remove'](new E(_0x501b83['name'],_0x2f5540))),_0x40c588['insert'](_0x501b83,_0x501b83['node']);}});return new te(_0x4493a7,this['indexSet_']);}['removeFromIndexes'](_0x3787c5,_0x9359c6){const _0x41ea60=_n(this['indexes_'],_0x5f30d0=>{if(_0x5f30d0===Qe)return _0x5f30d0;{const _0x16d52d=_0x9359c6['get'](_0x3787c5['name']);return _0x16d52d?_0x5f30d0['remove'](new E(_0x3787c5['name'],_0x16d52d)):_0x5f30d0;}});return new te(_0x41ea60,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x5d6cba,_0x39ca23,_0x268ec9){this['children_']=_0x5d6cba,this['priorityNode_']=_0x39ca23,this['indexMap_']=_0x268ec9,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x27881f){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x27881f,this['indexMap_']);}['getImmediateChild'](_0x39f9c1){if(_0x39f9c1==='.priority')return this['getPriority']();{const _0x37f7c5=this['children_']['get'](_0x39f9c1);return _0x37f7c5===null?It:_0x37f7c5;}}['getChild'](_0x233e83){const _0x3e6c9e=y(_0x233e83);return _0x3e6c9e===null?this:this['getImmediateChild'](_0x3e6c9e)['getChild'](S(_0x233e83));}['hasChild'](_0x4a956a){return this['children_']['get'](_0x4a956a)!==null;}['updateImmediateChild'](_0x4ddcaa,_0x1e5b7b){if(f(_0x1e5b7b,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4ddcaa==='.priority')return this['updatePriority'](_0x1e5b7b);{const _0x4f3c6f=new E(_0x4ddcaa,_0x1e5b7b);let _0x1044c0,_0x8ffc19;_0x1e5b7b['isEmpty']()?(_0x1044c0=this['children_']['remove'](_0x4ddcaa),_0x8ffc19=this['indexMap_']['removeFromIndexes'](_0x4f3c6f,this['children_'])):(_0x1044c0=this['children_']['insert'](_0x4ddcaa,_0x1e5b7b),_0x8ffc19=this['indexMap_']['addToIndexes'](_0x4f3c6f,this['children_']));const _0x34ced3=_0x1044c0['isEmpty']()?It:this['priorityNode_'];return new g(_0x1044c0,_0x34ced3,_0x8ffc19);}}['updateChild'](_0x3facf3,_0x371ebf){const _0x46dcfe=y(_0x3facf3);if(_0x46dcfe===null)return _0x371ebf;{f(y(_0x3facf3)!=='.priority'||Ce(_0x3facf3)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x32f806=this['getImmediateChild'](_0x46dcfe)['updateChild'](S(_0x3facf3),_0x371ebf);return this['updateImmediateChild'](_0x46dcfe,_0x32f806);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x504f3e){if(this['isEmpty']())return null;const _0x2e6ed6={};let _0x54819e=0x0,_0x1fb589=0x0,_0xbf4baf=!0x0;if(this['forEachChild'](R,(_0x900309,_0x109fc8)=>{_0x2e6ed6[_0x900309]=_0x109fc8['val'](_0x504f3e),_0x54819e++,_0xbf4baf&&g['INTEGER_REGEXP_']['test'](_0x900309)?_0x1fb589=Math['max'](_0x1fb589,Number(_0x900309)):_0xbf4baf=!0x1;}),!_0x504f3e&&_0xbf4baf&&_0x1fb589<0x2*_0x54819e){const _0x4fa7b5=[];for(const _0xcbe6ad in _0x2e6ed6)_0x4fa7b5[_0xcbe6ad]=_0x2e6ed6[_0xcbe6ad];return _0x4fa7b5;}else return _0x504f3e&&!this['getPriority']()['isEmpty']()&&(_0x2e6ed6['.priority']=this['getPriority']()['val']()),_0x2e6ed6;}['hash'](){if(this['lazyHash_']===null){let _0x222df5='';this['getPriority']()['isEmpty']()||(_0x222df5+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2a0a9f,_0x43dd1f)=>{const _0x3f0e95=_0x43dd1f['hash']();_0x3f0e95!==''&&(_0x222df5+=':'+_0x2a0a9f+':'+_0x3f0e95);}),this['lazyHash_']=_0x222df5===''?'':ro(_0x222df5);}return this['lazyHash_'];}['getPredecessorChildName'](_0x5d0ea5,_0xb97152,_0x16d3c8){const _0x23e06f=this['resolveIndex_'](_0x16d3c8);if(_0x23e06f){const _0x579887=_0x23e06f['getPredecessorKey'](new E(_0x5d0ea5,_0xb97152));return _0x579887?_0x579887['name']:null;}else return this['children_']['getPredecessorKey'](_0x5d0ea5);}['getFirstChildName'](_0x4a23ee){const _0x9dede0=this['resolveIndex_'](_0x4a23ee);if(_0x9dede0){const _0x21a11c=_0x9dede0['minKey']();return _0x21a11c&&_0x21a11c['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x5be3b2){const _0x5393e7=this['getFirstChildName'](_0x5be3b2);return _0x5393e7?new E(_0x5393e7,this['children_']['get'](_0x5393e7)):null;}['getLastChildName'](_0x32051d){const _0x2bf93c=this['resolveIndex_'](_0x32051d);if(_0x2bf93c){const _0x4526a8=_0x2bf93c['maxKey']();return _0x4526a8&&_0x4526a8['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4376ec){const _0x250f00=this['getLastChildName'](_0x4376ec);return _0x250f00?new E(_0x250f00,this['children_']['get'](_0x250f00)):null;}['forEachChild'](_0x2b15a5,_0x31dc6b){const _0x4c7d11=this['resolveIndex_'](_0x2b15a5);return _0x4c7d11?_0x4c7d11['inorderTraversal'](_0x56f66c=>_0x31dc6b(_0x56f66c['name'],_0x56f66c['node'])):this['children_']['inorderTraversal'](_0x31dc6b);}['getIterator'](_0x38faff){return this['getIteratorFrom'](_0x38faff['minPost'](),_0x38faff);}['getIteratorFrom'](_0x488361,_0x217b6f){const _0x5a4c29=this['resolveIndex_'](_0x217b6f);if(_0x5a4c29)return _0x5a4c29['getIteratorFrom'](_0x488361,_0x388076=>_0x388076);{const _0x3b62bd=this['children_']['getIteratorFrom'](_0x488361['name'],E['Wrap']);let _0xadf323=_0x3b62bd['peek']();for(;_0xadf323!=null&&_0x217b6f['compare'](_0xadf323,_0x488361)<0x0;)_0x3b62bd['getNext'](),_0xadf323=_0x3b62bd['peek']();return _0x3b62bd;}}['getReverseIterator'](_0x33be3e){return this['getReverseIteratorFrom'](_0x33be3e['maxPost'](),_0x33be3e);}['getReverseIteratorFrom'](_0x112813,_0xe6f87b){const _0x4d98e2=this['resolveIndex_'](_0xe6f87b);if(_0x4d98e2)return _0x4d98e2['getReverseIteratorFrom'](_0x112813,_0x43c0e7=>_0x43c0e7);{const _0x468581=this['children_']['getReverseIteratorFrom'](_0x112813['name'],E['Wrap']);let _0x3f1890=_0x468581['peek']();for(;_0x3f1890!=null&&_0xe6f87b['compare'](_0x3f1890,_0x112813)>0x0;)_0x468581['getNext'](),_0x3f1890=_0x468581['peek']();return _0x468581;}}['compareTo'](_0xb92242){return this['isEmpty']()?_0xb92242['isEmpty']()?0x0:-0x1:_0xb92242['isLeafNode']()||_0xb92242['isEmpty']()?0x1:_0xb92242===Kt?-0x1:0x0;}['withIndex'](_0x43cd51){if(_0x43cd51===ve||this['indexMap_']['hasIndex'](_0x43cd51))return this;{const _0x5ee5b0=this['indexMap_']['addIndex'](_0x43cd51,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x5ee5b0);}}['isIndexed'](_0x1161af){return _0x1161af===ve||this['indexMap_']['hasIndex'](_0x1161af);}['equals'](_0x48bc14){if(_0x48bc14===this)return!0x0;if(_0x48bc14['isLeafNode']())return!0x1;{const _0x56dea0=_0x48bc14;if(this['getPriority']()['equals'](_0x56dea0['getPriority']())){if(this['children_']['count']()===_0x56dea0['children_']['count']()){const _0x8df6b9=this['getIterator'](R),_0x3c6887=_0x56dea0['getIterator'](R);let _0x327da4=_0x8df6b9['getNext'](),_0x509de6=_0x3c6887['getNext']();for(;_0x327da4&&_0x509de6;){if(_0x327da4['name']!==_0x509de6['name']||!_0x327da4['node']['equals'](_0x509de6['node']))return!0x1;_0x327da4=_0x8df6b9['getNext'](),_0x509de6=_0x3c6887['getNext']();}return _0x327da4===null&&_0x509de6===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x58cd6d){return _0x58cd6d===ve?null:this['indexMap_']['get'](_0x58cd6d['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x5b2c52){return _0x5b2c52===this?0x0:0x1;}['equals'](_0x3c8832){return _0x3c8832===this;}['getPriority'](){return this;}['getImmediateChild'](_0x27a4b0){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x3dcdb1,_0x1def54=null){if(_0x3dcdb1===null)return g['EMPTY_NODE'];if(typeof _0x3dcdb1=='object'&&'.priority'in _0x3dcdb1&&(_0x1def54=_0x3dcdb1['.priority']),f(_0x1def54===null||typeof _0x1def54=='string'||typeof _0x1def54=='number'||typeof _0x1def54=='object'&&'.sv'in _0x1def54,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1def54),typeof _0x3dcdb1=='object'&&'.value'in _0x3dcdb1&&_0x3dcdb1['.value']!==null&&(_0x3dcdb1=_0x3dcdb1['.value']),typeof _0x3dcdb1!='object'||'.sv'in _0x3dcdb1){const _0x1a7f47=_0x3dcdb1;return new D(_0x1a7f47,A(_0x1def54));}if(!(_0x3dcdb1 instanceof Array)&&Gh){const _0x21a087=[];let _0x3c418b=!0x1;if(x(_0x3dcdb1,(_0x92d063,_0x3addcb)=>{if(_0x92d063['substring'](0x0,0x1)!=='.'){const _0x5de6ee=A(_0x3addcb);_0x5de6ee['isEmpty']()||(_0x3c418b=_0x3c418b||!_0x5de6ee['getPriority']()['isEmpty'](),_0x21a087['push'](new E(_0x92d063,_0x5de6ee)));}}),_0x21a087['length']===0x0)return g['EMPTY_NODE'];const _0x3594f6=yn(_0x21a087,xh,_0x34f6e9=>_0x34f6e9['name'],Qi);if(_0x3c418b){const _0x3505c1=yn(_0x21a087,R['getCompare']());return new g(_0x3594f6,A(_0x1def54),new te({'.priority':_0x3505c1},{'.priority':R}));}else return new g(_0x3594f6,A(_0x1def54),te['Default']);}else{let _0x42021e=g['EMPTY_NODE'];return x(_0x3dcdb1,(_0x388d09,_0x25e4fb)=>{if(Q(_0x3dcdb1,_0x388d09)&&_0x388d09['substring'](0x0,0x1)!=='.'){const _0x4d173d=A(_0x25e4fb);(_0x4d173d['isLeafNode']()||!_0x4d173d['isEmpty']())&&(_0x42021e=_0x42021e['updateImmediateChild'](_0x388d09,_0x4d173d));}}),_0x42021e['updatePriority'](A(_0x1def54));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x1d3396){super(),this['indexPath_']=_0x1d3396,f(!v(_0x1d3396)&&y(_0x1d3396)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x450b9d){return _0x450b9d['getChild'](this['indexPath_']);}['isDefinedOn'](_0x430895){return!_0x430895['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x43b06c,_0x22e1f8){const _0x110e47=this['extractChild'](_0x43b06c['node']),_0x1f9b0d=this['extractChild'](_0x22e1f8['node']),_0x10dfab=_0x110e47['compareTo'](_0x1f9b0d);return _0x10dfab===0x0?qe(_0x43b06c['name'],_0x22e1f8['name']):_0x10dfab;}['makePost'](_0x194643,_0x52a022){const _0x542f38=A(_0x194643),_0x11dfb5=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x542f38);return new E(_0x52a022,_0x11dfb5);}['maxPost'](){const _0x1ada01=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x1ada01);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x215ec1,_0x2d440f){const _0x45af18=_0x215ec1['node']['compareTo'](_0x2d440f['node']);return _0x45af18===0x0?qe(_0x215ec1['name'],_0x2d440f['name']):_0x45af18;}['isDefinedOn'](_0x5ef17d){return!0x0;}['indexedValueChanged'](_0x8ecebd,_0x55eaca){return!_0x8ecebd['equals'](_0x55eaca);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3cd225,_0x12326d){const _0x4078ce=A(_0x3cd225);return new E(_0x12326d,_0x4078ce);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x5e41e){return{'type':'value','snapshotNode':_0x5e41e};}function rt(_0x17881c,_0x558356){return{'type':'child_added','snapshotNode':_0x558356,'childName':_0x17881c};}function Lt(_0x4e7b6e,_0x930ee2){return{'type':'child_removed','snapshotNode':_0x930ee2,'childName':_0x4e7b6e};}function xt(_0x24c428,_0x207554,_0x33f1cf){return{'type':'child_changed','snapshotNode':_0x207554,'childName':_0x24c428,'oldSnap':_0x33f1cf};}function zh(_0x517b7a,_0xf6040){return{'type':'child_moved','snapshotNode':_0xf6040,'childName':_0x517b7a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x55c4cb){this['index_']=_0x55c4cb;}['updateChild'](_0x25096c,_0x41f411,_0x204d91,_0x35d280,_0x89ad1b,_0x5aa68f){f(_0x25096c['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x7d9d94=_0x25096c['getImmediateChild'](_0x41f411);return _0x7d9d94['getChild'](_0x35d280)['equals'](_0x204d91['getChild'](_0x35d280))&&_0x7d9d94['isEmpty']()===_0x204d91['isEmpty']()||(_0x5aa68f!=null&&(_0x204d91['isEmpty']()?_0x25096c['hasChild'](_0x41f411)?_0x5aa68f['trackChildChange'](Lt(_0x41f411,_0x7d9d94)):f(_0x25096c['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x7d9d94['isEmpty']()?_0x5aa68f['trackChildChange'](rt(_0x41f411,_0x204d91)):_0x5aa68f['trackChildChange'](xt(_0x41f411,_0x204d91,_0x7d9d94))),_0x25096c['isLeafNode']()&&_0x204d91['isEmpty']())?_0x25096c:_0x25096c['updateImmediateChild'](_0x41f411,_0x204d91)['withIndex'](this['index_']);}['updateFullNode'](_0x12e518,_0x46ddf4,_0x1d96f6){return _0x1d96f6!=null&&(_0x12e518['isLeafNode']()||_0x12e518['forEachChild'](R,(_0x2a0a00,_0x45b290)=>{_0x46ddf4['hasChild'](_0x2a0a00)||_0x1d96f6['trackChildChange'](Lt(_0x2a0a00,_0x45b290));}),_0x46ddf4['isLeafNode']()||_0x46ddf4['forEachChild'](R,(_0x4a2fa1,_0x435391)=>{if(_0x12e518['hasChild'](_0x4a2fa1)){const _0x900306=_0x12e518['getImmediateChild'](_0x4a2fa1);_0x900306['equals'](_0x435391)||_0x1d96f6['trackChildChange'](xt(_0x4a2fa1,_0x435391,_0x900306));}else _0x1d96f6['trackChildChange'](rt(_0x4a2fa1,_0x435391));})),_0x46ddf4['withIndex'](this['index_']);}['updatePriority'](_0x2b6919,_0xabeff0){return _0x2b6919['isEmpty']()?g['EMPTY_NODE']:_0x2b6919['updatePriority'](_0xabeff0);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x1bba74){this['indexedFilter_']=new Xi(_0x1bba74['getIndex']()),this['index_']=_0x1bba74['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x1bba74),this['endPost_']=Ft['getEndPost_'](_0x1bba74),this['startIsInclusive_']=!_0x1bba74['startAfterSet_'],this['endIsInclusive_']=!_0x1bba74['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x30bc14){const _0x44ac9f=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x30bc14)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x30bc14)<0x0,_0x2e9350=this['endIsInclusive_']?this['index_']['compare'](_0x30bc14,this['getEndPost']())<=0x0:this['index_']['compare'](_0x30bc14,this['getEndPost']())<0x0;return _0x44ac9f&&_0x2e9350;}['updateChild'](_0x1d6bf8,_0x367239,_0x22d25c,_0x1adcfd,_0x15c6c7,_0x2842d1){return this['matches'](new E(_0x367239,_0x22d25c))||(_0x22d25c=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1d6bf8,_0x367239,_0x22d25c,_0x1adcfd,_0x15c6c7,_0x2842d1);}['updateFullNode'](_0x4e8ec8,_0x1605c4,_0x3f66bc){_0x1605c4['isLeafNode']()&&(_0x1605c4=g['EMPTY_NODE']);let _0x14595c=_0x1605c4['withIndex'](this['index_']);_0x14595c=_0x14595c['updatePriority'](g['EMPTY_NODE']);const _0x3e66cc=this;return _0x1605c4['forEachChild'](R,(_0x5dc582,_0x585902)=>{_0x3e66cc['matches'](new E(_0x5dc582,_0x585902))||(_0x14595c=_0x14595c['updateImmediateChild'](_0x5dc582,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x4e8ec8,_0x14595c,_0x3f66bc);}['updatePriority'](_0x2aa89a,_0x2b887b){return _0x2aa89a;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2c155a){if(_0x2c155a['hasStart']()){const _0x135907=_0x2c155a['getIndexStartName']();return _0x2c155a['getIndex']()['makePost'](_0x2c155a['getIndexStartValue'](),_0x135907);}else return _0x2c155a['getIndex']()['minPost']();}static['getEndPost_'](_0x258bb6){if(_0x258bb6['hasEnd']()){const _0x425214=_0x258bb6['getIndexEndName']();return _0x258bb6['getIndex']()['makePost'](_0x258bb6['getIndexEndValue'](),_0x425214);}else return _0x258bb6['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x4a1c37){this['withinDirectionalStart']=_0x54ffce=>this['reverse_']?this['withinEndPost'](_0x54ffce):this['withinStartPost'](_0x54ffce),this['withinDirectionalEnd']=_0x1a97ea=>this['reverse_']?this['withinStartPost'](_0x1a97ea):this['withinEndPost'](_0x1a97ea),this['withinStartPost']=_0x20112b=>{const _0x237f9c=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x20112b);return this['startIsInclusive_']?_0x237f9c<=0x0:_0x237f9c<0x0;},this['withinEndPost']=_0xe30979=>{const _0x13cc6c=this['index_']['compare'](_0xe30979,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x13cc6c<=0x0:_0x13cc6c<0x0;},this['rangedFilter_']=new Ft(_0x4a1c37),this['index_']=_0x4a1c37['getIndex'](),this['limit_']=_0x4a1c37['getLimit'](),this['reverse_']=!_0x4a1c37['isViewFromLeft'](),this['startIsInclusive_']=!_0x4a1c37['startAfterSet_'],this['endIsInclusive_']=!_0x4a1c37['endBeforeSet_'];}['updateChild'](_0xaf58fa,_0x462871,_0x2b9373,_0x22ca2a,_0x44f6aa,_0x9f8db2){return this['rangedFilter_']['matches'](new E(_0x462871,_0x2b9373))||(_0x2b9373=g['EMPTY_NODE']),_0xaf58fa['getImmediateChild'](_0x462871)['equals'](_0x2b9373)?_0xaf58fa:_0xaf58fa['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xaf58fa,_0x462871,_0x2b9373,_0x22ca2a,_0x44f6aa,_0x9f8db2):this['fullLimitUpdateChild_'](_0xaf58fa,_0x462871,_0x2b9373,_0x44f6aa,_0x9f8db2);}['updateFullNode'](_0x581a5e,_0x24627e,_0x484c64){let _0x145fce;if(_0x24627e['isLeafNode']()||_0x24627e['isEmpty']())_0x145fce=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x24627e['numChildren']()&&_0x24627e['isIndexed'](this['index_'])){_0x145fce=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4e59c9;this['reverse_']?_0x4e59c9=_0x24627e['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4e59c9=_0x24627e['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x58feaa=0x0;for(;_0x4e59c9['hasNext']()&&_0x58feaa<this['limit_'];){const _0x57fce9=_0x4e59c9['getNext']();if(this['withinDirectionalStart'](_0x57fce9)){if(this['withinDirectionalEnd'](_0x57fce9))_0x145fce=_0x145fce['updateImmediateChild'](_0x57fce9['name'],_0x57fce9['node']),_0x58feaa++;else break;}else continue;}}else{_0x145fce=_0x24627e['withIndex'](this['index_']),_0x145fce=_0x145fce['updatePriority'](g['EMPTY_NODE']);let _0x87a22c;this['reverse_']?_0x87a22c=_0x145fce['getReverseIterator'](this['index_']):_0x87a22c=_0x145fce['getIterator'](this['index_']);let _0x415929=0x0;for(;_0x87a22c['hasNext']();){const _0x279f48=_0x87a22c['getNext']();_0x415929<this['limit_']&&this['withinDirectionalStart'](_0x279f48)&&this['withinDirectionalEnd'](_0x279f48)?_0x415929++:_0x145fce=_0x145fce['updateImmediateChild'](_0x279f48['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x581a5e,_0x145fce,_0x484c64);}['updatePriority'](_0x133330,_0x1012c4){return _0x133330;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x43faef,_0x4b1120,_0x386510,_0x316513,_0x11f4c8){let _0xdb3de4;if(this['reverse_']){const _0x3c5ad7=this['index_']['getCompare']();_0xdb3de4=(_0x1ba972,_0x3d774d)=>_0x3c5ad7(_0x3d774d,_0x1ba972);}else _0xdb3de4=this['index_']['getCompare']();const _0x152918=_0x43faef;f(_0x152918['numChildren']()===this['limit_'],'');const _0x39e676=new E(_0x4b1120,_0x386510),_0x192b8f=this['reverse_']?_0x152918['getFirstChild'](this['index_']):_0x152918['getLastChild'](this['index_']),_0xd6e452=this['rangedFilter_']['matches'](_0x39e676);if(_0x152918['hasChild'](_0x4b1120)){const _0x1c7d1b=_0x152918['getImmediateChild'](_0x4b1120);let _0x5785af=_0x316513['getChildAfterChild'](this['index_'],_0x192b8f,this['reverse_']);for(;_0x5785af!=null&&(_0x5785af['name']===_0x4b1120||_0x152918['hasChild'](_0x5785af['name']));)_0x5785af=_0x316513['getChildAfterChild'](this['index_'],_0x5785af,this['reverse_']);const _0x1faaec=_0x5785af==null?0x1:_0xdb3de4(_0x5785af,_0x39e676);if(_0xd6e452&&!_0x386510['isEmpty']()&&_0x1faaec>=0x0)return _0x11f4c8!=null&&_0x11f4c8['trackChildChange'](xt(_0x4b1120,_0x386510,_0x1c7d1b)),_0x152918['updateImmediateChild'](_0x4b1120,_0x386510);{_0x11f4c8!=null&&_0x11f4c8['trackChildChange'](Lt(_0x4b1120,_0x1c7d1b));const _0x4e07c4=_0x152918['updateImmediateChild'](_0x4b1120,g['EMPTY_NODE']);return _0x5785af!=null&&this['rangedFilter_']['matches'](_0x5785af)?(_0x11f4c8!=null&&_0x11f4c8['trackChildChange'](rt(_0x5785af['name'],_0x5785af['node'])),_0x4e07c4['updateImmediateChild'](_0x5785af['name'],_0x5785af['node'])):_0x4e07c4;}}else return _0x386510['isEmpty']()?_0x43faef:_0xd6e452&&_0xdb3de4(_0x192b8f,_0x39e676)>=0x0?(_0x11f4c8!=null&&(_0x11f4c8['trackChildChange'](Lt(_0x192b8f['name'],_0x192b8f['node'])),_0x11f4c8['trackChildChange'](rt(_0x4b1120,_0x386510))),_0x152918['updateImmediateChild'](_0x4b1120,_0x386510)['updateImmediateChild'](_0x192b8f['name'],g['EMPTY_NODE'])):_0x43faef;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x13769d=new Zi();return _0x13769d['limitSet_']=this['limitSet_'],_0x13769d['limit_']=this['limit_'],_0x13769d['startSet_']=this['startSet_'],_0x13769d['startAfterSet_']=this['startAfterSet_'],_0x13769d['indexStartValue_']=this['indexStartValue_'],_0x13769d['startNameSet_']=this['startNameSet_'],_0x13769d['indexStartName_']=this['indexStartName_'],_0x13769d['endSet_']=this['endSet_'],_0x13769d['endBeforeSet_']=this['endBeforeSet_'],_0x13769d['indexEndValue_']=this['indexEndValue_'],_0x13769d['endNameSet_']=this['endNameSet_'],_0x13769d['indexEndName_']=this['indexEndName_'],_0x13769d['index_']=this['index_'],_0x13769d['viewFrom_']=this['viewFrom_'],_0x13769d;}}function Kh(_0x233804){return _0x233804['loadsAllData']()?new Xi(_0x233804['getIndex']()):_0x233804['hasLimit']()?new jh(_0x233804):new Ft(_0x233804);}function Yh(_0x19e524,_0x5f578d){const _0x4279cf=_0x19e524['copy']();return _0x4279cf['limitSet_']=!0x0,_0x4279cf['limit_']=_0x5f578d,_0x4279cf['viewFrom_']='l',_0x4279cf;}function Qh(_0x4c8f38,_0x40accc,_0x5c2ed0){const _0x3bb58e=_0x4c8f38['copy']();return _0x3bb58e['startSet_']=!0x0,_0x40accc===void 0x0&&(_0x40accc=null),_0x3bb58e['indexStartValue_']=_0x40accc,_0x5c2ed0!=null?(_0x3bb58e['startNameSet_']=!0x0,_0x3bb58e['indexStartName_']=_0x5c2ed0):(_0x3bb58e['startNameSet_']=!0x1,_0x3bb58e['indexStartName_']=''),_0x3bb58e;}function Jh(_0xdc0283,_0x3bdcbb,_0x1a2b00){const _0x77b5e5=_0xdc0283['copy']();return _0x77b5e5['endSet_']=!0x0,_0x3bdcbb===void 0x0&&(_0x3bdcbb=null),_0x77b5e5['indexEndValue_']=_0x3bdcbb,_0x1a2b00!==void 0x0?(_0x77b5e5['endNameSet_']=!0x0,_0x77b5e5['indexEndName_']=_0x1a2b00):(_0x77b5e5['endNameSet_']=!0x1,_0x77b5e5['indexEndName_']=''),_0x77b5e5;}function xo(_0x257bc9,_0x2ed420){const _0x426074=_0x257bc9['copy']();return _0x426074['index_']=_0x2ed420,_0x426074;}function ir(_0x45bc6e){const _0x41c07b={};if(_0x45bc6e['isDefault']())return _0x41c07b;let _0x54e67c;if(_0x45bc6e['index_']===R?_0x54e67c='$priority':_0x45bc6e['index_']===Mo?_0x54e67c='$value':_0x45bc6e['index_']===ve?_0x54e67c='$key':(f(_0x45bc6e['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x54e67c=_0x45bc6e['index_']['toString']()),_0x41c07b['orderBy']=O(_0x54e67c),_0x45bc6e['startSet_']){const _0x1fae34=_0x45bc6e['startAfterSet_']?'startAfter':'startAt';_0x41c07b[_0x1fae34]=O(_0x45bc6e['indexStartValue_']),_0x45bc6e['startNameSet_']&&(_0x41c07b[_0x1fae34]+=','+O(_0x45bc6e['indexStartName_']));}if(_0x45bc6e['endSet_']){const _0xbff3de=_0x45bc6e['endBeforeSet_']?'endBefore':'endAt';_0x41c07b[_0xbff3de]=O(_0x45bc6e['indexEndValue_']),_0x45bc6e['endNameSet_']&&(_0x41c07b[_0xbff3de]+=','+O(_0x45bc6e['indexEndName_']));}return _0x45bc6e['limitSet_']&&(_0x45bc6e['isViewFromLeft']()?_0x41c07b['limitToFirst']=_0x45bc6e['limit_']:_0x41c07b['limitToLast']=_0x45bc6e['limit_']),_0x41c07b;}function sr(_0x18724f){const _0x475030={};if(_0x18724f['startSet_']&&(_0x475030['sp']=_0x18724f['indexStartValue_'],_0x18724f['startNameSet_']&&(_0x475030['sn']=_0x18724f['indexStartName_']),_0x475030['sin']=!_0x18724f['startAfterSet_']),_0x18724f['endSet_']&&(_0x475030['ep']=_0x18724f['indexEndValue_'],_0x18724f['endNameSet_']&&(_0x475030['en']=_0x18724f['indexEndName_']),_0x475030['ein']=!_0x18724f['endBeforeSet_']),_0x18724f['limitSet_']){_0x475030['l']=_0x18724f['limit_'];let _0x5d1fe1=_0x18724f['viewFrom_'];_0x5d1fe1===''&&(_0x18724f['isViewFromLeft']()?_0x5d1fe1='l':_0x5d1fe1='r'),_0x475030['vf']=_0x5d1fe1;}return _0x18724f['index_']!==R&&(_0x475030['i']=_0x18724f['index_']['toString']()),_0x475030;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x54820b){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x212464,_0x4ef057){return _0x4ef057!==void 0x0?'tag$'+_0x4ef057:(f(_0x212464['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x212464['_path']['toString']());}constructor(_0x29919b,_0x4e5327,_0x38bcd5,_0x47911f){super(),this['repoInfo_']=_0x29919b,this['onDataUpdate_']=_0x4e5327,this['authTokenProvider_']=_0x38bcd5,this['appCheckTokenProvider_']=_0x47911f,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x5a63e9,_0x317166,_0x352e2b,_0x49f3e8){const _0x3e5688=_0x5a63e9['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3e5688+'\x20'+_0x5a63e9['_queryIdentifier']);const _0x229a47=vn['getListenId_'](_0x5a63e9,_0x352e2b),_0x265931={};this['listens_'][_0x229a47]=_0x265931;const _0x384924=ir(_0x5a63e9['_queryParams']);this['restRequest_'](_0x3e5688+'.json',_0x384924,(_0x6252d8,_0x5ad62e)=>{let _0x3a45ae=_0x5ad62e;if(_0x6252d8===0x194&&(_0x3a45ae=null,_0x6252d8=null),_0x6252d8===null&&this['onDataUpdate_'](_0x3e5688,_0x3a45ae,!0x1,_0x352e2b),Le(this['listens_'],_0x229a47)===_0x265931){let _0x196194;_0x6252d8?_0x6252d8===0x191?_0x196194='permission_denied':_0x196194='rest_error:'+_0x6252d8:_0x196194='ok',_0x49f3e8(_0x196194,null);}});}['unlisten'](_0x5dba52,_0x2936a8){const _0x3bcb7b=vn['getListenId_'](_0x5dba52,_0x2936a8);delete this['listens_'][_0x3bcb7b];}['get'](_0x23433d){const _0x2abddf=ir(_0x23433d['_queryParams']),_0x37196f=_0x23433d['_path']['toString'](),_0x1b4050=new H();return this['restRequest_'](_0x37196f+'.json',_0x2abddf,(_0x4265b9,_0x2a01b3)=>{let _0x42e0be=_0x2a01b3;_0x4265b9===0x194&&(_0x42e0be=null,_0x4265b9=null),_0x4265b9===null?(this['onDataUpdate_'](_0x37196f,_0x42e0be,!0x1,null),_0x1b4050['resolve'](_0x42e0be)):_0x1b4050['reject'](new Error(_0x42e0be));}),_0x1b4050['promise'];}['refreshAuthToken'](_0x379dc2){}['restRequest_'](_0x20f53f,_0x45b48b={},_0x286e9a){return _0x45b48b['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4173ae,_0x724a2c])=>{_0x4173ae&&_0x4173ae['accessToken']&&(_0x45b48b['auth']=_0x4173ae['accessToken']),_0x724a2c&&_0x724a2c['token']&&(_0x45b48b['ac']=_0x724a2c['token']);const _0x17364b=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x20f53f+'?ns='+this['repoInfo_']['namespace']+ut(_0x45b48b);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x17364b);const _0x5df01a=new XMLHttpRequest();_0x5df01a['onreadystatechange']=()=>{if(_0x286e9a&&_0x5df01a['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x17364b+'\x20received.\x20status:',_0x5df01a['status'],'response:',_0x5df01a['responseText']);let _0x6e2bfe=null;if(_0x5df01a['status']>=0xc8&&_0x5df01a['status']<0x12c){try{_0x6e2bfe=Nt(_0x5df01a['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x17364b+':\x20'+_0x5df01a['responseText']);}_0x286e9a(null,_0x6e2bfe);}else _0x5df01a['status']!==0x191&&_0x5df01a['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x17364b+'\x20Status:\x20'+_0x5df01a['status']),_0x286e9a(_0x5df01a['status']);_0x286e9a=null;}},_0x5df01a['open']('GET',_0x17364b,!0x0),_0x5df01a['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x795e55){return this['rootNode_']['getChild'](_0x795e55);}['updateSnapshot'](_0x29cbb8,_0x1b02f3){this['rootNode_']=this['rootNode_']['updateChild'](_0x29cbb8,_0x1b02f3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x12f6e3,_0xba9dba,_0x2158f2){if(v(_0xba9dba))_0x12f6e3['value']=_0x2158f2,_0x12f6e3['children']['clear']();else{if(_0x12f6e3['value']!==null)_0x12f6e3['value']=_0x12f6e3['value']['updateChild'](_0xba9dba,_0x2158f2);else{const _0x1fc7b8=y(_0xba9dba);_0x12f6e3['children']['has'](_0x1fc7b8)||_0x12f6e3['children']['set'](_0x1fc7b8,En());const _0x142f0e=_0x12f6e3['children']['get'](_0x1fc7b8);_0xba9dba=S(_0xba9dba),pt(_0x142f0e,_0xba9dba,_0x2158f2);}}}function Ti(_0x3820ef,_0x5bc9b0){if(v(_0x5bc9b0))return _0x3820ef['value']=null,_0x3820ef['children']['clear'](),!0x0;if(_0x3820ef['value']!==null){if(_0x3820ef['value']['isLeafNode']())return!0x1;{const _0x3b9db3=_0x3820ef['value'];return _0x3820ef['value']=null,_0x3b9db3['forEachChild'](R,(_0x307187,_0x1c9fc2)=>{pt(_0x3820ef,new C(_0x307187),_0x1c9fc2);}),Ti(_0x3820ef,_0x5bc9b0);}}else{if(_0x3820ef['children']['size']>0x0){const _0x2ddf33=y(_0x5bc9b0);return _0x5bc9b0=S(_0x5bc9b0),_0x3820ef['children']['has'](_0x2ddf33)&&Ti(_0x3820ef['children']['get'](_0x2ddf33),_0x5bc9b0)&&_0x3820ef['children']['delete'](_0x2ddf33),_0x3820ef['children']['size']===0x0;}else return!0x0;}}function Si(_0x32c343,_0x3dcbe2,_0x8a8f02){_0x32c343['value']!==null?_0x8a8f02(_0x3dcbe2,_0x32c343['value']):Zh(_0x32c343,(_0x50e393,_0x2600af)=>{const _0x299c3d=new C(_0x3dcbe2['toString']()+'/'+_0x50e393);Si(_0x2600af,_0x299c3d,_0x8a8f02);});}function Zh(_0x488895,_0x5ab07a){_0x488895['children']['forEach']((_0x4d44a2,_0x985223)=>{_0x5ab07a(_0x985223,_0x4d44a2);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x3d75d4){this['collection_']=_0x3d75d4,this['last_']=null;}['get'](){const _0x466d5b=this['collection_']['get'](),_0x235a78={..._0x466d5b};return this['last_']&&x(this['last_'],(_0x4c37fa,_0x4f9ffc)=>{_0x235a78[_0x4c37fa]=_0x235a78[_0x4c37fa]-_0x4f9ffc;}),this['last_']=_0x466d5b,_0x235a78;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x1261a2,_0x59c1a9){this['server_']=_0x59c1a9,this['statsToReport_']={},this['statsListener_']=new eu(_0x1261a2);const _0x1d5679=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x1d5679));}['reportStats_'](){const _0x2c8149=this['statsListener_']['get'](),_0xca0155={};let _0x40efe3=!0x1;x(_0x2c8149,(_0x2cab3f,_0x582ffd)=>{_0x582ffd>0x0&&Q(this['statsToReport_'],_0x2cab3f)&&(_0xca0155[_0x2cab3f]=_0x582ffd,_0x40efe3=!0x0);}),_0x40efe3&&this['server_']['reportStats'](_0xca0155),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x212e01){_0x212e01[_0x212e01['OVERWRITE']=0x0]='OVERWRITE',_0x212e01[_0x212e01['MERGE']=0x1]='MERGE',_0x212e01[_0x212e01['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x212e01[_0x212e01['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x2c486e){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2c486e,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0xb011a3,_0x2782d7,_0x31fefa){this['path']=_0xb011a3,this['affectedTree']=_0x2782d7,this['revert']=_0x31fefa,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x2afaff){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x7e7898=this['affectedTree']['subtree'](new C(_0x2afaff));return new In(w(),_0x7e7898,this['revert']);}}else return f(y(this['path'])===_0x2afaff,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x291b9e,_0x5fa617){this['source']=_0x291b9e,this['path']=_0x5fa617,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x3644a1){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x582507,_0x541331,_0x17702d){this['source']=_0x582507,this['path']=_0x541331,this['snap']=_0x17702d,this['type']=z['OVERWRITE'];}['operationForChild'](_0x2c9a3d){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x2c9a3d)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x3419bd,_0xcd060f,_0x15ffdc){this['source']=_0x3419bd,this['path']=_0xcd060f,this['children']=_0x15ffdc,this['type']=z['MERGE'];}['operationForChild'](_0x4c1337){if(v(this['path'])){const _0x1bb557=this['children']['subtree'](new C(_0x4c1337));return _0x1bb557['isEmpty']()?null:_0x1bb557['value']?new Be(this['source'],w(),_0x1bb557['value']):new ot(this['source'],w(),_0x1bb557);}else return f(y(this['path'])===_0x4c1337,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x5ef592,_0x22b4df,_0x4e252a){this['node_']=_0x5ef592,this['fullyInitialized_']=_0x22b4df,this['filtered_']=_0x4e252a;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x5f509f){if(v(_0x5f509f))return this['isFullyInitialized']()&&!this['filtered_'];const _0x49ffef=y(_0x5f509f);return this['isCompleteForChild'](_0x49ffef);}['isCompleteForChild'](_0x817aee){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x817aee);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x469b5c){this['query_']=_0x469b5c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x2b1183,_0x23f834,_0x232f68,_0x3bb69c){const _0x328e87=[],_0x67861e=[];return _0x23f834['forEach'](_0x12f981=>{_0x12f981['type']==='child_changed'&&_0x2b1183['index_']['indexedValueChanged'](_0x12f981['oldSnap'],_0x12f981['snapshotNode'])&&_0x67861e['push'](zh(_0x12f981['childName'],_0x12f981['snapshotNode']));}),wt(_0x2b1183,_0x328e87,'child_removed',_0x23f834,_0x3bb69c,_0x232f68),wt(_0x2b1183,_0x328e87,'child_added',_0x23f834,_0x3bb69c,_0x232f68),wt(_0x2b1183,_0x328e87,'child_moved',_0x67861e,_0x3bb69c,_0x232f68),wt(_0x2b1183,_0x328e87,'child_changed',_0x23f834,_0x3bb69c,_0x232f68),wt(_0x2b1183,_0x328e87,'value',_0x23f834,_0x3bb69c,_0x232f68),_0x328e87;}function wt(_0x5cc5a8,_0x1a2fc8,_0x40825f,_0x55ff5e,_0x680d83,_0x5557fe){const _0x5f1075=_0x55ff5e['filter'](_0x1becd5=>_0x1becd5['type']===_0x40825f);_0x5f1075['sort']((_0x2d22a2,_0x21978c)=>au(_0x5cc5a8,_0x2d22a2,_0x21978c)),_0x5f1075['forEach'](_0x3e22e3=>{const _0x2a4e52=ou(_0x5cc5a8,_0x3e22e3,_0x5557fe);_0x680d83['forEach'](_0x491604=>{_0x491604['respondsTo'](_0x3e22e3['type'])&&_0x1a2fc8['push'](_0x491604['createEvent'](_0x2a4e52,_0x5cc5a8['query_']));});});}function ou(_0x8c5a71,_0x5abe73,_0x58c3ab){return _0x5abe73['type']==='value'||_0x5abe73['type']==='child_removed'||(_0x5abe73['prevName']=_0x58c3ab['getPredecessorChildName'](_0x5abe73['childName'],_0x5abe73['snapshotNode'],_0x8c5a71['index_'])),_0x5abe73;}function au(_0x5764af,_0x547e13,_0x4dbf2e){if(_0x547e13['childName']==null||_0x4dbf2e['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1687ff=new E(_0x547e13['childName'],_0x547e13['snapshotNode']),_0x21fc1e=new E(_0x4dbf2e['childName'],_0x4dbf2e['snapshotNode']);return _0x5764af['index_']['compare'](_0x1687ff,_0x21fc1e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0xe43d84,_0xd4f0dd){return{'eventCache':_0xe43d84,'serverCache':_0xd4f0dd};}function Rt(_0x3b0be8,_0x26ba27,_0x127045,_0x41f3ee){return Un(new Te(_0x26ba27,_0x127045,_0x41f3ee),_0x3b0be8['serverCache']);}function Fo(_0x48b22a,_0x6d3a1d,_0x5b50b3,_0x3b3523){return Un(_0x48b22a['eventCache'],new Te(_0x6d3a1d,_0x5b50b3,_0x3b3523));}function wn(_0x39f7df){return _0x39f7df['eventCache']['isFullyInitialized']()?_0x39f7df['eventCache']['getNode']():null;}function Ve(_0xd7605b){return _0xd7605b['serverCache']['isFullyInitialized']()?_0xd7605b['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x53efc5){let _0x125390=new b(null);return x(_0x53efc5,(_0x51ce61,_0x2ad50b)=>{_0x125390=_0x125390['set'](new C(_0x51ce61),_0x2ad50b);}),_0x125390;}constructor(_0x323328,_0x4f3acd=cu()){this['value']=_0x323328,this['children']=_0x4f3acd;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x16fea7,_0x3c8fe6){if(this['value']!=null&&_0x3c8fe6(this['value']))return{'path':w(),'value':this['value']};if(v(_0x16fea7))return null;{const _0x317e2c=y(_0x16fea7),_0x55c906=this['children']['get'](_0x317e2c);if(_0x55c906!==null){const _0x5454ec=_0x55c906['findRootMostMatchingPathAndValue'](S(_0x16fea7),_0x3c8fe6);return _0x5454ec!=null?{'path':k(new C(_0x317e2c),_0x5454ec['path']),'value':_0x5454ec['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5a660b){return this['findRootMostMatchingPathAndValue'](_0x5a660b,()=>!0x0);}['subtree'](_0x74e577){if(v(_0x74e577))return this;{const _0x309621=y(_0x74e577),_0x5f3b91=this['children']['get'](_0x309621);return _0x5f3b91!==null?_0x5f3b91['subtree'](S(_0x74e577)):new b(null);}}['set'](_0x30b219,_0xbd4210){if(v(_0x30b219))return new b(_0xbd4210,this['children']);{const _0x3f8c74=y(_0x30b219),_0x29f0c4=(this['children']['get'](_0x3f8c74)||new b(null))['set'](S(_0x30b219),_0xbd4210),_0x22ab6e=this['children']['insert'](_0x3f8c74,_0x29f0c4);return new b(this['value'],_0x22ab6e);}}['remove'](_0x515dab){if(v(_0x515dab))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x24162d=y(_0x515dab),_0x2f6699=this['children']['get'](_0x24162d);if(_0x2f6699){const _0xa4891a=_0x2f6699['remove'](S(_0x515dab));let _0x11be41;return _0xa4891a['isEmpty']()?_0x11be41=this['children']['remove'](_0x24162d):_0x11be41=this['children']['insert'](_0x24162d,_0xa4891a),this['value']===null&&_0x11be41['isEmpty']()?new b(null):new b(this['value'],_0x11be41);}else return this;}}['get'](_0x26cb88){if(v(_0x26cb88))return this['value'];{const _0x597a75=y(_0x26cb88),_0x11db64=this['children']['get'](_0x597a75);return _0x11db64?_0x11db64['get'](S(_0x26cb88)):null;}}['setTree'](_0x4a17e5,_0x4c33ba){if(v(_0x4a17e5))return _0x4c33ba;{const _0x2a8ea9=y(_0x4a17e5),_0x53f172=(this['children']['get'](_0x2a8ea9)||new b(null))['setTree'](S(_0x4a17e5),_0x4c33ba);let _0x507e38;return _0x53f172['isEmpty']()?_0x507e38=this['children']['remove'](_0x2a8ea9):_0x507e38=this['children']['insert'](_0x2a8ea9,_0x53f172),new b(this['value'],_0x507e38);}}['fold'](_0xad81b5){return this['fold_'](w(),_0xad81b5);}['fold_'](_0x2aa32a,_0x482501){const _0x29864d={};return this['children']['inorderTraversal']((_0x5a8a18,_0x4931d3)=>{_0x29864d[_0x5a8a18]=_0x4931d3['fold_'](k(_0x2aa32a,_0x5a8a18),_0x482501);}),_0x482501(_0x2aa32a,this['value'],_0x29864d);}['findOnPath'](_0x2e0960,_0x1596b6){return this['findOnPath_'](_0x2e0960,w(),_0x1596b6);}['findOnPath_'](_0x5f09bb,_0x108bfd,_0x58f64a){const _0x1d28ff=this['value']?_0x58f64a(_0x108bfd,this['value']):!0x1;if(_0x1d28ff)return _0x1d28ff;if(v(_0x5f09bb))return null;{const _0xb48500=y(_0x5f09bb),_0x306fd8=this['children']['get'](_0xb48500);return _0x306fd8?_0x306fd8['findOnPath_'](S(_0x5f09bb),k(_0x108bfd,_0xb48500),_0x58f64a):null;}}['foreachOnPath'](_0x245349,_0x168a47){return this['foreachOnPath_'](_0x245349,w(),_0x168a47);}['foreachOnPath_'](_0x4e628e,_0xac41c0,_0x5100b7){if(v(_0x4e628e))return this;{this['value']&&_0x5100b7(_0xac41c0,this['value']);const _0x1e5f69=y(_0x4e628e),_0x584e2e=this['children']['get'](_0x1e5f69);return _0x584e2e?_0x584e2e['foreachOnPath_'](S(_0x4e628e),k(_0xac41c0,_0x1e5f69),_0x5100b7):new b(null);}}['foreach'](_0x33fb13){this['foreach_'](w(),_0x33fb13);}['foreach_'](_0x416ce0,_0x4d8a7e){this['children']['inorderTraversal']((_0x5c8cd8,_0x452681)=>{_0x452681['foreach_'](k(_0x416ce0,_0x5c8cd8),_0x4d8a7e);}),this['value']&&_0x4d8a7e(_0x416ce0,this['value']);}['foreachChild'](_0xbc5154){this['children']['inorderTraversal']((_0x2dddf1,_0x539872)=>{_0x539872['value']&&_0xbc5154(_0x2dddf1,_0x539872['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x4b9b24){this['writeTree_']=_0x4b9b24;}static['empty'](){return new K(new b(null));}}function At(_0x4a4d9c,_0x3a986e,_0x3df593){if(v(_0x3a986e))return new K(new b(_0x3df593));{const _0x1f2385=_0x4a4d9c['writeTree_']['findRootMostValueAndPath'](_0x3a986e);if(_0x1f2385!=null){const _0xd41d1d=_0x1f2385['path'];let _0x2aedbf=_0x1f2385['value'];const _0x474016=F(_0xd41d1d,_0x3a986e);return _0x2aedbf=_0x2aedbf['updateChild'](_0x474016,_0x3df593),new K(_0x4a4d9c['writeTree_']['set'](_0xd41d1d,_0x2aedbf));}else{const _0x41983f=new b(_0x3df593),_0x1c62d8=_0x4a4d9c['writeTree_']['setTree'](_0x3a986e,_0x41983f);return new K(_0x1c62d8);}}}function bi(_0x300800,_0x110250,_0x3bb56d){let _0x18dfb9=_0x300800;return x(_0x3bb56d,(_0x233405,_0x470c66)=>{_0x18dfb9=At(_0x18dfb9,k(_0x110250,_0x233405),_0x470c66);}),_0x18dfb9;}function or(_0x1bedc8,_0x1b637a){if(v(_0x1b637a))return K['empty']();{const _0x2e95db=_0x1bedc8['writeTree_']['setTree'](_0x1b637a,new b(null));return new K(_0x2e95db);}}function Ri(_0x2f2d9d,_0x2c308f){return ze(_0x2f2d9d,_0x2c308f)!=null;}function ze(_0x1703d8,_0x4d9de0){const _0x1fe854=_0x1703d8['writeTree_']['findRootMostValueAndPath'](_0x4d9de0);return _0x1fe854!=null?_0x1703d8['writeTree_']['get'](_0x1fe854['path'])['getChild'](F(_0x1fe854['path'],_0x4d9de0)):null;}function ar(_0x3a439f){const _0x51f359=[],_0x1b1f61=_0x3a439f['writeTree_']['value'];return _0x1b1f61!=null?_0x1b1f61['isLeafNode']()||_0x1b1f61['forEachChild'](R,(_0x4cd1a3,_0x5cd06b)=>{_0x51f359['push'](new E(_0x4cd1a3,_0x5cd06b));}):_0x3a439f['writeTree_']['children']['inorderTraversal']((_0x5dca34,_0x57f17d)=>{_0x57f17d['value']!=null&&_0x51f359['push'](new E(_0x5dca34,_0x57f17d['value']));}),_0x51f359;}function Ee(_0x3fff8c,_0x49637b){if(v(_0x49637b))return _0x3fff8c;{const _0x53dab2=ze(_0x3fff8c,_0x49637b);return _0x53dab2!=null?new K(new b(_0x53dab2)):new K(_0x3fff8c['writeTree_']['subtree'](_0x49637b));}}function Ai(_0x3e7938){return _0x3e7938['writeTree_']['isEmpty']();}function at(_0x5a11d8,_0x3cd754){return Uo(w(),_0x5a11d8['writeTree_'],_0x3cd754);}function Uo(_0x2e4c98,_0x511520,_0x932ac9){if(_0x511520['value']!=null)return _0x932ac9['updateChild'](_0x2e4c98,_0x511520['value']);{let _0x2b47a0=null;return _0x511520['children']['inorderTraversal']((_0x502507,_0x567b8b)=>{_0x502507==='.priority'?(f(_0x567b8b['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2b47a0=_0x567b8b['value']):_0x932ac9=Uo(k(_0x2e4c98,_0x502507),_0x567b8b,_0x932ac9);}),!_0x932ac9['getChild'](_0x2e4c98)['isEmpty']()&&_0x2b47a0!==null&&(_0x932ac9=_0x932ac9['updateChild'](k(_0x2e4c98,'.priority'),_0x2b47a0)),_0x932ac9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x22fb3d,_0x17b3cc){return Ho(_0x17b3cc,_0x22fb3d);}function lu(_0x38a902,_0x32bb3f,_0x3f147c,_0xd41b95,_0x375eb6){f(_0xd41b95>_0x38a902['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x375eb6===void 0x0&&(_0x375eb6=!0x0),_0x38a902['allWrites']['push']({'path':_0x32bb3f,'snap':_0x3f147c,'writeId':_0xd41b95,'visible':_0x375eb6}),_0x375eb6&&(_0x38a902['visibleWrites']=At(_0x38a902['visibleWrites'],_0x32bb3f,_0x3f147c)),_0x38a902['lastWriteId']=_0xd41b95;}function hu(_0x58c5e6,_0x494a6a,_0x147f35,_0x15156f){f(_0x15156f>_0x58c5e6['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x58c5e6['allWrites']['push']({'path':_0x494a6a,'children':_0x147f35,'writeId':_0x15156f,'visible':!0x0}),_0x58c5e6['visibleWrites']=bi(_0x58c5e6['visibleWrites'],_0x494a6a,_0x147f35),_0x58c5e6['lastWriteId']=_0x15156f;}function uu(_0x3bdf68,_0x394fcd){for(let _0x548572=0x0;_0x548572<_0x3bdf68['allWrites']['length'];_0x548572++){const _0x39c7ba=_0x3bdf68['allWrites'][_0x548572];if(_0x39c7ba['writeId']===_0x394fcd)return _0x39c7ba;}return null;}function du(_0x396a14,_0x16fede){const _0xf78af1=_0x396a14['allWrites']['findIndex'](_0x376513=>_0x376513['writeId']===_0x16fede);f(_0xf78af1>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x58db5d=_0x396a14['allWrites'][_0xf78af1];_0x396a14['allWrites']['splice'](_0xf78af1,0x1);let _0x146861=_0x58db5d['visible'],_0x457727=!0x1,_0x4b2d51=_0x396a14['allWrites']['length']-0x1;for(;_0x146861&&_0x4b2d51>=0x0;){const _0x564f8b=_0x396a14['allWrites'][_0x4b2d51];_0x564f8b['visible']&&(_0x4b2d51>=_0xf78af1&&fu(_0x564f8b,_0x58db5d['path'])?_0x146861=!0x1:G(_0x58db5d['path'],_0x564f8b['path'])&&(_0x457727=!0x0)),_0x4b2d51--;}if(_0x146861){if(_0x457727)return pu(_0x396a14),!0x0;if(_0x58db5d['snap'])_0x396a14['visibleWrites']=or(_0x396a14['visibleWrites'],_0x58db5d['path']);else{const _0x5692a1=_0x58db5d['children'];x(_0x5692a1,_0x25ad0d=>{_0x396a14['visibleWrites']=or(_0x396a14['visibleWrites'],k(_0x58db5d['path'],_0x25ad0d));});}return!0x0;}else return!0x1;}function fu(_0x3c3c47,_0x32c157){if(_0x3c3c47['snap'])return G(_0x3c3c47['path'],_0x32c157);for(const _0x1a45db in _0x3c3c47['children'])if(_0x3c3c47['children']['hasOwnProperty'](_0x1a45db)&&G(k(_0x3c3c47['path'],_0x1a45db),_0x32c157))return!0x0;return!0x1;}function pu(_0x3e53a0){_0x3e53a0['visibleWrites']=Wo(_0x3e53a0['allWrites'],_u,w()),_0x3e53a0['allWrites']['length']>0x0?_0x3e53a0['lastWriteId']=_0x3e53a0['allWrites'][_0x3e53a0['allWrites']['length']-0x1]['writeId']:_0x3e53a0['lastWriteId']=-0x1;}function _u(_0x4baeec){return _0x4baeec['visible'];}function Wo(_0x332b49,_0xc0cf9a,_0x33d7ee){let _0x52b013=K['empty']();for(let _0x40dfca=0x0;_0x40dfca<_0x332b49['length'];++_0x40dfca){const _0x565c76=_0x332b49[_0x40dfca];if(_0xc0cf9a(_0x565c76)){const _0x58e326=_0x565c76['path'];let _0x4532c4;if(_0x565c76['snap'])G(_0x33d7ee,_0x58e326)?(_0x4532c4=F(_0x33d7ee,_0x58e326),_0x52b013=At(_0x52b013,_0x4532c4,_0x565c76['snap'])):G(_0x58e326,_0x33d7ee)&&(_0x4532c4=F(_0x58e326,_0x33d7ee),_0x52b013=At(_0x52b013,w(),_0x565c76['snap']['getChild'](_0x4532c4)));else{if(_0x565c76['children']){if(G(_0x33d7ee,_0x58e326))_0x4532c4=F(_0x33d7ee,_0x58e326),_0x52b013=bi(_0x52b013,_0x4532c4,_0x565c76['children']);else{if(G(_0x58e326,_0x33d7ee)){if(_0x4532c4=F(_0x58e326,_0x33d7ee),v(_0x4532c4))_0x52b013=bi(_0x52b013,w(),_0x565c76['children']);else{const _0x1b6929=Le(_0x565c76['children'],y(_0x4532c4));if(_0x1b6929){const _0x446b19=_0x1b6929['getChild'](S(_0x4532c4));_0x52b013=At(_0x52b013,w(),_0x446b19);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x52b013;}function Bo(_0x2338c7,_0x3724bc,_0x99f478,_0x226466,_0x420cac){if(!_0x226466&&!_0x420cac){const _0x406a71=ze(_0x2338c7['visibleWrites'],_0x3724bc);if(_0x406a71!=null)return _0x406a71;{const _0x264e8d=Ee(_0x2338c7['visibleWrites'],_0x3724bc);if(Ai(_0x264e8d))return _0x99f478;if(_0x99f478==null&&!Ri(_0x264e8d,w()))return null;{const _0x49aaa7=_0x99f478||g['EMPTY_NODE'];return at(_0x264e8d,_0x49aaa7);}}}else{const _0x90d403=Ee(_0x2338c7['visibleWrites'],_0x3724bc);if(!_0x420cac&&Ai(_0x90d403))return _0x99f478;if(!_0x420cac&&_0x99f478==null&&!Ri(_0x90d403,w()))return null;{const _0x5dce22=function(_0xab2db2){return(_0xab2db2['visible']||_0x420cac)&&(!_0x226466||!~_0x226466['indexOf'](_0xab2db2['writeId']))&&(G(_0xab2db2['path'],_0x3724bc)||G(_0x3724bc,_0xab2db2['path']));},_0x3ee19a=Wo(_0x2338c7['allWrites'],_0x5dce22,_0x3724bc),_0x19aa37=_0x99f478||g['EMPTY_NODE'];return at(_0x3ee19a,_0x19aa37);}}}function gu(_0x223903,_0x16689b,_0xbdb064){let _0x159dc8=g['EMPTY_NODE'];const _0x194e7d=ze(_0x223903['visibleWrites'],_0x16689b);if(_0x194e7d)return _0x194e7d['isLeafNode']()||_0x194e7d['forEachChild'](R,(_0x5266cf,_0x4bd61a)=>{_0x159dc8=_0x159dc8['updateImmediateChild'](_0x5266cf,_0x4bd61a);}),_0x159dc8;if(_0xbdb064){const _0x9a1922=Ee(_0x223903['visibleWrites'],_0x16689b);return _0xbdb064['forEachChild'](R,(_0x29b09b,_0xb58739)=>{const _0x252120=at(Ee(_0x9a1922,new C(_0x29b09b)),_0xb58739);_0x159dc8=_0x159dc8['updateImmediateChild'](_0x29b09b,_0x252120);}),ar(_0x9a1922)['forEach'](_0x2a1626=>{_0x159dc8=_0x159dc8['updateImmediateChild'](_0x2a1626['name'],_0x2a1626['node']);}),_0x159dc8;}else{const _0x4bfa3d=Ee(_0x223903['visibleWrites'],_0x16689b);return ar(_0x4bfa3d)['forEach'](_0x39cd4e=>{_0x159dc8=_0x159dc8['updateImmediateChild'](_0x39cd4e['name'],_0x39cd4e['node']);}),_0x159dc8;}}function mu(_0x2671dc,_0x5ed6a1,_0x588637,_0x2e3eb2,_0xe1ffe0){f(_0x2e3eb2||_0xe1ffe0,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3e3e94=k(_0x5ed6a1,_0x588637);if(Ri(_0x2671dc['visibleWrites'],_0x3e3e94))return null;{const _0x5762de=Ee(_0x2671dc['visibleWrites'],_0x3e3e94);return Ai(_0x5762de)?_0xe1ffe0['getChild'](_0x588637):at(_0x5762de,_0xe1ffe0['getChild'](_0x588637));}}function yu(_0x26807f,_0x161a69,_0x264024,_0x5d9ec1){const _0x3ca85e=k(_0x161a69,_0x264024),_0x1bf5ef=ze(_0x26807f['visibleWrites'],_0x3ca85e);if(_0x1bf5ef!=null)return _0x1bf5ef;if(_0x5d9ec1['isCompleteForChild'](_0x264024)){const _0x538965=Ee(_0x26807f['visibleWrites'],_0x3ca85e);return at(_0x538965,_0x5d9ec1['getNode']()['getImmediateChild'](_0x264024));}else return null;}function vu(_0xd95fc2,_0x350642){return ze(_0xd95fc2['visibleWrites'],_0x350642);}function Eu(_0x1c18a7,_0x37f100,_0xaed822,_0xb4298d,_0xf89a91,_0x4ea02d,_0x43b80b){let _0xa6534e;const _0x2cee7a=Ee(_0x1c18a7['visibleWrites'],_0x37f100),_0x10afa2=ze(_0x2cee7a,w());if(_0x10afa2!=null)_0xa6534e=_0x10afa2;else{if(_0xaed822!=null)_0xa6534e=at(_0x2cee7a,_0xaed822);else return[];}if(_0xa6534e=_0xa6534e['withIndex'](_0x43b80b),!_0xa6534e['isEmpty']()&&!_0xa6534e['isLeafNode']()){const _0x3cf612=[],_0xc41ec2=_0x43b80b['getCompare'](),_0x495bef=_0x4ea02d?_0xa6534e['getReverseIteratorFrom'](_0xb4298d,_0x43b80b):_0xa6534e['getIteratorFrom'](_0xb4298d,_0x43b80b);let _0x1f2a11=_0x495bef['getNext']();for(;_0x1f2a11&&_0x3cf612['length']<_0xf89a91;)_0xc41ec2(_0x1f2a11,_0xb4298d)!==0x0&&_0x3cf612['push'](_0x1f2a11),_0x1f2a11=_0x495bef['getNext']();return _0x3cf612;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x156f58,_0x4b883a,_0x184d27,_0x1f4405){return Bo(_0x156f58['writeTree'],_0x156f58['treePath'],_0x4b883a,_0x184d27,_0x1f4405);}function is(_0x32b55b,_0x9b9ff4){return gu(_0x32b55b['writeTree'],_0x32b55b['treePath'],_0x9b9ff4);}function cr(_0x8e0f17,_0x395d79,_0x3773dd,_0x2c5ae6){return mu(_0x8e0f17['writeTree'],_0x8e0f17['treePath'],_0x395d79,_0x3773dd,_0x2c5ae6);}function Tn(_0x17729c,_0x56498f){return vu(_0x17729c['writeTree'],k(_0x17729c['treePath'],_0x56498f));}function wu(_0x23d649,_0x5678b6,_0x30b434,_0x150485,_0x46974f,_0x1c5880){return Eu(_0x23d649['writeTree'],_0x23d649['treePath'],_0x5678b6,_0x30b434,_0x150485,_0x46974f,_0x1c5880);}function ss(_0x48a0d6,_0x392b7e,_0xf4019a){return yu(_0x48a0d6['writeTree'],_0x48a0d6['treePath'],_0x392b7e,_0xf4019a);}function Vo(_0x33b012,_0x251ed8){return Ho(k(_0x33b012['treePath'],_0x251ed8),_0x33b012['writeTree']);}function Ho(_0x50c21a,_0x4264cb){return{'treePath':_0x50c21a,'writeTree':_0x4264cb};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x49d586){const _0x336a9a=_0x49d586['type'],_0x480a90=_0x49d586['childName'];f(_0x336a9a==='child_added'||_0x336a9a==='child_changed'||_0x336a9a==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x480a90!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0xdfd8fd=this['changeMap']['get'](_0x480a90);if(_0xdfd8fd){const _0x13b2a2=_0xdfd8fd['type'];if(_0x336a9a==='child_added'&&_0x13b2a2==='child_removed')this['changeMap']['set'](_0x480a90,xt(_0x480a90,_0x49d586['snapshotNode'],_0xdfd8fd['snapshotNode']));else{if(_0x336a9a==='child_removed'&&_0x13b2a2==='child_added')this['changeMap']['delete'](_0x480a90);else{if(_0x336a9a==='child_removed'&&_0x13b2a2==='child_changed')this['changeMap']['set'](_0x480a90,Lt(_0x480a90,_0xdfd8fd['oldSnap']));else{if(_0x336a9a==='child_changed'&&_0x13b2a2==='child_added')this['changeMap']['set'](_0x480a90,rt(_0x480a90,_0x49d586['snapshotNode']));else{if(_0x336a9a==='child_changed'&&_0x13b2a2==='child_changed')this['changeMap']['set'](_0x480a90,xt(_0x480a90,_0x49d586['snapshotNode'],_0xdfd8fd['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x49d586+'\x20occurred\x20after\x20'+_0xdfd8fd);}}}}}else this['changeMap']['set'](_0x480a90,_0x49d586);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x87426f){return null;}['getChildAfterChild'](_0x3fed9b,_0x216f6d,_0x44856f){return null;}}const $o=new Tu();class rs{constructor(_0x5259d4,_0x49ee9b,_0x44eb9f=null){this['writes_']=_0x5259d4,this['viewCache_']=_0x49ee9b,this['optCompleteServerCache_']=_0x44eb9f;}['getCompleteChild'](_0x5c2407){const _0xc6e73b=this['viewCache_']['eventCache'];if(_0xc6e73b['isCompleteForChild'](_0x5c2407))return _0xc6e73b['getNode']()['getImmediateChild'](_0x5c2407);{const _0x56e947=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x5c2407,_0x56e947);}}['getChildAfterChild'](_0x1529db,_0x489967,_0x352a5c){const _0x443476=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x33070c=wu(this['writes_'],_0x443476,_0x489967,0x1,_0x352a5c,_0x1529db);return _0x33070c['length']===0x0?null:_0x33070c[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x376a8a){return{'filter':_0x376a8a};}function bu(_0x37246d,_0x68e3e8){f(_0x68e3e8['eventCache']['getNode']()['isIndexed'](_0x37246d['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x68e3e8['serverCache']['getNode']()['isIndexed'](_0x37246d['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x40cc7b,_0x4e07ec,_0x448979,_0x2756c6,_0x56cdcc){const _0x244b8d=new Cu();let _0x5cea67,_0x1d262b;if(_0x448979['type']===z['OVERWRITE']){const _0x1b1333=_0x448979;_0x1b1333['source']['fromUser']?_0x5cea67=ki(_0x40cc7b,_0x4e07ec,_0x1b1333['path'],_0x1b1333['snap'],_0x2756c6,_0x56cdcc,_0x244b8d):(f(_0x1b1333['source']['fromServer'],'Unknown\x20source.'),_0x1d262b=_0x1b1333['source']['tagged']||_0x4e07ec['serverCache']['isFiltered']()&&!v(_0x1b1333['path']),_0x5cea67=Sn(_0x40cc7b,_0x4e07ec,_0x1b1333['path'],_0x1b1333['snap'],_0x2756c6,_0x56cdcc,_0x1d262b,_0x244b8d));}else{if(_0x448979['type']===z['MERGE']){const _0x545790=_0x448979;_0x545790['source']['fromUser']?_0x5cea67=ku(_0x40cc7b,_0x4e07ec,_0x545790['path'],_0x545790['children'],_0x2756c6,_0x56cdcc,_0x244b8d):(f(_0x545790['source']['fromServer'],'Unknown\x20source.'),_0x1d262b=_0x545790['source']['tagged']||_0x4e07ec['serverCache']['isFiltered'](),_0x5cea67=Pi(_0x40cc7b,_0x4e07ec,_0x545790['path'],_0x545790['children'],_0x2756c6,_0x56cdcc,_0x1d262b,_0x244b8d));}else{if(_0x448979['type']===z['ACK_USER_WRITE']){const _0x442ea9=_0x448979;_0x442ea9['revert']?_0x5cea67=Ou(_0x40cc7b,_0x4e07ec,_0x442ea9['path'],_0x2756c6,_0x56cdcc,_0x244b8d):_0x5cea67=Pu(_0x40cc7b,_0x4e07ec,_0x442ea9['path'],_0x442ea9['affectedTree'],_0x2756c6,_0x56cdcc,_0x244b8d);}else{if(_0x448979['type']===z['LISTEN_COMPLETE'])_0x5cea67=Nu(_0x40cc7b,_0x4e07ec,_0x448979['path'],_0x2756c6,_0x244b8d);else throw ht('Unknown\x20operation\x20type:\x20'+_0x448979['type']);}}}const _0x43b74c=_0x244b8d['getChanges']();return Au(_0x4e07ec,_0x5cea67,_0x43b74c),{'viewCache':_0x5cea67,'changes':_0x43b74c};}function Au(_0x29e797,_0x52215d,_0x39131b){const _0x27e2a9=_0x52215d['eventCache'];if(_0x27e2a9['isFullyInitialized']()){const _0x3d45a6=_0x27e2a9['getNode']()['isLeafNode']()||_0x27e2a9['getNode']()['isEmpty'](),_0x133277=wn(_0x29e797);(_0x39131b['length']>0x0||!_0x29e797['eventCache']['isFullyInitialized']()||_0x3d45a6&&!_0x27e2a9['getNode']()['equals'](_0x133277)||!_0x27e2a9['getNode']()['getPriority']()['equals'](_0x133277['getPriority']()))&&_0x39131b['push'](Lo(wn(_0x52215d)));}}function Go(_0x764f74,_0xb5ca1f,_0xff42c5,_0x1ffd8f,_0x1162f7,_0x19d8d3){const _0x9001fe=_0xb5ca1f['eventCache'];if(Tn(_0x1ffd8f,_0xff42c5)!=null)return _0xb5ca1f;{let _0x1d51a5,_0xb15257;if(v(_0xff42c5)){if(f(_0xb5ca1f['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xb5ca1f['serverCache']['isFiltered']()){const _0x3fd375=Ve(_0xb5ca1f),_0x2bcfe5=_0x3fd375 instanceof g?_0x3fd375:g['EMPTY_NODE'],_0x538cd0=is(_0x1ffd8f,_0x2bcfe5);_0x1d51a5=_0x764f74['filter']['updateFullNode'](_0xb5ca1f['eventCache']['getNode'](),_0x538cd0,_0x19d8d3);}else{const _0x64adcb=Cn(_0x1ffd8f,Ve(_0xb5ca1f));_0x1d51a5=_0x764f74['filter']['updateFullNode'](_0xb5ca1f['eventCache']['getNode'](),_0x64adcb,_0x19d8d3);}}else{const _0x2e147d=y(_0xff42c5);if(_0x2e147d==='.priority'){f(Ce(_0xff42c5)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3a2cc7=_0x9001fe['getNode']();_0xb15257=_0xb5ca1f['serverCache']['getNode']();const _0x1cd5b5=cr(_0x1ffd8f,_0xff42c5,_0x3a2cc7,_0xb15257);_0x1cd5b5!=null?_0x1d51a5=_0x764f74['filter']['updatePriority'](_0x3a2cc7,_0x1cd5b5):_0x1d51a5=_0x9001fe['getNode']();}else{const _0x479b32=S(_0xff42c5);let _0x1724cf;if(_0x9001fe['isCompleteForChild'](_0x2e147d)){_0xb15257=_0xb5ca1f['serverCache']['getNode']();const _0x13bfc1=cr(_0x1ffd8f,_0xff42c5,_0x9001fe['getNode'](),_0xb15257);_0x13bfc1!=null?_0x1724cf=_0x9001fe['getNode']()['getImmediateChild'](_0x2e147d)['updateChild'](_0x479b32,_0x13bfc1):_0x1724cf=_0x9001fe['getNode']()['getImmediateChild'](_0x2e147d);}else _0x1724cf=ss(_0x1ffd8f,_0x2e147d,_0xb5ca1f['serverCache']);_0x1724cf!=null?_0x1d51a5=_0x764f74['filter']['updateChild'](_0x9001fe['getNode'](),_0x2e147d,_0x1724cf,_0x479b32,_0x1162f7,_0x19d8d3):_0x1d51a5=_0x9001fe['getNode']();}}return Rt(_0xb5ca1f,_0x1d51a5,_0x9001fe['isFullyInitialized']()||v(_0xff42c5),_0x764f74['filter']['filtersNodes']());}}function Sn(_0x1f72a8,_0x3e1dfc,_0x5931f1,_0x511a74,_0x821f2d,_0x2dc177,_0x24d054,_0xea775f){const _0x56d42d=_0x3e1dfc['serverCache'];let _0x4174b2;const _0x49baa5=_0x24d054?_0x1f72a8['filter']:_0x1f72a8['filter']['getIndexedFilter']();if(v(_0x5931f1))_0x4174b2=_0x49baa5['updateFullNode'](_0x56d42d['getNode'](),_0x511a74,null);else{if(_0x49baa5['filtersNodes']()&&!_0x56d42d['isFiltered']()){const _0x25fb7b=_0x56d42d['getNode']()['updateChild'](_0x5931f1,_0x511a74);_0x4174b2=_0x49baa5['updateFullNode'](_0x56d42d['getNode'](),_0x25fb7b,null);}else{const _0x2abfe7=y(_0x5931f1);if(!_0x56d42d['isCompleteForPath'](_0x5931f1)&&Ce(_0x5931f1)>0x1)return _0x3e1dfc;const _0x1b7bc0=S(_0x5931f1),_0x231358=_0x56d42d['getNode']()['getImmediateChild'](_0x2abfe7)['updateChild'](_0x1b7bc0,_0x511a74);_0x2abfe7==='.priority'?_0x4174b2=_0x49baa5['updatePriority'](_0x56d42d['getNode'](),_0x231358):_0x4174b2=_0x49baa5['updateChild'](_0x56d42d['getNode'](),_0x2abfe7,_0x231358,_0x1b7bc0,$o,null);}}const _0x52e702=Fo(_0x3e1dfc,_0x4174b2,_0x56d42d['isFullyInitialized']()||v(_0x5931f1),_0x49baa5['filtersNodes']()),_0xa1a378=new rs(_0x821f2d,_0x52e702,_0x2dc177);return Go(_0x1f72a8,_0x52e702,_0x5931f1,_0x821f2d,_0xa1a378,_0xea775f);}function ki(_0x2763f4,_0x22623e,_0x40e4ae,_0x3f0b10,_0x1da015,_0x4d513c,_0x4fda84){const _0x38066b=_0x22623e['eventCache'];let _0x231239,_0x1de916;const _0x2a1983=new rs(_0x1da015,_0x22623e,_0x4d513c);if(v(_0x40e4ae))_0x1de916=_0x2763f4['filter']['updateFullNode'](_0x22623e['eventCache']['getNode'](),_0x3f0b10,_0x4fda84),_0x231239=Rt(_0x22623e,_0x1de916,!0x0,_0x2763f4['filter']['filtersNodes']());else{const _0x51691c=y(_0x40e4ae);if(_0x51691c==='.priority')_0x1de916=_0x2763f4['filter']['updatePriority'](_0x22623e['eventCache']['getNode'](),_0x3f0b10),_0x231239=Rt(_0x22623e,_0x1de916,_0x38066b['isFullyInitialized'](),_0x38066b['isFiltered']());else{const _0x2220ee=S(_0x40e4ae),_0x37cd2d=_0x38066b['getNode']()['getImmediateChild'](_0x51691c);let _0x2ef1e9;if(v(_0x2220ee))_0x2ef1e9=_0x3f0b10;else{const _0x4ed388=_0x2a1983['getCompleteChild'](_0x51691c);_0x4ed388!=null?ji(_0x2220ee)==='.priority'&&_0x4ed388['getChild'](Ro(_0x2220ee))['isEmpty']()?_0x2ef1e9=_0x4ed388:_0x2ef1e9=_0x4ed388['updateChild'](_0x2220ee,_0x3f0b10):_0x2ef1e9=g['EMPTY_NODE'];}if(_0x37cd2d['equals'](_0x2ef1e9))_0x231239=_0x22623e;else{const _0x59ab69=_0x2763f4['filter']['updateChild'](_0x38066b['getNode'](),_0x51691c,_0x2ef1e9,_0x2220ee,_0x2a1983,_0x4fda84);_0x231239=Rt(_0x22623e,_0x59ab69,_0x38066b['isFullyInitialized'](),_0x2763f4['filter']['filtersNodes']());}}}return _0x231239;}function lr(_0x1202fc,_0x4dab7b){return _0x1202fc['eventCache']['isCompleteForChild'](_0x4dab7b);}function ku(_0x3ce96a,_0x4d2252,_0x236616,_0x21f130,_0x4a3e15,_0x93d40a,_0x3b29a8){let _0x35784d=_0x4d2252;return _0x21f130['foreach']((_0xe3d78e,_0x3b448a)=>{const _0x15bf74=k(_0x236616,_0xe3d78e);lr(_0x4d2252,y(_0x15bf74))&&(_0x35784d=ki(_0x3ce96a,_0x35784d,_0x15bf74,_0x3b448a,_0x4a3e15,_0x93d40a,_0x3b29a8));}),_0x21f130['foreach']((_0x22f0b8,_0x121d95)=>{const _0x133750=k(_0x236616,_0x22f0b8);lr(_0x4d2252,y(_0x133750))||(_0x35784d=ki(_0x3ce96a,_0x35784d,_0x133750,_0x121d95,_0x4a3e15,_0x93d40a,_0x3b29a8));}),_0x35784d;}function hr(_0xbd665e,_0x1c6c11,_0x379659){return _0x379659['foreach']((_0x1e925e,_0x3beaaa)=>{_0x1c6c11=_0x1c6c11['updateChild'](_0x1e925e,_0x3beaaa);}),_0x1c6c11;}function Pi(_0x3dd94e,_0x1d2fe6,_0x4a9963,_0xbd8c8c,_0x4a31d2,_0x539977,_0x37afe3,_0x42798a){if(_0x1d2fe6['serverCache']['getNode']()['isEmpty']()&&!_0x1d2fe6['serverCache']['isFullyInitialized']())return _0x1d2fe6;let _0x4a83c0=_0x1d2fe6,_0x2fbc18;v(_0x4a9963)?_0x2fbc18=_0xbd8c8c:_0x2fbc18=new b(null)['setTree'](_0x4a9963,_0xbd8c8c);const _0x1e50b3=_0x1d2fe6['serverCache']['getNode']();return _0x2fbc18['children']['inorderTraversal']((_0x47db56,_0x469d11)=>{if(_0x1e50b3['hasChild'](_0x47db56)){const _0x30c843=_0x1d2fe6['serverCache']['getNode']()['getImmediateChild'](_0x47db56),_0x38e415=hr(_0x3dd94e,_0x30c843,_0x469d11);_0x4a83c0=Sn(_0x3dd94e,_0x4a83c0,new C(_0x47db56),_0x38e415,_0x4a31d2,_0x539977,_0x37afe3,_0x42798a);}}),_0x2fbc18['children']['inorderTraversal']((_0x3a26ec,_0x470ba0)=>{const _0x163f6f=!_0x1d2fe6['serverCache']['isCompleteForChild'](_0x3a26ec)&&_0x470ba0['value']===null;if(!_0x1e50b3['hasChild'](_0x3a26ec)&&!_0x163f6f){const _0x45a59b=_0x1d2fe6['serverCache']['getNode']()['getImmediateChild'](_0x3a26ec),_0x4a76f6=hr(_0x3dd94e,_0x45a59b,_0x470ba0);_0x4a83c0=Sn(_0x3dd94e,_0x4a83c0,new C(_0x3a26ec),_0x4a76f6,_0x4a31d2,_0x539977,_0x37afe3,_0x42798a);}}),_0x4a83c0;}function Pu(_0x442b4b,_0x516aea,_0x5ef55e,_0x5e4bb3,_0x436ee3,_0x470928,_0x5bacb5){if(Tn(_0x436ee3,_0x5ef55e)!=null)return _0x516aea;const _0x420e89=_0x516aea['serverCache']['isFiltered'](),_0x4d3b41=_0x516aea['serverCache'];if(_0x5e4bb3['value']!=null){if(v(_0x5ef55e)&&_0x4d3b41['isFullyInitialized']()||_0x4d3b41['isCompleteForPath'](_0x5ef55e))return Sn(_0x442b4b,_0x516aea,_0x5ef55e,_0x4d3b41['getNode']()['getChild'](_0x5ef55e),_0x436ee3,_0x470928,_0x420e89,_0x5bacb5);if(v(_0x5ef55e)){let _0x56b3cd=new b(null);return _0x4d3b41['getNode']()['forEachChild'](ve,(_0x36eb6c,_0x26d18d)=>{_0x56b3cd=_0x56b3cd['set'](new C(_0x36eb6c),_0x26d18d);}),Pi(_0x442b4b,_0x516aea,_0x5ef55e,_0x56b3cd,_0x436ee3,_0x470928,_0x420e89,_0x5bacb5);}else return _0x516aea;}else{let _0x44ba06=new b(null);return _0x5e4bb3['foreach']((_0x24fc68,_0xc4127c)=>{const _0x381fcd=k(_0x5ef55e,_0x24fc68);_0x4d3b41['isCompleteForPath'](_0x381fcd)&&(_0x44ba06=_0x44ba06['set'](_0x24fc68,_0x4d3b41['getNode']()['getChild'](_0x381fcd)));}),Pi(_0x442b4b,_0x516aea,_0x5ef55e,_0x44ba06,_0x436ee3,_0x470928,_0x420e89,_0x5bacb5);}}function Nu(_0x5aa17a,_0x382f06,_0x3da7f4,_0x57509e,_0x6be8ef){const _0x11d5b0=_0x382f06['serverCache'],_0x89fcd2=Fo(_0x382f06,_0x11d5b0['getNode'](),_0x11d5b0['isFullyInitialized']()||v(_0x3da7f4),_0x11d5b0['isFiltered']());return Go(_0x5aa17a,_0x89fcd2,_0x3da7f4,_0x57509e,$o,_0x6be8ef);}function Ou(_0x48a4b6,_0x1c8798,_0x1d8e37,_0x9ba9d0,_0x2f74b8,_0x1e9a84){let _0x5ad63e;if(Tn(_0x9ba9d0,_0x1d8e37)!=null)return _0x1c8798;{const _0x36c87c=new rs(_0x9ba9d0,_0x1c8798,_0x2f74b8),_0x2851e2=_0x1c8798['eventCache']['getNode']();let _0x457f84;if(v(_0x1d8e37)||y(_0x1d8e37)==='.priority'){let _0x376008;if(_0x1c8798['serverCache']['isFullyInitialized']())_0x376008=Cn(_0x9ba9d0,Ve(_0x1c8798));else{const _0x5ba536=_0x1c8798['serverCache']['getNode']();f(_0x5ba536 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x376008=is(_0x9ba9d0,_0x5ba536);}_0x376008=_0x376008,_0x457f84=_0x48a4b6['filter']['updateFullNode'](_0x2851e2,_0x376008,_0x1e9a84);}else{const _0x5941c5=y(_0x1d8e37);let _0x16d729=ss(_0x9ba9d0,_0x5941c5,_0x1c8798['serverCache']);_0x16d729==null&&_0x1c8798['serverCache']['isCompleteForChild'](_0x5941c5)&&(_0x16d729=_0x2851e2['getImmediateChild'](_0x5941c5)),_0x16d729!=null?_0x457f84=_0x48a4b6['filter']['updateChild'](_0x2851e2,_0x5941c5,_0x16d729,S(_0x1d8e37),_0x36c87c,_0x1e9a84):_0x1c8798['eventCache']['getNode']()['hasChild'](_0x5941c5)?_0x457f84=_0x48a4b6['filter']['updateChild'](_0x2851e2,_0x5941c5,g['EMPTY_NODE'],S(_0x1d8e37),_0x36c87c,_0x1e9a84):_0x457f84=_0x2851e2,_0x457f84['isEmpty']()&&_0x1c8798['serverCache']['isFullyInitialized']()&&(_0x5ad63e=Cn(_0x9ba9d0,Ve(_0x1c8798)),_0x5ad63e['isLeafNode']()&&(_0x457f84=_0x48a4b6['filter']['updateFullNode'](_0x457f84,_0x5ad63e,_0x1e9a84)));}return _0x5ad63e=_0x1c8798['serverCache']['isFullyInitialized']()||Tn(_0x9ba9d0,w())!=null,Rt(_0x1c8798,_0x457f84,_0x5ad63e,_0x48a4b6['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x308047,_0x31b82f){this['query_']=_0x308047,this['eventRegistrations_']=[];const _0x126315=this['query_']['_queryParams'],_0x22af9e=new Xi(_0x126315['getIndex']()),_0xbce7aa=Kh(_0x126315);this['processor_']=Su(_0xbce7aa);const _0x5ec9d3=_0x31b82f['serverCache'],_0x5b977f=_0x31b82f['eventCache'],_0x4f0458=_0x22af9e['updateFullNode'](g['EMPTY_NODE'],_0x5ec9d3['getNode'](),null),_0x1859b3=_0xbce7aa['updateFullNode'](g['EMPTY_NODE'],_0x5b977f['getNode'](),null),_0x3f366f=new Te(_0x4f0458,_0x5ec9d3['isFullyInitialized'](),_0x22af9e['filtersNodes']()),_0xcdb559=new Te(_0x1859b3,_0x5b977f['isFullyInitialized'](),_0xbce7aa['filtersNodes']());this['viewCache_']=Un(_0xcdb559,_0x3f366f),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x46304b){return _0x46304b['viewCache_']['serverCache']['getNode']();}function Lu(_0x3293ea){return wn(_0x3293ea['viewCache_']);}function xu(_0x1ba1b9,_0x18cb51){const _0x141578=Ve(_0x1ba1b9['viewCache_']);return _0x141578&&(_0x1ba1b9['query']['_queryParams']['loadsAllData']()||!v(_0x18cb51)&&!_0x141578['getImmediateChild'](y(_0x18cb51))['isEmpty']())?_0x141578['getChild'](_0x18cb51):null;}function ur(_0x5a0095){return _0x5a0095['eventRegistrations_']['length']===0x0;}function Fu(_0x51323e,_0x10353e){_0x51323e['eventRegistrations_']['push'](_0x10353e);}function dr(_0x3743dd,_0x229b8c,_0x426fb2){const _0x49567c=[];if(_0x426fb2){f(_0x229b8c==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2fac06=_0x3743dd['query']['_path'];_0x3743dd['eventRegistrations_']['forEach'](_0x374080=>{const _0x11e587=_0x374080['createCancelEvent'](_0x426fb2,_0x2fac06);_0x11e587&&_0x49567c['push'](_0x11e587);});}if(_0x229b8c){let _0x3dbb9d=[];for(let _0x6be66f=0x0;_0x6be66f<_0x3743dd['eventRegistrations_']['length'];++_0x6be66f){const _0x247130=_0x3743dd['eventRegistrations_'][_0x6be66f];if(!_0x247130['matches'](_0x229b8c))_0x3dbb9d['push'](_0x247130);else{if(_0x229b8c['hasAnyCallback']()){_0x3dbb9d=_0x3dbb9d['concat'](_0x3743dd['eventRegistrations_']['slice'](_0x6be66f+0x1));break;}}}_0x3743dd['eventRegistrations_']=_0x3dbb9d;}else _0x3743dd['eventRegistrations_']=[];return _0x49567c;}function fr(_0xbfd0cf,_0x5caee6,_0x26bfd2,_0x32bd36){_0x5caee6['type']===z['MERGE']&&_0x5caee6['source']['queryId']!==null&&(f(Ve(_0xbfd0cf['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0xbfd0cf['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x197dfc=_0xbfd0cf['viewCache_'],_0x483b4a=Ru(_0xbfd0cf['processor_'],_0x197dfc,_0x5caee6,_0x26bfd2,_0x32bd36);return bu(_0xbfd0cf['processor_'],_0x483b4a['viewCache']),f(_0x483b4a['viewCache']['serverCache']['isFullyInitialized']()||!_0x197dfc['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xbfd0cf['viewCache_']=_0x483b4a['viewCache'],qo(_0xbfd0cf,_0x483b4a['changes'],_0x483b4a['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x59abf6,_0x1f13d6){const _0x20ec4c=_0x59abf6['viewCache_']['eventCache'],_0x48fab8=[];return _0x20ec4c['getNode']()['isLeafNode']()||_0x20ec4c['getNode']()['forEachChild'](R,(_0x2d31dd,_0x23490b)=>{_0x48fab8['push'](rt(_0x2d31dd,_0x23490b));}),_0x20ec4c['isFullyInitialized']()&&_0x48fab8['push'](Lo(_0x20ec4c['getNode']())),qo(_0x59abf6,_0x48fab8,_0x20ec4c['getNode'](),_0x1f13d6);}function qo(_0x27d7e9,_0x1dc5b6,_0x1ae1e3,_0x2850fb){const _0x176354=_0x2850fb?[_0x2850fb]:_0x27d7e9['eventRegistrations_'];return ru(_0x27d7e9['eventGenerator_'],_0x1dc5b6,_0x1ae1e3,_0x176354);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x3f9ed8){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x3f9ed8;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x300bdf){return _0x300bdf['views']['size']===0x0;}function os(_0x642e78,_0x560a26,_0x5758c5,_0x114d80){const _0x2d90f5=_0x560a26['source']['queryId'];if(_0x2d90f5!==null){const _0x5e6fca=_0x642e78['views']['get'](_0x2d90f5);return f(_0x5e6fca!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x5e6fca,_0x560a26,_0x5758c5,_0x114d80);}else{let _0x436188=[];for(const _0x50f63c of _0x642e78['views']['values']())_0x436188=_0x436188['concat'](fr(_0x50f63c,_0x560a26,_0x5758c5,_0x114d80));return _0x436188;}}function jo(_0x2a94fe,_0x18b54b,_0x1db382,_0x5982e2,_0x212436){const _0x255387=_0x18b54b['_queryIdentifier'],_0x243592=_0x2a94fe['views']['get'](_0x255387);if(!_0x243592){let _0x88641e=Cn(_0x1db382,_0x212436?_0x5982e2:null),_0x3adbdc=!0x1;_0x88641e?_0x3adbdc=!0x0:_0x5982e2 instanceof g?(_0x88641e=is(_0x1db382,_0x5982e2),_0x3adbdc=!0x1):(_0x88641e=g['EMPTY_NODE'],_0x3adbdc=!0x1);const _0x146138=Un(new Te(_0x88641e,_0x3adbdc,!0x1),new Te(_0x5982e2,_0x212436,!0x1));return new Du(_0x18b54b,_0x146138);}return _0x243592;}function Hu(_0x3afd98,_0x27dbc4,_0x8fa62e,_0x19c372,_0x4fc64e,_0x5aee78){const _0x40d658=jo(_0x3afd98,_0x27dbc4,_0x19c372,_0x4fc64e,_0x5aee78);return _0x3afd98['views']['has'](_0x27dbc4['_queryIdentifier'])||_0x3afd98['views']['set'](_0x27dbc4['_queryIdentifier'],_0x40d658),Fu(_0x40d658,_0x8fa62e),Uu(_0x40d658,_0x8fa62e);}function $u(_0x3d2aa,_0xb8bbcb,_0x50a339,_0x1073f9){const _0x3b7ed7=_0xb8bbcb['_queryIdentifier'],_0x11360e=[];let _0x49d548=[];const _0x3570d5=Se(_0x3d2aa);if(_0x3b7ed7==='default'){for(const [_0x1117b1,_0x3ab18d]of _0x3d2aa['views']['entries']())_0x49d548=_0x49d548['concat'](dr(_0x3ab18d,_0x50a339,_0x1073f9)),ur(_0x3ab18d)&&(_0x3d2aa['views']['delete'](_0x1117b1),_0x3ab18d['query']['_queryParams']['loadsAllData']()||_0x11360e['push'](_0x3ab18d['query']));}else{const _0xd26e67=_0x3d2aa['views']['get'](_0x3b7ed7);_0xd26e67&&(_0x49d548=_0x49d548['concat'](dr(_0xd26e67,_0x50a339,_0x1073f9)),ur(_0xd26e67)&&(_0x3d2aa['views']['delete'](_0x3b7ed7),_0xd26e67['query']['_queryParams']['loadsAllData']()||_0x11360e['push'](_0xd26e67['query'])));}return _0x3570d5&&!Se(_0x3d2aa)&&_0x11360e['push'](new(Bu())(_0xb8bbcb['_repo'],_0xb8bbcb['_path'])),{'removed':_0x11360e,'events':_0x49d548};}function Ko(_0x1548e7){const _0x3d9267=[];for(const _0x1ef1df of _0x1548e7['views']['values']())_0x1ef1df['query']['_queryParams']['loadsAllData']()||_0x3d9267['push'](_0x1ef1df);return _0x3d9267;}function Ie(_0x44f666,_0x3eb8e5){let _0x41cc78=null;for(const _0x1b2baa of _0x44f666['views']['values']())_0x41cc78=_0x41cc78||xu(_0x1b2baa,_0x3eb8e5);return _0x41cc78;}function Yo(_0x1ec2ef,_0xccd24a){if(_0xccd24a['_queryParams']['loadsAllData']())return Bn(_0x1ec2ef);{const _0x2136a8=_0xccd24a['_queryIdentifier'];return _0x1ec2ef['views']['get'](_0x2136a8);}}function Qo(_0x2629f9,_0x40b9e4){return Yo(_0x2629f9,_0x40b9e4)!=null;}function Se(_0x1a1acc){return Bn(_0x1a1acc)!=null;}function Bn(_0x10079e){for(const _0x477942 of _0x10079e['views']['values']())if(_0x477942['query']['_queryParams']['loadsAllData']())return _0x477942;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x101100){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x101100;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x3b2a15){this['listenProvider_']=_0x3b2a15,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x2b29b5,_0x5aa7e6,_0x248603,_0x2e1930,_0x38affd){return lu(_0x2b29b5['pendingWriteTree_'],_0x5aa7e6,_0x248603,_0x2e1930,_0x38affd),_0x38affd?_t(_0x2b29b5,new Be(es(),_0x5aa7e6,_0x248603)):[];}function ju(_0x5c03ca,_0x20fb14,_0x37a239,_0x223c03){hu(_0x5c03ca['pendingWriteTree_'],_0x20fb14,_0x37a239,_0x223c03);const _0x5e6cc3=b['fromObject'](_0x37a239);return _t(_0x5c03ca,new ot(es(),_0x20fb14,_0x5e6cc3));}function _e(_0x480aa6,_0x3b068b,_0x7db818=!0x1){const _0x51a449=uu(_0x480aa6['pendingWriteTree_'],_0x3b068b);if(du(_0x480aa6['pendingWriteTree_'],_0x3b068b)){let _0x24fd90=new b(null);return _0x51a449['snap']!=null?_0x24fd90=_0x24fd90['set'](w(),!0x0):x(_0x51a449['children'],_0x3e815f=>{_0x24fd90=_0x24fd90['set'](new C(_0x3e815f),!0x0);}),_t(_0x480aa6,new In(_0x51a449['path'],_0x24fd90,_0x7db818));}else return[];}function Yt(_0x485308,_0x549f74,_0x49e58e){return _t(_0x485308,new Be(ts(),_0x549f74,_0x49e58e));}function Ku(_0x1256b0,_0x15fafd,_0x2fc530){const _0x3369de=b['fromObject'](_0x2fc530);return _t(_0x1256b0,new ot(ts(),_0x15fafd,_0x3369de));}function Yu(_0x4ac30f,_0x4d1a5a){return _t(_0x4ac30f,new Ut(ts(),_0x4d1a5a));}function Qu(_0x3f83b6,_0x4520f8,_0x32d70a){const _0x2d452d=cs(_0x3f83b6,_0x32d70a);if(_0x2d452d){const _0x462261=ls(_0x2d452d),_0xe9f091=_0x462261['path'],_0xb4c549=_0x462261['queryId'],_0x33bb0c=F(_0xe9f091,_0x4520f8),_0x1aab7e=new Ut(ns(_0xb4c549),_0x33bb0c);return hs(_0x3f83b6,_0xe9f091,_0x1aab7e);}else return[];}function An(_0x186984,_0x401a68,_0x1aa320,_0x20cf90,_0x53cf70=!0x1){const _0x18c2db=_0x401a68['_path'],_0x1ee5aa=_0x186984['syncPointTree_']['get'](_0x18c2db);let _0xecdc8a=[];if(_0x1ee5aa&&(_0x401a68['_queryIdentifier']==='default'||Qo(_0x1ee5aa,_0x401a68))){const _0x4cb02b=$u(_0x1ee5aa,_0x401a68,_0x1aa320,_0x20cf90);Vu(_0x1ee5aa)&&(_0x186984['syncPointTree_']=_0x186984['syncPointTree_']['remove'](_0x18c2db));const _0x58b9c1=_0x4cb02b['removed'];if(_0xecdc8a=_0x4cb02b['events'],!_0x53cf70){const _0x490c56=_0x58b9c1['findIndex'](_0x26f4c8=>_0x26f4c8['_queryParams']['loadsAllData']())!==-0x1,_0x174dc0=_0x186984['syncPointTree_']['findOnPath'](_0x18c2db,(_0x4cba00,_0x2cbfdf)=>Se(_0x2cbfdf));if(_0x490c56&&!_0x174dc0){const _0x419f62=_0x186984['syncPointTree_']['subtree'](_0x18c2db);if(!_0x419f62['isEmpty']()){const _0x3d50b1=Zu(_0x419f62);for(let _0x338cdd=0x0;_0x338cdd<_0x3d50b1['length'];++_0x338cdd){const _0x5441a1=_0x3d50b1[_0x338cdd],_0x5b18cc=_0x5441a1['query'],_0x2a3422=ea(_0x186984,_0x5441a1);_0x186984['listenProvider_']['startListening'](kt(_0x5b18cc),Wt(_0x186984,_0x5b18cc),_0x2a3422['hashFn'],_0x2a3422['onComplete']);}}}!_0x174dc0&&_0x58b9c1['length']>0x0&&!_0x20cf90&&(_0x490c56?_0x186984['listenProvider_']['stopListening'](kt(_0x401a68),null):_0x58b9c1['forEach'](_0x3fcca0=>{const _0x4e653a=_0x186984['queryToTagMap']['get'](Hn(_0x3fcca0));_0x186984['listenProvider_']['stopListening'](kt(_0x3fcca0),_0x4e653a);}));}ed(_0x186984,_0x58b9c1);}return _0xecdc8a;}function Jo(_0x406cc9,_0x390c12,_0x5e2116,_0x49193f){const _0x460076=cs(_0x406cc9,_0x49193f);if(_0x460076!=null){const _0x3d2dba=ls(_0x460076),_0x47c99a=_0x3d2dba['path'],_0x56ec69=_0x3d2dba['queryId'],_0x5388f2=F(_0x47c99a,_0x390c12),_0x424f1b=new Be(ns(_0x56ec69),_0x5388f2,_0x5e2116);return hs(_0x406cc9,_0x47c99a,_0x424f1b);}else return[];}function Ju(_0x467f63,_0x2df3b0,_0x87a567,_0x2a6105){const _0x42fc5e=cs(_0x467f63,_0x2a6105);if(_0x42fc5e){const _0x4b2393=ls(_0x42fc5e),_0x2fdc5e=_0x4b2393['path'],_0x227ab1=_0x4b2393['queryId'],_0x14c028=F(_0x2fdc5e,_0x2df3b0),_0x995584=b['fromObject'](_0x87a567),_0x5b30c6=new ot(ns(_0x227ab1),_0x14c028,_0x995584);return hs(_0x467f63,_0x2fdc5e,_0x5b30c6);}else return[];}function Ni(_0x77fd71,_0x233d48,_0x290413,_0x1d3b3e=!0x1){const _0x5df40c=_0x233d48['_path'];let _0x3cc52d=null,_0x30d127=!0x1;_0x77fd71['syncPointTree_']['foreachOnPath'](_0x5df40c,(_0x543ba1,_0x310ed6)=>{const _0x329b0a=F(_0x543ba1,_0x5df40c);_0x3cc52d=_0x3cc52d||Ie(_0x310ed6,_0x329b0a),_0x30d127=_0x30d127||Se(_0x310ed6);});let _0x1dfcc6=_0x77fd71['syncPointTree_']['get'](_0x5df40c);_0x1dfcc6?(_0x30d127=_0x30d127||Se(_0x1dfcc6),_0x3cc52d=_0x3cc52d||Ie(_0x1dfcc6,w())):(_0x1dfcc6=new zo(),_0x77fd71['syncPointTree_']=_0x77fd71['syncPointTree_']['set'](_0x5df40c,_0x1dfcc6));let _0x309b61;_0x3cc52d!=null?_0x309b61=!0x0:(_0x309b61=!0x1,_0x3cc52d=g['EMPTY_NODE'],_0x77fd71['syncPointTree_']['subtree'](_0x5df40c)['foreachChild']((_0x3d272e,_0x195f31)=>{const _0x2d178e=Ie(_0x195f31,w());_0x2d178e&&(_0x3cc52d=_0x3cc52d['updateImmediateChild'](_0x3d272e,_0x2d178e));}));const _0x3be6a4=Qo(_0x1dfcc6,_0x233d48);if(!_0x3be6a4&&!_0x233d48['_queryParams']['loadsAllData']()){const _0x3eb350=Hn(_0x233d48);f(!_0x77fd71['queryToTagMap']['has'](_0x3eb350),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x513769=td();_0x77fd71['queryToTagMap']['set'](_0x3eb350,_0x513769),_0x77fd71['tagToQueryMap']['set'](_0x513769,_0x3eb350);}const _0x4bc15e=Wn(_0x77fd71['pendingWriteTree_'],_0x5df40c);let _0x411a0a=Hu(_0x1dfcc6,_0x233d48,_0x290413,_0x4bc15e,_0x3cc52d,_0x309b61);if(!_0x3be6a4&&!_0x30d127&&!_0x1d3b3e){const _0x249111=Yo(_0x1dfcc6,_0x233d48);_0x411a0a=_0x411a0a['concat'](nd(_0x77fd71,_0x233d48,_0x249111));}return _0x411a0a;}function Vn(_0x43d308,_0x332239,_0x19ea26){const _0x5e6b66=_0x43d308['pendingWriteTree_'],_0x10930c=_0x43d308['syncPointTree_']['findOnPath'](_0x332239,(_0x33e61d,_0x19980e)=>{const _0x199dc0=F(_0x33e61d,_0x332239),_0x5d18bb=Ie(_0x19980e,_0x199dc0);if(_0x5d18bb)return _0x5d18bb;});return Bo(_0x5e6b66,_0x332239,_0x10930c,_0x19ea26,!0x0);}function Xu(_0x363d71,_0x595f8d){const _0x41e600=_0x595f8d['_path'];let _0xee8af8=null;_0x363d71['syncPointTree_']['foreachOnPath'](_0x41e600,(_0x62b34f,_0x53a4c2)=>{const _0x54f352=F(_0x62b34f,_0x41e600);_0xee8af8=_0xee8af8||Ie(_0x53a4c2,_0x54f352);});let _0xfe320a=_0x363d71['syncPointTree_']['get'](_0x41e600);_0xfe320a?_0xee8af8=_0xee8af8||Ie(_0xfe320a,w()):(_0xfe320a=new zo(),_0x363d71['syncPointTree_']=_0x363d71['syncPointTree_']['set'](_0x41e600,_0xfe320a));const _0x4e1b61=_0xee8af8!=null,_0x5ef94b=_0x4e1b61?new Te(_0xee8af8,!0x0,!0x1):null,_0x4f0adf=Wn(_0x363d71['pendingWriteTree_'],_0x595f8d['_path']),_0x4c4744=jo(_0xfe320a,_0x595f8d,_0x4f0adf,_0x4e1b61?_0x5ef94b['getNode']():g['EMPTY_NODE'],_0x4e1b61);return Lu(_0x4c4744);}function _t(_0x176d23,_0x350ad0){return Xo(_0x350ad0,_0x176d23['syncPointTree_'],null,Wn(_0x176d23['pendingWriteTree_'],w()));}function Xo(_0x36bd7c,_0x12a443,_0x1b6e3d,_0xcad0bd){if(v(_0x36bd7c['path']))return Zo(_0x36bd7c,_0x12a443,_0x1b6e3d,_0xcad0bd);{const _0x230b2f=_0x12a443['get'](w());_0x1b6e3d==null&&_0x230b2f!=null&&(_0x1b6e3d=Ie(_0x230b2f,w()));let _0x5899e6=[];const _0x4fb94a=y(_0x36bd7c['path']),_0x2194cb=_0x36bd7c['operationForChild'](_0x4fb94a),_0x4d6f5c=_0x12a443['children']['get'](_0x4fb94a);if(_0x4d6f5c&&_0x2194cb){const _0xe01805=_0x1b6e3d?_0x1b6e3d['getImmediateChild'](_0x4fb94a):null,_0x511e02=Vo(_0xcad0bd,_0x4fb94a);_0x5899e6=_0x5899e6['concat'](Xo(_0x2194cb,_0x4d6f5c,_0xe01805,_0x511e02));}return _0x230b2f&&(_0x5899e6=_0x5899e6['concat'](os(_0x230b2f,_0x36bd7c,_0xcad0bd,_0x1b6e3d))),_0x5899e6;}}function Zo(_0x34eb6f,_0x228554,_0x226c60,_0x311ad5){const _0x7e3cb9=_0x228554['get'](w());_0x226c60==null&&_0x7e3cb9!=null&&(_0x226c60=Ie(_0x7e3cb9,w()));let _0x59a89e=[];return _0x228554['children']['inorderTraversal']((_0x48e61b,_0x51b01b)=>{const _0x59a5bc=_0x226c60?_0x226c60['getImmediateChild'](_0x48e61b):null,_0x391bf5=Vo(_0x311ad5,_0x48e61b),_0x21b1f5=_0x34eb6f['operationForChild'](_0x48e61b);_0x21b1f5&&(_0x59a89e=_0x59a89e['concat'](Zo(_0x21b1f5,_0x51b01b,_0x59a5bc,_0x391bf5)));}),_0x7e3cb9&&(_0x59a89e=_0x59a89e['concat'](os(_0x7e3cb9,_0x34eb6f,_0x311ad5,_0x226c60))),_0x59a89e;}function ea(_0x2432fa,_0x1329c7){const _0x9ce718=_0x1329c7['query'],_0x19e830=Wt(_0x2432fa,_0x9ce718);return{'hashFn':()=>(Mu(_0x1329c7)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x6fa3f6=>{if(_0x6fa3f6==='ok')return _0x19e830?Qu(_0x2432fa,_0x9ce718['_path'],_0x19e830):Yu(_0x2432fa,_0x9ce718['_path']);{const _0x26c908=Kl(_0x6fa3f6,_0x9ce718);return An(_0x2432fa,_0x9ce718,null,_0x26c908);}}};}function Wt(_0x38c4b6,_0x5ebfa9){const _0x598ca0=Hn(_0x5ebfa9);return _0x38c4b6['queryToTagMap']['get'](_0x598ca0);}function Hn(_0x1e0646){return _0x1e0646['_path']['toString']()+'$'+_0x1e0646['_queryIdentifier'];}function cs(_0x1d1022,_0x77d58a){return _0x1d1022['tagToQueryMap']['get'](_0x77d58a);}function ls(_0x359deb){const _0x43b177=_0x359deb['indexOf']('$');return f(_0x43b177!==-0x1&&_0x43b177<_0x359deb['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x359deb['substr'](_0x43b177+0x1),'path':new C(_0x359deb['substr'](0x0,_0x43b177))};}function hs(_0x5da6fe,_0x2e6f5e,_0x1b0133){const _0x433260=_0x5da6fe['syncPointTree_']['get'](_0x2e6f5e);f(_0x433260,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1db4b4=Wn(_0x5da6fe['pendingWriteTree_'],_0x2e6f5e);return os(_0x433260,_0x1b0133,_0x1db4b4,null);}function Zu(_0x4d3d40){return _0x4d3d40['fold']((_0x4bfd9e,_0x56d724,_0x57c27)=>{if(_0x56d724&&Se(_0x56d724))return[Bn(_0x56d724)];{let _0x544f12=[];return _0x56d724&&(_0x544f12=Ko(_0x56d724)),x(_0x57c27,(_0x241964,_0x3caa4f)=>{_0x544f12=_0x544f12['concat'](_0x3caa4f);}),_0x544f12;}});}function kt(_0x251452){return _0x251452['_queryParams']['loadsAllData']()&&!_0x251452['_queryParams']['isDefault']()?new(qu())(_0x251452['_repo'],_0x251452['_path']):_0x251452;}function ed(_0x4bd585,_0x554d98){for(let _0x3ea861=0x0;_0x3ea861<_0x554d98['length'];++_0x3ea861){const _0x2a7dea=_0x554d98[_0x3ea861];if(!_0x2a7dea['_queryParams']['loadsAllData']()){const _0x3d1aeb=Hn(_0x2a7dea),_0x5f3b29=_0x4bd585['queryToTagMap']['get'](_0x3d1aeb);_0x4bd585['queryToTagMap']['delete'](_0x3d1aeb),_0x4bd585['tagToQueryMap']['delete'](_0x5f3b29);}}}function td(){return zu++;}function nd(_0x1eaeeb,_0x162073,_0xc47172){const _0x32d92e=_0x162073['_path'],_0x4320b7=Wt(_0x1eaeeb,_0x162073),_0x720ae1=ea(_0x1eaeeb,_0xc47172),_0x48eb71=_0x1eaeeb['listenProvider_']['startListening'](kt(_0x162073),_0x4320b7,_0x720ae1['hashFn'],_0x720ae1['onComplete']),_0x966987=_0x1eaeeb['syncPointTree_']['subtree'](_0x32d92e);if(_0x4320b7)f(!Se(_0x966987['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5b2fe9=_0x966987['fold']((_0x5c5a1f,_0x5b98c7,_0x234d9f)=>{if(!v(_0x5c5a1f)&&_0x5b98c7&&Se(_0x5b98c7))return[Bn(_0x5b98c7)['query']];{let _0x37fc16=[];return _0x5b98c7&&(_0x37fc16=_0x37fc16['concat'](Ko(_0x5b98c7)['map'](_0xb332b6=>_0xb332b6['query']))),x(_0x234d9f,(_0x55bb47,_0xbf285b)=>{_0x37fc16=_0x37fc16['concat'](_0xbf285b);}),_0x37fc16;}});for(let _0x3abd5f=0x0;_0x3abd5f<_0x5b2fe9['length'];++_0x3abd5f){const _0x1f6b09=_0x5b2fe9[_0x3abd5f];_0x1eaeeb['listenProvider_']['stopListening'](kt(_0x1f6b09),Wt(_0x1eaeeb,_0x1f6b09));}}return _0x48eb71;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x143044){this['node_']=_0x143044;}['getImmediateChild'](_0x3a8811){const _0x279ed5=this['node_']['getImmediateChild'](_0x3a8811);return new us(_0x279ed5);}['node'](){return this['node_'];}}class ds{constructor(_0x5c797f,_0x5a579d){this['syncTree_']=_0x5c797f,this['path_']=_0x5a579d;}['getImmediateChild'](_0xbbb83){const _0x11d8c8=k(this['path_'],_0xbbb83);return new ds(this['syncTree_'],_0x11d8c8);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x1699fa){return _0x1699fa=_0x1699fa||{},_0x1699fa['timestamp']=_0x1699fa['timestamp']||new Date()['getTime'](),_0x1699fa;},_r=function(_0x48ed73,_0x3d96d0,_0x1a5631){if(!_0x48ed73||typeof _0x48ed73!='object')return _0x48ed73;if(f('.sv'in _0x48ed73,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x48ed73['.sv']=='string')return sd(_0x48ed73['.sv'],_0x3d96d0,_0x1a5631);if(typeof _0x48ed73['.sv']=='object')return rd(_0x48ed73['.sv'],_0x3d96d0);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x48ed73,null,0x2));},sd=function(_0x33e427,_0x29b95f,_0x408812){switch(_0x33e427){case'timestamp':return _0x408812['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x33e427);}},rd=function(_0x181aa2,_0x245716,_0x525a5f){_0x181aa2['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x181aa2,null,0x2));const _0x526dcc=_0x181aa2['increment'];typeof _0x526dcc!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x526dcc);const _0x744844=_0x245716['node']();if(f(_0x744844!==null&&typeof _0x744844<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x744844['isLeafNode']())return _0x526dcc;const _0x1f024c=_0x744844['getValue']();return typeof _0x1f024c!='number'?_0x526dcc:_0x1f024c+_0x526dcc;},ta=function(_0x4dc4d7,_0x1e2192,_0x158eac,_0x441cdd){return ps(_0x1e2192,new ds(_0x158eac,_0x4dc4d7),_0x441cdd);},fs=function(_0x10d255,_0x130047,_0x30d8bb){return ps(_0x10d255,new us(_0x130047),_0x30d8bb);};function ps(_0x3ecd47,_0x32fa21,_0x40f12f){const _0x4f62af=_0x3ecd47['getPriority']()['val'](),_0x5c6e35=_r(_0x4f62af,_0x32fa21['getImmediateChild']('.priority'),_0x40f12f);let _0x599cad;if(_0x3ecd47['isLeafNode']()){const _0x25001b=_0x3ecd47,_0x399f13=_r(_0x25001b['getValue'](),_0x32fa21,_0x40f12f);return _0x399f13!==_0x25001b['getValue']()||_0x5c6e35!==_0x25001b['getPriority']()['val']()?new D(_0x399f13,A(_0x5c6e35)):_0x3ecd47;}else{const _0x4dadae=_0x3ecd47;return _0x599cad=_0x4dadae,_0x5c6e35!==_0x4dadae['getPriority']()['val']()&&(_0x599cad=_0x599cad['updatePriority'](new D(_0x5c6e35))),_0x4dadae['forEachChild'](R,(_0x52b6a3,_0xa5fc0)=>{const _0x1aa5f2=ps(_0xa5fc0,_0x32fa21['getImmediateChild'](_0x52b6a3),_0x40f12f);_0x1aa5f2!==_0xa5fc0&&(_0x599cad=_0x599cad['updateImmediateChild'](_0x52b6a3,_0x1aa5f2));}),_0x599cad;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x598b5b='',_0x3e5e54=null,_0x4292c4={'children':{},'childCount':0x0}){this['name']=_0x598b5b,this['parent']=_0x3e5e54,this['node']=_0x4292c4;}}function $n(_0x5112ad,_0x45cc49){let _0x1ca288=_0x45cc49 instanceof C?_0x45cc49:new C(_0x45cc49),_0x3c66c8=_0x5112ad,_0x5c48b2=y(_0x1ca288);for(;_0x5c48b2!==null;){const _0xe7017c=Le(_0x3c66c8['node']['children'],_0x5c48b2)||{'children':{},'childCount':0x0};_0x3c66c8=new _s(_0x5c48b2,_0x3c66c8,_0xe7017c),_0x1ca288=S(_0x1ca288),_0x5c48b2=y(_0x1ca288);}return _0x3c66c8;}function je(_0x54fd30){return _0x54fd30['node']['value'];}function gs(_0x104f29,_0xb2044b){_0x104f29['node']['value']=_0xb2044b,Oi(_0x104f29);}function na(_0x49c504){return _0x49c504['node']['childCount']>0x0;}function od(_0xe200d7){return je(_0xe200d7)===void 0x0&&!na(_0xe200d7);}function Gn(_0x33b4c5,_0x3d53fa){x(_0x33b4c5['node']['children'],(_0x62de51,_0x203fdd)=>{_0x3d53fa(new _s(_0x62de51,_0x33b4c5,_0x203fdd));});}function ia(_0x5bdec1,_0xef68b4,_0x462958,_0x104ebc){_0x462958&&_0xef68b4(_0x5bdec1),Gn(_0x5bdec1,_0x5999f3=>{ia(_0x5999f3,_0xef68b4,!0x0);});}function ad(_0x5d3ca1,_0x989495,_0x1cf0c6){let _0x48fda5=_0x5d3ca1['parent'];for(;_0x48fda5!==null;){if(_0x989495(_0x48fda5))return!0x0;_0x48fda5=_0x48fda5['parent'];}return!0x1;}function Qt(_0xe5a65e){return new C(_0xe5a65e['parent']===null?_0xe5a65e['name']:Qt(_0xe5a65e['parent'])+'/'+_0xe5a65e['name']);}function Oi(_0x1c55e2){_0x1c55e2['parent']!==null&&cd(_0x1c55e2['parent'],_0x1c55e2['name'],_0x1c55e2);}function cd(_0x59666e,_0x41df36,_0x4f5153){const _0x3bcfb3=od(_0x4f5153),_0x4808dc=Q(_0x59666e['node']['children'],_0x41df36);_0x3bcfb3&&_0x4808dc?(delete _0x59666e['node']['children'][_0x41df36],_0x59666e['node']['childCount']--,Oi(_0x59666e)):!_0x3bcfb3&&!_0x4808dc&&(_0x59666e['node']['children'][_0x41df36]=_0x4f5153['node'],_0x59666e['node']['childCount']++,Oi(_0x59666e));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0xc5443){return typeof _0xc5443=='string'&&_0xc5443['length']!==0x0&&!ld['test'](_0xc5443);},sa=function(_0x54d917){return typeof _0x54d917=='string'&&_0x54d917['length']!==0x0&&!hd['test'](_0x54d917);},ud=function(_0x3998c6){return _0x3998c6&&(_0x3998c6=_0x3998c6['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x3998c6);},Bt=function(_0x248a4e){return _0x248a4e===null||typeof _0x248a4e=='string'||typeof _0x248a4e=='number'&&!xn(_0x248a4e)||_0x248a4e&&typeof _0x248a4e=='object'&&Q(_0x248a4e,'.sv');},He=function(_0x5d9c13,_0xcb363c,_0x1373ce,_0x1e1f17){_0x1e1f17&&_0xcb363c===void 0x0||Jt(it(_0x5d9c13,'value'),_0xcb363c,_0x1373ce);},Jt=function(_0x45c968,_0xdbcaa4,_0x1aee21){const _0x223b9d=_0x1aee21 instanceof C?new Ah(_0x1aee21,_0x45c968):_0x1aee21;if(_0xdbcaa4===void 0x0)throw new Error(_0x45c968+'contains\x20undefined\x20'+Oe(_0x223b9d));if(typeof _0xdbcaa4=='function')throw new Error(_0x45c968+'contains\x20a\x20function\x20'+Oe(_0x223b9d)+'\x20with\x20contents\x20=\x20'+_0xdbcaa4['toString']());if(xn(_0xdbcaa4))throw new Error(_0x45c968+'contains\x20'+_0xdbcaa4['toString']()+'\x20'+Oe(_0x223b9d));if(typeof _0xdbcaa4=='string'&&_0xdbcaa4['length']>ui/0x3&&Ln(_0xdbcaa4)>ui)throw new Error(_0x45c968+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x223b9d)+'\x20(\x27'+_0xdbcaa4['substring'](0x0,0x32)+'...\x27)');if(_0xdbcaa4&&typeof _0xdbcaa4=='object'){let _0x6342db=!0x1,_0x28877d=!0x1;if(x(_0xdbcaa4,(_0x197e9b,_0x3c7342)=>{if(_0x197e9b==='.value')_0x6342db=!0x0;else{if(_0x197e9b!=='.priority'&&_0x197e9b!=='.sv'&&(_0x28877d=!0x0,!ms(_0x197e9b)))throw new Error(_0x45c968+'\x20contains\x20an\x20invalid\x20key\x20('+_0x197e9b+')\x20'+Oe(_0x223b9d)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x223b9d,_0x197e9b),Jt(_0x45c968,_0x3c7342,_0x223b9d),Ph(_0x223b9d);}),_0x6342db&&_0x28877d)throw new Error(_0x45c968+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x223b9d)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x239d44,_0x1fd350){let _0x3f337b,_0x35d297;for(_0x3f337b=0x0;_0x3f337b<_0x1fd350['length'];_0x3f337b++){_0x35d297=_0x1fd350[_0x3f337b];const _0xc4d128=Mt(_0x35d297);for(let _0x32da73=0x0;_0x32da73<_0xc4d128['length'];_0x32da73++)if(!(_0xc4d128[_0x32da73]==='.priority'&&_0x32da73===_0xc4d128['length']-0x1)){if(!ms(_0xc4d128[_0x32da73]))throw new Error(_0x239d44+'contains\x20an\x20invalid\x20key\x20('+_0xc4d128[_0x32da73]+')\x20in\x20path\x20'+_0x35d297['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x1fd350['sort'](Rh);let _0x1b60b2=null;for(_0x3f337b=0x0;_0x3f337b<_0x1fd350['length'];_0x3f337b++){if(_0x35d297=_0x1fd350[_0x3f337b],_0x1b60b2!==null&&G(_0x1b60b2,_0x35d297))throw new Error(_0x239d44+'contains\x20a\x20path\x20'+_0x1b60b2['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x35d297['toString']());_0x1b60b2=_0x35d297;}},ra=function(_0x4d6561,_0x529e82,_0x216b4c,_0x3a9aab){const _0x4d7ba0=it(_0x4d6561,'values');if(!(_0x529e82&&typeof _0x529e82=='object')||Array['isArray'](_0x529e82))throw new Error(_0x4d7ba0+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x932360=[];x(_0x529e82,(_0x460d06,_0x354c70)=>{const _0x11c151=new C(_0x460d06);if(Jt(_0x4d7ba0,_0x354c70,k(_0x216b4c,_0x11c151)),ji(_0x11c151)==='.priority'&&!Bt(_0x354c70))throw new Error(_0x4d7ba0+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x11c151['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x932360['push'](_0x11c151);}),dd(_0x4d7ba0,_0x932360);},fd=function(_0x4f2a75,_0x4636a3,_0x5f575a){if(xn(_0x4636a3))throw new Error(it(_0x4f2a75,'priority')+'is\x20'+_0x4636a3['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x4636a3))throw new Error(it(_0x4f2a75,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0xca0007,_0x7632c3,_0x4e2ba7,_0xb18462){if(!sa(_0x4e2ba7))throw new Error(it(_0xca0007,_0x7632c3)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4e2ba7+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x38fc63,_0x49a0d8,_0x36a56b,_0xdd5b20){_0x36a56b&&(_0x36a56b=_0x36a56b['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x38fc63,_0x49a0d8,_0x36a56b);},Me=function(_0x111857,_0x13c579){if(y(_0x13c579)==='.info')throw new Error(_0x111857+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x3be3e3,_0x326a08){const _0x36e096=_0x326a08['path']['toString']();if(typeof _0x326a08['repoInfo']['host']!='string'||_0x326a08['repoInfo']['host']['length']===0x0||!ms(_0x326a08['repoInfo']['namespace'])&&_0x326a08['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x36e096['length']!==0x0&&!ud(_0x36e096))throw new Error(it(_0x3be3e3,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x23a00c,_0x47235f){let _0x546171=null;for(let _0x431f36=0x0;_0x431f36<_0x47235f['length'];_0x431f36++){const _0x43a59e=_0x47235f[_0x431f36],_0x13d6f5=_0x43a59e['getPath']();_0x546171!==null&&!Ki(_0x13d6f5,_0x546171['path'])&&(_0x23a00c['eventLists_']['push'](_0x546171),_0x546171=null),_0x546171===null&&(_0x546171={'events':[],'path':_0x13d6f5}),_0x546171['events']['push'](_0x43a59e);}_0x546171&&_0x23a00c['eventLists_']['push'](_0x546171);}function oa(_0x1c6685,_0xe81be1,_0x1997d8){qn(_0x1c6685,_0x1997d8),aa(_0x1c6685,_0x3293be=>Ki(_0x3293be,_0xe81be1));}function V(_0xc53d3b,_0x3ce3c6,_0x231b79){qn(_0xc53d3b,_0x231b79),aa(_0xc53d3b,_0x279ddb=>G(_0x279ddb,_0x3ce3c6)||G(_0x3ce3c6,_0x279ddb));}function aa(_0x5c53b1,_0x4048d5){_0x5c53b1['recursionDepth_']++;let _0x3102f4=!0x0;for(let _0x3215dc=0x0;_0x3215dc<_0x5c53b1['eventLists_']['length'];_0x3215dc++){const _0x15219b=_0x5c53b1['eventLists_'][_0x3215dc];if(_0x15219b){const _0x3bbf9c=_0x15219b['path'];_0x4048d5(_0x3bbf9c)?(md(_0x5c53b1['eventLists_'][_0x3215dc]),_0x5c53b1['eventLists_'][_0x3215dc]=null):_0x3102f4=!0x1;}}_0x3102f4&&(_0x5c53b1['eventLists_']=[]),_0x5c53b1['recursionDepth_']--;}function md(_0x1103b0){for(let _0x4781d4=0x0;_0x4781d4<_0x1103b0['events']['length'];_0x4781d4++){const _0x1db22e=_0x1103b0['events'][_0x4781d4];if(_0x1db22e!==null){_0x1103b0['events'][_0x4781d4]=null;const _0x1c47ce=_0x1db22e['getEventRunner']();St&&L('event:\x20'+_0x1db22e['toString']()),ft(_0x1c47ce);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x409d0e,_0x432ebc,_0x4b9856,_0x6b74d8){this['repoInfo_']=_0x409d0e,this['forceRestClient_']=_0x432ebc,this['authTokenProvider_']=_0x4b9856,this['appCheckProvider_']=_0x6b74d8,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x491980,_0x1293e5,_0x1ba8e4){if(_0x491980['stats_']=qi(_0x491980['repoInfo_']),_0x491980['forceRestClient_']||Xl())_0x491980['server_']=new vn(_0x491980['repoInfo_'],(_0x418972,_0x52eb04,_0x2eb91a,_0x190a35)=>{gr(_0x491980,_0x418972,_0x52eb04,_0x2eb91a,_0x190a35);},_0x491980['authTokenProvider_'],_0x491980['appCheckProvider_']),setTimeout(()=>mr(_0x491980,!0x0),0x0);else{if(typeof _0x1ba8e4<'u'&&_0x1ba8e4!==null){if(typeof _0x1ba8e4!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1ba8e4);}catch(_0x207e8d){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x207e8d);}}_0x491980['persistentConnection_']=new se(_0x491980['repoInfo_'],_0x1293e5,(_0x5ae8f6,_0x2e82c1,_0x30bd18,_0x3f9e67)=>{gr(_0x491980,_0x5ae8f6,_0x2e82c1,_0x30bd18,_0x3f9e67);},_0x37bd90=>{mr(_0x491980,_0x37bd90);},_0x83a326=>{Id(_0x491980,_0x83a326);},_0x491980['authTokenProvider_'],_0x491980['appCheckProvider_'],_0x1ba8e4),_0x491980['server_']=_0x491980['persistentConnection_'];}_0x491980['authTokenProvider_']['addTokenChangeListener'](_0x382d13=>{_0x491980['server_']['refreshAuthToken'](_0x382d13);}),_0x491980['appCheckProvider_']['addTokenChangeListener'](_0x77ce14=>{_0x491980['server_']['refreshAppCheckToken'](_0x77ce14['token']);}),_0x491980['statsReporter_']=ih(_0x491980['repoInfo_'],()=>new iu(_0x491980['stats_'],_0x491980['server_'])),_0x491980['infoData_']=new Xh(),_0x491980['infoSyncTree_']=new pr({'startListening':(_0x2a45dc,_0xb8b43b,_0x14b1c2,_0x229c73)=>{let _0x20d1cb=[];const _0x4d22ac=_0x491980['infoData_']['getNode'](_0x2a45dc['_path']);return _0x4d22ac['isEmpty']()||(_0x20d1cb=Yt(_0x491980['infoSyncTree_'],_0x2a45dc['_path'],_0x4d22ac),setTimeout(()=>{_0x229c73('ok');},0x0)),_0x20d1cb;},'stopListening':()=>{}}),vs(_0x491980,'connected',!0x1),_0x491980['serverSyncTree_']=new pr({'startListening':(_0x5009a2,_0x5272f0,_0x59c472,_0x1a767c)=>(_0x491980['server_']['listen'](_0x5009a2,_0x59c472,_0x5272f0,(_0xdf9357,_0x1a6782)=>{const _0x35dd27=_0x1a767c(_0xdf9357,_0x1a6782);V(_0x491980['eventQueue_'],_0x5009a2['_path'],_0x35dd27);}),[]),'stopListening':(_0x36451c,_0x52b57f)=>{_0x491980['server_']['unlisten'](_0x36451c,_0x52b57f);}});}function la(_0x4dc466){const _0x27b977=_0x4dc466['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x27b977;}function Xt(_0x1a755e){return id({'timestamp':la(_0x1a755e)});}function gr(_0x53870b,_0x2decd4,_0x48407f,_0x4d3f8f,_0x4ca4c5){_0x53870b['dataUpdateCount']++;const _0x2ed8c4=new C(_0x2decd4);_0x48407f=_0x53870b['interceptServerDataCallback_']?_0x53870b['interceptServerDataCallback_'](_0x2decd4,_0x48407f):_0x48407f;let _0x2279be=[];if(_0x4ca4c5){if(_0x4d3f8f){const _0x6bde4e=_n(_0x48407f,_0x34b34f=>A(_0x34b34f));_0x2279be=Ju(_0x53870b['serverSyncTree_'],_0x2ed8c4,_0x6bde4e,_0x4ca4c5);}else{const _0x21e73e=A(_0x48407f);_0x2279be=Jo(_0x53870b['serverSyncTree_'],_0x2ed8c4,_0x21e73e,_0x4ca4c5);}}else{if(_0x4d3f8f){const _0x3bcdb2=_n(_0x48407f,_0x256964=>A(_0x256964));_0x2279be=Ku(_0x53870b['serverSyncTree_'],_0x2ed8c4,_0x3bcdb2);}else{const _0x298150=A(_0x48407f);_0x2279be=Yt(_0x53870b['serverSyncTree_'],_0x2ed8c4,_0x298150);}}let _0x2cc05e=_0x2ed8c4;_0x2279be['length']>0x0&&(_0x2cc05e=ct(_0x53870b,_0x2ed8c4)),V(_0x53870b['eventQueue_'],_0x2cc05e,_0x2279be);}function mr(_0x3a2464,_0x3784bd){vs(_0x3a2464,'connected',_0x3784bd),_0x3784bd===!0x1&&Sd(_0x3a2464);}function Id(_0x471c1f,_0x59c743){x(_0x59c743,(_0x589c0,_0x461f1f)=>{vs(_0x471c1f,_0x589c0,_0x461f1f);});}function vs(_0x337e36,_0x3e7da0,_0x2c93fd){const _0x5b3c0f=new C('/.info/'+_0x3e7da0),_0x26e3cd=A(_0x2c93fd);_0x337e36['infoData_']['updateSnapshot'](_0x5b3c0f,_0x26e3cd);const _0x160e8a=Yt(_0x337e36['infoSyncTree_'],_0x5b3c0f,_0x26e3cd);V(_0x337e36['eventQueue_'],_0x5b3c0f,_0x160e8a);}function zn(_0x19e028){return _0x19e028['nextWriteId_']++;}function wd(_0xd1cf57,_0x12402a,_0x5b60d6){const _0xcd4d3b=Xu(_0xd1cf57['serverSyncTree_'],_0x12402a);return _0xcd4d3b!=null?Promise['resolve'](_0xcd4d3b):_0xd1cf57['server_']['get'](_0x12402a)['then'](_0x4160f7=>{const _0x288018=A(_0x4160f7)['withIndex'](_0x12402a['_queryParams']['getIndex']());Ni(_0xd1cf57['serverSyncTree_'],_0x12402a,_0x5b60d6,!0x0);let _0x3d6035;if(_0x12402a['_queryParams']['loadsAllData']())_0x3d6035=Yt(_0xd1cf57['serverSyncTree_'],_0x12402a['_path'],_0x288018);else{const _0x433a4a=Wt(_0xd1cf57['serverSyncTree_'],_0x12402a);_0x3d6035=Jo(_0xd1cf57['serverSyncTree_'],_0x12402a['_path'],_0x288018,_0x433a4a);}return V(_0xd1cf57['eventQueue_'],_0x12402a['_path'],_0x3d6035),An(_0xd1cf57['serverSyncTree_'],_0x12402a,_0x5b60d6,null,!0x0),_0x288018;},_0x26e161=>(gt(_0xd1cf57,'get\x20for\x20query\x20'+O(_0x12402a)+'\x20failed:\x20'+_0x26e161),Promise['reject'](new Error(_0x26e161))));}function Cd(_0xe2821b,_0x4ba549,_0x5442da,_0x11c19f,_0x22a9dc){gt(_0xe2821b,'set',{'path':_0x4ba549['toString'](),'value':_0x5442da,'priority':_0x11c19f});const _0x928d6=Xt(_0xe2821b),_0x4b85dc=A(_0x5442da,_0x11c19f),_0x5271ad=Vn(_0xe2821b['serverSyncTree_'],_0x4ba549),_0x112274=fs(_0x4b85dc,_0x5271ad,_0x928d6),_0x5f3855=zn(_0xe2821b),_0x1f6266=as(_0xe2821b['serverSyncTree_'],_0x4ba549,_0x112274,_0x5f3855,!0x0);qn(_0xe2821b['eventQueue_'],_0x1f6266),_0xe2821b['server_']['put'](_0x4ba549['toString'](),_0x4b85dc['val'](!0x0),(_0xb9c96b,_0x40b50d)=>{const _0x52ef76=_0xb9c96b==='ok';_0x52ef76||U('set\x20at\x20'+_0x4ba549+'\x20failed:\x20'+_0xb9c96b);const _0x1a2abb=_e(_0xe2821b['serverSyncTree_'],_0x5f3855,!_0x52ef76);V(_0xe2821b['eventQueue_'],_0x4ba549,_0x1a2abb),be(_0xe2821b,_0x22a9dc,_0xb9c96b,_0x40b50d);});const _0x4fbed0=Is(_0xe2821b,_0x4ba549);ct(_0xe2821b,_0x4fbed0),V(_0xe2821b['eventQueue_'],_0x4fbed0,[]);}function Td(_0x45152a,_0x1aeb00,_0x3e42dc,_0x16e3b6){gt(_0x45152a,'update',{'path':_0x1aeb00['toString'](),'value':_0x3e42dc});let _0x2eab11=!0x0;const _0x1913b2=Xt(_0x45152a),_0x3f99a9={};if(x(_0x3e42dc,(_0x5519de,_0x528862)=>{_0x2eab11=!0x1,_0x3f99a9[_0x5519de]=ta(k(_0x1aeb00,_0x5519de),A(_0x528862),_0x45152a['serverSyncTree_'],_0x1913b2);}),_0x2eab11)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x45152a,_0x16e3b6,'ok',void 0x0);else{const _0x59f648=zn(_0x45152a),_0x17a636=ju(_0x45152a['serverSyncTree_'],_0x1aeb00,_0x3f99a9,_0x59f648);qn(_0x45152a['eventQueue_'],_0x17a636),_0x45152a['server_']['merge'](_0x1aeb00['toString'](),_0x3e42dc,(_0x2dd8d1,_0x37b160)=>{const _0x58160f=_0x2dd8d1==='ok';_0x58160f||U('update\x20at\x20'+_0x1aeb00+'\x20failed:\x20'+_0x2dd8d1);const _0x4547ca=_e(_0x45152a['serverSyncTree_'],_0x59f648,!_0x58160f),_0x414b4b=_0x4547ca['length']>0x0?ct(_0x45152a,_0x1aeb00):_0x1aeb00;V(_0x45152a['eventQueue_'],_0x414b4b,_0x4547ca),be(_0x45152a,_0x16e3b6,_0x2dd8d1,_0x37b160);}),x(_0x3e42dc,_0x2d21a6=>{const _0x3ed3d7=Is(_0x45152a,k(_0x1aeb00,_0x2d21a6));ct(_0x45152a,_0x3ed3d7);}),V(_0x45152a['eventQueue_'],_0x1aeb00,[]);}}function Sd(_0x44b588){gt(_0x44b588,'onDisconnectEvents');const _0x2677b4=Xt(_0x44b588),_0x3a62d0=En();Si(_0x44b588['onDisconnect_'],w(),(_0x4ccd56,_0x3f9f1f)=>{const _0xb16ec1=ta(_0x4ccd56,_0x3f9f1f,_0x44b588['serverSyncTree_'],_0x2677b4);pt(_0x3a62d0,_0x4ccd56,_0xb16ec1);});let _0x50b120=[];Si(_0x3a62d0,w(),(_0x3904cf,_0x116b84)=>{_0x50b120=_0x50b120['concat'](Yt(_0x44b588['serverSyncTree_'],_0x3904cf,_0x116b84));const _0x291041=Is(_0x44b588,_0x3904cf);ct(_0x44b588,_0x291041);}),_0x44b588['onDisconnect_']=En(),V(_0x44b588['eventQueue_'],w(),_0x50b120);}function bd(_0xd05f86,_0x3c0d59,_0x47e638){_0xd05f86['server_']['onDisconnectCancel'](_0x3c0d59['toString'](),(_0x479c69,_0x3ca8c8)=>{_0x479c69==='ok'&&Ti(_0xd05f86['onDisconnect_'],_0x3c0d59),be(_0xd05f86,_0x47e638,_0x479c69,_0x3ca8c8);});}function yr(_0x3649ae,_0x46bb57,_0x4be898,_0x47ce72){const _0x7d8fe3=A(_0x4be898);_0x3649ae['server_']['onDisconnectPut'](_0x46bb57['toString'](),_0x7d8fe3['val'](!0x0),(_0xa7d9,_0x2580b5)=>{_0xa7d9==='ok'&&pt(_0x3649ae['onDisconnect_'],_0x46bb57,_0x7d8fe3),be(_0x3649ae,_0x47ce72,_0xa7d9,_0x2580b5);});}function Rd(_0x38a5d6,_0x1e1b9b,_0x4e0f3b,_0x34d2de,_0x367fb5){const _0x293f6f=A(_0x4e0f3b,_0x34d2de);_0x38a5d6['server_']['onDisconnectPut'](_0x1e1b9b['toString'](),_0x293f6f['val'](!0x0),(_0x458374,_0x78b4c4)=>{_0x458374==='ok'&&pt(_0x38a5d6['onDisconnect_'],_0x1e1b9b,_0x293f6f),be(_0x38a5d6,_0x367fb5,_0x458374,_0x78b4c4);});}function Ad(_0x26436b,_0x15f644,_0x10bfd8,_0x1487a5){if(pn(_0x10bfd8)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x26436b,_0x1487a5,'ok',void 0x0);return;}_0x26436b['server_']['onDisconnectMerge'](_0x15f644['toString'](),_0x10bfd8,(_0x49e40e,_0x102188)=>{_0x49e40e==='ok'&&x(_0x10bfd8,(_0xfb053c,_0x479822)=>{const _0x3e953d=A(_0x479822);pt(_0x26436b['onDisconnect_'],k(_0x15f644,_0xfb053c),_0x3e953d);}),be(_0x26436b,_0x1487a5,_0x49e40e,_0x102188);});}function kd(_0x25c20c,_0x1e4bd6,_0x24dfcd){let _0x1504b9;y(_0x1e4bd6['_path'])==='.info'?_0x1504b9=Ni(_0x25c20c['infoSyncTree_'],_0x1e4bd6,_0x24dfcd):_0x1504b9=Ni(_0x25c20c['serverSyncTree_'],_0x1e4bd6,_0x24dfcd),oa(_0x25c20c['eventQueue_'],_0x1e4bd6['_path'],_0x1504b9);}function Pd(_0x9fbc9f,_0x503e58,_0x8f76a6){let _0x45b30e;y(_0x503e58['_path'])==='.info'?_0x45b30e=An(_0x9fbc9f['infoSyncTree_'],_0x503e58,_0x8f76a6):_0x45b30e=An(_0x9fbc9f['serverSyncTree_'],_0x503e58,_0x8f76a6),oa(_0x9fbc9f['eventQueue_'],_0x503e58['_path'],_0x45b30e);}function ha(_0x277ea8){_0x277ea8['persistentConnection_']&&_0x277ea8['persistentConnection_']['interrupt'](ca);}function Nd(_0xfe6af){_0xfe6af['persistentConnection_']&&_0xfe6af['persistentConnection_']['resume'](ca);}function gt(_0x528c2b,..._0x56f4e1){let _0x12176b='';_0x528c2b['persistentConnection_']&&(_0x12176b=_0x528c2b['persistentConnection_']['id']+':'),L(_0x12176b,..._0x56f4e1);}function be(_0x3b32be,_0x42c80d,_0x4ca497,_0x24c5c3){_0x42c80d&&ft(()=>{if(_0x4ca497==='ok')_0x42c80d(null);else{const _0x1ced8f=(_0x4ca497||'error')['toUpperCase']();let _0x184ccc=_0x1ced8f;_0x24c5c3&&(_0x184ccc+=':\x20'+_0x24c5c3);const _0x37650b=new Error(_0x184ccc);_0x37650b['code']=_0x1ced8f,_0x42c80d(_0x37650b);}});}function Od(_0x2b15ea,_0x18ae5f,_0x5b5402,_0x198a4f,_0x395f65,_0x128aca){gt(_0x2b15ea,'transaction\x20on\x20'+_0x18ae5f);const _0x4eb82d={'path':_0x18ae5f,'update':_0x5b5402,'onComplete':_0x198a4f,'status':null,'order':so(),'applyLocally':_0x128aca,'retryCount':0x0,'unwatcher':_0x395f65,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x346723=Es(_0x2b15ea,_0x18ae5f,void 0x0);_0x4eb82d['currentInputSnapshot']=_0x346723;const _0x16bb75=_0x4eb82d['update'](_0x346723['val']());if(_0x16bb75===void 0x0)_0x4eb82d['unwatcher'](),_0x4eb82d['currentOutputSnapshotRaw']=null,_0x4eb82d['currentOutputSnapshotResolved']=null,_0x4eb82d['onComplete']&&_0x4eb82d['onComplete'](null,!0x1,_0x4eb82d['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x16bb75,_0x4eb82d['path']),_0x4eb82d['status']=0x0;const _0x3617b4=$n(_0x2b15ea['transactionQueueTree_'],_0x18ae5f),_0x4a88da=je(_0x3617b4)||[];_0x4a88da['push'](_0x4eb82d),gs(_0x3617b4,_0x4a88da);let _0x4b061c;typeof _0x16bb75=='object'&&_0x16bb75!==null&&Q(_0x16bb75,'.priority')?(_0x4b061c=Le(_0x16bb75,'.priority'),f(Bt(_0x4b061c),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x4b061c=(Vn(_0x2b15ea['serverSyncTree_'],_0x18ae5f)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3ebc8f=Xt(_0x2b15ea),_0x1ccd6e=A(_0x16bb75,_0x4b061c),_0x22f916=fs(_0x1ccd6e,_0x346723,_0x3ebc8f);_0x4eb82d['currentOutputSnapshotRaw']=_0x1ccd6e,_0x4eb82d['currentOutputSnapshotResolved']=_0x22f916,_0x4eb82d['currentWriteId']=zn(_0x2b15ea);const _0x26a14c=as(_0x2b15ea['serverSyncTree_'],_0x18ae5f,_0x22f916,_0x4eb82d['currentWriteId'],_0x4eb82d['applyLocally']);V(_0x2b15ea['eventQueue_'],_0x18ae5f,_0x26a14c),jn(_0x2b15ea,_0x2b15ea['transactionQueueTree_']);}}function Es(_0x46680a,_0x1e9e6a,_0x2fcc37){return Vn(_0x46680a['serverSyncTree_'],_0x1e9e6a,_0x2fcc37)||g['EMPTY_NODE'];}function jn(_0xaec1e0,_0x1fb96c=_0xaec1e0['transactionQueueTree_']){if(_0x1fb96c||Kn(_0xaec1e0,_0x1fb96c),je(_0x1fb96c)){const _0x29b63b=da(_0xaec1e0,_0x1fb96c);f(_0x29b63b['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x29b63b['every'](_0x33c0a7=>_0x33c0a7['status']===0x0)&&Dd(_0xaec1e0,Qt(_0x1fb96c),_0x29b63b);}else na(_0x1fb96c)&&Gn(_0x1fb96c,_0x1c1bba=>{jn(_0xaec1e0,_0x1c1bba);});}function Dd(_0x5438f1,_0x215f8e,_0x95766d){const _0x2e1322=_0x95766d['map'](_0x229bbe=>_0x229bbe['currentWriteId']),_0x2bca60=Es(_0x5438f1,_0x215f8e,_0x2e1322);let _0x19b16b=_0x2bca60;const _0x4fae98=_0x2bca60['hash']();for(let _0x4b8adb=0x0;_0x4b8adb<_0x95766d['length'];_0x4b8adb++){const _0x4a540b=_0x95766d[_0x4b8adb];f(_0x4a540b['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4a540b['status']=0x1,_0x4a540b['retryCount']++;const _0x4eb243=F(_0x215f8e,_0x4a540b['path']);_0x19b16b=_0x19b16b['updateChild'](_0x4eb243,_0x4a540b['currentOutputSnapshotRaw']);}const _0x96568b=_0x19b16b['val'](!0x0),_0x2cbf7e=_0x215f8e;_0x5438f1['server_']['put'](_0x2cbf7e['toString'](),_0x96568b,_0x1ddc0d=>{gt(_0x5438f1,'transaction\x20put\x20response',{'path':_0x2cbf7e['toString'](),'status':_0x1ddc0d});let _0x237c43=[];if(_0x1ddc0d==='ok'){const _0x473d80=[];for(let _0x587ecc=0x0;_0x587ecc<_0x95766d['length'];_0x587ecc++)_0x95766d[_0x587ecc]['status']=0x2,_0x237c43=_0x237c43['concat'](_e(_0x5438f1['serverSyncTree_'],_0x95766d[_0x587ecc]['currentWriteId'])),_0x95766d[_0x587ecc]['onComplete']&&_0x473d80['push'](()=>_0x95766d[_0x587ecc]['onComplete'](null,!0x0,_0x95766d[_0x587ecc]['currentOutputSnapshotResolved'])),_0x95766d[_0x587ecc]['unwatcher']();Kn(_0x5438f1,$n(_0x5438f1['transactionQueueTree_'],_0x215f8e)),jn(_0x5438f1,_0x5438f1['transactionQueueTree_']),V(_0x5438f1['eventQueue_'],_0x215f8e,_0x237c43);for(let _0x44679f=0x0;_0x44679f<_0x473d80['length'];_0x44679f++)ft(_0x473d80[_0x44679f]);}else{if(_0x1ddc0d==='datastale'){for(let _0x124386=0x0;_0x124386<_0x95766d['length'];_0x124386++)_0x95766d[_0x124386]['status']===0x3?_0x95766d[_0x124386]['status']=0x4:_0x95766d[_0x124386]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2cbf7e['toString']()+'\x20failed:\x20'+_0x1ddc0d);for(let _0x344e0b=0x0;_0x344e0b<_0x95766d['length'];_0x344e0b++)_0x95766d[_0x344e0b]['status']=0x4,_0x95766d[_0x344e0b]['abortReason']=_0x1ddc0d;}ct(_0x5438f1,_0x215f8e);}},_0x4fae98);}function ct(_0x473931,_0x3c3192){const _0x561196=ua(_0x473931,_0x3c3192),_0x2257f9=Qt(_0x561196),_0x42afcc=da(_0x473931,_0x561196);return Md(_0x473931,_0x42afcc,_0x2257f9),_0x2257f9;}function Md(_0x539ddb,_0x519494,_0x10534d){if(_0x519494['length']===0x0)return;const _0x536716=[];let _0x558251=[];const _0x17a10e=_0x519494['filter'](_0x3d5868=>_0x3d5868['status']===0x0)['map'](_0x34f0b5=>_0x34f0b5['currentWriteId']);for(let _0x3664c9=0x0;_0x3664c9<_0x519494['length'];_0x3664c9++){const _0xde145b=_0x519494[_0x3664c9],_0x2ff3d6=F(_0x10534d,_0xde145b['path']);let _0x5a26cb=!0x1,_0x36ca37;if(f(_0x2ff3d6!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xde145b['status']===0x4)_0x5a26cb=!0x0,_0x36ca37=_0xde145b['abortReason'],_0x558251=_0x558251['concat'](_e(_0x539ddb['serverSyncTree_'],_0xde145b['currentWriteId'],!0x0));else{if(_0xde145b['status']===0x0){if(_0xde145b['retryCount']>=yd)_0x5a26cb=!0x0,_0x36ca37='maxretry',_0x558251=_0x558251['concat'](_e(_0x539ddb['serverSyncTree_'],_0xde145b['currentWriteId'],!0x0));else{const _0x70802a=Es(_0x539ddb,_0xde145b['path'],_0x17a10e);_0xde145b['currentInputSnapshot']=_0x70802a;const _0x31d009=_0x519494[_0x3664c9]['update'](_0x70802a['val']());if(_0x31d009!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x31d009,_0xde145b['path']);let _0x4a52d0=A(_0x31d009);typeof _0x31d009=='object'&&_0x31d009!=null&&Q(_0x31d009,'.priority')||(_0x4a52d0=_0x4a52d0['updatePriority'](_0x70802a['getPriority']()));const _0x1e507d=_0xde145b['currentWriteId'],_0x2fd8f4=Xt(_0x539ddb),_0x42f885=fs(_0x4a52d0,_0x70802a,_0x2fd8f4);_0xde145b['currentOutputSnapshotRaw']=_0x4a52d0,_0xde145b['currentOutputSnapshotResolved']=_0x42f885,_0xde145b['currentWriteId']=zn(_0x539ddb),_0x17a10e['splice'](_0x17a10e['indexOf'](_0x1e507d),0x1),_0x558251=_0x558251['concat'](as(_0x539ddb['serverSyncTree_'],_0xde145b['path'],_0x42f885,_0xde145b['currentWriteId'],_0xde145b['applyLocally'])),_0x558251=_0x558251['concat'](_e(_0x539ddb['serverSyncTree_'],_0x1e507d,!0x0));}else _0x5a26cb=!0x0,_0x36ca37='nodata',_0x558251=_0x558251['concat'](_e(_0x539ddb['serverSyncTree_'],_0xde145b['currentWriteId'],!0x0));}}}V(_0x539ddb['eventQueue_'],_0x10534d,_0x558251),_0x558251=[],_0x5a26cb&&(_0x519494[_0x3664c9]['status']=0x2,function(_0x774c0a){setTimeout(_0x774c0a,Math['floor'](0x0));}(_0x519494[_0x3664c9]['unwatcher']),_0x519494[_0x3664c9]['onComplete']&&(_0x36ca37==='nodata'?_0x536716['push'](()=>_0x519494[_0x3664c9]['onComplete'](null,!0x1,_0x519494[_0x3664c9]['currentInputSnapshot'])):_0x536716['push'](()=>_0x519494[_0x3664c9]['onComplete'](new Error(_0x36ca37),!0x1,null))));}Kn(_0x539ddb,_0x539ddb['transactionQueueTree_']);for(let _0x483377=0x0;_0x483377<_0x536716['length'];_0x483377++)ft(_0x536716[_0x483377]);jn(_0x539ddb,_0x539ddb['transactionQueueTree_']);}function ua(_0x44d6cc,_0x28164a){let _0x2fad90,_0x1277ce=_0x44d6cc['transactionQueueTree_'];for(_0x2fad90=y(_0x28164a);_0x2fad90!==null&&je(_0x1277ce)===void 0x0;)_0x1277ce=$n(_0x1277ce,_0x2fad90),_0x28164a=S(_0x28164a),_0x2fad90=y(_0x28164a);return _0x1277ce;}function da(_0x31a559,_0x3e30ab){const _0x480dd4=[];return fa(_0x31a559,_0x3e30ab,_0x480dd4),_0x480dd4['sort']((_0x1f9d85,_0x3e851b)=>_0x1f9d85['order']-_0x3e851b['order']),_0x480dd4;}function fa(_0x26ec3c,_0x3dc206,_0x228ae8){const _0x13b4a7=je(_0x3dc206);if(_0x13b4a7){for(let _0x323bc3=0x0;_0x323bc3<_0x13b4a7['length'];_0x323bc3++)_0x228ae8['push'](_0x13b4a7[_0x323bc3]);}Gn(_0x3dc206,_0x4aa2a7=>{fa(_0x26ec3c,_0x4aa2a7,_0x228ae8);});}function Kn(_0x35b567,_0x38be1f){const _0x179c52=je(_0x38be1f);if(_0x179c52){let _0x421fd0=0x0;for(let _0x315daa=0x0;_0x315daa<_0x179c52['length'];_0x315daa++)_0x179c52[_0x315daa]['status']!==0x2&&(_0x179c52[_0x421fd0]=_0x179c52[_0x315daa],_0x421fd0++);_0x179c52['length']=_0x421fd0,gs(_0x38be1f,_0x179c52['length']>0x0?_0x179c52:void 0x0);}Gn(_0x38be1f,_0x211299=>{Kn(_0x35b567,_0x211299);});}function Is(_0x1455b6,_0x47b9f5){const _0x2815f6=Qt(ua(_0x1455b6,_0x47b9f5)),_0x42208f=$n(_0x1455b6['transactionQueueTree_'],_0x47b9f5);return ad(_0x42208f,_0x11faf7=>{di(_0x1455b6,_0x11faf7);}),di(_0x1455b6,_0x42208f),ia(_0x42208f,_0x3ef6a8=>{di(_0x1455b6,_0x3ef6a8);}),_0x2815f6;}function di(_0x5d88f9,_0x290240){const _0x5d14c9=je(_0x290240);if(_0x5d14c9){const _0x59a722=[];let _0x21d7c3=[],_0x4b88cd=-0x1;for(let _0xf0576e=0x0;_0xf0576e<_0x5d14c9['length'];_0xf0576e++)_0x5d14c9[_0xf0576e]['status']===0x3||(_0x5d14c9[_0xf0576e]['status']===0x1?(f(_0x4b88cd===_0xf0576e-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4b88cd=_0xf0576e,_0x5d14c9[_0xf0576e]['status']=0x3,_0x5d14c9[_0xf0576e]['abortReason']='set'):(f(_0x5d14c9[_0xf0576e]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5d14c9[_0xf0576e]['unwatcher'](),_0x21d7c3=_0x21d7c3['concat'](_e(_0x5d88f9['serverSyncTree_'],_0x5d14c9[_0xf0576e]['currentWriteId'],!0x0)),_0x5d14c9[_0xf0576e]['onComplete']&&_0x59a722['push'](_0x5d14c9[_0xf0576e]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4b88cd===-0x1?gs(_0x290240,void 0x0):_0x5d14c9['length']=_0x4b88cd+0x1,V(_0x5d88f9['eventQueue_'],Qt(_0x290240),_0x21d7c3);for(let _0x4c9561=0x0;_0x4c9561<_0x59a722['length'];_0x4c9561++)ft(_0x59a722[_0x4c9561]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x4f4b95){let _0x5d2375='';const _0x62cb8c=_0x4f4b95['split']('/');for(let _0x20481d=0x0;_0x20481d<_0x62cb8c['length'];_0x20481d++)if(_0x62cb8c[_0x20481d]['length']>0x0){let _0x387838=_0x62cb8c[_0x20481d];try{_0x387838=decodeURIComponent(_0x387838['replace'](/\+/g,'\x20'));}catch{}_0x5d2375+='/'+_0x387838;}return _0x5d2375;}function xd(_0x45918){const _0x1dccf1={};_0x45918['charAt'](0x0)==='?'&&(_0x45918=_0x45918['substring'](0x1));for(const _0x58ec25 of _0x45918['split']('&')){if(_0x58ec25['length']===0x0)continue;const _0x5368d4=_0x58ec25['split']('=');_0x5368d4['length']===0x2?_0x1dccf1[decodeURIComponent(_0x5368d4[0x0])]=decodeURIComponent(_0x5368d4[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x58ec25+'\x27\x20in\x20query\x20\x27'+_0x45918+'\x27');}return _0x1dccf1;}const vr=function(_0x5c8381,_0x11820a){const _0x351d72=Fd(_0x5c8381),_0x3c03c4=_0x351d72['namespace'];_0x351d72['domain']==='firebase.com'&&ae(_0x351d72['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3c03c4||_0x3c03c4==='undefined')&&_0x351d72['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x351d72['secure']||$l();const _0x18556d=_0x351d72['scheme']==='ws'||_0x351d72['scheme']==='wss';return{'repoInfo':new yo(_0x351d72['host'],_0x351d72['secure'],_0x3c03c4,_0x18556d,_0x11820a,'',_0x3c03c4!==_0x351d72['subdomain']),'path':new C(_0x351d72['pathString'])};},Fd=function(_0x193276){let _0x34a0d5='',_0x235500='',_0x29e7be='',_0x3a569b='',_0x26f8b4='',_0x16a182=!0x0,_0x4d18ce='https',_0x43e931=0x1bb;if(typeof _0x193276=='string'){let _0x10ecdf=_0x193276['indexOf']('//');_0x10ecdf>=0x0&&(_0x4d18ce=_0x193276['substring'](0x0,_0x10ecdf-0x1),_0x193276=_0x193276['substring'](_0x10ecdf+0x2));let _0x3d2ac5=_0x193276['indexOf']('/');_0x3d2ac5===-0x1&&(_0x3d2ac5=_0x193276['length']);let _0x4c41d3=_0x193276['indexOf']('?');_0x4c41d3===-0x1&&(_0x4c41d3=_0x193276['length']),_0x34a0d5=_0x193276['substring'](0x0,Math['min'](_0x3d2ac5,_0x4c41d3)),_0x3d2ac5<_0x4c41d3&&(_0x3a569b=Ld(_0x193276['substring'](_0x3d2ac5,_0x4c41d3)));const _0x5ac40c=xd(_0x193276['substring'](Math['min'](_0x193276['length'],_0x4c41d3)));_0x10ecdf=_0x34a0d5['indexOf'](':'),_0x10ecdf>=0x0?(_0x16a182=_0x4d18ce==='https'||_0x4d18ce==='wss',_0x43e931=parseInt(_0x34a0d5['substring'](_0x10ecdf+0x1),0xa)):_0x10ecdf=_0x34a0d5['length'];const _0x367920=_0x34a0d5['slice'](0x0,_0x10ecdf);if(_0x367920['toLowerCase']()==='localhost')_0x235500='localhost';else{if(_0x367920['split']('.')['length']<=0x2)_0x235500=_0x367920;else{const _0x242aef=_0x34a0d5['indexOf']('.');_0x29e7be=_0x34a0d5['substring'](0x0,_0x242aef)['toLowerCase'](),_0x235500=_0x34a0d5['substring'](_0x242aef+0x1),_0x26f8b4=_0x29e7be;}}'ns'in _0x5ac40c&&(_0x26f8b4=_0x5ac40c['ns']);}return{'host':_0x34a0d5,'port':_0x43e931,'domain':_0x235500,'subdomain':_0x29e7be,'secure':_0x16a182,'scheme':_0x4d18ce,'pathString':_0x3a569b,'namespace':_0x26f8b4};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x230d30=0x0;const _0x1dc782=[];return function(_0x1a2bde){const _0x26a579=_0x1a2bde===_0x230d30;_0x230d30=_0x1a2bde;let _0x3e055a;const _0x54d899=new Array(0x8);for(_0x3e055a=0x7;_0x3e055a>=0x0;_0x3e055a--)_0x54d899[_0x3e055a]=Er['charAt'](_0x1a2bde%0x40),_0x1a2bde=Math['floor'](_0x1a2bde/0x40);f(_0x1a2bde===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5ede6a=_0x54d899['join']('');if(_0x26a579){for(_0x3e055a=0xb;_0x3e055a>=0x0&&_0x1dc782[_0x3e055a]===0x3f;_0x3e055a--)_0x1dc782[_0x3e055a]=0x0;_0x1dc782[_0x3e055a]++;}else{for(_0x3e055a=0x0;_0x3e055a<0xc;_0x3e055a++)_0x1dc782[_0x3e055a]=Math['floor'](Math['random']()*0x40);}for(_0x3e055a=0x0;_0x3e055a<0xc;_0x3e055a++)_0x5ede6a+=Er['charAt'](_0x1dc782[_0x3e055a]);return f(_0x5ede6a['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5ede6a;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x31b7ac,_0x477e91,_0x112fa0,_0x36bfa6){this['eventType']=_0x31b7ac,this['eventRegistration']=_0x477e91,this['snapshot']=_0x112fa0,this['prevName']=_0x36bfa6;}['getPath'](){const _0x388041=this['snapshot']['ref'];return this['eventType']==='value'?_0x388041['_path']:_0x388041['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x41e7f6,_0xa86b0,_0x4cd35b){this['eventRegistration']=_0x41e7f6,this['error']=_0xa86b0,this['path']=_0x4cd35b;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x35b0e2,_0x202cf4){this['snapshotCallback']=_0x35b0e2,this['cancelCallback']=_0x202cf4;}['onValue'](_0x1cb4ed,_0x4482a0){this['snapshotCallback']['call'](null,_0x1cb4ed,_0x4482a0);}['onCancel'](_0x4cd2ea){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4cd2ea);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xb9a77d){return this['snapshotCallback']===_0xb9a77d['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xb9a77d['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xb9a77d['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x3ff012,_0x55a2a9){this['_repo']=_0x3ff012,this['_path']=_0x55a2a9;}['cancel'](){const _0x1c1e2e=new H();return bd(this['_repo'],this['_path'],_0x1c1e2e['wrapCallback'](()=>{})),_0x1c1e2e['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x1f22db=new H();return yr(this['_repo'],this['_path'],null,_0x1f22db['wrapCallback'](()=>{})),_0x1f22db['promise'];}['set'](_0x2c568a){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x2c568a,this['_path'],!0x1);const _0x3f162f=new H();return yr(this['_repo'],this['_path'],_0x2c568a,_0x3f162f['wrapCallback'](()=>{})),_0x3f162f['promise'];}['setWithPriority'](_0x2d613b,_0x16c1f4){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x2d613b,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x16c1f4);const _0x3aee8f=new H();return Rd(this['_repo'],this['_path'],_0x2d613b,_0x16c1f4,_0x3aee8f['wrapCallback'](()=>{})),_0x3aee8f['promise'];}['update'](_0x3488e4){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x3488e4,this['_path']);const _0x1b5535=new H();return Ad(this['_repo'],this['_path'],_0x3488e4,_0x1b5535['wrapCallback'](()=>{})),_0x1b5535['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x19cac2,_0x42b2b2,_0x15ec94,_0x56a99e){this['_repo']=_0x19cac2,this['_path']=_0x42b2b2,this['_queryParams']=_0x15ec94,this['_orderByCalled']=_0x56a99e;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x1d9e2f=sr(this['_queryParams']),_0x4c8f6e=$i(_0x1d9e2f);return _0x4c8f6e==='{}'?'default':_0x4c8f6e;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x5e05b2){if(_0x5e05b2=P(_0x5e05b2),!(_0x5e05b2 instanceof Ae))return!0x1;const _0x4f4db0=this['_repo']===_0x5e05b2['_repo'],_0x7d7cdb=Ki(this['_path'],_0x5e05b2['_path']),_0x5bcfab=this['_queryIdentifier']===_0x5e05b2['_queryIdentifier'];return _0x4f4db0&&_0x7d7cdb&&_0x5bcfab;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x1fc18a,_0x271fed){if(_0x1fc18a['_orderByCalled']===!0x0)throw new Error(_0x271fed+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x321760){let _0x46a5b7=null,_0x3a0d=null;if(_0x321760['hasStart']()&&(_0x46a5b7=_0x321760['getIndexStartValue']()),_0x321760['hasEnd']()&&(_0x3a0d=_0x321760['getIndexEndValue']()),_0x321760['getIndex']()===ve){const _0x117b56='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x472a58='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x321760['hasStart']()){if(_0x321760['getIndexStartName']()!==We)throw new Error(_0x117b56);if(typeof _0x46a5b7!='string')throw new Error(_0x472a58);}if(_0x321760['hasEnd']()){if(_0x321760['getIndexEndName']()!==we)throw new Error(_0x117b56);if(typeof _0x3a0d!='string')throw new Error(_0x472a58);}}else{if(_0x321760['getIndex']()===R){if(_0x46a5b7!=null&&!Bt(_0x46a5b7)||_0x3a0d!=null&&!Bt(_0x3a0d))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x321760['getIndex']()instanceof Ji||_0x321760['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x46a5b7!=null&&typeof _0x46a5b7=='object'||_0x3a0d!=null&&typeof _0x3a0d=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x428c3c){if(_0x428c3c['hasStart']()&&_0x428c3c['hasEnd']()&&_0x428c3c['hasLimit']()&&!_0x428c3c['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x4fa937,_0x86f873){super(_0x4fa937,_0x86f873,new Zi(),!0x1);}get['parent'](){const _0x148498=Ro(this['_path']);return _0x148498===null?null:new ee(this['_repo'],_0x148498);}get['root'](){let _0x51f8db=this;for(;_0x51f8db['parent']!==null;)_0x51f8db=_0x51f8db['parent'];return _0x51f8db;}}class lt{constructor(_0x54e4a4,_0x903005,_0x506bf3){this['_node']=_0x54e4a4,this['ref']=_0x903005,this['_index']=_0x506bf3;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x3bfdfd){const _0x14908e=new C(_0x3bfdfd),_0x31fb0c=Vt(this['ref'],_0x3bfdfd);return new lt(this['_node']['getChild'](_0x14908e),_0x31fb0c,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x9b6c71){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2bc305,_0x390d1d)=>_0x9b6c71(new lt(_0x390d1d,Vt(this['ref'],_0x2bc305),R)));}['hasChild'](_0x3b5a38){const _0x22cc6e=new C(_0x3b5a38);return!this['_node']['getChild'](_0x22cc6e)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x7bd7f5,_0x224bb6){return _0x7bd7f5=P(_0x7bd7f5),_0x7bd7f5['_checkNotDeleted']('ref'),_0x224bb6!==void 0x0?Vt(_0x7bd7f5['_root'],_0x224bb6):_0x7bd7f5['_root'];}function Vt(_0x26f839,_0x4ab419){return _0x26f839=P(_0x26f839),y(_0x26f839['_path'])===null?pd('child','path',_0x4ab419):ys('child','path',_0x4ab419),new ee(_0x26f839['_repo'],k(_0x26f839['_path'],_0x4ab419));}function v_(_0x11f34e){return _0x11f34e=P(_0x11f34e),new Vd(_0x11f34e['_repo'],_0x11f34e['_path']);}function E_(_0x11c990,_0x5278dd){_0x11c990=P(_0x11c990),Me('push',_0x11c990['_path']),He('push',_0x5278dd,_0x11c990['_path'],!0x0);const _0x244e33=la(_0x11c990['_repo']),_0x5aa438=Ud(_0x244e33),_0x560dbc=Vt(_0x11c990,_0x5aa438),_0x49e4cb=Vt(_0x11c990,_0x5aa438);let _0xf0631f;return _0x5278dd!=null?_0xf0631f=Hd(_0x49e4cb,_0x5278dd)['then'](()=>_0x49e4cb):_0xf0631f=Promise['resolve'](_0x49e4cb),_0x560dbc['then']=_0xf0631f['then']['bind'](_0xf0631f),_0x560dbc['catch']=_0xf0631f['then']['bind'](_0xf0631f,void 0x0),_0x560dbc;}function Hd(_0x15e69f,_0x52d707){_0x15e69f=P(_0x15e69f),Me('set',_0x15e69f['_path']),He('set',_0x52d707,_0x15e69f['_path'],!0x1);const _0x304589=new H();return Cd(_0x15e69f['_repo'],_0x15e69f['_path'],_0x52d707,null,_0x304589['wrapCallback'](()=>{})),_0x304589['promise'];}function I_(_0x17977c,_0x1381ec){ra('update',_0x1381ec,_0x17977c['_path']);const _0x50fb42=new H();return Td(_0x17977c['_repo'],_0x17977c['_path'],_0x1381ec,_0x50fb42['wrapCallback'](()=>{})),_0x50fb42['promise'];}function w_(_0x15bebc){_0x15bebc=P(_0x15bebc);const _0x51bad3=new pa(()=>{}),_0x465863=new Qn(_0x51bad3);return wd(_0x15bebc['_repo'],_0x15bebc,_0x465863)['then'](_0x71a414=>new lt(_0x71a414,new ee(_0x15bebc['_repo'],_0x15bebc['_path']),_0x15bebc['_queryParams']['getIndex']()));}class Qn{constructor(_0x5c5b6a){this['callbackContext']=_0x5c5b6a;}['respondsTo'](_0x33e840){return _0x33e840==='value';}['createEvent'](_0x354bc3,_0x1ba960){const _0x1b7443=_0x1ba960['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x354bc3['snapshotNode'],new ee(_0x1ba960['_repo'],_0x1ba960['_path']),_0x1b7443));}['getEventRunner'](_0x15a502){return _0x15a502['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x15a502['error']):()=>this['callbackContext']['onValue'](_0x15a502['snapshot'],null);}['createCancelEvent'](_0x31d2c3,_0x48091f){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x31d2c3,_0x48091f):null;}['matches'](_0x1954ee){return _0x1954ee instanceof Qn?!_0x1954ee['callbackContext']||!this['callbackContext']?!0x0:_0x1954ee['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x899b48,_0x1f82cc,_0x237aae,_0x4b8b5e,_0x5ee66e){const _0x4b255b=new pa(_0x237aae,void 0x0),_0xdd5780=new Qn(_0x4b255b);return kd(_0x899b48['_repo'],_0x899b48,_0xdd5780),()=>Pd(_0x899b48['_repo'],_0x899b48,_0xdd5780);}function Gd(_0x3ba5da,_0x434ee3,_0x27e2b7,_0x2581bf){return $d(_0x3ba5da,'value',_0x434ee3);}class mt{}class ma extends mt{constructor(_0x3f2c48,_0x14be12){super(),this['_value']=_0x3f2c48,this['_key']=_0x14be12,this['type']='endAt';}['_apply'](_0x74b7a){He('endAt',this['_value'],_0x74b7a['_path'],!0x0);const _0x3e239f=Jh(_0x74b7a['_queryParams'],this['_value'],this['_key']);if(ga(_0x3e239f),Yn(_0x3e239f),_0x74b7a['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x74b7a['_repo'],_0x74b7a['_path'],_0x3e239f,_0x74b7a['_orderByCalled']);}}function C_(_0x149711,_0x4f92fa){return new ma(_0x149711,_0x4f92fa);}class ya extends mt{constructor(_0x3f1bc1,_0xad5bb6){super(),this['_value']=_0x3f1bc1,this['_key']=_0xad5bb6,this['type']='startAt';}['_apply'](_0x24b709){He('startAt',this['_value'],_0x24b709['_path'],!0x0);const _0x44136a=Qh(_0x24b709['_queryParams'],this['_value'],this['_key']);if(ga(_0x44136a),Yn(_0x44136a),_0x24b709['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x24b709['_repo'],_0x24b709['_path'],_0x44136a,_0x24b709['_orderByCalled']);}}function T_(_0xf68e95=null,_0x227d94){return new ya(_0xf68e95,_0x227d94);}class qd extends mt{constructor(_0x51b028){super(),this['_limit']=_0x51b028,this['type']='limitToFirst';}['_apply'](_0x430880){if(_0x430880['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x430880['_repo'],_0x430880['_path'],Yh(_0x430880['_queryParams'],this['_limit']),_0x430880['_orderByCalled']);}}function S_(_0x37578d){if(Math['floor'](_0x37578d)!==_0x37578d||_0x37578d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x37578d);}class zd extends mt{constructor(_0x5f178c){super(),this['_path']=_0x5f178c,this['type']='orderByChild';}['_apply'](_0x7fedc1){_a(_0x7fedc1,'orderByChild');const _0x7ce328=new C(this['_path']);if(v(_0x7ce328))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x28fe43=new Ji(_0x7ce328),_0x1a55a2=xo(_0x7fedc1['_queryParams'],_0x28fe43);return Yn(_0x1a55a2),new Ae(_0x7fedc1['_repo'],_0x7fedc1['_path'],_0x1a55a2,!0x0);}}function b_(_0x5c63e6){if(_0x5c63e6==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5c63e6==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5c63e6==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5c63e6),new zd(_0x5c63e6);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2b55ab){_a(_0x2b55ab,'orderByKey');const _0x52f351=xo(_0x2b55ab['_queryParams'],ve);return Yn(_0x52f351),new Ae(_0x2b55ab['_repo'],_0x2b55ab['_path'],_0x52f351,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x184413,_0x5a7f82){super(),this['_value']=_0x184413,this['_key']=_0x5a7f82,this['type']='equalTo';}['_apply'](_0x16c632){if(He('equalTo',this['_value'],_0x16c632['_path'],!0x1),_0x16c632['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x16c632['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x16c632));}}function A_(_0x1e2c88,_0x43e941){return new Kd(_0x1e2c88,_0x43e941);}function k_(_0x21a45d,..._0x2daf97){let _0x308ae9=P(_0x21a45d);for(const _0x387bab of _0x2daf97)_0x308ae9=_0x387bab['_apply'](_0x308ae9);return _0x308ae9;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x425ad5,_0x32935f,_0x19c1b2,_0x38ac2f){const _0x31411a=_0x32935f['lastIndexOf'](':'),_0x52e0f2=_0x32935f['substring'](0x0,_0x31411a),_0x510992=qt(_0x52e0f2);_0x425ad5['repoInfo_']=new yo(_0x32935f,_0x510992,_0x425ad5['repoInfo_']['namespace'],_0x425ad5['repoInfo_']['webSocketOnly'],_0x425ad5['repoInfo_']['nodeAdmin'],_0x425ad5['repoInfo_']['persistenceKey'],_0x425ad5['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x19c1b2),_0x38ac2f&&(_0x425ad5['authTokenProvider_']=_0x38ac2f);}function Xd(_0x1c9e0d,_0x2f9b55,_0x1af4d8,_0x30f11c,_0xd9ba99){let _0x120dbb=_0x30f11c||_0x1c9e0d['options']['databaseURL'];_0x120dbb===void 0x0&&(_0x1c9e0d['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x1c9e0d['options']['projectId']),_0x120dbb=_0x1c9e0d['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2377d1=vr(_0x120dbb,_0xd9ba99),_0x4845c7=_0x2377d1['repoInfo'],_0x1eed75;typeof process<'u'&&Bs&&(_0x1eed75=Bs[Yd]),_0x1eed75?(_0x120dbb='http://'+_0x1eed75+'?ns='+_0x4845c7['namespace'],_0x2377d1=vr(_0x120dbb,_0xd9ba99),_0x4845c7=_0x2377d1['repoInfo']):_0x2377d1['repoInfo']['secure'];const _0x238def=new eh(_0x1c9e0d['name'],_0x1c9e0d['options'],_0x2f9b55);_d('Invalid\x20Firebase\x20Database\x20URL',_0x2377d1),v(_0x2377d1['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3952d5=ef(_0x4845c7,_0x1c9e0d,_0x238def,new Zl(_0x1c9e0d,_0x1af4d8));return new tf(_0x3952d5,_0x1c9e0d);}function Zd(_0x4cc634,_0x4812ef){const _0x5e88c5=Di[_0x4812ef];(!_0x5e88c5||_0x5e88c5[_0x4cc634['key']]!==_0x4cc634)&&ae('Database\x20'+_0x4812ef+'('+_0x4cc634['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x4cc634),delete _0x5e88c5[_0x4cc634['key']];}function ef(_0x47329c,_0x229757,_0x3f2e73,_0x57df15){let _0x2f7c62=Di[_0x229757['name']];_0x2f7c62||(_0x2f7c62={},Di[_0x229757['name']]=_0x2f7c62);let _0x165f1c=_0x2f7c62[_0x47329c['toURLString']()];return _0x165f1c&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x165f1c=new vd(_0x47329c,Qd,_0x3f2e73,_0x57df15),_0x2f7c62[_0x47329c['toURLString']()]=_0x165f1c,_0x165f1c;}class tf{constructor(_0x6404be,_0x13fa75){this['_repoInternal']=_0x6404be,this['app']=_0x13fa75,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x86fbb1){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x86fbb1+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x2f07ff=Zr(),_0x2e2656){const _0x4bdfff=Hi(_0x2f07ff,'database')['getImmediate']({'identifier':_0x2e2656});if(!_0x4bdfff['_instanceStarted']){const _0x17025f=hc('database');_0x17025f&&nf(_0x4bdfff,..._0x17025f);}return _0x4bdfff;}function nf(_0x4781f0,_0x4cf211,_0x4bedca,_0x51ebbd={}){_0x4781f0=P(_0x4781f0),_0x4781f0['_checkNotDeleted']('useEmulator');const _0x1ea162=_0x4cf211+':'+_0x4bedca,_0xfd4f74=_0x4781f0['_repoInternal'];if(_0x4781f0['_instanceStarted']){if(_0x1ea162===_0x4781f0['_repoInternal']['repoInfo_']['host']&&xe(_0x51ebbd,_0xfd4f74['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xa8d18a;if(_0xfd4f74['repoInfo_']['nodeAdmin'])_0x51ebbd['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xa8d18a=new an(an['OWNER']);else{if(_0x51ebbd['mockUserToken']){const _0x179d16=typeof _0x51ebbd['mockUserToken']=='string'?_0x51ebbd['mockUserToken']:uc(_0x51ebbd['mockUserToken'],_0x4781f0['app']['options']['projectId']);_0xa8d18a=new an(_0x179d16);}}qt(_0x4cf211)&&Qr(_0x4cf211),Jd(_0xfd4f74,_0x1ea162,_0x51ebbd,_0xa8d18a);}function N_(_0x26d2fd){_0x26d2fd=P(_0x26d2fd),_0x26d2fd['_checkNotDeleted']('goOffline'),ha(_0x26d2fd['_repo']);}function O_(_0x536e19){_0x536e19=P(_0x536e19),_0x536e19['_checkNotDeleted']('goOnline'),Nd(_0x536e19['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x218b93){Ul(dt),st(new Fe('database',(_0x792f15,{instanceIdentifier:_0x23648d})=>{const _0x26d800=_0x792f15['getProvider']('app')['getImmediate'](),_0x477bd7=_0x792f15['getProvider']('auth-internal'),_0x25a11e=_0x792f15['getProvider']('app-check-internal');return Xd(_0x26d800,_0x477bd7,_0x25a11e,_0x23648d);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x218b93),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x37aec5,_0x370331){this['committed']=_0x37aec5,this['snapshot']=_0x370331;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0xcef28f,_0x25b8a9,_0x6247bf){if(_0xcef28f=P(_0xcef28f),Me('Reference.transaction',_0xcef28f['_path']),_0xcef28f['key']==='.length'||_0xcef28f['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0xcef28f['key']+'\x20is\x20a\x20read-only\x20object.';const _0x41e09f=!0x0,_0x1ec8fe=new H(),_0x5b4fbf=(_0x420c09,_0x2b181f,_0x32466a)=>{let _0x36c30a=null;_0x420c09?_0x1ec8fe['reject'](_0x420c09):(_0x36c30a=new lt(_0x32466a,new ee(_0xcef28f['_repo'],_0xcef28f['_path']),R),_0x1ec8fe['resolve'](new of(_0x2b181f,_0x36c30a)));},_0x5e23b5=Gd(_0xcef28f,()=>{});return Od(_0xcef28f['_repo'],_0xcef28f['_path'],_0x25b8a9,_0x5b4fbf,_0x5e23b5,_0x41e09f),_0x1ec8fe['promise'];}se['prototype']['simpleListen']=function(_0x468dc2,_0x15c39e){this['sendRequest']('q',{'p':_0x468dc2},_0x15c39e);},se['prototype']['echo']=function(_0x2fb822,_0x26039c){this['sendRequest']('echo',{'d':_0x2fb822},_0x26039c);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x2152a3,..._0x2503d3){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x2152a3,..._0x2503d3);}function cn(_0x248865,..._0x1e2309){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x248865,..._0x1e2309);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x55966c,..._0x3aef2f){throw ws(_0x55966c,..._0x3aef2f);}function X(_0x543c95,..._0x7b626){return ws(_0x543c95,..._0x7b626);}function Ia(_0x59f122,_0x414654,_0x42e855){const _0x2ee77d={...af(),[_0x414654]:_0x42e855};return new Gt('auth','Firebase',_0x2ee77d)['create'](_0x414654,{'appName':_0x59f122['name']});}function re(_0x456a22){return Ia(_0x456a22,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0xafca65,..._0x1be923){if(typeof _0xafca65!='string'){const _0x5aebb5=_0x1be923[0x0],_0x4b7d1f=[..._0x1be923['slice'](0x1)];return _0x4b7d1f[0x0]&&(_0x4b7d1f[0x0]['appName']=_0xafca65['name']),_0xafca65['_errorFactory']['create'](_0x5aebb5,..._0x4b7d1f);}return Ea['create'](_0xafca65,..._0x1be923);}function m(_0x1cbb20,_0x504433,..._0x39808a){if(!_0x1cbb20)throw ws(_0x504433,..._0x39808a);}function ne(_0x4bc69e){const _0x503325='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4bc69e;throw cn(_0x503325),new Error(_0x503325);}function ce(_0x389f40,_0x48b72f){_0x389f40||ne(_0x48b72f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x4850a9;return typeof self<'u'&&((_0x4850a9=self['location'])==null?void 0x0:_0x4850a9['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x1c0dba;return typeof self<'u'&&((_0x1c0dba=self['location'])==null?void 0x0:_0x1c0dba['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x12fe04=navigator;return _0x12fe04['languages']&&_0x12fe04['languages'][0x0]||_0x12fe04['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x559378,_0x3f1a2d){this['shortDelay']=_0x559378,this['longDelay']=_0x3f1a2d,ce(_0x3f1a2d>_0x559378,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x339591,_0x432b5e){ce(_0x339591['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x331876}=_0x339591['emulator'];return _0x432b5e?''+_0x331876+(_0x432b5e['startsWith']('/')?_0x432b5e['slice'](0x1):_0x432b5e):_0x331876;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x496e4e,_0x37f97b,_0x14bc5b){this['fetchImpl']=_0x496e4e,_0x37f97b&&(this['headersImpl']=_0x37f97b),_0x14bc5b&&(this['responseImpl']=_0x14bc5b);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x3ebf55,_0x14dbcb){return _0x3ebf55['tenantId']&&!_0x14dbcb['tenantId']?{..._0x14dbcb,'tenantId':_0x3ebf55['tenantId']}:_0x14dbcb;}async function Pe(_0x241f95,_0x1ab7b4,_0x4de8e6,_0x33e09b,_0x3d2737={}){return Ca(_0x241f95,_0x3d2737,async()=>{let _0x47a08d={},_0x283f47={};_0x33e09b&&(_0x1ab7b4==='GET'?_0x283f47=_0x33e09b:_0x47a08d={'body':JSON['stringify'](_0x33e09b)});const _0x3b8990=ut({..._0x283f47,'key':_0x241f95['config']['apiKey']})['slice'](0x1),_0x5ea00a=await _0x241f95['_getAdditionalHeaders']();_0x5ea00a['Content-Type']='application/json',_0x241f95['languageCode']&&(_0x5ea00a['X-Firebase-Locale']=_0x241f95['languageCode']);const _0x597b87={'method':_0x1ab7b4,'headers':_0x5ea00a,..._0x47a08d};return dc()||(_0x597b87['referrerPolicy']='strict-origin-when-cross-origin'),_0x241f95['emulatorConfig']&&qt(_0x241f95['emulatorConfig']['host'])&&(_0x597b87['credentials']='include'),wa['fetch']()(await Ta(_0x241f95,_0x241f95['config']['apiHost'],_0x4de8e6,_0x3b8990),_0x597b87);});}async function Ca(_0x1147a9,_0x22098d,_0x2ffd99){_0x1147a9['_canInitEmulator']=!0x1;const _0x288a58={...df,..._0x22098d};try{const _0x59e3c1=new gf(_0x1147a9),_0x3aa1b7=await Promise['race']([_0x2ffd99(),_0x59e3c1['promise']]);_0x59e3c1['clearNetworkTimeout']();const _0x2ea5cd=await _0x3aa1b7['json']();if('needConfirmation'in _0x2ea5cd)throw on(_0x1147a9,'account-exists-with-different-credential',_0x2ea5cd);if(_0x3aa1b7['ok']&&!('errorMessage'in _0x2ea5cd))return _0x2ea5cd;{const _0x34e375=_0x3aa1b7['ok']?_0x2ea5cd['errorMessage']:_0x2ea5cd['error']['message'],[_0x4ae175,_0x2d9b4f]=_0x34e375['split']('\x20:\x20');if(_0x4ae175==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x1147a9,'credential-already-in-use',_0x2ea5cd);if(_0x4ae175==='EMAIL_EXISTS')throw on(_0x1147a9,'email-already-in-use',_0x2ea5cd);if(_0x4ae175==='USER_DISABLED')throw on(_0x1147a9,'user-disabled',_0x2ea5cd);const _0x504ad0=_0x288a58[_0x4ae175]||_0x4ae175['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2d9b4f)throw Ia(_0x1147a9,_0x504ad0,_0x2d9b4f);Y(_0x1147a9,_0x504ad0);}}catch(_0x398fd2){if(_0x398fd2 instanceof Re)throw _0x398fd2;Y(_0x1147a9,'network-request-failed',{'message':String(_0x398fd2)});}}async function en(_0x56f706,_0x2efd2c,_0x4ee2e9,_0x288872,_0x4e9130={}){const _0x56fab7=await Pe(_0x56f706,_0x2efd2c,_0x4ee2e9,_0x288872,_0x4e9130);return'mfaPendingCredential'in _0x56fab7&&Y(_0x56f706,'multi-factor-auth-required',{'_serverResponse':_0x56fab7}),_0x56fab7;}async function Ta(_0x54994a,_0x5f396,_0x511a95,_0x3d3018){const _0x54d4da=''+_0x5f396+_0x511a95+'?'+_0x3d3018,_0x4da689=_0x54994a,_0x1ab856=_0x4da689['config']['emulator']?Cs(_0x54994a['config'],_0x54d4da):_0x54994a['config']['apiScheme']+'://'+_0x54d4da;return ff['includes'](_0x511a95)&&(await _0x4da689['_persistenceManagerAvailable'],_0x4da689['_getPersistenceType']()==='COOKIE')?_0x4da689['_getPersistence']()['_getFinalTarget'](_0x1ab856)['toString']():_0x1ab856;}function _f(_0x288daa){switch(_0x288daa){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x2d065f){this['auth']=_0x2d065f,this['timer']=null,this['promise']=new Promise((_0x2bc42d,_0x1a9cce)=>{this['timer']=setTimeout(()=>_0x1a9cce(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x121d4c,_0x5efb7b,_0x248116){const _0x290d9e={'appName':_0x121d4c['name']};_0x248116['email']&&(_0x290d9e['email']=_0x248116['email']),_0x248116['phoneNumber']&&(_0x290d9e['phoneNumber']=_0x248116['phoneNumber']);const _0x189d5b=X(_0x121d4c,_0x5efb7b,_0x290d9e);return _0x189d5b['customData']['_tokenResponse']=_0x248116,_0x189d5b;}function wr(_0x2ab2ae){return _0x2ab2ae!==void 0x0&&_0x2ab2ae['enterprise']!==void 0x0;}class mf{constructor(_0x27eca3){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x27eca3['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x27eca3['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x27eca3['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x50ea9f){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x59d67b of this['recaptchaEnforcementState'])if(_0x59d67b['provider']&&_0x59d67b['provider']===_0x50ea9f)return _f(_0x59d67b['enforcementState']);return null;}['isProviderEnabled'](_0x23a86d){return this['getProviderEnforcementState'](_0x23a86d)==='ENFORCE'||this['getProviderEnforcementState'](_0x23a86d)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5014d6,_0x45eded){return Pe(_0x5014d6,'GET','/v2/recaptchaConfig',ke(_0x5014d6,_0x45eded));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3e56ef,_0x122a64){return Pe(_0x3e56ef,'POST','/v1/accounts:delete',_0x122a64);}async function Pn(_0x1686c2,_0x12db4b){return Pe(_0x1686c2,'POST','/v1/accounts:lookup',_0x12db4b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x2156ba){if(_0x2156ba)try{const _0x3ace25=new Date(Number(_0x2156ba));if(!isNaN(_0x3ace25['getTime']()))return _0x3ace25['toUTCString']();}catch{}}async function Ef(_0x3e1bd3,_0x35d29b=!0x1){const _0x476eec=P(_0x3e1bd3),_0x56f1f2=await _0x476eec['getIdToken'](_0x35d29b),_0x3e7409=Ts(_0x56f1f2);m(_0x3e7409&&_0x3e7409['exp']&&_0x3e7409['auth_time']&&_0x3e7409['iat'],_0x476eec['auth'],'internal-error');const _0x4d1b45=typeof _0x3e7409['firebase']=='object'?_0x3e7409['firebase']:void 0x0,_0x1f48f6=_0x4d1b45==null?void 0x0:_0x4d1b45['sign_in_provider'];return{'claims':_0x3e7409,'token':_0x56f1f2,'authTime':Pt(fi(_0x3e7409['auth_time'])),'issuedAtTime':Pt(fi(_0x3e7409['iat'])),'expirationTime':Pt(fi(_0x3e7409['exp'])),'signInProvider':_0x1f48f6||null,'signInSecondFactor':(_0x4d1b45==null?void 0x0:_0x4d1b45['sign_in_second_factor'])||null};}function fi(_0x513b71){return Number(_0x513b71)*0x3e8;}function Ts(_0x1ca9cf){const [_0x505483,_0x19ae65,_0x40efca]=_0x1ca9cf['split']('.');if(_0x505483===void 0x0||_0x19ae65===void 0x0||_0x40efca===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2ec9c9=fn(_0x19ae65);return _0x2ec9c9?JSON['parse'](_0x2ec9c9):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x112624){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x112624==null?void 0x0:_0x112624['toString']()),null;}}function Cr(_0x7b1adb){const _0x22742f=Ts(_0x7b1adb);return m(_0x22742f,'internal-error'),m(typeof _0x22742f['exp']<'u','internal-error'),m(typeof _0x22742f['iat']<'u','internal-error'),Number(_0x22742f['exp'])-Number(_0x22742f['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x23d14f,_0x15e0da,_0x5e0293=!0x1){if(_0x5e0293)return _0x15e0da;try{return await _0x15e0da;}catch(_0x68c975){throw _0x68c975 instanceof Re&&If(_0x68c975)&&_0x23d14f['auth']['currentUser']===_0x23d14f&&await _0x23d14f['auth']['signOut'](),_0x68c975;}}function If({code:_0x5f558c}){return _0x5f558c==='auth/user-disabled'||_0x5f558c==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x3c7b78){this['user']=_0x3c7b78,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x4317e1){if(_0x4317e1){const _0x5e93f8=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x5e93f8;}else{this['errorBackoff']=0x7530;const _0x310136=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x310136);}}['schedule'](_0x4e39ae=!0x1){if(!this['isRunning'])return;const _0x2df54f=this['getInterval'](_0x4e39ae);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x2df54f);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x547aa5){(_0x547aa5==null?void 0x0:_0x547aa5['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x4c308e,_0xb76195){this['createdAt']=_0x4c308e,this['lastLoginAt']=_0xb76195,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x2d5b59){this['createdAt']=_0x2d5b59['createdAt'],this['lastLoginAt']=_0x2d5b59['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x35c5a8){var _0x1b2144;const _0x46b554=_0x35c5a8['auth'],_0x3659b7=await _0x35c5a8['getIdToken'](),_0x5a9ae3=await Ht(_0x35c5a8,Pn(_0x46b554,{'idToken':_0x3659b7}));m(_0x5a9ae3==null?void 0x0:_0x5a9ae3['users']['length'],_0x46b554,'internal-error');const _0x3cdb17=_0x5a9ae3['users'][0x0];_0x35c5a8['_notifyReloadListener'](_0x3cdb17);const _0x384746=(_0x1b2144=_0x3cdb17['providerUserInfo'])!=null&&_0x1b2144['length']?Sa(_0x3cdb17['providerUserInfo']):[],_0x1b2ccd=Tf(_0x35c5a8['providerData'],_0x384746),_0x5c0bc7=_0x35c5a8['isAnonymous'],_0x1fcea3=!(_0x35c5a8['email']&&_0x3cdb17['passwordHash'])&&!(_0x1b2ccd!=null&&_0x1b2ccd['length']),_0x33bc2b=_0x5c0bc7?_0x1fcea3:!0x1,_0x13768d={'uid':_0x3cdb17['localId'],'displayName':_0x3cdb17['displayName']||null,'photoURL':_0x3cdb17['photoUrl']||null,'email':_0x3cdb17['email']||null,'emailVerified':_0x3cdb17['emailVerified']||!0x1,'phoneNumber':_0x3cdb17['phoneNumber']||null,'tenantId':_0x3cdb17['tenantId']||null,'providerData':_0x1b2ccd,'metadata':new Li(_0x3cdb17['createdAt'],_0x3cdb17['lastLoginAt']),'isAnonymous':_0x33bc2b};Object['assign'](_0x35c5a8,_0x13768d);}async function Cf(_0x46daa1){const _0xc3a5dd=P(_0x46daa1);await Nn(_0xc3a5dd),await _0xc3a5dd['auth']['_persistUserIfCurrent'](_0xc3a5dd),_0xc3a5dd['auth']['_notifyListenersIfCurrent'](_0xc3a5dd);}function Tf(_0x13a757,_0x41e74d){return[..._0x13a757['filter'](_0x50a1dc=>!_0x41e74d['some'](_0x425125=>_0x425125['providerId']===_0x50a1dc['providerId'])),..._0x41e74d];}function Sa(_0x27b16c){return _0x27b16c['map'](({providerId:_0xfcbbce,..._0x3ae442})=>({'providerId':_0xfcbbce,'uid':_0x3ae442['rawId']||'','displayName':_0x3ae442['displayName']||null,'email':_0x3ae442['email']||null,'phoneNumber':_0x3ae442['phoneNumber']||null,'photoURL':_0x3ae442['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x25852b,_0x414cc6){const _0x5894e3=await Ca(_0x25852b,{},async()=>{const _0x317b59=ut({'grant_type':'refresh_token','refresh_token':_0x414cc6})['slice'](0x1),{tokenApiHost:_0x21e0b3,apiKey:_0x24b9e8}=_0x25852b['config'],_0x490f10=await Ta(_0x25852b,_0x21e0b3,'/v1/token','key='+_0x24b9e8),_0xb92639=await _0x25852b['_getAdditionalHeaders']();_0xb92639['Content-Type']='application/x-www-form-urlencoded';const _0x15bb91={'method':'POST','headers':_0xb92639,'body':_0x317b59};return _0x25852b['emulatorConfig']&&qt(_0x25852b['emulatorConfig']['host'])&&(_0x15bb91['credentials']='include'),wa['fetch']()(_0x490f10,_0x15bb91);});return{'accessToken':_0x5894e3['access_token'],'expiresIn':_0x5894e3['expires_in'],'refreshToken':_0x5894e3['refresh_token']};}async function bf(_0x109f2e,_0x13b6ec){return Pe(_0x109f2e,'POST','/v2/accounts:revokeToken',ke(_0x109f2e,_0x13b6ec));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xe3beb2){m(_0xe3beb2['idToken'],'internal-error'),m(typeof _0xe3beb2['idToken']<'u','internal-error'),m(typeof _0xe3beb2['refreshToken']<'u','internal-error');const _0x4ab3b9='expiresIn'in _0xe3beb2&&typeof _0xe3beb2['expiresIn']<'u'?Number(_0xe3beb2['expiresIn']):Cr(_0xe3beb2['idToken']);this['updateTokensAndExpiration'](_0xe3beb2['idToken'],_0xe3beb2['refreshToken'],_0x4ab3b9);}['updateFromIdToken'](_0x4b8f62){m(_0x4b8f62['length']!==0x0,'internal-error');const _0x5eadd9=Cr(_0x4b8f62);this['updateTokensAndExpiration'](_0x4b8f62,null,_0x5eadd9);}async['getToken'](_0x22afbf,_0x42535d=!0x1){return!_0x42535d&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x22afbf,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x22afbf,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2b3c15,_0x258d3d){const {accessToken:_0x4f8b80,refreshToken:_0x2e77ab,expiresIn:_0x429046}=await Sf(_0x2b3c15,_0x258d3d);this['updateTokensAndExpiration'](_0x4f8b80,_0x2e77ab,Number(_0x429046));}['updateTokensAndExpiration'](_0xb92b41,_0xc91871,_0x5d93a8){this['refreshToken']=_0xc91871||null,this['accessToken']=_0xb92b41||null,this['expirationTime']=Date['now']()+_0x5d93a8*0x3e8;}static['fromJSON'](_0x1aa8fc,_0x35471f){const {refreshToken:_0x119d0f,accessToken:_0x3fb550,expirationTime:_0xe575b1}=_0x35471f,_0x3c9939=new et();return _0x119d0f&&(m(typeof _0x119d0f=='string','internal-error',{'appName':_0x1aa8fc}),_0x3c9939['refreshToken']=_0x119d0f),_0x3fb550&&(m(typeof _0x3fb550=='string','internal-error',{'appName':_0x1aa8fc}),_0x3c9939['accessToken']=_0x3fb550),_0xe575b1&&(m(typeof _0xe575b1=='number','internal-error',{'appName':_0x1aa8fc}),_0x3c9939['expirationTime']=_0xe575b1),_0x3c9939;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x40d0ef){this['accessToken']=_0x40d0ef['accessToken'],this['refreshToken']=_0x40d0ef['refreshToken'],this['expirationTime']=_0x40d0ef['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x1c76ae,_0x30c984){m(typeof _0x1c76ae=='string'||typeof _0x1c76ae>'u','internal-error',{'appName':_0x30c984});}class j{constructor({uid:_0x3e82c9,auth:_0xd0f13c,stsTokenManager:_0x5ad8b6,..._0x3e4469}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3e82c9,this['auth']=_0xd0f13c,this['stsTokenManager']=_0x5ad8b6,this['accessToken']=_0x5ad8b6['accessToken'],this['displayName']=_0x3e4469['displayName']||null,this['email']=_0x3e4469['email']||null,this['emailVerified']=_0x3e4469['emailVerified']||!0x1,this['phoneNumber']=_0x3e4469['phoneNumber']||null,this['photoURL']=_0x3e4469['photoURL']||null,this['isAnonymous']=_0x3e4469['isAnonymous']||!0x1,this['tenantId']=_0x3e4469['tenantId']||null,this['providerData']=_0x3e4469['providerData']?[..._0x3e4469['providerData']]:[],this['metadata']=new Li(_0x3e4469['createdAt']||void 0x0,_0x3e4469['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3dceee){const _0x3cd8ee=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x3dceee));return m(_0x3cd8ee,this['auth'],'internal-error'),this['accessToken']!==_0x3cd8ee&&(this['accessToken']=_0x3cd8ee,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3cd8ee;}['getIdTokenResult'](_0xddae8c){return Ef(this,_0xddae8c);}['reload'](){return Cf(this);}['_assign'](_0x27e326){this!==_0x27e326&&(m(this['uid']===_0x27e326['uid'],this['auth'],'internal-error'),this['displayName']=_0x27e326['displayName'],this['photoURL']=_0x27e326['photoURL'],this['email']=_0x27e326['email'],this['emailVerified']=_0x27e326['emailVerified'],this['phoneNumber']=_0x27e326['phoneNumber'],this['isAnonymous']=_0x27e326['isAnonymous'],this['tenantId']=_0x27e326['tenantId'],this['providerData']=_0x27e326['providerData']['map'](_0x3a0906=>({..._0x3a0906})),this['metadata']['_copy'](_0x27e326['metadata']),this['stsTokenManager']['_assign'](_0x27e326['stsTokenManager']));}['_clone'](_0x15982b){const _0x442ffb=new j({...this,'auth':_0x15982b,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x442ffb['metadata']['_copy'](this['metadata']),_0x442ffb;}['_onReload'](_0x4e96ea){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x4e96ea,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xf46138){this['reloadListener']?this['reloadListener'](_0xf46138):this['reloadUserInfo']=_0xf46138;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5228c3,_0x135b8b=!0x1){let _0x3e053e=!0x1;_0x5228c3['idToken']&&_0x5228c3['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5228c3),_0x3e053e=!0x0),_0x135b8b&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3e053e&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x425d8d=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x425d8d})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x579bfa=>({..._0x579bfa})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4fd351,_0x2e7145){const _0x3a567a=_0x2e7145['displayName']??void 0x0,_0xa7aa01=_0x2e7145['email']??void 0x0,_0x36cecb=_0x2e7145['phoneNumber']??void 0x0,_0x3cc527=_0x2e7145['photoURL']??void 0x0,_0x157322=_0x2e7145['tenantId']??void 0x0,_0x3f52f3=_0x2e7145['_redirectEventId']??void 0x0,_0x831652=_0x2e7145['createdAt']??void 0x0,_0x1f39f9=_0x2e7145['lastLoginAt']??void 0x0,{uid:_0x4483bc,emailVerified:_0x34b7a2,isAnonymous:_0x1c01f7,providerData:_0x95a7a4,stsTokenManager:_0x464d19}=_0x2e7145;m(_0x4483bc&&_0x464d19,_0x4fd351,'internal-error');const _0x1d3651=et['fromJSON'](this['name'],_0x464d19);m(typeof _0x4483bc=='string',_0x4fd351,'internal-error'),le(_0x3a567a,_0x4fd351['name']),le(_0xa7aa01,_0x4fd351['name']),m(typeof _0x34b7a2=='boolean',_0x4fd351,'internal-error'),m(typeof _0x1c01f7=='boolean',_0x4fd351,'internal-error'),le(_0x36cecb,_0x4fd351['name']),le(_0x3cc527,_0x4fd351['name']),le(_0x157322,_0x4fd351['name']),le(_0x3f52f3,_0x4fd351['name']),le(_0x831652,_0x4fd351['name']),le(_0x1f39f9,_0x4fd351['name']);const _0x2f8ba9=new j({'uid':_0x4483bc,'auth':_0x4fd351,'email':_0xa7aa01,'emailVerified':_0x34b7a2,'displayName':_0x3a567a,'isAnonymous':_0x1c01f7,'photoURL':_0x3cc527,'phoneNumber':_0x36cecb,'tenantId':_0x157322,'stsTokenManager':_0x1d3651,'createdAt':_0x831652,'lastLoginAt':_0x1f39f9});return _0x95a7a4&&Array['isArray'](_0x95a7a4)&&(_0x2f8ba9['providerData']=_0x95a7a4['map'](_0x2fed36=>({..._0x2fed36}))),_0x3f52f3&&(_0x2f8ba9['_redirectEventId']=_0x3f52f3),_0x2f8ba9;}static async['_fromIdTokenResponse'](_0x44430c,_0x4725ba,_0x5d4e7a=!0x1){const _0x5e9e17=new et();_0x5e9e17['updateFromServerResponse'](_0x4725ba);const _0x21cddf=new j({'uid':_0x4725ba['localId'],'auth':_0x44430c,'stsTokenManager':_0x5e9e17,'isAnonymous':_0x5d4e7a});return await Nn(_0x21cddf),_0x21cddf;}static async['_fromGetAccountInfoResponse'](_0x547993,_0x305e04,_0xd0d274){const _0x83dd13=_0x305e04['users'][0x0];m(_0x83dd13['localId']!==void 0x0,'internal-error');const _0x25d43d=_0x83dd13['providerUserInfo']!==void 0x0?Sa(_0x83dd13['providerUserInfo']):[],_0x2838d3=!(_0x83dd13['email']&&_0x83dd13['passwordHash'])&&!(_0x25d43d!=null&&_0x25d43d['length']),_0x3cf2bb=new et();_0x3cf2bb['updateFromIdToken'](_0xd0d274);const _0x3a9db1=new j({'uid':_0x83dd13['localId'],'auth':_0x547993,'stsTokenManager':_0x3cf2bb,'isAnonymous':_0x2838d3}),_0x4bfab8={'uid':_0x83dd13['localId'],'displayName':_0x83dd13['displayName']||null,'photoURL':_0x83dd13['photoUrl']||null,'email':_0x83dd13['email']||null,'emailVerified':_0x83dd13['emailVerified']||!0x1,'phoneNumber':_0x83dd13['phoneNumber']||null,'tenantId':_0x83dd13['tenantId']||null,'providerData':_0x25d43d,'metadata':new Li(_0x83dd13['createdAt'],_0x83dd13['lastLoginAt']),'isAnonymous':!(_0x83dd13['email']&&_0x83dd13['passwordHash'])&&!(_0x25d43d!=null&&_0x25d43d['length'])};return Object['assign'](_0x3a9db1,_0x4bfab8),_0x3a9db1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x394178){ce(_0x394178 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3a6718=Tr['get'](_0x394178);return _0x3a6718?(ce(_0x3a6718 instanceof _0x394178,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3a6718):(_0x3a6718=new _0x394178(),Tr['set'](_0x394178,_0x3a6718),_0x3a6718);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x1f8329,_0xa1d61c){this['storage'][_0x1f8329]=_0xa1d61c;}async['_get'](_0x2c1e6b){const _0x5eac98=this['storage'][_0x2c1e6b];return _0x5eac98===void 0x0?null:_0x5eac98;}async['_remove'](_0x2a706a){delete this['storage'][_0x2a706a];}['_addListener'](_0x3b8f53,_0x25a201){}['_removeListener'](_0x59c0ad,_0x26c52e){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x71cf07,_0x232274,_0x4d7aca){return'firebase:'+_0x71cf07+':'+_0x232274+':'+_0x4d7aca;}class tt{constructor(_0x2bfc78,_0xc7f4f6,_0x3a308f){this['persistence']=_0x2bfc78,this['auth']=_0xc7f4f6,this['userKey']=_0x3a308f;const {config:_0x3de1da,name:_0x560981}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x3de1da['apiKey'],_0x560981),this['fullPersistenceKey']=ln('persistence',_0x3de1da['apiKey'],_0x560981),this['boundEventHandler']=_0xc7f4f6['_onStorageEvent']['bind'](_0xc7f4f6),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x17dfb2){return this['persistence']['_set'](this['fullUserKey'],_0x17dfb2['toJSON']());}async['getCurrentUser'](){const _0x9d7271=await this['persistence']['_get'](this['fullUserKey']);if(!_0x9d7271)return null;if(typeof _0x9d7271=='string'){const _0x4b3993=await Pn(this['auth'],{'idToken':_0x9d7271})['catch'](()=>{});return _0x4b3993?j['_fromGetAccountInfoResponse'](this['auth'],_0x4b3993,_0x9d7271):null;}return j['_fromJSON'](this['auth'],_0x9d7271);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1cf9ce){if(this['persistence']===_0x1cf9ce)return;const _0x251d92=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1cf9ce,_0x251d92)return this['setCurrentUser'](_0x251d92);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x21a587,_0x236765,_0xdd4315='authUser'){if(!_0x236765['length'])return new tt(ie(Sr),_0x21a587,_0xdd4315);const _0x275d58=(await Promise['all'](_0x236765['map'](async _0x27a0fb=>{if(await _0x27a0fb['_isAvailable']())return _0x27a0fb;})))['filter'](_0x417535=>_0x417535);let _0x691aaf=_0x275d58[0x0]||ie(Sr);const _0x19179c=ln(_0xdd4315,_0x21a587['config']['apiKey'],_0x21a587['name']);let _0x3b5180=null;for(const _0x162a00 of _0x236765)try{const _0x5f4e11=await _0x162a00['_get'](_0x19179c);if(_0x5f4e11){let _0x235e37;if(typeof _0x5f4e11=='string'){const _0xb81578=await Pn(_0x21a587,{'idToken':_0x5f4e11})['catch'](()=>{});if(!_0xb81578)break;_0x235e37=await j['_fromGetAccountInfoResponse'](_0x21a587,_0xb81578,_0x5f4e11);}else _0x235e37=j['_fromJSON'](_0x21a587,_0x5f4e11);_0x162a00!==_0x691aaf&&(_0x3b5180=_0x235e37),_0x691aaf=_0x162a00;break;}}catch{}const _0x3f99c0=_0x275d58['filter'](_0x5dd299=>_0x5dd299['_shouldAllowMigration']);return!_0x691aaf['_shouldAllowMigration']||!_0x3f99c0['length']?new tt(_0x691aaf,_0x21a587,_0xdd4315):(_0x691aaf=_0x3f99c0[0x0],_0x3b5180&&await _0x691aaf['_set'](_0x19179c,_0x3b5180['toJSON']()),await Promise['all'](_0x236765['map'](async _0x3572bd=>{if(_0x3572bd!==_0x691aaf)try{await _0x3572bd['_remove'](_0x19179c);}catch{}})),new tt(_0x691aaf,_0x21a587,_0xdd4315));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x5af535){const _0x2a3604=_0x5af535['toLowerCase']();if(_0x2a3604['includes']('opera/')||_0x2a3604['includes']('opr/')||_0x2a3604['includes']('opios/'))return'Opera';if(Pa(_0x2a3604))return'IEMobile';if(_0x2a3604['includes']('msie')||_0x2a3604['includes']('trident/'))return'IE';if(_0x2a3604['includes']('edge/'))return'Edge';if(Ra(_0x2a3604))return'Firefox';if(_0x2a3604['includes']('silk/'))return'Silk';if(Oa(_0x2a3604))return'Blackberry';if(Da(_0x2a3604))return'Webos';if(Aa(_0x2a3604))return'Safari';if((_0x2a3604['includes']('chrome/')||ka(_0x2a3604))&&!_0x2a3604['includes']('edge/'))return'Chrome';if(Na(_0x2a3604))return'Android';{const _0x5975b5=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x20a5e1=_0x5af535['match'](_0x5975b5);if((_0x20a5e1==null?void 0x0:_0x20a5e1['length'])===0x2)return _0x20a5e1[0x1];}return'Other';}function Ra(_0x221131=W()){return/firefox\//i['test'](_0x221131);}function Aa(_0x246dde=W()){const _0x4680e3=_0x246dde['toLowerCase']();return _0x4680e3['includes']('safari/')&&!_0x4680e3['includes']('chrome/')&&!_0x4680e3['includes']('crios/')&&!_0x4680e3['includes']('android');}function ka(_0x5703a0=W()){return/crios\//i['test'](_0x5703a0);}function Pa(_0x515fc4=W()){return/iemobile/i['test'](_0x515fc4);}function Na(_0x1b07ec=W()){return/android/i['test'](_0x1b07ec);}function Oa(_0x378607=W()){return/blackberry/i['test'](_0x378607);}function Da(_0x5d8b66=W()){return/webos/i['test'](_0x5d8b66);}function Ss(_0x553426=W()){return/iphone|ipad|ipod/i['test'](_0x553426)||/macintosh/i['test'](_0x553426)&&/mobile/i['test'](_0x553426);}function Rf(_0x372e12=W()){var _0x194397;return Ss(_0x372e12)&&!!((_0x194397=window['navigator'])!=null&&_0x194397['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x48d188=W()){return Ss(_0x48d188)||Na(_0x48d188)||Da(_0x48d188)||Oa(_0x48d188)||/windows phone/i['test'](_0x48d188)||Pa(_0x48d188);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x5ca79f,_0x59973f=[]){let _0x227a00;switch(_0x5ca79f){case'Browser':_0x227a00=br(W());break;case'Worker':_0x227a00=br(W())+'-'+_0x5ca79f;break;default:_0x227a00=_0x5ca79f;}const _0x5799d9=_0x59973f['length']?_0x59973f['join'](','):'FirebaseCore-web';return _0x227a00+'/JsCore/'+dt+'/'+_0x5799d9;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x538363){this['auth']=_0x538363,this['queue']=[];}['pushCallback'](_0x26c588,_0x5005ad){const _0x19f866=_0x256a5c=>new Promise((_0x29024e,_0x58ce1a)=>{try{const _0x35d061=_0x26c588(_0x256a5c);_0x29024e(_0x35d061);}catch(_0x5e2b7b){_0x58ce1a(_0x5e2b7b);}});_0x19f866['onAbort']=_0x5005ad,this['queue']['push'](_0x19f866);const _0x2206e3=this['queue']['length']-0x1;return()=>{this['queue'][_0x2206e3]=()=>Promise['resolve']();};}async['runMiddleware'](_0x21e1c0){if(this['auth']['currentUser']===_0x21e1c0)return;const _0xb4b311=[];try{for(const _0x2458d9 of this['queue'])await _0x2458d9(_0x21e1c0),_0x2458d9['onAbort']&&_0xb4b311['push'](_0x2458d9['onAbort']);}catch(_0x249fad){_0xb4b311['reverse']();for(const _0x1ad63d of _0xb4b311)try{_0x1ad63d();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x249fad==null?void 0x0:_0x249fad['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0xb656b4,_0x4d029e={}){return Pe(_0xb656b4,'GET','/v2/passwordPolicy',ke(_0xb656b4,_0x4d029e));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x408ef6){var _0x78354b;const _0x101bb2=_0x408ef6['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x101bb2['minPasswordLength']??Nf,_0x101bb2['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x101bb2['maxPasswordLength']),_0x101bb2['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x101bb2['containsLowercaseCharacter']),_0x101bb2['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x101bb2['containsUppercaseCharacter']),_0x101bb2['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x101bb2['containsNumericCharacter']),_0x101bb2['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x101bb2['containsNonAlphanumericCharacter']),this['enforcementState']=_0x408ef6['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x78354b=_0x408ef6['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x78354b['join'](''))??'',this['forceUpgradeOnSignin']=_0x408ef6['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x408ef6['schemaVersion'];}['validatePassword'](_0x357695){const _0x28f785={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x357695,_0x28f785),this['validatePasswordCharacterOptions'](_0x357695,_0x28f785),_0x28f785['isValid']&&(_0x28f785['isValid']=_0x28f785['meetsMinPasswordLength']??!0x0),_0x28f785['isValid']&&(_0x28f785['isValid']=_0x28f785['meetsMaxPasswordLength']??!0x0),_0x28f785['isValid']&&(_0x28f785['isValid']=_0x28f785['containsLowercaseLetter']??!0x0),_0x28f785['isValid']&&(_0x28f785['isValid']=_0x28f785['containsUppercaseLetter']??!0x0),_0x28f785['isValid']&&(_0x28f785['isValid']=_0x28f785['containsNumericCharacter']??!0x0),_0x28f785['isValid']&&(_0x28f785['isValid']=_0x28f785['containsNonAlphanumericCharacter']??!0x0),_0x28f785;}['validatePasswordLengthOptions'](_0x56f65a,_0x35b033){const _0xd1383=this['customStrengthOptions']['minPasswordLength'],_0x1ff937=this['customStrengthOptions']['maxPasswordLength'];_0xd1383&&(_0x35b033['meetsMinPasswordLength']=_0x56f65a['length']>=_0xd1383),_0x1ff937&&(_0x35b033['meetsMaxPasswordLength']=_0x56f65a['length']<=_0x1ff937);}['validatePasswordCharacterOptions'](_0xfdf86d,_0x2026b1){this['updatePasswordCharacterOptionsStatuses'](_0x2026b1,!0x1,!0x1,!0x1,!0x1);let _0x4b491f;for(let _0x20ab26=0x0;_0x20ab26<_0xfdf86d['length'];_0x20ab26++)_0x4b491f=_0xfdf86d['charAt'](_0x20ab26),this['updatePasswordCharacterOptionsStatuses'](_0x2026b1,_0x4b491f>='a'&&_0x4b491f<='z',_0x4b491f>='A'&&_0x4b491f<='Z',_0x4b491f>='0'&&_0x4b491f<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x4b491f));}['updatePasswordCharacterOptionsStatuses'](_0x15f575,_0x57d0e5,_0x158a98,_0x1ba6c2,_0x22132b){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x15f575['containsLowercaseLetter']||(_0x15f575['containsLowercaseLetter']=_0x57d0e5)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x15f575['containsUppercaseLetter']||(_0x15f575['containsUppercaseLetter']=_0x158a98)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x15f575['containsNumericCharacter']||(_0x15f575['containsNumericCharacter']=_0x1ba6c2)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x15f575['containsNonAlphanumericCharacter']||(_0x15f575['containsNonAlphanumericCharacter']=_0x22132b));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x17588f,_0x2152c1,_0x4342f8,_0x53a57f){this['app']=_0x17588f,this['heartbeatServiceProvider']=_0x2152c1,this['appCheckServiceProvider']=_0x4342f8,this['config']=_0x53a57f,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x17588f['name'],this['clientVersion']=_0x53a57f['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5cc652=>this['_resolvePersistenceManagerAvailable']=_0x5cc652);}['_initializeWithPersistence'](_0x1f9dd7,_0x461c69){return _0x461c69&&(this['_popupRedirectResolver']=ie(_0x461c69)),this['_initializationPromise']=this['queue'](async()=>{var _0x236a4f,_0x987779,_0x59e0c7;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x1f9dd7),(_0x236a4f=this['_resolvePersistenceManagerAvailable'])==null||_0x236a4f['call'](this),!this['_deleted'])){if((_0x987779=this['_popupRedirectResolver'])!=null&&_0x987779['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x461c69),this['lastNotifiedUid']=((_0x59e0c7=this['currentUser'])==null?void 0x0:_0x59e0c7['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3c17ad=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3c17ad)){if(this['currentUser']&&_0x3c17ad&&this['currentUser']['uid']===_0x3c17ad['uid']){this['_currentUser']['_assign'](_0x3c17ad),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3c17ad,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4dddb){try{const _0x82e420=await Pn(this,{'idToken':_0x4dddb}),_0xb21d74=await j['_fromGetAccountInfoResponse'](this,_0x82e420,_0x4dddb);await this['directlySetCurrentUser'](_0xb21d74);}catch(_0x38ef2e){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x38ef2e),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x394489){var _0x52c44c;if($(this['app'])){const _0x201661=this['app']['settings']['authIdToken'];return _0x201661?new Promise(_0x35d8f1=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x201661)['then'](_0x35d8f1,_0x35d8f1));}):this['directlySetCurrentUser'](null);}const _0x34e6e4=await this['assertedPersistence']['getCurrentUser']();let _0xe5232a=_0x34e6e4,_0x456996=!0x1;if(_0x394489&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x14be87=(_0x52c44c=this['redirectUser'])==null?void 0x0:_0x52c44c['_redirectEventId'],_0x3f008f=_0xe5232a==null?void 0x0:_0xe5232a['_redirectEventId'],_0x72acf4=await this['tryRedirectSignIn'](_0x394489);(!_0x14be87||_0x14be87===_0x3f008f)&&(_0x72acf4!=null&&_0x72acf4['user'])&&(_0xe5232a=_0x72acf4['user'],_0x456996=!0x0);}if(!_0xe5232a)return this['directlySetCurrentUser'](null);if(!_0xe5232a['_redirectEventId']){if(_0x456996)try{await this['beforeStateQueue']['runMiddleware'](_0xe5232a);}catch(_0x1b49af){_0xe5232a=_0x34e6e4,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1b49af));}return _0xe5232a?this['reloadAndSetCurrentUserOrClear'](_0xe5232a):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0xe5232a['_redirectEventId']?this['directlySetCurrentUser'](_0xe5232a):this['reloadAndSetCurrentUserOrClear'](_0xe5232a);}async['tryRedirectSignIn'](_0x1bdecd){let _0x4a47bd=null;try{_0x4a47bd=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1bdecd,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4a47bd;}async['reloadAndSetCurrentUserOrClear'](_0x474e34){try{await Nn(_0x474e34);}catch(_0x3496bf){if((_0x3496bf==null?void 0x0:_0x3496bf['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x474e34);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x51781c){if($(this['app']))return Promise['reject'](re(this));const _0x38b361=_0x51781c?P(_0x51781c):null;return _0x38b361&&m(_0x38b361['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x38b361&&_0x38b361['_clone'](this));}async['_updateCurrentUser'](_0x3f3839,_0x1e0490=!0x1){if(!this['_deleted'])return _0x3f3839&&m(this['tenantId']===_0x3f3839['tenantId'],this,'tenant-id-mismatch'),_0x1e0490||await this['beforeStateQueue']['runMiddleware'](_0x3f3839),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x3f3839),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x5bcf03){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x5bcf03));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1fd22b){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x26b1bb=this['_getPasswordPolicyInternal']();return _0x26b1bb['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x26b1bb['validatePassword'](_0x1fd22b);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3129a1=await Pf(this),_0x4fbee9=new Of(_0x3129a1);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4fbee9:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4fbee9;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x187325){this['_errorFactory']=new Gt('auth','Firebase',_0x187325());}['onAuthStateChanged'](_0x661d8f,_0x2678fc,_0x51f7e5){return this['registerStateListener'](this['authStateSubscription'],_0x661d8f,_0x2678fc,_0x51f7e5);}['beforeAuthStateChanged'](_0x260dcb,_0x16a75a){return this['beforeStateQueue']['pushCallback'](_0x260dcb,_0x16a75a);}['onIdTokenChanged'](_0x46124c,_0x5769a1,_0x11d5d9){return this['registerStateListener'](this['idTokenSubscription'],_0x46124c,_0x5769a1,_0x11d5d9);}['authStateReady'](){return new Promise((_0x3c491c,_0x151df8)=>{if(this['currentUser'])_0x3c491c();else{const _0x599778=this['onAuthStateChanged'](()=>{_0x599778(),_0x3c491c();},_0x151df8);}});}async['revokeAccessToken'](_0x444195){if(this['currentUser']){const _0x1cccce=await this['currentUser']['getIdToken'](),_0x5670fa={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x444195,'idToken':_0x1cccce};this['tenantId']!=null&&(_0x5670fa['tenantId']=this['tenantId']),await bf(this,_0x5670fa);}}['toJSON'](){var _0xf6127f;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xf6127f=this['_currentUser'])==null?void 0x0:_0xf6127f['toJSON']()};}async['_setRedirectUser'](_0x3d57c8,_0x3bc290){const _0x3abab7=await this['getOrInitRedirectPersistenceManager'](_0x3bc290);return _0x3d57c8===null?_0x3abab7['removeCurrentUser']():_0x3abab7['setCurrentUser'](_0x3d57c8);}async['getOrInitRedirectPersistenceManager'](_0x59e52e){if(!this['redirectPersistenceManager']){const _0x1a53d2=_0x59e52e&&ie(_0x59e52e)||this['_popupRedirectResolver'];m(_0x1a53d2,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x1a53d2['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x307972){var _0x4640d5,_0x262625;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4640d5=this['_currentUser'])==null?void 0x0:_0x4640d5['_redirectEventId'])===_0x307972?this['_currentUser']:((_0x262625=this['redirectUser'])==null?void 0x0:_0x262625['_redirectEventId'])===_0x307972?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x154ff1){if(_0x154ff1===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x154ff1));}['_notifyListenersIfCurrent'](_0x1316e9){_0x1316e9===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x47b14c;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x19e44f=((_0x47b14c=this['currentUser'])==null?void 0x0:_0x47b14c['uid'])??null;this['lastNotifiedUid']!==_0x19e44f&&(this['lastNotifiedUid']=_0x19e44f,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x5b579d,_0x4b6606,_0x1703b5,_0x5e5410){if(this['_deleted'])return()=>{};const _0x293c0f=typeof _0x4b6606=='function'?_0x4b6606:_0x4b6606['next']['bind'](_0x4b6606);let _0x2c945c=!0x1;const _0x11a590=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x11a590,this,'internal-error'),_0x11a590['then'](()=>{_0x2c945c||_0x293c0f(this['currentUser']);}),typeof _0x4b6606=='function'){const _0x4cf800=_0x5b579d['addObserver'](_0x4b6606,_0x1703b5,_0x5e5410);return()=>{_0x2c945c=!0x0,_0x4cf800();};}else{const _0x37b110=_0x5b579d['addObserver'](_0x4b6606);return()=>{_0x2c945c=!0x0,_0x37b110();};}}async['directlySetCurrentUser'](_0x3842f4){this['currentUser']&&this['currentUser']!==_0x3842f4&&this['_currentUser']['_stopProactiveRefresh'](),_0x3842f4&&this['isProactiveRefreshEnabled']&&_0x3842f4['_startProactiveRefresh'](),this['currentUser']=_0x3842f4,_0x3842f4?await this['assertedPersistence']['setCurrentUser'](_0x3842f4):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4fef39){return this['operations']=this['operations']['then'](_0x4fef39,_0x4fef39),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x43016e){!_0x43016e||this['frameworks']['includes'](_0x43016e)||(this['frameworks']['push'](_0x43016e),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x17bb2e;const _0x4c380d={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4c380d['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x2df0ce=await((_0x17bb2e=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x17bb2e['getHeartbeatsHeader']());_0x2df0ce&&(_0x4c380d['X-Firebase-Client']=_0x2df0ce);const _0x1ffdfe=await this['_getAppCheckToken']();return _0x1ffdfe&&(_0x4c380d['X-Firebase-AppCheck']=_0x1ffdfe),_0x4c380d;}async['_getAppCheckToken'](){var _0x1ea009;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5607a3=await((_0x1ea009=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1ea009['getToken']());return _0x5607a3!=null&&_0x5607a3['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5607a3['error']),_0x5607a3==null?void 0x0:_0x5607a3['token'];}}function Ke(_0x1a81c6){return P(_0x1a81c6);}class Rr{constructor(_0xc281cc){this['auth']=_0xc281cc,this['observer']=null,this['addObserver']=Tc(_0x269122=>this['observer']=_0x269122);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0xa84482){Jn=_0xa84482;}function xa(_0x589245){return Jn['loadJS'](_0x589245);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x1f6ed0){return'__'+_0x1f6ed0+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x320720){_0x320720();}['execute'](_0x48634e,_0x478deb){return Promise['resolve']('token');}['render'](_0x59b1ac,_0x557832){return'';}}class Wf{['ready'](_0x2384dd){_0x2384dd();}['execute'](_0x3c268b,_0x53496c){return Promise['resolve']('token');}['render'](_0xafcae5,_0x1f2ae6){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x52a29f){this['type']=Bf,this['auth']=Ke(_0x52a29f);}async['verify'](_0x204195='verify',_0x5cc635=!0x1){async function _0x22aa69(_0x46329a){if(!_0x5cc635){if(_0x46329a['tenantId']==null&&_0x46329a['_agentRecaptchaConfig']!=null)return _0x46329a['_agentRecaptchaConfig']['siteKey'];if(_0x46329a['tenantId']!=null&&_0x46329a['_tenantRecaptchaConfigs'][_0x46329a['tenantId']]!==void 0x0)return _0x46329a['_tenantRecaptchaConfigs'][_0x46329a['tenantId']]['siteKey'];}return new Promise(async(_0x25d689,_0x3726d7)=>{yf(_0x46329a,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x580245=>{if(_0x580245['recaptchaKey']===void 0x0)_0x3726d7(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x35639a=new mf(_0x580245);return _0x46329a['tenantId']==null?_0x46329a['_agentRecaptchaConfig']=_0x35639a:_0x46329a['_tenantRecaptchaConfigs'][_0x46329a['tenantId']]=_0x35639a,_0x25d689(_0x35639a['siteKey']);}})['catch'](_0x3cf403=>{_0x3726d7(_0x3cf403);});});}function _0xcb09d6(_0x2b2346,_0x464b8c,_0x587dd2){const _0x4ecfa8=window['grecaptcha'];wr(_0x4ecfa8)?_0x4ecfa8['enterprise']['ready'](()=>{_0x4ecfa8['enterprise']['execute'](_0x2b2346,{'action':_0x204195})['then'](_0x5c875a=>{_0x464b8c(_0x5c875a);})['catch'](()=>{_0x464b8c(Fa);});}):_0x587dd2(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0xaeee30,_0x532136)=>{_0x22aa69(this['auth'])['then'](async _0x2441d2=>{if(!_0x5cc635&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0xcb09d6(_0x2441d2,_0xaeee30,_0x532136);else{if(typeof window>'u'){_0x532136(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x12dcf4=Lf();_0x12dcf4['length']!==0x0&&(_0x12dcf4+=_0x2441d2+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x213e56;(_0x213e56=he['scriptInjectionDeferred'])==null||_0x213e56['resolve']();},xa(_0x12dcf4)['then'](()=>{var _0x1d2a16;return(_0x1d2a16=he['scriptInjectionDeferred'])==null?void 0x0:_0x1d2a16['promise'];})['then'](()=>{_0xcb09d6(_0x2441d2,_0xaeee30,_0x532136);})['catch'](_0x609736=>{_0x532136(_0x609736);});}})['catch'](_0xe2d2fa=>{_0x532136(_0xe2d2fa);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x36604d,_0x269f2e,_0x1fc5ec,_0xa69906=!0x1,_0xec6754=!0x1){const _0x962092=new he(_0x36604d);let _0x18e6c0;if(_0xec6754)_0x18e6c0=Fa;else try{_0x18e6c0=await _0x962092['verify'](_0x1fc5ec);}catch{_0x18e6c0=await _0x962092['verify'](_0x1fc5ec,!0x0);}const _0x2a6612={..._0x269f2e};if(_0x1fc5ec==='mfaSmsEnrollment'||_0x1fc5ec==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x2a6612){const _0x489d92=_0x2a6612['phoneEnrollmentInfo']['phoneNumber'],_0x36b042=_0x2a6612['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x2a6612,{'phoneEnrollmentInfo':{'phoneNumber':_0x489d92,'recaptchaToken':_0x36b042,'captchaResponse':_0x18e6c0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x2a6612){const _0x1ff4e7=_0x2a6612['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x2a6612,{'phoneSignInInfo':{'recaptchaToken':_0x1ff4e7,'captchaResponse':_0x18e6c0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x2a6612;}return _0xa69906?Object['assign'](_0x2a6612,{'captchaResp':_0x18e6c0}):Object['assign'](_0x2a6612,{'captchaResponse':_0x18e6c0}),Object['assign'](_0x2a6612,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x2a6612,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x2a6612;}async function xi(_0x17c63f,_0x39bca5,_0x4aecc6,_0x478291,_0x2ab667){var _0x3e72ac;if((_0x3e72ac=_0x17c63f['_getRecaptchaConfig']())!=null&&_0x3e72ac['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xaf43a9=await kr(_0x17c63f,_0x39bca5,_0x4aecc6,_0x4aecc6==='getOobCode');return _0x478291(_0x17c63f,_0xaf43a9);}else return _0x478291(_0x17c63f,_0x39bca5)['catch'](async _0x4189f8=>{if(_0x4189f8['code']==='auth/missing-recaptcha-token'){console['log'](_0x4aecc6+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1a50ae=await kr(_0x17c63f,_0x39bca5,_0x4aecc6,_0x4aecc6==='getOobCode');return _0x478291(_0x17c63f,_0x1a50ae);}else return Promise['reject'](_0x4189f8);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x748832,_0xdbceb){const _0x31389e=Hi(_0x748832,'auth');if(_0x31389e['isInitialized']()){const _0x726912=_0x31389e['getImmediate'](),_0x4f9829=_0x31389e['getOptions']();if(xe(_0x4f9829,_0xdbceb??{}))return _0x726912;Y(_0x726912,'already-initialized');}return _0x31389e['initialize']({'options':_0xdbceb});}function Hf(_0x4a9515,_0x3447e5){const _0x4068c5=(_0x3447e5==null?void 0x0:_0x3447e5['persistence'])||[],_0x23d6b7=(Array['isArray'](_0x4068c5)?_0x4068c5:[_0x4068c5])['map'](ie);_0x3447e5!=null&&_0x3447e5['errorMap']&&_0x4a9515['_updateErrorMap'](_0x3447e5['errorMap']),_0x4a9515['_initializeWithPersistence'](_0x23d6b7,_0x3447e5==null?void 0x0:_0x3447e5['popupRedirectResolver']);}function $f(_0x1e035b,_0x11dd4e,_0x4534a4){const _0x303991=Ke(_0x1e035b);m(/^https?:\/\//['test'](_0x11dd4e),_0x303991,'invalid-emulator-scheme');const _0x449bd0=!0x1,_0x4610da=Ua(_0x11dd4e),{host:_0x27fadc,port:_0x10a775}=Gf(_0x11dd4e),_0x5d62cc=_0x10a775===null?'':':'+_0x10a775,_0x181e21={'url':_0x4610da+'//'+_0x27fadc+_0x5d62cc+'/'},_0x567ff=Object['freeze']({'host':_0x27fadc,'port':_0x10a775,'protocol':_0x4610da['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x449bd0})});if(!_0x303991['_canInitEmulator']){m(_0x303991['config']['emulator']&&_0x303991['emulatorConfig'],_0x303991,'emulator-config-failed'),m(xe(_0x181e21,_0x303991['config']['emulator'])&&xe(_0x567ff,_0x303991['emulatorConfig']),_0x303991,'emulator-config-failed');return;}_0x303991['config']['emulator']=_0x181e21,_0x303991['emulatorConfig']=_0x567ff,_0x303991['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x27fadc)?Qr(_0x4610da+'//'+_0x27fadc+_0x5d62cc):qf();}function Ua(_0x2c8097){const _0x4c9d90=_0x2c8097['indexOf'](':');return _0x4c9d90<0x0?'':_0x2c8097['substr'](0x0,_0x4c9d90+0x1);}function Gf(_0xc8ea2e){const _0x3f7932=Ua(_0xc8ea2e),_0x333ae7=/(\/\/)?([^?#/]+)/['exec'](_0xc8ea2e['substr'](_0x3f7932['length']));if(!_0x333ae7)return{'host':'','port':null};const _0x562bf4=_0x333ae7[0x2]['split']('@')['pop']()||'',_0x552ce5=/^(\[[^\]]+\])(:|$)/['exec'](_0x562bf4);if(_0x552ce5){const _0x23d578=_0x552ce5[0x1];return{'host':_0x23d578,'port':Pr(_0x562bf4['substr'](_0x23d578['length']+0x1))};}else{const [_0xa88069,_0x3ea441]=_0x562bf4['split'](':');return{'host':_0xa88069,'port':Pr(_0x3ea441)};}}function Pr(_0x2d265f){if(!_0x2d265f)return null;const _0x21eca7=Number(_0x2d265f);return isNaN(_0x21eca7)?null:_0x21eca7;}function qf(){function _0x42d071(){const _0x12b416=document['createElement']('p'),_0x5b0ffa=_0x12b416['style'];_0x12b416['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5b0ffa['position']='fixed',_0x5b0ffa['width']='100%',_0x5b0ffa['backgroundColor']='#ffffff',_0x5b0ffa['border']='.1em\x20solid\x20#000000',_0x5b0ffa['color']='#b50000',_0x5b0ffa['bottom']='0px',_0x5b0ffa['left']='0px',_0x5b0ffa['margin']='0px',_0x5b0ffa['zIndex']='10000',_0x5b0ffa['textAlign']='center',_0x12b416['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x12b416);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x42d071):_0x42d071());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x1f063b,_0x4d8e72){this['providerId']=_0x1f063b,this['signInMethod']=_0x4d8e72;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3c77d1){return ne('not\x20implemented');}['_linkToIdToken'](_0x5ac8e6,_0x875149){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xf95edf){return ne('not\x20implemented');}}async function zf(_0x52db78,_0x298385){return Pe(_0x52db78,'POST','/v1/accounts:signUp',_0x298385);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x15e911,_0x443bf9){return en(_0x15e911,'POST','/v1/accounts:signInWithPassword',ke(_0x15e911,_0x443bf9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x4b5544,_0x4e5a04){return en(_0x4b5544,'POST','/v1/accounts:signInWithEmailLink',ke(_0x4b5544,_0x4e5a04));}async function Yf(_0x386359,_0x123e8f){return en(_0x386359,'POST','/v1/accounts:signInWithEmailLink',ke(_0x386359,_0x123e8f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x1d8ecf,_0x47cea4,_0x52211d,_0x58a847=null){super('password',_0x52211d),this['_email']=_0x1d8ecf,this['_password']=_0x47cea4,this['_tenantId']=_0x58a847;}static['_fromEmailAndPassword'](_0x14dddb,_0x135e85){return new $t(_0x14dddb,_0x135e85,'password');}static['_fromEmailAndCode'](_0x103489,_0x55d108,_0x2aad7d=null){return new $t(_0x103489,_0x55d108,'emailLink',_0x2aad7d);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3c41a1){const _0xc5154c=typeof _0x3c41a1=='string'?JSON['parse'](_0x3c41a1):_0x3c41a1;if(_0xc5154c!=null&&_0xc5154c['email']&&(_0xc5154c!=null&&_0xc5154c['password'])){if(_0xc5154c['signInMethod']==='password')return this['_fromEmailAndPassword'](_0xc5154c['email'],_0xc5154c['password']);if(_0xc5154c['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0xc5154c['email'],_0xc5154c['password'],_0xc5154c['tenantId']);}return null;}async['_getIdTokenResponse'](_0x497140){switch(this['signInMethod']){case'password':const _0x3e53d2={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x497140,_0x3e53d2,'signInWithPassword',jf);case'emailLink':return Kf(_0x497140,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x497140,'internal-error');}}async['_linkToIdToken'](_0x69abb1,_0x2a8350){switch(this['signInMethod']){case'password':const _0xfae106={'idToken':_0x2a8350,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x69abb1,_0xfae106,'signUpPassword',zf);case'emailLink':return Yf(_0x69abb1,{'idToken':_0x2a8350,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x69abb1,'internal-error');}}['_getReauthenticationResolver'](_0x149e1c){return this['_getIdTokenResponse'](_0x149e1c);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x106bd8,_0x3e7ea4){return en(_0x106bd8,'POST','/v1/accounts:signInWithIdp',ke(_0x106bd8,_0x3e7ea4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x230f53){const _0x446ced=new $e(_0x230f53['providerId'],_0x230f53['signInMethod']);return _0x230f53['idToken']||_0x230f53['accessToken']?(_0x230f53['idToken']&&(_0x446ced['idToken']=_0x230f53['idToken']),_0x230f53['accessToken']&&(_0x446ced['accessToken']=_0x230f53['accessToken']),_0x230f53['nonce']&&!_0x230f53['pendingToken']&&(_0x446ced['nonce']=_0x230f53['nonce']),_0x230f53['pendingToken']&&(_0x446ced['pendingToken']=_0x230f53['pendingToken'])):_0x230f53['oauthToken']&&_0x230f53['oauthTokenSecret']?(_0x446ced['accessToken']=_0x230f53['oauthToken'],_0x446ced['secret']=_0x230f53['oauthTokenSecret']):Y('argument-error'),_0x446ced;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x169d8d){const _0x4fb21f=typeof _0x169d8d=='string'?JSON['parse'](_0x169d8d):_0x169d8d,{providerId:_0x5c4581,signInMethod:_0x19dfcb,..._0x56c5f5}=_0x4fb21f;if(!_0x5c4581||!_0x19dfcb)return null;const _0x59229d=new $e(_0x5c4581,_0x19dfcb);return _0x59229d['idToken']=_0x56c5f5['idToken']||void 0x0,_0x59229d['accessToken']=_0x56c5f5['accessToken']||void 0x0,_0x59229d['secret']=_0x56c5f5['secret'],_0x59229d['nonce']=_0x56c5f5['nonce'],_0x59229d['pendingToken']=_0x56c5f5['pendingToken']||null,_0x59229d;}['_getIdTokenResponse'](_0x1a80d6){const _0xc45c42=this['buildRequest']();return nt(_0x1a80d6,_0xc45c42);}['_linkToIdToken'](_0x1fdd97,_0xbcc2ac){const _0x392977=this['buildRequest']();return _0x392977['idToken']=_0xbcc2ac,nt(_0x1fdd97,_0x392977);}['_getReauthenticationResolver'](_0x50f561){const _0x49abc9=this['buildRequest']();return _0x49abc9['autoCreate']=!0x1,nt(_0x50f561,_0x49abc9);}['buildRequest'](){const _0x103272={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x103272['pendingToken']=this['pendingToken'];else{const _0x1403c2={};this['idToken']&&(_0x1403c2['id_token']=this['idToken']),this['accessToken']&&(_0x1403c2['access_token']=this['accessToken']),this['secret']&&(_0x1403c2['oauth_token_secret']=this['secret']),_0x1403c2['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x1403c2['nonce']=this['nonce']),_0x103272['postBody']=ut(_0x1403c2);}return _0x103272;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x158859){switch(_0x158859){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x3afd19){const _0x6231af=Ct(Tt(_0x3afd19))['link'],_0x2e62fd=_0x6231af?Ct(Tt(_0x6231af))['deep_link_id']:null,_0x7f64ce=Ct(Tt(_0x3afd19))['deep_link_id'];return(_0x7f64ce?Ct(Tt(_0x7f64ce))['link']:null)||_0x7f64ce||_0x2e62fd||_0x6231af||_0x3afd19;}class Rs{constructor(_0x86090f){const _0x193099=Ct(Tt(_0x86090f)),_0x1ee3c4=_0x193099['apiKey']??null,_0x2e90fe=_0x193099['oobCode']??null,_0x32e83a=Jf(_0x193099['mode']??null);m(_0x1ee3c4&&_0x2e90fe&&_0x32e83a,'argument-error'),this['apiKey']=_0x1ee3c4,this['operation']=_0x32e83a,this['code']=_0x2e90fe,this['continueUrl']=_0x193099['continueUrl']??null,this['languageCode']=_0x193099['lang']??null,this['tenantId']=_0x193099['tenantId']??null;}static['parseLink'](_0x1574b8){const _0x544fb5=Xf(_0x1574b8);try{return new Rs(_0x544fb5);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x191ae2,_0x4313b2){return $t['_fromEmailAndPassword'](_0x191ae2,_0x4313b2);}static['credentialWithLink'](_0x44f21f,_0x8b654e){const _0x20b5eb=Rs['parseLink'](_0x8b654e);return m(_0x20b5eb,'argument-error'),$t['_fromEmailAndCode'](_0x44f21f,_0x20b5eb['code'],_0x20b5eb['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x56bea3){this['providerId']=_0x56bea3,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1d7fca){this['defaultLanguageCode']=_0x1d7fca;}['setCustomParameters'](_0x5f496e){return this['customParameters']=_0x5f496e,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x277e90){return this['scopes']['includes'](_0x277e90)||this['scopes']['push'](_0x277e90),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2738ed){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2738ed});}static['credentialFromResult'](_0x278d5c){return ue['credentialFromTaggedObject'](_0x278d5c);}static['credentialFromError'](_0x24af0c){return ue['credentialFromTaggedObject'](_0x24af0c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x37c272}){if(!_0x37c272||!('oauthAccessToken'in _0x37c272)||!_0x37c272['oauthAccessToken'])return null;try{return ue['credential'](_0x37c272['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xc15b9f,_0x1b1cca){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xc15b9f,'accessToken':_0x1b1cca});}static['credentialFromResult'](_0x4f3a25){return de['credentialFromTaggedObject'](_0x4f3a25);}static['credentialFromError'](_0x462633){return de['credentialFromTaggedObject'](_0x462633['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3fa865}){if(!_0x3fa865)return null;const {oauthIdToken:_0x572dc0,oauthAccessToken:_0x3eb4e1}=_0x3fa865;if(!_0x572dc0&&!_0x3eb4e1)return null;try{return de['credential'](_0x572dc0,_0x3eb4e1);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x34205a){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x34205a});}static['credentialFromResult'](_0x1141d8){return fe['credentialFromTaggedObject'](_0x1141d8);}static['credentialFromError'](_0x29beda){return fe['credentialFromTaggedObject'](_0x29beda['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3eaa4b}){if(!_0x3eaa4b||!('oauthAccessToken'in _0x3eaa4b)||!_0x3eaa4b['oauthAccessToken'])return null;try{return fe['credential'](_0x3eaa4b['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x15db61,_0x29f78b){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x15db61,'oauthTokenSecret':_0x29f78b});}static['credentialFromResult'](_0x26bdd7){return pe['credentialFromTaggedObject'](_0x26bdd7);}static['credentialFromError'](_0x33a8b5){return pe['credentialFromTaggedObject'](_0x33a8b5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1b6b1e}){if(!_0x1b6b1e)return null;const {oauthAccessToken:_0x596eb7,oauthTokenSecret:_0x4e11cf}=_0x1b6b1e;if(!_0x596eb7||!_0x4e11cf)return null;try{return pe['credential'](_0x596eb7,_0x4e11cf);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x2ea848,_0x1362fb){return en(_0x2ea848,'POST','/v1/accounts:signUp',ke(_0x2ea848,_0x1362fb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x5af809){this['user']=_0x5af809['user'],this['providerId']=_0x5af809['providerId'],this['_tokenResponse']=_0x5af809['_tokenResponse'],this['operationType']=_0x5af809['operationType'];}static async['_fromIdTokenResponse'](_0x139ff6,_0x1579ab,_0x5904e5,_0x5ef39d=!0x1){const _0x51b262=await j['_fromIdTokenResponse'](_0x139ff6,_0x5904e5,_0x5ef39d),_0x23ead1=Nr(_0x5904e5);return new Ge({'user':_0x51b262,'providerId':_0x23ead1,'_tokenResponse':_0x5904e5,'operationType':_0x1579ab});}static async['_forOperation'](_0x5cfd86,_0x2d2796,_0x540b2e){await _0x5cfd86['_updateTokensIfNecessary'](_0x540b2e,!0x0);const _0x4f8a22=Nr(_0x540b2e);return new Ge({'user':_0x5cfd86,'providerId':_0x4f8a22,'_tokenResponse':_0x540b2e,'operationType':_0x2d2796});}}function Nr(_0x56ed98){return _0x56ed98['providerId']?_0x56ed98['providerId']:'phoneNumber'in _0x56ed98?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x9b54d9,_0x185ef2,_0x570b7e,_0x55a93d){super(_0x185ef2['code'],_0x185ef2['message']),this['operationType']=_0x570b7e,this['user']=_0x55a93d,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x9b54d9['name'],'tenantId':_0x9b54d9['tenantId']??void 0x0,'_serverResponse':_0x185ef2['customData']['_serverResponse'],'operationType':_0x570b7e};}static['_fromErrorAndOperation'](_0x16a5cb,_0x16c805,_0x5b2012,_0x539635){return new On(_0x16a5cb,_0x16c805,_0x5b2012,_0x539635);}}function Ba(_0x511db3,_0x185811,_0x3eed63,_0x3bb7ef){return(_0x185811==='reauthenticate'?_0x3eed63['_getReauthenticationResolver'](_0x511db3):_0x3eed63['_getIdTokenResponse'](_0x511db3))['catch'](_0xf09fd2=>{throw _0xf09fd2['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x511db3,_0xf09fd2,_0x185811,_0x3bb7ef):_0xf09fd2;});}async function ep(_0x5c854e,_0x46442e,_0x1d3fc2=!0x1){const _0x18aa2a=await Ht(_0x5c854e,_0x46442e['_linkToIdToken'](_0x5c854e['auth'],await _0x5c854e['getIdToken']()),_0x1d3fc2);return Ge['_forOperation'](_0x5c854e,'link',_0x18aa2a);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x48a0f9,_0x29424c,_0x5b6d7e=!0x1){const {auth:_0x44bf00}=_0x48a0f9;if($(_0x44bf00['app']))return Promise['reject'](re(_0x44bf00));const _0x40591a='reauthenticate';try{const _0x33ca47=await Ht(_0x48a0f9,Ba(_0x44bf00,_0x40591a,_0x29424c,_0x48a0f9),_0x5b6d7e);m(_0x33ca47['idToken'],_0x44bf00,'internal-error');const _0x503b1a=Ts(_0x33ca47['idToken']);m(_0x503b1a,_0x44bf00,'internal-error');const {sub:_0x590c1d}=_0x503b1a;return m(_0x48a0f9['uid']===_0x590c1d,_0x44bf00,'user-mismatch'),Ge['_forOperation'](_0x48a0f9,_0x40591a,_0x33ca47);}catch(_0xd23a1b){throw(_0xd23a1b==null?void 0x0:_0xd23a1b['code'])==='auth/user-not-found'&&Y(_0x44bf00,'user-mismatch'),_0xd23a1b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x1361ac,_0x4daf10,_0x340847=!0x1){if($(_0x1361ac['app']))return Promise['reject'](re(_0x1361ac));const _0x11bca3='signIn',_0x4bc017=await Ba(_0x1361ac,_0x11bca3,_0x4daf10),_0x39b693=await Ge['_fromIdTokenResponse'](_0x1361ac,_0x11bca3,_0x4bc017);return _0x340847||await _0x1361ac['_updateCurrentUser'](_0x39b693['user']),_0x39b693;}async function np(_0x48018e,_0x4d65e5){return Va(Ke(_0x48018e),_0x4d65e5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x31416c){const _0x545de6=Ke(_0x31416c);_0x545de6['_getPasswordPolicyInternal']()&&await _0x545de6['_updatePasswordPolicy']();}async function L_(_0x10ff1b,_0x3109d9,_0x1a8ded){if($(_0x10ff1b['app']))return Promise['reject'](re(_0x10ff1b));const _0x2208f4=Ke(_0x10ff1b),_0x4e4592=await xi(_0x2208f4,{'returnSecureToken':!0x0,'email':_0x3109d9,'password':_0x1a8ded,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x260709=>{throw _0x260709['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x10ff1b),_0x260709;}),_0x384d92=await Ge['_fromIdTokenResponse'](_0x2208f4,'signIn',_0x4e4592);return await _0x2208f4['_updateCurrentUser'](_0x384d92['user']),_0x384d92;}function x_(_0x5cbb73,_0x40e4c1,_0x190dd5){return $(_0x5cbb73['app'])?Promise['reject'](re(_0x5cbb73)):np(P(_0x5cbb73),yt['credential'](_0x40e4c1,_0x190dd5))['catch'](async _0x52e504=>{throw _0x52e504['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5cbb73),_0x52e504;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x1657c2,_0x3074a2){return P(_0x1657c2)['setPersistence'](_0x3074a2);}function ip(_0x324c38,_0x52fd89,_0x89e79a,_0x580eaf){return P(_0x324c38)['onIdTokenChanged'](_0x52fd89,_0x89e79a,_0x580eaf);}function sp(_0x42abbd,_0x4775f8,_0x4a706f){return P(_0x42abbd)['beforeAuthStateChanged'](_0x4775f8,_0x4a706f);}function U_(_0x53e710,_0x532778,_0x56edd5,_0x4f2325){return P(_0x53e710)['onAuthStateChanged'](_0x532778,_0x56edd5,_0x4f2325);}function W_(_0x23b18c){return P(_0x23b18c)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x27c633,_0x1bb52b){this['storageRetriever']=_0x27c633,this['type']=_0x1bb52b;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3a83d3,_0x519c65){return this['storage']['setItem'](_0x3a83d3,JSON['stringify'](_0x519c65)),Promise['resolve']();}['_get'](_0x27dbe6){const _0x5919a0=this['storage']['getItem'](_0x27dbe6);return Promise['resolve'](_0x5919a0?JSON['parse'](_0x5919a0):null);}['_remove'](_0x481960){return this['storage']['removeItem'](_0x481960),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x46fbc2,_0x3473bc)=>this['onStorageEvent'](_0x46fbc2,_0x3473bc),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xaea607){for(const _0x5801f5 of Object['keys'](this['listeners'])){const _0x2f4550=this['storage']['getItem'](_0x5801f5),_0x137e3d=this['localCache'][_0x5801f5];_0x2f4550!==_0x137e3d&&_0xaea607(_0x5801f5,_0x137e3d,_0x2f4550);}}['onStorageEvent'](_0x1e5c2f,_0x49d8aa=!0x1){if(!_0x1e5c2f['key']){this['forAllChangedKeys']((_0x45ccfa,_0x3e751e,_0x3c3c1a)=>{this['notifyListeners'](_0x45ccfa,_0x3c3c1a);});return;}const _0x14f9a0=_0x1e5c2f['key'];_0x49d8aa?this['detachListener']():this['stopPolling']();const _0x1a637f=()=>{const _0x20e2da=this['storage']['getItem'](_0x14f9a0);!_0x49d8aa&&this['localCache'][_0x14f9a0]===_0x20e2da||this['notifyListeners'](_0x14f9a0,_0x20e2da);},_0x4af3ea=this['storage']['getItem'](_0x14f9a0);Af()&&_0x4af3ea!==_0x1e5c2f['newValue']&&_0x1e5c2f['newValue']!==_0x1e5c2f['oldValue']?setTimeout(_0x1a637f,op):_0x1a637f();}['notifyListeners'](_0x1b7211,_0x3a8856){this['localCache'][_0x1b7211]=_0x3a8856;const _0x1357e3=this['listeners'][_0x1b7211];if(_0x1357e3){for(const _0x2a7566 of Array['from'](_0x1357e3))_0x2a7566(_0x3a8856&&JSON['parse'](_0x3a8856));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3ddd5d,_0x1ac2be,_0x3b81d2)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3ddd5d,'oldValue':_0x1ac2be,'newValue':_0x3b81d2}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x155c86,_0x3d8c14){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x155c86]||(this['listeners'][_0x155c86]=new Set(),this['localCache'][_0x155c86]=this['storage']['getItem'](_0x155c86)),this['listeners'][_0x155c86]['add'](_0x3d8c14);}['_removeListener'](_0x14d04f,_0x1806a0){this['listeners'][_0x14d04f]&&(this['listeners'][_0x14d04f]['delete'](_0x1806a0),this['listeners'][_0x14d04f]['size']===0x0&&delete this['listeners'][_0x14d04f]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x9fc8be,_0x33c9bf){await super['_set'](_0x9fc8be,_0x33c9bf),this['localCache'][_0x9fc8be]=JSON['stringify'](_0x33c9bf);}async['_get'](_0x39ef5b){const _0x279169=await super['_get'](_0x39ef5b);return this['localCache'][_0x39ef5b]=JSON['stringify'](_0x279169),_0x279169;}async['_remove'](_0x29d2f5){await super['_remove'](_0x29d2f5),delete this['localCache'][_0x29d2f5];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x267d50,_0xf9385e){}['_removeListener'](_0x433a49,_0x2d9ff9){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x1be57b){return Promise['all'](_0x1be57b['map'](async _0x1795e3=>{try{return{'fulfilled':!0x0,'value':await _0x1795e3};}catch(_0x136b0a){return{'fulfilled':!0x1,'reason':_0x136b0a};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x851407){this['eventTarget']=_0x851407,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x305e19){const _0x1abdbc=this['receivers']['find'](_0x40d4ce=>_0x40d4ce['isListeningto'](_0x305e19));if(_0x1abdbc)return _0x1abdbc;const _0x14d3ff=new Xn(_0x305e19);return this['receivers']['push'](_0x14d3ff),_0x14d3ff;}['isListeningto'](_0x5516fb){return this['eventTarget']===_0x5516fb;}async['handleEvent'](_0x5dcf5d){const _0x48d088=_0x5dcf5d,{eventId:_0x4872c7,eventType:_0x3b912f,data:_0x3eaa80}=_0x48d088['data'],_0x51c869=this['handlersMap'][_0x3b912f];if(!(_0x51c869!=null&&_0x51c869['size']))return;_0x48d088['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4872c7,'eventType':_0x3b912f});const _0x1c3cee=Array['from'](_0x51c869)['map'](async _0x484ffb=>_0x484ffb(_0x48d088['origin'],_0x3eaa80)),_0xe7c97=await cp(_0x1c3cee);_0x48d088['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4872c7,'eventType':_0x3b912f,'response':_0xe7c97});}['_subscribe'](_0x4ecfe9,_0xd665e0){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x4ecfe9]||(this['handlersMap'][_0x4ecfe9]=new Set()),this['handlersMap'][_0x4ecfe9]['add'](_0xd665e0);}['_unsubscribe'](_0x4390fa,_0x1c108c){this['handlersMap'][_0x4390fa]&&_0x1c108c&&this['handlersMap'][_0x4390fa]['delete'](_0x1c108c),(!_0x1c108c||this['handlersMap'][_0x4390fa]['size']===0x0)&&delete this['handlersMap'][_0x4390fa],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x592efd='',_0x567632=0xa){let _0x2ebccc='';for(let _0x5c635a=0x0;_0x5c635a<_0x567632;_0x5c635a++)_0x2ebccc+=Math['floor'](Math['random']()*0xa);return _0x592efd+_0x2ebccc;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x5051e6){this['target']=_0x5051e6,this['handlers']=new Set();}['removeMessageHandler'](_0x4ccfcd){_0x4ccfcd['messageChannel']&&(_0x4ccfcd['messageChannel']['port1']['removeEventListener']('message',_0x4ccfcd['onMessage']),_0x4ccfcd['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4ccfcd);}async['_send'](_0x2a8bcd,_0x214e81,_0x1b2b86=0x32){const _0x134d3a=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x134d3a)throw new Error('connection_unavailable');let _0x519a6e,_0x4c261f;return new Promise((_0x26295b,_0x4032a0)=>{const _0x5472a5=As('',0x14);_0x134d3a['port1']['start']();const _0x4b6a89=setTimeout(()=>{_0x4032a0(new Error('unsupported_event'));},_0x1b2b86);_0x4c261f={'messageChannel':_0x134d3a,'onMessage'(_0x59ad10){const _0x4608d6=_0x59ad10;if(_0x4608d6['data']['eventId']===_0x5472a5)switch(_0x4608d6['data']['status']){case'ack':clearTimeout(_0x4b6a89),_0x519a6e=setTimeout(()=>{_0x4032a0(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x519a6e),_0x26295b(_0x4608d6['data']['response']);break;default:clearTimeout(_0x4b6a89),clearTimeout(_0x519a6e),_0x4032a0(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4c261f),_0x134d3a['port1']['addEventListener']('message',_0x4c261f['onMessage']),this['target']['postMessage']({'eventType':_0x2a8bcd,'eventId':_0x5472a5,'data':_0x214e81},[_0x134d3a['port2']]);})['finally'](()=>{_0x4c261f&&this['removeMessageHandler'](_0x4c261f);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x3f4bef){Z()['location']['href']=_0x3f4bef;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x582511;return((_0x582511=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x582511['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x292a3b){this['request']=_0x292a3b;}['toPromise'](){return new Promise((_0xf85265,_0x567ec9)=>{this['request']['addEventListener']('success',()=>{_0xf85265(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x567ec9(this['request']['error']);});});}}function Zn(_0x3dced1,_0x52a5b2){return _0x3dced1['transaction']([Mn],_0x52a5b2?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x9d1c95=indexedDB['deleteDatabase'](Ka);return new nn(_0x9d1c95)['toPromise']();}function Qa(){const _0x2d1e61=indexedDB['open'](Ka,pp);return new Promise((_0x5d33af,_0x37cd14)=>{_0x2d1e61['addEventListener']('error',()=>{_0x37cd14(_0x2d1e61['error']);}),_0x2d1e61['addEventListener']('upgradeneeded',()=>{const _0x295367=_0x2d1e61['result'];try{_0x295367['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x4328ff){_0x37cd14(_0x4328ff);}}),_0x2d1e61['addEventListener']('success',async()=>{const _0x78e05b=_0x2d1e61['result'];_0x78e05b['objectStoreNames']['contains'](Mn)?_0x5d33af(_0x78e05b):(_0x78e05b['close'](),await _p(),_0x5d33af(await Qa()));});});}async function Or(_0x22fd00,_0x35fcf4,_0x337cba){const _0x21cb81=Zn(_0x22fd00,!0x0)['put']({[Ya]:_0x35fcf4,'value':_0x337cba});return new nn(_0x21cb81)['toPromise']();}async function gp(_0x2296a1,_0x11f90c){const _0x383348=Zn(_0x2296a1,!0x1)['get'](_0x11f90c),_0x312b3e=await new nn(_0x383348)['toPromise']();return _0x312b3e===void 0x0?null:_0x312b3e['value'];}function Dr(_0xb5304e,_0x4bb965){const _0x3b3227=Zn(_0xb5304e,!0x0)['delete'](_0x4bb965);return new nn(_0x3b3227)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x25b6f5){let _0x5675e0=0x0;for(;;)try{const _0x1e73bc=await this['_openDb']();return await _0x25b6f5(_0x1e73bc);}catch(_0x382415){if(_0x5675e0++>yp)throw _0x382415;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x2084da,_0x51286a)=>({'keyProcessed':(await this['_poll']())['includes'](_0x51286a['key'])})),this['receiver']['_subscribe']('ping',async(_0x53f534,_0x170851)=>['keyChanged']);}async['initializeSender'](){var _0x15aee2,_0x5afa45;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x374947=await this['sender']['_send']('ping',{},0x320);_0x374947&&(_0x15aee2=_0x374947[0x0])!=null&&_0x15aee2['fulfilled']&&(_0x5afa45=_0x374947[0x0])!=null&&_0x5afa45['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x423b9c){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x423b9c},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3b1459=>{await Or(_0x3b1459,Dn,'1'),await Dr(_0x3b1459,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x323ecc){this['pendingWrites']++;try{await _0x323ecc();}finally{this['pendingWrites']--;}}async['_set'](_0x465440,_0x38a167){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x55e91f=>Or(_0x55e91f,_0x465440,_0x38a167)),this['localCache'][_0x465440]=_0x38a167,this['notifyServiceWorker'](_0x465440)));}async['_get'](_0x3e7eed){const _0x12d173=await this['_withRetries'](_0x480f9c=>gp(_0x480f9c,_0x3e7eed));return this['localCache'][_0x3e7eed]=_0x12d173,_0x12d173;}async['_remove'](_0x1a0d04){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x597ec8=>Dr(_0x597ec8,_0x1a0d04)),delete this['localCache'][_0x1a0d04],this['notifyServiceWorker'](_0x1a0d04)));}async['_poll'](){const _0x3d692b=await this['_withRetries'](_0xe17071=>{const _0x2a8030=Zn(_0xe17071,!0x1)['getAll']();return new nn(_0x2a8030)['toPromise']();});if(!_0x3d692b)return[];if(this['pendingWrites']!==0x0)return[];const _0x277980=[],_0x36fe58=new Set();if(_0x3d692b['length']!==0x0){for(const {fbase_key:_0x3be5cd,value:_0xc1f905}of _0x3d692b)_0x36fe58['add'](_0x3be5cd),JSON['stringify'](this['localCache'][_0x3be5cd])!==JSON['stringify'](_0xc1f905)&&(this['notifyListeners'](_0x3be5cd,_0xc1f905),_0x277980['push'](_0x3be5cd));}for(const _0x4a7296 of Object['keys'](this['localCache']))this['localCache'][_0x4a7296]&&!_0x36fe58['has'](_0x4a7296)&&(this['notifyListeners'](_0x4a7296,null),_0x277980['push'](_0x4a7296));return _0x277980;}['notifyListeners'](_0x200817,_0x37a47e){this['localCache'][_0x200817]=_0x37a47e;const _0x500a89=this['listeners'][_0x200817];if(_0x500a89){for(const _0x989f11 of Array['from'](_0x500a89))_0x989f11(_0x37a47e);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3df24f,_0x4cd374){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3df24f]||(this['listeners'][_0x3df24f]=new Set(),this['_get'](_0x3df24f)),this['listeners'][_0x3df24f]['add'](_0x4cd374);}['_removeListener'](_0x14bce3,_0x27f6b){this['listeners'][_0x14bce3]&&(this['listeners'][_0x14bce3]['delete'](_0x27f6b),this['listeners'][_0x14bce3]['size']===0x0&&delete this['listeners'][_0x14bce3]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x3c1aff,_0x4d0adc){return _0x4d0adc?ie(_0x4d0adc):(m(_0x3c1aff['_popupRedirectResolver'],_0x3c1aff,'argument-error'),_0x3c1aff['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x4942a4){super('custom','custom'),this['params']=_0x4942a4;}['_getIdTokenResponse'](_0x46573a){return nt(_0x46573a,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3f3682,_0x32a1ce){return nt(_0x3f3682,this['_buildIdpRequest'](_0x32a1ce));}['_getReauthenticationResolver'](_0x49b9f7){return nt(_0x49b9f7,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x523141){const _0x3591bf={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x523141&&(_0x3591bf['idToken']=_0x523141),_0x3591bf;}}function Ip(_0x16d3b5){return Va(_0x16d3b5['auth'],new ks(_0x16d3b5),_0x16d3b5['bypassAuthState']);}function wp(_0x386166){const {auth:_0x21d9a7,user:_0x4ebdd5}=_0x386166;return m(_0x4ebdd5,_0x21d9a7,'internal-error'),tp(_0x4ebdd5,new ks(_0x386166),_0x386166['bypassAuthState']);}async function Cp(_0x2d5899){const {auth:_0x2c7b12,user:_0x7101a4}=_0x2d5899;return m(_0x7101a4,_0x2c7b12,'internal-error'),ep(_0x7101a4,new ks(_0x2d5899),_0x2d5899['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x233503,_0x2a789e,_0x1521f3,_0x1e7a70,_0x17e057=!0x1){this['auth']=_0x233503,this['resolver']=_0x1521f3,this['user']=_0x1e7a70,this['bypassAuthState']=_0x17e057,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2a789e)?_0x2a789e:[_0x2a789e];}['execute'](){return new Promise(async(_0x23d55d,_0x1beb09)=>{this['pendingPromise']={'resolve':_0x23d55d,'reject':_0x1beb09};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x456a93){this['reject'](_0x456a93);}});}async['onAuthEvent'](_0xa69c1d){const {urlResponse:_0x3a51df,sessionId:_0xca5faf,postBody:_0x3d6681,tenantId:_0x45cdcc,error:_0x3df533,type:_0x13c172}=_0xa69c1d;if(_0x3df533){this['reject'](_0x3df533);return;}const _0x1e4785={'auth':this['auth'],'requestUri':_0x3a51df,'sessionId':_0xca5faf,'tenantId':_0x45cdcc||void 0x0,'postBody':_0x3d6681||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x13c172)(_0x1e4785));}catch(_0x522704){this['reject'](_0x522704);}}['onError'](_0x4e4a46){this['reject'](_0x4e4a46);}['getIdpTask'](_0x2acaca){switch(_0x2acaca){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x392b4e){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x392b4e),this['unregisterAndCleanUp']();}['reject'](_0x2014b7){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2014b7),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x28105f,_0x56ffe4,_0x3da05a,_0x48b5b5,_0x2d93dc){super(_0x28105f,_0x56ffe4,_0x48b5b5,_0x2d93dc),this['provider']=_0x3da05a,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x2bae28=await this['execute']();return m(_0x2bae28,this['auth'],'internal-error'),_0x2bae28;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2940f3=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2940f3),this['authWindow']['associatedEvent']=_0x2940f3,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2e1bf5=>{this['reject'](_0x2e1bf5);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x2999f8=>{_0x2999f8||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4d1c1e;return((_0x4d1c1e=this['authWindow'])==null?void 0x0:_0x4d1c1e['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x32b8b7=()=>{var _0x220770,_0x4af578;if((_0x4af578=(_0x220770=this['authWindow'])==null?void 0x0:_0x220770['window'])!=null&&_0x4af578['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x32b8b7,Tp['get']());};_0x32b8b7();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x4cf913,_0x4b5d9a,_0x4cf626=!0x1){super(_0x4cf913,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4b5d9a,void 0x0,_0x4cf626),this['eventId']=null;}async['execute'](){let _0x3eac2b=hn['get'](this['auth']['_key']());if(!_0x3eac2b){try{const _0x1cf0a8=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x3eac2b=()=>Promise['resolve'](_0x1cf0a8);}catch(_0x568b7b){_0x3eac2b=()=>Promise['reject'](_0x568b7b);}hn['set'](this['auth']['_key'](),_0x3eac2b);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3eac2b();}async['onAuthEvent'](_0x523d0d){if(_0x523d0d['type']==='signInViaRedirect')return super['onAuthEvent'](_0x523d0d);if(_0x523d0d['type']==='unknown'){this['resolve'](null);return;}if(_0x523d0d['eventId']){const _0x4984ec=await this['auth']['_redirectUserForId'](_0x523d0d['eventId']);if(_0x4984ec)return this['user']=_0x4984ec,super['onAuthEvent'](_0x523d0d);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x2376ae,_0x596edb){const _0x3fceda=Pp(_0x596edb),_0x455855=kp(_0x2376ae);if(!await _0x455855['_isAvailable']())return!0x1;const _0x5a785c=await _0x455855['_get'](_0x3fceda)==='true';return await _0x455855['_remove'](_0x3fceda),_0x5a785c;}function Ap(_0x188b66,_0x4a7dde){hn['set'](_0x188b66['_key'](),_0x4a7dde);}function kp(_0x263db2){return ie(_0x263db2['_redirectPersistence']);}function Pp(_0x49b039){return ln(Sp,_0x49b039['config']['apiKey'],_0x49b039['name']);}async function Np(_0x52d3b6,_0x5e1e3e,_0x529a63=!0x1){if($(_0x52d3b6['app']))return Promise['reject'](re(_0x52d3b6));const _0x3d00bd=Ke(_0x52d3b6),_0x58e2f3=Ep(_0x3d00bd,_0x5e1e3e),_0x2de3c4=await new bp(_0x3d00bd,_0x58e2f3,_0x529a63)['execute']();return _0x2de3c4&&!_0x529a63&&(delete _0x2de3c4['user']['_redirectEventId'],await _0x3d00bd['_persistUserIfCurrent'](_0x2de3c4['user']),await _0x3d00bd['_setRedirectUser'](null,_0x5e1e3e)),_0x2de3c4;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x5ce1a7){this['auth']=_0x5ce1a7,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x25a224){this['consumers']['add'](_0x25a224),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x25a224)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x25a224),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x4fdd22){this['consumers']['delete'](_0x4fdd22);}['onEvent'](_0x18133f){if(this['hasEventBeenHandled'](_0x18133f))return!0x1;let _0x2f0b7b=!0x1;return this['consumers']['forEach'](_0x4ba825=>{this['isEventForConsumer'](_0x18133f,_0x4ba825)&&(_0x2f0b7b=!0x0,this['sendToConsumer'](_0x18133f,_0x4ba825),this['saveEventToCache'](_0x18133f));}),this['hasHandledPotentialRedirect']||!Mp(_0x18133f)||(this['hasHandledPotentialRedirect']=!0x0,_0x2f0b7b||(this['queuedRedirectEvent']=_0x18133f,_0x2f0b7b=!0x0)),_0x2f0b7b;}['sendToConsumer'](_0x5fb7b5,_0x4eb0ca){var _0x192d44;if(_0x5fb7b5['error']&&!Za(_0x5fb7b5)){const _0x5e2b98=((_0x192d44=_0x5fb7b5['error']['code'])==null?void 0x0:_0x192d44['split']('auth/')[0x1])||'internal-error';_0x4eb0ca['onError'](X(this['auth'],_0x5e2b98));}else _0x4eb0ca['onAuthEvent'](_0x5fb7b5);}['isEventForConsumer'](_0x391acd,_0x336b02){const _0x4da605=_0x336b02['eventId']===null||!!_0x391acd['eventId']&&_0x391acd['eventId']===_0x336b02['eventId'];return _0x336b02['filter']['includes'](_0x391acd['type'])&&_0x4da605;}['hasEventBeenHandled'](_0x26f484){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x26f484));}['saveEventToCache'](_0x2aa5fa){this['cachedEventUids']['add'](Mr(_0x2aa5fa)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x30c8b6){return[_0x30c8b6['type'],_0x30c8b6['eventId'],_0x30c8b6['sessionId'],_0x30c8b6['tenantId']]['filter'](_0x35bd12=>_0x35bd12)['join']('-');}function Za({type:_0x5cfec3,error:_0x5aee06}){return _0x5cfec3==='unknown'&&(_0x5aee06==null?void 0x0:_0x5aee06['code'])==='auth/no-auth-event';}function Mp(_0x24ec55){switch(_0x24ec55['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x24ec55);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x455a62,_0x19952f={}){return Pe(_0x455a62,'GET','/v1/projects',_0x19952f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x3d638a){if(_0x3d638a['config']['emulator'])return;const {authorizedDomains:_0x481fd5}=await Lp(_0x3d638a);for(const _0x1b66df of _0x481fd5)try{if(Wp(_0x1b66df))return;}catch{}Y(_0x3d638a,'unauthorized-domain');}function Wp(_0x1147be){const _0x4c8d85=Mi(),{protocol:_0x31c0da,hostname:_0x1ed584}=new URL(_0x4c8d85);if(_0x1147be['startsWith']('chrome-extension://')){const _0x337cd9=new URL(_0x1147be);return _0x337cd9['hostname']===''&&_0x1ed584===''?_0x31c0da==='chrome-extension:'&&_0x1147be['replace']('chrome-extension://','')===_0x4c8d85['replace']('chrome-extension://',''):_0x31c0da==='chrome-extension:'&&_0x337cd9['hostname']===_0x1ed584;}if(!Fp['test'](_0x31c0da))return!0x1;if(xp['test'](_0x1147be))return _0x1ed584===_0x1147be;const _0x5835dd=_0x1147be['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5835dd+'|'+_0x5835dd+')$','i')['test'](_0x1ed584);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x38bb0f=Z()['___jsl'];if(_0x38bb0f!=null&&_0x38bb0f['H']){for(const _0x260778 of Object['keys'](_0x38bb0f['H']))if(_0x38bb0f['H'][_0x260778]['r']=_0x38bb0f['H'][_0x260778]['r']||[],_0x38bb0f['H'][_0x260778]['L']=_0x38bb0f['H'][_0x260778]['L']||[],_0x38bb0f['H'][_0x260778]['r']=[..._0x38bb0f['H'][_0x260778]['L']],_0x38bb0f['CP']){for(let _0x2f40ae=0x0;_0x2f40ae<_0x38bb0f['CP']['length'];_0x2f40ae++)_0x38bb0f['CP'][_0x2f40ae]=null;}}}function Vp(_0x33d289){return new Promise((_0x302508,_0x4a9be2)=>{var _0x1b4ec9,_0x27ffbe,_0x408eca;function _0x39c2ae(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x302508(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4a9be2(X(_0x33d289,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x27ffbe=(_0x1b4ec9=Z()['gapi'])==null?void 0x0:_0x1b4ec9['iframes'])!=null&&_0x27ffbe['Iframe'])_0x302508(gapi['iframes']['getContext']());else{if((_0x408eca=Z()['gapi'])!=null&&_0x408eca['load'])_0x39c2ae();else{const _0x2af864=Ff('iframefcb');return Z()[_0x2af864]=()=>{gapi['load']?_0x39c2ae():_0x4a9be2(X(_0x33d289,'network-request-failed'));},xa(xf()+'?onload='+_0x2af864)['catch'](_0x31dd34=>_0x4a9be2(_0x31dd34));}}})['catch'](_0x571cb2=>{throw un=null,_0x571cb2;});}let un=null;function Hp(_0x3a0ae0){return un=un||Vp(_0x3a0ae0),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x1053d3){const _0x2d3d8a=_0x1053d3['config'];m(_0x2d3d8a['authDomain'],_0x1053d3,'auth-domain-config-required');const _0xf19809=_0x2d3d8a['emulator']?Cs(_0x2d3d8a,qp):'https://'+_0x1053d3['config']['authDomain']+'/'+Gp,_0x484be7={'apiKey':_0x2d3d8a['apiKey'],'appName':_0x1053d3['name'],'v':dt},_0x43457b=jp['get'](_0x1053d3['config']['apiHost']);_0x43457b&&(_0x484be7['eid']=_0x43457b);const _0x3c78b4=_0x1053d3['_getFrameworks']();return _0x3c78b4['length']&&(_0x484be7['fw']=_0x3c78b4['join'](',')),_0xf19809+'?'+ut(_0x484be7)['slice'](0x1);}async function Yp(_0x5774ba){const _0x59ecd9=await Hp(_0x5774ba),_0x2cc3c3=Z()['gapi'];return m(_0x2cc3c3,_0x5774ba,'internal-error'),_0x59ecd9['open']({'where':document['body'],'url':Kp(_0x5774ba),'messageHandlersFilter':_0x2cc3c3['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x1b3dd9=>new Promise(async(_0x4f6e81,_0x23eb25)=>{await _0x1b3dd9['restyle']({'setHideOnLeave':!0x1});const _0x116881=X(_0x5774ba,'network-request-failed'),_0x315b29=Z()['setTimeout'](()=>{_0x23eb25(_0x116881);},$p['get']());function _0x543f18(){Z()['clearTimeout'](_0x315b29),_0x4f6e81(_0x1b3dd9);}_0x1b3dd9['ping'](_0x543f18)['then'](_0x543f18,()=>{_0x23eb25(_0x116881);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x3dbbc6){this['window']=_0x3dbbc6,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x764ac5,_0x23216b,_0x44f58f,_0x223649=Jp,_0x52a960=Xp){const _0x52a832=Math['max']((window['screen']['availHeight']-_0x52a960)/0x2,0x0)['toString'](),_0x315785=Math['max']((window['screen']['availWidth']-_0x223649)/0x2,0x0)['toString']();let _0x2219a2='';const _0x2af6d9={...Qp,'width':_0x223649['toString'](),'height':_0x52a960['toString'](),'top':_0x52a832,'left':_0x315785},_0x234472=W()['toLowerCase']();_0x44f58f&&(_0x2219a2=ka(_0x234472)?Zp:_0x44f58f),Ra(_0x234472)&&(_0x23216b=_0x23216b||e_,_0x2af6d9['scrollbars']='yes');const _0x4487f2=Object['entries'](_0x2af6d9)['reduce']((_0x1d383e,[_0x34293c,_0x3df31c])=>''+_0x1d383e+_0x34293c+'='+_0x3df31c+',','');if(Rf(_0x234472)&&_0x2219a2!=='_self')return n_(_0x23216b||'',_0x2219a2),new xr(null);const _0x45a479=window['open'](_0x23216b||'',_0x2219a2,_0x4487f2);m(_0x45a479,_0x764ac5,'popup-blocked');try{_0x45a479['focus']();}catch{}return new xr(_0x45a479);}function n_(_0x3803ec,_0x14a69c){const _0x355955=document['createElement']('a');_0x355955['href']=_0x3803ec,_0x355955['target']=_0x14a69c;const _0x4fa01f=document['createEvent']('MouseEvent');_0x4fa01f['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x355955['dispatchEvent'](_0x4fa01f);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x513a9e,_0x4eca0b,_0x45059e,_0x24d142,_0x514cee,_0x219707){m(_0x513a9e['config']['authDomain'],_0x513a9e,'auth-domain-config-required'),m(_0x513a9e['config']['apiKey'],_0x513a9e,'invalid-api-key');const _0x1a0b82={'apiKey':_0x513a9e['config']['apiKey'],'appName':_0x513a9e['name'],'authType':_0x45059e,'redirectUrl':_0x24d142,'v':dt,'eventId':_0x514cee};if(_0x4eca0b instanceof Wa){_0x4eca0b['setDefaultLanguage'](_0x513a9e['languageCode']),_0x1a0b82['providerId']=_0x4eca0b['providerId']||'',pn(_0x4eca0b['getCustomParameters']())||(_0x1a0b82['customParameters']=JSON['stringify'](_0x4eca0b['getCustomParameters']()));for(const [_0x573830,_0x584d13]of Object['entries']({}))_0x1a0b82[_0x573830]=_0x584d13;}if(_0x4eca0b instanceof tn){const _0x7f1fdd=_0x4eca0b['getScopes']()['filter'](_0x416409=>_0x416409!=='');_0x7f1fdd['length']>0x0&&(_0x1a0b82['scopes']=_0x7f1fdd['join'](','));}_0x513a9e['tenantId']&&(_0x1a0b82['tid']=_0x513a9e['tenantId']);const _0x54d0d2=_0x1a0b82;for(const _0x1fcace of Object['keys'](_0x54d0d2))_0x54d0d2[_0x1fcace]===void 0x0&&delete _0x54d0d2[_0x1fcace];const _0x51fe69=await _0x513a9e['_getAppCheckToken'](),_0x4e2099=_0x51fe69?'#'+r_+'='+encodeURIComponent(_0x51fe69):'';return o_(_0x513a9e)+'?'+ut(_0x54d0d2)['slice'](0x1)+_0x4e2099;}function o_({config:_0x19d168}){return _0x19d168['emulator']?Cs(_0x19d168,s_):'https://'+_0x19d168['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x4f0504,_0x4fc050,_0x314576,_0x1ee74e){var _0xac4e1a;ce((_0xac4e1a=this['eventManagers'][_0x4f0504['_key']()])==null?void 0x0:_0xac4e1a['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x338110=await Fr(_0x4f0504,_0x4fc050,_0x314576,Mi(),_0x1ee74e);return t_(_0x4f0504,_0x338110,As());}async['_openRedirect'](_0x1837be,_0x547678,_0x489981,_0x78bbe8){await this['_originValidation'](_0x1837be);const _0xa44937=await Fr(_0x1837be,_0x547678,_0x489981,Mi(),_0x78bbe8);return hp(_0xa44937),new Promise(()=>{});}['_initialize'](_0x31892b){const _0x94fba1=_0x31892b['_key']();if(this['eventManagers'][_0x94fba1]){const {manager:_0x34c5ff,promise:_0x20cc88}=this['eventManagers'][_0x94fba1];return _0x34c5ff?Promise['resolve'](_0x34c5ff):(ce(_0x20cc88,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x20cc88);}const _0x3681e9=this['initAndGetManager'](_0x31892b);return this['eventManagers'][_0x94fba1]={'promise':_0x3681e9},_0x3681e9['catch'](()=>{delete this['eventManagers'][_0x94fba1];}),_0x3681e9;}async['initAndGetManager'](_0x389a4b){const _0xe68f4f=await Yp(_0x389a4b),_0x597abc=new Dp(_0x389a4b);return _0xe68f4f['register']('authEvent',_0x275a30=>(m(_0x275a30==null?void 0x0:_0x275a30['authEvent'],_0x389a4b,'invalid-auth-event'),{'status':_0x597abc['onEvent'](_0x275a30['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x389a4b['_key']()]={'manager':_0x597abc},this['iframes'][_0x389a4b['_key']()]=_0xe68f4f,_0x597abc;}['_isIframeWebStorageSupported'](_0x238832,_0x135465){this['iframes'][_0x238832['_key']()]['send'](pi,{'type':pi},_0x913041=>{var _0x2a9168;const _0x2a0956=(_0x2a9168=_0x913041==null?void 0x0:_0x913041[0x0])==null?void 0x0:_0x2a9168[pi];_0x2a0956!==void 0x0&&_0x135465(!!_0x2a0956),Y(_0x238832,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x240469){const _0x537df5=_0x240469['_key']();return this['originValidationPromises'][_0x537df5]||(this['originValidationPromises'][_0x537df5]=Up(_0x240469)),this['originValidationPromises'][_0x537df5];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x248347){this['auth']=_0x248347,this['internalListeners']=new Map();}['getUid'](){var _0x57758d;return this['assertAuthConfigured'](),((_0x57758d=this['auth']['currentUser'])==null?void 0x0:_0x57758d['uid'])||null;}async['getToken'](_0x3c50b9){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3c50b9)}:null;}['addAuthTokenListener'](_0x532acd){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x532acd))return;const _0x21c294=this['auth']['onIdTokenChanged'](_0x2e4523=>{_0x532acd((_0x2e4523==null?void 0x0:_0x2e4523['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x532acd,_0x21c294),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x76ed1c){this['assertAuthConfigured']();const _0x34f3df=this['internalListeners']['get'](_0x76ed1c);_0x34f3df&&(this['internalListeners']['delete'](_0x76ed1c),_0x34f3df(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x57c5bc){switch(_0x57c5bc){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x7983cf){st(new Fe('auth',(_0x4413c9,{options:_0x290fcb})=>{const _0x536300=_0x4413c9['getProvider']('app')['getImmediate'](),_0x10f880=_0x4413c9['getProvider']('heartbeat'),_0x1b3f92=_0x4413c9['getProvider']('app-check-internal'),{apiKey:_0x20ef3c,authDomain:_0x25ea69}=_0x536300['options'];m(_0x20ef3c&&!_0x20ef3c['includes'](':'),'invalid-api-key',{'appName':_0x536300['name']});const _0x1a5377={'apiKey':_0x20ef3c,'authDomain':_0x25ea69,'clientPlatform':_0x7983cf,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x7983cf)},_0x3fcdf1=new Df(_0x536300,_0x10f880,_0x1b3f92,_0x1a5377);return Hf(_0x3fcdf1,_0x290fcb),_0x3fcdf1;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3ac6cd,_0x124d21,_0xc418f7)=>{_0x3ac6cd['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x19885e=>{const _0x237108=Ke(_0x19885e['getProvider']('auth')['getImmediate']());return(_0x20ffe7=>new l_(_0x20ffe7))(_0x237108);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x7983cf)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x10fdba=>async _0x204bd2=>{const _0x4a1436=_0x204bd2&&await _0x204bd2['getIdTokenResult'](),_0xbb7334=_0x4a1436&&(new Date()['getTime']()-Date['parse'](_0x4a1436['issuedAtTime']))/0x3e8;if(_0xbb7334&&_0xbb7334>f_)return;const _0x2a5216=_0x4a1436==null?void 0x0:_0x4a1436['token'];Br!==_0x2a5216&&(Br=_0x2a5216,await fetch(_0x10fdba,{'method':_0x2a5216?'POST':'DELETE','headers':_0x2a5216?{'Authorization':'Bearer\x20'+_0x2a5216}:{}}));};function B_(_0x3dc930=Zr()){const _0x33428a=Hi(_0x3dc930,'auth');if(_0x33428a['isInitialized']())return _0x33428a['getImmediate']();const _0x360179=Vf(_0x3dc930,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x4d2242=jr('authTokenSyncURL');if(_0x4d2242&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x240917=new URL(_0x4d2242,location['origin']);if(location['origin']===_0x240917['origin']){const _0xee850f=p_(_0x240917['toString']());sp(_0x360179,_0xee850f,()=>_0xee850f(_0x360179['currentUser'])),ip(_0x360179,_0x5d1047=>_0xee850f(_0x5d1047));}}const _0x49352a=qr('auth');return _0x49352a&&$f(_0x360179,'http://'+_0x49352a),_0x360179;}function __(){var _0x53f35d;return((_0x53f35d=document['getElementsByTagName']('head'))==null?void 0x0:_0x53f35d[0x0])??document;}Mf({'loadJS'(_0x4d98d1){return new Promise((_0x1d4221,_0x110a5b)=>{const _0x6a5b48=document['createElement']('script');_0x6a5b48['setAttribute']('src',_0x4d98d1),_0x6a5b48['onload']=_0x1d4221,_0x6a5b48['onerror']=_0x30ad12=>{const _0x4f091b=X('internal-error');_0x4f091b['customData']=_0x30ad12,_0x110a5b(_0x4f091b);},_0x6a5b48['type']='text/javascript',_0x6a5b48['charset']='UTF-8',__()['appendChild'](_0x6a5b48);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};