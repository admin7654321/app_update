const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x16755f,_0x329c4c){if(!_0x16755f)throw ht(_0x329c4c);},ht=function(_0x5b458c){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5b458c);},Hr=function(_0x440c98){const _0x50566b=[];let _0x279922=0x0;for(let _0x58ca63=0x0;_0x58ca63<_0x440c98['length'];_0x58ca63++){let _0x1ab801=_0x440c98['charCodeAt'](_0x58ca63);_0x1ab801<0x80?_0x50566b[_0x279922++]=_0x1ab801:_0x1ab801<0x800?(_0x50566b[_0x279922++]=_0x1ab801>>0x6|0xc0,_0x50566b[_0x279922++]=_0x1ab801&0x3f|0x80):(_0x1ab801&0xfc00)===0xd800&&_0x58ca63+0x1<_0x440c98['length']&&(_0x440c98['charCodeAt'](_0x58ca63+0x1)&0xfc00)===0xdc00?(_0x1ab801=0x10000+((_0x1ab801&0x3ff)<<0xa)+(_0x440c98['charCodeAt'](++_0x58ca63)&0x3ff),_0x50566b[_0x279922++]=_0x1ab801>>0x12|0xf0,_0x50566b[_0x279922++]=_0x1ab801>>0xc&0x3f|0x80,_0x50566b[_0x279922++]=_0x1ab801>>0x6&0x3f|0x80,_0x50566b[_0x279922++]=_0x1ab801&0x3f|0x80):(_0x50566b[_0x279922++]=_0x1ab801>>0xc|0xe0,_0x50566b[_0x279922++]=_0x1ab801>>0x6&0x3f|0x80,_0x50566b[_0x279922++]=_0x1ab801&0x3f|0x80);}return _0x50566b;},nc=function(_0x49cfcd){const _0x5812b6=[];let _0x4ad878=0x0,_0x59ed92=0x0;for(;_0x4ad878<_0x49cfcd['length'];){const _0x5209ad=_0x49cfcd[_0x4ad878++];if(_0x5209ad<0x80)_0x5812b6[_0x59ed92++]=String['fromCharCode'](_0x5209ad);else{if(_0x5209ad>0xbf&&_0x5209ad<0xe0){const _0x50ecec=_0x49cfcd[_0x4ad878++];_0x5812b6[_0x59ed92++]=String['fromCharCode']((_0x5209ad&0x1f)<<0x6|_0x50ecec&0x3f);}else{if(_0x5209ad>0xef&&_0x5209ad<0x16d){const _0x4a6791=_0x49cfcd[_0x4ad878++],_0x487571=_0x49cfcd[_0x4ad878++],_0x239168=_0x49cfcd[_0x4ad878++],_0x3eb773=((_0x5209ad&0x7)<<0x12|(_0x4a6791&0x3f)<<0xc|(_0x487571&0x3f)<<0x6|_0x239168&0x3f)-0x10000;_0x5812b6[_0x59ed92++]=String['fromCharCode'](0xd800+(_0x3eb773>>0xa)),_0x5812b6[_0x59ed92++]=String['fromCharCode'](0xdc00+(_0x3eb773&0x3ff));}else{const _0x2f4527=_0x49cfcd[_0x4ad878++],_0x4d3e43=_0x49cfcd[_0x4ad878++];_0x5812b6[_0x59ed92++]=String['fromCharCode']((_0x5209ad&0xf)<<0xc|(_0x2f4527&0x3f)<<0x6|_0x4d3e43&0x3f);}}}}return _0x5812b6['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x10f21a,_0x482339){if(!Array['isArray'](_0x10f21a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x228cd0=_0x482339?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x19fa31=[];for(let _0xc33f7e=0x0;_0xc33f7e<_0x10f21a['length'];_0xc33f7e+=0x3){const _0x2ce7d0=_0x10f21a[_0xc33f7e],_0x3a8ea0=_0xc33f7e+0x1<_0x10f21a['length'],_0x1274cc=_0x3a8ea0?_0x10f21a[_0xc33f7e+0x1]:0x0,_0x107a6e=_0xc33f7e+0x2<_0x10f21a['length'],_0x2e060a=_0x107a6e?_0x10f21a[_0xc33f7e+0x2]:0x0,_0x44dff7=_0x2ce7d0>>0x2,_0x565f22=(_0x2ce7d0&0x3)<<0x4|_0x1274cc>>0x4;let _0x29914d=(_0x1274cc&0xf)<<0x2|_0x2e060a>>0x6,_0x4d50d7=_0x2e060a&0x3f;_0x107a6e||(_0x4d50d7=0x40,_0x3a8ea0||(_0x29914d=0x40)),_0x19fa31['push'](_0x228cd0[_0x44dff7],_0x228cd0[_0x565f22],_0x228cd0[_0x29914d],_0x228cd0[_0x4d50d7]);}return _0x19fa31['join']('');},'encodeString'(_0x1a1159,_0x5d9f98){return this['HAS_NATIVE_SUPPORT']&&!_0x5d9f98?btoa(_0x1a1159):this['encodeByteArray'](Hr(_0x1a1159),_0x5d9f98);},'decodeString'(_0x5bc00f,_0x423e83){return this['HAS_NATIVE_SUPPORT']&&!_0x423e83?atob(_0x5bc00f):nc(this['decodeStringToByteArray'](_0x5bc00f,_0x423e83));},'decodeStringToByteArray'(_0x2a9bc7,_0x330547){this['init_']();const _0x3e8ad7=_0x330547?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4f2c89=[];for(let _0x268d03=0x0;_0x268d03<_0x2a9bc7['length'];){const _0x1e733e=_0x3e8ad7[_0x2a9bc7['charAt'](_0x268d03++)],_0x2dfedb=_0x268d03<_0x2a9bc7['length']?_0x3e8ad7[_0x2a9bc7['charAt'](_0x268d03)]:0x0;++_0x268d03;const _0x55fc27=_0x268d03<_0x2a9bc7['length']?_0x3e8ad7[_0x2a9bc7['charAt'](_0x268d03)]:0x40;++_0x268d03;const _0x15b608=_0x268d03<_0x2a9bc7['length']?_0x3e8ad7[_0x2a9bc7['charAt'](_0x268d03)]:0x40;if(++_0x268d03,_0x1e733e==null||_0x2dfedb==null||_0x55fc27==null||_0x15b608==null)throw new ic();const _0x318bb1=_0x1e733e<<0x2|_0x2dfedb>>0x4;if(_0x4f2c89['push'](_0x318bb1),_0x55fc27!==0x40){const _0x382be8=_0x2dfedb<<0x4&0xf0|_0x55fc27>>0x2;if(_0x4f2c89['push'](_0x382be8),_0x15b608!==0x40){const _0x1cf9ce=_0x55fc27<<0x6&0xc0|_0x15b608;_0x4f2c89['push'](_0x1cf9ce);}}}return _0x4f2c89;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x159ad6=0x0;_0x159ad6<this['ENCODED_VALS']['length'];_0x159ad6++)this['byteToCharMap_'][_0x159ad6]=this['ENCODED_VALS']['charAt'](_0x159ad6),this['charToByteMap_'][this['byteToCharMap_'][_0x159ad6]]=_0x159ad6,this['byteToCharMapWebSafe_'][_0x159ad6]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x159ad6),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x159ad6]]=_0x159ad6,_0x159ad6>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x159ad6)]=_0x159ad6,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x159ad6)]=_0x159ad6);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x1323aa){const _0x27754a=Hr(_0x1323aa);return Fi['encodeByteArray'](_0x27754a,!0x0);},dn=function(_0x31393e){return $r(_0x31393e)['replace'](/\./g,'');},fn=function(_0x18238f){try{return Fi['decodeString'](_0x18238f,!0x0);}catch(_0x548a78){console['error']('base64Decode\x20failed:\x20',_0x548a78);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x12df89){return Gr(void 0x0,_0x12df89);}function Gr(_0x14be94,_0x4f7509){if(!(_0x4f7509 instanceof Object))return _0x4f7509;switch(_0x4f7509['constructor']){case Date:const _0x45920b=_0x4f7509;return new Date(_0x45920b['getTime']());case Object:_0x14be94===void 0x0&&(_0x14be94={});break;case Array:_0x14be94=[];break;default:return _0x4f7509;}for(const _0x5c77b8 in _0x4f7509)!_0x4f7509['hasOwnProperty'](_0x5c77b8)||!rc(_0x5c77b8)||(_0x14be94[_0x5c77b8]=Gr(_0x14be94[_0x5c77b8],_0x4f7509[_0x5c77b8]));return _0x14be94;}function rc(_0x466340){return _0x466340!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x11c444=Ps['__FIREBASE_DEFAULTS__'];if(_0x11c444)return JSON['parse'](_0x11c444);},lc=()=>{if(typeof document>'u')return;let _0x9fdf16;try{_0x9fdf16=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4ec97c=_0x9fdf16&&fn(_0x9fdf16[0x1]);return _0x4ec97c&&JSON['parse'](_0x4ec97c);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x2f4524){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x2f4524);return;}},qr=_0x1243cd=>{var _0x2ee238,_0x3e4470;return(_0x3e4470=(_0x2ee238=Ui())==null?void 0x0:_0x2ee238['emulatorHosts'])==null?void 0x0:_0x3e4470[_0x1243cd];},hc=_0x4a132a=>{const _0x38630b=qr(_0x4a132a);if(!_0x38630b)return;const _0x122e7d=_0x38630b['lastIndexOf'](':');if(_0x122e7d<=0x0||_0x122e7d+0x1===_0x38630b['length'])throw new Error('Invalid\x20host\x20'+_0x38630b+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1ed619=parseInt(_0x38630b['substring'](_0x122e7d+0x1),0xa);return _0x38630b[0x0]==='['?[_0x38630b['substring'](0x1,_0x122e7d-0x1),_0x1ed619]:[_0x38630b['substring'](0x0,_0x122e7d),_0x1ed619];},zr=()=>{var _0x4f5ede;return(_0x4f5ede=Ui())==null?void 0x0:_0x4f5ede['config'];},jr=_0x1af9bc=>{var _0x57928a;return(_0x57928a=Ui())==null?void 0x0:_0x57928a['_'+_0x1af9bc];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x5878ae,_0x4bcff8)=>{this['resolve']=_0x5878ae,this['reject']=_0x4bcff8;});}['wrapCallback'](_0x67c536){return(_0x214199,_0x3ccc1e)=>{_0x214199?this['reject'](_0x214199):this['resolve'](_0x3ccc1e),typeof _0x67c536=='function'&&(this['promise']['catch'](()=>{}),_0x67c536['length']===0x1?_0x67c536(_0x214199):_0x67c536(_0x214199,_0x3ccc1e));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x58a355,_0x103386){if(_0x58a355['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x25b3e7={'alg':'none','type':'JWT'},_0x12eec6=_0x103386||'demo-project',_0x4a9278=_0x58a355['iat']||0x0,_0x4d08f3=_0x58a355['sub']||_0x58a355['user_id'];if(!_0x4d08f3)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5658b9={'iss':'https://securetoken.google.com/'+_0x12eec6,'aud':_0x12eec6,'iat':_0x4a9278,'exp':_0x4a9278+0xe10,'auth_time':_0x4a9278,'sub':_0x4d08f3,'user_id':_0x4d08f3,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x58a355};return[dn(JSON['stringify'](_0x25b3e7)),dn(JSON['stringify'](_0x5658b9)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x395b6c=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x395b6c=='object'&&_0x395b6c['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x412a48=W();return _0x412a48['indexOf']('MSIE\x20')>=0x0||_0x412a48['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x49044c,_0x2e67a1)=>{try{let _0x4ce644=!0x0;const _0x27a48a='validate-browser-context-for-indexeddb-analytics-module',_0x438911=self['indexedDB']['open'](_0x27a48a);_0x438911['onsuccess']=()=>{_0x438911['result']['close'](),_0x4ce644||self['indexedDB']['deleteDatabase'](_0x27a48a),_0x49044c(!0x0);},_0x438911['onupgradeneeded']=()=>{_0x4ce644=!0x1;},_0x438911['onerror']=()=>{var _0x28cf20;_0x2e67a1(((_0x28cf20=_0x438911['error'])==null?void 0x0:_0x28cf20['message'])||'');};}catch(_0x4ff6a1){_0x2e67a1(_0x4ff6a1);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x4dc39f,_0x4027b5,_0x1b35dd){super(_0x4027b5),this['code']=_0x4dc39f,this['customData']=_0x1b35dd,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x2f8e19,_0x122cf3,_0x4dfbce){this['service']=_0x2f8e19,this['serviceName']=_0x122cf3,this['errors']=_0x4dfbce;}['create'](_0x37bffe,..._0x33a1d5){const _0x33b998=_0x33a1d5[0x0]||{},_0x47644c=this['service']+'/'+_0x37bffe,_0x1c125e=this['errors'][_0x37bffe],_0x3e2d78=_0x1c125e?vc(_0x1c125e,_0x33b998):'Error',_0x4a3163=this['serviceName']+':\x20'+_0x3e2d78+'\x20('+_0x47644c+').';return new Re(_0x47644c,_0x4a3163,_0x33b998);}}function vc(_0x27bd98,_0x2b1b2e){return _0x27bd98['replace'](Ec,(_0x55fae9,_0x340048)=>{const _0x7e63b2=_0x2b1b2e[_0x340048];return _0x7e63b2!=null?String(_0x7e63b2):'<'+_0x340048+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x11ebd8){return JSON['parse'](_0x11ebd8);}function O(_0x37af52){return JSON['stringify'](_0x37af52);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x429e62){let _0x41268a={},_0x3eed1e={},_0x2ffd4a={},_0x2bfcac='';try{const _0x196da9=_0x429e62['split']('.');_0x41268a=Nt(fn(_0x196da9[0x0])||''),_0x3eed1e=Nt(fn(_0x196da9[0x1])||''),_0x2bfcac=_0x196da9[0x2],_0x2ffd4a=_0x3eed1e['d']||{},delete _0x3eed1e['d'];}catch{}return{'header':_0x41268a,'claims':_0x3eed1e,'data':_0x2ffd4a,'signature':_0x2bfcac};},Ic=function(_0x2a44e4){const _0x49aae1=Yr(_0x2a44e4),_0x4eb570=_0x49aae1['claims'];return!!_0x4eb570&&typeof _0x4eb570=='object'&&_0x4eb570['hasOwnProperty']('iat');},wc=function(_0x1a24b6){const _0x331b05=Yr(_0x1a24b6)['claims'];return typeof _0x331b05=='object'&&_0x331b05['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x3f0133,_0x4914c1){return Object['prototype']['hasOwnProperty']['call'](_0x3f0133,_0x4914c1);}function Le(_0x1fd85b,_0x32fddc){if(Object['prototype']['hasOwnProperty']['call'](_0x1fd85b,_0x32fddc))return _0x1fd85b[_0x32fddc];}function pn(_0x2cd2a3){for(const _0xc62fff in _0x2cd2a3)if(Object['prototype']['hasOwnProperty']['call'](_0x2cd2a3,_0xc62fff))return!0x1;return!0x0;}function _n(_0x2cd277,_0x132951,_0x7ee45a){const _0x1cefa2={};for(const _0x4f60f7 in _0x2cd277)Object['prototype']['hasOwnProperty']['call'](_0x2cd277,_0x4f60f7)&&(_0x1cefa2[_0x4f60f7]=_0x132951['call'](_0x7ee45a,_0x2cd277[_0x4f60f7],_0x4f60f7,_0x2cd277));return _0x1cefa2;}function xe(_0x50b24d,_0x2c2069){if(_0x50b24d===_0x2c2069)return!0x0;const _0x3df62e=Object['keys'](_0x50b24d),_0x470da6=Object['keys'](_0x2c2069);for(const _0x98cfd1 of _0x3df62e){if(!_0x470da6['includes'](_0x98cfd1))return!0x1;const _0x14b300=_0x50b24d[_0x98cfd1],_0x3ca9a7=_0x2c2069[_0x98cfd1];if(Ns(_0x14b300)&&Ns(_0x3ca9a7)){if(!xe(_0x14b300,_0x3ca9a7))return!0x1;}else{if(_0x14b300!==_0x3ca9a7)return!0x1;}}for(const _0x562044 of _0x470da6)if(!_0x3df62e['includes'](_0x562044))return!0x1;return!0x0;}function Ns(_0x2cb264){return _0x2cb264!==null&&typeof _0x2cb264=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x363011){const _0x53b05e=[];for(const [_0xdf5a12,_0x22a135]of Object['entries'](_0x363011))Array['isArray'](_0x22a135)?_0x22a135['forEach'](_0x44602b=>{_0x53b05e['push'](encodeURIComponent(_0xdf5a12)+'='+encodeURIComponent(_0x44602b));}):_0x53b05e['push'](encodeURIComponent(_0xdf5a12)+'='+encodeURIComponent(_0x22a135));return _0x53b05e['length']?'&'+_0x53b05e['join']('&'):'';}function Ct(_0x20aa80){const _0x372adc={};return _0x20aa80['replace'](/^\?/,'')['split']('&')['forEach'](_0x18ee01=>{if(_0x18ee01){const [_0x380d7d,_0xc5c914]=_0x18ee01['split']('=');_0x372adc[decodeURIComponent(_0x380d7d)]=decodeURIComponent(_0xc5c914);}}),_0x372adc;}function Tt(_0x482c0d){const _0x52188b=_0x482c0d['indexOf']('?');if(!_0x52188b)return'';const _0x4f2803=_0x482c0d['indexOf']('#',_0x52188b);return _0x482c0d['substring'](_0x52188b,_0x4f2803>0x0?_0x4f2803:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3834be=0x1;_0x3834be<this['blockSize'];++_0x3834be)this['pad_'][_0x3834be]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0xa36c84,_0x518bac){_0x518bac||(_0x518bac=0x0);const _0x4f0282=this['W_'];if(typeof _0xa36c84=='string'){for(let _0x41a994=0x0;_0x41a994<0x10;_0x41a994++)_0x4f0282[_0x41a994]=_0xa36c84['charCodeAt'](_0x518bac)<<0x18|_0xa36c84['charCodeAt'](_0x518bac+0x1)<<0x10|_0xa36c84['charCodeAt'](_0x518bac+0x2)<<0x8|_0xa36c84['charCodeAt'](_0x518bac+0x3),_0x518bac+=0x4;}else{for(let _0x37c994=0x0;_0x37c994<0x10;_0x37c994++)_0x4f0282[_0x37c994]=_0xa36c84[_0x518bac]<<0x18|_0xa36c84[_0x518bac+0x1]<<0x10|_0xa36c84[_0x518bac+0x2]<<0x8|_0xa36c84[_0x518bac+0x3],_0x518bac+=0x4;}for(let _0xc1dcb7=0x10;_0xc1dcb7<0x50;_0xc1dcb7++){const _0x1de557=_0x4f0282[_0xc1dcb7-0x3]^_0x4f0282[_0xc1dcb7-0x8]^_0x4f0282[_0xc1dcb7-0xe]^_0x4f0282[_0xc1dcb7-0x10];_0x4f0282[_0xc1dcb7]=(_0x1de557<<0x1|_0x1de557>>>0x1f)&0xffffffff;}let _0x5c09fd=this['chain_'][0x0],_0x117563=this['chain_'][0x1],_0x3f1af6=this['chain_'][0x2],_0x1708d5=this['chain_'][0x3],_0x3e669b=this['chain_'][0x4],_0x317ceb,_0x2b769c;for(let _0x1630d4=0x0;_0x1630d4<0x50;_0x1630d4++){_0x1630d4<0x28?_0x1630d4<0x14?(_0x317ceb=_0x1708d5^_0x117563&(_0x3f1af6^_0x1708d5),_0x2b769c=0x5a827999):(_0x317ceb=_0x117563^_0x3f1af6^_0x1708d5,_0x2b769c=0x6ed9eba1):_0x1630d4<0x3c?(_0x317ceb=_0x117563&_0x3f1af6|_0x1708d5&(_0x117563|_0x3f1af6),_0x2b769c=0x8f1bbcdc):(_0x317ceb=_0x117563^_0x3f1af6^_0x1708d5,_0x2b769c=0xca62c1d6);const _0xa88a93=(_0x5c09fd<<0x5|_0x5c09fd>>>0x1b)+_0x317ceb+_0x3e669b+_0x2b769c+_0x4f0282[_0x1630d4]&0xffffffff;_0x3e669b=_0x1708d5,_0x1708d5=_0x3f1af6,_0x3f1af6=(_0x117563<<0x1e|_0x117563>>>0x2)&0xffffffff,_0x117563=_0x5c09fd,_0x5c09fd=_0xa88a93;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5c09fd&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x117563&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3f1af6&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1708d5&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3e669b&0xffffffff;}['update'](_0x3305b7,_0x4d2b4c){if(_0x3305b7==null)return;_0x4d2b4c===void 0x0&&(_0x4d2b4c=_0x3305b7['length']);const _0x1a8ccc=_0x4d2b4c-this['blockSize'];let _0x227441=0x0;const _0x2c7347=this['buf_'];let _0xefd036=this['inbuf_'];for(;_0x227441<_0x4d2b4c;){if(_0xefd036===0x0){for(;_0x227441<=_0x1a8ccc;)this['compress_'](_0x3305b7,_0x227441),_0x227441+=this['blockSize'];}if(typeof _0x3305b7=='string'){for(;_0x227441<_0x4d2b4c;)if(_0x2c7347[_0xefd036]=_0x3305b7['charCodeAt'](_0x227441),++_0xefd036,++_0x227441,_0xefd036===this['blockSize']){this['compress_'](_0x2c7347),_0xefd036=0x0;break;}}else{for(;_0x227441<_0x4d2b4c;)if(_0x2c7347[_0xefd036]=_0x3305b7[_0x227441],++_0xefd036,++_0x227441,_0xefd036===this['blockSize']){this['compress_'](_0x2c7347),_0xefd036=0x0;break;}}}this['inbuf_']=_0xefd036,this['total_']+=_0x4d2b4c;}['digest'](){const _0x26c2e0=[];let _0x244c9f=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2a3751=this['blockSize']-0x1;_0x2a3751>=0x38;_0x2a3751--)this['buf_'][_0x2a3751]=_0x244c9f&0xff,_0x244c9f/=0x100;this['compress_'](this['buf_']);let _0x33fc1b=0x0;for(let _0x237ff7=0x0;_0x237ff7<0x5;_0x237ff7++)for(let _0xf24139=0x18;_0xf24139>=0x0;_0xf24139-=0x8)_0x26c2e0[_0x33fc1b]=this['chain_'][_0x237ff7]>>_0xf24139&0xff,++_0x33fc1b;return _0x26c2e0;}}function Tc(_0x4c13c,_0x372c23){const _0x485302=new Sc(_0x4c13c,_0x372c23);return _0x485302['subscribe']['bind'](_0x485302);}class Sc{constructor(_0xd87ce0,_0x5f447d){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x5f447d,this['task']['then'](()=>{_0xd87ce0(this);})['catch'](_0x56f0f8=>{this['error'](_0x56f0f8);});}['next'](_0x18549c){this['forEachObserver'](_0x54b681=>{_0x54b681['next'](_0x18549c);});}['error'](_0x419855){this['forEachObserver'](_0x318872=>{_0x318872['error'](_0x419855);}),this['close'](_0x419855);}['complete'](){this['forEachObserver'](_0x20a131=>{_0x20a131['complete']();}),this['close']();}['subscribe'](_0x16366e,_0x58b4b9,_0x3d33c0){let _0x40ef14;if(_0x16366e===void 0x0&&_0x58b4b9===void 0x0&&_0x3d33c0===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x16366e,['next','error','complete'])?_0x40ef14=_0x16366e:_0x40ef14={'next':_0x16366e,'error':_0x58b4b9,'complete':_0x3d33c0},_0x40ef14['next']===void 0x0&&(_0x40ef14['next']=ti),_0x40ef14['error']===void 0x0&&(_0x40ef14['error']=ti),_0x40ef14['complete']===void 0x0&&(_0x40ef14['complete']=ti);const _0x3778a6=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x40ef14['error'](this['finalError']):_0x40ef14['complete']();}catch{}}),this['observers']['push'](_0x40ef14),_0x3778a6;}['unsubscribeOne'](_0x197eb7){this['observers']===void 0x0||this['observers'][_0x197eb7]===void 0x0||(delete this['observers'][_0x197eb7],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x441221){if(!this['finalized']){for(let _0x54b6ea=0x0;_0x54b6ea<this['observers']['length'];_0x54b6ea++)this['sendOne'](_0x54b6ea,_0x441221);}}['sendOne'](_0x4bb76a,_0xa3269a){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4bb76a]!==void 0x0)try{_0xa3269a(this['observers'][_0x4bb76a]);}catch(_0xb2db5e){typeof console<'u'&&console['error']&&console['error'](_0xb2db5e);}});}['close'](_0x1f0533){this['finalized']||(this['finalized']=!0x0,_0x1f0533!==void 0x0&&(this['finalError']=_0x1f0533),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x1fd408,_0x105a1){if(typeof _0x1fd408!='object'||_0x1fd408===null)return!0x1;for(const _0x35f986 of _0x105a1)if(_0x35f986 in _0x1fd408&&typeof _0x1fd408[_0x35f986]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x591080,_0x48e025){return _0x591080+'\x20failed:\x20'+_0x48e025+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x454d1c){const _0x25d04b=[];let _0x661a58=0x0;for(let _0x2ebb60=0x0;_0x2ebb60<_0x454d1c['length'];_0x2ebb60++){let _0x4f9297=_0x454d1c['charCodeAt'](_0x2ebb60);if(_0x4f9297>=0xd800&&_0x4f9297<=0xdbff){const _0x557227=_0x4f9297-0xd800;_0x2ebb60++,f(_0x2ebb60<_0x454d1c['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5199f7=_0x454d1c['charCodeAt'](_0x2ebb60)-0xdc00;_0x4f9297=0x10000+(_0x557227<<0xa)+_0x5199f7;}_0x4f9297<0x80?_0x25d04b[_0x661a58++]=_0x4f9297:_0x4f9297<0x800?(_0x25d04b[_0x661a58++]=_0x4f9297>>0x6|0xc0,_0x25d04b[_0x661a58++]=_0x4f9297&0x3f|0x80):_0x4f9297<0x10000?(_0x25d04b[_0x661a58++]=_0x4f9297>>0xc|0xe0,_0x25d04b[_0x661a58++]=_0x4f9297>>0x6&0x3f|0x80,_0x25d04b[_0x661a58++]=_0x4f9297&0x3f|0x80):(_0x25d04b[_0x661a58++]=_0x4f9297>>0x12|0xf0,_0x25d04b[_0x661a58++]=_0x4f9297>>0xc&0x3f|0x80,_0x25d04b[_0x661a58++]=_0x4f9297>>0x6&0x3f|0x80,_0x25d04b[_0x661a58++]=_0x4f9297&0x3f|0x80);}return _0x25d04b;},Ln=function(_0x26d3dc){let _0x47f83c=0x0;for(let _0xca2f92=0x0;_0xca2f92<_0x26d3dc['length'];_0xca2f92++){const _0x4f66f3=_0x26d3dc['charCodeAt'](_0xca2f92);_0x4f66f3<0x80?_0x47f83c++:_0x4f66f3<0x800?_0x47f83c+=0x2:_0x4f66f3>=0xd800&&_0x4f66f3<=0xdbff?(_0x47f83c+=0x4,_0xca2f92++):_0x47f83c+=0x3;}return _0x47f83c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0xcd809){return _0xcd809&&_0xcd809['_delegate']?_0xcd809['_delegate']:_0xcd809;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x3fb16a){try{return(_0x3fb16a['startsWith']('http://')||_0x3fb16a['startsWith']('https://')?new URL(_0x3fb16a)['hostname']:_0x3fb16a)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x127483){return(await fetch(_0x127483,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x2d7dee,_0x2e4048,_0x3d1aa6){this['name']=_0x2d7dee,this['instanceFactory']=_0x2e4048,this['type']=_0x3d1aa6,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x33e2af){return this['instantiationMode']=_0x33e2af,this;}['setMultipleInstances'](_0x14c1f0){return this['multipleInstances']=_0x14c1f0,this;}['setServiceProps'](_0x2cf3f2){return this['serviceProps']=_0x2cf3f2,this;}['setInstanceCreatedCallback'](_0x1e6b0b){return this['onInstanceCreated']=_0x1e6b0b,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4f071d,_0x1bf2df){this['name']=_0x4f071d,this['container']=_0x1bf2df,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xc2a79b){const _0x39ab8d=this['normalizeInstanceIdentifier'](_0xc2a79b);if(!this['instancesDeferred']['has'](_0x39ab8d)){const _0x232930=new H();if(this['instancesDeferred']['set'](_0x39ab8d,_0x232930),this['isInitialized'](_0x39ab8d)||this['shouldAutoInitialize']())try{const _0x6179dc=this['getOrInitializeService']({'instanceIdentifier':_0x39ab8d});_0x6179dc&&_0x232930['resolve'](_0x6179dc);}catch{}}return this['instancesDeferred']['get'](_0x39ab8d)['promise'];}['getImmediate'](_0x4c88d7){const _0x4e4ab6=this['normalizeInstanceIdentifier'](_0x4c88d7==null?void 0x0:_0x4c88d7['identifier']),_0xa59bda=(_0x4c88d7==null?void 0x0:_0x4c88d7['optional'])??!0x1;if(this['isInitialized'](_0x4e4ab6)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4e4ab6});}catch(_0x400891){if(_0xa59bda)return null;throw _0x400891;}else{if(_0xa59bda)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x9dd8c9){if(_0x9dd8c9['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x9dd8c9['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x9dd8c9,!!this['shouldAutoInitialize']()){if(Pc(_0x9dd8c9))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x257648,_0x29af1d]of this['instancesDeferred']['entries']()){const _0x52d977=this['normalizeInstanceIdentifier'](_0x257648);try{const _0x6b007=this['getOrInitializeService']({'instanceIdentifier':_0x52d977});_0x29af1d['resolve'](_0x6b007);}catch{}}}}['clearInstance'](_0x206890=Ne){this['instancesDeferred']['delete'](_0x206890),this['instancesOptions']['delete'](_0x206890),this['instances']['delete'](_0x206890);}async['delete'](){const _0x2193fd=Array['from'](this['instances']['values']());await Promise['all']([..._0x2193fd['filter'](_0x2d4885=>'INTERNAL'in _0x2d4885)['map'](_0x99ab7c=>_0x99ab7c['INTERNAL']['delete']()),..._0x2193fd['filter'](_0x380194=>'_delete'in _0x380194)['map'](_0x18d346=>_0x18d346['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x149288=Ne){return this['instances']['has'](_0x149288);}['getOptions'](_0x44def7=Ne){return this['instancesOptions']['get'](_0x44def7)||{};}['initialize'](_0x1ae64e={}){const {options:_0x21a224={}}=_0x1ae64e,_0x51e401=this['normalizeInstanceIdentifier'](_0x1ae64e['instanceIdentifier']);if(this['isInitialized'](_0x51e401))throw Error(this['name']+'('+_0x51e401+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x238cf1=this['getOrInitializeService']({'instanceIdentifier':_0x51e401,'options':_0x21a224});for(const [_0x4fcbc2,_0x429a89]of this['instancesDeferred']['entries']()){const _0x41d50f=this['normalizeInstanceIdentifier'](_0x4fcbc2);_0x51e401===_0x41d50f&&_0x429a89['resolve'](_0x238cf1);}return _0x238cf1;}['onInit'](_0x3387e4,_0x315d52){const _0x22e57e=this['normalizeInstanceIdentifier'](_0x315d52),_0x48c17f=this['onInitCallbacks']['get'](_0x22e57e)??new Set();_0x48c17f['add'](_0x3387e4),this['onInitCallbacks']['set'](_0x22e57e,_0x48c17f);const _0x7be33d=this['instances']['get'](_0x22e57e);return _0x7be33d&&_0x3387e4(_0x7be33d,_0x22e57e),()=>{_0x48c17f['delete'](_0x3387e4);};}['invokeOnInitCallbacks'](_0x31792c,_0x35f0d1){const _0x4f60db=this['onInitCallbacks']['get'](_0x35f0d1);if(_0x4f60db){for(const _0x51c1b5 of _0x4f60db)try{_0x51c1b5(_0x31792c,_0x35f0d1);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1c5bd9,options:_0x5c6a09={}}){let _0xa4f874=this['instances']['get'](_0x1c5bd9);if(!_0xa4f874&&this['component']&&(_0xa4f874=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x1c5bd9),'options':_0x5c6a09}),this['instances']['set'](_0x1c5bd9,_0xa4f874),this['instancesOptions']['set'](_0x1c5bd9,_0x5c6a09),this['invokeOnInitCallbacks'](_0xa4f874,_0x1c5bd9),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1c5bd9,_0xa4f874);}catch{}return _0xa4f874||null;}['normalizeInstanceIdentifier'](_0x1782de=Ne){return this['component']?this['component']['multipleInstances']?_0x1782de:Ne:_0x1782de;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x50162b){return _0x50162b===Ne?void 0x0:_0x50162b;}function Pc(_0x3fd22d){return _0x3fd22d['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x416d3e){this['name']=_0x416d3e,this['providers']=new Map();}['addComponent'](_0x164af7){const _0x342c02=this['getProvider'](_0x164af7['name']);if(_0x342c02['isComponentSet']())throw new Error('Component\x20'+_0x164af7['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x342c02['setComponent'](_0x164af7);}['addOrOverwriteComponent'](_0x41795b){this['getProvider'](_0x41795b['name'])['isComponentSet']()&&this['providers']['delete'](_0x41795b['name']),this['addComponent'](_0x41795b);}['getProvider'](_0x50daf1){if(this['providers']['has'](_0x50daf1))return this['providers']['get'](_0x50daf1);const _0x56d497=new Ac(_0x50daf1,this);return this['providers']['set'](_0x50daf1,_0x56d497),_0x56d497;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x5b9d14){_0x5b9d14[_0x5b9d14['DEBUG']=0x0]='DEBUG',_0x5b9d14[_0x5b9d14['VERBOSE']=0x1]='VERBOSE',_0x5b9d14[_0x5b9d14['INFO']=0x2]='INFO',_0x5b9d14[_0x5b9d14['WARN']=0x3]='WARN',_0x5b9d14[_0x5b9d14['ERROR']=0x4]='ERROR',_0x5b9d14[_0x5b9d14['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x361614,_0x527492,..._0x3db574)=>{if(_0x527492<_0x361614['logLevel'])return;const _0x2bab1f=new Date()['toISOString'](),_0x4aace3=Mc[_0x527492];if(_0x4aace3)console[_0x4aace3]('['+_0x2bab1f+']\x20\x20'+_0x361614['name']+':',..._0x3db574);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x527492+')');};class Bi{constructor(_0x38126d){this['name']=_0x38126d,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5e794a){if(!(_0x5e794a in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5e794a+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5e794a;}['setLogLevel'](_0x42a7f3){this['_logLevel']=typeof _0x42a7f3=='string'?Oc[_0x42a7f3]:_0x42a7f3;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3c83e5){if(typeof _0x3c83e5!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3c83e5;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1cfea0){this['_userLogHandler']=_0x1cfea0;}['debug'](..._0x1c091a){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1c091a),this['_logHandler'](this,T['DEBUG'],..._0x1c091a);}['log'](..._0x1539b9){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1539b9),this['_logHandler'](this,T['VERBOSE'],..._0x1539b9);}['info'](..._0x4a464d){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x4a464d),this['_logHandler'](this,T['INFO'],..._0x4a464d);}['warn'](..._0x48cab2){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x48cab2),this['_logHandler'](this,T['WARN'],..._0x48cab2);}['error'](..._0xc0c0cf){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0xc0c0cf),this['_logHandler'](this,T['ERROR'],..._0xc0c0cf);}}const xc=(_0x3b8149,_0x135170)=>_0x135170['some'](_0x2ee67d=>_0x3b8149 instanceof _0x2ee67d);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x5f212f){const _0x14dfbb=new Promise((_0x5c4edf,_0x21d077)=>{const _0x5c4074=()=>{_0x5f212f['removeEventListener']('success',_0x56db73),_0x5f212f['removeEventListener']('error',_0x3cb1d8);},_0x56db73=()=>{_0x5c4edf(ge(_0x5f212f['result'])),_0x5c4074();},_0x3cb1d8=()=>{_0x21d077(_0x5f212f['error']),_0x5c4074();};_0x5f212f['addEventListener']('success',_0x56db73),_0x5f212f['addEventListener']('error',_0x3cb1d8);});return _0x14dfbb['then'](_0xc74e9b=>{_0xc74e9b instanceof IDBCursor&&Jr['set'](_0xc74e9b,_0x5f212f);})['catch'](()=>{}),Vi['set'](_0x14dfbb,_0x5f212f),_0x14dfbb;}function Bc(_0x4c7968){if(_i['has'](_0x4c7968))return;const _0x43c951=new Promise((_0x187544,_0x4993f2)=>{const _0x32d12b=()=>{_0x4c7968['removeEventListener']('complete',_0x71e9ee),_0x4c7968['removeEventListener']('error',_0x57d969),_0x4c7968['removeEventListener']('abort',_0x57d969);},_0x71e9ee=()=>{_0x187544(),_0x32d12b();},_0x57d969=()=>{_0x4993f2(_0x4c7968['error']||new DOMException('AbortError','AbortError')),_0x32d12b();};_0x4c7968['addEventListener']('complete',_0x71e9ee),_0x4c7968['addEventListener']('error',_0x57d969),_0x4c7968['addEventListener']('abort',_0x57d969);});_i['set'](_0x4c7968,_0x43c951);}let gi={'get'(_0x5f0a1c,_0x2b5f20,_0x31353c){if(_0x5f0a1c instanceof IDBTransaction){if(_0x2b5f20==='done')return _i['get'](_0x5f0a1c);if(_0x2b5f20==='objectStoreNames')return _0x5f0a1c['objectStoreNames']||Xr['get'](_0x5f0a1c);if(_0x2b5f20==='store')return _0x31353c['objectStoreNames'][0x1]?void 0x0:_0x31353c['objectStore'](_0x31353c['objectStoreNames'][0x0]);}return ge(_0x5f0a1c[_0x2b5f20]);},'set'(_0x1d794c,_0x51fcce,_0x598d80){return _0x1d794c[_0x51fcce]=_0x598d80,!0x0;},'has'(_0x16f6aa,_0x37bd00){return _0x16f6aa instanceof IDBTransaction&&(_0x37bd00==='done'||_0x37bd00==='store')?!0x0:_0x37bd00 in _0x16f6aa;}};function Vc(_0xdac320){gi=_0xdac320(gi);}function Hc(_0x181d35){return _0x181d35===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x408373,..._0x44eeb9){const _0x21e7f9=_0x181d35['call'](ii(this),_0x408373,..._0x44eeb9);return Xr['set'](_0x21e7f9,_0x408373['sort']?_0x408373['sort']():[_0x408373]),ge(_0x21e7f9);}:Uc()['includes'](_0x181d35)?function(..._0x4e10ee){return _0x181d35['apply'](ii(this),_0x4e10ee),ge(Jr['get'](this));}:function(..._0x149765){return ge(_0x181d35['apply'](ii(this),_0x149765));};}function $c(_0xed37b4){return typeof _0xed37b4=='function'?Hc(_0xed37b4):(_0xed37b4 instanceof IDBTransaction&&Bc(_0xed37b4),xc(_0xed37b4,Fc())?new Proxy(_0xed37b4,gi):_0xed37b4);}function ge(_0xacf266){if(_0xacf266 instanceof IDBRequest)return Wc(_0xacf266);if(ni['has'](_0xacf266))return ni['get'](_0xacf266);const _0x75f3ab=$c(_0xacf266);return _0x75f3ab!==_0xacf266&&(ni['set'](_0xacf266,_0x75f3ab),Vi['set'](_0x75f3ab,_0xacf266)),_0x75f3ab;}const ii=_0x5818ff=>Vi['get'](_0x5818ff);function Gc(_0x1d0cc5,_0x3f96f2,{blocked:_0x23696e,upgrade:_0x5c7e88,blocking:_0x57654e,terminated:_0x11e548}={}){const _0x20f4a3=indexedDB['open'](_0x1d0cc5,_0x3f96f2),_0x3ea4ee=ge(_0x20f4a3);return _0x5c7e88&&_0x20f4a3['addEventListener']('upgradeneeded',_0x44cddc=>{_0x5c7e88(ge(_0x20f4a3['result']),_0x44cddc['oldVersion'],_0x44cddc['newVersion'],ge(_0x20f4a3['transaction']),_0x44cddc);}),_0x23696e&&_0x20f4a3['addEventListener']('blocked',_0x1a9571=>_0x23696e(_0x1a9571['oldVersion'],_0x1a9571['newVersion'],_0x1a9571)),_0x3ea4ee['then'](_0x24fe24=>{_0x11e548&&_0x24fe24['addEventListener']('close',()=>_0x11e548()),_0x57654e&&_0x24fe24['addEventListener']('versionchange',_0x194516=>_0x57654e(_0x194516['oldVersion'],_0x194516['newVersion'],_0x194516));})['catch'](()=>{}),_0x3ea4ee;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x6b3799,_0x58813e){if(!(_0x6b3799 instanceof IDBDatabase&&!(_0x58813e in _0x6b3799)&&typeof _0x58813e=='string'))return;if(si['get'](_0x58813e))return si['get'](_0x58813e);const _0x7bc11d=_0x58813e['replace'](/FromIndex$/,''),_0x5e7cb5=_0x58813e!==_0x7bc11d,_0x5ef39c=zc['includes'](_0x7bc11d);if(!(_0x7bc11d in(_0x5e7cb5?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5ef39c||qc['includes'](_0x7bc11d)))return;const _0xf81f75=async function(_0x5ecbd2,..._0xbfebe6){const _0x1eb6d7=this['transaction'](_0x5ecbd2,_0x5ef39c?'readwrite':'readonly');let _0x2090fa=_0x1eb6d7['store'];return _0x5e7cb5&&(_0x2090fa=_0x2090fa['index'](_0xbfebe6['shift']())),(await Promise['all']([_0x2090fa[_0x7bc11d](..._0xbfebe6),_0x5ef39c&&_0x1eb6d7['done']]))[0x0];};return si['set'](_0x58813e,_0xf81f75),_0xf81f75;}Vc(_0x152af3=>({..._0x152af3,'get':(_0x1815fe,_0x791a4c,_0x4d2a6e)=>Ms(_0x1815fe,_0x791a4c)||_0x152af3['get'](_0x1815fe,_0x791a4c,_0x4d2a6e),'has':(_0x460051,_0x4d6d9b)=>!!Ms(_0x460051,_0x4d6d9b)||_0x152af3['has'](_0x460051,_0x4d6d9b)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x1aa86a){this['container']=_0x1aa86a;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x3814a6=>{if(Kc(_0x3814a6)){const _0x3d4005=_0x3814a6['getImmediate']();return _0x3d4005['library']+'/'+_0x3d4005['version'];}else return null;})['filter'](_0x1dbe5b=>_0x1dbe5b)['join']('\x20');}}function Kc(_0x356d1b){const _0x21d698=_0x356d1b['getComponent']();return(_0x21d698==null?void 0x0:_0x21d698['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x157e1c,_0x177a65){try{_0x157e1c['container']['addComponent'](_0x177a65);}catch(_0x232fce){oe['debug']('Component\x20'+_0x177a65['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x157e1c['name'],_0x232fce);}}function st(_0x501b1c){const _0x2414a9=_0x501b1c['name'];if(Ei['has'](_0x2414a9))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x2414a9+'.'),!0x1;Ei['set'](_0x2414a9,_0x501b1c);for(const _0x1ae2e7 of Ue['values']())xs(_0x1ae2e7,_0x501b1c);for(const _0x451b4f of vi['values']())xs(_0x451b4f,_0x501b1c);return!0x0;}function Hi(_0xbcdac6,_0x208433){const _0x2e4074=_0xbcdac6['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x2e4074&&_0x2e4074['triggerHeartbeat'](),_0xbcdac6['container']['getProvider'](_0x208433);}function $(_0x687a79){return _0x687a79==null?!0x1:_0x687a79['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0xcb6ef4,_0x464b44,_0x10f1e7){this['_isDeleted']=!0x1,this['_options']={..._0xcb6ef4},this['_config']={..._0x464b44},this['_name']=_0x464b44['name'],this['_automaticDataCollectionEnabled']=_0x464b44['automaticDataCollectionEnabled'],this['_container']=_0x10f1e7,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2f2c13){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2f2c13;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x4717cb){this['_isDeleted']=_0x4717cb;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x423c2d,_0x654b3c={}){let _0x40c53b=_0x423c2d;typeof _0x654b3c!='object'&&(_0x654b3c={'name':_0x654b3c});const _0x32ed56={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x654b3c},_0x1f09c7=_0x32ed56['name'];if(typeof _0x1f09c7!='string'||!_0x1f09c7)throw me['create']('bad-app-name',{'appName':String(_0x1f09c7)});if(_0x40c53b||(_0x40c53b=zr()),!_0x40c53b)throw me['create']('no-options');const _0x23e8fe=Ue['get'](_0x1f09c7);if(_0x23e8fe){if(xe(_0x40c53b,_0x23e8fe['options'])&&xe(_0x32ed56,_0x23e8fe['config']))return _0x23e8fe;throw me['create']('duplicate-app',{'appName':_0x1f09c7});}const _0x456116=new Nc(_0x1f09c7);for(const _0x5cfa0b of Ei['values']())_0x456116['addComponent'](_0x5cfa0b);const _0x2ee067=new Tl(_0x40c53b,_0x32ed56,_0x456116);return Ue['set'](_0x1f09c7,_0x2ee067),_0x2ee067;}function Zr(_0x4cc4de=yi){const _0x57ae37=Ue['get'](_0x4cc4de);if(!_0x57ae37&&_0x4cc4de===yi&&zr())return Sl();if(!_0x57ae37)throw me['create']('no-app',{'appName':_0x4cc4de});return _0x57ae37;}function g_(){return Array['from'](Ue['values']());}async function m_(_0xa896f9){let _0x59ce5f=!0x1;const _0x35570d=_0xa896f9['name'];Ue['has'](_0x35570d)?(_0x59ce5f=!0x0,Ue['delete'](_0x35570d)):vi['has'](_0x35570d)&&_0xa896f9['decRefCount']()<=0x0&&(vi['delete'](_0x35570d),_0x59ce5f=!0x0),_0x59ce5f&&(await Promise['all'](_0xa896f9['container']['getProviders']()['map'](_0x2f5a95=>_0x2f5a95['delete']())),_0xa896f9['isDeleted']=!0x0);}function ye(_0x3a070a,_0x58d4e5,_0x3e61cd){let _0x18b128=wl[_0x3a070a]??_0x3a070a;_0x3e61cd&&(_0x18b128+='-'+_0x3e61cd);const _0x10592c=_0x18b128['match'](/\s|\//),_0x2fe9a1=_0x58d4e5['match'](/\s|\//);if(_0x10592c||_0x2fe9a1){const _0x5b1ff9=['Unable\x20to\x20register\x20library\x20\x22'+_0x18b128+'\x22\x20with\x20version\x20\x22'+_0x58d4e5+'\x22:'];_0x10592c&&_0x5b1ff9['push']('library\x20name\x20\x22'+_0x18b128+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x10592c&&_0x2fe9a1&&_0x5b1ff9['push']('and'),_0x2fe9a1&&_0x5b1ff9['push']('version\x20name\x20\x22'+_0x58d4e5+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x5b1ff9['join']('\x20'));return;}st(new Fe(_0x18b128+'-version',()=>({'library':_0x18b128,'version':_0x58d4e5}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x47445c,_0x1f6b9a)=>{switch(_0x1f6b9a){case 0x0:try{_0x47445c['createObjectStore'](Ot);}catch(_0x59f587){console['warn'](_0x59f587);}}}})['catch'](_0x41bc4e=>{throw me['create']('idb-open',{'originalErrorMessage':_0x41bc4e['message']});})),ri;}async function Al(_0x1efcc1){try{const _0x1cbce9=(await eo())['transaction'](Ot),_0x186d68=await _0x1cbce9['objectStore'](Ot)['get'](to(_0x1efcc1));return await _0x1cbce9['done'],_0x186d68;}catch(_0x2240f2){if(_0x2240f2 instanceof Re)oe['warn'](_0x2240f2['message']);else{const _0xb28eec=me['create']('idb-get',{'originalErrorMessage':_0x2240f2==null?void 0x0:_0x2240f2['message']});oe['warn'](_0xb28eec['message']);}}}async function Fs(_0x4c13ed,_0x5c2d23){try{const _0x260da5=(await eo())['transaction'](Ot,'readwrite');await _0x260da5['objectStore'](Ot)['put'](_0x5c2d23,to(_0x4c13ed)),await _0x260da5['done'];}catch(_0x58b118){if(_0x58b118 instanceof Re)oe['warn'](_0x58b118['message']);else{const _0x3f8d82=me['create']('idb-set',{'originalErrorMessage':_0x58b118==null?void 0x0:_0x58b118['message']});oe['warn'](_0x3f8d82['message']);}}}function to(_0x2642a7){return _0x2642a7['name']+'!'+_0x2642a7['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x15975b){this['container']=_0x15975b,this['_heartbeatsCache']=null;const _0x45cec6=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x45cec6),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x273238=>(this['_heartbeatsCache']=_0x273238,_0x273238));}async['triggerHeartbeat'](){var _0x15fed0,_0x5df5e9;try{const _0x52bcc6=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xbed258=Us();if(((_0x15fed0=this['_heartbeatsCache'])==null?void 0x0:_0x15fed0['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5df5e9=this['_heartbeatsCache'])==null?void 0x0:_0x5df5e9['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xbed258||this['_heartbeatsCache']['heartbeats']['some'](_0x3f1cde=>_0x3f1cde['date']===_0xbed258))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xbed258,'agent':_0x52bcc6}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0xc0e58d=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0xc0e58d,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4d1236){oe['warn'](_0x4d1236);}}async['getHeartbeatsHeader'](){var _0x1da49e;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1da49e=this['_heartbeatsCache'])==null?void 0x0:_0x1da49e['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1ba1b8=Us(),{heartbeatsToSend:_0x56b8a0,unsentEntries:_0x1f9d3f}=Ol(this['_heartbeatsCache']['heartbeats']),_0x2e6027=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x56b8a0}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1ba1b8,_0x1f9d3f['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x1f9d3f,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2e6027;}catch(_0x134931){return oe['warn'](_0x134931),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x1ca8df,_0x44bf8c=kl){const _0x16e74a=[];let _0x30ed77=_0x1ca8df['slice']();for(const _0xaa3f77 of _0x1ca8df){const _0x1706df=_0x16e74a['find'](_0xfcb25a=>_0xfcb25a['agent']===_0xaa3f77['agent']);if(_0x1706df){if(_0x1706df['dates']['push'](_0xaa3f77['date']),Ws(_0x16e74a)>_0x44bf8c){_0x1706df['dates']['pop']();break;}}else{if(_0x16e74a['push']({'agent':_0xaa3f77['agent'],'dates':[_0xaa3f77['date']]}),Ws(_0x16e74a)>_0x44bf8c){_0x16e74a['pop']();break;}}_0x30ed77=_0x30ed77['slice'](0x1);}return{'heartbeatsToSend':_0x16e74a,'unsentEntries':_0x30ed77};}class Dl{constructor(_0x584674){this['app']=_0x584674,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x1c644c=await Al(this['app']);return _0x1c644c!=null&&_0x1c644c['heartbeats']?_0x1c644c:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x10bddc){if(await this['_canUseIndexedDBPromise']){const _0x1b8ac9=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x10bddc['lastSentHeartbeatDate']??_0x1b8ac9['lastSentHeartbeatDate'],'heartbeats':_0x10bddc['heartbeats']});}else return;}async['add'](_0x2e75a9){if(await this['_canUseIndexedDBPromise']){const _0x373892=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x2e75a9['lastSentHeartbeatDate']??_0x373892['lastSentHeartbeatDate'],'heartbeats':[..._0x373892['heartbeats'],..._0x2e75a9['heartbeats']]});}else return;}}function Ws(_0x3c47b9){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3c47b9}))['length'];}function Ml(_0x27e375){if(_0x27e375['length']===0x0)return-0x1;let _0x3d419f=0x0,_0x39d583=_0x27e375[0x0]['date'];for(let _0x56fac5=0x1;_0x56fac5<_0x27e375['length'];_0x56fac5++)_0x27e375[_0x56fac5]['date']<_0x39d583&&(_0x39d583=_0x27e375[_0x56fac5]['date'],_0x3d419f=_0x56fac5);return _0x3d419f;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1ae47f){st(new Fe('platform-logger',_0xaa5dd8=>new jc(_0xaa5dd8),'PRIVATE')),st(new Fe('heartbeat',_0x2fc419=>new Nl(_0x2fc419),'PRIVATE')),ye(mi,Ls,_0x1ae47f),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x256f24){no=_0x256f24;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x441f62){this['domStorage_']=_0x441f62,this['prefix_']='firebase:';}['set'](_0x3d69fd,_0x42e258){_0x42e258==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3d69fd)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3d69fd),O(_0x42e258));}['get'](_0x6c8afe){const _0xcde52=this['domStorage_']['getItem'](this['prefixedName_'](_0x6c8afe));return _0xcde52==null?null:Nt(_0xcde52);}['remove'](_0x1f0a99){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1f0a99));}['prefixedName_'](_0x3afc43){return this['prefix_']+_0x3afc43;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2130db,_0x13e51c){_0x13e51c==null?delete this['cache_'][_0x2130db]:this['cache_'][_0x2130db]=_0x13e51c;}['get'](_0x2b4937){return Q(this['cache_'],_0x2b4937)?this['cache_'][_0x2b4937]:null;}['remove'](_0x17755b){delete this['cache_'][_0x17755b];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x2ddb3d){try{if(typeof window<'u'&&typeof window[_0x2ddb3d]<'u'){const _0x4e3c97=window[_0x2ddb3d];return _0x4e3c97['setItem']('firebase:sentinel','cache'),_0x4e3c97['removeItem']('firebase:sentinel'),new Wl(_0x4e3c97);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x4c8a5b=0x1;return function(){return _0x4c8a5b++;};}()),ro=function(_0x2e9600){const _0x1f5ba6=Rc(_0x2e9600),_0x35ff02=new Cc();_0x35ff02['update'](_0x1f5ba6);const _0xd9624d=_0x35ff02['digest']();return Fi['encodeByteArray'](_0xd9624d);},zt=function(..._0x4d2ca9){let _0xeef5e2='';for(let _0x16a90e=0x0;_0x16a90e<_0x4d2ca9['length'];_0x16a90e++){const _0x590d6f=_0x4d2ca9[_0x16a90e];Array['isArray'](_0x590d6f)||_0x590d6f&&typeof _0x590d6f=='object'&&typeof _0x590d6f['length']=='number'?_0xeef5e2+=zt['apply'](null,_0x590d6f):typeof _0x590d6f=='object'?_0xeef5e2+=O(_0x590d6f):_0xeef5e2+=_0x590d6f,_0xeef5e2+='\x20';}return _0xeef5e2;};let St=null,$s=!0x0;const Hl=function(_0x3a9b16,_0x283fe4){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x520197){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x1abad6=zt['apply'](null,_0x520197);St(_0x1abad6);}},jt=function(_0x52683c){return function(..._0x1f14ec){L(_0x52683c,..._0x1f14ec);};},Ii=function(..._0x50600f){const _0x55b196='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x50600f);Ze['error'](_0x55b196);},ae=function(..._0x18498f){const _0x2ebd11='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x18498f);throw Ze['error'](_0x2ebd11),new Error(_0x2ebd11);},U=function(..._0x243300){const _0x398c58='FIREBASE\x20WARNING:\x20'+zt(..._0x243300);Ze['warn'](_0x398c58);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x2d82f2){return typeof _0x2d82f2=='number'&&(_0x2d82f2!==_0x2d82f2||_0x2d82f2===Number['POSITIVE_INFINITY']||_0x2d82f2===Number['NEGATIVE_INFINITY']);},Gl=function(_0x33ccd6){if(document['readyState']==='complete')_0x33ccd6();else{let _0x353485=!0x1;const _0x2a2142=function(){if(!document['body']){setTimeout(_0x2a2142,Math['floor'](0xa));return;}_0x353485||(_0x353485=!0x0,_0x33ccd6());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2a2142,!0x1),window['addEventListener']('load',_0x2a2142,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2a2142();}),window['attachEvent']('onload',_0x2a2142));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x55a3c9,_0x515a57){if(_0x55a3c9===_0x515a57)return 0x0;if(_0x55a3c9===We||_0x515a57===we)return-0x1;if(_0x515a57===We||_0x55a3c9===we)return 0x1;{const _0x4359d4=Gs(_0x55a3c9),_0x4dadce=Gs(_0x515a57);return _0x4359d4!==null?_0x4dadce!==null?_0x4359d4-_0x4dadce===0x0?_0x55a3c9['length']-_0x515a57['length']:_0x4359d4-_0x4dadce:-0x1:_0x4dadce!==null?0x1:_0x55a3c9<_0x515a57?-0x1:0x1;}},ql=function(_0x3c6430,_0x40d1f8){return _0x3c6430===_0x40d1f8?0x0:_0x3c6430<_0x40d1f8?-0x1:0x1;},vt=function(_0xb74e4a,_0x28f0b6){if(_0x28f0b6&&_0xb74e4a in _0x28f0b6)return _0x28f0b6[_0xb74e4a];throw new Error('Missing\x20required\x20key\x20('+_0xb74e4a+')\x20in\x20object:\x20'+O(_0x28f0b6));},$i=function(_0x31499d){if(typeof _0x31499d!='object'||_0x31499d===null)return O(_0x31499d);const _0x1b60a5=[];for(const _0x11eac8 in _0x31499d)_0x1b60a5['push'](_0x11eac8);_0x1b60a5['sort']();let _0x7683b4='{';for(let _0x1d927a=0x0;_0x1d927a<_0x1b60a5['length'];_0x1d927a++)_0x1d927a!==0x0&&(_0x7683b4+=','),_0x7683b4+=O(_0x1b60a5[_0x1d927a]),_0x7683b4+=':',_0x7683b4+=$i(_0x31499d[_0x1b60a5[_0x1d927a]]);return _0x7683b4+='}',_0x7683b4;},oo=function(_0x698b1c,_0x480ae0){const _0x4fc406=_0x698b1c['length'];if(_0x4fc406<=_0x480ae0)return[_0x698b1c];const _0x4d8148=[];for(let _0x1330b7=0x0;_0x1330b7<_0x4fc406;_0x1330b7+=_0x480ae0)_0x1330b7+_0x480ae0>_0x4fc406?_0x4d8148['push'](_0x698b1c['substring'](_0x1330b7,_0x4fc406)):_0x4d8148['push'](_0x698b1c['substring'](_0x1330b7,_0x1330b7+_0x480ae0));return _0x4d8148;};function x(_0x26ed67,_0x16667e){for(const _0x3438c8 in _0x26ed67)_0x26ed67['hasOwnProperty'](_0x3438c8)&&_0x16667e(_0x3438c8,_0x26ed67[_0x3438c8]);}const ao=function(_0x26fd60){f(!xn(_0x26fd60),'Invalid\x20JSON\x20number');const _0x5614f0=0xb,_0x5a7d11=0x34,_0x3d3b69=(0x1<<_0x5614f0-0x1)-0x1;let _0x52ff19,_0xba1933,_0x257d7f,_0x3c8234,_0xdd99c2;_0x26fd60===0x0?(_0xba1933=0x0,_0x257d7f=0x0,_0x52ff19=0x1/_0x26fd60===-0x1/0x0?0x1:0x0):(_0x52ff19=_0x26fd60<0x0,_0x26fd60=Math['abs'](_0x26fd60),_0x26fd60>=Math['pow'](0x2,0x1-_0x3d3b69)?(_0x3c8234=Math['min'](Math['floor'](Math['log'](_0x26fd60)/Math['LN2']),_0x3d3b69),_0xba1933=_0x3c8234+_0x3d3b69,_0x257d7f=Math['round'](_0x26fd60*Math['pow'](0x2,_0x5a7d11-_0x3c8234)-Math['pow'](0x2,_0x5a7d11))):(_0xba1933=0x0,_0x257d7f=Math['round'](_0x26fd60/Math['pow'](0x2,0x1-_0x3d3b69-_0x5a7d11))));const _0x845808=[];for(_0xdd99c2=_0x5a7d11;_0xdd99c2;_0xdd99c2-=0x1)_0x845808['push'](_0x257d7f%0x2?0x1:0x0),_0x257d7f=Math['floor'](_0x257d7f/0x2);for(_0xdd99c2=_0x5614f0;_0xdd99c2;_0xdd99c2-=0x1)_0x845808['push'](_0xba1933%0x2?0x1:0x0),_0xba1933=Math['floor'](_0xba1933/0x2);_0x845808['push'](_0x52ff19?0x1:0x0),_0x845808['reverse']();const _0x5447cc=_0x845808['join']('');let _0x4b26eb='';for(_0xdd99c2=0x0;_0xdd99c2<0x40;_0xdd99c2+=0x8){let _0x5d546e=parseInt(_0x5447cc['substr'](_0xdd99c2,0x8),0x2)['toString'](0x10);_0x5d546e['length']===0x1&&(_0x5d546e='0'+_0x5d546e),_0x4b26eb=_0x4b26eb+_0x5d546e;}return _0x4b26eb['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x537c60,_0x16afd2){let _0x38edd8='Unknown\x20Error';_0x537c60==='too_big'?_0x38edd8='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x537c60==='permission_denied'?_0x38edd8='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x537c60==='unavailable'&&(_0x38edd8='The\x20service\x20is\x20unavailable');const _0x517fa3=new Error(_0x537c60+'\x20at\x20'+_0x16afd2['_path']['toString']()+':\x20'+_0x38edd8);return _0x517fa3['code']=_0x537c60['toUpperCase'](),_0x517fa3;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x222f1f){if(Yl['test'](_0x222f1f)){const _0x340558=Number(_0x222f1f);if(_0x340558>=Ql&&_0x340558<=Jl)return _0x340558;}return null;},ft=function(_0x5592df){try{_0x5592df();}catch(_0x2c38a9){setTimeout(()=>{const _0x5ddf4f=_0x2c38a9['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5ddf4f),_0x2c38a9;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x3949df,_0x5c97b1){const _0x487279=setTimeout(_0x3949df,_0x5c97b1);return typeof _0x487279=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x487279):typeof _0x487279=='object'&&_0x487279['unref']&&_0x487279['unref'](),_0x487279;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x53e3d2,_0x370a2a){this['appCheckProvider']=_0x370a2a,this['appName']=_0x53e3d2['name'],$(_0x53e3d2)&&_0x53e3d2['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x53e3d2['settings']['appCheckToken']),this['appCheck']=_0x370a2a==null?void 0x0:_0x370a2a['getImmediate']({'optional':!0x0}),this['appCheck']||_0x370a2a==null||_0x370a2a['get']()['then'](_0x2c82fd=>this['appCheck']=_0x2c82fd);}['getToken'](_0x2b0293){if(this['serverAppAppCheckToken']){if(_0x2b0293)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2b0293):new Promise((_0x463ee4,_0x5ee10c)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2b0293)['then'](_0x463ee4,_0x5ee10c):_0x463ee4(null);},0x0);});}['addTokenChangeListener'](_0x20eb3c){var _0x14d4ae;(_0x14d4ae=this['appCheckProvider'])==null||_0x14d4ae['get']()['then'](_0x53a5f3=>_0x53a5f3['addTokenListener'](_0x20eb3c));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x36de7d,_0x44255,_0x4122a1){this['appName_']=_0x36de7d,this['firebaseOptions_']=_0x44255,this['authProvider_']=_0x4122a1,this['auth_']=null,this['auth_']=_0x4122a1['getImmediate']({'optional':!0x0}),this['auth_']||_0x4122a1['onInit'](_0x28a8fe=>this['auth_']=_0x28a8fe);}['getToken'](_0x645cc3){return this['auth_']?this['auth_']['getToken'](_0x645cc3)['catch'](_0x341ee6=>_0x341ee6&&_0x341ee6['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x341ee6)):new Promise((_0x2dd248,_0x56ece8)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x645cc3)['then'](_0x2dd248,_0x56ece8):_0x2dd248(null);},0x0);});}['addTokenChangeListener'](_0x327b10){this['auth_']?this['auth_']['addAuthTokenListener'](_0x327b10):this['authProvider_']['get']()['then'](_0x4aa8ce=>_0x4aa8ce['addAuthTokenListener'](_0x327b10));}['removeTokenChangeListener'](_0x6ddd60){this['authProvider_']['get']()['then'](_0x12ca64=>_0x12ca64['removeAuthTokenListener'](_0x6ddd60));}['notifyForInvalidToken'](){let _0x1d0d0d='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1d0d0d+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1d0d0d+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1d0d0d+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1d0d0d);}}class an{constructor(_0x5d1186){this['accessToken']=_0x5d1186;}['getToken'](_0x54e5c3){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x1eccac){_0x1eccac(this['accessToken']);}['removeTokenChangeListener'](_0x235a30){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x38f500,_0x391d2a,_0xd4f4a1,_0x11b4ad,_0x18515c=!0x1,_0x4c5706='',_0x31e7da=!0x1,_0x518932=!0x1,_0x296ea7=null){this['secure']=_0x391d2a,this['namespace']=_0xd4f4a1,this['webSocketOnly']=_0x11b4ad,this['nodeAdmin']=_0x18515c,this['persistenceKey']=_0x4c5706,this['includeNamespaceInQueryParams']=_0x31e7da,this['isUsingEmulator']=_0x518932,this['emulatorOptions']=_0x296ea7,this['_host']=_0x38f500['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x38f500)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x375e73){_0x375e73!==this['internalHost']&&(this['internalHost']=_0x375e73,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x358bc8=this['toURLString']();return this['persistenceKey']&&(_0x358bc8+='<'+this['persistenceKey']+'>'),_0x358bc8;}['toURLString'](){const _0x48cfd1=this['secure']?'https://':'http://',_0x46264d=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x48cfd1+this['host']+'/'+_0x46264d;}}function th(_0x12945c){return _0x12945c['host']!==_0x12945c['internalHost']||_0x12945c['isCustomHost']()||_0x12945c['includeNamespaceInQueryParams'];}function vo(_0x3fb1fa,_0x5a1622,_0xd89bbe){f(typeof _0x5a1622=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0xd89bbe=='object','typeof\x20params\x20must\x20==\x20object');let _0x3b8970;if(_0x5a1622===go)_0x3b8970=(_0x3fb1fa['secure']?'wss://':'ws://')+_0x3fb1fa['internalHost']+'/.ws?';else{if(_0x5a1622===mo)_0x3b8970=(_0x3fb1fa['secure']?'https://':'http://')+_0x3fb1fa['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x5a1622);}th(_0x3fb1fa)&&(_0xd89bbe['ns']=_0x3fb1fa['namespace']);const _0x3389d8=[];return x(_0xd89bbe,(_0x3c3a87,_0x1e4a8c)=>{_0x3389d8['push'](_0x3c3a87+'='+_0x1e4a8c);}),_0x3b8970+_0x3389d8['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x46eb53,_0x44a6e1=0x1){Q(this['counters_'],_0x46eb53)||(this['counters_'][_0x46eb53]=0x0),this['counters_'][_0x46eb53]+=_0x44a6e1;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x3d6e55){const _0x284925=_0x3d6e55['toString']();return oi[_0x284925]||(oi[_0x284925]=new nh()),oi[_0x284925];}function ih(_0x5a80a2,_0x15ed10){const _0x371830=_0x5a80a2['toString']();return ai[_0x371830]||(ai[_0x371830]=_0x15ed10()),ai[_0x371830];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x520dbd){this['onMessage_']=_0x520dbd,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5aea42,_0x5e5e13){this['closeAfterResponse']=_0x5aea42,this['onClose']=_0x5e5e13,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x296cc6,_0x3e7015){for(this['pendingResponses'][_0x296cc6]=_0x3e7015;this['pendingResponses'][this['currentResponseNum']];){const _0x26f8ed=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x21c7d8=0x0;_0x21c7d8<_0x26f8ed['length'];++_0x21c7d8)_0x26f8ed[_0x21c7d8]&&ft(()=>{this['onMessage_'](_0x26f8ed[_0x21c7d8]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x2383b4,_0x1ebd11,_0x418200,_0x14ed21,_0xbcf1a9,_0x2cf5cd,_0x55501c){this['connId']=_0x2383b4,this['repoInfo']=_0x1ebd11,this['applicationId']=_0x418200,this['appCheckToken']=_0x14ed21,this['authToken']=_0xbcf1a9,this['transportSessionId']=_0x2cf5cd,this['lastSessionId']=_0x55501c,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x2383b4),this['stats_']=qi(_0x1ebd11),this['urlFn']=_0x373294=>(this['appCheckToken']&&(_0x373294[wi]=this['appCheckToken']),vo(_0x1ebd11,mo,_0x373294));}['open'](_0x46fc5b,_0x3bf7ba){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3bf7ba,this['myPacketOrderer']=new sh(_0x46fc5b),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x2d4867)=>{const [_0x7677bc,_0x5097c5,_0x44dfd6,_0x5e913,_0x700580]=_0x2d4867;if(this['incrementIncomingBytes_'](_0x2d4867),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x7677bc===qs)this['id']=_0x5097c5,this['password']=_0x44dfd6;else{if(_0x7677bc===rh)_0x5097c5?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5097c5,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x7677bc);}}},(..._0x576d2f)=>{const [_0x3ec814,_0x2a714e]=_0x576d2f;this['incrementIncomingBytes_'](_0x576d2f),this['myPacketOrderer']['handleResponse'](_0x3ec814,_0x2a714e);},()=>{this['onClosed_']();},this['urlFn']);const _0x5b6d05={};_0x5b6d05[qs]='t',_0x5b6d05[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5b6d05[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5b6d05[co]=Gi,this['transportSessionId']&&(_0x5b6d05[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x5b6d05[po]=this['lastSessionId']),this['applicationId']&&(_0x5b6d05[_o]=this['applicationId']),this['appCheckToken']&&(_0x5b6d05[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x5b6d05[ho]=uo);const _0x225849=this['urlFn'](_0x5b6d05);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x225849),this['scriptTagHolder']['addTag'](_0x225849,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1b54b0){const _0xba6ee4=O(_0x1b54b0);this['bytesSent']+=_0xba6ee4['length'],this['stats_']['incrementCounter']('bytes_sent',_0xba6ee4['length']);const _0x2c410d=$r(_0xba6ee4),_0x79ab29=oo(_0x2c410d,fh);for(let _0x55b28d=0x0;_0x55b28d<_0x79ab29['length'];_0x55b28d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x79ab29['length'],_0x79ab29[_0x55b28d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x14d487,_0x57b0b8){this['myDisconnFrame']=document['createElement']('iframe');const _0x5a33fd={};_0x5a33fd[dh]='t',_0x5a33fd[Eo]=_0x14d487,_0x5a33fd[Io]=_0x57b0b8,this['myDisconnFrame']['src']=this['urlFn'](_0x5a33fd),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x246ee5){const _0x28173f=O(_0x246ee5)['length'];this['bytesReceived']+=_0x28173f,this['stats_']['incrementCounter']('bytes_received',_0x28173f);}}class zi{constructor(_0x47a046,_0x453a0c,_0x2e9d9c,_0x5a2c18){this['onDisconnect']=_0x2e9d9c,this['urlFn']=_0x5a2c18,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x47a046,window[ah+this['uniqueCallbackIdentifier']]=_0x453a0c,this['myIFrame']=zi['createIFrame_']();let _0x4df09a='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4df09a='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x15a3a5='<html><body>'+_0x4df09a+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x15a3a5),this['myIFrame']['doc']['close']();}catch(_0xfbfec2){L('frame\x20writing\x20exception'),_0xfbfec2['stack']&&L(_0xfbfec2['stack']),L(_0xfbfec2);}}}static['createIFrame_'](){const _0x35f36f=document['createElement']('iframe');if(_0x35f36f['style']['display']='none',document['body']){document['body']['appendChild'](_0x35f36f);try{_0x35f36f['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x38857e=document['domain'];_0x35f36f['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x38857e+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x35f36f['contentDocument']?_0x35f36f['doc']=_0x35f36f['contentDocument']:_0x35f36f['contentWindow']?_0x35f36f['doc']=_0x35f36f['contentWindow']['document']:_0x35f36f['document']&&(_0x35f36f['doc']=_0x35f36f['document']),_0x35f36f;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x596ff2=this['onDisconnect'];_0x596ff2&&(this['onDisconnect']=null,_0x596ff2());}['startLongPoll'](_0x3bed82,_0x1bf0c3){for(this['myID']=_0x3bed82,this['myPW']=_0x1bf0c3,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x46a587={};_0x46a587[Eo]=this['myID'],_0x46a587[Io]=this['myPW'],_0x46a587[wo]=this['currentSerial'];let _0x2246d1=this['urlFn'](_0x46a587),_0x4e75e='',_0x45460f=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x4e75e['length']<=Co;){const _0xc92b4=this['pendingSegs']['shift']();_0x4e75e=_0x4e75e+'&'+lh+_0x45460f+'='+_0xc92b4['seg']+'&'+hh+_0x45460f+'='+_0xc92b4['ts']+'&'+uh+_0x45460f+'='+_0xc92b4['d'],_0x45460f++;}return _0x2246d1=_0x2246d1+_0x4e75e,this['addLongPollTag_'](_0x2246d1,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0xa5d63a,_0x28da2f,_0x1c9219){this['pendingSegs']['push']({'seg':_0xa5d63a,'ts':_0x28da2f,'d':_0x1c9219}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x54d3a2,_0x5dd2f7){this['outstandingRequests']['add'](_0x5dd2f7);const _0x2b0864=()=>{this['outstandingRequests']['delete'](_0x5dd2f7),this['newRequest_']();},_0x5abe7b=setTimeout(_0x2b0864,Math['floor'](ph)),_0x14c369=()=>{clearTimeout(_0x5abe7b),_0x2b0864();};this['addTag'](_0x54d3a2,_0x14c369);}['addTag'](_0x2d6785,_0xa75155){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x2d8dde=this['myIFrame']['doc']['createElement']('script');_0x2d8dde['type']='text/javascript',_0x2d8dde['async']=!0x0,_0x2d8dde['src']=_0x2d6785,_0x2d8dde['onload']=_0x2d8dde['onreadystatechange']=function(){const _0x141031=_0x2d8dde['readyState'];(!_0x141031||_0x141031==='loaded'||_0x141031==='complete')&&(_0x2d8dde['onload']=_0x2d8dde['onreadystatechange']=null,_0x2d8dde['parentNode']&&_0x2d8dde['parentNode']['removeChild'](_0x2d8dde),_0xa75155());},_0x2d8dde['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2d6785),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x2d8dde);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x554daa,_0x5d81e7,_0x14ba0d,_0x3abd65,_0x41cd88,_0x1cbe25,_0x351dd7){this['connId']=_0x554daa,this['applicationId']=_0x14ba0d,this['appCheckToken']=_0x3abd65,this['authToken']=_0x41cd88,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x5d81e7),this['connURL']=q['connectionURL_'](_0x5d81e7,_0x1cbe25,_0x351dd7,_0x3abd65,_0x14ba0d),this['nodeAdmin']=_0x5d81e7['nodeAdmin'];}static['connectionURL_'](_0x41c7cb,_0x25f301,_0x6220,_0x5322a0,_0x5d229d){const _0x43ff02={};return _0x43ff02[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x43ff02[ho]=uo),_0x25f301&&(_0x43ff02[lo]=_0x25f301),_0x6220&&(_0x43ff02[po]=_0x6220),_0x5322a0&&(_0x43ff02[wi]=_0x5322a0),_0x5d229d&&(_0x43ff02[_o]=_0x5d229d),vo(_0x41c7cb,go,_0x43ff02);}['open'](_0x1d88ca,_0xed528d){this['onDisconnect']=_0xed528d,this['onMessage']=_0x1d88ca,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x5d191f;_c(),this['mySock']=new gn(this['connURL'],[],_0x5d191f);}catch(_0x1a3c21){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x36ea17=_0x1a3c21['message']||_0x1a3c21['data'];_0x36ea17&&this['log_'](_0x36ea17),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x338dc0=>{this['handleIncomingFrame'](_0x338dc0);},this['mySock']['onerror']=_0x5427f5=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xdafa99=_0x5427f5['message']||_0x5427f5['data'];_0xdafa99&&this['log_'](_0xdafa99),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3738ea=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x42519b=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3b0a45=navigator['userAgent']['match'](_0x42519b);_0x3b0a45&&_0x3b0a45['length']>0x1&&parseFloat(_0x3b0a45[0x1])<4.4&&(_0x3738ea=!0x0);}return!_0x3738ea&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x2fc675){if(this['frames']['push'](_0x2fc675),this['frames']['length']===this['totalFrames']){const _0x2347be=this['frames']['join']('');this['frames']=null;const _0x2403dc=Nt(_0x2347be);this['onMessage'](_0x2403dc);}}['handleNewFrameCount_'](_0x5c6237){this['totalFrames']=_0x5c6237,this['frames']=[];}['extractFrameCount_'](_0x32e48b){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x32e48b['length']<=0x6){const _0x5a29ec=Number(_0x32e48b);if(!isNaN(_0x5a29ec))return this['handleNewFrameCount_'](_0x5a29ec),null;}return this['handleNewFrameCount_'](0x1),_0x32e48b;}['handleIncomingFrame'](_0x23cb09){if(this['mySock']===null)return;const _0x16c52a=_0x23cb09['data'];if(this['bytesReceived']+=_0x16c52a['length'],this['stats_']['incrementCounter']('bytes_received',_0x16c52a['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x16c52a);else{const _0x25f68b=this['extractFrameCount_'](_0x16c52a);_0x25f68b!==null&&this['appendFrame_'](_0x25f68b);}}['send'](_0x2c618f){this['resetKeepAlive']();const _0x4e440f=O(_0x2c618f);this['bytesSent']+=_0x4e440f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4e440f['length']);const _0x9f4758=oo(_0x4e440f,gh);_0x9f4758['length']>0x1&&this['sendString_'](String(_0x9f4758['length']));for(let _0x5a22bf=0x0;_0x5a22bf<_0x9f4758['length'];_0x5a22bf++)this['sendString_'](_0x9f4758[_0x5a22bf]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x1a46ff){try{this['mySock']['send'](_0x1a46ff);}catch(_0x14ad63){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x14ad63['message']||_0x14ad63['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2671bc){this['initTransports_'](_0x2671bc);}['initTransports_'](_0x2c73df){const _0x173a59=q&&q['isAvailable']();let _0x1b729f=_0x173a59&&!q['previouslyFailed']();if(_0x2c73df['webSocketOnly']&&(_0x173a59||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1b729f=!0x0),_0x1b729f)this['transports_']=[q];else{const _0x587113=this['transports_']=[];for(const _0x4d8137 of Dt['ALL_TRANSPORTS'])_0x4d8137&&_0x4d8137['isAvailable']()&&_0x587113['push'](_0x4d8137);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x5b0b25,_0x40c4ba,_0x5411b0,_0x5502fd,_0x234038,_0x2393af,_0x488652,_0x26e4c6,_0x26625f,_0x18e506){this['id']=_0x5b0b25,this['repoInfo_']=_0x40c4ba,this['applicationId_']=_0x5411b0,this['appCheckToken_']=_0x5502fd,this['authToken_']=_0x234038,this['onMessage_']=_0x2393af,this['onReady_']=_0x488652,this['onDisconnect_']=_0x26e4c6,this['onKill_']=_0x26625f,this['lastSessionId']=_0x18e506,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x40c4ba),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4d6a44=this['transportManager_']['initialTransport']();this['conn_']=new _0x4d6a44(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4d6a44['responsesRequiredToBeHealthy']||0x0;const _0x11974f=this['connReceiver_'](this['conn_']),_0x46bb20=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x11974f,_0x46bb20);},Math['floor'](0x0));const _0x10a86b=_0x4d6a44['healthyTimeout']||0x0;_0x10a86b>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x10a86b)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x428801){return _0x14b0b4=>{_0x428801===this['conn_']?this['onConnectionLost_'](_0x14b0b4):_0x428801===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xf68f97){return _0x26ded4=>{this['state_']!==0x2&&(_0xf68f97===this['rx_']?this['onPrimaryMessageReceived_'](_0x26ded4):_0xf68f97===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x26ded4):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4a1b6d){const _0x399fed={'t':'d','d':_0x4a1b6d};this['sendData_'](_0x399fed);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x220cff){if(ci in _0x220cff){const _0x880446=_0x220cff[ci];_0x880446===Ys?this['upgradeIfSecondaryHealthy_']():_0x880446===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x880446===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x5f34eb){const _0x4f516f=vt('t',_0x5f34eb),_0x3821a7=vt('d',_0x5f34eb);if(_0x4f516f==='c')this['onSecondaryControl_'](_0x3821a7);else{if(_0x4f516f==='d')this['pendingDataMessages']['push'](_0x3821a7);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4f516f);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x47f8eb){const _0x54ead0=vt('t',_0x47f8eb),_0x24f212=vt('d',_0x47f8eb);_0x54ead0==='c'?this['onControl_'](_0x24f212):_0x54ead0==='d'&&this['onDataMessage_'](_0x24f212);}['onDataMessage_'](_0x4d4592){this['onPrimaryResponse_'](),this['onMessage_'](_0x4d4592);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x172ea6){const _0x38d44d=vt(ci,_0x172ea6);if(zs in _0x172ea6){const _0x1e95fa=_0x172ea6[zs];if(_0x38d44d===Th){const _0x576b8a={..._0x1e95fa};this['repoInfo_']['isUsingEmulator']&&(_0x576b8a['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x576b8a);}else{if(_0x38d44d===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2877b8=0x0;_0x2877b8<this['pendingDataMessages']['length'];++_0x2877b8)this['onDataMessage_'](this['pendingDataMessages'][_0x2877b8]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x38d44d===wh?this['onConnectionShutdown_'](_0x1e95fa):_0x38d44d===js?this['onReset_'](_0x1e95fa):_0x38d44d===Ch?Ii('Server\x20Error:\x20'+_0x1e95fa):_0x38d44d===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x38d44d);}}}['onHandshake_'](_0x30606d){const _0x3e9e08=_0x30606d['ts'],_0x6fb908=_0x30606d['v'],_0xbafe55=_0x30606d['h'];this['sessionId']=_0x30606d['s'],this['repoInfo_']['host']=_0xbafe55,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3e9e08),Gi!==_0x6fb908&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x21eed9=this['transportManager_']['upgradeTransport']();_0x21eed9&&this['startUpgrade_'](_0x21eed9);}['startUpgrade_'](_0x3bfa10){this['secondaryConn_']=new _0x3bfa10(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x3bfa10['responsesRequiredToBeHealthy']||0x0;const _0x1b881c=this['connReceiver_'](this['secondaryConn_']),_0x5b14f3=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1b881c,_0x5b14f3),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x58addc){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x58addc),this['repoInfo_']['host']=_0x58addc,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x27d57b,_0x5c5944){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x27d57b,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x5c5944,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x1f0632=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x1f0632||this['rx_']===_0x1f0632)&&this['close']();}['onConnectionLost_'](_0x57a292){this['conn_']=null,!_0x57a292&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5875b8){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5875b8),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x478eca){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x478eca);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3a4a32,_0x420997,_0x28733f,_0x3fa1dc){}['merge'](_0x3b27ac,_0xe95b3f,_0x302a2e,_0x396fe7){}['refreshAuthToken'](_0x49e474){}['refreshAppCheckToken'](_0x3a7df3){}['onDisconnectPut'](_0xcafc2d,_0x13da45,_0x3e9c76){}['onDisconnectMerge'](_0x345dd1,_0x19e148,_0x4e3b23){}['onDisconnectCancel'](_0x3c5a08,_0x563fd7){}['reportStats'](_0x24a521){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x3fecb7){this['allowedEvents_']=_0x3fecb7,this['listeners_']={},f(Array['isArray'](_0x3fecb7)&&_0x3fecb7['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0xfc5266,..._0x44d2cb){if(Array['isArray'](this['listeners_'][_0xfc5266])){const _0x4cf921=[...this['listeners_'][_0xfc5266]];for(let _0x5257b0=0x0;_0x5257b0<_0x4cf921['length'];_0x5257b0++)_0x4cf921[_0x5257b0]['callback']['apply'](_0x4cf921[_0x5257b0]['context'],_0x44d2cb);}}['on'](_0xa0dd44,_0x3d549a,_0x442d2d){this['validateEventType_'](_0xa0dd44),this['listeners_'][_0xa0dd44]=this['listeners_'][_0xa0dd44]||[],this['listeners_'][_0xa0dd44]['push']({'callback':_0x3d549a,'context':_0x442d2d});const _0x446e4c=this['getInitialEvent'](_0xa0dd44);_0x446e4c&&_0x3d549a['apply'](_0x442d2d,_0x446e4c);}['off'](_0x1caf96,_0x5b0662,_0x206b17){this['validateEventType_'](_0x1caf96);const _0x164258=this['listeners_'][_0x1caf96]||[];for(let _0x2cb871=0x0;_0x2cb871<_0x164258['length'];_0x2cb871++)if(_0x164258[_0x2cb871]['callback']===_0x5b0662&&(!_0x206b17||_0x206b17===_0x164258[_0x2cb871]['context'])){_0x164258['splice'](_0x2cb871,0x1);return;}}['validateEventType_'](_0x344b27){f(this['allowedEvents_']['find'](_0xe97504=>_0xe97504===_0x344b27),'Unknown\x20event:\x20'+_0x344b27);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x332140){return f(_0x332140==='online','Unknown\x20event\x20type:\x20'+_0x332140),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0xc9e30f,_0x5b2fdf){if(_0x5b2fdf===void 0x0){this['pieces_']=_0xc9e30f['split']('/');let _0x43d14f=0x0;for(let _0x43a471=0x0;_0x43a471<this['pieces_']['length'];_0x43a471++)this['pieces_'][_0x43a471]['length']>0x0&&(this['pieces_'][_0x43d14f]=this['pieces_'][_0x43a471],_0x43d14f++);this['pieces_']['length']=_0x43d14f,this['pieceNum_']=0x0;}else this['pieces_']=_0xc9e30f,this['pieceNum_']=_0x5b2fdf;}['toString'](){let _0x2f00b7='';for(let _0x386b66=this['pieceNum_'];_0x386b66<this['pieces_']['length'];_0x386b66++)this['pieces_'][_0x386b66]!==''&&(_0x2f00b7+='/'+this['pieces_'][_0x386b66]);return _0x2f00b7||'/';}}function w(){return new C('');}function y(_0x5027a6){return _0x5027a6['pieceNum_']>=_0x5027a6['pieces_']['length']?null:_0x5027a6['pieces_'][_0x5027a6['pieceNum_']];}function Ce(_0x1e4668){return _0x1e4668['pieces_']['length']-_0x1e4668['pieceNum_'];}function S(_0x284309){let _0x20d2c3=_0x284309['pieceNum_'];return _0x20d2c3<_0x284309['pieces_']['length']&&_0x20d2c3++,new C(_0x284309['pieces_'],_0x20d2c3);}function ji(_0x3f9c18){return _0x3f9c18['pieceNum_']<_0x3f9c18['pieces_']['length']?_0x3f9c18['pieces_'][_0x3f9c18['pieces_']['length']-0x1]:null;}function bh(_0x2ca429){let _0x4cf9fc='';for(let _0x4f4e6f=_0x2ca429['pieceNum_'];_0x4f4e6f<_0x2ca429['pieces_']['length'];_0x4f4e6f++)_0x2ca429['pieces_'][_0x4f4e6f]!==''&&(_0x4cf9fc+='/'+encodeURIComponent(String(_0x2ca429['pieces_'][_0x4f4e6f])));return _0x4cf9fc||'/';}function Mt(_0x3bd208,_0x2fb08e=0x0){return _0x3bd208['pieces_']['slice'](_0x3bd208['pieceNum_']+_0x2fb08e);}function Ro(_0x3dd9d0){if(_0x3dd9d0['pieceNum_']>=_0x3dd9d0['pieces_']['length'])return null;const _0x55dd65=[];for(let _0x4149b0=_0x3dd9d0['pieceNum_'];_0x4149b0<_0x3dd9d0['pieces_']['length']-0x1;_0x4149b0++)_0x55dd65['push'](_0x3dd9d0['pieces_'][_0x4149b0]);return new C(_0x55dd65,0x0);}function k(_0x27864e,_0x2f46dc){const _0x5f331b=[];for(let _0x5598b1=_0x27864e['pieceNum_'];_0x5598b1<_0x27864e['pieces_']['length'];_0x5598b1++)_0x5f331b['push'](_0x27864e['pieces_'][_0x5598b1]);if(_0x2f46dc instanceof C){for(let _0x3b648d=_0x2f46dc['pieceNum_'];_0x3b648d<_0x2f46dc['pieces_']['length'];_0x3b648d++)_0x5f331b['push'](_0x2f46dc['pieces_'][_0x3b648d]);}else{const _0x362bc6=_0x2f46dc['split']('/');for(let _0x422a7d=0x0;_0x422a7d<_0x362bc6['length'];_0x422a7d++)_0x362bc6[_0x422a7d]['length']>0x0&&_0x5f331b['push'](_0x362bc6[_0x422a7d]);}return new C(_0x5f331b,0x0);}function v(_0x11b9a7){return _0x11b9a7['pieceNum_']>=_0x11b9a7['pieces_']['length'];}function F(_0x478dcd,_0x3a0c07){const _0x2fb482=y(_0x478dcd),_0xf830ab=y(_0x3a0c07);if(_0x2fb482===null)return _0x3a0c07;if(_0x2fb482===_0xf830ab)return F(S(_0x478dcd),S(_0x3a0c07));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3a0c07+')\x20is\x20not\x20within\x20outerPath\x20('+_0x478dcd+')');}function Rh(_0x3bdd49,_0x4f73bf){const _0x3cf286=Mt(_0x3bdd49,0x0),_0x4b59a5=Mt(_0x4f73bf,0x0);for(let _0x34337c=0x0;_0x34337c<_0x3cf286['length']&&_0x34337c<_0x4b59a5['length'];_0x34337c++){const _0x29adec=qe(_0x3cf286[_0x34337c],_0x4b59a5[_0x34337c]);if(_0x29adec!==0x0)return _0x29adec;}return _0x3cf286['length']===_0x4b59a5['length']?0x0:_0x3cf286['length']<_0x4b59a5['length']?-0x1:0x1;}function Ki(_0x395806,_0x1b88bc){if(Ce(_0x395806)!==Ce(_0x1b88bc))return!0x1;for(let _0x467c41=_0x395806['pieceNum_'],_0x59a3b4=_0x1b88bc['pieceNum_'];_0x467c41<=_0x395806['pieces_']['length'];_0x467c41++,_0x59a3b4++)if(_0x395806['pieces_'][_0x467c41]!==_0x1b88bc['pieces_'][_0x59a3b4])return!0x1;return!0x0;}function G(_0x5d865f,_0x242540){let _0xb4c34b=_0x5d865f['pieceNum_'],_0x378273=_0x242540['pieceNum_'];if(Ce(_0x5d865f)>Ce(_0x242540))return!0x1;for(;_0xb4c34b<_0x5d865f['pieces_']['length'];){if(_0x5d865f['pieces_'][_0xb4c34b]!==_0x242540['pieces_'][_0x378273])return!0x1;++_0xb4c34b,++_0x378273;}return!0x0;}class Ah{constructor(_0x332d3e,_0x30dffe){this['errorPrefix_']=_0x30dffe,this['parts_']=Mt(_0x332d3e,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4fdb11=0x0;_0x4fdb11<this['parts_']['length'];_0x4fdb11++)this['byteLength_']+=Ln(this['parts_'][_0x4fdb11]);Ao(this);}}function kh(_0x579da7,_0x4e33dd){_0x579da7['parts_']['length']>0x0&&(_0x579da7['byteLength_']+=0x1),_0x579da7['parts_']['push'](_0x4e33dd),_0x579da7['byteLength_']+=Ln(_0x4e33dd),Ao(_0x579da7);}function Ph(_0x12f70f){const _0x2d778e=_0x12f70f['parts_']['pop']();_0x12f70f['byteLength_']-=Ln(_0x2d778e),_0x12f70f['parts_']['length']>0x0&&(_0x12f70f['byteLength_']-=0x1);}function Ao(_0x3d11ee){if(_0x3d11ee['byteLength_']>Zs)throw new Error(_0x3d11ee['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x3d11ee['byteLength_']+').');if(_0x3d11ee['parts_']['length']>Xs)throw new Error(_0x3d11ee['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x3d11ee));}function Oe(_0x53fc0d){return _0x53fc0d['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x53fc0d['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x3f0d51,_0x21bc54;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x21bc54='visibilitychange',_0x3f0d51='hidden'):typeof document['mozHidden']<'u'?(_0x21bc54='mozvisibilitychange',_0x3f0d51='mozHidden'):typeof document['msHidden']<'u'?(_0x21bc54='msvisibilitychange',_0x3f0d51='msHidden'):typeof document['webkitHidden']<'u'&&(_0x21bc54='webkitvisibilitychange',_0x3f0d51='webkitHidden')),this['visible_']=!0x0,_0x21bc54&&document['addEventListener'](_0x21bc54,()=>{const _0x3e7f33=!document[_0x3f0d51];_0x3e7f33!==this['visible_']&&(this['visible_']=_0x3e7f33,this['trigger']('visible',_0x3e7f33));},!0x1);}['getInitialEvent'](_0x33e066){return f(_0x33e066==='visible','Unknown\x20event\x20type:\x20'+_0x33e066),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x54226d,_0xe6fc3b,_0x25c2e2,_0xa2a2a8,_0x17b644,_0x3583a2,_0x5dd0bd,_0x59d286){if(super(),this['repoInfo_']=_0x54226d,this['applicationId_']=_0xe6fc3b,this['onDataUpdate_']=_0x25c2e2,this['onConnectStatus_']=_0xa2a2a8,this['onServerInfoUpdate_']=_0x17b644,this['authTokenProvider_']=_0x3583a2,this['appCheckTokenProvider_']=_0x5dd0bd,this['authOverride_']=_0x59d286,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x59d286)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x54226d['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0xc574f9,_0x57bcb3,_0x581980){const _0x126607=++this['requestNumber_'],_0x3c9cc5={'r':_0x126607,'a':_0xc574f9,'b':_0x57bcb3};this['log_'](O(_0x3c9cc5)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3c9cc5),_0x581980&&(this['requestCBHash_'][_0x126607]=_0x581980);}['get'](_0x4eb12c){this['initConnection_']();const _0x2fbe6e=new H(),_0x36e7c3={'action':'g','request':{'p':_0x4eb12c['_path']['toString'](),'q':_0x4eb12c['_queryObject']},'onComplete':_0x40b7b3=>{const _0x243c8b=_0x40b7b3['d'];_0x40b7b3['s']==='ok'?_0x2fbe6e['resolve'](_0x243c8b):_0x2fbe6e['reject'](_0x243c8b);}};this['outstandingGets_']['push'](_0x36e7c3),this['outstandingGetCount_']++;const _0x445eb7=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x445eb7),_0x2fbe6e['promise'];}['listen'](_0x5ae31c,_0x13d786,_0x55c673,_0x1da828){this['initConnection_']();const _0x35b53a=_0x5ae31c['_queryIdentifier'],_0x507e02=_0x5ae31c['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x507e02+'\x20'+_0x35b53a),this['listens']['has'](_0x507e02)||this['listens']['set'](_0x507e02,new Map()),f(_0x5ae31c['_queryParams']['isDefault']()||!_0x5ae31c['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x507e02)['has'](_0x35b53a),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1b71a9={'onComplete':_0x1da828,'hashFn':_0x13d786,'query':_0x5ae31c,'tag':_0x55c673};this['listens']['get'](_0x507e02)['set'](_0x35b53a,_0x1b71a9),this['connected_']&&this['sendListen_'](_0x1b71a9);}['sendGet_'](_0x4ffe00){const _0x2b66af=this['outstandingGets_'][_0x4ffe00];this['sendRequest']('g',_0x2b66af['request'],_0x527a69=>{delete this['outstandingGets_'][_0x4ffe00],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2b66af['onComplete']&&_0x2b66af['onComplete'](_0x527a69);});}['sendListen_'](_0x2db501){const _0x42a17c=_0x2db501['query'],_0x15d98c=_0x42a17c['_path']['toString'](),_0x35ec84=_0x42a17c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x15d98c+'\x20for\x20'+_0x35ec84);const _0x1433c4={'p':_0x15d98c},_0x347a01='q';_0x2db501['tag']&&(_0x1433c4['q']=_0x42a17c['_queryObject'],_0x1433c4['t']=_0x2db501['tag']),_0x1433c4['h']=_0x2db501['hashFn'](),this['sendRequest'](_0x347a01,_0x1433c4,_0x57f875=>{const _0x16b33c=_0x57f875['d'],_0x470da2=_0x57f875['s'];se['warnOnListenWarnings_'](_0x16b33c,_0x42a17c),(this['listens']['get'](_0x15d98c)&&this['listens']['get'](_0x15d98c)['get'](_0x35ec84))===_0x2db501&&(this['log_']('listen\x20response',_0x57f875),_0x470da2!=='ok'&&this['removeListen_'](_0x15d98c,_0x35ec84),_0x2db501['onComplete']&&_0x2db501['onComplete'](_0x470da2,_0x16b33c));});}static['warnOnListenWarnings_'](_0x458e5e,_0x491b22){if(_0x458e5e&&typeof _0x458e5e=='object'&&Q(_0x458e5e,'w')){const _0x2a5bf7=Le(_0x458e5e,'w');if(Array['isArray'](_0x2a5bf7)&&~_0x2a5bf7['indexOf']('no_index')){const _0x237f88='\x22.indexOn\x22:\x20\x22'+_0x491b22['_queryParams']['getIndex']()['toString']()+'\x22',_0x302fbe=_0x491b22['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x237f88+'\x20at\x20'+_0x302fbe+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3a6917){this['authToken_']=_0x3a6917,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3a6917);}['reduceReconnectDelayIfAdminCredential_'](_0x4c808b){(_0x4c808b&&_0x4c808b['length']===0x28||wc(_0x4c808b))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x22e9d9){this['appCheckToken_']=_0x22e9d9,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x3b40f4=this['authToken_'],_0x499c28=Ic(_0x3b40f4)?'auth':'gauth',_0x5953b6={'cred':_0x3b40f4};this['authOverride_']===null?_0x5953b6['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5953b6['authvar']=this['authOverride_']),this['sendRequest'](_0x499c28,_0x5953b6,_0x495c79=>{const _0x291915=_0x495c79['s'],_0x485208=_0x495c79['d']||'error';this['authToken_']===_0x3b40f4&&(_0x291915==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x291915,_0x485208));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0xa3aab6=>{const _0x21e43d=_0xa3aab6['s'],_0x2e8e87=_0xa3aab6['d']||'error';_0x21e43d==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x21e43d,_0x2e8e87);});}['unlisten'](_0x1fcc73,_0x1750d9){const _0x157252=_0x1fcc73['_path']['toString'](),_0x51b4af=_0x1fcc73['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x157252+'\x20'+_0x51b4af),f(_0x1fcc73['_queryParams']['isDefault']()||!_0x1fcc73['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x157252,_0x51b4af)&&this['connected_']&&this['sendUnlisten_'](_0x157252,_0x51b4af,_0x1fcc73['_queryObject'],_0x1750d9);}['sendUnlisten_'](_0x121bf8,_0xaf1ab6,_0x495e13,_0x3a50d3){this['log_']('Unlisten\x20on\x20'+_0x121bf8+'\x20for\x20'+_0xaf1ab6);const _0x111660={'p':_0x121bf8},_0x1c4f1d='n';_0x3a50d3&&(_0x111660['q']=_0x495e13,_0x111660['t']=_0x3a50d3),this['sendRequest'](_0x1c4f1d,_0x111660);}['onDisconnectPut'](_0x2ab87c,_0x216553,_0x39e421){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x2ab87c,_0x216553,_0x39e421):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2ab87c,'action':'o','data':_0x216553,'onComplete':_0x39e421});}['onDisconnectMerge'](_0x418f9d,_0x4e8284,_0xc37703){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x418f9d,_0x4e8284,_0xc37703):this['onDisconnectRequestQueue_']['push']({'pathString':_0x418f9d,'action':'om','data':_0x4e8284,'onComplete':_0xc37703});}['onDisconnectCancel'](_0x2490ef,_0x5d7505){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x2490ef,null,_0x5d7505):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2490ef,'action':'oc','data':null,'onComplete':_0x5d7505});}['sendOnDisconnect_'](_0x42e955,_0xf6d495,_0x4915eb,_0x318ad5){const _0x1d43d6={'p':_0xf6d495,'d':_0x4915eb};this['log_']('onDisconnect\x20'+_0x42e955,_0x1d43d6),this['sendRequest'](_0x42e955,_0x1d43d6,_0x2e7905=>{_0x318ad5&&setTimeout(()=>{_0x318ad5(_0x2e7905['s'],_0x2e7905['d']);},Math['floor'](0x0));});}['put'](_0x1e635e,_0x3af093,_0x3f4556,_0x5d5449){this['putInternal']('p',_0x1e635e,_0x3af093,_0x3f4556,_0x5d5449);}['merge'](_0x10e7f6,_0x2685b1,_0xff37e4,_0x356515){this['putInternal']('m',_0x10e7f6,_0x2685b1,_0xff37e4,_0x356515);}['putInternal'](_0x5e8e0f,_0x46462b,_0x17dcca,_0x50c02b,_0x3902b9){this['initConnection_']();const _0x26b63e={'p':_0x46462b,'d':_0x17dcca};_0x3902b9!==void 0x0&&(_0x26b63e['h']=_0x3902b9),this['outstandingPuts_']['push']({'action':_0x5e8e0f,'request':_0x26b63e,'onComplete':_0x50c02b}),this['outstandingPutCount_']++;const _0x21327e=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x21327e):this['log_']('Buffering\x20put:\x20'+_0x46462b);}['sendPut_'](_0x98fbcd){const _0x957071=this['outstandingPuts_'][_0x98fbcd]['action'],_0x8fa87a=this['outstandingPuts_'][_0x98fbcd]['request'],_0x36b5ea=this['outstandingPuts_'][_0x98fbcd]['onComplete'];this['outstandingPuts_'][_0x98fbcd]['queued']=this['connected_'],this['sendRequest'](_0x957071,_0x8fa87a,_0x3b7b24=>{this['log_'](_0x957071+'\x20response',_0x3b7b24),delete this['outstandingPuts_'][_0x98fbcd],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x36b5ea&&_0x36b5ea(_0x3b7b24['s'],_0x3b7b24['d']);});}['reportStats'](_0xccb7d6){if(this['connected_']){const _0x197101={'c':_0xccb7d6};this['log_']('reportStats',_0x197101),this['sendRequest']('s',_0x197101,_0x2b8b91=>{if(_0x2b8b91['s']!=='ok'){const _0x51af0a=_0x2b8b91['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x51af0a);}});}}['onDataMessage_'](_0x5ebcc4){if('r'in _0x5ebcc4){this['log_']('from\x20server:\x20'+O(_0x5ebcc4));const _0x536fb0=_0x5ebcc4['r'],_0x3ec2b1=this['requestCBHash_'][_0x536fb0];_0x3ec2b1&&(delete this['requestCBHash_'][_0x536fb0],_0x3ec2b1(_0x5ebcc4['b']));}else{if('error'in _0x5ebcc4)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5ebcc4['error'];'a'in _0x5ebcc4&&this['onDataPush_'](_0x5ebcc4['a'],_0x5ebcc4['b']);}}['onDataPush_'](_0x39d32a,_0x572203){this['log_']('handleServerMessage',_0x39d32a,_0x572203),_0x39d32a==='d'?this['onDataUpdate_'](_0x572203['p'],_0x572203['d'],!0x1,_0x572203['t']):_0x39d32a==='m'?this['onDataUpdate_'](_0x572203['p'],_0x572203['d'],!0x0,_0x572203['t']):_0x39d32a==='c'?this['onListenRevoked_'](_0x572203['p'],_0x572203['q']):_0x39d32a==='ac'?this['onAuthRevoked_'](_0x572203['s'],_0x572203['d']):_0x39d32a==='apc'?this['onAppCheckRevoked_'](_0x572203['s'],_0x572203['d']):_0x39d32a==='sd'?this['onSecurityDebugPacket_'](_0x572203):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x39d32a)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x186ff1,_0x4d8732){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x186ff1),this['lastSessionId']=_0x4d8732,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x516cbc){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x516cbc));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2eab3b){_0x2eab3b&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2eab3b;}['onOnline_'](_0x4d60df){_0x4d60df?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x564949=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x49f9fb=Math['max'](0x0,this['reconnectDelay_']-_0x564949);_0x49f9fb=Math['random']()*_0x49f9fb,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x49f9fb+'ms'),this['scheduleConnect_'](_0x49f9fb),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1d36d1=this['onDataMessage_']['bind'](this),_0x885235=this['onReady_']['bind'](this),_0x540178=this['onRealtimeDisconnect_']['bind'](this),_0x5c1144=this['id']+':'+se['nextConnectionId_']++,_0x5bb69f=this['lastSessionId'];let _0x314b81=!0x1,_0xe5da65=null;const _0x356e67=function(){_0xe5da65?_0xe5da65['close']():(_0x314b81=!0x0,_0x540178());},_0x4fd72f=function(_0xbb0156){f(_0xe5da65,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0xe5da65['sendRequest'](_0xbb0156);};this['realtime_']={'close':_0x356e67,'sendRequest':_0x4fd72f};const _0x568357=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2a8993,_0x4d35f0]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x568357),this['appCheckTokenProvider_']['getToken'](_0x568357)]);_0x314b81?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2a8993&&_0x2a8993['accessToken'],this['appCheckToken_']=_0x4d35f0&&_0x4d35f0['token'],_0xe5da65=new Sh(_0x5c1144,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1d36d1,_0x885235,_0x540178,_0x293cf3=>{U(_0x293cf3+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x5bb69f));}catch(_0x2e55d7){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2e55d7),_0x314b81||(this['repoInfo_']['nodeAdmin']&&U(_0x2e55d7),_0x356e67());}}}['interrupt'](_0x4b795c){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x4b795c),this['interruptReasons_'][_0x4b795c]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x10db7c){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x10db7c),delete this['interruptReasons_'][_0x10db7c],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x51721d){const _0x129c8a=_0x51721d-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x129c8a});}['cancelSentTransactions_'](){for(let _0x16bf51=0x0;_0x16bf51<this['outstandingPuts_']['length'];_0x16bf51++){const _0x10ff0a=this['outstandingPuts_'][_0x16bf51];_0x10ff0a&&'h'in _0x10ff0a['request']&&_0x10ff0a['queued']&&(_0x10ff0a['onComplete']&&_0x10ff0a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x16bf51],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x33f3e0,_0x55dda9){let _0x11b891;_0x55dda9?_0x11b891=_0x55dda9['map'](_0x305e6f=>$i(_0x305e6f))['join']('$'):_0x11b891='default';const _0x5f44d5=this['removeListen_'](_0x33f3e0,_0x11b891);_0x5f44d5&&_0x5f44d5['onComplete']&&_0x5f44d5['onComplete']('permission_denied');}['removeListen_'](_0x5e3087,_0x449d27){const _0x588472=new C(_0x5e3087)['toString']();let _0xf42d8d;if(this['listens']['has'](_0x588472)){const _0x21e941=this['listens']['get'](_0x588472);_0xf42d8d=_0x21e941['get'](_0x449d27),_0x21e941['delete'](_0x449d27),_0x21e941['size']===0x0&&this['listens']['delete'](_0x588472);}else _0xf42d8d=void 0x0;return _0xf42d8d;}['onAuthRevoked_'](_0x3002b9,_0x1e01b0){L('Auth\x20token\x20revoked:\x20'+_0x3002b9+'/'+_0x1e01b0),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3002b9==='invalid_token'||_0x3002b9==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x39dc82,_0x36cb0e){L('App\x20check\x20token\x20revoked:\x20'+_0x39dc82+'/'+_0x36cb0e),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x39dc82==='invalid_token'||_0x39dc82==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x293f35){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x293f35):'msg'in _0x293f35&&console['log']('FIREBASE:\x20'+_0x293f35['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x28b768 of this['listens']['values']())for(const _0x437ac7 of _0x28b768['values']())this['sendListen_'](_0x437ac7);for(let _0x676153=0x0;_0x676153<this['outstandingPuts_']['length'];_0x676153++)this['outstandingPuts_'][_0x676153]&&this['sendPut_'](_0x676153);for(;this['onDisconnectRequestQueue_']['length'];){const _0x54ebe2=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x54ebe2['action'],_0x54ebe2['pathString'],_0x54ebe2['data'],_0x54ebe2['onComplete']);}for(let _0x55d672=0x0;_0x55d672<this['outstandingGets_']['length'];_0x55d672++)this['outstandingGets_'][_0x55d672]&&this['sendGet_'](_0x55d672);}['sendConnectStats_'](){const _0x5d0e97={};let _0x42e7f0='js';_0x5d0e97['sdk.'+_0x42e7f0+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x5d0e97['framework.cordova']=0x1:Kr()&&(_0x5d0e97['framework.reactnative']=0x1),this['reportStats'](_0x5d0e97);}['shouldReconnect_'](){const _0x5917cc=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x5917cc;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x2e61c7,_0x532133){this['name']=_0x2e61c7,this['node']=_0x532133;}static['Wrap'](_0x1d221d,_0x54d325){return new E(_0x1d221d,_0x54d325);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xf17e31,_0x395cd6){const _0x33faee=new E(We,_0xf17e31),_0x55dd89=new E(We,_0x395cd6);return this['compare'](_0x33faee,_0x55dd89)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0xec13e3){sn=_0xec13e3;}['compare'](_0x4cc87e,_0x275d51){return qe(_0x4cc87e['name'],_0x275d51['name']);}['isDefinedOn'](_0x393ba4){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4def7d,_0x283c93){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x1cd08b,_0x2cc384){return f(typeof _0x1cd08b=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x1cd08b,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x136a60,_0x33b6c2,_0x654d6f,_0x53bf0b,_0x25db9e=null){this['isReverse_']=_0x53bf0b,this['resultGenerator_']=_0x25db9e,this['nodeStack_']=[];let _0x58eca0=0x1;for(;!_0x136a60['isEmpty']();)if(_0x136a60=_0x136a60,_0x58eca0=_0x33b6c2?_0x654d6f(_0x136a60['key'],_0x33b6c2):0x1,_0x53bf0b&&(_0x58eca0*=-0x1),_0x58eca0<0x0)this['isReverse_']?_0x136a60=_0x136a60['left']:_0x136a60=_0x136a60['right'];else{if(_0x58eca0===0x0){this['nodeStack_']['push'](_0x136a60);break;}else this['nodeStack_']['push'](_0x136a60),this['isReverse_']?_0x136a60=_0x136a60['right']:_0x136a60=_0x136a60['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x2db53f=this['nodeStack_']['pop'](),_0x1d7caa;if(this['resultGenerator_']?_0x1d7caa=this['resultGenerator_'](_0x2db53f['key'],_0x2db53f['value']):_0x1d7caa={'key':_0x2db53f['key'],'value':_0x2db53f['value']},this['isReverse_']){for(_0x2db53f=_0x2db53f['left'];!_0x2db53f['isEmpty']();)this['nodeStack_']['push'](_0x2db53f),_0x2db53f=_0x2db53f['right'];}else{for(_0x2db53f=_0x2db53f['right'];!_0x2db53f['isEmpty']();)this['nodeStack_']['push'](_0x2db53f),_0x2db53f=_0x2db53f['left'];}return _0x1d7caa;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5d27e8=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5d27e8['key'],_0x5d27e8['value']):{'key':_0x5d27e8['key'],'value':_0x5d27e8['value']};}}class M{constructor(_0x2a4915,_0x68e50e,_0x44bf68,_0x4e0fdb,_0x5ce7a4){this['key']=_0x2a4915,this['value']=_0x68e50e,this['color']=_0x44bf68??M['RED'],this['left']=_0x4e0fdb??B['EMPTY_NODE'],this['right']=_0x5ce7a4??B['EMPTY_NODE'];}['copy'](_0xb7e33d,_0x297d55,_0x9f7bcd,_0x50f156,_0x2bec22){return new M(_0xb7e33d??this['key'],_0x297d55??this['value'],_0x9f7bcd??this['color'],_0x50f156??this['left'],_0x2bec22??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x304485){return this['left']['inorderTraversal'](_0x304485)||!!_0x304485(this['key'],this['value'])||this['right']['inorderTraversal'](_0x304485);}['reverseTraversal'](_0x42e8a9){return this['right']['reverseTraversal'](_0x42e8a9)||_0x42e8a9(this['key'],this['value'])||this['left']['reverseTraversal'](_0x42e8a9);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0xb165d,_0x44cce9,_0x43f876){let _0x44067c=this;const _0x1f744a=_0x43f876(_0xb165d,_0x44067c['key']);return _0x1f744a<0x0?_0x44067c=_0x44067c['copy'](null,null,null,_0x44067c['left']['insert'](_0xb165d,_0x44cce9,_0x43f876),null):_0x1f744a===0x0?_0x44067c=_0x44067c['copy'](null,_0x44cce9,null,null,null):_0x44067c=_0x44067c['copy'](null,null,null,null,_0x44067c['right']['insert'](_0xb165d,_0x44cce9,_0x43f876)),_0x44067c['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x608075=this;return!_0x608075['left']['isRed_']()&&!_0x608075['left']['left']['isRed_']()&&(_0x608075=_0x608075['moveRedLeft_']()),_0x608075=_0x608075['copy'](null,null,null,_0x608075['left']['removeMin_'](),null),_0x608075['fixUp_']();}['remove'](_0x5be9c9,_0xcb6e34){let _0x4b1309,_0xd46e65;if(_0x4b1309=this,_0xcb6e34(_0x5be9c9,_0x4b1309['key'])<0x0)!_0x4b1309['left']['isEmpty']()&&!_0x4b1309['left']['isRed_']()&&!_0x4b1309['left']['left']['isRed_']()&&(_0x4b1309=_0x4b1309['moveRedLeft_']()),_0x4b1309=_0x4b1309['copy'](null,null,null,_0x4b1309['left']['remove'](_0x5be9c9,_0xcb6e34),null);else{if(_0x4b1309['left']['isRed_']()&&(_0x4b1309=_0x4b1309['rotateRight_']()),!_0x4b1309['right']['isEmpty']()&&!_0x4b1309['right']['isRed_']()&&!_0x4b1309['right']['left']['isRed_']()&&(_0x4b1309=_0x4b1309['moveRedRight_']()),_0xcb6e34(_0x5be9c9,_0x4b1309['key'])===0x0){if(_0x4b1309['right']['isEmpty']())return B['EMPTY_NODE'];_0xd46e65=_0x4b1309['right']['min_'](),_0x4b1309=_0x4b1309['copy'](_0xd46e65['key'],_0xd46e65['value'],null,null,_0x4b1309['right']['removeMin_']());}_0x4b1309=_0x4b1309['copy'](null,null,null,null,_0x4b1309['right']['remove'](_0x5be9c9,_0xcb6e34));}return _0x4b1309['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2530ce=this;return _0x2530ce['right']['isRed_']()&&!_0x2530ce['left']['isRed_']()&&(_0x2530ce=_0x2530ce['rotateLeft_']()),_0x2530ce['left']['isRed_']()&&_0x2530ce['left']['left']['isRed_']()&&(_0x2530ce=_0x2530ce['rotateRight_']()),_0x2530ce['left']['isRed_']()&&_0x2530ce['right']['isRed_']()&&(_0x2530ce=_0x2530ce['colorFlip_']()),_0x2530ce;}['moveRedLeft_'](){let _0x4fff89=this['colorFlip_']();return _0x4fff89['right']['left']['isRed_']()&&(_0x4fff89=_0x4fff89['copy'](null,null,null,null,_0x4fff89['right']['rotateRight_']()),_0x4fff89=_0x4fff89['rotateLeft_'](),_0x4fff89=_0x4fff89['colorFlip_']()),_0x4fff89;}['moveRedRight_'](){let _0x403961=this['colorFlip_']();return _0x403961['left']['left']['isRed_']()&&(_0x403961=_0x403961['rotateRight_'](),_0x403961=_0x403961['colorFlip_']()),_0x403961;}['rotateLeft_'](){const _0x31353d=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x31353d,null);}['rotateRight_'](){const _0x4e00db=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4e00db);}['colorFlip_'](){const _0xf3c1a=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x2d5b55=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0xf3c1a,_0x2d5b55);}['checkMaxDepth_'](){const _0x26fe54=this['check_']();return Math['pow'](0x2,_0x26fe54)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2d01ab=this['left']['check_']();if(_0x2d01ab!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2d01ab+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x14ebca,_0x8424c3,_0x341dbe,_0x1557c4,_0x38ef9f){return this;}['insert'](_0x110e01,_0x2aadc1,_0x3adf59){return new M(_0x110e01,_0x2aadc1,null);}['remove'](_0x46e138,_0x7f26d){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x22e3b9){return!0x1;}['reverseTraversal'](_0x51ef94){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x3c119b,_0x584760=B['EMPTY_NODE']){this['comparator_']=_0x3c119b,this['root_']=_0x584760;}['insert'](_0x51d10b,_0x22ba1e){return new B(this['comparator_'],this['root_']['insert'](_0x51d10b,_0x22ba1e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3523b0){return new B(this['comparator_'],this['root_']['remove'](_0x3523b0,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x3c4d05){let _0x5a98fd,_0xc41c47=this['root_'];for(;!_0xc41c47['isEmpty']();){if(_0x5a98fd=this['comparator_'](_0x3c4d05,_0xc41c47['key']),_0x5a98fd===0x0)return _0xc41c47['value'];_0x5a98fd<0x0?_0xc41c47=_0xc41c47['left']:_0x5a98fd>0x0&&(_0xc41c47=_0xc41c47['right']);}return null;}['getPredecessorKey'](_0x4679c5){let _0x45943c,_0x1a4a27=this['root_'],_0x397e25=null;for(;!_0x1a4a27['isEmpty']();)if(_0x45943c=this['comparator_'](_0x4679c5,_0x1a4a27['key']),_0x45943c===0x0){if(_0x1a4a27['left']['isEmpty']())return _0x397e25?_0x397e25['key']:null;for(_0x1a4a27=_0x1a4a27['left'];!_0x1a4a27['right']['isEmpty']();)_0x1a4a27=_0x1a4a27['right'];return _0x1a4a27['key'];}else _0x45943c<0x0?_0x1a4a27=_0x1a4a27['left']:_0x45943c>0x0&&(_0x397e25=_0x1a4a27,_0x1a4a27=_0x1a4a27['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x587059){return this['root_']['inorderTraversal'](_0x587059);}['reverseTraversal'](_0x58f190){return this['root_']['reverseTraversal'](_0x58f190);}['getIterator'](_0x5e1d13){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x5e1d13);}['getIteratorFrom'](_0x1aec0c,_0x5d61aa){return new rn(this['root_'],_0x1aec0c,this['comparator_'],!0x1,_0x5d61aa);}['getReverseIteratorFrom'](_0x183fbe,_0x31becd){return new rn(this['root_'],_0x183fbe,this['comparator_'],!0x0,_0x31becd);}['getReverseIterator'](_0x5cf08a){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x5cf08a);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x185bf2,_0x517317){return qe(_0x185bf2['name'],_0x517317['name']);}function Qi(_0x5b2888,_0x10c1e9){return qe(_0x5b2888,_0x10c1e9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x5c4e28){Ci=_0x5c4e28;}const Po=function(_0x5afc10){return typeof _0x5afc10=='number'?'number:'+ao(_0x5afc10):'string:'+_0x5afc10;},No=function(_0x4f8efd){if(_0x4f8efd['isLeafNode']()){const _0x57dea4=_0x4f8efd['val']();f(typeof _0x57dea4=='string'||typeof _0x57dea4=='number'||typeof _0x57dea4=='object'&&Q(_0x57dea4,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4f8efd===Ci||_0x4f8efd['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4f8efd===Ci||_0x4f8efd['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x451ded){nr=_0x451ded;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x20407c,_0xb800a7=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x20407c,this['priorityNode_']=_0xb800a7,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x68dfde){return new D(this['value_'],_0x68dfde);}['getImmediateChild'](_0x1b9bda){return _0x1b9bda==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x1833e1){return v(_0x1833e1)?this:y(_0x1833e1)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5db161,_0x5c154c){return null;}['updateImmediateChild'](_0x42f5a4,_0x2f9449){return _0x42f5a4==='.priority'?this['updatePriority'](_0x2f9449):_0x2f9449['isEmpty']()&&_0x42f5a4!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x42f5a4,_0x2f9449)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4b62bb,_0x1a999a){const _0x16691f=y(_0x4b62bb);return _0x16691f===null?_0x1a999a:_0x1a999a['isEmpty']()&&_0x16691f!=='.priority'?this:(f(_0x16691f!=='.priority'||Ce(_0x4b62bb)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x16691f,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x4b62bb),_0x1a999a)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2a937d,_0x21a1af){return!0x1;}['val'](_0x3a354a){return _0x3a354a&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x112588='';this['priorityNode_']['isEmpty']()||(_0x112588+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x282ca8=typeof this['value_'];_0x112588+=_0x282ca8+':',_0x282ca8==='number'?_0x112588+=ao(this['value_']):_0x112588+=this['value_'],this['lazyHash_']=ro(_0x112588);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1e07a6){return _0x1e07a6===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1e07a6 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1e07a6['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1e07a6));}['compareToLeafNode_'](_0xb8113f){const _0x181be1=typeof _0xb8113f['value_'],_0xb367f=typeof this['value_'],_0x26e894=D['VALUE_TYPE_ORDER']['indexOf'](_0x181be1),_0x2601de=D['VALUE_TYPE_ORDER']['indexOf'](_0xb367f);return f(_0x26e894>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x181be1),f(_0x2601de>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xb367f),_0x26e894===_0x2601de?_0xb367f==='object'?0x0:this['value_']<_0xb8113f['value_']?-0x1:this['value_']===_0xb8113f['value_']?0x0:0x1:_0x2601de-_0x26e894;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x13e95e){if(_0x13e95e===this)return!0x0;if(_0x13e95e['isLeafNode']()){const _0x47bd72=_0x13e95e;return this['value_']===_0x47bd72['value_']&&this['priorityNode_']['equals'](_0x47bd72['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x50e15a){Oo=_0x50e15a;}function Wh(_0x21c498){Do=_0x21c498;}class Bh extends Fn{['compare'](_0x9720c5,_0x41f053){const _0x19fd16=_0x9720c5['node']['getPriority'](),_0x54113b=_0x41f053['node']['getPriority'](),_0x5a68fd=_0x19fd16['compareTo'](_0x54113b);return _0x5a68fd===0x0?qe(_0x9720c5['name'],_0x41f053['name']):_0x5a68fd;}['isDefinedOn'](_0x3bf046){return!_0x3bf046['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4457b2,_0x1a66b7){return!_0x4457b2['getPriority']()['equals'](_0x1a66b7['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x3985ef,_0x2ca12f){const _0x3e218e=Oo(_0x3985ef);return new E(_0x2ca12f,new D('[PRIORITY-POST]',_0x3e218e));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x2eff62){const _0x57cfd4=_0x767ed5=>parseInt(Math['log'](_0x767ed5)/Vh,0xa),_0x53520e=_0x13324a=>parseInt(Array(_0x13324a+0x1)['join']('1'),0x2);this['count']=_0x57cfd4(_0x2eff62+0x1),this['current_']=this['count']-0x1;const _0x360924=_0x53520e(this['count']);this['bits_']=_0x2eff62+0x1&_0x360924;}['nextBitIsOne'](){const _0x46614e=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x46614e;}}const yn=function(_0x1fbd43,_0x268c50,_0x4b034b,_0x455040){_0x1fbd43['sort'](_0x268c50);const _0x2ebc79=function(_0xd3163,_0x2d11c9){const _0x1c2194=_0x2d11c9-_0xd3163;let _0x2d648d,_0x106a1f;if(_0x1c2194===0x0)return null;if(_0x1c2194===0x1)return _0x2d648d=_0x1fbd43[_0xd3163],_0x106a1f=_0x4b034b?_0x4b034b(_0x2d648d):_0x2d648d,new M(_0x106a1f,_0x2d648d['node'],M['BLACK'],null,null);{const _0x2cd6cb=parseInt(_0x1c2194/0x2,0xa)+_0xd3163,_0x36ae47=_0x2ebc79(_0xd3163,_0x2cd6cb),_0x1150c7=_0x2ebc79(_0x2cd6cb+0x1,_0x2d11c9);return _0x2d648d=_0x1fbd43[_0x2cd6cb],_0x106a1f=_0x4b034b?_0x4b034b(_0x2d648d):_0x2d648d,new M(_0x106a1f,_0x2d648d['node'],M['BLACK'],_0x36ae47,_0x1150c7);}},_0x596823=function(_0x1ee8a1){let _0x5f3385=null,_0x4b3e58=null,_0x275aed=_0x1fbd43['length'];const _0x4f3264=function(_0x18a59a,_0x14ffa1){const _0x58b211=_0x275aed-_0x18a59a,_0xf54581=_0x275aed;_0x275aed-=_0x18a59a;const _0x5dc3c6=_0x2ebc79(_0x58b211+0x1,_0xf54581),_0x311ecb=_0x1fbd43[_0x58b211],_0x52fff2=_0x4b034b?_0x4b034b(_0x311ecb):_0x311ecb;_0x5c8adf(new M(_0x52fff2,_0x311ecb['node'],_0x14ffa1,null,_0x5dc3c6));},_0x5c8adf=function(_0x72cf1c){_0x5f3385?(_0x5f3385['left']=_0x72cf1c,_0x5f3385=_0x72cf1c):(_0x4b3e58=_0x72cf1c,_0x5f3385=_0x72cf1c);};for(let _0x292857=0x0;_0x292857<_0x1ee8a1['count'];++_0x292857){const _0x2ef486=_0x1ee8a1['nextBitIsOne'](),_0x49ef53=Math['pow'](0x2,_0x1ee8a1['count']-(_0x292857+0x1));_0x2ef486?_0x4f3264(_0x49ef53,M['BLACK']):(_0x4f3264(_0x49ef53,M['BLACK']),_0x4f3264(_0x49ef53,M['RED']));}return _0x4b3e58;},_0x1c46e5=new Hh(_0x1fbd43['length']),_0x410ac2=_0x596823(_0x1c46e5);return new B(_0x455040||_0x268c50,_0x410ac2);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x3d4ce6,_0x53e757){this['indexes_']=_0x3d4ce6,this['indexSet_']=_0x53e757;}['get'](_0x4b5fb3){const _0x1a4730=Le(this['indexes_'],_0x4b5fb3);if(!_0x1a4730)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4b5fb3);return _0x1a4730 instanceof B?_0x1a4730:null;}['hasIndex'](_0x96ce28){return Q(this['indexSet_'],_0x96ce28['toString']());}['addIndex'](_0x3fbfa4,_0x5f1f94){f(_0x3fbfa4!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x86c62f=[];let _0x33ecc9=!0x1;const _0x554a65=_0x5f1f94['getIterator'](E['Wrap']);let _0x2f0bed=_0x554a65['getNext']();for(;_0x2f0bed;)_0x33ecc9=_0x33ecc9||_0x3fbfa4['isDefinedOn'](_0x2f0bed['node']),_0x86c62f['push'](_0x2f0bed),_0x2f0bed=_0x554a65['getNext']();let _0x3b96ae;_0x33ecc9?_0x3b96ae=yn(_0x86c62f,_0x3fbfa4['getCompare']()):_0x3b96ae=Qe;const _0x2d9f19=_0x3fbfa4['toString'](),_0x4c960c={...this['indexSet_']};_0x4c960c[_0x2d9f19]=_0x3fbfa4;const _0x151380={...this['indexes_']};return _0x151380[_0x2d9f19]=_0x3b96ae,new te(_0x151380,_0x4c960c);}['addToIndexes'](_0x2c71bb,_0x184fa8){const _0x27f6a5=_n(this['indexes_'],(_0x333e35,_0x55534d)=>{const _0x28eb10=Le(this['indexSet_'],_0x55534d);if(f(_0x28eb10,'Missing\x20index\x20implementation\x20for\x20'+_0x55534d),_0x333e35===Qe){if(_0x28eb10['isDefinedOn'](_0x2c71bb['node'])){const _0x5550a9=[],_0x26cfc5=_0x184fa8['getIterator'](E['Wrap']);let _0x4e2084=_0x26cfc5['getNext']();for(;_0x4e2084;)_0x4e2084['name']!==_0x2c71bb['name']&&_0x5550a9['push'](_0x4e2084),_0x4e2084=_0x26cfc5['getNext']();return _0x5550a9['push'](_0x2c71bb),yn(_0x5550a9,_0x28eb10['getCompare']());}else return Qe;}else{const _0x7db770=_0x184fa8['get'](_0x2c71bb['name']);let _0x5188c1=_0x333e35;return _0x7db770&&(_0x5188c1=_0x5188c1['remove'](new E(_0x2c71bb['name'],_0x7db770))),_0x5188c1['insert'](_0x2c71bb,_0x2c71bb['node']);}});return new te(_0x27f6a5,this['indexSet_']);}['removeFromIndexes'](_0x33c76f,_0x1e6f34){const _0x290043=_n(this['indexes_'],_0x517a5c=>{if(_0x517a5c===Qe)return _0x517a5c;{const _0x37c59f=_0x1e6f34['get'](_0x33c76f['name']);return _0x37c59f?_0x517a5c['remove'](new E(_0x33c76f['name'],_0x37c59f)):_0x517a5c;}});return new te(_0x290043,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x1f15dc,_0x56d528,_0x168378){this['children_']=_0x1f15dc,this['priorityNode_']=_0x56d528,this['indexMap_']=_0x168378,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x45e2fb){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x45e2fb,this['indexMap_']);}['getImmediateChild'](_0x3c6779){if(_0x3c6779==='.priority')return this['getPriority']();{const _0x4ce2c5=this['children_']['get'](_0x3c6779);return _0x4ce2c5===null?It:_0x4ce2c5;}}['getChild'](_0x2724dc){const _0x2c444e=y(_0x2724dc);return _0x2c444e===null?this:this['getImmediateChild'](_0x2c444e)['getChild'](S(_0x2724dc));}['hasChild'](_0x3e7010){return this['children_']['get'](_0x3e7010)!==null;}['updateImmediateChild'](_0x26376c,_0x724dbb){if(f(_0x724dbb,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x26376c==='.priority')return this['updatePriority'](_0x724dbb);{const _0x407e2b=new E(_0x26376c,_0x724dbb);let _0x9dcb1e,_0x1a2a0f;_0x724dbb['isEmpty']()?(_0x9dcb1e=this['children_']['remove'](_0x26376c),_0x1a2a0f=this['indexMap_']['removeFromIndexes'](_0x407e2b,this['children_'])):(_0x9dcb1e=this['children_']['insert'](_0x26376c,_0x724dbb),_0x1a2a0f=this['indexMap_']['addToIndexes'](_0x407e2b,this['children_']));const _0x1bf2f4=_0x9dcb1e['isEmpty']()?It:this['priorityNode_'];return new g(_0x9dcb1e,_0x1bf2f4,_0x1a2a0f);}}['updateChild'](_0x7c585b,_0x4947b1){const _0xb9268a=y(_0x7c585b);if(_0xb9268a===null)return _0x4947b1;{f(y(_0x7c585b)!=='.priority'||Ce(_0x7c585b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x47bf8b=this['getImmediateChild'](_0xb9268a)['updateChild'](S(_0x7c585b),_0x4947b1);return this['updateImmediateChild'](_0xb9268a,_0x47bf8b);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x44655e){if(this['isEmpty']())return null;const _0x41ff06={};let _0x267044=0x0,_0x5079ad=0x0,_0x367e3e=!0x0;if(this['forEachChild'](R,(_0x1682c8,_0x56f60b)=>{_0x41ff06[_0x1682c8]=_0x56f60b['val'](_0x44655e),_0x267044++,_0x367e3e&&g['INTEGER_REGEXP_']['test'](_0x1682c8)?_0x5079ad=Math['max'](_0x5079ad,Number(_0x1682c8)):_0x367e3e=!0x1;}),!_0x44655e&&_0x367e3e&&_0x5079ad<0x2*_0x267044){const _0x157a2e=[];for(const _0xdf51c8 in _0x41ff06)_0x157a2e[_0xdf51c8]=_0x41ff06[_0xdf51c8];return _0x157a2e;}else return _0x44655e&&!this['getPriority']()['isEmpty']()&&(_0x41ff06['.priority']=this['getPriority']()['val']()),_0x41ff06;}['hash'](){if(this['lazyHash_']===null){let _0x2cc769='';this['getPriority']()['isEmpty']()||(_0x2cc769+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2796a4,_0x2424d8)=>{const _0x479b0c=_0x2424d8['hash']();_0x479b0c!==''&&(_0x2cc769+=':'+_0x2796a4+':'+_0x479b0c);}),this['lazyHash_']=_0x2cc769===''?'':ro(_0x2cc769);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4b5a24,_0xf5b960,_0x39cae8){const _0xbda71f=this['resolveIndex_'](_0x39cae8);if(_0xbda71f){const _0x52b6b7=_0xbda71f['getPredecessorKey'](new E(_0x4b5a24,_0xf5b960));return _0x52b6b7?_0x52b6b7['name']:null;}else return this['children_']['getPredecessorKey'](_0x4b5a24);}['getFirstChildName'](_0x5807d2){const _0x8e12b7=this['resolveIndex_'](_0x5807d2);if(_0x8e12b7){const _0xc0e804=_0x8e12b7['minKey']();return _0xc0e804&&_0xc0e804['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x4c9128){const _0x5c05b9=this['getFirstChildName'](_0x4c9128);return _0x5c05b9?new E(_0x5c05b9,this['children_']['get'](_0x5c05b9)):null;}['getLastChildName'](_0x59e082){const _0x263af7=this['resolveIndex_'](_0x59e082);if(_0x263af7){const _0x2fa853=_0x263af7['maxKey']();return _0x2fa853&&_0x2fa853['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x357cdf){const _0x2665e7=this['getLastChildName'](_0x357cdf);return _0x2665e7?new E(_0x2665e7,this['children_']['get'](_0x2665e7)):null;}['forEachChild'](_0x542bfe,_0x2ab356){const _0x2cb2a7=this['resolveIndex_'](_0x542bfe);return _0x2cb2a7?_0x2cb2a7['inorderTraversal'](_0x3053d1=>_0x2ab356(_0x3053d1['name'],_0x3053d1['node'])):this['children_']['inorderTraversal'](_0x2ab356);}['getIterator'](_0x26aa7f){return this['getIteratorFrom'](_0x26aa7f['minPost'](),_0x26aa7f);}['getIteratorFrom'](_0x303ac3,_0x53e32c){const _0x583fba=this['resolveIndex_'](_0x53e32c);if(_0x583fba)return _0x583fba['getIteratorFrom'](_0x303ac3,_0x495448=>_0x495448);{const _0x59b582=this['children_']['getIteratorFrom'](_0x303ac3['name'],E['Wrap']);let _0x52e2a8=_0x59b582['peek']();for(;_0x52e2a8!=null&&_0x53e32c['compare'](_0x52e2a8,_0x303ac3)<0x0;)_0x59b582['getNext'](),_0x52e2a8=_0x59b582['peek']();return _0x59b582;}}['getReverseIterator'](_0xc0ac76){return this['getReverseIteratorFrom'](_0xc0ac76['maxPost'](),_0xc0ac76);}['getReverseIteratorFrom'](_0x1f3db2,_0x4bc608){const _0x3d320f=this['resolveIndex_'](_0x4bc608);if(_0x3d320f)return _0x3d320f['getReverseIteratorFrom'](_0x1f3db2,_0x43db22=>_0x43db22);{const _0x1b0160=this['children_']['getReverseIteratorFrom'](_0x1f3db2['name'],E['Wrap']);let _0x595aee=_0x1b0160['peek']();for(;_0x595aee!=null&&_0x4bc608['compare'](_0x595aee,_0x1f3db2)>0x0;)_0x1b0160['getNext'](),_0x595aee=_0x1b0160['peek']();return _0x1b0160;}}['compareTo'](_0x197454){return this['isEmpty']()?_0x197454['isEmpty']()?0x0:-0x1:_0x197454['isLeafNode']()||_0x197454['isEmpty']()?0x1:_0x197454===Kt?-0x1:0x0;}['withIndex'](_0x12962c){if(_0x12962c===ve||this['indexMap_']['hasIndex'](_0x12962c))return this;{const _0x203310=this['indexMap_']['addIndex'](_0x12962c,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x203310);}}['isIndexed'](_0x101ed2){return _0x101ed2===ve||this['indexMap_']['hasIndex'](_0x101ed2);}['equals'](_0x4e8c30){if(_0x4e8c30===this)return!0x0;if(_0x4e8c30['isLeafNode']())return!0x1;{const _0xcf1f14=_0x4e8c30;if(this['getPriority']()['equals'](_0xcf1f14['getPriority']())){if(this['children_']['count']()===_0xcf1f14['children_']['count']()){const _0x1419a5=this['getIterator'](R),_0x2e304d=_0xcf1f14['getIterator'](R);let _0x2bd658=_0x1419a5['getNext'](),_0x24bc2e=_0x2e304d['getNext']();for(;_0x2bd658&&_0x24bc2e;){if(_0x2bd658['name']!==_0x24bc2e['name']||!_0x2bd658['node']['equals'](_0x24bc2e['node']))return!0x1;_0x2bd658=_0x1419a5['getNext'](),_0x24bc2e=_0x2e304d['getNext']();}return _0x2bd658===null&&_0x24bc2e===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x57a270){return _0x57a270===ve?null:this['indexMap_']['get'](_0x57a270['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3e2dea){return _0x3e2dea===this?0x0:0x1;}['equals'](_0x56b7f4){return _0x56b7f4===this;}['getPriority'](){return this;}['getImmediateChild'](_0x576add){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x350357,_0x1afa51=null){if(_0x350357===null)return g['EMPTY_NODE'];if(typeof _0x350357=='object'&&'.priority'in _0x350357&&(_0x1afa51=_0x350357['.priority']),f(_0x1afa51===null||typeof _0x1afa51=='string'||typeof _0x1afa51=='number'||typeof _0x1afa51=='object'&&'.sv'in _0x1afa51,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1afa51),typeof _0x350357=='object'&&'.value'in _0x350357&&_0x350357['.value']!==null&&(_0x350357=_0x350357['.value']),typeof _0x350357!='object'||'.sv'in _0x350357){const _0x208ac6=_0x350357;return new D(_0x208ac6,A(_0x1afa51));}if(!(_0x350357 instanceof Array)&&Gh){const _0x24d07c=[];let _0x2b30f4=!0x1;if(x(_0x350357,(_0x5e4cc4,_0x3e9e3e)=>{if(_0x5e4cc4['substring'](0x0,0x1)!=='.'){const _0x3f1a7f=A(_0x3e9e3e);_0x3f1a7f['isEmpty']()||(_0x2b30f4=_0x2b30f4||!_0x3f1a7f['getPriority']()['isEmpty'](),_0x24d07c['push'](new E(_0x5e4cc4,_0x3f1a7f)));}}),_0x24d07c['length']===0x0)return g['EMPTY_NODE'];const _0x25d98b=yn(_0x24d07c,xh,_0x2fb7de=>_0x2fb7de['name'],Qi);if(_0x2b30f4){const _0x15aefa=yn(_0x24d07c,R['getCompare']());return new g(_0x25d98b,A(_0x1afa51),new te({'.priority':_0x15aefa},{'.priority':R}));}else return new g(_0x25d98b,A(_0x1afa51),te['Default']);}else{let _0x59b6f7=g['EMPTY_NODE'];return x(_0x350357,(_0x5c0e40,_0x3fcd48)=>{if(Q(_0x350357,_0x5c0e40)&&_0x5c0e40['substring'](0x0,0x1)!=='.'){const _0x2be677=A(_0x3fcd48);(_0x2be677['isLeafNode']()||!_0x2be677['isEmpty']())&&(_0x59b6f7=_0x59b6f7['updateImmediateChild'](_0x5c0e40,_0x2be677));}}),_0x59b6f7['updatePriority'](A(_0x1afa51));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x19221b){super(),this['indexPath_']=_0x19221b,f(!v(_0x19221b)&&y(_0x19221b)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2d9b84){return _0x2d9b84['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4e0f87){return!_0x4e0f87['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x8f26db,_0x2d6b61){const _0x17b1f2=this['extractChild'](_0x8f26db['node']),_0x2ed582=this['extractChild'](_0x2d6b61['node']),_0x10554f=_0x17b1f2['compareTo'](_0x2ed582);return _0x10554f===0x0?qe(_0x8f26db['name'],_0x2d6b61['name']):_0x10554f;}['makePost'](_0xc19967,_0x14e24c){const _0x4d6d27=A(_0xc19967),_0x49bba1=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4d6d27);return new E(_0x14e24c,_0x49bba1);}['maxPost'](){const _0x3f2e28=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x3f2e28);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x2b3f8c,_0x359cbc){const _0x458ddc=_0x2b3f8c['node']['compareTo'](_0x359cbc['node']);return _0x458ddc===0x0?qe(_0x2b3f8c['name'],_0x359cbc['name']):_0x458ddc;}['isDefinedOn'](_0x5c6231){return!0x0;}['indexedValueChanged'](_0x43df7f,_0x5e75b9){return!_0x43df7f['equals'](_0x5e75b9);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x138b82,_0x1bf1fb){const _0x57d003=A(_0x138b82);return new E(_0x1bf1fb,_0x57d003);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x1b4511){return{'type':'value','snapshotNode':_0x1b4511};}function rt(_0x5cb6a6,_0x312ec3){return{'type':'child_added','snapshotNode':_0x312ec3,'childName':_0x5cb6a6};}function Lt(_0x2aef93,_0x1d838f){return{'type':'child_removed','snapshotNode':_0x1d838f,'childName':_0x2aef93};}function xt(_0x329d5e,_0xf6e097,_0x5382e2){return{'type':'child_changed','snapshotNode':_0xf6e097,'childName':_0x329d5e,'oldSnap':_0x5382e2};}function zh(_0x15c5ef,_0x2deee8){return{'type':'child_moved','snapshotNode':_0x2deee8,'childName':_0x15c5ef};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x23ba6d){this['index_']=_0x23ba6d;}['updateChild'](_0x19c73d,_0x484b40,_0x2ee89e,_0x5b82e1,_0x497435,_0x373f49){f(_0x19c73d['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x84d2ef=_0x19c73d['getImmediateChild'](_0x484b40);return _0x84d2ef['getChild'](_0x5b82e1)['equals'](_0x2ee89e['getChild'](_0x5b82e1))&&_0x84d2ef['isEmpty']()===_0x2ee89e['isEmpty']()||(_0x373f49!=null&&(_0x2ee89e['isEmpty']()?_0x19c73d['hasChild'](_0x484b40)?_0x373f49['trackChildChange'](Lt(_0x484b40,_0x84d2ef)):f(_0x19c73d['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x84d2ef['isEmpty']()?_0x373f49['trackChildChange'](rt(_0x484b40,_0x2ee89e)):_0x373f49['trackChildChange'](xt(_0x484b40,_0x2ee89e,_0x84d2ef))),_0x19c73d['isLeafNode']()&&_0x2ee89e['isEmpty']())?_0x19c73d:_0x19c73d['updateImmediateChild'](_0x484b40,_0x2ee89e)['withIndex'](this['index_']);}['updateFullNode'](_0x4124e1,_0x519047,_0x2c54df){return _0x2c54df!=null&&(_0x4124e1['isLeafNode']()||_0x4124e1['forEachChild'](R,(_0x10dcbd,_0x157d79)=>{_0x519047['hasChild'](_0x10dcbd)||_0x2c54df['trackChildChange'](Lt(_0x10dcbd,_0x157d79));}),_0x519047['isLeafNode']()||_0x519047['forEachChild'](R,(_0x25b205,_0x40119e)=>{if(_0x4124e1['hasChild'](_0x25b205)){const _0x10897c=_0x4124e1['getImmediateChild'](_0x25b205);_0x10897c['equals'](_0x40119e)||_0x2c54df['trackChildChange'](xt(_0x25b205,_0x40119e,_0x10897c));}else _0x2c54df['trackChildChange'](rt(_0x25b205,_0x40119e));})),_0x519047['withIndex'](this['index_']);}['updatePriority'](_0x1781cb,_0xee7f8d){return _0x1781cb['isEmpty']()?g['EMPTY_NODE']:_0x1781cb['updatePriority'](_0xee7f8d);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x36a886){this['indexedFilter_']=new Xi(_0x36a886['getIndex']()),this['index_']=_0x36a886['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x36a886),this['endPost_']=Ft['getEndPost_'](_0x36a886),this['startIsInclusive_']=!_0x36a886['startAfterSet_'],this['endIsInclusive_']=!_0x36a886['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x74a566){const _0x491b8e=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x74a566)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x74a566)<0x0,_0x511289=this['endIsInclusive_']?this['index_']['compare'](_0x74a566,this['getEndPost']())<=0x0:this['index_']['compare'](_0x74a566,this['getEndPost']())<0x0;return _0x491b8e&&_0x511289;}['updateChild'](_0x1957d5,_0x14475f,_0x1737e8,_0x12c30b,_0x1811c2,_0xef9996){return this['matches'](new E(_0x14475f,_0x1737e8))||(_0x1737e8=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1957d5,_0x14475f,_0x1737e8,_0x12c30b,_0x1811c2,_0xef9996);}['updateFullNode'](_0x57a8f6,_0x26117d,_0x4097ad){_0x26117d['isLeafNode']()&&(_0x26117d=g['EMPTY_NODE']);let _0x15212c=_0x26117d['withIndex'](this['index_']);_0x15212c=_0x15212c['updatePriority'](g['EMPTY_NODE']);const _0x154d73=this;return _0x26117d['forEachChild'](R,(_0x4217b,_0x53c2a6)=>{_0x154d73['matches'](new E(_0x4217b,_0x53c2a6))||(_0x15212c=_0x15212c['updateImmediateChild'](_0x4217b,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x57a8f6,_0x15212c,_0x4097ad);}['updatePriority'](_0x1db09a,_0x425df9){return _0x1db09a;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xf33ab4){if(_0xf33ab4['hasStart']()){const _0x3c342a=_0xf33ab4['getIndexStartName']();return _0xf33ab4['getIndex']()['makePost'](_0xf33ab4['getIndexStartValue'](),_0x3c342a);}else return _0xf33ab4['getIndex']()['minPost']();}static['getEndPost_'](_0x52ef7b){if(_0x52ef7b['hasEnd']()){const _0xe5deb8=_0x52ef7b['getIndexEndName']();return _0x52ef7b['getIndex']()['makePost'](_0x52ef7b['getIndexEndValue'](),_0xe5deb8);}else return _0x52ef7b['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x43833c){this['withinDirectionalStart']=_0x4a0d90=>this['reverse_']?this['withinEndPost'](_0x4a0d90):this['withinStartPost'](_0x4a0d90),this['withinDirectionalEnd']=_0x9c13bd=>this['reverse_']?this['withinStartPost'](_0x9c13bd):this['withinEndPost'](_0x9c13bd),this['withinStartPost']=_0x41c946=>{const _0x3ede87=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x41c946);return this['startIsInclusive_']?_0x3ede87<=0x0:_0x3ede87<0x0;},this['withinEndPost']=_0x573bb5=>{const _0x456e5e=this['index_']['compare'](_0x573bb5,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x456e5e<=0x0:_0x456e5e<0x0;},this['rangedFilter_']=new Ft(_0x43833c),this['index_']=_0x43833c['getIndex'](),this['limit_']=_0x43833c['getLimit'](),this['reverse_']=!_0x43833c['isViewFromLeft'](),this['startIsInclusive_']=!_0x43833c['startAfterSet_'],this['endIsInclusive_']=!_0x43833c['endBeforeSet_'];}['updateChild'](_0xcccdbf,_0x4244a5,_0x4acf8a,_0x130770,_0x70be8,_0x3ffe3d){return this['rangedFilter_']['matches'](new E(_0x4244a5,_0x4acf8a))||(_0x4acf8a=g['EMPTY_NODE']),_0xcccdbf['getImmediateChild'](_0x4244a5)['equals'](_0x4acf8a)?_0xcccdbf:_0xcccdbf['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xcccdbf,_0x4244a5,_0x4acf8a,_0x130770,_0x70be8,_0x3ffe3d):this['fullLimitUpdateChild_'](_0xcccdbf,_0x4244a5,_0x4acf8a,_0x70be8,_0x3ffe3d);}['updateFullNode'](_0x318cce,_0x313b2b,_0x2844d0){let _0x3b608b;if(_0x313b2b['isLeafNode']()||_0x313b2b['isEmpty']())_0x3b608b=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x313b2b['numChildren']()&&_0x313b2b['isIndexed'](this['index_'])){_0x3b608b=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5565ad;this['reverse_']?_0x5565ad=_0x313b2b['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5565ad=_0x313b2b['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x4cd3c2=0x0;for(;_0x5565ad['hasNext']()&&_0x4cd3c2<this['limit_'];){const _0x454543=_0x5565ad['getNext']();if(this['withinDirectionalStart'](_0x454543)){if(this['withinDirectionalEnd'](_0x454543))_0x3b608b=_0x3b608b['updateImmediateChild'](_0x454543['name'],_0x454543['node']),_0x4cd3c2++;else break;}else continue;}}else{_0x3b608b=_0x313b2b['withIndex'](this['index_']),_0x3b608b=_0x3b608b['updatePriority'](g['EMPTY_NODE']);let _0x5d7b54;this['reverse_']?_0x5d7b54=_0x3b608b['getReverseIterator'](this['index_']):_0x5d7b54=_0x3b608b['getIterator'](this['index_']);let _0x35eb68=0x0;for(;_0x5d7b54['hasNext']();){const _0x5dcaee=_0x5d7b54['getNext']();_0x35eb68<this['limit_']&&this['withinDirectionalStart'](_0x5dcaee)&&this['withinDirectionalEnd'](_0x5dcaee)?_0x35eb68++:_0x3b608b=_0x3b608b['updateImmediateChild'](_0x5dcaee['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x318cce,_0x3b608b,_0x2844d0);}['updatePriority'](_0x5bcae9,_0x58c49b){return _0x5bcae9;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x542ff1,_0x11e2e0,_0x47bd5e,_0x3fa766,_0x5599e0){let _0x44a8fa;if(this['reverse_']){const _0x1afcb2=this['index_']['getCompare']();_0x44a8fa=(_0x243201,_0x1b8a65)=>_0x1afcb2(_0x1b8a65,_0x243201);}else _0x44a8fa=this['index_']['getCompare']();const _0x4ea4bb=_0x542ff1;f(_0x4ea4bb['numChildren']()===this['limit_'],'');const _0x4d27e3=new E(_0x11e2e0,_0x47bd5e),_0x2796b9=this['reverse_']?_0x4ea4bb['getFirstChild'](this['index_']):_0x4ea4bb['getLastChild'](this['index_']),_0x6122cf=this['rangedFilter_']['matches'](_0x4d27e3);if(_0x4ea4bb['hasChild'](_0x11e2e0)){const _0x3d91b4=_0x4ea4bb['getImmediateChild'](_0x11e2e0);let _0x4e74da=_0x3fa766['getChildAfterChild'](this['index_'],_0x2796b9,this['reverse_']);for(;_0x4e74da!=null&&(_0x4e74da['name']===_0x11e2e0||_0x4ea4bb['hasChild'](_0x4e74da['name']));)_0x4e74da=_0x3fa766['getChildAfterChild'](this['index_'],_0x4e74da,this['reverse_']);const _0x151e40=_0x4e74da==null?0x1:_0x44a8fa(_0x4e74da,_0x4d27e3);if(_0x6122cf&&!_0x47bd5e['isEmpty']()&&_0x151e40>=0x0)return _0x5599e0!=null&&_0x5599e0['trackChildChange'](xt(_0x11e2e0,_0x47bd5e,_0x3d91b4)),_0x4ea4bb['updateImmediateChild'](_0x11e2e0,_0x47bd5e);{_0x5599e0!=null&&_0x5599e0['trackChildChange'](Lt(_0x11e2e0,_0x3d91b4));const _0x1a364f=_0x4ea4bb['updateImmediateChild'](_0x11e2e0,g['EMPTY_NODE']);return _0x4e74da!=null&&this['rangedFilter_']['matches'](_0x4e74da)?(_0x5599e0!=null&&_0x5599e0['trackChildChange'](rt(_0x4e74da['name'],_0x4e74da['node'])),_0x1a364f['updateImmediateChild'](_0x4e74da['name'],_0x4e74da['node'])):_0x1a364f;}}else return _0x47bd5e['isEmpty']()?_0x542ff1:_0x6122cf&&_0x44a8fa(_0x2796b9,_0x4d27e3)>=0x0?(_0x5599e0!=null&&(_0x5599e0['trackChildChange'](Lt(_0x2796b9['name'],_0x2796b9['node'])),_0x5599e0['trackChildChange'](rt(_0x11e2e0,_0x47bd5e))),_0x4ea4bb['updateImmediateChild'](_0x11e2e0,_0x47bd5e)['updateImmediateChild'](_0x2796b9['name'],g['EMPTY_NODE'])):_0x542ff1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1547c7=new Zi();return _0x1547c7['limitSet_']=this['limitSet_'],_0x1547c7['limit_']=this['limit_'],_0x1547c7['startSet_']=this['startSet_'],_0x1547c7['startAfterSet_']=this['startAfterSet_'],_0x1547c7['indexStartValue_']=this['indexStartValue_'],_0x1547c7['startNameSet_']=this['startNameSet_'],_0x1547c7['indexStartName_']=this['indexStartName_'],_0x1547c7['endSet_']=this['endSet_'],_0x1547c7['endBeforeSet_']=this['endBeforeSet_'],_0x1547c7['indexEndValue_']=this['indexEndValue_'],_0x1547c7['endNameSet_']=this['endNameSet_'],_0x1547c7['indexEndName_']=this['indexEndName_'],_0x1547c7['index_']=this['index_'],_0x1547c7['viewFrom_']=this['viewFrom_'],_0x1547c7;}}function Kh(_0x45862e){return _0x45862e['loadsAllData']()?new Xi(_0x45862e['getIndex']()):_0x45862e['hasLimit']()?new jh(_0x45862e):new Ft(_0x45862e);}function Yh(_0x5aca21,_0x4018d6){const _0x7a48d9=_0x5aca21['copy']();return _0x7a48d9['limitSet_']=!0x0,_0x7a48d9['limit_']=_0x4018d6,_0x7a48d9['viewFrom_']='l',_0x7a48d9;}function Qh(_0x369324,_0x500b81,_0x2bf20b){const _0x3320c8=_0x369324['copy']();return _0x3320c8['startSet_']=!0x0,_0x500b81===void 0x0&&(_0x500b81=null),_0x3320c8['indexStartValue_']=_0x500b81,_0x2bf20b!=null?(_0x3320c8['startNameSet_']=!0x0,_0x3320c8['indexStartName_']=_0x2bf20b):(_0x3320c8['startNameSet_']=!0x1,_0x3320c8['indexStartName_']=''),_0x3320c8;}function Jh(_0x3f4358,_0x103520,_0x2b83b5){const _0x15bf37=_0x3f4358['copy']();return _0x15bf37['endSet_']=!0x0,_0x103520===void 0x0&&(_0x103520=null),_0x15bf37['indexEndValue_']=_0x103520,_0x2b83b5!==void 0x0?(_0x15bf37['endNameSet_']=!0x0,_0x15bf37['indexEndName_']=_0x2b83b5):(_0x15bf37['endNameSet_']=!0x1,_0x15bf37['indexEndName_']=''),_0x15bf37;}function xo(_0xde34c4,_0x327c9d){const _0x21f56d=_0xde34c4['copy']();return _0x21f56d['index_']=_0x327c9d,_0x21f56d;}function ir(_0x1ff89a){const _0x344132={};if(_0x1ff89a['isDefault']())return _0x344132;let _0x2ebc28;if(_0x1ff89a['index_']===R?_0x2ebc28='$priority':_0x1ff89a['index_']===Mo?_0x2ebc28='$value':_0x1ff89a['index_']===ve?_0x2ebc28='$key':(f(_0x1ff89a['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x2ebc28=_0x1ff89a['index_']['toString']()),_0x344132['orderBy']=O(_0x2ebc28),_0x1ff89a['startSet_']){const _0x1787b4=_0x1ff89a['startAfterSet_']?'startAfter':'startAt';_0x344132[_0x1787b4]=O(_0x1ff89a['indexStartValue_']),_0x1ff89a['startNameSet_']&&(_0x344132[_0x1787b4]+=','+O(_0x1ff89a['indexStartName_']));}if(_0x1ff89a['endSet_']){const _0x2d859f=_0x1ff89a['endBeforeSet_']?'endBefore':'endAt';_0x344132[_0x2d859f]=O(_0x1ff89a['indexEndValue_']),_0x1ff89a['endNameSet_']&&(_0x344132[_0x2d859f]+=','+O(_0x1ff89a['indexEndName_']));}return _0x1ff89a['limitSet_']&&(_0x1ff89a['isViewFromLeft']()?_0x344132['limitToFirst']=_0x1ff89a['limit_']:_0x344132['limitToLast']=_0x1ff89a['limit_']),_0x344132;}function sr(_0x37fd61){const _0x1fe4d0={};if(_0x37fd61['startSet_']&&(_0x1fe4d0['sp']=_0x37fd61['indexStartValue_'],_0x37fd61['startNameSet_']&&(_0x1fe4d0['sn']=_0x37fd61['indexStartName_']),_0x1fe4d0['sin']=!_0x37fd61['startAfterSet_']),_0x37fd61['endSet_']&&(_0x1fe4d0['ep']=_0x37fd61['indexEndValue_'],_0x37fd61['endNameSet_']&&(_0x1fe4d0['en']=_0x37fd61['indexEndName_']),_0x1fe4d0['ein']=!_0x37fd61['endBeforeSet_']),_0x37fd61['limitSet_']){_0x1fe4d0['l']=_0x37fd61['limit_'];let _0x412613=_0x37fd61['viewFrom_'];_0x412613===''&&(_0x37fd61['isViewFromLeft']()?_0x412613='l':_0x412613='r'),_0x1fe4d0['vf']=_0x412613;}return _0x37fd61['index_']!==R&&(_0x1fe4d0['i']=_0x37fd61['index_']['toString']()),_0x1fe4d0;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x20c03d){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x472914,_0x1ffc75){return _0x1ffc75!==void 0x0?'tag$'+_0x1ffc75:(f(_0x472914['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x472914['_path']['toString']());}constructor(_0x3c062c,_0x2b6e00,_0x4178e9,_0x42c2b4){super(),this['repoInfo_']=_0x3c062c,this['onDataUpdate_']=_0x2b6e00,this['authTokenProvider_']=_0x4178e9,this['appCheckTokenProvider_']=_0x42c2b4,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x4fcfe4,_0x6b175b,_0x32e033,_0x1c57f7){const _0x4f802d=_0x4fcfe4['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4f802d+'\x20'+_0x4fcfe4['_queryIdentifier']);const _0x5ec067=vn['getListenId_'](_0x4fcfe4,_0x32e033),_0x35103b={};this['listens_'][_0x5ec067]=_0x35103b;const _0x5f27aa=ir(_0x4fcfe4['_queryParams']);this['restRequest_'](_0x4f802d+'.json',_0x5f27aa,(_0x1d2fb7,_0x36e767)=>{let _0x196f44=_0x36e767;if(_0x1d2fb7===0x194&&(_0x196f44=null,_0x1d2fb7=null),_0x1d2fb7===null&&this['onDataUpdate_'](_0x4f802d,_0x196f44,!0x1,_0x32e033),Le(this['listens_'],_0x5ec067)===_0x35103b){let _0x2958b7;_0x1d2fb7?_0x1d2fb7===0x191?_0x2958b7='permission_denied':_0x2958b7='rest_error:'+_0x1d2fb7:_0x2958b7='ok',_0x1c57f7(_0x2958b7,null);}});}['unlisten'](_0x3d4a5a,_0x4473dd){const _0x3fb38e=vn['getListenId_'](_0x3d4a5a,_0x4473dd);delete this['listens_'][_0x3fb38e];}['get'](_0xf4a50c){const _0xad7cf8=ir(_0xf4a50c['_queryParams']),_0x3cf1c4=_0xf4a50c['_path']['toString'](),_0x188b68=new H();return this['restRequest_'](_0x3cf1c4+'.json',_0xad7cf8,(_0xa3ef93,_0x32787d)=>{let _0x33549a=_0x32787d;_0xa3ef93===0x194&&(_0x33549a=null,_0xa3ef93=null),_0xa3ef93===null?(this['onDataUpdate_'](_0x3cf1c4,_0x33549a,!0x1,null),_0x188b68['resolve'](_0x33549a)):_0x188b68['reject'](new Error(_0x33549a));}),_0x188b68['promise'];}['refreshAuthToken'](_0x5daca0){}['restRequest_'](_0x24f7cd,_0x7dc40a={},_0x3fae00){return _0x7dc40a['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3a80be,_0x1ed589])=>{_0x3a80be&&_0x3a80be['accessToken']&&(_0x7dc40a['auth']=_0x3a80be['accessToken']),_0x1ed589&&_0x1ed589['token']&&(_0x7dc40a['ac']=_0x1ed589['token']);const _0x5a4c46=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x24f7cd+'?ns='+this['repoInfo_']['namespace']+ut(_0x7dc40a);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5a4c46);const _0x50dd11=new XMLHttpRequest();_0x50dd11['onreadystatechange']=()=>{if(_0x3fae00&&_0x50dd11['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5a4c46+'\x20received.\x20status:',_0x50dd11['status'],'response:',_0x50dd11['responseText']);let _0x7190f8=null;if(_0x50dd11['status']>=0xc8&&_0x50dd11['status']<0x12c){try{_0x7190f8=Nt(_0x50dd11['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5a4c46+':\x20'+_0x50dd11['responseText']);}_0x3fae00(null,_0x7190f8);}else _0x50dd11['status']!==0x191&&_0x50dd11['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5a4c46+'\x20Status:\x20'+_0x50dd11['status']),_0x3fae00(_0x50dd11['status']);_0x3fae00=null;}},_0x50dd11['open']('GET',_0x5a4c46,!0x0),_0x50dd11['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2ebf71){return this['rootNode_']['getChild'](_0x2ebf71);}['updateSnapshot'](_0x4a471e,_0x4f9143){this['rootNode_']=this['rootNode_']['updateChild'](_0x4a471e,_0x4f9143);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x218914,_0x1da3b3,_0xa5cdb){if(v(_0x1da3b3))_0x218914['value']=_0xa5cdb,_0x218914['children']['clear']();else{if(_0x218914['value']!==null)_0x218914['value']=_0x218914['value']['updateChild'](_0x1da3b3,_0xa5cdb);else{const _0x4a85c1=y(_0x1da3b3);_0x218914['children']['has'](_0x4a85c1)||_0x218914['children']['set'](_0x4a85c1,En());const _0x5d5c07=_0x218914['children']['get'](_0x4a85c1);_0x1da3b3=S(_0x1da3b3),pt(_0x5d5c07,_0x1da3b3,_0xa5cdb);}}}function Ti(_0x7fb45e,_0x227850){if(v(_0x227850))return _0x7fb45e['value']=null,_0x7fb45e['children']['clear'](),!0x0;if(_0x7fb45e['value']!==null){if(_0x7fb45e['value']['isLeafNode']())return!0x1;{const _0x2ca380=_0x7fb45e['value'];return _0x7fb45e['value']=null,_0x2ca380['forEachChild'](R,(_0x23e9af,_0x5f08fc)=>{pt(_0x7fb45e,new C(_0x23e9af),_0x5f08fc);}),Ti(_0x7fb45e,_0x227850);}}else{if(_0x7fb45e['children']['size']>0x0){const _0x559960=y(_0x227850);return _0x227850=S(_0x227850),_0x7fb45e['children']['has'](_0x559960)&&Ti(_0x7fb45e['children']['get'](_0x559960),_0x227850)&&_0x7fb45e['children']['delete'](_0x559960),_0x7fb45e['children']['size']===0x0;}else return!0x0;}}function Si(_0x1d8aa0,_0x299c19,_0x1da6b5){_0x1d8aa0['value']!==null?_0x1da6b5(_0x299c19,_0x1d8aa0['value']):Zh(_0x1d8aa0,(_0x1a626a,_0x514d60)=>{const _0x48f984=new C(_0x299c19['toString']()+'/'+_0x1a626a);Si(_0x514d60,_0x48f984,_0x1da6b5);});}function Zh(_0x42b654,_0xa81dd8){_0x42b654['children']['forEach']((_0x56ab65,_0x425aa6)=>{_0xa81dd8(_0x425aa6,_0x56ab65);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x2caf75){this['collection_']=_0x2caf75,this['last_']=null;}['get'](){const _0x159170=this['collection_']['get'](),_0x58737b={..._0x159170};return this['last_']&&x(this['last_'],(_0x6f25a0,_0x4bda35)=>{_0x58737b[_0x6f25a0]=_0x58737b[_0x6f25a0]-_0x4bda35;}),this['last_']=_0x159170,_0x58737b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x5b78ee,_0x34f546){this['server_']=_0x34f546,this['statsToReport_']={},this['statsListener_']=new eu(_0x5b78ee);const _0x5e04e4=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x5e04e4));}['reportStats_'](){const _0x458f21=this['statsListener_']['get'](),_0x2ed616={};let _0x31ec15=!0x1;x(_0x458f21,(_0x1cbe63,_0x1b811)=>{_0x1b811>0x0&&Q(this['statsToReport_'],_0x1cbe63)&&(_0x2ed616[_0x1cbe63]=_0x1b811,_0x31ec15=!0x0);}),_0x31ec15&&this['server_']['reportStats'](_0x2ed616),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x31814a){_0x31814a[_0x31814a['OVERWRITE']=0x0]='OVERWRITE',_0x31814a[_0x31814a['MERGE']=0x1]='MERGE',_0x31814a[_0x31814a['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x31814a[_0x31814a['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x3f386b){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x3f386b,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x1b4ff2,_0x28661a,_0x1c6cf8){this['path']=_0x1b4ff2,this['affectedTree']=_0x28661a,this['revert']=_0x1c6cf8,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0xf1b616){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4de09b=this['affectedTree']['subtree'](new C(_0xf1b616));return new In(w(),_0x4de09b,this['revert']);}}else return f(y(this['path'])===_0xf1b616,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x38f161,_0x1e87b1){this['source']=_0x38f161,this['path']=_0x1e87b1,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x4e798a){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x16787a,_0x6e0a2e,_0xd07895){this['source']=_0x16787a,this['path']=_0x6e0a2e,this['snap']=_0xd07895,this['type']=z['OVERWRITE'];}['operationForChild'](_0x3086a3){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x3086a3)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x361e47,_0x4911dd,_0x2c8ced){this['source']=_0x361e47,this['path']=_0x4911dd,this['children']=_0x2c8ced,this['type']=z['MERGE'];}['operationForChild'](_0x4efb1e){if(v(this['path'])){const _0x49aec2=this['children']['subtree'](new C(_0x4efb1e));return _0x49aec2['isEmpty']()?null:_0x49aec2['value']?new Be(this['source'],w(),_0x49aec2['value']):new ot(this['source'],w(),_0x49aec2);}else return f(y(this['path'])===_0x4efb1e,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x5a8f2f,_0x1a98f0,_0x15b283){this['node_']=_0x5a8f2f,this['fullyInitialized_']=_0x1a98f0,this['filtered_']=_0x15b283;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4bb322){if(v(_0x4bb322))return this['isFullyInitialized']()&&!this['filtered_'];const _0xe1127f=y(_0x4bb322);return this['isCompleteForChild'](_0xe1127f);}['isCompleteForChild'](_0x2b410d){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2b410d);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x2fd4a3){this['query_']=_0x2fd4a3,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x4864fb,_0x3b9197,_0x309ff2,_0x3a3c06){const _0x319a16=[],_0x510f07=[];return _0x3b9197['forEach'](_0x1ccf73=>{_0x1ccf73['type']==='child_changed'&&_0x4864fb['index_']['indexedValueChanged'](_0x1ccf73['oldSnap'],_0x1ccf73['snapshotNode'])&&_0x510f07['push'](zh(_0x1ccf73['childName'],_0x1ccf73['snapshotNode']));}),wt(_0x4864fb,_0x319a16,'child_removed',_0x3b9197,_0x3a3c06,_0x309ff2),wt(_0x4864fb,_0x319a16,'child_added',_0x3b9197,_0x3a3c06,_0x309ff2),wt(_0x4864fb,_0x319a16,'child_moved',_0x510f07,_0x3a3c06,_0x309ff2),wt(_0x4864fb,_0x319a16,'child_changed',_0x3b9197,_0x3a3c06,_0x309ff2),wt(_0x4864fb,_0x319a16,'value',_0x3b9197,_0x3a3c06,_0x309ff2),_0x319a16;}function wt(_0x1b7b5d,_0x28eaf6,_0x38b2a4,_0x4778c0,_0xa8cbf2,_0x197b0a){const _0x3ebbc4=_0x4778c0['filter'](_0x36a50d=>_0x36a50d['type']===_0x38b2a4);_0x3ebbc4['sort']((_0x2e997f,_0x2f5ac4)=>au(_0x1b7b5d,_0x2e997f,_0x2f5ac4)),_0x3ebbc4['forEach'](_0x3bb675=>{const _0x275743=ou(_0x1b7b5d,_0x3bb675,_0x197b0a);_0xa8cbf2['forEach'](_0x16564a=>{_0x16564a['respondsTo'](_0x3bb675['type'])&&_0x28eaf6['push'](_0x16564a['createEvent'](_0x275743,_0x1b7b5d['query_']));});});}function ou(_0x171ba2,_0x9cdaaa,_0x1a3f9f){return _0x9cdaaa['type']==='value'||_0x9cdaaa['type']==='child_removed'||(_0x9cdaaa['prevName']=_0x1a3f9f['getPredecessorChildName'](_0x9cdaaa['childName'],_0x9cdaaa['snapshotNode'],_0x171ba2['index_'])),_0x9cdaaa;}function au(_0xace7af,_0x345f97,_0x51978f){if(_0x345f97['childName']==null||_0x51978f['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x42da02=new E(_0x345f97['childName'],_0x345f97['snapshotNode']),_0x1c071f=new E(_0x51978f['childName'],_0x51978f['snapshotNode']);return _0xace7af['index_']['compare'](_0x42da02,_0x1c071f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x365865,_0x20f73c){return{'eventCache':_0x365865,'serverCache':_0x20f73c};}function Rt(_0x59edda,_0x5536e6,_0x64ef99,_0x34c42c){return Un(new Te(_0x5536e6,_0x64ef99,_0x34c42c),_0x59edda['serverCache']);}function Fo(_0x22feeb,_0x2f4895,_0x1bde8f,_0x34cda8){return Un(_0x22feeb['eventCache'],new Te(_0x2f4895,_0x1bde8f,_0x34cda8));}function wn(_0x180b69){return _0x180b69['eventCache']['isFullyInitialized']()?_0x180b69['eventCache']['getNode']():null;}function Ve(_0x4037f4){return _0x4037f4['serverCache']['isFullyInitialized']()?_0x4037f4['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x5e89a4){let _0x586bda=new b(null);return x(_0x5e89a4,(_0x537ce1,_0x19dd38)=>{_0x586bda=_0x586bda['set'](new C(_0x537ce1),_0x19dd38);}),_0x586bda;}constructor(_0x779f5f,_0x4ca518=cu()){this['value']=_0x779f5f,this['children']=_0x4ca518;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5b8288,_0x5261d1){if(this['value']!=null&&_0x5261d1(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5b8288))return null;{const _0x1023da=y(_0x5b8288),_0x12e631=this['children']['get'](_0x1023da);if(_0x12e631!==null){const _0x1bbf96=_0x12e631['findRootMostMatchingPathAndValue'](S(_0x5b8288),_0x5261d1);return _0x1bbf96!=null?{'path':k(new C(_0x1023da),_0x1bbf96['path']),'value':_0x1bbf96['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4e6c67){return this['findRootMostMatchingPathAndValue'](_0x4e6c67,()=>!0x0);}['subtree'](_0x34ab3b){if(v(_0x34ab3b))return this;{const _0x6be3d8=y(_0x34ab3b),_0x4e85d2=this['children']['get'](_0x6be3d8);return _0x4e85d2!==null?_0x4e85d2['subtree'](S(_0x34ab3b)):new b(null);}}['set'](_0x5f0a01,_0x2e190c){if(v(_0x5f0a01))return new b(_0x2e190c,this['children']);{const _0x205c4e=y(_0x5f0a01),_0x41a9cc=(this['children']['get'](_0x205c4e)||new b(null))['set'](S(_0x5f0a01),_0x2e190c),_0x4ad33c=this['children']['insert'](_0x205c4e,_0x41a9cc);return new b(this['value'],_0x4ad33c);}}['remove'](_0x86669){if(v(_0x86669))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x39ee05=y(_0x86669),_0x263b09=this['children']['get'](_0x39ee05);if(_0x263b09){const _0x1c2341=_0x263b09['remove'](S(_0x86669));let _0xcae9d0;return _0x1c2341['isEmpty']()?_0xcae9d0=this['children']['remove'](_0x39ee05):_0xcae9d0=this['children']['insert'](_0x39ee05,_0x1c2341),this['value']===null&&_0xcae9d0['isEmpty']()?new b(null):new b(this['value'],_0xcae9d0);}else return this;}}['get'](_0x4a1b16){if(v(_0x4a1b16))return this['value'];{const _0x14e2b5=y(_0x4a1b16),_0x44d655=this['children']['get'](_0x14e2b5);return _0x44d655?_0x44d655['get'](S(_0x4a1b16)):null;}}['setTree'](_0x8cb018,_0x260bc7){if(v(_0x8cb018))return _0x260bc7;{const _0x107091=y(_0x8cb018),_0x23400e=(this['children']['get'](_0x107091)||new b(null))['setTree'](S(_0x8cb018),_0x260bc7);let _0x5495c2;return _0x23400e['isEmpty']()?_0x5495c2=this['children']['remove'](_0x107091):_0x5495c2=this['children']['insert'](_0x107091,_0x23400e),new b(this['value'],_0x5495c2);}}['fold'](_0x51c764){return this['fold_'](w(),_0x51c764);}['fold_'](_0x248b12,_0x45edb6){const _0x4a4875={};return this['children']['inorderTraversal']((_0x10196d,_0x557bcb)=>{_0x4a4875[_0x10196d]=_0x557bcb['fold_'](k(_0x248b12,_0x10196d),_0x45edb6);}),_0x45edb6(_0x248b12,this['value'],_0x4a4875);}['findOnPath'](_0x5a6070,_0xf1f6da){return this['findOnPath_'](_0x5a6070,w(),_0xf1f6da);}['findOnPath_'](_0x57a95c,_0x698b9f,_0x193ba1){const _0x85d07b=this['value']?_0x193ba1(_0x698b9f,this['value']):!0x1;if(_0x85d07b)return _0x85d07b;if(v(_0x57a95c))return null;{const _0xb80d08=y(_0x57a95c),_0x2b61f5=this['children']['get'](_0xb80d08);return _0x2b61f5?_0x2b61f5['findOnPath_'](S(_0x57a95c),k(_0x698b9f,_0xb80d08),_0x193ba1):null;}}['foreachOnPath'](_0xf26fc8,_0x59cda9){return this['foreachOnPath_'](_0xf26fc8,w(),_0x59cda9);}['foreachOnPath_'](_0x50882f,_0x59c762,_0x1d4357){if(v(_0x50882f))return this;{this['value']&&_0x1d4357(_0x59c762,this['value']);const _0x2ba3f5=y(_0x50882f),_0x211023=this['children']['get'](_0x2ba3f5);return _0x211023?_0x211023['foreachOnPath_'](S(_0x50882f),k(_0x59c762,_0x2ba3f5),_0x1d4357):new b(null);}}['foreach'](_0x49693c){this['foreach_'](w(),_0x49693c);}['foreach_'](_0x215baa,_0x1dd347){this['children']['inorderTraversal']((_0x2e624a,_0x70b62f)=>{_0x70b62f['foreach_'](k(_0x215baa,_0x2e624a),_0x1dd347);}),this['value']&&_0x1dd347(_0x215baa,this['value']);}['foreachChild'](_0x55882e){this['children']['inorderTraversal']((_0x4ddbb4,_0x5a1868)=>{_0x5a1868['value']&&_0x55882e(_0x4ddbb4,_0x5a1868['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x231a45){this['writeTree_']=_0x231a45;}static['empty'](){return new K(new b(null));}}function At(_0x3d4b34,_0x3a12f7,_0x48c844){if(v(_0x3a12f7))return new K(new b(_0x48c844));{const _0x54b257=_0x3d4b34['writeTree_']['findRootMostValueAndPath'](_0x3a12f7);if(_0x54b257!=null){const _0x930424=_0x54b257['path'];let _0x14ece8=_0x54b257['value'];const _0x234bdd=F(_0x930424,_0x3a12f7);return _0x14ece8=_0x14ece8['updateChild'](_0x234bdd,_0x48c844),new K(_0x3d4b34['writeTree_']['set'](_0x930424,_0x14ece8));}else{const _0x594abb=new b(_0x48c844),_0xca3a67=_0x3d4b34['writeTree_']['setTree'](_0x3a12f7,_0x594abb);return new K(_0xca3a67);}}}function bi(_0x519dd6,_0x518753,_0x2e36e1){let _0x286fba=_0x519dd6;return x(_0x2e36e1,(_0x139901,_0x10e75a)=>{_0x286fba=At(_0x286fba,k(_0x518753,_0x139901),_0x10e75a);}),_0x286fba;}function or(_0x57328f,_0x5a084b){if(v(_0x5a084b))return K['empty']();{const _0x33c16c=_0x57328f['writeTree_']['setTree'](_0x5a084b,new b(null));return new K(_0x33c16c);}}function Ri(_0x4884b1,_0x38287e){return ze(_0x4884b1,_0x38287e)!=null;}function ze(_0x217307,_0x5234fd){const _0x1c9c3c=_0x217307['writeTree_']['findRootMostValueAndPath'](_0x5234fd);return _0x1c9c3c!=null?_0x217307['writeTree_']['get'](_0x1c9c3c['path'])['getChild'](F(_0x1c9c3c['path'],_0x5234fd)):null;}function ar(_0x5aa959){const _0x5bba87=[],_0xfebcdf=_0x5aa959['writeTree_']['value'];return _0xfebcdf!=null?_0xfebcdf['isLeafNode']()||_0xfebcdf['forEachChild'](R,(_0x2a851a,_0x45de54)=>{_0x5bba87['push'](new E(_0x2a851a,_0x45de54));}):_0x5aa959['writeTree_']['children']['inorderTraversal']((_0x1d4158,_0x363647)=>{_0x363647['value']!=null&&_0x5bba87['push'](new E(_0x1d4158,_0x363647['value']));}),_0x5bba87;}function Ee(_0x51b428,_0x26ebbe){if(v(_0x26ebbe))return _0x51b428;{const _0x37d2c8=ze(_0x51b428,_0x26ebbe);return _0x37d2c8!=null?new K(new b(_0x37d2c8)):new K(_0x51b428['writeTree_']['subtree'](_0x26ebbe));}}function Ai(_0x5600c7){return _0x5600c7['writeTree_']['isEmpty']();}function at(_0x582559,_0x2f9e6e){return Uo(w(),_0x582559['writeTree_'],_0x2f9e6e);}function Uo(_0x22e13c,_0x33439f,_0x5787ec){if(_0x33439f['value']!=null)return _0x5787ec['updateChild'](_0x22e13c,_0x33439f['value']);{let _0x5e075c=null;return _0x33439f['children']['inorderTraversal']((_0x26804d,_0x4c40ac)=>{_0x26804d==='.priority'?(f(_0x4c40ac['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5e075c=_0x4c40ac['value']):_0x5787ec=Uo(k(_0x22e13c,_0x26804d),_0x4c40ac,_0x5787ec);}),!_0x5787ec['getChild'](_0x22e13c)['isEmpty']()&&_0x5e075c!==null&&(_0x5787ec=_0x5787ec['updateChild'](k(_0x22e13c,'.priority'),_0x5e075c)),_0x5787ec;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x58bbfd,_0x673e88){return Ho(_0x673e88,_0x58bbfd);}function lu(_0x4667ed,_0x4579d0,_0x535a84,_0xc52a3c,_0x305303){f(_0xc52a3c>_0x4667ed['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x305303===void 0x0&&(_0x305303=!0x0),_0x4667ed['allWrites']['push']({'path':_0x4579d0,'snap':_0x535a84,'writeId':_0xc52a3c,'visible':_0x305303}),_0x305303&&(_0x4667ed['visibleWrites']=At(_0x4667ed['visibleWrites'],_0x4579d0,_0x535a84)),_0x4667ed['lastWriteId']=_0xc52a3c;}function hu(_0x3ccf8a,_0x59e77e,_0x1d69e8,_0x43a9fb){f(_0x43a9fb>_0x3ccf8a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3ccf8a['allWrites']['push']({'path':_0x59e77e,'children':_0x1d69e8,'writeId':_0x43a9fb,'visible':!0x0}),_0x3ccf8a['visibleWrites']=bi(_0x3ccf8a['visibleWrites'],_0x59e77e,_0x1d69e8),_0x3ccf8a['lastWriteId']=_0x43a9fb;}function uu(_0xfdf06b,_0x289f81){for(let _0x456761=0x0;_0x456761<_0xfdf06b['allWrites']['length'];_0x456761++){const _0x583359=_0xfdf06b['allWrites'][_0x456761];if(_0x583359['writeId']===_0x289f81)return _0x583359;}return null;}function du(_0x238bfa,_0x3fe159){const _0x596819=_0x238bfa['allWrites']['findIndex'](_0xb9328a=>_0xb9328a['writeId']===_0x3fe159);f(_0x596819>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x13fc67=_0x238bfa['allWrites'][_0x596819];_0x238bfa['allWrites']['splice'](_0x596819,0x1);let _0x167af6=_0x13fc67['visible'],_0x207df7=!0x1,_0x125e77=_0x238bfa['allWrites']['length']-0x1;for(;_0x167af6&&_0x125e77>=0x0;){const _0x19640f=_0x238bfa['allWrites'][_0x125e77];_0x19640f['visible']&&(_0x125e77>=_0x596819&&fu(_0x19640f,_0x13fc67['path'])?_0x167af6=!0x1:G(_0x13fc67['path'],_0x19640f['path'])&&(_0x207df7=!0x0)),_0x125e77--;}if(_0x167af6){if(_0x207df7)return pu(_0x238bfa),!0x0;if(_0x13fc67['snap'])_0x238bfa['visibleWrites']=or(_0x238bfa['visibleWrites'],_0x13fc67['path']);else{const _0x5b1287=_0x13fc67['children'];x(_0x5b1287,_0x1be8c3=>{_0x238bfa['visibleWrites']=or(_0x238bfa['visibleWrites'],k(_0x13fc67['path'],_0x1be8c3));});}return!0x0;}else return!0x1;}function fu(_0x3e05eb,_0x1148b1){if(_0x3e05eb['snap'])return G(_0x3e05eb['path'],_0x1148b1);for(const _0x367c02 in _0x3e05eb['children'])if(_0x3e05eb['children']['hasOwnProperty'](_0x367c02)&&G(k(_0x3e05eb['path'],_0x367c02),_0x1148b1))return!0x0;return!0x1;}function pu(_0x54a944){_0x54a944['visibleWrites']=Wo(_0x54a944['allWrites'],_u,w()),_0x54a944['allWrites']['length']>0x0?_0x54a944['lastWriteId']=_0x54a944['allWrites'][_0x54a944['allWrites']['length']-0x1]['writeId']:_0x54a944['lastWriteId']=-0x1;}function _u(_0x448062){return _0x448062['visible'];}function Wo(_0xf96609,_0x120f7f,_0xad2b2){let _0x4dfe20=K['empty']();for(let _0x494691=0x0;_0x494691<_0xf96609['length'];++_0x494691){const _0x1115d1=_0xf96609[_0x494691];if(_0x120f7f(_0x1115d1)){const _0x17daa8=_0x1115d1['path'];let _0x592e12;if(_0x1115d1['snap'])G(_0xad2b2,_0x17daa8)?(_0x592e12=F(_0xad2b2,_0x17daa8),_0x4dfe20=At(_0x4dfe20,_0x592e12,_0x1115d1['snap'])):G(_0x17daa8,_0xad2b2)&&(_0x592e12=F(_0x17daa8,_0xad2b2),_0x4dfe20=At(_0x4dfe20,w(),_0x1115d1['snap']['getChild'](_0x592e12)));else{if(_0x1115d1['children']){if(G(_0xad2b2,_0x17daa8))_0x592e12=F(_0xad2b2,_0x17daa8),_0x4dfe20=bi(_0x4dfe20,_0x592e12,_0x1115d1['children']);else{if(G(_0x17daa8,_0xad2b2)){if(_0x592e12=F(_0x17daa8,_0xad2b2),v(_0x592e12))_0x4dfe20=bi(_0x4dfe20,w(),_0x1115d1['children']);else{const _0x3c38be=Le(_0x1115d1['children'],y(_0x592e12));if(_0x3c38be){const _0x19514e=_0x3c38be['getChild'](S(_0x592e12));_0x4dfe20=At(_0x4dfe20,w(),_0x19514e);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4dfe20;}function Bo(_0x931ff,_0x406e8b,_0x28764c,_0x116eac,_0x30555d){if(!_0x116eac&&!_0x30555d){const _0x3f0372=ze(_0x931ff['visibleWrites'],_0x406e8b);if(_0x3f0372!=null)return _0x3f0372;{const _0x1f8749=Ee(_0x931ff['visibleWrites'],_0x406e8b);if(Ai(_0x1f8749))return _0x28764c;if(_0x28764c==null&&!Ri(_0x1f8749,w()))return null;{const _0x4ad105=_0x28764c||g['EMPTY_NODE'];return at(_0x1f8749,_0x4ad105);}}}else{const _0x5276ee=Ee(_0x931ff['visibleWrites'],_0x406e8b);if(!_0x30555d&&Ai(_0x5276ee))return _0x28764c;if(!_0x30555d&&_0x28764c==null&&!Ri(_0x5276ee,w()))return null;{const _0x2f7d6e=function(_0x298289){return(_0x298289['visible']||_0x30555d)&&(!_0x116eac||!~_0x116eac['indexOf'](_0x298289['writeId']))&&(G(_0x298289['path'],_0x406e8b)||G(_0x406e8b,_0x298289['path']));},_0xc05f=Wo(_0x931ff['allWrites'],_0x2f7d6e,_0x406e8b),_0x241975=_0x28764c||g['EMPTY_NODE'];return at(_0xc05f,_0x241975);}}}function gu(_0x42eeb6,_0x43f89d,_0x4b8a6e){let _0x4a5435=g['EMPTY_NODE'];const _0xaf5ff6=ze(_0x42eeb6['visibleWrites'],_0x43f89d);if(_0xaf5ff6)return _0xaf5ff6['isLeafNode']()||_0xaf5ff6['forEachChild'](R,(_0x1a387b,_0x2b04b7)=>{_0x4a5435=_0x4a5435['updateImmediateChild'](_0x1a387b,_0x2b04b7);}),_0x4a5435;if(_0x4b8a6e){const _0x3908db=Ee(_0x42eeb6['visibleWrites'],_0x43f89d);return _0x4b8a6e['forEachChild'](R,(_0x4e72a4,_0x25ac13)=>{const _0x12f9ac=at(Ee(_0x3908db,new C(_0x4e72a4)),_0x25ac13);_0x4a5435=_0x4a5435['updateImmediateChild'](_0x4e72a4,_0x12f9ac);}),ar(_0x3908db)['forEach'](_0x3a7a6b=>{_0x4a5435=_0x4a5435['updateImmediateChild'](_0x3a7a6b['name'],_0x3a7a6b['node']);}),_0x4a5435;}else{const _0x1f138d=Ee(_0x42eeb6['visibleWrites'],_0x43f89d);return ar(_0x1f138d)['forEach'](_0x363b94=>{_0x4a5435=_0x4a5435['updateImmediateChild'](_0x363b94['name'],_0x363b94['node']);}),_0x4a5435;}}function mu(_0x3bcd66,_0x2ce2da,_0x5cd152,_0x2c6182,_0x3bcab9){f(_0x2c6182||_0x3bcab9,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x135178=k(_0x2ce2da,_0x5cd152);if(Ri(_0x3bcd66['visibleWrites'],_0x135178))return null;{const _0x37655a=Ee(_0x3bcd66['visibleWrites'],_0x135178);return Ai(_0x37655a)?_0x3bcab9['getChild'](_0x5cd152):at(_0x37655a,_0x3bcab9['getChild'](_0x5cd152));}}function yu(_0x24f70e,_0x14799b,_0x212db5,_0x328fa4){const _0x41c605=k(_0x14799b,_0x212db5),_0x2847c6=ze(_0x24f70e['visibleWrites'],_0x41c605);if(_0x2847c6!=null)return _0x2847c6;if(_0x328fa4['isCompleteForChild'](_0x212db5)){const _0x260b9a=Ee(_0x24f70e['visibleWrites'],_0x41c605);return at(_0x260b9a,_0x328fa4['getNode']()['getImmediateChild'](_0x212db5));}else return null;}function vu(_0x37c774,_0x200afd){return ze(_0x37c774['visibleWrites'],_0x200afd);}function Eu(_0x175ebc,_0x54845f,_0x55647c,_0x382859,_0x3c98a6,_0x455b12,_0x2b99cf){let _0x4cd3a6;const _0xce68c3=Ee(_0x175ebc['visibleWrites'],_0x54845f),_0x474186=ze(_0xce68c3,w());if(_0x474186!=null)_0x4cd3a6=_0x474186;else{if(_0x55647c!=null)_0x4cd3a6=at(_0xce68c3,_0x55647c);else return[];}if(_0x4cd3a6=_0x4cd3a6['withIndex'](_0x2b99cf),!_0x4cd3a6['isEmpty']()&&!_0x4cd3a6['isLeafNode']()){const _0x1b735a=[],_0x623e4b=_0x2b99cf['getCompare'](),_0xe484a0=_0x455b12?_0x4cd3a6['getReverseIteratorFrom'](_0x382859,_0x2b99cf):_0x4cd3a6['getIteratorFrom'](_0x382859,_0x2b99cf);let _0x555f40=_0xe484a0['getNext']();for(;_0x555f40&&_0x1b735a['length']<_0x3c98a6;)_0x623e4b(_0x555f40,_0x382859)!==0x0&&_0x1b735a['push'](_0x555f40),_0x555f40=_0xe484a0['getNext']();return _0x1b735a;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x2a97a1,_0x7883f8,_0x332d5e,_0x194b45){return Bo(_0x2a97a1['writeTree'],_0x2a97a1['treePath'],_0x7883f8,_0x332d5e,_0x194b45);}function is(_0x5f5989,_0x4f2a6e){return gu(_0x5f5989['writeTree'],_0x5f5989['treePath'],_0x4f2a6e);}function cr(_0x2dfde6,_0x2dcb37,_0x9f4008,_0x5ed9bd){return mu(_0x2dfde6['writeTree'],_0x2dfde6['treePath'],_0x2dcb37,_0x9f4008,_0x5ed9bd);}function Tn(_0x18a235,_0x3ba285){return vu(_0x18a235['writeTree'],k(_0x18a235['treePath'],_0x3ba285));}function wu(_0x238843,_0xa8c625,_0x1d2470,_0x439f39,_0x22be7a,_0x4375da){return Eu(_0x238843['writeTree'],_0x238843['treePath'],_0xa8c625,_0x1d2470,_0x439f39,_0x22be7a,_0x4375da);}function ss(_0x3d80f1,_0x996526,_0x172843){return yu(_0x3d80f1['writeTree'],_0x3d80f1['treePath'],_0x996526,_0x172843);}function Vo(_0x2f0af7,_0x1a9c0c){return Ho(k(_0x2f0af7['treePath'],_0x1a9c0c),_0x2f0af7['writeTree']);}function Ho(_0xb815ff,_0x3d207b){return{'treePath':_0xb815ff,'writeTree':_0x3d207b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x33f58f){const _0x2987d0=_0x33f58f['type'],_0x4e29c1=_0x33f58f['childName'];f(_0x2987d0==='child_added'||_0x2987d0==='child_changed'||_0x2987d0==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4e29c1!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2260d2=this['changeMap']['get'](_0x4e29c1);if(_0x2260d2){const _0x212902=_0x2260d2['type'];if(_0x2987d0==='child_added'&&_0x212902==='child_removed')this['changeMap']['set'](_0x4e29c1,xt(_0x4e29c1,_0x33f58f['snapshotNode'],_0x2260d2['snapshotNode']));else{if(_0x2987d0==='child_removed'&&_0x212902==='child_added')this['changeMap']['delete'](_0x4e29c1);else{if(_0x2987d0==='child_removed'&&_0x212902==='child_changed')this['changeMap']['set'](_0x4e29c1,Lt(_0x4e29c1,_0x2260d2['oldSnap']));else{if(_0x2987d0==='child_changed'&&_0x212902==='child_added')this['changeMap']['set'](_0x4e29c1,rt(_0x4e29c1,_0x33f58f['snapshotNode']));else{if(_0x2987d0==='child_changed'&&_0x212902==='child_changed')this['changeMap']['set'](_0x4e29c1,xt(_0x4e29c1,_0x33f58f['snapshotNode'],_0x2260d2['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x33f58f+'\x20occurred\x20after\x20'+_0x2260d2);}}}}}else this['changeMap']['set'](_0x4e29c1,_0x33f58f);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x290881){return null;}['getChildAfterChild'](_0x2f3eca,_0x1ea93b,_0x5b99dd){return null;}}const $o=new Tu();class rs{constructor(_0x476958,_0xab36d9,_0x246727=null){this['writes_']=_0x476958,this['viewCache_']=_0xab36d9,this['optCompleteServerCache_']=_0x246727;}['getCompleteChild'](_0x1ff6ce){const _0x2c019c=this['viewCache_']['eventCache'];if(_0x2c019c['isCompleteForChild'](_0x1ff6ce))return _0x2c019c['getNode']()['getImmediateChild'](_0x1ff6ce);{const _0x403f03=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x1ff6ce,_0x403f03);}}['getChildAfterChild'](_0x262be8,_0x444494,_0x5e8b8e){const _0x1ee858=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x5d87e9=wu(this['writes_'],_0x1ee858,_0x444494,0x1,_0x5e8b8e,_0x262be8);return _0x5d87e9['length']===0x0?null:_0x5d87e9[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3ee0b6){return{'filter':_0x3ee0b6};}function bu(_0x55e7f0,_0x23480e){f(_0x23480e['eventCache']['getNode']()['isIndexed'](_0x55e7f0['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x23480e['serverCache']['getNode']()['isIndexed'](_0x55e7f0['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0xd09e7d,_0x37df3f,_0x77390f,_0x3c36e7,_0x30b44d){const _0x2520c=new Cu();let _0x391c50,_0x2e000a;if(_0x77390f['type']===z['OVERWRITE']){const _0x86e1f4=_0x77390f;_0x86e1f4['source']['fromUser']?_0x391c50=ki(_0xd09e7d,_0x37df3f,_0x86e1f4['path'],_0x86e1f4['snap'],_0x3c36e7,_0x30b44d,_0x2520c):(f(_0x86e1f4['source']['fromServer'],'Unknown\x20source.'),_0x2e000a=_0x86e1f4['source']['tagged']||_0x37df3f['serverCache']['isFiltered']()&&!v(_0x86e1f4['path']),_0x391c50=Sn(_0xd09e7d,_0x37df3f,_0x86e1f4['path'],_0x86e1f4['snap'],_0x3c36e7,_0x30b44d,_0x2e000a,_0x2520c));}else{if(_0x77390f['type']===z['MERGE']){const _0x3d5eb6=_0x77390f;_0x3d5eb6['source']['fromUser']?_0x391c50=ku(_0xd09e7d,_0x37df3f,_0x3d5eb6['path'],_0x3d5eb6['children'],_0x3c36e7,_0x30b44d,_0x2520c):(f(_0x3d5eb6['source']['fromServer'],'Unknown\x20source.'),_0x2e000a=_0x3d5eb6['source']['tagged']||_0x37df3f['serverCache']['isFiltered'](),_0x391c50=Pi(_0xd09e7d,_0x37df3f,_0x3d5eb6['path'],_0x3d5eb6['children'],_0x3c36e7,_0x30b44d,_0x2e000a,_0x2520c));}else{if(_0x77390f['type']===z['ACK_USER_WRITE']){const _0x592315=_0x77390f;_0x592315['revert']?_0x391c50=Ou(_0xd09e7d,_0x37df3f,_0x592315['path'],_0x3c36e7,_0x30b44d,_0x2520c):_0x391c50=Pu(_0xd09e7d,_0x37df3f,_0x592315['path'],_0x592315['affectedTree'],_0x3c36e7,_0x30b44d,_0x2520c);}else{if(_0x77390f['type']===z['LISTEN_COMPLETE'])_0x391c50=Nu(_0xd09e7d,_0x37df3f,_0x77390f['path'],_0x3c36e7,_0x2520c);else throw ht('Unknown\x20operation\x20type:\x20'+_0x77390f['type']);}}}const _0x4bff8f=_0x2520c['getChanges']();return Au(_0x37df3f,_0x391c50,_0x4bff8f),{'viewCache':_0x391c50,'changes':_0x4bff8f};}function Au(_0xa41d65,_0x370416,_0x48dc74){const _0x778f26=_0x370416['eventCache'];if(_0x778f26['isFullyInitialized']()){const _0x9b4de4=_0x778f26['getNode']()['isLeafNode']()||_0x778f26['getNode']()['isEmpty'](),_0x48a6f5=wn(_0xa41d65);(_0x48dc74['length']>0x0||!_0xa41d65['eventCache']['isFullyInitialized']()||_0x9b4de4&&!_0x778f26['getNode']()['equals'](_0x48a6f5)||!_0x778f26['getNode']()['getPriority']()['equals'](_0x48a6f5['getPriority']()))&&_0x48dc74['push'](Lo(wn(_0x370416)));}}function Go(_0x37b714,_0x3fe212,_0x1cefaa,_0x47d87a,_0x5e6e19,_0xb41646){const _0x210d8c=_0x3fe212['eventCache'];if(Tn(_0x47d87a,_0x1cefaa)!=null)return _0x3fe212;{let _0x2aff5d,_0x838a54;if(v(_0x1cefaa)){if(f(_0x3fe212['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3fe212['serverCache']['isFiltered']()){const _0xda9503=Ve(_0x3fe212),_0x25a139=_0xda9503 instanceof g?_0xda9503:g['EMPTY_NODE'],_0x4a2a20=is(_0x47d87a,_0x25a139);_0x2aff5d=_0x37b714['filter']['updateFullNode'](_0x3fe212['eventCache']['getNode'](),_0x4a2a20,_0xb41646);}else{const _0x34e26b=Cn(_0x47d87a,Ve(_0x3fe212));_0x2aff5d=_0x37b714['filter']['updateFullNode'](_0x3fe212['eventCache']['getNode'](),_0x34e26b,_0xb41646);}}else{const _0x5359ea=y(_0x1cefaa);if(_0x5359ea==='.priority'){f(Ce(_0x1cefaa)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xf8c520=_0x210d8c['getNode']();_0x838a54=_0x3fe212['serverCache']['getNode']();const _0x3b9eeb=cr(_0x47d87a,_0x1cefaa,_0xf8c520,_0x838a54);_0x3b9eeb!=null?_0x2aff5d=_0x37b714['filter']['updatePriority'](_0xf8c520,_0x3b9eeb):_0x2aff5d=_0x210d8c['getNode']();}else{const _0x290c34=S(_0x1cefaa);let _0x2f7473;if(_0x210d8c['isCompleteForChild'](_0x5359ea)){_0x838a54=_0x3fe212['serverCache']['getNode']();const _0xb06358=cr(_0x47d87a,_0x1cefaa,_0x210d8c['getNode'](),_0x838a54);_0xb06358!=null?_0x2f7473=_0x210d8c['getNode']()['getImmediateChild'](_0x5359ea)['updateChild'](_0x290c34,_0xb06358):_0x2f7473=_0x210d8c['getNode']()['getImmediateChild'](_0x5359ea);}else _0x2f7473=ss(_0x47d87a,_0x5359ea,_0x3fe212['serverCache']);_0x2f7473!=null?_0x2aff5d=_0x37b714['filter']['updateChild'](_0x210d8c['getNode'](),_0x5359ea,_0x2f7473,_0x290c34,_0x5e6e19,_0xb41646):_0x2aff5d=_0x210d8c['getNode']();}}return Rt(_0x3fe212,_0x2aff5d,_0x210d8c['isFullyInitialized']()||v(_0x1cefaa),_0x37b714['filter']['filtersNodes']());}}function Sn(_0x2764a,_0x57847f,_0x558332,_0x31f8bb,_0x4d5fad,_0x22391d,_0x1820c3,_0x5be12d){const _0x2212d4=_0x57847f['serverCache'];let _0x1666b5;const _0x396091=_0x1820c3?_0x2764a['filter']:_0x2764a['filter']['getIndexedFilter']();if(v(_0x558332))_0x1666b5=_0x396091['updateFullNode'](_0x2212d4['getNode'](),_0x31f8bb,null);else{if(_0x396091['filtersNodes']()&&!_0x2212d4['isFiltered']()){const _0x22ad14=_0x2212d4['getNode']()['updateChild'](_0x558332,_0x31f8bb);_0x1666b5=_0x396091['updateFullNode'](_0x2212d4['getNode'](),_0x22ad14,null);}else{const _0x45f461=y(_0x558332);if(!_0x2212d4['isCompleteForPath'](_0x558332)&&Ce(_0x558332)>0x1)return _0x57847f;const _0x511aa6=S(_0x558332),_0x385846=_0x2212d4['getNode']()['getImmediateChild'](_0x45f461)['updateChild'](_0x511aa6,_0x31f8bb);_0x45f461==='.priority'?_0x1666b5=_0x396091['updatePriority'](_0x2212d4['getNode'](),_0x385846):_0x1666b5=_0x396091['updateChild'](_0x2212d4['getNode'](),_0x45f461,_0x385846,_0x511aa6,$o,null);}}const _0xd99fd4=Fo(_0x57847f,_0x1666b5,_0x2212d4['isFullyInitialized']()||v(_0x558332),_0x396091['filtersNodes']()),_0x368b99=new rs(_0x4d5fad,_0xd99fd4,_0x22391d);return Go(_0x2764a,_0xd99fd4,_0x558332,_0x4d5fad,_0x368b99,_0x5be12d);}function ki(_0x1d29c0,_0x1f1aac,_0x3a316e,_0x2a5889,_0x1f2853,_0x514416,_0x358dad){const _0x4867d0=_0x1f1aac['eventCache'];let _0x1a2b33,_0x29b9ba;const _0x10112f=new rs(_0x1f2853,_0x1f1aac,_0x514416);if(v(_0x3a316e))_0x29b9ba=_0x1d29c0['filter']['updateFullNode'](_0x1f1aac['eventCache']['getNode'](),_0x2a5889,_0x358dad),_0x1a2b33=Rt(_0x1f1aac,_0x29b9ba,!0x0,_0x1d29c0['filter']['filtersNodes']());else{const _0xc9283d=y(_0x3a316e);if(_0xc9283d==='.priority')_0x29b9ba=_0x1d29c0['filter']['updatePriority'](_0x1f1aac['eventCache']['getNode'](),_0x2a5889),_0x1a2b33=Rt(_0x1f1aac,_0x29b9ba,_0x4867d0['isFullyInitialized'](),_0x4867d0['isFiltered']());else{const _0x432a92=S(_0x3a316e),_0x1a7d88=_0x4867d0['getNode']()['getImmediateChild'](_0xc9283d);let _0x925a2e;if(v(_0x432a92))_0x925a2e=_0x2a5889;else{const _0x30a0e2=_0x10112f['getCompleteChild'](_0xc9283d);_0x30a0e2!=null?ji(_0x432a92)==='.priority'&&_0x30a0e2['getChild'](Ro(_0x432a92))['isEmpty']()?_0x925a2e=_0x30a0e2:_0x925a2e=_0x30a0e2['updateChild'](_0x432a92,_0x2a5889):_0x925a2e=g['EMPTY_NODE'];}if(_0x1a7d88['equals'](_0x925a2e))_0x1a2b33=_0x1f1aac;else{const _0x5e249f=_0x1d29c0['filter']['updateChild'](_0x4867d0['getNode'](),_0xc9283d,_0x925a2e,_0x432a92,_0x10112f,_0x358dad);_0x1a2b33=Rt(_0x1f1aac,_0x5e249f,_0x4867d0['isFullyInitialized'](),_0x1d29c0['filter']['filtersNodes']());}}}return _0x1a2b33;}function lr(_0x1956ab,_0x3acac3){return _0x1956ab['eventCache']['isCompleteForChild'](_0x3acac3);}function ku(_0x2f74ed,_0x1db2e8,_0x1fd15a,_0x34a692,_0x5f53bf,_0x332574,_0x3903e6){let _0x19c7b4=_0x1db2e8;return _0x34a692['foreach']((_0x4740d5,_0x2be205)=>{const _0x38864d=k(_0x1fd15a,_0x4740d5);lr(_0x1db2e8,y(_0x38864d))&&(_0x19c7b4=ki(_0x2f74ed,_0x19c7b4,_0x38864d,_0x2be205,_0x5f53bf,_0x332574,_0x3903e6));}),_0x34a692['foreach']((_0x1de361,_0x16cf40)=>{const _0xce3592=k(_0x1fd15a,_0x1de361);lr(_0x1db2e8,y(_0xce3592))||(_0x19c7b4=ki(_0x2f74ed,_0x19c7b4,_0xce3592,_0x16cf40,_0x5f53bf,_0x332574,_0x3903e6));}),_0x19c7b4;}function hr(_0x1883da,_0x2d8e0d,_0x24c827){return _0x24c827['foreach']((_0x4d99bf,_0x3b9c86)=>{_0x2d8e0d=_0x2d8e0d['updateChild'](_0x4d99bf,_0x3b9c86);}),_0x2d8e0d;}function Pi(_0x5f0fba,_0x5c098e,_0x2beaf9,_0x56ed28,_0x16ac04,_0x48512e,_0x2e67a3,_0x1d0cba){if(_0x5c098e['serverCache']['getNode']()['isEmpty']()&&!_0x5c098e['serverCache']['isFullyInitialized']())return _0x5c098e;let _0x331b80=_0x5c098e,_0x98c86e;v(_0x2beaf9)?_0x98c86e=_0x56ed28:_0x98c86e=new b(null)['setTree'](_0x2beaf9,_0x56ed28);const _0x5cd1bd=_0x5c098e['serverCache']['getNode']();return _0x98c86e['children']['inorderTraversal']((_0x11fab2,_0x516353)=>{if(_0x5cd1bd['hasChild'](_0x11fab2)){const _0x70558f=_0x5c098e['serverCache']['getNode']()['getImmediateChild'](_0x11fab2),_0x8bd344=hr(_0x5f0fba,_0x70558f,_0x516353);_0x331b80=Sn(_0x5f0fba,_0x331b80,new C(_0x11fab2),_0x8bd344,_0x16ac04,_0x48512e,_0x2e67a3,_0x1d0cba);}}),_0x98c86e['children']['inorderTraversal']((_0x30d504,_0x48455f)=>{const _0x1860d6=!_0x5c098e['serverCache']['isCompleteForChild'](_0x30d504)&&_0x48455f['value']===null;if(!_0x5cd1bd['hasChild'](_0x30d504)&&!_0x1860d6){const _0x561d04=_0x5c098e['serverCache']['getNode']()['getImmediateChild'](_0x30d504),_0x3e3f94=hr(_0x5f0fba,_0x561d04,_0x48455f);_0x331b80=Sn(_0x5f0fba,_0x331b80,new C(_0x30d504),_0x3e3f94,_0x16ac04,_0x48512e,_0x2e67a3,_0x1d0cba);}}),_0x331b80;}function Pu(_0x34cd44,_0x4e3a63,_0xbb1835,_0x480310,_0x2d54a9,_0x2366f7,_0x5c37ff){if(Tn(_0x2d54a9,_0xbb1835)!=null)return _0x4e3a63;const _0x3eac68=_0x4e3a63['serverCache']['isFiltered'](),_0x4b8707=_0x4e3a63['serverCache'];if(_0x480310['value']!=null){if(v(_0xbb1835)&&_0x4b8707['isFullyInitialized']()||_0x4b8707['isCompleteForPath'](_0xbb1835))return Sn(_0x34cd44,_0x4e3a63,_0xbb1835,_0x4b8707['getNode']()['getChild'](_0xbb1835),_0x2d54a9,_0x2366f7,_0x3eac68,_0x5c37ff);if(v(_0xbb1835)){let _0x2e303c=new b(null);return _0x4b8707['getNode']()['forEachChild'](ve,(_0x6b3e59,_0x44eca3)=>{_0x2e303c=_0x2e303c['set'](new C(_0x6b3e59),_0x44eca3);}),Pi(_0x34cd44,_0x4e3a63,_0xbb1835,_0x2e303c,_0x2d54a9,_0x2366f7,_0x3eac68,_0x5c37ff);}else return _0x4e3a63;}else{let _0x429e24=new b(null);return _0x480310['foreach']((_0x1515ae,_0x23946d)=>{const _0x398114=k(_0xbb1835,_0x1515ae);_0x4b8707['isCompleteForPath'](_0x398114)&&(_0x429e24=_0x429e24['set'](_0x1515ae,_0x4b8707['getNode']()['getChild'](_0x398114)));}),Pi(_0x34cd44,_0x4e3a63,_0xbb1835,_0x429e24,_0x2d54a9,_0x2366f7,_0x3eac68,_0x5c37ff);}}function Nu(_0x313658,_0x23e796,_0x21574f,_0x552845,_0x1147cc){const _0x2aa063=_0x23e796['serverCache'],_0x15d0b1=Fo(_0x23e796,_0x2aa063['getNode'](),_0x2aa063['isFullyInitialized']()||v(_0x21574f),_0x2aa063['isFiltered']());return Go(_0x313658,_0x15d0b1,_0x21574f,_0x552845,$o,_0x1147cc);}function Ou(_0x4548a3,_0x5ae967,_0x2e3ebc,_0x3e73f3,_0x1d0b29,_0x4ade97){let _0x36e422;if(Tn(_0x3e73f3,_0x2e3ebc)!=null)return _0x5ae967;{const _0x2e4505=new rs(_0x3e73f3,_0x5ae967,_0x1d0b29),_0x2156f1=_0x5ae967['eventCache']['getNode']();let _0x4650e2;if(v(_0x2e3ebc)||y(_0x2e3ebc)==='.priority'){let _0x50cb0d;if(_0x5ae967['serverCache']['isFullyInitialized']())_0x50cb0d=Cn(_0x3e73f3,Ve(_0x5ae967));else{const _0xa99f6d=_0x5ae967['serverCache']['getNode']();f(_0xa99f6d instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x50cb0d=is(_0x3e73f3,_0xa99f6d);}_0x50cb0d=_0x50cb0d,_0x4650e2=_0x4548a3['filter']['updateFullNode'](_0x2156f1,_0x50cb0d,_0x4ade97);}else{const _0x4c83f1=y(_0x2e3ebc);let _0x4a318a=ss(_0x3e73f3,_0x4c83f1,_0x5ae967['serverCache']);_0x4a318a==null&&_0x5ae967['serverCache']['isCompleteForChild'](_0x4c83f1)&&(_0x4a318a=_0x2156f1['getImmediateChild'](_0x4c83f1)),_0x4a318a!=null?_0x4650e2=_0x4548a3['filter']['updateChild'](_0x2156f1,_0x4c83f1,_0x4a318a,S(_0x2e3ebc),_0x2e4505,_0x4ade97):_0x5ae967['eventCache']['getNode']()['hasChild'](_0x4c83f1)?_0x4650e2=_0x4548a3['filter']['updateChild'](_0x2156f1,_0x4c83f1,g['EMPTY_NODE'],S(_0x2e3ebc),_0x2e4505,_0x4ade97):_0x4650e2=_0x2156f1,_0x4650e2['isEmpty']()&&_0x5ae967['serverCache']['isFullyInitialized']()&&(_0x36e422=Cn(_0x3e73f3,Ve(_0x5ae967)),_0x36e422['isLeafNode']()&&(_0x4650e2=_0x4548a3['filter']['updateFullNode'](_0x4650e2,_0x36e422,_0x4ade97)));}return _0x36e422=_0x5ae967['serverCache']['isFullyInitialized']()||Tn(_0x3e73f3,w())!=null,Rt(_0x5ae967,_0x4650e2,_0x36e422,_0x4548a3['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x487e47,_0x590eb9){this['query_']=_0x487e47,this['eventRegistrations_']=[];const _0x186c0b=this['query_']['_queryParams'],_0x1f7b48=new Xi(_0x186c0b['getIndex']()),_0x25d9c0=Kh(_0x186c0b);this['processor_']=Su(_0x25d9c0);const _0x4aef5b=_0x590eb9['serverCache'],_0x9ca311=_0x590eb9['eventCache'],_0x33b9cb=_0x1f7b48['updateFullNode'](g['EMPTY_NODE'],_0x4aef5b['getNode'](),null),_0x42884f=_0x25d9c0['updateFullNode'](g['EMPTY_NODE'],_0x9ca311['getNode'](),null),_0x1da9cd=new Te(_0x33b9cb,_0x4aef5b['isFullyInitialized'](),_0x1f7b48['filtersNodes']()),_0x3a77bd=new Te(_0x42884f,_0x9ca311['isFullyInitialized'](),_0x25d9c0['filtersNodes']());this['viewCache_']=Un(_0x3a77bd,_0x1da9cd),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x3599a7){return _0x3599a7['viewCache_']['serverCache']['getNode']();}function Lu(_0x1796a6){return wn(_0x1796a6['viewCache_']);}function xu(_0x3bcb67,_0x5ccc4d){const _0x56d77a=Ve(_0x3bcb67['viewCache_']);return _0x56d77a&&(_0x3bcb67['query']['_queryParams']['loadsAllData']()||!v(_0x5ccc4d)&&!_0x56d77a['getImmediateChild'](y(_0x5ccc4d))['isEmpty']())?_0x56d77a['getChild'](_0x5ccc4d):null;}function ur(_0x53300c){return _0x53300c['eventRegistrations_']['length']===0x0;}function Fu(_0x11717d,_0x495fbd){_0x11717d['eventRegistrations_']['push'](_0x495fbd);}function dr(_0x54cd74,_0x24cccb,_0x311007){const _0x82c013=[];if(_0x311007){f(_0x24cccb==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x21fe24=_0x54cd74['query']['_path'];_0x54cd74['eventRegistrations_']['forEach'](_0xa0642d=>{const _0x3dacfb=_0xa0642d['createCancelEvent'](_0x311007,_0x21fe24);_0x3dacfb&&_0x82c013['push'](_0x3dacfb);});}if(_0x24cccb){let _0x46596e=[];for(let _0x479cb4=0x0;_0x479cb4<_0x54cd74['eventRegistrations_']['length'];++_0x479cb4){const _0x52d286=_0x54cd74['eventRegistrations_'][_0x479cb4];if(!_0x52d286['matches'](_0x24cccb))_0x46596e['push'](_0x52d286);else{if(_0x24cccb['hasAnyCallback']()){_0x46596e=_0x46596e['concat'](_0x54cd74['eventRegistrations_']['slice'](_0x479cb4+0x1));break;}}}_0x54cd74['eventRegistrations_']=_0x46596e;}else _0x54cd74['eventRegistrations_']=[];return _0x82c013;}function fr(_0x4993dc,_0x2f8c8e,_0x324721,_0x460036){_0x2f8c8e['type']===z['MERGE']&&_0x2f8c8e['source']['queryId']!==null&&(f(Ve(_0x4993dc['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x4993dc['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x30a718=_0x4993dc['viewCache_'],_0x2296f3=Ru(_0x4993dc['processor_'],_0x30a718,_0x2f8c8e,_0x324721,_0x460036);return bu(_0x4993dc['processor_'],_0x2296f3['viewCache']),f(_0x2296f3['viewCache']['serverCache']['isFullyInitialized']()||!_0x30a718['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4993dc['viewCache_']=_0x2296f3['viewCache'],qo(_0x4993dc,_0x2296f3['changes'],_0x2296f3['viewCache']['eventCache']['getNode'](),null);}function Uu(_0xe7c3ba,_0x89bd06){const _0x3c2f71=_0xe7c3ba['viewCache_']['eventCache'],_0x1cfe6b=[];return _0x3c2f71['getNode']()['isLeafNode']()||_0x3c2f71['getNode']()['forEachChild'](R,(_0x520d73,_0x29ee90)=>{_0x1cfe6b['push'](rt(_0x520d73,_0x29ee90));}),_0x3c2f71['isFullyInitialized']()&&_0x1cfe6b['push'](Lo(_0x3c2f71['getNode']())),qo(_0xe7c3ba,_0x1cfe6b,_0x3c2f71['getNode'](),_0x89bd06);}function qo(_0x25d1bb,_0x3dd9c1,_0xf68efd,_0x396342){const _0x176d07=_0x396342?[_0x396342]:_0x25d1bb['eventRegistrations_'];return ru(_0x25d1bb['eventGenerator_'],_0x3dd9c1,_0xf68efd,_0x176d07);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x4605d3){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x4605d3;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x1f51e4){return _0x1f51e4['views']['size']===0x0;}function os(_0x178b36,_0x9bc40b,_0x16c9e6,_0x106b96){const _0xc639c2=_0x9bc40b['source']['queryId'];if(_0xc639c2!==null){const _0x2ea41d=_0x178b36['views']['get'](_0xc639c2);return f(_0x2ea41d!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x2ea41d,_0x9bc40b,_0x16c9e6,_0x106b96);}else{let _0x2e4186=[];for(const _0x15bed0 of _0x178b36['views']['values']())_0x2e4186=_0x2e4186['concat'](fr(_0x15bed0,_0x9bc40b,_0x16c9e6,_0x106b96));return _0x2e4186;}}function jo(_0x3d523b,_0x698ae,_0xe96e98,_0x171b06,_0x236b21){const _0x2b59c2=_0x698ae['_queryIdentifier'],_0x25c0a1=_0x3d523b['views']['get'](_0x2b59c2);if(!_0x25c0a1){let _0x5a9530=Cn(_0xe96e98,_0x236b21?_0x171b06:null),_0x467e8f=!0x1;_0x5a9530?_0x467e8f=!0x0:_0x171b06 instanceof g?(_0x5a9530=is(_0xe96e98,_0x171b06),_0x467e8f=!0x1):(_0x5a9530=g['EMPTY_NODE'],_0x467e8f=!0x1);const _0x28acb6=Un(new Te(_0x5a9530,_0x467e8f,!0x1),new Te(_0x171b06,_0x236b21,!0x1));return new Du(_0x698ae,_0x28acb6);}return _0x25c0a1;}function Hu(_0x4840c6,_0x404ebd,_0x52c35f,_0x31389b,_0x52180d,_0x4d4752){const _0x50eeca=jo(_0x4840c6,_0x404ebd,_0x31389b,_0x52180d,_0x4d4752);return _0x4840c6['views']['has'](_0x404ebd['_queryIdentifier'])||_0x4840c6['views']['set'](_0x404ebd['_queryIdentifier'],_0x50eeca),Fu(_0x50eeca,_0x52c35f),Uu(_0x50eeca,_0x52c35f);}function $u(_0x37cd35,_0x4102ce,_0xe8b57e,_0xfa06fa){const _0x116dd1=_0x4102ce['_queryIdentifier'],_0x4d4ad9=[];let _0x479930=[];const _0x3d1d90=Se(_0x37cd35);if(_0x116dd1==='default'){for(const [_0x4dcc3d,_0x33bbd4]of _0x37cd35['views']['entries']())_0x479930=_0x479930['concat'](dr(_0x33bbd4,_0xe8b57e,_0xfa06fa)),ur(_0x33bbd4)&&(_0x37cd35['views']['delete'](_0x4dcc3d),_0x33bbd4['query']['_queryParams']['loadsAllData']()||_0x4d4ad9['push'](_0x33bbd4['query']));}else{const _0x38c9a7=_0x37cd35['views']['get'](_0x116dd1);_0x38c9a7&&(_0x479930=_0x479930['concat'](dr(_0x38c9a7,_0xe8b57e,_0xfa06fa)),ur(_0x38c9a7)&&(_0x37cd35['views']['delete'](_0x116dd1),_0x38c9a7['query']['_queryParams']['loadsAllData']()||_0x4d4ad9['push'](_0x38c9a7['query'])));}return _0x3d1d90&&!Se(_0x37cd35)&&_0x4d4ad9['push'](new(Bu())(_0x4102ce['_repo'],_0x4102ce['_path'])),{'removed':_0x4d4ad9,'events':_0x479930};}function Ko(_0x38aca4){const _0x22573e=[];for(const _0x51f23c of _0x38aca4['views']['values']())_0x51f23c['query']['_queryParams']['loadsAllData']()||_0x22573e['push'](_0x51f23c);return _0x22573e;}function Ie(_0x212c1f,_0x7cec7){let _0x4b712e=null;for(const _0x24ca28 of _0x212c1f['views']['values']())_0x4b712e=_0x4b712e||xu(_0x24ca28,_0x7cec7);return _0x4b712e;}function Yo(_0x179282,_0x23fb9a){if(_0x23fb9a['_queryParams']['loadsAllData']())return Bn(_0x179282);{const _0x46b20a=_0x23fb9a['_queryIdentifier'];return _0x179282['views']['get'](_0x46b20a);}}function Qo(_0x38a9f3,_0x248867){return Yo(_0x38a9f3,_0x248867)!=null;}function Se(_0x49c432){return Bn(_0x49c432)!=null;}function Bn(_0x2f5032){for(const _0x5d1370 of _0x2f5032['views']['values']())if(_0x5d1370['query']['_queryParams']['loadsAllData']())return _0x5d1370;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x505036){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x505036;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x96842){this['listenProvider_']=_0x96842,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x45a736,_0x32bd0c,_0x950526,_0x55c19b,_0x4adc31){return lu(_0x45a736['pendingWriteTree_'],_0x32bd0c,_0x950526,_0x55c19b,_0x4adc31),_0x4adc31?_t(_0x45a736,new Be(es(),_0x32bd0c,_0x950526)):[];}function ju(_0x14ca12,_0x57c939,_0xdfa2b,_0x1a202d){hu(_0x14ca12['pendingWriteTree_'],_0x57c939,_0xdfa2b,_0x1a202d);const _0x437c70=b['fromObject'](_0xdfa2b);return _t(_0x14ca12,new ot(es(),_0x57c939,_0x437c70));}function _e(_0x90efb6,_0x3981ab,_0x22984b=!0x1){const _0x4a8860=uu(_0x90efb6['pendingWriteTree_'],_0x3981ab);if(du(_0x90efb6['pendingWriteTree_'],_0x3981ab)){let _0x671c95=new b(null);return _0x4a8860['snap']!=null?_0x671c95=_0x671c95['set'](w(),!0x0):x(_0x4a8860['children'],_0x466ad8=>{_0x671c95=_0x671c95['set'](new C(_0x466ad8),!0x0);}),_t(_0x90efb6,new In(_0x4a8860['path'],_0x671c95,_0x22984b));}else return[];}function Yt(_0x9c63f,_0x7e2472,_0x288b61){return _t(_0x9c63f,new Be(ts(),_0x7e2472,_0x288b61));}function Ku(_0x405bde,_0x49ed18,_0x3d1372){const _0x2bce9b=b['fromObject'](_0x3d1372);return _t(_0x405bde,new ot(ts(),_0x49ed18,_0x2bce9b));}function Yu(_0x41be3c,_0x145b0a){return _t(_0x41be3c,new Ut(ts(),_0x145b0a));}function Qu(_0x5b7cb4,_0x3771d3,_0x49ae52){const _0x26c440=cs(_0x5b7cb4,_0x49ae52);if(_0x26c440){const _0x254a16=ls(_0x26c440),_0x544c27=_0x254a16['path'],_0x364e0d=_0x254a16['queryId'],_0x1c1400=F(_0x544c27,_0x3771d3),_0x416839=new Ut(ns(_0x364e0d),_0x1c1400);return hs(_0x5b7cb4,_0x544c27,_0x416839);}else return[];}function An(_0x3fa2e2,_0x470f4e,_0x34a616,_0x19a056,_0x13c9bd=!0x1){const _0x280a73=_0x470f4e['_path'],_0x18b7b7=_0x3fa2e2['syncPointTree_']['get'](_0x280a73);let _0x4eeb27=[];if(_0x18b7b7&&(_0x470f4e['_queryIdentifier']==='default'||Qo(_0x18b7b7,_0x470f4e))){const _0x540381=$u(_0x18b7b7,_0x470f4e,_0x34a616,_0x19a056);Vu(_0x18b7b7)&&(_0x3fa2e2['syncPointTree_']=_0x3fa2e2['syncPointTree_']['remove'](_0x280a73));const _0x1547c6=_0x540381['removed'];if(_0x4eeb27=_0x540381['events'],!_0x13c9bd){const _0x6b9165=_0x1547c6['findIndex'](_0x40a436=>_0x40a436['_queryParams']['loadsAllData']())!==-0x1,_0x47c787=_0x3fa2e2['syncPointTree_']['findOnPath'](_0x280a73,(_0x4d95f5,_0x45accb)=>Se(_0x45accb));if(_0x6b9165&&!_0x47c787){const _0x2dd67d=_0x3fa2e2['syncPointTree_']['subtree'](_0x280a73);if(!_0x2dd67d['isEmpty']()){const _0x1c4c80=Zu(_0x2dd67d);for(let _0x23dfc6=0x0;_0x23dfc6<_0x1c4c80['length'];++_0x23dfc6){const _0x1a75ec=_0x1c4c80[_0x23dfc6],_0x8cf8be=_0x1a75ec['query'],_0x4d9172=ea(_0x3fa2e2,_0x1a75ec);_0x3fa2e2['listenProvider_']['startListening'](kt(_0x8cf8be),Wt(_0x3fa2e2,_0x8cf8be),_0x4d9172['hashFn'],_0x4d9172['onComplete']);}}}!_0x47c787&&_0x1547c6['length']>0x0&&!_0x19a056&&(_0x6b9165?_0x3fa2e2['listenProvider_']['stopListening'](kt(_0x470f4e),null):_0x1547c6['forEach'](_0x8cc47d=>{const _0x38ce46=_0x3fa2e2['queryToTagMap']['get'](Hn(_0x8cc47d));_0x3fa2e2['listenProvider_']['stopListening'](kt(_0x8cc47d),_0x38ce46);}));}ed(_0x3fa2e2,_0x1547c6);}return _0x4eeb27;}function Jo(_0x525693,_0x4501fd,_0x55a7d5,_0x29dca6){const _0x572a06=cs(_0x525693,_0x29dca6);if(_0x572a06!=null){const _0x44a556=ls(_0x572a06),_0x30fd50=_0x44a556['path'],_0x2408ab=_0x44a556['queryId'],_0x5277a4=F(_0x30fd50,_0x4501fd),_0x1af0cf=new Be(ns(_0x2408ab),_0x5277a4,_0x55a7d5);return hs(_0x525693,_0x30fd50,_0x1af0cf);}else return[];}function Ju(_0x59df8c,_0xcba196,_0x2d4912,_0x3f03bf){const _0x1718a7=cs(_0x59df8c,_0x3f03bf);if(_0x1718a7){const _0x1f3d83=ls(_0x1718a7),_0x57bcad=_0x1f3d83['path'],_0x4491ba=_0x1f3d83['queryId'],_0x605d7d=F(_0x57bcad,_0xcba196),_0x5f2fda=b['fromObject'](_0x2d4912),_0x1e5828=new ot(ns(_0x4491ba),_0x605d7d,_0x5f2fda);return hs(_0x59df8c,_0x57bcad,_0x1e5828);}else return[];}function Ni(_0x20f3c5,_0x10a24c,_0x19b7f0,_0x224000=!0x1){const _0x22b4e2=_0x10a24c['_path'];let _0x4a911c=null,_0xac1c7a=!0x1;_0x20f3c5['syncPointTree_']['foreachOnPath'](_0x22b4e2,(_0x1208f9,_0xb3d8c8)=>{const _0x13c02e=F(_0x1208f9,_0x22b4e2);_0x4a911c=_0x4a911c||Ie(_0xb3d8c8,_0x13c02e),_0xac1c7a=_0xac1c7a||Se(_0xb3d8c8);});let _0x1ce154=_0x20f3c5['syncPointTree_']['get'](_0x22b4e2);_0x1ce154?(_0xac1c7a=_0xac1c7a||Se(_0x1ce154),_0x4a911c=_0x4a911c||Ie(_0x1ce154,w())):(_0x1ce154=new zo(),_0x20f3c5['syncPointTree_']=_0x20f3c5['syncPointTree_']['set'](_0x22b4e2,_0x1ce154));let _0x48391b;_0x4a911c!=null?_0x48391b=!0x0:(_0x48391b=!0x1,_0x4a911c=g['EMPTY_NODE'],_0x20f3c5['syncPointTree_']['subtree'](_0x22b4e2)['foreachChild']((_0x5a3b0a,_0x521f1a)=>{const _0x5cb65a=Ie(_0x521f1a,w());_0x5cb65a&&(_0x4a911c=_0x4a911c['updateImmediateChild'](_0x5a3b0a,_0x5cb65a));}));const _0x21c474=Qo(_0x1ce154,_0x10a24c);if(!_0x21c474&&!_0x10a24c['_queryParams']['loadsAllData']()){const _0xd21d0f=Hn(_0x10a24c);f(!_0x20f3c5['queryToTagMap']['has'](_0xd21d0f),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x12c6c2=td();_0x20f3c5['queryToTagMap']['set'](_0xd21d0f,_0x12c6c2),_0x20f3c5['tagToQueryMap']['set'](_0x12c6c2,_0xd21d0f);}const _0x25ced0=Wn(_0x20f3c5['pendingWriteTree_'],_0x22b4e2);let _0x49e606=Hu(_0x1ce154,_0x10a24c,_0x19b7f0,_0x25ced0,_0x4a911c,_0x48391b);if(!_0x21c474&&!_0xac1c7a&&!_0x224000){const _0x4dd5a9=Yo(_0x1ce154,_0x10a24c);_0x49e606=_0x49e606['concat'](nd(_0x20f3c5,_0x10a24c,_0x4dd5a9));}return _0x49e606;}function Vn(_0x2fd6b3,_0x2ee1ee,_0x590643){const _0x28adaf=_0x2fd6b3['pendingWriteTree_'],_0x15be81=_0x2fd6b3['syncPointTree_']['findOnPath'](_0x2ee1ee,(_0x1b40a0,_0xe812c)=>{const _0x3c22f2=F(_0x1b40a0,_0x2ee1ee),_0x16452a=Ie(_0xe812c,_0x3c22f2);if(_0x16452a)return _0x16452a;});return Bo(_0x28adaf,_0x2ee1ee,_0x15be81,_0x590643,!0x0);}function Xu(_0x2161cf,_0x58cb96){const _0x112473=_0x58cb96['_path'];let _0x109f0a=null;_0x2161cf['syncPointTree_']['foreachOnPath'](_0x112473,(_0x2b823d,_0x4a42d2)=>{const _0x1c1c74=F(_0x2b823d,_0x112473);_0x109f0a=_0x109f0a||Ie(_0x4a42d2,_0x1c1c74);});let _0x1cdd55=_0x2161cf['syncPointTree_']['get'](_0x112473);_0x1cdd55?_0x109f0a=_0x109f0a||Ie(_0x1cdd55,w()):(_0x1cdd55=new zo(),_0x2161cf['syncPointTree_']=_0x2161cf['syncPointTree_']['set'](_0x112473,_0x1cdd55));const _0x42fce1=_0x109f0a!=null,_0x381fca=_0x42fce1?new Te(_0x109f0a,!0x0,!0x1):null,_0x50ba21=Wn(_0x2161cf['pendingWriteTree_'],_0x58cb96['_path']),_0x3fad78=jo(_0x1cdd55,_0x58cb96,_0x50ba21,_0x42fce1?_0x381fca['getNode']():g['EMPTY_NODE'],_0x42fce1);return Lu(_0x3fad78);}function _t(_0x568a98,_0xb26ad7){return Xo(_0xb26ad7,_0x568a98['syncPointTree_'],null,Wn(_0x568a98['pendingWriteTree_'],w()));}function Xo(_0x12f6d2,_0x5588ae,_0x3c7cab,_0x3d794b){if(v(_0x12f6d2['path']))return Zo(_0x12f6d2,_0x5588ae,_0x3c7cab,_0x3d794b);{const _0x1ae885=_0x5588ae['get'](w());_0x3c7cab==null&&_0x1ae885!=null&&(_0x3c7cab=Ie(_0x1ae885,w()));let _0x52e8cd=[];const _0x408096=y(_0x12f6d2['path']),_0x4f7a18=_0x12f6d2['operationForChild'](_0x408096),_0x4b1991=_0x5588ae['children']['get'](_0x408096);if(_0x4b1991&&_0x4f7a18){const _0x1147fb=_0x3c7cab?_0x3c7cab['getImmediateChild'](_0x408096):null,_0x3c40bd=Vo(_0x3d794b,_0x408096);_0x52e8cd=_0x52e8cd['concat'](Xo(_0x4f7a18,_0x4b1991,_0x1147fb,_0x3c40bd));}return _0x1ae885&&(_0x52e8cd=_0x52e8cd['concat'](os(_0x1ae885,_0x12f6d2,_0x3d794b,_0x3c7cab))),_0x52e8cd;}}function Zo(_0x25624f,_0x451b08,_0x19bd3c,_0x4f9754){const _0x425693=_0x451b08['get'](w());_0x19bd3c==null&&_0x425693!=null&&(_0x19bd3c=Ie(_0x425693,w()));let _0x160924=[];return _0x451b08['children']['inorderTraversal']((_0x3c72b9,_0x314584)=>{const _0x2d6fa1=_0x19bd3c?_0x19bd3c['getImmediateChild'](_0x3c72b9):null,_0x5a3632=Vo(_0x4f9754,_0x3c72b9),_0x32b18a=_0x25624f['operationForChild'](_0x3c72b9);_0x32b18a&&(_0x160924=_0x160924['concat'](Zo(_0x32b18a,_0x314584,_0x2d6fa1,_0x5a3632)));}),_0x425693&&(_0x160924=_0x160924['concat'](os(_0x425693,_0x25624f,_0x4f9754,_0x19bd3c))),_0x160924;}function ea(_0x3e8d8e,_0x59e064){const _0xeb2f45=_0x59e064['query'],_0x4ecc9f=Wt(_0x3e8d8e,_0xeb2f45);return{'hashFn':()=>(Mu(_0x59e064)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x484439=>{if(_0x484439==='ok')return _0x4ecc9f?Qu(_0x3e8d8e,_0xeb2f45['_path'],_0x4ecc9f):Yu(_0x3e8d8e,_0xeb2f45['_path']);{const _0x3303d5=Kl(_0x484439,_0xeb2f45);return An(_0x3e8d8e,_0xeb2f45,null,_0x3303d5);}}};}function Wt(_0x224352,_0x3e32c1){const _0x3b4865=Hn(_0x3e32c1);return _0x224352['queryToTagMap']['get'](_0x3b4865);}function Hn(_0x1dd791){return _0x1dd791['_path']['toString']()+'$'+_0x1dd791['_queryIdentifier'];}function cs(_0x1dadcf,_0x1f7122){return _0x1dadcf['tagToQueryMap']['get'](_0x1f7122);}function ls(_0x3fdeac){const _0x1af3c7=_0x3fdeac['indexOf']('$');return f(_0x1af3c7!==-0x1&&_0x1af3c7<_0x3fdeac['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3fdeac['substr'](_0x1af3c7+0x1),'path':new C(_0x3fdeac['substr'](0x0,_0x1af3c7))};}function hs(_0x4e71c7,_0x5f44f8,_0x4fbfae){const _0xaac20e=_0x4e71c7['syncPointTree_']['get'](_0x5f44f8);f(_0xaac20e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x49da0a=Wn(_0x4e71c7['pendingWriteTree_'],_0x5f44f8);return os(_0xaac20e,_0x4fbfae,_0x49da0a,null);}function Zu(_0x1cff4e){return _0x1cff4e['fold']((_0x4bed4c,_0x248aed,_0x34351f)=>{if(_0x248aed&&Se(_0x248aed))return[Bn(_0x248aed)];{let _0x4cb3e7=[];return _0x248aed&&(_0x4cb3e7=Ko(_0x248aed)),x(_0x34351f,(_0x1d43b8,_0x1832b0)=>{_0x4cb3e7=_0x4cb3e7['concat'](_0x1832b0);}),_0x4cb3e7;}});}function kt(_0x5c818a){return _0x5c818a['_queryParams']['loadsAllData']()&&!_0x5c818a['_queryParams']['isDefault']()?new(qu())(_0x5c818a['_repo'],_0x5c818a['_path']):_0x5c818a;}function ed(_0x3cd259,_0x14c462){for(let _0xf3b577=0x0;_0xf3b577<_0x14c462['length'];++_0xf3b577){const _0x2b1104=_0x14c462[_0xf3b577];if(!_0x2b1104['_queryParams']['loadsAllData']()){const _0x2b4c13=Hn(_0x2b1104),_0x4c9e75=_0x3cd259['queryToTagMap']['get'](_0x2b4c13);_0x3cd259['queryToTagMap']['delete'](_0x2b4c13),_0x3cd259['tagToQueryMap']['delete'](_0x4c9e75);}}}function td(){return zu++;}function nd(_0x138c1a,_0x3c334b,_0x12d7e5){const _0x3bc4e0=_0x3c334b['_path'],_0x1caaae=Wt(_0x138c1a,_0x3c334b),_0x5f4212=ea(_0x138c1a,_0x12d7e5),_0x15b74a=_0x138c1a['listenProvider_']['startListening'](kt(_0x3c334b),_0x1caaae,_0x5f4212['hashFn'],_0x5f4212['onComplete']),_0x38f291=_0x138c1a['syncPointTree_']['subtree'](_0x3bc4e0);if(_0x1caaae)f(!Se(_0x38f291['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3d2251=_0x38f291['fold']((_0x41d171,_0x159bd4,_0x57376b)=>{if(!v(_0x41d171)&&_0x159bd4&&Se(_0x159bd4))return[Bn(_0x159bd4)['query']];{let _0x7368f7=[];return _0x159bd4&&(_0x7368f7=_0x7368f7['concat'](Ko(_0x159bd4)['map'](_0x2fc0a7=>_0x2fc0a7['query']))),x(_0x57376b,(_0x3be77e,_0x46e7ce)=>{_0x7368f7=_0x7368f7['concat'](_0x46e7ce);}),_0x7368f7;}});for(let _0x1d1743=0x0;_0x1d1743<_0x3d2251['length'];++_0x1d1743){const _0x546dc3=_0x3d2251[_0x1d1743];_0x138c1a['listenProvider_']['stopListening'](kt(_0x546dc3),Wt(_0x138c1a,_0x546dc3));}}return _0x15b74a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x1f12fe){this['node_']=_0x1f12fe;}['getImmediateChild'](_0x4e6586){const _0x536807=this['node_']['getImmediateChild'](_0x4e6586);return new us(_0x536807);}['node'](){return this['node_'];}}class ds{constructor(_0x33868b,_0x4b56bd){this['syncTree_']=_0x33868b,this['path_']=_0x4b56bd;}['getImmediateChild'](_0x43f23d){const _0x16196a=k(this['path_'],_0x43f23d);return new ds(this['syncTree_'],_0x16196a);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x5e1e85){return _0x5e1e85=_0x5e1e85||{},_0x5e1e85['timestamp']=_0x5e1e85['timestamp']||new Date()['getTime'](),_0x5e1e85;},_r=function(_0x17e446,_0x578437,_0x5cb624){if(!_0x17e446||typeof _0x17e446!='object')return _0x17e446;if(f('.sv'in _0x17e446,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x17e446['.sv']=='string')return sd(_0x17e446['.sv'],_0x578437,_0x5cb624);if(typeof _0x17e446['.sv']=='object')return rd(_0x17e446['.sv'],_0x578437);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x17e446,null,0x2));},sd=function(_0x46b5d3,_0x32d946,_0x9bbaa0){switch(_0x46b5d3){case'timestamp':return _0x9bbaa0['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x46b5d3);}},rd=function(_0x401285,_0x5e2a8d,_0x125a6c){_0x401285['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x401285,null,0x2));const _0x486ac9=_0x401285['increment'];typeof _0x486ac9!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x486ac9);const _0x391b98=_0x5e2a8d['node']();if(f(_0x391b98!==null&&typeof _0x391b98<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x391b98['isLeafNode']())return _0x486ac9;const _0x22acd6=_0x391b98['getValue']();return typeof _0x22acd6!='number'?_0x486ac9:_0x22acd6+_0x486ac9;},ta=function(_0x51b32f,_0x9b31bc,_0x422e49,_0x1ccf62){return ps(_0x9b31bc,new ds(_0x422e49,_0x51b32f),_0x1ccf62);},fs=function(_0x17102e,_0x896807,_0x3abc0f){return ps(_0x17102e,new us(_0x896807),_0x3abc0f);};function ps(_0x1000ca,_0x1bfa7e,_0x5026e1){const _0x4d7260=_0x1000ca['getPriority']()['val'](),_0x162f10=_r(_0x4d7260,_0x1bfa7e['getImmediateChild']('.priority'),_0x5026e1);let _0x391a85;if(_0x1000ca['isLeafNode']()){const _0x24e32d=_0x1000ca,_0x60d4c3=_r(_0x24e32d['getValue'](),_0x1bfa7e,_0x5026e1);return _0x60d4c3!==_0x24e32d['getValue']()||_0x162f10!==_0x24e32d['getPriority']()['val']()?new D(_0x60d4c3,A(_0x162f10)):_0x1000ca;}else{const _0x252ab0=_0x1000ca;return _0x391a85=_0x252ab0,_0x162f10!==_0x252ab0['getPriority']()['val']()&&(_0x391a85=_0x391a85['updatePriority'](new D(_0x162f10))),_0x252ab0['forEachChild'](R,(_0x589af5,_0x10a64f)=>{const _0x37ff73=ps(_0x10a64f,_0x1bfa7e['getImmediateChild'](_0x589af5),_0x5026e1);_0x37ff73!==_0x10a64f&&(_0x391a85=_0x391a85['updateImmediateChild'](_0x589af5,_0x37ff73));}),_0x391a85;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x3d412a='',_0x104048=null,_0x3fbe7e={'children':{},'childCount':0x0}){this['name']=_0x3d412a,this['parent']=_0x104048,this['node']=_0x3fbe7e;}}function $n(_0x2c0640,_0x55b2aa){let _0xb5d10=_0x55b2aa instanceof C?_0x55b2aa:new C(_0x55b2aa),_0x5e4143=_0x2c0640,_0x44bed6=y(_0xb5d10);for(;_0x44bed6!==null;){const _0x4d27ab=Le(_0x5e4143['node']['children'],_0x44bed6)||{'children':{},'childCount':0x0};_0x5e4143=new _s(_0x44bed6,_0x5e4143,_0x4d27ab),_0xb5d10=S(_0xb5d10),_0x44bed6=y(_0xb5d10);}return _0x5e4143;}function je(_0x2bece0){return _0x2bece0['node']['value'];}function gs(_0x5f4d3a,_0x14de30){_0x5f4d3a['node']['value']=_0x14de30,Oi(_0x5f4d3a);}function na(_0x347ecc){return _0x347ecc['node']['childCount']>0x0;}function od(_0x3faeb0){return je(_0x3faeb0)===void 0x0&&!na(_0x3faeb0);}function Gn(_0x175160,_0x13fbcd){x(_0x175160['node']['children'],(_0x48243d,_0x487326)=>{_0x13fbcd(new _s(_0x48243d,_0x175160,_0x487326));});}function ia(_0x35b2b1,_0x4de61a,_0x578ac7,_0x3f39cb){_0x578ac7&&_0x4de61a(_0x35b2b1),Gn(_0x35b2b1,_0x19c1dd=>{ia(_0x19c1dd,_0x4de61a,!0x0);});}function ad(_0x44c78e,_0x2cbbab,_0x17d2e1){let _0x129271=_0x44c78e['parent'];for(;_0x129271!==null;){if(_0x2cbbab(_0x129271))return!0x0;_0x129271=_0x129271['parent'];}return!0x1;}function Qt(_0x39b5a8){return new C(_0x39b5a8['parent']===null?_0x39b5a8['name']:Qt(_0x39b5a8['parent'])+'/'+_0x39b5a8['name']);}function Oi(_0x5cc2a6){_0x5cc2a6['parent']!==null&&cd(_0x5cc2a6['parent'],_0x5cc2a6['name'],_0x5cc2a6);}function cd(_0xd8d955,_0x137d9a,_0x40e2a2){const _0x2501ed=od(_0x40e2a2),_0x35f917=Q(_0xd8d955['node']['children'],_0x137d9a);_0x2501ed&&_0x35f917?(delete _0xd8d955['node']['children'][_0x137d9a],_0xd8d955['node']['childCount']--,Oi(_0xd8d955)):!_0x2501ed&&!_0x35f917&&(_0xd8d955['node']['children'][_0x137d9a]=_0x40e2a2['node'],_0xd8d955['node']['childCount']++,Oi(_0xd8d955));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x2b6279){return typeof _0x2b6279=='string'&&_0x2b6279['length']!==0x0&&!ld['test'](_0x2b6279);},sa=function(_0x40a9b0){return typeof _0x40a9b0=='string'&&_0x40a9b0['length']!==0x0&&!hd['test'](_0x40a9b0);},ud=function(_0x58931e){return _0x58931e&&(_0x58931e=_0x58931e['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x58931e);},Bt=function(_0x540d75){return _0x540d75===null||typeof _0x540d75=='string'||typeof _0x540d75=='number'&&!xn(_0x540d75)||_0x540d75&&typeof _0x540d75=='object'&&Q(_0x540d75,'.sv');},He=function(_0x52b66c,_0x4bb810,_0x3d3771,_0x257a43){_0x257a43&&_0x4bb810===void 0x0||Jt(it(_0x52b66c,'value'),_0x4bb810,_0x3d3771);},Jt=function(_0x2c9c88,_0x1d8a8d,_0x251882){const _0x779e39=_0x251882 instanceof C?new Ah(_0x251882,_0x2c9c88):_0x251882;if(_0x1d8a8d===void 0x0)throw new Error(_0x2c9c88+'contains\x20undefined\x20'+Oe(_0x779e39));if(typeof _0x1d8a8d=='function')throw new Error(_0x2c9c88+'contains\x20a\x20function\x20'+Oe(_0x779e39)+'\x20with\x20contents\x20=\x20'+_0x1d8a8d['toString']());if(xn(_0x1d8a8d))throw new Error(_0x2c9c88+'contains\x20'+_0x1d8a8d['toString']()+'\x20'+Oe(_0x779e39));if(typeof _0x1d8a8d=='string'&&_0x1d8a8d['length']>ui/0x3&&Ln(_0x1d8a8d)>ui)throw new Error(_0x2c9c88+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x779e39)+'\x20(\x27'+_0x1d8a8d['substring'](0x0,0x32)+'...\x27)');if(_0x1d8a8d&&typeof _0x1d8a8d=='object'){let _0x4e0832=!0x1,_0x4befc0=!0x1;if(x(_0x1d8a8d,(_0x3c702b,_0x170a84)=>{if(_0x3c702b==='.value')_0x4e0832=!0x0;else{if(_0x3c702b!=='.priority'&&_0x3c702b!=='.sv'&&(_0x4befc0=!0x0,!ms(_0x3c702b)))throw new Error(_0x2c9c88+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3c702b+')\x20'+Oe(_0x779e39)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x779e39,_0x3c702b),Jt(_0x2c9c88,_0x170a84,_0x779e39),Ph(_0x779e39);}),_0x4e0832&&_0x4befc0)throw new Error(_0x2c9c88+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x779e39)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x5f270d,_0x4086a2){let _0x3ab3d5,_0x3c1208;for(_0x3ab3d5=0x0;_0x3ab3d5<_0x4086a2['length'];_0x3ab3d5++){_0x3c1208=_0x4086a2[_0x3ab3d5];const _0xbbd30f=Mt(_0x3c1208);for(let _0x4cf6ef=0x0;_0x4cf6ef<_0xbbd30f['length'];_0x4cf6ef++)if(!(_0xbbd30f[_0x4cf6ef]==='.priority'&&_0x4cf6ef===_0xbbd30f['length']-0x1)){if(!ms(_0xbbd30f[_0x4cf6ef]))throw new Error(_0x5f270d+'contains\x20an\x20invalid\x20key\x20('+_0xbbd30f[_0x4cf6ef]+')\x20in\x20path\x20'+_0x3c1208['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4086a2['sort'](Rh);let _0x174bb1=null;for(_0x3ab3d5=0x0;_0x3ab3d5<_0x4086a2['length'];_0x3ab3d5++){if(_0x3c1208=_0x4086a2[_0x3ab3d5],_0x174bb1!==null&&G(_0x174bb1,_0x3c1208))throw new Error(_0x5f270d+'contains\x20a\x20path\x20'+_0x174bb1['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3c1208['toString']());_0x174bb1=_0x3c1208;}},ra=function(_0xc5b7b3,_0x43c3de,_0x398cad,_0x3d4fdc){const _0xe04e24=it(_0xc5b7b3,'values');if(!(_0x43c3de&&typeof _0x43c3de=='object')||Array['isArray'](_0x43c3de))throw new Error(_0xe04e24+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4030c3=[];x(_0x43c3de,(_0x234539,_0x11ea66)=>{const _0x1e6842=new C(_0x234539);if(Jt(_0xe04e24,_0x11ea66,k(_0x398cad,_0x1e6842)),ji(_0x1e6842)==='.priority'&&!Bt(_0x11ea66))throw new Error(_0xe04e24+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x1e6842['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4030c3['push'](_0x1e6842);}),dd(_0xe04e24,_0x4030c3);},fd=function(_0x4e679c,_0x1ecd72,_0x56a63d){if(xn(_0x1ecd72))throw new Error(it(_0x4e679c,'priority')+'is\x20'+_0x1ecd72['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x1ecd72))throw new Error(it(_0x4e679c,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x51ea01,_0x24a2bc,_0x232efb,_0x6e298){if(!sa(_0x232efb))throw new Error(it(_0x51ea01,_0x24a2bc)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x232efb+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x1c5e9d,_0x56966c,_0x1ad503,_0x12b982){_0x1ad503&&(_0x1ad503=_0x1ad503['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x1c5e9d,_0x56966c,_0x1ad503);},Me=function(_0x1c130d,_0x52b34d){if(y(_0x52b34d)==='.info')throw new Error(_0x1c130d+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x194ea8,_0x260a53){const _0x284b01=_0x260a53['path']['toString']();if(typeof _0x260a53['repoInfo']['host']!='string'||_0x260a53['repoInfo']['host']['length']===0x0||!ms(_0x260a53['repoInfo']['namespace'])&&_0x260a53['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x284b01['length']!==0x0&&!ud(_0x284b01))throw new Error(it(_0x194ea8,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x3a6a83,_0x4e08f1){let _0x4609d7=null;for(let _0x2504a9=0x0;_0x2504a9<_0x4e08f1['length'];_0x2504a9++){const _0x3ab4f4=_0x4e08f1[_0x2504a9],_0x48cc2c=_0x3ab4f4['getPath']();_0x4609d7!==null&&!Ki(_0x48cc2c,_0x4609d7['path'])&&(_0x3a6a83['eventLists_']['push'](_0x4609d7),_0x4609d7=null),_0x4609d7===null&&(_0x4609d7={'events':[],'path':_0x48cc2c}),_0x4609d7['events']['push'](_0x3ab4f4);}_0x4609d7&&_0x3a6a83['eventLists_']['push'](_0x4609d7);}function oa(_0x51ec92,_0xae4dd4,_0x63196a){qn(_0x51ec92,_0x63196a),aa(_0x51ec92,_0x489287=>Ki(_0x489287,_0xae4dd4));}function V(_0x4716d7,_0x537e21,_0x210acd){qn(_0x4716d7,_0x210acd),aa(_0x4716d7,_0x574c52=>G(_0x574c52,_0x537e21)||G(_0x537e21,_0x574c52));}function aa(_0x5d5e3a,_0x362507){_0x5d5e3a['recursionDepth_']++;let _0x1cf545=!0x0;for(let _0x346378=0x0;_0x346378<_0x5d5e3a['eventLists_']['length'];_0x346378++){const _0x11575=_0x5d5e3a['eventLists_'][_0x346378];if(_0x11575){const _0x3f7917=_0x11575['path'];_0x362507(_0x3f7917)?(md(_0x5d5e3a['eventLists_'][_0x346378]),_0x5d5e3a['eventLists_'][_0x346378]=null):_0x1cf545=!0x1;}}_0x1cf545&&(_0x5d5e3a['eventLists_']=[]),_0x5d5e3a['recursionDepth_']--;}function md(_0x3c8052){for(let _0x391056=0x0;_0x391056<_0x3c8052['events']['length'];_0x391056++){const _0x5e0dfe=_0x3c8052['events'][_0x391056];if(_0x5e0dfe!==null){_0x3c8052['events'][_0x391056]=null;const _0x3d2685=_0x5e0dfe['getEventRunner']();St&&L('event:\x20'+_0x5e0dfe['toString']()),ft(_0x3d2685);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x534599,_0x3ede91,_0xc07bd4,_0x3e8d97){this['repoInfo_']=_0x534599,this['forceRestClient_']=_0x3ede91,this['authTokenProvider_']=_0xc07bd4,this['appCheckProvider_']=_0x3e8d97,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x23c182,_0x30277c,_0x4e7a45){if(_0x23c182['stats_']=qi(_0x23c182['repoInfo_']),_0x23c182['forceRestClient_']||Xl())_0x23c182['server_']=new vn(_0x23c182['repoInfo_'],(_0x1783d8,_0x4fe0e1,_0x59ec9e,_0x8a1ad7)=>{gr(_0x23c182,_0x1783d8,_0x4fe0e1,_0x59ec9e,_0x8a1ad7);},_0x23c182['authTokenProvider_'],_0x23c182['appCheckProvider_']),setTimeout(()=>mr(_0x23c182,!0x0),0x0);else{if(typeof _0x4e7a45<'u'&&_0x4e7a45!==null){if(typeof _0x4e7a45!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4e7a45);}catch(_0x4c92cf){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4c92cf);}}_0x23c182['persistentConnection_']=new se(_0x23c182['repoInfo_'],_0x30277c,(_0x452ac0,_0xe31b42,_0x15f816,_0x9482a3)=>{gr(_0x23c182,_0x452ac0,_0xe31b42,_0x15f816,_0x9482a3);},_0x1c56a1=>{mr(_0x23c182,_0x1c56a1);},_0x9428e2=>{Id(_0x23c182,_0x9428e2);},_0x23c182['authTokenProvider_'],_0x23c182['appCheckProvider_'],_0x4e7a45),_0x23c182['server_']=_0x23c182['persistentConnection_'];}_0x23c182['authTokenProvider_']['addTokenChangeListener'](_0x22a763=>{_0x23c182['server_']['refreshAuthToken'](_0x22a763);}),_0x23c182['appCheckProvider_']['addTokenChangeListener'](_0x292112=>{_0x23c182['server_']['refreshAppCheckToken'](_0x292112['token']);}),_0x23c182['statsReporter_']=ih(_0x23c182['repoInfo_'],()=>new iu(_0x23c182['stats_'],_0x23c182['server_'])),_0x23c182['infoData_']=new Xh(),_0x23c182['infoSyncTree_']=new pr({'startListening':(_0x4977c1,_0x343b79,_0x5f0817,_0x3c35f8)=>{let _0x67c0be=[];const _0x26fc54=_0x23c182['infoData_']['getNode'](_0x4977c1['_path']);return _0x26fc54['isEmpty']()||(_0x67c0be=Yt(_0x23c182['infoSyncTree_'],_0x4977c1['_path'],_0x26fc54),setTimeout(()=>{_0x3c35f8('ok');},0x0)),_0x67c0be;},'stopListening':()=>{}}),vs(_0x23c182,'connected',!0x1),_0x23c182['serverSyncTree_']=new pr({'startListening':(_0x37ef76,_0x293ee9,_0x5d0fe7,_0x48ecae)=>(_0x23c182['server_']['listen'](_0x37ef76,_0x5d0fe7,_0x293ee9,(_0x57e2f8,_0x30d83d)=>{const _0x5e5cec=_0x48ecae(_0x57e2f8,_0x30d83d);V(_0x23c182['eventQueue_'],_0x37ef76['_path'],_0x5e5cec);}),[]),'stopListening':(_0x2f842b,_0x44ff68)=>{_0x23c182['server_']['unlisten'](_0x2f842b,_0x44ff68);}});}function la(_0xbca7bb){const _0x409e05=_0xbca7bb['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x409e05;}function Xt(_0x316c23){return id({'timestamp':la(_0x316c23)});}function gr(_0x1de64d,_0x53aa1d,_0x5de69a,_0x59e530,_0x2d0b4b){_0x1de64d['dataUpdateCount']++;const _0x83d089=new C(_0x53aa1d);_0x5de69a=_0x1de64d['interceptServerDataCallback_']?_0x1de64d['interceptServerDataCallback_'](_0x53aa1d,_0x5de69a):_0x5de69a;let _0x5075ec=[];if(_0x2d0b4b){if(_0x59e530){const _0x46695e=_n(_0x5de69a,_0x384180=>A(_0x384180));_0x5075ec=Ju(_0x1de64d['serverSyncTree_'],_0x83d089,_0x46695e,_0x2d0b4b);}else{const _0x470530=A(_0x5de69a);_0x5075ec=Jo(_0x1de64d['serverSyncTree_'],_0x83d089,_0x470530,_0x2d0b4b);}}else{if(_0x59e530){const _0x1188db=_n(_0x5de69a,_0x77573b=>A(_0x77573b));_0x5075ec=Ku(_0x1de64d['serverSyncTree_'],_0x83d089,_0x1188db);}else{const _0x941487=A(_0x5de69a);_0x5075ec=Yt(_0x1de64d['serverSyncTree_'],_0x83d089,_0x941487);}}let _0x442719=_0x83d089;_0x5075ec['length']>0x0&&(_0x442719=ct(_0x1de64d,_0x83d089)),V(_0x1de64d['eventQueue_'],_0x442719,_0x5075ec);}function mr(_0x324a6f,_0x190faf){vs(_0x324a6f,'connected',_0x190faf),_0x190faf===!0x1&&Sd(_0x324a6f);}function Id(_0x2baab5,_0x441fef){x(_0x441fef,(_0x51e02d,_0x31cba1)=>{vs(_0x2baab5,_0x51e02d,_0x31cba1);});}function vs(_0x2c2ec2,_0x2e32e,_0x2e187b){const _0x382ea2=new C('/.info/'+_0x2e32e),_0x3bcc41=A(_0x2e187b);_0x2c2ec2['infoData_']['updateSnapshot'](_0x382ea2,_0x3bcc41);const _0xaa350d=Yt(_0x2c2ec2['infoSyncTree_'],_0x382ea2,_0x3bcc41);V(_0x2c2ec2['eventQueue_'],_0x382ea2,_0xaa350d);}function zn(_0xe45d7e){return _0xe45d7e['nextWriteId_']++;}function wd(_0x51810c,_0x47191e,_0x32adfe){const _0xe93da9=Xu(_0x51810c['serverSyncTree_'],_0x47191e);return _0xe93da9!=null?Promise['resolve'](_0xe93da9):_0x51810c['server_']['get'](_0x47191e)['then'](_0x41eb7b=>{const _0x1e7b80=A(_0x41eb7b)['withIndex'](_0x47191e['_queryParams']['getIndex']());Ni(_0x51810c['serverSyncTree_'],_0x47191e,_0x32adfe,!0x0);let _0x2b74f8;if(_0x47191e['_queryParams']['loadsAllData']())_0x2b74f8=Yt(_0x51810c['serverSyncTree_'],_0x47191e['_path'],_0x1e7b80);else{const _0x52000a=Wt(_0x51810c['serverSyncTree_'],_0x47191e);_0x2b74f8=Jo(_0x51810c['serverSyncTree_'],_0x47191e['_path'],_0x1e7b80,_0x52000a);}return V(_0x51810c['eventQueue_'],_0x47191e['_path'],_0x2b74f8),An(_0x51810c['serverSyncTree_'],_0x47191e,_0x32adfe,null,!0x0),_0x1e7b80;},_0x3a4328=>(gt(_0x51810c,'get\x20for\x20query\x20'+O(_0x47191e)+'\x20failed:\x20'+_0x3a4328),Promise['reject'](new Error(_0x3a4328))));}function Cd(_0x2229f2,_0x2d4245,_0x282d83,_0x23ef2c,_0x57c50d){gt(_0x2229f2,'set',{'path':_0x2d4245['toString'](),'value':_0x282d83,'priority':_0x23ef2c});const _0xbc1674=Xt(_0x2229f2),_0x72d211=A(_0x282d83,_0x23ef2c),_0x40eb08=Vn(_0x2229f2['serverSyncTree_'],_0x2d4245),_0x4826cd=fs(_0x72d211,_0x40eb08,_0xbc1674),_0x5c2bf3=zn(_0x2229f2),_0xa886da=as(_0x2229f2['serverSyncTree_'],_0x2d4245,_0x4826cd,_0x5c2bf3,!0x0);qn(_0x2229f2['eventQueue_'],_0xa886da),_0x2229f2['server_']['put'](_0x2d4245['toString'](),_0x72d211['val'](!0x0),(_0x30d27d,_0x2ac104)=>{const _0xa0d4a1=_0x30d27d==='ok';_0xa0d4a1||U('set\x20at\x20'+_0x2d4245+'\x20failed:\x20'+_0x30d27d);const _0x4c4f4b=_e(_0x2229f2['serverSyncTree_'],_0x5c2bf3,!_0xa0d4a1);V(_0x2229f2['eventQueue_'],_0x2d4245,_0x4c4f4b),be(_0x2229f2,_0x57c50d,_0x30d27d,_0x2ac104);});const _0x2892fc=Is(_0x2229f2,_0x2d4245);ct(_0x2229f2,_0x2892fc),V(_0x2229f2['eventQueue_'],_0x2892fc,[]);}function Td(_0x3e7cfe,_0x35b4bf,_0xd3504d,_0x4daf9c){gt(_0x3e7cfe,'update',{'path':_0x35b4bf['toString'](),'value':_0xd3504d});let _0x25aa1f=!0x0;const _0x25ccd6=Xt(_0x3e7cfe),_0x2eb871={};if(x(_0xd3504d,(_0x862735,_0x1cb38e)=>{_0x25aa1f=!0x1,_0x2eb871[_0x862735]=ta(k(_0x35b4bf,_0x862735),A(_0x1cb38e),_0x3e7cfe['serverSyncTree_'],_0x25ccd6);}),_0x25aa1f)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x3e7cfe,_0x4daf9c,'ok',void 0x0);else{const _0x80425c=zn(_0x3e7cfe),_0x2e0419=ju(_0x3e7cfe['serverSyncTree_'],_0x35b4bf,_0x2eb871,_0x80425c);qn(_0x3e7cfe['eventQueue_'],_0x2e0419),_0x3e7cfe['server_']['merge'](_0x35b4bf['toString'](),_0xd3504d,(_0x37b048,_0x3d79b3)=>{const _0xbe0bdf=_0x37b048==='ok';_0xbe0bdf||U('update\x20at\x20'+_0x35b4bf+'\x20failed:\x20'+_0x37b048);const _0x3c52dd=_e(_0x3e7cfe['serverSyncTree_'],_0x80425c,!_0xbe0bdf),_0x7fdfc5=_0x3c52dd['length']>0x0?ct(_0x3e7cfe,_0x35b4bf):_0x35b4bf;V(_0x3e7cfe['eventQueue_'],_0x7fdfc5,_0x3c52dd),be(_0x3e7cfe,_0x4daf9c,_0x37b048,_0x3d79b3);}),x(_0xd3504d,_0x525327=>{const _0x26cf58=Is(_0x3e7cfe,k(_0x35b4bf,_0x525327));ct(_0x3e7cfe,_0x26cf58);}),V(_0x3e7cfe['eventQueue_'],_0x35b4bf,[]);}}function Sd(_0x4c23da){gt(_0x4c23da,'onDisconnectEvents');const _0x3e1299=Xt(_0x4c23da),_0xd3548d=En();Si(_0x4c23da['onDisconnect_'],w(),(_0x3c4bd8,_0x5d56e7)=>{const _0x1631cf=ta(_0x3c4bd8,_0x5d56e7,_0x4c23da['serverSyncTree_'],_0x3e1299);pt(_0xd3548d,_0x3c4bd8,_0x1631cf);});let _0x30717f=[];Si(_0xd3548d,w(),(_0x4e5d8b,_0x49d96a)=>{_0x30717f=_0x30717f['concat'](Yt(_0x4c23da['serverSyncTree_'],_0x4e5d8b,_0x49d96a));const _0x521457=Is(_0x4c23da,_0x4e5d8b);ct(_0x4c23da,_0x521457);}),_0x4c23da['onDisconnect_']=En(),V(_0x4c23da['eventQueue_'],w(),_0x30717f);}function bd(_0x484f35,_0x17f25c,_0x49abe5){_0x484f35['server_']['onDisconnectCancel'](_0x17f25c['toString'](),(_0x33bb7c,_0x7172f0)=>{_0x33bb7c==='ok'&&Ti(_0x484f35['onDisconnect_'],_0x17f25c),be(_0x484f35,_0x49abe5,_0x33bb7c,_0x7172f0);});}function yr(_0x2e7349,_0x591096,_0x260d57,_0x8c2bff){const _0x6db3a6=A(_0x260d57);_0x2e7349['server_']['onDisconnectPut'](_0x591096['toString'](),_0x6db3a6['val'](!0x0),(_0x36a576,_0xf642b3)=>{_0x36a576==='ok'&&pt(_0x2e7349['onDisconnect_'],_0x591096,_0x6db3a6),be(_0x2e7349,_0x8c2bff,_0x36a576,_0xf642b3);});}function Rd(_0x305b47,_0x326e68,_0x780e92,_0x1855de,_0xa6b328){const _0x3173e8=A(_0x780e92,_0x1855de);_0x305b47['server_']['onDisconnectPut'](_0x326e68['toString'](),_0x3173e8['val'](!0x0),(_0x3ffea0,_0x4d56df)=>{_0x3ffea0==='ok'&&pt(_0x305b47['onDisconnect_'],_0x326e68,_0x3173e8),be(_0x305b47,_0xa6b328,_0x3ffea0,_0x4d56df);});}function Ad(_0x378819,_0x345a23,_0x19ab9b,_0x4f01cf){if(pn(_0x19ab9b)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x378819,_0x4f01cf,'ok',void 0x0);return;}_0x378819['server_']['onDisconnectMerge'](_0x345a23['toString'](),_0x19ab9b,(_0x10a738,_0x5db8ea)=>{_0x10a738==='ok'&&x(_0x19ab9b,(_0x1ebacd,_0x43e5c7)=>{const _0x52fa74=A(_0x43e5c7);pt(_0x378819['onDisconnect_'],k(_0x345a23,_0x1ebacd),_0x52fa74);}),be(_0x378819,_0x4f01cf,_0x10a738,_0x5db8ea);});}function kd(_0x5dc4b2,_0x5b630a,_0x327ff2){let _0x28f0c0;y(_0x5b630a['_path'])==='.info'?_0x28f0c0=Ni(_0x5dc4b2['infoSyncTree_'],_0x5b630a,_0x327ff2):_0x28f0c0=Ni(_0x5dc4b2['serverSyncTree_'],_0x5b630a,_0x327ff2),oa(_0x5dc4b2['eventQueue_'],_0x5b630a['_path'],_0x28f0c0);}function Pd(_0x35133a,_0x47b31c,_0x5e9770){let _0x445158;y(_0x47b31c['_path'])==='.info'?_0x445158=An(_0x35133a['infoSyncTree_'],_0x47b31c,_0x5e9770):_0x445158=An(_0x35133a['serverSyncTree_'],_0x47b31c,_0x5e9770),oa(_0x35133a['eventQueue_'],_0x47b31c['_path'],_0x445158);}function ha(_0x11687d){_0x11687d['persistentConnection_']&&_0x11687d['persistentConnection_']['interrupt'](ca);}function Nd(_0x159d40){_0x159d40['persistentConnection_']&&_0x159d40['persistentConnection_']['resume'](ca);}function gt(_0x397e6a,..._0x21d673){let _0x199f78='';_0x397e6a['persistentConnection_']&&(_0x199f78=_0x397e6a['persistentConnection_']['id']+':'),L(_0x199f78,..._0x21d673);}function be(_0x5d383a,_0x1b36a3,_0x3abec6,_0x52fe45){_0x1b36a3&&ft(()=>{if(_0x3abec6==='ok')_0x1b36a3(null);else{const _0x1c0520=(_0x3abec6||'error')['toUpperCase']();let _0x1053d8=_0x1c0520;_0x52fe45&&(_0x1053d8+=':\x20'+_0x52fe45);const _0x54d0ff=new Error(_0x1053d8);_0x54d0ff['code']=_0x1c0520,_0x1b36a3(_0x54d0ff);}});}function Od(_0x2c818c,_0x489992,_0x44b9b3,_0x2efe3c,_0x4e348a,_0x2849a9){gt(_0x2c818c,'transaction\x20on\x20'+_0x489992);const _0x2510d5={'path':_0x489992,'update':_0x44b9b3,'onComplete':_0x2efe3c,'status':null,'order':so(),'applyLocally':_0x2849a9,'retryCount':0x0,'unwatcher':_0x4e348a,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2a3434=Es(_0x2c818c,_0x489992,void 0x0);_0x2510d5['currentInputSnapshot']=_0x2a3434;const _0x2c368f=_0x2510d5['update'](_0x2a3434['val']());if(_0x2c368f===void 0x0)_0x2510d5['unwatcher'](),_0x2510d5['currentOutputSnapshotRaw']=null,_0x2510d5['currentOutputSnapshotResolved']=null,_0x2510d5['onComplete']&&_0x2510d5['onComplete'](null,!0x1,_0x2510d5['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2c368f,_0x2510d5['path']),_0x2510d5['status']=0x0;const _0x3356c8=$n(_0x2c818c['transactionQueueTree_'],_0x489992),_0x31a3b4=je(_0x3356c8)||[];_0x31a3b4['push'](_0x2510d5),gs(_0x3356c8,_0x31a3b4);let _0x1f915b;typeof _0x2c368f=='object'&&_0x2c368f!==null&&Q(_0x2c368f,'.priority')?(_0x1f915b=Le(_0x2c368f,'.priority'),f(Bt(_0x1f915b),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1f915b=(Vn(_0x2c818c['serverSyncTree_'],_0x489992)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x492cd4=Xt(_0x2c818c),_0x3417d9=A(_0x2c368f,_0x1f915b),_0x2b5b4a=fs(_0x3417d9,_0x2a3434,_0x492cd4);_0x2510d5['currentOutputSnapshotRaw']=_0x3417d9,_0x2510d5['currentOutputSnapshotResolved']=_0x2b5b4a,_0x2510d5['currentWriteId']=zn(_0x2c818c);const _0x13a4fb=as(_0x2c818c['serverSyncTree_'],_0x489992,_0x2b5b4a,_0x2510d5['currentWriteId'],_0x2510d5['applyLocally']);V(_0x2c818c['eventQueue_'],_0x489992,_0x13a4fb),jn(_0x2c818c,_0x2c818c['transactionQueueTree_']);}}function Es(_0x1eb9ff,_0x1add96,_0x711e15){return Vn(_0x1eb9ff['serverSyncTree_'],_0x1add96,_0x711e15)||g['EMPTY_NODE'];}function jn(_0x454ab2,_0x478848=_0x454ab2['transactionQueueTree_']){if(_0x478848||Kn(_0x454ab2,_0x478848),je(_0x478848)){const _0x106c7f=da(_0x454ab2,_0x478848);f(_0x106c7f['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x106c7f['every'](_0xa6997b=>_0xa6997b['status']===0x0)&&Dd(_0x454ab2,Qt(_0x478848),_0x106c7f);}else na(_0x478848)&&Gn(_0x478848,_0x102fdb=>{jn(_0x454ab2,_0x102fdb);});}function Dd(_0x14a6c4,_0x274bd2,_0x1d3bb4){const _0x5721a6=_0x1d3bb4['map'](_0x18a177=>_0x18a177['currentWriteId']),_0x3c378a=Es(_0x14a6c4,_0x274bd2,_0x5721a6);let _0x29223f=_0x3c378a;const _0x367cd6=_0x3c378a['hash']();for(let _0x11138a=0x0;_0x11138a<_0x1d3bb4['length'];_0x11138a++){const _0x2734cd=_0x1d3bb4[_0x11138a];f(_0x2734cd['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2734cd['status']=0x1,_0x2734cd['retryCount']++;const _0x379067=F(_0x274bd2,_0x2734cd['path']);_0x29223f=_0x29223f['updateChild'](_0x379067,_0x2734cd['currentOutputSnapshotRaw']);}const _0x254b1c=_0x29223f['val'](!0x0),_0x3ebd1d=_0x274bd2;_0x14a6c4['server_']['put'](_0x3ebd1d['toString'](),_0x254b1c,_0x1a1f57=>{gt(_0x14a6c4,'transaction\x20put\x20response',{'path':_0x3ebd1d['toString'](),'status':_0x1a1f57});let _0xa83cd2=[];if(_0x1a1f57==='ok'){const _0x1cb60d=[];for(let _0x2a61d7=0x0;_0x2a61d7<_0x1d3bb4['length'];_0x2a61d7++)_0x1d3bb4[_0x2a61d7]['status']=0x2,_0xa83cd2=_0xa83cd2['concat'](_e(_0x14a6c4['serverSyncTree_'],_0x1d3bb4[_0x2a61d7]['currentWriteId'])),_0x1d3bb4[_0x2a61d7]['onComplete']&&_0x1cb60d['push'](()=>_0x1d3bb4[_0x2a61d7]['onComplete'](null,!0x0,_0x1d3bb4[_0x2a61d7]['currentOutputSnapshotResolved'])),_0x1d3bb4[_0x2a61d7]['unwatcher']();Kn(_0x14a6c4,$n(_0x14a6c4['transactionQueueTree_'],_0x274bd2)),jn(_0x14a6c4,_0x14a6c4['transactionQueueTree_']),V(_0x14a6c4['eventQueue_'],_0x274bd2,_0xa83cd2);for(let _0x3e3cce=0x0;_0x3e3cce<_0x1cb60d['length'];_0x3e3cce++)ft(_0x1cb60d[_0x3e3cce]);}else{if(_0x1a1f57==='datastale'){for(let _0x56a3e7=0x0;_0x56a3e7<_0x1d3bb4['length'];_0x56a3e7++)_0x1d3bb4[_0x56a3e7]['status']===0x3?_0x1d3bb4[_0x56a3e7]['status']=0x4:_0x1d3bb4[_0x56a3e7]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3ebd1d['toString']()+'\x20failed:\x20'+_0x1a1f57);for(let _0x2f5788=0x0;_0x2f5788<_0x1d3bb4['length'];_0x2f5788++)_0x1d3bb4[_0x2f5788]['status']=0x4,_0x1d3bb4[_0x2f5788]['abortReason']=_0x1a1f57;}ct(_0x14a6c4,_0x274bd2);}},_0x367cd6);}function ct(_0x45d9ca,_0x5860e7){const _0x301b13=ua(_0x45d9ca,_0x5860e7),_0x152d96=Qt(_0x301b13),_0x365ff9=da(_0x45d9ca,_0x301b13);return Md(_0x45d9ca,_0x365ff9,_0x152d96),_0x152d96;}function Md(_0x52330c,_0x24b4e9,_0x106cee){if(_0x24b4e9['length']===0x0)return;const _0x3b5f0f=[];let _0x5e9f7d=[];const _0x15b1c1=_0x24b4e9['filter'](_0x44685d=>_0x44685d['status']===0x0)['map'](_0x46640c=>_0x46640c['currentWriteId']);for(let _0x51d2ad=0x0;_0x51d2ad<_0x24b4e9['length'];_0x51d2ad++){const _0x6eb980=_0x24b4e9[_0x51d2ad],_0x311e05=F(_0x106cee,_0x6eb980['path']);let _0x3119d6=!0x1,_0x38cdd8;if(f(_0x311e05!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x6eb980['status']===0x4)_0x3119d6=!0x0,_0x38cdd8=_0x6eb980['abortReason'],_0x5e9f7d=_0x5e9f7d['concat'](_e(_0x52330c['serverSyncTree_'],_0x6eb980['currentWriteId'],!0x0));else{if(_0x6eb980['status']===0x0){if(_0x6eb980['retryCount']>=yd)_0x3119d6=!0x0,_0x38cdd8='maxretry',_0x5e9f7d=_0x5e9f7d['concat'](_e(_0x52330c['serverSyncTree_'],_0x6eb980['currentWriteId'],!0x0));else{const _0x40134f=Es(_0x52330c,_0x6eb980['path'],_0x15b1c1);_0x6eb980['currentInputSnapshot']=_0x40134f;const _0x479e44=_0x24b4e9[_0x51d2ad]['update'](_0x40134f['val']());if(_0x479e44!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x479e44,_0x6eb980['path']);let _0x1a6485=A(_0x479e44);typeof _0x479e44=='object'&&_0x479e44!=null&&Q(_0x479e44,'.priority')||(_0x1a6485=_0x1a6485['updatePriority'](_0x40134f['getPriority']()));const _0xc92a64=_0x6eb980['currentWriteId'],_0x3f77cf=Xt(_0x52330c),_0x51f180=fs(_0x1a6485,_0x40134f,_0x3f77cf);_0x6eb980['currentOutputSnapshotRaw']=_0x1a6485,_0x6eb980['currentOutputSnapshotResolved']=_0x51f180,_0x6eb980['currentWriteId']=zn(_0x52330c),_0x15b1c1['splice'](_0x15b1c1['indexOf'](_0xc92a64),0x1),_0x5e9f7d=_0x5e9f7d['concat'](as(_0x52330c['serverSyncTree_'],_0x6eb980['path'],_0x51f180,_0x6eb980['currentWriteId'],_0x6eb980['applyLocally'])),_0x5e9f7d=_0x5e9f7d['concat'](_e(_0x52330c['serverSyncTree_'],_0xc92a64,!0x0));}else _0x3119d6=!0x0,_0x38cdd8='nodata',_0x5e9f7d=_0x5e9f7d['concat'](_e(_0x52330c['serverSyncTree_'],_0x6eb980['currentWriteId'],!0x0));}}}V(_0x52330c['eventQueue_'],_0x106cee,_0x5e9f7d),_0x5e9f7d=[],_0x3119d6&&(_0x24b4e9[_0x51d2ad]['status']=0x2,function(_0x3168bb){setTimeout(_0x3168bb,Math['floor'](0x0));}(_0x24b4e9[_0x51d2ad]['unwatcher']),_0x24b4e9[_0x51d2ad]['onComplete']&&(_0x38cdd8==='nodata'?_0x3b5f0f['push'](()=>_0x24b4e9[_0x51d2ad]['onComplete'](null,!0x1,_0x24b4e9[_0x51d2ad]['currentInputSnapshot'])):_0x3b5f0f['push'](()=>_0x24b4e9[_0x51d2ad]['onComplete'](new Error(_0x38cdd8),!0x1,null))));}Kn(_0x52330c,_0x52330c['transactionQueueTree_']);for(let _0x4cf107=0x0;_0x4cf107<_0x3b5f0f['length'];_0x4cf107++)ft(_0x3b5f0f[_0x4cf107]);jn(_0x52330c,_0x52330c['transactionQueueTree_']);}function ua(_0x3090eb,_0x3fa880){let _0x84059f,_0x2df099=_0x3090eb['transactionQueueTree_'];for(_0x84059f=y(_0x3fa880);_0x84059f!==null&&je(_0x2df099)===void 0x0;)_0x2df099=$n(_0x2df099,_0x84059f),_0x3fa880=S(_0x3fa880),_0x84059f=y(_0x3fa880);return _0x2df099;}function da(_0x55b3ae,_0x14f3ee){const _0x4b3d40=[];return fa(_0x55b3ae,_0x14f3ee,_0x4b3d40),_0x4b3d40['sort']((_0x4f677b,_0x1442d1)=>_0x4f677b['order']-_0x1442d1['order']),_0x4b3d40;}function fa(_0x1b7a2f,_0x2130a6,_0x138aba){const _0x57fbfc=je(_0x2130a6);if(_0x57fbfc){for(let _0x4faacd=0x0;_0x4faacd<_0x57fbfc['length'];_0x4faacd++)_0x138aba['push'](_0x57fbfc[_0x4faacd]);}Gn(_0x2130a6,_0x3a8728=>{fa(_0x1b7a2f,_0x3a8728,_0x138aba);});}function Kn(_0x40ad88,_0x518b42){const _0x5de58f=je(_0x518b42);if(_0x5de58f){let _0x2e69c0=0x0;for(let _0x4d6d59=0x0;_0x4d6d59<_0x5de58f['length'];_0x4d6d59++)_0x5de58f[_0x4d6d59]['status']!==0x2&&(_0x5de58f[_0x2e69c0]=_0x5de58f[_0x4d6d59],_0x2e69c0++);_0x5de58f['length']=_0x2e69c0,gs(_0x518b42,_0x5de58f['length']>0x0?_0x5de58f:void 0x0);}Gn(_0x518b42,_0x422647=>{Kn(_0x40ad88,_0x422647);});}function Is(_0x5a01f1,_0x5afa9d){const _0x1e9948=Qt(ua(_0x5a01f1,_0x5afa9d)),_0x131bbd=$n(_0x5a01f1['transactionQueueTree_'],_0x5afa9d);return ad(_0x131bbd,_0x4b65a4=>{di(_0x5a01f1,_0x4b65a4);}),di(_0x5a01f1,_0x131bbd),ia(_0x131bbd,_0x4b0c39=>{di(_0x5a01f1,_0x4b0c39);}),_0x1e9948;}function di(_0x1bfdd7,_0x45b516){const _0x94749c=je(_0x45b516);if(_0x94749c){const _0x577895=[];let _0x484b2c=[],_0x4a2a7b=-0x1;for(let _0x1fbe55=0x0;_0x1fbe55<_0x94749c['length'];_0x1fbe55++)_0x94749c[_0x1fbe55]['status']===0x3||(_0x94749c[_0x1fbe55]['status']===0x1?(f(_0x4a2a7b===_0x1fbe55-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4a2a7b=_0x1fbe55,_0x94749c[_0x1fbe55]['status']=0x3,_0x94749c[_0x1fbe55]['abortReason']='set'):(f(_0x94749c[_0x1fbe55]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x94749c[_0x1fbe55]['unwatcher'](),_0x484b2c=_0x484b2c['concat'](_e(_0x1bfdd7['serverSyncTree_'],_0x94749c[_0x1fbe55]['currentWriteId'],!0x0)),_0x94749c[_0x1fbe55]['onComplete']&&_0x577895['push'](_0x94749c[_0x1fbe55]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4a2a7b===-0x1?gs(_0x45b516,void 0x0):_0x94749c['length']=_0x4a2a7b+0x1,V(_0x1bfdd7['eventQueue_'],Qt(_0x45b516),_0x484b2c);for(let _0x2bbc98=0x0;_0x2bbc98<_0x577895['length'];_0x2bbc98++)ft(_0x577895[_0x2bbc98]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x366cea){let _0x107858='';const _0x25910d=_0x366cea['split']('/');for(let _0x5e73b3=0x0;_0x5e73b3<_0x25910d['length'];_0x5e73b3++)if(_0x25910d[_0x5e73b3]['length']>0x0){let _0x56a495=_0x25910d[_0x5e73b3];try{_0x56a495=decodeURIComponent(_0x56a495['replace'](/\+/g,'\x20'));}catch{}_0x107858+='/'+_0x56a495;}return _0x107858;}function xd(_0x2a2bd6){const _0x32e8ed={};_0x2a2bd6['charAt'](0x0)==='?'&&(_0x2a2bd6=_0x2a2bd6['substring'](0x1));for(const _0x4d28c5 of _0x2a2bd6['split']('&')){if(_0x4d28c5['length']===0x0)continue;const _0x59be9c=_0x4d28c5['split']('=');_0x59be9c['length']===0x2?_0x32e8ed[decodeURIComponent(_0x59be9c[0x0])]=decodeURIComponent(_0x59be9c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4d28c5+'\x27\x20in\x20query\x20\x27'+_0x2a2bd6+'\x27');}return _0x32e8ed;}const vr=function(_0x2967fb,_0x2aed6f){const _0x392fe5=Fd(_0x2967fb),_0x445b19=_0x392fe5['namespace'];_0x392fe5['domain']==='firebase.com'&&ae(_0x392fe5['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x445b19||_0x445b19==='undefined')&&_0x392fe5['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x392fe5['secure']||$l();const _0x515b52=_0x392fe5['scheme']==='ws'||_0x392fe5['scheme']==='wss';return{'repoInfo':new yo(_0x392fe5['host'],_0x392fe5['secure'],_0x445b19,_0x515b52,_0x2aed6f,'',_0x445b19!==_0x392fe5['subdomain']),'path':new C(_0x392fe5['pathString'])};},Fd=function(_0x2ae5d6){let _0x1c8845='',_0x5ae31='',_0x59a1e7='',_0x40d6a0='',_0x18059c='',_0x2698ad=!0x0,_0x257c88='https',_0x30cdb4=0x1bb;if(typeof _0x2ae5d6=='string'){let _0x146417=_0x2ae5d6['indexOf']('//');_0x146417>=0x0&&(_0x257c88=_0x2ae5d6['substring'](0x0,_0x146417-0x1),_0x2ae5d6=_0x2ae5d6['substring'](_0x146417+0x2));let _0x2413d9=_0x2ae5d6['indexOf']('/');_0x2413d9===-0x1&&(_0x2413d9=_0x2ae5d6['length']);let _0x483441=_0x2ae5d6['indexOf']('?');_0x483441===-0x1&&(_0x483441=_0x2ae5d6['length']),_0x1c8845=_0x2ae5d6['substring'](0x0,Math['min'](_0x2413d9,_0x483441)),_0x2413d9<_0x483441&&(_0x40d6a0=Ld(_0x2ae5d6['substring'](_0x2413d9,_0x483441)));const _0x4feb72=xd(_0x2ae5d6['substring'](Math['min'](_0x2ae5d6['length'],_0x483441)));_0x146417=_0x1c8845['indexOf'](':'),_0x146417>=0x0?(_0x2698ad=_0x257c88==='https'||_0x257c88==='wss',_0x30cdb4=parseInt(_0x1c8845['substring'](_0x146417+0x1),0xa)):_0x146417=_0x1c8845['length'];const _0x33e0b0=_0x1c8845['slice'](0x0,_0x146417);if(_0x33e0b0['toLowerCase']()==='localhost')_0x5ae31='localhost';else{if(_0x33e0b0['split']('.')['length']<=0x2)_0x5ae31=_0x33e0b0;else{const _0x258a65=_0x1c8845['indexOf']('.');_0x59a1e7=_0x1c8845['substring'](0x0,_0x258a65)['toLowerCase'](),_0x5ae31=_0x1c8845['substring'](_0x258a65+0x1),_0x18059c=_0x59a1e7;}}'ns'in _0x4feb72&&(_0x18059c=_0x4feb72['ns']);}return{'host':_0x1c8845,'port':_0x30cdb4,'domain':_0x5ae31,'subdomain':_0x59a1e7,'secure':_0x2698ad,'scheme':_0x257c88,'pathString':_0x40d6a0,'namespace':_0x18059c};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x1a992a=0x0;const _0xb6d418=[];return function(_0x5b633c){const _0x5129ba=_0x5b633c===_0x1a992a;_0x1a992a=_0x5b633c;let _0x5968e0;const _0x16cfee=new Array(0x8);for(_0x5968e0=0x7;_0x5968e0>=0x0;_0x5968e0--)_0x16cfee[_0x5968e0]=Er['charAt'](_0x5b633c%0x40),_0x5b633c=Math['floor'](_0x5b633c/0x40);f(_0x5b633c===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1e4f7d=_0x16cfee['join']('');if(_0x5129ba){for(_0x5968e0=0xb;_0x5968e0>=0x0&&_0xb6d418[_0x5968e0]===0x3f;_0x5968e0--)_0xb6d418[_0x5968e0]=0x0;_0xb6d418[_0x5968e0]++;}else{for(_0x5968e0=0x0;_0x5968e0<0xc;_0x5968e0++)_0xb6d418[_0x5968e0]=Math['floor'](Math['random']()*0x40);}for(_0x5968e0=0x0;_0x5968e0<0xc;_0x5968e0++)_0x1e4f7d+=Er['charAt'](_0xb6d418[_0x5968e0]);return f(_0x1e4f7d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1e4f7d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x3f0006,_0x5a5103,_0x5750c4,_0x2885b3){this['eventType']=_0x3f0006,this['eventRegistration']=_0x5a5103,this['snapshot']=_0x5750c4,this['prevName']=_0x2885b3;}['getPath'](){const _0x225263=this['snapshot']['ref'];return this['eventType']==='value'?_0x225263['_path']:_0x225263['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x5954ca,_0x36f3aa,_0x38ea26){this['eventRegistration']=_0x5954ca,this['error']=_0x36f3aa,this['path']=_0x38ea26;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0xe88b00,_0x5a6f18){this['snapshotCallback']=_0xe88b00,this['cancelCallback']=_0x5a6f18;}['onValue'](_0xa6ec1,_0x2c88ec){this['snapshotCallback']['call'](null,_0xa6ec1,_0x2c88ec);}['onCancel'](_0x2016df){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2016df);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x342f23){return this['snapshotCallback']===_0x342f23['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x342f23['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x342f23['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x3bcafc,_0x1b3af7){this['_repo']=_0x3bcafc,this['_path']=_0x1b3af7;}['cancel'](){const _0x3c4646=new H();return bd(this['_repo'],this['_path'],_0x3c4646['wrapCallback'](()=>{})),_0x3c4646['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x58a55d=new H();return yr(this['_repo'],this['_path'],null,_0x58a55d['wrapCallback'](()=>{})),_0x58a55d['promise'];}['set'](_0x1317eb){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x1317eb,this['_path'],!0x1);const _0x5027e4=new H();return yr(this['_repo'],this['_path'],_0x1317eb,_0x5027e4['wrapCallback'](()=>{})),_0x5027e4['promise'];}['setWithPriority'](_0x48e944,_0x1d7fab){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x48e944,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x1d7fab);const _0x832e21=new H();return Rd(this['_repo'],this['_path'],_0x48e944,_0x1d7fab,_0x832e21['wrapCallback'](()=>{})),_0x832e21['promise'];}['update'](_0x2263e6){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x2263e6,this['_path']);const _0xf508e5=new H();return Ad(this['_repo'],this['_path'],_0x2263e6,_0xf508e5['wrapCallback'](()=>{})),_0xf508e5['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x28af6b,_0x339d11,_0x20c10e,_0x2d56c8){this['_repo']=_0x28af6b,this['_path']=_0x339d11,this['_queryParams']=_0x20c10e,this['_orderByCalled']=_0x2d56c8;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5dba4a=sr(this['_queryParams']),_0x4037c0=$i(_0x5dba4a);return _0x4037c0==='{}'?'default':_0x4037c0;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x2c17b5){if(_0x2c17b5=P(_0x2c17b5),!(_0x2c17b5 instanceof Ae))return!0x1;const _0x445500=this['_repo']===_0x2c17b5['_repo'],_0x50b445=Ki(this['_path'],_0x2c17b5['_path']),_0xffc9c3=this['_queryIdentifier']===_0x2c17b5['_queryIdentifier'];return _0x445500&&_0x50b445&&_0xffc9c3;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x4573a1,_0xffd381){if(_0x4573a1['_orderByCalled']===!0x0)throw new Error(_0xffd381+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0xe8d463){let _0x293d5d=null,_0x3c205a=null;if(_0xe8d463['hasStart']()&&(_0x293d5d=_0xe8d463['getIndexStartValue']()),_0xe8d463['hasEnd']()&&(_0x3c205a=_0xe8d463['getIndexEndValue']()),_0xe8d463['getIndex']()===ve){const _0x4cf816='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3f6193='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0xe8d463['hasStart']()){if(_0xe8d463['getIndexStartName']()!==We)throw new Error(_0x4cf816);if(typeof _0x293d5d!='string')throw new Error(_0x3f6193);}if(_0xe8d463['hasEnd']()){if(_0xe8d463['getIndexEndName']()!==we)throw new Error(_0x4cf816);if(typeof _0x3c205a!='string')throw new Error(_0x3f6193);}}else{if(_0xe8d463['getIndex']()===R){if(_0x293d5d!=null&&!Bt(_0x293d5d)||_0x3c205a!=null&&!Bt(_0x3c205a))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0xe8d463['getIndex']()instanceof Ji||_0xe8d463['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x293d5d!=null&&typeof _0x293d5d=='object'||_0x3c205a!=null&&typeof _0x3c205a=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x153d66){if(_0x153d66['hasStart']()&&_0x153d66['hasEnd']()&&_0x153d66['hasLimit']()&&!_0x153d66['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x499c17,_0x1dca03){super(_0x499c17,_0x1dca03,new Zi(),!0x1);}get['parent'](){const _0x3d554e=Ro(this['_path']);return _0x3d554e===null?null:new ee(this['_repo'],_0x3d554e);}get['root'](){let _0x62f745=this;for(;_0x62f745['parent']!==null;)_0x62f745=_0x62f745['parent'];return _0x62f745;}}class lt{constructor(_0x3e6b0f,_0x53dfbd,_0xb0a3b2){this['_node']=_0x3e6b0f,this['ref']=_0x53dfbd,this['_index']=_0xb0a3b2;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x542f2e){const _0x41a6e7=new C(_0x542f2e),_0xc1e786=Vt(this['ref'],_0x542f2e);return new lt(this['_node']['getChild'](_0x41a6e7),_0xc1e786,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4b285f){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x21b958,_0x453ec1)=>_0x4b285f(new lt(_0x453ec1,Vt(this['ref'],_0x21b958),R)));}['hasChild'](_0x86945e){const _0x36619b=new C(_0x86945e);return!this['_node']['getChild'](_0x36619b)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x573690,_0x556f04){return _0x573690=P(_0x573690),_0x573690['_checkNotDeleted']('ref'),_0x556f04!==void 0x0?Vt(_0x573690['_root'],_0x556f04):_0x573690['_root'];}function Vt(_0x209ddc,_0x59e177){return _0x209ddc=P(_0x209ddc),y(_0x209ddc['_path'])===null?pd('child','path',_0x59e177):ys('child','path',_0x59e177),new ee(_0x209ddc['_repo'],k(_0x209ddc['_path'],_0x59e177));}function v_(_0x141c98){return _0x141c98=P(_0x141c98),new Vd(_0x141c98['_repo'],_0x141c98['_path']);}function E_(_0x546309,_0x2ddd99){_0x546309=P(_0x546309),Me('push',_0x546309['_path']),He('push',_0x2ddd99,_0x546309['_path'],!0x0);const _0x180eb5=la(_0x546309['_repo']),_0x4a9038=Ud(_0x180eb5),_0x3b2f95=Vt(_0x546309,_0x4a9038),_0x5d5343=Vt(_0x546309,_0x4a9038);let _0x34d013;return _0x2ddd99!=null?_0x34d013=Hd(_0x5d5343,_0x2ddd99)['then'](()=>_0x5d5343):_0x34d013=Promise['resolve'](_0x5d5343),_0x3b2f95['then']=_0x34d013['then']['bind'](_0x34d013),_0x3b2f95['catch']=_0x34d013['then']['bind'](_0x34d013,void 0x0),_0x3b2f95;}function Hd(_0x261228,_0x3517a0){_0x261228=P(_0x261228),Me('set',_0x261228['_path']),He('set',_0x3517a0,_0x261228['_path'],!0x1);const _0x28f88b=new H();return Cd(_0x261228['_repo'],_0x261228['_path'],_0x3517a0,null,_0x28f88b['wrapCallback'](()=>{})),_0x28f88b['promise'];}function I_(_0x1d8d91,_0x182381){ra('update',_0x182381,_0x1d8d91['_path']);const _0x1a346f=new H();return Td(_0x1d8d91['_repo'],_0x1d8d91['_path'],_0x182381,_0x1a346f['wrapCallback'](()=>{})),_0x1a346f['promise'];}function w_(_0x2a6ff4){_0x2a6ff4=P(_0x2a6ff4);const _0x5374f4=new pa(()=>{}),_0x2b27dc=new Qn(_0x5374f4);return wd(_0x2a6ff4['_repo'],_0x2a6ff4,_0x2b27dc)['then'](_0x47a98e=>new lt(_0x47a98e,new ee(_0x2a6ff4['_repo'],_0x2a6ff4['_path']),_0x2a6ff4['_queryParams']['getIndex']()));}class Qn{constructor(_0x22e5f2){this['callbackContext']=_0x22e5f2;}['respondsTo'](_0x599f86){return _0x599f86==='value';}['createEvent'](_0x1014a9,_0x4bcb02){const _0xa6a77a=_0x4bcb02['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x1014a9['snapshotNode'],new ee(_0x4bcb02['_repo'],_0x4bcb02['_path']),_0xa6a77a));}['getEventRunner'](_0x1ba9bc){return _0x1ba9bc['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1ba9bc['error']):()=>this['callbackContext']['onValue'](_0x1ba9bc['snapshot'],null);}['createCancelEvent'](_0xf3c3de,_0x44c01b){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0xf3c3de,_0x44c01b):null;}['matches'](_0x4a8340){return _0x4a8340 instanceof Qn?!_0x4a8340['callbackContext']||!this['callbackContext']?!0x0:_0x4a8340['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x375f81,_0x2914c4,_0x262916,_0x308f2a,_0x2e67d5){const _0x3ae9ab=new pa(_0x262916,void 0x0),_0x2e54a3=new Qn(_0x3ae9ab);return kd(_0x375f81['_repo'],_0x375f81,_0x2e54a3),()=>Pd(_0x375f81['_repo'],_0x375f81,_0x2e54a3);}function Gd(_0x4ba9dc,_0x1284aa,_0x549dab,_0x3b55f6){return $d(_0x4ba9dc,'value',_0x1284aa);}class mt{}class ma extends mt{constructor(_0x4ba1c6,_0x129caf){super(),this['_value']=_0x4ba1c6,this['_key']=_0x129caf,this['type']='endAt';}['_apply'](_0x3f796d){He('endAt',this['_value'],_0x3f796d['_path'],!0x0);const _0x453aa7=Jh(_0x3f796d['_queryParams'],this['_value'],this['_key']);if(ga(_0x453aa7),Yn(_0x453aa7),_0x3f796d['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x3f796d['_repo'],_0x3f796d['_path'],_0x453aa7,_0x3f796d['_orderByCalled']);}}function C_(_0x8189af,_0x150101){return new ma(_0x8189af,_0x150101);}class ya extends mt{constructor(_0x19955b,_0x6fae1){super(),this['_value']=_0x19955b,this['_key']=_0x6fae1,this['type']='startAt';}['_apply'](_0x372f48){He('startAt',this['_value'],_0x372f48['_path'],!0x0);const _0x247f75=Qh(_0x372f48['_queryParams'],this['_value'],this['_key']);if(ga(_0x247f75),Yn(_0x247f75),_0x372f48['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x372f48['_repo'],_0x372f48['_path'],_0x247f75,_0x372f48['_orderByCalled']);}}function T_(_0x44e4e2=null,_0x275438){return new ya(_0x44e4e2,_0x275438);}class qd extends mt{constructor(_0x5a6c00){super(),this['_limit']=_0x5a6c00,this['type']='limitToFirst';}['_apply'](_0x2a8a8c){if(_0x2a8a8c['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x2a8a8c['_repo'],_0x2a8a8c['_path'],Yh(_0x2a8a8c['_queryParams'],this['_limit']),_0x2a8a8c['_orderByCalled']);}}function S_(_0x12abd1){if(Math['floor'](_0x12abd1)!==_0x12abd1||_0x12abd1<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x12abd1);}class zd extends mt{constructor(_0x2d682c){super(),this['_path']=_0x2d682c,this['type']='orderByChild';}['_apply'](_0x12123f){_a(_0x12123f,'orderByChild');const _0x5b8fed=new C(this['_path']);if(v(_0x5b8fed))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2d4bfd=new Ji(_0x5b8fed),_0x55da9a=xo(_0x12123f['_queryParams'],_0x2d4bfd);return Yn(_0x55da9a),new Ae(_0x12123f['_repo'],_0x12123f['_path'],_0x55da9a,!0x0);}}function b_(_0x5be910){if(_0x5be910==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5be910==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5be910==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5be910),new zd(_0x5be910);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2e53cf){_a(_0x2e53cf,'orderByKey');const _0x5c1aca=xo(_0x2e53cf['_queryParams'],ve);return Yn(_0x5c1aca),new Ae(_0x2e53cf['_repo'],_0x2e53cf['_path'],_0x5c1aca,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x3fa4a6,_0x25c9d5){super(),this['_value']=_0x3fa4a6,this['_key']=_0x25c9d5,this['type']='equalTo';}['_apply'](_0x469047){if(He('equalTo',this['_value'],_0x469047['_path'],!0x1),_0x469047['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x469047['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x469047));}}function A_(_0x21eb59,_0x2b4f3f){return new Kd(_0x21eb59,_0x2b4f3f);}function k_(_0x2b72b1,..._0x17a0a4){let _0xffeaec=P(_0x2b72b1);for(const _0x5cba32 of _0x17a0a4)_0xffeaec=_0x5cba32['_apply'](_0xffeaec);return _0xffeaec;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x132c05,_0x599371,_0x268358,_0x4b709c){const _0x2a7c3b=_0x599371['lastIndexOf'](':'),_0x28f94b=_0x599371['substring'](0x0,_0x2a7c3b),_0x3d4702=qt(_0x28f94b);_0x132c05['repoInfo_']=new yo(_0x599371,_0x3d4702,_0x132c05['repoInfo_']['namespace'],_0x132c05['repoInfo_']['webSocketOnly'],_0x132c05['repoInfo_']['nodeAdmin'],_0x132c05['repoInfo_']['persistenceKey'],_0x132c05['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x268358),_0x4b709c&&(_0x132c05['authTokenProvider_']=_0x4b709c);}function Xd(_0x3cd775,_0xa3d91e,_0x48a016,_0xb9a2e6,_0x1c0740){let _0x519a4b=_0xb9a2e6||_0x3cd775['options']['databaseURL'];_0x519a4b===void 0x0&&(_0x3cd775['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3cd775['options']['projectId']),_0x519a4b=_0x3cd775['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x55eea7=vr(_0x519a4b,_0x1c0740),_0x349516=_0x55eea7['repoInfo'],_0x3a4951;typeof process<'u'&&Bs&&(_0x3a4951=Bs[Yd]),_0x3a4951?(_0x519a4b='http://'+_0x3a4951+'?ns='+_0x349516['namespace'],_0x55eea7=vr(_0x519a4b,_0x1c0740),_0x349516=_0x55eea7['repoInfo']):_0x55eea7['repoInfo']['secure'];const _0x33b13b=new eh(_0x3cd775['name'],_0x3cd775['options'],_0xa3d91e);_d('Invalid\x20Firebase\x20Database\x20URL',_0x55eea7),v(_0x55eea7['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x214ca5=ef(_0x349516,_0x3cd775,_0x33b13b,new Zl(_0x3cd775,_0x48a016));return new tf(_0x214ca5,_0x3cd775);}function Zd(_0x4c4df4,_0x17f40d){const _0x581edc=Di[_0x17f40d];(!_0x581edc||_0x581edc[_0x4c4df4['key']]!==_0x4c4df4)&&ae('Database\x20'+_0x17f40d+'('+_0x4c4df4['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x4c4df4),delete _0x581edc[_0x4c4df4['key']];}function ef(_0x4c0a8c,_0x46c9fc,_0x3872c0,_0x1d440f){let _0x483503=Di[_0x46c9fc['name']];_0x483503||(_0x483503={},Di[_0x46c9fc['name']]=_0x483503);let _0x518527=_0x483503[_0x4c0a8c['toURLString']()];return _0x518527&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x518527=new vd(_0x4c0a8c,Qd,_0x3872c0,_0x1d440f),_0x483503[_0x4c0a8c['toURLString']()]=_0x518527,_0x518527;}class tf{constructor(_0x15b692,_0x1f235f){this['_repoInternal']=_0x15b692,this['app']=_0x1f235f,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x43a459){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x43a459+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x2aa785=Zr(),_0x3692cc){const _0x36e6be=Hi(_0x2aa785,'database')['getImmediate']({'identifier':_0x3692cc});if(!_0x36e6be['_instanceStarted']){const _0x46a37c=hc('database');_0x46a37c&&nf(_0x36e6be,..._0x46a37c);}return _0x36e6be;}function nf(_0x549875,_0x58f625,_0x196a96,_0x4e8db1={}){_0x549875=P(_0x549875),_0x549875['_checkNotDeleted']('useEmulator');const _0x5bbf46=_0x58f625+':'+_0x196a96,_0x25b9b1=_0x549875['_repoInternal'];if(_0x549875['_instanceStarted']){if(_0x5bbf46===_0x549875['_repoInternal']['repoInfo_']['host']&&xe(_0x4e8db1,_0x25b9b1['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4e2a24;if(_0x25b9b1['repoInfo_']['nodeAdmin'])_0x4e8db1['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4e2a24=new an(an['OWNER']);else{if(_0x4e8db1['mockUserToken']){const _0x42b848=typeof _0x4e8db1['mockUserToken']=='string'?_0x4e8db1['mockUserToken']:uc(_0x4e8db1['mockUserToken'],_0x549875['app']['options']['projectId']);_0x4e2a24=new an(_0x42b848);}}qt(_0x58f625)&&Qr(_0x58f625),Jd(_0x25b9b1,_0x5bbf46,_0x4e8db1,_0x4e2a24);}function N_(_0x4311b2){_0x4311b2=P(_0x4311b2),_0x4311b2['_checkNotDeleted']('goOffline'),ha(_0x4311b2['_repo']);}function O_(_0x5aaccb){_0x5aaccb=P(_0x5aaccb),_0x5aaccb['_checkNotDeleted']('goOnline'),Nd(_0x5aaccb['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x30a314){Ul(dt),st(new Fe('database',(_0x21d37b,{instanceIdentifier:_0x4d445f})=>{const _0x495522=_0x21d37b['getProvider']('app')['getImmediate'](),_0x41752b=_0x21d37b['getProvider']('auth-internal'),_0x5806f3=_0x21d37b['getProvider']('app-check-internal');return Xd(_0x495522,_0x41752b,_0x5806f3,_0x4d445f);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x30a314),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x5c8f29,_0x406ace){this['committed']=_0x5c8f29,this['snapshot']=_0x406ace;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x117369,_0x407212,_0x373649){if(_0x117369=P(_0x117369),Me('Reference.transaction',_0x117369['_path']),_0x117369['key']==='.length'||_0x117369['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x117369['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5d3c39=!0x0,_0x3dfa6e=new H(),_0x44d87b=(_0x5d21bb,_0x5bd3de,_0x1b4538)=>{let _0x5a6613=null;_0x5d21bb?_0x3dfa6e['reject'](_0x5d21bb):(_0x5a6613=new lt(_0x1b4538,new ee(_0x117369['_repo'],_0x117369['_path']),R),_0x3dfa6e['resolve'](new of(_0x5bd3de,_0x5a6613)));},_0x405442=Gd(_0x117369,()=>{});return Od(_0x117369['_repo'],_0x117369['_path'],_0x407212,_0x44d87b,_0x405442,_0x5d3c39),_0x3dfa6e['promise'];}se['prototype']['simpleListen']=function(_0x5611b9,_0x5dbdf2){this['sendRequest']('q',{'p':_0x5611b9},_0x5dbdf2);},se['prototype']['echo']=function(_0x640aa,_0x52441f){this['sendRequest']('echo',{'d':_0x640aa},_0x52441f);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x1104b4,..._0xf7c0f6){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x1104b4,..._0xf7c0f6);}function cn(_0x5510dd,..._0x2d8863){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x5510dd,..._0x2d8863);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x4aa095,..._0x3de472){throw ws(_0x4aa095,..._0x3de472);}function X(_0x14c7fb,..._0x13ea79){return ws(_0x14c7fb,..._0x13ea79);}function Ia(_0x34750f,_0x2aad3c,_0x472920){const _0x48e9e4={...af(),[_0x2aad3c]:_0x472920};return new Gt('auth','Firebase',_0x48e9e4)['create'](_0x2aad3c,{'appName':_0x34750f['name']});}function re(_0x3c27b1){return Ia(_0x3c27b1,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x3fb53c,..._0x2fd94d){if(typeof _0x3fb53c!='string'){const _0x6b04a2=_0x2fd94d[0x0],_0x438b66=[..._0x2fd94d['slice'](0x1)];return _0x438b66[0x0]&&(_0x438b66[0x0]['appName']=_0x3fb53c['name']),_0x3fb53c['_errorFactory']['create'](_0x6b04a2,..._0x438b66);}return Ea['create'](_0x3fb53c,..._0x2fd94d);}function m(_0x396ef0,_0x21049d,..._0x5ce6db){if(!_0x396ef0)throw ws(_0x21049d,..._0x5ce6db);}function ne(_0x4a3d45){const _0xe0d044='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4a3d45;throw cn(_0xe0d044),new Error(_0xe0d044);}function ce(_0x325e80,_0x49c444){_0x325e80||ne(_0x49c444);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x1333c2;return typeof self<'u'&&((_0x1333c2=self['location'])==null?void 0x0:_0x1333c2['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x5456ec;return typeof self<'u'&&((_0x5456ec=self['location'])==null?void 0x0:_0x5456ec['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x226bdf=navigator;return _0x226bdf['languages']&&_0x226bdf['languages'][0x0]||_0x226bdf['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x113be4,_0x51d24c){this['shortDelay']=_0x113be4,this['longDelay']=_0x51d24c,ce(_0x51d24c>_0x113be4,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x1ef58d,_0x15e63a){ce(_0x1ef58d['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x414d04}=_0x1ef58d['emulator'];return _0x15e63a?''+_0x414d04+(_0x15e63a['startsWith']('/')?_0x15e63a['slice'](0x1):_0x15e63a):_0x414d04;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x522c3d,_0x4768db,_0x40531f){this['fetchImpl']=_0x522c3d,_0x4768db&&(this['headersImpl']=_0x4768db),_0x40531f&&(this['responseImpl']=_0x40531f);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x247de9,_0x55c07a){return _0x247de9['tenantId']&&!_0x55c07a['tenantId']?{..._0x55c07a,'tenantId':_0x247de9['tenantId']}:_0x55c07a;}async function Pe(_0x3b7aff,_0x455552,_0x4b4123,_0x38fd70,_0x4937fd={}){return Ca(_0x3b7aff,_0x4937fd,async()=>{let _0x159c5a={},_0x4be815={};_0x38fd70&&(_0x455552==='GET'?_0x4be815=_0x38fd70:_0x159c5a={'body':JSON['stringify'](_0x38fd70)});const _0x3da812=ut({..._0x4be815,'key':_0x3b7aff['config']['apiKey']})['slice'](0x1),_0x302ae2=await _0x3b7aff['_getAdditionalHeaders']();_0x302ae2['Content-Type']='application/json',_0x3b7aff['languageCode']&&(_0x302ae2['X-Firebase-Locale']=_0x3b7aff['languageCode']);const _0x2f8779={'method':_0x455552,'headers':_0x302ae2,..._0x159c5a};return dc()||(_0x2f8779['referrerPolicy']='strict-origin-when-cross-origin'),_0x3b7aff['emulatorConfig']&&qt(_0x3b7aff['emulatorConfig']['host'])&&(_0x2f8779['credentials']='include'),wa['fetch']()(await Ta(_0x3b7aff,_0x3b7aff['config']['apiHost'],_0x4b4123,_0x3da812),_0x2f8779);});}async function Ca(_0x1b9c41,_0x550484,_0x53e4bc){_0x1b9c41['_canInitEmulator']=!0x1;const _0x20d581={...df,..._0x550484};try{const _0x185ea6=new gf(_0x1b9c41),_0x2649c1=await Promise['race']([_0x53e4bc(),_0x185ea6['promise']]);_0x185ea6['clearNetworkTimeout']();const _0x1e42aa=await _0x2649c1['json']();if('needConfirmation'in _0x1e42aa)throw on(_0x1b9c41,'account-exists-with-different-credential',_0x1e42aa);if(_0x2649c1['ok']&&!('errorMessage'in _0x1e42aa))return _0x1e42aa;{const _0x2baa8d=_0x2649c1['ok']?_0x1e42aa['errorMessage']:_0x1e42aa['error']['message'],[_0x316318,_0x341c5a]=_0x2baa8d['split']('\x20:\x20');if(_0x316318==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x1b9c41,'credential-already-in-use',_0x1e42aa);if(_0x316318==='EMAIL_EXISTS')throw on(_0x1b9c41,'email-already-in-use',_0x1e42aa);if(_0x316318==='USER_DISABLED')throw on(_0x1b9c41,'user-disabled',_0x1e42aa);const _0x40e060=_0x20d581[_0x316318]||_0x316318['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x341c5a)throw Ia(_0x1b9c41,_0x40e060,_0x341c5a);Y(_0x1b9c41,_0x40e060);}}catch(_0xa8981b){if(_0xa8981b instanceof Re)throw _0xa8981b;Y(_0x1b9c41,'network-request-failed',{'message':String(_0xa8981b)});}}async function en(_0x1513ad,_0x3a7e0a,_0xe49e5,_0x474ad8,_0xcfd106={}){const _0x2b8ff8=await Pe(_0x1513ad,_0x3a7e0a,_0xe49e5,_0x474ad8,_0xcfd106);return'mfaPendingCredential'in _0x2b8ff8&&Y(_0x1513ad,'multi-factor-auth-required',{'_serverResponse':_0x2b8ff8}),_0x2b8ff8;}async function Ta(_0x242def,_0x3cd028,_0x227016,_0x4a2f37){const _0x3bd0f8=''+_0x3cd028+_0x227016+'?'+_0x4a2f37,_0x32d4c5=_0x242def,_0x360bec=_0x32d4c5['config']['emulator']?Cs(_0x242def['config'],_0x3bd0f8):_0x242def['config']['apiScheme']+'://'+_0x3bd0f8;return ff['includes'](_0x227016)&&(await _0x32d4c5['_persistenceManagerAvailable'],_0x32d4c5['_getPersistenceType']()==='COOKIE')?_0x32d4c5['_getPersistence']()['_getFinalTarget'](_0x360bec)['toString']():_0x360bec;}function _f(_0x29a45c){switch(_0x29a45c){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x26ebd6){this['auth']=_0x26ebd6,this['timer']=null,this['promise']=new Promise((_0x435116,_0x2c090b)=>{this['timer']=setTimeout(()=>_0x2c090b(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x479f86,_0x5f5d61,_0x25bd6a){const _0x28fb34={'appName':_0x479f86['name']};_0x25bd6a['email']&&(_0x28fb34['email']=_0x25bd6a['email']),_0x25bd6a['phoneNumber']&&(_0x28fb34['phoneNumber']=_0x25bd6a['phoneNumber']);const _0x5cc1ea=X(_0x479f86,_0x5f5d61,_0x28fb34);return _0x5cc1ea['customData']['_tokenResponse']=_0x25bd6a,_0x5cc1ea;}function wr(_0x5ed93c){return _0x5ed93c!==void 0x0&&_0x5ed93c['enterprise']!==void 0x0;}class mf{constructor(_0x1c1cd5){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x1c1cd5['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x1c1cd5['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x1c1cd5['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x38903d){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x16d642 of this['recaptchaEnforcementState'])if(_0x16d642['provider']&&_0x16d642['provider']===_0x38903d)return _f(_0x16d642['enforcementState']);return null;}['isProviderEnabled'](_0x368aa1){return this['getProviderEnforcementState'](_0x368aa1)==='ENFORCE'||this['getProviderEnforcementState'](_0x368aa1)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x43bcc6,_0x37ab67){return Pe(_0x43bcc6,'GET','/v2/recaptchaConfig',ke(_0x43bcc6,_0x37ab67));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x598153,_0x380dfb){return Pe(_0x598153,'POST','/v1/accounts:delete',_0x380dfb);}async function Pn(_0x2ee285,_0xa6e2bb){return Pe(_0x2ee285,'POST','/v1/accounts:lookup',_0xa6e2bb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x565185){if(_0x565185)try{const _0x232d9f=new Date(Number(_0x565185));if(!isNaN(_0x232d9f['getTime']()))return _0x232d9f['toUTCString']();}catch{}}async function Ef(_0x3161b6,_0x17b0b1=!0x1){const _0x1c926b=P(_0x3161b6),_0x24bc82=await _0x1c926b['getIdToken'](_0x17b0b1),_0x594b53=Ts(_0x24bc82);m(_0x594b53&&_0x594b53['exp']&&_0x594b53['auth_time']&&_0x594b53['iat'],_0x1c926b['auth'],'internal-error');const _0x28a3cc=typeof _0x594b53['firebase']=='object'?_0x594b53['firebase']:void 0x0,_0x5f59d5=_0x28a3cc==null?void 0x0:_0x28a3cc['sign_in_provider'];return{'claims':_0x594b53,'token':_0x24bc82,'authTime':Pt(fi(_0x594b53['auth_time'])),'issuedAtTime':Pt(fi(_0x594b53['iat'])),'expirationTime':Pt(fi(_0x594b53['exp'])),'signInProvider':_0x5f59d5||null,'signInSecondFactor':(_0x28a3cc==null?void 0x0:_0x28a3cc['sign_in_second_factor'])||null};}function fi(_0x51afb2){return Number(_0x51afb2)*0x3e8;}function Ts(_0x2a0737){const [_0x22cb6d,_0x2e9c01,_0x4aba0e]=_0x2a0737['split']('.');if(_0x22cb6d===void 0x0||_0x2e9c01===void 0x0||_0x4aba0e===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x347907=fn(_0x2e9c01);return _0x347907?JSON['parse'](_0x347907):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x40989b){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x40989b==null?void 0x0:_0x40989b['toString']()),null;}}function Cr(_0x2e02fd){const _0x4896a1=Ts(_0x2e02fd);return m(_0x4896a1,'internal-error'),m(typeof _0x4896a1['exp']<'u','internal-error'),m(typeof _0x4896a1['iat']<'u','internal-error'),Number(_0x4896a1['exp'])-Number(_0x4896a1['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x286a3c,_0x479f0e,_0x547bf9=!0x1){if(_0x547bf9)return _0x479f0e;try{return await _0x479f0e;}catch(_0xeef07e){throw _0xeef07e instanceof Re&&If(_0xeef07e)&&_0x286a3c['auth']['currentUser']===_0x286a3c&&await _0x286a3c['auth']['signOut'](),_0xeef07e;}}function If({code:_0x3d8ca7}){return _0x3d8ca7==='auth/user-disabled'||_0x3d8ca7==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x122ea1){this['user']=_0x122ea1,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2c904a){if(_0x2c904a){const _0x44fdcd=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x44fdcd;}else{this['errorBackoff']=0x7530;const _0x25020e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x25020e);}}['schedule'](_0x2461d1=!0x1){if(!this['isRunning'])return;const _0x4d592b=this['getInterval'](_0x2461d1);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4d592b);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x96d361){(_0x96d361==null?void 0x0:_0x96d361['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x49e633,_0x54694a){this['createdAt']=_0x49e633,this['lastLoginAt']=_0x54694a,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x391a0f){this['createdAt']=_0x391a0f['createdAt'],this['lastLoginAt']=_0x391a0f['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x24fcaa){var _0xd553aa;const _0x46371=_0x24fcaa['auth'],_0x138105=await _0x24fcaa['getIdToken'](),_0x3fc2dc=await Ht(_0x24fcaa,Pn(_0x46371,{'idToken':_0x138105}));m(_0x3fc2dc==null?void 0x0:_0x3fc2dc['users']['length'],_0x46371,'internal-error');const _0x13eeaa=_0x3fc2dc['users'][0x0];_0x24fcaa['_notifyReloadListener'](_0x13eeaa);const _0x32f71f=(_0xd553aa=_0x13eeaa['providerUserInfo'])!=null&&_0xd553aa['length']?Sa(_0x13eeaa['providerUserInfo']):[],_0x1a2f1f=Tf(_0x24fcaa['providerData'],_0x32f71f),_0x316ab2=_0x24fcaa['isAnonymous'],_0x130072=!(_0x24fcaa['email']&&_0x13eeaa['passwordHash'])&&!(_0x1a2f1f!=null&&_0x1a2f1f['length']),_0x26fd07=_0x316ab2?_0x130072:!0x1,_0x3ba379={'uid':_0x13eeaa['localId'],'displayName':_0x13eeaa['displayName']||null,'photoURL':_0x13eeaa['photoUrl']||null,'email':_0x13eeaa['email']||null,'emailVerified':_0x13eeaa['emailVerified']||!0x1,'phoneNumber':_0x13eeaa['phoneNumber']||null,'tenantId':_0x13eeaa['tenantId']||null,'providerData':_0x1a2f1f,'metadata':new Li(_0x13eeaa['createdAt'],_0x13eeaa['lastLoginAt']),'isAnonymous':_0x26fd07};Object['assign'](_0x24fcaa,_0x3ba379);}async function Cf(_0x16bb35){const _0x511dd1=P(_0x16bb35);await Nn(_0x511dd1),await _0x511dd1['auth']['_persistUserIfCurrent'](_0x511dd1),_0x511dd1['auth']['_notifyListenersIfCurrent'](_0x511dd1);}function Tf(_0x319493,_0x414138){return[..._0x319493['filter'](_0x5e12b3=>!_0x414138['some'](_0x5301f6=>_0x5301f6['providerId']===_0x5e12b3['providerId'])),..._0x414138];}function Sa(_0x34771b){return _0x34771b['map'](({providerId:_0x5cec7d,..._0x31eff0})=>({'providerId':_0x5cec7d,'uid':_0x31eff0['rawId']||'','displayName':_0x31eff0['displayName']||null,'email':_0x31eff0['email']||null,'phoneNumber':_0x31eff0['phoneNumber']||null,'photoURL':_0x31eff0['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x628fa7,_0x2b24b5){const _0x19338d=await Ca(_0x628fa7,{},async()=>{const _0x239663=ut({'grant_type':'refresh_token','refresh_token':_0x2b24b5})['slice'](0x1),{tokenApiHost:_0x247bc2,apiKey:_0x398d2d}=_0x628fa7['config'],_0x36424f=await Ta(_0x628fa7,_0x247bc2,'/v1/token','key='+_0x398d2d),_0x3e8ccc=await _0x628fa7['_getAdditionalHeaders']();_0x3e8ccc['Content-Type']='application/x-www-form-urlencoded';const _0x4ad30d={'method':'POST','headers':_0x3e8ccc,'body':_0x239663};return _0x628fa7['emulatorConfig']&&qt(_0x628fa7['emulatorConfig']['host'])&&(_0x4ad30d['credentials']='include'),wa['fetch']()(_0x36424f,_0x4ad30d);});return{'accessToken':_0x19338d['access_token'],'expiresIn':_0x19338d['expires_in'],'refreshToken':_0x19338d['refresh_token']};}async function bf(_0x2adafd,_0x1f484c){return Pe(_0x2adafd,'POST','/v2/accounts:revokeToken',ke(_0x2adafd,_0x1f484c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x294c16){m(_0x294c16['idToken'],'internal-error'),m(typeof _0x294c16['idToken']<'u','internal-error'),m(typeof _0x294c16['refreshToken']<'u','internal-error');const _0x3ca4c1='expiresIn'in _0x294c16&&typeof _0x294c16['expiresIn']<'u'?Number(_0x294c16['expiresIn']):Cr(_0x294c16['idToken']);this['updateTokensAndExpiration'](_0x294c16['idToken'],_0x294c16['refreshToken'],_0x3ca4c1);}['updateFromIdToken'](_0x3c8673){m(_0x3c8673['length']!==0x0,'internal-error');const _0x42be27=Cr(_0x3c8673);this['updateTokensAndExpiration'](_0x3c8673,null,_0x42be27);}async['getToken'](_0x3431c7,_0x482a00=!0x1){return!_0x482a00&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3431c7,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3431c7,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3be1dc,_0x123ce1){const {accessToken:_0xf73d26,refreshToken:_0x58f2d,expiresIn:_0x1ab069}=await Sf(_0x3be1dc,_0x123ce1);this['updateTokensAndExpiration'](_0xf73d26,_0x58f2d,Number(_0x1ab069));}['updateTokensAndExpiration'](_0x34397e,_0x15588e,_0x121a98){this['refreshToken']=_0x15588e||null,this['accessToken']=_0x34397e||null,this['expirationTime']=Date['now']()+_0x121a98*0x3e8;}static['fromJSON'](_0x19bcee,_0x3cba75){const {refreshToken:_0x157199,accessToken:_0x4f871c,expirationTime:_0x4d4cea}=_0x3cba75,_0xb53b1d=new et();return _0x157199&&(m(typeof _0x157199=='string','internal-error',{'appName':_0x19bcee}),_0xb53b1d['refreshToken']=_0x157199),_0x4f871c&&(m(typeof _0x4f871c=='string','internal-error',{'appName':_0x19bcee}),_0xb53b1d['accessToken']=_0x4f871c),_0x4d4cea&&(m(typeof _0x4d4cea=='number','internal-error',{'appName':_0x19bcee}),_0xb53b1d['expirationTime']=_0x4d4cea),_0xb53b1d;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x46dd50){this['accessToken']=_0x46dd50['accessToken'],this['refreshToken']=_0x46dd50['refreshToken'],this['expirationTime']=_0x46dd50['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x2a8fdd,_0x52ce46){m(typeof _0x2a8fdd=='string'||typeof _0x2a8fdd>'u','internal-error',{'appName':_0x52ce46});}class j{constructor({uid:_0x58d7f,auth:_0x86bd8b,stsTokenManager:_0x2b53a7,..._0x16ac2b}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x58d7f,this['auth']=_0x86bd8b,this['stsTokenManager']=_0x2b53a7,this['accessToken']=_0x2b53a7['accessToken'],this['displayName']=_0x16ac2b['displayName']||null,this['email']=_0x16ac2b['email']||null,this['emailVerified']=_0x16ac2b['emailVerified']||!0x1,this['phoneNumber']=_0x16ac2b['phoneNumber']||null,this['photoURL']=_0x16ac2b['photoURL']||null,this['isAnonymous']=_0x16ac2b['isAnonymous']||!0x1,this['tenantId']=_0x16ac2b['tenantId']||null,this['providerData']=_0x16ac2b['providerData']?[..._0x16ac2b['providerData']]:[],this['metadata']=new Li(_0x16ac2b['createdAt']||void 0x0,_0x16ac2b['lastLoginAt']||void 0x0);}async['getIdToken'](_0x16ba33){const _0x9dc7f1=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x16ba33));return m(_0x9dc7f1,this['auth'],'internal-error'),this['accessToken']!==_0x9dc7f1&&(this['accessToken']=_0x9dc7f1,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x9dc7f1;}['getIdTokenResult'](_0xcedd20){return Ef(this,_0xcedd20);}['reload'](){return Cf(this);}['_assign'](_0xcf5dfd){this!==_0xcf5dfd&&(m(this['uid']===_0xcf5dfd['uid'],this['auth'],'internal-error'),this['displayName']=_0xcf5dfd['displayName'],this['photoURL']=_0xcf5dfd['photoURL'],this['email']=_0xcf5dfd['email'],this['emailVerified']=_0xcf5dfd['emailVerified'],this['phoneNumber']=_0xcf5dfd['phoneNumber'],this['isAnonymous']=_0xcf5dfd['isAnonymous'],this['tenantId']=_0xcf5dfd['tenantId'],this['providerData']=_0xcf5dfd['providerData']['map'](_0x3fb8fb=>({..._0x3fb8fb})),this['metadata']['_copy'](_0xcf5dfd['metadata']),this['stsTokenManager']['_assign'](_0xcf5dfd['stsTokenManager']));}['_clone'](_0x165641){const _0x53a2f6=new j({...this,'auth':_0x165641,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x53a2f6['metadata']['_copy'](this['metadata']),_0x53a2f6;}['_onReload'](_0xc9a1f1){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xc9a1f1,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x1cce36){this['reloadListener']?this['reloadListener'](_0x1cce36):this['reloadUserInfo']=_0x1cce36;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4eba74,_0x160f62=!0x1){let _0x231d91=!0x1;_0x4eba74['idToken']&&_0x4eba74['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4eba74),_0x231d91=!0x0),_0x160f62&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x231d91&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x129f45=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x129f45})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x24f429=>({..._0x24f429})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x178431,_0x2a4f62){const _0x515713=_0x2a4f62['displayName']??void 0x0,_0x40d5bf=_0x2a4f62['email']??void 0x0,_0x4668ea=_0x2a4f62['phoneNumber']??void 0x0,_0x138954=_0x2a4f62['photoURL']??void 0x0,_0x2327dd=_0x2a4f62['tenantId']??void 0x0,_0x260bb1=_0x2a4f62['_redirectEventId']??void 0x0,_0x11fd27=_0x2a4f62['createdAt']??void 0x0,_0x3abdca=_0x2a4f62['lastLoginAt']??void 0x0,{uid:_0x19e934,emailVerified:_0x42c1d5,isAnonymous:_0x3e67d7,providerData:_0xd6f2af,stsTokenManager:_0x3c2a26}=_0x2a4f62;m(_0x19e934&&_0x3c2a26,_0x178431,'internal-error');const _0x43d8e7=et['fromJSON'](this['name'],_0x3c2a26);m(typeof _0x19e934=='string',_0x178431,'internal-error'),le(_0x515713,_0x178431['name']),le(_0x40d5bf,_0x178431['name']),m(typeof _0x42c1d5=='boolean',_0x178431,'internal-error'),m(typeof _0x3e67d7=='boolean',_0x178431,'internal-error'),le(_0x4668ea,_0x178431['name']),le(_0x138954,_0x178431['name']),le(_0x2327dd,_0x178431['name']),le(_0x260bb1,_0x178431['name']),le(_0x11fd27,_0x178431['name']),le(_0x3abdca,_0x178431['name']);const _0x39d22f=new j({'uid':_0x19e934,'auth':_0x178431,'email':_0x40d5bf,'emailVerified':_0x42c1d5,'displayName':_0x515713,'isAnonymous':_0x3e67d7,'photoURL':_0x138954,'phoneNumber':_0x4668ea,'tenantId':_0x2327dd,'stsTokenManager':_0x43d8e7,'createdAt':_0x11fd27,'lastLoginAt':_0x3abdca});return _0xd6f2af&&Array['isArray'](_0xd6f2af)&&(_0x39d22f['providerData']=_0xd6f2af['map'](_0x4bba01=>({..._0x4bba01}))),_0x260bb1&&(_0x39d22f['_redirectEventId']=_0x260bb1),_0x39d22f;}static async['_fromIdTokenResponse'](_0x172af7,_0x5cd412,_0x25520f=!0x1){const _0x43e7a3=new et();_0x43e7a3['updateFromServerResponse'](_0x5cd412);const _0x2e55f5=new j({'uid':_0x5cd412['localId'],'auth':_0x172af7,'stsTokenManager':_0x43e7a3,'isAnonymous':_0x25520f});return await Nn(_0x2e55f5),_0x2e55f5;}static async['_fromGetAccountInfoResponse'](_0xba6dac,_0x231354,_0x4b85e6){const _0x221612=_0x231354['users'][0x0];m(_0x221612['localId']!==void 0x0,'internal-error');const _0x2ac6c0=_0x221612['providerUserInfo']!==void 0x0?Sa(_0x221612['providerUserInfo']):[],_0x34f6f0=!(_0x221612['email']&&_0x221612['passwordHash'])&&!(_0x2ac6c0!=null&&_0x2ac6c0['length']),_0x2a6999=new et();_0x2a6999['updateFromIdToken'](_0x4b85e6);const _0x5235f4=new j({'uid':_0x221612['localId'],'auth':_0xba6dac,'stsTokenManager':_0x2a6999,'isAnonymous':_0x34f6f0}),_0x5ac810={'uid':_0x221612['localId'],'displayName':_0x221612['displayName']||null,'photoURL':_0x221612['photoUrl']||null,'email':_0x221612['email']||null,'emailVerified':_0x221612['emailVerified']||!0x1,'phoneNumber':_0x221612['phoneNumber']||null,'tenantId':_0x221612['tenantId']||null,'providerData':_0x2ac6c0,'metadata':new Li(_0x221612['createdAt'],_0x221612['lastLoginAt']),'isAnonymous':!(_0x221612['email']&&_0x221612['passwordHash'])&&!(_0x2ac6c0!=null&&_0x2ac6c0['length'])};return Object['assign'](_0x5235f4,_0x5ac810),_0x5235f4;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x28cba5){ce(_0x28cba5 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1498e6=Tr['get'](_0x28cba5);return _0x1498e6?(ce(_0x1498e6 instanceof _0x28cba5,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1498e6):(_0x1498e6=new _0x28cba5(),Tr['set'](_0x28cba5,_0x1498e6),_0x1498e6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x4952f0,_0x32a217){this['storage'][_0x4952f0]=_0x32a217;}async['_get'](_0x407789){const _0xc9483d=this['storage'][_0x407789];return _0xc9483d===void 0x0?null:_0xc9483d;}async['_remove'](_0xb0cce7){delete this['storage'][_0xb0cce7];}['_addListener'](_0x577368,_0xbaec73){}['_removeListener'](_0x3c1cab,_0x418287){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x3ec500,_0x26a35d,_0x2c6347){return'firebase:'+_0x3ec500+':'+_0x26a35d+':'+_0x2c6347;}class tt{constructor(_0x5c36ff,_0x4bddef,_0x3b4e6b){this['persistence']=_0x5c36ff,this['auth']=_0x4bddef,this['userKey']=_0x3b4e6b;const {config:_0x127ca7,name:_0x528f51}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x127ca7['apiKey'],_0x528f51),this['fullPersistenceKey']=ln('persistence',_0x127ca7['apiKey'],_0x528f51),this['boundEventHandler']=_0x4bddef['_onStorageEvent']['bind'](_0x4bddef),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3ef8b2){return this['persistence']['_set'](this['fullUserKey'],_0x3ef8b2['toJSON']());}async['getCurrentUser'](){const _0x52cd2a=await this['persistence']['_get'](this['fullUserKey']);if(!_0x52cd2a)return null;if(typeof _0x52cd2a=='string'){const _0xb40b7=await Pn(this['auth'],{'idToken':_0x52cd2a})['catch'](()=>{});return _0xb40b7?j['_fromGetAccountInfoResponse'](this['auth'],_0xb40b7,_0x52cd2a):null;}return j['_fromJSON'](this['auth'],_0x52cd2a);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1502d8){if(this['persistence']===_0x1502d8)return;const _0x59447d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1502d8,_0x59447d)return this['setCurrentUser'](_0x59447d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x35ae5f,_0x7b665f,_0x9cf72f='authUser'){if(!_0x7b665f['length'])return new tt(ie(Sr),_0x35ae5f,_0x9cf72f);const _0x3799a9=(await Promise['all'](_0x7b665f['map'](async _0x384ced=>{if(await _0x384ced['_isAvailable']())return _0x384ced;})))['filter'](_0x460a63=>_0x460a63);let _0x517df6=_0x3799a9[0x0]||ie(Sr);const _0x18288b=ln(_0x9cf72f,_0x35ae5f['config']['apiKey'],_0x35ae5f['name']);let _0x4ef32b=null;for(const _0x5bf16c of _0x7b665f)try{const _0x3e8d12=await _0x5bf16c['_get'](_0x18288b);if(_0x3e8d12){let _0x3db7ac;if(typeof _0x3e8d12=='string'){const _0x30c511=await Pn(_0x35ae5f,{'idToken':_0x3e8d12})['catch'](()=>{});if(!_0x30c511)break;_0x3db7ac=await j['_fromGetAccountInfoResponse'](_0x35ae5f,_0x30c511,_0x3e8d12);}else _0x3db7ac=j['_fromJSON'](_0x35ae5f,_0x3e8d12);_0x5bf16c!==_0x517df6&&(_0x4ef32b=_0x3db7ac),_0x517df6=_0x5bf16c;break;}}catch{}const _0x157226=_0x3799a9['filter'](_0x3ab0cd=>_0x3ab0cd['_shouldAllowMigration']);return!_0x517df6['_shouldAllowMigration']||!_0x157226['length']?new tt(_0x517df6,_0x35ae5f,_0x9cf72f):(_0x517df6=_0x157226[0x0],_0x4ef32b&&await _0x517df6['_set'](_0x18288b,_0x4ef32b['toJSON']()),await Promise['all'](_0x7b665f['map'](async _0x4defb7=>{if(_0x4defb7!==_0x517df6)try{await _0x4defb7['_remove'](_0x18288b);}catch{}})),new tt(_0x517df6,_0x35ae5f,_0x9cf72f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0xf621b3){const _0x1c81e0=_0xf621b3['toLowerCase']();if(_0x1c81e0['includes']('opera/')||_0x1c81e0['includes']('opr/')||_0x1c81e0['includes']('opios/'))return'Opera';if(Pa(_0x1c81e0))return'IEMobile';if(_0x1c81e0['includes']('msie')||_0x1c81e0['includes']('trident/'))return'IE';if(_0x1c81e0['includes']('edge/'))return'Edge';if(Ra(_0x1c81e0))return'Firefox';if(_0x1c81e0['includes']('silk/'))return'Silk';if(Oa(_0x1c81e0))return'Blackberry';if(Da(_0x1c81e0))return'Webos';if(Aa(_0x1c81e0))return'Safari';if((_0x1c81e0['includes']('chrome/')||ka(_0x1c81e0))&&!_0x1c81e0['includes']('edge/'))return'Chrome';if(Na(_0x1c81e0))return'Android';{const _0x12a184=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3f44ff=_0xf621b3['match'](_0x12a184);if((_0x3f44ff==null?void 0x0:_0x3f44ff['length'])===0x2)return _0x3f44ff[0x1];}return'Other';}function Ra(_0x2d9a48=W()){return/firefox\//i['test'](_0x2d9a48);}function Aa(_0x57ee82=W()){const _0x292077=_0x57ee82['toLowerCase']();return _0x292077['includes']('safari/')&&!_0x292077['includes']('chrome/')&&!_0x292077['includes']('crios/')&&!_0x292077['includes']('android');}function ka(_0x34679e=W()){return/crios\//i['test'](_0x34679e);}function Pa(_0x5ba760=W()){return/iemobile/i['test'](_0x5ba760);}function Na(_0x1ee437=W()){return/android/i['test'](_0x1ee437);}function Oa(_0x5ce690=W()){return/blackberry/i['test'](_0x5ce690);}function Da(_0x1484a5=W()){return/webos/i['test'](_0x1484a5);}function Ss(_0x20a4aa=W()){return/iphone|ipad|ipod/i['test'](_0x20a4aa)||/macintosh/i['test'](_0x20a4aa)&&/mobile/i['test'](_0x20a4aa);}function Rf(_0xe4007c=W()){var _0x469c8d;return Ss(_0xe4007c)&&!!((_0x469c8d=window['navigator'])!=null&&_0x469c8d['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x150f55=W()){return Ss(_0x150f55)||Na(_0x150f55)||Da(_0x150f55)||Oa(_0x150f55)||/windows phone/i['test'](_0x150f55)||Pa(_0x150f55);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x423c18,_0x7c3712=[]){let _0x40c750;switch(_0x423c18){case'Browser':_0x40c750=br(W());break;case'Worker':_0x40c750=br(W())+'-'+_0x423c18;break;default:_0x40c750=_0x423c18;}const _0x414e3b=_0x7c3712['length']?_0x7c3712['join'](','):'FirebaseCore-web';return _0x40c750+'/JsCore/'+dt+'/'+_0x414e3b;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x58d019){this['auth']=_0x58d019,this['queue']=[];}['pushCallback'](_0x14cb37,_0x18a4a3){const _0x19f6a4=_0x1679f0=>new Promise((_0x3f1db2,_0x5b248b)=>{try{const _0x2bac4a=_0x14cb37(_0x1679f0);_0x3f1db2(_0x2bac4a);}catch(_0x50f35c){_0x5b248b(_0x50f35c);}});_0x19f6a4['onAbort']=_0x18a4a3,this['queue']['push'](_0x19f6a4);const _0x48fb41=this['queue']['length']-0x1;return()=>{this['queue'][_0x48fb41]=()=>Promise['resolve']();};}async['runMiddleware'](_0x31d76d){if(this['auth']['currentUser']===_0x31d76d)return;const _0x5a0280=[];try{for(const _0x2510a5 of this['queue'])await _0x2510a5(_0x31d76d),_0x2510a5['onAbort']&&_0x5a0280['push'](_0x2510a5['onAbort']);}catch(_0x24eaf8){_0x5a0280['reverse']();for(const _0x4ba87d of _0x5a0280)try{_0x4ba87d();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x24eaf8==null?void 0x0:_0x24eaf8['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x13afd0,_0x1a8102={}){return Pe(_0x13afd0,'GET','/v2/passwordPolicy',ke(_0x13afd0,_0x1a8102));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x4910c2){var _0x22ee29;const _0x2081c7=_0x4910c2['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x2081c7['minPasswordLength']??Nf,_0x2081c7['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x2081c7['maxPasswordLength']),_0x2081c7['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x2081c7['containsLowercaseCharacter']),_0x2081c7['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x2081c7['containsUppercaseCharacter']),_0x2081c7['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x2081c7['containsNumericCharacter']),_0x2081c7['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x2081c7['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4910c2['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x22ee29=_0x4910c2['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x22ee29['join'](''))??'',this['forceUpgradeOnSignin']=_0x4910c2['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4910c2['schemaVersion'];}['validatePassword'](_0x4b98f9){const _0x477dc8={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4b98f9,_0x477dc8),this['validatePasswordCharacterOptions'](_0x4b98f9,_0x477dc8),_0x477dc8['isValid']&&(_0x477dc8['isValid']=_0x477dc8['meetsMinPasswordLength']??!0x0),_0x477dc8['isValid']&&(_0x477dc8['isValid']=_0x477dc8['meetsMaxPasswordLength']??!0x0),_0x477dc8['isValid']&&(_0x477dc8['isValid']=_0x477dc8['containsLowercaseLetter']??!0x0),_0x477dc8['isValid']&&(_0x477dc8['isValid']=_0x477dc8['containsUppercaseLetter']??!0x0),_0x477dc8['isValid']&&(_0x477dc8['isValid']=_0x477dc8['containsNumericCharacter']??!0x0),_0x477dc8['isValid']&&(_0x477dc8['isValid']=_0x477dc8['containsNonAlphanumericCharacter']??!0x0),_0x477dc8;}['validatePasswordLengthOptions'](_0x5f2e02,_0x500a91){const _0x5e4fcc=this['customStrengthOptions']['minPasswordLength'],_0x2a45e0=this['customStrengthOptions']['maxPasswordLength'];_0x5e4fcc&&(_0x500a91['meetsMinPasswordLength']=_0x5f2e02['length']>=_0x5e4fcc),_0x2a45e0&&(_0x500a91['meetsMaxPasswordLength']=_0x5f2e02['length']<=_0x2a45e0);}['validatePasswordCharacterOptions'](_0x1c088e,_0x2d0997){this['updatePasswordCharacterOptionsStatuses'](_0x2d0997,!0x1,!0x1,!0x1,!0x1);let _0x253590;for(let _0x3b665b=0x0;_0x3b665b<_0x1c088e['length'];_0x3b665b++)_0x253590=_0x1c088e['charAt'](_0x3b665b),this['updatePasswordCharacterOptionsStatuses'](_0x2d0997,_0x253590>='a'&&_0x253590<='z',_0x253590>='A'&&_0x253590<='Z',_0x253590>='0'&&_0x253590<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x253590));}['updatePasswordCharacterOptionsStatuses'](_0x40f23a,_0x1fe2f3,_0x199298,_0x163522,_0x7e6956){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x40f23a['containsLowercaseLetter']||(_0x40f23a['containsLowercaseLetter']=_0x1fe2f3)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x40f23a['containsUppercaseLetter']||(_0x40f23a['containsUppercaseLetter']=_0x199298)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x40f23a['containsNumericCharacter']||(_0x40f23a['containsNumericCharacter']=_0x163522)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x40f23a['containsNonAlphanumericCharacter']||(_0x40f23a['containsNonAlphanumericCharacter']=_0x7e6956));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x242621,_0x19f9b8,_0x5ce5d9,_0x2aa739){this['app']=_0x242621,this['heartbeatServiceProvider']=_0x19f9b8,this['appCheckServiceProvider']=_0x5ce5d9,this['config']=_0x2aa739,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x242621['name'],this['clientVersion']=_0x2aa739['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x30087b=>this['_resolvePersistenceManagerAvailable']=_0x30087b);}['_initializeWithPersistence'](_0x143078,_0x1a19d5){return _0x1a19d5&&(this['_popupRedirectResolver']=ie(_0x1a19d5)),this['_initializationPromise']=this['queue'](async()=>{var _0x22224f,_0x2cfcad,_0xb4b654;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x143078),(_0x22224f=this['_resolvePersistenceManagerAvailable'])==null||_0x22224f['call'](this),!this['_deleted'])){if((_0x2cfcad=this['_popupRedirectResolver'])!=null&&_0x2cfcad['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1a19d5),this['lastNotifiedUid']=((_0xb4b654=this['currentUser'])==null?void 0x0:_0xb4b654['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x790559=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x790559)){if(this['currentUser']&&_0x790559&&this['currentUser']['uid']===_0x790559['uid']){this['_currentUser']['_assign'](_0x790559),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x790559,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3dc700){try{const _0x3c91c8=await Pn(this,{'idToken':_0x3dc700}),_0x987189=await j['_fromGetAccountInfoResponse'](this,_0x3c91c8,_0x3dc700);await this['directlySetCurrentUser'](_0x987189);}catch(_0x178f2e){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x178f2e),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5c0ea7){var _0x5e1ba5;if($(this['app'])){const _0x2cf160=this['app']['settings']['authIdToken'];return _0x2cf160?new Promise(_0x405c69=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2cf160)['then'](_0x405c69,_0x405c69));}):this['directlySetCurrentUser'](null);}const _0x351b96=await this['assertedPersistence']['getCurrentUser']();let _0x46e984=_0x351b96,_0x6c0f4f=!0x1;if(_0x5c0ea7&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x59cd19=(_0x5e1ba5=this['redirectUser'])==null?void 0x0:_0x5e1ba5['_redirectEventId'],_0x3dc11f=_0x46e984==null?void 0x0:_0x46e984['_redirectEventId'],_0x5e1a06=await this['tryRedirectSignIn'](_0x5c0ea7);(!_0x59cd19||_0x59cd19===_0x3dc11f)&&(_0x5e1a06!=null&&_0x5e1a06['user'])&&(_0x46e984=_0x5e1a06['user'],_0x6c0f4f=!0x0);}if(!_0x46e984)return this['directlySetCurrentUser'](null);if(!_0x46e984['_redirectEventId']){if(_0x6c0f4f)try{await this['beforeStateQueue']['runMiddleware'](_0x46e984);}catch(_0x2b7e67){_0x46e984=_0x351b96,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2b7e67));}return _0x46e984?this['reloadAndSetCurrentUserOrClear'](_0x46e984):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x46e984['_redirectEventId']?this['directlySetCurrentUser'](_0x46e984):this['reloadAndSetCurrentUserOrClear'](_0x46e984);}async['tryRedirectSignIn'](_0x40bebd){let _0x462b54=null;try{_0x462b54=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x40bebd,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x462b54;}async['reloadAndSetCurrentUserOrClear'](_0x3af265){try{await Nn(_0x3af265);}catch(_0x3eb1cc){if((_0x3eb1cc==null?void 0x0:_0x3eb1cc['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3af265);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0xc91871){if($(this['app']))return Promise['reject'](re(this));const _0xf2ebac=_0xc91871?P(_0xc91871):null;return _0xf2ebac&&m(_0xf2ebac['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0xf2ebac&&_0xf2ebac['_clone'](this));}async['_updateCurrentUser'](_0x95e355,_0x25696d=!0x1){if(!this['_deleted'])return _0x95e355&&m(this['tenantId']===_0x95e355['tenantId'],this,'tenant-id-mismatch'),_0x25696d||await this['beforeStateQueue']['runMiddleware'](_0x95e355),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x95e355),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3a274f){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3a274f));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2ba241){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5dd51d=this['_getPasswordPolicyInternal']();return _0x5dd51d['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5dd51d['validatePassword'](_0x2ba241);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x49a8b1=await Pf(this),_0x4f73d2=new Of(_0x49a8b1);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4f73d2:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4f73d2;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x3e2a70){this['_errorFactory']=new Gt('auth','Firebase',_0x3e2a70());}['onAuthStateChanged'](_0x4d7b32,_0x524b0b,_0x1679b3){return this['registerStateListener'](this['authStateSubscription'],_0x4d7b32,_0x524b0b,_0x1679b3);}['beforeAuthStateChanged'](_0x503e15,_0x28f085){return this['beforeStateQueue']['pushCallback'](_0x503e15,_0x28f085);}['onIdTokenChanged'](_0x44db6e,_0xcbf248,_0xfc861){return this['registerStateListener'](this['idTokenSubscription'],_0x44db6e,_0xcbf248,_0xfc861);}['authStateReady'](){return new Promise((_0x1102d7,_0x5ba605)=>{if(this['currentUser'])_0x1102d7();else{const _0x1b7ad1=this['onAuthStateChanged'](()=>{_0x1b7ad1(),_0x1102d7();},_0x5ba605);}});}async['revokeAccessToken'](_0x6f626d){if(this['currentUser']){const _0x17a278=await this['currentUser']['getIdToken'](),_0x2db0aa={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x6f626d,'idToken':_0x17a278};this['tenantId']!=null&&(_0x2db0aa['tenantId']=this['tenantId']),await bf(this,_0x2db0aa);}}['toJSON'](){var _0x325b06;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x325b06=this['_currentUser'])==null?void 0x0:_0x325b06['toJSON']()};}async['_setRedirectUser'](_0x57491b,_0x3a22b5){const _0x5ec7de=await this['getOrInitRedirectPersistenceManager'](_0x3a22b5);return _0x57491b===null?_0x5ec7de['removeCurrentUser']():_0x5ec7de['setCurrentUser'](_0x57491b);}async['getOrInitRedirectPersistenceManager'](_0x13ef8a){if(!this['redirectPersistenceManager']){const _0x29a682=_0x13ef8a&&ie(_0x13ef8a)||this['_popupRedirectResolver'];m(_0x29a682,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x29a682['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2ce694){var _0xaaefcb,_0x121d0c;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0xaaefcb=this['_currentUser'])==null?void 0x0:_0xaaefcb['_redirectEventId'])===_0x2ce694?this['_currentUser']:((_0x121d0c=this['redirectUser'])==null?void 0x0:_0x121d0c['_redirectEventId'])===_0x2ce694?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2f4f48){if(_0x2f4f48===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2f4f48));}['_notifyListenersIfCurrent'](_0x5a33ec){_0x5a33ec===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x24108f;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x985c43=((_0x24108f=this['currentUser'])==null?void 0x0:_0x24108f['uid'])??null;this['lastNotifiedUid']!==_0x985c43&&(this['lastNotifiedUid']=_0x985c43,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x39461c,_0x37c158,_0x17bc06,_0x146437){if(this['_deleted'])return()=>{};const _0x1c4429=typeof _0x37c158=='function'?_0x37c158:_0x37c158['next']['bind'](_0x37c158);let _0x4a24e6=!0x1;const _0x59bcbb=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x59bcbb,this,'internal-error'),_0x59bcbb['then'](()=>{_0x4a24e6||_0x1c4429(this['currentUser']);}),typeof _0x37c158=='function'){const _0x430f82=_0x39461c['addObserver'](_0x37c158,_0x17bc06,_0x146437);return()=>{_0x4a24e6=!0x0,_0x430f82();};}else{const _0x5aed73=_0x39461c['addObserver'](_0x37c158);return()=>{_0x4a24e6=!0x0,_0x5aed73();};}}async['directlySetCurrentUser'](_0xbcbed2){this['currentUser']&&this['currentUser']!==_0xbcbed2&&this['_currentUser']['_stopProactiveRefresh'](),_0xbcbed2&&this['isProactiveRefreshEnabled']&&_0xbcbed2['_startProactiveRefresh'](),this['currentUser']=_0xbcbed2,_0xbcbed2?await this['assertedPersistence']['setCurrentUser'](_0xbcbed2):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3e5374){return this['operations']=this['operations']['then'](_0x3e5374,_0x3e5374),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x2ebfef){!_0x2ebfef||this['frameworks']['includes'](_0x2ebfef)||(this['frameworks']['push'](_0x2ebfef),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x3a7eac;const _0x513db={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x513db['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x5d719c=await((_0x3a7eac=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3a7eac['getHeartbeatsHeader']());_0x5d719c&&(_0x513db['X-Firebase-Client']=_0x5d719c);const _0x59ce38=await this['_getAppCheckToken']();return _0x59ce38&&(_0x513db['X-Firebase-AppCheck']=_0x59ce38),_0x513db;}async['_getAppCheckToken'](){var _0x35b8bd;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5be668=await((_0x35b8bd=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x35b8bd['getToken']());return _0x5be668!=null&&_0x5be668['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5be668['error']),_0x5be668==null?void 0x0:_0x5be668['token'];}}function Ke(_0xd046d4){return P(_0xd046d4);}class Rr{constructor(_0x30cd00){this['auth']=_0x30cd00,this['observer']=null,this['addObserver']=Tc(_0x26f4b0=>this['observer']=_0x26f4b0);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x3937a9){Jn=_0x3937a9;}function xa(_0x3d2705){return Jn['loadJS'](_0x3d2705);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x24a44c){return'__'+_0x24a44c+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x165e6f){_0x165e6f();}['execute'](_0x4247cb,_0x58d65f){return Promise['resolve']('token');}['render'](_0x49c0da,_0x24a49c){return'';}}class Wf{['ready'](_0x3735ba){_0x3735ba();}['execute'](_0x874e3b,_0x3c9af5){return Promise['resolve']('token');}['render'](_0x1a31ad,_0x5bbfcc){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x10c24a){this['type']=Bf,this['auth']=Ke(_0x10c24a);}async['verify'](_0x21a677='verify',_0x4366c8=!0x1){async function _0x15ac9d(_0x14bac9){if(!_0x4366c8){if(_0x14bac9['tenantId']==null&&_0x14bac9['_agentRecaptchaConfig']!=null)return _0x14bac9['_agentRecaptchaConfig']['siteKey'];if(_0x14bac9['tenantId']!=null&&_0x14bac9['_tenantRecaptchaConfigs'][_0x14bac9['tenantId']]!==void 0x0)return _0x14bac9['_tenantRecaptchaConfigs'][_0x14bac9['tenantId']]['siteKey'];}return new Promise(async(_0x437e55,_0x541c63)=>{yf(_0x14bac9,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x513154=>{if(_0x513154['recaptchaKey']===void 0x0)_0x541c63(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5c9934=new mf(_0x513154);return _0x14bac9['tenantId']==null?_0x14bac9['_agentRecaptchaConfig']=_0x5c9934:_0x14bac9['_tenantRecaptchaConfigs'][_0x14bac9['tenantId']]=_0x5c9934,_0x437e55(_0x5c9934['siteKey']);}})['catch'](_0x32ec24=>{_0x541c63(_0x32ec24);});});}function _0x27a0a1(_0x531b4a,_0x11900b,_0x40aeb8){const _0x56825b=window['grecaptcha'];wr(_0x56825b)?_0x56825b['enterprise']['ready'](()=>{_0x56825b['enterprise']['execute'](_0x531b4a,{'action':_0x21a677})['then'](_0x143c98=>{_0x11900b(_0x143c98);})['catch'](()=>{_0x11900b(Fa);});}):_0x40aeb8(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x15c87e,_0x32b0f3)=>{_0x15ac9d(this['auth'])['then'](async _0x47d917=>{if(!_0x4366c8&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x27a0a1(_0x47d917,_0x15c87e,_0x32b0f3);else{if(typeof window>'u'){_0x32b0f3(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4f5c95=Lf();_0x4f5c95['length']!==0x0&&(_0x4f5c95+=_0x47d917+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x2a6283;(_0x2a6283=he['scriptInjectionDeferred'])==null||_0x2a6283['resolve']();},xa(_0x4f5c95)['then'](()=>{var _0x2c428a;return(_0x2c428a=he['scriptInjectionDeferred'])==null?void 0x0:_0x2c428a['promise'];})['then'](()=>{_0x27a0a1(_0x47d917,_0x15c87e,_0x32b0f3);})['catch'](_0x377a0a=>{_0x32b0f3(_0x377a0a);});}})['catch'](_0x3118ea=>{_0x32b0f3(_0x3118ea);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x44a642,_0x3ec96c,_0x33f498,_0x334074=!0x1,_0x5c3ecc=!0x1){const _0x21c6cc=new he(_0x44a642);let _0x2944b3;if(_0x5c3ecc)_0x2944b3=Fa;else try{_0x2944b3=await _0x21c6cc['verify'](_0x33f498);}catch{_0x2944b3=await _0x21c6cc['verify'](_0x33f498,!0x0);}const _0x3ebe60={..._0x3ec96c};if(_0x33f498==='mfaSmsEnrollment'||_0x33f498==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3ebe60){const _0x3f40b4=_0x3ebe60['phoneEnrollmentInfo']['phoneNumber'],_0x121af6=_0x3ebe60['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3ebe60,{'phoneEnrollmentInfo':{'phoneNumber':_0x3f40b4,'recaptchaToken':_0x121af6,'captchaResponse':_0x2944b3,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3ebe60){const _0x3d133b=_0x3ebe60['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3ebe60,{'phoneSignInInfo':{'recaptchaToken':_0x3d133b,'captchaResponse':_0x2944b3,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3ebe60;}return _0x334074?Object['assign'](_0x3ebe60,{'captchaResp':_0x2944b3}):Object['assign'](_0x3ebe60,{'captchaResponse':_0x2944b3}),Object['assign'](_0x3ebe60,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3ebe60,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3ebe60;}async function xi(_0x482687,_0x24c948,_0x41592e,_0x1a1054,_0x47cdb3){var _0x217792;if((_0x217792=_0x482687['_getRecaptchaConfig']())!=null&&_0x217792['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x48e229=await kr(_0x482687,_0x24c948,_0x41592e,_0x41592e==='getOobCode');return _0x1a1054(_0x482687,_0x48e229);}else return _0x1a1054(_0x482687,_0x24c948)['catch'](async _0x2a6774=>{if(_0x2a6774['code']==='auth/missing-recaptcha-token'){console['log'](_0x41592e+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4a61dc=await kr(_0x482687,_0x24c948,_0x41592e,_0x41592e==='getOobCode');return _0x1a1054(_0x482687,_0x4a61dc);}else return Promise['reject'](_0x2a6774);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0xf124ca,_0x389d5d){const _0x28ddf8=Hi(_0xf124ca,'auth');if(_0x28ddf8['isInitialized']()){const _0x3a00cb=_0x28ddf8['getImmediate'](),_0x2db889=_0x28ddf8['getOptions']();if(xe(_0x2db889,_0x389d5d??{}))return _0x3a00cb;Y(_0x3a00cb,'already-initialized');}return _0x28ddf8['initialize']({'options':_0x389d5d});}function Hf(_0x3b51c8,_0x41f08b){const _0x177194=(_0x41f08b==null?void 0x0:_0x41f08b['persistence'])||[],_0x5ce033=(Array['isArray'](_0x177194)?_0x177194:[_0x177194])['map'](ie);_0x41f08b!=null&&_0x41f08b['errorMap']&&_0x3b51c8['_updateErrorMap'](_0x41f08b['errorMap']),_0x3b51c8['_initializeWithPersistence'](_0x5ce033,_0x41f08b==null?void 0x0:_0x41f08b['popupRedirectResolver']);}function $f(_0x6a49b5,_0x21af3a,_0x281890){const _0x3c0d63=Ke(_0x6a49b5);m(/^https?:\/\//['test'](_0x21af3a),_0x3c0d63,'invalid-emulator-scheme');const _0x3d6aae=!0x1,_0x5992b8=Ua(_0x21af3a),{host:_0xfc262b,port:_0x3d4e96}=Gf(_0x21af3a),_0x835a2a=_0x3d4e96===null?'':':'+_0x3d4e96,_0x83aca9={'url':_0x5992b8+'//'+_0xfc262b+_0x835a2a+'/'},_0xa6dec7=Object['freeze']({'host':_0xfc262b,'port':_0x3d4e96,'protocol':_0x5992b8['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3d6aae})});if(!_0x3c0d63['_canInitEmulator']){m(_0x3c0d63['config']['emulator']&&_0x3c0d63['emulatorConfig'],_0x3c0d63,'emulator-config-failed'),m(xe(_0x83aca9,_0x3c0d63['config']['emulator'])&&xe(_0xa6dec7,_0x3c0d63['emulatorConfig']),_0x3c0d63,'emulator-config-failed');return;}_0x3c0d63['config']['emulator']=_0x83aca9,_0x3c0d63['emulatorConfig']=_0xa6dec7,_0x3c0d63['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0xfc262b)?Qr(_0x5992b8+'//'+_0xfc262b+_0x835a2a):qf();}function Ua(_0x5c4d17){const _0x1f64f0=_0x5c4d17['indexOf'](':');return _0x1f64f0<0x0?'':_0x5c4d17['substr'](0x0,_0x1f64f0+0x1);}function Gf(_0x471ab9){const _0x1b68ad=Ua(_0x471ab9),_0x179e95=/(\/\/)?([^?#/]+)/['exec'](_0x471ab9['substr'](_0x1b68ad['length']));if(!_0x179e95)return{'host':'','port':null};const _0x2a3d12=_0x179e95[0x2]['split']('@')['pop']()||'',_0x5baee3=/^(\[[^\]]+\])(:|$)/['exec'](_0x2a3d12);if(_0x5baee3){const _0x4294ea=_0x5baee3[0x1];return{'host':_0x4294ea,'port':Pr(_0x2a3d12['substr'](_0x4294ea['length']+0x1))};}else{const [_0x386f63,_0x3eecdf]=_0x2a3d12['split'](':');return{'host':_0x386f63,'port':Pr(_0x3eecdf)};}}function Pr(_0x1b2af5){if(!_0x1b2af5)return null;const _0x31ddac=Number(_0x1b2af5);return isNaN(_0x31ddac)?null:_0x31ddac;}function qf(){function _0x38d674(){const _0x490ed3=document['createElement']('p'),_0xde3db8=_0x490ed3['style'];_0x490ed3['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xde3db8['position']='fixed',_0xde3db8['width']='100%',_0xde3db8['backgroundColor']='#ffffff',_0xde3db8['border']='.1em\x20solid\x20#000000',_0xde3db8['color']='#b50000',_0xde3db8['bottom']='0px',_0xde3db8['left']='0px',_0xde3db8['margin']='0px',_0xde3db8['zIndex']='10000',_0xde3db8['textAlign']='center',_0x490ed3['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x490ed3);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x38d674):_0x38d674());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x1d4d2c,_0x4c2ff7){this['providerId']=_0x1d4d2c,this['signInMethod']=_0x4c2ff7;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x402ef4){return ne('not\x20implemented');}['_linkToIdToken'](_0x418381,_0xbf78a9){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xdc66bf){return ne('not\x20implemented');}}async function zf(_0x4c6042,_0x9e2f0){return Pe(_0x4c6042,'POST','/v1/accounts:signUp',_0x9e2f0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x58b71c,_0x35bd1c){return en(_0x58b71c,'POST','/v1/accounts:signInWithPassword',ke(_0x58b71c,_0x35bd1c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x30631f,_0x5d9801){return en(_0x30631f,'POST','/v1/accounts:signInWithEmailLink',ke(_0x30631f,_0x5d9801));}async function Yf(_0x5d8a68,_0x553b41){return en(_0x5d8a68,'POST','/v1/accounts:signInWithEmailLink',ke(_0x5d8a68,_0x553b41));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x213abc,_0x597d1f,_0x3dfcf1,_0x37a553=null){super('password',_0x3dfcf1),this['_email']=_0x213abc,this['_password']=_0x597d1f,this['_tenantId']=_0x37a553;}static['_fromEmailAndPassword'](_0x27135a,_0x65b9a1){return new $t(_0x27135a,_0x65b9a1,'password');}static['_fromEmailAndCode'](_0x2647ce,_0x508792,_0x21dc24=null){return new $t(_0x2647ce,_0x508792,'emailLink',_0x21dc24);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x72cc03){const _0x2e70b5=typeof _0x72cc03=='string'?JSON['parse'](_0x72cc03):_0x72cc03;if(_0x2e70b5!=null&&_0x2e70b5['email']&&(_0x2e70b5!=null&&_0x2e70b5['password'])){if(_0x2e70b5['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2e70b5['email'],_0x2e70b5['password']);if(_0x2e70b5['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2e70b5['email'],_0x2e70b5['password'],_0x2e70b5['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2dad73){switch(this['signInMethod']){case'password':const _0x514947={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2dad73,_0x514947,'signInWithPassword',jf);case'emailLink':return Kf(_0x2dad73,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2dad73,'internal-error');}}async['_linkToIdToken'](_0x262f07,_0x58f374){switch(this['signInMethod']){case'password':const _0x3cbb47={'idToken':_0x58f374,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x262f07,_0x3cbb47,'signUpPassword',zf);case'emailLink':return Yf(_0x262f07,{'idToken':_0x58f374,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x262f07,'internal-error');}}['_getReauthenticationResolver'](_0x2331d3){return this['_getIdTokenResponse'](_0x2331d3);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x5edce8,_0x2dce6a){return en(_0x5edce8,'POST','/v1/accounts:signInWithIdp',ke(_0x5edce8,_0x2dce6a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3702a7){const _0x494ddd=new $e(_0x3702a7['providerId'],_0x3702a7['signInMethod']);return _0x3702a7['idToken']||_0x3702a7['accessToken']?(_0x3702a7['idToken']&&(_0x494ddd['idToken']=_0x3702a7['idToken']),_0x3702a7['accessToken']&&(_0x494ddd['accessToken']=_0x3702a7['accessToken']),_0x3702a7['nonce']&&!_0x3702a7['pendingToken']&&(_0x494ddd['nonce']=_0x3702a7['nonce']),_0x3702a7['pendingToken']&&(_0x494ddd['pendingToken']=_0x3702a7['pendingToken'])):_0x3702a7['oauthToken']&&_0x3702a7['oauthTokenSecret']?(_0x494ddd['accessToken']=_0x3702a7['oauthToken'],_0x494ddd['secret']=_0x3702a7['oauthTokenSecret']):Y('argument-error'),_0x494ddd;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x4c517e){const _0x1182f3=typeof _0x4c517e=='string'?JSON['parse'](_0x4c517e):_0x4c517e,{providerId:_0x2ab679,signInMethod:_0x59c884,..._0x54ed03}=_0x1182f3;if(!_0x2ab679||!_0x59c884)return null;const _0x3106cc=new $e(_0x2ab679,_0x59c884);return _0x3106cc['idToken']=_0x54ed03['idToken']||void 0x0,_0x3106cc['accessToken']=_0x54ed03['accessToken']||void 0x0,_0x3106cc['secret']=_0x54ed03['secret'],_0x3106cc['nonce']=_0x54ed03['nonce'],_0x3106cc['pendingToken']=_0x54ed03['pendingToken']||null,_0x3106cc;}['_getIdTokenResponse'](_0x4aee02){const _0x4f582b=this['buildRequest']();return nt(_0x4aee02,_0x4f582b);}['_linkToIdToken'](_0x4c21fb,_0x74849d){const _0x3717dd=this['buildRequest']();return _0x3717dd['idToken']=_0x74849d,nt(_0x4c21fb,_0x3717dd);}['_getReauthenticationResolver'](_0x525958){const _0x19746d=this['buildRequest']();return _0x19746d['autoCreate']=!0x1,nt(_0x525958,_0x19746d);}['buildRequest'](){const _0x5e67d3={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x5e67d3['pendingToken']=this['pendingToken'];else{const _0x25d470={};this['idToken']&&(_0x25d470['id_token']=this['idToken']),this['accessToken']&&(_0x25d470['access_token']=this['accessToken']),this['secret']&&(_0x25d470['oauth_token_secret']=this['secret']),_0x25d470['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x25d470['nonce']=this['nonce']),_0x5e67d3['postBody']=ut(_0x25d470);}return _0x5e67d3;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x508c21){switch(_0x508c21){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x4d5665){const _0x165503=Ct(Tt(_0x4d5665))['link'],_0x9f06e7=_0x165503?Ct(Tt(_0x165503))['deep_link_id']:null,_0x5d2918=Ct(Tt(_0x4d5665))['deep_link_id'];return(_0x5d2918?Ct(Tt(_0x5d2918))['link']:null)||_0x5d2918||_0x9f06e7||_0x165503||_0x4d5665;}class Rs{constructor(_0x595998){const _0x4b1e81=Ct(Tt(_0x595998)),_0x4c9676=_0x4b1e81['apiKey']??null,_0x1bbb1e=_0x4b1e81['oobCode']??null,_0x3d3b4a=Jf(_0x4b1e81['mode']??null);m(_0x4c9676&&_0x1bbb1e&&_0x3d3b4a,'argument-error'),this['apiKey']=_0x4c9676,this['operation']=_0x3d3b4a,this['code']=_0x1bbb1e,this['continueUrl']=_0x4b1e81['continueUrl']??null,this['languageCode']=_0x4b1e81['lang']??null,this['tenantId']=_0x4b1e81['tenantId']??null;}static['parseLink'](_0x5463ed){const _0x29bb63=Xf(_0x5463ed);try{return new Rs(_0x29bb63);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x5bfa42,_0x5bc25a){return $t['_fromEmailAndPassword'](_0x5bfa42,_0x5bc25a);}static['credentialWithLink'](_0x9e6b78,_0x1c3543){const _0xeb9ad7=Rs['parseLink'](_0x1c3543);return m(_0xeb9ad7,'argument-error'),$t['_fromEmailAndCode'](_0x9e6b78,_0xeb9ad7['code'],_0xeb9ad7['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x5a680c){this['providerId']=_0x5a680c,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x5aa66e){this['defaultLanguageCode']=_0x5aa66e;}['setCustomParameters'](_0x4ddfb1){return this['customParameters']=_0x4ddfb1,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1983e6){return this['scopes']['includes'](_0x1983e6)||this['scopes']['push'](_0x1983e6),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x1f8d03){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1f8d03});}static['credentialFromResult'](_0x38e2c0){return ue['credentialFromTaggedObject'](_0x38e2c0);}static['credentialFromError'](_0x1b32e2){return ue['credentialFromTaggedObject'](_0x1b32e2['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x391c18}){if(!_0x391c18||!('oauthAccessToken'in _0x391c18)||!_0x391c18['oauthAccessToken'])return null;try{return ue['credential'](_0x391c18['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x579e01,_0xb6932f){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x579e01,'accessToken':_0xb6932f});}static['credentialFromResult'](_0x26c9f0){return de['credentialFromTaggedObject'](_0x26c9f0);}static['credentialFromError'](_0x1131a9){return de['credentialFromTaggedObject'](_0x1131a9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x167bdb}){if(!_0x167bdb)return null;const {oauthIdToken:_0x4980c6,oauthAccessToken:_0xe2b17}=_0x167bdb;if(!_0x4980c6&&!_0xe2b17)return null;try{return de['credential'](_0x4980c6,_0xe2b17);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0xaa07ea){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xaa07ea});}static['credentialFromResult'](_0x55cdf0){return fe['credentialFromTaggedObject'](_0x55cdf0);}static['credentialFromError'](_0x4bbc63){return fe['credentialFromTaggedObject'](_0x4bbc63['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x26416e}){if(!_0x26416e||!('oauthAccessToken'in _0x26416e)||!_0x26416e['oauthAccessToken'])return null;try{return fe['credential'](_0x26416e['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x28c1a4,_0x5149eb){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x28c1a4,'oauthTokenSecret':_0x5149eb});}static['credentialFromResult'](_0x3f5dbf){return pe['credentialFromTaggedObject'](_0x3f5dbf);}static['credentialFromError'](_0x1c9940){return pe['credentialFromTaggedObject'](_0x1c9940['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1cbf04}){if(!_0x1cbf04)return null;const {oauthAccessToken:_0x431557,oauthTokenSecret:_0x1fd0d7}=_0x1cbf04;if(!_0x431557||!_0x1fd0d7)return null;try{return pe['credential'](_0x431557,_0x1fd0d7);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x2ec103,_0x1f1927){return en(_0x2ec103,'POST','/v1/accounts:signUp',ke(_0x2ec103,_0x1f1927));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x553ef8){this['user']=_0x553ef8['user'],this['providerId']=_0x553ef8['providerId'],this['_tokenResponse']=_0x553ef8['_tokenResponse'],this['operationType']=_0x553ef8['operationType'];}static async['_fromIdTokenResponse'](_0xf70624,_0x3fd5ea,_0x1e31d7,_0x24074d=!0x1){const _0x1fd060=await j['_fromIdTokenResponse'](_0xf70624,_0x1e31d7,_0x24074d),_0x274e7a=Nr(_0x1e31d7);return new Ge({'user':_0x1fd060,'providerId':_0x274e7a,'_tokenResponse':_0x1e31d7,'operationType':_0x3fd5ea});}static async['_forOperation'](_0x5659fd,_0x5b27ff,_0x4c9ae4){await _0x5659fd['_updateTokensIfNecessary'](_0x4c9ae4,!0x0);const _0x586ad9=Nr(_0x4c9ae4);return new Ge({'user':_0x5659fd,'providerId':_0x586ad9,'_tokenResponse':_0x4c9ae4,'operationType':_0x5b27ff});}}function Nr(_0x1e5472){return _0x1e5472['providerId']?_0x1e5472['providerId']:'phoneNumber'in _0x1e5472?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x5e4a62,_0x1806cd,_0x38ef27,_0x4f1458){super(_0x1806cd['code'],_0x1806cd['message']),this['operationType']=_0x38ef27,this['user']=_0x4f1458,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x5e4a62['name'],'tenantId':_0x5e4a62['tenantId']??void 0x0,'_serverResponse':_0x1806cd['customData']['_serverResponse'],'operationType':_0x38ef27};}static['_fromErrorAndOperation'](_0x4a5563,_0x15e667,_0x51ea0e,_0x312f2d){return new On(_0x4a5563,_0x15e667,_0x51ea0e,_0x312f2d);}}function Ba(_0x92d757,_0x1eeaee,_0x17638c,_0x4c1b73){return(_0x1eeaee==='reauthenticate'?_0x17638c['_getReauthenticationResolver'](_0x92d757):_0x17638c['_getIdTokenResponse'](_0x92d757))['catch'](_0x5e4db6=>{throw _0x5e4db6['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x92d757,_0x5e4db6,_0x1eeaee,_0x4c1b73):_0x5e4db6;});}async function ep(_0x4e2c98,_0x3f98b2,_0x222019=!0x1){const _0x516b03=await Ht(_0x4e2c98,_0x3f98b2['_linkToIdToken'](_0x4e2c98['auth'],await _0x4e2c98['getIdToken']()),_0x222019);return Ge['_forOperation'](_0x4e2c98,'link',_0x516b03);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x2675f6,_0x3dd83a,_0x2c2ced=!0x1){const {auth:_0x2339b3}=_0x2675f6;if($(_0x2339b3['app']))return Promise['reject'](re(_0x2339b3));const _0x20e1be='reauthenticate';try{const _0x37ec35=await Ht(_0x2675f6,Ba(_0x2339b3,_0x20e1be,_0x3dd83a,_0x2675f6),_0x2c2ced);m(_0x37ec35['idToken'],_0x2339b3,'internal-error');const _0x48f267=Ts(_0x37ec35['idToken']);m(_0x48f267,_0x2339b3,'internal-error');const {sub:_0x4f93ba}=_0x48f267;return m(_0x2675f6['uid']===_0x4f93ba,_0x2339b3,'user-mismatch'),Ge['_forOperation'](_0x2675f6,_0x20e1be,_0x37ec35);}catch(_0x560d74){throw(_0x560d74==null?void 0x0:_0x560d74['code'])==='auth/user-not-found'&&Y(_0x2339b3,'user-mismatch'),_0x560d74;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x33b771,_0x184f48,_0x32cf31=!0x1){if($(_0x33b771['app']))return Promise['reject'](re(_0x33b771));const _0x5e189f='signIn',_0x3417a4=await Ba(_0x33b771,_0x5e189f,_0x184f48),_0xc58832=await Ge['_fromIdTokenResponse'](_0x33b771,_0x5e189f,_0x3417a4);return _0x32cf31||await _0x33b771['_updateCurrentUser'](_0xc58832['user']),_0xc58832;}async function np(_0x2eff68,_0x4bc2d9){return Va(Ke(_0x2eff68),_0x4bc2d9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x3b8cb8){const _0x6e817b=Ke(_0x3b8cb8);_0x6e817b['_getPasswordPolicyInternal']()&&await _0x6e817b['_updatePasswordPolicy']();}async function L_(_0x1075f3,_0x4c17aa,_0x107edb){if($(_0x1075f3['app']))return Promise['reject'](re(_0x1075f3));const _0x3b5bf1=Ke(_0x1075f3),_0xc6a786=await xi(_0x3b5bf1,{'returnSecureToken':!0x0,'email':_0x4c17aa,'password':_0x107edb,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x1b1217=>{throw _0x1b1217['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x1075f3),_0x1b1217;}),_0x56da36=await Ge['_fromIdTokenResponse'](_0x3b5bf1,'signIn',_0xc6a786);return await _0x3b5bf1['_updateCurrentUser'](_0x56da36['user']),_0x56da36;}function x_(_0xd29fa5,_0x151c7e,_0x487e2b){return $(_0xd29fa5['app'])?Promise['reject'](re(_0xd29fa5)):np(P(_0xd29fa5),yt['credential'](_0x151c7e,_0x487e2b))['catch'](async _0x236b24=>{throw _0x236b24['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xd29fa5),_0x236b24;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x1a4af8,_0x4d0324){return P(_0x1a4af8)['setPersistence'](_0x4d0324);}function ip(_0x37a6d1,_0x143e3b,_0x21e3e8,_0x118524){return P(_0x37a6d1)['onIdTokenChanged'](_0x143e3b,_0x21e3e8,_0x118524);}function sp(_0xc281da,_0x4e952b,_0x279327){return P(_0xc281da)['beforeAuthStateChanged'](_0x4e952b,_0x279327);}function U_(_0x393253,_0x4334f2,_0x5b89dc,_0x4e816c){return P(_0x393253)['onAuthStateChanged'](_0x4334f2,_0x5b89dc,_0x4e816c);}function W_(_0x3a7d51){return P(_0x3a7d51)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x31a4b0,_0x3902f4){this['storageRetriever']=_0x31a4b0,this['type']=_0x3902f4;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x46f76c,_0x5e65da){return this['storage']['setItem'](_0x46f76c,JSON['stringify'](_0x5e65da)),Promise['resolve']();}['_get'](_0x1ef284){const _0x46d40b=this['storage']['getItem'](_0x1ef284);return Promise['resolve'](_0x46d40b?JSON['parse'](_0x46d40b):null);}['_remove'](_0x4ed2b3){return this['storage']['removeItem'](_0x4ed2b3),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x57bf4f,_0x5de009)=>this['onStorageEvent'](_0x57bf4f,_0x5de009),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x44ac43){for(const _0x35a468 of Object['keys'](this['listeners'])){const _0x592e76=this['storage']['getItem'](_0x35a468),_0x9e158e=this['localCache'][_0x35a468];_0x592e76!==_0x9e158e&&_0x44ac43(_0x35a468,_0x9e158e,_0x592e76);}}['onStorageEvent'](_0xa25395,_0x138db4=!0x1){if(!_0xa25395['key']){this['forAllChangedKeys']((_0x4510ce,_0x3d108f,_0x37e3e7)=>{this['notifyListeners'](_0x4510ce,_0x37e3e7);});return;}const _0x5e67ff=_0xa25395['key'];_0x138db4?this['detachListener']():this['stopPolling']();const _0xe25e51=()=>{const _0x4da722=this['storage']['getItem'](_0x5e67ff);!_0x138db4&&this['localCache'][_0x5e67ff]===_0x4da722||this['notifyListeners'](_0x5e67ff,_0x4da722);},_0x5db8ff=this['storage']['getItem'](_0x5e67ff);Af()&&_0x5db8ff!==_0xa25395['newValue']&&_0xa25395['newValue']!==_0xa25395['oldValue']?setTimeout(_0xe25e51,op):_0xe25e51();}['notifyListeners'](_0x25d03f,_0x14fa64){this['localCache'][_0x25d03f]=_0x14fa64;const _0x4f7e98=this['listeners'][_0x25d03f];if(_0x4f7e98){for(const _0x486c25 of Array['from'](_0x4f7e98))_0x486c25(_0x14fa64&&JSON['parse'](_0x14fa64));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x539f25,_0x516d1b,_0x77c6c7)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x539f25,'oldValue':_0x516d1b,'newValue':_0x77c6c7}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x23c627,_0x15175e){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x23c627]||(this['listeners'][_0x23c627]=new Set(),this['localCache'][_0x23c627]=this['storage']['getItem'](_0x23c627)),this['listeners'][_0x23c627]['add'](_0x15175e);}['_removeListener'](_0xd1fa24,_0x2b1c7f){this['listeners'][_0xd1fa24]&&(this['listeners'][_0xd1fa24]['delete'](_0x2b1c7f),this['listeners'][_0xd1fa24]['size']===0x0&&delete this['listeners'][_0xd1fa24]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x2f206,_0xd1eb30){await super['_set'](_0x2f206,_0xd1eb30),this['localCache'][_0x2f206]=JSON['stringify'](_0xd1eb30);}async['_get'](_0x4b8e65){const _0x533825=await super['_get'](_0x4b8e65);return this['localCache'][_0x4b8e65]=JSON['stringify'](_0x533825),_0x533825;}async['_remove'](_0x2f1928){await super['_remove'](_0x2f1928),delete this['localCache'][_0x2f1928];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1939e6,_0xa2b8e5){}['_removeListener'](_0x1a5fd4,_0x3b8575){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2923db){return Promise['all'](_0x2923db['map'](async _0x326e8d=>{try{return{'fulfilled':!0x0,'value':await _0x326e8d};}catch(_0x1d2efe){return{'fulfilled':!0x1,'reason':_0x1d2efe};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x1f9c54){this['eventTarget']=_0x1f9c54,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1509f8){const _0x5e0fd7=this['receivers']['find'](_0x1d870d=>_0x1d870d['isListeningto'](_0x1509f8));if(_0x5e0fd7)return _0x5e0fd7;const _0x568093=new Xn(_0x1509f8);return this['receivers']['push'](_0x568093),_0x568093;}['isListeningto'](_0x4c18cb){return this['eventTarget']===_0x4c18cb;}async['handleEvent'](_0x2182af){const _0x22c465=_0x2182af,{eventId:_0xb37e5c,eventType:_0x2c7d3f,data:_0x2625f8}=_0x22c465['data'],_0x5db843=this['handlersMap'][_0x2c7d3f];if(!(_0x5db843!=null&&_0x5db843['size']))return;_0x22c465['ports'][0x0]['postMessage']({'status':'ack','eventId':_0xb37e5c,'eventType':_0x2c7d3f});const _0x455905=Array['from'](_0x5db843)['map'](async _0x22e15b=>_0x22e15b(_0x22c465['origin'],_0x2625f8)),_0x5c89f2=await cp(_0x455905);_0x22c465['ports'][0x0]['postMessage']({'status':'done','eventId':_0xb37e5c,'eventType':_0x2c7d3f,'response':_0x5c89f2});}['_subscribe'](_0x4adec1,_0x25e0c3){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x4adec1]||(this['handlersMap'][_0x4adec1]=new Set()),this['handlersMap'][_0x4adec1]['add'](_0x25e0c3);}['_unsubscribe'](_0x52cdfc,_0x1ef5b4){this['handlersMap'][_0x52cdfc]&&_0x1ef5b4&&this['handlersMap'][_0x52cdfc]['delete'](_0x1ef5b4),(!_0x1ef5b4||this['handlersMap'][_0x52cdfc]['size']===0x0)&&delete this['handlersMap'][_0x52cdfc],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x2abe00='',_0x2ccc30=0xa){let _0x4f03c0='';for(let _0xc9349=0x0;_0xc9349<_0x2ccc30;_0xc9349++)_0x4f03c0+=Math['floor'](Math['random']()*0xa);return _0x2abe00+_0x4f03c0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x1508ea){this['target']=_0x1508ea,this['handlers']=new Set();}['removeMessageHandler'](_0x46adbb){_0x46adbb['messageChannel']&&(_0x46adbb['messageChannel']['port1']['removeEventListener']('message',_0x46adbb['onMessage']),_0x46adbb['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x46adbb);}async['_send'](_0x24f998,_0x540b2d,_0x75dca1=0x32){const _0x17a2e8=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x17a2e8)throw new Error('connection_unavailable');let _0x4342c9,_0x442a7f;return new Promise((_0x120f1f,_0x2f9c3c)=>{const _0x363e88=As('',0x14);_0x17a2e8['port1']['start']();const _0x36ffc2=setTimeout(()=>{_0x2f9c3c(new Error('unsupported_event'));},_0x75dca1);_0x442a7f={'messageChannel':_0x17a2e8,'onMessage'(_0x1819f7){const _0x1a0292=_0x1819f7;if(_0x1a0292['data']['eventId']===_0x363e88)switch(_0x1a0292['data']['status']){case'ack':clearTimeout(_0x36ffc2),_0x4342c9=setTimeout(()=>{_0x2f9c3c(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4342c9),_0x120f1f(_0x1a0292['data']['response']);break;default:clearTimeout(_0x36ffc2),clearTimeout(_0x4342c9),_0x2f9c3c(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x442a7f),_0x17a2e8['port1']['addEventListener']('message',_0x442a7f['onMessage']),this['target']['postMessage']({'eventType':_0x24f998,'eventId':_0x363e88,'data':_0x540b2d},[_0x17a2e8['port2']]);})['finally'](()=>{_0x442a7f&&this['removeMessageHandler'](_0x442a7f);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x3561fd){Z()['location']['href']=_0x3561fd;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0xbf42f1;return((_0xbf42f1=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0xbf42f1['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x497d11){this['request']=_0x497d11;}['toPromise'](){return new Promise((_0x5ebb36,_0x4cb35f)=>{this['request']['addEventListener']('success',()=>{_0x5ebb36(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x4cb35f(this['request']['error']);});});}}function Zn(_0x4db8ef,_0x10b37e){return _0x4db8ef['transaction']([Mn],_0x10b37e?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x229cc7=indexedDB['deleteDatabase'](Ka);return new nn(_0x229cc7)['toPromise']();}function Qa(){const _0x4a69cb=indexedDB['open'](Ka,pp);return new Promise((_0x1d8da6,_0x302533)=>{_0x4a69cb['addEventListener']('error',()=>{_0x302533(_0x4a69cb['error']);}),_0x4a69cb['addEventListener']('upgradeneeded',()=>{const _0x36fb55=_0x4a69cb['result'];try{_0x36fb55['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x35cf70){_0x302533(_0x35cf70);}}),_0x4a69cb['addEventListener']('success',async()=>{const _0x6faa46=_0x4a69cb['result'];_0x6faa46['objectStoreNames']['contains'](Mn)?_0x1d8da6(_0x6faa46):(_0x6faa46['close'](),await _p(),_0x1d8da6(await Qa()));});});}async function Or(_0x158d5d,_0x346dd8,_0x1c3361){const _0x102597=Zn(_0x158d5d,!0x0)['put']({[Ya]:_0x346dd8,'value':_0x1c3361});return new nn(_0x102597)['toPromise']();}async function gp(_0x26c4a8,_0x1e9307){const _0x19c3aa=Zn(_0x26c4a8,!0x1)['get'](_0x1e9307),_0x87d5ae=await new nn(_0x19c3aa)['toPromise']();return _0x87d5ae===void 0x0?null:_0x87d5ae['value'];}function Dr(_0x30c831,_0x310707){const _0x4cd737=Zn(_0x30c831,!0x0)['delete'](_0x310707);return new nn(_0x4cd737)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x59554a){let _0x543cf8=0x0;for(;;)try{const _0x3bdef4=await this['_openDb']();return await _0x59554a(_0x3bdef4);}catch(_0x42b26e){if(_0x543cf8++>yp)throw _0x42b26e;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x33eeca,_0x51b4d3)=>({'keyProcessed':(await this['_poll']())['includes'](_0x51b4d3['key'])})),this['receiver']['_subscribe']('ping',async(_0x4ef31f,_0x1d3991)=>['keyChanged']);}async['initializeSender'](){var _0x7d8274,_0x31b590;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x55a24f=await this['sender']['_send']('ping',{},0x320);_0x55a24f&&(_0x7d8274=_0x55a24f[0x0])!=null&&_0x7d8274['fulfilled']&&(_0x31b590=_0x55a24f[0x0])!=null&&_0x31b590['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x290bda){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x290bda},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x196d17=>{await Or(_0x196d17,Dn,'1'),await Dr(_0x196d17,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x118304){this['pendingWrites']++;try{await _0x118304();}finally{this['pendingWrites']--;}}async['_set'](_0x1637aa,_0x5ccb9d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5e58d8=>Or(_0x5e58d8,_0x1637aa,_0x5ccb9d)),this['localCache'][_0x1637aa]=_0x5ccb9d,this['notifyServiceWorker'](_0x1637aa)));}async['_get'](_0x18e995){const _0x2a5e89=await this['_withRetries'](_0x1de453=>gp(_0x1de453,_0x18e995));return this['localCache'][_0x18e995]=_0x2a5e89,_0x2a5e89;}async['_remove'](_0x5f2332){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x33a2d1=>Dr(_0x33a2d1,_0x5f2332)),delete this['localCache'][_0x5f2332],this['notifyServiceWorker'](_0x5f2332)));}async['_poll'](){const _0x57cdf5=await this['_withRetries'](_0x26ec14=>{const _0x92e6d6=Zn(_0x26ec14,!0x1)['getAll']();return new nn(_0x92e6d6)['toPromise']();});if(!_0x57cdf5)return[];if(this['pendingWrites']!==0x0)return[];const _0x187ed6=[],_0x44712e=new Set();if(_0x57cdf5['length']!==0x0){for(const {fbase_key:_0x266884,value:_0x339372}of _0x57cdf5)_0x44712e['add'](_0x266884),JSON['stringify'](this['localCache'][_0x266884])!==JSON['stringify'](_0x339372)&&(this['notifyListeners'](_0x266884,_0x339372),_0x187ed6['push'](_0x266884));}for(const _0x5b96b4 of Object['keys'](this['localCache']))this['localCache'][_0x5b96b4]&&!_0x44712e['has'](_0x5b96b4)&&(this['notifyListeners'](_0x5b96b4,null),_0x187ed6['push'](_0x5b96b4));return _0x187ed6;}['notifyListeners'](_0x50a7a5,_0x190913){this['localCache'][_0x50a7a5]=_0x190913;const _0x4b60f8=this['listeners'][_0x50a7a5];if(_0x4b60f8){for(const _0xddb0b3 of Array['from'](_0x4b60f8))_0xddb0b3(_0x190913);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x13f2ee,_0x54b87d){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x13f2ee]||(this['listeners'][_0x13f2ee]=new Set(),this['_get'](_0x13f2ee)),this['listeners'][_0x13f2ee]['add'](_0x54b87d);}['_removeListener'](_0x209d2f,_0x304b02){this['listeners'][_0x209d2f]&&(this['listeners'][_0x209d2f]['delete'](_0x304b02),this['listeners'][_0x209d2f]['size']===0x0&&delete this['listeners'][_0x209d2f]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x2c307a,_0x1525aa){return _0x1525aa?ie(_0x1525aa):(m(_0x2c307a['_popupRedirectResolver'],_0x2c307a,'argument-error'),_0x2c307a['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x22ba57){super('custom','custom'),this['params']=_0x22ba57;}['_getIdTokenResponse'](_0x52b3f4){return nt(_0x52b3f4,this['_buildIdpRequest']());}['_linkToIdToken'](_0x50153d,_0x481573){return nt(_0x50153d,this['_buildIdpRequest'](_0x481573));}['_getReauthenticationResolver'](_0x1dd70a){return nt(_0x1dd70a,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3060de){const _0x2882c5={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3060de&&(_0x2882c5['idToken']=_0x3060de),_0x2882c5;}}function Ip(_0x415a3b){return Va(_0x415a3b['auth'],new ks(_0x415a3b),_0x415a3b['bypassAuthState']);}function wp(_0x1b1967){const {auth:_0x4cd74d,user:_0x384389}=_0x1b1967;return m(_0x384389,_0x4cd74d,'internal-error'),tp(_0x384389,new ks(_0x1b1967),_0x1b1967['bypassAuthState']);}async function Cp(_0x301eea){const {auth:_0x390cf4,user:_0x2c797d}=_0x301eea;return m(_0x2c797d,_0x390cf4,'internal-error'),ep(_0x2c797d,new ks(_0x301eea),_0x301eea['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x73ec30,_0x3836e7,_0x1eb0e6,_0x619494,_0xe24d2e=!0x1){this['auth']=_0x73ec30,this['resolver']=_0x1eb0e6,this['user']=_0x619494,this['bypassAuthState']=_0xe24d2e,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3836e7)?_0x3836e7:[_0x3836e7];}['execute'](){return new Promise(async(_0x1b6b9d,_0x488c71)=>{this['pendingPromise']={'resolve':_0x1b6b9d,'reject':_0x488c71};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x1c7d49){this['reject'](_0x1c7d49);}});}async['onAuthEvent'](_0x15d442){const {urlResponse:_0x4f3586,sessionId:_0x56d3eb,postBody:_0x2c981b,tenantId:_0x58b99c,error:_0x4d103c,type:_0x24a77a}=_0x15d442;if(_0x4d103c){this['reject'](_0x4d103c);return;}const _0x17bd8d={'auth':this['auth'],'requestUri':_0x4f3586,'sessionId':_0x56d3eb,'tenantId':_0x58b99c||void 0x0,'postBody':_0x2c981b||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x24a77a)(_0x17bd8d));}catch(_0x5c04a5){this['reject'](_0x5c04a5);}}['onError'](_0x34a50a){this['reject'](_0x34a50a);}['getIdpTask'](_0x512ec2){switch(_0x512ec2){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x3ba41a){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3ba41a),this['unregisterAndCleanUp']();}['reject'](_0x4fe6ec){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x4fe6ec),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x5dc9cf,_0x46e3ed,_0x5be149,_0x299735,_0x2e967b){super(_0x5dc9cf,_0x46e3ed,_0x299735,_0x2e967b),this['provider']=_0x5be149,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x211ca5=await this['execute']();return m(_0x211ca5,this['auth'],'internal-error'),_0x211ca5;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1f9aaa=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1f9aaa),this['authWindow']['associatedEvent']=_0x1f9aaa,this['resolver']['_originValidation'](this['auth'])['catch'](_0x52a32c=>{this['reject'](_0x52a32c);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x52d48b=>{_0x52d48b||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x49b436;return((_0x49b436=this['authWindow'])==null?void 0x0:_0x49b436['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x11ea0d=()=>{var _0x250d7e,_0x18d774;if((_0x18d774=(_0x250d7e=this['authWindow'])==null?void 0x0:_0x250d7e['window'])!=null&&_0x18d774['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x11ea0d,Tp['get']());};_0x11ea0d();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x2ec6c5,_0x5e96da,_0x1eaea4=!0x1){super(_0x2ec6c5,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5e96da,void 0x0,_0x1eaea4),this['eventId']=null;}async['execute'](){let _0xc22aa2=hn['get'](this['auth']['_key']());if(!_0xc22aa2){try{const _0x5a4d4e=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0xc22aa2=()=>Promise['resolve'](_0x5a4d4e);}catch(_0x56389f){_0xc22aa2=()=>Promise['reject'](_0x56389f);}hn['set'](this['auth']['_key'](),_0xc22aa2);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xc22aa2();}async['onAuthEvent'](_0x202b09){if(_0x202b09['type']==='signInViaRedirect')return super['onAuthEvent'](_0x202b09);if(_0x202b09['type']==='unknown'){this['resolve'](null);return;}if(_0x202b09['eventId']){const _0xab46da=await this['auth']['_redirectUserForId'](_0x202b09['eventId']);if(_0xab46da)return this['user']=_0xab46da,super['onAuthEvent'](_0x202b09);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x4a33a7,_0x52a7e6){const _0x115cbd=Pp(_0x52a7e6),_0x5b529d=kp(_0x4a33a7);if(!await _0x5b529d['_isAvailable']())return!0x1;const _0x355e71=await _0x5b529d['_get'](_0x115cbd)==='true';return await _0x5b529d['_remove'](_0x115cbd),_0x355e71;}function Ap(_0x2f5c50,_0x253186){hn['set'](_0x2f5c50['_key'](),_0x253186);}function kp(_0x86de38){return ie(_0x86de38['_redirectPersistence']);}function Pp(_0x5960d7){return ln(Sp,_0x5960d7['config']['apiKey'],_0x5960d7['name']);}async function Np(_0x46c5f5,_0x40eff7,_0x50dc5a=!0x1){if($(_0x46c5f5['app']))return Promise['reject'](re(_0x46c5f5));const _0x471baf=Ke(_0x46c5f5),_0x4bc898=Ep(_0x471baf,_0x40eff7),_0x4a2057=await new bp(_0x471baf,_0x4bc898,_0x50dc5a)['execute']();return _0x4a2057&&!_0x50dc5a&&(delete _0x4a2057['user']['_redirectEventId'],await _0x471baf['_persistUserIfCurrent'](_0x4a2057['user']),await _0x471baf['_setRedirectUser'](null,_0x40eff7)),_0x4a2057;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x56ae47){this['auth']=_0x56ae47,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4c6ae9){this['consumers']['add'](_0x4c6ae9),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4c6ae9)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4c6ae9),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x28e94b){this['consumers']['delete'](_0x28e94b);}['onEvent'](_0x3c91c0){if(this['hasEventBeenHandled'](_0x3c91c0))return!0x1;let _0x1e58ad=!0x1;return this['consumers']['forEach'](_0x33395e=>{this['isEventForConsumer'](_0x3c91c0,_0x33395e)&&(_0x1e58ad=!0x0,this['sendToConsumer'](_0x3c91c0,_0x33395e),this['saveEventToCache'](_0x3c91c0));}),this['hasHandledPotentialRedirect']||!Mp(_0x3c91c0)||(this['hasHandledPotentialRedirect']=!0x0,_0x1e58ad||(this['queuedRedirectEvent']=_0x3c91c0,_0x1e58ad=!0x0)),_0x1e58ad;}['sendToConsumer'](_0x9a8274,_0x1ed53c){var _0x1b9428;if(_0x9a8274['error']&&!Za(_0x9a8274)){const _0x45c1a7=((_0x1b9428=_0x9a8274['error']['code'])==null?void 0x0:_0x1b9428['split']('auth/')[0x1])||'internal-error';_0x1ed53c['onError'](X(this['auth'],_0x45c1a7));}else _0x1ed53c['onAuthEvent'](_0x9a8274);}['isEventForConsumer'](_0x47b7ef,_0x34cd17){const _0x49eaf3=_0x34cd17['eventId']===null||!!_0x47b7ef['eventId']&&_0x47b7ef['eventId']===_0x34cd17['eventId'];return _0x34cd17['filter']['includes'](_0x47b7ef['type'])&&_0x49eaf3;}['hasEventBeenHandled'](_0x1eb261){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x1eb261));}['saveEventToCache'](_0x1a5d25){this['cachedEventUids']['add'](Mr(_0x1a5d25)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x178665){return[_0x178665['type'],_0x178665['eventId'],_0x178665['sessionId'],_0x178665['tenantId']]['filter'](_0x55b1de=>_0x55b1de)['join']('-');}function Za({type:_0xe5f708,error:_0x3b9dea}){return _0xe5f708==='unknown'&&(_0x3b9dea==null?void 0x0:_0x3b9dea['code'])==='auth/no-auth-event';}function Mp(_0x51bbd6){switch(_0x51bbd6['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x51bbd6);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x1b23a4,_0x379451={}){return Pe(_0x1b23a4,'GET','/v1/projects',_0x379451);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0xcd5aa1){if(_0xcd5aa1['config']['emulator'])return;const {authorizedDomains:_0xe134b3}=await Lp(_0xcd5aa1);for(const _0x18d590 of _0xe134b3)try{if(Wp(_0x18d590))return;}catch{}Y(_0xcd5aa1,'unauthorized-domain');}function Wp(_0x83d70d){const _0x5d5de5=Mi(),{protocol:_0x3cfb58,hostname:_0x1b5a6f}=new URL(_0x5d5de5);if(_0x83d70d['startsWith']('chrome-extension://')){const _0x13bf10=new URL(_0x83d70d);return _0x13bf10['hostname']===''&&_0x1b5a6f===''?_0x3cfb58==='chrome-extension:'&&_0x83d70d['replace']('chrome-extension://','')===_0x5d5de5['replace']('chrome-extension://',''):_0x3cfb58==='chrome-extension:'&&_0x13bf10['hostname']===_0x1b5a6f;}if(!Fp['test'](_0x3cfb58))return!0x1;if(xp['test'](_0x83d70d))return _0x1b5a6f===_0x83d70d;const _0x3d5473=_0x83d70d['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3d5473+'|'+_0x3d5473+')$','i')['test'](_0x1b5a6f);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x5ea23f=Z()['___jsl'];if(_0x5ea23f!=null&&_0x5ea23f['H']){for(const _0x338ca1 of Object['keys'](_0x5ea23f['H']))if(_0x5ea23f['H'][_0x338ca1]['r']=_0x5ea23f['H'][_0x338ca1]['r']||[],_0x5ea23f['H'][_0x338ca1]['L']=_0x5ea23f['H'][_0x338ca1]['L']||[],_0x5ea23f['H'][_0x338ca1]['r']=[..._0x5ea23f['H'][_0x338ca1]['L']],_0x5ea23f['CP']){for(let _0x34a2c9=0x0;_0x34a2c9<_0x5ea23f['CP']['length'];_0x34a2c9++)_0x5ea23f['CP'][_0x34a2c9]=null;}}}function Vp(_0x79e268){return new Promise((_0x3587f1,_0xa73770)=>{var _0x2a26f3,_0x3655bd,_0x5e4951;function _0x1a8c03(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3587f1(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0xa73770(X(_0x79e268,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x3655bd=(_0x2a26f3=Z()['gapi'])==null?void 0x0:_0x2a26f3['iframes'])!=null&&_0x3655bd['Iframe'])_0x3587f1(gapi['iframes']['getContext']());else{if((_0x5e4951=Z()['gapi'])!=null&&_0x5e4951['load'])_0x1a8c03();else{const _0x16e246=Ff('iframefcb');return Z()[_0x16e246]=()=>{gapi['load']?_0x1a8c03():_0xa73770(X(_0x79e268,'network-request-failed'));},xa(xf()+'?onload='+_0x16e246)['catch'](_0x518cb0=>_0xa73770(_0x518cb0));}}})['catch'](_0x5f3917=>{throw un=null,_0x5f3917;});}let un=null;function Hp(_0x46efc7){return un=un||Vp(_0x46efc7),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x1ce658){const _0x32f235=_0x1ce658['config'];m(_0x32f235['authDomain'],_0x1ce658,'auth-domain-config-required');const _0x390898=_0x32f235['emulator']?Cs(_0x32f235,qp):'https://'+_0x1ce658['config']['authDomain']+'/'+Gp,_0x444c97={'apiKey':_0x32f235['apiKey'],'appName':_0x1ce658['name'],'v':dt},_0x9ab29b=jp['get'](_0x1ce658['config']['apiHost']);_0x9ab29b&&(_0x444c97['eid']=_0x9ab29b);const _0x44d3e0=_0x1ce658['_getFrameworks']();return _0x44d3e0['length']&&(_0x444c97['fw']=_0x44d3e0['join'](',')),_0x390898+'?'+ut(_0x444c97)['slice'](0x1);}async function Yp(_0x174413){const _0x79f030=await Hp(_0x174413),_0x495871=Z()['gapi'];return m(_0x495871,_0x174413,'internal-error'),_0x79f030['open']({'where':document['body'],'url':Kp(_0x174413),'messageHandlersFilter':_0x495871['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x4c3995=>new Promise(async(_0x597336,_0x32fa0f)=>{await _0x4c3995['restyle']({'setHideOnLeave':!0x1});const _0x2b480f=X(_0x174413,'network-request-failed'),_0x5e8671=Z()['setTimeout'](()=>{_0x32fa0f(_0x2b480f);},$p['get']());function _0x392ab7(){Z()['clearTimeout'](_0x5e8671),_0x597336(_0x4c3995);}_0x4c3995['ping'](_0x392ab7)['then'](_0x392ab7,()=>{_0x32fa0f(_0x2b480f);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x13110f){this['window']=_0x13110f,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x5859d0,_0xe1fe67,_0xfc091d,_0x2ccea5=Jp,_0x31b18f=Xp){const _0x3d42da=Math['max']((window['screen']['availHeight']-_0x31b18f)/0x2,0x0)['toString'](),_0x71b1cc=Math['max']((window['screen']['availWidth']-_0x2ccea5)/0x2,0x0)['toString']();let _0x814a8c='';const _0x2b01af={...Qp,'width':_0x2ccea5['toString'](),'height':_0x31b18f['toString'](),'top':_0x3d42da,'left':_0x71b1cc},_0x302a98=W()['toLowerCase']();_0xfc091d&&(_0x814a8c=ka(_0x302a98)?Zp:_0xfc091d),Ra(_0x302a98)&&(_0xe1fe67=_0xe1fe67||e_,_0x2b01af['scrollbars']='yes');const _0x410a3a=Object['entries'](_0x2b01af)['reduce']((_0x681e2e,[_0x54480c,_0x462169])=>''+_0x681e2e+_0x54480c+'='+_0x462169+',','');if(Rf(_0x302a98)&&_0x814a8c!=='_self')return n_(_0xe1fe67||'',_0x814a8c),new xr(null);const _0x331817=window['open'](_0xe1fe67||'',_0x814a8c,_0x410a3a);m(_0x331817,_0x5859d0,'popup-blocked');try{_0x331817['focus']();}catch{}return new xr(_0x331817);}function n_(_0x2d0d11,_0x4f74fc){const _0x55522b=document['createElement']('a');_0x55522b['href']=_0x2d0d11,_0x55522b['target']=_0x4f74fc;const _0x6350a7=document['createEvent']('MouseEvent');_0x6350a7['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x55522b['dispatchEvent'](_0x6350a7);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x412fc6,_0x597cd9,_0x16c556,_0x2a4624,_0x4af5e9,_0x124d65){m(_0x412fc6['config']['authDomain'],_0x412fc6,'auth-domain-config-required'),m(_0x412fc6['config']['apiKey'],_0x412fc6,'invalid-api-key');const _0x41fdef={'apiKey':_0x412fc6['config']['apiKey'],'appName':_0x412fc6['name'],'authType':_0x16c556,'redirectUrl':_0x2a4624,'v':dt,'eventId':_0x4af5e9};if(_0x597cd9 instanceof Wa){_0x597cd9['setDefaultLanguage'](_0x412fc6['languageCode']),_0x41fdef['providerId']=_0x597cd9['providerId']||'',pn(_0x597cd9['getCustomParameters']())||(_0x41fdef['customParameters']=JSON['stringify'](_0x597cd9['getCustomParameters']()));for(const [_0xe692f9,_0x49d6c7]of Object['entries']({}))_0x41fdef[_0xe692f9]=_0x49d6c7;}if(_0x597cd9 instanceof tn){const _0x25931e=_0x597cd9['getScopes']()['filter'](_0x31ae99=>_0x31ae99!=='');_0x25931e['length']>0x0&&(_0x41fdef['scopes']=_0x25931e['join'](','));}_0x412fc6['tenantId']&&(_0x41fdef['tid']=_0x412fc6['tenantId']);const _0x342f1a=_0x41fdef;for(const _0x1affce of Object['keys'](_0x342f1a))_0x342f1a[_0x1affce]===void 0x0&&delete _0x342f1a[_0x1affce];const _0x321e52=await _0x412fc6['_getAppCheckToken'](),_0x583a99=_0x321e52?'#'+r_+'='+encodeURIComponent(_0x321e52):'';return o_(_0x412fc6)+'?'+ut(_0x342f1a)['slice'](0x1)+_0x583a99;}function o_({config:_0x4f31f7}){return _0x4f31f7['emulator']?Cs(_0x4f31f7,s_):'https://'+_0x4f31f7['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x55d822,_0x34ea1a,_0xcdce22,_0x17abcf){var _0x530ba7;ce((_0x530ba7=this['eventManagers'][_0x55d822['_key']()])==null?void 0x0:_0x530ba7['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3cb08b=await Fr(_0x55d822,_0x34ea1a,_0xcdce22,Mi(),_0x17abcf);return t_(_0x55d822,_0x3cb08b,As());}async['_openRedirect'](_0x475104,_0x3d8f28,_0x41cf18,_0x58de62){await this['_originValidation'](_0x475104);const _0x294474=await Fr(_0x475104,_0x3d8f28,_0x41cf18,Mi(),_0x58de62);return hp(_0x294474),new Promise(()=>{});}['_initialize'](_0x5578bb){const _0x3aedce=_0x5578bb['_key']();if(this['eventManagers'][_0x3aedce]){const {manager:_0x301985,promise:_0x5246cd}=this['eventManagers'][_0x3aedce];return _0x301985?Promise['resolve'](_0x301985):(ce(_0x5246cd,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5246cd);}const _0x5d00d6=this['initAndGetManager'](_0x5578bb);return this['eventManagers'][_0x3aedce]={'promise':_0x5d00d6},_0x5d00d6['catch'](()=>{delete this['eventManagers'][_0x3aedce];}),_0x5d00d6;}async['initAndGetManager'](_0x41dc4a){const _0x151fdc=await Yp(_0x41dc4a),_0x3996c3=new Dp(_0x41dc4a);return _0x151fdc['register']('authEvent',_0x185762=>(m(_0x185762==null?void 0x0:_0x185762['authEvent'],_0x41dc4a,'invalid-auth-event'),{'status':_0x3996c3['onEvent'](_0x185762['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x41dc4a['_key']()]={'manager':_0x3996c3},this['iframes'][_0x41dc4a['_key']()]=_0x151fdc,_0x3996c3;}['_isIframeWebStorageSupported'](_0x31f043,_0x1ba4f3){this['iframes'][_0x31f043['_key']()]['send'](pi,{'type':pi},_0x40a994=>{var _0x33d591;const _0x3b6f7a=(_0x33d591=_0x40a994==null?void 0x0:_0x40a994[0x0])==null?void 0x0:_0x33d591[pi];_0x3b6f7a!==void 0x0&&_0x1ba4f3(!!_0x3b6f7a),Y(_0x31f043,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1d5e15){const _0x554caf=_0x1d5e15['_key']();return this['originValidationPromises'][_0x554caf]||(this['originValidationPromises'][_0x554caf]=Up(_0x1d5e15)),this['originValidationPromises'][_0x554caf];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x413669){this['auth']=_0x413669,this['internalListeners']=new Map();}['getUid'](){var _0x508b46;return this['assertAuthConfigured'](),((_0x508b46=this['auth']['currentUser'])==null?void 0x0:_0x508b46['uid'])||null;}async['getToken'](_0x2d7a9f){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2d7a9f)}:null;}['addAuthTokenListener'](_0x3acb12){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3acb12))return;const _0x551b61=this['auth']['onIdTokenChanged'](_0x5a1c13=>{_0x3acb12((_0x5a1c13==null?void 0x0:_0x5a1c13['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3acb12,_0x551b61),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x537d2f){this['assertAuthConfigured']();const _0x32dd36=this['internalListeners']['get'](_0x537d2f);_0x32dd36&&(this['internalListeners']['delete'](_0x537d2f),_0x32dd36(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x1f57ac){switch(_0x1f57ac){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x5d1f5c){st(new Fe('auth',(_0x59b175,{options:_0x34bb97})=>{const _0x5f09fd=_0x59b175['getProvider']('app')['getImmediate'](),_0x15c1ee=_0x59b175['getProvider']('heartbeat'),_0x22b1e9=_0x59b175['getProvider']('app-check-internal'),{apiKey:_0x55e100,authDomain:_0x20a64f}=_0x5f09fd['options'];m(_0x55e100&&!_0x55e100['includes'](':'),'invalid-api-key',{'appName':_0x5f09fd['name']});const _0x2d7598={'apiKey':_0x55e100,'authDomain':_0x20a64f,'clientPlatform':_0x5d1f5c,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5d1f5c)},_0x860bd8=new Df(_0x5f09fd,_0x15c1ee,_0x22b1e9,_0x2d7598);return Hf(_0x860bd8,_0x34bb97),_0x860bd8;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2b059e,_0x3f9f3d,_0x729572)=>{_0x2b059e['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x6363de=>{const _0x36e64e=Ke(_0x6363de['getProvider']('auth')['getImmediate']());return(_0xee25f7=>new l_(_0xee25f7))(_0x36e64e);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x5d1f5c)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x2fcea9=>async _0x319896=>{const _0x3d2c46=_0x319896&&await _0x319896['getIdTokenResult'](),_0x18be69=_0x3d2c46&&(new Date()['getTime']()-Date['parse'](_0x3d2c46['issuedAtTime']))/0x3e8;if(_0x18be69&&_0x18be69>f_)return;const _0xad4759=_0x3d2c46==null?void 0x0:_0x3d2c46['token'];Br!==_0xad4759&&(Br=_0xad4759,await fetch(_0x2fcea9,{'method':_0xad4759?'POST':'DELETE','headers':_0xad4759?{'Authorization':'Bearer\x20'+_0xad4759}:{}}));};function B_(_0x1813d1=Zr()){const _0x6ba595=Hi(_0x1813d1,'auth');if(_0x6ba595['isInitialized']())return _0x6ba595['getImmediate']();const _0x3be5b5=Vf(_0x1813d1,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x3ba1fe=jr('authTokenSyncURL');if(_0x3ba1fe&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2f89df=new URL(_0x3ba1fe,location['origin']);if(location['origin']===_0x2f89df['origin']){const _0x20eb3f=p_(_0x2f89df['toString']());sp(_0x3be5b5,_0x20eb3f,()=>_0x20eb3f(_0x3be5b5['currentUser'])),ip(_0x3be5b5,_0x4b9dc9=>_0x20eb3f(_0x4b9dc9));}}const _0x519483=qr('auth');return _0x519483&&$f(_0x3be5b5,'http://'+_0x519483),_0x3be5b5;}function __(){var _0x9a849d;return((_0x9a849d=document['getElementsByTagName']('head'))==null?void 0x0:_0x9a849d[0x0])??document;}Mf({'loadJS'(_0xc9e5e6){return new Promise((_0x1a65d5,_0x1e0297)=>{const _0x5e7cbf=document['createElement']('script');_0x5e7cbf['setAttribute']('src',_0xc9e5e6),_0x5e7cbf['onload']=_0x1a65d5,_0x5e7cbf['onerror']=_0x418415=>{const _0x15d6ee=X('internal-error');_0x15d6ee['customData']=_0x418415,_0x1e0297(_0x15d6ee);},_0x5e7cbf['type']='text/javascript',_0x5e7cbf['charset']='UTF-8',__()['appendChild'](_0x5e7cbf);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};