const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3c2e29,_0x4c18ec){if(!_0x3c2e29)throw ht(_0x4c18ec);},ht=function(_0x1c9a8d){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1c9a8d);},Hr=function(_0x4d0325){const _0x2c3bdb=[];let _0x5c821f=0x0;for(let _0x5459b7=0x0;_0x5459b7<_0x4d0325['length'];_0x5459b7++){let _0x1b845f=_0x4d0325['charCodeAt'](_0x5459b7);_0x1b845f<0x80?_0x2c3bdb[_0x5c821f++]=_0x1b845f:_0x1b845f<0x800?(_0x2c3bdb[_0x5c821f++]=_0x1b845f>>0x6|0xc0,_0x2c3bdb[_0x5c821f++]=_0x1b845f&0x3f|0x80):(_0x1b845f&0xfc00)===0xd800&&_0x5459b7+0x1<_0x4d0325['length']&&(_0x4d0325['charCodeAt'](_0x5459b7+0x1)&0xfc00)===0xdc00?(_0x1b845f=0x10000+((_0x1b845f&0x3ff)<<0xa)+(_0x4d0325['charCodeAt'](++_0x5459b7)&0x3ff),_0x2c3bdb[_0x5c821f++]=_0x1b845f>>0x12|0xf0,_0x2c3bdb[_0x5c821f++]=_0x1b845f>>0xc&0x3f|0x80,_0x2c3bdb[_0x5c821f++]=_0x1b845f>>0x6&0x3f|0x80,_0x2c3bdb[_0x5c821f++]=_0x1b845f&0x3f|0x80):(_0x2c3bdb[_0x5c821f++]=_0x1b845f>>0xc|0xe0,_0x2c3bdb[_0x5c821f++]=_0x1b845f>>0x6&0x3f|0x80,_0x2c3bdb[_0x5c821f++]=_0x1b845f&0x3f|0x80);}return _0x2c3bdb;},nc=function(_0x71d1){const _0x5ce2d0=[];let _0x23e16f=0x0,_0x2135ae=0x0;for(;_0x23e16f<_0x71d1['length'];){const _0x55da14=_0x71d1[_0x23e16f++];if(_0x55da14<0x80)_0x5ce2d0[_0x2135ae++]=String['fromCharCode'](_0x55da14);else{if(_0x55da14>0xbf&&_0x55da14<0xe0){const _0x19c8ad=_0x71d1[_0x23e16f++];_0x5ce2d0[_0x2135ae++]=String['fromCharCode']((_0x55da14&0x1f)<<0x6|_0x19c8ad&0x3f);}else{if(_0x55da14>0xef&&_0x55da14<0x16d){const _0x183b96=_0x71d1[_0x23e16f++],_0x1ca48f=_0x71d1[_0x23e16f++],_0x17c9d0=_0x71d1[_0x23e16f++],_0xdbfdd6=((_0x55da14&0x7)<<0x12|(_0x183b96&0x3f)<<0xc|(_0x1ca48f&0x3f)<<0x6|_0x17c9d0&0x3f)-0x10000;_0x5ce2d0[_0x2135ae++]=String['fromCharCode'](0xd800+(_0xdbfdd6>>0xa)),_0x5ce2d0[_0x2135ae++]=String['fromCharCode'](0xdc00+(_0xdbfdd6&0x3ff));}else{const _0x541653=_0x71d1[_0x23e16f++],_0x5db798=_0x71d1[_0x23e16f++];_0x5ce2d0[_0x2135ae++]=String['fromCharCode']((_0x55da14&0xf)<<0xc|(_0x541653&0x3f)<<0x6|_0x5db798&0x3f);}}}}return _0x5ce2d0['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x44d08b,_0x731cdf){if(!Array['isArray'](_0x44d08b))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x439572=_0x731cdf?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x38a182=[];for(let _0xdc8aeb=0x0;_0xdc8aeb<_0x44d08b['length'];_0xdc8aeb+=0x3){const _0x3417d6=_0x44d08b[_0xdc8aeb],_0x7be2d4=_0xdc8aeb+0x1<_0x44d08b['length'],_0x3e9fb2=_0x7be2d4?_0x44d08b[_0xdc8aeb+0x1]:0x0,_0x585bf5=_0xdc8aeb+0x2<_0x44d08b['length'],_0x42d877=_0x585bf5?_0x44d08b[_0xdc8aeb+0x2]:0x0,_0x3cc625=_0x3417d6>>0x2,_0xbf8e60=(_0x3417d6&0x3)<<0x4|_0x3e9fb2>>0x4;let _0x2127ab=(_0x3e9fb2&0xf)<<0x2|_0x42d877>>0x6,_0x939c9a=_0x42d877&0x3f;_0x585bf5||(_0x939c9a=0x40,_0x7be2d4||(_0x2127ab=0x40)),_0x38a182['push'](_0x439572[_0x3cc625],_0x439572[_0xbf8e60],_0x439572[_0x2127ab],_0x439572[_0x939c9a]);}return _0x38a182['join']('');},'encodeString'(_0x541ed8,_0xef5a85){return this['HAS_NATIVE_SUPPORT']&&!_0xef5a85?btoa(_0x541ed8):this['encodeByteArray'](Hr(_0x541ed8),_0xef5a85);},'decodeString'(_0x2f7940,_0x5be85f){return this['HAS_NATIVE_SUPPORT']&&!_0x5be85f?atob(_0x2f7940):nc(this['decodeStringToByteArray'](_0x2f7940,_0x5be85f));},'decodeStringToByteArray'(_0x912b37,_0x487ec6){this['init_']();const _0x186d49=_0x487ec6?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x1ed1d8=[];for(let _0x244152=0x0;_0x244152<_0x912b37['length'];){const _0x136d67=_0x186d49[_0x912b37['charAt'](_0x244152++)],_0x1f0e29=_0x244152<_0x912b37['length']?_0x186d49[_0x912b37['charAt'](_0x244152)]:0x0;++_0x244152;const _0x18eb49=_0x244152<_0x912b37['length']?_0x186d49[_0x912b37['charAt'](_0x244152)]:0x40;++_0x244152;const _0x3d7a13=_0x244152<_0x912b37['length']?_0x186d49[_0x912b37['charAt'](_0x244152)]:0x40;if(++_0x244152,_0x136d67==null||_0x1f0e29==null||_0x18eb49==null||_0x3d7a13==null)throw new ic();const _0x274c83=_0x136d67<<0x2|_0x1f0e29>>0x4;if(_0x1ed1d8['push'](_0x274c83),_0x18eb49!==0x40){const _0x4660d5=_0x1f0e29<<0x4&0xf0|_0x18eb49>>0x2;if(_0x1ed1d8['push'](_0x4660d5),_0x3d7a13!==0x40){const _0x4f873b=_0x18eb49<<0x6&0xc0|_0x3d7a13;_0x1ed1d8['push'](_0x4f873b);}}}return _0x1ed1d8;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x1faf85=0x0;_0x1faf85<this['ENCODED_VALS']['length'];_0x1faf85++)this['byteToCharMap_'][_0x1faf85]=this['ENCODED_VALS']['charAt'](_0x1faf85),this['charToByteMap_'][this['byteToCharMap_'][_0x1faf85]]=_0x1faf85,this['byteToCharMapWebSafe_'][_0x1faf85]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1faf85),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x1faf85]]=_0x1faf85,_0x1faf85>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1faf85)]=_0x1faf85,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x1faf85)]=_0x1faf85);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x529c11){const _0x2ca955=Hr(_0x529c11);return Fi['encodeByteArray'](_0x2ca955,!0x0);},dn=function(_0x464bb7){return $r(_0x464bb7)['replace'](/\./g,'');},fn=function(_0x2dc4ac){try{return Fi['decodeString'](_0x2dc4ac,!0x0);}catch(_0x3d4bc0){console['error']('base64Decode\x20failed:\x20',_0x3d4bc0);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x60ae1f){return Gr(void 0x0,_0x60ae1f);}function Gr(_0x3ee340,_0x26d5b3){if(!(_0x26d5b3 instanceof Object))return _0x26d5b3;switch(_0x26d5b3['constructor']){case Date:const _0x18cbe9=_0x26d5b3;return new Date(_0x18cbe9['getTime']());case Object:_0x3ee340===void 0x0&&(_0x3ee340={});break;case Array:_0x3ee340=[];break;default:return _0x26d5b3;}for(const _0xf89fc4 in _0x26d5b3)!_0x26d5b3['hasOwnProperty'](_0xf89fc4)||!rc(_0xf89fc4)||(_0x3ee340[_0xf89fc4]=Gr(_0x3ee340[_0xf89fc4],_0x26d5b3[_0xf89fc4]));return _0x3ee340;}function rc(_0x479176){return _0x479176!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x39ca47=Ps['__FIREBASE_DEFAULTS__'];if(_0x39ca47)return JSON['parse'](_0x39ca47);},lc=()=>{if(typeof document>'u')return;let _0x396927;try{_0x396927=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4e9b06=_0x396927&&fn(_0x396927[0x1]);return _0x4e9b06&&JSON['parse'](_0x4e9b06);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0xa1de0b){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xa1de0b);return;}},qr=_0x4ec958=>{var _0x467625,_0x1cdb32;return(_0x1cdb32=(_0x467625=Ui())==null?void 0x0:_0x467625['emulatorHosts'])==null?void 0x0:_0x1cdb32[_0x4ec958];},hc=_0x3c7970=>{const _0x589822=qr(_0x3c7970);if(!_0x589822)return;const _0xf4da4e=_0x589822['lastIndexOf'](':');if(_0xf4da4e<=0x0||_0xf4da4e+0x1===_0x589822['length'])throw new Error('Invalid\x20host\x20'+_0x589822+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4f735a=parseInt(_0x589822['substring'](_0xf4da4e+0x1),0xa);return _0x589822[0x0]==='['?[_0x589822['substring'](0x1,_0xf4da4e-0x1),_0x4f735a]:[_0x589822['substring'](0x0,_0xf4da4e),_0x4f735a];},zr=()=>{var _0x4bdd66;return(_0x4bdd66=Ui())==null?void 0x0:_0x4bdd66['config'];},jr=_0x8acf3e=>{var _0x4a5d06;return(_0x4a5d06=Ui())==null?void 0x0:_0x4a5d06['_'+_0x8acf3e];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0xea8a76,_0x380dd6)=>{this['resolve']=_0xea8a76,this['reject']=_0x380dd6;});}['wrapCallback'](_0x6126e2){return(_0x4e7553,_0x19abac)=>{_0x4e7553?this['reject'](_0x4e7553):this['resolve'](_0x19abac),typeof _0x6126e2=='function'&&(this['promise']['catch'](()=>{}),_0x6126e2['length']===0x1?_0x6126e2(_0x4e7553):_0x6126e2(_0x4e7553,_0x19abac));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x35fbff,_0x5a3a91){if(_0x35fbff['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5993c0={'alg':'none','type':'JWT'},_0x3148a1=_0x5a3a91||'demo-project',_0x4ebb0c=_0x35fbff['iat']||0x0,_0x433e78=_0x35fbff['sub']||_0x35fbff['user_id'];if(!_0x433e78)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x54ac4c={'iss':'https://securetoken.google.com/'+_0x3148a1,'aud':_0x3148a1,'iat':_0x4ebb0c,'exp':_0x4ebb0c+0xe10,'auth_time':_0x4ebb0c,'sub':_0x433e78,'user_id':_0x433e78,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x35fbff};return[dn(JSON['stringify'](_0x5993c0)),dn(JSON['stringify'](_0x54ac4c)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x5eb96a=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5eb96a=='object'&&_0x5eb96a['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x177386=W();return _0x177386['indexOf']('MSIE\x20')>=0x0||_0x177386['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x3917aa,_0x131636)=>{try{let _0x10b02c=!0x0;const _0x34eaf0='validate-browser-context-for-indexeddb-analytics-module',_0x44046d=self['indexedDB']['open'](_0x34eaf0);_0x44046d['onsuccess']=()=>{_0x44046d['result']['close'](),_0x10b02c||self['indexedDB']['deleteDatabase'](_0x34eaf0),_0x3917aa(!0x0);},_0x44046d['onupgradeneeded']=()=>{_0x10b02c=!0x1;},_0x44046d['onerror']=()=>{var _0xd9ce6d;_0x131636(((_0xd9ce6d=_0x44046d['error'])==null?void 0x0:_0xd9ce6d['message'])||'');};}catch(_0x390588){_0x131636(_0x390588);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x466801,_0x5bb859,_0xd686ed){super(_0x5bb859),this['code']=_0x466801,this['customData']=_0xd686ed,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x1a3ae3,_0x435b34,_0x5967e4){this['service']=_0x1a3ae3,this['serviceName']=_0x435b34,this['errors']=_0x5967e4;}['create'](_0x1e05dc,..._0xd63314){const _0x17645e=_0xd63314[0x0]||{},_0x62dca3=this['service']+'/'+_0x1e05dc,_0x35b525=this['errors'][_0x1e05dc],_0x2c6c39=_0x35b525?vc(_0x35b525,_0x17645e):'Error',_0x540ca6=this['serviceName']+':\x20'+_0x2c6c39+'\x20('+_0x62dca3+').';return new Re(_0x62dca3,_0x540ca6,_0x17645e);}}function vc(_0x106a09,_0x3e890b){return _0x106a09['replace'](Ec,(_0x161d35,_0x7ce854)=>{const _0x30b21f=_0x3e890b[_0x7ce854];return _0x30b21f!=null?String(_0x30b21f):'<'+_0x7ce854+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x35bd93){return JSON['parse'](_0x35bd93);}function O(_0x2eeab){return JSON['stringify'](_0x2eeab);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x584f2c){let _0x5a22eb={},_0x12d580={},_0x5b65b={},_0x299c9e='';try{const _0x25d9e5=_0x584f2c['split']('.');_0x5a22eb=Nt(fn(_0x25d9e5[0x0])||''),_0x12d580=Nt(fn(_0x25d9e5[0x1])||''),_0x299c9e=_0x25d9e5[0x2],_0x5b65b=_0x12d580['d']||{},delete _0x12d580['d'];}catch{}return{'header':_0x5a22eb,'claims':_0x12d580,'data':_0x5b65b,'signature':_0x299c9e};},Ic=function(_0x4e28a0){const _0x29cd71=Yr(_0x4e28a0),_0x19b89a=_0x29cd71['claims'];return!!_0x19b89a&&typeof _0x19b89a=='object'&&_0x19b89a['hasOwnProperty']('iat');},wc=function(_0x46d73a){const _0x4fe61c=Yr(_0x46d73a)['claims'];return typeof _0x4fe61c=='object'&&_0x4fe61c['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x169b7e,_0x44f8ca){return Object['prototype']['hasOwnProperty']['call'](_0x169b7e,_0x44f8ca);}function Le(_0x4ad651,_0x5dbf50){if(Object['prototype']['hasOwnProperty']['call'](_0x4ad651,_0x5dbf50))return _0x4ad651[_0x5dbf50];}function pn(_0x181dba){for(const _0x4df491 in _0x181dba)if(Object['prototype']['hasOwnProperty']['call'](_0x181dba,_0x4df491))return!0x1;return!0x0;}function _n(_0x8811a5,_0x35f523,_0xb2a3e2){const _0x10646c={};for(const _0x1f6a0a in _0x8811a5)Object['prototype']['hasOwnProperty']['call'](_0x8811a5,_0x1f6a0a)&&(_0x10646c[_0x1f6a0a]=_0x35f523['call'](_0xb2a3e2,_0x8811a5[_0x1f6a0a],_0x1f6a0a,_0x8811a5));return _0x10646c;}function xe(_0x2d91a5,_0x5ef36a){if(_0x2d91a5===_0x5ef36a)return!0x0;const _0x20ae9d=Object['keys'](_0x2d91a5),_0x5abf30=Object['keys'](_0x5ef36a);for(const _0x53e12d of _0x20ae9d){if(!_0x5abf30['includes'](_0x53e12d))return!0x1;const _0x2b5da9=_0x2d91a5[_0x53e12d],_0xe575ca=_0x5ef36a[_0x53e12d];if(Ns(_0x2b5da9)&&Ns(_0xe575ca)){if(!xe(_0x2b5da9,_0xe575ca))return!0x1;}else{if(_0x2b5da9!==_0xe575ca)return!0x1;}}for(const _0x48abef of _0x5abf30)if(!_0x20ae9d['includes'](_0x48abef))return!0x1;return!0x0;}function Ns(_0x29e1d8){return _0x29e1d8!==null&&typeof _0x29e1d8=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x5def58){const _0x52aa53=[];for(const [_0x5e3c5f,_0x24f7e4]of Object['entries'](_0x5def58))Array['isArray'](_0x24f7e4)?_0x24f7e4['forEach'](_0x181de3=>{_0x52aa53['push'](encodeURIComponent(_0x5e3c5f)+'='+encodeURIComponent(_0x181de3));}):_0x52aa53['push'](encodeURIComponent(_0x5e3c5f)+'='+encodeURIComponent(_0x24f7e4));return _0x52aa53['length']?'&'+_0x52aa53['join']('&'):'';}function Ct(_0x4b03ae){const _0x2798b3={};return _0x4b03ae['replace'](/^\?/,'')['split']('&')['forEach'](_0x2e6a05=>{if(_0x2e6a05){const [_0x4fca12,_0x2c8165]=_0x2e6a05['split']('=');_0x2798b3[decodeURIComponent(_0x4fca12)]=decodeURIComponent(_0x2c8165);}}),_0x2798b3;}function Tt(_0x1943a0){const _0x25ab9d=_0x1943a0['indexOf']('?');if(!_0x25ab9d)return'';const _0x263577=_0x1943a0['indexOf']('#',_0x25ab9d);return _0x1943a0['substring'](_0x25ab9d,_0x263577>0x0?_0x263577:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x4b3b6f=0x1;_0x4b3b6f<this['blockSize'];++_0x4b3b6f)this['pad_'][_0x4b3b6f]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x35a17a,_0x48c45a){_0x48c45a||(_0x48c45a=0x0);const _0x587d42=this['W_'];if(typeof _0x35a17a=='string'){for(let _0x3a7fd1=0x0;_0x3a7fd1<0x10;_0x3a7fd1++)_0x587d42[_0x3a7fd1]=_0x35a17a['charCodeAt'](_0x48c45a)<<0x18|_0x35a17a['charCodeAt'](_0x48c45a+0x1)<<0x10|_0x35a17a['charCodeAt'](_0x48c45a+0x2)<<0x8|_0x35a17a['charCodeAt'](_0x48c45a+0x3),_0x48c45a+=0x4;}else{for(let _0x39cdfe=0x0;_0x39cdfe<0x10;_0x39cdfe++)_0x587d42[_0x39cdfe]=_0x35a17a[_0x48c45a]<<0x18|_0x35a17a[_0x48c45a+0x1]<<0x10|_0x35a17a[_0x48c45a+0x2]<<0x8|_0x35a17a[_0x48c45a+0x3],_0x48c45a+=0x4;}for(let _0x43c833=0x10;_0x43c833<0x50;_0x43c833++){const _0x2cb77f=_0x587d42[_0x43c833-0x3]^_0x587d42[_0x43c833-0x8]^_0x587d42[_0x43c833-0xe]^_0x587d42[_0x43c833-0x10];_0x587d42[_0x43c833]=(_0x2cb77f<<0x1|_0x2cb77f>>>0x1f)&0xffffffff;}let _0x319460=this['chain_'][0x0],_0x15a5cb=this['chain_'][0x1],_0x4fed32=this['chain_'][0x2],_0x1f196e=this['chain_'][0x3],_0x14ef72=this['chain_'][0x4],_0x56e2c,_0x120343;for(let _0x50a1b6=0x0;_0x50a1b6<0x50;_0x50a1b6++){_0x50a1b6<0x28?_0x50a1b6<0x14?(_0x56e2c=_0x1f196e^_0x15a5cb&(_0x4fed32^_0x1f196e),_0x120343=0x5a827999):(_0x56e2c=_0x15a5cb^_0x4fed32^_0x1f196e,_0x120343=0x6ed9eba1):_0x50a1b6<0x3c?(_0x56e2c=_0x15a5cb&_0x4fed32|_0x1f196e&(_0x15a5cb|_0x4fed32),_0x120343=0x8f1bbcdc):(_0x56e2c=_0x15a5cb^_0x4fed32^_0x1f196e,_0x120343=0xca62c1d6);const _0x3b927e=(_0x319460<<0x5|_0x319460>>>0x1b)+_0x56e2c+_0x14ef72+_0x120343+_0x587d42[_0x50a1b6]&0xffffffff;_0x14ef72=_0x1f196e,_0x1f196e=_0x4fed32,_0x4fed32=(_0x15a5cb<<0x1e|_0x15a5cb>>>0x2)&0xffffffff,_0x15a5cb=_0x319460,_0x319460=_0x3b927e;}this['chain_'][0x0]=this['chain_'][0x0]+_0x319460&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x15a5cb&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4fed32&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1f196e&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x14ef72&0xffffffff;}['update'](_0x4b888a,_0x4de8da){if(_0x4b888a==null)return;_0x4de8da===void 0x0&&(_0x4de8da=_0x4b888a['length']);const _0x49a429=_0x4de8da-this['blockSize'];let _0x4c161a=0x0;const _0x168314=this['buf_'];let _0x1a3bbb=this['inbuf_'];for(;_0x4c161a<_0x4de8da;){if(_0x1a3bbb===0x0){for(;_0x4c161a<=_0x49a429;)this['compress_'](_0x4b888a,_0x4c161a),_0x4c161a+=this['blockSize'];}if(typeof _0x4b888a=='string'){for(;_0x4c161a<_0x4de8da;)if(_0x168314[_0x1a3bbb]=_0x4b888a['charCodeAt'](_0x4c161a),++_0x1a3bbb,++_0x4c161a,_0x1a3bbb===this['blockSize']){this['compress_'](_0x168314),_0x1a3bbb=0x0;break;}}else{for(;_0x4c161a<_0x4de8da;)if(_0x168314[_0x1a3bbb]=_0x4b888a[_0x4c161a],++_0x1a3bbb,++_0x4c161a,_0x1a3bbb===this['blockSize']){this['compress_'](_0x168314),_0x1a3bbb=0x0;break;}}}this['inbuf_']=_0x1a3bbb,this['total_']+=_0x4de8da;}['digest'](){const _0x447341=[];let _0x550b8a=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0xdb0273=this['blockSize']-0x1;_0xdb0273>=0x38;_0xdb0273--)this['buf_'][_0xdb0273]=_0x550b8a&0xff,_0x550b8a/=0x100;this['compress_'](this['buf_']);let _0x4646df=0x0;for(let _0x3f69df=0x0;_0x3f69df<0x5;_0x3f69df++)for(let _0x11c953=0x18;_0x11c953>=0x0;_0x11c953-=0x8)_0x447341[_0x4646df]=this['chain_'][_0x3f69df]>>_0x11c953&0xff,++_0x4646df;return _0x447341;}}function Tc(_0x59da30,_0x1ba09d){const _0x4ea205=new Sc(_0x59da30,_0x1ba09d);return _0x4ea205['subscribe']['bind'](_0x4ea205);}class Sc{constructor(_0x44ac16,_0x4d3bbe){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4d3bbe,this['task']['then'](()=>{_0x44ac16(this);})['catch'](_0x43487b=>{this['error'](_0x43487b);});}['next'](_0x45b581){this['forEachObserver'](_0x4eb706=>{_0x4eb706['next'](_0x45b581);});}['error'](_0x1c2b22){this['forEachObserver'](_0xe30c21=>{_0xe30c21['error'](_0x1c2b22);}),this['close'](_0x1c2b22);}['complete'](){this['forEachObserver'](_0x49f3ea=>{_0x49f3ea['complete']();}),this['close']();}['subscribe'](_0x3272f7,_0x5e3ce8,_0x18a0c8){let _0x42c4e6;if(_0x3272f7===void 0x0&&_0x5e3ce8===void 0x0&&_0x18a0c8===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x3272f7,['next','error','complete'])?_0x42c4e6=_0x3272f7:_0x42c4e6={'next':_0x3272f7,'error':_0x5e3ce8,'complete':_0x18a0c8},_0x42c4e6['next']===void 0x0&&(_0x42c4e6['next']=ti),_0x42c4e6['error']===void 0x0&&(_0x42c4e6['error']=ti),_0x42c4e6['complete']===void 0x0&&(_0x42c4e6['complete']=ti);const _0x3a1b4d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x42c4e6['error'](this['finalError']):_0x42c4e6['complete']();}catch{}}),this['observers']['push'](_0x42c4e6),_0x3a1b4d;}['unsubscribeOne'](_0x53186b){this['observers']===void 0x0||this['observers'][_0x53186b]===void 0x0||(delete this['observers'][_0x53186b],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x401545){if(!this['finalized']){for(let _0xeb83ff=0x0;_0xeb83ff<this['observers']['length'];_0xeb83ff++)this['sendOne'](_0xeb83ff,_0x401545);}}['sendOne'](_0x4c493a,_0x264bc7){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4c493a]!==void 0x0)try{_0x264bc7(this['observers'][_0x4c493a]);}catch(_0x2960e1){typeof console<'u'&&console['error']&&console['error'](_0x2960e1);}});}['close'](_0x1deb2b){this['finalized']||(this['finalized']=!0x0,_0x1deb2b!==void 0x0&&(this['finalError']=_0x1deb2b),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x3edc5b,_0x3be2a0){if(typeof _0x3edc5b!='object'||_0x3edc5b===null)return!0x1;for(const _0x8b0335 of _0x3be2a0)if(_0x8b0335 in _0x3edc5b&&typeof _0x3edc5b[_0x8b0335]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x37cf2a,_0x4308d1){return _0x37cf2a+'\x20failed:\x20'+_0x4308d1+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x830f0d){const _0x33bd03=[];let _0x16fe84=0x0;for(let _0x58dbcc=0x0;_0x58dbcc<_0x830f0d['length'];_0x58dbcc++){let _0x427b1e=_0x830f0d['charCodeAt'](_0x58dbcc);if(_0x427b1e>=0xd800&&_0x427b1e<=0xdbff){const _0x17d5a7=_0x427b1e-0xd800;_0x58dbcc++,f(_0x58dbcc<_0x830f0d['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x375d9d=_0x830f0d['charCodeAt'](_0x58dbcc)-0xdc00;_0x427b1e=0x10000+(_0x17d5a7<<0xa)+_0x375d9d;}_0x427b1e<0x80?_0x33bd03[_0x16fe84++]=_0x427b1e:_0x427b1e<0x800?(_0x33bd03[_0x16fe84++]=_0x427b1e>>0x6|0xc0,_0x33bd03[_0x16fe84++]=_0x427b1e&0x3f|0x80):_0x427b1e<0x10000?(_0x33bd03[_0x16fe84++]=_0x427b1e>>0xc|0xe0,_0x33bd03[_0x16fe84++]=_0x427b1e>>0x6&0x3f|0x80,_0x33bd03[_0x16fe84++]=_0x427b1e&0x3f|0x80):(_0x33bd03[_0x16fe84++]=_0x427b1e>>0x12|0xf0,_0x33bd03[_0x16fe84++]=_0x427b1e>>0xc&0x3f|0x80,_0x33bd03[_0x16fe84++]=_0x427b1e>>0x6&0x3f|0x80,_0x33bd03[_0x16fe84++]=_0x427b1e&0x3f|0x80);}return _0x33bd03;},Ln=function(_0x3e99ac){let _0x4cc1c5=0x0;for(let _0x13a6c4=0x0;_0x13a6c4<_0x3e99ac['length'];_0x13a6c4++){const _0x1c0876=_0x3e99ac['charCodeAt'](_0x13a6c4);_0x1c0876<0x80?_0x4cc1c5++:_0x1c0876<0x800?_0x4cc1c5+=0x2:_0x1c0876>=0xd800&&_0x1c0876<=0xdbff?(_0x4cc1c5+=0x4,_0x13a6c4++):_0x4cc1c5+=0x3;}return _0x4cc1c5;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x382b0d){return _0x382b0d&&_0x382b0d['_delegate']?_0x382b0d['_delegate']:_0x382b0d;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x5663e9){try{return(_0x5663e9['startsWith']('http://')||_0x5663e9['startsWith']('https://')?new URL(_0x5663e9)['hostname']:_0x5663e9)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x229166){return(await fetch(_0x229166,{'credentials':'include'}))['ok'];}class Fe{constructor(_0xbf85e,_0xa6c35,_0x441c49){this['name']=_0xbf85e,this['instanceFactory']=_0xa6c35,this['type']=_0x441c49,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x46fe3c){return this['instantiationMode']=_0x46fe3c,this;}['setMultipleInstances'](_0x19ba3f){return this['multipleInstances']=_0x19ba3f,this;}['setServiceProps'](_0x1ea210){return this['serviceProps']=_0x1ea210,this;}['setInstanceCreatedCallback'](_0x1e0e6a){return this['onInstanceCreated']=_0x1e0e6a,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3e2e69,_0x454939){this['name']=_0x3e2e69,this['container']=_0x454939,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5840bc){const _0xd5a43f=this['normalizeInstanceIdentifier'](_0x5840bc);if(!this['instancesDeferred']['has'](_0xd5a43f)){const _0x381602=new H();if(this['instancesDeferred']['set'](_0xd5a43f,_0x381602),this['isInitialized'](_0xd5a43f)||this['shouldAutoInitialize']())try{const _0x1406b4=this['getOrInitializeService']({'instanceIdentifier':_0xd5a43f});_0x1406b4&&_0x381602['resolve'](_0x1406b4);}catch{}}return this['instancesDeferred']['get'](_0xd5a43f)['promise'];}['getImmediate'](_0x91e0d8){const _0x18fc21=this['normalizeInstanceIdentifier'](_0x91e0d8==null?void 0x0:_0x91e0d8['identifier']),_0x20ab46=(_0x91e0d8==null?void 0x0:_0x91e0d8['optional'])??!0x1;if(this['isInitialized'](_0x18fc21)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x18fc21});}catch(_0x1ed129){if(_0x20ab46)return null;throw _0x1ed129;}else{if(_0x20ab46)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x223b0f){if(_0x223b0f['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x223b0f['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x223b0f,!!this['shouldAutoInitialize']()){if(Pc(_0x223b0f))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x1c8e58,_0x31c966]of this['instancesDeferred']['entries']()){const _0x215b97=this['normalizeInstanceIdentifier'](_0x1c8e58);try{const _0xbacfb3=this['getOrInitializeService']({'instanceIdentifier':_0x215b97});_0x31c966['resolve'](_0xbacfb3);}catch{}}}}['clearInstance'](_0x51bd30=Ne){this['instancesDeferred']['delete'](_0x51bd30),this['instancesOptions']['delete'](_0x51bd30),this['instances']['delete'](_0x51bd30);}async['delete'](){const _0x133f57=Array['from'](this['instances']['values']());await Promise['all']([..._0x133f57['filter'](_0x2a79d2=>'INTERNAL'in _0x2a79d2)['map'](_0x2a3425=>_0x2a3425['INTERNAL']['delete']()),..._0x133f57['filter'](_0x5056e2=>'_delete'in _0x5056e2)['map'](_0x264bb3=>_0x264bb3['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x3acfb9=Ne){return this['instances']['has'](_0x3acfb9);}['getOptions'](_0xe07dba=Ne){return this['instancesOptions']['get'](_0xe07dba)||{};}['initialize'](_0xa1cb93={}){const {options:_0x424f71={}}=_0xa1cb93,_0x5a40a8=this['normalizeInstanceIdentifier'](_0xa1cb93['instanceIdentifier']);if(this['isInitialized'](_0x5a40a8))throw Error(this['name']+'('+_0x5a40a8+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x37169a=this['getOrInitializeService']({'instanceIdentifier':_0x5a40a8,'options':_0x424f71});for(const [_0x1399a3,_0xb91d3f]of this['instancesDeferred']['entries']()){const _0x2a3228=this['normalizeInstanceIdentifier'](_0x1399a3);_0x5a40a8===_0x2a3228&&_0xb91d3f['resolve'](_0x37169a);}return _0x37169a;}['onInit'](_0x3e2c8c,_0x4bb86e){const _0x8b2f37=this['normalizeInstanceIdentifier'](_0x4bb86e),_0x239d07=this['onInitCallbacks']['get'](_0x8b2f37)??new Set();_0x239d07['add'](_0x3e2c8c),this['onInitCallbacks']['set'](_0x8b2f37,_0x239d07);const _0x1a07f4=this['instances']['get'](_0x8b2f37);return _0x1a07f4&&_0x3e2c8c(_0x1a07f4,_0x8b2f37),()=>{_0x239d07['delete'](_0x3e2c8c);};}['invokeOnInitCallbacks'](_0x1539de,_0x5c4f95){const _0x42a43e=this['onInitCallbacks']['get'](_0x5c4f95);if(_0x42a43e){for(const _0x28b8b5 of _0x42a43e)try{_0x28b8b5(_0x1539de,_0x5c4f95);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x53dc03,options:_0x21fa3a={}}){let _0x524139=this['instances']['get'](_0x53dc03);if(!_0x524139&&this['component']&&(_0x524139=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x53dc03),'options':_0x21fa3a}),this['instances']['set'](_0x53dc03,_0x524139),this['instancesOptions']['set'](_0x53dc03,_0x21fa3a),this['invokeOnInitCallbacks'](_0x524139,_0x53dc03),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x53dc03,_0x524139);}catch{}return _0x524139||null;}['normalizeInstanceIdentifier'](_0x18e38d=Ne){return this['component']?this['component']['multipleInstances']?_0x18e38d:Ne:_0x18e38d;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x163f45){return _0x163f45===Ne?void 0x0:_0x163f45;}function Pc(_0x2c500b){return _0x2c500b['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x22cc30){this['name']=_0x22cc30,this['providers']=new Map();}['addComponent'](_0x39d511){const _0xf527ae=this['getProvider'](_0x39d511['name']);if(_0xf527ae['isComponentSet']())throw new Error('Component\x20'+_0x39d511['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xf527ae['setComponent'](_0x39d511);}['addOrOverwriteComponent'](_0x3650fc){this['getProvider'](_0x3650fc['name'])['isComponentSet']()&&this['providers']['delete'](_0x3650fc['name']),this['addComponent'](_0x3650fc);}['getProvider'](_0x321f1f){if(this['providers']['has'](_0x321f1f))return this['providers']['get'](_0x321f1f);const _0x2ac05f=new Ac(_0x321f1f,this);return this['providers']['set'](_0x321f1f,_0x2ac05f),_0x2ac05f;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x4d5f2b){_0x4d5f2b[_0x4d5f2b['DEBUG']=0x0]='DEBUG',_0x4d5f2b[_0x4d5f2b['VERBOSE']=0x1]='VERBOSE',_0x4d5f2b[_0x4d5f2b['INFO']=0x2]='INFO',_0x4d5f2b[_0x4d5f2b['WARN']=0x3]='WARN',_0x4d5f2b[_0x4d5f2b['ERROR']=0x4]='ERROR',_0x4d5f2b[_0x4d5f2b['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x5d2482,_0x394005,..._0x2d64ba)=>{if(_0x394005<_0x5d2482['logLevel'])return;const _0xd7d620=new Date()['toISOString'](),_0x557e52=Mc[_0x394005];if(_0x557e52)console[_0x557e52]('['+_0xd7d620+']\x20\x20'+_0x5d2482['name']+':',..._0x2d64ba);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x394005+')');};class Bi{constructor(_0x743b7c){this['name']=_0x743b7c,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x2385d0){if(!(_0x2385d0 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x2385d0+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x2385d0;}['setLogLevel'](_0x31fad7){this['_logLevel']=typeof _0x31fad7=='string'?Oc[_0x31fad7]:_0x31fad7;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x571d6e){if(typeof _0x571d6e!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x571d6e;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x3868ad){this['_userLogHandler']=_0x3868ad;}['debug'](..._0x5d8953){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x5d8953),this['_logHandler'](this,T['DEBUG'],..._0x5d8953);}['log'](..._0xa581f4){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0xa581f4),this['_logHandler'](this,T['VERBOSE'],..._0xa581f4);}['info'](..._0x422bbe){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x422bbe),this['_logHandler'](this,T['INFO'],..._0x422bbe);}['warn'](..._0x451bd9){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x451bd9),this['_logHandler'](this,T['WARN'],..._0x451bd9);}['error'](..._0x352a7f){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x352a7f),this['_logHandler'](this,T['ERROR'],..._0x352a7f);}}const xc=(_0x299a1b,_0xdd7570)=>_0xdd7570['some'](_0xea8e4a=>_0x299a1b instanceof _0xea8e4a);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0xc9cd41){const _0x4dcad5=new Promise((_0x146267,_0x2d6092)=>{const _0x10479b=()=>{_0xc9cd41['removeEventListener']('success',_0x449764),_0xc9cd41['removeEventListener']('error',_0x263601);},_0x449764=()=>{_0x146267(ge(_0xc9cd41['result'])),_0x10479b();},_0x263601=()=>{_0x2d6092(_0xc9cd41['error']),_0x10479b();};_0xc9cd41['addEventListener']('success',_0x449764),_0xc9cd41['addEventListener']('error',_0x263601);});return _0x4dcad5['then'](_0x331fd8=>{_0x331fd8 instanceof IDBCursor&&Jr['set'](_0x331fd8,_0xc9cd41);})['catch'](()=>{}),Vi['set'](_0x4dcad5,_0xc9cd41),_0x4dcad5;}function Bc(_0x3f3567){if(_i['has'](_0x3f3567))return;const _0x2c1827=new Promise((_0x40199c,_0x4ac8b9)=>{const _0x2161e2=()=>{_0x3f3567['removeEventListener']('complete',_0x2db094),_0x3f3567['removeEventListener']('error',_0x51f278),_0x3f3567['removeEventListener']('abort',_0x51f278);},_0x2db094=()=>{_0x40199c(),_0x2161e2();},_0x51f278=()=>{_0x4ac8b9(_0x3f3567['error']||new DOMException('AbortError','AbortError')),_0x2161e2();};_0x3f3567['addEventListener']('complete',_0x2db094),_0x3f3567['addEventListener']('error',_0x51f278),_0x3f3567['addEventListener']('abort',_0x51f278);});_i['set'](_0x3f3567,_0x2c1827);}let gi={'get'(_0x18546d,_0x37f1a0,_0x3f97ae){if(_0x18546d instanceof IDBTransaction){if(_0x37f1a0==='done')return _i['get'](_0x18546d);if(_0x37f1a0==='objectStoreNames')return _0x18546d['objectStoreNames']||Xr['get'](_0x18546d);if(_0x37f1a0==='store')return _0x3f97ae['objectStoreNames'][0x1]?void 0x0:_0x3f97ae['objectStore'](_0x3f97ae['objectStoreNames'][0x0]);}return ge(_0x18546d[_0x37f1a0]);},'set'(_0x847336,_0x2a58b5,_0x57f5eb){return _0x847336[_0x2a58b5]=_0x57f5eb,!0x0;},'has'(_0x246b6f,_0x4cd8da){return _0x246b6f instanceof IDBTransaction&&(_0x4cd8da==='done'||_0x4cd8da==='store')?!0x0:_0x4cd8da in _0x246b6f;}};function Vc(_0x5cbb03){gi=_0x5cbb03(gi);}function Hc(_0x5a8ea8){return _0x5a8ea8===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x40c043,..._0x510987){const _0x37b105=_0x5a8ea8['call'](ii(this),_0x40c043,..._0x510987);return Xr['set'](_0x37b105,_0x40c043['sort']?_0x40c043['sort']():[_0x40c043]),ge(_0x37b105);}:Uc()['includes'](_0x5a8ea8)?function(..._0x176bd5){return _0x5a8ea8['apply'](ii(this),_0x176bd5),ge(Jr['get'](this));}:function(..._0xaa3539){return ge(_0x5a8ea8['apply'](ii(this),_0xaa3539));};}function $c(_0x195a9e){return typeof _0x195a9e=='function'?Hc(_0x195a9e):(_0x195a9e instanceof IDBTransaction&&Bc(_0x195a9e),xc(_0x195a9e,Fc())?new Proxy(_0x195a9e,gi):_0x195a9e);}function ge(_0x2c6d2d){if(_0x2c6d2d instanceof IDBRequest)return Wc(_0x2c6d2d);if(ni['has'](_0x2c6d2d))return ni['get'](_0x2c6d2d);const _0x37bc78=$c(_0x2c6d2d);return _0x37bc78!==_0x2c6d2d&&(ni['set'](_0x2c6d2d,_0x37bc78),Vi['set'](_0x37bc78,_0x2c6d2d)),_0x37bc78;}const ii=_0x12c423=>Vi['get'](_0x12c423);function Gc(_0x3c3ec9,_0x493355,{blocked:_0x325f78,upgrade:_0x1ac3f1,blocking:_0x245a09,terminated:_0x44565a}={}){const _0x1a84ec=indexedDB['open'](_0x3c3ec9,_0x493355),_0x449e9b=ge(_0x1a84ec);return _0x1ac3f1&&_0x1a84ec['addEventListener']('upgradeneeded',_0x7df79b=>{_0x1ac3f1(ge(_0x1a84ec['result']),_0x7df79b['oldVersion'],_0x7df79b['newVersion'],ge(_0x1a84ec['transaction']),_0x7df79b);}),_0x325f78&&_0x1a84ec['addEventListener']('blocked',_0x40c85b=>_0x325f78(_0x40c85b['oldVersion'],_0x40c85b['newVersion'],_0x40c85b)),_0x449e9b['then'](_0x5cef06=>{_0x44565a&&_0x5cef06['addEventListener']('close',()=>_0x44565a()),_0x245a09&&_0x5cef06['addEventListener']('versionchange',_0x5d0166=>_0x245a09(_0x5d0166['oldVersion'],_0x5d0166['newVersion'],_0x5d0166));})['catch'](()=>{}),_0x449e9b;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x10572c,_0x4336c4){if(!(_0x10572c instanceof IDBDatabase&&!(_0x4336c4 in _0x10572c)&&typeof _0x4336c4=='string'))return;if(si['get'](_0x4336c4))return si['get'](_0x4336c4);const _0x23887b=_0x4336c4['replace'](/FromIndex$/,''),_0x35e390=_0x4336c4!==_0x23887b,_0x4f277f=zc['includes'](_0x23887b);if(!(_0x23887b in(_0x35e390?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4f277f||qc['includes'](_0x23887b)))return;const _0x3a91e=async function(_0x267a87,..._0x2ab713){const _0xd5778=this['transaction'](_0x267a87,_0x4f277f?'readwrite':'readonly');let _0x961669=_0xd5778['store'];return _0x35e390&&(_0x961669=_0x961669['index'](_0x2ab713['shift']())),(await Promise['all']([_0x961669[_0x23887b](..._0x2ab713),_0x4f277f&&_0xd5778['done']]))[0x0];};return si['set'](_0x4336c4,_0x3a91e),_0x3a91e;}Vc(_0xf577fd=>({..._0xf577fd,'get':(_0x226094,_0x4419be,_0x40b29c)=>Ms(_0x226094,_0x4419be)||_0xf577fd['get'](_0x226094,_0x4419be,_0x40b29c),'has':(_0x2d75d8,_0x194136)=>!!Ms(_0x2d75d8,_0x194136)||_0xf577fd['has'](_0x2d75d8,_0x194136)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x3df7c4){this['container']=_0x3df7c4;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x12fccf=>{if(Kc(_0x12fccf)){const _0x1c5fed=_0x12fccf['getImmediate']();return _0x1c5fed['library']+'/'+_0x1c5fed['version'];}else return null;})['filter'](_0x72d7e9=>_0x72d7e9)['join']('\x20');}}function Kc(_0x2e1539){const _0x14c065=_0x2e1539['getComponent']();return(_0x14c065==null?void 0x0:_0x14c065['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0xd8ce14,_0x341667){try{_0xd8ce14['container']['addComponent'](_0x341667);}catch(_0x28e7af){oe['debug']('Component\x20'+_0x341667['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xd8ce14['name'],_0x28e7af);}}function st(_0x147176){const _0x2b4ec0=_0x147176['name'];if(Ei['has'](_0x2b4ec0))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x2b4ec0+'.'),!0x1;Ei['set'](_0x2b4ec0,_0x147176);for(const _0x32e3b4 of Ue['values']())xs(_0x32e3b4,_0x147176);for(const _0x5d9b71 of vi['values']())xs(_0x5d9b71,_0x147176);return!0x0;}function Hi(_0x27951b,_0x454ae7){const _0x66b27f=_0x27951b['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x66b27f&&_0x66b27f['triggerHeartbeat'](),_0x27951b['container']['getProvider'](_0x454ae7);}function $(_0x588aa3){return _0x588aa3==null?!0x1:_0x588aa3['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x39f025,_0x712021,_0x3b3ae2){this['_isDeleted']=!0x1,this['_options']={..._0x39f025},this['_config']={..._0x712021},this['_name']=_0x712021['name'],this['_automaticDataCollectionEnabled']=_0x712021['automaticDataCollectionEnabled'],this['_container']=_0x3b3ae2,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2e4b1d){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2e4b1d;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x2850dd){this['_isDeleted']=_0x2850dd;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x5f1817,_0x5bde18={}){let _0x40b223=_0x5f1817;typeof _0x5bde18!='object'&&(_0x5bde18={'name':_0x5bde18});const _0x7e69b7={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x5bde18},_0x14b36c=_0x7e69b7['name'];if(typeof _0x14b36c!='string'||!_0x14b36c)throw me['create']('bad-app-name',{'appName':String(_0x14b36c)});if(_0x40b223||(_0x40b223=zr()),!_0x40b223)throw me['create']('no-options');const _0x4841b5=Ue['get'](_0x14b36c);if(_0x4841b5){if(xe(_0x40b223,_0x4841b5['options'])&&xe(_0x7e69b7,_0x4841b5['config']))return _0x4841b5;throw me['create']('duplicate-app',{'appName':_0x14b36c});}const _0x257963=new Nc(_0x14b36c);for(const _0x5e561a of Ei['values']())_0x257963['addComponent'](_0x5e561a);const _0x15cfda=new Tl(_0x40b223,_0x7e69b7,_0x257963);return Ue['set'](_0x14b36c,_0x15cfda),_0x15cfda;}function Zr(_0x1f9c1e=yi){const _0x550e4f=Ue['get'](_0x1f9c1e);if(!_0x550e4f&&_0x1f9c1e===yi&&zr())return Sl();if(!_0x550e4f)throw me['create']('no-app',{'appName':_0x1f9c1e});return _0x550e4f;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x3ea0d6){let _0x1dfcdd=!0x1;const _0x4204ca=_0x3ea0d6['name'];Ue['has'](_0x4204ca)?(_0x1dfcdd=!0x0,Ue['delete'](_0x4204ca)):vi['has'](_0x4204ca)&&_0x3ea0d6['decRefCount']()<=0x0&&(vi['delete'](_0x4204ca),_0x1dfcdd=!0x0),_0x1dfcdd&&(await Promise['all'](_0x3ea0d6['container']['getProviders']()['map'](_0x594da0=>_0x594da0['delete']())),_0x3ea0d6['isDeleted']=!0x0);}function ye(_0x578970,_0x2fe217,_0x11252a){let _0x27e39d=wl[_0x578970]??_0x578970;_0x11252a&&(_0x27e39d+='-'+_0x11252a);const _0xa596ce=_0x27e39d['match'](/\s|\//),_0x3dcfd2=_0x2fe217['match'](/\s|\//);if(_0xa596ce||_0x3dcfd2){const _0x122afe=['Unable\x20to\x20register\x20library\x20\x22'+_0x27e39d+'\x22\x20with\x20version\x20\x22'+_0x2fe217+'\x22:'];_0xa596ce&&_0x122afe['push']('library\x20name\x20\x22'+_0x27e39d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0xa596ce&&_0x3dcfd2&&_0x122afe['push']('and'),_0x3dcfd2&&_0x122afe['push']('version\x20name\x20\x22'+_0x2fe217+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x122afe['join']('\x20'));return;}st(new Fe(_0x27e39d+'-version',()=>({'library':_0x27e39d,'version':_0x2fe217}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x5d0016,_0x44ab8a)=>{switch(_0x44ab8a){case 0x0:try{_0x5d0016['createObjectStore'](Ot);}catch(_0x347585){console['warn'](_0x347585);}}}})['catch'](_0x3d061b=>{throw me['create']('idb-open',{'originalErrorMessage':_0x3d061b['message']});})),ri;}async function Al(_0x3f3aaf){try{const _0xa49776=(await eo())['transaction'](Ot),_0x458570=await _0xa49776['objectStore'](Ot)['get'](to(_0x3f3aaf));return await _0xa49776['done'],_0x458570;}catch(_0x159742){if(_0x159742 instanceof Re)oe['warn'](_0x159742['message']);else{const _0x1f02ad=me['create']('idb-get',{'originalErrorMessage':_0x159742==null?void 0x0:_0x159742['message']});oe['warn'](_0x1f02ad['message']);}}}async function Fs(_0x54b4e0,_0x50b96c){try{const _0x1cdcec=(await eo())['transaction'](Ot,'readwrite');await _0x1cdcec['objectStore'](Ot)['put'](_0x50b96c,to(_0x54b4e0)),await _0x1cdcec['done'];}catch(_0x464362){if(_0x464362 instanceof Re)oe['warn'](_0x464362['message']);else{const _0x1c6ad2=me['create']('idb-set',{'originalErrorMessage':_0x464362==null?void 0x0:_0x464362['message']});oe['warn'](_0x1c6ad2['message']);}}}function to(_0x588b09){return _0x588b09['name']+'!'+_0x588b09['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x32ad1e){this['container']=_0x32ad1e,this['_heartbeatsCache']=null;const _0x5127bc=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x5127bc),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2d4c79=>(this['_heartbeatsCache']=_0x2d4c79,_0x2d4c79));}async['triggerHeartbeat'](){var _0x4b8eb0,_0x80d7c3;try{const _0x1d0f0=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3277b2=Us();if(((_0x4b8eb0=this['_heartbeatsCache'])==null?void 0x0:_0x4b8eb0['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x80d7c3=this['_heartbeatsCache'])==null?void 0x0:_0x80d7c3['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3277b2||this['_heartbeatsCache']['heartbeats']['some'](_0x54e030=>_0x54e030['date']===_0x3277b2))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3277b2,'agent':_0x1d0f0}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x3c6c2b=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3c6c2b,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x1e62e8){oe['warn'](_0x1e62e8);}}async['getHeartbeatsHeader'](){var _0x10a850;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x10a850=this['_heartbeatsCache'])==null?void 0x0:_0x10a850['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x381cb1=Us(),{heartbeatsToSend:_0x3744b2,unsentEntries:_0x1ccb32}=Ol(this['_heartbeatsCache']['heartbeats']),_0x1a3548=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3744b2}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x381cb1,_0x1ccb32['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x1ccb32,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1a3548;}catch(_0x3c113a){return oe['warn'](_0x3c113a),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x599fc6,_0x1141fe=kl){const _0x24959d=[];let _0x38e9a0=_0x599fc6['slice']();for(const _0x17d01e of _0x599fc6){const _0x30617c=_0x24959d['find'](_0x15c141=>_0x15c141['agent']===_0x17d01e['agent']);if(_0x30617c){if(_0x30617c['dates']['push'](_0x17d01e['date']),Ws(_0x24959d)>_0x1141fe){_0x30617c['dates']['pop']();break;}}else{if(_0x24959d['push']({'agent':_0x17d01e['agent'],'dates':[_0x17d01e['date']]}),Ws(_0x24959d)>_0x1141fe){_0x24959d['pop']();break;}}_0x38e9a0=_0x38e9a0['slice'](0x1);}return{'heartbeatsToSend':_0x24959d,'unsentEntries':_0x38e9a0};}class Dl{constructor(_0x1888bf){this['app']=_0x1888bf,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x328002=await Al(this['app']);return _0x328002!=null&&_0x328002['heartbeats']?_0x328002:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x54ef69){if(await this['_canUseIndexedDBPromise']){const _0x49bcc7=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x54ef69['lastSentHeartbeatDate']??_0x49bcc7['lastSentHeartbeatDate'],'heartbeats':_0x54ef69['heartbeats']});}else return;}async['add'](_0xa4bdb7){if(await this['_canUseIndexedDBPromise']){const _0x271541=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0xa4bdb7['lastSentHeartbeatDate']??_0x271541['lastSentHeartbeatDate'],'heartbeats':[..._0x271541['heartbeats'],..._0xa4bdb7['heartbeats']]});}else return;}}function Ws(_0x2883f1){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2883f1}))['length'];}function Ml(_0x53abf4){if(_0x53abf4['length']===0x0)return-0x1;let _0x39e7f1=0x0,_0x53f533=_0x53abf4[0x0]['date'];for(let _0x58ddb9=0x1;_0x58ddb9<_0x53abf4['length'];_0x58ddb9++)_0x53abf4[_0x58ddb9]['date']<_0x53f533&&(_0x53f533=_0x53abf4[_0x58ddb9]['date'],_0x39e7f1=_0x58ddb9);return _0x39e7f1;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x275077){st(new Fe('platform-logger',_0x522021=>new jc(_0x522021),'PRIVATE')),st(new Fe('heartbeat',_0x44bbec=>new Nl(_0x44bbec),'PRIVATE')),ye(mi,Ls,_0x275077),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x3dce25){no=_0x3dce25;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x2fda9d){this['domStorage_']=_0x2fda9d,this['prefix_']='firebase:';}['set'](_0x403aa9,_0x37940b){_0x37940b==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x403aa9)):this['domStorage_']['setItem'](this['prefixedName_'](_0x403aa9),O(_0x37940b));}['get'](_0x30abf2){const _0xa24abe=this['domStorage_']['getItem'](this['prefixedName_'](_0x30abf2));return _0xa24abe==null?null:Nt(_0xa24abe);}['remove'](_0x14e5c7){this['domStorage_']['removeItem'](this['prefixedName_'](_0x14e5c7));}['prefixedName_'](_0x136b52){return this['prefix_']+_0x136b52;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x3e6950,_0x53d9bd){_0x53d9bd==null?delete this['cache_'][_0x3e6950]:this['cache_'][_0x3e6950]=_0x53d9bd;}['get'](_0x83e170){return Q(this['cache_'],_0x83e170)?this['cache_'][_0x83e170]:null;}['remove'](_0x5f4bab){delete this['cache_'][_0x5f4bab];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0xd7fe8){try{if(typeof window<'u'&&typeof window[_0xd7fe8]<'u'){const _0x17e0dd=window[_0xd7fe8];return _0x17e0dd['setItem']('firebase:sentinel','cache'),_0x17e0dd['removeItem']('firebase:sentinel'),new Wl(_0x17e0dd);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x4722f6=0x1;return function(){return _0x4722f6++;};}()),ro=function(_0x4369b6){const _0x19f1eb=Rc(_0x4369b6),_0x30beee=new Cc();_0x30beee['update'](_0x19f1eb);const _0x496ab2=_0x30beee['digest']();return Fi['encodeByteArray'](_0x496ab2);},zt=function(..._0x5adf5b){let _0x2f03a0='';for(let _0x15afc0=0x0;_0x15afc0<_0x5adf5b['length'];_0x15afc0++){const _0x221cb5=_0x5adf5b[_0x15afc0];Array['isArray'](_0x221cb5)||_0x221cb5&&typeof _0x221cb5=='object'&&typeof _0x221cb5['length']=='number'?_0x2f03a0+=zt['apply'](null,_0x221cb5):typeof _0x221cb5=='object'?_0x2f03a0+=O(_0x221cb5):_0x2f03a0+=_0x221cb5,_0x2f03a0+='\x20';}return _0x2f03a0;};let St=null,$s=!0x0;const Hl=function(_0x5cb0d3,_0x27ff58){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x1c6316){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0xad5f4=zt['apply'](null,_0x1c6316);St(_0xad5f4);}},jt=function(_0xeb0233){return function(..._0x55794b){L(_0xeb0233,..._0x55794b);};},Ii=function(..._0x13ff61){const _0x1e3248='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x13ff61);Ze['error'](_0x1e3248);},ae=function(..._0x27af96){const _0xb7e8ce='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x27af96);throw Ze['error'](_0xb7e8ce),new Error(_0xb7e8ce);},U=function(..._0xfb998c){const _0x2181c3='FIREBASE\x20WARNING:\x20'+zt(..._0xfb998c);Ze['warn'](_0x2181c3);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x1a8a78){return typeof _0x1a8a78=='number'&&(_0x1a8a78!==_0x1a8a78||_0x1a8a78===Number['POSITIVE_INFINITY']||_0x1a8a78===Number['NEGATIVE_INFINITY']);},Gl=function(_0x26e0a6){if(document['readyState']==='complete')_0x26e0a6();else{let _0x55cdcf=!0x1;const _0x418b0e=function(){if(!document['body']){setTimeout(_0x418b0e,Math['floor'](0xa));return;}_0x55cdcf||(_0x55cdcf=!0x0,_0x26e0a6());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x418b0e,!0x1),window['addEventListener']('load',_0x418b0e,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x418b0e();}),window['attachEvent']('onload',_0x418b0e));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x35a441,_0x32ebaf){if(_0x35a441===_0x32ebaf)return 0x0;if(_0x35a441===We||_0x32ebaf===we)return-0x1;if(_0x32ebaf===We||_0x35a441===we)return 0x1;{const _0x20a7ae=Gs(_0x35a441),_0x8a0fb7=Gs(_0x32ebaf);return _0x20a7ae!==null?_0x8a0fb7!==null?_0x20a7ae-_0x8a0fb7===0x0?_0x35a441['length']-_0x32ebaf['length']:_0x20a7ae-_0x8a0fb7:-0x1:_0x8a0fb7!==null?0x1:_0x35a441<_0x32ebaf?-0x1:0x1;}},ql=function(_0x1dc726,_0x498a56){return _0x1dc726===_0x498a56?0x0:_0x1dc726<_0x498a56?-0x1:0x1;},vt=function(_0x15da28,_0x1610bb){if(_0x1610bb&&_0x15da28 in _0x1610bb)return _0x1610bb[_0x15da28];throw new Error('Missing\x20required\x20key\x20('+_0x15da28+')\x20in\x20object:\x20'+O(_0x1610bb));},$i=function(_0x1c87ca){if(typeof _0x1c87ca!='object'||_0x1c87ca===null)return O(_0x1c87ca);const _0x4d7e62=[];for(const _0x51cfe7 in _0x1c87ca)_0x4d7e62['push'](_0x51cfe7);_0x4d7e62['sort']();let _0x4fe487='{';for(let _0x5a95c7=0x0;_0x5a95c7<_0x4d7e62['length'];_0x5a95c7++)_0x5a95c7!==0x0&&(_0x4fe487+=','),_0x4fe487+=O(_0x4d7e62[_0x5a95c7]),_0x4fe487+=':',_0x4fe487+=$i(_0x1c87ca[_0x4d7e62[_0x5a95c7]]);return _0x4fe487+='}',_0x4fe487;},oo=function(_0x1e6f5a,_0x4b6ee1){const _0x153cde=_0x1e6f5a['length'];if(_0x153cde<=_0x4b6ee1)return[_0x1e6f5a];const _0xdff3da=[];for(let _0x7ab70a=0x0;_0x7ab70a<_0x153cde;_0x7ab70a+=_0x4b6ee1)_0x7ab70a+_0x4b6ee1>_0x153cde?_0xdff3da['push'](_0x1e6f5a['substring'](_0x7ab70a,_0x153cde)):_0xdff3da['push'](_0x1e6f5a['substring'](_0x7ab70a,_0x7ab70a+_0x4b6ee1));return _0xdff3da;};function x(_0x1d1e3d,_0x2a5bbb){for(const _0x1e3ef9 in _0x1d1e3d)_0x1d1e3d['hasOwnProperty'](_0x1e3ef9)&&_0x2a5bbb(_0x1e3ef9,_0x1d1e3d[_0x1e3ef9]);}const ao=function(_0xe49465){f(!xn(_0xe49465),'Invalid\x20JSON\x20number');const _0x555c98=0xb,_0x280ba2=0x34,_0x1eb75d=(0x1<<_0x555c98-0x1)-0x1;let _0x45819a,_0x1a82f5,_0x3a3d21,_0x23f399,_0x50bf36;_0xe49465===0x0?(_0x1a82f5=0x0,_0x3a3d21=0x0,_0x45819a=0x1/_0xe49465===-0x1/0x0?0x1:0x0):(_0x45819a=_0xe49465<0x0,_0xe49465=Math['abs'](_0xe49465),_0xe49465>=Math['pow'](0x2,0x1-_0x1eb75d)?(_0x23f399=Math['min'](Math['floor'](Math['log'](_0xe49465)/Math['LN2']),_0x1eb75d),_0x1a82f5=_0x23f399+_0x1eb75d,_0x3a3d21=Math['round'](_0xe49465*Math['pow'](0x2,_0x280ba2-_0x23f399)-Math['pow'](0x2,_0x280ba2))):(_0x1a82f5=0x0,_0x3a3d21=Math['round'](_0xe49465/Math['pow'](0x2,0x1-_0x1eb75d-_0x280ba2))));const _0x5ac661=[];for(_0x50bf36=_0x280ba2;_0x50bf36;_0x50bf36-=0x1)_0x5ac661['push'](_0x3a3d21%0x2?0x1:0x0),_0x3a3d21=Math['floor'](_0x3a3d21/0x2);for(_0x50bf36=_0x555c98;_0x50bf36;_0x50bf36-=0x1)_0x5ac661['push'](_0x1a82f5%0x2?0x1:0x0),_0x1a82f5=Math['floor'](_0x1a82f5/0x2);_0x5ac661['push'](_0x45819a?0x1:0x0),_0x5ac661['reverse']();const _0xb68b83=_0x5ac661['join']('');let _0x23e595='';for(_0x50bf36=0x0;_0x50bf36<0x40;_0x50bf36+=0x8){let _0x213fd5=parseInt(_0xb68b83['substr'](_0x50bf36,0x8),0x2)['toString'](0x10);_0x213fd5['length']===0x1&&(_0x213fd5='0'+_0x213fd5),_0x23e595=_0x23e595+_0x213fd5;}return _0x23e595['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x13207e,_0x115e3c){let _0x1eab8d='Unknown\x20Error';_0x13207e==='too_big'?_0x1eab8d='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x13207e==='permission_denied'?_0x1eab8d='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x13207e==='unavailable'&&(_0x1eab8d='The\x20service\x20is\x20unavailable');const _0x439145=new Error(_0x13207e+'\x20at\x20'+_0x115e3c['_path']['toString']()+':\x20'+_0x1eab8d);return _0x439145['code']=_0x13207e['toUpperCase'](),_0x439145;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x334992){if(Yl['test'](_0x334992)){const _0x30005c=Number(_0x334992);if(_0x30005c>=Ql&&_0x30005c<=Jl)return _0x30005c;}return null;},ft=function(_0x23ee96){try{_0x23ee96();}catch(_0x1a79f3){setTimeout(()=>{const _0x20bfc4=_0x1a79f3['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x20bfc4),_0x1a79f3;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0xf5c146,_0x579b61){const _0x533d3c=setTimeout(_0xf5c146,_0x579b61);return typeof _0x533d3c=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x533d3c):typeof _0x533d3c=='object'&&_0x533d3c['unref']&&_0x533d3c['unref'](),_0x533d3c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x525751,_0x16b086){this['appCheckProvider']=_0x16b086,this['appName']=_0x525751['name'],$(_0x525751)&&_0x525751['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x525751['settings']['appCheckToken']),this['appCheck']=_0x16b086==null?void 0x0:_0x16b086['getImmediate']({'optional':!0x0}),this['appCheck']||_0x16b086==null||_0x16b086['get']()['then'](_0x424ff1=>this['appCheck']=_0x424ff1);}['getToken'](_0x5a2c6a){if(this['serverAppAppCheckToken']){if(_0x5a2c6a)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x5a2c6a):new Promise((_0x12e3af,_0x2ee2f9)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x5a2c6a)['then'](_0x12e3af,_0x2ee2f9):_0x12e3af(null);},0x0);});}['addTokenChangeListener'](_0x5e2f4e){var _0x432b05;(_0x432b05=this['appCheckProvider'])==null||_0x432b05['get']()['then'](_0x110b74=>_0x110b74['addTokenListener'](_0x5e2f4e));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x43234d,_0x1587df,_0x26dfe9){this['appName_']=_0x43234d,this['firebaseOptions_']=_0x1587df,this['authProvider_']=_0x26dfe9,this['auth_']=null,this['auth_']=_0x26dfe9['getImmediate']({'optional':!0x0}),this['auth_']||_0x26dfe9['onInit'](_0x58c940=>this['auth_']=_0x58c940);}['getToken'](_0x2655ff){return this['auth_']?this['auth_']['getToken'](_0x2655ff)['catch'](_0x36b51a=>_0x36b51a&&_0x36b51a['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x36b51a)):new Promise((_0x52d568,_0x36dc2a)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x2655ff)['then'](_0x52d568,_0x36dc2a):_0x52d568(null);},0x0);});}['addTokenChangeListener'](_0x46bad9){this['auth_']?this['auth_']['addAuthTokenListener'](_0x46bad9):this['authProvider_']['get']()['then'](_0x5e66d4=>_0x5e66d4['addAuthTokenListener'](_0x46bad9));}['removeTokenChangeListener'](_0x2922b4){this['authProvider_']['get']()['then'](_0xd25cda=>_0xd25cda['removeAuthTokenListener'](_0x2922b4));}['notifyForInvalidToken'](){let _0x270bb3='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x270bb3+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x270bb3+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x270bb3+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x270bb3);}}class an{constructor(_0x438da0){this['accessToken']=_0x438da0;}['getToken'](_0x3389bb){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x33111b){_0x33111b(this['accessToken']);}['removeTokenChangeListener'](_0xc573f3){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x3a844c,_0x5b329f,_0x4c96ec,_0x46fc08,_0x32f265=!0x1,_0xd94d4b='',_0x2b6dd9=!0x1,_0x262ad6=!0x1,_0x3bd5fa=null){this['secure']=_0x5b329f,this['namespace']=_0x4c96ec,this['webSocketOnly']=_0x46fc08,this['nodeAdmin']=_0x32f265,this['persistenceKey']=_0xd94d4b,this['includeNamespaceInQueryParams']=_0x2b6dd9,this['isUsingEmulator']=_0x262ad6,this['emulatorOptions']=_0x3bd5fa,this['_host']=_0x3a844c['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x3a844c)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x237605){_0x237605!==this['internalHost']&&(this['internalHost']=_0x237605,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x94a806=this['toURLString']();return this['persistenceKey']&&(_0x94a806+='<'+this['persistenceKey']+'>'),_0x94a806;}['toURLString'](){const _0x56e788=this['secure']?'https://':'http://',_0x10af73=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x56e788+this['host']+'/'+_0x10af73;}}function th(_0xc61c19){return _0xc61c19['host']!==_0xc61c19['internalHost']||_0xc61c19['isCustomHost']()||_0xc61c19['includeNamespaceInQueryParams'];}function vo(_0x5ed751,_0x1fb9e1,_0xe09c54){f(typeof _0x1fb9e1=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0xe09c54=='object','typeof\x20params\x20must\x20==\x20object');let _0x452ab6;if(_0x1fb9e1===go)_0x452ab6=(_0x5ed751['secure']?'wss://':'ws://')+_0x5ed751['internalHost']+'/.ws?';else{if(_0x1fb9e1===mo)_0x452ab6=(_0x5ed751['secure']?'https://':'http://')+_0x5ed751['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1fb9e1);}th(_0x5ed751)&&(_0xe09c54['ns']=_0x5ed751['namespace']);const _0x63714b=[];return x(_0xe09c54,(_0x14e2cd,_0x27a86b)=>{_0x63714b['push'](_0x14e2cd+'='+_0x27a86b);}),_0x452ab6+_0x63714b['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x2df435,_0x32fe72=0x1){Q(this['counters_'],_0x2df435)||(this['counters_'][_0x2df435]=0x0),this['counters_'][_0x2df435]+=_0x32fe72;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x24f9df){const _0x18d237=_0x24f9df['toString']();return oi[_0x18d237]||(oi[_0x18d237]=new nh()),oi[_0x18d237];}function ih(_0x417316,_0x55f399){const _0x251078=_0x417316['toString']();return ai[_0x251078]||(ai[_0x251078]=_0x55f399()),ai[_0x251078];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x307a55){this['onMessage_']=_0x307a55,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x179a0d,_0x4c170f){this['closeAfterResponse']=_0x179a0d,this['onClose']=_0x4c170f,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3bc9f3,_0x42a674){for(this['pendingResponses'][_0x3bc9f3]=_0x42a674;this['pendingResponses'][this['currentResponseNum']];){const _0xdedaee=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x55d415=0x0;_0x55d415<_0xdedaee['length'];++_0x55d415)_0xdedaee[_0x55d415]&&ft(()=>{this['onMessage_'](_0xdedaee[_0x55d415]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x32be22,_0x40307d,_0x58b1b1,_0xc73bee,_0x10f2f0,_0x1364c0,_0x29732a){this['connId']=_0x32be22,this['repoInfo']=_0x40307d,this['applicationId']=_0x58b1b1,this['appCheckToken']=_0xc73bee,this['authToken']=_0x10f2f0,this['transportSessionId']=_0x1364c0,this['lastSessionId']=_0x29732a,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x32be22),this['stats_']=qi(_0x40307d),this['urlFn']=_0x28306a=>(this['appCheckToken']&&(_0x28306a[wi]=this['appCheckToken']),vo(_0x40307d,mo,_0x28306a));}['open'](_0x10a43e,_0x362e1d){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x362e1d,this['myPacketOrderer']=new sh(_0x10a43e),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x4743d)=>{const [_0x2d0fdd,_0x2c2eb0,_0x1af45a,_0x220dba,_0x264751]=_0x4743d;if(this['incrementIncomingBytes_'](_0x4743d),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2d0fdd===qs)this['id']=_0x2c2eb0,this['password']=_0x1af45a;else{if(_0x2d0fdd===rh)_0x2c2eb0?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2c2eb0,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2d0fdd);}}},(..._0x2ace55)=>{const [_0x2a4dbc,_0x2e51f6]=_0x2ace55;this['incrementIncomingBytes_'](_0x2ace55),this['myPacketOrderer']['handleResponse'](_0x2a4dbc,_0x2e51f6);},()=>{this['onClosed_']();},this['urlFn']);const _0x548a8f={};_0x548a8f[qs]='t',_0x548a8f[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x548a8f[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x548a8f[co]=Gi,this['transportSessionId']&&(_0x548a8f[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x548a8f[po]=this['lastSessionId']),this['applicationId']&&(_0x548a8f[_o]=this['applicationId']),this['appCheckToken']&&(_0x548a8f[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x548a8f[ho]=uo);const _0x2ccd6d=this['urlFn'](_0x548a8f);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x2ccd6d),this['scriptTagHolder']['addTag'](_0x2ccd6d,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4aa20a){const _0x25383d=O(_0x4aa20a);this['bytesSent']+=_0x25383d['length'],this['stats_']['incrementCounter']('bytes_sent',_0x25383d['length']);const _0x542efb=$r(_0x25383d),_0x3afdf1=oo(_0x542efb,fh);for(let _0x56cfe9=0x0;_0x56cfe9<_0x3afdf1['length'];_0x56cfe9++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3afdf1['length'],_0x3afdf1[_0x56cfe9]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x150eb7,_0x134bad){this['myDisconnFrame']=document['createElement']('iframe');const _0x5e8ae3={};_0x5e8ae3[dh]='t',_0x5e8ae3[Eo]=_0x150eb7,_0x5e8ae3[Io]=_0x134bad,this['myDisconnFrame']['src']=this['urlFn'](_0x5e8ae3),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xd1ab28){const _0x438a12=O(_0xd1ab28)['length'];this['bytesReceived']+=_0x438a12,this['stats_']['incrementCounter']('bytes_received',_0x438a12);}}class zi{constructor(_0x5a512f,_0x1d790d,_0x17f7b7,_0x543d64){this['onDisconnect']=_0x17f7b7,this['urlFn']=_0x543d64,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x5a512f,window[ah+this['uniqueCallbackIdentifier']]=_0x1d790d,this['myIFrame']=zi['createIFrame_']();let _0x83d460='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x83d460='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3fd479='<html><body>'+_0x83d460+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3fd479),this['myIFrame']['doc']['close']();}catch(_0x2916a0){L('frame\x20writing\x20exception'),_0x2916a0['stack']&&L(_0x2916a0['stack']),L(_0x2916a0);}}}static['createIFrame_'](){const _0x54a1a6=document['createElement']('iframe');if(_0x54a1a6['style']['display']='none',document['body']){document['body']['appendChild'](_0x54a1a6);try{_0x54a1a6['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3e23ff=document['domain'];_0x54a1a6['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3e23ff+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x54a1a6['contentDocument']?_0x54a1a6['doc']=_0x54a1a6['contentDocument']:_0x54a1a6['contentWindow']?_0x54a1a6['doc']=_0x54a1a6['contentWindow']['document']:_0x54a1a6['document']&&(_0x54a1a6['doc']=_0x54a1a6['document']),_0x54a1a6;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x44d089=this['onDisconnect'];_0x44d089&&(this['onDisconnect']=null,_0x44d089());}['startLongPoll'](_0x4d0155,_0x54f243){for(this['myID']=_0x4d0155,this['myPW']=_0x54f243,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x406d06={};_0x406d06[Eo]=this['myID'],_0x406d06[Io]=this['myPW'],_0x406d06[wo]=this['currentSerial'];let _0x473e9f=this['urlFn'](_0x406d06),_0x16decf='',_0x387d19=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x16decf['length']<=Co;){const _0x4f1e73=this['pendingSegs']['shift']();_0x16decf=_0x16decf+'&'+lh+_0x387d19+'='+_0x4f1e73['seg']+'&'+hh+_0x387d19+'='+_0x4f1e73['ts']+'&'+uh+_0x387d19+'='+_0x4f1e73['d'],_0x387d19++;}return _0x473e9f=_0x473e9f+_0x16decf,this['addLongPollTag_'](_0x473e9f,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2edd21,_0x9651f4,_0x431dbe){this['pendingSegs']['push']({'seg':_0x2edd21,'ts':_0x9651f4,'d':_0x431dbe}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1195dc,_0x5d137e){this['outstandingRequests']['add'](_0x5d137e);const _0x273532=()=>{this['outstandingRequests']['delete'](_0x5d137e),this['newRequest_']();},_0x5689fc=setTimeout(_0x273532,Math['floor'](ph)),_0x580354=()=>{clearTimeout(_0x5689fc),_0x273532();};this['addTag'](_0x1195dc,_0x580354);}['addTag'](_0x1078a4,_0x5c0a56){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x2d691c=this['myIFrame']['doc']['createElement']('script');_0x2d691c['type']='text/javascript',_0x2d691c['async']=!0x0,_0x2d691c['src']=_0x1078a4,_0x2d691c['onload']=_0x2d691c['onreadystatechange']=function(){const _0x53f375=_0x2d691c['readyState'];(!_0x53f375||_0x53f375==='loaded'||_0x53f375==='complete')&&(_0x2d691c['onload']=_0x2d691c['onreadystatechange']=null,_0x2d691c['parentNode']&&_0x2d691c['parentNode']['removeChild'](_0x2d691c),_0x5c0a56());},_0x2d691c['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x1078a4),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x2d691c);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x40c0c2,_0x31bfc8,_0x1b5ee5,_0x14dccf,_0x41f2a3,_0x35eb21,_0x184625){this['connId']=_0x40c0c2,this['applicationId']=_0x1b5ee5,this['appCheckToken']=_0x14dccf,this['authToken']=_0x41f2a3,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x31bfc8),this['connURL']=q['connectionURL_'](_0x31bfc8,_0x35eb21,_0x184625,_0x14dccf,_0x1b5ee5),this['nodeAdmin']=_0x31bfc8['nodeAdmin'];}static['connectionURL_'](_0x25068b,_0x20164a,_0x53c20a,_0x464542,_0xda1d7){const _0x4e5803={};return _0x4e5803[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4e5803[ho]=uo),_0x20164a&&(_0x4e5803[lo]=_0x20164a),_0x53c20a&&(_0x4e5803[po]=_0x53c20a),_0x464542&&(_0x4e5803[wi]=_0x464542),_0xda1d7&&(_0x4e5803[_o]=_0xda1d7),vo(_0x25068b,go,_0x4e5803);}['open'](_0xf899d1,_0x45da1d){this['onDisconnect']=_0x45da1d,this['onMessage']=_0xf899d1,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x4488dc;_c(),this['mySock']=new gn(this['connURL'],[],_0x4488dc);}catch(_0x120c3e){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1eb5d4=_0x120c3e['message']||_0x120c3e['data'];_0x1eb5d4&&this['log_'](_0x1eb5d4),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x47f51b=>{this['handleIncomingFrame'](_0x47f51b);},this['mySock']['onerror']=_0x141886=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x14ba15=_0x141886['message']||_0x141886['data'];_0x14ba15&&this['log_'](_0x14ba15),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x567d29=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1f2421=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x196fee=navigator['userAgent']['match'](_0x1f2421);_0x196fee&&_0x196fee['length']>0x1&&parseFloat(_0x196fee[0x1])<4.4&&(_0x567d29=!0x0);}return!_0x567d29&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x5650ef){if(this['frames']['push'](_0x5650ef),this['frames']['length']===this['totalFrames']){const _0x283742=this['frames']['join']('');this['frames']=null;const _0x1a510e=Nt(_0x283742);this['onMessage'](_0x1a510e);}}['handleNewFrameCount_'](_0x1de6da){this['totalFrames']=_0x1de6da,this['frames']=[];}['extractFrameCount_'](_0x1bdda9){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x1bdda9['length']<=0x6){const _0x1ad968=Number(_0x1bdda9);if(!isNaN(_0x1ad968))return this['handleNewFrameCount_'](_0x1ad968),null;}return this['handleNewFrameCount_'](0x1),_0x1bdda9;}['handleIncomingFrame'](_0x7745d){if(this['mySock']===null)return;const _0x3430af=_0x7745d['data'];if(this['bytesReceived']+=_0x3430af['length'],this['stats_']['incrementCounter']('bytes_received',_0x3430af['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x3430af);else{const _0x47ca0b=this['extractFrameCount_'](_0x3430af);_0x47ca0b!==null&&this['appendFrame_'](_0x47ca0b);}}['send'](_0x22e8fa){this['resetKeepAlive']();const _0x8570bc=O(_0x22e8fa);this['bytesSent']+=_0x8570bc['length'],this['stats_']['incrementCounter']('bytes_sent',_0x8570bc['length']);const _0x43145c=oo(_0x8570bc,gh);_0x43145c['length']>0x1&&this['sendString_'](String(_0x43145c['length']));for(let _0x5a8048=0x0;_0x5a8048<_0x43145c['length'];_0x5a8048++)this['sendString_'](_0x43145c[_0x5a8048]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0xd34dab){try{this['mySock']['send'](_0xd34dab);}catch(_0x266a51){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x266a51['message']||_0x266a51['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x29a381){this['initTransports_'](_0x29a381);}['initTransports_'](_0x3581c8){const _0x245e1e=q&&q['isAvailable']();let _0x31bfa6=_0x245e1e&&!q['previouslyFailed']();if(_0x3581c8['webSocketOnly']&&(_0x245e1e||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x31bfa6=!0x0),_0x31bfa6)this['transports_']=[q];else{const _0x334884=this['transports_']=[];for(const _0x1f85ec of Dt['ALL_TRANSPORTS'])_0x1f85ec&&_0x1f85ec['isAvailable']()&&_0x334884['push'](_0x1f85ec);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x3e0119,_0x4719b9,_0x490a15,_0x12c3ec,_0x419a55,_0x2aa650,_0x548e0a,_0x27e572,_0x4086f6,_0x4ac5f3){this['id']=_0x3e0119,this['repoInfo_']=_0x4719b9,this['applicationId_']=_0x490a15,this['appCheckToken_']=_0x12c3ec,this['authToken_']=_0x419a55,this['onMessage_']=_0x2aa650,this['onReady_']=_0x548e0a,this['onDisconnect_']=_0x27e572,this['onKill_']=_0x4086f6,this['lastSessionId']=_0x4ac5f3,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x4719b9),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x45bd9a=this['transportManager_']['initialTransport']();this['conn_']=new _0x45bd9a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x45bd9a['responsesRequiredToBeHealthy']||0x0;const _0x46d58d=this['connReceiver_'](this['conn_']),_0x455504=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x46d58d,_0x455504);},Math['floor'](0x0));const _0x3c9d38=_0x45bd9a['healthyTimeout']||0x0;_0x3c9d38>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3c9d38)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x261053){return _0x35125b=>{_0x261053===this['conn_']?this['onConnectionLost_'](_0x35125b):_0x261053===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3ff14e){return _0x4c5151=>{this['state_']!==0x2&&(_0x3ff14e===this['rx_']?this['onPrimaryMessageReceived_'](_0x4c5151):_0x3ff14e===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4c5151):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xfea0e3){const _0x34043b={'t':'d','d':_0xfea0e3};this['sendData_'](_0x34043b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x48944a){if(ci in _0x48944a){const _0x19a843=_0x48944a[ci];_0x19a843===Ys?this['upgradeIfSecondaryHealthy_']():_0x19a843===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x19a843===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x42646e){const _0x13478e=vt('t',_0x42646e),_0x2125fd=vt('d',_0x42646e);if(_0x13478e==='c')this['onSecondaryControl_'](_0x2125fd);else{if(_0x13478e==='d')this['pendingDataMessages']['push'](_0x2125fd);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x13478e);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4f3859){const _0x2214fe=vt('t',_0x4f3859),_0x236b06=vt('d',_0x4f3859);_0x2214fe==='c'?this['onControl_'](_0x236b06):_0x2214fe==='d'&&this['onDataMessage_'](_0x236b06);}['onDataMessage_'](_0x15155e){this['onPrimaryResponse_'](),this['onMessage_'](_0x15155e);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2614b2){const _0x5ad497=vt(ci,_0x2614b2);if(zs in _0x2614b2){const _0x33d06d=_0x2614b2[zs];if(_0x5ad497===Th){const _0x21bed8={..._0x33d06d};this['repoInfo_']['isUsingEmulator']&&(_0x21bed8['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x21bed8);}else{if(_0x5ad497===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x499e87=0x0;_0x499e87<this['pendingDataMessages']['length'];++_0x499e87)this['onDataMessage_'](this['pendingDataMessages'][_0x499e87]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5ad497===wh?this['onConnectionShutdown_'](_0x33d06d):_0x5ad497===js?this['onReset_'](_0x33d06d):_0x5ad497===Ch?Ii('Server\x20Error:\x20'+_0x33d06d):_0x5ad497===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x5ad497);}}}['onHandshake_'](_0x511858){const _0x294a9a=_0x511858['ts'],_0x13f27a=_0x511858['v'],_0x208c89=_0x511858['h'];this['sessionId']=_0x511858['s'],this['repoInfo_']['host']=_0x208c89,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x294a9a),Gi!==_0x13f27a&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2fe4a7=this['transportManager_']['upgradeTransport']();_0x2fe4a7&&this['startUpgrade_'](_0x2fe4a7);}['startUpgrade_'](_0x5cc9d1){this['secondaryConn_']=new _0x5cc9d1(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x5cc9d1['responsesRequiredToBeHealthy']||0x0;const _0x56d848=this['connReceiver_'](this['secondaryConn_']),_0x2125a7=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x56d848,_0x2125a7),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x3947a9){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x3947a9),this['repoInfo_']['host']=_0x3947a9,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x311940,_0x331077){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x311940,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x331077,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4d7002=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4d7002||this['rx_']===_0x4d7002)&&this['close']();}['onConnectionLost_'](_0x1b1f43){this['conn_']=null,!_0x1b1f43&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x226201){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x226201),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1e571a){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1e571a);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x324b37,_0x343bd4,_0x3d9f2b,_0x208445){}['merge'](_0x5bf8c1,_0x25aeca,_0x5cf60f,_0x289c13){}['refreshAuthToken'](_0x1c1e56){}['refreshAppCheckToken'](_0x1884c6){}['onDisconnectPut'](_0x33b8d9,_0x3436a5,_0x21e4ab){}['onDisconnectMerge'](_0x3692e2,_0x5dfa73,_0x6f01ad){}['onDisconnectCancel'](_0x11c945,_0x8d2151){}['reportStats'](_0x2e4a6a){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x19ce1e){this['allowedEvents_']=_0x19ce1e,this['listeners_']={},f(Array['isArray'](_0x19ce1e)&&_0x19ce1e['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x4348ab,..._0x217004){if(Array['isArray'](this['listeners_'][_0x4348ab])){const _0x1e1e5e=[...this['listeners_'][_0x4348ab]];for(let _0x186d6c=0x0;_0x186d6c<_0x1e1e5e['length'];_0x186d6c++)_0x1e1e5e[_0x186d6c]['callback']['apply'](_0x1e1e5e[_0x186d6c]['context'],_0x217004);}}['on'](_0x6322c,_0x5eedd6,_0x2dffba){this['validateEventType_'](_0x6322c),this['listeners_'][_0x6322c]=this['listeners_'][_0x6322c]||[],this['listeners_'][_0x6322c]['push']({'callback':_0x5eedd6,'context':_0x2dffba});const _0x2b4497=this['getInitialEvent'](_0x6322c);_0x2b4497&&_0x5eedd6['apply'](_0x2dffba,_0x2b4497);}['off'](_0x865f83,_0x4a0795,_0x460286){this['validateEventType_'](_0x865f83);const _0x35becb=this['listeners_'][_0x865f83]||[];for(let _0x5943c2=0x0;_0x5943c2<_0x35becb['length'];_0x5943c2++)if(_0x35becb[_0x5943c2]['callback']===_0x4a0795&&(!_0x460286||_0x460286===_0x35becb[_0x5943c2]['context'])){_0x35becb['splice'](_0x5943c2,0x1);return;}}['validateEventType_'](_0x8e420d){f(this['allowedEvents_']['find'](_0x51317f=>_0x51317f===_0x8e420d),'Unknown\x20event:\x20'+_0x8e420d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x212e64){return f(_0x212e64==='online','Unknown\x20event\x20type:\x20'+_0x212e64),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x49011b,_0x311291){if(_0x311291===void 0x0){this['pieces_']=_0x49011b['split']('/');let _0x121685=0x0;for(let _0x352af3=0x0;_0x352af3<this['pieces_']['length'];_0x352af3++)this['pieces_'][_0x352af3]['length']>0x0&&(this['pieces_'][_0x121685]=this['pieces_'][_0x352af3],_0x121685++);this['pieces_']['length']=_0x121685,this['pieceNum_']=0x0;}else this['pieces_']=_0x49011b,this['pieceNum_']=_0x311291;}['toString'](){let _0x4ccd0d='';for(let _0x222a0f=this['pieceNum_'];_0x222a0f<this['pieces_']['length'];_0x222a0f++)this['pieces_'][_0x222a0f]!==''&&(_0x4ccd0d+='/'+this['pieces_'][_0x222a0f]);return _0x4ccd0d||'/';}}function w(){return new C('');}function y(_0x290a8c){return _0x290a8c['pieceNum_']>=_0x290a8c['pieces_']['length']?null:_0x290a8c['pieces_'][_0x290a8c['pieceNum_']];}function Ce(_0x4f6c0d){return _0x4f6c0d['pieces_']['length']-_0x4f6c0d['pieceNum_'];}function S(_0x5ba4db){let _0x37b1b3=_0x5ba4db['pieceNum_'];return _0x37b1b3<_0x5ba4db['pieces_']['length']&&_0x37b1b3++,new C(_0x5ba4db['pieces_'],_0x37b1b3);}function ji(_0x4f085f){return _0x4f085f['pieceNum_']<_0x4f085f['pieces_']['length']?_0x4f085f['pieces_'][_0x4f085f['pieces_']['length']-0x1]:null;}function bh(_0x2317d3){let _0x5dd519='';for(let _0x1161e3=_0x2317d3['pieceNum_'];_0x1161e3<_0x2317d3['pieces_']['length'];_0x1161e3++)_0x2317d3['pieces_'][_0x1161e3]!==''&&(_0x5dd519+='/'+encodeURIComponent(String(_0x2317d3['pieces_'][_0x1161e3])));return _0x5dd519||'/';}function Mt(_0x5b1fe9,_0xc69235=0x0){return _0x5b1fe9['pieces_']['slice'](_0x5b1fe9['pieceNum_']+_0xc69235);}function Ro(_0xfea883){if(_0xfea883['pieceNum_']>=_0xfea883['pieces_']['length'])return null;const _0x372c5d=[];for(let _0x50b09f=_0xfea883['pieceNum_'];_0x50b09f<_0xfea883['pieces_']['length']-0x1;_0x50b09f++)_0x372c5d['push'](_0xfea883['pieces_'][_0x50b09f]);return new C(_0x372c5d,0x0);}function k(_0x525494,_0x4980fd){const _0x544549=[];for(let _0x3fd2cb=_0x525494['pieceNum_'];_0x3fd2cb<_0x525494['pieces_']['length'];_0x3fd2cb++)_0x544549['push'](_0x525494['pieces_'][_0x3fd2cb]);if(_0x4980fd instanceof C){for(let _0x4ba178=_0x4980fd['pieceNum_'];_0x4ba178<_0x4980fd['pieces_']['length'];_0x4ba178++)_0x544549['push'](_0x4980fd['pieces_'][_0x4ba178]);}else{const _0x293a01=_0x4980fd['split']('/');for(let _0x3e7968=0x0;_0x3e7968<_0x293a01['length'];_0x3e7968++)_0x293a01[_0x3e7968]['length']>0x0&&_0x544549['push'](_0x293a01[_0x3e7968]);}return new C(_0x544549,0x0);}function v(_0x3974a1){return _0x3974a1['pieceNum_']>=_0x3974a1['pieces_']['length'];}function F(_0x138180,_0x24836b){const _0x4fcad1=y(_0x138180),_0x41f11d=y(_0x24836b);if(_0x4fcad1===null)return _0x24836b;if(_0x4fcad1===_0x41f11d)return F(S(_0x138180),S(_0x24836b));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x24836b+')\x20is\x20not\x20within\x20outerPath\x20('+_0x138180+')');}function Rh(_0x1cc3d1,_0x514326){const _0x83cd4=Mt(_0x1cc3d1,0x0),_0x252659=Mt(_0x514326,0x0);for(let _0x2ba69b=0x0;_0x2ba69b<_0x83cd4['length']&&_0x2ba69b<_0x252659['length'];_0x2ba69b++){const _0x41ff57=qe(_0x83cd4[_0x2ba69b],_0x252659[_0x2ba69b]);if(_0x41ff57!==0x0)return _0x41ff57;}return _0x83cd4['length']===_0x252659['length']?0x0:_0x83cd4['length']<_0x252659['length']?-0x1:0x1;}function Ki(_0x18bbc3,_0x240b11){if(Ce(_0x18bbc3)!==Ce(_0x240b11))return!0x1;for(let _0xd6af86=_0x18bbc3['pieceNum_'],_0x57e2ba=_0x240b11['pieceNum_'];_0xd6af86<=_0x18bbc3['pieces_']['length'];_0xd6af86++,_0x57e2ba++)if(_0x18bbc3['pieces_'][_0xd6af86]!==_0x240b11['pieces_'][_0x57e2ba])return!0x1;return!0x0;}function G(_0x2b0bff,_0x1a980f){let _0x2242c1=_0x2b0bff['pieceNum_'],_0x61d7b7=_0x1a980f['pieceNum_'];if(Ce(_0x2b0bff)>Ce(_0x1a980f))return!0x1;for(;_0x2242c1<_0x2b0bff['pieces_']['length'];){if(_0x2b0bff['pieces_'][_0x2242c1]!==_0x1a980f['pieces_'][_0x61d7b7])return!0x1;++_0x2242c1,++_0x61d7b7;}return!0x0;}class Ah{constructor(_0x1f7cde,_0x4c2a9a){this['errorPrefix_']=_0x4c2a9a,this['parts_']=Mt(_0x1f7cde,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x45e4b8=0x0;_0x45e4b8<this['parts_']['length'];_0x45e4b8++)this['byteLength_']+=Ln(this['parts_'][_0x45e4b8]);Ao(this);}}function kh(_0x1a1966,_0x566867){_0x1a1966['parts_']['length']>0x0&&(_0x1a1966['byteLength_']+=0x1),_0x1a1966['parts_']['push'](_0x566867),_0x1a1966['byteLength_']+=Ln(_0x566867),Ao(_0x1a1966);}function Ph(_0x5c42f5){const _0x3432a2=_0x5c42f5['parts_']['pop']();_0x5c42f5['byteLength_']-=Ln(_0x3432a2),_0x5c42f5['parts_']['length']>0x0&&(_0x5c42f5['byteLength_']-=0x1);}function Ao(_0x4d4302){if(_0x4d4302['byteLength_']>Zs)throw new Error(_0x4d4302['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x4d4302['byteLength_']+').');if(_0x4d4302['parts_']['length']>Xs)throw new Error(_0x4d4302['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x4d4302));}function Oe(_0xb75853){return _0xb75853['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0xb75853['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x2132aa,_0x2d69b2;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2d69b2='visibilitychange',_0x2132aa='hidden'):typeof document['mozHidden']<'u'?(_0x2d69b2='mozvisibilitychange',_0x2132aa='mozHidden'):typeof document['msHidden']<'u'?(_0x2d69b2='msvisibilitychange',_0x2132aa='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2d69b2='webkitvisibilitychange',_0x2132aa='webkitHidden')),this['visible_']=!0x0,_0x2d69b2&&document['addEventListener'](_0x2d69b2,()=>{const _0x2bceca=!document[_0x2132aa];_0x2bceca!==this['visible_']&&(this['visible_']=_0x2bceca,this['trigger']('visible',_0x2bceca));},!0x1);}['getInitialEvent'](_0x587e61){return f(_0x587e61==='visible','Unknown\x20event\x20type:\x20'+_0x587e61),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x1925a7,_0x26fd8a,_0xbe7ac9,_0x5ad233,_0x39dae2,_0x188f82,_0x5198a2,_0x1602bd){if(super(),this['repoInfo_']=_0x1925a7,this['applicationId_']=_0x26fd8a,this['onDataUpdate_']=_0xbe7ac9,this['onConnectStatus_']=_0x5ad233,this['onServerInfoUpdate_']=_0x39dae2,this['authTokenProvider_']=_0x188f82,this['appCheckTokenProvider_']=_0x5198a2,this['authOverride_']=_0x1602bd,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x1602bd)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x1925a7['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x49ad52,_0x4a0d7c,_0x49ca85){const _0x24eb30=++this['requestNumber_'],_0x59e41c={'r':_0x24eb30,'a':_0x49ad52,'b':_0x4a0d7c};this['log_'](O(_0x59e41c)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x59e41c),_0x49ca85&&(this['requestCBHash_'][_0x24eb30]=_0x49ca85);}['get'](_0x40e277){this['initConnection_']();const _0x4a0bba=new H(),_0xc8c54={'action':'g','request':{'p':_0x40e277['_path']['toString'](),'q':_0x40e277['_queryObject']},'onComplete':_0xfc2ed0=>{const _0x4caebe=_0xfc2ed0['d'];_0xfc2ed0['s']==='ok'?_0x4a0bba['resolve'](_0x4caebe):_0x4a0bba['reject'](_0x4caebe);}};this['outstandingGets_']['push'](_0xc8c54),this['outstandingGetCount_']++;const _0x2d8536=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x2d8536),_0x4a0bba['promise'];}['listen'](_0x211136,_0x352a4b,_0x326d1c,_0x105b3c){this['initConnection_']();const _0x4dc880=_0x211136['_queryIdentifier'],_0x424b12=_0x211136['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x424b12+'\x20'+_0x4dc880),this['listens']['has'](_0x424b12)||this['listens']['set'](_0x424b12,new Map()),f(_0x211136['_queryParams']['isDefault']()||!_0x211136['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x424b12)['has'](_0x4dc880),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0xb9a65b={'onComplete':_0x105b3c,'hashFn':_0x352a4b,'query':_0x211136,'tag':_0x326d1c};this['listens']['get'](_0x424b12)['set'](_0x4dc880,_0xb9a65b),this['connected_']&&this['sendListen_'](_0xb9a65b);}['sendGet_'](_0x1a7ef2){const _0x497c61=this['outstandingGets_'][_0x1a7ef2];this['sendRequest']('g',_0x497c61['request'],_0x51ca2a=>{delete this['outstandingGets_'][_0x1a7ef2],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x497c61['onComplete']&&_0x497c61['onComplete'](_0x51ca2a);});}['sendListen_'](_0x3de9cc){const _0x5c6c8f=_0x3de9cc['query'],_0x46e75a=_0x5c6c8f['_path']['toString'](),_0x4027ae=_0x5c6c8f['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x46e75a+'\x20for\x20'+_0x4027ae);const _0x52c69a={'p':_0x46e75a},_0x6548d0='q';_0x3de9cc['tag']&&(_0x52c69a['q']=_0x5c6c8f['_queryObject'],_0x52c69a['t']=_0x3de9cc['tag']),_0x52c69a['h']=_0x3de9cc['hashFn'](),this['sendRequest'](_0x6548d0,_0x52c69a,_0x34e93b=>{const _0x58791d=_0x34e93b['d'],_0x3e054f=_0x34e93b['s'];se['warnOnListenWarnings_'](_0x58791d,_0x5c6c8f),(this['listens']['get'](_0x46e75a)&&this['listens']['get'](_0x46e75a)['get'](_0x4027ae))===_0x3de9cc&&(this['log_']('listen\x20response',_0x34e93b),_0x3e054f!=='ok'&&this['removeListen_'](_0x46e75a,_0x4027ae),_0x3de9cc['onComplete']&&_0x3de9cc['onComplete'](_0x3e054f,_0x58791d));});}static['warnOnListenWarnings_'](_0x55ddba,_0x560665){if(_0x55ddba&&typeof _0x55ddba=='object'&&Q(_0x55ddba,'w')){const _0x56e9d5=Le(_0x55ddba,'w');if(Array['isArray'](_0x56e9d5)&&~_0x56e9d5['indexOf']('no_index')){const _0x3b86a5='\x22.indexOn\x22:\x20\x22'+_0x560665['_queryParams']['getIndex']()['toString']()+'\x22',_0x37014d=_0x560665['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3b86a5+'\x20at\x20'+_0x37014d+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x10b333){this['authToken_']=_0x10b333,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x10b333);}['reduceReconnectDelayIfAdminCredential_'](_0x2e659d){(_0x2e659d&&_0x2e659d['length']===0x28||wc(_0x2e659d))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x270e95){this['appCheckToken_']=_0x270e95,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x102aaf=this['authToken_'],_0x41267d=Ic(_0x102aaf)?'auth':'gauth',_0x49a860={'cred':_0x102aaf};this['authOverride_']===null?_0x49a860['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x49a860['authvar']=this['authOverride_']),this['sendRequest'](_0x41267d,_0x49a860,_0x283685=>{const _0x110d00=_0x283685['s'],_0x4258f7=_0x283685['d']||'error';this['authToken_']===_0x102aaf&&(_0x110d00==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x110d00,_0x4258f7));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5c66bd=>{const _0x3b48ce=_0x5c66bd['s'],_0x41b3e3=_0x5c66bd['d']||'error';_0x3b48ce==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x3b48ce,_0x41b3e3);});}['unlisten'](_0x5787b3,_0x1a09f3){const _0x513984=_0x5787b3['_path']['toString'](),_0x48ccdc=_0x5787b3['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x513984+'\x20'+_0x48ccdc),f(_0x5787b3['_queryParams']['isDefault']()||!_0x5787b3['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x513984,_0x48ccdc)&&this['connected_']&&this['sendUnlisten_'](_0x513984,_0x48ccdc,_0x5787b3['_queryObject'],_0x1a09f3);}['sendUnlisten_'](_0x32c390,_0x4b9440,_0x4d4194,_0x55d135){this['log_']('Unlisten\x20on\x20'+_0x32c390+'\x20for\x20'+_0x4b9440);const _0x49d870={'p':_0x32c390},_0x1c24ab='n';_0x55d135&&(_0x49d870['q']=_0x4d4194,_0x49d870['t']=_0x55d135),this['sendRequest'](_0x1c24ab,_0x49d870);}['onDisconnectPut'](_0x1dbea5,_0x2cfa8d,_0x28a2cd){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1dbea5,_0x2cfa8d,_0x28a2cd):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1dbea5,'action':'o','data':_0x2cfa8d,'onComplete':_0x28a2cd});}['onDisconnectMerge'](_0x302d2b,_0x1f10e6,_0x3c8d09){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x302d2b,_0x1f10e6,_0x3c8d09):this['onDisconnectRequestQueue_']['push']({'pathString':_0x302d2b,'action':'om','data':_0x1f10e6,'onComplete':_0x3c8d09});}['onDisconnectCancel'](_0x1598f2,_0x38ce83){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1598f2,null,_0x38ce83):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1598f2,'action':'oc','data':null,'onComplete':_0x38ce83});}['sendOnDisconnect_'](_0x44cc09,_0xa56433,_0x3bb04f,_0x5f224){const _0x4dd8cc={'p':_0xa56433,'d':_0x3bb04f};this['log_']('onDisconnect\x20'+_0x44cc09,_0x4dd8cc),this['sendRequest'](_0x44cc09,_0x4dd8cc,_0x6baeed=>{_0x5f224&&setTimeout(()=>{_0x5f224(_0x6baeed['s'],_0x6baeed['d']);},Math['floor'](0x0));});}['put'](_0x53fbbb,_0x4ac0bb,_0x911afe,_0x16e844){this['putInternal']('p',_0x53fbbb,_0x4ac0bb,_0x911afe,_0x16e844);}['merge'](_0x5356e7,_0x28f15a,_0x29386d,_0x22f045){this['putInternal']('m',_0x5356e7,_0x28f15a,_0x29386d,_0x22f045);}['putInternal'](_0x4d26bd,_0x46ca71,_0x2832f1,_0x4e7858,_0x225663){this['initConnection_']();const _0x12e613={'p':_0x46ca71,'d':_0x2832f1};_0x225663!==void 0x0&&(_0x12e613['h']=_0x225663),this['outstandingPuts_']['push']({'action':_0x4d26bd,'request':_0x12e613,'onComplete':_0x4e7858}),this['outstandingPutCount_']++;const _0x3e8e69=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3e8e69):this['log_']('Buffering\x20put:\x20'+_0x46ca71);}['sendPut_'](_0xc0fffe){const _0x52f914=this['outstandingPuts_'][_0xc0fffe]['action'],_0x28863f=this['outstandingPuts_'][_0xc0fffe]['request'],_0x63766f=this['outstandingPuts_'][_0xc0fffe]['onComplete'];this['outstandingPuts_'][_0xc0fffe]['queued']=this['connected_'],this['sendRequest'](_0x52f914,_0x28863f,_0x1555a8=>{this['log_'](_0x52f914+'\x20response',_0x1555a8),delete this['outstandingPuts_'][_0xc0fffe],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x63766f&&_0x63766f(_0x1555a8['s'],_0x1555a8['d']);});}['reportStats'](_0x4adbba){if(this['connected_']){const _0x216e82={'c':_0x4adbba};this['log_']('reportStats',_0x216e82),this['sendRequest']('s',_0x216e82,_0x4ea0cf=>{if(_0x4ea0cf['s']!=='ok'){const _0x5d0dee=_0x4ea0cf['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5d0dee);}});}}['onDataMessage_'](_0x159a7a){if('r'in _0x159a7a){this['log_']('from\x20server:\x20'+O(_0x159a7a));const _0x31321f=_0x159a7a['r'],_0x5ac42c=this['requestCBHash_'][_0x31321f];_0x5ac42c&&(delete this['requestCBHash_'][_0x31321f],_0x5ac42c(_0x159a7a['b']));}else{if('error'in _0x159a7a)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x159a7a['error'];'a'in _0x159a7a&&this['onDataPush_'](_0x159a7a['a'],_0x159a7a['b']);}}['onDataPush_'](_0x3397f1,_0x3b1ad8){this['log_']('handleServerMessage',_0x3397f1,_0x3b1ad8),_0x3397f1==='d'?this['onDataUpdate_'](_0x3b1ad8['p'],_0x3b1ad8['d'],!0x1,_0x3b1ad8['t']):_0x3397f1==='m'?this['onDataUpdate_'](_0x3b1ad8['p'],_0x3b1ad8['d'],!0x0,_0x3b1ad8['t']):_0x3397f1==='c'?this['onListenRevoked_'](_0x3b1ad8['p'],_0x3b1ad8['q']):_0x3397f1==='ac'?this['onAuthRevoked_'](_0x3b1ad8['s'],_0x3b1ad8['d']):_0x3397f1==='apc'?this['onAppCheckRevoked_'](_0x3b1ad8['s'],_0x3b1ad8['d']):_0x3397f1==='sd'?this['onSecurityDebugPacket_'](_0x3b1ad8):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3397f1)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x14a055,_0x162b0b){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x14a055),this['lastSessionId']=_0x162b0b,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x22a062){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x22a062));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0xfd214d){_0xfd214d&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0xfd214d;}['onOnline_'](_0x553c00){_0x553c00?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x1e1a1e=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x2774e0=Math['max'](0x0,this['reconnectDelay_']-_0x1e1a1e);_0x2774e0=Math['random']()*_0x2774e0,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x2774e0+'ms'),this['scheduleConnect_'](_0x2774e0),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x22cf17=this['onDataMessage_']['bind'](this),_0x2b9fe8=this['onReady_']['bind'](this),_0x36f4c8=this['onRealtimeDisconnect_']['bind'](this),_0x2b1cec=this['id']+':'+se['nextConnectionId_']++,_0x2642f6=this['lastSessionId'];let _0x10ea32=!0x1,_0x1236c1=null;const _0x8ef687=function(){_0x1236c1?_0x1236c1['close']():(_0x10ea32=!0x0,_0x36f4c8());},_0x1bff1e=function(_0x4bc756){f(_0x1236c1,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1236c1['sendRequest'](_0x4bc756);};this['realtime_']={'close':_0x8ef687,'sendRequest':_0x1bff1e};const _0x300c13=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x3fc59c,_0x37555f]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x300c13),this['appCheckTokenProvider_']['getToken'](_0x300c13)]);_0x10ea32?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x3fc59c&&_0x3fc59c['accessToken'],this['appCheckToken_']=_0x37555f&&_0x37555f['token'],_0x1236c1=new Sh(_0x2b1cec,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x22cf17,_0x2b9fe8,_0x36f4c8,_0x15c550=>{U(_0x15c550+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x2642f6));}catch(_0x45b561){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x45b561),_0x10ea32||(this['repoInfo_']['nodeAdmin']&&U(_0x45b561),_0x8ef687());}}}['interrupt'](_0x5d18b9){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x5d18b9),this['interruptReasons_'][_0x5d18b9]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x3882b7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x3882b7),delete this['interruptReasons_'][_0x3882b7],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x24e46f){const _0x2f0051=_0x24e46f-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2f0051});}['cancelSentTransactions_'](){for(let _0x4dc092=0x0;_0x4dc092<this['outstandingPuts_']['length'];_0x4dc092++){const _0x4bf080=this['outstandingPuts_'][_0x4dc092];_0x4bf080&&'h'in _0x4bf080['request']&&_0x4bf080['queued']&&(_0x4bf080['onComplete']&&_0x4bf080['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x4dc092],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x161384,_0x248f12){let _0x52301f;_0x248f12?_0x52301f=_0x248f12['map'](_0x31105d=>$i(_0x31105d))['join']('$'):_0x52301f='default';const _0x4907f9=this['removeListen_'](_0x161384,_0x52301f);_0x4907f9&&_0x4907f9['onComplete']&&_0x4907f9['onComplete']('permission_denied');}['removeListen_'](_0x4b9424,_0x17c79e){const _0x1b3ed6=new C(_0x4b9424)['toString']();let _0x5ab931;if(this['listens']['has'](_0x1b3ed6)){const _0x121b4d=this['listens']['get'](_0x1b3ed6);_0x5ab931=_0x121b4d['get'](_0x17c79e),_0x121b4d['delete'](_0x17c79e),_0x121b4d['size']===0x0&&this['listens']['delete'](_0x1b3ed6);}else _0x5ab931=void 0x0;return _0x5ab931;}['onAuthRevoked_'](_0x165726,_0x511e67){L('Auth\x20token\x20revoked:\x20'+_0x165726+'/'+_0x511e67),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x165726==='invalid_token'||_0x165726==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1c905d,_0x287ea4){L('App\x20check\x20token\x20revoked:\x20'+_0x1c905d+'/'+_0x287ea4),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1c905d==='invalid_token'||_0x1c905d==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x158d4b){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x158d4b):'msg'in _0x158d4b&&console['log']('FIREBASE:\x20'+_0x158d4b['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0xfd61e1 of this['listens']['values']())for(const _0x257460 of _0xfd61e1['values']())this['sendListen_'](_0x257460);for(let _0x2ddbd0=0x0;_0x2ddbd0<this['outstandingPuts_']['length'];_0x2ddbd0++)this['outstandingPuts_'][_0x2ddbd0]&&this['sendPut_'](_0x2ddbd0);for(;this['onDisconnectRequestQueue_']['length'];){const _0x21be5e=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x21be5e['action'],_0x21be5e['pathString'],_0x21be5e['data'],_0x21be5e['onComplete']);}for(let _0x56c2e0=0x0;_0x56c2e0<this['outstandingGets_']['length'];_0x56c2e0++)this['outstandingGets_'][_0x56c2e0]&&this['sendGet_'](_0x56c2e0);}['sendConnectStats_'](){const _0x21171c={};let _0x5aa736='js';_0x21171c['sdk.'+_0x5aa736+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x21171c['framework.cordova']=0x1:Kr()&&(_0x21171c['framework.reactnative']=0x1),this['reportStats'](_0x21171c);}['shouldReconnect_'](){const _0x5b04f5=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x5b04f5;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5ccb9a,_0x533598){this['name']=_0x5ccb9a,this['node']=_0x533598;}static['Wrap'](_0x3c4c00,_0x49a4ca){return new E(_0x3c4c00,_0x49a4ca);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x30de35,_0x387169){const _0x1b9f2e=new E(We,_0x30de35),_0x65aea5=new E(We,_0x387169);return this['compare'](_0x1b9f2e,_0x65aea5)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x21fa85){sn=_0x21fa85;}['compare'](_0x225463,_0x16ffd0){return qe(_0x225463['name'],_0x16ffd0['name']);}['isDefinedOn'](_0x8887c9){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x26dbe3,_0x3a077f){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x2903b6,_0x491377){return f(typeof _0x2903b6=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x2903b6,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x3719e5,_0x486d0d,_0x9a7e97,_0x1388fb,_0x286140=null){this['isReverse_']=_0x1388fb,this['resultGenerator_']=_0x286140,this['nodeStack_']=[];let _0x4f4405=0x1;for(;!_0x3719e5['isEmpty']();)if(_0x3719e5=_0x3719e5,_0x4f4405=_0x486d0d?_0x9a7e97(_0x3719e5['key'],_0x486d0d):0x1,_0x1388fb&&(_0x4f4405*=-0x1),_0x4f4405<0x0)this['isReverse_']?_0x3719e5=_0x3719e5['left']:_0x3719e5=_0x3719e5['right'];else{if(_0x4f4405===0x0){this['nodeStack_']['push'](_0x3719e5);break;}else this['nodeStack_']['push'](_0x3719e5),this['isReverse_']?_0x3719e5=_0x3719e5['right']:_0x3719e5=_0x3719e5['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x2bcf80=this['nodeStack_']['pop'](),_0x10c939;if(this['resultGenerator_']?_0x10c939=this['resultGenerator_'](_0x2bcf80['key'],_0x2bcf80['value']):_0x10c939={'key':_0x2bcf80['key'],'value':_0x2bcf80['value']},this['isReverse_']){for(_0x2bcf80=_0x2bcf80['left'];!_0x2bcf80['isEmpty']();)this['nodeStack_']['push'](_0x2bcf80),_0x2bcf80=_0x2bcf80['right'];}else{for(_0x2bcf80=_0x2bcf80['right'];!_0x2bcf80['isEmpty']();)this['nodeStack_']['push'](_0x2bcf80),_0x2bcf80=_0x2bcf80['left'];}return _0x10c939;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x28c38c=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x28c38c['key'],_0x28c38c['value']):{'key':_0x28c38c['key'],'value':_0x28c38c['value']};}}class M{constructor(_0x2d6054,_0x82d615,_0x4d0cf3,_0x24b27c,_0x1934b2){this['key']=_0x2d6054,this['value']=_0x82d615,this['color']=_0x4d0cf3??M['RED'],this['left']=_0x24b27c??B['EMPTY_NODE'],this['right']=_0x1934b2??B['EMPTY_NODE'];}['copy'](_0x22735d,_0x33a231,_0x120b6e,_0xbea5ed,_0x599ec2){return new M(_0x22735d??this['key'],_0x33a231??this['value'],_0x120b6e??this['color'],_0xbea5ed??this['left'],_0x599ec2??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x1c7f8f){return this['left']['inorderTraversal'](_0x1c7f8f)||!!_0x1c7f8f(this['key'],this['value'])||this['right']['inorderTraversal'](_0x1c7f8f);}['reverseTraversal'](_0x4fd6f3){return this['right']['reverseTraversal'](_0x4fd6f3)||_0x4fd6f3(this['key'],this['value'])||this['left']['reverseTraversal'](_0x4fd6f3);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4c34c6,_0x13af78,_0x2518aa){let _0x45a35=this;const _0x555ee5=_0x2518aa(_0x4c34c6,_0x45a35['key']);return _0x555ee5<0x0?_0x45a35=_0x45a35['copy'](null,null,null,_0x45a35['left']['insert'](_0x4c34c6,_0x13af78,_0x2518aa),null):_0x555ee5===0x0?_0x45a35=_0x45a35['copy'](null,_0x13af78,null,null,null):_0x45a35=_0x45a35['copy'](null,null,null,null,_0x45a35['right']['insert'](_0x4c34c6,_0x13af78,_0x2518aa)),_0x45a35['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x5c016a=this;return!_0x5c016a['left']['isRed_']()&&!_0x5c016a['left']['left']['isRed_']()&&(_0x5c016a=_0x5c016a['moveRedLeft_']()),_0x5c016a=_0x5c016a['copy'](null,null,null,_0x5c016a['left']['removeMin_'](),null),_0x5c016a['fixUp_']();}['remove'](_0x318841,_0x30665b){let _0x345ea8,_0x4b6484;if(_0x345ea8=this,_0x30665b(_0x318841,_0x345ea8['key'])<0x0)!_0x345ea8['left']['isEmpty']()&&!_0x345ea8['left']['isRed_']()&&!_0x345ea8['left']['left']['isRed_']()&&(_0x345ea8=_0x345ea8['moveRedLeft_']()),_0x345ea8=_0x345ea8['copy'](null,null,null,_0x345ea8['left']['remove'](_0x318841,_0x30665b),null);else{if(_0x345ea8['left']['isRed_']()&&(_0x345ea8=_0x345ea8['rotateRight_']()),!_0x345ea8['right']['isEmpty']()&&!_0x345ea8['right']['isRed_']()&&!_0x345ea8['right']['left']['isRed_']()&&(_0x345ea8=_0x345ea8['moveRedRight_']()),_0x30665b(_0x318841,_0x345ea8['key'])===0x0){if(_0x345ea8['right']['isEmpty']())return B['EMPTY_NODE'];_0x4b6484=_0x345ea8['right']['min_'](),_0x345ea8=_0x345ea8['copy'](_0x4b6484['key'],_0x4b6484['value'],null,null,_0x345ea8['right']['removeMin_']());}_0x345ea8=_0x345ea8['copy'](null,null,null,null,_0x345ea8['right']['remove'](_0x318841,_0x30665b));}return _0x345ea8['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1a8494=this;return _0x1a8494['right']['isRed_']()&&!_0x1a8494['left']['isRed_']()&&(_0x1a8494=_0x1a8494['rotateLeft_']()),_0x1a8494['left']['isRed_']()&&_0x1a8494['left']['left']['isRed_']()&&(_0x1a8494=_0x1a8494['rotateRight_']()),_0x1a8494['left']['isRed_']()&&_0x1a8494['right']['isRed_']()&&(_0x1a8494=_0x1a8494['colorFlip_']()),_0x1a8494;}['moveRedLeft_'](){let _0x27e889=this['colorFlip_']();return _0x27e889['right']['left']['isRed_']()&&(_0x27e889=_0x27e889['copy'](null,null,null,null,_0x27e889['right']['rotateRight_']()),_0x27e889=_0x27e889['rotateLeft_'](),_0x27e889=_0x27e889['colorFlip_']()),_0x27e889;}['moveRedRight_'](){let _0x147bcf=this['colorFlip_']();return _0x147bcf['left']['left']['isRed_']()&&(_0x147bcf=_0x147bcf['rotateRight_'](),_0x147bcf=_0x147bcf['colorFlip_']()),_0x147bcf;}['rotateLeft_'](){const _0x386d35=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x386d35,null);}['rotateRight_'](){const _0x29b300=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x29b300);}['colorFlip_'](){const _0x1c8dab=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x1de24d=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1c8dab,_0x1de24d);}['checkMaxDepth_'](){const _0x22f7b2=this['check_']();return Math['pow'](0x2,_0x22f7b2)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2874e8=this['left']['check_']();if(_0x2874e8!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2874e8+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x40c67d,_0x334aaf,_0x3fb3fc,_0x289c4c,_0x18c7f3){return this;}['insert'](_0x491a73,_0x36dfc2,_0x1bfbf0){return new M(_0x491a73,_0x36dfc2,null);}['remove'](_0x40c17d,_0x12acc0){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1005b3){return!0x1;}['reverseTraversal'](_0x763661){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x50184e,_0x5d3a1e=B['EMPTY_NODE']){this['comparator_']=_0x50184e,this['root_']=_0x5d3a1e;}['insert'](_0x3f7d0c,_0x570314){return new B(this['comparator_'],this['root_']['insert'](_0x3f7d0c,_0x570314,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3a1d75){return new B(this['comparator_'],this['root_']['remove'](_0x3a1d75,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x276772){let _0x188895,_0x518f63=this['root_'];for(;!_0x518f63['isEmpty']();){if(_0x188895=this['comparator_'](_0x276772,_0x518f63['key']),_0x188895===0x0)return _0x518f63['value'];_0x188895<0x0?_0x518f63=_0x518f63['left']:_0x188895>0x0&&(_0x518f63=_0x518f63['right']);}return null;}['getPredecessorKey'](_0x55cee5){let _0x34a900,_0x51bd58=this['root_'],_0xda4eb=null;for(;!_0x51bd58['isEmpty']();)if(_0x34a900=this['comparator_'](_0x55cee5,_0x51bd58['key']),_0x34a900===0x0){if(_0x51bd58['left']['isEmpty']())return _0xda4eb?_0xda4eb['key']:null;for(_0x51bd58=_0x51bd58['left'];!_0x51bd58['right']['isEmpty']();)_0x51bd58=_0x51bd58['right'];return _0x51bd58['key'];}else _0x34a900<0x0?_0x51bd58=_0x51bd58['left']:_0x34a900>0x0&&(_0xda4eb=_0x51bd58,_0x51bd58=_0x51bd58['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x25e1ea){return this['root_']['inorderTraversal'](_0x25e1ea);}['reverseTraversal'](_0x5c69af){return this['root_']['reverseTraversal'](_0x5c69af);}['getIterator'](_0x3a333b){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x3a333b);}['getIteratorFrom'](_0x54a8ab,_0x35d058){return new rn(this['root_'],_0x54a8ab,this['comparator_'],!0x1,_0x35d058);}['getReverseIteratorFrom'](_0x79e76f,_0x4389a0){return new rn(this['root_'],_0x79e76f,this['comparator_'],!0x0,_0x4389a0);}['getReverseIterator'](_0x1487d4){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x1487d4);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x3df093,_0x127eb5){return qe(_0x3df093['name'],_0x127eb5['name']);}function Qi(_0x57e112,_0x593138){return qe(_0x57e112,_0x593138);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x41b4b9){Ci=_0x41b4b9;}const Po=function(_0x54a15f){return typeof _0x54a15f=='number'?'number:'+ao(_0x54a15f):'string:'+_0x54a15f;},No=function(_0x17b74e){if(_0x17b74e['isLeafNode']()){const _0x1a21e0=_0x17b74e['val']();f(typeof _0x1a21e0=='string'||typeof _0x1a21e0=='number'||typeof _0x1a21e0=='object'&&Q(_0x1a21e0,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x17b74e===Ci||_0x17b74e['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x17b74e===Ci||_0x17b74e['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x59231e){nr=_0x59231e;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x4f435d,_0x36d2c6=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4f435d,this['priorityNode_']=_0x36d2c6,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0xfceeac){return new D(this['value_'],_0xfceeac);}['getImmediateChild'](_0x57a6a1){return _0x57a6a1==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5e4a7f){return v(_0x5e4a7f)?this:y(_0x5e4a7f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x339eec,_0x14efba){return null;}['updateImmediateChild'](_0x46e68a,_0xa796f0){return _0x46e68a==='.priority'?this['updatePriority'](_0xa796f0):_0xa796f0['isEmpty']()&&_0x46e68a!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x46e68a,_0xa796f0)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x594295,_0x3317cf){const _0x16bed4=y(_0x594295);return _0x16bed4===null?_0x3317cf:_0x3317cf['isEmpty']()&&_0x16bed4!=='.priority'?this:(f(_0x16bed4!=='.priority'||Ce(_0x594295)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x16bed4,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x594295),_0x3317cf)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x202498,_0x4bbb80){return!0x1;}['val'](_0x566202){return _0x566202&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5236a6='';this['priorityNode_']['isEmpty']()||(_0x5236a6+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x1822d9=typeof this['value_'];_0x5236a6+=_0x1822d9+':',_0x1822d9==='number'?_0x5236a6+=ao(this['value_']):_0x5236a6+=this['value_'],this['lazyHash_']=ro(_0x5236a6);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x5f570e){return _0x5f570e===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x5f570e instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x5f570e['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x5f570e));}['compareToLeafNode_'](_0x319bae){const _0x3a3a3a=typeof _0x319bae['value_'],_0x1192d8=typeof this['value_'],_0x407d0e=D['VALUE_TYPE_ORDER']['indexOf'](_0x3a3a3a),_0x8f3b25=D['VALUE_TYPE_ORDER']['indexOf'](_0x1192d8);return f(_0x407d0e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3a3a3a),f(_0x8f3b25>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1192d8),_0x407d0e===_0x8f3b25?_0x1192d8==='object'?0x0:this['value_']<_0x319bae['value_']?-0x1:this['value_']===_0x319bae['value_']?0x0:0x1:_0x8f3b25-_0x407d0e;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3d86af){if(_0x3d86af===this)return!0x0;if(_0x3d86af['isLeafNode']()){const _0x38c082=_0x3d86af;return this['value_']===_0x38c082['value_']&&this['priorityNode_']['equals'](_0x38c082['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x33c16d){Oo=_0x33c16d;}function Wh(_0x4d2c95){Do=_0x4d2c95;}class Bh extends Fn{['compare'](_0x2bbfbb,_0x2fbf2d){const _0x1431c9=_0x2bbfbb['node']['getPriority'](),_0x313ada=_0x2fbf2d['node']['getPriority'](),_0x3d7f57=_0x1431c9['compareTo'](_0x313ada);return _0x3d7f57===0x0?qe(_0x2bbfbb['name'],_0x2fbf2d['name']):_0x3d7f57;}['isDefinedOn'](_0x4435ae){return!_0x4435ae['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5a79a2,_0x53c178){return!_0x5a79a2['getPriority']()['equals'](_0x53c178['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x118b81,_0x3b32a2){const _0x26004d=Oo(_0x118b81);return new E(_0x3b32a2,new D('[PRIORITY-POST]',_0x26004d));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x547c17){const _0xbcdf0d=_0x2bd34e=>parseInt(Math['log'](_0x2bd34e)/Vh,0xa),_0x8996af=_0x23c3d2=>parseInt(Array(_0x23c3d2+0x1)['join']('1'),0x2);this['count']=_0xbcdf0d(_0x547c17+0x1),this['current_']=this['count']-0x1;const _0x3817f9=_0x8996af(this['count']);this['bits_']=_0x547c17+0x1&_0x3817f9;}['nextBitIsOne'](){const _0x3f95dc=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3f95dc;}}const yn=function(_0x4aaa10,_0x493bb1,_0x396209,_0xfa6f44){_0x4aaa10['sort'](_0x493bb1);const _0x5de976=function(_0xdf981,_0x487510){const _0x1e1508=_0x487510-_0xdf981;let _0x5d7d1e,_0x20c49e;if(_0x1e1508===0x0)return null;if(_0x1e1508===0x1)return _0x5d7d1e=_0x4aaa10[_0xdf981],_0x20c49e=_0x396209?_0x396209(_0x5d7d1e):_0x5d7d1e,new M(_0x20c49e,_0x5d7d1e['node'],M['BLACK'],null,null);{const _0x5217f6=parseInt(_0x1e1508/0x2,0xa)+_0xdf981,_0x383cdb=_0x5de976(_0xdf981,_0x5217f6),_0x1e3e6e=_0x5de976(_0x5217f6+0x1,_0x487510);return _0x5d7d1e=_0x4aaa10[_0x5217f6],_0x20c49e=_0x396209?_0x396209(_0x5d7d1e):_0x5d7d1e,new M(_0x20c49e,_0x5d7d1e['node'],M['BLACK'],_0x383cdb,_0x1e3e6e);}},_0x5178bd=function(_0x20eefd){let _0x58d771=null,_0x51b312=null,_0x3a0bb9=_0x4aaa10['length'];const _0x446e3d=function(_0x155092,_0x738eaf){const _0x11f272=_0x3a0bb9-_0x155092,_0x3c6cc3=_0x3a0bb9;_0x3a0bb9-=_0x155092;const _0x190ee8=_0x5de976(_0x11f272+0x1,_0x3c6cc3),_0xcb327a=_0x4aaa10[_0x11f272],_0x2a125b=_0x396209?_0x396209(_0xcb327a):_0xcb327a;_0x23d68d(new M(_0x2a125b,_0xcb327a['node'],_0x738eaf,null,_0x190ee8));},_0x23d68d=function(_0x52d2a7){_0x58d771?(_0x58d771['left']=_0x52d2a7,_0x58d771=_0x52d2a7):(_0x51b312=_0x52d2a7,_0x58d771=_0x52d2a7);};for(let _0x12d7f6=0x0;_0x12d7f6<_0x20eefd['count'];++_0x12d7f6){const _0x590ecc=_0x20eefd['nextBitIsOne'](),_0x46e5c6=Math['pow'](0x2,_0x20eefd['count']-(_0x12d7f6+0x1));_0x590ecc?_0x446e3d(_0x46e5c6,M['BLACK']):(_0x446e3d(_0x46e5c6,M['BLACK']),_0x446e3d(_0x46e5c6,M['RED']));}return _0x51b312;},_0x3a0752=new Hh(_0x4aaa10['length']),_0x4ed255=_0x5178bd(_0x3a0752);return new B(_0xfa6f44||_0x493bb1,_0x4ed255);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x483116,_0x35bc58){this['indexes_']=_0x483116,this['indexSet_']=_0x35bc58;}['get'](_0x33f7ca){const _0x15caf9=Le(this['indexes_'],_0x33f7ca);if(!_0x15caf9)throw new Error('No\x20index\x20defined\x20for\x20'+_0x33f7ca);return _0x15caf9 instanceof B?_0x15caf9:null;}['hasIndex'](_0x36eeb2){return Q(this['indexSet_'],_0x36eeb2['toString']());}['addIndex'](_0x41b8f4,_0x111448){f(_0x41b8f4!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4fb65c=[];let _0x2cf19e=!0x1;const _0x5613a9=_0x111448['getIterator'](E['Wrap']);let _0x1b7a45=_0x5613a9['getNext']();for(;_0x1b7a45;)_0x2cf19e=_0x2cf19e||_0x41b8f4['isDefinedOn'](_0x1b7a45['node']),_0x4fb65c['push'](_0x1b7a45),_0x1b7a45=_0x5613a9['getNext']();let _0x11418c;_0x2cf19e?_0x11418c=yn(_0x4fb65c,_0x41b8f4['getCompare']()):_0x11418c=Qe;const _0x54d3bf=_0x41b8f4['toString'](),_0x9b3561={...this['indexSet_']};_0x9b3561[_0x54d3bf]=_0x41b8f4;const _0x19d4a2={...this['indexes_']};return _0x19d4a2[_0x54d3bf]=_0x11418c,new te(_0x19d4a2,_0x9b3561);}['addToIndexes'](_0x1c86e5,_0x4e6714){const _0x1574c4=_n(this['indexes_'],(_0x169252,_0x5bddb6)=>{const _0x575d95=Le(this['indexSet_'],_0x5bddb6);if(f(_0x575d95,'Missing\x20index\x20implementation\x20for\x20'+_0x5bddb6),_0x169252===Qe){if(_0x575d95['isDefinedOn'](_0x1c86e5['node'])){const _0x14b6f9=[],_0x1a393c=_0x4e6714['getIterator'](E['Wrap']);let _0x23e0af=_0x1a393c['getNext']();for(;_0x23e0af;)_0x23e0af['name']!==_0x1c86e5['name']&&_0x14b6f9['push'](_0x23e0af),_0x23e0af=_0x1a393c['getNext']();return _0x14b6f9['push'](_0x1c86e5),yn(_0x14b6f9,_0x575d95['getCompare']());}else return Qe;}else{const _0x167583=_0x4e6714['get'](_0x1c86e5['name']);let _0x1ecb7f=_0x169252;return _0x167583&&(_0x1ecb7f=_0x1ecb7f['remove'](new E(_0x1c86e5['name'],_0x167583))),_0x1ecb7f['insert'](_0x1c86e5,_0x1c86e5['node']);}});return new te(_0x1574c4,this['indexSet_']);}['removeFromIndexes'](_0x357462,_0x4cb24f){const _0x1fca79=_n(this['indexes_'],_0x3858b2=>{if(_0x3858b2===Qe)return _0x3858b2;{const _0x225ac4=_0x4cb24f['get'](_0x357462['name']);return _0x225ac4?_0x3858b2['remove'](new E(_0x357462['name'],_0x225ac4)):_0x3858b2;}});return new te(_0x1fca79,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x490a77,_0x3d1d1,_0x591cda){this['children_']=_0x490a77,this['priorityNode_']=_0x3d1d1,this['indexMap_']=_0x591cda,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x53a91c){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x53a91c,this['indexMap_']);}['getImmediateChild'](_0x15f8a2){if(_0x15f8a2==='.priority')return this['getPriority']();{const _0xecd4f1=this['children_']['get'](_0x15f8a2);return _0xecd4f1===null?It:_0xecd4f1;}}['getChild'](_0x1cbf06){const _0x5dbdae=y(_0x1cbf06);return _0x5dbdae===null?this:this['getImmediateChild'](_0x5dbdae)['getChild'](S(_0x1cbf06));}['hasChild'](_0x5a6623){return this['children_']['get'](_0x5a6623)!==null;}['updateImmediateChild'](_0x1933cb,_0x52b676){if(f(_0x52b676,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1933cb==='.priority')return this['updatePriority'](_0x52b676);{const _0x5ad191=new E(_0x1933cb,_0x52b676);let _0x38ca8f,_0x911245;_0x52b676['isEmpty']()?(_0x38ca8f=this['children_']['remove'](_0x1933cb),_0x911245=this['indexMap_']['removeFromIndexes'](_0x5ad191,this['children_'])):(_0x38ca8f=this['children_']['insert'](_0x1933cb,_0x52b676),_0x911245=this['indexMap_']['addToIndexes'](_0x5ad191,this['children_']));const _0x4889ee=_0x38ca8f['isEmpty']()?It:this['priorityNode_'];return new g(_0x38ca8f,_0x4889ee,_0x911245);}}['updateChild'](_0x5e681b,_0x58e51e){const _0x5c8da2=y(_0x5e681b);if(_0x5c8da2===null)return _0x58e51e;{f(y(_0x5e681b)!=='.priority'||Ce(_0x5e681b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2fa495=this['getImmediateChild'](_0x5c8da2)['updateChild'](S(_0x5e681b),_0x58e51e);return this['updateImmediateChild'](_0x5c8da2,_0x2fa495);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2f1499){if(this['isEmpty']())return null;const _0x3346fc={};let _0x385b43=0x0,_0x574f67=0x0,_0x1c04f3=!0x0;if(this['forEachChild'](R,(_0x31788a,_0x513f8d)=>{_0x3346fc[_0x31788a]=_0x513f8d['val'](_0x2f1499),_0x385b43++,_0x1c04f3&&g['INTEGER_REGEXP_']['test'](_0x31788a)?_0x574f67=Math['max'](_0x574f67,Number(_0x31788a)):_0x1c04f3=!0x1;}),!_0x2f1499&&_0x1c04f3&&_0x574f67<0x2*_0x385b43){const _0x25fb9c=[];for(const _0x2be0c4 in _0x3346fc)_0x25fb9c[_0x2be0c4]=_0x3346fc[_0x2be0c4];return _0x25fb9c;}else return _0x2f1499&&!this['getPriority']()['isEmpty']()&&(_0x3346fc['.priority']=this['getPriority']()['val']()),_0x3346fc;}['hash'](){if(this['lazyHash_']===null){let _0x38f423='';this['getPriority']()['isEmpty']()||(_0x38f423+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xa69c19,_0x2e17a2)=>{const _0x5482c7=_0x2e17a2['hash']();_0x5482c7!==''&&(_0x38f423+=':'+_0xa69c19+':'+_0x5482c7);}),this['lazyHash_']=_0x38f423===''?'':ro(_0x38f423);}return this['lazyHash_'];}['getPredecessorChildName'](_0x42cb3c,_0x5e3c0c,_0x44af53){const _0x8ede5c=this['resolveIndex_'](_0x44af53);if(_0x8ede5c){const _0x5a6c35=_0x8ede5c['getPredecessorKey'](new E(_0x42cb3c,_0x5e3c0c));return _0x5a6c35?_0x5a6c35['name']:null;}else return this['children_']['getPredecessorKey'](_0x42cb3c);}['getFirstChildName'](_0x404e99){const _0x1db3bd=this['resolveIndex_'](_0x404e99);if(_0x1db3bd){const _0x2c5258=_0x1db3bd['minKey']();return _0x2c5258&&_0x2c5258['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x511b1a){const _0x34fcaf=this['getFirstChildName'](_0x511b1a);return _0x34fcaf?new E(_0x34fcaf,this['children_']['get'](_0x34fcaf)):null;}['getLastChildName'](_0xe97551){const _0x36aa99=this['resolveIndex_'](_0xe97551);if(_0x36aa99){const _0x57b83c=_0x36aa99['maxKey']();return _0x57b83c&&_0x57b83c['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5b86d0){const _0x45f115=this['getLastChildName'](_0x5b86d0);return _0x45f115?new E(_0x45f115,this['children_']['get'](_0x45f115)):null;}['forEachChild'](_0x5078c7,_0x46ecb3){const _0x2590b7=this['resolveIndex_'](_0x5078c7);return _0x2590b7?_0x2590b7['inorderTraversal'](_0x7b31f=>_0x46ecb3(_0x7b31f['name'],_0x7b31f['node'])):this['children_']['inorderTraversal'](_0x46ecb3);}['getIterator'](_0x42131a){return this['getIteratorFrom'](_0x42131a['minPost'](),_0x42131a);}['getIteratorFrom'](_0x1bd349,_0x941541){const _0x13860a=this['resolveIndex_'](_0x941541);if(_0x13860a)return _0x13860a['getIteratorFrom'](_0x1bd349,_0xf69a46=>_0xf69a46);{const _0x46de4c=this['children_']['getIteratorFrom'](_0x1bd349['name'],E['Wrap']);let _0x42f4e8=_0x46de4c['peek']();for(;_0x42f4e8!=null&&_0x941541['compare'](_0x42f4e8,_0x1bd349)<0x0;)_0x46de4c['getNext'](),_0x42f4e8=_0x46de4c['peek']();return _0x46de4c;}}['getReverseIterator'](_0x237d95){return this['getReverseIteratorFrom'](_0x237d95['maxPost'](),_0x237d95);}['getReverseIteratorFrom'](_0x5d0164,_0x19205f){const _0x2c87d7=this['resolveIndex_'](_0x19205f);if(_0x2c87d7)return _0x2c87d7['getReverseIteratorFrom'](_0x5d0164,_0x2de0ce=>_0x2de0ce);{const _0x287b7=this['children_']['getReverseIteratorFrom'](_0x5d0164['name'],E['Wrap']);let _0x2772fc=_0x287b7['peek']();for(;_0x2772fc!=null&&_0x19205f['compare'](_0x2772fc,_0x5d0164)>0x0;)_0x287b7['getNext'](),_0x2772fc=_0x287b7['peek']();return _0x287b7;}}['compareTo'](_0xa1dbf2){return this['isEmpty']()?_0xa1dbf2['isEmpty']()?0x0:-0x1:_0xa1dbf2['isLeafNode']()||_0xa1dbf2['isEmpty']()?0x1:_0xa1dbf2===Kt?-0x1:0x0;}['withIndex'](_0x210a44){if(_0x210a44===ve||this['indexMap_']['hasIndex'](_0x210a44))return this;{const _0x207edc=this['indexMap_']['addIndex'](_0x210a44,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x207edc);}}['isIndexed'](_0x331f13){return _0x331f13===ve||this['indexMap_']['hasIndex'](_0x331f13);}['equals'](_0x59b946){if(_0x59b946===this)return!0x0;if(_0x59b946['isLeafNode']())return!0x1;{const _0x6850d7=_0x59b946;if(this['getPriority']()['equals'](_0x6850d7['getPriority']())){if(this['children_']['count']()===_0x6850d7['children_']['count']()){const _0x34b8d4=this['getIterator'](R),_0x23e62b=_0x6850d7['getIterator'](R);let _0x3a49a1=_0x34b8d4['getNext'](),_0x47cb48=_0x23e62b['getNext']();for(;_0x3a49a1&&_0x47cb48;){if(_0x3a49a1['name']!==_0x47cb48['name']||!_0x3a49a1['node']['equals'](_0x47cb48['node']))return!0x1;_0x3a49a1=_0x34b8d4['getNext'](),_0x47cb48=_0x23e62b['getNext']();}return _0x3a49a1===null&&_0x47cb48===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4c865d){return _0x4c865d===ve?null:this['indexMap_']['get'](_0x4c865d['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x42be4d){return _0x42be4d===this?0x0:0x1;}['equals'](_0x295fab){return _0x295fab===this;}['getPriority'](){return this;}['getImmediateChild'](_0x288a06){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x3fe1ed,_0x30cd6a=null){if(_0x3fe1ed===null)return g['EMPTY_NODE'];if(typeof _0x3fe1ed=='object'&&'.priority'in _0x3fe1ed&&(_0x30cd6a=_0x3fe1ed['.priority']),f(_0x30cd6a===null||typeof _0x30cd6a=='string'||typeof _0x30cd6a=='number'||typeof _0x30cd6a=='object'&&'.sv'in _0x30cd6a,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x30cd6a),typeof _0x3fe1ed=='object'&&'.value'in _0x3fe1ed&&_0x3fe1ed['.value']!==null&&(_0x3fe1ed=_0x3fe1ed['.value']),typeof _0x3fe1ed!='object'||'.sv'in _0x3fe1ed){const _0x419106=_0x3fe1ed;return new D(_0x419106,A(_0x30cd6a));}if(!(_0x3fe1ed instanceof Array)&&Gh){const _0x526a1f=[];let _0x2ab385=!0x1;if(x(_0x3fe1ed,(_0x1a0da6,_0x2f0153)=>{if(_0x1a0da6['substring'](0x0,0x1)!=='.'){const _0x4700f9=A(_0x2f0153);_0x4700f9['isEmpty']()||(_0x2ab385=_0x2ab385||!_0x4700f9['getPriority']()['isEmpty'](),_0x526a1f['push'](new E(_0x1a0da6,_0x4700f9)));}}),_0x526a1f['length']===0x0)return g['EMPTY_NODE'];const _0x573653=yn(_0x526a1f,xh,_0x35286d=>_0x35286d['name'],Qi);if(_0x2ab385){const _0x167294=yn(_0x526a1f,R['getCompare']());return new g(_0x573653,A(_0x30cd6a),new te({'.priority':_0x167294},{'.priority':R}));}else return new g(_0x573653,A(_0x30cd6a),te['Default']);}else{let _0x518c84=g['EMPTY_NODE'];return x(_0x3fe1ed,(_0x45465e,_0x3c96ce)=>{if(Q(_0x3fe1ed,_0x45465e)&&_0x45465e['substring'](0x0,0x1)!=='.'){const _0x105a4f=A(_0x3c96ce);(_0x105a4f['isLeafNode']()||!_0x105a4f['isEmpty']())&&(_0x518c84=_0x518c84['updateImmediateChild'](_0x45465e,_0x105a4f));}}),_0x518c84['updatePriority'](A(_0x30cd6a));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x5d1e04){super(),this['indexPath_']=_0x5d1e04,f(!v(_0x5d1e04)&&y(_0x5d1e04)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2badcc){return _0x2badcc['getChild'](this['indexPath_']);}['isDefinedOn'](_0x293c3d){return!_0x293c3d['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x33e990,_0x35e6e4){const _0x5669dc=this['extractChild'](_0x33e990['node']),_0x326eb3=this['extractChild'](_0x35e6e4['node']),_0x4ac805=_0x5669dc['compareTo'](_0x326eb3);return _0x4ac805===0x0?qe(_0x33e990['name'],_0x35e6e4['name']):_0x4ac805;}['makePost'](_0x54ba28,_0x1655d7){const _0x5240d0=A(_0x54ba28),_0x1eaeff=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x5240d0);return new E(_0x1655d7,_0x1eaeff);}['maxPost'](){const _0x4308ac=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4308ac);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x179646,_0x5b1e50){const _0x50b461=_0x179646['node']['compareTo'](_0x5b1e50['node']);return _0x50b461===0x0?qe(_0x179646['name'],_0x5b1e50['name']):_0x50b461;}['isDefinedOn'](_0x308314){return!0x0;}['indexedValueChanged'](_0x13c64e,_0x116d4c){return!_0x13c64e['equals'](_0x116d4c);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4a29ed,_0x5eb089){const _0x36f547=A(_0x4a29ed);return new E(_0x5eb089,_0x36f547);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x4d31df){return{'type':'value','snapshotNode':_0x4d31df};}function rt(_0x1b0ed5,_0x233037){return{'type':'child_added','snapshotNode':_0x233037,'childName':_0x1b0ed5};}function Lt(_0xb3b664,_0x358adc){return{'type':'child_removed','snapshotNode':_0x358adc,'childName':_0xb3b664};}function xt(_0x196beb,_0x412686,_0x9c08db){return{'type':'child_changed','snapshotNode':_0x412686,'childName':_0x196beb,'oldSnap':_0x9c08db};}function zh(_0x4c208d,_0x4f79e1){return{'type':'child_moved','snapshotNode':_0x4f79e1,'childName':_0x4c208d};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x5b4d1b){this['index_']=_0x5b4d1b;}['updateChild'](_0xbe6728,_0x14329f,_0x37d798,_0x7ef84a,_0x2d7454,_0x3fe42d){f(_0xbe6728['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3d3856=_0xbe6728['getImmediateChild'](_0x14329f);return _0x3d3856['getChild'](_0x7ef84a)['equals'](_0x37d798['getChild'](_0x7ef84a))&&_0x3d3856['isEmpty']()===_0x37d798['isEmpty']()||(_0x3fe42d!=null&&(_0x37d798['isEmpty']()?_0xbe6728['hasChild'](_0x14329f)?_0x3fe42d['trackChildChange'](Lt(_0x14329f,_0x3d3856)):f(_0xbe6728['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3d3856['isEmpty']()?_0x3fe42d['trackChildChange'](rt(_0x14329f,_0x37d798)):_0x3fe42d['trackChildChange'](xt(_0x14329f,_0x37d798,_0x3d3856))),_0xbe6728['isLeafNode']()&&_0x37d798['isEmpty']())?_0xbe6728:_0xbe6728['updateImmediateChild'](_0x14329f,_0x37d798)['withIndex'](this['index_']);}['updateFullNode'](_0x507161,_0x540d72,_0xb3fe43){return _0xb3fe43!=null&&(_0x507161['isLeafNode']()||_0x507161['forEachChild'](R,(_0xa3fe53,_0x531f00)=>{_0x540d72['hasChild'](_0xa3fe53)||_0xb3fe43['trackChildChange'](Lt(_0xa3fe53,_0x531f00));}),_0x540d72['isLeafNode']()||_0x540d72['forEachChild'](R,(_0x1ee8e3,_0x5350ff)=>{if(_0x507161['hasChild'](_0x1ee8e3)){const _0x2cc777=_0x507161['getImmediateChild'](_0x1ee8e3);_0x2cc777['equals'](_0x5350ff)||_0xb3fe43['trackChildChange'](xt(_0x1ee8e3,_0x5350ff,_0x2cc777));}else _0xb3fe43['trackChildChange'](rt(_0x1ee8e3,_0x5350ff));})),_0x540d72['withIndex'](this['index_']);}['updatePriority'](_0xb17318,_0x856777){return _0xb17318['isEmpty']()?g['EMPTY_NODE']:_0xb17318['updatePriority'](_0x856777);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x392430){this['indexedFilter_']=new Xi(_0x392430['getIndex']()),this['index_']=_0x392430['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x392430),this['endPost_']=Ft['getEndPost_'](_0x392430),this['startIsInclusive_']=!_0x392430['startAfterSet_'],this['endIsInclusive_']=!_0x392430['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3edc43){const _0x4580ee=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3edc43)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3edc43)<0x0,_0x3a039d=this['endIsInclusive_']?this['index_']['compare'](_0x3edc43,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3edc43,this['getEndPost']())<0x0;return _0x4580ee&&_0x3a039d;}['updateChild'](_0x371c2d,_0x5b691f,_0x5652f3,_0x140952,_0x3bb200,_0x32bccd){return this['matches'](new E(_0x5b691f,_0x5652f3))||(_0x5652f3=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x371c2d,_0x5b691f,_0x5652f3,_0x140952,_0x3bb200,_0x32bccd);}['updateFullNode'](_0x32fa7b,_0x102793,_0xfeb685){_0x102793['isLeafNode']()&&(_0x102793=g['EMPTY_NODE']);let _0x31e00b=_0x102793['withIndex'](this['index_']);_0x31e00b=_0x31e00b['updatePriority'](g['EMPTY_NODE']);const _0x1f76c7=this;return _0x102793['forEachChild'](R,(_0x553ec9,_0x2d6b54)=>{_0x1f76c7['matches'](new E(_0x553ec9,_0x2d6b54))||(_0x31e00b=_0x31e00b['updateImmediateChild'](_0x553ec9,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x32fa7b,_0x31e00b,_0xfeb685);}['updatePriority'](_0x4ef125,_0x92bb7d){return _0x4ef125;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x457db7){if(_0x457db7['hasStart']()){const _0x257272=_0x457db7['getIndexStartName']();return _0x457db7['getIndex']()['makePost'](_0x457db7['getIndexStartValue'](),_0x257272);}else return _0x457db7['getIndex']()['minPost']();}static['getEndPost_'](_0x31855b){if(_0x31855b['hasEnd']()){const _0x5b2d08=_0x31855b['getIndexEndName']();return _0x31855b['getIndex']()['makePost'](_0x31855b['getIndexEndValue'](),_0x5b2d08);}else return _0x31855b['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1b4247){this['withinDirectionalStart']=_0x1c8ce6=>this['reverse_']?this['withinEndPost'](_0x1c8ce6):this['withinStartPost'](_0x1c8ce6),this['withinDirectionalEnd']=_0x2620da=>this['reverse_']?this['withinStartPost'](_0x2620da):this['withinEndPost'](_0x2620da),this['withinStartPost']=_0x20bc18=>{const _0x584cf0=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x20bc18);return this['startIsInclusive_']?_0x584cf0<=0x0:_0x584cf0<0x0;},this['withinEndPost']=_0x1027cd=>{const _0x3196f7=this['index_']['compare'](_0x1027cd,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3196f7<=0x0:_0x3196f7<0x0;},this['rangedFilter_']=new Ft(_0x1b4247),this['index_']=_0x1b4247['getIndex'](),this['limit_']=_0x1b4247['getLimit'](),this['reverse_']=!_0x1b4247['isViewFromLeft'](),this['startIsInclusive_']=!_0x1b4247['startAfterSet_'],this['endIsInclusive_']=!_0x1b4247['endBeforeSet_'];}['updateChild'](_0x1809f5,_0x56424c,_0x430f40,_0x52bc7b,_0x78a1f0,_0x1f2ca3){return this['rangedFilter_']['matches'](new E(_0x56424c,_0x430f40))||(_0x430f40=g['EMPTY_NODE']),_0x1809f5['getImmediateChild'](_0x56424c)['equals'](_0x430f40)?_0x1809f5:_0x1809f5['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1809f5,_0x56424c,_0x430f40,_0x52bc7b,_0x78a1f0,_0x1f2ca3):this['fullLimitUpdateChild_'](_0x1809f5,_0x56424c,_0x430f40,_0x78a1f0,_0x1f2ca3);}['updateFullNode'](_0x48e301,_0xf87525,_0x10dbb7){let _0x3f7a2a;if(_0xf87525['isLeafNode']()||_0xf87525['isEmpty']())_0x3f7a2a=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0xf87525['numChildren']()&&_0xf87525['isIndexed'](this['index_'])){_0x3f7a2a=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4932b7;this['reverse_']?_0x4932b7=_0xf87525['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4932b7=_0xf87525['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x1f3ea9=0x0;for(;_0x4932b7['hasNext']()&&_0x1f3ea9<this['limit_'];){const _0x3deaff=_0x4932b7['getNext']();if(this['withinDirectionalStart'](_0x3deaff)){if(this['withinDirectionalEnd'](_0x3deaff))_0x3f7a2a=_0x3f7a2a['updateImmediateChild'](_0x3deaff['name'],_0x3deaff['node']),_0x1f3ea9++;else break;}else continue;}}else{_0x3f7a2a=_0xf87525['withIndex'](this['index_']),_0x3f7a2a=_0x3f7a2a['updatePriority'](g['EMPTY_NODE']);let _0x2ba456;this['reverse_']?_0x2ba456=_0x3f7a2a['getReverseIterator'](this['index_']):_0x2ba456=_0x3f7a2a['getIterator'](this['index_']);let _0x156836=0x0;for(;_0x2ba456['hasNext']();){const _0x451c35=_0x2ba456['getNext']();_0x156836<this['limit_']&&this['withinDirectionalStart'](_0x451c35)&&this['withinDirectionalEnd'](_0x451c35)?_0x156836++:_0x3f7a2a=_0x3f7a2a['updateImmediateChild'](_0x451c35['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x48e301,_0x3f7a2a,_0x10dbb7);}['updatePriority'](_0x5ce269,_0x4b4e85){return _0x5ce269;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2d6284,_0x15ecbb,_0x1c1852,_0x5ebaf8,_0xe1d1e3){let _0x29530f;if(this['reverse_']){const _0x230a83=this['index_']['getCompare']();_0x29530f=(_0x3e19f0,_0x4ee73b)=>_0x230a83(_0x4ee73b,_0x3e19f0);}else _0x29530f=this['index_']['getCompare']();const _0x18b40d=_0x2d6284;f(_0x18b40d['numChildren']()===this['limit_'],'');const _0x58e974=new E(_0x15ecbb,_0x1c1852),_0x1b5f53=this['reverse_']?_0x18b40d['getFirstChild'](this['index_']):_0x18b40d['getLastChild'](this['index_']),_0x1d77e4=this['rangedFilter_']['matches'](_0x58e974);if(_0x18b40d['hasChild'](_0x15ecbb)){const _0x26b4f2=_0x18b40d['getImmediateChild'](_0x15ecbb);let _0x2a823c=_0x5ebaf8['getChildAfterChild'](this['index_'],_0x1b5f53,this['reverse_']);for(;_0x2a823c!=null&&(_0x2a823c['name']===_0x15ecbb||_0x18b40d['hasChild'](_0x2a823c['name']));)_0x2a823c=_0x5ebaf8['getChildAfterChild'](this['index_'],_0x2a823c,this['reverse_']);const _0xda6f06=_0x2a823c==null?0x1:_0x29530f(_0x2a823c,_0x58e974);if(_0x1d77e4&&!_0x1c1852['isEmpty']()&&_0xda6f06>=0x0)return _0xe1d1e3!=null&&_0xe1d1e3['trackChildChange'](xt(_0x15ecbb,_0x1c1852,_0x26b4f2)),_0x18b40d['updateImmediateChild'](_0x15ecbb,_0x1c1852);{_0xe1d1e3!=null&&_0xe1d1e3['trackChildChange'](Lt(_0x15ecbb,_0x26b4f2));const _0x1f67c8=_0x18b40d['updateImmediateChild'](_0x15ecbb,g['EMPTY_NODE']);return _0x2a823c!=null&&this['rangedFilter_']['matches'](_0x2a823c)?(_0xe1d1e3!=null&&_0xe1d1e3['trackChildChange'](rt(_0x2a823c['name'],_0x2a823c['node'])),_0x1f67c8['updateImmediateChild'](_0x2a823c['name'],_0x2a823c['node'])):_0x1f67c8;}}else return _0x1c1852['isEmpty']()?_0x2d6284:_0x1d77e4&&_0x29530f(_0x1b5f53,_0x58e974)>=0x0?(_0xe1d1e3!=null&&(_0xe1d1e3['trackChildChange'](Lt(_0x1b5f53['name'],_0x1b5f53['node'])),_0xe1d1e3['trackChildChange'](rt(_0x15ecbb,_0x1c1852))),_0x18b40d['updateImmediateChild'](_0x15ecbb,_0x1c1852)['updateImmediateChild'](_0x1b5f53['name'],g['EMPTY_NODE'])):_0x2d6284;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x11e7c5=new Zi();return _0x11e7c5['limitSet_']=this['limitSet_'],_0x11e7c5['limit_']=this['limit_'],_0x11e7c5['startSet_']=this['startSet_'],_0x11e7c5['startAfterSet_']=this['startAfterSet_'],_0x11e7c5['indexStartValue_']=this['indexStartValue_'],_0x11e7c5['startNameSet_']=this['startNameSet_'],_0x11e7c5['indexStartName_']=this['indexStartName_'],_0x11e7c5['endSet_']=this['endSet_'],_0x11e7c5['endBeforeSet_']=this['endBeforeSet_'],_0x11e7c5['indexEndValue_']=this['indexEndValue_'],_0x11e7c5['endNameSet_']=this['endNameSet_'],_0x11e7c5['indexEndName_']=this['indexEndName_'],_0x11e7c5['index_']=this['index_'],_0x11e7c5['viewFrom_']=this['viewFrom_'],_0x11e7c5;}}function Kh(_0x15fc62){return _0x15fc62['loadsAllData']()?new Xi(_0x15fc62['getIndex']()):_0x15fc62['hasLimit']()?new jh(_0x15fc62):new Ft(_0x15fc62);}function Yh(_0x42ba54,_0x4a674b){const _0x1dbff1=_0x42ba54['copy']();return _0x1dbff1['limitSet_']=!0x0,_0x1dbff1['limit_']=_0x4a674b,_0x1dbff1['viewFrom_']='l',_0x1dbff1;}function Qh(_0x5970db,_0x1d5e70,_0x5e68fd){const _0x2687b9=_0x5970db['copy']();return _0x2687b9['startSet_']=!0x0,_0x1d5e70===void 0x0&&(_0x1d5e70=null),_0x2687b9['indexStartValue_']=_0x1d5e70,_0x5e68fd!=null?(_0x2687b9['startNameSet_']=!0x0,_0x2687b9['indexStartName_']=_0x5e68fd):(_0x2687b9['startNameSet_']=!0x1,_0x2687b9['indexStartName_']=''),_0x2687b9;}function Jh(_0x2dba2c,_0x1d4ad6,_0x1753a8){const _0x2a92c=_0x2dba2c['copy']();return _0x2a92c['endSet_']=!0x0,_0x1d4ad6===void 0x0&&(_0x1d4ad6=null),_0x2a92c['indexEndValue_']=_0x1d4ad6,_0x1753a8!==void 0x0?(_0x2a92c['endNameSet_']=!0x0,_0x2a92c['indexEndName_']=_0x1753a8):(_0x2a92c['endNameSet_']=!0x1,_0x2a92c['indexEndName_']=''),_0x2a92c;}function xo(_0x2ce325,_0xa4fe72){const _0x5a4a5c=_0x2ce325['copy']();return _0x5a4a5c['index_']=_0xa4fe72,_0x5a4a5c;}function ir(_0x128ec6){const _0x417de9={};if(_0x128ec6['isDefault']())return _0x417de9;let _0x1896b5;if(_0x128ec6['index_']===R?_0x1896b5='$priority':_0x128ec6['index_']===Mo?_0x1896b5='$value':_0x128ec6['index_']===ve?_0x1896b5='$key':(f(_0x128ec6['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x1896b5=_0x128ec6['index_']['toString']()),_0x417de9['orderBy']=O(_0x1896b5),_0x128ec6['startSet_']){const _0x2b185a=_0x128ec6['startAfterSet_']?'startAfter':'startAt';_0x417de9[_0x2b185a]=O(_0x128ec6['indexStartValue_']),_0x128ec6['startNameSet_']&&(_0x417de9[_0x2b185a]+=','+O(_0x128ec6['indexStartName_']));}if(_0x128ec6['endSet_']){const _0x4d698f=_0x128ec6['endBeforeSet_']?'endBefore':'endAt';_0x417de9[_0x4d698f]=O(_0x128ec6['indexEndValue_']),_0x128ec6['endNameSet_']&&(_0x417de9[_0x4d698f]+=','+O(_0x128ec6['indexEndName_']));}return _0x128ec6['limitSet_']&&(_0x128ec6['isViewFromLeft']()?_0x417de9['limitToFirst']=_0x128ec6['limit_']:_0x417de9['limitToLast']=_0x128ec6['limit_']),_0x417de9;}function sr(_0x25ccdc){const _0x405199={};if(_0x25ccdc['startSet_']&&(_0x405199['sp']=_0x25ccdc['indexStartValue_'],_0x25ccdc['startNameSet_']&&(_0x405199['sn']=_0x25ccdc['indexStartName_']),_0x405199['sin']=!_0x25ccdc['startAfterSet_']),_0x25ccdc['endSet_']&&(_0x405199['ep']=_0x25ccdc['indexEndValue_'],_0x25ccdc['endNameSet_']&&(_0x405199['en']=_0x25ccdc['indexEndName_']),_0x405199['ein']=!_0x25ccdc['endBeforeSet_']),_0x25ccdc['limitSet_']){_0x405199['l']=_0x25ccdc['limit_'];let _0x50347b=_0x25ccdc['viewFrom_'];_0x50347b===''&&(_0x25ccdc['isViewFromLeft']()?_0x50347b='l':_0x50347b='r'),_0x405199['vf']=_0x50347b;}return _0x25ccdc['index_']!==R&&(_0x405199['i']=_0x25ccdc['index_']['toString']()),_0x405199;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x3e90e5){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3c0803,_0x5e60ed){return _0x5e60ed!==void 0x0?'tag$'+_0x5e60ed:(f(_0x3c0803['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3c0803['_path']['toString']());}constructor(_0x30dbd3,_0x233313,_0x5f4813,_0x173c71){super(),this['repoInfo_']=_0x30dbd3,this['onDataUpdate_']=_0x233313,this['authTokenProvider_']=_0x5f4813,this['appCheckTokenProvider_']=_0x173c71,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x1231f3,_0x34a0de,_0x41b2d0,_0x578c7c){const _0x33e2d7=_0x1231f3['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x33e2d7+'\x20'+_0x1231f3['_queryIdentifier']);const _0x4b5588=vn['getListenId_'](_0x1231f3,_0x41b2d0),_0x3834c7={};this['listens_'][_0x4b5588]=_0x3834c7;const _0x839309=ir(_0x1231f3['_queryParams']);this['restRequest_'](_0x33e2d7+'.json',_0x839309,(_0x4367fa,_0x1b0dc0)=>{let _0x1904b3=_0x1b0dc0;if(_0x4367fa===0x194&&(_0x1904b3=null,_0x4367fa=null),_0x4367fa===null&&this['onDataUpdate_'](_0x33e2d7,_0x1904b3,!0x1,_0x41b2d0),Le(this['listens_'],_0x4b5588)===_0x3834c7){let _0x31a56e;_0x4367fa?_0x4367fa===0x191?_0x31a56e='permission_denied':_0x31a56e='rest_error:'+_0x4367fa:_0x31a56e='ok',_0x578c7c(_0x31a56e,null);}});}['unlisten'](_0x2361dc,_0x175451){const _0x34c56b=vn['getListenId_'](_0x2361dc,_0x175451);delete this['listens_'][_0x34c56b];}['get'](_0x43a97f){const _0x31d747=ir(_0x43a97f['_queryParams']),_0x39904c=_0x43a97f['_path']['toString'](),_0x598ead=new H();return this['restRequest_'](_0x39904c+'.json',_0x31d747,(_0x1f550b,_0x39723d)=>{let _0x40ea1d=_0x39723d;_0x1f550b===0x194&&(_0x40ea1d=null,_0x1f550b=null),_0x1f550b===null?(this['onDataUpdate_'](_0x39904c,_0x40ea1d,!0x1,null),_0x598ead['resolve'](_0x40ea1d)):_0x598ead['reject'](new Error(_0x40ea1d));}),_0x598ead['promise'];}['refreshAuthToken'](_0x230686){}['restRequest_'](_0x3c5bb8,_0x220cf9={},_0x5065bb){return _0x220cf9['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x521b46,_0x42d353])=>{_0x521b46&&_0x521b46['accessToken']&&(_0x220cf9['auth']=_0x521b46['accessToken']),_0x42d353&&_0x42d353['token']&&(_0x220cf9['ac']=_0x42d353['token']);const _0x27aff7=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3c5bb8+'?ns='+this['repoInfo_']['namespace']+ut(_0x220cf9);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x27aff7);const _0x4e9082=new XMLHttpRequest();_0x4e9082['onreadystatechange']=()=>{if(_0x5065bb&&_0x4e9082['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x27aff7+'\x20received.\x20status:',_0x4e9082['status'],'response:',_0x4e9082['responseText']);let _0xa37fd3=null;if(_0x4e9082['status']>=0xc8&&_0x4e9082['status']<0x12c){try{_0xa37fd3=Nt(_0x4e9082['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x27aff7+':\x20'+_0x4e9082['responseText']);}_0x5065bb(null,_0xa37fd3);}else _0x4e9082['status']!==0x191&&_0x4e9082['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x27aff7+'\x20Status:\x20'+_0x4e9082['status']),_0x5065bb(_0x4e9082['status']);_0x5065bb=null;}},_0x4e9082['open']('GET',_0x27aff7,!0x0),_0x4e9082['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5217b2){return this['rootNode_']['getChild'](_0x5217b2);}['updateSnapshot'](_0x1c25a4,_0x459520){this['rootNode_']=this['rootNode_']['updateChild'](_0x1c25a4,_0x459520);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x5bb3ce,_0x33ca3e,_0x5e2f6c){if(v(_0x33ca3e))_0x5bb3ce['value']=_0x5e2f6c,_0x5bb3ce['children']['clear']();else{if(_0x5bb3ce['value']!==null)_0x5bb3ce['value']=_0x5bb3ce['value']['updateChild'](_0x33ca3e,_0x5e2f6c);else{const _0x566936=y(_0x33ca3e);_0x5bb3ce['children']['has'](_0x566936)||_0x5bb3ce['children']['set'](_0x566936,En());const _0x574f55=_0x5bb3ce['children']['get'](_0x566936);_0x33ca3e=S(_0x33ca3e),pt(_0x574f55,_0x33ca3e,_0x5e2f6c);}}}function Ti(_0xb9b9c0,_0x43e5f7){if(v(_0x43e5f7))return _0xb9b9c0['value']=null,_0xb9b9c0['children']['clear'](),!0x0;if(_0xb9b9c0['value']!==null){if(_0xb9b9c0['value']['isLeafNode']())return!0x1;{const _0xc5f2cf=_0xb9b9c0['value'];return _0xb9b9c0['value']=null,_0xc5f2cf['forEachChild'](R,(_0x2c0903,_0x3c72bc)=>{pt(_0xb9b9c0,new C(_0x2c0903),_0x3c72bc);}),Ti(_0xb9b9c0,_0x43e5f7);}}else{if(_0xb9b9c0['children']['size']>0x0){const _0x436470=y(_0x43e5f7);return _0x43e5f7=S(_0x43e5f7),_0xb9b9c0['children']['has'](_0x436470)&&Ti(_0xb9b9c0['children']['get'](_0x436470),_0x43e5f7)&&_0xb9b9c0['children']['delete'](_0x436470),_0xb9b9c0['children']['size']===0x0;}else return!0x0;}}function Si(_0x3331dd,_0x47d0aa,_0x2ab185){_0x3331dd['value']!==null?_0x2ab185(_0x47d0aa,_0x3331dd['value']):Zh(_0x3331dd,(_0x3fe37f,_0x50a073)=>{const _0x3c57b0=new C(_0x47d0aa['toString']()+'/'+_0x3fe37f);Si(_0x50a073,_0x3c57b0,_0x2ab185);});}function Zh(_0xaafc0f,_0x144835){_0xaafc0f['children']['forEach']((_0x5569cf,_0x3c538b)=>{_0x144835(_0x3c538b,_0x5569cf);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x36266e){this['collection_']=_0x36266e,this['last_']=null;}['get'](){const _0x55d1d3=this['collection_']['get'](),_0x10d83c={..._0x55d1d3};return this['last_']&&x(this['last_'],(_0x498807,_0x51b0c7)=>{_0x10d83c[_0x498807]=_0x10d83c[_0x498807]-_0x51b0c7;}),this['last_']=_0x55d1d3,_0x10d83c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x39d88a,_0x154e32){this['server_']=_0x154e32,this['statsToReport_']={},this['statsListener_']=new eu(_0x39d88a);const _0x1a9fdc=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x1a9fdc));}['reportStats_'](){const _0x4bbcb7=this['statsListener_']['get'](),_0x54b7ac={};let _0x5324d3=!0x1;x(_0x4bbcb7,(_0x56634d,_0x439683)=>{_0x439683>0x0&&Q(this['statsToReport_'],_0x56634d)&&(_0x54b7ac[_0x56634d]=_0x439683,_0x5324d3=!0x0);}),_0x5324d3&&this['server_']['reportStats'](_0x54b7ac),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0xdfca26){_0xdfca26[_0xdfca26['OVERWRITE']=0x0]='OVERWRITE',_0xdfca26[_0xdfca26['MERGE']=0x1]='MERGE',_0xdfca26[_0xdfca26['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xdfca26[_0xdfca26['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x16dcc9){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x16dcc9,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x68d02a,_0x2001f8,_0x2ae4ff){this['path']=_0x68d02a,this['affectedTree']=_0x2001f8,this['revert']=_0x2ae4ff,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0xdc2d3){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4e3a68=this['affectedTree']['subtree'](new C(_0xdc2d3));return new In(w(),_0x4e3a68,this['revert']);}}else return f(y(this['path'])===_0xdc2d3,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0xabdc53,_0x4b75bc){this['source']=_0xabdc53,this['path']=_0x4b75bc,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x49e610){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x54e417,_0x38a2dc,_0x384dfb){this['source']=_0x54e417,this['path']=_0x38a2dc,this['snap']=_0x384dfb,this['type']=z['OVERWRITE'];}['operationForChild'](_0x1d0fea){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x1d0fea)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x29a72a,_0x478cfa,_0x328925){this['source']=_0x29a72a,this['path']=_0x478cfa,this['children']=_0x328925,this['type']=z['MERGE'];}['operationForChild'](_0x316244){if(v(this['path'])){const _0x2c95a4=this['children']['subtree'](new C(_0x316244));return _0x2c95a4['isEmpty']()?null:_0x2c95a4['value']?new Be(this['source'],w(),_0x2c95a4['value']):new ot(this['source'],w(),_0x2c95a4);}else return f(y(this['path'])===_0x316244,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x4b7d62,_0x473d95,_0x246685){this['node_']=_0x4b7d62,this['fullyInitialized_']=_0x473d95,this['filtered_']=_0x246685;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x397d8d){if(v(_0x397d8d))return this['isFullyInitialized']()&&!this['filtered_'];const _0x2501c3=y(_0x397d8d);return this['isCompleteForChild'](_0x2501c3);}['isCompleteForChild'](_0x23327b){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x23327b);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x2c6d6f){this['query_']=_0x2c6d6f,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x45af13,_0x204c72,_0x446260,_0xd3b661){const _0xa1a407=[],_0x2efc23=[];return _0x204c72['forEach'](_0x465296=>{_0x465296['type']==='child_changed'&&_0x45af13['index_']['indexedValueChanged'](_0x465296['oldSnap'],_0x465296['snapshotNode'])&&_0x2efc23['push'](zh(_0x465296['childName'],_0x465296['snapshotNode']));}),wt(_0x45af13,_0xa1a407,'child_removed',_0x204c72,_0xd3b661,_0x446260),wt(_0x45af13,_0xa1a407,'child_added',_0x204c72,_0xd3b661,_0x446260),wt(_0x45af13,_0xa1a407,'child_moved',_0x2efc23,_0xd3b661,_0x446260),wt(_0x45af13,_0xa1a407,'child_changed',_0x204c72,_0xd3b661,_0x446260),wt(_0x45af13,_0xa1a407,'value',_0x204c72,_0xd3b661,_0x446260),_0xa1a407;}function wt(_0x15eb42,_0x3b3b7c,_0x1f15c0,_0x470958,_0x261973,_0x496dc3){const _0x5b43a1=_0x470958['filter'](_0x2b5e4e=>_0x2b5e4e['type']===_0x1f15c0);_0x5b43a1['sort']((_0x4b4d98,_0x53de04)=>au(_0x15eb42,_0x4b4d98,_0x53de04)),_0x5b43a1['forEach'](_0x49fa2b=>{const _0x3b608e=ou(_0x15eb42,_0x49fa2b,_0x496dc3);_0x261973['forEach'](_0x5bf220=>{_0x5bf220['respondsTo'](_0x49fa2b['type'])&&_0x3b3b7c['push'](_0x5bf220['createEvent'](_0x3b608e,_0x15eb42['query_']));});});}function ou(_0xc1a729,_0x439bc2,_0x5b340f){return _0x439bc2['type']==='value'||_0x439bc2['type']==='child_removed'||(_0x439bc2['prevName']=_0x5b340f['getPredecessorChildName'](_0x439bc2['childName'],_0x439bc2['snapshotNode'],_0xc1a729['index_'])),_0x439bc2;}function au(_0x18d10c,_0x3547b7,_0x152d47){if(_0x3547b7['childName']==null||_0x152d47['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1d9a27=new E(_0x3547b7['childName'],_0x3547b7['snapshotNode']),_0x586a45=new E(_0x152d47['childName'],_0x152d47['snapshotNode']);return _0x18d10c['index_']['compare'](_0x1d9a27,_0x586a45);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x10abd0,_0x27836f){return{'eventCache':_0x10abd0,'serverCache':_0x27836f};}function Rt(_0x4f9f16,_0x41e61d,_0x1716df,_0x351368){return Un(new Te(_0x41e61d,_0x1716df,_0x351368),_0x4f9f16['serverCache']);}function Fo(_0x55ff68,_0x178c39,_0x20e7ef,_0xff34c4){return Un(_0x55ff68['eventCache'],new Te(_0x178c39,_0x20e7ef,_0xff34c4));}function wn(_0x4afa34){return _0x4afa34['eventCache']['isFullyInitialized']()?_0x4afa34['eventCache']['getNode']():null;}function Ve(_0x26a785){return _0x26a785['serverCache']['isFullyInitialized']()?_0x26a785['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x55092c){let _0x4dc04d=new b(null);return x(_0x55092c,(_0x1331ab,_0x44a87b)=>{_0x4dc04d=_0x4dc04d['set'](new C(_0x1331ab),_0x44a87b);}),_0x4dc04d;}constructor(_0x5dca8c,_0x2d69c5=cu()){this['value']=_0x5dca8c,this['children']=_0x2d69c5;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2ea770,_0x11e0ae){if(this['value']!=null&&_0x11e0ae(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2ea770))return null;{const _0xbdcadf=y(_0x2ea770),_0x39382c=this['children']['get'](_0xbdcadf);if(_0x39382c!==null){const _0x3eb001=_0x39382c['findRootMostMatchingPathAndValue'](S(_0x2ea770),_0x11e0ae);return _0x3eb001!=null?{'path':k(new C(_0xbdcadf),_0x3eb001['path']),'value':_0x3eb001['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x134591){return this['findRootMostMatchingPathAndValue'](_0x134591,()=>!0x0);}['subtree'](_0x472d71){if(v(_0x472d71))return this;{const _0x1492b1=y(_0x472d71),_0x419490=this['children']['get'](_0x1492b1);return _0x419490!==null?_0x419490['subtree'](S(_0x472d71)):new b(null);}}['set'](_0x9e975f,_0x25602f){if(v(_0x9e975f))return new b(_0x25602f,this['children']);{const _0x1b53e1=y(_0x9e975f),_0x30dbd9=(this['children']['get'](_0x1b53e1)||new b(null))['set'](S(_0x9e975f),_0x25602f),_0x70cc0c=this['children']['insert'](_0x1b53e1,_0x30dbd9);return new b(this['value'],_0x70cc0c);}}['remove'](_0x5b1808){if(v(_0x5b1808))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x1b43f2=y(_0x5b1808),_0x436793=this['children']['get'](_0x1b43f2);if(_0x436793){const _0x1d1000=_0x436793['remove'](S(_0x5b1808));let _0x48ac0b;return _0x1d1000['isEmpty']()?_0x48ac0b=this['children']['remove'](_0x1b43f2):_0x48ac0b=this['children']['insert'](_0x1b43f2,_0x1d1000),this['value']===null&&_0x48ac0b['isEmpty']()?new b(null):new b(this['value'],_0x48ac0b);}else return this;}}['get'](_0x406658){if(v(_0x406658))return this['value'];{const _0x2996b2=y(_0x406658),_0x1d9a17=this['children']['get'](_0x2996b2);return _0x1d9a17?_0x1d9a17['get'](S(_0x406658)):null;}}['setTree'](_0x463d17,_0x66303d){if(v(_0x463d17))return _0x66303d;{const _0xbf1994=y(_0x463d17),_0x14fa43=(this['children']['get'](_0xbf1994)||new b(null))['setTree'](S(_0x463d17),_0x66303d);let _0x300c6a;return _0x14fa43['isEmpty']()?_0x300c6a=this['children']['remove'](_0xbf1994):_0x300c6a=this['children']['insert'](_0xbf1994,_0x14fa43),new b(this['value'],_0x300c6a);}}['fold'](_0x3a8f51){return this['fold_'](w(),_0x3a8f51);}['fold_'](_0x2f5391,_0x4f86db){const _0x327cac={};return this['children']['inorderTraversal']((_0x45a426,_0x2c0add)=>{_0x327cac[_0x45a426]=_0x2c0add['fold_'](k(_0x2f5391,_0x45a426),_0x4f86db);}),_0x4f86db(_0x2f5391,this['value'],_0x327cac);}['findOnPath'](_0x3fa5d0,_0x46496d){return this['findOnPath_'](_0x3fa5d0,w(),_0x46496d);}['findOnPath_'](_0xc2b3d0,_0x5c0f58,_0x1acbd7){const _0x514c01=this['value']?_0x1acbd7(_0x5c0f58,this['value']):!0x1;if(_0x514c01)return _0x514c01;if(v(_0xc2b3d0))return null;{const _0x3603ab=y(_0xc2b3d0),_0x4715e3=this['children']['get'](_0x3603ab);return _0x4715e3?_0x4715e3['findOnPath_'](S(_0xc2b3d0),k(_0x5c0f58,_0x3603ab),_0x1acbd7):null;}}['foreachOnPath'](_0x5e0e84,_0x53fe41){return this['foreachOnPath_'](_0x5e0e84,w(),_0x53fe41);}['foreachOnPath_'](_0x48b81c,_0xb35d10,_0x34ed4b){if(v(_0x48b81c))return this;{this['value']&&_0x34ed4b(_0xb35d10,this['value']);const _0x341150=y(_0x48b81c),_0x27b640=this['children']['get'](_0x341150);return _0x27b640?_0x27b640['foreachOnPath_'](S(_0x48b81c),k(_0xb35d10,_0x341150),_0x34ed4b):new b(null);}}['foreach'](_0x3248f7){this['foreach_'](w(),_0x3248f7);}['foreach_'](_0x4bdabc,_0x66423c){this['children']['inorderTraversal']((_0x2af237,_0x197fb3)=>{_0x197fb3['foreach_'](k(_0x4bdabc,_0x2af237),_0x66423c);}),this['value']&&_0x66423c(_0x4bdabc,this['value']);}['foreachChild'](_0x340821){this['children']['inorderTraversal']((_0x22f820,_0x235fd7)=>{_0x235fd7['value']&&_0x340821(_0x22f820,_0x235fd7['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x29a8e7){this['writeTree_']=_0x29a8e7;}static['empty'](){return new K(new b(null));}}function At(_0x105f72,_0x557841,_0x29d718){if(v(_0x557841))return new K(new b(_0x29d718));{const _0x128408=_0x105f72['writeTree_']['findRootMostValueAndPath'](_0x557841);if(_0x128408!=null){const _0x3140b0=_0x128408['path'];let _0x412fd1=_0x128408['value'];const _0x3798e5=F(_0x3140b0,_0x557841);return _0x412fd1=_0x412fd1['updateChild'](_0x3798e5,_0x29d718),new K(_0x105f72['writeTree_']['set'](_0x3140b0,_0x412fd1));}else{const _0x1114b1=new b(_0x29d718),_0x8cb68=_0x105f72['writeTree_']['setTree'](_0x557841,_0x1114b1);return new K(_0x8cb68);}}}function bi(_0x35aa06,_0x15df6e,_0x1c2c6e){let _0x4bd1ce=_0x35aa06;return x(_0x1c2c6e,(_0x5a61c9,_0x1932a1)=>{_0x4bd1ce=At(_0x4bd1ce,k(_0x15df6e,_0x5a61c9),_0x1932a1);}),_0x4bd1ce;}function or(_0x2d2922,_0x478916){if(v(_0x478916))return K['empty']();{const _0x43c5e7=_0x2d2922['writeTree_']['setTree'](_0x478916,new b(null));return new K(_0x43c5e7);}}function Ri(_0x1ad0c3,_0x2c2364){return ze(_0x1ad0c3,_0x2c2364)!=null;}function ze(_0x17095c,_0x34bebd){const _0xc240d8=_0x17095c['writeTree_']['findRootMostValueAndPath'](_0x34bebd);return _0xc240d8!=null?_0x17095c['writeTree_']['get'](_0xc240d8['path'])['getChild'](F(_0xc240d8['path'],_0x34bebd)):null;}function ar(_0xfbc789){const _0x3df8b0=[],_0x3c180b=_0xfbc789['writeTree_']['value'];return _0x3c180b!=null?_0x3c180b['isLeafNode']()||_0x3c180b['forEachChild'](R,(_0x4f9b30,_0x435dfd)=>{_0x3df8b0['push'](new E(_0x4f9b30,_0x435dfd));}):_0xfbc789['writeTree_']['children']['inorderTraversal']((_0x3c9c26,_0xc1b9e5)=>{_0xc1b9e5['value']!=null&&_0x3df8b0['push'](new E(_0x3c9c26,_0xc1b9e5['value']));}),_0x3df8b0;}function Ee(_0x16c8fb,_0x5c6f10){if(v(_0x5c6f10))return _0x16c8fb;{const _0x2e72d4=ze(_0x16c8fb,_0x5c6f10);return _0x2e72d4!=null?new K(new b(_0x2e72d4)):new K(_0x16c8fb['writeTree_']['subtree'](_0x5c6f10));}}function Ai(_0x1645f3){return _0x1645f3['writeTree_']['isEmpty']();}function at(_0x374ca9,_0x16ab76){return Uo(w(),_0x374ca9['writeTree_'],_0x16ab76);}function Uo(_0xe9a5be,_0x5c19ad,_0x1bab8a){if(_0x5c19ad['value']!=null)return _0x1bab8a['updateChild'](_0xe9a5be,_0x5c19ad['value']);{let _0x237a5f=null;return _0x5c19ad['children']['inorderTraversal']((_0x418f4e,_0x41a4a6)=>{_0x418f4e==='.priority'?(f(_0x41a4a6['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x237a5f=_0x41a4a6['value']):_0x1bab8a=Uo(k(_0xe9a5be,_0x418f4e),_0x41a4a6,_0x1bab8a);}),!_0x1bab8a['getChild'](_0xe9a5be)['isEmpty']()&&_0x237a5f!==null&&(_0x1bab8a=_0x1bab8a['updateChild'](k(_0xe9a5be,'.priority'),_0x237a5f)),_0x1bab8a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0xc53719,_0x5d8c37){return Ho(_0x5d8c37,_0xc53719);}function lu(_0x440996,_0x15d894,_0x3d577e,_0xe0705,_0x564746){f(_0xe0705>_0x440996['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x564746===void 0x0&&(_0x564746=!0x0),_0x440996['allWrites']['push']({'path':_0x15d894,'snap':_0x3d577e,'writeId':_0xe0705,'visible':_0x564746}),_0x564746&&(_0x440996['visibleWrites']=At(_0x440996['visibleWrites'],_0x15d894,_0x3d577e)),_0x440996['lastWriteId']=_0xe0705;}function hu(_0x2905bb,_0x4e8e06,_0x30c274,_0x3f16c5){f(_0x3f16c5>_0x2905bb['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x2905bb['allWrites']['push']({'path':_0x4e8e06,'children':_0x30c274,'writeId':_0x3f16c5,'visible':!0x0}),_0x2905bb['visibleWrites']=bi(_0x2905bb['visibleWrites'],_0x4e8e06,_0x30c274),_0x2905bb['lastWriteId']=_0x3f16c5;}function uu(_0x11260a,_0x553a09){for(let _0x790f9c=0x0;_0x790f9c<_0x11260a['allWrites']['length'];_0x790f9c++){const _0x5a7c7d=_0x11260a['allWrites'][_0x790f9c];if(_0x5a7c7d['writeId']===_0x553a09)return _0x5a7c7d;}return null;}function du(_0x4d9c73,_0x251cba){const _0x59aa9e=_0x4d9c73['allWrites']['findIndex'](_0x3b2369=>_0x3b2369['writeId']===_0x251cba);f(_0x59aa9e>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x41fb06=_0x4d9c73['allWrites'][_0x59aa9e];_0x4d9c73['allWrites']['splice'](_0x59aa9e,0x1);let _0x45d32e=_0x41fb06['visible'],_0x28ff9d=!0x1,_0x26d343=_0x4d9c73['allWrites']['length']-0x1;for(;_0x45d32e&&_0x26d343>=0x0;){const _0x4f13b5=_0x4d9c73['allWrites'][_0x26d343];_0x4f13b5['visible']&&(_0x26d343>=_0x59aa9e&&fu(_0x4f13b5,_0x41fb06['path'])?_0x45d32e=!0x1:G(_0x41fb06['path'],_0x4f13b5['path'])&&(_0x28ff9d=!0x0)),_0x26d343--;}if(_0x45d32e){if(_0x28ff9d)return pu(_0x4d9c73),!0x0;if(_0x41fb06['snap'])_0x4d9c73['visibleWrites']=or(_0x4d9c73['visibleWrites'],_0x41fb06['path']);else{const _0x198209=_0x41fb06['children'];x(_0x198209,_0x7601a4=>{_0x4d9c73['visibleWrites']=or(_0x4d9c73['visibleWrites'],k(_0x41fb06['path'],_0x7601a4));});}return!0x0;}else return!0x1;}function fu(_0x52d00d,_0x2693db){if(_0x52d00d['snap'])return G(_0x52d00d['path'],_0x2693db);for(const _0x204f22 in _0x52d00d['children'])if(_0x52d00d['children']['hasOwnProperty'](_0x204f22)&&G(k(_0x52d00d['path'],_0x204f22),_0x2693db))return!0x0;return!0x1;}function pu(_0x14c670){_0x14c670['visibleWrites']=Wo(_0x14c670['allWrites'],_u,w()),_0x14c670['allWrites']['length']>0x0?_0x14c670['lastWriteId']=_0x14c670['allWrites'][_0x14c670['allWrites']['length']-0x1]['writeId']:_0x14c670['lastWriteId']=-0x1;}function _u(_0x5054c9){return _0x5054c9['visible'];}function Wo(_0x2dc0f2,_0xf8eae5,_0x15919c){let _0x41bd4b=K['empty']();for(let _0x49a947=0x0;_0x49a947<_0x2dc0f2['length'];++_0x49a947){const _0x4d3637=_0x2dc0f2[_0x49a947];if(_0xf8eae5(_0x4d3637)){const _0x319bce=_0x4d3637['path'];let _0x26f8b7;if(_0x4d3637['snap'])G(_0x15919c,_0x319bce)?(_0x26f8b7=F(_0x15919c,_0x319bce),_0x41bd4b=At(_0x41bd4b,_0x26f8b7,_0x4d3637['snap'])):G(_0x319bce,_0x15919c)&&(_0x26f8b7=F(_0x319bce,_0x15919c),_0x41bd4b=At(_0x41bd4b,w(),_0x4d3637['snap']['getChild'](_0x26f8b7)));else{if(_0x4d3637['children']){if(G(_0x15919c,_0x319bce))_0x26f8b7=F(_0x15919c,_0x319bce),_0x41bd4b=bi(_0x41bd4b,_0x26f8b7,_0x4d3637['children']);else{if(G(_0x319bce,_0x15919c)){if(_0x26f8b7=F(_0x319bce,_0x15919c),v(_0x26f8b7))_0x41bd4b=bi(_0x41bd4b,w(),_0x4d3637['children']);else{const _0x1be30f=Le(_0x4d3637['children'],y(_0x26f8b7));if(_0x1be30f){const _0x3e7915=_0x1be30f['getChild'](S(_0x26f8b7));_0x41bd4b=At(_0x41bd4b,w(),_0x3e7915);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x41bd4b;}function Bo(_0x432974,_0x2f551b,_0x3889db,_0x3e2f46,_0x78e133){if(!_0x3e2f46&&!_0x78e133){const _0x1df89e=ze(_0x432974['visibleWrites'],_0x2f551b);if(_0x1df89e!=null)return _0x1df89e;{const _0x390218=Ee(_0x432974['visibleWrites'],_0x2f551b);if(Ai(_0x390218))return _0x3889db;if(_0x3889db==null&&!Ri(_0x390218,w()))return null;{const _0x210c01=_0x3889db||g['EMPTY_NODE'];return at(_0x390218,_0x210c01);}}}else{const _0x346866=Ee(_0x432974['visibleWrites'],_0x2f551b);if(!_0x78e133&&Ai(_0x346866))return _0x3889db;if(!_0x78e133&&_0x3889db==null&&!Ri(_0x346866,w()))return null;{const _0x386f10=function(_0x5dc769){return(_0x5dc769['visible']||_0x78e133)&&(!_0x3e2f46||!~_0x3e2f46['indexOf'](_0x5dc769['writeId']))&&(G(_0x5dc769['path'],_0x2f551b)||G(_0x2f551b,_0x5dc769['path']));},_0x3c8e0b=Wo(_0x432974['allWrites'],_0x386f10,_0x2f551b),_0x3c3550=_0x3889db||g['EMPTY_NODE'];return at(_0x3c8e0b,_0x3c3550);}}}function gu(_0x399b73,_0x2d155e,_0x428284){let _0x4c7669=g['EMPTY_NODE'];const _0x3826f0=ze(_0x399b73['visibleWrites'],_0x2d155e);if(_0x3826f0)return _0x3826f0['isLeafNode']()||_0x3826f0['forEachChild'](R,(_0x21d1cc,_0x527737)=>{_0x4c7669=_0x4c7669['updateImmediateChild'](_0x21d1cc,_0x527737);}),_0x4c7669;if(_0x428284){const _0x2acc25=Ee(_0x399b73['visibleWrites'],_0x2d155e);return _0x428284['forEachChild'](R,(_0x18d488,_0x1182b0)=>{const _0x3941dc=at(Ee(_0x2acc25,new C(_0x18d488)),_0x1182b0);_0x4c7669=_0x4c7669['updateImmediateChild'](_0x18d488,_0x3941dc);}),ar(_0x2acc25)['forEach'](_0x4189d5=>{_0x4c7669=_0x4c7669['updateImmediateChild'](_0x4189d5['name'],_0x4189d5['node']);}),_0x4c7669;}else{const _0xec2565=Ee(_0x399b73['visibleWrites'],_0x2d155e);return ar(_0xec2565)['forEach'](_0x57425d=>{_0x4c7669=_0x4c7669['updateImmediateChild'](_0x57425d['name'],_0x57425d['node']);}),_0x4c7669;}}function mu(_0x189c97,_0x1a6770,_0x1944d4,_0x578b8b,_0x3aed0c){f(_0x578b8b||_0x3aed0c,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x349dc4=k(_0x1a6770,_0x1944d4);if(Ri(_0x189c97['visibleWrites'],_0x349dc4))return null;{const _0x447110=Ee(_0x189c97['visibleWrites'],_0x349dc4);return Ai(_0x447110)?_0x3aed0c['getChild'](_0x1944d4):at(_0x447110,_0x3aed0c['getChild'](_0x1944d4));}}function yu(_0x35be86,_0x2f4b92,_0x46b59f,_0x437820){const _0x35aad0=k(_0x2f4b92,_0x46b59f),_0x265bc0=ze(_0x35be86['visibleWrites'],_0x35aad0);if(_0x265bc0!=null)return _0x265bc0;if(_0x437820['isCompleteForChild'](_0x46b59f)){const _0x3ecbf4=Ee(_0x35be86['visibleWrites'],_0x35aad0);return at(_0x3ecbf4,_0x437820['getNode']()['getImmediateChild'](_0x46b59f));}else return null;}function vu(_0x4a0c32,_0x331bf7){return ze(_0x4a0c32['visibleWrites'],_0x331bf7);}function Eu(_0x35e762,_0x5d8378,_0x97f4e2,_0x2bec60,_0x2c9cf1,_0x11054f,_0x3cdc2d){let _0x5ea633;const _0x1078a1=Ee(_0x35e762['visibleWrites'],_0x5d8378),_0x3096fc=ze(_0x1078a1,w());if(_0x3096fc!=null)_0x5ea633=_0x3096fc;else{if(_0x97f4e2!=null)_0x5ea633=at(_0x1078a1,_0x97f4e2);else return[];}if(_0x5ea633=_0x5ea633['withIndex'](_0x3cdc2d),!_0x5ea633['isEmpty']()&&!_0x5ea633['isLeafNode']()){const _0xaaa058=[],_0x12655f=_0x3cdc2d['getCompare'](),_0x5ab7a4=_0x11054f?_0x5ea633['getReverseIteratorFrom'](_0x2bec60,_0x3cdc2d):_0x5ea633['getIteratorFrom'](_0x2bec60,_0x3cdc2d);let _0x3344b5=_0x5ab7a4['getNext']();for(;_0x3344b5&&_0xaaa058['length']<_0x2c9cf1;)_0x12655f(_0x3344b5,_0x2bec60)!==0x0&&_0xaaa058['push'](_0x3344b5),_0x3344b5=_0x5ab7a4['getNext']();return _0xaaa058;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x31ef6b,_0x2cd192,_0x3ef5a7,_0x59bee4){return Bo(_0x31ef6b['writeTree'],_0x31ef6b['treePath'],_0x2cd192,_0x3ef5a7,_0x59bee4);}function is(_0x568fe0,_0x444902){return gu(_0x568fe0['writeTree'],_0x568fe0['treePath'],_0x444902);}function cr(_0xb1fea3,_0x2f25c0,_0x43ff13,_0x196f8d){return mu(_0xb1fea3['writeTree'],_0xb1fea3['treePath'],_0x2f25c0,_0x43ff13,_0x196f8d);}function Tn(_0x499cca,_0x445ced){return vu(_0x499cca['writeTree'],k(_0x499cca['treePath'],_0x445ced));}function wu(_0x1830de,_0x211b72,_0x57f7c0,_0x41ef51,_0x573c9f,_0x7a6185){return Eu(_0x1830de['writeTree'],_0x1830de['treePath'],_0x211b72,_0x57f7c0,_0x41ef51,_0x573c9f,_0x7a6185);}function ss(_0x51dc39,_0x165619,_0x450bd6){return yu(_0x51dc39['writeTree'],_0x51dc39['treePath'],_0x165619,_0x450bd6);}function Vo(_0x479d16,_0x5b4cae){return Ho(k(_0x479d16['treePath'],_0x5b4cae),_0x479d16['writeTree']);}function Ho(_0x56b426,_0x5235ff){return{'treePath':_0x56b426,'writeTree':_0x5235ff};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x16141b){const _0x4f60ea=_0x16141b['type'],_0x22449e=_0x16141b['childName'];f(_0x4f60ea==='child_added'||_0x4f60ea==='child_changed'||_0x4f60ea==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x22449e!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3d0d07=this['changeMap']['get'](_0x22449e);if(_0x3d0d07){const _0x9c97d3=_0x3d0d07['type'];if(_0x4f60ea==='child_added'&&_0x9c97d3==='child_removed')this['changeMap']['set'](_0x22449e,xt(_0x22449e,_0x16141b['snapshotNode'],_0x3d0d07['snapshotNode']));else{if(_0x4f60ea==='child_removed'&&_0x9c97d3==='child_added')this['changeMap']['delete'](_0x22449e);else{if(_0x4f60ea==='child_removed'&&_0x9c97d3==='child_changed')this['changeMap']['set'](_0x22449e,Lt(_0x22449e,_0x3d0d07['oldSnap']));else{if(_0x4f60ea==='child_changed'&&_0x9c97d3==='child_added')this['changeMap']['set'](_0x22449e,rt(_0x22449e,_0x16141b['snapshotNode']));else{if(_0x4f60ea==='child_changed'&&_0x9c97d3==='child_changed')this['changeMap']['set'](_0x22449e,xt(_0x22449e,_0x16141b['snapshotNode'],_0x3d0d07['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x16141b+'\x20occurred\x20after\x20'+_0x3d0d07);}}}}}else this['changeMap']['set'](_0x22449e,_0x16141b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x1bdfd3){return null;}['getChildAfterChild'](_0x5a7c66,_0x318af2,_0x150966){return null;}}const $o=new Tu();class rs{constructor(_0x4ac574,_0x3af254,_0x59c388=null){this['writes_']=_0x4ac574,this['viewCache_']=_0x3af254,this['optCompleteServerCache_']=_0x59c388;}['getCompleteChild'](_0x2dde83){const _0x45fe59=this['viewCache_']['eventCache'];if(_0x45fe59['isCompleteForChild'](_0x2dde83))return _0x45fe59['getNode']()['getImmediateChild'](_0x2dde83);{const _0x3e50fd=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x2dde83,_0x3e50fd);}}['getChildAfterChild'](_0x29a98a,_0x3d99e8,_0x400ee9){const _0x3a7568=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x2f12b1=wu(this['writes_'],_0x3a7568,_0x3d99e8,0x1,_0x400ee9,_0x29a98a);return _0x2f12b1['length']===0x0?null:_0x2f12b1[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x9ae6e8){return{'filter':_0x9ae6e8};}function bu(_0x118092,_0x21ac2f){f(_0x21ac2f['eventCache']['getNode']()['isIndexed'](_0x118092['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x21ac2f['serverCache']['getNode']()['isIndexed'](_0x118092['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x2d402e,_0x5e31ce,_0x3da9d0,_0x173109,_0x17a260){const _0x408dca=new Cu();let _0x3a458f,_0x91347e;if(_0x3da9d0['type']===z['OVERWRITE']){const _0x53b5da=_0x3da9d0;_0x53b5da['source']['fromUser']?_0x3a458f=ki(_0x2d402e,_0x5e31ce,_0x53b5da['path'],_0x53b5da['snap'],_0x173109,_0x17a260,_0x408dca):(f(_0x53b5da['source']['fromServer'],'Unknown\x20source.'),_0x91347e=_0x53b5da['source']['tagged']||_0x5e31ce['serverCache']['isFiltered']()&&!v(_0x53b5da['path']),_0x3a458f=Sn(_0x2d402e,_0x5e31ce,_0x53b5da['path'],_0x53b5da['snap'],_0x173109,_0x17a260,_0x91347e,_0x408dca));}else{if(_0x3da9d0['type']===z['MERGE']){const _0x2a36f2=_0x3da9d0;_0x2a36f2['source']['fromUser']?_0x3a458f=ku(_0x2d402e,_0x5e31ce,_0x2a36f2['path'],_0x2a36f2['children'],_0x173109,_0x17a260,_0x408dca):(f(_0x2a36f2['source']['fromServer'],'Unknown\x20source.'),_0x91347e=_0x2a36f2['source']['tagged']||_0x5e31ce['serverCache']['isFiltered'](),_0x3a458f=Pi(_0x2d402e,_0x5e31ce,_0x2a36f2['path'],_0x2a36f2['children'],_0x173109,_0x17a260,_0x91347e,_0x408dca));}else{if(_0x3da9d0['type']===z['ACK_USER_WRITE']){const _0x264808=_0x3da9d0;_0x264808['revert']?_0x3a458f=Ou(_0x2d402e,_0x5e31ce,_0x264808['path'],_0x173109,_0x17a260,_0x408dca):_0x3a458f=Pu(_0x2d402e,_0x5e31ce,_0x264808['path'],_0x264808['affectedTree'],_0x173109,_0x17a260,_0x408dca);}else{if(_0x3da9d0['type']===z['LISTEN_COMPLETE'])_0x3a458f=Nu(_0x2d402e,_0x5e31ce,_0x3da9d0['path'],_0x173109,_0x408dca);else throw ht('Unknown\x20operation\x20type:\x20'+_0x3da9d0['type']);}}}const _0x3eca34=_0x408dca['getChanges']();return Au(_0x5e31ce,_0x3a458f,_0x3eca34),{'viewCache':_0x3a458f,'changes':_0x3eca34};}function Au(_0x1ceaae,_0xad9e9d,_0x468a05){const _0x49e076=_0xad9e9d['eventCache'];if(_0x49e076['isFullyInitialized']()){const _0x4750db=_0x49e076['getNode']()['isLeafNode']()||_0x49e076['getNode']()['isEmpty'](),_0x8c59cd=wn(_0x1ceaae);(_0x468a05['length']>0x0||!_0x1ceaae['eventCache']['isFullyInitialized']()||_0x4750db&&!_0x49e076['getNode']()['equals'](_0x8c59cd)||!_0x49e076['getNode']()['getPriority']()['equals'](_0x8c59cd['getPriority']()))&&_0x468a05['push'](Lo(wn(_0xad9e9d)));}}function Go(_0x2f40fe,_0x23fabd,_0x4d68dc,_0x25b5c6,_0x38e971,_0x276bad){const _0x1f7969=_0x23fabd['eventCache'];if(Tn(_0x25b5c6,_0x4d68dc)!=null)return _0x23fabd;{let _0x113b80,_0xd339ce;if(v(_0x4d68dc)){if(f(_0x23fabd['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x23fabd['serverCache']['isFiltered']()){const _0x59abf5=Ve(_0x23fabd),_0x35edf9=_0x59abf5 instanceof g?_0x59abf5:g['EMPTY_NODE'],_0x3e8cc0=is(_0x25b5c6,_0x35edf9);_0x113b80=_0x2f40fe['filter']['updateFullNode'](_0x23fabd['eventCache']['getNode'](),_0x3e8cc0,_0x276bad);}else{const _0x100bd2=Cn(_0x25b5c6,Ve(_0x23fabd));_0x113b80=_0x2f40fe['filter']['updateFullNode'](_0x23fabd['eventCache']['getNode'](),_0x100bd2,_0x276bad);}}else{const _0x4f4f1c=y(_0x4d68dc);if(_0x4f4f1c==='.priority'){f(Ce(_0x4d68dc)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x128130=_0x1f7969['getNode']();_0xd339ce=_0x23fabd['serverCache']['getNode']();const _0x54216f=cr(_0x25b5c6,_0x4d68dc,_0x128130,_0xd339ce);_0x54216f!=null?_0x113b80=_0x2f40fe['filter']['updatePriority'](_0x128130,_0x54216f):_0x113b80=_0x1f7969['getNode']();}else{const _0x111980=S(_0x4d68dc);let _0x13911c;if(_0x1f7969['isCompleteForChild'](_0x4f4f1c)){_0xd339ce=_0x23fabd['serverCache']['getNode']();const _0x1720b8=cr(_0x25b5c6,_0x4d68dc,_0x1f7969['getNode'](),_0xd339ce);_0x1720b8!=null?_0x13911c=_0x1f7969['getNode']()['getImmediateChild'](_0x4f4f1c)['updateChild'](_0x111980,_0x1720b8):_0x13911c=_0x1f7969['getNode']()['getImmediateChild'](_0x4f4f1c);}else _0x13911c=ss(_0x25b5c6,_0x4f4f1c,_0x23fabd['serverCache']);_0x13911c!=null?_0x113b80=_0x2f40fe['filter']['updateChild'](_0x1f7969['getNode'](),_0x4f4f1c,_0x13911c,_0x111980,_0x38e971,_0x276bad):_0x113b80=_0x1f7969['getNode']();}}return Rt(_0x23fabd,_0x113b80,_0x1f7969['isFullyInitialized']()||v(_0x4d68dc),_0x2f40fe['filter']['filtersNodes']());}}function Sn(_0x4da08a,_0x482d47,_0x499218,_0x682570,_0x13e355,_0x13989b,_0x3c6510,_0x23bebb){const _0x1a810f=_0x482d47['serverCache'];let _0x1bc459;const _0x1e9831=_0x3c6510?_0x4da08a['filter']:_0x4da08a['filter']['getIndexedFilter']();if(v(_0x499218))_0x1bc459=_0x1e9831['updateFullNode'](_0x1a810f['getNode'](),_0x682570,null);else{if(_0x1e9831['filtersNodes']()&&!_0x1a810f['isFiltered']()){const _0x216848=_0x1a810f['getNode']()['updateChild'](_0x499218,_0x682570);_0x1bc459=_0x1e9831['updateFullNode'](_0x1a810f['getNode'](),_0x216848,null);}else{const _0xa7bc8=y(_0x499218);if(!_0x1a810f['isCompleteForPath'](_0x499218)&&Ce(_0x499218)>0x1)return _0x482d47;const _0x18a59b=S(_0x499218),_0x1bd94a=_0x1a810f['getNode']()['getImmediateChild'](_0xa7bc8)['updateChild'](_0x18a59b,_0x682570);_0xa7bc8==='.priority'?_0x1bc459=_0x1e9831['updatePriority'](_0x1a810f['getNode'](),_0x1bd94a):_0x1bc459=_0x1e9831['updateChild'](_0x1a810f['getNode'](),_0xa7bc8,_0x1bd94a,_0x18a59b,$o,null);}}const _0x174fc3=Fo(_0x482d47,_0x1bc459,_0x1a810f['isFullyInitialized']()||v(_0x499218),_0x1e9831['filtersNodes']()),_0x5985b6=new rs(_0x13e355,_0x174fc3,_0x13989b);return Go(_0x4da08a,_0x174fc3,_0x499218,_0x13e355,_0x5985b6,_0x23bebb);}function ki(_0x1cbba0,_0x48a454,_0x1b0cf,_0x5ba3d1,_0x3cebf2,_0x1b6188,_0x1f7e40){const _0x4901d3=_0x48a454['eventCache'];let _0x554897,_0x1a41d7;const _0x243b97=new rs(_0x3cebf2,_0x48a454,_0x1b6188);if(v(_0x1b0cf))_0x1a41d7=_0x1cbba0['filter']['updateFullNode'](_0x48a454['eventCache']['getNode'](),_0x5ba3d1,_0x1f7e40),_0x554897=Rt(_0x48a454,_0x1a41d7,!0x0,_0x1cbba0['filter']['filtersNodes']());else{const _0x468e25=y(_0x1b0cf);if(_0x468e25==='.priority')_0x1a41d7=_0x1cbba0['filter']['updatePriority'](_0x48a454['eventCache']['getNode'](),_0x5ba3d1),_0x554897=Rt(_0x48a454,_0x1a41d7,_0x4901d3['isFullyInitialized'](),_0x4901d3['isFiltered']());else{const _0x477ef5=S(_0x1b0cf),_0x34a6f0=_0x4901d3['getNode']()['getImmediateChild'](_0x468e25);let _0x512e4f;if(v(_0x477ef5))_0x512e4f=_0x5ba3d1;else{const _0x28ac3a=_0x243b97['getCompleteChild'](_0x468e25);_0x28ac3a!=null?ji(_0x477ef5)==='.priority'&&_0x28ac3a['getChild'](Ro(_0x477ef5))['isEmpty']()?_0x512e4f=_0x28ac3a:_0x512e4f=_0x28ac3a['updateChild'](_0x477ef5,_0x5ba3d1):_0x512e4f=g['EMPTY_NODE'];}if(_0x34a6f0['equals'](_0x512e4f))_0x554897=_0x48a454;else{const _0x31a36c=_0x1cbba0['filter']['updateChild'](_0x4901d3['getNode'](),_0x468e25,_0x512e4f,_0x477ef5,_0x243b97,_0x1f7e40);_0x554897=Rt(_0x48a454,_0x31a36c,_0x4901d3['isFullyInitialized'](),_0x1cbba0['filter']['filtersNodes']());}}}return _0x554897;}function lr(_0x453af9,_0x1b4b85){return _0x453af9['eventCache']['isCompleteForChild'](_0x1b4b85);}function ku(_0x238c01,_0x3deffe,_0x3419df,_0x4d89f0,_0x1e2bbf,_0x5a68f1,_0x59a8c8){let _0x5ee4b2=_0x3deffe;return _0x4d89f0['foreach']((_0xcb6362,_0x9cb357)=>{const _0x38623e=k(_0x3419df,_0xcb6362);lr(_0x3deffe,y(_0x38623e))&&(_0x5ee4b2=ki(_0x238c01,_0x5ee4b2,_0x38623e,_0x9cb357,_0x1e2bbf,_0x5a68f1,_0x59a8c8));}),_0x4d89f0['foreach']((_0x59bd28,_0x17df37)=>{const _0x43d646=k(_0x3419df,_0x59bd28);lr(_0x3deffe,y(_0x43d646))||(_0x5ee4b2=ki(_0x238c01,_0x5ee4b2,_0x43d646,_0x17df37,_0x1e2bbf,_0x5a68f1,_0x59a8c8));}),_0x5ee4b2;}function hr(_0x318c6a,_0x22ae0f,_0x6a5901){return _0x6a5901['foreach']((_0x4a8b06,_0x1955cd)=>{_0x22ae0f=_0x22ae0f['updateChild'](_0x4a8b06,_0x1955cd);}),_0x22ae0f;}function Pi(_0x4b4dec,_0x319099,_0xd612b0,_0xcfbf7f,_0x5ddd39,_0x1d20b4,_0x260285,_0xa42d7c){if(_0x319099['serverCache']['getNode']()['isEmpty']()&&!_0x319099['serverCache']['isFullyInitialized']())return _0x319099;let _0x2f2ad2=_0x319099,_0x1f2749;v(_0xd612b0)?_0x1f2749=_0xcfbf7f:_0x1f2749=new b(null)['setTree'](_0xd612b0,_0xcfbf7f);const _0xe30537=_0x319099['serverCache']['getNode']();return _0x1f2749['children']['inorderTraversal']((_0x49a5ba,_0x34bf1)=>{if(_0xe30537['hasChild'](_0x49a5ba)){const _0x3cff1c=_0x319099['serverCache']['getNode']()['getImmediateChild'](_0x49a5ba),_0x2222fa=hr(_0x4b4dec,_0x3cff1c,_0x34bf1);_0x2f2ad2=Sn(_0x4b4dec,_0x2f2ad2,new C(_0x49a5ba),_0x2222fa,_0x5ddd39,_0x1d20b4,_0x260285,_0xa42d7c);}}),_0x1f2749['children']['inorderTraversal']((_0x26a29b,_0x146551)=>{const _0x2decb4=!_0x319099['serverCache']['isCompleteForChild'](_0x26a29b)&&_0x146551['value']===null;if(!_0xe30537['hasChild'](_0x26a29b)&&!_0x2decb4){const _0x1e5bee=_0x319099['serverCache']['getNode']()['getImmediateChild'](_0x26a29b),_0x1cef0f=hr(_0x4b4dec,_0x1e5bee,_0x146551);_0x2f2ad2=Sn(_0x4b4dec,_0x2f2ad2,new C(_0x26a29b),_0x1cef0f,_0x5ddd39,_0x1d20b4,_0x260285,_0xa42d7c);}}),_0x2f2ad2;}function Pu(_0x1b92d,_0x270a26,_0xbf04d4,_0x43d1b9,_0x641772,_0x12dd80,_0x11533a){if(Tn(_0x641772,_0xbf04d4)!=null)return _0x270a26;const _0x5ec113=_0x270a26['serverCache']['isFiltered'](),_0x47ec2e=_0x270a26['serverCache'];if(_0x43d1b9['value']!=null){if(v(_0xbf04d4)&&_0x47ec2e['isFullyInitialized']()||_0x47ec2e['isCompleteForPath'](_0xbf04d4))return Sn(_0x1b92d,_0x270a26,_0xbf04d4,_0x47ec2e['getNode']()['getChild'](_0xbf04d4),_0x641772,_0x12dd80,_0x5ec113,_0x11533a);if(v(_0xbf04d4)){let _0x6b1a4d=new b(null);return _0x47ec2e['getNode']()['forEachChild'](ve,(_0x2d132a,_0x3aec0d)=>{_0x6b1a4d=_0x6b1a4d['set'](new C(_0x2d132a),_0x3aec0d);}),Pi(_0x1b92d,_0x270a26,_0xbf04d4,_0x6b1a4d,_0x641772,_0x12dd80,_0x5ec113,_0x11533a);}else return _0x270a26;}else{let _0x301150=new b(null);return _0x43d1b9['foreach']((_0x197b46,_0x447afe)=>{const _0xc9d36e=k(_0xbf04d4,_0x197b46);_0x47ec2e['isCompleteForPath'](_0xc9d36e)&&(_0x301150=_0x301150['set'](_0x197b46,_0x47ec2e['getNode']()['getChild'](_0xc9d36e)));}),Pi(_0x1b92d,_0x270a26,_0xbf04d4,_0x301150,_0x641772,_0x12dd80,_0x5ec113,_0x11533a);}}function Nu(_0x5bbb8b,_0x3f44fb,_0x2783b8,_0x3d7048,_0x23478c){const _0x4d491e=_0x3f44fb['serverCache'],_0xbe21fb=Fo(_0x3f44fb,_0x4d491e['getNode'](),_0x4d491e['isFullyInitialized']()||v(_0x2783b8),_0x4d491e['isFiltered']());return Go(_0x5bbb8b,_0xbe21fb,_0x2783b8,_0x3d7048,$o,_0x23478c);}function Ou(_0x377e29,_0x633600,_0x1e91d6,_0xb1d9f5,_0x3ad97c,_0x16f8b8){let _0xd22b2f;if(Tn(_0xb1d9f5,_0x1e91d6)!=null)return _0x633600;{const _0x3322ef=new rs(_0xb1d9f5,_0x633600,_0x3ad97c),_0x1af667=_0x633600['eventCache']['getNode']();let _0x8edbe9;if(v(_0x1e91d6)||y(_0x1e91d6)==='.priority'){let _0x5d2605;if(_0x633600['serverCache']['isFullyInitialized']())_0x5d2605=Cn(_0xb1d9f5,Ve(_0x633600));else{const _0x52c195=_0x633600['serverCache']['getNode']();f(_0x52c195 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5d2605=is(_0xb1d9f5,_0x52c195);}_0x5d2605=_0x5d2605,_0x8edbe9=_0x377e29['filter']['updateFullNode'](_0x1af667,_0x5d2605,_0x16f8b8);}else{const _0x225498=y(_0x1e91d6);let _0x47da37=ss(_0xb1d9f5,_0x225498,_0x633600['serverCache']);_0x47da37==null&&_0x633600['serverCache']['isCompleteForChild'](_0x225498)&&(_0x47da37=_0x1af667['getImmediateChild'](_0x225498)),_0x47da37!=null?_0x8edbe9=_0x377e29['filter']['updateChild'](_0x1af667,_0x225498,_0x47da37,S(_0x1e91d6),_0x3322ef,_0x16f8b8):_0x633600['eventCache']['getNode']()['hasChild'](_0x225498)?_0x8edbe9=_0x377e29['filter']['updateChild'](_0x1af667,_0x225498,g['EMPTY_NODE'],S(_0x1e91d6),_0x3322ef,_0x16f8b8):_0x8edbe9=_0x1af667,_0x8edbe9['isEmpty']()&&_0x633600['serverCache']['isFullyInitialized']()&&(_0xd22b2f=Cn(_0xb1d9f5,Ve(_0x633600)),_0xd22b2f['isLeafNode']()&&(_0x8edbe9=_0x377e29['filter']['updateFullNode'](_0x8edbe9,_0xd22b2f,_0x16f8b8)));}return _0xd22b2f=_0x633600['serverCache']['isFullyInitialized']()||Tn(_0xb1d9f5,w())!=null,Rt(_0x633600,_0x8edbe9,_0xd22b2f,_0x377e29['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x5a17d1,_0x332208){this['query_']=_0x5a17d1,this['eventRegistrations_']=[];const _0x1a0577=this['query_']['_queryParams'],_0x19783b=new Xi(_0x1a0577['getIndex']()),_0x292e1d=Kh(_0x1a0577);this['processor_']=Su(_0x292e1d);const _0x44610a=_0x332208['serverCache'],_0x587818=_0x332208['eventCache'],_0xa9506f=_0x19783b['updateFullNode'](g['EMPTY_NODE'],_0x44610a['getNode'](),null),_0x183af1=_0x292e1d['updateFullNode'](g['EMPTY_NODE'],_0x587818['getNode'](),null),_0xa16d83=new Te(_0xa9506f,_0x44610a['isFullyInitialized'](),_0x19783b['filtersNodes']()),_0x144706=new Te(_0x183af1,_0x587818['isFullyInitialized'](),_0x292e1d['filtersNodes']());this['viewCache_']=Un(_0x144706,_0xa16d83),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x281b1d){return _0x281b1d['viewCache_']['serverCache']['getNode']();}function Lu(_0x193f96){return wn(_0x193f96['viewCache_']);}function xu(_0x2d5096,_0x33f172){const _0x1283b1=Ve(_0x2d5096['viewCache_']);return _0x1283b1&&(_0x2d5096['query']['_queryParams']['loadsAllData']()||!v(_0x33f172)&&!_0x1283b1['getImmediateChild'](y(_0x33f172))['isEmpty']())?_0x1283b1['getChild'](_0x33f172):null;}function ur(_0x35a553){return _0x35a553['eventRegistrations_']['length']===0x0;}function Fu(_0x2f418a,_0x5e43ab){_0x2f418a['eventRegistrations_']['push'](_0x5e43ab);}function dr(_0x2f0c5a,_0x220bde,_0x2b0c0e){const _0x5d1d56=[];if(_0x2b0c0e){f(_0x220bde==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x519520=_0x2f0c5a['query']['_path'];_0x2f0c5a['eventRegistrations_']['forEach'](_0x50cce5=>{const _0x2c675c=_0x50cce5['createCancelEvent'](_0x2b0c0e,_0x519520);_0x2c675c&&_0x5d1d56['push'](_0x2c675c);});}if(_0x220bde){let _0x45af9d=[];for(let _0x3d562f=0x0;_0x3d562f<_0x2f0c5a['eventRegistrations_']['length'];++_0x3d562f){const _0x3973bd=_0x2f0c5a['eventRegistrations_'][_0x3d562f];if(!_0x3973bd['matches'](_0x220bde))_0x45af9d['push'](_0x3973bd);else{if(_0x220bde['hasAnyCallback']()){_0x45af9d=_0x45af9d['concat'](_0x2f0c5a['eventRegistrations_']['slice'](_0x3d562f+0x1));break;}}}_0x2f0c5a['eventRegistrations_']=_0x45af9d;}else _0x2f0c5a['eventRegistrations_']=[];return _0x5d1d56;}function fr(_0x24ff75,_0x51a00e,_0x506ea9,_0x45daee){_0x51a00e['type']===z['MERGE']&&_0x51a00e['source']['queryId']!==null&&(f(Ve(_0x24ff75['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x24ff75['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x4b3d6e=_0x24ff75['viewCache_'],_0x31f43d=Ru(_0x24ff75['processor_'],_0x4b3d6e,_0x51a00e,_0x506ea9,_0x45daee);return bu(_0x24ff75['processor_'],_0x31f43d['viewCache']),f(_0x31f43d['viewCache']['serverCache']['isFullyInitialized']()||!_0x4b3d6e['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x24ff75['viewCache_']=_0x31f43d['viewCache'],qo(_0x24ff75,_0x31f43d['changes'],_0x31f43d['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x486655,_0x344d43){const _0xb54437=_0x486655['viewCache_']['eventCache'],_0x40ce8c=[];return _0xb54437['getNode']()['isLeafNode']()||_0xb54437['getNode']()['forEachChild'](R,(_0x349765,_0x56ddd8)=>{_0x40ce8c['push'](rt(_0x349765,_0x56ddd8));}),_0xb54437['isFullyInitialized']()&&_0x40ce8c['push'](Lo(_0xb54437['getNode']())),qo(_0x486655,_0x40ce8c,_0xb54437['getNode'](),_0x344d43);}function qo(_0x324103,_0x1276f0,_0x47e9df,_0x49d70a){const _0x3c4929=_0x49d70a?[_0x49d70a]:_0x324103['eventRegistrations_'];return ru(_0x324103['eventGenerator_'],_0x1276f0,_0x47e9df,_0x3c4929);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x513958){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x513958;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x1d8483){return _0x1d8483['views']['size']===0x0;}function os(_0x46b527,_0x3d12d3,_0x13294d,_0x1ff8c4){const _0x5b282f=_0x3d12d3['source']['queryId'];if(_0x5b282f!==null){const _0x37a323=_0x46b527['views']['get'](_0x5b282f);return f(_0x37a323!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x37a323,_0x3d12d3,_0x13294d,_0x1ff8c4);}else{let _0xd61453=[];for(const _0x4951e7 of _0x46b527['views']['values']())_0xd61453=_0xd61453['concat'](fr(_0x4951e7,_0x3d12d3,_0x13294d,_0x1ff8c4));return _0xd61453;}}function jo(_0x562b9d,_0x50bea9,_0x286261,_0x7387ef,_0x2af58d){const _0x1bc3f4=_0x50bea9['_queryIdentifier'],_0x268f69=_0x562b9d['views']['get'](_0x1bc3f4);if(!_0x268f69){let _0x32af20=Cn(_0x286261,_0x2af58d?_0x7387ef:null),_0x1cc75b=!0x1;_0x32af20?_0x1cc75b=!0x0:_0x7387ef instanceof g?(_0x32af20=is(_0x286261,_0x7387ef),_0x1cc75b=!0x1):(_0x32af20=g['EMPTY_NODE'],_0x1cc75b=!0x1);const _0x42e41f=Un(new Te(_0x32af20,_0x1cc75b,!0x1),new Te(_0x7387ef,_0x2af58d,!0x1));return new Du(_0x50bea9,_0x42e41f);}return _0x268f69;}function Hu(_0x54be4f,_0x4a9dcd,_0x1a5e8b,_0x3d873e,_0x54dd80,_0x3fcfcb){const _0x26b3ee=jo(_0x54be4f,_0x4a9dcd,_0x3d873e,_0x54dd80,_0x3fcfcb);return _0x54be4f['views']['has'](_0x4a9dcd['_queryIdentifier'])||_0x54be4f['views']['set'](_0x4a9dcd['_queryIdentifier'],_0x26b3ee),Fu(_0x26b3ee,_0x1a5e8b),Uu(_0x26b3ee,_0x1a5e8b);}function $u(_0x1bdd93,_0x5b4167,_0x96a5bd,_0x14b6ec){const _0x12c255=_0x5b4167['_queryIdentifier'],_0x565c4c=[];let _0x2bccfc=[];const _0x500dd0=Se(_0x1bdd93);if(_0x12c255==='default'){for(const [_0x23a474,_0x23399d]of _0x1bdd93['views']['entries']())_0x2bccfc=_0x2bccfc['concat'](dr(_0x23399d,_0x96a5bd,_0x14b6ec)),ur(_0x23399d)&&(_0x1bdd93['views']['delete'](_0x23a474),_0x23399d['query']['_queryParams']['loadsAllData']()||_0x565c4c['push'](_0x23399d['query']));}else{const _0x57ba5a=_0x1bdd93['views']['get'](_0x12c255);_0x57ba5a&&(_0x2bccfc=_0x2bccfc['concat'](dr(_0x57ba5a,_0x96a5bd,_0x14b6ec)),ur(_0x57ba5a)&&(_0x1bdd93['views']['delete'](_0x12c255),_0x57ba5a['query']['_queryParams']['loadsAllData']()||_0x565c4c['push'](_0x57ba5a['query'])));}return _0x500dd0&&!Se(_0x1bdd93)&&_0x565c4c['push'](new(Bu())(_0x5b4167['_repo'],_0x5b4167['_path'])),{'removed':_0x565c4c,'events':_0x2bccfc};}function Ko(_0x6bc5c0){const _0x2378d3=[];for(const _0x38f792 of _0x6bc5c0['views']['values']())_0x38f792['query']['_queryParams']['loadsAllData']()||_0x2378d3['push'](_0x38f792);return _0x2378d3;}function Ie(_0x17a814,_0x5e3e9c){let _0x1bca85=null;for(const _0x42af15 of _0x17a814['views']['values']())_0x1bca85=_0x1bca85||xu(_0x42af15,_0x5e3e9c);return _0x1bca85;}function Yo(_0x331ecc,_0x518ba5){if(_0x518ba5['_queryParams']['loadsAllData']())return Bn(_0x331ecc);{const _0x4e1d35=_0x518ba5['_queryIdentifier'];return _0x331ecc['views']['get'](_0x4e1d35);}}function Qo(_0x4b66e1,_0x20b447){return Yo(_0x4b66e1,_0x20b447)!=null;}function Se(_0x161194){return Bn(_0x161194)!=null;}function Bn(_0x5ddfe2){for(const _0x19ff1a of _0x5ddfe2['views']['values']())if(_0x19ff1a['query']['_queryParams']['loadsAllData']())return _0x19ff1a;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0xa37745){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0xa37745;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x240929){this['listenProvider_']=_0x240929,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x4cf3f0,_0x221b60,_0x3c9262,_0x26e35b,_0x25f9df){return lu(_0x4cf3f0['pendingWriteTree_'],_0x221b60,_0x3c9262,_0x26e35b,_0x25f9df),_0x25f9df?_t(_0x4cf3f0,new Be(es(),_0x221b60,_0x3c9262)):[];}function ju(_0x29d4c1,_0x1749c1,_0x252aef,_0xe6af6d){hu(_0x29d4c1['pendingWriteTree_'],_0x1749c1,_0x252aef,_0xe6af6d);const _0xb7a163=b['fromObject'](_0x252aef);return _t(_0x29d4c1,new ot(es(),_0x1749c1,_0xb7a163));}function _e(_0x500f0d,_0x5611e5,_0x1a37d3=!0x1){const _0x50a816=uu(_0x500f0d['pendingWriteTree_'],_0x5611e5);if(du(_0x500f0d['pendingWriteTree_'],_0x5611e5)){let _0x1aa4d0=new b(null);return _0x50a816['snap']!=null?_0x1aa4d0=_0x1aa4d0['set'](w(),!0x0):x(_0x50a816['children'],_0x59275e=>{_0x1aa4d0=_0x1aa4d0['set'](new C(_0x59275e),!0x0);}),_t(_0x500f0d,new In(_0x50a816['path'],_0x1aa4d0,_0x1a37d3));}else return[];}function Yt(_0x129608,_0x1d1f8e,_0x2863a0){return _t(_0x129608,new Be(ts(),_0x1d1f8e,_0x2863a0));}function Ku(_0x57bf9d,_0x5e5929,_0x2d8885){const _0x3bb4c6=b['fromObject'](_0x2d8885);return _t(_0x57bf9d,new ot(ts(),_0x5e5929,_0x3bb4c6));}function Yu(_0x18cdff,_0x5810dc){return _t(_0x18cdff,new Ut(ts(),_0x5810dc));}function Qu(_0x54c17c,_0x160edf,_0x59a501){const _0x15259d=cs(_0x54c17c,_0x59a501);if(_0x15259d){const _0x20c477=ls(_0x15259d),_0x5a083e=_0x20c477['path'],_0x10fbb1=_0x20c477['queryId'],_0x2ec898=F(_0x5a083e,_0x160edf),_0x351472=new Ut(ns(_0x10fbb1),_0x2ec898);return hs(_0x54c17c,_0x5a083e,_0x351472);}else return[];}function An(_0x480871,_0x29ad67,_0x4c4a23,_0x3ccf35,_0x34fb00=!0x1){const _0x282384=_0x29ad67['_path'],_0x513bd2=_0x480871['syncPointTree_']['get'](_0x282384);let _0x2a058e=[];if(_0x513bd2&&(_0x29ad67['_queryIdentifier']==='default'||Qo(_0x513bd2,_0x29ad67))){const _0x44e68b=$u(_0x513bd2,_0x29ad67,_0x4c4a23,_0x3ccf35);Vu(_0x513bd2)&&(_0x480871['syncPointTree_']=_0x480871['syncPointTree_']['remove'](_0x282384));const _0x16f5c4=_0x44e68b['removed'];if(_0x2a058e=_0x44e68b['events'],!_0x34fb00){const _0x3f15f5=_0x16f5c4['findIndex'](_0x322c81=>_0x322c81['_queryParams']['loadsAllData']())!==-0x1,_0x168768=_0x480871['syncPointTree_']['findOnPath'](_0x282384,(_0x2434d3,_0x176ed1)=>Se(_0x176ed1));if(_0x3f15f5&&!_0x168768){const _0x4e7026=_0x480871['syncPointTree_']['subtree'](_0x282384);if(!_0x4e7026['isEmpty']()){const _0x7bc563=Zu(_0x4e7026);for(let _0xfda1e7=0x0;_0xfda1e7<_0x7bc563['length'];++_0xfda1e7){const _0x1dfc5b=_0x7bc563[_0xfda1e7],_0x3bdbc8=_0x1dfc5b['query'],_0x33be1e=ea(_0x480871,_0x1dfc5b);_0x480871['listenProvider_']['startListening'](kt(_0x3bdbc8),Wt(_0x480871,_0x3bdbc8),_0x33be1e['hashFn'],_0x33be1e['onComplete']);}}}!_0x168768&&_0x16f5c4['length']>0x0&&!_0x3ccf35&&(_0x3f15f5?_0x480871['listenProvider_']['stopListening'](kt(_0x29ad67),null):_0x16f5c4['forEach'](_0x2594ae=>{const _0x3a8eba=_0x480871['queryToTagMap']['get'](Hn(_0x2594ae));_0x480871['listenProvider_']['stopListening'](kt(_0x2594ae),_0x3a8eba);}));}ed(_0x480871,_0x16f5c4);}return _0x2a058e;}function Jo(_0x34fa83,_0x50d5ee,_0x460ff5,_0x23b1cf){const _0x927c3a=cs(_0x34fa83,_0x23b1cf);if(_0x927c3a!=null){const _0x30dd60=ls(_0x927c3a),_0x20b098=_0x30dd60['path'],_0x1232e8=_0x30dd60['queryId'],_0x3edafc=F(_0x20b098,_0x50d5ee),_0x5aa95e=new Be(ns(_0x1232e8),_0x3edafc,_0x460ff5);return hs(_0x34fa83,_0x20b098,_0x5aa95e);}else return[];}function Ju(_0xa106ce,_0x24ee5b,_0x2f0c0c,_0x35b329){const _0x37cc83=cs(_0xa106ce,_0x35b329);if(_0x37cc83){const _0x414a18=ls(_0x37cc83),_0x1a0340=_0x414a18['path'],_0x312a80=_0x414a18['queryId'],_0x284bdb=F(_0x1a0340,_0x24ee5b),_0x3dce17=b['fromObject'](_0x2f0c0c),_0x3be376=new ot(ns(_0x312a80),_0x284bdb,_0x3dce17);return hs(_0xa106ce,_0x1a0340,_0x3be376);}else return[];}function Ni(_0x560194,_0x3d0b7d,_0x3572b8,_0x3be00d=!0x1){const _0x410736=_0x3d0b7d['_path'];let _0x4d4caa=null,_0x41a646=!0x1;_0x560194['syncPointTree_']['foreachOnPath'](_0x410736,(_0x924b1e,_0x41d21c)=>{const _0x49932a=F(_0x924b1e,_0x410736);_0x4d4caa=_0x4d4caa||Ie(_0x41d21c,_0x49932a),_0x41a646=_0x41a646||Se(_0x41d21c);});let _0x5aa7c1=_0x560194['syncPointTree_']['get'](_0x410736);_0x5aa7c1?(_0x41a646=_0x41a646||Se(_0x5aa7c1),_0x4d4caa=_0x4d4caa||Ie(_0x5aa7c1,w())):(_0x5aa7c1=new zo(),_0x560194['syncPointTree_']=_0x560194['syncPointTree_']['set'](_0x410736,_0x5aa7c1));let _0x1f379d;_0x4d4caa!=null?_0x1f379d=!0x0:(_0x1f379d=!0x1,_0x4d4caa=g['EMPTY_NODE'],_0x560194['syncPointTree_']['subtree'](_0x410736)['foreachChild']((_0x4439a8,_0xf16445)=>{const _0x5212a2=Ie(_0xf16445,w());_0x5212a2&&(_0x4d4caa=_0x4d4caa['updateImmediateChild'](_0x4439a8,_0x5212a2));}));const _0x6ce81e=Qo(_0x5aa7c1,_0x3d0b7d);if(!_0x6ce81e&&!_0x3d0b7d['_queryParams']['loadsAllData']()){const _0x46726a=Hn(_0x3d0b7d);f(!_0x560194['queryToTagMap']['has'](_0x46726a),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1ada6b=td();_0x560194['queryToTagMap']['set'](_0x46726a,_0x1ada6b),_0x560194['tagToQueryMap']['set'](_0x1ada6b,_0x46726a);}const _0x1f0f36=Wn(_0x560194['pendingWriteTree_'],_0x410736);let _0x16ec66=Hu(_0x5aa7c1,_0x3d0b7d,_0x3572b8,_0x1f0f36,_0x4d4caa,_0x1f379d);if(!_0x6ce81e&&!_0x41a646&&!_0x3be00d){const _0x279cd8=Yo(_0x5aa7c1,_0x3d0b7d);_0x16ec66=_0x16ec66['concat'](nd(_0x560194,_0x3d0b7d,_0x279cd8));}return _0x16ec66;}function Vn(_0xe56bed,_0x2a6d92,_0x290493){const _0x4699ac=_0xe56bed['pendingWriteTree_'],_0x5e8e7c=_0xe56bed['syncPointTree_']['findOnPath'](_0x2a6d92,(_0x268c3b,_0x4926b8)=>{const _0x365928=F(_0x268c3b,_0x2a6d92),_0x12fd1b=Ie(_0x4926b8,_0x365928);if(_0x12fd1b)return _0x12fd1b;});return Bo(_0x4699ac,_0x2a6d92,_0x5e8e7c,_0x290493,!0x0);}function Xu(_0x3a5bfa,_0x2dd4f4){const _0x23f400=_0x2dd4f4['_path'];let _0x505d42=null;_0x3a5bfa['syncPointTree_']['foreachOnPath'](_0x23f400,(_0x5d08ab,_0x4eb113)=>{const _0x360cc7=F(_0x5d08ab,_0x23f400);_0x505d42=_0x505d42||Ie(_0x4eb113,_0x360cc7);});let _0x5e29ea=_0x3a5bfa['syncPointTree_']['get'](_0x23f400);_0x5e29ea?_0x505d42=_0x505d42||Ie(_0x5e29ea,w()):(_0x5e29ea=new zo(),_0x3a5bfa['syncPointTree_']=_0x3a5bfa['syncPointTree_']['set'](_0x23f400,_0x5e29ea));const _0x17f124=_0x505d42!=null,_0x24bc9d=_0x17f124?new Te(_0x505d42,!0x0,!0x1):null,_0x3c9f19=Wn(_0x3a5bfa['pendingWriteTree_'],_0x2dd4f4['_path']),_0x13a470=jo(_0x5e29ea,_0x2dd4f4,_0x3c9f19,_0x17f124?_0x24bc9d['getNode']():g['EMPTY_NODE'],_0x17f124);return Lu(_0x13a470);}function _t(_0x4102d9,_0x1c13fe){return Xo(_0x1c13fe,_0x4102d9['syncPointTree_'],null,Wn(_0x4102d9['pendingWriteTree_'],w()));}function Xo(_0x254c76,_0x18ff78,_0x2213b7,_0x56e886){if(v(_0x254c76['path']))return Zo(_0x254c76,_0x18ff78,_0x2213b7,_0x56e886);{const _0x8400c0=_0x18ff78['get'](w());_0x2213b7==null&&_0x8400c0!=null&&(_0x2213b7=Ie(_0x8400c0,w()));let _0x3a57bb=[];const _0xa17cf9=y(_0x254c76['path']),_0x1e430b=_0x254c76['operationForChild'](_0xa17cf9),_0xa5fda=_0x18ff78['children']['get'](_0xa17cf9);if(_0xa5fda&&_0x1e430b){const _0x2265ef=_0x2213b7?_0x2213b7['getImmediateChild'](_0xa17cf9):null,_0x339589=Vo(_0x56e886,_0xa17cf9);_0x3a57bb=_0x3a57bb['concat'](Xo(_0x1e430b,_0xa5fda,_0x2265ef,_0x339589));}return _0x8400c0&&(_0x3a57bb=_0x3a57bb['concat'](os(_0x8400c0,_0x254c76,_0x56e886,_0x2213b7))),_0x3a57bb;}}function Zo(_0x3f8c68,_0x3344aa,_0x5a95fd,_0x44c359){const _0x191e7d=_0x3344aa['get'](w());_0x5a95fd==null&&_0x191e7d!=null&&(_0x5a95fd=Ie(_0x191e7d,w()));let _0x1363ad=[];return _0x3344aa['children']['inorderTraversal']((_0x37498d,_0x15846a)=>{const _0x66b6c8=_0x5a95fd?_0x5a95fd['getImmediateChild'](_0x37498d):null,_0x2dfc98=Vo(_0x44c359,_0x37498d),_0x2d4c6f=_0x3f8c68['operationForChild'](_0x37498d);_0x2d4c6f&&(_0x1363ad=_0x1363ad['concat'](Zo(_0x2d4c6f,_0x15846a,_0x66b6c8,_0x2dfc98)));}),_0x191e7d&&(_0x1363ad=_0x1363ad['concat'](os(_0x191e7d,_0x3f8c68,_0x44c359,_0x5a95fd))),_0x1363ad;}function ea(_0x5b4844,_0x44ce15){const _0x230733=_0x44ce15['query'],_0x4a8e7e=Wt(_0x5b4844,_0x230733);return{'hashFn':()=>(Mu(_0x44ce15)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x5b7521=>{if(_0x5b7521==='ok')return _0x4a8e7e?Qu(_0x5b4844,_0x230733['_path'],_0x4a8e7e):Yu(_0x5b4844,_0x230733['_path']);{const _0x20c062=Kl(_0x5b7521,_0x230733);return An(_0x5b4844,_0x230733,null,_0x20c062);}}};}function Wt(_0x15ab30,_0x4075f5){const _0x4bf5d4=Hn(_0x4075f5);return _0x15ab30['queryToTagMap']['get'](_0x4bf5d4);}function Hn(_0x526cbd){return _0x526cbd['_path']['toString']()+'$'+_0x526cbd['_queryIdentifier'];}function cs(_0x57acdf,_0x81c687){return _0x57acdf['tagToQueryMap']['get'](_0x81c687);}function ls(_0x43024c){const _0x25eb93=_0x43024c['indexOf']('$');return f(_0x25eb93!==-0x1&&_0x25eb93<_0x43024c['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x43024c['substr'](_0x25eb93+0x1),'path':new C(_0x43024c['substr'](0x0,_0x25eb93))};}function hs(_0x29ae36,_0x5d037f,_0x28d26e){const _0x37c843=_0x29ae36['syncPointTree_']['get'](_0x5d037f);f(_0x37c843,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1f8b79=Wn(_0x29ae36['pendingWriteTree_'],_0x5d037f);return os(_0x37c843,_0x28d26e,_0x1f8b79,null);}function Zu(_0x4b8685){return _0x4b8685['fold']((_0x3bd31f,_0x5aec13,_0x114c14)=>{if(_0x5aec13&&Se(_0x5aec13))return[Bn(_0x5aec13)];{let _0x5d3225=[];return _0x5aec13&&(_0x5d3225=Ko(_0x5aec13)),x(_0x114c14,(_0x41a084,_0x295692)=>{_0x5d3225=_0x5d3225['concat'](_0x295692);}),_0x5d3225;}});}function kt(_0xe49913){return _0xe49913['_queryParams']['loadsAllData']()&&!_0xe49913['_queryParams']['isDefault']()?new(qu())(_0xe49913['_repo'],_0xe49913['_path']):_0xe49913;}function ed(_0x22e5c6,_0x895353){for(let _0x2252d9=0x0;_0x2252d9<_0x895353['length'];++_0x2252d9){const _0x405b54=_0x895353[_0x2252d9];if(!_0x405b54['_queryParams']['loadsAllData']()){const _0x1650b2=Hn(_0x405b54),_0x384553=_0x22e5c6['queryToTagMap']['get'](_0x1650b2);_0x22e5c6['queryToTagMap']['delete'](_0x1650b2),_0x22e5c6['tagToQueryMap']['delete'](_0x384553);}}}function td(){return zu++;}function nd(_0x43dae9,_0x2f9b0a,_0x2f50ef){const _0xbb32b6=_0x2f9b0a['_path'],_0x2d4096=Wt(_0x43dae9,_0x2f9b0a),_0x2c39ec=ea(_0x43dae9,_0x2f50ef),_0x54b501=_0x43dae9['listenProvider_']['startListening'](kt(_0x2f9b0a),_0x2d4096,_0x2c39ec['hashFn'],_0x2c39ec['onComplete']),_0x13ccfa=_0x43dae9['syncPointTree_']['subtree'](_0xbb32b6);if(_0x2d4096)f(!Se(_0x13ccfa['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x21ccda=_0x13ccfa['fold']((_0x5ee9c7,_0x51f58d,_0x48b85f)=>{if(!v(_0x5ee9c7)&&_0x51f58d&&Se(_0x51f58d))return[Bn(_0x51f58d)['query']];{let _0xd35ea3=[];return _0x51f58d&&(_0xd35ea3=_0xd35ea3['concat'](Ko(_0x51f58d)['map'](_0x8e6173=>_0x8e6173['query']))),x(_0x48b85f,(_0x50d39a,_0x1e0817)=>{_0xd35ea3=_0xd35ea3['concat'](_0x1e0817);}),_0xd35ea3;}});for(let _0x2f9a45=0x0;_0x2f9a45<_0x21ccda['length'];++_0x2f9a45){const _0x582a12=_0x21ccda[_0x2f9a45];_0x43dae9['listenProvider_']['stopListening'](kt(_0x582a12),Wt(_0x43dae9,_0x582a12));}}return _0x54b501;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0xcc8a87){this['node_']=_0xcc8a87;}['getImmediateChild'](_0x32b533){const _0x2236c9=this['node_']['getImmediateChild'](_0x32b533);return new us(_0x2236c9);}['node'](){return this['node_'];}}class ds{constructor(_0x25f7a8,_0x56c09b){this['syncTree_']=_0x25f7a8,this['path_']=_0x56c09b;}['getImmediateChild'](_0x895169){const _0x3a1aa2=k(this['path_'],_0x895169);return new ds(this['syncTree_'],_0x3a1aa2);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x15535b){return _0x15535b=_0x15535b||{},_0x15535b['timestamp']=_0x15535b['timestamp']||new Date()['getTime'](),_0x15535b;},_r=function(_0x395414,_0xbf4f96,_0x1cc437){if(!_0x395414||typeof _0x395414!='object')return _0x395414;if(f('.sv'in _0x395414,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x395414['.sv']=='string')return sd(_0x395414['.sv'],_0xbf4f96,_0x1cc437);if(typeof _0x395414['.sv']=='object')return rd(_0x395414['.sv'],_0xbf4f96);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x395414,null,0x2));},sd=function(_0x524adc,_0x15de60,_0x56c688){switch(_0x524adc){case'timestamp':return _0x56c688['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x524adc);}},rd=function(_0x3a2ef7,_0x10736e,_0x58efd3){_0x3a2ef7['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3a2ef7,null,0x2));const _0xbab53e=_0x3a2ef7['increment'];typeof _0xbab53e!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0xbab53e);const _0x5bf14b=_0x10736e['node']();if(f(_0x5bf14b!==null&&typeof _0x5bf14b<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5bf14b['isLeafNode']())return _0xbab53e;const _0x4271bb=_0x5bf14b['getValue']();return typeof _0x4271bb!='number'?_0xbab53e:_0x4271bb+_0xbab53e;},ta=function(_0x2a9b2b,_0x300071,_0x1c666c,_0x20d40c){return ps(_0x300071,new ds(_0x1c666c,_0x2a9b2b),_0x20d40c);},fs=function(_0x32f100,_0x569a7a,_0x17149b){return ps(_0x32f100,new us(_0x569a7a),_0x17149b);};function ps(_0x1db24d,_0x3a4431,_0x1eccb2){const _0x14cffa=_0x1db24d['getPriority']()['val'](),_0x29452a=_r(_0x14cffa,_0x3a4431['getImmediateChild']('.priority'),_0x1eccb2);let _0xa5d2f;if(_0x1db24d['isLeafNode']()){const _0x580ecd=_0x1db24d,_0x3a5384=_r(_0x580ecd['getValue'](),_0x3a4431,_0x1eccb2);return _0x3a5384!==_0x580ecd['getValue']()||_0x29452a!==_0x580ecd['getPriority']()['val']()?new D(_0x3a5384,A(_0x29452a)):_0x1db24d;}else{const _0x456571=_0x1db24d;return _0xa5d2f=_0x456571,_0x29452a!==_0x456571['getPriority']()['val']()&&(_0xa5d2f=_0xa5d2f['updatePriority'](new D(_0x29452a))),_0x456571['forEachChild'](R,(_0x3f086a,_0x3566c2)=>{const _0x5ea7dc=ps(_0x3566c2,_0x3a4431['getImmediateChild'](_0x3f086a),_0x1eccb2);_0x5ea7dc!==_0x3566c2&&(_0xa5d2f=_0xa5d2f['updateImmediateChild'](_0x3f086a,_0x5ea7dc));}),_0xa5d2f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x401dda='',_0x337995=null,_0x6fe768={'children':{},'childCount':0x0}){this['name']=_0x401dda,this['parent']=_0x337995,this['node']=_0x6fe768;}}function $n(_0x5c02c5,_0x31f0ff){let _0x27f10a=_0x31f0ff instanceof C?_0x31f0ff:new C(_0x31f0ff),_0x499412=_0x5c02c5,_0x4bd686=y(_0x27f10a);for(;_0x4bd686!==null;){const _0x4f1d45=Le(_0x499412['node']['children'],_0x4bd686)||{'children':{},'childCount':0x0};_0x499412=new _s(_0x4bd686,_0x499412,_0x4f1d45),_0x27f10a=S(_0x27f10a),_0x4bd686=y(_0x27f10a);}return _0x499412;}function je(_0xd163e4){return _0xd163e4['node']['value'];}function gs(_0x209586,_0x1462f7){_0x209586['node']['value']=_0x1462f7,Oi(_0x209586);}function na(_0x14f2a9){return _0x14f2a9['node']['childCount']>0x0;}function od(_0x26c1d7){return je(_0x26c1d7)===void 0x0&&!na(_0x26c1d7);}function Gn(_0x17b140,_0x508d36){x(_0x17b140['node']['children'],(_0x14c2d4,_0x6baf17)=>{_0x508d36(new _s(_0x14c2d4,_0x17b140,_0x6baf17));});}function ia(_0x332d6f,_0x1a5b7e,_0x3e4866,_0x1da824){_0x3e4866&&_0x1a5b7e(_0x332d6f),Gn(_0x332d6f,_0x50d694=>{ia(_0x50d694,_0x1a5b7e,!0x0);});}function ad(_0x4ebe53,_0x4da8fe,_0x1face7){let _0x2f952a=_0x4ebe53['parent'];for(;_0x2f952a!==null;){if(_0x4da8fe(_0x2f952a))return!0x0;_0x2f952a=_0x2f952a['parent'];}return!0x1;}function Qt(_0x285050){return new C(_0x285050['parent']===null?_0x285050['name']:Qt(_0x285050['parent'])+'/'+_0x285050['name']);}function Oi(_0x2a7086){_0x2a7086['parent']!==null&&cd(_0x2a7086['parent'],_0x2a7086['name'],_0x2a7086);}function cd(_0xf431eb,_0x584206,_0x31e808){const _0x4bd112=od(_0x31e808),_0x3475af=Q(_0xf431eb['node']['children'],_0x584206);_0x4bd112&&_0x3475af?(delete _0xf431eb['node']['children'][_0x584206],_0xf431eb['node']['childCount']--,Oi(_0xf431eb)):!_0x4bd112&&!_0x3475af&&(_0xf431eb['node']['children'][_0x584206]=_0x31e808['node'],_0xf431eb['node']['childCount']++,Oi(_0xf431eb));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x3b38aa){return typeof _0x3b38aa=='string'&&_0x3b38aa['length']!==0x0&&!ld['test'](_0x3b38aa);},sa=function(_0x4e3546){return typeof _0x4e3546=='string'&&_0x4e3546['length']!==0x0&&!hd['test'](_0x4e3546);},ud=function(_0x44106d){return _0x44106d&&(_0x44106d=_0x44106d['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x44106d);},Bt=function(_0x575cd9){return _0x575cd9===null||typeof _0x575cd9=='string'||typeof _0x575cd9=='number'&&!xn(_0x575cd9)||_0x575cd9&&typeof _0x575cd9=='object'&&Q(_0x575cd9,'.sv');},He=function(_0x51edb0,_0xfb2419,_0x223071,_0x1d8fce){_0x1d8fce&&_0xfb2419===void 0x0||Jt(it(_0x51edb0,'value'),_0xfb2419,_0x223071);},Jt=function(_0x5ad58d,_0x1e857f,_0x5bce0c){const _0x544413=_0x5bce0c instanceof C?new Ah(_0x5bce0c,_0x5ad58d):_0x5bce0c;if(_0x1e857f===void 0x0)throw new Error(_0x5ad58d+'contains\x20undefined\x20'+Oe(_0x544413));if(typeof _0x1e857f=='function')throw new Error(_0x5ad58d+'contains\x20a\x20function\x20'+Oe(_0x544413)+'\x20with\x20contents\x20=\x20'+_0x1e857f['toString']());if(xn(_0x1e857f))throw new Error(_0x5ad58d+'contains\x20'+_0x1e857f['toString']()+'\x20'+Oe(_0x544413));if(typeof _0x1e857f=='string'&&_0x1e857f['length']>ui/0x3&&Ln(_0x1e857f)>ui)throw new Error(_0x5ad58d+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x544413)+'\x20(\x27'+_0x1e857f['substring'](0x0,0x32)+'...\x27)');if(_0x1e857f&&typeof _0x1e857f=='object'){let _0x37c311=!0x1,_0x4457b9=!0x1;if(x(_0x1e857f,(_0x34ed76,_0xa8135a)=>{if(_0x34ed76==='.value')_0x37c311=!0x0;else{if(_0x34ed76!=='.priority'&&_0x34ed76!=='.sv'&&(_0x4457b9=!0x0,!ms(_0x34ed76)))throw new Error(_0x5ad58d+'\x20contains\x20an\x20invalid\x20key\x20('+_0x34ed76+')\x20'+Oe(_0x544413)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x544413,_0x34ed76),Jt(_0x5ad58d,_0xa8135a,_0x544413),Ph(_0x544413);}),_0x37c311&&_0x4457b9)throw new Error(_0x5ad58d+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x544413)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x2dd41b,_0x92b7db){let _0x46f94b,_0x56f13a;for(_0x46f94b=0x0;_0x46f94b<_0x92b7db['length'];_0x46f94b++){_0x56f13a=_0x92b7db[_0x46f94b];const _0x45ff6c=Mt(_0x56f13a);for(let _0x35e9f7=0x0;_0x35e9f7<_0x45ff6c['length'];_0x35e9f7++)if(!(_0x45ff6c[_0x35e9f7]==='.priority'&&_0x35e9f7===_0x45ff6c['length']-0x1)){if(!ms(_0x45ff6c[_0x35e9f7]))throw new Error(_0x2dd41b+'contains\x20an\x20invalid\x20key\x20('+_0x45ff6c[_0x35e9f7]+')\x20in\x20path\x20'+_0x56f13a['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x92b7db['sort'](Rh);let _0x3e44fa=null;for(_0x46f94b=0x0;_0x46f94b<_0x92b7db['length'];_0x46f94b++){if(_0x56f13a=_0x92b7db[_0x46f94b],_0x3e44fa!==null&&G(_0x3e44fa,_0x56f13a))throw new Error(_0x2dd41b+'contains\x20a\x20path\x20'+_0x3e44fa['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x56f13a['toString']());_0x3e44fa=_0x56f13a;}},ra=function(_0x50a20a,_0xbc8553,_0x3dc1bf,_0x2f3e04){const _0x407e6d=it(_0x50a20a,'values');if(!(_0xbc8553&&typeof _0xbc8553=='object')||Array['isArray'](_0xbc8553))throw new Error(_0x407e6d+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4d3dab=[];x(_0xbc8553,(_0x3a4ed1,_0x283cd8)=>{const _0x1f0500=new C(_0x3a4ed1);if(Jt(_0x407e6d,_0x283cd8,k(_0x3dc1bf,_0x1f0500)),ji(_0x1f0500)==='.priority'&&!Bt(_0x283cd8))throw new Error(_0x407e6d+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x1f0500['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4d3dab['push'](_0x1f0500);}),dd(_0x407e6d,_0x4d3dab);},fd=function(_0x1aba9f,_0x391b3e,_0x23d1ff){if(xn(_0x391b3e))throw new Error(it(_0x1aba9f,'priority')+'is\x20'+_0x391b3e['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x391b3e))throw new Error(it(_0x1aba9f,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x318ad6,_0x2f0135,_0x9aa5f4,_0x4f9836){if(!sa(_0x9aa5f4))throw new Error(it(_0x318ad6,_0x2f0135)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x9aa5f4+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x1e3719,_0x3ad76c,_0x4272e8,_0x4f3d1e){_0x4272e8&&(_0x4272e8=_0x4272e8['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x1e3719,_0x3ad76c,_0x4272e8);},Me=function(_0x5b9362,_0x6be411){if(y(_0x6be411)==='.info')throw new Error(_0x5b9362+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x19c9bb,_0x3f0648){const _0x495361=_0x3f0648['path']['toString']();if(typeof _0x3f0648['repoInfo']['host']!='string'||_0x3f0648['repoInfo']['host']['length']===0x0||!ms(_0x3f0648['repoInfo']['namespace'])&&_0x3f0648['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x495361['length']!==0x0&&!ud(_0x495361))throw new Error(it(_0x19c9bb,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x514187,_0x2dd5b2){let _0x5cebe5=null;for(let _0x5e2340=0x0;_0x5e2340<_0x2dd5b2['length'];_0x5e2340++){const _0x1ee336=_0x2dd5b2[_0x5e2340],_0x4a5971=_0x1ee336['getPath']();_0x5cebe5!==null&&!Ki(_0x4a5971,_0x5cebe5['path'])&&(_0x514187['eventLists_']['push'](_0x5cebe5),_0x5cebe5=null),_0x5cebe5===null&&(_0x5cebe5={'events':[],'path':_0x4a5971}),_0x5cebe5['events']['push'](_0x1ee336);}_0x5cebe5&&_0x514187['eventLists_']['push'](_0x5cebe5);}function oa(_0x1d2e64,_0x4d0f62,_0x54f748){qn(_0x1d2e64,_0x54f748),aa(_0x1d2e64,_0x1c8d3d=>Ki(_0x1c8d3d,_0x4d0f62));}function V(_0x361524,_0x24ff91,_0x26c118){qn(_0x361524,_0x26c118),aa(_0x361524,_0x2be237=>G(_0x2be237,_0x24ff91)||G(_0x24ff91,_0x2be237));}function aa(_0x1ebc59,_0x35a6ca){_0x1ebc59['recursionDepth_']++;let _0x3f0c8b=!0x0;for(let _0x2ba726=0x0;_0x2ba726<_0x1ebc59['eventLists_']['length'];_0x2ba726++){const _0xcf60f5=_0x1ebc59['eventLists_'][_0x2ba726];if(_0xcf60f5){const _0x4ceab9=_0xcf60f5['path'];_0x35a6ca(_0x4ceab9)?(md(_0x1ebc59['eventLists_'][_0x2ba726]),_0x1ebc59['eventLists_'][_0x2ba726]=null):_0x3f0c8b=!0x1;}}_0x3f0c8b&&(_0x1ebc59['eventLists_']=[]),_0x1ebc59['recursionDepth_']--;}function md(_0x2cd26d){for(let _0x1d28a9=0x0;_0x1d28a9<_0x2cd26d['events']['length'];_0x1d28a9++){const _0xf09c08=_0x2cd26d['events'][_0x1d28a9];if(_0xf09c08!==null){_0x2cd26d['events'][_0x1d28a9]=null;const _0x4e56fd=_0xf09c08['getEventRunner']();St&&L('event:\x20'+_0xf09c08['toString']()),ft(_0x4e56fd);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x560beb,_0x5c2a15,_0x297027,_0xa458df){this['repoInfo_']=_0x560beb,this['forceRestClient_']=_0x5c2a15,this['authTokenProvider_']=_0x297027,this['appCheckProvider_']=_0xa458df,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x68400d,_0x1d7a9f,_0x91fd68){if(_0x68400d['stats_']=qi(_0x68400d['repoInfo_']),_0x68400d['forceRestClient_']||Xl())_0x68400d['server_']=new vn(_0x68400d['repoInfo_'],(_0x2d2c61,_0x5a11c4,_0x33d3f9,_0x3ab96d)=>{gr(_0x68400d,_0x2d2c61,_0x5a11c4,_0x33d3f9,_0x3ab96d);},_0x68400d['authTokenProvider_'],_0x68400d['appCheckProvider_']),setTimeout(()=>mr(_0x68400d,!0x0),0x0);else{if(typeof _0x91fd68<'u'&&_0x91fd68!==null){if(typeof _0x91fd68!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x91fd68);}catch(_0x1f6618){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1f6618);}}_0x68400d['persistentConnection_']=new se(_0x68400d['repoInfo_'],_0x1d7a9f,(_0x4637e9,_0x89aa31,_0x3a58cc,_0x6f8f0e)=>{gr(_0x68400d,_0x4637e9,_0x89aa31,_0x3a58cc,_0x6f8f0e);},_0x1638b0=>{mr(_0x68400d,_0x1638b0);},_0x23c782=>{Id(_0x68400d,_0x23c782);},_0x68400d['authTokenProvider_'],_0x68400d['appCheckProvider_'],_0x91fd68),_0x68400d['server_']=_0x68400d['persistentConnection_'];}_0x68400d['authTokenProvider_']['addTokenChangeListener'](_0x5aa75a=>{_0x68400d['server_']['refreshAuthToken'](_0x5aa75a);}),_0x68400d['appCheckProvider_']['addTokenChangeListener'](_0x3ccf57=>{_0x68400d['server_']['refreshAppCheckToken'](_0x3ccf57['token']);}),_0x68400d['statsReporter_']=ih(_0x68400d['repoInfo_'],()=>new iu(_0x68400d['stats_'],_0x68400d['server_'])),_0x68400d['infoData_']=new Xh(),_0x68400d['infoSyncTree_']=new pr({'startListening':(_0xe5d5fc,_0x2b6f99,_0x52717d,_0x1fb3b9)=>{let _0x3e07ef=[];const _0x47824c=_0x68400d['infoData_']['getNode'](_0xe5d5fc['_path']);return _0x47824c['isEmpty']()||(_0x3e07ef=Yt(_0x68400d['infoSyncTree_'],_0xe5d5fc['_path'],_0x47824c),setTimeout(()=>{_0x1fb3b9('ok');},0x0)),_0x3e07ef;},'stopListening':()=>{}}),vs(_0x68400d,'connected',!0x1),_0x68400d['serverSyncTree_']=new pr({'startListening':(_0x3518b0,_0x2c5e38,_0x54139f,_0x4004e2)=>(_0x68400d['server_']['listen'](_0x3518b0,_0x54139f,_0x2c5e38,(_0x760de9,_0x4bd26b)=>{const _0x5c2704=_0x4004e2(_0x760de9,_0x4bd26b);V(_0x68400d['eventQueue_'],_0x3518b0['_path'],_0x5c2704);}),[]),'stopListening':(_0x4cd882,_0x5e15e8)=>{_0x68400d['server_']['unlisten'](_0x4cd882,_0x5e15e8);}});}function la(_0x16397a){const _0x17271d=_0x16397a['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x17271d;}function Xt(_0x13bb6b){return id({'timestamp':la(_0x13bb6b)});}function gr(_0x2eb88a,_0x1986b2,_0x2df634,_0x36b95f,_0x2c15f8){_0x2eb88a['dataUpdateCount']++;const _0xa2f8f5=new C(_0x1986b2);_0x2df634=_0x2eb88a['interceptServerDataCallback_']?_0x2eb88a['interceptServerDataCallback_'](_0x1986b2,_0x2df634):_0x2df634;let _0x3f8b5b=[];if(_0x2c15f8){if(_0x36b95f){const _0x425753=_n(_0x2df634,_0x52a74f=>A(_0x52a74f));_0x3f8b5b=Ju(_0x2eb88a['serverSyncTree_'],_0xa2f8f5,_0x425753,_0x2c15f8);}else{const _0x28c6cd=A(_0x2df634);_0x3f8b5b=Jo(_0x2eb88a['serverSyncTree_'],_0xa2f8f5,_0x28c6cd,_0x2c15f8);}}else{if(_0x36b95f){const _0x2b5de4=_n(_0x2df634,_0x1746cc=>A(_0x1746cc));_0x3f8b5b=Ku(_0x2eb88a['serverSyncTree_'],_0xa2f8f5,_0x2b5de4);}else{const _0x1fc528=A(_0x2df634);_0x3f8b5b=Yt(_0x2eb88a['serverSyncTree_'],_0xa2f8f5,_0x1fc528);}}let _0xe18883=_0xa2f8f5;_0x3f8b5b['length']>0x0&&(_0xe18883=ct(_0x2eb88a,_0xa2f8f5)),V(_0x2eb88a['eventQueue_'],_0xe18883,_0x3f8b5b);}function mr(_0x3d5ac9,_0x28c183){vs(_0x3d5ac9,'connected',_0x28c183),_0x28c183===!0x1&&Sd(_0x3d5ac9);}function Id(_0x1a9c86,_0x40646e){x(_0x40646e,(_0x22bbbd,_0x1a63b8)=>{vs(_0x1a9c86,_0x22bbbd,_0x1a63b8);});}function vs(_0x2c17d0,_0x45ed58,_0x251867){const _0x301dd6=new C('/.info/'+_0x45ed58),_0x2a4881=A(_0x251867);_0x2c17d0['infoData_']['updateSnapshot'](_0x301dd6,_0x2a4881);const _0x5863ad=Yt(_0x2c17d0['infoSyncTree_'],_0x301dd6,_0x2a4881);V(_0x2c17d0['eventQueue_'],_0x301dd6,_0x5863ad);}function zn(_0x221080){return _0x221080['nextWriteId_']++;}function wd(_0x3d6d25,_0x368f3b,_0x20e2f1){const _0x15d970=Xu(_0x3d6d25['serverSyncTree_'],_0x368f3b);return _0x15d970!=null?Promise['resolve'](_0x15d970):_0x3d6d25['server_']['get'](_0x368f3b)['then'](_0x35e3b9=>{const _0x27a7ee=A(_0x35e3b9)['withIndex'](_0x368f3b['_queryParams']['getIndex']());Ni(_0x3d6d25['serverSyncTree_'],_0x368f3b,_0x20e2f1,!0x0);let _0x194867;if(_0x368f3b['_queryParams']['loadsAllData']())_0x194867=Yt(_0x3d6d25['serverSyncTree_'],_0x368f3b['_path'],_0x27a7ee);else{const _0x411d2e=Wt(_0x3d6d25['serverSyncTree_'],_0x368f3b);_0x194867=Jo(_0x3d6d25['serverSyncTree_'],_0x368f3b['_path'],_0x27a7ee,_0x411d2e);}return V(_0x3d6d25['eventQueue_'],_0x368f3b['_path'],_0x194867),An(_0x3d6d25['serverSyncTree_'],_0x368f3b,_0x20e2f1,null,!0x0),_0x27a7ee;},_0x3d9b14=>(gt(_0x3d6d25,'get\x20for\x20query\x20'+O(_0x368f3b)+'\x20failed:\x20'+_0x3d9b14),Promise['reject'](new Error(_0x3d9b14))));}function Cd(_0x2556c7,_0x3dd0d3,_0x313b4d,_0x4ab77a,_0x4693e1){gt(_0x2556c7,'set',{'path':_0x3dd0d3['toString'](),'value':_0x313b4d,'priority':_0x4ab77a});const _0x16baa6=Xt(_0x2556c7),_0xf9ad20=A(_0x313b4d,_0x4ab77a),_0x27348b=Vn(_0x2556c7['serverSyncTree_'],_0x3dd0d3),_0x44f89b=fs(_0xf9ad20,_0x27348b,_0x16baa6),_0x531b92=zn(_0x2556c7),_0xd0a68a=as(_0x2556c7['serverSyncTree_'],_0x3dd0d3,_0x44f89b,_0x531b92,!0x0);qn(_0x2556c7['eventQueue_'],_0xd0a68a),_0x2556c7['server_']['put'](_0x3dd0d3['toString'](),_0xf9ad20['val'](!0x0),(_0x57c48f,_0x44f4f1)=>{const _0x3976bd=_0x57c48f==='ok';_0x3976bd||U('set\x20at\x20'+_0x3dd0d3+'\x20failed:\x20'+_0x57c48f);const _0x4b739d=_e(_0x2556c7['serverSyncTree_'],_0x531b92,!_0x3976bd);V(_0x2556c7['eventQueue_'],_0x3dd0d3,_0x4b739d),be(_0x2556c7,_0x4693e1,_0x57c48f,_0x44f4f1);});const _0x2c3919=Is(_0x2556c7,_0x3dd0d3);ct(_0x2556c7,_0x2c3919),V(_0x2556c7['eventQueue_'],_0x2c3919,[]);}function Td(_0x57d08b,_0x272169,_0x12eb9e,_0x655aa7){gt(_0x57d08b,'update',{'path':_0x272169['toString'](),'value':_0x12eb9e});let _0x3a8bcb=!0x0;const _0x19f681=Xt(_0x57d08b),_0x94cdfd={};if(x(_0x12eb9e,(_0x43bb06,_0x178ffd)=>{_0x3a8bcb=!0x1,_0x94cdfd[_0x43bb06]=ta(k(_0x272169,_0x43bb06),A(_0x178ffd),_0x57d08b['serverSyncTree_'],_0x19f681);}),_0x3a8bcb)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x57d08b,_0x655aa7,'ok',void 0x0);else{const _0x3628bd=zn(_0x57d08b),_0x1c6110=ju(_0x57d08b['serverSyncTree_'],_0x272169,_0x94cdfd,_0x3628bd);qn(_0x57d08b['eventQueue_'],_0x1c6110),_0x57d08b['server_']['merge'](_0x272169['toString'](),_0x12eb9e,(_0x19eba3,_0x15020e)=>{const _0x538d75=_0x19eba3==='ok';_0x538d75||U('update\x20at\x20'+_0x272169+'\x20failed:\x20'+_0x19eba3);const _0x397951=_e(_0x57d08b['serverSyncTree_'],_0x3628bd,!_0x538d75),_0x1df0f7=_0x397951['length']>0x0?ct(_0x57d08b,_0x272169):_0x272169;V(_0x57d08b['eventQueue_'],_0x1df0f7,_0x397951),be(_0x57d08b,_0x655aa7,_0x19eba3,_0x15020e);}),x(_0x12eb9e,_0x3f302d=>{const _0x41530a=Is(_0x57d08b,k(_0x272169,_0x3f302d));ct(_0x57d08b,_0x41530a);}),V(_0x57d08b['eventQueue_'],_0x272169,[]);}}function Sd(_0x3af88b){gt(_0x3af88b,'onDisconnectEvents');const _0x4ffeec=Xt(_0x3af88b),_0x2e6765=En();Si(_0x3af88b['onDisconnect_'],w(),(_0x515810,_0x485c84)=>{const _0x13df3a=ta(_0x515810,_0x485c84,_0x3af88b['serverSyncTree_'],_0x4ffeec);pt(_0x2e6765,_0x515810,_0x13df3a);});let _0xa27f4c=[];Si(_0x2e6765,w(),(_0x289aed,_0x16e07f)=>{_0xa27f4c=_0xa27f4c['concat'](Yt(_0x3af88b['serverSyncTree_'],_0x289aed,_0x16e07f));const _0x542ffa=Is(_0x3af88b,_0x289aed);ct(_0x3af88b,_0x542ffa);}),_0x3af88b['onDisconnect_']=En(),V(_0x3af88b['eventQueue_'],w(),_0xa27f4c);}function bd(_0x93cef5,_0x2df43f,_0x56ffcd){_0x93cef5['server_']['onDisconnectCancel'](_0x2df43f['toString'](),(_0x4d568f,_0x54bddf)=>{_0x4d568f==='ok'&&Ti(_0x93cef5['onDisconnect_'],_0x2df43f),be(_0x93cef5,_0x56ffcd,_0x4d568f,_0x54bddf);});}function yr(_0x417c56,_0x4bc957,_0x2975c7,_0x16cafd){const _0x46690f=A(_0x2975c7);_0x417c56['server_']['onDisconnectPut'](_0x4bc957['toString'](),_0x46690f['val'](!0x0),(_0x7615a7,_0x1a32e2)=>{_0x7615a7==='ok'&&pt(_0x417c56['onDisconnect_'],_0x4bc957,_0x46690f),be(_0x417c56,_0x16cafd,_0x7615a7,_0x1a32e2);});}function Rd(_0x2cf7c4,_0xd42b70,_0x2b9633,_0x30579a,_0x39d1e7){const _0x3788af=A(_0x2b9633,_0x30579a);_0x2cf7c4['server_']['onDisconnectPut'](_0xd42b70['toString'](),_0x3788af['val'](!0x0),(_0x5e6ead,_0x4e11c5)=>{_0x5e6ead==='ok'&&pt(_0x2cf7c4['onDisconnect_'],_0xd42b70,_0x3788af),be(_0x2cf7c4,_0x39d1e7,_0x5e6ead,_0x4e11c5);});}function Ad(_0x19f602,_0x573c90,_0x3fbe64,_0x248907){if(pn(_0x3fbe64)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x19f602,_0x248907,'ok',void 0x0);return;}_0x19f602['server_']['onDisconnectMerge'](_0x573c90['toString'](),_0x3fbe64,(_0x38151e,_0x2af769)=>{_0x38151e==='ok'&&x(_0x3fbe64,(_0x1dcdb1,_0x108224)=>{const _0x415c0b=A(_0x108224);pt(_0x19f602['onDisconnect_'],k(_0x573c90,_0x1dcdb1),_0x415c0b);}),be(_0x19f602,_0x248907,_0x38151e,_0x2af769);});}function kd(_0x290599,_0x1591bb,_0x252b6c){let _0x2aa5da;y(_0x1591bb['_path'])==='.info'?_0x2aa5da=Ni(_0x290599['infoSyncTree_'],_0x1591bb,_0x252b6c):_0x2aa5da=Ni(_0x290599['serverSyncTree_'],_0x1591bb,_0x252b6c),oa(_0x290599['eventQueue_'],_0x1591bb['_path'],_0x2aa5da);}function Pd(_0x247f65,_0x258d41,_0x2f30cc){let _0x3b2a35;y(_0x258d41['_path'])==='.info'?_0x3b2a35=An(_0x247f65['infoSyncTree_'],_0x258d41,_0x2f30cc):_0x3b2a35=An(_0x247f65['serverSyncTree_'],_0x258d41,_0x2f30cc),oa(_0x247f65['eventQueue_'],_0x258d41['_path'],_0x3b2a35);}function ha(_0x4d47e1){_0x4d47e1['persistentConnection_']&&_0x4d47e1['persistentConnection_']['interrupt'](ca);}function Nd(_0x28fc23){_0x28fc23['persistentConnection_']&&_0x28fc23['persistentConnection_']['resume'](ca);}function gt(_0x136a64,..._0x4f747a){let _0x19d996='';_0x136a64['persistentConnection_']&&(_0x19d996=_0x136a64['persistentConnection_']['id']+':'),L(_0x19d996,..._0x4f747a);}function be(_0x18f879,_0x262706,_0x59d628,_0x4d8480){_0x262706&&ft(()=>{if(_0x59d628==='ok')_0x262706(null);else{const _0x274a2b=(_0x59d628||'error')['toUpperCase']();let _0x23a427=_0x274a2b;_0x4d8480&&(_0x23a427+=':\x20'+_0x4d8480);const _0x45d955=new Error(_0x23a427);_0x45d955['code']=_0x274a2b,_0x262706(_0x45d955);}});}function Od(_0x4bdb61,_0x1a95ec,_0x2d6aaa,_0x56b8ee,_0x32e0c7,_0x4ca94c){gt(_0x4bdb61,'transaction\x20on\x20'+_0x1a95ec);const _0x3309aa={'path':_0x1a95ec,'update':_0x2d6aaa,'onComplete':_0x56b8ee,'status':null,'order':so(),'applyLocally':_0x4ca94c,'retryCount':0x0,'unwatcher':_0x32e0c7,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5896a8=Es(_0x4bdb61,_0x1a95ec,void 0x0);_0x3309aa['currentInputSnapshot']=_0x5896a8;const _0x56dc51=_0x3309aa['update'](_0x5896a8['val']());if(_0x56dc51===void 0x0)_0x3309aa['unwatcher'](),_0x3309aa['currentOutputSnapshotRaw']=null,_0x3309aa['currentOutputSnapshotResolved']=null,_0x3309aa['onComplete']&&_0x3309aa['onComplete'](null,!0x1,_0x3309aa['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x56dc51,_0x3309aa['path']),_0x3309aa['status']=0x0;const _0x5bd0cb=$n(_0x4bdb61['transactionQueueTree_'],_0x1a95ec),_0x1552b7=je(_0x5bd0cb)||[];_0x1552b7['push'](_0x3309aa),gs(_0x5bd0cb,_0x1552b7);let _0x5e8cd0;typeof _0x56dc51=='object'&&_0x56dc51!==null&&Q(_0x56dc51,'.priority')?(_0x5e8cd0=Le(_0x56dc51,'.priority'),f(Bt(_0x5e8cd0),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5e8cd0=(Vn(_0x4bdb61['serverSyncTree_'],_0x1a95ec)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x550137=Xt(_0x4bdb61),_0xb4e911=A(_0x56dc51,_0x5e8cd0),_0x1a066b=fs(_0xb4e911,_0x5896a8,_0x550137);_0x3309aa['currentOutputSnapshotRaw']=_0xb4e911,_0x3309aa['currentOutputSnapshotResolved']=_0x1a066b,_0x3309aa['currentWriteId']=zn(_0x4bdb61);const _0x3c6bac=as(_0x4bdb61['serverSyncTree_'],_0x1a95ec,_0x1a066b,_0x3309aa['currentWriteId'],_0x3309aa['applyLocally']);V(_0x4bdb61['eventQueue_'],_0x1a95ec,_0x3c6bac),jn(_0x4bdb61,_0x4bdb61['transactionQueueTree_']);}}function Es(_0x516322,_0xaf1d89,_0x5e930a){return Vn(_0x516322['serverSyncTree_'],_0xaf1d89,_0x5e930a)||g['EMPTY_NODE'];}function jn(_0x200e57,_0x558860=_0x200e57['transactionQueueTree_']){if(_0x558860||Kn(_0x200e57,_0x558860),je(_0x558860)){const _0x523dba=da(_0x200e57,_0x558860);f(_0x523dba['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x523dba['every'](_0x54ea95=>_0x54ea95['status']===0x0)&&Dd(_0x200e57,Qt(_0x558860),_0x523dba);}else na(_0x558860)&&Gn(_0x558860,_0x4a65ce=>{jn(_0x200e57,_0x4a65ce);});}function Dd(_0x101832,_0x4c62af,_0x172a64){const _0x206548=_0x172a64['map'](_0x82f849=>_0x82f849['currentWriteId']),_0x338a52=Es(_0x101832,_0x4c62af,_0x206548);let _0x5ad6a5=_0x338a52;const _0x735997=_0x338a52['hash']();for(let _0x234210=0x0;_0x234210<_0x172a64['length'];_0x234210++){const _0x24f02c=_0x172a64[_0x234210];f(_0x24f02c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x24f02c['status']=0x1,_0x24f02c['retryCount']++;const _0x4b599f=F(_0x4c62af,_0x24f02c['path']);_0x5ad6a5=_0x5ad6a5['updateChild'](_0x4b599f,_0x24f02c['currentOutputSnapshotRaw']);}const _0x57f9af=_0x5ad6a5['val'](!0x0),_0x2e20cf=_0x4c62af;_0x101832['server_']['put'](_0x2e20cf['toString'](),_0x57f9af,_0x48205d=>{gt(_0x101832,'transaction\x20put\x20response',{'path':_0x2e20cf['toString'](),'status':_0x48205d});let _0x25d1e8=[];if(_0x48205d==='ok'){const _0x2056bd=[];for(let _0x1f2bdd=0x0;_0x1f2bdd<_0x172a64['length'];_0x1f2bdd++)_0x172a64[_0x1f2bdd]['status']=0x2,_0x25d1e8=_0x25d1e8['concat'](_e(_0x101832['serverSyncTree_'],_0x172a64[_0x1f2bdd]['currentWriteId'])),_0x172a64[_0x1f2bdd]['onComplete']&&_0x2056bd['push'](()=>_0x172a64[_0x1f2bdd]['onComplete'](null,!0x0,_0x172a64[_0x1f2bdd]['currentOutputSnapshotResolved'])),_0x172a64[_0x1f2bdd]['unwatcher']();Kn(_0x101832,$n(_0x101832['transactionQueueTree_'],_0x4c62af)),jn(_0x101832,_0x101832['transactionQueueTree_']),V(_0x101832['eventQueue_'],_0x4c62af,_0x25d1e8);for(let _0x1a326e=0x0;_0x1a326e<_0x2056bd['length'];_0x1a326e++)ft(_0x2056bd[_0x1a326e]);}else{if(_0x48205d==='datastale'){for(let _0x1c8e81=0x0;_0x1c8e81<_0x172a64['length'];_0x1c8e81++)_0x172a64[_0x1c8e81]['status']===0x3?_0x172a64[_0x1c8e81]['status']=0x4:_0x172a64[_0x1c8e81]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2e20cf['toString']()+'\x20failed:\x20'+_0x48205d);for(let _0x1746b2=0x0;_0x1746b2<_0x172a64['length'];_0x1746b2++)_0x172a64[_0x1746b2]['status']=0x4,_0x172a64[_0x1746b2]['abortReason']=_0x48205d;}ct(_0x101832,_0x4c62af);}},_0x735997);}function ct(_0x5b0390,_0x46844b){const _0x2e1811=ua(_0x5b0390,_0x46844b),_0x3a4e43=Qt(_0x2e1811),_0x1fd024=da(_0x5b0390,_0x2e1811);return Md(_0x5b0390,_0x1fd024,_0x3a4e43),_0x3a4e43;}function Md(_0xe6f31a,_0x3355ce,_0x43864f){if(_0x3355ce['length']===0x0)return;const _0x732cf6=[];let _0x30d513=[];const _0x519107=_0x3355ce['filter'](_0x56e5c6=>_0x56e5c6['status']===0x0)['map'](_0x34cf0f=>_0x34cf0f['currentWriteId']);for(let _0x50afca=0x0;_0x50afca<_0x3355ce['length'];_0x50afca++){const _0x31c31d=_0x3355ce[_0x50afca],_0x4b3309=F(_0x43864f,_0x31c31d['path']);let _0xe7303f=!0x1,_0x28d39e;if(f(_0x4b3309!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x31c31d['status']===0x4)_0xe7303f=!0x0,_0x28d39e=_0x31c31d['abortReason'],_0x30d513=_0x30d513['concat'](_e(_0xe6f31a['serverSyncTree_'],_0x31c31d['currentWriteId'],!0x0));else{if(_0x31c31d['status']===0x0){if(_0x31c31d['retryCount']>=yd)_0xe7303f=!0x0,_0x28d39e='maxretry',_0x30d513=_0x30d513['concat'](_e(_0xe6f31a['serverSyncTree_'],_0x31c31d['currentWriteId'],!0x0));else{const _0x4f5423=Es(_0xe6f31a,_0x31c31d['path'],_0x519107);_0x31c31d['currentInputSnapshot']=_0x4f5423;const _0x922b2e=_0x3355ce[_0x50afca]['update'](_0x4f5423['val']());if(_0x922b2e!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x922b2e,_0x31c31d['path']);let _0x20b78b=A(_0x922b2e);typeof _0x922b2e=='object'&&_0x922b2e!=null&&Q(_0x922b2e,'.priority')||(_0x20b78b=_0x20b78b['updatePriority'](_0x4f5423['getPriority']()));const _0x50464d=_0x31c31d['currentWriteId'],_0x49fe00=Xt(_0xe6f31a),_0x404d6f=fs(_0x20b78b,_0x4f5423,_0x49fe00);_0x31c31d['currentOutputSnapshotRaw']=_0x20b78b,_0x31c31d['currentOutputSnapshotResolved']=_0x404d6f,_0x31c31d['currentWriteId']=zn(_0xe6f31a),_0x519107['splice'](_0x519107['indexOf'](_0x50464d),0x1),_0x30d513=_0x30d513['concat'](as(_0xe6f31a['serverSyncTree_'],_0x31c31d['path'],_0x404d6f,_0x31c31d['currentWriteId'],_0x31c31d['applyLocally'])),_0x30d513=_0x30d513['concat'](_e(_0xe6f31a['serverSyncTree_'],_0x50464d,!0x0));}else _0xe7303f=!0x0,_0x28d39e='nodata',_0x30d513=_0x30d513['concat'](_e(_0xe6f31a['serverSyncTree_'],_0x31c31d['currentWriteId'],!0x0));}}}V(_0xe6f31a['eventQueue_'],_0x43864f,_0x30d513),_0x30d513=[],_0xe7303f&&(_0x3355ce[_0x50afca]['status']=0x2,function(_0xc43740){setTimeout(_0xc43740,Math['floor'](0x0));}(_0x3355ce[_0x50afca]['unwatcher']),_0x3355ce[_0x50afca]['onComplete']&&(_0x28d39e==='nodata'?_0x732cf6['push'](()=>_0x3355ce[_0x50afca]['onComplete'](null,!0x1,_0x3355ce[_0x50afca]['currentInputSnapshot'])):_0x732cf6['push'](()=>_0x3355ce[_0x50afca]['onComplete'](new Error(_0x28d39e),!0x1,null))));}Kn(_0xe6f31a,_0xe6f31a['transactionQueueTree_']);for(let _0x62e18=0x0;_0x62e18<_0x732cf6['length'];_0x62e18++)ft(_0x732cf6[_0x62e18]);jn(_0xe6f31a,_0xe6f31a['transactionQueueTree_']);}function ua(_0x180b75,_0x4b35e5){let _0x441e3f,_0x336811=_0x180b75['transactionQueueTree_'];for(_0x441e3f=y(_0x4b35e5);_0x441e3f!==null&&je(_0x336811)===void 0x0;)_0x336811=$n(_0x336811,_0x441e3f),_0x4b35e5=S(_0x4b35e5),_0x441e3f=y(_0x4b35e5);return _0x336811;}function da(_0xb25d,_0x2da8a2){const _0x41b4d0=[];return fa(_0xb25d,_0x2da8a2,_0x41b4d0),_0x41b4d0['sort']((_0x11db40,_0xaa34ab)=>_0x11db40['order']-_0xaa34ab['order']),_0x41b4d0;}function fa(_0x3876b8,_0x338339,_0x38e9f6){const _0x542138=je(_0x338339);if(_0x542138){for(let _0x28c68b=0x0;_0x28c68b<_0x542138['length'];_0x28c68b++)_0x38e9f6['push'](_0x542138[_0x28c68b]);}Gn(_0x338339,_0x5f432e=>{fa(_0x3876b8,_0x5f432e,_0x38e9f6);});}function Kn(_0x55ef6c,_0x3f2512){const _0x486124=je(_0x3f2512);if(_0x486124){let _0xb52de0=0x0;for(let _0x130a1b=0x0;_0x130a1b<_0x486124['length'];_0x130a1b++)_0x486124[_0x130a1b]['status']!==0x2&&(_0x486124[_0xb52de0]=_0x486124[_0x130a1b],_0xb52de0++);_0x486124['length']=_0xb52de0,gs(_0x3f2512,_0x486124['length']>0x0?_0x486124:void 0x0);}Gn(_0x3f2512,_0x248da5=>{Kn(_0x55ef6c,_0x248da5);});}function Is(_0x5d2b18,_0x1a8dc5){const _0x555ae7=Qt(ua(_0x5d2b18,_0x1a8dc5)),_0x272814=$n(_0x5d2b18['transactionQueueTree_'],_0x1a8dc5);return ad(_0x272814,_0x2b1d0a=>{di(_0x5d2b18,_0x2b1d0a);}),di(_0x5d2b18,_0x272814),ia(_0x272814,_0x12bad9=>{di(_0x5d2b18,_0x12bad9);}),_0x555ae7;}function di(_0x23eb89,_0x118e94){const _0x1820fb=je(_0x118e94);if(_0x1820fb){const _0x692e6=[];let _0x46ca8d=[],_0x349cf9=-0x1;for(let _0x1e4c14=0x0;_0x1e4c14<_0x1820fb['length'];_0x1e4c14++)_0x1820fb[_0x1e4c14]['status']===0x3||(_0x1820fb[_0x1e4c14]['status']===0x1?(f(_0x349cf9===_0x1e4c14-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x349cf9=_0x1e4c14,_0x1820fb[_0x1e4c14]['status']=0x3,_0x1820fb[_0x1e4c14]['abortReason']='set'):(f(_0x1820fb[_0x1e4c14]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x1820fb[_0x1e4c14]['unwatcher'](),_0x46ca8d=_0x46ca8d['concat'](_e(_0x23eb89['serverSyncTree_'],_0x1820fb[_0x1e4c14]['currentWriteId'],!0x0)),_0x1820fb[_0x1e4c14]['onComplete']&&_0x692e6['push'](_0x1820fb[_0x1e4c14]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x349cf9===-0x1?gs(_0x118e94,void 0x0):_0x1820fb['length']=_0x349cf9+0x1,V(_0x23eb89['eventQueue_'],Qt(_0x118e94),_0x46ca8d);for(let _0x28cdfd=0x0;_0x28cdfd<_0x692e6['length'];_0x28cdfd++)ft(_0x692e6[_0x28cdfd]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x2b5e61){let _0x2424da='';const _0x856676=_0x2b5e61['split']('/');for(let _0x4cc337=0x0;_0x4cc337<_0x856676['length'];_0x4cc337++)if(_0x856676[_0x4cc337]['length']>0x0){let _0x5674ed=_0x856676[_0x4cc337];try{_0x5674ed=decodeURIComponent(_0x5674ed['replace'](/\+/g,'\x20'));}catch{}_0x2424da+='/'+_0x5674ed;}return _0x2424da;}function xd(_0x47acbe){const _0x3d1362={};_0x47acbe['charAt'](0x0)==='?'&&(_0x47acbe=_0x47acbe['substring'](0x1));for(const _0x1ff4e0 of _0x47acbe['split']('&')){if(_0x1ff4e0['length']===0x0)continue;const _0x119145=_0x1ff4e0['split']('=');_0x119145['length']===0x2?_0x3d1362[decodeURIComponent(_0x119145[0x0])]=decodeURIComponent(_0x119145[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1ff4e0+'\x27\x20in\x20query\x20\x27'+_0x47acbe+'\x27');}return _0x3d1362;}const vr=function(_0x3685ce,_0x2ccd0a){const _0x5d2a37=Fd(_0x3685ce),_0x4d8ec1=_0x5d2a37['namespace'];_0x5d2a37['domain']==='firebase.com'&&ae(_0x5d2a37['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4d8ec1||_0x4d8ec1==='undefined')&&_0x5d2a37['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x5d2a37['secure']||$l();const _0x2a2472=_0x5d2a37['scheme']==='ws'||_0x5d2a37['scheme']==='wss';return{'repoInfo':new yo(_0x5d2a37['host'],_0x5d2a37['secure'],_0x4d8ec1,_0x2a2472,_0x2ccd0a,'',_0x4d8ec1!==_0x5d2a37['subdomain']),'path':new C(_0x5d2a37['pathString'])};},Fd=function(_0x2d7970){let _0x2771a0='',_0x2093ec='',_0x1248d8='',_0x349cd2='',_0x2af56c='',_0x12141f=!0x0,_0x1ab497='https',_0x9056a5=0x1bb;if(typeof _0x2d7970=='string'){let _0x19a30a=_0x2d7970['indexOf']('//');_0x19a30a>=0x0&&(_0x1ab497=_0x2d7970['substring'](0x0,_0x19a30a-0x1),_0x2d7970=_0x2d7970['substring'](_0x19a30a+0x2));let _0x13f8fb=_0x2d7970['indexOf']('/');_0x13f8fb===-0x1&&(_0x13f8fb=_0x2d7970['length']);let _0x39f5fc=_0x2d7970['indexOf']('?');_0x39f5fc===-0x1&&(_0x39f5fc=_0x2d7970['length']),_0x2771a0=_0x2d7970['substring'](0x0,Math['min'](_0x13f8fb,_0x39f5fc)),_0x13f8fb<_0x39f5fc&&(_0x349cd2=Ld(_0x2d7970['substring'](_0x13f8fb,_0x39f5fc)));const _0x2fd392=xd(_0x2d7970['substring'](Math['min'](_0x2d7970['length'],_0x39f5fc)));_0x19a30a=_0x2771a0['indexOf'](':'),_0x19a30a>=0x0?(_0x12141f=_0x1ab497==='https'||_0x1ab497==='wss',_0x9056a5=parseInt(_0x2771a0['substring'](_0x19a30a+0x1),0xa)):_0x19a30a=_0x2771a0['length'];const _0x2c8147=_0x2771a0['slice'](0x0,_0x19a30a);if(_0x2c8147['toLowerCase']()==='localhost')_0x2093ec='localhost';else{if(_0x2c8147['split']('.')['length']<=0x2)_0x2093ec=_0x2c8147;else{const _0x332340=_0x2771a0['indexOf']('.');_0x1248d8=_0x2771a0['substring'](0x0,_0x332340)['toLowerCase'](),_0x2093ec=_0x2771a0['substring'](_0x332340+0x1),_0x2af56c=_0x1248d8;}}'ns'in _0x2fd392&&(_0x2af56c=_0x2fd392['ns']);}return{'host':_0x2771a0,'port':_0x9056a5,'domain':_0x2093ec,'subdomain':_0x1248d8,'secure':_0x12141f,'scheme':_0x1ab497,'pathString':_0x349cd2,'namespace':_0x2af56c};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x3cd933=0x0;const _0x1fa821=[];return function(_0x22bfbd){const _0x258c82=_0x22bfbd===_0x3cd933;_0x3cd933=_0x22bfbd;let _0x4e4699;const _0x421474=new Array(0x8);for(_0x4e4699=0x7;_0x4e4699>=0x0;_0x4e4699--)_0x421474[_0x4e4699]=Er['charAt'](_0x22bfbd%0x40),_0x22bfbd=Math['floor'](_0x22bfbd/0x40);f(_0x22bfbd===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0xf664d5=_0x421474['join']('');if(_0x258c82){for(_0x4e4699=0xb;_0x4e4699>=0x0&&_0x1fa821[_0x4e4699]===0x3f;_0x4e4699--)_0x1fa821[_0x4e4699]=0x0;_0x1fa821[_0x4e4699]++;}else{for(_0x4e4699=0x0;_0x4e4699<0xc;_0x4e4699++)_0x1fa821[_0x4e4699]=Math['floor'](Math['random']()*0x40);}for(_0x4e4699=0x0;_0x4e4699<0xc;_0x4e4699++)_0xf664d5+=Er['charAt'](_0x1fa821[_0x4e4699]);return f(_0xf664d5['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0xf664d5;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0xc2e86c,_0x2af844,_0x2f58f8,_0x3e5007){this['eventType']=_0xc2e86c,this['eventRegistration']=_0x2af844,this['snapshot']=_0x2f58f8,this['prevName']=_0x3e5007;}['getPath'](){const _0x27a496=this['snapshot']['ref'];return this['eventType']==='value'?_0x27a496['_path']:_0x27a496['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x13167c,_0x3fb79c,_0x44f01f){this['eventRegistration']=_0x13167c,this['error']=_0x3fb79c,this['path']=_0x44f01f;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x4934,_0x2f01b0){this['snapshotCallback']=_0x4934,this['cancelCallback']=_0x2f01b0;}['onValue'](_0x4b87ed,_0x4f0180){this['snapshotCallback']['call'](null,_0x4b87ed,_0x4f0180);}['onCancel'](_0x3e4058){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3e4058);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x44acf8){return this['snapshotCallback']===_0x44acf8['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x44acf8['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x44acf8['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x195193,_0x23e9b1){this['_repo']=_0x195193,this['_path']=_0x23e9b1;}['cancel'](){const _0x1958b9=new H();return bd(this['_repo'],this['_path'],_0x1958b9['wrapCallback'](()=>{})),_0x1958b9['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x38fe12=new H();return yr(this['_repo'],this['_path'],null,_0x38fe12['wrapCallback'](()=>{})),_0x38fe12['promise'];}['set'](_0x251db0){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x251db0,this['_path'],!0x1);const _0x96a407=new H();return yr(this['_repo'],this['_path'],_0x251db0,_0x96a407['wrapCallback'](()=>{})),_0x96a407['promise'];}['setWithPriority'](_0x3d5913,_0x55295a){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x3d5913,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x55295a);const _0x3cf206=new H();return Rd(this['_repo'],this['_path'],_0x3d5913,_0x55295a,_0x3cf206['wrapCallback'](()=>{})),_0x3cf206['promise'];}['update'](_0x103560){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x103560,this['_path']);const _0x4e399c=new H();return Ad(this['_repo'],this['_path'],_0x103560,_0x4e399c['wrapCallback'](()=>{})),_0x4e399c['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x4783a5,_0x4032e4,_0x255bfc,_0x32b41e){this['_repo']=_0x4783a5,this['_path']=_0x4032e4,this['_queryParams']=_0x255bfc,this['_orderByCalled']=_0x32b41e;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x8a1ec5=sr(this['_queryParams']),_0x2527f4=$i(_0x8a1ec5);return _0x2527f4==='{}'?'default':_0x2527f4;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x278576){if(_0x278576=P(_0x278576),!(_0x278576 instanceof Ae))return!0x1;const _0x577d8e=this['_repo']===_0x278576['_repo'],_0x19ec50=Ki(this['_path'],_0x278576['_path']),_0x4f9356=this['_queryIdentifier']===_0x278576['_queryIdentifier'];return _0x577d8e&&_0x19ec50&&_0x4f9356;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0xff7fa0,_0x256c08){if(_0xff7fa0['_orderByCalled']===!0x0)throw new Error(_0x256c08+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x21e2cc){let _0xcd5cd2=null,_0x541006=null;if(_0x21e2cc['hasStart']()&&(_0xcd5cd2=_0x21e2cc['getIndexStartValue']()),_0x21e2cc['hasEnd']()&&(_0x541006=_0x21e2cc['getIndexEndValue']()),_0x21e2cc['getIndex']()===ve){const _0x1ab0ef='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2866f2='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x21e2cc['hasStart']()){if(_0x21e2cc['getIndexStartName']()!==We)throw new Error(_0x1ab0ef);if(typeof _0xcd5cd2!='string')throw new Error(_0x2866f2);}if(_0x21e2cc['hasEnd']()){if(_0x21e2cc['getIndexEndName']()!==we)throw new Error(_0x1ab0ef);if(typeof _0x541006!='string')throw new Error(_0x2866f2);}}else{if(_0x21e2cc['getIndex']()===R){if(_0xcd5cd2!=null&&!Bt(_0xcd5cd2)||_0x541006!=null&&!Bt(_0x541006))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x21e2cc['getIndex']()instanceof Ji||_0x21e2cc['getIndex']()===Mo,'unknown\x20index\x20type.'),_0xcd5cd2!=null&&typeof _0xcd5cd2=='object'||_0x541006!=null&&typeof _0x541006=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x3899b4){if(_0x3899b4['hasStart']()&&_0x3899b4['hasEnd']()&&_0x3899b4['hasLimit']()&&!_0x3899b4['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x111dfa,_0x4b3cfa){super(_0x111dfa,_0x4b3cfa,new Zi(),!0x1);}get['parent'](){const _0x56f255=Ro(this['_path']);return _0x56f255===null?null:new ee(this['_repo'],_0x56f255);}get['root'](){let _0x26a0f9=this;for(;_0x26a0f9['parent']!==null;)_0x26a0f9=_0x26a0f9['parent'];return _0x26a0f9;}}class lt{constructor(_0x549ce9,_0x547861,_0x87c304){this['_node']=_0x549ce9,this['ref']=_0x547861,this['_index']=_0x87c304;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x559319){const _0x55f6c1=new C(_0x559319),_0x151fd6=Vt(this['ref'],_0x559319);return new lt(this['_node']['getChild'](_0x55f6c1),_0x151fd6,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x151d2e){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3abe62,_0x4855e6)=>_0x151d2e(new lt(_0x4855e6,Vt(this['ref'],_0x3abe62),R)));}['hasChild'](_0x268913){const _0x5481f4=new C(_0x268913);return!this['_node']['getChild'](_0x5481f4)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x35a4df,_0x7fd9c1){return _0x35a4df=P(_0x35a4df),_0x35a4df['_checkNotDeleted']('ref'),_0x7fd9c1!==void 0x0?Vt(_0x35a4df['_root'],_0x7fd9c1):_0x35a4df['_root'];}function Vt(_0x58ddee,_0x23ac21){return _0x58ddee=P(_0x58ddee),y(_0x58ddee['_path'])===null?pd('child','path',_0x23ac21):ys('child','path',_0x23ac21),new ee(_0x58ddee['_repo'],k(_0x58ddee['_path'],_0x23ac21));}function v_(_0x5ef9d9){return _0x5ef9d9=P(_0x5ef9d9),new Vd(_0x5ef9d9['_repo'],_0x5ef9d9['_path']);}function E_(_0x3909e7,_0x2e72a9){_0x3909e7=P(_0x3909e7),Me('push',_0x3909e7['_path']),He('push',_0x2e72a9,_0x3909e7['_path'],!0x0);const _0x5a9499=la(_0x3909e7['_repo']),_0x4c4489=Ud(_0x5a9499),_0x4992df=Vt(_0x3909e7,_0x4c4489),_0x529221=Vt(_0x3909e7,_0x4c4489);let _0x10ce94;return _0x2e72a9!=null?_0x10ce94=Hd(_0x529221,_0x2e72a9)['then'](()=>_0x529221):_0x10ce94=Promise['resolve'](_0x529221),_0x4992df['then']=_0x10ce94['then']['bind'](_0x10ce94),_0x4992df['catch']=_0x10ce94['then']['bind'](_0x10ce94,void 0x0),_0x4992df;}function Hd(_0x1a248a,_0x4e9a3f){_0x1a248a=P(_0x1a248a),Me('set',_0x1a248a['_path']),He('set',_0x4e9a3f,_0x1a248a['_path'],!0x1);const _0x47e2fd=new H();return Cd(_0x1a248a['_repo'],_0x1a248a['_path'],_0x4e9a3f,null,_0x47e2fd['wrapCallback'](()=>{})),_0x47e2fd['promise'];}function I_(_0xf6c98,_0x445e3e){ra('update',_0x445e3e,_0xf6c98['_path']);const _0x260fa2=new H();return Td(_0xf6c98['_repo'],_0xf6c98['_path'],_0x445e3e,_0x260fa2['wrapCallback'](()=>{})),_0x260fa2['promise'];}function w_(_0x5d116c){_0x5d116c=P(_0x5d116c);const _0xc3b136=new pa(()=>{}),_0x1267f4=new Qn(_0xc3b136);return wd(_0x5d116c['_repo'],_0x5d116c,_0x1267f4)['then'](_0x3cdbdf=>new lt(_0x3cdbdf,new ee(_0x5d116c['_repo'],_0x5d116c['_path']),_0x5d116c['_queryParams']['getIndex']()));}class Qn{constructor(_0x135d83){this['callbackContext']=_0x135d83;}['respondsTo'](_0x4ef0ae){return _0x4ef0ae==='value';}['createEvent'](_0xb668fd,_0x5669a7){const _0x31dd5f=_0x5669a7['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0xb668fd['snapshotNode'],new ee(_0x5669a7['_repo'],_0x5669a7['_path']),_0x31dd5f));}['getEventRunner'](_0x2126cd){return _0x2126cd['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x2126cd['error']):()=>this['callbackContext']['onValue'](_0x2126cd['snapshot'],null);}['createCancelEvent'](_0x24c5ba,_0x2291f5){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x24c5ba,_0x2291f5):null;}['matches'](_0x555159){return _0x555159 instanceof Qn?!_0x555159['callbackContext']||!this['callbackContext']?!0x0:_0x555159['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x28d2f4,_0x12a41e,_0x27bf25,_0x2b484d,_0x2f1aa7){const _0x573955=new pa(_0x27bf25,void 0x0),_0x55658f=new Qn(_0x573955);return kd(_0x28d2f4['_repo'],_0x28d2f4,_0x55658f),()=>Pd(_0x28d2f4['_repo'],_0x28d2f4,_0x55658f);}function Gd(_0x4251ae,_0x5dda6e,_0x54dd35,_0x58b5a4){return $d(_0x4251ae,'value',_0x5dda6e);}class mt{}class ma extends mt{constructor(_0x462786,_0x3a1829){super(),this['_value']=_0x462786,this['_key']=_0x3a1829,this['type']='endAt';}['_apply'](_0x152bd3){He('endAt',this['_value'],_0x152bd3['_path'],!0x0);const _0x29ac46=Jh(_0x152bd3['_queryParams'],this['_value'],this['_key']);if(ga(_0x29ac46),Yn(_0x29ac46),_0x152bd3['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x152bd3['_repo'],_0x152bd3['_path'],_0x29ac46,_0x152bd3['_orderByCalled']);}}function C_(_0x136854,_0x285476){return new ma(_0x136854,_0x285476);}class ya extends mt{constructor(_0x110361,_0x3a77cb){super(),this['_value']=_0x110361,this['_key']=_0x3a77cb,this['type']='startAt';}['_apply'](_0x1c929a){He('startAt',this['_value'],_0x1c929a['_path'],!0x0);const _0xc20701=Qh(_0x1c929a['_queryParams'],this['_value'],this['_key']);if(ga(_0xc20701),Yn(_0xc20701),_0x1c929a['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x1c929a['_repo'],_0x1c929a['_path'],_0xc20701,_0x1c929a['_orderByCalled']);}}function T_(_0x515a27=null,_0x4aae75){return new ya(_0x515a27,_0x4aae75);}class qd extends mt{constructor(_0x5435cc){super(),this['_limit']=_0x5435cc,this['type']='limitToFirst';}['_apply'](_0xa1cc50){if(_0xa1cc50['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0xa1cc50['_repo'],_0xa1cc50['_path'],Yh(_0xa1cc50['_queryParams'],this['_limit']),_0xa1cc50['_orderByCalled']);}}function S_(_0x494517){if(Math['floor'](_0x494517)!==_0x494517||_0x494517<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x494517);}class zd extends mt{constructor(_0x5e3906){super(),this['_path']=_0x5e3906,this['type']='orderByChild';}['_apply'](_0x52cf8a){_a(_0x52cf8a,'orderByChild');const _0x1fbee5=new C(this['_path']);if(v(_0x1fbee5))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x5a2327=new Ji(_0x1fbee5),_0x5c501b=xo(_0x52cf8a['_queryParams'],_0x5a2327);return Yn(_0x5c501b),new Ae(_0x52cf8a['_repo'],_0x52cf8a['_path'],_0x5c501b,!0x0);}}function b_(_0x5d2705){if(_0x5d2705==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5d2705==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5d2705==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5d2705),new zd(_0x5d2705);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2954ff){_a(_0x2954ff,'orderByKey');const _0x59c5d3=xo(_0x2954ff['_queryParams'],ve);return Yn(_0x59c5d3),new Ae(_0x2954ff['_repo'],_0x2954ff['_path'],_0x59c5d3,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x388e3e,_0x580815){super(),this['_value']=_0x388e3e,this['_key']=_0x580815,this['type']='equalTo';}['_apply'](_0x39a859){if(He('equalTo',this['_value'],_0x39a859['_path'],!0x1),_0x39a859['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x39a859['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x39a859));}}function A_(_0x2f679d,_0x21bf26){return new Kd(_0x2f679d,_0x21bf26);}function k_(_0x556630,..._0x27f191){let _0x4cf070=P(_0x556630);for(const _0xa79e6e of _0x27f191)_0x4cf070=_0xa79e6e['_apply'](_0x4cf070);return _0x4cf070;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x3b4840,_0x588081,_0x42d902,_0x1a2e04){const _0x1c5aef=_0x588081['lastIndexOf'](':'),_0x352f04=_0x588081['substring'](0x0,_0x1c5aef),_0x48dd35=qt(_0x352f04);_0x3b4840['repoInfo_']=new yo(_0x588081,_0x48dd35,_0x3b4840['repoInfo_']['namespace'],_0x3b4840['repoInfo_']['webSocketOnly'],_0x3b4840['repoInfo_']['nodeAdmin'],_0x3b4840['repoInfo_']['persistenceKey'],_0x3b4840['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x42d902),_0x1a2e04&&(_0x3b4840['authTokenProvider_']=_0x1a2e04);}function Xd(_0x4dfcc0,_0xac2cbc,_0x12f7f4,_0x48cf94,_0x2f2755){let _0x48a019=_0x48cf94||_0x4dfcc0['options']['databaseURL'];_0x48a019===void 0x0&&(_0x4dfcc0['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4dfcc0['options']['projectId']),_0x48a019=_0x4dfcc0['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x3e0e50=vr(_0x48a019,_0x2f2755),_0x5d99ee=_0x3e0e50['repoInfo'],_0x185591;typeof process<'u'&&Bs&&(_0x185591=Bs[Yd]),_0x185591?(_0x48a019='http://'+_0x185591+'?ns='+_0x5d99ee['namespace'],_0x3e0e50=vr(_0x48a019,_0x2f2755),_0x5d99ee=_0x3e0e50['repoInfo']):_0x3e0e50['repoInfo']['secure'];const _0x489993=new eh(_0x4dfcc0['name'],_0x4dfcc0['options'],_0xac2cbc);_d('Invalid\x20Firebase\x20Database\x20URL',_0x3e0e50),v(_0x3e0e50['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x14890e=ef(_0x5d99ee,_0x4dfcc0,_0x489993,new Zl(_0x4dfcc0,_0x12f7f4));return new tf(_0x14890e,_0x4dfcc0);}function Zd(_0x18fa8a,_0x327d96){const _0x410154=Di[_0x327d96];(!_0x410154||_0x410154[_0x18fa8a['key']]!==_0x18fa8a)&&ae('Database\x20'+_0x327d96+'('+_0x18fa8a['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x18fa8a),delete _0x410154[_0x18fa8a['key']];}function ef(_0x2485dd,_0x5ed4c3,_0x383b48,_0x7a1f0e){let _0x2f4117=Di[_0x5ed4c3['name']];_0x2f4117||(_0x2f4117={},Di[_0x5ed4c3['name']]=_0x2f4117);let _0x5fc100=_0x2f4117[_0x2485dd['toURLString']()];return _0x5fc100&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x5fc100=new vd(_0x2485dd,Qd,_0x383b48,_0x7a1f0e),_0x2f4117[_0x2485dd['toURLString']()]=_0x5fc100,_0x5fc100;}class tf{constructor(_0x3e6a67,_0x2c1973){this['_repoInternal']=_0x3e6a67,this['app']=_0x2c1973,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x1b2ac2){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x1b2ac2+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x9ba119=Zr(),_0x3ebbef){const _0x2260b6=Hi(_0x9ba119,'database')['getImmediate']({'identifier':_0x3ebbef});if(!_0x2260b6['_instanceStarted']){const _0x483df7=hc('database');_0x483df7&&nf(_0x2260b6,..._0x483df7);}return _0x2260b6;}function nf(_0xaaa987,_0x68772b,_0x1b5888,_0x4815c5={}){_0xaaa987=P(_0xaaa987),_0xaaa987['_checkNotDeleted']('useEmulator');const _0x68d656=_0x68772b+':'+_0x1b5888,_0xac397=_0xaaa987['_repoInternal'];if(_0xaaa987['_instanceStarted']){if(_0x68d656===_0xaaa987['_repoInternal']['repoInfo_']['host']&&xe(_0x4815c5,_0xac397['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x283d98;if(_0xac397['repoInfo_']['nodeAdmin'])_0x4815c5['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x283d98=new an(an['OWNER']);else{if(_0x4815c5['mockUserToken']){const _0x4d4970=typeof _0x4815c5['mockUserToken']=='string'?_0x4815c5['mockUserToken']:uc(_0x4815c5['mockUserToken'],_0xaaa987['app']['options']['projectId']);_0x283d98=new an(_0x4d4970);}}qt(_0x68772b)&&Qr(_0x68772b),Jd(_0xac397,_0x68d656,_0x4815c5,_0x283d98);}function N_(_0x472943){_0x472943=P(_0x472943),_0x472943['_checkNotDeleted']('goOffline'),ha(_0x472943['_repo']);}function O_(_0x4c6081){_0x4c6081=P(_0x4c6081),_0x4c6081['_checkNotDeleted']('goOnline'),Nd(_0x4c6081['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x35edd9){Ul(dt),st(new Fe('database',(_0x5afe47,{instanceIdentifier:_0x591815})=>{const _0x13863e=_0x5afe47['getProvider']('app')['getImmediate'](),_0x18452f=_0x5afe47['getProvider']('auth-internal'),_0x379666=_0x5afe47['getProvider']('app-check-internal');return Xd(_0x13863e,_0x18452f,_0x379666,_0x591815);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x35edd9),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x59e117,_0x198b6b){this['committed']=_0x59e117,this['snapshot']=_0x198b6b;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x22b8d5,_0x55b515,_0x1cbbb0){if(_0x22b8d5=P(_0x22b8d5),Me('Reference.transaction',_0x22b8d5['_path']),_0x22b8d5['key']==='.length'||_0x22b8d5['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x22b8d5['key']+'\x20is\x20a\x20read-only\x20object.';const _0x292ea4=!0x0,_0x5ab877=new H(),_0x1a04f9=(_0xb2032e,_0x464ecf,_0x5b3886)=>{let _0x1bfacb=null;_0xb2032e?_0x5ab877['reject'](_0xb2032e):(_0x1bfacb=new lt(_0x5b3886,new ee(_0x22b8d5['_repo'],_0x22b8d5['_path']),R),_0x5ab877['resolve'](new of(_0x464ecf,_0x1bfacb)));},_0x108fa0=Gd(_0x22b8d5,()=>{});return Od(_0x22b8d5['_repo'],_0x22b8d5['_path'],_0x55b515,_0x1a04f9,_0x108fa0,_0x292ea4),_0x5ab877['promise'];}se['prototype']['simpleListen']=function(_0xdbde1c,_0x20dac1){this['sendRequest']('q',{'p':_0xdbde1c},_0x20dac1);},se['prototype']['echo']=function(_0xa470f4,_0x4abfc8){this['sendRequest']('echo',{'d':_0xa470f4},_0x4abfc8);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x223ffb,..._0x3ebeae){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x223ffb,..._0x3ebeae);}function cn(_0x3c6dec,..._0x6e2efe){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x3c6dec,..._0x6e2efe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x37d33d,..._0x3c50c4){throw ws(_0x37d33d,..._0x3c50c4);}function X(_0x4a1164,..._0x53dd2b){return ws(_0x4a1164,..._0x53dd2b);}function Ia(_0x17bd7e,_0x4b173d,_0x2ea8e1){const _0x389f03={...af(),[_0x4b173d]:_0x2ea8e1};return new Gt('auth','Firebase',_0x389f03)['create'](_0x4b173d,{'appName':_0x17bd7e['name']});}function re(_0x1214db){return Ia(_0x1214db,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0xde28c9,..._0x4ad561){if(typeof _0xde28c9!='string'){const _0x569013=_0x4ad561[0x0],_0x54f5db=[..._0x4ad561['slice'](0x1)];return _0x54f5db[0x0]&&(_0x54f5db[0x0]['appName']=_0xde28c9['name']),_0xde28c9['_errorFactory']['create'](_0x569013,..._0x54f5db);}return Ea['create'](_0xde28c9,..._0x4ad561);}function m(_0x1af560,_0x285a27,..._0x4959f9){if(!_0x1af560)throw ws(_0x285a27,..._0x4959f9);}function ne(_0x325b2c){const _0x45e1cd='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x325b2c;throw cn(_0x45e1cd),new Error(_0x45e1cd);}function ce(_0x45c7ff,_0x548b39){_0x45c7ff||ne(_0x548b39);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x5eb5da;return typeof self<'u'&&((_0x5eb5da=self['location'])==null?void 0x0:_0x5eb5da['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x5b7618;return typeof self<'u'&&((_0x5b7618=self['location'])==null?void 0x0:_0x5b7618['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x4796c7=navigator;return _0x4796c7['languages']&&_0x4796c7['languages'][0x0]||_0x4796c7['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x206b8b,_0x52546b){this['shortDelay']=_0x206b8b,this['longDelay']=_0x52546b,ce(_0x52546b>_0x206b8b,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x56c664,_0x886089){ce(_0x56c664['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x957a36}=_0x56c664['emulator'];return _0x886089?''+_0x957a36+(_0x886089['startsWith']('/')?_0x886089['slice'](0x1):_0x886089):_0x957a36;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x5ecaed,_0x56afe1,_0x39e2d5){this['fetchImpl']=_0x5ecaed,_0x56afe1&&(this['headersImpl']=_0x56afe1),_0x39e2d5&&(this['responseImpl']=_0x39e2d5);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x1b7d3a,_0x3265fc){return _0x1b7d3a['tenantId']&&!_0x3265fc['tenantId']?{..._0x3265fc,'tenantId':_0x1b7d3a['tenantId']}:_0x3265fc;}async function Pe(_0x53e56f,_0x5a4a2c,_0x5ab7ac,_0x1aac57,_0x452fab={}){return Ca(_0x53e56f,_0x452fab,async()=>{let _0x216fa5={},_0x556e5e={};_0x1aac57&&(_0x5a4a2c==='GET'?_0x556e5e=_0x1aac57:_0x216fa5={'body':JSON['stringify'](_0x1aac57)});const _0x4de805=ut({..._0x556e5e,'key':_0x53e56f['config']['apiKey']})['slice'](0x1),_0x2f47e3=await _0x53e56f['_getAdditionalHeaders']();_0x2f47e3['Content-Type']='application/json',_0x53e56f['languageCode']&&(_0x2f47e3['X-Firebase-Locale']=_0x53e56f['languageCode']);const _0x7895ad={'method':_0x5a4a2c,'headers':_0x2f47e3,..._0x216fa5};return dc()||(_0x7895ad['referrerPolicy']='strict-origin-when-cross-origin'),_0x53e56f['emulatorConfig']&&qt(_0x53e56f['emulatorConfig']['host'])&&(_0x7895ad['credentials']='include'),wa['fetch']()(await Ta(_0x53e56f,_0x53e56f['config']['apiHost'],_0x5ab7ac,_0x4de805),_0x7895ad);});}async function Ca(_0x1b54e8,_0xb217ea,_0x215735){_0x1b54e8['_canInitEmulator']=!0x1;const _0x5dbac4={...df,..._0xb217ea};try{const _0x2146a4=new gf(_0x1b54e8),_0x38b2a6=await Promise['race']([_0x215735(),_0x2146a4['promise']]);_0x2146a4['clearNetworkTimeout']();const _0x37e690=await _0x38b2a6['json']();if('needConfirmation'in _0x37e690)throw on(_0x1b54e8,'account-exists-with-different-credential',_0x37e690);if(_0x38b2a6['ok']&&!('errorMessage'in _0x37e690))return _0x37e690;{const _0x948bce=_0x38b2a6['ok']?_0x37e690['errorMessage']:_0x37e690['error']['message'],[_0x161f7f,_0x33ec8d]=_0x948bce['split']('\x20:\x20');if(_0x161f7f==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x1b54e8,'credential-already-in-use',_0x37e690);if(_0x161f7f==='EMAIL_EXISTS')throw on(_0x1b54e8,'email-already-in-use',_0x37e690);if(_0x161f7f==='USER_DISABLED')throw on(_0x1b54e8,'user-disabled',_0x37e690);const _0x4c3381=_0x5dbac4[_0x161f7f]||_0x161f7f['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x33ec8d)throw Ia(_0x1b54e8,_0x4c3381,_0x33ec8d);Y(_0x1b54e8,_0x4c3381);}}catch(_0x487ba2){if(_0x487ba2 instanceof Re)throw _0x487ba2;Y(_0x1b54e8,'network-request-failed',{'message':String(_0x487ba2)});}}async function en(_0x86fc40,_0x3693f3,_0x3884f9,_0x5a733c,_0x46fc9d={}){const _0x53a5c4=await Pe(_0x86fc40,_0x3693f3,_0x3884f9,_0x5a733c,_0x46fc9d);return'mfaPendingCredential'in _0x53a5c4&&Y(_0x86fc40,'multi-factor-auth-required',{'_serverResponse':_0x53a5c4}),_0x53a5c4;}async function Ta(_0x9ab95e,_0x2b4053,_0x257c68,_0x29e626){const _0x7cf19=''+_0x2b4053+_0x257c68+'?'+_0x29e626,_0x502248=_0x9ab95e,_0x27aff6=_0x502248['config']['emulator']?Cs(_0x9ab95e['config'],_0x7cf19):_0x9ab95e['config']['apiScheme']+'://'+_0x7cf19;return ff['includes'](_0x257c68)&&(await _0x502248['_persistenceManagerAvailable'],_0x502248['_getPersistenceType']()==='COOKIE')?_0x502248['_getPersistence']()['_getFinalTarget'](_0x27aff6)['toString']():_0x27aff6;}function _f(_0x2f5398){switch(_0x2f5398){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x26ea89){this['auth']=_0x26ea89,this['timer']=null,this['promise']=new Promise((_0x13ac14,_0x128be2)=>{this['timer']=setTimeout(()=>_0x128be2(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x36c9a0,_0x2cea03,_0xd809a9){const _0x1bcda1={'appName':_0x36c9a0['name']};_0xd809a9['email']&&(_0x1bcda1['email']=_0xd809a9['email']),_0xd809a9['phoneNumber']&&(_0x1bcda1['phoneNumber']=_0xd809a9['phoneNumber']);const _0x1b65d7=X(_0x36c9a0,_0x2cea03,_0x1bcda1);return _0x1b65d7['customData']['_tokenResponse']=_0xd809a9,_0x1b65d7;}function wr(_0x50e3cf){return _0x50e3cf!==void 0x0&&_0x50e3cf['enterprise']!==void 0x0;}class mf{constructor(_0x1faf2b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x1faf2b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x1faf2b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x1faf2b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x543aea){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x4f6b9b of this['recaptchaEnforcementState'])if(_0x4f6b9b['provider']&&_0x4f6b9b['provider']===_0x543aea)return _f(_0x4f6b9b['enforcementState']);return null;}['isProviderEnabled'](_0x1438d8){return this['getProviderEnforcementState'](_0x1438d8)==='ENFORCE'||this['getProviderEnforcementState'](_0x1438d8)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x52c255,_0x35987d){return Pe(_0x52c255,'GET','/v2/recaptchaConfig',ke(_0x52c255,_0x35987d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3fabb5,_0x533630){return Pe(_0x3fabb5,'POST','/v1/accounts:delete',_0x533630);}async function Pn(_0x30323e,_0x2e1497){return Pe(_0x30323e,'POST','/v1/accounts:lookup',_0x2e1497);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x5c1403){if(_0x5c1403)try{const _0x43308e=new Date(Number(_0x5c1403));if(!isNaN(_0x43308e['getTime']()))return _0x43308e['toUTCString']();}catch{}}async function Ef(_0x2eeb34,_0xf77705=!0x1){const _0x2d406d=P(_0x2eeb34),_0x322ed5=await _0x2d406d['getIdToken'](_0xf77705),_0x5c9cc9=Ts(_0x322ed5);m(_0x5c9cc9&&_0x5c9cc9['exp']&&_0x5c9cc9['auth_time']&&_0x5c9cc9['iat'],_0x2d406d['auth'],'internal-error');const _0x583faa=typeof _0x5c9cc9['firebase']=='object'?_0x5c9cc9['firebase']:void 0x0,_0x1ff1d1=_0x583faa==null?void 0x0:_0x583faa['sign_in_provider'];return{'claims':_0x5c9cc9,'token':_0x322ed5,'authTime':Pt(fi(_0x5c9cc9['auth_time'])),'issuedAtTime':Pt(fi(_0x5c9cc9['iat'])),'expirationTime':Pt(fi(_0x5c9cc9['exp'])),'signInProvider':_0x1ff1d1||null,'signInSecondFactor':(_0x583faa==null?void 0x0:_0x583faa['sign_in_second_factor'])||null};}function fi(_0x87742f){return Number(_0x87742f)*0x3e8;}function Ts(_0x38bcff){const [_0x232649,_0x1ebf3f,_0x92fca9]=_0x38bcff['split']('.');if(_0x232649===void 0x0||_0x1ebf3f===void 0x0||_0x92fca9===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x254619=fn(_0x1ebf3f);return _0x254619?JSON['parse'](_0x254619):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x813d90){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x813d90==null?void 0x0:_0x813d90['toString']()),null;}}function Cr(_0x5db3a9){const _0x4b65d9=Ts(_0x5db3a9);return m(_0x4b65d9,'internal-error'),m(typeof _0x4b65d9['exp']<'u','internal-error'),m(typeof _0x4b65d9['iat']<'u','internal-error'),Number(_0x4b65d9['exp'])-Number(_0x4b65d9['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x1ba395,_0x3cf9ae,_0x29ef91=!0x1){if(_0x29ef91)return _0x3cf9ae;try{return await _0x3cf9ae;}catch(_0x39f82f){throw _0x39f82f instanceof Re&&If(_0x39f82f)&&_0x1ba395['auth']['currentUser']===_0x1ba395&&await _0x1ba395['auth']['signOut'](),_0x39f82f;}}function If({code:_0x9c3c96}){return _0x9c3c96==='auth/user-disabled'||_0x9c3c96==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x48d7d7){this['user']=_0x48d7d7,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x161033){if(_0x161033){const _0x134d2b=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x134d2b;}else{this['errorBackoff']=0x7530;const _0x3cfa09=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3cfa09);}}['schedule'](_0x339f40=!0x1){if(!this['isRunning'])return;const _0x315a66=this['getInterval'](_0x339f40);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x315a66);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x38174d){(_0x38174d==null?void 0x0:_0x38174d['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0xfbfcb9,_0x5fc92a){this['createdAt']=_0xfbfcb9,this['lastLoginAt']=_0x5fc92a,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x96118c){this['createdAt']=_0x96118c['createdAt'],this['lastLoginAt']=_0x96118c['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x2ca5fd){var _0x396364;const _0x57ad40=_0x2ca5fd['auth'],_0x294702=await _0x2ca5fd['getIdToken'](),_0x52c059=await Ht(_0x2ca5fd,Pn(_0x57ad40,{'idToken':_0x294702}));m(_0x52c059==null?void 0x0:_0x52c059['users']['length'],_0x57ad40,'internal-error');const _0x4c08af=_0x52c059['users'][0x0];_0x2ca5fd['_notifyReloadListener'](_0x4c08af);const _0x2cec8a=(_0x396364=_0x4c08af['providerUserInfo'])!=null&&_0x396364['length']?Sa(_0x4c08af['providerUserInfo']):[],_0x17f76f=Tf(_0x2ca5fd['providerData'],_0x2cec8a),_0x1519dc=_0x2ca5fd['isAnonymous'],_0x28d49c=!(_0x2ca5fd['email']&&_0x4c08af['passwordHash'])&&!(_0x17f76f!=null&&_0x17f76f['length']),_0xaea8a1=_0x1519dc?_0x28d49c:!0x1,_0x26147e={'uid':_0x4c08af['localId'],'displayName':_0x4c08af['displayName']||null,'photoURL':_0x4c08af['photoUrl']||null,'email':_0x4c08af['email']||null,'emailVerified':_0x4c08af['emailVerified']||!0x1,'phoneNumber':_0x4c08af['phoneNumber']||null,'tenantId':_0x4c08af['tenantId']||null,'providerData':_0x17f76f,'metadata':new Li(_0x4c08af['createdAt'],_0x4c08af['lastLoginAt']),'isAnonymous':_0xaea8a1};Object['assign'](_0x2ca5fd,_0x26147e);}async function Cf(_0x4df4bb){const _0x28ef95=P(_0x4df4bb);await Nn(_0x28ef95),await _0x28ef95['auth']['_persistUserIfCurrent'](_0x28ef95),_0x28ef95['auth']['_notifyListenersIfCurrent'](_0x28ef95);}function Tf(_0x1ab45f,_0x4cd37c){return[..._0x1ab45f['filter'](_0x584745=>!_0x4cd37c['some'](_0x337a84=>_0x337a84['providerId']===_0x584745['providerId'])),..._0x4cd37c];}function Sa(_0x373f52){return _0x373f52['map'](({providerId:_0x4a0502,..._0xd29b23})=>({'providerId':_0x4a0502,'uid':_0xd29b23['rawId']||'','displayName':_0xd29b23['displayName']||null,'email':_0xd29b23['email']||null,'phoneNumber':_0xd29b23['phoneNumber']||null,'photoURL':_0xd29b23['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x471dc4,_0x5e576a){const _0x4ffbca=await Ca(_0x471dc4,{},async()=>{const _0x50ab0a=ut({'grant_type':'refresh_token','refresh_token':_0x5e576a})['slice'](0x1),{tokenApiHost:_0xd570fa,apiKey:_0x2dc291}=_0x471dc4['config'],_0x10bd6e=await Ta(_0x471dc4,_0xd570fa,'/v1/token','key='+_0x2dc291),_0x2146c6=await _0x471dc4['_getAdditionalHeaders']();_0x2146c6['Content-Type']='application/x-www-form-urlencoded';const _0x3b8954={'method':'POST','headers':_0x2146c6,'body':_0x50ab0a};return _0x471dc4['emulatorConfig']&&qt(_0x471dc4['emulatorConfig']['host'])&&(_0x3b8954['credentials']='include'),wa['fetch']()(_0x10bd6e,_0x3b8954);});return{'accessToken':_0x4ffbca['access_token'],'expiresIn':_0x4ffbca['expires_in'],'refreshToken':_0x4ffbca['refresh_token']};}async function bf(_0x40a1bc,_0x1d8a2e){return Pe(_0x40a1bc,'POST','/v2/accounts:revokeToken',ke(_0x40a1bc,_0x1d8a2e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x17d22a){m(_0x17d22a['idToken'],'internal-error'),m(typeof _0x17d22a['idToken']<'u','internal-error'),m(typeof _0x17d22a['refreshToken']<'u','internal-error');const _0x45576f='expiresIn'in _0x17d22a&&typeof _0x17d22a['expiresIn']<'u'?Number(_0x17d22a['expiresIn']):Cr(_0x17d22a['idToken']);this['updateTokensAndExpiration'](_0x17d22a['idToken'],_0x17d22a['refreshToken'],_0x45576f);}['updateFromIdToken'](_0x27fcd1){m(_0x27fcd1['length']!==0x0,'internal-error');const _0x6e4701=Cr(_0x27fcd1);this['updateTokensAndExpiration'](_0x27fcd1,null,_0x6e4701);}async['getToken'](_0x4dfd48,_0x5bbd2a=!0x1){return!_0x5bbd2a&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4dfd48,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4dfd48,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x592955,_0x390265){const {accessToken:_0x455b02,refreshToken:_0x3cd3f2,expiresIn:_0x49b0cd}=await Sf(_0x592955,_0x390265);this['updateTokensAndExpiration'](_0x455b02,_0x3cd3f2,Number(_0x49b0cd));}['updateTokensAndExpiration'](_0x21b187,_0x481fa9,_0x4e4db4){this['refreshToken']=_0x481fa9||null,this['accessToken']=_0x21b187||null,this['expirationTime']=Date['now']()+_0x4e4db4*0x3e8;}static['fromJSON'](_0x4753fb,_0x203d79){const {refreshToken:_0x297bbe,accessToken:_0x5d319f,expirationTime:_0x1cbd22}=_0x203d79,_0x346b9f=new et();return _0x297bbe&&(m(typeof _0x297bbe=='string','internal-error',{'appName':_0x4753fb}),_0x346b9f['refreshToken']=_0x297bbe),_0x5d319f&&(m(typeof _0x5d319f=='string','internal-error',{'appName':_0x4753fb}),_0x346b9f['accessToken']=_0x5d319f),_0x1cbd22&&(m(typeof _0x1cbd22=='number','internal-error',{'appName':_0x4753fb}),_0x346b9f['expirationTime']=_0x1cbd22),_0x346b9f;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1e8fa5){this['accessToken']=_0x1e8fa5['accessToken'],this['refreshToken']=_0x1e8fa5['refreshToken'],this['expirationTime']=_0x1e8fa5['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x4c61ce,_0x5d0911){m(typeof _0x4c61ce=='string'||typeof _0x4c61ce>'u','internal-error',{'appName':_0x5d0911});}class j{constructor({uid:_0x35c719,auth:_0x5ace5d,stsTokenManager:_0x48a728,..._0x4c8210}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x35c719,this['auth']=_0x5ace5d,this['stsTokenManager']=_0x48a728,this['accessToken']=_0x48a728['accessToken'],this['displayName']=_0x4c8210['displayName']||null,this['email']=_0x4c8210['email']||null,this['emailVerified']=_0x4c8210['emailVerified']||!0x1,this['phoneNumber']=_0x4c8210['phoneNumber']||null,this['photoURL']=_0x4c8210['photoURL']||null,this['isAnonymous']=_0x4c8210['isAnonymous']||!0x1,this['tenantId']=_0x4c8210['tenantId']||null,this['providerData']=_0x4c8210['providerData']?[..._0x4c8210['providerData']]:[],this['metadata']=new Li(_0x4c8210['createdAt']||void 0x0,_0x4c8210['lastLoginAt']||void 0x0);}async['getIdToken'](_0x32af2b){const _0x5429c6=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x32af2b));return m(_0x5429c6,this['auth'],'internal-error'),this['accessToken']!==_0x5429c6&&(this['accessToken']=_0x5429c6,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5429c6;}['getIdTokenResult'](_0x15292e){return Ef(this,_0x15292e);}['reload'](){return Cf(this);}['_assign'](_0x234b16){this!==_0x234b16&&(m(this['uid']===_0x234b16['uid'],this['auth'],'internal-error'),this['displayName']=_0x234b16['displayName'],this['photoURL']=_0x234b16['photoURL'],this['email']=_0x234b16['email'],this['emailVerified']=_0x234b16['emailVerified'],this['phoneNumber']=_0x234b16['phoneNumber'],this['isAnonymous']=_0x234b16['isAnonymous'],this['tenantId']=_0x234b16['tenantId'],this['providerData']=_0x234b16['providerData']['map'](_0x309da2=>({..._0x309da2})),this['metadata']['_copy'](_0x234b16['metadata']),this['stsTokenManager']['_assign'](_0x234b16['stsTokenManager']));}['_clone'](_0x1af8c8){const _0x7d5c33=new j({...this,'auth':_0x1af8c8,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x7d5c33['metadata']['_copy'](this['metadata']),_0x7d5c33;}['_onReload'](_0x418251){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x418251,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2f05a7){this['reloadListener']?this['reloadListener'](_0x2f05a7):this['reloadUserInfo']=_0x2f05a7;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2afe48,_0x263763=!0x1){let _0x5915a2=!0x1;_0x2afe48['idToken']&&_0x2afe48['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2afe48),_0x5915a2=!0x0),_0x263763&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5915a2&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x2de127=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x2de127})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x36236b=>({..._0x36236b})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x1b1cc5,_0x9ec1ac){const _0x70c9=_0x9ec1ac['displayName']??void 0x0,_0x15d731=_0x9ec1ac['email']??void 0x0,_0x367d35=_0x9ec1ac['phoneNumber']??void 0x0,_0x672de6=_0x9ec1ac['photoURL']??void 0x0,_0x157eb0=_0x9ec1ac['tenantId']??void 0x0,_0x4a17ed=_0x9ec1ac['_redirectEventId']??void 0x0,_0x8d8a34=_0x9ec1ac['createdAt']??void 0x0,_0x2d8998=_0x9ec1ac['lastLoginAt']??void 0x0,{uid:_0x222a0e,emailVerified:_0x5accee,isAnonymous:_0x437f96,providerData:_0x1f5e80,stsTokenManager:_0x4c7c9f}=_0x9ec1ac;m(_0x222a0e&&_0x4c7c9f,_0x1b1cc5,'internal-error');const _0x4dda62=et['fromJSON'](this['name'],_0x4c7c9f);m(typeof _0x222a0e=='string',_0x1b1cc5,'internal-error'),le(_0x70c9,_0x1b1cc5['name']),le(_0x15d731,_0x1b1cc5['name']),m(typeof _0x5accee=='boolean',_0x1b1cc5,'internal-error'),m(typeof _0x437f96=='boolean',_0x1b1cc5,'internal-error'),le(_0x367d35,_0x1b1cc5['name']),le(_0x672de6,_0x1b1cc5['name']),le(_0x157eb0,_0x1b1cc5['name']),le(_0x4a17ed,_0x1b1cc5['name']),le(_0x8d8a34,_0x1b1cc5['name']),le(_0x2d8998,_0x1b1cc5['name']);const _0x1959aa=new j({'uid':_0x222a0e,'auth':_0x1b1cc5,'email':_0x15d731,'emailVerified':_0x5accee,'displayName':_0x70c9,'isAnonymous':_0x437f96,'photoURL':_0x672de6,'phoneNumber':_0x367d35,'tenantId':_0x157eb0,'stsTokenManager':_0x4dda62,'createdAt':_0x8d8a34,'lastLoginAt':_0x2d8998});return _0x1f5e80&&Array['isArray'](_0x1f5e80)&&(_0x1959aa['providerData']=_0x1f5e80['map'](_0xad219f=>({..._0xad219f}))),_0x4a17ed&&(_0x1959aa['_redirectEventId']=_0x4a17ed),_0x1959aa;}static async['_fromIdTokenResponse'](_0x51aa27,_0x45196d,_0x3cae16=!0x1){const _0x5e61a6=new et();_0x5e61a6['updateFromServerResponse'](_0x45196d);const _0x52a8f3=new j({'uid':_0x45196d['localId'],'auth':_0x51aa27,'stsTokenManager':_0x5e61a6,'isAnonymous':_0x3cae16});return await Nn(_0x52a8f3),_0x52a8f3;}static async['_fromGetAccountInfoResponse'](_0x9b24a3,_0x30a797,_0x2bce94){const _0xfeaf47=_0x30a797['users'][0x0];m(_0xfeaf47['localId']!==void 0x0,'internal-error');const _0x34c961=_0xfeaf47['providerUserInfo']!==void 0x0?Sa(_0xfeaf47['providerUserInfo']):[],_0x26ea7a=!(_0xfeaf47['email']&&_0xfeaf47['passwordHash'])&&!(_0x34c961!=null&&_0x34c961['length']),_0x466463=new et();_0x466463['updateFromIdToken'](_0x2bce94);const _0x355121=new j({'uid':_0xfeaf47['localId'],'auth':_0x9b24a3,'stsTokenManager':_0x466463,'isAnonymous':_0x26ea7a}),_0x14e19e={'uid':_0xfeaf47['localId'],'displayName':_0xfeaf47['displayName']||null,'photoURL':_0xfeaf47['photoUrl']||null,'email':_0xfeaf47['email']||null,'emailVerified':_0xfeaf47['emailVerified']||!0x1,'phoneNumber':_0xfeaf47['phoneNumber']||null,'tenantId':_0xfeaf47['tenantId']||null,'providerData':_0x34c961,'metadata':new Li(_0xfeaf47['createdAt'],_0xfeaf47['lastLoginAt']),'isAnonymous':!(_0xfeaf47['email']&&_0xfeaf47['passwordHash'])&&!(_0x34c961!=null&&_0x34c961['length'])};return Object['assign'](_0x355121,_0x14e19e),_0x355121;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x46fa51){ce(_0x46fa51 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x24d9b2=Tr['get'](_0x46fa51);return _0x24d9b2?(ce(_0x24d9b2 instanceof _0x46fa51,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x24d9b2):(_0x24d9b2=new _0x46fa51(),Tr['set'](_0x46fa51,_0x24d9b2),_0x24d9b2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x192ff1,_0x367578){this['storage'][_0x192ff1]=_0x367578;}async['_get'](_0x33509b){const _0x30fc2e=this['storage'][_0x33509b];return _0x30fc2e===void 0x0?null:_0x30fc2e;}async['_remove'](_0x465048){delete this['storage'][_0x465048];}['_addListener'](_0x1f4fd4,_0x2d408c){}['_removeListener'](_0x5df63c,_0x54bd71){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x1ccfc6,_0x497c9a,_0x31f040){return'firebase:'+_0x1ccfc6+':'+_0x497c9a+':'+_0x31f040;}class tt{constructor(_0x476fe4,_0x53ba93,_0x5f0ec0){this['persistence']=_0x476fe4,this['auth']=_0x53ba93,this['userKey']=_0x5f0ec0;const {config:_0x57f277,name:_0x155b16}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x57f277['apiKey'],_0x155b16),this['fullPersistenceKey']=ln('persistence',_0x57f277['apiKey'],_0x155b16),this['boundEventHandler']=_0x53ba93['_onStorageEvent']['bind'](_0x53ba93),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x13196d){return this['persistence']['_set'](this['fullUserKey'],_0x13196d['toJSON']());}async['getCurrentUser'](){const _0x174f94=await this['persistence']['_get'](this['fullUserKey']);if(!_0x174f94)return null;if(typeof _0x174f94=='string'){const _0x518c86=await Pn(this['auth'],{'idToken':_0x174f94})['catch'](()=>{});return _0x518c86?j['_fromGetAccountInfoResponse'](this['auth'],_0x518c86,_0x174f94):null;}return j['_fromJSON'](this['auth'],_0x174f94);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x262da5){if(this['persistence']===_0x262da5)return;const _0x28f1a1=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x262da5,_0x28f1a1)return this['setCurrentUser'](_0x28f1a1);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4da726,_0x1437b4,_0x5a4362='authUser'){if(!_0x1437b4['length'])return new tt(ie(Sr),_0x4da726,_0x5a4362);const _0x160bdf=(await Promise['all'](_0x1437b4['map'](async _0x2b0983=>{if(await _0x2b0983['_isAvailable']())return _0x2b0983;})))['filter'](_0x23831b=>_0x23831b);let _0x37468d=_0x160bdf[0x0]||ie(Sr);const _0x34ec8b=ln(_0x5a4362,_0x4da726['config']['apiKey'],_0x4da726['name']);let _0x259be7=null;for(const _0x2a7e38 of _0x1437b4)try{const _0x35d998=await _0x2a7e38['_get'](_0x34ec8b);if(_0x35d998){let _0x6dc56d;if(typeof _0x35d998=='string'){const _0x325972=await Pn(_0x4da726,{'idToken':_0x35d998})['catch'](()=>{});if(!_0x325972)break;_0x6dc56d=await j['_fromGetAccountInfoResponse'](_0x4da726,_0x325972,_0x35d998);}else _0x6dc56d=j['_fromJSON'](_0x4da726,_0x35d998);_0x2a7e38!==_0x37468d&&(_0x259be7=_0x6dc56d),_0x37468d=_0x2a7e38;break;}}catch{}const _0xe2cec=_0x160bdf['filter'](_0x112cc9=>_0x112cc9['_shouldAllowMigration']);return!_0x37468d['_shouldAllowMigration']||!_0xe2cec['length']?new tt(_0x37468d,_0x4da726,_0x5a4362):(_0x37468d=_0xe2cec[0x0],_0x259be7&&await _0x37468d['_set'](_0x34ec8b,_0x259be7['toJSON']()),await Promise['all'](_0x1437b4['map'](async _0x21bb0c=>{if(_0x21bb0c!==_0x37468d)try{await _0x21bb0c['_remove'](_0x34ec8b);}catch{}})),new tt(_0x37468d,_0x4da726,_0x5a4362));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0xdab45b){const _0x198232=_0xdab45b['toLowerCase']();if(_0x198232['includes']('opera/')||_0x198232['includes']('opr/')||_0x198232['includes']('opios/'))return'Opera';if(Pa(_0x198232))return'IEMobile';if(_0x198232['includes']('msie')||_0x198232['includes']('trident/'))return'IE';if(_0x198232['includes']('edge/'))return'Edge';if(Ra(_0x198232))return'Firefox';if(_0x198232['includes']('silk/'))return'Silk';if(Oa(_0x198232))return'Blackberry';if(Da(_0x198232))return'Webos';if(Aa(_0x198232))return'Safari';if((_0x198232['includes']('chrome/')||ka(_0x198232))&&!_0x198232['includes']('edge/'))return'Chrome';if(Na(_0x198232))return'Android';{const _0x44b148=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1cfa09=_0xdab45b['match'](_0x44b148);if((_0x1cfa09==null?void 0x0:_0x1cfa09['length'])===0x2)return _0x1cfa09[0x1];}return'Other';}function Ra(_0x5595ba=W()){return/firefox\//i['test'](_0x5595ba);}function Aa(_0x374d8a=W()){const _0x4ee5d2=_0x374d8a['toLowerCase']();return _0x4ee5d2['includes']('safari/')&&!_0x4ee5d2['includes']('chrome/')&&!_0x4ee5d2['includes']('crios/')&&!_0x4ee5d2['includes']('android');}function ka(_0x1670ca=W()){return/crios\//i['test'](_0x1670ca);}function Pa(_0x3c3caa=W()){return/iemobile/i['test'](_0x3c3caa);}function Na(_0x115066=W()){return/android/i['test'](_0x115066);}function Oa(_0x987f8f=W()){return/blackberry/i['test'](_0x987f8f);}function Da(_0x10ff89=W()){return/webos/i['test'](_0x10ff89);}function Ss(_0x1e040f=W()){return/iphone|ipad|ipod/i['test'](_0x1e040f)||/macintosh/i['test'](_0x1e040f)&&/mobile/i['test'](_0x1e040f);}function Rf(_0x2dcbbc=W()){var _0x4f2bde;return Ss(_0x2dcbbc)&&!!((_0x4f2bde=window['navigator'])!=null&&_0x4f2bde['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x818e08=W()){return Ss(_0x818e08)||Na(_0x818e08)||Da(_0x818e08)||Oa(_0x818e08)||/windows phone/i['test'](_0x818e08)||Pa(_0x818e08);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x1d4852,_0x3b6a13=[]){let _0xf0d5d3;switch(_0x1d4852){case'Browser':_0xf0d5d3=br(W());break;case'Worker':_0xf0d5d3=br(W())+'-'+_0x1d4852;break;default:_0xf0d5d3=_0x1d4852;}const _0x50e9a1=_0x3b6a13['length']?_0x3b6a13['join'](','):'FirebaseCore-web';return _0xf0d5d3+'/JsCore/'+dt+'/'+_0x50e9a1;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x426796){this['auth']=_0x426796,this['queue']=[];}['pushCallback'](_0x5b37b3,_0xe36bbc){const _0x5463b5=_0x238823=>new Promise((_0x2e7786,_0x544cb0)=>{try{const _0xa5fabf=_0x5b37b3(_0x238823);_0x2e7786(_0xa5fabf);}catch(_0x1d4e9){_0x544cb0(_0x1d4e9);}});_0x5463b5['onAbort']=_0xe36bbc,this['queue']['push'](_0x5463b5);const _0x4c78b5=this['queue']['length']-0x1;return()=>{this['queue'][_0x4c78b5]=()=>Promise['resolve']();};}async['runMiddleware'](_0x20ee0a){if(this['auth']['currentUser']===_0x20ee0a)return;const _0x57b94e=[];try{for(const _0x37e818 of this['queue'])await _0x37e818(_0x20ee0a),_0x37e818['onAbort']&&_0x57b94e['push'](_0x37e818['onAbort']);}catch(_0xd9b386){_0x57b94e['reverse']();for(const _0x339eeb of _0x57b94e)try{_0x339eeb();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xd9b386==null?void 0x0:_0xd9b386['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x52023d,_0x1ab158={}){return Pe(_0x52023d,'GET','/v2/passwordPolicy',ke(_0x52023d,_0x1ab158));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x259485){var _0x3936b9;const _0x158115=_0x259485['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x158115['minPasswordLength']??Nf,_0x158115['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x158115['maxPasswordLength']),_0x158115['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x158115['containsLowercaseCharacter']),_0x158115['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x158115['containsUppercaseCharacter']),_0x158115['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x158115['containsNumericCharacter']),_0x158115['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x158115['containsNonAlphanumericCharacter']),this['enforcementState']=_0x259485['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3936b9=_0x259485['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3936b9['join'](''))??'',this['forceUpgradeOnSignin']=_0x259485['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x259485['schemaVersion'];}['validatePassword'](_0x138ddd){const _0x36a861={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x138ddd,_0x36a861),this['validatePasswordCharacterOptions'](_0x138ddd,_0x36a861),_0x36a861['isValid']&&(_0x36a861['isValid']=_0x36a861['meetsMinPasswordLength']??!0x0),_0x36a861['isValid']&&(_0x36a861['isValid']=_0x36a861['meetsMaxPasswordLength']??!0x0),_0x36a861['isValid']&&(_0x36a861['isValid']=_0x36a861['containsLowercaseLetter']??!0x0),_0x36a861['isValid']&&(_0x36a861['isValid']=_0x36a861['containsUppercaseLetter']??!0x0),_0x36a861['isValid']&&(_0x36a861['isValid']=_0x36a861['containsNumericCharacter']??!0x0),_0x36a861['isValid']&&(_0x36a861['isValid']=_0x36a861['containsNonAlphanumericCharacter']??!0x0),_0x36a861;}['validatePasswordLengthOptions'](_0x25d744,_0x266ef3){const _0x256f81=this['customStrengthOptions']['minPasswordLength'],_0x398796=this['customStrengthOptions']['maxPasswordLength'];_0x256f81&&(_0x266ef3['meetsMinPasswordLength']=_0x25d744['length']>=_0x256f81),_0x398796&&(_0x266ef3['meetsMaxPasswordLength']=_0x25d744['length']<=_0x398796);}['validatePasswordCharacterOptions'](_0x4c0c9d,_0x22f0b8){this['updatePasswordCharacterOptionsStatuses'](_0x22f0b8,!0x1,!0x1,!0x1,!0x1);let _0xed1163;for(let _0x517b67=0x0;_0x517b67<_0x4c0c9d['length'];_0x517b67++)_0xed1163=_0x4c0c9d['charAt'](_0x517b67),this['updatePasswordCharacterOptionsStatuses'](_0x22f0b8,_0xed1163>='a'&&_0xed1163<='z',_0xed1163>='A'&&_0xed1163<='Z',_0xed1163>='0'&&_0xed1163<='9',this['allowedNonAlphanumericCharacters']['includes'](_0xed1163));}['updatePasswordCharacterOptionsStatuses'](_0x37f7b7,_0x3fb2de,_0x5c2479,_0xef4800,_0x8b671a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x37f7b7['containsLowercaseLetter']||(_0x37f7b7['containsLowercaseLetter']=_0x3fb2de)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x37f7b7['containsUppercaseLetter']||(_0x37f7b7['containsUppercaseLetter']=_0x5c2479)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x37f7b7['containsNumericCharacter']||(_0x37f7b7['containsNumericCharacter']=_0xef4800)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x37f7b7['containsNonAlphanumericCharacter']||(_0x37f7b7['containsNonAlphanumericCharacter']=_0x8b671a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x439db6,_0x35ac41,_0x9b835c,_0x1fe995){this['app']=_0x439db6,this['heartbeatServiceProvider']=_0x35ac41,this['appCheckServiceProvider']=_0x9b835c,this['config']=_0x1fe995,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x439db6['name'],this['clientVersion']=_0x1fe995['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5d414b=>this['_resolvePersistenceManagerAvailable']=_0x5d414b);}['_initializeWithPersistence'](_0x2ed115,_0x4ba67a){return _0x4ba67a&&(this['_popupRedirectResolver']=ie(_0x4ba67a)),this['_initializationPromise']=this['queue'](async()=>{var _0x5a1e57,_0x55448e,_0x24df46;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x2ed115),(_0x5a1e57=this['_resolvePersistenceManagerAvailable'])==null||_0x5a1e57['call'](this),!this['_deleted'])){if((_0x55448e=this['_popupRedirectResolver'])!=null&&_0x55448e['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x4ba67a),this['lastNotifiedUid']=((_0x24df46=this['currentUser'])==null?void 0x0:_0x24df46['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x183550=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x183550)){if(this['currentUser']&&_0x183550&&this['currentUser']['uid']===_0x183550['uid']){this['_currentUser']['_assign'](_0x183550),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x183550,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x196a68){try{const _0x75f5c9=await Pn(this,{'idToken':_0x196a68}),_0x2d33b7=await j['_fromGetAccountInfoResponse'](this,_0x75f5c9,_0x196a68);await this['directlySetCurrentUser'](_0x2d33b7);}catch(_0x43f9b3){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x43f9b3),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x4d1522){var _0x34bd80;if($(this['app'])){const _0x4dea9a=this['app']['settings']['authIdToken'];return _0x4dea9a?new Promise(_0x241723=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4dea9a)['then'](_0x241723,_0x241723));}):this['directlySetCurrentUser'](null);}const _0xf6e709=await this['assertedPersistence']['getCurrentUser']();let _0x556c4f=_0xf6e709,_0x2fad7b=!0x1;if(_0x4d1522&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1c4e21=(_0x34bd80=this['redirectUser'])==null?void 0x0:_0x34bd80['_redirectEventId'],_0x1761ec=_0x556c4f==null?void 0x0:_0x556c4f['_redirectEventId'],_0x2ece53=await this['tryRedirectSignIn'](_0x4d1522);(!_0x1c4e21||_0x1c4e21===_0x1761ec)&&(_0x2ece53!=null&&_0x2ece53['user'])&&(_0x556c4f=_0x2ece53['user'],_0x2fad7b=!0x0);}if(!_0x556c4f)return this['directlySetCurrentUser'](null);if(!_0x556c4f['_redirectEventId']){if(_0x2fad7b)try{await this['beforeStateQueue']['runMiddleware'](_0x556c4f);}catch(_0x508061){_0x556c4f=_0xf6e709,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x508061));}return _0x556c4f?this['reloadAndSetCurrentUserOrClear'](_0x556c4f):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x556c4f['_redirectEventId']?this['directlySetCurrentUser'](_0x556c4f):this['reloadAndSetCurrentUserOrClear'](_0x556c4f);}async['tryRedirectSignIn'](_0x39f61d){let _0x2a85af=null;try{_0x2a85af=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x39f61d,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2a85af;}async['reloadAndSetCurrentUserOrClear'](_0x581653){try{await Nn(_0x581653);}catch(_0x25f9d5){if((_0x25f9d5==null?void 0x0:_0x25f9d5['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x581653);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x31bdc7){if($(this['app']))return Promise['reject'](re(this));const _0x56a3e2=_0x31bdc7?P(_0x31bdc7):null;return _0x56a3e2&&m(_0x56a3e2['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x56a3e2&&_0x56a3e2['_clone'](this));}async['_updateCurrentUser'](_0x502d3f,_0x585898=!0x1){if(!this['_deleted'])return _0x502d3f&&m(this['tenantId']===_0x502d3f['tenantId'],this,'tenant-id-mismatch'),_0x585898||await this['beforeStateQueue']['runMiddleware'](_0x502d3f),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x502d3f),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x42de2d){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x42de2d));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xe1840f){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1513b8=this['_getPasswordPolicyInternal']();return _0x1513b8['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1513b8['validatePassword'](_0xe1840f);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x498d35=await Pf(this),_0x5d2af5=new Of(_0x498d35);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5d2af5:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5d2af5;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x319695){this['_errorFactory']=new Gt('auth','Firebase',_0x319695());}['onAuthStateChanged'](_0x7d9298,_0x47173a,_0x5ec449){return this['registerStateListener'](this['authStateSubscription'],_0x7d9298,_0x47173a,_0x5ec449);}['beforeAuthStateChanged'](_0x469be6,_0x362656){return this['beforeStateQueue']['pushCallback'](_0x469be6,_0x362656);}['onIdTokenChanged'](_0x309f62,_0x15db2b,_0x3ad44f){return this['registerStateListener'](this['idTokenSubscription'],_0x309f62,_0x15db2b,_0x3ad44f);}['authStateReady'](){return new Promise((_0x32993d,_0x5f279f)=>{if(this['currentUser'])_0x32993d();else{const _0x2133f6=this['onAuthStateChanged'](()=>{_0x2133f6(),_0x32993d();},_0x5f279f);}});}async['revokeAccessToken'](_0x755686){if(this['currentUser']){const _0x3749a9=await this['currentUser']['getIdToken'](),_0x1e5398={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x755686,'idToken':_0x3749a9};this['tenantId']!=null&&(_0x1e5398['tenantId']=this['tenantId']),await bf(this,_0x1e5398);}}['toJSON'](){var _0x228755;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x228755=this['_currentUser'])==null?void 0x0:_0x228755['toJSON']()};}async['_setRedirectUser'](_0x502406,_0x478e30){const _0x10cc3a=await this['getOrInitRedirectPersistenceManager'](_0x478e30);return _0x502406===null?_0x10cc3a['removeCurrentUser']():_0x10cc3a['setCurrentUser'](_0x502406);}async['getOrInitRedirectPersistenceManager'](_0x23c169){if(!this['redirectPersistenceManager']){const _0x1ca0e7=_0x23c169&&ie(_0x23c169)||this['_popupRedirectResolver'];m(_0x1ca0e7,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x1ca0e7['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3952a6){var _0x31c49b,_0x433694;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x31c49b=this['_currentUser'])==null?void 0x0:_0x31c49b['_redirectEventId'])===_0x3952a6?this['_currentUser']:((_0x433694=this['redirectUser'])==null?void 0x0:_0x433694['_redirectEventId'])===_0x3952a6?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x53e1ce){if(_0x53e1ce===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x53e1ce));}['_notifyListenersIfCurrent'](_0x531322){_0x531322===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1a7a0e;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x2da261=((_0x1a7a0e=this['currentUser'])==null?void 0x0:_0x1a7a0e['uid'])??null;this['lastNotifiedUid']!==_0x2da261&&(this['lastNotifiedUid']=_0x2da261,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x4f4084,_0x3f7282,_0x554548,_0x419767){if(this['_deleted'])return()=>{};const _0x3a0fc4=typeof _0x3f7282=='function'?_0x3f7282:_0x3f7282['next']['bind'](_0x3f7282);let _0x59de9b=!0x1;const _0x4f3ee8=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4f3ee8,this,'internal-error'),_0x4f3ee8['then'](()=>{_0x59de9b||_0x3a0fc4(this['currentUser']);}),typeof _0x3f7282=='function'){const _0x41b16f=_0x4f4084['addObserver'](_0x3f7282,_0x554548,_0x419767);return()=>{_0x59de9b=!0x0,_0x41b16f();};}else{const _0x529115=_0x4f4084['addObserver'](_0x3f7282);return()=>{_0x59de9b=!0x0,_0x529115();};}}async['directlySetCurrentUser'](_0x575a00){this['currentUser']&&this['currentUser']!==_0x575a00&&this['_currentUser']['_stopProactiveRefresh'](),_0x575a00&&this['isProactiveRefreshEnabled']&&_0x575a00['_startProactiveRefresh'](),this['currentUser']=_0x575a00,_0x575a00?await this['assertedPersistence']['setCurrentUser'](_0x575a00):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2ec388){return this['operations']=this['operations']['then'](_0x2ec388,_0x2ec388),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x57315b){!_0x57315b||this['frameworks']['includes'](_0x57315b)||(this['frameworks']['push'](_0x57315b),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x43aa99;const _0x450613={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x450613['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x5bf71e=await((_0x43aa99=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x43aa99['getHeartbeatsHeader']());_0x5bf71e&&(_0x450613['X-Firebase-Client']=_0x5bf71e);const _0x9c1f45=await this['_getAppCheckToken']();return _0x9c1f45&&(_0x450613['X-Firebase-AppCheck']=_0x9c1f45),_0x450613;}async['_getAppCheckToken'](){var _0x5cb5c6;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x248c26=await((_0x5cb5c6=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5cb5c6['getToken']());return _0x248c26!=null&&_0x248c26['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x248c26['error']),_0x248c26==null?void 0x0:_0x248c26['token'];}}function Ke(_0x34598d){return P(_0x34598d);}class Rr{constructor(_0x57987b){this['auth']=_0x57987b,this['observer']=null,this['addObserver']=Tc(_0x2d592b=>this['observer']=_0x2d592b);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x15c9d9){Jn=_0x15c9d9;}function xa(_0x2b136e){return Jn['loadJS'](_0x2b136e);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x10f2f7){return'__'+_0x10f2f7+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x27e7cf){_0x27e7cf();}['execute'](_0x1cce3d,_0x5ce37a){return Promise['resolve']('token');}['render'](_0x320710,_0x441058){return'';}}class Wf{['ready'](_0xb18640){_0xb18640();}['execute'](_0x5128a7,_0x2e81f0){return Promise['resolve']('token');}['render'](_0x335d18,_0x5f3c79){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x3d8cb5){this['type']=Bf,this['auth']=Ke(_0x3d8cb5);}async['verify'](_0x5425b2='verify',_0x50e28a=!0x1){async function _0x41916a(_0x2a5eff){if(!_0x50e28a){if(_0x2a5eff['tenantId']==null&&_0x2a5eff['_agentRecaptchaConfig']!=null)return _0x2a5eff['_agentRecaptchaConfig']['siteKey'];if(_0x2a5eff['tenantId']!=null&&_0x2a5eff['_tenantRecaptchaConfigs'][_0x2a5eff['tenantId']]!==void 0x0)return _0x2a5eff['_tenantRecaptchaConfigs'][_0x2a5eff['tenantId']]['siteKey'];}return new Promise(async(_0x23ac90,_0x548d57)=>{yf(_0x2a5eff,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x32f6bb=>{if(_0x32f6bb['recaptchaKey']===void 0x0)_0x548d57(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x586fc2=new mf(_0x32f6bb);return _0x2a5eff['tenantId']==null?_0x2a5eff['_agentRecaptchaConfig']=_0x586fc2:_0x2a5eff['_tenantRecaptchaConfigs'][_0x2a5eff['tenantId']]=_0x586fc2,_0x23ac90(_0x586fc2['siteKey']);}})['catch'](_0x53b049=>{_0x548d57(_0x53b049);});});}function _0xa024b0(_0x32c153,_0x38c868,_0x1bd6a5){const _0x4830f7=window['grecaptcha'];wr(_0x4830f7)?_0x4830f7['enterprise']['ready'](()=>{_0x4830f7['enterprise']['execute'](_0x32c153,{'action':_0x5425b2})['then'](_0x542754=>{_0x38c868(_0x542754);})['catch'](()=>{_0x38c868(Fa);});}):_0x1bd6a5(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0xe4df32,_0x44eda3)=>{_0x41916a(this['auth'])['then'](async _0x1f434b=>{if(!_0x50e28a&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0xa024b0(_0x1f434b,_0xe4df32,_0x44eda3);else{if(typeof window>'u'){_0x44eda3(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x208af1=Lf();_0x208af1['length']!==0x0&&(_0x208af1+=_0x1f434b+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x111924;(_0x111924=he['scriptInjectionDeferred'])==null||_0x111924['resolve']();},xa(_0x208af1)['then'](()=>{var _0x57b051;return(_0x57b051=he['scriptInjectionDeferred'])==null?void 0x0:_0x57b051['promise'];})['then'](()=>{_0xa024b0(_0x1f434b,_0xe4df32,_0x44eda3);})['catch'](_0x1ace87=>{_0x44eda3(_0x1ace87);});}})['catch'](_0x3a62ff=>{_0x44eda3(_0x3a62ff);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x285fbc,_0x366ed4,_0x3bf857,_0x48a1e9=!0x1,_0x53cba7=!0x1){const _0x28965a=new he(_0x285fbc);let _0x1a59c2;if(_0x53cba7)_0x1a59c2=Fa;else try{_0x1a59c2=await _0x28965a['verify'](_0x3bf857);}catch{_0x1a59c2=await _0x28965a['verify'](_0x3bf857,!0x0);}const _0x1e8579={..._0x366ed4};if(_0x3bf857==='mfaSmsEnrollment'||_0x3bf857==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1e8579){const _0x546e90=_0x1e8579['phoneEnrollmentInfo']['phoneNumber'],_0x7a139=_0x1e8579['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1e8579,{'phoneEnrollmentInfo':{'phoneNumber':_0x546e90,'recaptchaToken':_0x7a139,'captchaResponse':_0x1a59c2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1e8579){const _0x4c253b=_0x1e8579['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1e8579,{'phoneSignInInfo':{'recaptchaToken':_0x4c253b,'captchaResponse':_0x1a59c2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1e8579;}return _0x48a1e9?Object['assign'](_0x1e8579,{'captchaResp':_0x1a59c2}):Object['assign'](_0x1e8579,{'captchaResponse':_0x1a59c2}),Object['assign'](_0x1e8579,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1e8579,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1e8579;}async function xi(_0xaed4d2,_0x256be6,_0x44c929,_0x5561fe,_0x1207b3){var _0x5b8136;if((_0x5b8136=_0xaed4d2['_getRecaptchaConfig']())!=null&&_0x5b8136['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x285860=await kr(_0xaed4d2,_0x256be6,_0x44c929,_0x44c929==='getOobCode');return _0x5561fe(_0xaed4d2,_0x285860);}else return _0x5561fe(_0xaed4d2,_0x256be6)['catch'](async _0x3b6110=>{if(_0x3b6110['code']==='auth/missing-recaptcha-token'){console['log'](_0x44c929+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1f66ce=await kr(_0xaed4d2,_0x256be6,_0x44c929,_0x44c929==='getOobCode');return _0x5561fe(_0xaed4d2,_0x1f66ce);}else return Promise['reject'](_0x3b6110);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x2e9f86,_0xbbb2d){const _0x2b42cc=Hi(_0x2e9f86,'auth');if(_0x2b42cc['isInitialized']()){const _0x2b6852=_0x2b42cc['getImmediate'](),_0x4b3502=_0x2b42cc['getOptions']();if(xe(_0x4b3502,_0xbbb2d??{}))return _0x2b6852;Y(_0x2b6852,'already-initialized');}return _0x2b42cc['initialize']({'options':_0xbbb2d});}function Hf(_0x3a9648,_0x38eedd){const _0x386f41=(_0x38eedd==null?void 0x0:_0x38eedd['persistence'])||[],_0x217fb7=(Array['isArray'](_0x386f41)?_0x386f41:[_0x386f41])['map'](ie);_0x38eedd!=null&&_0x38eedd['errorMap']&&_0x3a9648['_updateErrorMap'](_0x38eedd['errorMap']),_0x3a9648['_initializeWithPersistence'](_0x217fb7,_0x38eedd==null?void 0x0:_0x38eedd['popupRedirectResolver']);}function $f(_0x3db4d6,_0x3a1fd8,_0x10de4d){const _0xba31cd=Ke(_0x3db4d6);m(/^https?:\/\//['test'](_0x3a1fd8),_0xba31cd,'invalid-emulator-scheme');const _0x4eaa5a=!0x1,_0x17b04e=Ua(_0x3a1fd8),{host:_0x5abcb0,port:_0x4e4be3}=Gf(_0x3a1fd8),_0x2a9d0c=_0x4e4be3===null?'':':'+_0x4e4be3,_0x5501ab={'url':_0x17b04e+'//'+_0x5abcb0+_0x2a9d0c+'/'},_0x397c91=Object['freeze']({'host':_0x5abcb0,'port':_0x4e4be3,'protocol':_0x17b04e['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4eaa5a})});if(!_0xba31cd['_canInitEmulator']){m(_0xba31cd['config']['emulator']&&_0xba31cd['emulatorConfig'],_0xba31cd,'emulator-config-failed'),m(xe(_0x5501ab,_0xba31cd['config']['emulator'])&&xe(_0x397c91,_0xba31cd['emulatorConfig']),_0xba31cd,'emulator-config-failed');return;}_0xba31cd['config']['emulator']=_0x5501ab,_0xba31cd['emulatorConfig']=_0x397c91,_0xba31cd['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x5abcb0)?Qr(_0x17b04e+'//'+_0x5abcb0+_0x2a9d0c):qf();}function Ua(_0x576b57){const _0x15c3b0=_0x576b57['indexOf'](':');return _0x15c3b0<0x0?'':_0x576b57['substr'](0x0,_0x15c3b0+0x1);}function Gf(_0x1e203a){const _0x50f3cf=Ua(_0x1e203a),_0x2d6082=/(\/\/)?([^?#/]+)/['exec'](_0x1e203a['substr'](_0x50f3cf['length']));if(!_0x2d6082)return{'host':'','port':null};const _0x775041=_0x2d6082[0x2]['split']('@')['pop']()||'',_0x1bf001=/^(\[[^\]]+\])(:|$)/['exec'](_0x775041);if(_0x1bf001){const _0x1fc606=_0x1bf001[0x1];return{'host':_0x1fc606,'port':Pr(_0x775041['substr'](_0x1fc606['length']+0x1))};}else{const [_0x12c80d,_0x2508ea]=_0x775041['split'](':');return{'host':_0x12c80d,'port':Pr(_0x2508ea)};}}function Pr(_0x3b8299){if(!_0x3b8299)return null;const _0x4ff480=Number(_0x3b8299);return isNaN(_0x4ff480)?null:_0x4ff480;}function qf(){function _0x5592f5(){const _0x5536a5=document['createElement']('p'),_0x318d76=_0x5536a5['style'];_0x5536a5['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x318d76['position']='fixed',_0x318d76['width']='100%',_0x318d76['backgroundColor']='#ffffff',_0x318d76['border']='.1em\x20solid\x20#000000',_0x318d76['color']='#b50000',_0x318d76['bottom']='0px',_0x318d76['left']='0px',_0x318d76['margin']='0px',_0x318d76['zIndex']='10000',_0x318d76['textAlign']='center',_0x5536a5['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x5536a5);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x5592f5):_0x5592f5());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x2e21cf,_0x19951e){this['providerId']=_0x2e21cf,this['signInMethod']=_0x19951e;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x200bc3){return ne('not\x20implemented');}['_linkToIdToken'](_0x33ebb6,_0x957c34){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x48ec0d){return ne('not\x20implemented');}}async function zf(_0x4817ce,_0x2a3976){return Pe(_0x4817ce,'POST','/v1/accounts:signUp',_0x2a3976);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x349fb6,_0x2c4b68){return en(_0x349fb6,'POST','/v1/accounts:signInWithPassword',ke(_0x349fb6,_0x2c4b68));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x56af28,_0x52c005){return en(_0x56af28,'POST','/v1/accounts:signInWithEmailLink',ke(_0x56af28,_0x52c005));}async function Yf(_0x245ca6,_0x55146f){return en(_0x245ca6,'POST','/v1/accounts:signInWithEmailLink',ke(_0x245ca6,_0x55146f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x1907ad,_0x9d6d62,_0x580c77,_0x3190a5=null){super('password',_0x580c77),this['_email']=_0x1907ad,this['_password']=_0x9d6d62,this['_tenantId']=_0x3190a5;}static['_fromEmailAndPassword'](_0x343c2e,_0xd3c61f){return new $t(_0x343c2e,_0xd3c61f,'password');}static['_fromEmailAndCode'](_0x3cab07,_0x3f275d,_0x4c371b=null){return new $t(_0x3cab07,_0x3f275d,'emailLink',_0x4c371b);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x217c23){const _0x3bd829=typeof _0x217c23=='string'?JSON['parse'](_0x217c23):_0x217c23;if(_0x3bd829!=null&&_0x3bd829['email']&&(_0x3bd829!=null&&_0x3bd829['password'])){if(_0x3bd829['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3bd829['email'],_0x3bd829['password']);if(_0x3bd829['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3bd829['email'],_0x3bd829['password'],_0x3bd829['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1e3fac){switch(this['signInMethod']){case'password':const _0x35bae8={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1e3fac,_0x35bae8,'signInWithPassword',jf);case'emailLink':return Kf(_0x1e3fac,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1e3fac,'internal-error');}}async['_linkToIdToken'](_0x556b26,_0x4530aa){switch(this['signInMethod']){case'password':const _0x3fdcae={'idToken':_0x4530aa,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x556b26,_0x3fdcae,'signUpPassword',zf);case'emailLink':return Yf(_0x556b26,{'idToken':_0x4530aa,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x556b26,'internal-error');}}['_getReauthenticationResolver'](_0x33c820){return this['_getIdTokenResponse'](_0x33c820);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0xe43200,_0x938118){return en(_0xe43200,'POST','/v1/accounts:signInWithIdp',ke(_0xe43200,_0x938118));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3202bc){const _0x1b6733=new $e(_0x3202bc['providerId'],_0x3202bc['signInMethod']);return _0x3202bc['idToken']||_0x3202bc['accessToken']?(_0x3202bc['idToken']&&(_0x1b6733['idToken']=_0x3202bc['idToken']),_0x3202bc['accessToken']&&(_0x1b6733['accessToken']=_0x3202bc['accessToken']),_0x3202bc['nonce']&&!_0x3202bc['pendingToken']&&(_0x1b6733['nonce']=_0x3202bc['nonce']),_0x3202bc['pendingToken']&&(_0x1b6733['pendingToken']=_0x3202bc['pendingToken'])):_0x3202bc['oauthToken']&&_0x3202bc['oauthTokenSecret']?(_0x1b6733['accessToken']=_0x3202bc['oauthToken'],_0x1b6733['secret']=_0x3202bc['oauthTokenSecret']):Y('argument-error'),_0x1b6733;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2ca40f){const _0x37e7e0=typeof _0x2ca40f=='string'?JSON['parse'](_0x2ca40f):_0x2ca40f,{providerId:_0x1e907e,signInMethod:_0x232eb,..._0x26e2ab}=_0x37e7e0;if(!_0x1e907e||!_0x232eb)return null;const _0x44f950=new $e(_0x1e907e,_0x232eb);return _0x44f950['idToken']=_0x26e2ab['idToken']||void 0x0,_0x44f950['accessToken']=_0x26e2ab['accessToken']||void 0x0,_0x44f950['secret']=_0x26e2ab['secret'],_0x44f950['nonce']=_0x26e2ab['nonce'],_0x44f950['pendingToken']=_0x26e2ab['pendingToken']||null,_0x44f950;}['_getIdTokenResponse'](_0x3100db){const _0xa96d39=this['buildRequest']();return nt(_0x3100db,_0xa96d39);}['_linkToIdToken'](_0x52ab2f,_0xa16a5e){const _0x43a5ed=this['buildRequest']();return _0x43a5ed['idToken']=_0xa16a5e,nt(_0x52ab2f,_0x43a5ed);}['_getReauthenticationResolver'](_0x2f8d06){const _0x700913=this['buildRequest']();return _0x700913['autoCreate']=!0x1,nt(_0x2f8d06,_0x700913);}['buildRequest'](){const _0x37d6fc={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x37d6fc['pendingToken']=this['pendingToken'];else{const _0x5346c0={};this['idToken']&&(_0x5346c0['id_token']=this['idToken']),this['accessToken']&&(_0x5346c0['access_token']=this['accessToken']),this['secret']&&(_0x5346c0['oauth_token_secret']=this['secret']),_0x5346c0['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5346c0['nonce']=this['nonce']),_0x37d6fc['postBody']=ut(_0x5346c0);}return _0x37d6fc;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x2d42ed){switch(_0x2d42ed){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x2b8ffe){const _0x41c0e1=Ct(Tt(_0x2b8ffe))['link'],_0x5c8b0a=_0x41c0e1?Ct(Tt(_0x41c0e1))['deep_link_id']:null,_0x228c25=Ct(Tt(_0x2b8ffe))['deep_link_id'];return(_0x228c25?Ct(Tt(_0x228c25))['link']:null)||_0x228c25||_0x5c8b0a||_0x41c0e1||_0x2b8ffe;}class Rs{constructor(_0x52ddb2){const _0x4974b5=Ct(Tt(_0x52ddb2)),_0x3c8bcb=_0x4974b5['apiKey']??null,_0x4ecd29=_0x4974b5['oobCode']??null,_0x5b1a28=Jf(_0x4974b5['mode']??null);m(_0x3c8bcb&&_0x4ecd29&&_0x5b1a28,'argument-error'),this['apiKey']=_0x3c8bcb,this['operation']=_0x5b1a28,this['code']=_0x4ecd29,this['continueUrl']=_0x4974b5['continueUrl']??null,this['languageCode']=_0x4974b5['lang']??null,this['tenantId']=_0x4974b5['tenantId']??null;}static['parseLink'](_0xfc006e){const _0x3de157=Xf(_0xfc006e);try{return new Rs(_0x3de157);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x25e4d2,_0x26833b){return $t['_fromEmailAndPassword'](_0x25e4d2,_0x26833b);}static['credentialWithLink'](_0x53a085,_0x2b99e5){const _0x3ec8d9=Rs['parseLink'](_0x2b99e5);return m(_0x3ec8d9,'argument-error'),$t['_fromEmailAndCode'](_0x53a085,_0x3ec8d9['code'],_0x3ec8d9['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x362128){this['providerId']=_0x362128,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x483d12){this['defaultLanguageCode']=_0x483d12;}['setCustomParameters'](_0x1937f5){return this['customParameters']=_0x1937f5,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1e7a30){return this['scopes']['includes'](_0x1e7a30)||this['scopes']['push'](_0x1e7a30),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x158c05){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x158c05});}static['credentialFromResult'](_0x174444){return ue['credentialFromTaggedObject'](_0x174444);}static['credentialFromError'](_0x4b926e){return ue['credentialFromTaggedObject'](_0x4b926e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1cca04}){if(!_0x1cca04||!('oauthAccessToken'in _0x1cca04)||!_0x1cca04['oauthAccessToken'])return null;try{return ue['credential'](_0x1cca04['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xe2df70,_0x281b5b){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xe2df70,'accessToken':_0x281b5b});}static['credentialFromResult'](_0x4b53b2){return de['credentialFromTaggedObject'](_0x4b53b2);}static['credentialFromError'](_0x4a7aaa){return de['credentialFromTaggedObject'](_0x4a7aaa['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2f295b}){if(!_0x2f295b)return null;const {oauthIdToken:_0x53028f,oauthAccessToken:_0x464b4b}=_0x2f295b;if(!_0x53028f&&!_0x464b4b)return null;try{return de['credential'](_0x53028f,_0x464b4b);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x235209){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x235209});}static['credentialFromResult'](_0x366c13){return fe['credentialFromTaggedObject'](_0x366c13);}static['credentialFromError'](_0x5b2807){return fe['credentialFromTaggedObject'](_0x5b2807['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x392b36}){if(!_0x392b36||!('oauthAccessToken'in _0x392b36)||!_0x392b36['oauthAccessToken'])return null;try{return fe['credential'](_0x392b36['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x364b54,_0x5b13f5){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x364b54,'oauthTokenSecret':_0x5b13f5});}static['credentialFromResult'](_0x6ef942){return pe['credentialFromTaggedObject'](_0x6ef942);}static['credentialFromError'](_0x2e0270){return pe['credentialFromTaggedObject'](_0x2e0270['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1b64b9}){if(!_0x1b64b9)return null;const {oauthAccessToken:_0x1a94ff,oauthTokenSecret:_0x52c772}=_0x1b64b9;if(!_0x1a94ff||!_0x52c772)return null;try{return pe['credential'](_0x1a94ff,_0x52c772);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x2271b6,_0x2a1579){return en(_0x2271b6,'POST','/v1/accounts:signUp',ke(_0x2271b6,_0x2a1579));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x51fa06){this['user']=_0x51fa06['user'],this['providerId']=_0x51fa06['providerId'],this['_tokenResponse']=_0x51fa06['_tokenResponse'],this['operationType']=_0x51fa06['operationType'];}static async['_fromIdTokenResponse'](_0x107ee7,_0x59331d,_0x50a626,_0x391751=!0x1){const _0x2ef98e=await j['_fromIdTokenResponse'](_0x107ee7,_0x50a626,_0x391751),_0x255ece=Nr(_0x50a626);return new Ge({'user':_0x2ef98e,'providerId':_0x255ece,'_tokenResponse':_0x50a626,'operationType':_0x59331d});}static async['_forOperation'](_0x162c84,_0x55ee79,_0x1adfdd){await _0x162c84['_updateTokensIfNecessary'](_0x1adfdd,!0x0);const _0x2676d2=Nr(_0x1adfdd);return new Ge({'user':_0x162c84,'providerId':_0x2676d2,'_tokenResponse':_0x1adfdd,'operationType':_0x55ee79});}}function Nr(_0x4029d1){return _0x4029d1['providerId']?_0x4029d1['providerId']:'phoneNumber'in _0x4029d1?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x23b20c,_0x2ba8a9,_0xc7c4a2,_0x4a6f1d){super(_0x2ba8a9['code'],_0x2ba8a9['message']),this['operationType']=_0xc7c4a2,this['user']=_0x4a6f1d,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x23b20c['name'],'tenantId':_0x23b20c['tenantId']??void 0x0,'_serverResponse':_0x2ba8a9['customData']['_serverResponse'],'operationType':_0xc7c4a2};}static['_fromErrorAndOperation'](_0xba07b6,_0x3ab1b3,_0x2f7171,_0x302dc7){return new On(_0xba07b6,_0x3ab1b3,_0x2f7171,_0x302dc7);}}function Ba(_0x2b756e,_0x38d34c,_0x4aef46,_0x172686){return(_0x38d34c==='reauthenticate'?_0x4aef46['_getReauthenticationResolver'](_0x2b756e):_0x4aef46['_getIdTokenResponse'](_0x2b756e))['catch'](_0x18ad1f=>{throw _0x18ad1f['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x2b756e,_0x18ad1f,_0x38d34c,_0x172686):_0x18ad1f;});}async function ep(_0x553b9d,_0x44fcb2,_0x9243fe=!0x1){const _0x510311=await Ht(_0x553b9d,_0x44fcb2['_linkToIdToken'](_0x553b9d['auth'],await _0x553b9d['getIdToken']()),_0x9243fe);return Ge['_forOperation'](_0x553b9d,'link',_0x510311);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x49fa3b,_0x273183,_0x571d31=!0x1){const {auth:_0x112a14}=_0x49fa3b;if($(_0x112a14['app']))return Promise['reject'](re(_0x112a14));const _0x5784d1='reauthenticate';try{const _0x46647a=await Ht(_0x49fa3b,Ba(_0x112a14,_0x5784d1,_0x273183,_0x49fa3b),_0x571d31);m(_0x46647a['idToken'],_0x112a14,'internal-error');const _0x340c58=Ts(_0x46647a['idToken']);m(_0x340c58,_0x112a14,'internal-error');const {sub:_0x350937}=_0x340c58;return m(_0x49fa3b['uid']===_0x350937,_0x112a14,'user-mismatch'),Ge['_forOperation'](_0x49fa3b,_0x5784d1,_0x46647a);}catch(_0x2e6087){throw(_0x2e6087==null?void 0x0:_0x2e6087['code'])==='auth/user-not-found'&&Y(_0x112a14,'user-mismatch'),_0x2e6087;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x966476,_0x3c606f,_0x4cc46b=!0x1){if($(_0x966476['app']))return Promise['reject'](re(_0x966476));const _0x5a2097='signIn',_0x490011=await Ba(_0x966476,_0x5a2097,_0x3c606f),_0xb3fb8e=await Ge['_fromIdTokenResponse'](_0x966476,_0x5a2097,_0x490011);return _0x4cc46b||await _0x966476['_updateCurrentUser'](_0xb3fb8e['user']),_0xb3fb8e;}async function np(_0x5dd645,_0x175550){return Va(Ke(_0x5dd645),_0x175550);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x5c7c2c){const _0x47a997=Ke(_0x5c7c2c);_0x47a997['_getPasswordPolicyInternal']()&&await _0x47a997['_updatePasswordPolicy']();}async function L_(_0x243ffb,_0x38bdbb,_0x1b08f1){if($(_0x243ffb['app']))return Promise['reject'](re(_0x243ffb));const _0x137528=Ke(_0x243ffb),_0x771046=await xi(_0x137528,{'returnSecureToken':!0x0,'email':_0x38bdbb,'password':_0x1b08f1,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x4a7741=>{throw _0x4a7741['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x243ffb),_0x4a7741;}),_0x23dea3=await Ge['_fromIdTokenResponse'](_0x137528,'signIn',_0x771046);return await _0x137528['_updateCurrentUser'](_0x23dea3['user']),_0x23dea3;}function x_(_0x2629c2,_0x4583e8,_0x44bb3){return $(_0x2629c2['app'])?Promise['reject'](re(_0x2629c2)):np(P(_0x2629c2),yt['credential'](_0x4583e8,_0x44bb3))['catch'](async _0x2f9b3c=>{throw _0x2f9b3c['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x2629c2),_0x2f9b3c;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x2caa21,_0x16f062){return P(_0x2caa21)['setPersistence'](_0x16f062);}function ip(_0x5b12de,_0x59a642,_0x2c109e,_0x1739c9){return P(_0x5b12de)['onIdTokenChanged'](_0x59a642,_0x2c109e,_0x1739c9);}function sp(_0x3a9d86,_0x1c0e8c,_0x5001d9){return P(_0x3a9d86)['beforeAuthStateChanged'](_0x1c0e8c,_0x5001d9);}function U_(_0x2551c9,_0x50726f,_0x431e24,_0x17c3b1){return P(_0x2551c9)['onAuthStateChanged'](_0x50726f,_0x431e24,_0x17c3b1);}function W_(_0x574b4c){return P(_0x574b4c)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x479bf4,_0x39c5a4){this['storageRetriever']=_0x479bf4,this['type']=_0x39c5a4;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x504e60,_0x228eb2){return this['storage']['setItem'](_0x504e60,JSON['stringify'](_0x228eb2)),Promise['resolve']();}['_get'](_0x372eae){const _0x59bbbf=this['storage']['getItem'](_0x372eae);return Promise['resolve'](_0x59bbbf?JSON['parse'](_0x59bbbf):null);}['_remove'](_0x462f56){return this['storage']['removeItem'](_0x462f56),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3909b7,_0x576e12)=>this['onStorageEvent'](_0x3909b7,_0x576e12),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x8f0411){for(const _0x103787 of Object['keys'](this['listeners'])){const _0x3db61e=this['storage']['getItem'](_0x103787),_0x173d62=this['localCache'][_0x103787];_0x3db61e!==_0x173d62&&_0x8f0411(_0x103787,_0x173d62,_0x3db61e);}}['onStorageEvent'](_0x414212,_0x543916=!0x1){if(!_0x414212['key']){this['forAllChangedKeys']((_0x7bd1c5,_0x17a9d9,_0x1e314a)=>{this['notifyListeners'](_0x7bd1c5,_0x1e314a);});return;}const _0x5b6614=_0x414212['key'];_0x543916?this['detachListener']():this['stopPolling']();const _0x844b2b=()=>{const _0x36f593=this['storage']['getItem'](_0x5b6614);!_0x543916&&this['localCache'][_0x5b6614]===_0x36f593||this['notifyListeners'](_0x5b6614,_0x36f593);},_0x162a13=this['storage']['getItem'](_0x5b6614);Af()&&_0x162a13!==_0x414212['newValue']&&_0x414212['newValue']!==_0x414212['oldValue']?setTimeout(_0x844b2b,op):_0x844b2b();}['notifyListeners'](_0x24f37e,_0x2e71b3){this['localCache'][_0x24f37e]=_0x2e71b3;const _0x40c8fa=this['listeners'][_0x24f37e];if(_0x40c8fa){for(const _0x3d4e05 of Array['from'](_0x40c8fa))_0x3d4e05(_0x2e71b3&&JSON['parse'](_0x2e71b3));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x242a4f,_0x31c310,_0x3e8611)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x242a4f,'oldValue':_0x31c310,'newValue':_0x3e8611}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x2f7833,_0x3e584e){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x2f7833]||(this['listeners'][_0x2f7833]=new Set(),this['localCache'][_0x2f7833]=this['storage']['getItem'](_0x2f7833)),this['listeners'][_0x2f7833]['add'](_0x3e584e);}['_removeListener'](_0x3251be,_0xaa1a5b){this['listeners'][_0x3251be]&&(this['listeners'][_0x3251be]['delete'](_0xaa1a5b),this['listeners'][_0x3251be]['size']===0x0&&delete this['listeners'][_0x3251be]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x54b269,_0x4d56ca){await super['_set'](_0x54b269,_0x4d56ca),this['localCache'][_0x54b269]=JSON['stringify'](_0x4d56ca);}async['_get'](_0x5f41f0){const _0x1e0823=await super['_get'](_0x5f41f0);return this['localCache'][_0x5f41f0]=JSON['stringify'](_0x1e0823),_0x1e0823;}async['_remove'](_0x2cb766){await super['_remove'](_0x2cb766),delete this['localCache'][_0x2cb766];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x46aa82,_0x577c79){}['_removeListener'](_0x4aab86,_0x359318){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x35d335){return Promise['all'](_0x35d335['map'](async _0x5cc9a1=>{try{return{'fulfilled':!0x0,'value':await _0x5cc9a1};}catch(_0x4e8245){return{'fulfilled':!0x1,'reason':_0x4e8245};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x172594){this['eventTarget']=_0x172594,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1b4900){const _0x2049fc=this['receivers']['find'](_0x1af5a=>_0x1af5a['isListeningto'](_0x1b4900));if(_0x2049fc)return _0x2049fc;const _0x24dedb=new Xn(_0x1b4900);return this['receivers']['push'](_0x24dedb),_0x24dedb;}['isListeningto'](_0xd7c8da){return this['eventTarget']===_0xd7c8da;}async['handleEvent'](_0x2fd36e){const _0x54db4e=_0x2fd36e,{eventId:_0x313cfe,eventType:_0x1bbe32,data:_0x3cf189}=_0x54db4e['data'],_0x2a5907=this['handlersMap'][_0x1bbe32];if(!(_0x2a5907!=null&&_0x2a5907['size']))return;_0x54db4e['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x313cfe,'eventType':_0x1bbe32});const _0x3ff0fe=Array['from'](_0x2a5907)['map'](async _0x2922be=>_0x2922be(_0x54db4e['origin'],_0x3cf189)),_0x52e9f7=await cp(_0x3ff0fe);_0x54db4e['ports'][0x0]['postMessage']({'status':'done','eventId':_0x313cfe,'eventType':_0x1bbe32,'response':_0x52e9f7});}['_subscribe'](_0x2a238b,_0x1fa698){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2a238b]||(this['handlersMap'][_0x2a238b]=new Set()),this['handlersMap'][_0x2a238b]['add'](_0x1fa698);}['_unsubscribe'](_0x519f84,_0x3191c3){this['handlersMap'][_0x519f84]&&_0x3191c3&&this['handlersMap'][_0x519f84]['delete'](_0x3191c3),(!_0x3191c3||this['handlersMap'][_0x519f84]['size']===0x0)&&delete this['handlersMap'][_0x519f84],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x56c0c9='',_0x42e373=0xa){let _0x3443fa='';for(let _0x2e065e=0x0;_0x2e065e<_0x42e373;_0x2e065e++)_0x3443fa+=Math['floor'](Math['random']()*0xa);return _0x56c0c9+_0x3443fa;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x59dbbb){this['target']=_0x59dbbb,this['handlers']=new Set();}['removeMessageHandler'](_0x4d5f81){_0x4d5f81['messageChannel']&&(_0x4d5f81['messageChannel']['port1']['removeEventListener']('message',_0x4d5f81['onMessage']),_0x4d5f81['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4d5f81);}async['_send'](_0xfc47a0,_0x521027,_0x447e94=0x32){const _0x196b45=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x196b45)throw new Error('connection_unavailable');let _0x49490c,_0x53ef42;return new Promise((_0x26e9f2,_0x43e023)=>{const _0x4d25e6=As('',0x14);_0x196b45['port1']['start']();const _0x13fecf=setTimeout(()=>{_0x43e023(new Error('unsupported_event'));},_0x447e94);_0x53ef42={'messageChannel':_0x196b45,'onMessage'(_0x438245){const _0x423f08=_0x438245;if(_0x423f08['data']['eventId']===_0x4d25e6)switch(_0x423f08['data']['status']){case'ack':clearTimeout(_0x13fecf),_0x49490c=setTimeout(()=>{_0x43e023(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x49490c),_0x26e9f2(_0x423f08['data']['response']);break;default:clearTimeout(_0x13fecf),clearTimeout(_0x49490c),_0x43e023(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x53ef42),_0x196b45['port1']['addEventListener']('message',_0x53ef42['onMessage']),this['target']['postMessage']({'eventType':_0xfc47a0,'eventId':_0x4d25e6,'data':_0x521027},[_0x196b45['port2']]);})['finally'](()=>{_0x53ef42&&this['removeMessageHandler'](_0x53ef42);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x4c510e){Z()['location']['href']=_0x4c510e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x5870b6;return((_0x5870b6=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5870b6['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x4b57d0){this['request']=_0x4b57d0;}['toPromise'](){return new Promise((_0xc1615,_0x562469)=>{this['request']['addEventListener']('success',()=>{_0xc1615(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x562469(this['request']['error']);});});}}function Zn(_0x1132e9,_0x92fe9){return _0x1132e9['transaction']([Mn],_0x92fe9?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x258fcf=indexedDB['deleteDatabase'](Ka);return new nn(_0x258fcf)['toPromise']();}function Qa(){const _0x575be2=indexedDB['open'](Ka,pp);return new Promise((_0x111090,_0x18d937)=>{_0x575be2['addEventListener']('error',()=>{_0x18d937(_0x575be2['error']);}),_0x575be2['addEventListener']('upgradeneeded',()=>{const _0x41d487=_0x575be2['result'];try{_0x41d487['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x577552){_0x18d937(_0x577552);}}),_0x575be2['addEventListener']('success',async()=>{const _0x184490=_0x575be2['result'];_0x184490['objectStoreNames']['contains'](Mn)?_0x111090(_0x184490):(_0x184490['close'](),await _p(),_0x111090(await Qa()));});});}async function Or(_0x2cd13a,_0x46d198,_0x59e415){const _0x308d9b=Zn(_0x2cd13a,!0x0)['put']({[Ya]:_0x46d198,'value':_0x59e415});return new nn(_0x308d9b)['toPromise']();}async function gp(_0x25ecb4,_0x3d6716){const _0x57b747=Zn(_0x25ecb4,!0x1)['get'](_0x3d6716),_0x527802=await new nn(_0x57b747)['toPromise']();return _0x527802===void 0x0?null:_0x527802['value'];}function Dr(_0x74379c,_0x1f7c92){const _0x5d6bdd=Zn(_0x74379c,!0x0)['delete'](_0x1f7c92);return new nn(_0x5d6bdd)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2e7d2d){let _0x4ec23a=0x0;for(;;)try{const _0x298e24=await this['_openDb']();return await _0x2e7d2d(_0x298e24);}catch(_0x4f09d3){if(_0x4ec23a++>yp)throw _0x4f09d3;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x49efcc,_0x2a0340)=>({'keyProcessed':(await this['_poll']())['includes'](_0x2a0340['key'])})),this['receiver']['_subscribe']('ping',async(_0x235df4,_0xa30d13)=>['keyChanged']);}async['initializeSender'](){var _0x5f1d6d,_0x4e7241;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x59c3ad=await this['sender']['_send']('ping',{},0x320);_0x59c3ad&&(_0x5f1d6d=_0x59c3ad[0x0])!=null&&_0x5f1d6d['fulfilled']&&(_0x4e7241=_0x59c3ad[0x0])!=null&&_0x4e7241['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x3ff100){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x3ff100},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x35c7e3=>{await Or(_0x35c7e3,Dn,'1'),await Dr(_0x35c7e3,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x921ee8){this['pendingWrites']++;try{await _0x921ee8();}finally{this['pendingWrites']--;}}async['_set'](_0x43689a,_0x1d7e2d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3c27cf=>Or(_0x3c27cf,_0x43689a,_0x1d7e2d)),this['localCache'][_0x43689a]=_0x1d7e2d,this['notifyServiceWorker'](_0x43689a)));}async['_get'](_0x1479b0){const _0x2bb746=await this['_withRetries'](_0x8bb7f4=>gp(_0x8bb7f4,_0x1479b0));return this['localCache'][_0x1479b0]=_0x2bb746,_0x2bb746;}async['_remove'](_0x59af14){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x217d87=>Dr(_0x217d87,_0x59af14)),delete this['localCache'][_0x59af14],this['notifyServiceWorker'](_0x59af14)));}async['_poll'](){const _0x57c883=await this['_withRetries'](_0x1538fd=>{const _0x3e4c99=Zn(_0x1538fd,!0x1)['getAll']();return new nn(_0x3e4c99)['toPromise']();});if(!_0x57c883)return[];if(this['pendingWrites']!==0x0)return[];const _0x2529b7=[],_0x52df45=new Set();if(_0x57c883['length']!==0x0){for(const {fbase_key:_0x5a2811,value:_0xaac144}of _0x57c883)_0x52df45['add'](_0x5a2811),JSON['stringify'](this['localCache'][_0x5a2811])!==JSON['stringify'](_0xaac144)&&(this['notifyListeners'](_0x5a2811,_0xaac144),_0x2529b7['push'](_0x5a2811));}for(const _0x20851b of Object['keys'](this['localCache']))this['localCache'][_0x20851b]&&!_0x52df45['has'](_0x20851b)&&(this['notifyListeners'](_0x20851b,null),_0x2529b7['push'](_0x20851b));return _0x2529b7;}['notifyListeners'](_0x38aa58,_0x8ea457){this['localCache'][_0x38aa58]=_0x8ea457;const _0x34e331=this['listeners'][_0x38aa58];if(_0x34e331){for(const _0x44e6a0 of Array['from'](_0x34e331))_0x44e6a0(_0x8ea457);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5cd28f,_0xa572ca){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5cd28f]||(this['listeners'][_0x5cd28f]=new Set(),this['_get'](_0x5cd28f)),this['listeners'][_0x5cd28f]['add'](_0xa572ca);}['_removeListener'](_0x2359a8,_0x47763b){this['listeners'][_0x2359a8]&&(this['listeners'][_0x2359a8]['delete'](_0x47763b),this['listeners'][_0x2359a8]['size']===0x0&&delete this['listeners'][_0x2359a8]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x220560,_0x1e9632){return _0x1e9632?ie(_0x1e9632):(m(_0x220560['_popupRedirectResolver'],_0x220560,'argument-error'),_0x220560['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2048ef){super('custom','custom'),this['params']=_0x2048ef;}['_getIdTokenResponse'](_0x2e732c){return nt(_0x2e732c,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2ae608,_0x20cae8){return nt(_0x2ae608,this['_buildIdpRequest'](_0x20cae8));}['_getReauthenticationResolver'](_0x51028d){return nt(_0x51028d,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x10c19b){const _0x2bc505={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x10c19b&&(_0x2bc505['idToken']=_0x10c19b),_0x2bc505;}}function Ip(_0x18b779){return Va(_0x18b779['auth'],new ks(_0x18b779),_0x18b779['bypassAuthState']);}function wp(_0x2b42eb){const {auth:_0x253354,user:_0x517f32}=_0x2b42eb;return m(_0x517f32,_0x253354,'internal-error'),tp(_0x517f32,new ks(_0x2b42eb),_0x2b42eb['bypassAuthState']);}async function Cp(_0x2a79a2){const {auth:_0x526862,user:_0x40477f}=_0x2a79a2;return m(_0x40477f,_0x526862,'internal-error'),ep(_0x40477f,new ks(_0x2a79a2),_0x2a79a2['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0xe63219,_0x2d447b,_0x38f90f,_0x5aeac1,_0x19c89f=!0x1){this['auth']=_0xe63219,this['resolver']=_0x38f90f,this['user']=_0x5aeac1,this['bypassAuthState']=_0x19c89f,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2d447b)?_0x2d447b:[_0x2d447b];}['execute'](){return new Promise(async(_0x177be5,_0x150e4c)=>{this['pendingPromise']={'resolve':_0x177be5,'reject':_0x150e4c};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2b36b6){this['reject'](_0x2b36b6);}});}async['onAuthEvent'](_0x4c4234){const {urlResponse:_0x5aa315,sessionId:_0x24ebe0,postBody:_0x11f562,tenantId:_0x352f71,error:_0x2c5620,type:_0x2a34c9}=_0x4c4234;if(_0x2c5620){this['reject'](_0x2c5620);return;}const _0x4980b8={'auth':this['auth'],'requestUri':_0x5aa315,'sessionId':_0x24ebe0,'tenantId':_0x352f71||void 0x0,'postBody':_0x11f562||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2a34c9)(_0x4980b8));}catch(_0xee3894){this['reject'](_0xee3894);}}['onError'](_0x5c67f5){this['reject'](_0x5c67f5);}['getIdpTask'](_0x37a72e){switch(_0x37a72e){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x3f7f9b){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3f7f9b),this['unregisterAndCleanUp']();}['reject'](_0x19e3a6){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x19e3a6),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x4abc64,_0x21897d,_0x3330f4,_0x16418a,_0x4134a0){super(_0x4abc64,_0x21897d,_0x16418a,_0x4134a0),this['provider']=_0x3330f4,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x53beee=await this['execute']();return m(_0x53beee,this['auth'],'internal-error'),_0x53beee;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x17d621=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x17d621),this['authWindow']['associatedEvent']=_0x17d621,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2a482d=>{this['reject'](_0x2a482d);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3d031c=>{_0x3d031c||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5339e0;return((_0x5339e0=this['authWindow'])==null?void 0x0:_0x5339e0['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x50c0d3=()=>{var _0x1aa99e,_0x2a1798;if((_0x2a1798=(_0x1aa99e=this['authWindow'])==null?void 0x0:_0x1aa99e['window'])!=null&&_0x2a1798['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x50c0d3,Tp['get']());};_0x50c0d3();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x517e60,_0x573182,_0x194db2=!0x1){super(_0x517e60,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x573182,void 0x0,_0x194db2),this['eventId']=null;}async['execute'](){let _0x9dd00=hn['get'](this['auth']['_key']());if(!_0x9dd00){try{const _0x14c768=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x9dd00=()=>Promise['resolve'](_0x14c768);}catch(_0x440f85){_0x9dd00=()=>Promise['reject'](_0x440f85);}hn['set'](this['auth']['_key'](),_0x9dd00);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x9dd00();}async['onAuthEvent'](_0x325a54){if(_0x325a54['type']==='signInViaRedirect')return super['onAuthEvent'](_0x325a54);if(_0x325a54['type']==='unknown'){this['resolve'](null);return;}if(_0x325a54['eventId']){const _0x4df4f2=await this['auth']['_redirectUserForId'](_0x325a54['eventId']);if(_0x4df4f2)return this['user']=_0x4df4f2,super['onAuthEvent'](_0x325a54);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x19ac72,_0x545e30){const _0x64d3f2=Pp(_0x545e30),_0x440e59=kp(_0x19ac72);if(!await _0x440e59['_isAvailable']())return!0x1;const _0x1cd143=await _0x440e59['_get'](_0x64d3f2)==='true';return await _0x440e59['_remove'](_0x64d3f2),_0x1cd143;}function Ap(_0xbad1c1,_0x1e6ae5){hn['set'](_0xbad1c1['_key'](),_0x1e6ae5);}function kp(_0x12ce48){return ie(_0x12ce48['_redirectPersistence']);}function Pp(_0x5dd294){return ln(Sp,_0x5dd294['config']['apiKey'],_0x5dd294['name']);}async function Np(_0x25306d,_0x15f8eb,_0x42bc86=!0x1){if($(_0x25306d['app']))return Promise['reject'](re(_0x25306d));const _0x15f20d=Ke(_0x25306d),_0x3fdc=Ep(_0x15f20d,_0x15f8eb),_0x33603e=await new bp(_0x15f20d,_0x3fdc,_0x42bc86)['execute']();return _0x33603e&&!_0x42bc86&&(delete _0x33603e['user']['_redirectEventId'],await _0x15f20d['_persistUserIfCurrent'](_0x33603e['user']),await _0x15f20d['_setRedirectUser'](null,_0x15f8eb)),_0x33603e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x32e141){this['auth']=_0x32e141,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1ddde7){this['consumers']['add'](_0x1ddde7),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1ddde7)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1ddde7),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5ec16f){this['consumers']['delete'](_0x5ec16f);}['onEvent'](_0x173029){if(this['hasEventBeenHandled'](_0x173029))return!0x1;let _0x7af528=!0x1;return this['consumers']['forEach'](_0x2c9b12=>{this['isEventForConsumer'](_0x173029,_0x2c9b12)&&(_0x7af528=!0x0,this['sendToConsumer'](_0x173029,_0x2c9b12),this['saveEventToCache'](_0x173029));}),this['hasHandledPotentialRedirect']||!Mp(_0x173029)||(this['hasHandledPotentialRedirect']=!0x0,_0x7af528||(this['queuedRedirectEvent']=_0x173029,_0x7af528=!0x0)),_0x7af528;}['sendToConsumer'](_0xf8d0b5,_0x4ef766){var _0x6d1b3a;if(_0xf8d0b5['error']&&!Za(_0xf8d0b5)){const _0x1ecdd8=((_0x6d1b3a=_0xf8d0b5['error']['code'])==null?void 0x0:_0x6d1b3a['split']('auth/')[0x1])||'internal-error';_0x4ef766['onError'](X(this['auth'],_0x1ecdd8));}else _0x4ef766['onAuthEvent'](_0xf8d0b5);}['isEventForConsumer'](_0x5b5ad1,_0x49008d){const _0x333917=_0x49008d['eventId']===null||!!_0x5b5ad1['eventId']&&_0x5b5ad1['eventId']===_0x49008d['eventId'];return _0x49008d['filter']['includes'](_0x5b5ad1['type'])&&_0x333917;}['hasEventBeenHandled'](_0x1879e4){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x1879e4));}['saveEventToCache'](_0x369d1c){this['cachedEventUids']['add'](Mr(_0x369d1c)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x1f26ce){return[_0x1f26ce['type'],_0x1f26ce['eventId'],_0x1f26ce['sessionId'],_0x1f26ce['tenantId']]['filter'](_0x59df83=>_0x59df83)['join']('-');}function Za({type:_0x19c733,error:_0x4b14c6}){return _0x19c733==='unknown'&&(_0x4b14c6==null?void 0x0:_0x4b14c6['code'])==='auth/no-auth-event';}function Mp(_0x590db0){switch(_0x590db0['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x590db0);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x249deb,_0x5acd98={}){return Pe(_0x249deb,'GET','/v1/projects',_0x5acd98);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x434397){if(_0x434397['config']['emulator'])return;const {authorizedDomains:_0x51ce4e}=await Lp(_0x434397);for(const _0x43bf4a of _0x51ce4e)try{if(Wp(_0x43bf4a))return;}catch{}Y(_0x434397,'unauthorized-domain');}function Wp(_0x260185){const _0x5d83a1=Mi(),{protocol:_0x39a410,hostname:_0x1bd87f}=new URL(_0x5d83a1);if(_0x260185['startsWith']('chrome-extension://')){const _0x2ce784=new URL(_0x260185);return _0x2ce784['hostname']===''&&_0x1bd87f===''?_0x39a410==='chrome-extension:'&&_0x260185['replace']('chrome-extension://','')===_0x5d83a1['replace']('chrome-extension://',''):_0x39a410==='chrome-extension:'&&_0x2ce784['hostname']===_0x1bd87f;}if(!Fp['test'](_0x39a410))return!0x1;if(xp['test'](_0x260185))return _0x1bd87f===_0x260185;const _0x5ee387=_0x260185['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5ee387+'|'+_0x5ee387+')$','i')['test'](_0x1bd87f);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x258e39=Z()['___jsl'];if(_0x258e39!=null&&_0x258e39['H']){for(const _0xdecbd1 of Object['keys'](_0x258e39['H']))if(_0x258e39['H'][_0xdecbd1]['r']=_0x258e39['H'][_0xdecbd1]['r']||[],_0x258e39['H'][_0xdecbd1]['L']=_0x258e39['H'][_0xdecbd1]['L']||[],_0x258e39['H'][_0xdecbd1]['r']=[..._0x258e39['H'][_0xdecbd1]['L']],_0x258e39['CP']){for(let _0x21f811=0x0;_0x21f811<_0x258e39['CP']['length'];_0x21f811++)_0x258e39['CP'][_0x21f811]=null;}}}function Vp(_0x23019a){return new Promise((_0xbb9ce5,_0x42bd23)=>{var _0x23e2b1,_0x2f8cec,_0x4bebb5;function _0x20b11e(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0xbb9ce5(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x42bd23(X(_0x23019a,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x2f8cec=(_0x23e2b1=Z()['gapi'])==null?void 0x0:_0x23e2b1['iframes'])!=null&&_0x2f8cec['Iframe'])_0xbb9ce5(gapi['iframes']['getContext']());else{if((_0x4bebb5=Z()['gapi'])!=null&&_0x4bebb5['load'])_0x20b11e();else{const _0x4562c6=Ff('iframefcb');return Z()[_0x4562c6]=()=>{gapi['load']?_0x20b11e():_0x42bd23(X(_0x23019a,'network-request-failed'));},xa(xf()+'?onload='+_0x4562c6)['catch'](_0x2ee6a6=>_0x42bd23(_0x2ee6a6));}}})['catch'](_0xb2b992=>{throw un=null,_0xb2b992;});}let un=null;function Hp(_0x14a7b4){return un=un||Vp(_0x14a7b4),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0xd82885){const _0x224951=_0xd82885['config'];m(_0x224951['authDomain'],_0xd82885,'auth-domain-config-required');const _0x3f3f46=_0x224951['emulator']?Cs(_0x224951,qp):'https://'+_0xd82885['config']['authDomain']+'/'+Gp,_0x5b76eb={'apiKey':_0x224951['apiKey'],'appName':_0xd82885['name'],'v':dt},_0x1fc049=jp['get'](_0xd82885['config']['apiHost']);_0x1fc049&&(_0x5b76eb['eid']=_0x1fc049);const _0x1ba8e9=_0xd82885['_getFrameworks']();return _0x1ba8e9['length']&&(_0x5b76eb['fw']=_0x1ba8e9['join'](',')),_0x3f3f46+'?'+ut(_0x5b76eb)['slice'](0x1);}async function Yp(_0x2bea7b){const _0x2f1480=await Hp(_0x2bea7b),_0x1241d6=Z()['gapi'];return m(_0x1241d6,_0x2bea7b,'internal-error'),_0x2f1480['open']({'where':document['body'],'url':Kp(_0x2bea7b),'messageHandlersFilter':_0x1241d6['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x16ee1f=>new Promise(async(_0x507a40,_0x24f996)=>{await _0x16ee1f['restyle']({'setHideOnLeave':!0x1});const _0x15167f=X(_0x2bea7b,'network-request-failed'),_0x325499=Z()['setTimeout'](()=>{_0x24f996(_0x15167f);},$p['get']());function _0x63beda(){Z()['clearTimeout'](_0x325499),_0x507a40(_0x16ee1f);}_0x16ee1f['ping'](_0x63beda)['then'](_0x63beda,()=>{_0x24f996(_0x15167f);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x411d30){this['window']=_0x411d30,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x5ddfdf,_0x25e1e9,_0x2330d0,_0x35c530=Jp,_0x2fefaa=Xp){const _0x58c061=Math['max']((window['screen']['availHeight']-_0x2fefaa)/0x2,0x0)['toString'](),_0x5177b7=Math['max']((window['screen']['availWidth']-_0x35c530)/0x2,0x0)['toString']();let _0x20d59d='';const _0xd0815e={...Qp,'width':_0x35c530['toString'](),'height':_0x2fefaa['toString'](),'top':_0x58c061,'left':_0x5177b7},_0x46a3fd=W()['toLowerCase']();_0x2330d0&&(_0x20d59d=ka(_0x46a3fd)?Zp:_0x2330d0),Ra(_0x46a3fd)&&(_0x25e1e9=_0x25e1e9||e_,_0xd0815e['scrollbars']='yes');const _0x2a51d9=Object['entries'](_0xd0815e)['reduce']((_0x38d7d3,[_0xf17a87,_0x51b2ef])=>''+_0x38d7d3+_0xf17a87+'='+_0x51b2ef+',','');if(Rf(_0x46a3fd)&&_0x20d59d!=='_self')return n_(_0x25e1e9||'',_0x20d59d),new xr(null);const _0x5830c5=window['open'](_0x25e1e9||'',_0x20d59d,_0x2a51d9);m(_0x5830c5,_0x5ddfdf,'popup-blocked');try{_0x5830c5['focus']();}catch{}return new xr(_0x5830c5);}function n_(_0x186057,_0x439dfc){const _0x250d48=document['createElement']('a');_0x250d48['href']=_0x186057,_0x250d48['target']=_0x439dfc;const _0x3c0e5d=document['createEvent']('MouseEvent');_0x3c0e5d['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x250d48['dispatchEvent'](_0x3c0e5d);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x1ed58e,_0xebfa4b,_0x225c16,_0x1cd13f,_0x42dbb8,_0x31b267){m(_0x1ed58e['config']['authDomain'],_0x1ed58e,'auth-domain-config-required'),m(_0x1ed58e['config']['apiKey'],_0x1ed58e,'invalid-api-key');const _0x43bf1e={'apiKey':_0x1ed58e['config']['apiKey'],'appName':_0x1ed58e['name'],'authType':_0x225c16,'redirectUrl':_0x1cd13f,'v':dt,'eventId':_0x42dbb8};if(_0xebfa4b instanceof Wa){_0xebfa4b['setDefaultLanguage'](_0x1ed58e['languageCode']),_0x43bf1e['providerId']=_0xebfa4b['providerId']||'',pn(_0xebfa4b['getCustomParameters']())||(_0x43bf1e['customParameters']=JSON['stringify'](_0xebfa4b['getCustomParameters']()));for(const [_0x16f800,_0x4aee20]of Object['entries']({}))_0x43bf1e[_0x16f800]=_0x4aee20;}if(_0xebfa4b instanceof tn){const _0x5ccb17=_0xebfa4b['getScopes']()['filter'](_0x3f8970=>_0x3f8970!=='');_0x5ccb17['length']>0x0&&(_0x43bf1e['scopes']=_0x5ccb17['join'](','));}_0x1ed58e['tenantId']&&(_0x43bf1e['tid']=_0x1ed58e['tenantId']);const _0x238c08=_0x43bf1e;for(const _0x35f212 of Object['keys'](_0x238c08))_0x238c08[_0x35f212]===void 0x0&&delete _0x238c08[_0x35f212];const _0x8930f1=await _0x1ed58e['_getAppCheckToken'](),_0x59df69=_0x8930f1?'#'+r_+'='+encodeURIComponent(_0x8930f1):'';return o_(_0x1ed58e)+'?'+ut(_0x238c08)['slice'](0x1)+_0x59df69;}function o_({config:_0x5b4913}){return _0x5b4913['emulator']?Cs(_0x5b4913,s_):'https://'+_0x5b4913['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0xb17ae8,_0x27f6e1,_0x77d65c,_0x12964e){var _0x492999;ce((_0x492999=this['eventManagers'][_0xb17ae8['_key']()])==null?void 0x0:_0x492999['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5924e7=await Fr(_0xb17ae8,_0x27f6e1,_0x77d65c,Mi(),_0x12964e);return t_(_0xb17ae8,_0x5924e7,As());}async['_openRedirect'](_0x1e2151,_0x54f3d6,_0x351008,_0x591f35){await this['_originValidation'](_0x1e2151);const _0x4040c3=await Fr(_0x1e2151,_0x54f3d6,_0x351008,Mi(),_0x591f35);return hp(_0x4040c3),new Promise(()=>{});}['_initialize'](_0x975756){const _0x2b0e57=_0x975756['_key']();if(this['eventManagers'][_0x2b0e57]){const {manager:_0x22e8ba,promise:_0x5403f1}=this['eventManagers'][_0x2b0e57];return _0x22e8ba?Promise['resolve'](_0x22e8ba):(ce(_0x5403f1,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5403f1);}const _0x3ec5c4=this['initAndGetManager'](_0x975756);return this['eventManagers'][_0x2b0e57]={'promise':_0x3ec5c4},_0x3ec5c4['catch'](()=>{delete this['eventManagers'][_0x2b0e57];}),_0x3ec5c4;}async['initAndGetManager'](_0x1f736f){const _0x168511=await Yp(_0x1f736f),_0x3613b8=new Dp(_0x1f736f);return _0x168511['register']('authEvent',_0x5df700=>(m(_0x5df700==null?void 0x0:_0x5df700['authEvent'],_0x1f736f,'invalid-auth-event'),{'status':_0x3613b8['onEvent'](_0x5df700['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1f736f['_key']()]={'manager':_0x3613b8},this['iframes'][_0x1f736f['_key']()]=_0x168511,_0x3613b8;}['_isIframeWebStorageSupported'](_0x1d9928,_0xa1cc32){this['iframes'][_0x1d9928['_key']()]['send'](pi,{'type':pi},_0x14b6af=>{var _0x5b9143;const _0x3418d4=(_0x5b9143=_0x14b6af==null?void 0x0:_0x14b6af[0x0])==null?void 0x0:_0x5b9143[pi];_0x3418d4!==void 0x0&&_0xa1cc32(!!_0x3418d4),Y(_0x1d9928,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x20f04a){const _0x307496=_0x20f04a['_key']();return this['originValidationPromises'][_0x307496]||(this['originValidationPromises'][_0x307496]=Up(_0x20f04a)),this['originValidationPromises'][_0x307496];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x56ad67){this['auth']=_0x56ad67,this['internalListeners']=new Map();}['getUid'](){var _0x3e9865;return this['assertAuthConfigured'](),((_0x3e9865=this['auth']['currentUser'])==null?void 0x0:_0x3e9865['uid'])||null;}async['getToken'](_0x30f0ad){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x30f0ad)}:null;}['addAuthTokenListener'](_0x287f12){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x287f12))return;const _0x3e698d=this['auth']['onIdTokenChanged'](_0x43fa68=>{_0x287f12((_0x43fa68==null?void 0x0:_0x43fa68['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x287f12,_0x3e698d),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x30d2ff){this['assertAuthConfigured']();const _0x17b4dc=this['internalListeners']['get'](_0x30d2ff);_0x17b4dc&&(this['internalListeners']['delete'](_0x30d2ff),_0x17b4dc(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x21baad){switch(_0x21baad){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x27a4fa){st(new Fe('auth',(_0xd6fecc,{options:_0x3833e9})=>{const _0x34fa2c=_0xd6fecc['getProvider']('app')['getImmediate'](),_0x30ee68=_0xd6fecc['getProvider']('heartbeat'),_0x1f218b=_0xd6fecc['getProvider']('app-check-internal'),{apiKey:_0x1edffb,authDomain:_0x4ee4ad}=_0x34fa2c['options'];m(_0x1edffb&&!_0x1edffb['includes'](':'),'invalid-api-key',{'appName':_0x34fa2c['name']});const _0x1c9782={'apiKey':_0x1edffb,'authDomain':_0x4ee4ad,'clientPlatform':_0x27a4fa,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x27a4fa)},_0x934925=new Df(_0x34fa2c,_0x30ee68,_0x1f218b,_0x1c9782);return Hf(_0x934925,_0x3833e9),_0x934925;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2c353c,_0x304182,_0x5357e3)=>{_0x2c353c['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x379c2b=>{const _0x32f5ba=Ke(_0x379c2b['getProvider']('auth')['getImmediate']());return(_0x3c99ad=>new l_(_0x3c99ad))(_0x32f5ba);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x27a4fa)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x428d02=>async _0x30876c=>{const _0x247dfd=_0x30876c&&await _0x30876c['getIdTokenResult'](),_0x59fa1c=_0x247dfd&&(new Date()['getTime']()-Date['parse'](_0x247dfd['issuedAtTime']))/0x3e8;if(_0x59fa1c&&_0x59fa1c>f_)return;const _0xa15776=_0x247dfd==null?void 0x0:_0x247dfd['token'];Br!==_0xa15776&&(Br=_0xa15776,await fetch(_0x428d02,{'method':_0xa15776?'POST':'DELETE','headers':_0xa15776?{'Authorization':'Bearer\x20'+_0xa15776}:{}}));};function B_(_0x168255=Zr()){const _0x4f7345=Hi(_0x168255,'auth');if(_0x4f7345['isInitialized']())return _0x4f7345['getImmediate']();const _0xd7773d=Vf(_0x168255,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x591af4=jr('authTokenSyncURL');if(_0x591af4&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4e01d4=new URL(_0x591af4,location['origin']);if(location['origin']===_0x4e01d4['origin']){const _0x3e15c7=p_(_0x4e01d4['toString']());sp(_0xd7773d,_0x3e15c7,()=>_0x3e15c7(_0xd7773d['currentUser'])),ip(_0xd7773d,_0x1865f2=>_0x3e15c7(_0x1865f2));}}const _0x43d5dd=qr('auth');return _0x43d5dd&&$f(_0xd7773d,'http://'+_0x43d5dd),_0xd7773d;}function __(){var _0x31508e;return((_0x31508e=document['getElementsByTagName']('head'))==null?void 0x0:_0x31508e[0x0])??document;}Mf({'loadJS'(_0x41ea21){return new Promise((_0x1a0fd3,_0x23042b)=>{const _0x11579f=document['createElement']('script');_0x11579f['setAttribute']('src',_0x41ea21),_0x11579f['onload']=_0x1a0fd3,_0x11579f['onerror']=_0x5e556b=>{const _0x5dd5e9=X('internal-error');_0x5dd5e9['customData']=_0x5e556b,_0x23042b(_0x5dd5e9);},_0x11579f['type']='text/javascript',_0x11579f['charset']='UTF-8',__()['appendChild'](_0x11579f);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};