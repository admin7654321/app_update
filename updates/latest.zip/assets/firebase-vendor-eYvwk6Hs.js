const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x13b0b6,_0x1bef47){if(!_0x13b0b6)throw ht(_0x1bef47);},ht=function(_0x1cffac){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1cffac);},Hr=function(_0x14a5db){const _0x5e2028=[];let _0x565a0a=0x0;for(let _0x3c74c9=0x0;_0x3c74c9<_0x14a5db['length'];_0x3c74c9++){let _0x4711be=_0x14a5db['charCodeAt'](_0x3c74c9);_0x4711be<0x80?_0x5e2028[_0x565a0a++]=_0x4711be:_0x4711be<0x800?(_0x5e2028[_0x565a0a++]=_0x4711be>>0x6|0xc0,_0x5e2028[_0x565a0a++]=_0x4711be&0x3f|0x80):(_0x4711be&0xfc00)===0xd800&&_0x3c74c9+0x1<_0x14a5db['length']&&(_0x14a5db['charCodeAt'](_0x3c74c9+0x1)&0xfc00)===0xdc00?(_0x4711be=0x10000+((_0x4711be&0x3ff)<<0xa)+(_0x14a5db['charCodeAt'](++_0x3c74c9)&0x3ff),_0x5e2028[_0x565a0a++]=_0x4711be>>0x12|0xf0,_0x5e2028[_0x565a0a++]=_0x4711be>>0xc&0x3f|0x80,_0x5e2028[_0x565a0a++]=_0x4711be>>0x6&0x3f|0x80,_0x5e2028[_0x565a0a++]=_0x4711be&0x3f|0x80):(_0x5e2028[_0x565a0a++]=_0x4711be>>0xc|0xe0,_0x5e2028[_0x565a0a++]=_0x4711be>>0x6&0x3f|0x80,_0x5e2028[_0x565a0a++]=_0x4711be&0x3f|0x80);}return _0x5e2028;},nc=function(_0x4ce154){const _0x40f459=[];let _0x193c20=0x0,_0x3f9c2f=0x0;for(;_0x193c20<_0x4ce154['length'];){const _0x2f68b7=_0x4ce154[_0x193c20++];if(_0x2f68b7<0x80)_0x40f459[_0x3f9c2f++]=String['fromCharCode'](_0x2f68b7);else{if(_0x2f68b7>0xbf&&_0x2f68b7<0xe0){const _0x2d256a=_0x4ce154[_0x193c20++];_0x40f459[_0x3f9c2f++]=String['fromCharCode']((_0x2f68b7&0x1f)<<0x6|_0x2d256a&0x3f);}else{if(_0x2f68b7>0xef&&_0x2f68b7<0x16d){const _0x4723ea=_0x4ce154[_0x193c20++],_0x1053a7=_0x4ce154[_0x193c20++],_0x3dd779=_0x4ce154[_0x193c20++],_0x45f669=((_0x2f68b7&0x7)<<0x12|(_0x4723ea&0x3f)<<0xc|(_0x1053a7&0x3f)<<0x6|_0x3dd779&0x3f)-0x10000;_0x40f459[_0x3f9c2f++]=String['fromCharCode'](0xd800+(_0x45f669>>0xa)),_0x40f459[_0x3f9c2f++]=String['fromCharCode'](0xdc00+(_0x45f669&0x3ff));}else{const _0x330252=_0x4ce154[_0x193c20++],_0x5222a2=_0x4ce154[_0x193c20++];_0x40f459[_0x3f9c2f++]=String['fromCharCode']((_0x2f68b7&0xf)<<0xc|(_0x330252&0x3f)<<0x6|_0x5222a2&0x3f);}}}}return _0x40f459['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2e6fc6,_0x16b23d){if(!Array['isArray'](_0x2e6fc6))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3c8f94=_0x16b23d?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4fc2d7=[];for(let _0x2ca473=0x0;_0x2ca473<_0x2e6fc6['length'];_0x2ca473+=0x3){const _0x4c84d1=_0x2e6fc6[_0x2ca473],_0x3294fb=_0x2ca473+0x1<_0x2e6fc6['length'],_0x2352d0=_0x3294fb?_0x2e6fc6[_0x2ca473+0x1]:0x0,_0x1a1e1e=_0x2ca473+0x2<_0x2e6fc6['length'],_0x8b654d=_0x1a1e1e?_0x2e6fc6[_0x2ca473+0x2]:0x0,_0x39629c=_0x4c84d1>>0x2,_0x4aca60=(_0x4c84d1&0x3)<<0x4|_0x2352d0>>0x4;let _0x149d3e=(_0x2352d0&0xf)<<0x2|_0x8b654d>>0x6,_0x31bf86=_0x8b654d&0x3f;_0x1a1e1e||(_0x31bf86=0x40,_0x3294fb||(_0x149d3e=0x40)),_0x4fc2d7['push'](_0x3c8f94[_0x39629c],_0x3c8f94[_0x4aca60],_0x3c8f94[_0x149d3e],_0x3c8f94[_0x31bf86]);}return _0x4fc2d7['join']('');},'encodeString'(_0x52662f,_0x367452){return this['HAS_NATIVE_SUPPORT']&&!_0x367452?btoa(_0x52662f):this['encodeByteArray'](Hr(_0x52662f),_0x367452);},'decodeString'(_0x5aa234,_0x475191){return this['HAS_NATIVE_SUPPORT']&&!_0x475191?atob(_0x5aa234):nc(this['decodeStringToByteArray'](_0x5aa234,_0x475191));},'decodeStringToByteArray'(_0x15d64d,_0x386cac){this['init_']();const _0x2dd824=_0x386cac?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4298f7=[];for(let _0x3c00cd=0x0;_0x3c00cd<_0x15d64d['length'];){const _0x1a0030=_0x2dd824[_0x15d64d['charAt'](_0x3c00cd++)],_0x42a96c=_0x3c00cd<_0x15d64d['length']?_0x2dd824[_0x15d64d['charAt'](_0x3c00cd)]:0x0;++_0x3c00cd;const _0x4f5850=_0x3c00cd<_0x15d64d['length']?_0x2dd824[_0x15d64d['charAt'](_0x3c00cd)]:0x40;++_0x3c00cd;const _0x65086e=_0x3c00cd<_0x15d64d['length']?_0x2dd824[_0x15d64d['charAt'](_0x3c00cd)]:0x40;if(++_0x3c00cd,_0x1a0030==null||_0x42a96c==null||_0x4f5850==null||_0x65086e==null)throw new ic();const _0x2dcdf9=_0x1a0030<<0x2|_0x42a96c>>0x4;if(_0x4298f7['push'](_0x2dcdf9),_0x4f5850!==0x40){const _0x2fd43c=_0x42a96c<<0x4&0xf0|_0x4f5850>>0x2;if(_0x4298f7['push'](_0x2fd43c),_0x65086e!==0x40){const _0x453c7d=_0x4f5850<<0x6&0xc0|_0x65086e;_0x4298f7['push'](_0x453c7d);}}}return _0x4298f7;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3ebfa3=0x0;_0x3ebfa3<this['ENCODED_VALS']['length'];_0x3ebfa3++)this['byteToCharMap_'][_0x3ebfa3]=this['ENCODED_VALS']['charAt'](_0x3ebfa3),this['charToByteMap_'][this['byteToCharMap_'][_0x3ebfa3]]=_0x3ebfa3,this['byteToCharMapWebSafe_'][_0x3ebfa3]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3ebfa3),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3ebfa3]]=_0x3ebfa3,_0x3ebfa3>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3ebfa3)]=_0x3ebfa3,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3ebfa3)]=_0x3ebfa3);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x4d5147){const _0x26391a=Hr(_0x4d5147);return Fi['encodeByteArray'](_0x26391a,!0x0);},dn=function(_0x2233c4){return $r(_0x2233c4)['replace'](/\./g,'');},fn=function(_0x4d5b76){try{return Fi['decodeString'](_0x4d5b76,!0x0);}catch(_0x3755a8){console['error']('base64Decode\x20failed:\x20',_0x3755a8);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x20c8dc){return Gr(void 0x0,_0x20c8dc);}function Gr(_0x2f2177,_0x3d9ca6){if(!(_0x3d9ca6 instanceof Object))return _0x3d9ca6;switch(_0x3d9ca6['constructor']){case Date:const _0x3e79a1=_0x3d9ca6;return new Date(_0x3e79a1['getTime']());case Object:_0x2f2177===void 0x0&&(_0x2f2177={});break;case Array:_0x2f2177=[];break;default:return _0x3d9ca6;}for(const _0x4f2b3d in _0x3d9ca6)!_0x3d9ca6['hasOwnProperty'](_0x4f2b3d)||!rc(_0x4f2b3d)||(_0x2f2177[_0x4f2b3d]=Gr(_0x2f2177[_0x4f2b3d],_0x3d9ca6[_0x4f2b3d]));return _0x2f2177;}function rc(_0x467031){return _0x467031!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x1664cf=Ps['__FIREBASE_DEFAULTS__'];if(_0x1664cf)return JSON['parse'](_0x1664cf);},lc=()=>{if(typeof document>'u')return;let _0x2e7f13;try{_0x2e7f13=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5ccc50=_0x2e7f13&&fn(_0x2e7f13[0x1]);return _0x5ccc50&&JSON['parse'](_0x5ccc50);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x10b452){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x10b452);return;}},qr=_0x433a40=>{var _0x5d8073,_0x4e0930;return(_0x4e0930=(_0x5d8073=Ui())==null?void 0x0:_0x5d8073['emulatorHosts'])==null?void 0x0:_0x4e0930[_0x433a40];},hc=_0x2a3a09=>{const _0x55ddab=qr(_0x2a3a09);if(!_0x55ddab)return;const _0x4033de=_0x55ddab['lastIndexOf'](':');if(_0x4033de<=0x0||_0x4033de+0x1===_0x55ddab['length'])throw new Error('Invalid\x20host\x20'+_0x55ddab+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x546169=parseInt(_0x55ddab['substring'](_0x4033de+0x1),0xa);return _0x55ddab[0x0]==='['?[_0x55ddab['substring'](0x1,_0x4033de-0x1),_0x546169]:[_0x55ddab['substring'](0x0,_0x4033de),_0x546169];},zr=()=>{var _0x38c038;return(_0x38c038=Ui())==null?void 0x0:_0x38c038['config'];},jr=_0x5efaaa=>{var _0x2b1641;return(_0x2b1641=Ui())==null?void 0x0:_0x2b1641['_'+_0x5efaaa];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1e9411,_0x1629d4)=>{this['resolve']=_0x1e9411,this['reject']=_0x1629d4;});}['wrapCallback'](_0x49b2a3){return(_0x287128,_0x2fdd71)=>{_0x287128?this['reject'](_0x287128):this['resolve'](_0x2fdd71),typeof _0x49b2a3=='function'&&(this['promise']['catch'](()=>{}),_0x49b2a3['length']===0x1?_0x49b2a3(_0x287128):_0x49b2a3(_0x287128,_0x2fdd71));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x1e1b9d,_0x15a209){if(_0x1e1b9d['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3310f6={'alg':'none','type':'JWT'},_0x5a8bc4=_0x15a209||'demo-project',_0x190a4e=_0x1e1b9d['iat']||0x0,_0x42dcfe=_0x1e1b9d['sub']||_0x1e1b9d['user_id'];if(!_0x42dcfe)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x19f36e={'iss':'https://securetoken.google.com/'+_0x5a8bc4,'aud':_0x5a8bc4,'iat':_0x190a4e,'exp':_0x190a4e+0xe10,'auth_time':_0x190a4e,'sub':_0x42dcfe,'user_id':_0x42dcfe,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x1e1b9d};return[dn(JSON['stringify'](_0x3310f6)),dn(JSON['stringify'](_0x19f36e)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x5d61f4=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5d61f4=='object'&&_0x5d61f4['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x355e53=W();return _0x355e53['indexOf']('MSIE\x20')>=0x0||_0x355e53['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x806cc1,_0x218405)=>{try{let _0x40a122=!0x0;const _0x35d98b='validate-browser-context-for-indexeddb-analytics-module',_0x138a93=self['indexedDB']['open'](_0x35d98b);_0x138a93['onsuccess']=()=>{_0x138a93['result']['close'](),_0x40a122||self['indexedDB']['deleteDatabase'](_0x35d98b),_0x806cc1(!0x0);},_0x138a93['onupgradeneeded']=()=>{_0x40a122=!0x1;},_0x138a93['onerror']=()=>{var _0x47b80e;_0x218405(((_0x47b80e=_0x138a93['error'])==null?void 0x0:_0x47b80e['message'])||'');};}catch(_0x3bcf9e){_0x218405(_0x3bcf9e);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x4cd716,_0x250a16,_0x106141){super(_0x250a16),this['code']=_0x4cd716,this['customData']=_0x106141,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x339e00,_0x29510a,_0x3b1a80){this['service']=_0x339e00,this['serviceName']=_0x29510a,this['errors']=_0x3b1a80;}['create'](_0x55381e,..._0x1d2bf){const _0x2952e2=_0x1d2bf[0x0]||{},_0x4b89a2=this['service']+'/'+_0x55381e,_0x1ac551=this['errors'][_0x55381e],_0x37ef55=_0x1ac551?vc(_0x1ac551,_0x2952e2):'Error',_0x1905eb=this['serviceName']+':\x20'+_0x37ef55+'\x20('+_0x4b89a2+').';return new Re(_0x4b89a2,_0x1905eb,_0x2952e2);}}function vc(_0x11b008,_0x402d2c){return _0x11b008['replace'](Ec,(_0x4161ad,_0x152216)=>{const _0x585eeb=_0x402d2c[_0x152216];return _0x585eeb!=null?String(_0x585eeb):'<'+_0x152216+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x11939e){return JSON['parse'](_0x11939e);}function O(_0x326edb){return JSON['stringify'](_0x326edb);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x4c8e39){let _0x2bf9f0={},_0x3e3994={},_0x51567e={},_0x1a5476='';try{const _0x21ea29=_0x4c8e39['split']('.');_0x2bf9f0=Nt(fn(_0x21ea29[0x0])||''),_0x3e3994=Nt(fn(_0x21ea29[0x1])||''),_0x1a5476=_0x21ea29[0x2],_0x51567e=_0x3e3994['d']||{},delete _0x3e3994['d'];}catch{}return{'header':_0x2bf9f0,'claims':_0x3e3994,'data':_0x51567e,'signature':_0x1a5476};},Ic=function(_0x42394d){const _0x4eae68=Yr(_0x42394d),_0x2a78e2=_0x4eae68['claims'];return!!_0x2a78e2&&typeof _0x2a78e2=='object'&&_0x2a78e2['hasOwnProperty']('iat');},wc=function(_0x1abcca){const _0x3da38a=Yr(_0x1abcca)['claims'];return typeof _0x3da38a=='object'&&_0x3da38a['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x1a8607,_0x608fb0){return Object['prototype']['hasOwnProperty']['call'](_0x1a8607,_0x608fb0);}function Le(_0xc99578,_0x25fb1a){if(Object['prototype']['hasOwnProperty']['call'](_0xc99578,_0x25fb1a))return _0xc99578[_0x25fb1a];}function pn(_0x2560e2){for(const _0x43dc72 in _0x2560e2)if(Object['prototype']['hasOwnProperty']['call'](_0x2560e2,_0x43dc72))return!0x1;return!0x0;}function _n(_0x2cae68,_0x2b66ea,_0x3a3ee3){const _0x41e21e={};for(const _0x581833 in _0x2cae68)Object['prototype']['hasOwnProperty']['call'](_0x2cae68,_0x581833)&&(_0x41e21e[_0x581833]=_0x2b66ea['call'](_0x3a3ee3,_0x2cae68[_0x581833],_0x581833,_0x2cae68));return _0x41e21e;}function xe(_0xda854f,_0xf976f4){if(_0xda854f===_0xf976f4)return!0x0;const _0x4be59c=Object['keys'](_0xda854f),_0x3092bc=Object['keys'](_0xf976f4);for(const _0xf08213 of _0x4be59c){if(!_0x3092bc['includes'](_0xf08213))return!0x1;const _0x3c9580=_0xda854f[_0xf08213],_0x4cde5d=_0xf976f4[_0xf08213];if(Ns(_0x3c9580)&&Ns(_0x4cde5d)){if(!xe(_0x3c9580,_0x4cde5d))return!0x1;}else{if(_0x3c9580!==_0x4cde5d)return!0x1;}}for(const _0x56ed4f of _0x3092bc)if(!_0x4be59c['includes'](_0x56ed4f))return!0x1;return!0x0;}function Ns(_0x4ef959){return _0x4ef959!==null&&typeof _0x4ef959=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x59517c){const _0x25bc48=[];for(const [_0xf20077,_0x235184]of Object['entries'](_0x59517c))Array['isArray'](_0x235184)?_0x235184['forEach'](_0x4308d2=>{_0x25bc48['push'](encodeURIComponent(_0xf20077)+'='+encodeURIComponent(_0x4308d2));}):_0x25bc48['push'](encodeURIComponent(_0xf20077)+'='+encodeURIComponent(_0x235184));return _0x25bc48['length']?'&'+_0x25bc48['join']('&'):'';}function Ct(_0x57346f){const _0x3fa092={};return _0x57346f['replace'](/^\?/,'')['split']('&')['forEach'](_0x5caef8=>{if(_0x5caef8){const [_0xdd21f9,_0x5ddc8f]=_0x5caef8['split']('=');_0x3fa092[decodeURIComponent(_0xdd21f9)]=decodeURIComponent(_0x5ddc8f);}}),_0x3fa092;}function Tt(_0x3ad4c7){const _0x2ca725=_0x3ad4c7['indexOf']('?');if(!_0x2ca725)return'';const _0x1dc84b=_0x3ad4c7['indexOf']('#',_0x2ca725);return _0x3ad4c7['substring'](_0x2ca725,_0x1dc84b>0x0?_0x1dc84b:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x4b5090=0x1;_0x4b5090<this['blockSize'];++_0x4b5090)this['pad_'][_0x4b5090]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1fb177,_0x436fc9){_0x436fc9||(_0x436fc9=0x0);const _0x57960c=this['W_'];if(typeof _0x1fb177=='string'){for(let _0x3d8064=0x0;_0x3d8064<0x10;_0x3d8064++)_0x57960c[_0x3d8064]=_0x1fb177['charCodeAt'](_0x436fc9)<<0x18|_0x1fb177['charCodeAt'](_0x436fc9+0x1)<<0x10|_0x1fb177['charCodeAt'](_0x436fc9+0x2)<<0x8|_0x1fb177['charCodeAt'](_0x436fc9+0x3),_0x436fc9+=0x4;}else{for(let _0x7dfc1b=0x0;_0x7dfc1b<0x10;_0x7dfc1b++)_0x57960c[_0x7dfc1b]=_0x1fb177[_0x436fc9]<<0x18|_0x1fb177[_0x436fc9+0x1]<<0x10|_0x1fb177[_0x436fc9+0x2]<<0x8|_0x1fb177[_0x436fc9+0x3],_0x436fc9+=0x4;}for(let _0xa4a2af=0x10;_0xa4a2af<0x50;_0xa4a2af++){const _0x3f19b2=_0x57960c[_0xa4a2af-0x3]^_0x57960c[_0xa4a2af-0x8]^_0x57960c[_0xa4a2af-0xe]^_0x57960c[_0xa4a2af-0x10];_0x57960c[_0xa4a2af]=(_0x3f19b2<<0x1|_0x3f19b2>>>0x1f)&0xffffffff;}let _0x4bced2=this['chain_'][0x0],_0x2473a2=this['chain_'][0x1],_0x1dd31f=this['chain_'][0x2],_0x3ae6b3=this['chain_'][0x3],_0x44769b=this['chain_'][0x4],_0x1360bb,_0x4e6946;for(let _0x15f698=0x0;_0x15f698<0x50;_0x15f698++){_0x15f698<0x28?_0x15f698<0x14?(_0x1360bb=_0x3ae6b3^_0x2473a2&(_0x1dd31f^_0x3ae6b3),_0x4e6946=0x5a827999):(_0x1360bb=_0x2473a2^_0x1dd31f^_0x3ae6b3,_0x4e6946=0x6ed9eba1):_0x15f698<0x3c?(_0x1360bb=_0x2473a2&_0x1dd31f|_0x3ae6b3&(_0x2473a2|_0x1dd31f),_0x4e6946=0x8f1bbcdc):(_0x1360bb=_0x2473a2^_0x1dd31f^_0x3ae6b3,_0x4e6946=0xca62c1d6);const _0x395e1f=(_0x4bced2<<0x5|_0x4bced2>>>0x1b)+_0x1360bb+_0x44769b+_0x4e6946+_0x57960c[_0x15f698]&0xffffffff;_0x44769b=_0x3ae6b3,_0x3ae6b3=_0x1dd31f,_0x1dd31f=(_0x2473a2<<0x1e|_0x2473a2>>>0x2)&0xffffffff,_0x2473a2=_0x4bced2,_0x4bced2=_0x395e1f;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4bced2&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2473a2&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1dd31f&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x3ae6b3&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x44769b&0xffffffff;}['update'](_0x18745c,_0x34a528){if(_0x18745c==null)return;_0x34a528===void 0x0&&(_0x34a528=_0x18745c['length']);const _0x5ced93=_0x34a528-this['blockSize'];let _0x3c5cc5=0x0;const _0x22b46b=this['buf_'];let _0x48021b=this['inbuf_'];for(;_0x3c5cc5<_0x34a528;){if(_0x48021b===0x0){for(;_0x3c5cc5<=_0x5ced93;)this['compress_'](_0x18745c,_0x3c5cc5),_0x3c5cc5+=this['blockSize'];}if(typeof _0x18745c=='string'){for(;_0x3c5cc5<_0x34a528;)if(_0x22b46b[_0x48021b]=_0x18745c['charCodeAt'](_0x3c5cc5),++_0x48021b,++_0x3c5cc5,_0x48021b===this['blockSize']){this['compress_'](_0x22b46b),_0x48021b=0x0;break;}}else{for(;_0x3c5cc5<_0x34a528;)if(_0x22b46b[_0x48021b]=_0x18745c[_0x3c5cc5],++_0x48021b,++_0x3c5cc5,_0x48021b===this['blockSize']){this['compress_'](_0x22b46b),_0x48021b=0x0;break;}}}this['inbuf_']=_0x48021b,this['total_']+=_0x34a528;}['digest'](){const _0x180ae4=[];let _0x49dad3=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x215f76=this['blockSize']-0x1;_0x215f76>=0x38;_0x215f76--)this['buf_'][_0x215f76]=_0x49dad3&0xff,_0x49dad3/=0x100;this['compress_'](this['buf_']);let _0x593e83=0x0;for(let _0x3628c3=0x0;_0x3628c3<0x5;_0x3628c3++)for(let _0x112186=0x18;_0x112186>=0x0;_0x112186-=0x8)_0x180ae4[_0x593e83]=this['chain_'][_0x3628c3]>>_0x112186&0xff,++_0x593e83;return _0x180ae4;}}function Tc(_0x2f04c1,_0x21f545){const _0xd3f38f=new Sc(_0x2f04c1,_0x21f545);return _0xd3f38f['subscribe']['bind'](_0xd3f38f);}class Sc{constructor(_0x28bcb8,_0x15f197){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x15f197,this['task']['then'](()=>{_0x28bcb8(this);})['catch'](_0x1de855=>{this['error'](_0x1de855);});}['next'](_0x426ad4){this['forEachObserver'](_0x225d47=>{_0x225d47['next'](_0x426ad4);});}['error'](_0x22719f){this['forEachObserver'](_0x332d02=>{_0x332d02['error'](_0x22719f);}),this['close'](_0x22719f);}['complete'](){this['forEachObserver'](_0x161193=>{_0x161193['complete']();}),this['close']();}['subscribe'](_0x3ed375,_0x2790fb,_0x4c9e67){let _0x2bef5c;if(_0x3ed375===void 0x0&&_0x2790fb===void 0x0&&_0x4c9e67===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x3ed375,['next','error','complete'])?_0x2bef5c=_0x3ed375:_0x2bef5c={'next':_0x3ed375,'error':_0x2790fb,'complete':_0x4c9e67},_0x2bef5c['next']===void 0x0&&(_0x2bef5c['next']=ti),_0x2bef5c['error']===void 0x0&&(_0x2bef5c['error']=ti),_0x2bef5c['complete']===void 0x0&&(_0x2bef5c['complete']=ti);const _0x3b551d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2bef5c['error'](this['finalError']):_0x2bef5c['complete']();}catch{}}),this['observers']['push'](_0x2bef5c),_0x3b551d;}['unsubscribeOne'](_0x59b203){this['observers']===void 0x0||this['observers'][_0x59b203]===void 0x0||(delete this['observers'][_0x59b203],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4b5489){if(!this['finalized']){for(let _0x4baa41=0x0;_0x4baa41<this['observers']['length'];_0x4baa41++)this['sendOne'](_0x4baa41,_0x4b5489);}}['sendOne'](_0x143e71,_0x3cf8a8){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x143e71]!==void 0x0)try{_0x3cf8a8(this['observers'][_0x143e71]);}catch(_0x22b52b){typeof console<'u'&&console['error']&&console['error'](_0x22b52b);}});}['close'](_0x2b2539){this['finalized']||(this['finalized']=!0x0,_0x2b2539!==void 0x0&&(this['finalError']=_0x2b2539),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x515d86,_0x308ca7){if(typeof _0x515d86!='object'||_0x515d86===null)return!0x1;for(const _0x865f3f of _0x308ca7)if(_0x865f3f in _0x515d86&&typeof _0x515d86[_0x865f3f]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x35006a,_0x2e7e80){return _0x35006a+'\x20failed:\x20'+_0x2e7e80+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x44868e){const _0x34a2c0=[];let _0x12e1a7=0x0;for(let _0x28427b=0x0;_0x28427b<_0x44868e['length'];_0x28427b++){let _0x3f38de=_0x44868e['charCodeAt'](_0x28427b);if(_0x3f38de>=0xd800&&_0x3f38de<=0xdbff){const _0x1f21af=_0x3f38de-0xd800;_0x28427b++,f(_0x28427b<_0x44868e['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3bcd03=_0x44868e['charCodeAt'](_0x28427b)-0xdc00;_0x3f38de=0x10000+(_0x1f21af<<0xa)+_0x3bcd03;}_0x3f38de<0x80?_0x34a2c0[_0x12e1a7++]=_0x3f38de:_0x3f38de<0x800?(_0x34a2c0[_0x12e1a7++]=_0x3f38de>>0x6|0xc0,_0x34a2c0[_0x12e1a7++]=_0x3f38de&0x3f|0x80):_0x3f38de<0x10000?(_0x34a2c0[_0x12e1a7++]=_0x3f38de>>0xc|0xe0,_0x34a2c0[_0x12e1a7++]=_0x3f38de>>0x6&0x3f|0x80,_0x34a2c0[_0x12e1a7++]=_0x3f38de&0x3f|0x80):(_0x34a2c0[_0x12e1a7++]=_0x3f38de>>0x12|0xf0,_0x34a2c0[_0x12e1a7++]=_0x3f38de>>0xc&0x3f|0x80,_0x34a2c0[_0x12e1a7++]=_0x3f38de>>0x6&0x3f|0x80,_0x34a2c0[_0x12e1a7++]=_0x3f38de&0x3f|0x80);}return _0x34a2c0;},Ln=function(_0x5df82e){let _0x5852d7=0x0;for(let _0x19e475=0x0;_0x19e475<_0x5df82e['length'];_0x19e475++){const _0x5c75ff=_0x5df82e['charCodeAt'](_0x19e475);_0x5c75ff<0x80?_0x5852d7++:_0x5c75ff<0x800?_0x5852d7+=0x2:_0x5c75ff>=0xd800&&_0x5c75ff<=0xdbff?(_0x5852d7+=0x4,_0x19e475++):_0x5852d7+=0x3;}return _0x5852d7;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x51ab82){return _0x51ab82&&_0x51ab82['_delegate']?_0x51ab82['_delegate']:_0x51ab82;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x109fad){try{return(_0x109fad['startsWith']('http://')||_0x109fad['startsWith']('https://')?new URL(_0x109fad)['hostname']:_0x109fad)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x9f9f51){return(await fetch(_0x9f9f51,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x1e8720,_0x4d328a,_0x239015){this['name']=_0x1e8720,this['instanceFactory']=_0x4d328a,this['type']=_0x239015,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1d3a80){return this['instantiationMode']=_0x1d3a80,this;}['setMultipleInstances'](_0x5a5e42){return this['multipleInstances']=_0x5a5e42,this;}['setServiceProps'](_0x2cfd7f){return this['serviceProps']=_0x2cfd7f,this;}['setInstanceCreatedCallback'](_0x5ce773){return this['onInstanceCreated']=_0x5ce773,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x36db8e,_0x4c16a6){this['name']=_0x36db8e,this['container']=_0x4c16a6,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xd2bc44){const _0x583318=this['normalizeInstanceIdentifier'](_0xd2bc44);if(!this['instancesDeferred']['has'](_0x583318)){const _0x527354=new H();if(this['instancesDeferred']['set'](_0x583318,_0x527354),this['isInitialized'](_0x583318)||this['shouldAutoInitialize']())try{const _0x3522fb=this['getOrInitializeService']({'instanceIdentifier':_0x583318});_0x3522fb&&_0x527354['resolve'](_0x3522fb);}catch{}}return this['instancesDeferred']['get'](_0x583318)['promise'];}['getImmediate'](_0xe2e46c){const _0x36427b=this['normalizeInstanceIdentifier'](_0xe2e46c==null?void 0x0:_0xe2e46c['identifier']),_0x43f8db=(_0xe2e46c==null?void 0x0:_0xe2e46c['optional'])??!0x1;if(this['isInitialized'](_0x36427b)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x36427b});}catch(_0x4c870b){if(_0x43f8db)return null;throw _0x4c870b;}else{if(_0x43f8db)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x228762){if(_0x228762['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x228762['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x228762,!!this['shouldAutoInitialize']()){if(Pc(_0x228762))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x55391e,_0x5d6ff9]of this['instancesDeferred']['entries']()){const _0x2b03ac=this['normalizeInstanceIdentifier'](_0x55391e);try{const _0x13c898=this['getOrInitializeService']({'instanceIdentifier':_0x2b03ac});_0x5d6ff9['resolve'](_0x13c898);}catch{}}}}['clearInstance'](_0x26a8fd=Ne){this['instancesDeferred']['delete'](_0x26a8fd),this['instancesOptions']['delete'](_0x26a8fd),this['instances']['delete'](_0x26a8fd);}async['delete'](){const _0x5c298e=Array['from'](this['instances']['values']());await Promise['all']([..._0x5c298e['filter'](_0x5b7020=>'INTERNAL'in _0x5b7020)['map'](_0x4140bd=>_0x4140bd['INTERNAL']['delete']()),..._0x5c298e['filter'](_0x184fd8=>'_delete'in _0x184fd8)['map'](_0x48b295=>_0x48b295['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x124dc6=Ne){return this['instances']['has'](_0x124dc6);}['getOptions'](_0x519edc=Ne){return this['instancesOptions']['get'](_0x519edc)||{};}['initialize'](_0xe2246d={}){const {options:_0x4a9abf={}}=_0xe2246d,_0x2663be=this['normalizeInstanceIdentifier'](_0xe2246d['instanceIdentifier']);if(this['isInitialized'](_0x2663be))throw Error(this['name']+'('+_0x2663be+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x4d6ecf=this['getOrInitializeService']({'instanceIdentifier':_0x2663be,'options':_0x4a9abf});for(const [_0x10d501,_0x176ff4]of this['instancesDeferred']['entries']()){const _0x11b4a7=this['normalizeInstanceIdentifier'](_0x10d501);_0x2663be===_0x11b4a7&&_0x176ff4['resolve'](_0x4d6ecf);}return _0x4d6ecf;}['onInit'](_0x10aa2a,_0x3c8af4){const _0x503054=this['normalizeInstanceIdentifier'](_0x3c8af4),_0x4a49c9=this['onInitCallbacks']['get'](_0x503054)??new Set();_0x4a49c9['add'](_0x10aa2a),this['onInitCallbacks']['set'](_0x503054,_0x4a49c9);const _0x360e63=this['instances']['get'](_0x503054);return _0x360e63&&_0x10aa2a(_0x360e63,_0x503054),()=>{_0x4a49c9['delete'](_0x10aa2a);};}['invokeOnInitCallbacks'](_0x2190e0,_0x37ee3b){const _0x4ea907=this['onInitCallbacks']['get'](_0x37ee3b);if(_0x4ea907){for(const _0x415fd6 of _0x4ea907)try{_0x415fd6(_0x2190e0,_0x37ee3b);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x41260b,options:_0x41ea3a={}}){let _0x1fc80d=this['instances']['get'](_0x41260b);if(!_0x1fc80d&&this['component']&&(_0x1fc80d=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x41260b),'options':_0x41ea3a}),this['instances']['set'](_0x41260b,_0x1fc80d),this['instancesOptions']['set'](_0x41260b,_0x41ea3a),this['invokeOnInitCallbacks'](_0x1fc80d,_0x41260b),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x41260b,_0x1fc80d);}catch{}return _0x1fc80d||null;}['normalizeInstanceIdentifier'](_0x33872b=Ne){return this['component']?this['component']['multipleInstances']?_0x33872b:Ne:_0x33872b;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x3dc569){return _0x3dc569===Ne?void 0x0:_0x3dc569;}function Pc(_0x3fea00){return _0x3fea00['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x24d5d5){this['name']=_0x24d5d5,this['providers']=new Map();}['addComponent'](_0x33e7bb){const _0x12d93d=this['getProvider'](_0x33e7bb['name']);if(_0x12d93d['isComponentSet']())throw new Error('Component\x20'+_0x33e7bb['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x12d93d['setComponent'](_0x33e7bb);}['addOrOverwriteComponent'](_0x2957e4){this['getProvider'](_0x2957e4['name'])['isComponentSet']()&&this['providers']['delete'](_0x2957e4['name']),this['addComponent'](_0x2957e4);}['getProvider'](_0x2a4c92){if(this['providers']['has'](_0x2a4c92))return this['providers']['get'](_0x2a4c92);const _0x4cd8a9=new Ac(_0x2a4c92,this);return this['providers']['set'](_0x2a4c92,_0x4cd8a9),_0x4cd8a9;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xb1050d){_0xb1050d[_0xb1050d['DEBUG']=0x0]='DEBUG',_0xb1050d[_0xb1050d['VERBOSE']=0x1]='VERBOSE',_0xb1050d[_0xb1050d['INFO']=0x2]='INFO',_0xb1050d[_0xb1050d['WARN']=0x3]='WARN',_0xb1050d[_0xb1050d['ERROR']=0x4]='ERROR',_0xb1050d[_0xb1050d['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x3e5f4c,_0x43b1ad,..._0x58f56d)=>{if(_0x43b1ad<_0x3e5f4c['logLevel'])return;const _0x1dd298=new Date()['toISOString'](),_0x25211d=Mc[_0x43b1ad];if(_0x25211d)console[_0x25211d]('['+_0x1dd298+']\x20\x20'+_0x3e5f4c['name']+':',..._0x58f56d);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x43b1ad+')');};class Bi{constructor(_0x25782e){this['name']=_0x25782e,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x29d9d4){if(!(_0x29d9d4 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x29d9d4+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x29d9d4;}['setLogLevel'](_0x5ab309){this['_logLevel']=typeof _0x5ab309=='string'?Oc[_0x5ab309]:_0x5ab309;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5cda22){if(typeof _0x5cda22!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5cda22;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x25a68d){this['_userLogHandler']=_0x25a68d;}['debug'](..._0xc0406d){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0xc0406d),this['_logHandler'](this,T['DEBUG'],..._0xc0406d);}['log'](..._0x28d905){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x28d905),this['_logHandler'](this,T['VERBOSE'],..._0x28d905);}['info'](..._0x1af0c7){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1af0c7),this['_logHandler'](this,T['INFO'],..._0x1af0c7);}['warn'](..._0x463376){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x463376),this['_logHandler'](this,T['WARN'],..._0x463376);}['error'](..._0x5c86df){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5c86df),this['_logHandler'](this,T['ERROR'],..._0x5c86df);}}const xc=(_0x8e5062,_0x4ce0c9)=>_0x4ce0c9['some'](_0x267775=>_0x8e5062 instanceof _0x267775);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x8919a4){const _0x29433f=new Promise((_0x19c2a5,_0x1606ce)=>{const _0x2aea29=()=>{_0x8919a4['removeEventListener']('success',_0x1ad07f),_0x8919a4['removeEventListener']('error',_0x77a6e4);},_0x1ad07f=()=>{_0x19c2a5(ge(_0x8919a4['result'])),_0x2aea29();},_0x77a6e4=()=>{_0x1606ce(_0x8919a4['error']),_0x2aea29();};_0x8919a4['addEventListener']('success',_0x1ad07f),_0x8919a4['addEventListener']('error',_0x77a6e4);});return _0x29433f['then'](_0x26d657=>{_0x26d657 instanceof IDBCursor&&Jr['set'](_0x26d657,_0x8919a4);})['catch'](()=>{}),Vi['set'](_0x29433f,_0x8919a4),_0x29433f;}function Bc(_0x1614f9){if(_i['has'](_0x1614f9))return;const _0x4cf108=new Promise((_0x175ac5,_0x24efd1)=>{const _0x498341=()=>{_0x1614f9['removeEventListener']('complete',_0x45885e),_0x1614f9['removeEventListener']('error',_0x2ed74b),_0x1614f9['removeEventListener']('abort',_0x2ed74b);},_0x45885e=()=>{_0x175ac5(),_0x498341();},_0x2ed74b=()=>{_0x24efd1(_0x1614f9['error']||new DOMException('AbortError','AbortError')),_0x498341();};_0x1614f9['addEventListener']('complete',_0x45885e),_0x1614f9['addEventListener']('error',_0x2ed74b),_0x1614f9['addEventListener']('abort',_0x2ed74b);});_i['set'](_0x1614f9,_0x4cf108);}let gi={'get'(_0x3a059d,_0x5c234d,_0x2dca23){if(_0x3a059d instanceof IDBTransaction){if(_0x5c234d==='done')return _i['get'](_0x3a059d);if(_0x5c234d==='objectStoreNames')return _0x3a059d['objectStoreNames']||Xr['get'](_0x3a059d);if(_0x5c234d==='store')return _0x2dca23['objectStoreNames'][0x1]?void 0x0:_0x2dca23['objectStore'](_0x2dca23['objectStoreNames'][0x0]);}return ge(_0x3a059d[_0x5c234d]);},'set'(_0x350f46,_0x594276,_0x13284f){return _0x350f46[_0x594276]=_0x13284f,!0x0;},'has'(_0x3fba79,_0x2b1c03){return _0x3fba79 instanceof IDBTransaction&&(_0x2b1c03==='done'||_0x2b1c03==='store')?!0x0:_0x2b1c03 in _0x3fba79;}};function Vc(_0x488d7e){gi=_0x488d7e(gi);}function Hc(_0x1985fb){return _0x1985fb===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x54dddf,..._0xa433d8){const _0x54237e=_0x1985fb['call'](ii(this),_0x54dddf,..._0xa433d8);return Xr['set'](_0x54237e,_0x54dddf['sort']?_0x54dddf['sort']():[_0x54dddf]),ge(_0x54237e);}:Uc()['includes'](_0x1985fb)?function(..._0x64dc71){return _0x1985fb['apply'](ii(this),_0x64dc71),ge(Jr['get'](this));}:function(..._0x1efba1){return ge(_0x1985fb['apply'](ii(this),_0x1efba1));};}function $c(_0x124307){return typeof _0x124307=='function'?Hc(_0x124307):(_0x124307 instanceof IDBTransaction&&Bc(_0x124307),xc(_0x124307,Fc())?new Proxy(_0x124307,gi):_0x124307);}function ge(_0x495d44){if(_0x495d44 instanceof IDBRequest)return Wc(_0x495d44);if(ni['has'](_0x495d44))return ni['get'](_0x495d44);const _0x35de0f=$c(_0x495d44);return _0x35de0f!==_0x495d44&&(ni['set'](_0x495d44,_0x35de0f),Vi['set'](_0x35de0f,_0x495d44)),_0x35de0f;}const ii=_0x3a2c1e=>Vi['get'](_0x3a2c1e);function Gc(_0x269c58,_0x28b812,{blocked:_0xab9a1,upgrade:_0x5bfba9,blocking:_0x41dcdd,terminated:_0x254977}={}){const _0x568dbf=indexedDB['open'](_0x269c58,_0x28b812),_0x78861=ge(_0x568dbf);return _0x5bfba9&&_0x568dbf['addEventListener']('upgradeneeded',_0xab11b0=>{_0x5bfba9(ge(_0x568dbf['result']),_0xab11b0['oldVersion'],_0xab11b0['newVersion'],ge(_0x568dbf['transaction']),_0xab11b0);}),_0xab9a1&&_0x568dbf['addEventListener']('blocked',_0x1c6870=>_0xab9a1(_0x1c6870['oldVersion'],_0x1c6870['newVersion'],_0x1c6870)),_0x78861['then'](_0x572744=>{_0x254977&&_0x572744['addEventListener']('close',()=>_0x254977()),_0x41dcdd&&_0x572744['addEventListener']('versionchange',_0x527585=>_0x41dcdd(_0x527585['oldVersion'],_0x527585['newVersion'],_0x527585));})['catch'](()=>{}),_0x78861;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x5e893a,_0x4ca3ac){if(!(_0x5e893a instanceof IDBDatabase&&!(_0x4ca3ac in _0x5e893a)&&typeof _0x4ca3ac=='string'))return;if(si['get'](_0x4ca3ac))return si['get'](_0x4ca3ac);const _0x571a9c=_0x4ca3ac['replace'](/FromIndex$/,''),_0x31b9d4=_0x4ca3ac!==_0x571a9c,_0xb5d8cd=zc['includes'](_0x571a9c);if(!(_0x571a9c in(_0x31b9d4?IDBIndex:IDBObjectStore)['prototype'])||!(_0xb5d8cd||qc['includes'](_0x571a9c)))return;const _0x58323c=async function(_0x2e454f,..._0x46cb09){const _0x40d6ec=this['transaction'](_0x2e454f,_0xb5d8cd?'readwrite':'readonly');let _0x5f4327=_0x40d6ec['store'];return _0x31b9d4&&(_0x5f4327=_0x5f4327['index'](_0x46cb09['shift']())),(await Promise['all']([_0x5f4327[_0x571a9c](..._0x46cb09),_0xb5d8cd&&_0x40d6ec['done']]))[0x0];};return si['set'](_0x4ca3ac,_0x58323c),_0x58323c;}Vc(_0x598f7f=>({..._0x598f7f,'get':(_0x103c81,_0x2f3332,_0x86dd76)=>Ms(_0x103c81,_0x2f3332)||_0x598f7f['get'](_0x103c81,_0x2f3332,_0x86dd76),'has':(_0x15c8f3,_0x3bda2e)=>!!Ms(_0x15c8f3,_0x3bda2e)||_0x598f7f['has'](_0x15c8f3,_0x3bda2e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4c1b1c){this['container']=_0x4c1b1c;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x120164=>{if(Kc(_0x120164)){const _0x47746a=_0x120164['getImmediate']();return _0x47746a['library']+'/'+_0x47746a['version'];}else return null;})['filter'](_0x3c06be=>_0x3c06be)['join']('\x20');}}function Kc(_0x376652){const _0x1a32aa=_0x376652['getComponent']();return(_0x1a32aa==null?void 0x0:_0x1a32aa['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x458f83,_0x341951){try{_0x458f83['container']['addComponent'](_0x341951);}catch(_0x28d754){oe['debug']('Component\x20'+_0x341951['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x458f83['name'],_0x28d754);}}function st(_0x12ae26){const _0x139361=_0x12ae26['name'];if(Ei['has'](_0x139361))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x139361+'.'),!0x1;Ei['set'](_0x139361,_0x12ae26);for(const _0x31b5fa of Ue['values']())xs(_0x31b5fa,_0x12ae26);for(const _0x838c73 of vi['values']())xs(_0x838c73,_0x12ae26);return!0x0;}function Hi(_0x623b60,_0x8d69bd){const _0x41805c=_0x623b60['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x41805c&&_0x41805c['triggerHeartbeat'](),_0x623b60['container']['getProvider'](_0x8d69bd);}function $(_0x2db399){return _0x2db399==null?!0x1:_0x2db399['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x2ed46a,_0x14d563,_0x226f5e){this['_isDeleted']=!0x1,this['_options']={..._0x2ed46a},this['_config']={..._0x14d563},this['_name']=_0x14d563['name'],this['_automaticDataCollectionEnabled']=_0x14d563['automaticDataCollectionEnabled'],this['_container']=_0x226f5e,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x311d66){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x311d66;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5ca707){this['_isDeleted']=_0x5ca707;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x17c791,_0x553cd9={}){let _0x5d33fe=_0x17c791;typeof _0x553cd9!='object'&&(_0x553cd9={'name':_0x553cd9});const _0x22162a={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x553cd9},_0x5b7403=_0x22162a['name'];if(typeof _0x5b7403!='string'||!_0x5b7403)throw me['create']('bad-app-name',{'appName':String(_0x5b7403)});if(_0x5d33fe||(_0x5d33fe=zr()),!_0x5d33fe)throw me['create']('no-options');const _0x26093f=Ue['get'](_0x5b7403);if(_0x26093f){if(xe(_0x5d33fe,_0x26093f['options'])&&xe(_0x22162a,_0x26093f['config']))return _0x26093f;throw me['create']('duplicate-app',{'appName':_0x5b7403});}const _0x21ba87=new Nc(_0x5b7403);for(const _0x528fd4 of Ei['values']())_0x21ba87['addComponent'](_0x528fd4);const _0x5f3be9=new Tl(_0x5d33fe,_0x22162a,_0x21ba87);return Ue['set'](_0x5b7403,_0x5f3be9),_0x5f3be9;}function Zr(_0xe969e9=yi){const _0x5c2120=Ue['get'](_0xe969e9);if(!_0x5c2120&&_0xe969e9===yi&&zr())return Sl();if(!_0x5c2120)throw me['create']('no-app',{'appName':_0xe969e9});return _0x5c2120;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x53bac5){let _0x2b4b20=!0x1;const _0x4bc847=_0x53bac5['name'];Ue['has'](_0x4bc847)?(_0x2b4b20=!0x0,Ue['delete'](_0x4bc847)):vi['has'](_0x4bc847)&&_0x53bac5['decRefCount']()<=0x0&&(vi['delete'](_0x4bc847),_0x2b4b20=!0x0),_0x2b4b20&&(await Promise['all'](_0x53bac5['container']['getProviders']()['map'](_0x23f7db=>_0x23f7db['delete']())),_0x53bac5['isDeleted']=!0x0);}function ye(_0xa1af4d,_0x11f99e,_0x5181eb){let _0xd731e2=wl[_0xa1af4d]??_0xa1af4d;_0x5181eb&&(_0xd731e2+='-'+_0x5181eb);const _0x307485=_0xd731e2['match'](/\s|\//),_0x8de14b=_0x11f99e['match'](/\s|\//);if(_0x307485||_0x8de14b){const _0x4d0aa5=['Unable\x20to\x20register\x20library\x20\x22'+_0xd731e2+'\x22\x20with\x20version\x20\x22'+_0x11f99e+'\x22:'];_0x307485&&_0x4d0aa5['push']('library\x20name\x20\x22'+_0xd731e2+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x307485&&_0x8de14b&&_0x4d0aa5['push']('and'),_0x8de14b&&_0x4d0aa5['push']('version\x20name\x20\x22'+_0x11f99e+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x4d0aa5['join']('\x20'));return;}st(new Fe(_0xd731e2+'-version',()=>({'library':_0xd731e2,'version':_0x11f99e}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x4e5394,_0x47e218)=>{switch(_0x47e218){case 0x0:try{_0x4e5394['createObjectStore'](Ot);}catch(_0x381984){console['warn'](_0x381984);}}}})['catch'](_0x106762=>{throw me['create']('idb-open',{'originalErrorMessage':_0x106762['message']});})),ri;}async function Al(_0x3eddf9){try{const _0xb6536a=(await eo())['transaction'](Ot),_0x1038bb=await _0xb6536a['objectStore'](Ot)['get'](to(_0x3eddf9));return await _0xb6536a['done'],_0x1038bb;}catch(_0x1df8d4){if(_0x1df8d4 instanceof Re)oe['warn'](_0x1df8d4['message']);else{const _0x39f5b9=me['create']('idb-get',{'originalErrorMessage':_0x1df8d4==null?void 0x0:_0x1df8d4['message']});oe['warn'](_0x39f5b9['message']);}}}async function Fs(_0xb038ab,_0xf9d76c){try{const _0x4afe02=(await eo())['transaction'](Ot,'readwrite');await _0x4afe02['objectStore'](Ot)['put'](_0xf9d76c,to(_0xb038ab)),await _0x4afe02['done'];}catch(_0x30e7c2){if(_0x30e7c2 instanceof Re)oe['warn'](_0x30e7c2['message']);else{const _0x5abba8=me['create']('idb-set',{'originalErrorMessage':_0x30e7c2==null?void 0x0:_0x30e7c2['message']});oe['warn'](_0x5abba8['message']);}}}function to(_0x14b38d){return _0x14b38d['name']+'!'+_0x14b38d['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0xb34050){this['container']=_0xb34050,this['_heartbeatsCache']=null;const _0x13f783=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x13f783),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1e08c7=>(this['_heartbeatsCache']=_0x1e08c7,_0x1e08c7));}async['triggerHeartbeat'](){var _0x411aec,_0x1d9031;try{const _0x389fbf=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x13091a=Us();if(((_0x411aec=this['_heartbeatsCache'])==null?void 0x0:_0x411aec['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x1d9031=this['_heartbeatsCache'])==null?void 0x0:_0x1d9031['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x13091a||this['_heartbeatsCache']['heartbeats']['some'](_0x5085e5=>_0x5085e5['date']===_0x13091a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x13091a,'agent':_0x389fbf}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x3d57e3=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3d57e3,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x303fc8){oe['warn'](_0x303fc8);}}async['getHeartbeatsHeader'](){var _0x3f89c0;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3f89c0=this['_heartbeatsCache'])==null?void 0x0:_0x3f89c0['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3cd938=Us(),{heartbeatsToSend:_0x218039,unsentEntries:_0x3dacfe}=Ol(this['_heartbeatsCache']['heartbeats']),_0x54af37=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x218039}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3cd938,_0x3dacfe['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3dacfe,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x54af37;}catch(_0x3a3fd4){return oe['warn'](_0x3a3fd4),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x116652,_0x10b5d8=kl){const _0x4ce14a=[];let _0x53c4cf=_0x116652['slice']();for(const _0x44444a of _0x116652){const _0x3e9c98=_0x4ce14a['find'](_0x1debe2=>_0x1debe2['agent']===_0x44444a['agent']);if(_0x3e9c98){if(_0x3e9c98['dates']['push'](_0x44444a['date']),Ws(_0x4ce14a)>_0x10b5d8){_0x3e9c98['dates']['pop']();break;}}else{if(_0x4ce14a['push']({'agent':_0x44444a['agent'],'dates':[_0x44444a['date']]}),Ws(_0x4ce14a)>_0x10b5d8){_0x4ce14a['pop']();break;}}_0x53c4cf=_0x53c4cf['slice'](0x1);}return{'heartbeatsToSend':_0x4ce14a,'unsentEntries':_0x53c4cf};}class Dl{constructor(_0x5c89b5){this['app']=_0x5c89b5,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x24789e=await Al(this['app']);return _0x24789e!=null&&_0x24789e['heartbeats']?_0x24789e:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x480632){if(await this['_canUseIndexedDBPromise']){const _0x3b9b93=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x480632['lastSentHeartbeatDate']??_0x3b9b93['lastSentHeartbeatDate'],'heartbeats':_0x480632['heartbeats']});}else return;}async['add'](_0x5bb66b){if(await this['_canUseIndexedDBPromise']){const _0x1100dd=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5bb66b['lastSentHeartbeatDate']??_0x1100dd['lastSentHeartbeatDate'],'heartbeats':[..._0x1100dd['heartbeats'],..._0x5bb66b['heartbeats']]});}else return;}}function Ws(_0x54ef33){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x54ef33}))['length'];}function Ml(_0x37c9c8){if(_0x37c9c8['length']===0x0)return-0x1;let _0xdc86af=0x0,_0x29c70c=_0x37c9c8[0x0]['date'];for(let _0xf0d62b=0x1;_0xf0d62b<_0x37c9c8['length'];_0xf0d62b++)_0x37c9c8[_0xf0d62b]['date']<_0x29c70c&&(_0x29c70c=_0x37c9c8[_0xf0d62b]['date'],_0xdc86af=_0xf0d62b);return _0xdc86af;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x2fc6b8){st(new Fe('platform-logger',_0x4237c6=>new jc(_0x4237c6),'PRIVATE')),st(new Fe('heartbeat',_0x4a7521=>new Nl(_0x4a7521),'PRIVATE')),ye(mi,Ls,_0x2fc6b8),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x351fd9){no=_0x351fd9;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x204353){this['domStorage_']=_0x204353,this['prefix_']='firebase:';}['set'](_0x1cc6e0,_0x27bb1b){_0x27bb1b==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1cc6e0)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1cc6e0),O(_0x27bb1b));}['get'](_0xdf11e3){const _0x18693a=this['domStorage_']['getItem'](this['prefixedName_'](_0xdf11e3));return _0x18693a==null?null:Nt(_0x18693a);}['remove'](_0x12d273){this['domStorage_']['removeItem'](this['prefixedName_'](_0x12d273));}['prefixedName_'](_0xb63358){return this['prefix_']+_0xb63358;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x3294c5,_0x33fe8e){_0x33fe8e==null?delete this['cache_'][_0x3294c5]:this['cache_'][_0x3294c5]=_0x33fe8e;}['get'](_0x498661){return Q(this['cache_'],_0x498661)?this['cache_'][_0x498661]:null;}['remove'](_0x3e892e){delete this['cache_'][_0x3e892e];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x413546){try{if(typeof window<'u'&&typeof window[_0x413546]<'u'){const _0x25f0c6=window[_0x413546];return _0x25f0c6['setItem']('firebase:sentinel','cache'),_0x25f0c6['removeItem']('firebase:sentinel'),new Wl(_0x25f0c6);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x9093d0=0x1;return function(){return _0x9093d0++;};}()),ro=function(_0x23b961){const _0x4379fe=Rc(_0x23b961),_0xdb374b=new Cc();_0xdb374b['update'](_0x4379fe);const _0x2607d9=_0xdb374b['digest']();return Fi['encodeByteArray'](_0x2607d9);},zt=function(..._0x2906fc){let _0x4eeacc='';for(let _0x3b48a1=0x0;_0x3b48a1<_0x2906fc['length'];_0x3b48a1++){const _0x12a802=_0x2906fc[_0x3b48a1];Array['isArray'](_0x12a802)||_0x12a802&&typeof _0x12a802=='object'&&typeof _0x12a802['length']=='number'?_0x4eeacc+=zt['apply'](null,_0x12a802):typeof _0x12a802=='object'?_0x4eeacc+=O(_0x12a802):_0x4eeacc+=_0x12a802,_0x4eeacc+='\x20';}return _0x4eeacc;};let St=null,$s=!0x0;const Hl=function(_0x2b4a64,_0x27726c){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x228bba){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0xde695a=zt['apply'](null,_0x228bba);St(_0xde695a);}},jt=function(_0x53ec3f){return function(..._0x1af32d){L(_0x53ec3f,..._0x1af32d);};},Ii=function(..._0x1c732f){const _0x7578d4='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x1c732f);Ze['error'](_0x7578d4);},ae=function(..._0x4dc14e){const _0x232cea='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x4dc14e);throw Ze['error'](_0x232cea),new Error(_0x232cea);},U=function(..._0x4731da){const _0x13f71b='FIREBASE\x20WARNING:\x20'+zt(..._0x4731da);Ze['warn'](_0x13f71b);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x590faa){return typeof _0x590faa=='number'&&(_0x590faa!==_0x590faa||_0x590faa===Number['POSITIVE_INFINITY']||_0x590faa===Number['NEGATIVE_INFINITY']);},Gl=function(_0x4f80f2){if(document['readyState']==='complete')_0x4f80f2();else{let _0x33a944=!0x1;const _0x1ea06f=function(){if(!document['body']){setTimeout(_0x1ea06f,Math['floor'](0xa));return;}_0x33a944||(_0x33a944=!0x0,_0x4f80f2());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1ea06f,!0x1),window['addEventListener']('load',_0x1ea06f,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1ea06f();}),window['attachEvent']('onload',_0x1ea06f));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x30012b,_0x32e23c){if(_0x30012b===_0x32e23c)return 0x0;if(_0x30012b===We||_0x32e23c===we)return-0x1;if(_0x32e23c===We||_0x30012b===we)return 0x1;{const _0x266d09=Gs(_0x30012b),_0x3aff42=Gs(_0x32e23c);return _0x266d09!==null?_0x3aff42!==null?_0x266d09-_0x3aff42===0x0?_0x30012b['length']-_0x32e23c['length']:_0x266d09-_0x3aff42:-0x1:_0x3aff42!==null?0x1:_0x30012b<_0x32e23c?-0x1:0x1;}},ql=function(_0x5e9854,_0x37b357){return _0x5e9854===_0x37b357?0x0:_0x5e9854<_0x37b357?-0x1:0x1;},vt=function(_0x479efa,_0xe8a754){if(_0xe8a754&&_0x479efa in _0xe8a754)return _0xe8a754[_0x479efa];throw new Error('Missing\x20required\x20key\x20('+_0x479efa+')\x20in\x20object:\x20'+O(_0xe8a754));},$i=function(_0x13b3ef){if(typeof _0x13b3ef!='object'||_0x13b3ef===null)return O(_0x13b3ef);const _0x8bd1ec=[];for(const _0x420d2e in _0x13b3ef)_0x8bd1ec['push'](_0x420d2e);_0x8bd1ec['sort']();let _0x21ec09='{';for(let _0x5d8876=0x0;_0x5d8876<_0x8bd1ec['length'];_0x5d8876++)_0x5d8876!==0x0&&(_0x21ec09+=','),_0x21ec09+=O(_0x8bd1ec[_0x5d8876]),_0x21ec09+=':',_0x21ec09+=$i(_0x13b3ef[_0x8bd1ec[_0x5d8876]]);return _0x21ec09+='}',_0x21ec09;},oo=function(_0x1b544c,_0x3b5bf7){const _0x2b96e0=_0x1b544c['length'];if(_0x2b96e0<=_0x3b5bf7)return[_0x1b544c];const _0x59cd3a=[];for(let _0x5df475=0x0;_0x5df475<_0x2b96e0;_0x5df475+=_0x3b5bf7)_0x5df475+_0x3b5bf7>_0x2b96e0?_0x59cd3a['push'](_0x1b544c['substring'](_0x5df475,_0x2b96e0)):_0x59cd3a['push'](_0x1b544c['substring'](_0x5df475,_0x5df475+_0x3b5bf7));return _0x59cd3a;};function x(_0x5e79c8,_0x24e5d8){for(const _0x293722 in _0x5e79c8)_0x5e79c8['hasOwnProperty'](_0x293722)&&_0x24e5d8(_0x293722,_0x5e79c8[_0x293722]);}const ao=function(_0x332fb8){f(!xn(_0x332fb8),'Invalid\x20JSON\x20number');const _0x3d20e4=0xb,_0x42b268=0x34,_0x40d3d3=(0x1<<_0x3d20e4-0x1)-0x1;let _0x4f11c6,_0x427afa,_0x261817,_0x38595e,_0x432b16;_0x332fb8===0x0?(_0x427afa=0x0,_0x261817=0x0,_0x4f11c6=0x1/_0x332fb8===-0x1/0x0?0x1:0x0):(_0x4f11c6=_0x332fb8<0x0,_0x332fb8=Math['abs'](_0x332fb8),_0x332fb8>=Math['pow'](0x2,0x1-_0x40d3d3)?(_0x38595e=Math['min'](Math['floor'](Math['log'](_0x332fb8)/Math['LN2']),_0x40d3d3),_0x427afa=_0x38595e+_0x40d3d3,_0x261817=Math['round'](_0x332fb8*Math['pow'](0x2,_0x42b268-_0x38595e)-Math['pow'](0x2,_0x42b268))):(_0x427afa=0x0,_0x261817=Math['round'](_0x332fb8/Math['pow'](0x2,0x1-_0x40d3d3-_0x42b268))));const _0x2c6d38=[];for(_0x432b16=_0x42b268;_0x432b16;_0x432b16-=0x1)_0x2c6d38['push'](_0x261817%0x2?0x1:0x0),_0x261817=Math['floor'](_0x261817/0x2);for(_0x432b16=_0x3d20e4;_0x432b16;_0x432b16-=0x1)_0x2c6d38['push'](_0x427afa%0x2?0x1:0x0),_0x427afa=Math['floor'](_0x427afa/0x2);_0x2c6d38['push'](_0x4f11c6?0x1:0x0),_0x2c6d38['reverse']();const _0x4b1ccc=_0x2c6d38['join']('');let _0x2c8693='';for(_0x432b16=0x0;_0x432b16<0x40;_0x432b16+=0x8){let _0x5351a9=parseInt(_0x4b1ccc['substr'](_0x432b16,0x8),0x2)['toString'](0x10);_0x5351a9['length']===0x1&&(_0x5351a9='0'+_0x5351a9),_0x2c8693=_0x2c8693+_0x5351a9;}return _0x2c8693['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x2da349,_0x58f7c2){let _0x50ad78='Unknown\x20Error';_0x2da349==='too_big'?_0x50ad78='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2da349==='permission_denied'?_0x50ad78='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2da349==='unavailable'&&(_0x50ad78='The\x20service\x20is\x20unavailable');const _0x424ce4=new Error(_0x2da349+'\x20at\x20'+_0x58f7c2['_path']['toString']()+':\x20'+_0x50ad78);return _0x424ce4['code']=_0x2da349['toUpperCase'](),_0x424ce4;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x227807){if(Yl['test'](_0x227807)){const _0x575041=Number(_0x227807);if(_0x575041>=Ql&&_0x575041<=Jl)return _0x575041;}return null;},ft=function(_0x81e9b2){try{_0x81e9b2();}catch(_0x224d1f){setTimeout(()=>{const _0x495671=_0x224d1f['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x495671),_0x224d1f;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x51c664,_0x40c3d9){const _0x1b9a91=setTimeout(_0x51c664,_0x40c3d9);return typeof _0x1b9a91=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1b9a91):typeof _0x1b9a91=='object'&&_0x1b9a91['unref']&&_0x1b9a91['unref'](),_0x1b9a91;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x3ee45c,_0x1d438e){this['appCheckProvider']=_0x1d438e,this['appName']=_0x3ee45c['name'],$(_0x3ee45c)&&_0x3ee45c['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3ee45c['settings']['appCheckToken']),this['appCheck']=_0x1d438e==null?void 0x0:_0x1d438e['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1d438e==null||_0x1d438e['get']()['then'](_0x5c912e=>this['appCheck']=_0x5c912e);}['getToken'](_0x24c7b1){if(this['serverAppAppCheckToken']){if(_0x24c7b1)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x24c7b1):new Promise((_0xd70dbb,_0x5a77cc)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x24c7b1)['then'](_0xd70dbb,_0x5a77cc):_0xd70dbb(null);},0x0);});}['addTokenChangeListener'](_0xda3675){var _0x4a9376;(_0x4a9376=this['appCheckProvider'])==null||_0x4a9376['get']()['then'](_0x235ff6=>_0x235ff6['addTokenListener'](_0xda3675));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x36cc1f,_0x163ae4,_0x2be504){this['appName_']=_0x36cc1f,this['firebaseOptions_']=_0x163ae4,this['authProvider_']=_0x2be504,this['auth_']=null,this['auth_']=_0x2be504['getImmediate']({'optional':!0x0}),this['auth_']||_0x2be504['onInit'](_0x1d3816=>this['auth_']=_0x1d3816);}['getToken'](_0x20b5ab){return this['auth_']?this['auth_']['getToken'](_0x20b5ab)['catch'](_0x522924=>_0x522924&&_0x522924['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x522924)):new Promise((_0x1f0967,_0x2ea9bc)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x20b5ab)['then'](_0x1f0967,_0x2ea9bc):_0x1f0967(null);},0x0);});}['addTokenChangeListener'](_0x210e09){this['auth_']?this['auth_']['addAuthTokenListener'](_0x210e09):this['authProvider_']['get']()['then'](_0x5d147b=>_0x5d147b['addAuthTokenListener'](_0x210e09));}['removeTokenChangeListener'](_0x3335a2){this['authProvider_']['get']()['then'](_0x4c6c21=>_0x4c6c21['removeAuthTokenListener'](_0x3335a2));}['notifyForInvalidToken'](){let _0x426ad0='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x426ad0+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x426ad0+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x426ad0+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x426ad0);}}class an{constructor(_0x528e36){this['accessToken']=_0x528e36;}['getToken'](_0x5091da){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x57bc57){_0x57bc57(this['accessToken']);}['removeTokenChangeListener'](_0x34712c){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x2c8ffb,_0x26de60,_0x5a84c9,_0x144fdf,_0x2e1d56=!0x1,_0x39c199='',_0x492810=!0x1,_0x2019a9=!0x1,_0x437a02=null){this['secure']=_0x26de60,this['namespace']=_0x5a84c9,this['webSocketOnly']=_0x144fdf,this['nodeAdmin']=_0x2e1d56,this['persistenceKey']=_0x39c199,this['includeNamespaceInQueryParams']=_0x492810,this['isUsingEmulator']=_0x2019a9,this['emulatorOptions']=_0x437a02,this['_host']=_0x2c8ffb['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x2c8ffb)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x291571){_0x291571!==this['internalHost']&&(this['internalHost']=_0x291571,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1d17bc=this['toURLString']();return this['persistenceKey']&&(_0x1d17bc+='<'+this['persistenceKey']+'>'),_0x1d17bc;}['toURLString'](){const _0x229e42=this['secure']?'https://':'http://',_0x44f1a3=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x229e42+this['host']+'/'+_0x44f1a3;}}function th(_0x2481ca){return _0x2481ca['host']!==_0x2481ca['internalHost']||_0x2481ca['isCustomHost']()||_0x2481ca['includeNamespaceInQueryParams'];}function vo(_0x3085a1,_0x55c032,_0x1a2576){f(typeof _0x55c032=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1a2576=='object','typeof\x20params\x20must\x20==\x20object');let _0x479155;if(_0x55c032===go)_0x479155=(_0x3085a1['secure']?'wss://':'ws://')+_0x3085a1['internalHost']+'/.ws?';else{if(_0x55c032===mo)_0x479155=(_0x3085a1['secure']?'https://':'http://')+_0x3085a1['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x55c032);}th(_0x3085a1)&&(_0x1a2576['ns']=_0x3085a1['namespace']);const _0x5419b6=[];return x(_0x1a2576,(_0x5cf9a7,_0x28c8f6)=>{_0x5419b6['push'](_0x5cf9a7+'='+_0x28c8f6);}),_0x479155+_0x5419b6['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x1a3cb9,_0x33b620=0x1){Q(this['counters_'],_0x1a3cb9)||(this['counters_'][_0x1a3cb9]=0x0),this['counters_'][_0x1a3cb9]+=_0x33b620;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x48f688){const _0x35f379=_0x48f688['toString']();return oi[_0x35f379]||(oi[_0x35f379]=new nh()),oi[_0x35f379];}function ih(_0x8cf4d3,_0x16ec39){const _0x3279c1=_0x8cf4d3['toString']();return ai[_0x3279c1]||(ai[_0x3279c1]=_0x16ec39()),ai[_0x3279c1];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x54eaa3){this['onMessage_']=_0x54eaa3,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x1c5b2e,_0x377c17){this['closeAfterResponse']=_0x1c5b2e,this['onClose']=_0x377c17,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4f2949,_0x567cbf){for(this['pendingResponses'][_0x4f2949]=_0x567cbf;this['pendingResponses'][this['currentResponseNum']];){const _0x4a984=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1d0af5=0x0;_0x1d0af5<_0x4a984['length'];++_0x1d0af5)_0x4a984[_0x1d0af5]&&ft(()=>{this['onMessage_'](_0x4a984[_0x1d0af5]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x12ccba,_0x534ff4,_0x98ae35,_0xf8da96,_0x161d55,_0x489d90,_0x5596a8){this['connId']=_0x12ccba,this['repoInfo']=_0x534ff4,this['applicationId']=_0x98ae35,this['appCheckToken']=_0xf8da96,this['authToken']=_0x161d55,this['transportSessionId']=_0x489d90,this['lastSessionId']=_0x5596a8,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x12ccba),this['stats_']=qi(_0x534ff4),this['urlFn']=_0x1a647a=>(this['appCheckToken']&&(_0x1a647a[wi]=this['appCheckToken']),vo(_0x534ff4,mo,_0x1a647a));}['open'](_0x45ee3c,_0x5c83bc){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5c83bc,this['myPacketOrderer']=new sh(_0x45ee3c),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x1ddf6c)=>{const [_0x49b515,_0x1e9fc0,_0x3c80ee,_0x1305a4,_0x58ea9a]=_0x1ddf6c;if(this['incrementIncomingBytes_'](_0x1ddf6c),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x49b515===qs)this['id']=_0x1e9fc0,this['password']=_0x3c80ee;else{if(_0x49b515===rh)_0x1e9fc0?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1e9fc0,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x49b515);}}},(..._0x377bb3)=>{const [_0xb632b9,_0x28776a]=_0x377bb3;this['incrementIncomingBytes_'](_0x377bb3),this['myPacketOrderer']['handleResponse'](_0xb632b9,_0x28776a);},()=>{this['onClosed_']();},this['urlFn']);const _0x483972={};_0x483972[qs]='t',_0x483972[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x483972[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x483972[co]=Gi,this['transportSessionId']&&(_0x483972[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x483972[po]=this['lastSessionId']),this['applicationId']&&(_0x483972[_o]=this['applicationId']),this['appCheckToken']&&(_0x483972[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x483972[ho]=uo);const _0xf5f7d3=this['urlFn'](_0x483972);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0xf5f7d3),this['scriptTagHolder']['addTag'](_0xf5f7d3,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x453a17){const _0x18303d=O(_0x453a17);this['bytesSent']+=_0x18303d['length'],this['stats_']['incrementCounter']('bytes_sent',_0x18303d['length']);const _0x2ec719=$r(_0x18303d),_0x14a969=oo(_0x2ec719,fh);for(let _0x5b8432=0x0;_0x5b8432<_0x14a969['length'];_0x5b8432++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x14a969['length'],_0x14a969[_0x5b8432]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x8b0924,_0x27e033){this['myDisconnFrame']=document['createElement']('iframe');const _0x1aceeb={};_0x1aceeb[dh]='t',_0x1aceeb[Eo]=_0x8b0924,_0x1aceeb[Io]=_0x27e033,this['myDisconnFrame']['src']=this['urlFn'](_0x1aceeb),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x273ea3){const _0x220ba1=O(_0x273ea3)['length'];this['bytesReceived']+=_0x220ba1,this['stats_']['incrementCounter']('bytes_received',_0x220ba1);}}class zi{constructor(_0x3ef24d,_0x456d97,_0x50abf8,_0x28bd98){this['onDisconnect']=_0x50abf8,this['urlFn']=_0x28bd98,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x3ef24d,window[ah+this['uniqueCallbackIdentifier']]=_0x456d97,this['myIFrame']=zi['createIFrame_']();let _0x115b2f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x115b2f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x5a4c93='<html><body>'+_0x115b2f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x5a4c93),this['myIFrame']['doc']['close']();}catch(_0x29b00d){L('frame\x20writing\x20exception'),_0x29b00d['stack']&&L(_0x29b00d['stack']),L(_0x29b00d);}}}static['createIFrame_'](){const _0x4d087b=document['createElement']('iframe');if(_0x4d087b['style']['display']='none',document['body']){document['body']['appendChild'](_0x4d087b);try{_0x4d087b['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x23eab0=document['domain'];_0x4d087b['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x23eab0+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4d087b['contentDocument']?_0x4d087b['doc']=_0x4d087b['contentDocument']:_0x4d087b['contentWindow']?_0x4d087b['doc']=_0x4d087b['contentWindow']['document']:_0x4d087b['document']&&(_0x4d087b['doc']=_0x4d087b['document']),_0x4d087b;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3673e3=this['onDisconnect'];_0x3673e3&&(this['onDisconnect']=null,_0x3673e3());}['startLongPoll'](_0x160b65,_0x29cc3a){for(this['myID']=_0x160b65,this['myPW']=_0x29cc3a,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x557a84={};_0x557a84[Eo]=this['myID'],_0x557a84[Io]=this['myPW'],_0x557a84[wo]=this['currentSerial'];let _0x1ebf91=this['urlFn'](_0x557a84),_0x5abeb9='',_0x2b0b19=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x5abeb9['length']<=Co;){const _0x1b8114=this['pendingSegs']['shift']();_0x5abeb9=_0x5abeb9+'&'+lh+_0x2b0b19+'='+_0x1b8114['seg']+'&'+hh+_0x2b0b19+'='+_0x1b8114['ts']+'&'+uh+_0x2b0b19+'='+_0x1b8114['d'],_0x2b0b19++;}return _0x1ebf91=_0x1ebf91+_0x5abeb9,this['addLongPollTag_'](_0x1ebf91,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x4c6034,_0x3ba8ca,_0x1e5d61){this['pendingSegs']['push']({'seg':_0x4c6034,'ts':_0x3ba8ca,'d':_0x1e5d61}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2d5531,_0x2540b5){this['outstandingRequests']['add'](_0x2540b5);const _0x18655e=()=>{this['outstandingRequests']['delete'](_0x2540b5),this['newRequest_']();},_0x352387=setTimeout(_0x18655e,Math['floor'](ph)),_0x75a5bc=()=>{clearTimeout(_0x352387),_0x18655e();};this['addTag'](_0x2d5531,_0x75a5bc);}['addTag'](_0x4be8b8,_0x3d4b6d){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xeb1168=this['myIFrame']['doc']['createElement']('script');_0xeb1168['type']='text/javascript',_0xeb1168['async']=!0x0,_0xeb1168['src']=_0x4be8b8,_0xeb1168['onload']=_0xeb1168['onreadystatechange']=function(){const _0x3a00ad=_0xeb1168['readyState'];(!_0x3a00ad||_0x3a00ad==='loaded'||_0x3a00ad==='complete')&&(_0xeb1168['onload']=_0xeb1168['onreadystatechange']=null,_0xeb1168['parentNode']&&_0xeb1168['parentNode']['removeChild'](_0xeb1168),_0x3d4b6d());},_0xeb1168['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4be8b8),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xeb1168);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x2d5236,_0x53fbd2,_0x1cf7ee,_0x5b7aee,_0xabb1a7,_0x506f93,_0x175506){this['connId']=_0x2d5236,this['applicationId']=_0x1cf7ee,this['appCheckToken']=_0x5b7aee,this['authToken']=_0xabb1a7,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x53fbd2),this['connURL']=q['connectionURL_'](_0x53fbd2,_0x506f93,_0x175506,_0x5b7aee,_0x1cf7ee),this['nodeAdmin']=_0x53fbd2['nodeAdmin'];}static['connectionURL_'](_0x5a5a02,_0x1a1e99,_0x13d219,_0x1b5dc3,_0x21c7b2){const _0x2d5ad6={};return _0x2d5ad6[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2d5ad6[ho]=uo),_0x1a1e99&&(_0x2d5ad6[lo]=_0x1a1e99),_0x13d219&&(_0x2d5ad6[po]=_0x13d219),_0x1b5dc3&&(_0x2d5ad6[wi]=_0x1b5dc3),_0x21c7b2&&(_0x2d5ad6[_o]=_0x21c7b2),vo(_0x5a5a02,go,_0x2d5ad6);}['open'](_0x5a8e28,_0x45d0c9){this['onDisconnect']=_0x45d0c9,this['onMessage']=_0x5a8e28,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x18be0c;_c(),this['mySock']=new gn(this['connURL'],[],_0x18be0c);}catch(_0x260c9f){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2fb67b=_0x260c9f['message']||_0x260c9f['data'];_0x2fb67b&&this['log_'](_0x2fb67b),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x32b8e0=>{this['handleIncomingFrame'](_0x32b8e0);},this['mySock']['onerror']=_0xf0cb3c=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3eb823=_0xf0cb3c['message']||_0xf0cb3c['data'];_0x3eb823&&this['log_'](_0x3eb823),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x53505f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x38885f=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x41d383=navigator['userAgent']['match'](_0x38885f);_0x41d383&&_0x41d383['length']>0x1&&parseFloat(_0x41d383[0x1])<4.4&&(_0x53505f=!0x0);}return!_0x53505f&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x635e52){if(this['frames']['push'](_0x635e52),this['frames']['length']===this['totalFrames']){const _0x267836=this['frames']['join']('');this['frames']=null;const _0x539c2d=Nt(_0x267836);this['onMessage'](_0x539c2d);}}['handleNewFrameCount_'](_0x50cbf9){this['totalFrames']=_0x50cbf9,this['frames']=[];}['extractFrameCount_'](_0x5b221e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x5b221e['length']<=0x6){const _0x483178=Number(_0x5b221e);if(!isNaN(_0x483178))return this['handleNewFrameCount_'](_0x483178),null;}return this['handleNewFrameCount_'](0x1),_0x5b221e;}['handleIncomingFrame'](_0x9c3bc1){if(this['mySock']===null)return;const _0x446ccf=_0x9c3bc1['data'];if(this['bytesReceived']+=_0x446ccf['length'],this['stats_']['incrementCounter']('bytes_received',_0x446ccf['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x446ccf);else{const _0x300659=this['extractFrameCount_'](_0x446ccf);_0x300659!==null&&this['appendFrame_'](_0x300659);}}['send'](_0x5bf022){this['resetKeepAlive']();const _0x159903=O(_0x5bf022);this['bytesSent']+=_0x159903['length'],this['stats_']['incrementCounter']('bytes_sent',_0x159903['length']);const _0x57b063=oo(_0x159903,gh);_0x57b063['length']>0x1&&this['sendString_'](String(_0x57b063['length']));for(let _0x7f226=0x0;_0x7f226<_0x57b063['length'];_0x7f226++)this['sendString_'](_0x57b063[_0x7f226]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x20c78b){try{this['mySock']['send'](_0x20c78b);}catch(_0x1ce3a4){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1ce3a4['message']||_0x1ce3a4['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5f19b4){this['initTransports_'](_0x5f19b4);}['initTransports_'](_0x3275e3){const _0x5e5e33=q&&q['isAvailable']();let _0x24acd6=_0x5e5e33&&!q['previouslyFailed']();if(_0x3275e3['webSocketOnly']&&(_0x5e5e33||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x24acd6=!0x0),_0x24acd6)this['transports_']=[q];else{const _0x1986ff=this['transports_']=[];for(const _0x4ce55b of Dt['ALL_TRANSPORTS'])_0x4ce55b&&_0x4ce55b['isAvailable']()&&_0x1986ff['push'](_0x4ce55b);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x2ad16b,_0x7bd536,_0x1b5bd0,_0x5cdcf3,_0x5d28b3,_0xf3e006,_0x435dec,_0x21c44a,_0x26d82c,_0x863f6a){this['id']=_0x2ad16b,this['repoInfo_']=_0x7bd536,this['applicationId_']=_0x1b5bd0,this['appCheckToken_']=_0x5cdcf3,this['authToken_']=_0x5d28b3,this['onMessage_']=_0xf3e006,this['onReady_']=_0x435dec,this['onDisconnect_']=_0x21c44a,this['onKill_']=_0x26d82c,this['lastSessionId']=_0x863f6a,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x7bd536),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2b7b25=this['transportManager_']['initialTransport']();this['conn_']=new _0x2b7b25(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2b7b25['responsesRequiredToBeHealthy']||0x0;const _0x4a3bde=this['connReceiver_'](this['conn_']),_0xa7a604=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x4a3bde,_0xa7a604);},Math['floor'](0x0));const _0x3a8e5a=_0x2b7b25['healthyTimeout']||0x0;_0x3a8e5a>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3a8e5a)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1a17ba){return _0x13112e=>{_0x1a17ba===this['conn_']?this['onConnectionLost_'](_0x13112e):_0x1a17ba===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x4d9fd9){return _0x3d22c3=>{this['state_']!==0x2&&(_0x4d9fd9===this['rx_']?this['onPrimaryMessageReceived_'](_0x3d22c3):_0x4d9fd9===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3d22c3):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x14a2ce){const _0x46ea15={'t':'d','d':_0x14a2ce};this['sendData_'](_0x46ea15);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x5911c7){if(ci in _0x5911c7){const _0x3da7aa=_0x5911c7[ci];_0x3da7aa===Ys?this['upgradeIfSecondaryHealthy_']():_0x3da7aa===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3da7aa===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x531777){const _0x38c3f5=vt('t',_0x531777),_0x17519c=vt('d',_0x531777);if(_0x38c3f5==='c')this['onSecondaryControl_'](_0x17519c);else{if(_0x38c3f5==='d')this['pendingDataMessages']['push'](_0x17519c);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x38c3f5);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5ccdbe){const _0x2b9bc1=vt('t',_0x5ccdbe),_0x1152e6=vt('d',_0x5ccdbe);_0x2b9bc1==='c'?this['onControl_'](_0x1152e6):_0x2b9bc1==='d'&&this['onDataMessage_'](_0x1152e6);}['onDataMessage_'](_0x1c6536){this['onPrimaryResponse_'](),this['onMessage_'](_0x1c6536);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x132599){const _0x158d3c=vt(ci,_0x132599);if(zs in _0x132599){const _0x341081=_0x132599[zs];if(_0x158d3c===Th){const _0x2dfb40={..._0x341081};this['repoInfo_']['isUsingEmulator']&&(_0x2dfb40['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x2dfb40);}else{if(_0x158d3c===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x729d12=0x0;_0x729d12<this['pendingDataMessages']['length'];++_0x729d12)this['onDataMessage_'](this['pendingDataMessages'][_0x729d12]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x158d3c===wh?this['onConnectionShutdown_'](_0x341081):_0x158d3c===js?this['onReset_'](_0x341081):_0x158d3c===Ch?Ii('Server\x20Error:\x20'+_0x341081):_0x158d3c===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x158d3c);}}}['onHandshake_'](_0x1dbbcb){const _0x146910=_0x1dbbcb['ts'],_0x52ded6=_0x1dbbcb['v'],_0x3b2056=_0x1dbbcb['h'];this['sessionId']=_0x1dbbcb['s'],this['repoInfo_']['host']=_0x3b2056,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x146910),Gi!==_0x52ded6&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xcf8a0d=this['transportManager_']['upgradeTransport']();_0xcf8a0d&&this['startUpgrade_'](_0xcf8a0d);}['startUpgrade_'](_0x4326fa){this['secondaryConn_']=new _0x4326fa(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4326fa['responsesRequiredToBeHealthy']||0x0;const _0x3c5c67=this['connReceiver_'](this['secondaryConn_']),_0x461b7f=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3c5c67,_0x461b7f),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x3ebe96){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x3ebe96),this['repoInfo_']['host']=_0x3ebe96,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x32d393,_0x2b13ed){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x32d393,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2b13ed,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x59765f=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x59765f||this['rx_']===_0x59765f)&&this['close']();}['onConnectionLost_'](_0x41b9d1){this['conn_']=null,!_0x41b9d1&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5865cd){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5865cd),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x6d37e0){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x6d37e0);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x23023d,_0x50b60d,_0x1687c8,_0x711efc){}['merge'](_0x4238f6,_0x175e62,_0x35f0af,_0x5561e1){}['refreshAuthToken'](_0x5eb587){}['refreshAppCheckToken'](_0x5170d2){}['onDisconnectPut'](_0x3aeeb2,_0x5c6f94,_0x299b9f){}['onDisconnectMerge'](_0x1bd852,_0x4c6497,_0x4c9d29){}['onDisconnectCancel'](_0x1d7ed8,_0x59862f){}['reportStats'](_0x404663){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0xf838d9){this['allowedEvents_']=_0xf838d9,this['listeners_']={},f(Array['isArray'](_0xf838d9)&&_0xf838d9['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x54d9ad,..._0x4c3303){if(Array['isArray'](this['listeners_'][_0x54d9ad])){const _0x18fc33=[...this['listeners_'][_0x54d9ad]];for(let _0x1ef89c=0x0;_0x1ef89c<_0x18fc33['length'];_0x1ef89c++)_0x18fc33[_0x1ef89c]['callback']['apply'](_0x18fc33[_0x1ef89c]['context'],_0x4c3303);}}['on'](_0x261a5f,_0x543130,_0x44c5d1){this['validateEventType_'](_0x261a5f),this['listeners_'][_0x261a5f]=this['listeners_'][_0x261a5f]||[],this['listeners_'][_0x261a5f]['push']({'callback':_0x543130,'context':_0x44c5d1});const _0x33f18f=this['getInitialEvent'](_0x261a5f);_0x33f18f&&_0x543130['apply'](_0x44c5d1,_0x33f18f);}['off'](_0x510841,_0x211778,_0x3f4412){this['validateEventType_'](_0x510841);const _0x18475c=this['listeners_'][_0x510841]||[];for(let _0x4d0bae=0x0;_0x4d0bae<_0x18475c['length'];_0x4d0bae++)if(_0x18475c[_0x4d0bae]['callback']===_0x211778&&(!_0x3f4412||_0x3f4412===_0x18475c[_0x4d0bae]['context'])){_0x18475c['splice'](_0x4d0bae,0x1);return;}}['validateEventType_'](_0x105bf9){f(this['allowedEvents_']['find'](_0x5b3e31=>_0x5b3e31===_0x105bf9),'Unknown\x20event:\x20'+_0x105bf9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x5a61ca){return f(_0x5a61ca==='online','Unknown\x20event\x20type:\x20'+_0x5a61ca),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0xcd86ca,_0x2f9cef){if(_0x2f9cef===void 0x0){this['pieces_']=_0xcd86ca['split']('/');let _0x9a1a19=0x0;for(let _0x300461=0x0;_0x300461<this['pieces_']['length'];_0x300461++)this['pieces_'][_0x300461]['length']>0x0&&(this['pieces_'][_0x9a1a19]=this['pieces_'][_0x300461],_0x9a1a19++);this['pieces_']['length']=_0x9a1a19,this['pieceNum_']=0x0;}else this['pieces_']=_0xcd86ca,this['pieceNum_']=_0x2f9cef;}['toString'](){let _0x181746='';for(let _0x3fc796=this['pieceNum_'];_0x3fc796<this['pieces_']['length'];_0x3fc796++)this['pieces_'][_0x3fc796]!==''&&(_0x181746+='/'+this['pieces_'][_0x3fc796]);return _0x181746||'/';}}function w(){return new C('');}function y(_0x2c21fd){return _0x2c21fd['pieceNum_']>=_0x2c21fd['pieces_']['length']?null:_0x2c21fd['pieces_'][_0x2c21fd['pieceNum_']];}function Ce(_0x11ffa5){return _0x11ffa5['pieces_']['length']-_0x11ffa5['pieceNum_'];}function S(_0x496e3d){let _0x3ce775=_0x496e3d['pieceNum_'];return _0x3ce775<_0x496e3d['pieces_']['length']&&_0x3ce775++,new C(_0x496e3d['pieces_'],_0x3ce775);}function ji(_0xe666d7){return _0xe666d7['pieceNum_']<_0xe666d7['pieces_']['length']?_0xe666d7['pieces_'][_0xe666d7['pieces_']['length']-0x1]:null;}function bh(_0x2087b7){let _0x41ed9f='';for(let _0x3d86d8=_0x2087b7['pieceNum_'];_0x3d86d8<_0x2087b7['pieces_']['length'];_0x3d86d8++)_0x2087b7['pieces_'][_0x3d86d8]!==''&&(_0x41ed9f+='/'+encodeURIComponent(String(_0x2087b7['pieces_'][_0x3d86d8])));return _0x41ed9f||'/';}function Mt(_0x140d24,_0x2cbde5=0x0){return _0x140d24['pieces_']['slice'](_0x140d24['pieceNum_']+_0x2cbde5);}function Ro(_0x29b811){if(_0x29b811['pieceNum_']>=_0x29b811['pieces_']['length'])return null;const _0x2fc87d=[];for(let _0x8a833a=_0x29b811['pieceNum_'];_0x8a833a<_0x29b811['pieces_']['length']-0x1;_0x8a833a++)_0x2fc87d['push'](_0x29b811['pieces_'][_0x8a833a]);return new C(_0x2fc87d,0x0);}function k(_0x33c5df,_0x384fa0){const _0x2f7411=[];for(let _0x45cecb=_0x33c5df['pieceNum_'];_0x45cecb<_0x33c5df['pieces_']['length'];_0x45cecb++)_0x2f7411['push'](_0x33c5df['pieces_'][_0x45cecb]);if(_0x384fa0 instanceof C){for(let _0x55cdcb=_0x384fa0['pieceNum_'];_0x55cdcb<_0x384fa0['pieces_']['length'];_0x55cdcb++)_0x2f7411['push'](_0x384fa0['pieces_'][_0x55cdcb]);}else{const _0x4d60aa=_0x384fa0['split']('/');for(let _0x34c887=0x0;_0x34c887<_0x4d60aa['length'];_0x34c887++)_0x4d60aa[_0x34c887]['length']>0x0&&_0x2f7411['push'](_0x4d60aa[_0x34c887]);}return new C(_0x2f7411,0x0);}function v(_0x3e6de8){return _0x3e6de8['pieceNum_']>=_0x3e6de8['pieces_']['length'];}function F(_0x1b1f73,_0x4a6c54){const _0x164c4d=y(_0x1b1f73),_0x2e5f93=y(_0x4a6c54);if(_0x164c4d===null)return _0x4a6c54;if(_0x164c4d===_0x2e5f93)return F(S(_0x1b1f73),S(_0x4a6c54));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x4a6c54+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1b1f73+')');}function Rh(_0x2fc315,_0x4c30a5){const _0x393b9f=Mt(_0x2fc315,0x0),_0x2a01ff=Mt(_0x4c30a5,0x0);for(let _0x50a620=0x0;_0x50a620<_0x393b9f['length']&&_0x50a620<_0x2a01ff['length'];_0x50a620++){const _0x403f41=qe(_0x393b9f[_0x50a620],_0x2a01ff[_0x50a620]);if(_0x403f41!==0x0)return _0x403f41;}return _0x393b9f['length']===_0x2a01ff['length']?0x0:_0x393b9f['length']<_0x2a01ff['length']?-0x1:0x1;}function Ki(_0x1913a8,_0x4c52f5){if(Ce(_0x1913a8)!==Ce(_0x4c52f5))return!0x1;for(let _0x82b76a=_0x1913a8['pieceNum_'],_0x2672e5=_0x4c52f5['pieceNum_'];_0x82b76a<=_0x1913a8['pieces_']['length'];_0x82b76a++,_0x2672e5++)if(_0x1913a8['pieces_'][_0x82b76a]!==_0x4c52f5['pieces_'][_0x2672e5])return!0x1;return!0x0;}function G(_0x4e14cc,_0x16f020){let _0x22c174=_0x4e14cc['pieceNum_'],_0x59bf0e=_0x16f020['pieceNum_'];if(Ce(_0x4e14cc)>Ce(_0x16f020))return!0x1;for(;_0x22c174<_0x4e14cc['pieces_']['length'];){if(_0x4e14cc['pieces_'][_0x22c174]!==_0x16f020['pieces_'][_0x59bf0e])return!0x1;++_0x22c174,++_0x59bf0e;}return!0x0;}class Ah{constructor(_0x16192a,_0x17dfa2){this['errorPrefix_']=_0x17dfa2,this['parts_']=Mt(_0x16192a,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x276fe5=0x0;_0x276fe5<this['parts_']['length'];_0x276fe5++)this['byteLength_']+=Ln(this['parts_'][_0x276fe5]);Ao(this);}}function kh(_0x279c8f,_0xd622cd){_0x279c8f['parts_']['length']>0x0&&(_0x279c8f['byteLength_']+=0x1),_0x279c8f['parts_']['push'](_0xd622cd),_0x279c8f['byteLength_']+=Ln(_0xd622cd),Ao(_0x279c8f);}function Ph(_0x768aad){const _0x412981=_0x768aad['parts_']['pop']();_0x768aad['byteLength_']-=Ln(_0x412981),_0x768aad['parts_']['length']>0x0&&(_0x768aad['byteLength_']-=0x1);}function Ao(_0x410212){if(_0x410212['byteLength_']>Zs)throw new Error(_0x410212['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x410212['byteLength_']+').');if(_0x410212['parts_']['length']>Xs)throw new Error(_0x410212['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x410212));}function Oe(_0x2f4b9c){return _0x2f4b9c['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2f4b9c['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x549d9c,_0x303615;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x303615='visibilitychange',_0x549d9c='hidden'):typeof document['mozHidden']<'u'?(_0x303615='mozvisibilitychange',_0x549d9c='mozHidden'):typeof document['msHidden']<'u'?(_0x303615='msvisibilitychange',_0x549d9c='msHidden'):typeof document['webkitHidden']<'u'&&(_0x303615='webkitvisibilitychange',_0x549d9c='webkitHidden')),this['visible_']=!0x0,_0x303615&&document['addEventListener'](_0x303615,()=>{const _0x5c4b2f=!document[_0x549d9c];_0x5c4b2f!==this['visible_']&&(this['visible_']=_0x5c4b2f,this['trigger']('visible',_0x5c4b2f));},!0x1);}['getInitialEvent'](_0x3215a6){return f(_0x3215a6==='visible','Unknown\x20event\x20type:\x20'+_0x3215a6),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x2b547c,_0xc6d7a,_0x4dcc69,_0x5b8a7f,_0x255b52,_0x2b8004,_0x4c851d,_0xa65f26){if(super(),this['repoInfo_']=_0x2b547c,this['applicationId_']=_0xc6d7a,this['onDataUpdate_']=_0x4dcc69,this['onConnectStatus_']=_0x5b8a7f,this['onServerInfoUpdate_']=_0x255b52,this['authTokenProvider_']=_0x2b8004,this['appCheckTokenProvider_']=_0x4c851d,this['authOverride_']=_0xa65f26,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xa65f26)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2b547c['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x18503d,_0x2f3499,_0x1661e1){const _0x99e0e0=++this['requestNumber_'],_0x5e249d={'r':_0x99e0e0,'a':_0x18503d,'b':_0x2f3499};this['log_'](O(_0x5e249d)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5e249d),_0x1661e1&&(this['requestCBHash_'][_0x99e0e0]=_0x1661e1);}['get'](_0x22f413){this['initConnection_']();const _0x500002=new H(),_0x5c8f25={'action':'g','request':{'p':_0x22f413['_path']['toString'](),'q':_0x22f413['_queryObject']},'onComplete':_0x427695=>{const _0x96399=_0x427695['d'];_0x427695['s']==='ok'?_0x500002['resolve'](_0x96399):_0x500002['reject'](_0x96399);}};this['outstandingGets_']['push'](_0x5c8f25),this['outstandingGetCount_']++;const _0x14008b=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x14008b),_0x500002['promise'];}['listen'](_0x2a042f,_0x35873c,_0xf2b4e6,_0x36b9f8){this['initConnection_']();const _0xf52c1b=_0x2a042f['_queryIdentifier'],_0x5315a0=_0x2a042f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5315a0+'\x20'+_0xf52c1b),this['listens']['has'](_0x5315a0)||this['listens']['set'](_0x5315a0,new Map()),f(_0x2a042f['_queryParams']['isDefault']()||!_0x2a042f['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x5315a0)['has'](_0xf52c1b),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x57c740={'onComplete':_0x36b9f8,'hashFn':_0x35873c,'query':_0x2a042f,'tag':_0xf2b4e6};this['listens']['get'](_0x5315a0)['set'](_0xf52c1b,_0x57c740),this['connected_']&&this['sendListen_'](_0x57c740);}['sendGet_'](_0x55647d){const _0x407515=this['outstandingGets_'][_0x55647d];this['sendRequest']('g',_0x407515['request'],_0x2408bd=>{delete this['outstandingGets_'][_0x55647d],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x407515['onComplete']&&_0x407515['onComplete'](_0x2408bd);});}['sendListen_'](_0x501957){const _0x147e7c=_0x501957['query'],_0x656dcc=_0x147e7c['_path']['toString'](),_0x3bfc98=_0x147e7c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x656dcc+'\x20for\x20'+_0x3bfc98);const _0x340896={'p':_0x656dcc},_0x5840e2='q';_0x501957['tag']&&(_0x340896['q']=_0x147e7c['_queryObject'],_0x340896['t']=_0x501957['tag']),_0x340896['h']=_0x501957['hashFn'](),this['sendRequest'](_0x5840e2,_0x340896,_0x46a872=>{const _0x18b350=_0x46a872['d'],_0x24a65c=_0x46a872['s'];se['warnOnListenWarnings_'](_0x18b350,_0x147e7c),(this['listens']['get'](_0x656dcc)&&this['listens']['get'](_0x656dcc)['get'](_0x3bfc98))===_0x501957&&(this['log_']('listen\x20response',_0x46a872),_0x24a65c!=='ok'&&this['removeListen_'](_0x656dcc,_0x3bfc98),_0x501957['onComplete']&&_0x501957['onComplete'](_0x24a65c,_0x18b350));});}static['warnOnListenWarnings_'](_0x10cc61,_0x5c39a9){if(_0x10cc61&&typeof _0x10cc61=='object'&&Q(_0x10cc61,'w')){const _0x428779=Le(_0x10cc61,'w');if(Array['isArray'](_0x428779)&&~_0x428779['indexOf']('no_index')){const _0x36836b='\x22.indexOn\x22:\x20\x22'+_0x5c39a9['_queryParams']['getIndex']()['toString']()+'\x22',_0xb89e4a=_0x5c39a9['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x36836b+'\x20at\x20'+_0xb89e4a+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2ffb01){this['authToken_']=_0x2ffb01,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2ffb01);}['reduceReconnectDelayIfAdminCredential_'](_0x2b910f){(_0x2b910f&&_0x2b910f['length']===0x28||wc(_0x2b910f))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x381c51){this['appCheckToken_']=_0x381c51,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4b29de=this['authToken_'],_0xb4a121=Ic(_0x4b29de)?'auth':'gauth',_0x444a80={'cred':_0x4b29de};this['authOverride_']===null?_0x444a80['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x444a80['authvar']=this['authOverride_']),this['sendRequest'](_0xb4a121,_0x444a80,_0x370161=>{const _0x4a3a24=_0x370161['s'],_0x13137d=_0x370161['d']||'error';this['authToken_']===_0x4b29de&&(_0x4a3a24==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x4a3a24,_0x13137d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1b4bfb=>{const _0x302a49=_0x1b4bfb['s'],_0x454aa5=_0x1b4bfb['d']||'error';_0x302a49==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x302a49,_0x454aa5);});}['unlisten'](_0x3e7045,_0x33fcf2){const _0xc4c19f=_0x3e7045['_path']['toString'](),_0x3d8321=_0x3e7045['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0xc4c19f+'\x20'+_0x3d8321),f(_0x3e7045['_queryParams']['isDefault']()||!_0x3e7045['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0xc4c19f,_0x3d8321)&&this['connected_']&&this['sendUnlisten_'](_0xc4c19f,_0x3d8321,_0x3e7045['_queryObject'],_0x33fcf2);}['sendUnlisten_'](_0x4528b9,_0x90671b,_0x202bb4,_0x44c317){this['log_']('Unlisten\x20on\x20'+_0x4528b9+'\x20for\x20'+_0x90671b);const _0x176810={'p':_0x4528b9},_0x594d69='n';_0x44c317&&(_0x176810['q']=_0x202bb4,_0x176810['t']=_0x44c317),this['sendRequest'](_0x594d69,_0x176810);}['onDisconnectPut'](_0x15086c,_0x284245,_0x1ac75a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x15086c,_0x284245,_0x1ac75a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x15086c,'action':'o','data':_0x284245,'onComplete':_0x1ac75a});}['onDisconnectMerge'](_0x2a4096,_0x2d65d7,_0x46a33d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2a4096,_0x2d65d7,_0x46a33d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2a4096,'action':'om','data':_0x2d65d7,'onComplete':_0x46a33d});}['onDisconnectCancel'](_0x3619ea,_0x13f664){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3619ea,null,_0x13f664):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3619ea,'action':'oc','data':null,'onComplete':_0x13f664});}['sendOnDisconnect_'](_0x43e59a,_0x404d99,_0x325873,_0x2d36c3){const _0x5897a8={'p':_0x404d99,'d':_0x325873};this['log_']('onDisconnect\x20'+_0x43e59a,_0x5897a8),this['sendRequest'](_0x43e59a,_0x5897a8,_0x1dda40=>{_0x2d36c3&&setTimeout(()=>{_0x2d36c3(_0x1dda40['s'],_0x1dda40['d']);},Math['floor'](0x0));});}['put'](_0x2835d9,_0x4f73e4,_0x3f8f3d,_0x40cf62){this['putInternal']('p',_0x2835d9,_0x4f73e4,_0x3f8f3d,_0x40cf62);}['merge'](_0x29c7d0,_0x5423d6,_0x3b37b4,_0x363467){this['putInternal']('m',_0x29c7d0,_0x5423d6,_0x3b37b4,_0x363467);}['putInternal'](_0x284619,_0x5277ea,_0x747faa,_0x23ce16,_0x2575e7){this['initConnection_']();const _0x519069={'p':_0x5277ea,'d':_0x747faa};_0x2575e7!==void 0x0&&(_0x519069['h']=_0x2575e7),this['outstandingPuts_']['push']({'action':_0x284619,'request':_0x519069,'onComplete':_0x23ce16}),this['outstandingPutCount_']++;const _0x2d4129=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2d4129):this['log_']('Buffering\x20put:\x20'+_0x5277ea);}['sendPut_'](_0x41e3c7){const _0x7c8826=this['outstandingPuts_'][_0x41e3c7]['action'],_0x45df86=this['outstandingPuts_'][_0x41e3c7]['request'],_0x253496=this['outstandingPuts_'][_0x41e3c7]['onComplete'];this['outstandingPuts_'][_0x41e3c7]['queued']=this['connected_'],this['sendRequest'](_0x7c8826,_0x45df86,_0x3881c4=>{this['log_'](_0x7c8826+'\x20response',_0x3881c4),delete this['outstandingPuts_'][_0x41e3c7],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x253496&&_0x253496(_0x3881c4['s'],_0x3881c4['d']);});}['reportStats'](_0x101283){if(this['connected_']){const _0x2d4e0e={'c':_0x101283};this['log_']('reportStats',_0x2d4e0e),this['sendRequest']('s',_0x2d4e0e,_0x2c079e=>{if(_0x2c079e['s']!=='ok'){const _0x5abdc2=_0x2c079e['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5abdc2);}});}}['onDataMessage_'](_0x14979a){if('r'in _0x14979a){this['log_']('from\x20server:\x20'+O(_0x14979a));const _0x57e6b6=_0x14979a['r'],_0x2e2d04=this['requestCBHash_'][_0x57e6b6];_0x2e2d04&&(delete this['requestCBHash_'][_0x57e6b6],_0x2e2d04(_0x14979a['b']));}else{if('error'in _0x14979a)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x14979a['error'];'a'in _0x14979a&&this['onDataPush_'](_0x14979a['a'],_0x14979a['b']);}}['onDataPush_'](_0x2ae985,_0x3464a0){this['log_']('handleServerMessage',_0x2ae985,_0x3464a0),_0x2ae985==='d'?this['onDataUpdate_'](_0x3464a0['p'],_0x3464a0['d'],!0x1,_0x3464a0['t']):_0x2ae985==='m'?this['onDataUpdate_'](_0x3464a0['p'],_0x3464a0['d'],!0x0,_0x3464a0['t']):_0x2ae985==='c'?this['onListenRevoked_'](_0x3464a0['p'],_0x3464a0['q']):_0x2ae985==='ac'?this['onAuthRevoked_'](_0x3464a0['s'],_0x3464a0['d']):_0x2ae985==='apc'?this['onAppCheckRevoked_'](_0x3464a0['s'],_0x3464a0['d']):_0x2ae985==='sd'?this['onSecurityDebugPacket_'](_0x3464a0):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2ae985)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3c54a2,_0x363072){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3c54a2),this['lastSessionId']=_0x363072,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2b02f1){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2b02f1));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x311b77){_0x311b77&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x311b77;}['onOnline_'](_0x59d8b5){_0x59d8b5?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2d6961=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x26dc1b=Math['max'](0x0,this['reconnectDelay_']-_0x2d6961);_0x26dc1b=Math['random']()*_0x26dc1b,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x26dc1b+'ms'),this['scheduleConnect_'](_0x26dc1b),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x218bfa=this['onDataMessage_']['bind'](this),_0x495d20=this['onReady_']['bind'](this),_0x13ba0f=this['onRealtimeDisconnect_']['bind'](this),_0x523604=this['id']+':'+se['nextConnectionId_']++,_0xc7e1c3=this['lastSessionId'];let _0x442283=!0x1,_0x8e5e8f=null;const _0x234ff5=function(){_0x8e5e8f?_0x8e5e8f['close']():(_0x442283=!0x0,_0x13ba0f());},_0x2c142d=function(_0x1cc38b){f(_0x8e5e8f,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x8e5e8f['sendRequest'](_0x1cc38b);};this['realtime_']={'close':_0x234ff5,'sendRequest':_0x2c142d};const _0x2f296c=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5db767,_0x4178b9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2f296c),this['appCheckTokenProvider_']['getToken'](_0x2f296c)]);_0x442283?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5db767&&_0x5db767['accessToken'],this['appCheckToken_']=_0x4178b9&&_0x4178b9['token'],_0x8e5e8f=new Sh(_0x523604,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x218bfa,_0x495d20,_0x13ba0f,_0x3404c4=>{U(_0x3404c4+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0xc7e1c3));}catch(_0x231c43){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x231c43),_0x442283||(this['repoInfo_']['nodeAdmin']&&U(_0x231c43),_0x234ff5());}}}['interrupt'](_0x3c9bc8){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3c9bc8),this['interruptReasons_'][_0x3c9bc8]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x24d859){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x24d859),delete this['interruptReasons_'][_0x24d859],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x4f709c){const _0x5014d7=_0x4f709c-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5014d7});}['cancelSentTransactions_'](){for(let _0x5e39d7=0x0;_0x5e39d7<this['outstandingPuts_']['length'];_0x5e39d7++){const _0x5234fc=this['outstandingPuts_'][_0x5e39d7];_0x5234fc&&'h'in _0x5234fc['request']&&_0x5234fc['queued']&&(_0x5234fc['onComplete']&&_0x5234fc['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x5e39d7],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x42a4f5,_0x13ec12){let _0x52f8fc;_0x13ec12?_0x52f8fc=_0x13ec12['map'](_0x10309f=>$i(_0x10309f))['join']('$'):_0x52f8fc='default';const _0x57e947=this['removeListen_'](_0x42a4f5,_0x52f8fc);_0x57e947&&_0x57e947['onComplete']&&_0x57e947['onComplete']('permission_denied');}['removeListen_'](_0x18bfc4,_0x4646ad){const _0x41ece8=new C(_0x18bfc4)['toString']();let _0x37b456;if(this['listens']['has'](_0x41ece8)){const _0xe983b8=this['listens']['get'](_0x41ece8);_0x37b456=_0xe983b8['get'](_0x4646ad),_0xe983b8['delete'](_0x4646ad),_0xe983b8['size']===0x0&&this['listens']['delete'](_0x41ece8);}else _0x37b456=void 0x0;return _0x37b456;}['onAuthRevoked_'](_0x1961cf,_0x526b77){L('Auth\x20token\x20revoked:\x20'+_0x1961cf+'/'+_0x526b77),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1961cf==='invalid_token'||_0x1961cf==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x59334f,_0xe0f60){L('App\x20check\x20token\x20revoked:\x20'+_0x59334f+'/'+_0xe0f60),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x59334f==='invalid_token'||_0x59334f==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x311bc3){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x311bc3):'msg'in _0x311bc3&&console['log']('FIREBASE:\x20'+_0x311bc3['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0xc197d2 of this['listens']['values']())for(const _0x278d07 of _0xc197d2['values']())this['sendListen_'](_0x278d07);for(let _0x598a2e=0x0;_0x598a2e<this['outstandingPuts_']['length'];_0x598a2e++)this['outstandingPuts_'][_0x598a2e]&&this['sendPut_'](_0x598a2e);for(;this['onDisconnectRequestQueue_']['length'];){const _0x5c46cf=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x5c46cf['action'],_0x5c46cf['pathString'],_0x5c46cf['data'],_0x5c46cf['onComplete']);}for(let _0x2c3998=0x0;_0x2c3998<this['outstandingGets_']['length'];_0x2c3998++)this['outstandingGets_'][_0x2c3998]&&this['sendGet_'](_0x2c3998);}['sendConnectStats_'](){const _0x46e954={};let _0x127e2e='js';_0x46e954['sdk.'+_0x127e2e+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x46e954['framework.cordova']=0x1:Kr()&&(_0x46e954['framework.reactnative']=0x1),this['reportStats'](_0x46e954);}['shouldReconnect_'](){const _0x1318fe=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x1318fe;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x2b2aaa,_0x50e579){this['name']=_0x2b2aaa,this['node']=_0x50e579;}static['Wrap'](_0x4daeb7,_0x587cd1){return new E(_0x4daeb7,_0x587cd1);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3e0e18,_0x471d74){const _0x1198d=new E(We,_0x3e0e18),_0xa2883a=new E(We,_0x471d74);return this['compare'](_0x1198d,_0xa2883a)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x14cfa5){sn=_0x14cfa5;}['compare'](_0x199757,_0x1e1a36){return qe(_0x199757['name'],_0x1e1a36['name']);}['isDefinedOn'](_0x56607d){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x393437,_0x523081){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x4cf439,_0x6a8b2c){return f(typeof _0x4cf439=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4cf439,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x1a142c,_0x1b1212,_0x148901,_0x430bf7,_0x35bec0=null){this['isReverse_']=_0x430bf7,this['resultGenerator_']=_0x35bec0,this['nodeStack_']=[];let _0x58bfba=0x1;for(;!_0x1a142c['isEmpty']();)if(_0x1a142c=_0x1a142c,_0x58bfba=_0x1b1212?_0x148901(_0x1a142c['key'],_0x1b1212):0x1,_0x430bf7&&(_0x58bfba*=-0x1),_0x58bfba<0x0)this['isReverse_']?_0x1a142c=_0x1a142c['left']:_0x1a142c=_0x1a142c['right'];else{if(_0x58bfba===0x0){this['nodeStack_']['push'](_0x1a142c);break;}else this['nodeStack_']['push'](_0x1a142c),this['isReverse_']?_0x1a142c=_0x1a142c['right']:_0x1a142c=_0x1a142c['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4a085d=this['nodeStack_']['pop'](),_0x59a729;if(this['resultGenerator_']?_0x59a729=this['resultGenerator_'](_0x4a085d['key'],_0x4a085d['value']):_0x59a729={'key':_0x4a085d['key'],'value':_0x4a085d['value']},this['isReverse_']){for(_0x4a085d=_0x4a085d['left'];!_0x4a085d['isEmpty']();)this['nodeStack_']['push'](_0x4a085d),_0x4a085d=_0x4a085d['right'];}else{for(_0x4a085d=_0x4a085d['right'];!_0x4a085d['isEmpty']();)this['nodeStack_']['push'](_0x4a085d),_0x4a085d=_0x4a085d['left'];}return _0x59a729;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2f3616=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2f3616['key'],_0x2f3616['value']):{'key':_0x2f3616['key'],'value':_0x2f3616['value']};}}class M{constructor(_0x3c44d3,_0x27c04b,_0x3287af,_0x439eff,_0x2cad2e){this['key']=_0x3c44d3,this['value']=_0x27c04b,this['color']=_0x3287af??M['RED'],this['left']=_0x439eff??B['EMPTY_NODE'],this['right']=_0x2cad2e??B['EMPTY_NODE'];}['copy'](_0x3c54af,_0x344899,_0x3fe842,_0x37d511,_0x49e977){return new M(_0x3c54af??this['key'],_0x344899??this['value'],_0x3fe842??this['color'],_0x37d511??this['left'],_0x49e977??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x2ab9ee){return this['left']['inorderTraversal'](_0x2ab9ee)||!!_0x2ab9ee(this['key'],this['value'])||this['right']['inorderTraversal'](_0x2ab9ee);}['reverseTraversal'](_0xba3b28){return this['right']['reverseTraversal'](_0xba3b28)||_0xba3b28(this['key'],this['value'])||this['left']['reverseTraversal'](_0xba3b28);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1c76ba,_0x398a09,_0x2afbc1){let _0x2f85d1=this;const _0x3420cd=_0x2afbc1(_0x1c76ba,_0x2f85d1['key']);return _0x3420cd<0x0?_0x2f85d1=_0x2f85d1['copy'](null,null,null,_0x2f85d1['left']['insert'](_0x1c76ba,_0x398a09,_0x2afbc1),null):_0x3420cd===0x0?_0x2f85d1=_0x2f85d1['copy'](null,_0x398a09,null,null,null):_0x2f85d1=_0x2f85d1['copy'](null,null,null,null,_0x2f85d1['right']['insert'](_0x1c76ba,_0x398a09,_0x2afbc1)),_0x2f85d1['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0xa18c30=this;return!_0xa18c30['left']['isRed_']()&&!_0xa18c30['left']['left']['isRed_']()&&(_0xa18c30=_0xa18c30['moveRedLeft_']()),_0xa18c30=_0xa18c30['copy'](null,null,null,_0xa18c30['left']['removeMin_'](),null),_0xa18c30['fixUp_']();}['remove'](_0x25131e,_0x31afeb){let _0xb61fc4,_0x272e4c;if(_0xb61fc4=this,_0x31afeb(_0x25131e,_0xb61fc4['key'])<0x0)!_0xb61fc4['left']['isEmpty']()&&!_0xb61fc4['left']['isRed_']()&&!_0xb61fc4['left']['left']['isRed_']()&&(_0xb61fc4=_0xb61fc4['moveRedLeft_']()),_0xb61fc4=_0xb61fc4['copy'](null,null,null,_0xb61fc4['left']['remove'](_0x25131e,_0x31afeb),null);else{if(_0xb61fc4['left']['isRed_']()&&(_0xb61fc4=_0xb61fc4['rotateRight_']()),!_0xb61fc4['right']['isEmpty']()&&!_0xb61fc4['right']['isRed_']()&&!_0xb61fc4['right']['left']['isRed_']()&&(_0xb61fc4=_0xb61fc4['moveRedRight_']()),_0x31afeb(_0x25131e,_0xb61fc4['key'])===0x0){if(_0xb61fc4['right']['isEmpty']())return B['EMPTY_NODE'];_0x272e4c=_0xb61fc4['right']['min_'](),_0xb61fc4=_0xb61fc4['copy'](_0x272e4c['key'],_0x272e4c['value'],null,null,_0xb61fc4['right']['removeMin_']());}_0xb61fc4=_0xb61fc4['copy'](null,null,null,null,_0xb61fc4['right']['remove'](_0x25131e,_0x31afeb));}return _0xb61fc4['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x537330=this;return _0x537330['right']['isRed_']()&&!_0x537330['left']['isRed_']()&&(_0x537330=_0x537330['rotateLeft_']()),_0x537330['left']['isRed_']()&&_0x537330['left']['left']['isRed_']()&&(_0x537330=_0x537330['rotateRight_']()),_0x537330['left']['isRed_']()&&_0x537330['right']['isRed_']()&&(_0x537330=_0x537330['colorFlip_']()),_0x537330;}['moveRedLeft_'](){let _0x4d4748=this['colorFlip_']();return _0x4d4748['right']['left']['isRed_']()&&(_0x4d4748=_0x4d4748['copy'](null,null,null,null,_0x4d4748['right']['rotateRight_']()),_0x4d4748=_0x4d4748['rotateLeft_'](),_0x4d4748=_0x4d4748['colorFlip_']()),_0x4d4748;}['moveRedRight_'](){let _0x4eca8d=this['colorFlip_']();return _0x4eca8d['left']['left']['isRed_']()&&(_0x4eca8d=_0x4eca8d['rotateRight_'](),_0x4eca8d=_0x4eca8d['colorFlip_']()),_0x4eca8d;}['rotateLeft_'](){const _0x354d6e=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x354d6e,null);}['rotateRight_'](){const _0x17a3a8=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x17a3a8);}['colorFlip_'](){const _0x2ea738=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3c215e=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2ea738,_0x3c215e);}['checkMaxDepth_'](){const _0x315e4c=this['check_']();return Math['pow'](0x2,_0x315e4c)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x5944b0=this['left']['check_']();if(_0x5944b0!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x5944b0+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x32b62c,_0x2b9465,_0xad69a6,_0x575294,_0x2fe70a){return this;}['insert'](_0x35d843,_0x140995,_0x201aa9){return new M(_0x35d843,_0x140995,null);}['remove'](_0x45e052,_0x3394f8){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5bdddd){return!0x1;}['reverseTraversal'](_0x477038){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1a267d,_0x419fb1=B['EMPTY_NODE']){this['comparator_']=_0x1a267d,this['root_']=_0x419fb1;}['insert'](_0x321ab4,_0x279226){return new B(this['comparator_'],this['root_']['insert'](_0x321ab4,_0x279226,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4f38c7){return new B(this['comparator_'],this['root_']['remove'](_0x4f38c7,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x54f587){let _0x46f11a,_0x35f941=this['root_'];for(;!_0x35f941['isEmpty']();){if(_0x46f11a=this['comparator_'](_0x54f587,_0x35f941['key']),_0x46f11a===0x0)return _0x35f941['value'];_0x46f11a<0x0?_0x35f941=_0x35f941['left']:_0x46f11a>0x0&&(_0x35f941=_0x35f941['right']);}return null;}['getPredecessorKey'](_0x1de550){let _0x704787,_0x1d6631=this['root_'],_0x523700=null;for(;!_0x1d6631['isEmpty']();)if(_0x704787=this['comparator_'](_0x1de550,_0x1d6631['key']),_0x704787===0x0){if(_0x1d6631['left']['isEmpty']())return _0x523700?_0x523700['key']:null;for(_0x1d6631=_0x1d6631['left'];!_0x1d6631['right']['isEmpty']();)_0x1d6631=_0x1d6631['right'];return _0x1d6631['key'];}else _0x704787<0x0?_0x1d6631=_0x1d6631['left']:_0x704787>0x0&&(_0x523700=_0x1d6631,_0x1d6631=_0x1d6631['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x43279d){return this['root_']['inorderTraversal'](_0x43279d);}['reverseTraversal'](_0x312f00){return this['root_']['reverseTraversal'](_0x312f00);}['getIterator'](_0x68be54){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x68be54);}['getIteratorFrom'](_0x2710d0,_0x403978){return new rn(this['root_'],_0x2710d0,this['comparator_'],!0x1,_0x403978);}['getReverseIteratorFrom'](_0x1d0d36,_0x1b1d02){return new rn(this['root_'],_0x1d0d36,this['comparator_'],!0x0,_0x1b1d02);}['getReverseIterator'](_0x203d34){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x203d34);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1b85d1,_0x2077cf){return qe(_0x1b85d1['name'],_0x2077cf['name']);}function Qi(_0x413605,_0x264c7b){return qe(_0x413605,_0x264c7b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x23455e){Ci=_0x23455e;}const Po=function(_0x1b8c2b){return typeof _0x1b8c2b=='number'?'number:'+ao(_0x1b8c2b):'string:'+_0x1b8c2b;},No=function(_0x49a577){if(_0x49a577['isLeafNode']()){const _0x57e73b=_0x49a577['val']();f(typeof _0x57e73b=='string'||typeof _0x57e73b=='number'||typeof _0x57e73b=='object'&&Q(_0x57e73b,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x49a577===Ci||_0x49a577['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x49a577===Ci||_0x49a577['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x214ae0){nr=_0x214ae0;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x218503,_0x111d7d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x218503,this['priorityNode_']=_0x111d7d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x8630e6){return new D(this['value_'],_0x8630e6);}['getImmediateChild'](_0x4ea104){return _0x4ea104==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x44c326){return v(_0x44c326)?this:y(_0x44c326)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1f8f8c,_0x549bc4){return null;}['updateImmediateChild'](_0x4b15db,_0x20389f){return _0x4b15db==='.priority'?this['updatePriority'](_0x20389f):_0x20389f['isEmpty']()&&_0x4b15db!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x4b15db,_0x20389f)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x21acf3,_0x278e5d){const _0x4ea3c5=y(_0x21acf3);return _0x4ea3c5===null?_0x278e5d:_0x278e5d['isEmpty']()&&_0x4ea3c5!=='.priority'?this:(f(_0x4ea3c5!=='.priority'||Ce(_0x21acf3)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4ea3c5,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x21acf3),_0x278e5d)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4590ac,_0x2b4eae){return!0x1;}['val'](_0x58cb2e){return _0x58cb2e&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1b4b64='';this['priorityNode_']['isEmpty']()||(_0x1b4b64+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x1dc93a=typeof this['value_'];_0x1b4b64+=_0x1dc93a+':',_0x1dc93a==='number'?_0x1b4b64+=ao(this['value_']):_0x1b4b64+=this['value_'],this['lazyHash_']=ro(_0x1b4b64);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1894ef){return _0x1894ef===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1894ef instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1894ef['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1894ef));}['compareToLeafNode_'](_0x31a9bb){const _0x1750b6=typeof _0x31a9bb['value_'],_0x49b83d=typeof this['value_'],_0x3f934d=D['VALUE_TYPE_ORDER']['indexOf'](_0x1750b6),_0x66f452=D['VALUE_TYPE_ORDER']['indexOf'](_0x49b83d);return f(_0x3f934d>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1750b6),f(_0x66f452>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x49b83d),_0x3f934d===_0x66f452?_0x49b83d==='object'?0x0:this['value_']<_0x31a9bb['value_']?-0x1:this['value_']===_0x31a9bb['value_']?0x0:0x1:_0x66f452-_0x3f934d;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4d7b3c){if(_0x4d7b3c===this)return!0x0;if(_0x4d7b3c['isLeafNode']()){const _0x4c5c1d=_0x4d7b3c;return this['value_']===_0x4c5c1d['value_']&&this['priorityNode_']['equals'](_0x4c5c1d['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x1dda94){Oo=_0x1dda94;}function Wh(_0x27626a){Do=_0x27626a;}class Bh extends Fn{['compare'](_0x559bce,_0x1fed3d){const _0x4af171=_0x559bce['node']['getPriority'](),_0x1ad7ea=_0x1fed3d['node']['getPriority'](),_0x38b9a3=_0x4af171['compareTo'](_0x1ad7ea);return _0x38b9a3===0x0?qe(_0x559bce['name'],_0x1fed3d['name']):_0x38b9a3;}['isDefinedOn'](_0x4a2da4){return!_0x4a2da4['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3d7177,_0x3e7fb1){return!_0x3d7177['getPriority']()['equals'](_0x3e7fb1['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0xc7386a,_0x168c51){const _0xddeefb=Oo(_0xc7386a);return new E(_0x168c51,new D('[PRIORITY-POST]',_0xddeefb));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x5ea3ef){const _0x3c398a=_0x2ca0cc=>parseInt(Math['log'](_0x2ca0cc)/Vh,0xa),_0x5bd41f=_0x49b6ae=>parseInt(Array(_0x49b6ae+0x1)['join']('1'),0x2);this['count']=_0x3c398a(_0x5ea3ef+0x1),this['current_']=this['count']-0x1;const _0x3f985c=_0x5bd41f(this['count']);this['bits_']=_0x5ea3ef+0x1&_0x3f985c;}['nextBitIsOne'](){const _0x4df7f8=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4df7f8;}}const yn=function(_0x124393,_0x48024d,_0x12d341,_0x333983){_0x124393['sort'](_0x48024d);const _0x32ede1=function(_0x100bf6,_0x5554bf){const _0x3d7207=_0x5554bf-_0x100bf6;let _0x2feb2d,_0x396a16;if(_0x3d7207===0x0)return null;if(_0x3d7207===0x1)return _0x2feb2d=_0x124393[_0x100bf6],_0x396a16=_0x12d341?_0x12d341(_0x2feb2d):_0x2feb2d,new M(_0x396a16,_0x2feb2d['node'],M['BLACK'],null,null);{const _0x25771c=parseInt(_0x3d7207/0x2,0xa)+_0x100bf6,_0x40afa9=_0x32ede1(_0x100bf6,_0x25771c),_0x33179c=_0x32ede1(_0x25771c+0x1,_0x5554bf);return _0x2feb2d=_0x124393[_0x25771c],_0x396a16=_0x12d341?_0x12d341(_0x2feb2d):_0x2feb2d,new M(_0x396a16,_0x2feb2d['node'],M['BLACK'],_0x40afa9,_0x33179c);}},_0x363ab8=function(_0x359de5){let _0x5c6177=null,_0x53c290=null,_0x1ac3e0=_0x124393['length'];const _0x442a2a=function(_0xb0609d,_0x53e63b){const _0x2214e7=_0x1ac3e0-_0xb0609d,_0x1468de=_0x1ac3e0;_0x1ac3e0-=_0xb0609d;const _0x3bb402=_0x32ede1(_0x2214e7+0x1,_0x1468de),_0x5883d1=_0x124393[_0x2214e7],_0x258190=_0x12d341?_0x12d341(_0x5883d1):_0x5883d1;_0x5b9ef0(new M(_0x258190,_0x5883d1['node'],_0x53e63b,null,_0x3bb402));},_0x5b9ef0=function(_0x3c3e73){_0x5c6177?(_0x5c6177['left']=_0x3c3e73,_0x5c6177=_0x3c3e73):(_0x53c290=_0x3c3e73,_0x5c6177=_0x3c3e73);};for(let _0x389e65=0x0;_0x389e65<_0x359de5['count'];++_0x389e65){const _0x3d5e5b=_0x359de5['nextBitIsOne'](),_0x2b09d4=Math['pow'](0x2,_0x359de5['count']-(_0x389e65+0x1));_0x3d5e5b?_0x442a2a(_0x2b09d4,M['BLACK']):(_0x442a2a(_0x2b09d4,M['BLACK']),_0x442a2a(_0x2b09d4,M['RED']));}return _0x53c290;},_0xa4f3bd=new Hh(_0x124393['length']),_0x2949f9=_0x363ab8(_0xa4f3bd);return new B(_0x333983||_0x48024d,_0x2949f9);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0xb70179,_0x2b7a58){this['indexes_']=_0xb70179,this['indexSet_']=_0x2b7a58;}['get'](_0x50aad4){const _0x2a05ca=Le(this['indexes_'],_0x50aad4);if(!_0x2a05ca)throw new Error('No\x20index\x20defined\x20for\x20'+_0x50aad4);return _0x2a05ca instanceof B?_0x2a05ca:null;}['hasIndex'](_0x5b1024){return Q(this['indexSet_'],_0x5b1024['toString']());}['addIndex'](_0x523ca8,_0x516b9e){f(_0x523ca8!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x15dff0=[];let _0x429fe5=!0x1;const _0xdbe8f9=_0x516b9e['getIterator'](E['Wrap']);let _0x3ae66f=_0xdbe8f9['getNext']();for(;_0x3ae66f;)_0x429fe5=_0x429fe5||_0x523ca8['isDefinedOn'](_0x3ae66f['node']),_0x15dff0['push'](_0x3ae66f),_0x3ae66f=_0xdbe8f9['getNext']();let _0x27c63d;_0x429fe5?_0x27c63d=yn(_0x15dff0,_0x523ca8['getCompare']()):_0x27c63d=Qe;const _0x5e4ed0=_0x523ca8['toString'](),_0x168d53={...this['indexSet_']};_0x168d53[_0x5e4ed0]=_0x523ca8;const _0x21ad5e={...this['indexes_']};return _0x21ad5e[_0x5e4ed0]=_0x27c63d,new te(_0x21ad5e,_0x168d53);}['addToIndexes'](_0x357e9a,_0x25fbf6){const _0x5a6716=_n(this['indexes_'],(_0x2a6fcf,_0x4ae3cb)=>{const _0x422d4d=Le(this['indexSet_'],_0x4ae3cb);if(f(_0x422d4d,'Missing\x20index\x20implementation\x20for\x20'+_0x4ae3cb),_0x2a6fcf===Qe){if(_0x422d4d['isDefinedOn'](_0x357e9a['node'])){const _0x2ad01e=[],_0x23d382=_0x25fbf6['getIterator'](E['Wrap']);let _0x44da36=_0x23d382['getNext']();for(;_0x44da36;)_0x44da36['name']!==_0x357e9a['name']&&_0x2ad01e['push'](_0x44da36),_0x44da36=_0x23d382['getNext']();return _0x2ad01e['push'](_0x357e9a),yn(_0x2ad01e,_0x422d4d['getCompare']());}else return Qe;}else{const _0x39df23=_0x25fbf6['get'](_0x357e9a['name']);let _0x487af7=_0x2a6fcf;return _0x39df23&&(_0x487af7=_0x487af7['remove'](new E(_0x357e9a['name'],_0x39df23))),_0x487af7['insert'](_0x357e9a,_0x357e9a['node']);}});return new te(_0x5a6716,this['indexSet_']);}['removeFromIndexes'](_0x1aa7bc,_0x56ec27){const _0x2add04=_n(this['indexes_'],_0x2c043d=>{if(_0x2c043d===Qe)return _0x2c043d;{const _0x2ee03c=_0x56ec27['get'](_0x1aa7bc['name']);return _0x2ee03c?_0x2c043d['remove'](new E(_0x1aa7bc['name'],_0x2ee03c)):_0x2c043d;}});return new te(_0x2add04,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x5d4a31,_0x4cdad8,_0xa9cb90){this['children_']=_0x5d4a31,this['priorityNode_']=_0x4cdad8,this['indexMap_']=_0xa9cb90,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x51a9d7){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x51a9d7,this['indexMap_']);}['getImmediateChild'](_0x380fee){if(_0x380fee==='.priority')return this['getPriority']();{const _0x536fb6=this['children_']['get'](_0x380fee);return _0x536fb6===null?It:_0x536fb6;}}['getChild'](_0x576451){const _0x68b9e9=y(_0x576451);return _0x68b9e9===null?this:this['getImmediateChild'](_0x68b9e9)['getChild'](S(_0x576451));}['hasChild'](_0x7d51a8){return this['children_']['get'](_0x7d51a8)!==null;}['updateImmediateChild'](_0x1b3f04,_0x26c1a4){if(f(_0x26c1a4,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1b3f04==='.priority')return this['updatePriority'](_0x26c1a4);{const _0x7f663=new E(_0x1b3f04,_0x26c1a4);let _0x44684c,_0x2927e7;_0x26c1a4['isEmpty']()?(_0x44684c=this['children_']['remove'](_0x1b3f04),_0x2927e7=this['indexMap_']['removeFromIndexes'](_0x7f663,this['children_'])):(_0x44684c=this['children_']['insert'](_0x1b3f04,_0x26c1a4),_0x2927e7=this['indexMap_']['addToIndexes'](_0x7f663,this['children_']));const _0x48616b=_0x44684c['isEmpty']()?It:this['priorityNode_'];return new g(_0x44684c,_0x48616b,_0x2927e7);}}['updateChild'](_0x159bbc,_0x4de636){const _0x340998=y(_0x159bbc);if(_0x340998===null)return _0x4de636;{f(y(_0x159bbc)!=='.priority'||Ce(_0x159bbc)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x264578=this['getImmediateChild'](_0x340998)['updateChild'](S(_0x159bbc),_0x4de636);return this['updateImmediateChild'](_0x340998,_0x264578);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x243971){if(this['isEmpty']())return null;const _0x3d84fc={};let _0x2bc05=0x0,_0x22fb4b=0x0,_0x13044=!0x0;if(this['forEachChild'](R,(_0x57b50a,_0x2e0447)=>{_0x3d84fc[_0x57b50a]=_0x2e0447['val'](_0x243971),_0x2bc05++,_0x13044&&g['INTEGER_REGEXP_']['test'](_0x57b50a)?_0x22fb4b=Math['max'](_0x22fb4b,Number(_0x57b50a)):_0x13044=!0x1;}),!_0x243971&&_0x13044&&_0x22fb4b<0x2*_0x2bc05){const _0x1b5bb0=[];for(const _0x686f2c in _0x3d84fc)_0x1b5bb0[_0x686f2c]=_0x3d84fc[_0x686f2c];return _0x1b5bb0;}else return _0x243971&&!this['getPriority']()['isEmpty']()&&(_0x3d84fc['.priority']=this['getPriority']()['val']()),_0x3d84fc;}['hash'](){if(this['lazyHash_']===null){let _0x265fc2='';this['getPriority']()['isEmpty']()||(_0x265fc2+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x46b777,_0x3713d2)=>{const _0x127704=_0x3713d2['hash']();_0x127704!==''&&(_0x265fc2+=':'+_0x46b777+':'+_0x127704);}),this['lazyHash_']=_0x265fc2===''?'':ro(_0x265fc2);}return this['lazyHash_'];}['getPredecessorChildName'](_0x2b2540,_0xd378e2,_0x4b165d){const _0x16901c=this['resolveIndex_'](_0x4b165d);if(_0x16901c){const _0x401544=_0x16901c['getPredecessorKey'](new E(_0x2b2540,_0xd378e2));return _0x401544?_0x401544['name']:null;}else return this['children_']['getPredecessorKey'](_0x2b2540);}['getFirstChildName'](_0x451780){const _0x17fd57=this['resolveIndex_'](_0x451780);if(_0x17fd57){const _0x2ef607=_0x17fd57['minKey']();return _0x2ef607&&_0x2ef607['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x22327a){const _0x54285f=this['getFirstChildName'](_0x22327a);return _0x54285f?new E(_0x54285f,this['children_']['get'](_0x54285f)):null;}['getLastChildName'](_0x3a8ace){const _0x47ce02=this['resolveIndex_'](_0x3a8ace);if(_0x47ce02){const _0x507b18=_0x47ce02['maxKey']();return _0x507b18&&_0x507b18['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x17884d){const _0x1f66eb=this['getLastChildName'](_0x17884d);return _0x1f66eb?new E(_0x1f66eb,this['children_']['get'](_0x1f66eb)):null;}['forEachChild'](_0x395be1,_0x3e9dae){const _0x3fd208=this['resolveIndex_'](_0x395be1);return _0x3fd208?_0x3fd208['inorderTraversal'](_0x519267=>_0x3e9dae(_0x519267['name'],_0x519267['node'])):this['children_']['inorderTraversal'](_0x3e9dae);}['getIterator'](_0x385c2c){return this['getIteratorFrom'](_0x385c2c['minPost'](),_0x385c2c);}['getIteratorFrom'](_0x553ea2,_0x4d711d){const _0x5b0547=this['resolveIndex_'](_0x4d711d);if(_0x5b0547)return _0x5b0547['getIteratorFrom'](_0x553ea2,_0x445ddb=>_0x445ddb);{const _0x28b2af=this['children_']['getIteratorFrom'](_0x553ea2['name'],E['Wrap']);let _0x434f3d=_0x28b2af['peek']();for(;_0x434f3d!=null&&_0x4d711d['compare'](_0x434f3d,_0x553ea2)<0x0;)_0x28b2af['getNext'](),_0x434f3d=_0x28b2af['peek']();return _0x28b2af;}}['getReverseIterator'](_0x4cddde){return this['getReverseIteratorFrom'](_0x4cddde['maxPost'](),_0x4cddde);}['getReverseIteratorFrom'](_0x32517f,_0x238186){const _0x5746eb=this['resolveIndex_'](_0x238186);if(_0x5746eb)return _0x5746eb['getReverseIteratorFrom'](_0x32517f,_0x58fb2a=>_0x58fb2a);{const _0x22605c=this['children_']['getReverseIteratorFrom'](_0x32517f['name'],E['Wrap']);let _0x424ff3=_0x22605c['peek']();for(;_0x424ff3!=null&&_0x238186['compare'](_0x424ff3,_0x32517f)>0x0;)_0x22605c['getNext'](),_0x424ff3=_0x22605c['peek']();return _0x22605c;}}['compareTo'](_0x34ea91){return this['isEmpty']()?_0x34ea91['isEmpty']()?0x0:-0x1:_0x34ea91['isLeafNode']()||_0x34ea91['isEmpty']()?0x1:_0x34ea91===Kt?-0x1:0x0;}['withIndex'](_0x161385){if(_0x161385===ve||this['indexMap_']['hasIndex'](_0x161385))return this;{const _0xeffe2a=this['indexMap_']['addIndex'](_0x161385,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xeffe2a);}}['isIndexed'](_0x445dde){return _0x445dde===ve||this['indexMap_']['hasIndex'](_0x445dde);}['equals'](_0x5e82ba){if(_0x5e82ba===this)return!0x0;if(_0x5e82ba['isLeafNode']())return!0x1;{const _0x2b63e3=_0x5e82ba;if(this['getPriority']()['equals'](_0x2b63e3['getPriority']())){if(this['children_']['count']()===_0x2b63e3['children_']['count']()){const _0x40e251=this['getIterator'](R),_0x3ae766=_0x2b63e3['getIterator'](R);let _0x4e3afa=_0x40e251['getNext'](),_0x17c49e=_0x3ae766['getNext']();for(;_0x4e3afa&&_0x17c49e;){if(_0x4e3afa['name']!==_0x17c49e['name']||!_0x4e3afa['node']['equals'](_0x17c49e['node']))return!0x1;_0x4e3afa=_0x40e251['getNext'](),_0x17c49e=_0x3ae766['getNext']();}return _0x4e3afa===null&&_0x17c49e===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x30653d){return _0x30653d===ve?null:this['indexMap_']['get'](_0x30653d['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x311cd0){return _0x311cd0===this?0x0:0x1;}['equals'](_0x550956){return _0x550956===this;}['getPriority'](){return this;}['getImmediateChild'](_0x44bf1a){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x36cd9f,_0x42ca12=null){if(_0x36cd9f===null)return g['EMPTY_NODE'];if(typeof _0x36cd9f=='object'&&'.priority'in _0x36cd9f&&(_0x42ca12=_0x36cd9f['.priority']),f(_0x42ca12===null||typeof _0x42ca12=='string'||typeof _0x42ca12=='number'||typeof _0x42ca12=='object'&&'.sv'in _0x42ca12,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x42ca12),typeof _0x36cd9f=='object'&&'.value'in _0x36cd9f&&_0x36cd9f['.value']!==null&&(_0x36cd9f=_0x36cd9f['.value']),typeof _0x36cd9f!='object'||'.sv'in _0x36cd9f){const _0x21da27=_0x36cd9f;return new D(_0x21da27,A(_0x42ca12));}if(!(_0x36cd9f instanceof Array)&&Gh){const _0x510ccd=[];let _0x4226ba=!0x1;if(x(_0x36cd9f,(_0x3e4190,_0x2ac977)=>{if(_0x3e4190['substring'](0x0,0x1)!=='.'){const _0x122137=A(_0x2ac977);_0x122137['isEmpty']()||(_0x4226ba=_0x4226ba||!_0x122137['getPriority']()['isEmpty'](),_0x510ccd['push'](new E(_0x3e4190,_0x122137)));}}),_0x510ccd['length']===0x0)return g['EMPTY_NODE'];const _0x770809=yn(_0x510ccd,xh,_0x5c3388=>_0x5c3388['name'],Qi);if(_0x4226ba){const _0x4e1ef7=yn(_0x510ccd,R['getCompare']());return new g(_0x770809,A(_0x42ca12),new te({'.priority':_0x4e1ef7},{'.priority':R}));}else return new g(_0x770809,A(_0x42ca12),te['Default']);}else{let _0x28362a=g['EMPTY_NODE'];return x(_0x36cd9f,(_0x38527f,_0x17b331)=>{if(Q(_0x36cd9f,_0x38527f)&&_0x38527f['substring'](0x0,0x1)!=='.'){const _0x2f34b6=A(_0x17b331);(_0x2f34b6['isLeafNode']()||!_0x2f34b6['isEmpty']())&&(_0x28362a=_0x28362a['updateImmediateChild'](_0x38527f,_0x2f34b6));}}),_0x28362a['updatePriority'](A(_0x42ca12));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x18e865){super(),this['indexPath_']=_0x18e865,f(!v(_0x18e865)&&y(_0x18e865)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x4ce1d4){return _0x4ce1d4['getChild'](this['indexPath_']);}['isDefinedOn'](_0x32bac6){return!_0x32bac6['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3de911,_0x348707){const _0x592eea=this['extractChild'](_0x3de911['node']),_0x5e4eff=this['extractChild'](_0x348707['node']),_0x1ce40a=_0x592eea['compareTo'](_0x5e4eff);return _0x1ce40a===0x0?qe(_0x3de911['name'],_0x348707['name']):_0x1ce40a;}['makePost'](_0x1ec9ca,_0x3712fa){const _0x3cf216=A(_0x1ec9ca),_0x51aa35=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x3cf216);return new E(_0x3712fa,_0x51aa35);}['maxPost'](){const _0x242340=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x242340);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0xa6f171,_0x429f71){const _0x2b2bcf=_0xa6f171['node']['compareTo'](_0x429f71['node']);return _0x2b2bcf===0x0?qe(_0xa6f171['name'],_0x429f71['name']):_0x2b2bcf;}['isDefinedOn'](_0x287456){return!0x0;}['indexedValueChanged'](_0x1628f9,_0x1c79c5){return!_0x1628f9['equals'](_0x1c79c5);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1e80dd,_0x19366c){const _0x1cc9b2=A(_0x1e80dd);return new E(_0x19366c,_0x1cc9b2);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x52c6f8){return{'type':'value','snapshotNode':_0x52c6f8};}function rt(_0x4db0ca,_0x1f9a6f){return{'type':'child_added','snapshotNode':_0x1f9a6f,'childName':_0x4db0ca};}function Lt(_0x3c7765,_0x57524e){return{'type':'child_removed','snapshotNode':_0x57524e,'childName':_0x3c7765};}function xt(_0x53cd30,_0x3127df,_0x1107eb){return{'type':'child_changed','snapshotNode':_0x3127df,'childName':_0x53cd30,'oldSnap':_0x1107eb};}function zh(_0x42acf1,_0x2b3544){return{'type':'child_moved','snapshotNode':_0x2b3544,'childName':_0x42acf1};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x3803c9){this['index_']=_0x3803c9;}['updateChild'](_0x528f75,_0x26fbdc,_0x2fc7fd,_0x39f851,_0x29166d,_0x38f8c4){f(_0x528f75['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x189ff4=_0x528f75['getImmediateChild'](_0x26fbdc);return _0x189ff4['getChild'](_0x39f851)['equals'](_0x2fc7fd['getChild'](_0x39f851))&&_0x189ff4['isEmpty']()===_0x2fc7fd['isEmpty']()||(_0x38f8c4!=null&&(_0x2fc7fd['isEmpty']()?_0x528f75['hasChild'](_0x26fbdc)?_0x38f8c4['trackChildChange'](Lt(_0x26fbdc,_0x189ff4)):f(_0x528f75['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x189ff4['isEmpty']()?_0x38f8c4['trackChildChange'](rt(_0x26fbdc,_0x2fc7fd)):_0x38f8c4['trackChildChange'](xt(_0x26fbdc,_0x2fc7fd,_0x189ff4))),_0x528f75['isLeafNode']()&&_0x2fc7fd['isEmpty']())?_0x528f75:_0x528f75['updateImmediateChild'](_0x26fbdc,_0x2fc7fd)['withIndex'](this['index_']);}['updateFullNode'](_0x1a4575,_0x4e8444,_0x427eb8){return _0x427eb8!=null&&(_0x1a4575['isLeafNode']()||_0x1a4575['forEachChild'](R,(_0xb2b754,_0x2d2118)=>{_0x4e8444['hasChild'](_0xb2b754)||_0x427eb8['trackChildChange'](Lt(_0xb2b754,_0x2d2118));}),_0x4e8444['isLeafNode']()||_0x4e8444['forEachChild'](R,(_0x3e8040,_0x2d7bcd)=>{if(_0x1a4575['hasChild'](_0x3e8040)){const _0x933e1b=_0x1a4575['getImmediateChild'](_0x3e8040);_0x933e1b['equals'](_0x2d7bcd)||_0x427eb8['trackChildChange'](xt(_0x3e8040,_0x2d7bcd,_0x933e1b));}else _0x427eb8['trackChildChange'](rt(_0x3e8040,_0x2d7bcd));})),_0x4e8444['withIndex'](this['index_']);}['updatePriority'](_0x216c5b,_0x25c34f){return _0x216c5b['isEmpty']()?g['EMPTY_NODE']:_0x216c5b['updatePriority'](_0x25c34f);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x427209){this['indexedFilter_']=new Xi(_0x427209['getIndex']()),this['index_']=_0x427209['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x427209),this['endPost_']=Ft['getEndPost_'](_0x427209),this['startIsInclusive_']=!_0x427209['startAfterSet_'],this['endIsInclusive_']=!_0x427209['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x261190){const _0x28f36a=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x261190)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x261190)<0x0,_0x5a92df=this['endIsInclusive_']?this['index_']['compare'](_0x261190,this['getEndPost']())<=0x0:this['index_']['compare'](_0x261190,this['getEndPost']())<0x0;return _0x28f36a&&_0x5a92df;}['updateChild'](_0x11654b,_0x4bcbd5,_0xdf374e,_0x41337c,_0x40c53c,_0x39abf2){return this['matches'](new E(_0x4bcbd5,_0xdf374e))||(_0xdf374e=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x11654b,_0x4bcbd5,_0xdf374e,_0x41337c,_0x40c53c,_0x39abf2);}['updateFullNode'](_0x375de3,_0x1d60e5,_0x57c761){_0x1d60e5['isLeafNode']()&&(_0x1d60e5=g['EMPTY_NODE']);let _0xf7d354=_0x1d60e5['withIndex'](this['index_']);_0xf7d354=_0xf7d354['updatePriority'](g['EMPTY_NODE']);const _0x256058=this;return _0x1d60e5['forEachChild'](R,(_0x4320c1,_0x2f8bd3)=>{_0x256058['matches'](new E(_0x4320c1,_0x2f8bd3))||(_0xf7d354=_0xf7d354['updateImmediateChild'](_0x4320c1,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x375de3,_0xf7d354,_0x57c761);}['updatePriority'](_0x4ccb1c,_0x26f4c3){return _0x4ccb1c;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3c9151){if(_0x3c9151['hasStart']()){const _0x433d69=_0x3c9151['getIndexStartName']();return _0x3c9151['getIndex']()['makePost'](_0x3c9151['getIndexStartValue'](),_0x433d69);}else return _0x3c9151['getIndex']()['minPost']();}static['getEndPost_'](_0x4e2807){if(_0x4e2807['hasEnd']()){const _0x4888f7=_0x4e2807['getIndexEndName']();return _0x4e2807['getIndex']()['makePost'](_0x4e2807['getIndexEndValue'](),_0x4888f7);}else return _0x4e2807['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x34ae75){this['withinDirectionalStart']=_0x5244e6=>this['reverse_']?this['withinEndPost'](_0x5244e6):this['withinStartPost'](_0x5244e6),this['withinDirectionalEnd']=_0x274085=>this['reverse_']?this['withinStartPost'](_0x274085):this['withinEndPost'](_0x274085),this['withinStartPost']=_0x589fc1=>{const _0xff68dd=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x589fc1);return this['startIsInclusive_']?_0xff68dd<=0x0:_0xff68dd<0x0;},this['withinEndPost']=_0x1c4276=>{const _0x2d1442=this['index_']['compare'](_0x1c4276,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2d1442<=0x0:_0x2d1442<0x0;},this['rangedFilter_']=new Ft(_0x34ae75),this['index_']=_0x34ae75['getIndex'](),this['limit_']=_0x34ae75['getLimit'](),this['reverse_']=!_0x34ae75['isViewFromLeft'](),this['startIsInclusive_']=!_0x34ae75['startAfterSet_'],this['endIsInclusive_']=!_0x34ae75['endBeforeSet_'];}['updateChild'](_0x1838aa,_0x1ce892,_0x4ffcd2,_0x115b02,_0x304dd9,_0x264d97){return this['rangedFilter_']['matches'](new E(_0x1ce892,_0x4ffcd2))||(_0x4ffcd2=g['EMPTY_NODE']),_0x1838aa['getImmediateChild'](_0x1ce892)['equals'](_0x4ffcd2)?_0x1838aa:_0x1838aa['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1838aa,_0x1ce892,_0x4ffcd2,_0x115b02,_0x304dd9,_0x264d97):this['fullLimitUpdateChild_'](_0x1838aa,_0x1ce892,_0x4ffcd2,_0x304dd9,_0x264d97);}['updateFullNode'](_0x2eb48c,_0x4e1404,_0x2d43ae){let _0x5578a7;if(_0x4e1404['isLeafNode']()||_0x4e1404['isEmpty']())_0x5578a7=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x4e1404['numChildren']()&&_0x4e1404['isIndexed'](this['index_'])){_0x5578a7=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x43a3ba;this['reverse_']?_0x43a3ba=_0x4e1404['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x43a3ba=_0x4e1404['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x47f269=0x0;for(;_0x43a3ba['hasNext']()&&_0x47f269<this['limit_'];){const _0x7f723=_0x43a3ba['getNext']();if(this['withinDirectionalStart'](_0x7f723)){if(this['withinDirectionalEnd'](_0x7f723))_0x5578a7=_0x5578a7['updateImmediateChild'](_0x7f723['name'],_0x7f723['node']),_0x47f269++;else break;}else continue;}}else{_0x5578a7=_0x4e1404['withIndex'](this['index_']),_0x5578a7=_0x5578a7['updatePriority'](g['EMPTY_NODE']);let _0x25e223;this['reverse_']?_0x25e223=_0x5578a7['getReverseIterator'](this['index_']):_0x25e223=_0x5578a7['getIterator'](this['index_']);let _0x5df67b=0x0;for(;_0x25e223['hasNext']();){const _0x37ae89=_0x25e223['getNext']();_0x5df67b<this['limit_']&&this['withinDirectionalStart'](_0x37ae89)&&this['withinDirectionalEnd'](_0x37ae89)?_0x5df67b++:_0x5578a7=_0x5578a7['updateImmediateChild'](_0x37ae89['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2eb48c,_0x5578a7,_0x2d43ae);}['updatePriority'](_0x99d6b5,_0x37b11f){return _0x99d6b5;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3b7083,_0x145d08,_0x46dd50,_0x32d1db,_0x2ce06b){let _0x52404a;if(this['reverse_']){const _0x1c0b8a=this['index_']['getCompare']();_0x52404a=(_0xe1d539,_0x31898c)=>_0x1c0b8a(_0x31898c,_0xe1d539);}else _0x52404a=this['index_']['getCompare']();const _0x1c6db6=_0x3b7083;f(_0x1c6db6['numChildren']()===this['limit_'],'');const _0x53f333=new E(_0x145d08,_0x46dd50),_0x580741=this['reverse_']?_0x1c6db6['getFirstChild'](this['index_']):_0x1c6db6['getLastChild'](this['index_']),_0x44cdf5=this['rangedFilter_']['matches'](_0x53f333);if(_0x1c6db6['hasChild'](_0x145d08)){const _0x27c591=_0x1c6db6['getImmediateChild'](_0x145d08);let _0x351a88=_0x32d1db['getChildAfterChild'](this['index_'],_0x580741,this['reverse_']);for(;_0x351a88!=null&&(_0x351a88['name']===_0x145d08||_0x1c6db6['hasChild'](_0x351a88['name']));)_0x351a88=_0x32d1db['getChildAfterChild'](this['index_'],_0x351a88,this['reverse_']);const _0x5c5ea6=_0x351a88==null?0x1:_0x52404a(_0x351a88,_0x53f333);if(_0x44cdf5&&!_0x46dd50['isEmpty']()&&_0x5c5ea6>=0x0)return _0x2ce06b!=null&&_0x2ce06b['trackChildChange'](xt(_0x145d08,_0x46dd50,_0x27c591)),_0x1c6db6['updateImmediateChild'](_0x145d08,_0x46dd50);{_0x2ce06b!=null&&_0x2ce06b['trackChildChange'](Lt(_0x145d08,_0x27c591));const _0x1a9c6c=_0x1c6db6['updateImmediateChild'](_0x145d08,g['EMPTY_NODE']);return _0x351a88!=null&&this['rangedFilter_']['matches'](_0x351a88)?(_0x2ce06b!=null&&_0x2ce06b['trackChildChange'](rt(_0x351a88['name'],_0x351a88['node'])),_0x1a9c6c['updateImmediateChild'](_0x351a88['name'],_0x351a88['node'])):_0x1a9c6c;}}else return _0x46dd50['isEmpty']()?_0x3b7083:_0x44cdf5&&_0x52404a(_0x580741,_0x53f333)>=0x0?(_0x2ce06b!=null&&(_0x2ce06b['trackChildChange'](Lt(_0x580741['name'],_0x580741['node'])),_0x2ce06b['trackChildChange'](rt(_0x145d08,_0x46dd50))),_0x1c6db6['updateImmediateChild'](_0x145d08,_0x46dd50)['updateImmediateChild'](_0x580741['name'],g['EMPTY_NODE'])):_0x3b7083;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x2a9c8e=new Zi();return _0x2a9c8e['limitSet_']=this['limitSet_'],_0x2a9c8e['limit_']=this['limit_'],_0x2a9c8e['startSet_']=this['startSet_'],_0x2a9c8e['startAfterSet_']=this['startAfterSet_'],_0x2a9c8e['indexStartValue_']=this['indexStartValue_'],_0x2a9c8e['startNameSet_']=this['startNameSet_'],_0x2a9c8e['indexStartName_']=this['indexStartName_'],_0x2a9c8e['endSet_']=this['endSet_'],_0x2a9c8e['endBeforeSet_']=this['endBeforeSet_'],_0x2a9c8e['indexEndValue_']=this['indexEndValue_'],_0x2a9c8e['endNameSet_']=this['endNameSet_'],_0x2a9c8e['indexEndName_']=this['indexEndName_'],_0x2a9c8e['index_']=this['index_'],_0x2a9c8e['viewFrom_']=this['viewFrom_'],_0x2a9c8e;}}function Kh(_0x27e55d){return _0x27e55d['loadsAllData']()?new Xi(_0x27e55d['getIndex']()):_0x27e55d['hasLimit']()?new jh(_0x27e55d):new Ft(_0x27e55d);}function Yh(_0x59adc0,_0x1d1f64){const _0x5aecdc=_0x59adc0['copy']();return _0x5aecdc['limitSet_']=!0x0,_0x5aecdc['limit_']=_0x1d1f64,_0x5aecdc['viewFrom_']='l',_0x5aecdc;}function Qh(_0x1161f5,_0x7c2d1a,_0x7d4926){const _0x5ebf63=_0x1161f5['copy']();return _0x5ebf63['startSet_']=!0x0,_0x7c2d1a===void 0x0&&(_0x7c2d1a=null),_0x5ebf63['indexStartValue_']=_0x7c2d1a,_0x7d4926!=null?(_0x5ebf63['startNameSet_']=!0x0,_0x5ebf63['indexStartName_']=_0x7d4926):(_0x5ebf63['startNameSet_']=!0x1,_0x5ebf63['indexStartName_']=''),_0x5ebf63;}function Jh(_0x3155ce,_0x1c7f6f,_0x707717){const _0x1e22df=_0x3155ce['copy']();return _0x1e22df['endSet_']=!0x0,_0x1c7f6f===void 0x0&&(_0x1c7f6f=null),_0x1e22df['indexEndValue_']=_0x1c7f6f,_0x707717!==void 0x0?(_0x1e22df['endNameSet_']=!0x0,_0x1e22df['indexEndName_']=_0x707717):(_0x1e22df['endNameSet_']=!0x1,_0x1e22df['indexEndName_']=''),_0x1e22df;}function xo(_0x1718a6,_0x5872ff){const _0x3e2dba=_0x1718a6['copy']();return _0x3e2dba['index_']=_0x5872ff,_0x3e2dba;}function ir(_0x38ce5a){const _0xdf0cb3={};if(_0x38ce5a['isDefault']())return _0xdf0cb3;let _0x1b2db7;if(_0x38ce5a['index_']===R?_0x1b2db7='$priority':_0x38ce5a['index_']===Mo?_0x1b2db7='$value':_0x38ce5a['index_']===ve?_0x1b2db7='$key':(f(_0x38ce5a['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x1b2db7=_0x38ce5a['index_']['toString']()),_0xdf0cb3['orderBy']=O(_0x1b2db7),_0x38ce5a['startSet_']){const _0x3c2eed=_0x38ce5a['startAfterSet_']?'startAfter':'startAt';_0xdf0cb3[_0x3c2eed]=O(_0x38ce5a['indexStartValue_']),_0x38ce5a['startNameSet_']&&(_0xdf0cb3[_0x3c2eed]+=','+O(_0x38ce5a['indexStartName_']));}if(_0x38ce5a['endSet_']){const _0x3cf0ee=_0x38ce5a['endBeforeSet_']?'endBefore':'endAt';_0xdf0cb3[_0x3cf0ee]=O(_0x38ce5a['indexEndValue_']),_0x38ce5a['endNameSet_']&&(_0xdf0cb3[_0x3cf0ee]+=','+O(_0x38ce5a['indexEndName_']));}return _0x38ce5a['limitSet_']&&(_0x38ce5a['isViewFromLeft']()?_0xdf0cb3['limitToFirst']=_0x38ce5a['limit_']:_0xdf0cb3['limitToLast']=_0x38ce5a['limit_']),_0xdf0cb3;}function sr(_0x5cdd51){const _0x19a8df={};if(_0x5cdd51['startSet_']&&(_0x19a8df['sp']=_0x5cdd51['indexStartValue_'],_0x5cdd51['startNameSet_']&&(_0x19a8df['sn']=_0x5cdd51['indexStartName_']),_0x19a8df['sin']=!_0x5cdd51['startAfterSet_']),_0x5cdd51['endSet_']&&(_0x19a8df['ep']=_0x5cdd51['indexEndValue_'],_0x5cdd51['endNameSet_']&&(_0x19a8df['en']=_0x5cdd51['indexEndName_']),_0x19a8df['ein']=!_0x5cdd51['endBeforeSet_']),_0x5cdd51['limitSet_']){_0x19a8df['l']=_0x5cdd51['limit_'];let _0x3f8eb6=_0x5cdd51['viewFrom_'];_0x3f8eb6===''&&(_0x5cdd51['isViewFromLeft']()?_0x3f8eb6='l':_0x3f8eb6='r'),_0x19a8df['vf']=_0x3f8eb6;}return _0x5cdd51['index_']!==R&&(_0x19a8df['i']=_0x5cdd51['index_']['toString']()),_0x19a8df;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x2033a3){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x1e2bd4,_0x3eb292){return _0x3eb292!==void 0x0?'tag$'+_0x3eb292:(f(_0x1e2bd4['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x1e2bd4['_path']['toString']());}constructor(_0x2901f1,_0x566aa3,_0x3ff926,_0x55f7c3){super(),this['repoInfo_']=_0x2901f1,this['onDataUpdate_']=_0x566aa3,this['authTokenProvider_']=_0x3ff926,this['appCheckTokenProvider_']=_0x55f7c3,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x4bb377,_0x1d5533,_0x56e0f1,_0x31595d){const _0x415c92=_0x4bb377['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x415c92+'\x20'+_0x4bb377['_queryIdentifier']);const _0x2fd333=vn['getListenId_'](_0x4bb377,_0x56e0f1),_0x134324={};this['listens_'][_0x2fd333]=_0x134324;const _0x29fe12=ir(_0x4bb377['_queryParams']);this['restRequest_'](_0x415c92+'.json',_0x29fe12,(_0x24c328,_0x4a4ea8)=>{let _0x54a6af=_0x4a4ea8;if(_0x24c328===0x194&&(_0x54a6af=null,_0x24c328=null),_0x24c328===null&&this['onDataUpdate_'](_0x415c92,_0x54a6af,!0x1,_0x56e0f1),Le(this['listens_'],_0x2fd333)===_0x134324){let _0x56cfe8;_0x24c328?_0x24c328===0x191?_0x56cfe8='permission_denied':_0x56cfe8='rest_error:'+_0x24c328:_0x56cfe8='ok',_0x31595d(_0x56cfe8,null);}});}['unlisten'](_0x31cf11,_0x31a052){const _0x1d2e4f=vn['getListenId_'](_0x31cf11,_0x31a052);delete this['listens_'][_0x1d2e4f];}['get'](_0x5741ad){const _0x33c48e=ir(_0x5741ad['_queryParams']),_0x45f692=_0x5741ad['_path']['toString'](),_0xda9c58=new H();return this['restRequest_'](_0x45f692+'.json',_0x33c48e,(_0xd4f540,_0x453812)=>{let _0x5a3927=_0x453812;_0xd4f540===0x194&&(_0x5a3927=null,_0xd4f540=null),_0xd4f540===null?(this['onDataUpdate_'](_0x45f692,_0x5a3927,!0x1,null),_0xda9c58['resolve'](_0x5a3927)):_0xda9c58['reject'](new Error(_0x5a3927));}),_0xda9c58['promise'];}['refreshAuthToken'](_0x5a4f60){}['restRequest_'](_0x8ca27c,_0x5906c2={},_0x570863){return _0x5906c2['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5ce19b,_0x472573])=>{_0x5ce19b&&_0x5ce19b['accessToken']&&(_0x5906c2['auth']=_0x5ce19b['accessToken']),_0x472573&&_0x472573['token']&&(_0x5906c2['ac']=_0x472573['token']);const _0x5dc4a2=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x8ca27c+'?ns='+this['repoInfo_']['namespace']+ut(_0x5906c2);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5dc4a2);const _0x5a1bc9=new XMLHttpRequest();_0x5a1bc9['onreadystatechange']=()=>{if(_0x570863&&_0x5a1bc9['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5dc4a2+'\x20received.\x20status:',_0x5a1bc9['status'],'response:',_0x5a1bc9['responseText']);let _0xbbcf02=null;if(_0x5a1bc9['status']>=0xc8&&_0x5a1bc9['status']<0x12c){try{_0xbbcf02=Nt(_0x5a1bc9['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5dc4a2+':\x20'+_0x5a1bc9['responseText']);}_0x570863(null,_0xbbcf02);}else _0x5a1bc9['status']!==0x191&&_0x5a1bc9['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5dc4a2+'\x20Status:\x20'+_0x5a1bc9['status']),_0x570863(_0x5a1bc9['status']);_0x570863=null;}},_0x5a1bc9['open']('GET',_0x5dc4a2,!0x0),_0x5a1bc9['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x596236){return this['rootNode_']['getChild'](_0x596236);}['updateSnapshot'](_0x3e0f90,_0x324a3c){this['rootNode_']=this['rootNode_']['updateChild'](_0x3e0f90,_0x324a3c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x345c2b,_0x1af0a6,_0x1ea2c0){if(v(_0x1af0a6))_0x345c2b['value']=_0x1ea2c0,_0x345c2b['children']['clear']();else{if(_0x345c2b['value']!==null)_0x345c2b['value']=_0x345c2b['value']['updateChild'](_0x1af0a6,_0x1ea2c0);else{const _0x3fdc56=y(_0x1af0a6);_0x345c2b['children']['has'](_0x3fdc56)||_0x345c2b['children']['set'](_0x3fdc56,En());const _0x26150a=_0x345c2b['children']['get'](_0x3fdc56);_0x1af0a6=S(_0x1af0a6),pt(_0x26150a,_0x1af0a6,_0x1ea2c0);}}}function Ti(_0x3d92cd,_0x2ae590){if(v(_0x2ae590))return _0x3d92cd['value']=null,_0x3d92cd['children']['clear'](),!0x0;if(_0x3d92cd['value']!==null){if(_0x3d92cd['value']['isLeafNode']())return!0x1;{const _0x9fe54f=_0x3d92cd['value'];return _0x3d92cd['value']=null,_0x9fe54f['forEachChild'](R,(_0x15b89e,_0x28bbe2)=>{pt(_0x3d92cd,new C(_0x15b89e),_0x28bbe2);}),Ti(_0x3d92cd,_0x2ae590);}}else{if(_0x3d92cd['children']['size']>0x0){const _0x297470=y(_0x2ae590);return _0x2ae590=S(_0x2ae590),_0x3d92cd['children']['has'](_0x297470)&&Ti(_0x3d92cd['children']['get'](_0x297470),_0x2ae590)&&_0x3d92cd['children']['delete'](_0x297470),_0x3d92cd['children']['size']===0x0;}else return!0x0;}}function Si(_0x521b61,_0x566e52,_0x5596bb){_0x521b61['value']!==null?_0x5596bb(_0x566e52,_0x521b61['value']):Zh(_0x521b61,(_0x3664ba,_0x42bfe4)=>{const _0x1052ea=new C(_0x566e52['toString']()+'/'+_0x3664ba);Si(_0x42bfe4,_0x1052ea,_0x5596bb);});}function Zh(_0x5be572,_0xa22b67){_0x5be572['children']['forEach']((_0x356c2e,_0x261380)=>{_0xa22b67(_0x261380,_0x356c2e);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x344bef){this['collection_']=_0x344bef,this['last_']=null;}['get'](){const _0x65c483=this['collection_']['get'](),_0x1e232f={..._0x65c483};return this['last_']&&x(this['last_'],(_0x3e0e4a,_0x2bb1c6)=>{_0x1e232f[_0x3e0e4a]=_0x1e232f[_0x3e0e4a]-_0x2bb1c6;}),this['last_']=_0x65c483,_0x1e232f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x54c43a,_0x565bb0){this['server_']=_0x565bb0,this['statsToReport_']={},this['statsListener_']=new eu(_0x54c43a);const _0x395378=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x395378));}['reportStats_'](){const _0x2f52df=this['statsListener_']['get'](),_0x179576={};let _0xcb6f4c=!0x1;x(_0x2f52df,(_0x2dd817,_0x109dc7)=>{_0x109dc7>0x0&&Q(this['statsToReport_'],_0x2dd817)&&(_0x179576[_0x2dd817]=_0x109dc7,_0xcb6f4c=!0x0);}),_0xcb6f4c&&this['server_']['reportStats'](_0x179576),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x465991){_0x465991[_0x465991['OVERWRITE']=0x0]='OVERWRITE',_0x465991[_0x465991['MERGE']=0x1]='MERGE',_0x465991[_0x465991['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x465991[_0x465991['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x432cbc){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x432cbc,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x38cfd2,_0x242294,_0x2924f4){this['path']=_0x38cfd2,this['affectedTree']=_0x242294,this['revert']=_0x2924f4,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x462e34){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5646c0=this['affectedTree']['subtree'](new C(_0x462e34));return new In(w(),_0x5646c0,this['revert']);}}else return f(y(this['path'])===_0x462e34,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x16c1e4,_0x20ddcc){this['source']=_0x16c1e4,this['path']=_0x20ddcc,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x3cad52){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x53b3f3,_0x5f3c86,_0xc1ae0d){this['source']=_0x53b3f3,this['path']=_0x5f3c86,this['snap']=_0xc1ae0d,this['type']=z['OVERWRITE'];}['operationForChild'](_0x50daf8){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x50daf8)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x3bf4aa,_0x33788b,_0x641596){this['source']=_0x3bf4aa,this['path']=_0x33788b,this['children']=_0x641596,this['type']=z['MERGE'];}['operationForChild'](_0x4d8dc0){if(v(this['path'])){const _0x4d5ee7=this['children']['subtree'](new C(_0x4d8dc0));return _0x4d5ee7['isEmpty']()?null:_0x4d5ee7['value']?new Be(this['source'],w(),_0x4d5ee7['value']):new ot(this['source'],w(),_0x4d5ee7);}else return f(y(this['path'])===_0x4d8dc0,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x383983,_0x4487d0,_0x145f14){this['node_']=_0x383983,this['fullyInitialized_']=_0x4487d0,this['filtered_']=_0x145f14;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x257d1c){if(v(_0x257d1c))return this['isFullyInitialized']()&&!this['filtered_'];const _0x507f81=y(_0x257d1c);return this['isCompleteForChild'](_0x507f81);}['isCompleteForChild'](_0x2ab1f5){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2ab1f5);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x3347e9){this['query_']=_0x3347e9,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0xb11412,_0x3baa90,_0x277f04,_0x1f6229){const _0x2ba0b4=[],_0x32a06f=[];return _0x3baa90['forEach'](_0x20be9a=>{_0x20be9a['type']==='child_changed'&&_0xb11412['index_']['indexedValueChanged'](_0x20be9a['oldSnap'],_0x20be9a['snapshotNode'])&&_0x32a06f['push'](zh(_0x20be9a['childName'],_0x20be9a['snapshotNode']));}),wt(_0xb11412,_0x2ba0b4,'child_removed',_0x3baa90,_0x1f6229,_0x277f04),wt(_0xb11412,_0x2ba0b4,'child_added',_0x3baa90,_0x1f6229,_0x277f04),wt(_0xb11412,_0x2ba0b4,'child_moved',_0x32a06f,_0x1f6229,_0x277f04),wt(_0xb11412,_0x2ba0b4,'child_changed',_0x3baa90,_0x1f6229,_0x277f04),wt(_0xb11412,_0x2ba0b4,'value',_0x3baa90,_0x1f6229,_0x277f04),_0x2ba0b4;}function wt(_0x63dd65,_0x58f481,_0x4b2d75,_0x1b36a6,_0x31076b,_0x27dd86){const _0x2284c8=_0x1b36a6['filter'](_0x492a2f=>_0x492a2f['type']===_0x4b2d75);_0x2284c8['sort']((_0x5b03a8,_0x5acf2e)=>au(_0x63dd65,_0x5b03a8,_0x5acf2e)),_0x2284c8['forEach'](_0x22151e=>{const _0x2a6957=ou(_0x63dd65,_0x22151e,_0x27dd86);_0x31076b['forEach'](_0x333a3e=>{_0x333a3e['respondsTo'](_0x22151e['type'])&&_0x58f481['push'](_0x333a3e['createEvent'](_0x2a6957,_0x63dd65['query_']));});});}function ou(_0x24bfe9,_0x570a17,_0x5bf098){return _0x570a17['type']==='value'||_0x570a17['type']==='child_removed'||(_0x570a17['prevName']=_0x5bf098['getPredecessorChildName'](_0x570a17['childName'],_0x570a17['snapshotNode'],_0x24bfe9['index_'])),_0x570a17;}function au(_0x31cd5b,_0x4f8548,_0x5f0213){if(_0x4f8548['childName']==null||_0x5f0213['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0xeb13bc=new E(_0x4f8548['childName'],_0x4f8548['snapshotNode']),_0x439fab=new E(_0x5f0213['childName'],_0x5f0213['snapshotNode']);return _0x31cd5b['index_']['compare'](_0xeb13bc,_0x439fab);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x2d7438,_0x5e802d){return{'eventCache':_0x2d7438,'serverCache':_0x5e802d};}function Rt(_0x432270,_0x2f10f8,_0x5943f8,_0x54e4d3){return Un(new Te(_0x2f10f8,_0x5943f8,_0x54e4d3),_0x432270['serverCache']);}function Fo(_0x3a42f8,_0x305ed4,_0x4e0a12,_0x2afe3f){return Un(_0x3a42f8['eventCache'],new Te(_0x305ed4,_0x4e0a12,_0x2afe3f));}function wn(_0x1fb1ae){return _0x1fb1ae['eventCache']['isFullyInitialized']()?_0x1fb1ae['eventCache']['getNode']():null;}function Ve(_0x582c32){return _0x582c32['serverCache']['isFullyInitialized']()?_0x582c32['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x2f51fa){let _0x3dd01a=new b(null);return x(_0x2f51fa,(_0x516b6f,_0x5f22c6)=>{_0x3dd01a=_0x3dd01a['set'](new C(_0x516b6f),_0x5f22c6);}),_0x3dd01a;}constructor(_0x589c5a,_0x35692b=cu()){this['value']=_0x589c5a,this['children']=_0x35692b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2dfc84,_0x32cad9){if(this['value']!=null&&_0x32cad9(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2dfc84))return null;{const _0x4a55f0=y(_0x2dfc84),_0x35810b=this['children']['get'](_0x4a55f0);if(_0x35810b!==null){const _0x2e7cea=_0x35810b['findRootMostMatchingPathAndValue'](S(_0x2dfc84),_0x32cad9);return _0x2e7cea!=null?{'path':k(new C(_0x4a55f0),_0x2e7cea['path']),'value':_0x2e7cea['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3e08b7){return this['findRootMostMatchingPathAndValue'](_0x3e08b7,()=>!0x0);}['subtree'](_0x302d49){if(v(_0x302d49))return this;{const _0x31e748=y(_0x302d49),_0x1b7238=this['children']['get'](_0x31e748);return _0x1b7238!==null?_0x1b7238['subtree'](S(_0x302d49)):new b(null);}}['set'](_0x3b90e1,_0x40bc18){if(v(_0x3b90e1))return new b(_0x40bc18,this['children']);{const _0x51c642=y(_0x3b90e1),_0x1aafc4=(this['children']['get'](_0x51c642)||new b(null))['set'](S(_0x3b90e1),_0x40bc18),_0x2da42f=this['children']['insert'](_0x51c642,_0x1aafc4);return new b(this['value'],_0x2da42f);}}['remove'](_0x5bb7c1){if(v(_0x5bb7c1))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x14b0cc=y(_0x5bb7c1),_0x9eda16=this['children']['get'](_0x14b0cc);if(_0x9eda16){const _0x4a0739=_0x9eda16['remove'](S(_0x5bb7c1));let _0x39c134;return _0x4a0739['isEmpty']()?_0x39c134=this['children']['remove'](_0x14b0cc):_0x39c134=this['children']['insert'](_0x14b0cc,_0x4a0739),this['value']===null&&_0x39c134['isEmpty']()?new b(null):new b(this['value'],_0x39c134);}else return this;}}['get'](_0x262936){if(v(_0x262936))return this['value'];{const _0x485a3=y(_0x262936),_0x362957=this['children']['get'](_0x485a3);return _0x362957?_0x362957['get'](S(_0x262936)):null;}}['setTree'](_0x29b924,_0xced2a1){if(v(_0x29b924))return _0xced2a1;{const _0x5d9222=y(_0x29b924),_0x2466f8=(this['children']['get'](_0x5d9222)||new b(null))['setTree'](S(_0x29b924),_0xced2a1);let _0x1107d1;return _0x2466f8['isEmpty']()?_0x1107d1=this['children']['remove'](_0x5d9222):_0x1107d1=this['children']['insert'](_0x5d9222,_0x2466f8),new b(this['value'],_0x1107d1);}}['fold'](_0x11cad6){return this['fold_'](w(),_0x11cad6);}['fold_'](_0x1142f7,_0x5141ba){const _0x3e3682={};return this['children']['inorderTraversal']((_0x2edb43,_0x774672)=>{_0x3e3682[_0x2edb43]=_0x774672['fold_'](k(_0x1142f7,_0x2edb43),_0x5141ba);}),_0x5141ba(_0x1142f7,this['value'],_0x3e3682);}['findOnPath'](_0x17c144,_0x16a864){return this['findOnPath_'](_0x17c144,w(),_0x16a864);}['findOnPath_'](_0x344e00,_0x4ee41f,_0x29dd4b){const _0xa11f9b=this['value']?_0x29dd4b(_0x4ee41f,this['value']):!0x1;if(_0xa11f9b)return _0xa11f9b;if(v(_0x344e00))return null;{const _0x1e7d40=y(_0x344e00),_0x36ddd6=this['children']['get'](_0x1e7d40);return _0x36ddd6?_0x36ddd6['findOnPath_'](S(_0x344e00),k(_0x4ee41f,_0x1e7d40),_0x29dd4b):null;}}['foreachOnPath'](_0x169989,_0x21b8f1){return this['foreachOnPath_'](_0x169989,w(),_0x21b8f1);}['foreachOnPath_'](_0x2ac191,_0x1d5536,_0x291ea9){if(v(_0x2ac191))return this;{this['value']&&_0x291ea9(_0x1d5536,this['value']);const _0x273674=y(_0x2ac191),_0x197d21=this['children']['get'](_0x273674);return _0x197d21?_0x197d21['foreachOnPath_'](S(_0x2ac191),k(_0x1d5536,_0x273674),_0x291ea9):new b(null);}}['foreach'](_0x511996){this['foreach_'](w(),_0x511996);}['foreach_'](_0xd91d0a,_0x36a518){this['children']['inorderTraversal']((_0x203fda,_0x163c02)=>{_0x163c02['foreach_'](k(_0xd91d0a,_0x203fda),_0x36a518);}),this['value']&&_0x36a518(_0xd91d0a,this['value']);}['foreachChild'](_0x1cdf20){this['children']['inorderTraversal']((_0x4135a2,_0x135f75)=>{_0x135f75['value']&&_0x1cdf20(_0x4135a2,_0x135f75['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x41ef3a){this['writeTree_']=_0x41ef3a;}static['empty'](){return new K(new b(null));}}function At(_0x39297e,_0x2d9ba7,_0x556adf){if(v(_0x2d9ba7))return new K(new b(_0x556adf));{const _0x428bfc=_0x39297e['writeTree_']['findRootMostValueAndPath'](_0x2d9ba7);if(_0x428bfc!=null){const _0x5da94b=_0x428bfc['path'];let _0x2f91b9=_0x428bfc['value'];const _0x4969ae=F(_0x5da94b,_0x2d9ba7);return _0x2f91b9=_0x2f91b9['updateChild'](_0x4969ae,_0x556adf),new K(_0x39297e['writeTree_']['set'](_0x5da94b,_0x2f91b9));}else{const _0x21d9de=new b(_0x556adf),_0xb006e0=_0x39297e['writeTree_']['setTree'](_0x2d9ba7,_0x21d9de);return new K(_0xb006e0);}}}function bi(_0x508038,_0x3f83f8,_0x3f4d89){let _0x1195ee=_0x508038;return x(_0x3f4d89,(_0x12aed3,_0xd8b55e)=>{_0x1195ee=At(_0x1195ee,k(_0x3f83f8,_0x12aed3),_0xd8b55e);}),_0x1195ee;}function or(_0x2663fb,_0x863f95){if(v(_0x863f95))return K['empty']();{const _0x162ec6=_0x2663fb['writeTree_']['setTree'](_0x863f95,new b(null));return new K(_0x162ec6);}}function Ri(_0x185afd,_0x5d25ee){return ze(_0x185afd,_0x5d25ee)!=null;}function ze(_0x14f32e,_0x282fe5){const _0x815378=_0x14f32e['writeTree_']['findRootMostValueAndPath'](_0x282fe5);return _0x815378!=null?_0x14f32e['writeTree_']['get'](_0x815378['path'])['getChild'](F(_0x815378['path'],_0x282fe5)):null;}function ar(_0xce329e){const _0xd69c0f=[],_0x3575b1=_0xce329e['writeTree_']['value'];return _0x3575b1!=null?_0x3575b1['isLeafNode']()||_0x3575b1['forEachChild'](R,(_0x2a6d24,_0x2da03d)=>{_0xd69c0f['push'](new E(_0x2a6d24,_0x2da03d));}):_0xce329e['writeTree_']['children']['inorderTraversal']((_0x49ac51,_0xff56e8)=>{_0xff56e8['value']!=null&&_0xd69c0f['push'](new E(_0x49ac51,_0xff56e8['value']));}),_0xd69c0f;}function Ee(_0x8cb010,_0x4f901){if(v(_0x4f901))return _0x8cb010;{const _0x54d74e=ze(_0x8cb010,_0x4f901);return _0x54d74e!=null?new K(new b(_0x54d74e)):new K(_0x8cb010['writeTree_']['subtree'](_0x4f901));}}function Ai(_0x21fd3e){return _0x21fd3e['writeTree_']['isEmpty']();}function at(_0x4f8ebf,_0x1204c4){return Uo(w(),_0x4f8ebf['writeTree_'],_0x1204c4);}function Uo(_0x1f43ce,_0x5a9b21,_0x1a31da){if(_0x5a9b21['value']!=null)return _0x1a31da['updateChild'](_0x1f43ce,_0x5a9b21['value']);{let _0x5dbe31=null;return _0x5a9b21['children']['inorderTraversal']((_0x7b12a8,_0x37c313)=>{_0x7b12a8==='.priority'?(f(_0x37c313['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5dbe31=_0x37c313['value']):_0x1a31da=Uo(k(_0x1f43ce,_0x7b12a8),_0x37c313,_0x1a31da);}),!_0x1a31da['getChild'](_0x1f43ce)['isEmpty']()&&_0x5dbe31!==null&&(_0x1a31da=_0x1a31da['updateChild'](k(_0x1f43ce,'.priority'),_0x5dbe31)),_0x1a31da;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x51ea4f,_0x5295e8){return Ho(_0x5295e8,_0x51ea4f);}function lu(_0x4397df,_0x1b90c5,_0x121e22,_0x50fbc6,_0x29c5ed){f(_0x50fbc6>_0x4397df['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x29c5ed===void 0x0&&(_0x29c5ed=!0x0),_0x4397df['allWrites']['push']({'path':_0x1b90c5,'snap':_0x121e22,'writeId':_0x50fbc6,'visible':_0x29c5ed}),_0x29c5ed&&(_0x4397df['visibleWrites']=At(_0x4397df['visibleWrites'],_0x1b90c5,_0x121e22)),_0x4397df['lastWriteId']=_0x50fbc6;}function hu(_0xf9a92e,_0x3decee,_0x311fb8,_0x503660){f(_0x503660>_0xf9a92e['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0xf9a92e['allWrites']['push']({'path':_0x3decee,'children':_0x311fb8,'writeId':_0x503660,'visible':!0x0}),_0xf9a92e['visibleWrites']=bi(_0xf9a92e['visibleWrites'],_0x3decee,_0x311fb8),_0xf9a92e['lastWriteId']=_0x503660;}function uu(_0x4c890a,_0xa0b125){for(let _0x2ab6db=0x0;_0x2ab6db<_0x4c890a['allWrites']['length'];_0x2ab6db++){const _0x1549ab=_0x4c890a['allWrites'][_0x2ab6db];if(_0x1549ab['writeId']===_0xa0b125)return _0x1549ab;}return null;}function du(_0x2fee85,_0x5c4458){const _0x3a5a08=_0x2fee85['allWrites']['findIndex'](_0x40a1aa=>_0x40a1aa['writeId']===_0x5c4458);f(_0x3a5a08>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1cc16a=_0x2fee85['allWrites'][_0x3a5a08];_0x2fee85['allWrites']['splice'](_0x3a5a08,0x1);let _0x392ed6=_0x1cc16a['visible'],_0x2430c2=!0x1,_0x2fe8a7=_0x2fee85['allWrites']['length']-0x1;for(;_0x392ed6&&_0x2fe8a7>=0x0;){const _0x1c410b=_0x2fee85['allWrites'][_0x2fe8a7];_0x1c410b['visible']&&(_0x2fe8a7>=_0x3a5a08&&fu(_0x1c410b,_0x1cc16a['path'])?_0x392ed6=!0x1:G(_0x1cc16a['path'],_0x1c410b['path'])&&(_0x2430c2=!0x0)),_0x2fe8a7--;}if(_0x392ed6){if(_0x2430c2)return pu(_0x2fee85),!0x0;if(_0x1cc16a['snap'])_0x2fee85['visibleWrites']=or(_0x2fee85['visibleWrites'],_0x1cc16a['path']);else{const _0x3243c7=_0x1cc16a['children'];x(_0x3243c7,_0x413474=>{_0x2fee85['visibleWrites']=or(_0x2fee85['visibleWrites'],k(_0x1cc16a['path'],_0x413474));});}return!0x0;}else return!0x1;}function fu(_0x52023b,_0x2cc09b){if(_0x52023b['snap'])return G(_0x52023b['path'],_0x2cc09b);for(const _0x5201a5 in _0x52023b['children'])if(_0x52023b['children']['hasOwnProperty'](_0x5201a5)&&G(k(_0x52023b['path'],_0x5201a5),_0x2cc09b))return!0x0;return!0x1;}function pu(_0x278324){_0x278324['visibleWrites']=Wo(_0x278324['allWrites'],_u,w()),_0x278324['allWrites']['length']>0x0?_0x278324['lastWriteId']=_0x278324['allWrites'][_0x278324['allWrites']['length']-0x1]['writeId']:_0x278324['lastWriteId']=-0x1;}function _u(_0xf6befe){return _0xf6befe['visible'];}function Wo(_0x8b2a72,_0x578fbc,_0x5f29a4){let _0x1e9935=K['empty']();for(let _0x4e4c10=0x0;_0x4e4c10<_0x8b2a72['length'];++_0x4e4c10){const _0x9cead2=_0x8b2a72[_0x4e4c10];if(_0x578fbc(_0x9cead2)){const _0x375f9e=_0x9cead2['path'];let _0x59af2a;if(_0x9cead2['snap'])G(_0x5f29a4,_0x375f9e)?(_0x59af2a=F(_0x5f29a4,_0x375f9e),_0x1e9935=At(_0x1e9935,_0x59af2a,_0x9cead2['snap'])):G(_0x375f9e,_0x5f29a4)&&(_0x59af2a=F(_0x375f9e,_0x5f29a4),_0x1e9935=At(_0x1e9935,w(),_0x9cead2['snap']['getChild'](_0x59af2a)));else{if(_0x9cead2['children']){if(G(_0x5f29a4,_0x375f9e))_0x59af2a=F(_0x5f29a4,_0x375f9e),_0x1e9935=bi(_0x1e9935,_0x59af2a,_0x9cead2['children']);else{if(G(_0x375f9e,_0x5f29a4)){if(_0x59af2a=F(_0x375f9e,_0x5f29a4),v(_0x59af2a))_0x1e9935=bi(_0x1e9935,w(),_0x9cead2['children']);else{const _0x3346da=Le(_0x9cead2['children'],y(_0x59af2a));if(_0x3346da){const _0x54e16a=_0x3346da['getChild'](S(_0x59af2a));_0x1e9935=At(_0x1e9935,w(),_0x54e16a);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1e9935;}function Bo(_0x30d418,_0x3991b1,_0x4bf6f2,_0x422d73,_0x46e255){if(!_0x422d73&&!_0x46e255){const _0x168484=ze(_0x30d418['visibleWrites'],_0x3991b1);if(_0x168484!=null)return _0x168484;{const _0x25c919=Ee(_0x30d418['visibleWrites'],_0x3991b1);if(Ai(_0x25c919))return _0x4bf6f2;if(_0x4bf6f2==null&&!Ri(_0x25c919,w()))return null;{const _0x494303=_0x4bf6f2||g['EMPTY_NODE'];return at(_0x25c919,_0x494303);}}}else{const _0x36663c=Ee(_0x30d418['visibleWrites'],_0x3991b1);if(!_0x46e255&&Ai(_0x36663c))return _0x4bf6f2;if(!_0x46e255&&_0x4bf6f2==null&&!Ri(_0x36663c,w()))return null;{const _0xa636db=function(_0x405d85){return(_0x405d85['visible']||_0x46e255)&&(!_0x422d73||!~_0x422d73['indexOf'](_0x405d85['writeId']))&&(G(_0x405d85['path'],_0x3991b1)||G(_0x3991b1,_0x405d85['path']));},_0x537ec9=Wo(_0x30d418['allWrites'],_0xa636db,_0x3991b1),_0x227478=_0x4bf6f2||g['EMPTY_NODE'];return at(_0x537ec9,_0x227478);}}}function gu(_0x1e6be2,_0x24220e,_0x2d955e){let _0x580bf7=g['EMPTY_NODE'];const _0x27cc61=ze(_0x1e6be2['visibleWrites'],_0x24220e);if(_0x27cc61)return _0x27cc61['isLeafNode']()||_0x27cc61['forEachChild'](R,(_0x18ee4c,_0x5b71c6)=>{_0x580bf7=_0x580bf7['updateImmediateChild'](_0x18ee4c,_0x5b71c6);}),_0x580bf7;if(_0x2d955e){const _0x4a99ee=Ee(_0x1e6be2['visibleWrites'],_0x24220e);return _0x2d955e['forEachChild'](R,(_0x42cd9d,_0x47ffce)=>{const _0xce051f=at(Ee(_0x4a99ee,new C(_0x42cd9d)),_0x47ffce);_0x580bf7=_0x580bf7['updateImmediateChild'](_0x42cd9d,_0xce051f);}),ar(_0x4a99ee)['forEach'](_0x25af40=>{_0x580bf7=_0x580bf7['updateImmediateChild'](_0x25af40['name'],_0x25af40['node']);}),_0x580bf7;}else{const _0x624a38=Ee(_0x1e6be2['visibleWrites'],_0x24220e);return ar(_0x624a38)['forEach'](_0x272e56=>{_0x580bf7=_0x580bf7['updateImmediateChild'](_0x272e56['name'],_0x272e56['node']);}),_0x580bf7;}}function mu(_0xd0f0c9,_0x3724f3,_0x560b9d,_0x8b807c,_0x538c20){f(_0x8b807c||_0x538c20,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x40d632=k(_0x3724f3,_0x560b9d);if(Ri(_0xd0f0c9['visibleWrites'],_0x40d632))return null;{const _0x4778a9=Ee(_0xd0f0c9['visibleWrites'],_0x40d632);return Ai(_0x4778a9)?_0x538c20['getChild'](_0x560b9d):at(_0x4778a9,_0x538c20['getChild'](_0x560b9d));}}function yu(_0x176620,_0x282f1d,_0x1e4265,_0x4ba5ff){const _0x3541d9=k(_0x282f1d,_0x1e4265),_0x4f2f7c=ze(_0x176620['visibleWrites'],_0x3541d9);if(_0x4f2f7c!=null)return _0x4f2f7c;if(_0x4ba5ff['isCompleteForChild'](_0x1e4265)){const _0x385aed=Ee(_0x176620['visibleWrites'],_0x3541d9);return at(_0x385aed,_0x4ba5ff['getNode']()['getImmediateChild'](_0x1e4265));}else return null;}function vu(_0x4b5a71,_0x3f95e8){return ze(_0x4b5a71['visibleWrites'],_0x3f95e8);}function Eu(_0x1ef1f2,_0x4e31f5,_0x417aae,_0x12863d,_0x2811c4,_0x5f2c93,_0x5bf60b){let _0x56c420;const _0x514aea=Ee(_0x1ef1f2['visibleWrites'],_0x4e31f5),_0x237a07=ze(_0x514aea,w());if(_0x237a07!=null)_0x56c420=_0x237a07;else{if(_0x417aae!=null)_0x56c420=at(_0x514aea,_0x417aae);else return[];}if(_0x56c420=_0x56c420['withIndex'](_0x5bf60b),!_0x56c420['isEmpty']()&&!_0x56c420['isLeafNode']()){const _0x1a76ac=[],_0x2b5d18=_0x5bf60b['getCompare'](),_0x24da51=_0x5f2c93?_0x56c420['getReverseIteratorFrom'](_0x12863d,_0x5bf60b):_0x56c420['getIteratorFrom'](_0x12863d,_0x5bf60b);let _0x811c16=_0x24da51['getNext']();for(;_0x811c16&&_0x1a76ac['length']<_0x2811c4;)_0x2b5d18(_0x811c16,_0x12863d)!==0x0&&_0x1a76ac['push'](_0x811c16),_0x811c16=_0x24da51['getNext']();return _0x1a76ac;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x5ac170,_0x38826e,_0x578d41,_0x3ae043){return Bo(_0x5ac170['writeTree'],_0x5ac170['treePath'],_0x38826e,_0x578d41,_0x3ae043);}function is(_0x5e1bf6,_0x437be2){return gu(_0x5e1bf6['writeTree'],_0x5e1bf6['treePath'],_0x437be2);}function cr(_0x49a258,_0xa3bf2c,_0xa7d5be,_0x1382f7){return mu(_0x49a258['writeTree'],_0x49a258['treePath'],_0xa3bf2c,_0xa7d5be,_0x1382f7);}function Tn(_0x4c4bcb,_0x56d0cd){return vu(_0x4c4bcb['writeTree'],k(_0x4c4bcb['treePath'],_0x56d0cd));}function wu(_0x1ed0e2,_0x586a03,_0x217c9f,_0x43b0b5,_0x2d3b06,_0x1e1a12){return Eu(_0x1ed0e2['writeTree'],_0x1ed0e2['treePath'],_0x586a03,_0x217c9f,_0x43b0b5,_0x2d3b06,_0x1e1a12);}function ss(_0x3be2b7,_0x3833ba,_0x5445f3){return yu(_0x3be2b7['writeTree'],_0x3be2b7['treePath'],_0x3833ba,_0x5445f3);}function Vo(_0x551ffb,_0x3d0b26){return Ho(k(_0x551ffb['treePath'],_0x3d0b26),_0x551ffb['writeTree']);}function Ho(_0x2dfecb,_0x4e738d){return{'treePath':_0x2dfecb,'writeTree':_0x4e738d};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x2d1465){const _0x639060=_0x2d1465['type'],_0x2a114d=_0x2d1465['childName'];f(_0x639060==='child_added'||_0x639060==='child_changed'||_0x639060==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2a114d!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3cdd44=this['changeMap']['get'](_0x2a114d);if(_0x3cdd44){const _0x1a5937=_0x3cdd44['type'];if(_0x639060==='child_added'&&_0x1a5937==='child_removed')this['changeMap']['set'](_0x2a114d,xt(_0x2a114d,_0x2d1465['snapshotNode'],_0x3cdd44['snapshotNode']));else{if(_0x639060==='child_removed'&&_0x1a5937==='child_added')this['changeMap']['delete'](_0x2a114d);else{if(_0x639060==='child_removed'&&_0x1a5937==='child_changed')this['changeMap']['set'](_0x2a114d,Lt(_0x2a114d,_0x3cdd44['oldSnap']));else{if(_0x639060==='child_changed'&&_0x1a5937==='child_added')this['changeMap']['set'](_0x2a114d,rt(_0x2a114d,_0x2d1465['snapshotNode']));else{if(_0x639060==='child_changed'&&_0x1a5937==='child_changed')this['changeMap']['set'](_0x2a114d,xt(_0x2a114d,_0x2d1465['snapshotNode'],_0x3cdd44['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x2d1465+'\x20occurred\x20after\x20'+_0x3cdd44);}}}}}else this['changeMap']['set'](_0x2a114d,_0x2d1465);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x4304b3){return null;}['getChildAfterChild'](_0x55126e,_0x4d3164,_0x1c8a31){return null;}}const $o=new Tu();class rs{constructor(_0x1eef25,_0x39b384,_0x133f03=null){this['writes_']=_0x1eef25,this['viewCache_']=_0x39b384,this['optCompleteServerCache_']=_0x133f03;}['getCompleteChild'](_0x51feb9){const _0x435596=this['viewCache_']['eventCache'];if(_0x435596['isCompleteForChild'](_0x51feb9))return _0x435596['getNode']()['getImmediateChild'](_0x51feb9);{const _0x482b42=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x51feb9,_0x482b42);}}['getChildAfterChild'](_0x2f33d5,_0x4f0ab0,_0x3f2bcd){const _0x795f8=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x1e5b5f=wu(this['writes_'],_0x795f8,_0x4f0ab0,0x1,_0x3f2bcd,_0x2f33d5);return _0x1e5b5f['length']===0x0?null:_0x1e5b5f[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x4c8d31){return{'filter':_0x4c8d31};}function bu(_0x1b56a1,_0x53ea04){f(_0x53ea04['eventCache']['getNode']()['isIndexed'](_0x1b56a1['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x53ea04['serverCache']['getNode']()['isIndexed'](_0x1b56a1['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x2ec954,_0x5ec688,_0x396758,_0x317c43,_0x4befa0){const _0x13932d=new Cu();let _0x5128b0,_0x1dd3c5;if(_0x396758['type']===z['OVERWRITE']){const _0x346105=_0x396758;_0x346105['source']['fromUser']?_0x5128b0=ki(_0x2ec954,_0x5ec688,_0x346105['path'],_0x346105['snap'],_0x317c43,_0x4befa0,_0x13932d):(f(_0x346105['source']['fromServer'],'Unknown\x20source.'),_0x1dd3c5=_0x346105['source']['tagged']||_0x5ec688['serverCache']['isFiltered']()&&!v(_0x346105['path']),_0x5128b0=Sn(_0x2ec954,_0x5ec688,_0x346105['path'],_0x346105['snap'],_0x317c43,_0x4befa0,_0x1dd3c5,_0x13932d));}else{if(_0x396758['type']===z['MERGE']){const _0x1b8938=_0x396758;_0x1b8938['source']['fromUser']?_0x5128b0=ku(_0x2ec954,_0x5ec688,_0x1b8938['path'],_0x1b8938['children'],_0x317c43,_0x4befa0,_0x13932d):(f(_0x1b8938['source']['fromServer'],'Unknown\x20source.'),_0x1dd3c5=_0x1b8938['source']['tagged']||_0x5ec688['serverCache']['isFiltered'](),_0x5128b0=Pi(_0x2ec954,_0x5ec688,_0x1b8938['path'],_0x1b8938['children'],_0x317c43,_0x4befa0,_0x1dd3c5,_0x13932d));}else{if(_0x396758['type']===z['ACK_USER_WRITE']){const _0x18b627=_0x396758;_0x18b627['revert']?_0x5128b0=Ou(_0x2ec954,_0x5ec688,_0x18b627['path'],_0x317c43,_0x4befa0,_0x13932d):_0x5128b0=Pu(_0x2ec954,_0x5ec688,_0x18b627['path'],_0x18b627['affectedTree'],_0x317c43,_0x4befa0,_0x13932d);}else{if(_0x396758['type']===z['LISTEN_COMPLETE'])_0x5128b0=Nu(_0x2ec954,_0x5ec688,_0x396758['path'],_0x317c43,_0x13932d);else throw ht('Unknown\x20operation\x20type:\x20'+_0x396758['type']);}}}const _0x54ed11=_0x13932d['getChanges']();return Au(_0x5ec688,_0x5128b0,_0x54ed11),{'viewCache':_0x5128b0,'changes':_0x54ed11};}function Au(_0x12b8bb,_0x1109ed,_0x8960ad){const _0x5dbadf=_0x1109ed['eventCache'];if(_0x5dbadf['isFullyInitialized']()){const _0x196051=_0x5dbadf['getNode']()['isLeafNode']()||_0x5dbadf['getNode']()['isEmpty'](),_0x2d6a72=wn(_0x12b8bb);(_0x8960ad['length']>0x0||!_0x12b8bb['eventCache']['isFullyInitialized']()||_0x196051&&!_0x5dbadf['getNode']()['equals'](_0x2d6a72)||!_0x5dbadf['getNode']()['getPriority']()['equals'](_0x2d6a72['getPriority']()))&&_0x8960ad['push'](Lo(wn(_0x1109ed)));}}function Go(_0x303997,_0x3bd9f9,_0x2c9bd4,_0x2d55dc,_0x5a2a9c,_0xffe2ac){const _0x10d288=_0x3bd9f9['eventCache'];if(Tn(_0x2d55dc,_0x2c9bd4)!=null)return _0x3bd9f9;{let _0x345e2b,_0x5c00eb;if(v(_0x2c9bd4)){if(f(_0x3bd9f9['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3bd9f9['serverCache']['isFiltered']()){const _0x88314f=Ve(_0x3bd9f9),_0x1155dc=_0x88314f instanceof g?_0x88314f:g['EMPTY_NODE'],_0x38a73d=is(_0x2d55dc,_0x1155dc);_0x345e2b=_0x303997['filter']['updateFullNode'](_0x3bd9f9['eventCache']['getNode'](),_0x38a73d,_0xffe2ac);}else{const _0x501cca=Cn(_0x2d55dc,Ve(_0x3bd9f9));_0x345e2b=_0x303997['filter']['updateFullNode'](_0x3bd9f9['eventCache']['getNode'](),_0x501cca,_0xffe2ac);}}else{const _0x5e234c=y(_0x2c9bd4);if(_0x5e234c==='.priority'){f(Ce(_0x2c9bd4)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x50d631=_0x10d288['getNode']();_0x5c00eb=_0x3bd9f9['serverCache']['getNode']();const _0x563215=cr(_0x2d55dc,_0x2c9bd4,_0x50d631,_0x5c00eb);_0x563215!=null?_0x345e2b=_0x303997['filter']['updatePriority'](_0x50d631,_0x563215):_0x345e2b=_0x10d288['getNode']();}else{const _0x22738e=S(_0x2c9bd4);let _0x5e1b36;if(_0x10d288['isCompleteForChild'](_0x5e234c)){_0x5c00eb=_0x3bd9f9['serverCache']['getNode']();const _0x153f89=cr(_0x2d55dc,_0x2c9bd4,_0x10d288['getNode'](),_0x5c00eb);_0x153f89!=null?_0x5e1b36=_0x10d288['getNode']()['getImmediateChild'](_0x5e234c)['updateChild'](_0x22738e,_0x153f89):_0x5e1b36=_0x10d288['getNode']()['getImmediateChild'](_0x5e234c);}else _0x5e1b36=ss(_0x2d55dc,_0x5e234c,_0x3bd9f9['serverCache']);_0x5e1b36!=null?_0x345e2b=_0x303997['filter']['updateChild'](_0x10d288['getNode'](),_0x5e234c,_0x5e1b36,_0x22738e,_0x5a2a9c,_0xffe2ac):_0x345e2b=_0x10d288['getNode']();}}return Rt(_0x3bd9f9,_0x345e2b,_0x10d288['isFullyInitialized']()||v(_0x2c9bd4),_0x303997['filter']['filtersNodes']());}}function Sn(_0x248d51,_0xf0e564,_0x411dcd,_0x31fde3,_0xecdf1,_0x3e205f,_0x37ccc3,_0x551312){const _0x55efd5=_0xf0e564['serverCache'];let _0x36395b;const _0x8d407=_0x37ccc3?_0x248d51['filter']:_0x248d51['filter']['getIndexedFilter']();if(v(_0x411dcd))_0x36395b=_0x8d407['updateFullNode'](_0x55efd5['getNode'](),_0x31fde3,null);else{if(_0x8d407['filtersNodes']()&&!_0x55efd5['isFiltered']()){const _0x1d2ae6=_0x55efd5['getNode']()['updateChild'](_0x411dcd,_0x31fde3);_0x36395b=_0x8d407['updateFullNode'](_0x55efd5['getNode'](),_0x1d2ae6,null);}else{const _0x4257db=y(_0x411dcd);if(!_0x55efd5['isCompleteForPath'](_0x411dcd)&&Ce(_0x411dcd)>0x1)return _0xf0e564;const _0x25ff7a=S(_0x411dcd),_0x439da7=_0x55efd5['getNode']()['getImmediateChild'](_0x4257db)['updateChild'](_0x25ff7a,_0x31fde3);_0x4257db==='.priority'?_0x36395b=_0x8d407['updatePriority'](_0x55efd5['getNode'](),_0x439da7):_0x36395b=_0x8d407['updateChild'](_0x55efd5['getNode'](),_0x4257db,_0x439da7,_0x25ff7a,$o,null);}}const _0x537662=Fo(_0xf0e564,_0x36395b,_0x55efd5['isFullyInitialized']()||v(_0x411dcd),_0x8d407['filtersNodes']()),_0x1349a9=new rs(_0xecdf1,_0x537662,_0x3e205f);return Go(_0x248d51,_0x537662,_0x411dcd,_0xecdf1,_0x1349a9,_0x551312);}function ki(_0x14b756,_0x53a74f,_0x5d3563,_0x18051e,_0x3fb8bd,_0xe82c18,_0x39dd0f){const _0x2bc918=_0x53a74f['eventCache'];let _0x2a102e,_0x781a22;const _0x439b6a=new rs(_0x3fb8bd,_0x53a74f,_0xe82c18);if(v(_0x5d3563))_0x781a22=_0x14b756['filter']['updateFullNode'](_0x53a74f['eventCache']['getNode'](),_0x18051e,_0x39dd0f),_0x2a102e=Rt(_0x53a74f,_0x781a22,!0x0,_0x14b756['filter']['filtersNodes']());else{const _0x1a375c=y(_0x5d3563);if(_0x1a375c==='.priority')_0x781a22=_0x14b756['filter']['updatePriority'](_0x53a74f['eventCache']['getNode'](),_0x18051e),_0x2a102e=Rt(_0x53a74f,_0x781a22,_0x2bc918['isFullyInitialized'](),_0x2bc918['isFiltered']());else{const _0xd4b14d=S(_0x5d3563),_0x4b25bf=_0x2bc918['getNode']()['getImmediateChild'](_0x1a375c);let _0x2484b3;if(v(_0xd4b14d))_0x2484b3=_0x18051e;else{const _0x56d8f3=_0x439b6a['getCompleteChild'](_0x1a375c);_0x56d8f3!=null?ji(_0xd4b14d)==='.priority'&&_0x56d8f3['getChild'](Ro(_0xd4b14d))['isEmpty']()?_0x2484b3=_0x56d8f3:_0x2484b3=_0x56d8f3['updateChild'](_0xd4b14d,_0x18051e):_0x2484b3=g['EMPTY_NODE'];}if(_0x4b25bf['equals'](_0x2484b3))_0x2a102e=_0x53a74f;else{const _0x5d1318=_0x14b756['filter']['updateChild'](_0x2bc918['getNode'](),_0x1a375c,_0x2484b3,_0xd4b14d,_0x439b6a,_0x39dd0f);_0x2a102e=Rt(_0x53a74f,_0x5d1318,_0x2bc918['isFullyInitialized'](),_0x14b756['filter']['filtersNodes']());}}}return _0x2a102e;}function lr(_0x1555cb,_0x2a3925){return _0x1555cb['eventCache']['isCompleteForChild'](_0x2a3925);}function ku(_0x5250d5,_0x2018e9,_0x3f11b8,_0x2fb868,_0xfa83e4,_0x3c1201,_0x411e54){let _0x40f1d4=_0x2018e9;return _0x2fb868['foreach']((_0x5c8394,_0x5849f0)=>{const _0x14e590=k(_0x3f11b8,_0x5c8394);lr(_0x2018e9,y(_0x14e590))&&(_0x40f1d4=ki(_0x5250d5,_0x40f1d4,_0x14e590,_0x5849f0,_0xfa83e4,_0x3c1201,_0x411e54));}),_0x2fb868['foreach']((_0x4ed711,_0x2d2703)=>{const _0x2f9b1f=k(_0x3f11b8,_0x4ed711);lr(_0x2018e9,y(_0x2f9b1f))||(_0x40f1d4=ki(_0x5250d5,_0x40f1d4,_0x2f9b1f,_0x2d2703,_0xfa83e4,_0x3c1201,_0x411e54));}),_0x40f1d4;}function hr(_0x163d55,_0x1183eb,_0x3d68a2){return _0x3d68a2['foreach']((_0x17042a,_0x229193)=>{_0x1183eb=_0x1183eb['updateChild'](_0x17042a,_0x229193);}),_0x1183eb;}function Pi(_0x3c2887,_0x422e18,_0x1aec50,_0x2e8812,_0x458b3a,_0x2f3804,_0x5b5603,_0x5d0ecd){if(_0x422e18['serverCache']['getNode']()['isEmpty']()&&!_0x422e18['serverCache']['isFullyInitialized']())return _0x422e18;let _0x4cb795=_0x422e18,_0x3659d6;v(_0x1aec50)?_0x3659d6=_0x2e8812:_0x3659d6=new b(null)['setTree'](_0x1aec50,_0x2e8812);const _0x331447=_0x422e18['serverCache']['getNode']();return _0x3659d6['children']['inorderTraversal']((_0xafe061,_0x51d3f8)=>{if(_0x331447['hasChild'](_0xafe061)){const _0x2b0f7e=_0x422e18['serverCache']['getNode']()['getImmediateChild'](_0xafe061),_0x4dc049=hr(_0x3c2887,_0x2b0f7e,_0x51d3f8);_0x4cb795=Sn(_0x3c2887,_0x4cb795,new C(_0xafe061),_0x4dc049,_0x458b3a,_0x2f3804,_0x5b5603,_0x5d0ecd);}}),_0x3659d6['children']['inorderTraversal']((_0xf2c3de,_0x179a21)=>{const _0x44d0ce=!_0x422e18['serverCache']['isCompleteForChild'](_0xf2c3de)&&_0x179a21['value']===null;if(!_0x331447['hasChild'](_0xf2c3de)&&!_0x44d0ce){const _0x3efe10=_0x422e18['serverCache']['getNode']()['getImmediateChild'](_0xf2c3de),_0x144d28=hr(_0x3c2887,_0x3efe10,_0x179a21);_0x4cb795=Sn(_0x3c2887,_0x4cb795,new C(_0xf2c3de),_0x144d28,_0x458b3a,_0x2f3804,_0x5b5603,_0x5d0ecd);}}),_0x4cb795;}function Pu(_0x5b2fbb,_0x4b1bcc,_0x487f9e,_0x58993b,_0x4701de,_0x4a011a,_0x2dfbf1){if(Tn(_0x4701de,_0x487f9e)!=null)return _0x4b1bcc;const _0x3f8feb=_0x4b1bcc['serverCache']['isFiltered'](),_0x5e316c=_0x4b1bcc['serverCache'];if(_0x58993b['value']!=null){if(v(_0x487f9e)&&_0x5e316c['isFullyInitialized']()||_0x5e316c['isCompleteForPath'](_0x487f9e))return Sn(_0x5b2fbb,_0x4b1bcc,_0x487f9e,_0x5e316c['getNode']()['getChild'](_0x487f9e),_0x4701de,_0x4a011a,_0x3f8feb,_0x2dfbf1);if(v(_0x487f9e)){let _0x512896=new b(null);return _0x5e316c['getNode']()['forEachChild'](ve,(_0x48672e,_0x54f3bc)=>{_0x512896=_0x512896['set'](new C(_0x48672e),_0x54f3bc);}),Pi(_0x5b2fbb,_0x4b1bcc,_0x487f9e,_0x512896,_0x4701de,_0x4a011a,_0x3f8feb,_0x2dfbf1);}else return _0x4b1bcc;}else{let _0x5e924d=new b(null);return _0x58993b['foreach']((_0x550b47,_0x115384)=>{const _0x4e1eca=k(_0x487f9e,_0x550b47);_0x5e316c['isCompleteForPath'](_0x4e1eca)&&(_0x5e924d=_0x5e924d['set'](_0x550b47,_0x5e316c['getNode']()['getChild'](_0x4e1eca)));}),Pi(_0x5b2fbb,_0x4b1bcc,_0x487f9e,_0x5e924d,_0x4701de,_0x4a011a,_0x3f8feb,_0x2dfbf1);}}function Nu(_0x2c195c,_0x1ceb5b,_0x2bf6a2,_0x48e83e,_0x5940eb){const _0x54c0f2=_0x1ceb5b['serverCache'],_0x4fdeac=Fo(_0x1ceb5b,_0x54c0f2['getNode'](),_0x54c0f2['isFullyInitialized']()||v(_0x2bf6a2),_0x54c0f2['isFiltered']());return Go(_0x2c195c,_0x4fdeac,_0x2bf6a2,_0x48e83e,$o,_0x5940eb);}function Ou(_0x2cd0a8,_0x5e6bc8,_0xc9cb0d,_0x5363c9,_0x8c066d,_0x4b080c){let _0x1504c8;if(Tn(_0x5363c9,_0xc9cb0d)!=null)return _0x5e6bc8;{const _0x54cf56=new rs(_0x5363c9,_0x5e6bc8,_0x8c066d),_0x89988e=_0x5e6bc8['eventCache']['getNode']();let _0x1920e5;if(v(_0xc9cb0d)||y(_0xc9cb0d)==='.priority'){let _0x3e1d55;if(_0x5e6bc8['serverCache']['isFullyInitialized']())_0x3e1d55=Cn(_0x5363c9,Ve(_0x5e6bc8));else{const _0x238d26=_0x5e6bc8['serverCache']['getNode']();f(_0x238d26 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3e1d55=is(_0x5363c9,_0x238d26);}_0x3e1d55=_0x3e1d55,_0x1920e5=_0x2cd0a8['filter']['updateFullNode'](_0x89988e,_0x3e1d55,_0x4b080c);}else{const _0x4c1d45=y(_0xc9cb0d);let _0xe6a5f3=ss(_0x5363c9,_0x4c1d45,_0x5e6bc8['serverCache']);_0xe6a5f3==null&&_0x5e6bc8['serverCache']['isCompleteForChild'](_0x4c1d45)&&(_0xe6a5f3=_0x89988e['getImmediateChild'](_0x4c1d45)),_0xe6a5f3!=null?_0x1920e5=_0x2cd0a8['filter']['updateChild'](_0x89988e,_0x4c1d45,_0xe6a5f3,S(_0xc9cb0d),_0x54cf56,_0x4b080c):_0x5e6bc8['eventCache']['getNode']()['hasChild'](_0x4c1d45)?_0x1920e5=_0x2cd0a8['filter']['updateChild'](_0x89988e,_0x4c1d45,g['EMPTY_NODE'],S(_0xc9cb0d),_0x54cf56,_0x4b080c):_0x1920e5=_0x89988e,_0x1920e5['isEmpty']()&&_0x5e6bc8['serverCache']['isFullyInitialized']()&&(_0x1504c8=Cn(_0x5363c9,Ve(_0x5e6bc8)),_0x1504c8['isLeafNode']()&&(_0x1920e5=_0x2cd0a8['filter']['updateFullNode'](_0x1920e5,_0x1504c8,_0x4b080c)));}return _0x1504c8=_0x5e6bc8['serverCache']['isFullyInitialized']()||Tn(_0x5363c9,w())!=null,Rt(_0x5e6bc8,_0x1920e5,_0x1504c8,_0x2cd0a8['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x2c5139,_0x624d66){this['query_']=_0x2c5139,this['eventRegistrations_']=[];const _0x4e2146=this['query_']['_queryParams'],_0x5b310a=new Xi(_0x4e2146['getIndex']()),_0x1410ac=Kh(_0x4e2146);this['processor_']=Su(_0x1410ac);const _0x3fe9b3=_0x624d66['serverCache'],_0x16abcc=_0x624d66['eventCache'],_0x37864a=_0x5b310a['updateFullNode'](g['EMPTY_NODE'],_0x3fe9b3['getNode'](),null),_0x1d0a18=_0x1410ac['updateFullNode'](g['EMPTY_NODE'],_0x16abcc['getNode'](),null),_0x157eaa=new Te(_0x37864a,_0x3fe9b3['isFullyInitialized'](),_0x5b310a['filtersNodes']()),_0x2858be=new Te(_0x1d0a18,_0x16abcc['isFullyInitialized'](),_0x1410ac['filtersNodes']());this['viewCache_']=Un(_0x2858be,_0x157eaa),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x11717e){return _0x11717e['viewCache_']['serverCache']['getNode']();}function Lu(_0x5b22ce){return wn(_0x5b22ce['viewCache_']);}function xu(_0x589ec4,_0x4bafaf){const _0xbbfe03=Ve(_0x589ec4['viewCache_']);return _0xbbfe03&&(_0x589ec4['query']['_queryParams']['loadsAllData']()||!v(_0x4bafaf)&&!_0xbbfe03['getImmediateChild'](y(_0x4bafaf))['isEmpty']())?_0xbbfe03['getChild'](_0x4bafaf):null;}function ur(_0x110178){return _0x110178['eventRegistrations_']['length']===0x0;}function Fu(_0x172ce5,_0xeb27f0){_0x172ce5['eventRegistrations_']['push'](_0xeb27f0);}function dr(_0x48c1b1,_0x235eb5,_0x3b9802){const _0x3a99cf=[];if(_0x3b9802){f(_0x235eb5==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x262fe7=_0x48c1b1['query']['_path'];_0x48c1b1['eventRegistrations_']['forEach'](_0x107e03=>{const _0x4fa4a8=_0x107e03['createCancelEvent'](_0x3b9802,_0x262fe7);_0x4fa4a8&&_0x3a99cf['push'](_0x4fa4a8);});}if(_0x235eb5){let _0x36eba7=[];for(let _0x2c8ca5=0x0;_0x2c8ca5<_0x48c1b1['eventRegistrations_']['length'];++_0x2c8ca5){const _0x410095=_0x48c1b1['eventRegistrations_'][_0x2c8ca5];if(!_0x410095['matches'](_0x235eb5))_0x36eba7['push'](_0x410095);else{if(_0x235eb5['hasAnyCallback']()){_0x36eba7=_0x36eba7['concat'](_0x48c1b1['eventRegistrations_']['slice'](_0x2c8ca5+0x1));break;}}}_0x48c1b1['eventRegistrations_']=_0x36eba7;}else _0x48c1b1['eventRegistrations_']=[];return _0x3a99cf;}function fr(_0x2fc83e,_0x418727,_0x546ac5,_0x1869a5){_0x418727['type']===z['MERGE']&&_0x418727['source']['queryId']!==null&&(f(Ve(_0x2fc83e['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x2fc83e['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x45a9ef=_0x2fc83e['viewCache_'],_0x11c8c8=Ru(_0x2fc83e['processor_'],_0x45a9ef,_0x418727,_0x546ac5,_0x1869a5);return bu(_0x2fc83e['processor_'],_0x11c8c8['viewCache']),f(_0x11c8c8['viewCache']['serverCache']['isFullyInitialized']()||!_0x45a9ef['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2fc83e['viewCache_']=_0x11c8c8['viewCache'],qo(_0x2fc83e,_0x11c8c8['changes'],_0x11c8c8['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x49d7cb,_0x4269ef){const _0x3578fb=_0x49d7cb['viewCache_']['eventCache'],_0x2ba48f=[];return _0x3578fb['getNode']()['isLeafNode']()||_0x3578fb['getNode']()['forEachChild'](R,(_0x30b9c7,_0x357fbf)=>{_0x2ba48f['push'](rt(_0x30b9c7,_0x357fbf));}),_0x3578fb['isFullyInitialized']()&&_0x2ba48f['push'](Lo(_0x3578fb['getNode']())),qo(_0x49d7cb,_0x2ba48f,_0x3578fb['getNode'](),_0x4269ef);}function qo(_0x5272e4,_0xa66a0a,_0x4a3397,_0x2505a9){const _0x38db53=_0x2505a9?[_0x2505a9]:_0x5272e4['eventRegistrations_'];return ru(_0x5272e4['eventGenerator_'],_0xa66a0a,_0x4a3397,_0x38db53);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x49326c){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x49326c;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x5b94a4){return _0x5b94a4['views']['size']===0x0;}function os(_0x59fc32,_0x491188,_0xff8a24,_0x5ef008){const _0x351e1c=_0x491188['source']['queryId'];if(_0x351e1c!==null){const _0xfa8d40=_0x59fc32['views']['get'](_0x351e1c);return f(_0xfa8d40!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0xfa8d40,_0x491188,_0xff8a24,_0x5ef008);}else{let _0x2b6736=[];for(const _0x39a784 of _0x59fc32['views']['values']())_0x2b6736=_0x2b6736['concat'](fr(_0x39a784,_0x491188,_0xff8a24,_0x5ef008));return _0x2b6736;}}function jo(_0x1dca0d,_0x1df178,_0x25c7aa,_0x5d9d7e,_0x50843a){const _0x2d0ddf=_0x1df178['_queryIdentifier'],_0xc64d59=_0x1dca0d['views']['get'](_0x2d0ddf);if(!_0xc64d59){let _0x57640d=Cn(_0x25c7aa,_0x50843a?_0x5d9d7e:null),_0x310671=!0x1;_0x57640d?_0x310671=!0x0:_0x5d9d7e instanceof g?(_0x57640d=is(_0x25c7aa,_0x5d9d7e),_0x310671=!0x1):(_0x57640d=g['EMPTY_NODE'],_0x310671=!0x1);const _0x12fff5=Un(new Te(_0x57640d,_0x310671,!0x1),new Te(_0x5d9d7e,_0x50843a,!0x1));return new Du(_0x1df178,_0x12fff5);}return _0xc64d59;}function Hu(_0xd220b,_0x20acae,_0x2231d4,_0xd44eca,_0x2ab593,_0x1b8a07){const _0x5b2f0f=jo(_0xd220b,_0x20acae,_0xd44eca,_0x2ab593,_0x1b8a07);return _0xd220b['views']['has'](_0x20acae['_queryIdentifier'])||_0xd220b['views']['set'](_0x20acae['_queryIdentifier'],_0x5b2f0f),Fu(_0x5b2f0f,_0x2231d4),Uu(_0x5b2f0f,_0x2231d4);}function $u(_0x2609d2,_0x45c5bb,_0x349822,_0x4dc456){const _0x5ee067=_0x45c5bb['_queryIdentifier'],_0x4e24df=[];let _0x1c7b47=[];const _0x55a944=Se(_0x2609d2);if(_0x5ee067==='default'){for(const [_0xb4fde6,_0x58b310]of _0x2609d2['views']['entries']())_0x1c7b47=_0x1c7b47['concat'](dr(_0x58b310,_0x349822,_0x4dc456)),ur(_0x58b310)&&(_0x2609d2['views']['delete'](_0xb4fde6),_0x58b310['query']['_queryParams']['loadsAllData']()||_0x4e24df['push'](_0x58b310['query']));}else{const _0xbc2470=_0x2609d2['views']['get'](_0x5ee067);_0xbc2470&&(_0x1c7b47=_0x1c7b47['concat'](dr(_0xbc2470,_0x349822,_0x4dc456)),ur(_0xbc2470)&&(_0x2609d2['views']['delete'](_0x5ee067),_0xbc2470['query']['_queryParams']['loadsAllData']()||_0x4e24df['push'](_0xbc2470['query'])));}return _0x55a944&&!Se(_0x2609d2)&&_0x4e24df['push'](new(Bu())(_0x45c5bb['_repo'],_0x45c5bb['_path'])),{'removed':_0x4e24df,'events':_0x1c7b47};}function Ko(_0x44b129){const _0x165e5f=[];for(const _0x4c7185 of _0x44b129['views']['values']())_0x4c7185['query']['_queryParams']['loadsAllData']()||_0x165e5f['push'](_0x4c7185);return _0x165e5f;}function Ie(_0x543e00,_0x13ce45){let _0xf70ddd=null;for(const _0x6488f7 of _0x543e00['views']['values']())_0xf70ddd=_0xf70ddd||xu(_0x6488f7,_0x13ce45);return _0xf70ddd;}function Yo(_0x223afc,_0x2600a0){if(_0x2600a0['_queryParams']['loadsAllData']())return Bn(_0x223afc);{const _0x3b3d38=_0x2600a0['_queryIdentifier'];return _0x223afc['views']['get'](_0x3b3d38);}}function Qo(_0x39ef5a,_0x5e5975){return Yo(_0x39ef5a,_0x5e5975)!=null;}function Se(_0x5a8371){return Bn(_0x5a8371)!=null;}function Bn(_0xee1803){for(const _0x12a291 of _0xee1803['views']['values']())if(_0x12a291['query']['_queryParams']['loadsAllData']())return _0x12a291;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x16e4d9){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x16e4d9;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x5024bb){this['listenProvider_']=_0x5024bb,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x24c31a,_0x4c12e0,_0x1fd9b4,_0x39c6e6,_0x4dcdbb){return lu(_0x24c31a['pendingWriteTree_'],_0x4c12e0,_0x1fd9b4,_0x39c6e6,_0x4dcdbb),_0x4dcdbb?_t(_0x24c31a,new Be(es(),_0x4c12e0,_0x1fd9b4)):[];}function ju(_0x1e5e6c,_0x48c863,_0x5ebdad,_0x2a943b){hu(_0x1e5e6c['pendingWriteTree_'],_0x48c863,_0x5ebdad,_0x2a943b);const _0x3b5858=b['fromObject'](_0x5ebdad);return _t(_0x1e5e6c,new ot(es(),_0x48c863,_0x3b5858));}function _e(_0x2e6fd1,_0x18bfbf,_0x4af7bb=!0x1){const _0x16f0a2=uu(_0x2e6fd1['pendingWriteTree_'],_0x18bfbf);if(du(_0x2e6fd1['pendingWriteTree_'],_0x18bfbf)){let _0x1236d8=new b(null);return _0x16f0a2['snap']!=null?_0x1236d8=_0x1236d8['set'](w(),!0x0):x(_0x16f0a2['children'],_0x36705a=>{_0x1236d8=_0x1236d8['set'](new C(_0x36705a),!0x0);}),_t(_0x2e6fd1,new In(_0x16f0a2['path'],_0x1236d8,_0x4af7bb));}else return[];}function Yt(_0x1d22fb,_0x479c08,_0x3ed18c){return _t(_0x1d22fb,new Be(ts(),_0x479c08,_0x3ed18c));}function Ku(_0x4e17f3,_0x42a1bb,_0x286936){const _0x232f41=b['fromObject'](_0x286936);return _t(_0x4e17f3,new ot(ts(),_0x42a1bb,_0x232f41));}function Yu(_0x34bb1b,_0xd2ed32){return _t(_0x34bb1b,new Ut(ts(),_0xd2ed32));}function Qu(_0x549a26,_0x33a31c,_0x146afb){const _0x3112a6=cs(_0x549a26,_0x146afb);if(_0x3112a6){const _0x384d0b=ls(_0x3112a6),_0x5708d1=_0x384d0b['path'],_0x9b5c74=_0x384d0b['queryId'],_0x2ca2b5=F(_0x5708d1,_0x33a31c),_0x4173c2=new Ut(ns(_0x9b5c74),_0x2ca2b5);return hs(_0x549a26,_0x5708d1,_0x4173c2);}else return[];}function An(_0x14dc16,_0x279a2a,_0x3d1520,_0xfee903,_0x1428eb=!0x1){const _0x1e43a3=_0x279a2a['_path'],_0x3cc825=_0x14dc16['syncPointTree_']['get'](_0x1e43a3);let _0x536c65=[];if(_0x3cc825&&(_0x279a2a['_queryIdentifier']==='default'||Qo(_0x3cc825,_0x279a2a))){const _0x1c265e=$u(_0x3cc825,_0x279a2a,_0x3d1520,_0xfee903);Vu(_0x3cc825)&&(_0x14dc16['syncPointTree_']=_0x14dc16['syncPointTree_']['remove'](_0x1e43a3));const _0x3800ec=_0x1c265e['removed'];if(_0x536c65=_0x1c265e['events'],!_0x1428eb){const _0x17d2b4=_0x3800ec['findIndex'](_0x4c88a4=>_0x4c88a4['_queryParams']['loadsAllData']())!==-0x1,_0x181ea2=_0x14dc16['syncPointTree_']['findOnPath'](_0x1e43a3,(_0x191cb4,_0x5259ed)=>Se(_0x5259ed));if(_0x17d2b4&&!_0x181ea2){const _0xba26fb=_0x14dc16['syncPointTree_']['subtree'](_0x1e43a3);if(!_0xba26fb['isEmpty']()){const _0x1259bb=Zu(_0xba26fb);for(let _0x3cf1c1=0x0;_0x3cf1c1<_0x1259bb['length'];++_0x3cf1c1){const _0x452e97=_0x1259bb[_0x3cf1c1],_0x306a30=_0x452e97['query'],_0x305d1f=ea(_0x14dc16,_0x452e97);_0x14dc16['listenProvider_']['startListening'](kt(_0x306a30),Wt(_0x14dc16,_0x306a30),_0x305d1f['hashFn'],_0x305d1f['onComplete']);}}}!_0x181ea2&&_0x3800ec['length']>0x0&&!_0xfee903&&(_0x17d2b4?_0x14dc16['listenProvider_']['stopListening'](kt(_0x279a2a),null):_0x3800ec['forEach'](_0x2ca88f=>{const _0x2eb7dc=_0x14dc16['queryToTagMap']['get'](Hn(_0x2ca88f));_0x14dc16['listenProvider_']['stopListening'](kt(_0x2ca88f),_0x2eb7dc);}));}ed(_0x14dc16,_0x3800ec);}return _0x536c65;}function Jo(_0x2fdc20,_0xaa5ed2,_0x125816,_0x49be19){const _0x1c62b1=cs(_0x2fdc20,_0x49be19);if(_0x1c62b1!=null){const _0x5a3ed3=ls(_0x1c62b1),_0x599bc3=_0x5a3ed3['path'],_0x3cd3ab=_0x5a3ed3['queryId'],_0x1ac297=F(_0x599bc3,_0xaa5ed2),_0x3075f3=new Be(ns(_0x3cd3ab),_0x1ac297,_0x125816);return hs(_0x2fdc20,_0x599bc3,_0x3075f3);}else return[];}function Ju(_0x3cd8b6,_0x1f98f2,_0x410ef8,_0x4ef103){const _0x8607b6=cs(_0x3cd8b6,_0x4ef103);if(_0x8607b6){const _0x50e663=ls(_0x8607b6),_0x1de068=_0x50e663['path'],_0x99b5b8=_0x50e663['queryId'],_0x572bda=F(_0x1de068,_0x1f98f2),_0x218611=b['fromObject'](_0x410ef8),_0x37c255=new ot(ns(_0x99b5b8),_0x572bda,_0x218611);return hs(_0x3cd8b6,_0x1de068,_0x37c255);}else return[];}function Ni(_0x16744a,_0x73bfd2,_0x38a3b1,_0x3181e8=!0x1){const _0x37e092=_0x73bfd2['_path'];let _0x5a04b9=null,_0x275d74=!0x1;_0x16744a['syncPointTree_']['foreachOnPath'](_0x37e092,(_0x5a93ba,_0x284f0b)=>{const _0x2ba112=F(_0x5a93ba,_0x37e092);_0x5a04b9=_0x5a04b9||Ie(_0x284f0b,_0x2ba112),_0x275d74=_0x275d74||Se(_0x284f0b);});let _0xa96125=_0x16744a['syncPointTree_']['get'](_0x37e092);_0xa96125?(_0x275d74=_0x275d74||Se(_0xa96125),_0x5a04b9=_0x5a04b9||Ie(_0xa96125,w())):(_0xa96125=new zo(),_0x16744a['syncPointTree_']=_0x16744a['syncPointTree_']['set'](_0x37e092,_0xa96125));let _0x2cafe5;_0x5a04b9!=null?_0x2cafe5=!0x0:(_0x2cafe5=!0x1,_0x5a04b9=g['EMPTY_NODE'],_0x16744a['syncPointTree_']['subtree'](_0x37e092)['foreachChild']((_0x2f2616,_0x3b1c8c)=>{const _0x701ead=Ie(_0x3b1c8c,w());_0x701ead&&(_0x5a04b9=_0x5a04b9['updateImmediateChild'](_0x2f2616,_0x701ead));}));const _0x41f5bc=Qo(_0xa96125,_0x73bfd2);if(!_0x41f5bc&&!_0x73bfd2['_queryParams']['loadsAllData']()){const _0x50d42a=Hn(_0x73bfd2);f(!_0x16744a['queryToTagMap']['has'](_0x50d42a),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1e32a1=td();_0x16744a['queryToTagMap']['set'](_0x50d42a,_0x1e32a1),_0x16744a['tagToQueryMap']['set'](_0x1e32a1,_0x50d42a);}const _0x51f157=Wn(_0x16744a['pendingWriteTree_'],_0x37e092);let _0x4eb354=Hu(_0xa96125,_0x73bfd2,_0x38a3b1,_0x51f157,_0x5a04b9,_0x2cafe5);if(!_0x41f5bc&&!_0x275d74&&!_0x3181e8){const _0x2e62bb=Yo(_0xa96125,_0x73bfd2);_0x4eb354=_0x4eb354['concat'](nd(_0x16744a,_0x73bfd2,_0x2e62bb));}return _0x4eb354;}function Vn(_0x4ae49,_0x347aa1,_0x39dc8c){const _0x57a40a=_0x4ae49['pendingWriteTree_'],_0x49586a=_0x4ae49['syncPointTree_']['findOnPath'](_0x347aa1,(_0x229d63,_0x9957d)=>{const _0x5f366d=F(_0x229d63,_0x347aa1),_0x4486f5=Ie(_0x9957d,_0x5f366d);if(_0x4486f5)return _0x4486f5;});return Bo(_0x57a40a,_0x347aa1,_0x49586a,_0x39dc8c,!0x0);}function Xu(_0x436a11,_0x436beb){const _0x857c6f=_0x436beb['_path'];let _0x3fa5c6=null;_0x436a11['syncPointTree_']['foreachOnPath'](_0x857c6f,(_0xc5b21f,_0xd2bac3)=>{const _0x238fc3=F(_0xc5b21f,_0x857c6f);_0x3fa5c6=_0x3fa5c6||Ie(_0xd2bac3,_0x238fc3);});let _0x14434e=_0x436a11['syncPointTree_']['get'](_0x857c6f);_0x14434e?_0x3fa5c6=_0x3fa5c6||Ie(_0x14434e,w()):(_0x14434e=new zo(),_0x436a11['syncPointTree_']=_0x436a11['syncPointTree_']['set'](_0x857c6f,_0x14434e));const _0x1b74ce=_0x3fa5c6!=null,_0x4c7a58=_0x1b74ce?new Te(_0x3fa5c6,!0x0,!0x1):null,_0x59658a=Wn(_0x436a11['pendingWriteTree_'],_0x436beb['_path']),_0x48acab=jo(_0x14434e,_0x436beb,_0x59658a,_0x1b74ce?_0x4c7a58['getNode']():g['EMPTY_NODE'],_0x1b74ce);return Lu(_0x48acab);}function _t(_0x3b12da,_0x1b1365){return Xo(_0x1b1365,_0x3b12da['syncPointTree_'],null,Wn(_0x3b12da['pendingWriteTree_'],w()));}function Xo(_0x486b3a,_0x138375,_0x59ab05,_0x1372bf){if(v(_0x486b3a['path']))return Zo(_0x486b3a,_0x138375,_0x59ab05,_0x1372bf);{const _0x4bf3c9=_0x138375['get'](w());_0x59ab05==null&&_0x4bf3c9!=null&&(_0x59ab05=Ie(_0x4bf3c9,w()));let _0x357fd4=[];const _0x3b6f06=y(_0x486b3a['path']),_0xa580b=_0x486b3a['operationForChild'](_0x3b6f06),_0x101f8f=_0x138375['children']['get'](_0x3b6f06);if(_0x101f8f&&_0xa580b){const _0xb53cfd=_0x59ab05?_0x59ab05['getImmediateChild'](_0x3b6f06):null,_0x4eae58=Vo(_0x1372bf,_0x3b6f06);_0x357fd4=_0x357fd4['concat'](Xo(_0xa580b,_0x101f8f,_0xb53cfd,_0x4eae58));}return _0x4bf3c9&&(_0x357fd4=_0x357fd4['concat'](os(_0x4bf3c9,_0x486b3a,_0x1372bf,_0x59ab05))),_0x357fd4;}}function Zo(_0x258e6d,_0x557698,_0x254bca,_0x1b0f26){const _0x43f0b6=_0x557698['get'](w());_0x254bca==null&&_0x43f0b6!=null&&(_0x254bca=Ie(_0x43f0b6,w()));let _0x3982cd=[];return _0x557698['children']['inorderTraversal']((_0x27f18e,_0x2e1ac6)=>{const _0x37e027=_0x254bca?_0x254bca['getImmediateChild'](_0x27f18e):null,_0x6fcbf8=Vo(_0x1b0f26,_0x27f18e),_0x5ef3b8=_0x258e6d['operationForChild'](_0x27f18e);_0x5ef3b8&&(_0x3982cd=_0x3982cd['concat'](Zo(_0x5ef3b8,_0x2e1ac6,_0x37e027,_0x6fcbf8)));}),_0x43f0b6&&(_0x3982cd=_0x3982cd['concat'](os(_0x43f0b6,_0x258e6d,_0x1b0f26,_0x254bca))),_0x3982cd;}function ea(_0x274ee3,_0x3d5717){const _0x506ebc=_0x3d5717['query'],_0x46dd26=Wt(_0x274ee3,_0x506ebc);return{'hashFn':()=>(Mu(_0x3d5717)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x121fae=>{if(_0x121fae==='ok')return _0x46dd26?Qu(_0x274ee3,_0x506ebc['_path'],_0x46dd26):Yu(_0x274ee3,_0x506ebc['_path']);{const _0x7216b=Kl(_0x121fae,_0x506ebc);return An(_0x274ee3,_0x506ebc,null,_0x7216b);}}};}function Wt(_0x4a286d,_0x15c105){const _0x1d4762=Hn(_0x15c105);return _0x4a286d['queryToTagMap']['get'](_0x1d4762);}function Hn(_0x585388){return _0x585388['_path']['toString']()+'$'+_0x585388['_queryIdentifier'];}function cs(_0x4dc2be,_0x359943){return _0x4dc2be['tagToQueryMap']['get'](_0x359943);}function ls(_0x53215a){const _0x238e80=_0x53215a['indexOf']('$');return f(_0x238e80!==-0x1&&_0x238e80<_0x53215a['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x53215a['substr'](_0x238e80+0x1),'path':new C(_0x53215a['substr'](0x0,_0x238e80))};}function hs(_0x481a37,_0x5e9e4d,_0x190dad){const _0x13a4ff=_0x481a37['syncPointTree_']['get'](_0x5e9e4d);f(_0x13a4ff,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x25b41b=Wn(_0x481a37['pendingWriteTree_'],_0x5e9e4d);return os(_0x13a4ff,_0x190dad,_0x25b41b,null);}function Zu(_0x502c13){return _0x502c13['fold']((_0x34cdc6,_0xe8e7,_0x5f0b95)=>{if(_0xe8e7&&Se(_0xe8e7))return[Bn(_0xe8e7)];{let _0x300cbe=[];return _0xe8e7&&(_0x300cbe=Ko(_0xe8e7)),x(_0x5f0b95,(_0x2938e5,_0x200dcc)=>{_0x300cbe=_0x300cbe['concat'](_0x200dcc);}),_0x300cbe;}});}function kt(_0x23d707){return _0x23d707['_queryParams']['loadsAllData']()&&!_0x23d707['_queryParams']['isDefault']()?new(qu())(_0x23d707['_repo'],_0x23d707['_path']):_0x23d707;}function ed(_0xab9777,_0x4a3664){for(let _0x57908b=0x0;_0x57908b<_0x4a3664['length'];++_0x57908b){const _0x468590=_0x4a3664[_0x57908b];if(!_0x468590['_queryParams']['loadsAllData']()){const _0x326f54=Hn(_0x468590),_0x3e2c9a=_0xab9777['queryToTagMap']['get'](_0x326f54);_0xab9777['queryToTagMap']['delete'](_0x326f54),_0xab9777['tagToQueryMap']['delete'](_0x3e2c9a);}}}function td(){return zu++;}function nd(_0x3085da,_0x2183e6,_0x5464b8){const _0x4ff0a0=_0x2183e6['_path'],_0x5e90cb=Wt(_0x3085da,_0x2183e6),_0x3cec70=ea(_0x3085da,_0x5464b8),_0x2914f5=_0x3085da['listenProvider_']['startListening'](kt(_0x2183e6),_0x5e90cb,_0x3cec70['hashFn'],_0x3cec70['onComplete']),_0x14e786=_0x3085da['syncPointTree_']['subtree'](_0x4ff0a0);if(_0x5e90cb)f(!Se(_0x14e786['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3ec6a4=_0x14e786['fold']((_0x126c66,_0x7814ef,_0x13012b)=>{if(!v(_0x126c66)&&_0x7814ef&&Se(_0x7814ef))return[Bn(_0x7814ef)['query']];{let _0x391eb9=[];return _0x7814ef&&(_0x391eb9=_0x391eb9['concat'](Ko(_0x7814ef)['map'](_0x2720ff=>_0x2720ff['query']))),x(_0x13012b,(_0x1fd4ef,_0x421612)=>{_0x391eb9=_0x391eb9['concat'](_0x421612);}),_0x391eb9;}});for(let _0xa91f4=0x0;_0xa91f4<_0x3ec6a4['length'];++_0xa91f4){const _0x1b856b=_0x3ec6a4[_0xa91f4];_0x3085da['listenProvider_']['stopListening'](kt(_0x1b856b),Wt(_0x3085da,_0x1b856b));}}return _0x2914f5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x21cd32){this['node_']=_0x21cd32;}['getImmediateChild'](_0x3a0d89){const _0x150f40=this['node_']['getImmediateChild'](_0x3a0d89);return new us(_0x150f40);}['node'](){return this['node_'];}}class ds{constructor(_0x2aa1bd,_0x5a4846){this['syncTree_']=_0x2aa1bd,this['path_']=_0x5a4846;}['getImmediateChild'](_0xefb827){const _0x1d9010=k(this['path_'],_0xefb827);return new ds(this['syncTree_'],_0x1d9010);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x3df4f4){return _0x3df4f4=_0x3df4f4||{},_0x3df4f4['timestamp']=_0x3df4f4['timestamp']||new Date()['getTime'](),_0x3df4f4;},_r=function(_0x19a81e,_0x1aceb9,_0x1e99e9){if(!_0x19a81e||typeof _0x19a81e!='object')return _0x19a81e;if(f('.sv'in _0x19a81e,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x19a81e['.sv']=='string')return sd(_0x19a81e['.sv'],_0x1aceb9,_0x1e99e9);if(typeof _0x19a81e['.sv']=='object')return rd(_0x19a81e['.sv'],_0x1aceb9);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x19a81e,null,0x2));},sd=function(_0x454a9a,_0x296976,_0x83d775){switch(_0x454a9a){case'timestamp':return _0x83d775['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x454a9a);}},rd=function(_0x84ea97,_0x12a841,_0x396251){_0x84ea97['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x84ea97,null,0x2));const _0x1a6d88=_0x84ea97['increment'];typeof _0x1a6d88!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1a6d88);const _0x1b0bbf=_0x12a841['node']();if(f(_0x1b0bbf!==null&&typeof _0x1b0bbf<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1b0bbf['isLeafNode']())return _0x1a6d88;const _0x4ac067=_0x1b0bbf['getValue']();return typeof _0x4ac067!='number'?_0x1a6d88:_0x4ac067+_0x1a6d88;},ta=function(_0x97ecf,_0xf82d8f,_0x51b247,_0x5210f0){return ps(_0xf82d8f,new ds(_0x51b247,_0x97ecf),_0x5210f0);},fs=function(_0x53b303,_0x5a80bd,_0x17b5ba){return ps(_0x53b303,new us(_0x5a80bd),_0x17b5ba);};function ps(_0x129792,_0x580bd8,_0x4c526e){const _0x332366=_0x129792['getPriority']()['val'](),_0x2d432d=_r(_0x332366,_0x580bd8['getImmediateChild']('.priority'),_0x4c526e);let _0x2177df;if(_0x129792['isLeafNode']()){const _0x2fccef=_0x129792,_0x220b64=_r(_0x2fccef['getValue'](),_0x580bd8,_0x4c526e);return _0x220b64!==_0x2fccef['getValue']()||_0x2d432d!==_0x2fccef['getPriority']()['val']()?new D(_0x220b64,A(_0x2d432d)):_0x129792;}else{const _0x17c20=_0x129792;return _0x2177df=_0x17c20,_0x2d432d!==_0x17c20['getPriority']()['val']()&&(_0x2177df=_0x2177df['updatePriority'](new D(_0x2d432d))),_0x17c20['forEachChild'](R,(_0x3d9ef8,_0x2e54e1)=>{const _0x913cc7=ps(_0x2e54e1,_0x580bd8['getImmediateChild'](_0x3d9ef8),_0x4c526e);_0x913cc7!==_0x2e54e1&&(_0x2177df=_0x2177df['updateImmediateChild'](_0x3d9ef8,_0x913cc7));}),_0x2177df;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x48c60a='',_0x4a47b4=null,_0x24a6f7={'children':{},'childCount':0x0}){this['name']=_0x48c60a,this['parent']=_0x4a47b4,this['node']=_0x24a6f7;}}function $n(_0x4acf94,_0x18144d){let _0x1f016b=_0x18144d instanceof C?_0x18144d:new C(_0x18144d),_0x22db92=_0x4acf94,_0x446fd6=y(_0x1f016b);for(;_0x446fd6!==null;){const _0x5c1682=Le(_0x22db92['node']['children'],_0x446fd6)||{'children':{},'childCount':0x0};_0x22db92=new _s(_0x446fd6,_0x22db92,_0x5c1682),_0x1f016b=S(_0x1f016b),_0x446fd6=y(_0x1f016b);}return _0x22db92;}function je(_0x34bbb8){return _0x34bbb8['node']['value'];}function gs(_0x3809a0,_0xe23e82){_0x3809a0['node']['value']=_0xe23e82,Oi(_0x3809a0);}function na(_0x128f66){return _0x128f66['node']['childCount']>0x0;}function od(_0x124f84){return je(_0x124f84)===void 0x0&&!na(_0x124f84);}function Gn(_0x2869ec,_0xe99e1f){x(_0x2869ec['node']['children'],(_0x3790f1,_0x4eeb9f)=>{_0xe99e1f(new _s(_0x3790f1,_0x2869ec,_0x4eeb9f));});}function ia(_0x1adeac,_0x5f15f3,_0x4ae3eb,_0x21454e){_0x4ae3eb&&_0x5f15f3(_0x1adeac),Gn(_0x1adeac,_0x1e60fb=>{ia(_0x1e60fb,_0x5f15f3,!0x0);});}function ad(_0x35cc84,_0x52598d,_0x254696){let _0x290aab=_0x35cc84['parent'];for(;_0x290aab!==null;){if(_0x52598d(_0x290aab))return!0x0;_0x290aab=_0x290aab['parent'];}return!0x1;}function Qt(_0x2c156e){return new C(_0x2c156e['parent']===null?_0x2c156e['name']:Qt(_0x2c156e['parent'])+'/'+_0x2c156e['name']);}function Oi(_0x221994){_0x221994['parent']!==null&&cd(_0x221994['parent'],_0x221994['name'],_0x221994);}function cd(_0x208c31,_0x16a66a,_0x527502){const _0x14ce2c=od(_0x527502),_0x5220e0=Q(_0x208c31['node']['children'],_0x16a66a);_0x14ce2c&&_0x5220e0?(delete _0x208c31['node']['children'][_0x16a66a],_0x208c31['node']['childCount']--,Oi(_0x208c31)):!_0x14ce2c&&!_0x5220e0&&(_0x208c31['node']['children'][_0x16a66a]=_0x527502['node'],_0x208c31['node']['childCount']++,Oi(_0x208c31));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x725ed3){return typeof _0x725ed3=='string'&&_0x725ed3['length']!==0x0&&!ld['test'](_0x725ed3);},sa=function(_0x40f8b2){return typeof _0x40f8b2=='string'&&_0x40f8b2['length']!==0x0&&!hd['test'](_0x40f8b2);},ud=function(_0xc2981e){return _0xc2981e&&(_0xc2981e=_0xc2981e['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0xc2981e);},Bt=function(_0x3589f4){return _0x3589f4===null||typeof _0x3589f4=='string'||typeof _0x3589f4=='number'&&!xn(_0x3589f4)||_0x3589f4&&typeof _0x3589f4=='object'&&Q(_0x3589f4,'.sv');},He=function(_0x3054a6,_0x575e83,_0x3cc561,_0x2a9e7e){_0x2a9e7e&&_0x575e83===void 0x0||Jt(it(_0x3054a6,'value'),_0x575e83,_0x3cc561);},Jt=function(_0x239306,_0x31991b,_0xb759ed){const _0x113eb9=_0xb759ed instanceof C?new Ah(_0xb759ed,_0x239306):_0xb759ed;if(_0x31991b===void 0x0)throw new Error(_0x239306+'contains\x20undefined\x20'+Oe(_0x113eb9));if(typeof _0x31991b=='function')throw new Error(_0x239306+'contains\x20a\x20function\x20'+Oe(_0x113eb9)+'\x20with\x20contents\x20=\x20'+_0x31991b['toString']());if(xn(_0x31991b))throw new Error(_0x239306+'contains\x20'+_0x31991b['toString']()+'\x20'+Oe(_0x113eb9));if(typeof _0x31991b=='string'&&_0x31991b['length']>ui/0x3&&Ln(_0x31991b)>ui)throw new Error(_0x239306+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x113eb9)+'\x20(\x27'+_0x31991b['substring'](0x0,0x32)+'...\x27)');if(_0x31991b&&typeof _0x31991b=='object'){let _0x23ab24=!0x1,_0x113fe4=!0x1;if(x(_0x31991b,(_0x394166,_0x1fb807)=>{if(_0x394166==='.value')_0x23ab24=!0x0;else{if(_0x394166!=='.priority'&&_0x394166!=='.sv'&&(_0x113fe4=!0x0,!ms(_0x394166)))throw new Error(_0x239306+'\x20contains\x20an\x20invalid\x20key\x20('+_0x394166+')\x20'+Oe(_0x113eb9)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x113eb9,_0x394166),Jt(_0x239306,_0x1fb807,_0x113eb9),Ph(_0x113eb9);}),_0x23ab24&&_0x113fe4)throw new Error(_0x239306+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x113eb9)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x379320,_0x48c0b5){let _0x4bc2a5,_0x2b2e42;for(_0x4bc2a5=0x0;_0x4bc2a5<_0x48c0b5['length'];_0x4bc2a5++){_0x2b2e42=_0x48c0b5[_0x4bc2a5];const _0x5dcc0a=Mt(_0x2b2e42);for(let _0x30c13d=0x0;_0x30c13d<_0x5dcc0a['length'];_0x30c13d++)if(!(_0x5dcc0a[_0x30c13d]==='.priority'&&_0x30c13d===_0x5dcc0a['length']-0x1)){if(!ms(_0x5dcc0a[_0x30c13d]))throw new Error(_0x379320+'contains\x20an\x20invalid\x20key\x20('+_0x5dcc0a[_0x30c13d]+')\x20in\x20path\x20'+_0x2b2e42['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x48c0b5['sort'](Rh);let _0x2e04d7=null;for(_0x4bc2a5=0x0;_0x4bc2a5<_0x48c0b5['length'];_0x4bc2a5++){if(_0x2b2e42=_0x48c0b5[_0x4bc2a5],_0x2e04d7!==null&&G(_0x2e04d7,_0x2b2e42))throw new Error(_0x379320+'contains\x20a\x20path\x20'+_0x2e04d7['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2b2e42['toString']());_0x2e04d7=_0x2b2e42;}},ra=function(_0x50a008,_0x36e8c3,_0x578480,_0x46f92f){const _0x4bead6=it(_0x50a008,'values');if(!(_0x36e8c3&&typeof _0x36e8c3=='object')||Array['isArray'](_0x36e8c3))throw new Error(_0x4bead6+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x319015=[];x(_0x36e8c3,(_0xb62073,_0x1e19b3)=>{const _0x504ded=new C(_0xb62073);if(Jt(_0x4bead6,_0x1e19b3,k(_0x578480,_0x504ded)),ji(_0x504ded)==='.priority'&&!Bt(_0x1e19b3))throw new Error(_0x4bead6+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x504ded['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x319015['push'](_0x504ded);}),dd(_0x4bead6,_0x319015);},fd=function(_0x36d289,_0x158652,_0x1a3be4){if(xn(_0x158652))throw new Error(it(_0x36d289,'priority')+'is\x20'+_0x158652['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x158652))throw new Error(it(_0x36d289,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x4a5d51,_0x30a246,_0x31fa66,_0x5b8444){if(!sa(_0x31fa66))throw new Error(it(_0x4a5d51,_0x30a246)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x31fa66+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x317df7,_0xc0e06f,_0xd409fc,_0x16531b){_0xd409fc&&(_0xd409fc=_0xd409fc['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x317df7,_0xc0e06f,_0xd409fc);},Me=function(_0x16d9b4,_0x222168){if(y(_0x222168)==='.info')throw new Error(_0x16d9b4+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x1257bd,_0x3ac847){const _0x110c4e=_0x3ac847['path']['toString']();if(typeof _0x3ac847['repoInfo']['host']!='string'||_0x3ac847['repoInfo']['host']['length']===0x0||!ms(_0x3ac847['repoInfo']['namespace'])&&_0x3ac847['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x110c4e['length']!==0x0&&!ud(_0x110c4e))throw new Error(it(_0x1257bd,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x398ec2,_0x56695a){let _0x460ada=null;for(let _0x128e4c=0x0;_0x128e4c<_0x56695a['length'];_0x128e4c++){const _0x98efe2=_0x56695a[_0x128e4c],_0x2a48eb=_0x98efe2['getPath']();_0x460ada!==null&&!Ki(_0x2a48eb,_0x460ada['path'])&&(_0x398ec2['eventLists_']['push'](_0x460ada),_0x460ada=null),_0x460ada===null&&(_0x460ada={'events':[],'path':_0x2a48eb}),_0x460ada['events']['push'](_0x98efe2);}_0x460ada&&_0x398ec2['eventLists_']['push'](_0x460ada);}function oa(_0x487222,_0x393b03,_0x4b8dfe){qn(_0x487222,_0x4b8dfe),aa(_0x487222,_0x2f84d2=>Ki(_0x2f84d2,_0x393b03));}function V(_0x4361eb,_0x56c1dd,_0x2e73a5){qn(_0x4361eb,_0x2e73a5),aa(_0x4361eb,_0x294ee6=>G(_0x294ee6,_0x56c1dd)||G(_0x56c1dd,_0x294ee6));}function aa(_0x56f12a,_0x24084e){_0x56f12a['recursionDepth_']++;let _0x52f781=!0x0;for(let _0x495e62=0x0;_0x495e62<_0x56f12a['eventLists_']['length'];_0x495e62++){const _0x1e6e09=_0x56f12a['eventLists_'][_0x495e62];if(_0x1e6e09){const _0x3a2924=_0x1e6e09['path'];_0x24084e(_0x3a2924)?(md(_0x56f12a['eventLists_'][_0x495e62]),_0x56f12a['eventLists_'][_0x495e62]=null):_0x52f781=!0x1;}}_0x52f781&&(_0x56f12a['eventLists_']=[]),_0x56f12a['recursionDepth_']--;}function md(_0x36c1a9){for(let _0xa86de0=0x0;_0xa86de0<_0x36c1a9['events']['length'];_0xa86de0++){const _0x1c5e83=_0x36c1a9['events'][_0xa86de0];if(_0x1c5e83!==null){_0x36c1a9['events'][_0xa86de0]=null;const _0x3cb039=_0x1c5e83['getEventRunner']();St&&L('event:\x20'+_0x1c5e83['toString']()),ft(_0x3cb039);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x18b381,_0x1401a1,_0x412372,_0xa33671){this['repoInfo_']=_0x18b381,this['forceRestClient_']=_0x1401a1,this['authTokenProvider_']=_0x412372,this['appCheckProvider_']=_0xa33671,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x39d493,_0x43cbab,_0x5349f2){if(_0x39d493['stats_']=qi(_0x39d493['repoInfo_']),_0x39d493['forceRestClient_']||Xl())_0x39d493['server_']=new vn(_0x39d493['repoInfo_'],(_0x457360,_0x44ef41,_0x2c899c,_0x26bf7d)=>{gr(_0x39d493,_0x457360,_0x44ef41,_0x2c899c,_0x26bf7d);},_0x39d493['authTokenProvider_'],_0x39d493['appCheckProvider_']),setTimeout(()=>mr(_0x39d493,!0x0),0x0);else{if(typeof _0x5349f2<'u'&&_0x5349f2!==null){if(typeof _0x5349f2!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5349f2);}catch(_0x545053){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x545053);}}_0x39d493['persistentConnection_']=new se(_0x39d493['repoInfo_'],_0x43cbab,(_0x2e280c,_0x216f46,_0xf7ef5,_0x3fa180)=>{gr(_0x39d493,_0x2e280c,_0x216f46,_0xf7ef5,_0x3fa180);},_0xaf935c=>{mr(_0x39d493,_0xaf935c);},_0x2462ec=>{Id(_0x39d493,_0x2462ec);},_0x39d493['authTokenProvider_'],_0x39d493['appCheckProvider_'],_0x5349f2),_0x39d493['server_']=_0x39d493['persistentConnection_'];}_0x39d493['authTokenProvider_']['addTokenChangeListener'](_0x416b4a=>{_0x39d493['server_']['refreshAuthToken'](_0x416b4a);}),_0x39d493['appCheckProvider_']['addTokenChangeListener'](_0x2353e5=>{_0x39d493['server_']['refreshAppCheckToken'](_0x2353e5['token']);}),_0x39d493['statsReporter_']=ih(_0x39d493['repoInfo_'],()=>new iu(_0x39d493['stats_'],_0x39d493['server_'])),_0x39d493['infoData_']=new Xh(),_0x39d493['infoSyncTree_']=new pr({'startListening':(_0x3dfdd5,_0x20e0ed,_0x395e0e,_0xc8eaff)=>{let _0x142b4b=[];const _0x178e96=_0x39d493['infoData_']['getNode'](_0x3dfdd5['_path']);return _0x178e96['isEmpty']()||(_0x142b4b=Yt(_0x39d493['infoSyncTree_'],_0x3dfdd5['_path'],_0x178e96),setTimeout(()=>{_0xc8eaff('ok');},0x0)),_0x142b4b;},'stopListening':()=>{}}),vs(_0x39d493,'connected',!0x1),_0x39d493['serverSyncTree_']=new pr({'startListening':(_0x3c3fdb,_0x560798,_0x26b7ef,_0x1d3cf1)=>(_0x39d493['server_']['listen'](_0x3c3fdb,_0x26b7ef,_0x560798,(_0x16f930,_0x42109c)=>{const _0x137972=_0x1d3cf1(_0x16f930,_0x42109c);V(_0x39d493['eventQueue_'],_0x3c3fdb['_path'],_0x137972);}),[]),'stopListening':(_0x276bd8,_0x206411)=>{_0x39d493['server_']['unlisten'](_0x276bd8,_0x206411);}});}function la(_0x5971f9){const _0x2194b5=_0x5971f9['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x2194b5;}function Xt(_0x2565a7){return id({'timestamp':la(_0x2565a7)});}function gr(_0x33b764,_0x1c5199,_0x154306,_0x2f2f64,_0x399f1a){_0x33b764['dataUpdateCount']++;const _0x521531=new C(_0x1c5199);_0x154306=_0x33b764['interceptServerDataCallback_']?_0x33b764['interceptServerDataCallback_'](_0x1c5199,_0x154306):_0x154306;let _0x456006=[];if(_0x399f1a){if(_0x2f2f64){const _0x49b615=_n(_0x154306,_0x26e2de=>A(_0x26e2de));_0x456006=Ju(_0x33b764['serverSyncTree_'],_0x521531,_0x49b615,_0x399f1a);}else{const _0x11562c=A(_0x154306);_0x456006=Jo(_0x33b764['serverSyncTree_'],_0x521531,_0x11562c,_0x399f1a);}}else{if(_0x2f2f64){const _0x47108b=_n(_0x154306,_0x123ae6=>A(_0x123ae6));_0x456006=Ku(_0x33b764['serverSyncTree_'],_0x521531,_0x47108b);}else{const _0x447d65=A(_0x154306);_0x456006=Yt(_0x33b764['serverSyncTree_'],_0x521531,_0x447d65);}}let _0x401e21=_0x521531;_0x456006['length']>0x0&&(_0x401e21=ct(_0x33b764,_0x521531)),V(_0x33b764['eventQueue_'],_0x401e21,_0x456006);}function mr(_0x4b3007,_0x53fdcc){vs(_0x4b3007,'connected',_0x53fdcc),_0x53fdcc===!0x1&&Sd(_0x4b3007);}function Id(_0x45ecbc,_0x301335){x(_0x301335,(_0x14e3fe,_0x48f387)=>{vs(_0x45ecbc,_0x14e3fe,_0x48f387);});}function vs(_0x11d30a,_0x1a2dd3,_0x2b0d68){const _0x219ba7=new C('/.info/'+_0x1a2dd3),_0x26fefe=A(_0x2b0d68);_0x11d30a['infoData_']['updateSnapshot'](_0x219ba7,_0x26fefe);const _0x26beec=Yt(_0x11d30a['infoSyncTree_'],_0x219ba7,_0x26fefe);V(_0x11d30a['eventQueue_'],_0x219ba7,_0x26beec);}function zn(_0x141bbc){return _0x141bbc['nextWriteId_']++;}function wd(_0x30cf1a,_0x22f4a0,_0x2c1727){const _0x1b3f79=Xu(_0x30cf1a['serverSyncTree_'],_0x22f4a0);return _0x1b3f79!=null?Promise['resolve'](_0x1b3f79):_0x30cf1a['server_']['get'](_0x22f4a0)['then'](_0x57f6c3=>{const _0x5c7824=A(_0x57f6c3)['withIndex'](_0x22f4a0['_queryParams']['getIndex']());Ni(_0x30cf1a['serverSyncTree_'],_0x22f4a0,_0x2c1727,!0x0);let _0x2dc588;if(_0x22f4a0['_queryParams']['loadsAllData']())_0x2dc588=Yt(_0x30cf1a['serverSyncTree_'],_0x22f4a0['_path'],_0x5c7824);else{const _0x202669=Wt(_0x30cf1a['serverSyncTree_'],_0x22f4a0);_0x2dc588=Jo(_0x30cf1a['serverSyncTree_'],_0x22f4a0['_path'],_0x5c7824,_0x202669);}return V(_0x30cf1a['eventQueue_'],_0x22f4a0['_path'],_0x2dc588),An(_0x30cf1a['serverSyncTree_'],_0x22f4a0,_0x2c1727,null,!0x0),_0x5c7824;},_0xfccb25=>(gt(_0x30cf1a,'get\x20for\x20query\x20'+O(_0x22f4a0)+'\x20failed:\x20'+_0xfccb25),Promise['reject'](new Error(_0xfccb25))));}function Cd(_0x545081,_0x1ec615,_0x3ed72a,_0x528f80,_0x58cf82){gt(_0x545081,'set',{'path':_0x1ec615['toString'](),'value':_0x3ed72a,'priority':_0x528f80});const _0x27af1e=Xt(_0x545081),_0x5e6bbd=A(_0x3ed72a,_0x528f80),_0x1af8a9=Vn(_0x545081['serverSyncTree_'],_0x1ec615),_0x250f7b=fs(_0x5e6bbd,_0x1af8a9,_0x27af1e),_0x1ec924=zn(_0x545081),_0x3cb6ab=as(_0x545081['serverSyncTree_'],_0x1ec615,_0x250f7b,_0x1ec924,!0x0);qn(_0x545081['eventQueue_'],_0x3cb6ab),_0x545081['server_']['put'](_0x1ec615['toString'](),_0x5e6bbd['val'](!0x0),(_0x28ef2f,_0x3bb56f)=>{const _0x482791=_0x28ef2f==='ok';_0x482791||U('set\x20at\x20'+_0x1ec615+'\x20failed:\x20'+_0x28ef2f);const _0x121b1d=_e(_0x545081['serverSyncTree_'],_0x1ec924,!_0x482791);V(_0x545081['eventQueue_'],_0x1ec615,_0x121b1d),be(_0x545081,_0x58cf82,_0x28ef2f,_0x3bb56f);});const _0x4baa91=Is(_0x545081,_0x1ec615);ct(_0x545081,_0x4baa91),V(_0x545081['eventQueue_'],_0x4baa91,[]);}function Td(_0x4abc3a,_0x131992,_0x2583c1,_0x2b803f){gt(_0x4abc3a,'update',{'path':_0x131992['toString'](),'value':_0x2583c1});let _0x417513=!0x0;const _0x3077e9=Xt(_0x4abc3a),_0x49c304={};if(x(_0x2583c1,(_0x2a9ff3,_0x233258)=>{_0x417513=!0x1,_0x49c304[_0x2a9ff3]=ta(k(_0x131992,_0x2a9ff3),A(_0x233258),_0x4abc3a['serverSyncTree_'],_0x3077e9);}),_0x417513)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x4abc3a,_0x2b803f,'ok',void 0x0);else{const _0x2225f3=zn(_0x4abc3a),_0x3aedc9=ju(_0x4abc3a['serverSyncTree_'],_0x131992,_0x49c304,_0x2225f3);qn(_0x4abc3a['eventQueue_'],_0x3aedc9),_0x4abc3a['server_']['merge'](_0x131992['toString'](),_0x2583c1,(_0x1a687b,_0x203274)=>{const _0x207665=_0x1a687b==='ok';_0x207665||U('update\x20at\x20'+_0x131992+'\x20failed:\x20'+_0x1a687b);const _0x1ff6d3=_e(_0x4abc3a['serverSyncTree_'],_0x2225f3,!_0x207665),_0x148dd4=_0x1ff6d3['length']>0x0?ct(_0x4abc3a,_0x131992):_0x131992;V(_0x4abc3a['eventQueue_'],_0x148dd4,_0x1ff6d3),be(_0x4abc3a,_0x2b803f,_0x1a687b,_0x203274);}),x(_0x2583c1,_0x7f36b9=>{const _0x5efccb=Is(_0x4abc3a,k(_0x131992,_0x7f36b9));ct(_0x4abc3a,_0x5efccb);}),V(_0x4abc3a['eventQueue_'],_0x131992,[]);}}function Sd(_0x2baff6){gt(_0x2baff6,'onDisconnectEvents');const _0x285154=Xt(_0x2baff6),_0x4a63e0=En();Si(_0x2baff6['onDisconnect_'],w(),(_0x3412f4,_0xc22859)=>{const _0x2fca79=ta(_0x3412f4,_0xc22859,_0x2baff6['serverSyncTree_'],_0x285154);pt(_0x4a63e0,_0x3412f4,_0x2fca79);});let _0x4d74ed=[];Si(_0x4a63e0,w(),(_0x5788be,_0x4312c7)=>{_0x4d74ed=_0x4d74ed['concat'](Yt(_0x2baff6['serverSyncTree_'],_0x5788be,_0x4312c7));const _0x11a989=Is(_0x2baff6,_0x5788be);ct(_0x2baff6,_0x11a989);}),_0x2baff6['onDisconnect_']=En(),V(_0x2baff6['eventQueue_'],w(),_0x4d74ed);}function bd(_0x4d6f08,_0x42cd2e,_0x4ff8c7){_0x4d6f08['server_']['onDisconnectCancel'](_0x42cd2e['toString'](),(_0x4675ec,_0x48ccb4)=>{_0x4675ec==='ok'&&Ti(_0x4d6f08['onDisconnect_'],_0x42cd2e),be(_0x4d6f08,_0x4ff8c7,_0x4675ec,_0x48ccb4);});}function yr(_0x31e4f5,_0x373232,_0x4ac476,_0x1056ab){const _0x451f63=A(_0x4ac476);_0x31e4f5['server_']['onDisconnectPut'](_0x373232['toString'](),_0x451f63['val'](!0x0),(_0x3756b9,_0x4c3d45)=>{_0x3756b9==='ok'&&pt(_0x31e4f5['onDisconnect_'],_0x373232,_0x451f63),be(_0x31e4f5,_0x1056ab,_0x3756b9,_0x4c3d45);});}function Rd(_0x40c945,_0x23ab72,_0x10d536,_0x2830f4,_0x44b183){const _0x468fee=A(_0x10d536,_0x2830f4);_0x40c945['server_']['onDisconnectPut'](_0x23ab72['toString'](),_0x468fee['val'](!0x0),(_0x84c0c1,_0x392aac)=>{_0x84c0c1==='ok'&&pt(_0x40c945['onDisconnect_'],_0x23ab72,_0x468fee),be(_0x40c945,_0x44b183,_0x84c0c1,_0x392aac);});}function Ad(_0x234f30,_0xf50793,_0x3f9f2b,_0x57a513){if(pn(_0x3f9f2b)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x234f30,_0x57a513,'ok',void 0x0);return;}_0x234f30['server_']['onDisconnectMerge'](_0xf50793['toString'](),_0x3f9f2b,(_0x6d1bee,_0x48c7ad)=>{_0x6d1bee==='ok'&&x(_0x3f9f2b,(_0x1e986d,_0x52e539)=>{const _0x2ed86a=A(_0x52e539);pt(_0x234f30['onDisconnect_'],k(_0xf50793,_0x1e986d),_0x2ed86a);}),be(_0x234f30,_0x57a513,_0x6d1bee,_0x48c7ad);});}function kd(_0x32a00a,_0x2ad3b3,_0x2a0ba7){let _0x432c37;y(_0x2ad3b3['_path'])==='.info'?_0x432c37=Ni(_0x32a00a['infoSyncTree_'],_0x2ad3b3,_0x2a0ba7):_0x432c37=Ni(_0x32a00a['serverSyncTree_'],_0x2ad3b3,_0x2a0ba7),oa(_0x32a00a['eventQueue_'],_0x2ad3b3['_path'],_0x432c37);}function Pd(_0x1dc909,_0x1fa117,_0x356f86){let _0x7a153b;y(_0x1fa117['_path'])==='.info'?_0x7a153b=An(_0x1dc909['infoSyncTree_'],_0x1fa117,_0x356f86):_0x7a153b=An(_0x1dc909['serverSyncTree_'],_0x1fa117,_0x356f86),oa(_0x1dc909['eventQueue_'],_0x1fa117['_path'],_0x7a153b);}function ha(_0x32bd47){_0x32bd47['persistentConnection_']&&_0x32bd47['persistentConnection_']['interrupt'](ca);}function Nd(_0x467b17){_0x467b17['persistentConnection_']&&_0x467b17['persistentConnection_']['resume'](ca);}function gt(_0x526161,..._0x3af623){let _0x372411='';_0x526161['persistentConnection_']&&(_0x372411=_0x526161['persistentConnection_']['id']+':'),L(_0x372411,..._0x3af623);}function be(_0x43e962,_0x161b63,_0x3432ee,_0xa0e475){_0x161b63&&ft(()=>{if(_0x3432ee==='ok')_0x161b63(null);else{const _0x3d2c63=(_0x3432ee||'error')['toUpperCase']();let _0x1339f5=_0x3d2c63;_0xa0e475&&(_0x1339f5+=':\x20'+_0xa0e475);const _0x2ba6e2=new Error(_0x1339f5);_0x2ba6e2['code']=_0x3d2c63,_0x161b63(_0x2ba6e2);}});}function Od(_0x3cb2c5,_0x96cce1,_0x50c843,_0xb96fa8,_0x292604,_0x276a17){gt(_0x3cb2c5,'transaction\x20on\x20'+_0x96cce1);const _0x3dd335={'path':_0x96cce1,'update':_0x50c843,'onComplete':_0xb96fa8,'status':null,'order':so(),'applyLocally':_0x276a17,'retryCount':0x0,'unwatcher':_0x292604,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x44456c=Es(_0x3cb2c5,_0x96cce1,void 0x0);_0x3dd335['currentInputSnapshot']=_0x44456c;const _0x5b79cd=_0x3dd335['update'](_0x44456c['val']());if(_0x5b79cd===void 0x0)_0x3dd335['unwatcher'](),_0x3dd335['currentOutputSnapshotRaw']=null,_0x3dd335['currentOutputSnapshotResolved']=null,_0x3dd335['onComplete']&&_0x3dd335['onComplete'](null,!0x1,_0x3dd335['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5b79cd,_0x3dd335['path']),_0x3dd335['status']=0x0;const _0x5876ea=$n(_0x3cb2c5['transactionQueueTree_'],_0x96cce1),_0x1432c3=je(_0x5876ea)||[];_0x1432c3['push'](_0x3dd335),gs(_0x5876ea,_0x1432c3);let _0x34b873;typeof _0x5b79cd=='object'&&_0x5b79cd!==null&&Q(_0x5b79cd,'.priority')?(_0x34b873=Le(_0x5b79cd,'.priority'),f(Bt(_0x34b873),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x34b873=(Vn(_0x3cb2c5['serverSyncTree_'],_0x96cce1)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x4d0c76=Xt(_0x3cb2c5),_0x5db4cb=A(_0x5b79cd,_0x34b873),_0x4f2011=fs(_0x5db4cb,_0x44456c,_0x4d0c76);_0x3dd335['currentOutputSnapshotRaw']=_0x5db4cb,_0x3dd335['currentOutputSnapshotResolved']=_0x4f2011,_0x3dd335['currentWriteId']=zn(_0x3cb2c5);const _0x460341=as(_0x3cb2c5['serverSyncTree_'],_0x96cce1,_0x4f2011,_0x3dd335['currentWriteId'],_0x3dd335['applyLocally']);V(_0x3cb2c5['eventQueue_'],_0x96cce1,_0x460341),jn(_0x3cb2c5,_0x3cb2c5['transactionQueueTree_']);}}function Es(_0x31fc96,_0x1df47c,_0x1bd226){return Vn(_0x31fc96['serverSyncTree_'],_0x1df47c,_0x1bd226)||g['EMPTY_NODE'];}function jn(_0x50fd53,_0x17892e=_0x50fd53['transactionQueueTree_']){if(_0x17892e||Kn(_0x50fd53,_0x17892e),je(_0x17892e)){const _0x2e2e64=da(_0x50fd53,_0x17892e);f(_0x2e2e64['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2e2e64['every'](_0x55050c=>_0x55050c['status']===0x0)&&Dd(_0x50fd53,Qt(_0x17892e),_0x2e2e64);}else na(_0x17892e)&&Gn(_0x17892e,_0x298ffb=>{jn(_0x50fd53,_0x298ffb);});}function Dd(_0x751a8c,_0xce3f31,_0xf76a38){const _0x3575fd=_0xf76a38['map'](_0x28213d=>_0x28213d['currentWriteId']),_0x237e67=Es(_0x751a8c,_0xce3f31,_0x3575fd);let _0x42e722=_0x237e67;const _0x179d89=_0x237e67['hash']();for(let _0x1e1d7d=0x0;_0x1e1d7d<_0xf76a38['length'];_0x1e1d7d++){const _0x1ea3a2=_0xf76a38[_0x1e1d7d];f(_0x1ea3a2['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x1ea3a2['status']=0x1,_0x1ea3a2['retryCount']++;const _0x5e2f0a=F(_0xce3f31,_0x1ea3a2['path']);_0x42e722=_0x42e722['updateChild'](_0x5e2f0a,_0x1ea3a2['currentOutputSnapshotRaw']);}const _0x536c18=_0x42e722['val'](!0x0),_0x38a5b8=_0xce3f31;_0x751a8c['server_']['put'](_0x38a5b8['toString'](),_0x536c18,_0x14f7a5=>{gt(_0x751a8c,'transaction\x20put\x20response',{'path':_0x38a5b8['toString'](),'status':_0x14f7a5});let _0x166586=[];if(_0x14f7a5==='ok'){const _0xbf9ccd=[];for(let _0x2abec5=0x0;_0x2abec5<_0xf76a38['length'];_0x2abec5++)_0xf76a38[_0x2abec5]['status']=0x2,_0x166586=_0x166586['concat'](_e(_0x751a8c['serverSyncTree_'],_0xf76a38[_0x2abec5]['currentWriteId'])),_0xf76a38[_0x2abec5]['onComplete']&&_0xbf9ccd['push'](()=>_0xf76a38[_0x2abec5]['onComplete'](null,!0x0,_0xf76a38[_0x2abec5]['currentOutputSnapshotResolved'])),_0xf76a38[_0x2abec5]['unwatcher']();Kn(_0x751a8c,$n(_0x751a8c['transactionQueueTree_'],_0xce3f31)),jn(_0x751a8c,_0x751a8c['transactionQueueTree_']),V(_0x751a8c['eventQueue_'],_0xce3f31,_0x166586);for(let _0x434b5d=0x0;_0x434b5d<_0xbf9ccd['length'];_0x434b5d++)ft(_0xbf9ccd[_0x434b5d]);}else{if(_0x14f7a5==='datastale'){for(let _0x52d31f=0x0;_0x52d31f<_0xf76a38['length'];_0x52d31f++)_0xf76a38[_0x52d31f]['status']===0x3?_0xf76a38[_0x52d31f]['status']=0x4:_0xf76a38[_0x52d31f]['status']=0x0;}else{U('transaction\x20at\x20'+_0x38a5b8['toString']()+'\x20failed:\x20'+_0x14f7a5);for(let _0x344147=0x0;_0x344147<_0xf76a38['length'];_0x344147++)_0xf76a38[_0x344147]['status']=0x4,_0xf76a38[_0x344147]['abortReason']=_0x14f7a5;}ct(_0x751a8c,_0xce3f31);}},_0x179d89);}function ct(_0x20358b,_0x114dce){const _0x30b105=ua(_0x20358b,_0x114dce),_0x54e20e=Qt(_0x30b105),_0x5a647c=da(_0x20358b,_0x30b105);return Md(_0x20358b,_0x5a647c,_0x54e20e),_0x54e20e;}function Md(_0x3a536a,_0x53477e,_0xd1b97){if(_0x53477e['length']===0x0)return;const _0x16a1be=[];let _0x3d1d65=[];const _0x120721=_0x53477e['filter'](_0x1925ab=>_0x1925ab['status']===0x0)['map'](_0x229ca3=>_0x229ca3['currentWriteId']);for(let _0x23779c=0x0;_0x23779c<_0x53477e['length'];_0x23779c++){const _0x2f49e0=_0x53477e[_0x23779c],_0x424a39=F(_0xd1b97,_0x2f49e0['path']);let _0x3fb5e0=!0x1,_0x2041ac;if(f(_0x424a39!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2f49e0['status']===0x4)_0x3fb5e0=!0x0,_0x2041ac=_0x2f49e0['abortReason'],_0x3d1d65=_0x3d1d65['concat'](_e(_0x3a536a['serverSyncTree_'],_0x2f49e0['currentWriteId'],!0x0));else{if(_0x2f49e0['status']===0x0){if(_0x2f49e0['retryCount']>=yd)_0x3fb5e0=!0x0,_0x2041ac='maxretry',_0x3d1d65=_0x3d1d65['concat'](_e(_0x3a536a['serverSyncTree_'],_0x2f49e0['currentWriteId'],!0x0));else{const _0x28603b=Es(_0x3a536a,_0x2f49e0['path'],_0x120721);_0x2f49e0['currentInputSnapshot']=_0x28603b;const _0x4b92c2=_0x53477e[_0x23779c]['update'](_0x28603b['val']());if(_0x4b92c2!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4b92c2,_0x2f49e0['path']);let _0x36e51b=A(_0x4b92c2);typeof _0x4b92c2=='object'&&_0x4b92c2!=null&&Q(_0x4b92c2,'.priority')||(_0x36e51b=_0x36e51b['updatePriority'](_0x28603b['getPriority']()));const _0x2655e5=_0x2f49e0['currentWriteId'],_0x53ed33=Xt(_0x3a536a),_0x4a087b=fs(_0x36e51b,_0x28603b,_0x53ed33);_0x2f49e0['currentOutputSnapshotRaw']=_0x36e51b,_0x2f49e0['currentOutputSnapshotResolved']=_0x4a087b,_0x2f49e0['currentWriteId']=zn(_0x3a536a),_0x120721['splice'](_0x120721['indexOf'](_0x2655e5),0x1),_0x3d1d65=_0x3d1d65['concat'](as(_0x3a536a['serverSyncTree_'],_0x2f49e0['path'],_0x4a087b,_0x2f49e0['currentWriteId'],_0x2f49e0['applyLocally'])),_0x3d1d65=_0x3d1d65['concat'](_e(_0x3a536a['serverSyncTree_'],_0x2655e5,!0x0));}else _0x3fb5e0=!0x0,_0x2041ac='nodata',_0x3d1d65=_0x3d1d65['concat'](_e(_0x3a536a['serverSyncTree_'],_0x2f49e0['currentWriteId'],!0x0));}}}V(_0x3a536a['eventQueue_'],_0xd1b97,_0x3d1d65),_0x3d1d65=[],_0x3fb5e0&&(_0x53477e[_0x23779c]['status']=0x2,function(_0x3d3a46){setTimeout(_0x3d3a46,Math['floor'](0x0));}(_0x53477e[_0x23779c]['unwatcher']),_0x53477e[_0x23779c]['onComplete']&&(_0x2041ac==='nodata'?_0x16a1be['push'](()=>_0x53477e[_0x23779c]['onComplete'](null,!0x1,_0x53477e[_0x23779c]['currentInputSnapshot'])):_0x16a1be['push'](()=>_0x53477e[_0x23779c]['onComplete'](new Error(_0x2041ac),!0x1,null))));}Kn(_0x3a536a,_0x3a536a['transactionQueueTree_']);for(let _0xc2631a=0x0;_0xc2631a<_0x16a1be['length'];_0xc2631a++)ft(_0x16a1be[_0xc2631a]);jn(_0x3a536a,_0x3a536a['transactionQueueTree_']);}function ua(_0x471537,_0x4cb7f6){let _0x392c0d,_0x2ccd03=_0x471537['transactionQueueTree_'];for(_0x392c0d=y(_0x4cb7f6);_0x392c0d!==null&&je(_0x2ccd03)===void 0x0;)_0x2ccd03=$n(_0x2ccd03,_0x392c0d),_0x4cb7f6=S(_0x4cb7f6),_0x392c0d=y(_0x4cb7f6);return _0x2ccd03;}function da(_0x234e3e,_0x1061c9){const _0x2233ab=[];return fa(_0x234e3e,_0x1061c9,_0x2233ab),_0x2233ab['sort']((_0x19ae78,_0xd25e7d)=>_0x19ae78['order']-_0xd25e7d['order']),_0x2233ab;}function fa(_0x199e48,_0x1ff90b,_0x3de9cd){const _0x4f3c1c=je(_0x1ff90b);if(_0x4f3c1c){for(let _0x544b2d=0x0;_0x544b2d<_0x4f3c1c['length'];_0x544b2d++)_0x3de9cd['push'](_0x4f3c1c[_0x544b2d]);}Gn(_0x1ff90b,_0x22bf1d=>{fa(_0x199e48,_0x22bf1d,_0x3de9cd);});}function Kn(_0x1c9f80,_0x45aed1){const _0x31290=je(_0x45aed1);if(_0x31290){let _0xd03363=0x0;for(let _0x1648ae=0x0;_0x1648ae<_0x31290['length'];_0x1648ae++)_0x31290[_0x1648ae]['status']!==0x2&&(_0x31290[_0xd03363]=_0x31290[_0x1648ae],_0xd03363++);_0x31290['length']=_0xd03363,gs(_0x45aed1,_0x31290['length']>0x0?_0x31290:void 0x0);}Gn(_0x45aed1,_0x3484c6=>{Kn(_0x1c9f80,_0x3484c6);});}function Is(_0x3031f5,_0x3b0510){const _0x2abdee=Qt(ua(_0x3031f5,_0x3b0510)),_0x5d0f49=$n(_0x3031f5['transactionQueueTree_'],_0x3b0510);return ad(_0x5d0f49,_0x59275b=>{di(_0x3031f5,_0x59275b);}),di(_0x3031f5,_0x5d0f49),ia(_0x5d0f49,_0x16d348=>{di(_0x3031f5,_0x16d348);}),_0x2abdee;}function di(_0x312efe,_0x2226c0){const _0x4c9dd6=je(_0x2226c0);if(_0x4c9dd6){const _0x11296a=[];let _0xdb4df1=[],_0x46f981=-0x1;for(let _0x3d1f30=0x0;_0x3d1f30<_0x4c9dd6['length'];_0x3d1f30++)_0x4c9dd6[_0x3d1f30]['status']===0x3||(_0x4c9dd6[_0x3d1f30]['status']===0x1?(f(_0x46f981===_0x3d1f30-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x46f981=_0x3d1f30,_0x4c9dd6[_0x3d1f30]['status']=0x3,_0x4c9dd6[_0x3d1f30]['abortReason']='set'):(f(_0x4c9dd6[_0x3d1f30]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4c9dd6[_0x3d1f30]['unwatcher'](),_0xdb4df1=_0xdb4df1['concat'](_e(_0x312efe['serverSyncTree_'],_0x4c9dd6[_0x3d1f30]['currentWriteId'],!0x0)),_0x4c9dd6[_0x3d1f30]['onComplete']&&_0x11296a['push'](_0x4c9dd6[_0x3d1f30]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x46f981===-0x1?gs(_0x2226c0,void 0x0):_0x4c9dd6['length']=_0x46f981+0x1,V(_0x312efe['eventQueue_'],Qt(_0x2226c0),_0xdb4df1);for(let _0x42abb8=0x0;_0x42abb8<_0x11296a['length'];_0x42abb8++)ft(_0x11296a[_0x42abb8]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x16599a){let _0x5424fb='';const _0x1afd30=_0x16599a['split']('/');for(let _0x5e8d94=0x0;_0x5e8d94<_0x1afd30['length'];_0x5e8d94++)if(_0x1afd30[_0x5e8d94]['length']>0x0){let _0x3e112b=_0x1afd30[_0x5e8d94];try{_0x3e112b=decodeURIComponent(_0x3e112b['replace'](/\+/g,'\x20'));}catch{}_0x5424fb+='/'+_0x3e112b;}return _0x5424fb;}function xd(_0x3faef0){const _0x273c52={};_0x3faef0['charAt'](0x0)==='?'&&(_0x3faef0=_0x3faef0['substring'](0x1));for(const _0x11dc6e of _0x3faef0['split']('&')){if(_0x11dc6e['length']===0x0)continue;const _0x54f662=_0x11dc6e['split']('=');_0x54f662['length']===0x2?_0x273c52[decodeURIComponent(_0x54f662[0x0])]=decodeURIComponent(_0x54f662[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x11dc6e+'\x27\x20in\x20query\x20\x27'+_0x3faef0+'\x27');}return _0x273c52;}const vr=function(_0x46070c,_0x10f39c){const _0x37cae3=Fd(_0x46070c),_0x3b423d=_0x37cae3['namespace'];_0x37cae3['domain']==='firebase.com'&&ae(_0x37cae3['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3b423d||_0x3b423d==='undefined')&&_0x37cae3['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x37cae3['secure']||$l();const _0xde11bd=_0x37cae3['scheme']==='ws'||_0x37cae3['scheme']==='wss';return{'repoInfo':new yo(_0x37cae3['host'],_0x37cae3['secure'],_0x3b423d,_0xde11bd,_0x10f39c,'',_0x3b423d!==_0x37cae3['subdomain']),'path':new C(_0x37cae3['pathString'])};},Fd=function(_0x1217ff){let _0x584eee='',_0x398029='',_0x14850b='',_0x47c9b7='',_0x5a1de7='',_0x1ddd21=!0x0,_0xd100ea='https',_0x46ed8b=0x1bb;if(typeof _0x1217ff=='string'){let _0x12d94f=_0x1217ff['indexOf']('//');_0x12d94f>=0x0&&(_0xd100ea=_0x1217ff['substring'](0x0,_0x12d94f-0x1),_0x1217ff=_0x1217ff['substring'](_0x12d94f+0x2));let _0x510490=_0x1217ff['indexOf']('/');_0x510490===-0x1&&(_0x510490=_0x1217ff['length']);let _0x49b703=_0x1217ff['indexOf']('?');_0x49b703===-0x1&&(_0x49b703=_0x1217ff['length']),_0x584eee=_0x1217ff['substring'](0x0,Math['min'](_0x510490,_0x49b703)),_0x510490<_0x49b703&&(_0x47c9b7=Ld(_0x1217ff['substring'](_0x510490,_0x49b703)));const _0x5f891=xd(_0x1217ff['substring'](Math['min'](_0x1217ff['length'],_0x49b703)));_0x12d94f=_0x584eee['indexOf'](':'),_0x12d94f>=0x0?(_0x1ddd21=_0xd100ea==='https'||_0xd100ea==='wss',_0x46ed8b=parseInt(_0x584eee['substring'](_0x12d94f+0x1),0xa)):_0x12d94f=_0x584eee['length'];const _0x2929ee=_0x584eee['slice'](0x0,_0x12d94f);if(_0x2929ee['toLowerCase']()==='localhost')_0x398029='localhost';else{if(_0x2929ee['split']('.')['length']<=0x2)_0x398029=_0x2929ee;else{const _0x1ef0c8=_0x584eee['indexOf']('.');_0x14850b=_0x584eee['substring'](0x0,_0x1ef0c8)['toLowerCase'](),_0x398029=_0x584eee['substring'](_0x1ef0c8+0x1),_0x5a1de7=_0x14850b;}}'ns'in _0x5f891&&(_0x5a1de7=_0x5f891['ns']);}return{'host':_0x584eee,'port':_0x46ed8b,'domain':_0x398029,'subdomain':_0x14850b,'secure':_0x1ddd21,'scheme':_0xd100ea,'pathString':_0x47c9b7,'namespace':_0x5a1de7};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x59ac63=0x0;const _0x4e4981=[];return function(_0x1dad3d){const _0x31c5db=_0x1dad3d===_0x59ac63;_0x59ac63=_0x1dad3d;let _0x1e835b;const _0x461206=new Array(0x8);for(_0x1e835b=0x7;_0x1e835b>=0x0;_0x1e835b--)_0x461206[_0x1e835b]=Er['charAt'](_0x1dad3d%0x40),_0x1dad3d=Math['floor'](_0x1dad3d/0x40);f(_0x1dad3d===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x257196=_0x461206['join']('');if(_0x31c5db){for(_0x1e835b=0xb;_0x1e835b>=0x0&&_0x4e4981[_0x1e835b]===0x3f;_0x1e835b--)_0x4e4981[_0x1e835b]=0x0;_0x4e4981[_0x1e835b]++;}else{for(_0x1e835b=0x0;_0x1e835b<0xc;_0x1e835b++)_0x4e4981[_0x1e835b]=Math['floor'](Math['random']()*0x40);}for(_0x1e835b=0x0;_0x1e835b<0xc;_0x1e835b++)_0x257196+=Er['charAt'](_0x4e4981[_0x1e835b]);return f(_0x257196['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x257196;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x23e522,_0x5e40c4,_0x5b8823,_0x3bce0c){this['eventType']=_0x23e522,this['eventRegistration']=_0x5e40c4,this['snapshot']=_0x5b8823,this['prevName']=_0x3bce0c;}['getPath'](){const _0x59f59a=this['snapshot']['ref'];return this['eventType']==='value'?_0x59f59a['_path']:_0x59f59a['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x35fb4f,_0x59c544,_0x52274c){this['eventRegistration']=_0x35fb4f,this['error']=_0x59c544,this['path']=_0x52274c;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3763f0,_0x453d0e){this['snapshotCallback']=_0x3763f0,this['cancelCallback']=_0x453d0e;}['onValue'](_0xa6098e,_0x427415){this['snapshotCallback']['call'](null,_0xa6098e,_0x427415);}['onCancel'](_0x51a33e){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x51a33e);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x2a4cce){return this['snapshotCallback']===_0x2a4cce['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x2a4cce['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x2a4cce['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x205122,_0x2f2b53){this['_repo']=_0x205122,this['_path']=_0x2f2b53;}['cancel'](){const _0x3a7a42=new H();return bd(this['_repo'],this['_path'],_0x3a7a42['wrapCallback'](()=>{})),_0x3a7a42['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x2bb89d=new H();return yr(this['_repo'],this['_path'],null,_0x2bb89d['wrapCallback'](()=>{})),_0x2bb89d['promise'];}['set'](_0x2fbc3f){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x2fbc3f,this['_path'],!0x1);const _0xe980f1=new H();return yr(this['_repo'],this['_path'],_0x2fbc3f,_0xe980f1['wrapCallback'](()=>{})),_0xe980f1['promise'];}['setWithPriority'](_0x9243ff,_0x59c3){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x9243ff,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x59c3);const _0x14ab80=new H();return Rd(this['_repo'],this['_path'],_0x9243ff,_0x59c3,_0x14ab80['wrapCallback'](()=>{})),_0x14ab80['promise'];}['update'](_0x387d81){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x387d81,this['_path']);const _0x427be0=new H();return Ad(this['_repo'],this['_path'],_0x387d81,_0x427be0['wrapCallback'](()=>{})),_0x427be0['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x587fef,_0x2f5bda,_0x537f45,_0x595638){this['_repo']=_0x587fef,this['_path']=_0x2f5bda,this['_queryParams']=_0x537f45,this['_orderByCalled']=_0x595638;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5c0db2=sr(this['_queryParams']),_0x14a193=$i(_0x5c0db2);return _0x14a193==='{}'?'default':_0x14a193;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0xced95){if(_0xced95=P(_0xced95),!(_0xced95 instanceof Ae))return!0x1;const _0x595529=this['_repo']===_0xced95['_repo'],_0xf2e2f8=Ki(this['_path'],_0xced95['_path']),_0x169885=this['_queryIdentifier']===_0xced95['_queryIdentifier'];return _0x595529&&_0xf2e2f8&&_0x169885;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x509d80,_0xf094a3){if(_0x509d80['_orderByCalled']===!0x0)throw new Error(_0xf094a3+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x33769e){let _0x5249fe=null,_0x47a007=null;if(_0x33769e['hasStart']()&&(_0x5249fe=_0x33769e['getIndexStartValue']()),_0x33769e['hasEnd']()&&(_0x47a007=_0x33769e['getIndexEndValue']()),_0x33769e['getIndex']()===ve){const _0x56d4fe='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x438101='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x33769e['hasStart']()){if(_0x33769e['getIndexStartName']()!==We)throw new Error(_0x56d4fe);if(typeof _0x5249fe!='string')throw new Error(_0x438101);}if(_0x33769e['hasEnd']()){if(_0x33769e['getIndexEndName']()!==we)throw new Error(_0x56d4fe);if(typeof _0x47a007!='string')throw new Error(_0x438101);}}else{if(_0x33769e['getIndex']()===R){if(_0x5249fe!=null&&!Bt(_0x5249fe)||_0x47a007!=null&&!Bt(_0x47a007))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x33769e['getIndex']()instanceof Ji||_0x33769e['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x5249fe!=null&&typeof _0x5249fe=='object'||_0x47a007!=null&&typeof _0x47a007=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0xa53409){if(_0xa53409['hasStart']()&&_0xa53409['hasEnd']()&&_0xa53409['hasLimit']()&&!_0xa53409['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0xa45fac,_0x56de82){super(_0xa45fac,_0x56de82,new Zi(),!0x1);}get['parent'](){const _0x34532a=Ro(this['_path']);return _0x34532a===null?null:new ee(this['_repo'],_0x34532a);}get['root'](){let _0x515bfe=this;for(;_0x515bfe['parent']!==null;)_0x515bfe=_0x515bfe['parent'];return _0x515bfe;}}class lt{constructor(_0x524bcf,_0xcb2bdb,_0x15e774){this['_node']=_0x524bcf,this['ref']=_0xcb2bdb,this['_index']=_0x15e774;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x176897){const _0x31ada3=new C(_0x176897),_0x2915ba=Vt(this['ref'],_0x176897);return new lt(this['_node']['getChild'](_0x31ada3),_0x2915ba,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5b0ad1){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x16f67c,_0x4cc537)=>_0x5b0ad1(new lt(_0x4cc537,Vt(this['ref'],_0x16f67c),R)));}['hasChild'](_0x29d840){const _0x225788=new C(_0x29d840);return!this['_node']['getChild'](_0x225788)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x96a77d,_0x5ac8a6){return _0x96a77d=P(_0x96a77d),_0x96a77d['_checkNotDeleted']('ref'),_0x5ac8a6!==void 0x0?Vt(_0x96a77d['_root'],_0x5ac8a6):_0x96a77d['_root'];}function Vt(_0x549aab,_0x47c5ab){return _0x549aab=P(_0x549aab),y(_0x549aab['_path'])===null?pd('child','path',_0x47c5ab):ys('child','path',_0x47c5ab),new ee(_0x549aab['_repo'],k(_0x549aab['_path'],_0x47c5ab));}function v_(_0x2326ac){return _0x2326ac=P(_0x2326ac),new Vd(_0x2326ac['_repo'],_0x2326ac['_path']);}function E_(_0x1bb09e,_0x55a94f){_0x1bb09e=P(_0x1bb09e),Me('push',_0x1bb09e['_path']),He('push',_0x55a94f,_0x1bb09e['_path'],!0x0);const _0x28b787=la(_0x1bb09e['_repo']),_0x39c458=Ud(_0x28b787),_0x978ddc=Vt(_0x1bb09e,_0x39c458),_0x46a516=Vt(_0x1bb09e,_0x39c458);let _0x5358dc;return _0x55a94f!=null?_0x5358dc=Hd(_0x46a516,_0x55a94f)['then'](()=>_0x46a516):_0x5358dc=Promise['resolve'](_0x46a516),_0x978ddc['then']=_0x5358dc['then']['bind'](_0x5358dc),_0x978ddc['catch']=_0x5358dc['then']['bind'](_0x5358dc,void 0x0),_0x978ddc;}function Hd(_0x3d84a1,_0x2d1d92){_0x3d84a1=P(_0x3d84a1),Me('set',_0x3d84a1['_path']),He('set',_0x2d1d92,_0x3d84a1['_path'],!0x1);const _0x2cec24=new H();return Cd(_0x3d84a1['_repo'],_0x3d84a1['_path'],_0x2d1d92,null,_0x2cec24['wrapCallback'](()=>{})),_0x2cec24['promise'];}function I_(_0x2c8772,_0x2c32ed){ra('update',_0x2c32ed,_0x2c8772['_path']);const _0x53f645=new H();return Td(_0x2c8772['_repo'],_0x2c8772['_path'],_0x2c32ed,_0x53f645['wrapCallback'](()=>{})),_0x53f645['promise'];}function w_(_0x249080){_0x249080=P(_0x249080);const _0xd224e4=new pa(()=>{}),_0x563915=new Qn(_0xd224e4);return wd(_0x249080['_repo'],_0x249080,_0x563915)['then'](_0x384d91=>new lt(_0x384d91,new ee(_0x249080['_repo'],_0x249080['_path']),_0x249080['_queryParams']['getIndex']()));}class Qn{constructor(_0x3a0730){this['callbackContext']=_0x3a0730;}['respondsTo'](_0x673036){return _0x673036==='value';}['createEvent'](_0x2ff40d,_0x21bb07){const _0x49fdfc=_0x21bb07['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x2ff40d['snapshotNode'],new ee(_0x21bb07['_repo'],_0x21bb07['_path']),_0x49fdfc));}['getEventRunner'](_0x276dc3){return _0x276dc3['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x276dc3['error']):()=>this['callbackContext']['onValue'](_0x276dc3['snapshot'],null);}['createCancelEvent'](_0x30b7c6,_0x544a8f){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x30b7c6,_0x544a8f):null;}['matches'](_0x11f2f2){return _0x11f2f2 instanceof Qn?!_0x11f2f2['callbackContext']||!this['callbackContext']?!0x0:_0x11f2f2['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x504823,_0xaf685d,_0x198a4e,_0x3daa45,_0x22a32a){const _0x50ee73=new pa(_0x198a4e,void 0x0),_0x5688e1=new Qn(_0x50ee73);return kd(_0x504823['_repo'],_0x504823,_0x5688e1),()=>Pd(_0x504823['_repo'],_0x504823,_0x5688e1);}function Gd(_0x2c582c,_0x431e6f,_0x2bfe1a,_0x221bf2){return $d(_0x2c582c,'value',_0x431e6f);}class mt{}class ma extends mt{constructor(_0x42efec,_0x1cdfdd){super(),this['_value']=_0x42efec,this['_key']=_0x1cdfdd,this['type']='endAt';}['_apply'](_0x2b4ff4){He('endAt',this['_value'],_0x2b4ff4['_path'],!0x0);const _0x2ed65f=Jh(_0x2b4ff4['_queryParams'],this['_value'],this['_key']);if(ga(_0x2ed65f),Yn(_0x2ed65f),_0x2b4ff4['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x2b4ff4['_repo'],_0x2b4ff4['_path'],_0x2ed65f,_0x2b4ff4['_orderByCalled']);}}function C_(_0x501c44,_0x1ccf04){return new ma(_0x501c44,_0x1ccf04);}class ya extends mt{constructor(_0xe7f3a1,_0x521ee7){super(),this['_value']=_0xe7f3a1,this['_key']=_0x521ee7,this['type']='startAt';}['_apply'](_0x35190b){He('startAt',this['_value'],_0x35190b['_path'],!0x0);const _0x5f198b=Qh(_0x35190b['_queryParams'],this['_value'],this['_key']);if(ga(_0x5f198b),Yn(_0x5f198b),_0x35190b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x35190b['_repo'],_0x35190b['_path'],_0x5f198b,_0x35190b['_orderByCalled']);}}function T_(_0xf2e899=null,_0x491d01){return new ya(_0xf2e899,_0x491d01);}class qd extends mt{constructor(_0x2b6972){super(),this['_limit']=_0x2b6972,this['type']='limitToFirst';}['_apply'](_0x1b01a0){if(_0x1b01a0['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x1b01a0['_repo'],_0x1b01a0['_path'],Yh(_0x1b01a0['_queryParams'],this['_limit']),_0x1b01a0['_orderByCalled']);}}function S_(_0x32f52d){if(Math['floor'](_0x32f52d)!==_0x32f52d||_0x32f52d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x32f52d);}class zd extends mt{constructor(_0x4336c9){super(),this['_path']=_0x4336c9,this['type']='orderByChild';}['_apply'](_0x1af4b8){_a(_0x1af4b8,'orderByChild');const _0x278ecf=new C(this['_path']);if(v(_0x278ecf))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x543800=new Ji(_0x278ecf),_0x5c687c=xo(_0x1af4b8['_queryParams'],_0x543800);return Yn(_0x5c687c),new Ae(_0x1af4b8['_repo'],_0x1af4b8['_path'],_0x5c687c,!0x0);}}function b_(_0x32d339){if(_0x32d339==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x32d339==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x32d339==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x32d339),new zd(_0x32d339);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1063f0){_a(_0x1063f0,'orderByKey');const _0x4e7db1=xo(_0x1063f0['_queryParams'],ve);return Yn(_0x4e7db1),new Ae(_0x1063f0['_repo'],_0x1063f0['_path'],_0x4e7db1,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x13af28,_0x246945){super(),this['_value']=_0x13af28,this['_key']=_0x246945,this['type']='equalTo';}['_apply'](_0x5566e3){if(He('equalTo',this['_value'],_0x5566e3['_path'],!0x1),_0x5566e3['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x5566e3['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x5566e3));}}function A_(_0x403233,_0x40b100){return new Kd(_0x403233,_0x40b100);}function k_(_0x4abcd3,..._0x27182d){let _0x35a711=P(_0x4abcd3);for(const _0x26cb8c of _0x27182d)_0x35a711=_0x26cb8c['_apply'](_0x35a711);return _0x35a711;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x1c6a6b,_0x5c6d8c,_0x349a56,_0x7aa952){const _0x343c1d=_0x5c6d8c['lastIndexOf'](':'),_0x42bfee=_0x5c6d8c['substring'](0x0,_0x343c1d),_0x26b8e1=qt(_0x42bfee);_0x1c6a6b['repoInfo_']=new yo(_0x5c6d8c,_0x26b8e1,_0x1c6a6b['repoInfo_']['namespace'],_0x1c6a6b['repoInfo_']['webSocketOnly'],_0x1c6a6b['repoInfo_']['nodeAdmin'],_0x1c6a6b['repoInfo_']['persistenceKey'],_0x1c6a6b['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x349a56),_0x7aa952&&(_0x1c6a6b['authTokenProvider_']=_0x7aa952);}function Xd(_0x3d51cc,_0x14ef9f,_0x1ae6d5,_0x5ee7d9,_0xd6062f){let _0xe2094c=_0x5ee7d9||_0x3d51cc['options']['databaseURL'];_0xe2094c===void 0x0&&(_0x3d51cc['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3d51cc['options']['projectId']),_0xe2094c=_0x3d51cc['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x53d3b3=vr(_0xe2094c,_0xd6062f),_0x7f6a8f=_0x53d3b3['repoInfo'],_0x3e17dd;typeof process<'u'&&Bs&&(_0x3e17dd=Bs[Yd]),_0x3e17dd?(_0xe2094c='http://'+_0x3e17dd+'?ns='+_0x7f6a8f['namespace'],_0x53d3b3=vr(_0xe2094c,_0xd6062f),_0x7f6a8f=_0x53d3b3['repoInfo']):_0x53d3b3['repoInfo']['secure'];const _0x411d68=new eh(_0x3d51cc['name'],_0x3d51cc['options'],_0x14ef9f);_d('Invalid\x20Firebase\x20Database\x20URL',_0x53d3b3),v(_0x53d3b3['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x2197fa=ef(_0x7f6a8f,_0x3d51cc,_0x411d68,new Zl(_0x3d51cc,_0x1ae6d5));return new tf(_0x2197fa,_0x3d51cc);}function Zd(_0x19d2e0,_0x42f48b){const _0x417e1b=Di[_0x42f48b];(!_0x417e1b||_0x417e1b[_0x19d2e0['key']]!==_0x19d2e0)&&ae('Database\x20'+_0x42f48b+'('+_0x19d2e0['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x19d2e0),delete _0x417e1b[_0x19d2e0['key']];}function ef(_0x1b7ba7,_0x3abf12,_0x16e347,_0x57a725){let _0x1f8a26=Di[_0x3abf12['name']];_0x1f8a26||(_0x1f8a26={},Di[_0x3abf12['name']]=_0x1f8a26);let _0x382324=_0x1f8a26[_0x1b7ba7['toURLString']()];return _0x382324&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x382324=new vd(_0x1b7ba7,Qd,_0x16e347,_0x57a725),_0x1f8a26[_0x1b7ba7['toURLString']()]=_0x382324,_0x382324;}class tf{constructor(_0xecf611,_0x5893c2){this['_repoInternal']=_0xecf611,this['app']=_0x5893c2,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x19a200){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x19a200+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x2bc908=Zr(),_0x37a32e){const _0x4602c0=Hi(_0x2bc908,'database')['getImmediate']({'identifier':_0x37a32e});if(!_0x4602c0['_instanceStarted']){const _0xb0de9c=hc('database');_0xb0de9c&&nf(_0x4602c0,..._0xb0de9c);}return _0x4602c0;}function nf(_0x450a70,_0x276d4d,_0x4220a5,_0x143c06={}){_0x450a70=P(_0x450a70),_0x450a70['_checkNotDeleted']('useEmulator');const _0x44f695=_0x276d4d+':'+_0x4220a5,_0x3a39e2=_0x450a70['_repoInternal'];if(_0x450a70['_instanceStarted']){if(_0x44f695===_0x450a70['_repoInternal']['repoInfo_']['host']&&xe(_0x143c06,_0x3a39e2['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4b0d23;if(_0x3a39e2['repoInfo_']['nodeAdmin'])_0x143c06['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4b0d23=new an(an['OWNER']);else{if(_0x143c06['mockUserToken']){const _0x138002=typeof _0x143c06['mockUserToken']=='string'?_0x143c06['mockUserToken']:uc(_0x143c06['mockUserToken'],_0x450a70['app']['options']['projectId']);_0x4b0d23=new an(_0x138002);}}qt(_0x276d4d)&&Qr(_0x276d4d),Jd(_0x3a39e2,_0x44f695,_0x143c06,_0x4b0d23);}function N_(_0x282640){_0x282640=P(_0x282640),_0x282640['_checkNotDeleted']('goOffline'),ha(_0x282640['_repo']);}function O_(_0x3216ec){_0x3216ec=P(_0x3216ec),_0x3216ec['_checkNotDeleted']('goOnline'),Nd(_0x3216ec['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x4593a4){Ul(dt),st(new Fe('database',(_0x2a68f2,{instanceIdentifier:_0x33ece3})=>{const _0xd1ea3=_0x2a68f2['getProvider']('app')['getImmediate'](),_0x333e19=_0x2a68f2['getProvider']('auth-internal'),_0x1986d8=_0x2a68f2['getProvider']('app-check-internal');return Xd(_0xd1ea3,_0x333e19,_0x1986d8,_0x33ece3);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x4593a4),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x192467,_0xc1f19c){this['committed']=_0x192467,this['snapshot']=_0xc1f19c;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x51f58f,_0x489d2a,_0x121680){if(_0x51f58f=P(_0x51f58f),Me('Reference.transaction',_0x51f58f['_path']),_0x51f58f['key']==='.length'||_0x51f58f['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x51f58f['key']+'\x20is\x20a\x20read-only\x20object.';const _0x2c88b4=!0x0,_0x4814d7=new H(),_0x530b7f=(_0x46809e,_0x2cfab2,_0x4b6b19)=>{let _0x4c83ec=null;_0x46809e?_0x4814d7['reject'](_0x46809e):(_0x4c83ec=new lt(_0x4b6b19,new ee(_0x51f58f['_repo'],_0x51f58f['_path']),R),_0x4814d7['resolve'](new of(_0x2cfab2,_0x4c83ec)));},_0x1b009d=Gd(_0x51f58f,()=>{});return Od(_0x51f58f['_repo'],_0x51f58f['_path'],_0x489d2a,_0x530b7f,_0x1b009d,_0x2c88b4),_0x4814d7['promise'];}se['prototype']['simpleListen']=function(_0x4a6358,_0x12212b){this['sendRequest']('q',{'p':_0x4a6358},_0x12212b);},se['prototype']['echo']=function(_0x301dee,_0x41b913){this['sendRequest']('echo',{'d':_0x301dee},_0x41b913);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x38611f,..._0x5ad1c6){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x38611f,..._0x5ad1c6);}function cn(_0x6e97f5,..._0x4d1648){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x6e97f5,..._0x4d1648);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0xd23bcc,..._0x32d387){throw ws(_0xd23bcc,..._0x32d387);}function X(_0x313168,..._0x559495){return ws(_0x313168,..._0x559495);}function Ia(_0x3e137f,_0x1c1071,_0xdb33ca){const _0x17b0ee={...af(),[_0x1c1071]:_0xdb33ca};return new Gt('auth','Firebase',_0x17b0ee)['create'](_0x1c1071,{'appName':_0x3e137f['name']});}function re(_0x46b8de){return Ia(_0x46b8de,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x558a6e,..._0x37bba1){if(typeof _0x558a6e!='string'){const _0xeef7d4=_0x37bba1[0x0],_0x1c6884=[..._0x37bba1['slice'](0x1)];return _0x1c6884[0x0]&&(_0x1c6884[0x0]['appName']=_0x558a6e['name']),_0x558a6e['_errorFactory']['create'](_0xeef7d4,..._0x1c6884);}return Ea['create'](_0x558a6e,..._0x37bba1);}function m(_0x52cbf4,_0x301fb4,..._0x3a5c57){if(!_0x52cbf4)throw ws(_0x301fb4,..._0x3a5c57);}function ne(_0x54b2fd){const _0x55dc91='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x54b2fd;throw cn(_0x55dc91),new Error(_0x55dc91);}function ce(_0xd733a7,_0x339730){_0xd733a7||ne(_0x339730);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x3bce91;return typeof self<'u'&&((_0x3bce91=self['location'])==null?void 0x0:_0x3bce91['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x20ffac;return typeof self<'u'&&((_0x20ffac=self['location'])==null?void 0x0:_0x20ffac['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x48bae8=navigator;return _0x48bae8['languages']&&_0x48bae8['languages'][0x0]||_0x48bae8['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x458e79,_0x42999a){this['shortDelay']=_0x458e79,this['longDelay']=_0x42999a,ce(_0x42999a>_0x458e79,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x39033f,_0x4d9a5c){ce(_0x39033f['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x18c527}=_0x39033f['emulator'];return _0x4d9a5c?''+_0x18c527+(_0x4d9a5c['startsWith']('/')?_0x4d9a5c['slice'](0x1):_0x4d9a5c):_0x18c527;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x281594,_0x303cc5,_0x3a7a00){this['fetchImpl']=_0x281594,_0x303cc5&&(this['headersImpl']=_0x303cc5),_0x3a7a00&&(this['responseImpl']=_0x3a7a00);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x5762de,_0x23ffd0){return _0x5762de['tenantId']&&!_0x23ffd0['tenantId']?{..._0x23ffd0,'tenantId':_0x5762de['tenantId']}:_0x23ffd0;}async function Pe(_0xc78b72,_0x471a11,_0x5a4d82,_0x2243e5,_0x5b60dd={}){return Ca(_0xc78b72,_0x5b60dd,async()=>{let _0x5cde99={},_0x24cb5f={};_0x2243e5&&(_0x471a11==='GET'?_0x24cb5f=_0x2243e5:_0x5cde99={'body':JSON['stringify'](_0x2243e5)});const _0x1c6641=ut({..._0x24cb5f,'key':_0xc78b72['config']['apiKey']})['slice'](0x1),_0x135729=await _0xc78b72['_getAdditionalHeaders']();_0x135729['Content-Type']='application/json',_0xc78b72['languageCode']&&(_0x135729['X-Firebase-Locale']=_0xc78b72['languageCode']);const _0x1dfda6={'method':_0x471a11,'headers':_0x135729,..._0x5cde99};return dc()||(_0x1dfda6['referrerPolicy']='strict-origin-when-cross-origin'),_0xc78b72['emulatorConfig']&&qt(_0xc78b72['emulatorConfig']['host'])&&(_0x1dfda6['credentials']='include'),wa['fetch']()(await Ta(_0xc78b72,_0xc78b72['config']['apiHost'],_0x5a4d82,_0x1c6641),_0x1dfda6);});}async function Ca(_0x176590,_0x26d1b5,_0x2acc3f){_0x176590['_canInitEmulator']=!0x1;const _0x251779={...df,..._0x26d1b5};try{const _0x29583a=new gf(_0x176590),_0x2acf29=await Promise['race']([_0x2acc3f(),_0x29583a['promise']]);_0x29583a['clearNetworkTimeout']();const _0x244e44=await _0x2acf29['json']();if('needConfirmation'in _0x244e44)throw on(_0x176590,'account-exists-with-different-credential',_0x244e44);if(_0x2acf29['ok']&&!('errorMessage'in _0x244e44))return _0x244e44;{const _0x5a6e4a=_0x2acf29['ok']?_0x244e44['errorMessage']:_0x244e44['error']['message'],[_0xf2ec71,_0x5a68ac]=_0x5a6e4a['split']('\x20:\x20');if(_0xf2ec71==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x176590,'credential-already-in-use',_0x244e44);if(_0xf2ec71==='EMAIL_EXISTS')throw on(_0x176590,'email-already-in-use',_0x244e44);if(_0xf2ec71==='USER_DISABLED')throw on(_0x176590,'user-disabled',_0x244e44);const _0x30587e=_0x251779[_0xf2ec71]||_0xf2ec71['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x5a68ac)throw Ia(_0x176590,_0x30587e,_0x5a68ac);Y(_0x176590,_0x30587e);}}catch(_0x22673b){if(_0x22673b instanceof Re)throw _0x22673b;Y(_0x176590,'network-request-failed',{'message':String(_0x22673b)});}}async function en(_0x134323,_0x140759,_0x33bab6,_0x2a4141,_0x284caf={}){const _0x4bc420=await Pe(_0x134323,_0x140759,_0x33bab6,_0x2a4141,_0x284caf);return'mfaPendingCredential'in _0x4bc420&&Y(_0x134323,'multi-factor-auth-required',{'_serverResponse':_0x4bc420}),_0x4bc420;}async function Ta(_0x3774cb,_0x201444,_0x42304,_0x553790){const _0x55bd2f=''+_0x201444+_0x42304+'?'+_0x553790,_0x58cf78=_0x3774cb,_0x287a31=_0x58cf78['config']['emulator']?Cs(_0x3774cb['config'],_0x55bd2f):_0x3774cb['config']['apiScheme']+'://'+_0x55bd2f;return ff['includes'](_0x42304)&&(await _0x58cf78['_persistenceManagerAvailable'],_0x58cf78['_getPersistenceType']()==='COOKIE')?_0x58cf78['_getPersistence']()['_getFinalTarget'](_0x287a31)['toString']():_0x287a31;}function _f(_0x4778be){switch(_0x4778be){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x231a93){this['auth']=_0x231a93,this['timer']=null,this['promise']=new Promise((_0x1f469c,_0x26a55a)=>{this['timer']=setTimeout(()=>_0x26a55a(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x4a8c39,_0x423cda,_0x505a1a){const _0x86fb0f={'appName':_0x4a8c39['name']};_0x505a1a['email']&&(_0x86fb0f['email']=_0x505a1a['email']),_0x505a1a['phoneNumber']&&(_0x86fb0f['phoneNumber']=_0x505a1a['phoneNumber']);const _0x1113ae=X(_0x4a8c39,_0x423cda,_0x86fb0f);return _0x1113ae['customData']['_tokenResponse']=_0x505a1a,_0x1113ae;}function wr(_0x316905){return _0x316905!==void 0x0&&_0x316905['enterprise']!==void 0x0;}class mf{constructor(_0x48f3a6){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x48f3a6['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x48f3a6['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x48f3a6['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x5536ff){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x534b59 of this['recaptchaEnforcementState'])if(_0x534b59['provider']&&_0x534b59['provider']===_0x5536ff)return _f(_0x534b59['enforcementState']);return null;}['isProviderEnabled'](_0x17cf32){return this['getProviderEnforcementState'](_0x17cf32)==='ENFORCE'||this['getProviderEnforcementState'](_0x17cf32)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5a782f,_0x49467e){return Pe(_0x5a782f,'GET','/v2/recaptchaConfig',ke(_0x5a782f,_0x49467e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x18a21a,_0x25856f){return Pe(_0x18a21a,'POST','/v1/accounts:delete',_0x25856f);}async function Pn(_0x11768d,_0xa0318a){return Pe(_0x11768d,'POST','/v1/accounts:lookup',_0xa0318a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x49677a){if(_0x49677a)try{const _0x9db3dd=new Date(Number(_0x49677a));if(!isNaN(_0x9db3dd['getTime']()))return _0x9db3dd['toUTCString']();}catch{}}async function Ef(_0x6fbd16,_0x1d5dca=!0x1){const _0x4e664e=P(_0x6fbd16),_0x480d52=await _0x4e664e['getIdToken'](_0x1d5dca),_0x4b257a=Ts(_0x480d52);m(_0x4b257a&&_0x4b257a['exp']&&_0x4b257a['auth_time']&&_0x4b257a['iat'],_0x4e664e['auth'],'internal-error');const _0x5d5639=typeof _0x4b257a['firebase']=='object'?_0x4b257a['firebase']:void 0x0,_0x11c1f9=_0x5d5639==null?void 0x0:_0x5d5639['sign_in_provider'];return{'claims':_0x4b257a,'token':_0x480d52,'authTime':Pt(fi(_0x4b257a['auth_time'])),'issuedAtTime':Pt(fi(_0x4b257a['iat'])),'expirationTime':Pt(fi(_0x4b257a['exp'])),'signInProvider':_0x11c1f9||null,'signInSecondFactor':(_0x5d5639==null?void 0x0:_0x5d5639['sign_in_second_factor'])||null};}function fi(_0x206ebb){return Number(_0x206ebb)*0x3e8;}function Ts(_0x20c2a9){const [_0x226ded,_0x4bec08,_0x3adcb9]=_0x20c2a9['split']('.');if(_0x226ded===void 0x0||_0x4bec08===void 0x0||_0x3adcb9===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x44d88b=fn(_0x4bec08);return _0x44d88b?JSON['parse'](_0x44d88b):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4182a5){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4182a5==null?void 0x0:_0x4182a5['toString']()),null;}}function Cr(_0x273519){const _0x49120a=Ts(_0x273519);return m(_0x49120a,'internal-error'),m(typeof _0x49120a['exp']<'u','internal-error'),m(typeof _0x49120a['iat']<'u','internal-error'),Number(_0x49120a['exp'])-Number(_0x49120a['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x41a57d,_0x3c7b4c,_0x3f7708=!0x1){if(_0x3f7708)return _0x3c7b4c;try{return await _0x3c7b4c;}catch(_0x2a7aa5){throw _0x2a7aa5 instanceof Re&&If(_0x2a7aa5)&&_0x41a57d['auth']['currentUser']===_0x41a57d&&await _0x41a57d['auth']['signOut'](),_0x2a7aa5;}}function If({code:_0x333cbc}){return _0x333cbc==='auth/user-disabled'||_0x333cbc==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x383d5c){this['user']=_0x383d5c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x399e4f){if(_0x399e4f){const _0x4954ee=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4954ee;}else{this['errorBackoff']=0x7530;const _0x4b050b=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4b050b);}}['schedule'](_0x160e7d=!0x1){if(!this['isRunning'])return;const _0x6c2988=this['getInterval'](_0x160e7d);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x6c2988);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x572ce4){(_0x572ce4==null?void 0x0:_0x572ce4['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x368cc2,_0x559582){this['createdAt']=_0x368cc2,this['lastLoginAt']=_0x559582,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x56032a){this['createdAt']=_0x56032a['createdAt'],this['lastLoginAt']=_0x56032a['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x103a1b){var _0x11737d;const _0x1a5722=_0x103a1b['auth'],_0x496244=await _0x103a1b['getIdToken'](),_0x136b8a=await Ht(_0x103a1b,Pn(_0x1a5722,{'idToken':_0x496244}));m(_0x136b8a==null?void 0x0:_0x136b8a['users']['length'],_0x1a5722,'internal-error');const _0x4aeab8=_0x136b8a['users'][0x0];_0x103a1b['_notifyReloadListener'](_0x4aeab8);const _0x3fc49e=(_0x11737d=_0x4aeab8['providerUserInfo'])!=null&&_0x11737d['length']?Sa(_0x4aeab8['providerUserInfo']):[],_0x29335c=Tf(_0x103a1b['providerData'],_0x3fc49e),_0x41d46b=_0x103a1b['isAnonymous'],_0x5a6894=!(_0x103a1b['email']&&_0x4aeab8['passwordHash'])&&!(_0x29335c!=null&&_0x29335c['length']),_0x3edb14=_0x41d46b?_0x5a6894:!0x1,_0x1c8d6d={'uid':_0x4aeab8['localId'],'displayName':_0x4aeab8['displayName']||null,'photoURL':_0x4aeab8['photoUrl']||null,'email':_0x4aeab8['email']||null,'emailVerified':_0x4aeab8['emailVerified']||!0x1,'phoneNumber':_0x4aeab8['phoneNumber']||null,'tenantId':_0x4aeab8['tenantId']||null,'providerData':_0x29335c,'metadata':new Li(_0x4aeab8['createdAt'],_0x4aeab8['lastLoginAt']),'isAnonymous':_0x3edb14};Object['assign'](_0x103a1b,_0x1c8d6d);}async function Cf(_0x59b3f5){const _0x48e8f2=P(_0x59b3f5);await Nn(_0x48e8f2),await _0x48e8f2['auth']['_persistUserIfCurrent'](_0x48e8f2),_0x48e8f2['auth']['_notifyListenersIfCurrent'](_0x48e8f2);}function Tf(_0x44b723,_0x43da22){return[..._0x44b723['filter'](_0x4296c6=>!_0x43da22['some'](_0x3c64c6=>_0x3c64c6['providerId']===_0x4296c6['providerId'])),..._0x43da22];}function Sa(_0x46ab76){return _0x46ab76['map'](({providerId:_0x32cc7b,..._0x15fe6c})=>({'providerId':_0x32cc7b,'uid':_0x15fe6c['rawId']||'','displayName':_0x15fe6c['displayName']||null,'email':_0x15fe6c['email']||null,'phoneNumber':_0x15fe6c['phoneNumber']||null,'photoURL':_0x15fe6c['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x57b062,_0x1e3790){const _0x389878=await Ca(_0x57b062,{},async()=>{const _0xe8d8d9=ut({'grant_type':'refresh_token','refresh_token':_0x1e3790})['slice'](0x1),{tokenApiHost:_0x5be647,apiKey:_0x20e7bb}=_0x57b062['config'],_0x3cde03=await Ta(_0x57b062,_0x5be647,'/v1/token','key='+_0x20e7bb),_0x2708f9=await _0x57b062['_getAdditionalHeaders']();_0x2708f9['Content-Type']='application/x-www-form-urlencoded';const _0x340b18={'method':'POST','headers':_0x2708f9,'body':_0xe8d8d9};return _0x57b062['emulatorConfig']&&qt(_0x57b062['emulatorConfig']['host'])&&(_0x340b18['credentials']='include'),wa['fetch']()(_0x3cde03,_0x340b18);});return{'accessToken':_0x389878['access_token'],'expiresIn':_0x389878['expires_in'],'refreshToken':_0x389878['refresh_token']};}async function bf(_0x21d892,_0xcfb09){return Pe(_0x21d892,'POST','/v2/accounts:revokeToken',ke(_0x21d892,_0xcfb09));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5a4e22){m(_0x5a4e22['idToken'],'internal-error'),m(typeof _0x5a4e22['idToken']<'u','internal-error'),m(typeof _0x5a4e22['refreshToken']<'u','internal-error');const _0x44cb28='expiresIn'in _0x5a4e22&&typeof _0x5a4e22['expiresIn']<'u'?Number(_0x5a4e22['expiresIn']):Cr(_0x5a4e22['idToken']);this['updateTokensAndExpiration'](_0x5a4e22['idToken'],_0x5a4e22['refreshToken'],_0x44cb28);}['updateFromIdToken'](_0xcba83){m(_0xcba83['length']!==0x0,'internal-error');const _0x588964=Cr(_0xcba83);this['updateTokensAndExpiration'](_0xcba83,null,_0x588964);}async['getToken'](_0x2ab4f9,_0x1da1c6=!0x1){return!_0x1da1c6&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2ab4f9,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2ab4f9,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x4707b9,_0x14f63){const {accessToken:_0x3bdbed,refreshToken:_0x1559c5,expiresIn:_0x28549f}=await Sf(_0x4707b9,_0x14f63);this['updateTokensAndExpiration'](_0x3bdbed,_0x1559c5,Number(_0x28549f));}['updateTokensAndExpiration'](_0x21c1af,_0x5f5897,_0x57c58c){this['refreshToken']=_0x5f5897||null,this['accessToken']=_0x21c1af||null,this['expirationTime']=Date['now']()+_0x57c58c*0x3e8;}static['fromJSON'](_0x18ba5c,_0x40d0a5){const {refreshToken:_0x203531,accessToken:_0x499d15,expirationTime:_0xdfd0d1}=_0x40d0a5,_0xc98b40=new et();return _0x203531&&(m(typeof _0x203531=='string','internal-error',{'appName':_0x18ba5c}),_0xc98b40['refreshToken']=_0x203531),_0x499d15&&(m(typeof _0x499d15=='string','internal-error',{'appName':_0x18ba5c}),_0xc98b40['accessToken']=_0x499d15),_0xdfd0d1&&(m(typeof _0xdfd0d1=='number','internal-error',{'appName':_0x18ba5c}),_0xc98b40['expirationTime']=_0xdfd0d1),_0xc98b40;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x485b9e){this['accessToken']=_0x485b9e['accessToken'],this['refreshToken']=_0x485b9e['refreshToken'],this['expirationTime']=_0x485b9e['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x9e2466,_0x3dd0cd){m(typeof _0x9e2466=='string'||typeof _0x9e2466>'u','internal-error',{'appName':_0x3dd0cd});}class j{constructor({uid:_0x3e12e1,auth:_0x3b5673,stsTokenManager:_0x33d2ff,..._0x13537b}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3e12e1,this['auth']=_0x3b5673,this['stsTokenManager']=_0x33d2ff,this['accessToken']=_0x33d2ff['accessToken'],this['displayName']=_0x13537b['displayName']||null,this['email']=_0x13537b['email']||null,this['emailVerified']=_0x13537b['emailVerified']||!0x1,this['phoneNumber']=_0x13537b['phoneNumber']||null,this['photoURL']=_0x13537b['photoURL']||null,this['isAnonymous']=_0x13537b['isAnonymous']||!0x1,this['tenantId']=_0x13537b['tenantId']||null,this['providerData']=_0x13537b['providerData']?[..._0x13537b['providerData']]:[],this['metadata']=new Li(_0x13537b['createdAt']||void 0x0,_0x13537b['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1578c3){const _0x274305=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x1578c3));return m(_0x274305,this['auth'],'internal-error'),this['accessToken']!==_0x274305&&(this['accessToken']=_0x274305,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x274305;}['getIdTokenResult'](_0x421df0){return Ef(this,_0x421df0);}['reload'](){return Cf(this);}['_assign'](_0x52ef8c){this!==_0x52ef8c&&(m(this['uid']===_0x52ef8c['uid'],this['auth'],'internal-error'),this['displayName']=_0x52ef8c['displayName'],this['photoURL']=_0x52ef8c['photoURL'],this['email']=_0x52ef8c['email'],this['emailVerified']=_0x52ef8c['emailVerified'],this['phoneNumber']=_0x52ef8c['phoneNumber'],this['isAnonymous']=_0x52ef8c['isAnonymous'],this['tenantId']=_0x52ef8c['tenantId'],this['providerData']=_0x52ef8c['providerData']['map'](_0x4666bd=>({..._0x4666bd})),this['metadata']['_copy'](_0x52ef8c['metadata']),this['stsTokenManager']['_assign'](_0x52ef8c['stsTokenManager']));}['_clone'](_0x44e847){const _0x4c5472=new j({...this,'auth':_0x44e847,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4c5472['metadata']['_copy'](this['metadata']),_0x4c5472;}['_onReload'](_0x1f02d8){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1f02d8,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x54c4cc){this['reloadListener']?this['reloadListener'](_0x54c4cc):this['reloadUserInfo']=_0x54c4cc;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x587b6,_0x1402ed=!0x1){let _0x171256=!0x1;_0x587b6['idToken']&&_0x587b6['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x587b6),_0x171256=!0x0),_0x1402ed&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x171256&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x3af6a2=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x3af6a2})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x46bdf7=>({..._0x46bdf7})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4b9ae3,_0x2324bd){const _0x2354f3=_0x2324bd['displayName']??void 0x0,_0x4befa9=_0x2324bd['email']??void 0x0,_0x3e57ba=_0x2324bd['phoneNumber']??void 0x0,_0x4bf983=_0x2324bd['photoURL']??void 0x0,_0x5aa575=_0x2324bd['tenantId']??void 0x0,_0xd34c74=_0x2324bd['_redirectEventId']??void 0x0,_0x5f1213=_0x2324bd['createdAt']??void 0x0,_0x355b3e=_0x2324bd['lastLoginAt']??void 0x0,{uid:_0x4d8171,emailVerified:_0x37262e,isAnonymous:_0x4a7987,providerData:_0x5176b5,stsTokenManager:_0xe557d9}=_0x2324bd;m(_0x4d8171&&_0xe557d9,_0x4b9ae3,'internal-error');const _0x164f44=et['fromJSON'](this['name'],_0xe557d9);m(typeof _0x4d8171=='string',_0x4b9ae3,'internal-error'),le(_0x2354f3,_0x4b9ae3['name']),le(_0x4befa9,_0x4b9ae3['name']),m(typeof _0x37262e=='boolean',_0x4b9ae3,'internal-error'),m(typeof _0x4a7987=='boolean',_0x4b9ae3,'internal-error'),le(_0x3e57ba,_0x4b9ae3['name']),le(_0x4bf983,_0x4b9ae3['name']),le(_0x5aa575,_0x4b9ae3['name']),le(_0xd34c74,_0x4b9ae3['name']),le(_0x5f1213,_0x4b9ae3['name']),le(_0x355b3e,_0x4b9ae3['name']);const _0x5a80dc=new j({'uid':_0x4d8171,'auth':_0x4b9ae3,'email':_0x4befa9,'emailVerified':_0x37262e,'displayName':_0x2354f3,'isAnonymous':_0x4a7987,'photoURL':_0x4bf983,'phoneNumber':_0x3e57ba,'tenantId':_0x5aa575,'stsTokenManager':_0x164f44,'createdAt':_0x5f1213,'lastLoginAt':_0x355b3e});return _0x5176b5&&Array['isArray'](_0x5176b5)&&(_0x5a80dc['providerData']=_0x5176b5['map'](_0x42b85a=>({..._0x42b85a}))),_0xd34c74&&(_0x5a80dc['_redirectEventId']=_0xd34c74),_0x5a80dc;}static async['_fromIdTokenResponse'](_0x6b3b2f,_0x1bece2,_0x865f56=!0x1){const _0x26f257=new et();_0x26f257['updateFromServerResponse'](_0x1bece2);const _0x35393e=new j({'uid':_0x1bece2['localId'],'auth':_0x6b3b2f,'stsTokenManager':_0x26f257,'isAnonymous':_0x865f56});return await Nn(_0x35393e),_0x35393e;}static async['_fromGetAccountInfoResponse'](_0x22c850,_0x57d199,_0xa1f87d){const _0x37d575=_0x57d199['users'][0x0];m(_0x37d575['localId']!==void 0x0,'internal-error');const _0x3c9fdf=_0x37d575['providerUserInfo']!==void 0x0?Sa(_0x37d575['providerUserInfo']):[],_0x38d75b=!(_0x37d575['email']&&_0x37d575['passwordHash'])&&!(_0x3c9fdf!=null&&_0x3c9fdf['length']),_0x27dd63=new et();_0x27dd63['updateFromIdToken'](_0xa1f87d);const _0x5ed131=new j({'uid':_0x37d575['localId'],'auth':_0x22c850,'stsTokenManager':_0x27dd63,'isAnonymous':_0x38d75b}),_0x13988f={'uid':_0x37d575['localId'],'displayName':_0x37d575['displayName']||null,'photoURL':_0x37d575['photoUrl']||null,'email':_0x37d575['email']||null,'emailVerified':_0x37d575['emailVerified']||!0x1,'phoneNumber':_0x37d575['phoneNumber']||null,'tenantId':_0x37d575['tenantId']||null,'providerData':_0x3c9fdf,'metadata':new Li(_0x37d575['createdAt'],_0x37d575['lastLoginAt']),'isAnonymous':!(_0x37d575['email']&&_0x37d575['passwordHash'])&&!(_0x3c9fdf!=null&&_0x3c9fdf['length'])};return Object['assign'](_0x5ed131,_0x13988f),_0x5ed131;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x55da84){ce(_0x55da84 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1b2ae5=Tr['get'](_0x55da84);return _0x1b2ae5?(ce(_0x1b2ae5 instanceof _0x55da84,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1b2ae5):(_0x1b2ae5=new _0x55da84(),Tr['set'](_0x55da84,_0x1b2ae5),_0x1b2ae5);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3edd74,_0x51d047){this['storage'][_0x3edd74]=_0x51d047;}async['_get'](_0x520c5f){const _0x22918f=this['storage'][_0x520c5f];return _0x22918f===void 0x0?null:_0x22918f;}async['_remove'](_0x57ed4f){delete this['storage'][_0x57ed4f];}['_addListener'](_0x136202,_0x2a17d9){}['_removeListener'](_0x19ecd7,_0x1e3cdb){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0xfe685,_0x45d3be,_0xfa529b){return'firebase:'+_0xfe685+':'+_0x45d3be+':'+_0xfa529b;}class tt{constructor(_0x5d7c9e,_0x107c2,_0x43b424){this['persistence']=_0x5d7c9e,this['auth']=_0x107c2,this['userKey']=_0x43b424;const {config:_0x19bcc2,name:_0x47e955}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x19bcc2['apiKey'],_0x47e955),this['fullPersistenceKey']=ln('persistence',_0x19bcc2['apiKey'],_0x47e955),this['boundEventHandler']=_0x107c2['_onStorageEvent']['bind'](_0x107c2),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x2f1c59){return this['persistence']['_set'](this['fullUserKey'],_0x2f1c59['toJSON']());}async['getCurrentUser'](){const _0x450972=await this['persistence']['_get'](this['fullUserKey']);if(!_0x450972)return null;if(typeof _0x450972=='string'){const _0x3bbe94=await Pn(this['auth'],{'idToken':_0x450972})['catch'](()=>{});return _0x3bbe94?j['_fromGetAccountInfoResponse'](this['auth'],_0x3bbe94,_0x450972):null;}return j['_fromJSON'](this['auth'],_0x450972);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x82165d){if(this['persistence']===_0x82165d)return;const _0x34d71d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x82165d,_0x34d71d)return this['setCurrentUser'](_0x34d71d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5dbca0,_0x52dc0d,_0xe8d15b='authUser'){if(!_0x52dc0d['length'])return new tt(ie(Sr),_0x5dbca0,_0xe8d15b);const _0x344a50=(await Promise['all'](_0x52dc0d['map'](async _0x923d5e=>{if(await _0x923d5e['_isAvailable']())return _0x923d5e;})))['filter'](_0x4e646f=>_0x4e646f);let _0x4610fb=_0x344a50[0x0]||ie(Sr);const _0x476908=ln(_0xe8d15b,_0x5dbca0['config']['apiKey'],_0x5dbca0['name']);let _0x5d0fa3=null;for(const _0x109915 of _0x52dc0d)try{const _0x41f724=await _0x109915['_get'](_0x476908);if(_0x41f724){let _0x41b81d;if(typeof _0x41f724=='string'){const _0x4cf7f9=await Pn(_0x5dbca0,{'idToken':_0x41f724})['catch'](()=>{});if(!_0x4cf7f9)break;_0x41b81d=await j['_fromGetAccountInfoResponse'](_0x5dbca0,_0x4cf7f9,_0x41f724);}else _0x41b81d=j['_fromJSON'](_0x5dbca0,_0x41f724);_0x109915!==_0x4610fb&&(_0x5d0fa3=_0x41b81d),_0x4610fb=_0x109915;break;}}catch{}const _0x4d6333=_0x344a50['filter'](_0x1c22db=>_0x1c22db['_shouldAllowMigration']);return!_0x4610fb['_shouldAllowMigration']||!_0x4d6333['length']?new tt(_0x4610fb,_0x5dbca0,_0xe8d15b):(_0x4610fb=_0x4d6333[0x0],_0x5d0fa3&&await _0x4610fb['_set'](_0x476908,_0x5d0fa3['toJSON']()),await Promise['all'](_0x52dc0d['map'](async _0x1f27fe=>{if(_0x1f27fe!==_0x4610fb)try{await _0x1f27fe['_remove'](_0x476908);}catch{}})),new tt(_0x4610fb,_0x5dbca0,_0xe8d15b));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x28ba8c){const _0x17d3af=_0x28ba8c['toLowerCase']();if(_0x17d3af['includes']('opera/')||_0x17d3af['includes']('opr/')||_0x17d3af['includes']('opios/'))return'Opera';if(Pa(_0x17d3af))return'IEMobile';if(_0x17d3af['includes']('msie')||_0x17d3af['includes']('trident/'))return'IE';if(_0x17d3af['includes']('edge/'))return'Edge';if(Ra(_0x17d3af))return'Firefox';if(_0x17d3af['includes']('silk/'))return'Silk';if(Oa(_0x17d3af))return'Blackberry';if(Da(_0x17d3af))return'Webos';if(Aa(_0x17d3af))return'Safari';if((_0x17d3af['includes']('chrome/')||ka(_0x17d3af))&&!_0x17d3af['includes']('edge/'))return'Chrome';if(Na(_0x17d3af))return'Android';{const _0x32ae8a=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1bdac5=_0x28ba8c['match'](_0x32ae8a);if((_0x1bdac5==null?void 0x0:_0x1bdac5['length'])===0x2)return _0x1bdac5[0x1];}return'Other';}function Ra(_0x2aa526=W()){return/firefox\//i['test'](_0x2aa526);}function Aa(_0x1e6cd0=W()){const _0x50d383=_0x1e6cd0['toLowerCase']();return _0x50d383['includes']('safari/')&&!_0x50d383['includes']('chrome/')&&!_0x50d383['includes']('crios/')&&!_0x50d383['includes']('android');}function ka(_0x9099ef=W()){return/crios\//i['test'](_0x9099ef);}function Pa(_0x1e8f84=W()){return/iemobile/i['test'](_0x1e8f84);}function Na(_0x54f2ad=W()){return/android/i['test'](_0x54f2ad);}function Oa(_0x2b0a0f=W()){return/blackberry/i['test'](_0x2b0a0f);}function Da(_0x3bf9df=W()){return/webos/i['test'](_0x3bf9df);}function Ss(_0x54d403=W()){return/iphone|ipad|ipod/i['test'](_0x54d403)||/macintosh/i['test'](_0x54d403)&&/mobile/i['test'](_0x54d403);}function Rf(_0x52da65=W()){var _0x28b336;return Ss(_0x52da65)&&!!((_0x28b336=window['navigator'])!=null&&_0x28b336['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x2f7126=W()){return Ss(_0x2f7126)||Na(_0x2f7126)||Da(_0x2f7126)||Oa(_0x2f7126)||/windows phone/i['test'](_0x2f7126)||Pa(_0x2f7126);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x1a1557,_0x47faba=[]){let _0x19af6c;switch(_0x1a1557){case'Browser':_0x19af6c=br(W());break;case'Worker':_0x19af6c=br(W())+'-'+_0x1a1557;break;default:_0x19af6c=_0x1a1557;}const _0x1bf5a6=_0x47faba['length']?_0x47faba['join'](','):'FirebaseCore-web';return _0x19af6c+'/JsCore/'+dt+'/'+_0x1bf5a6;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x32b408){this['auth']=_0x32b408,this['queue']=[];}['pushCallback'](_0x480983,_0x2a2337){const _0x11eafa=_0x29b8a4=>new Promise((_0xaecb34,_0x3303fb)=>{try{const _0x4aed27=_0x480983(_0x29b8a4);_0xaecb34(_0x4aed27);}catch(_0x1295d7){_0x3303fb(_0x1295d7);}});_0x11eafa['onAbort']=_0x2a2337,this['queue']['push'](_0x11eafa);const _0x4fb446=this['queue']['length']-0x1;return()=>{this['queue'][_0x4fb446]=()=>Promise['resolve']();};}async['runMiddleware'](_0x2a7abf){if(this['auth']['currentUser']===_0x2a7abf)return;const _0x455edc=[];try{for(const _0x2057cd of this['queue'])await _0x2057cd(_0x2a7abf),_0x2057cd['onAbort']&&_0x455edc['push'](_0x2057cd['onAbort']);}catch(_0x36edae){_0x455edc['reverse']();for(const _0x3bf2d7 of _0x455edc)try{_0x3bf2d7();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x36edae==null?void 0x0:_0x36edae['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x541db9,_0x982fe6={}){return Pe(_0x541db9,'GET','/v2/passwordPolicy',ke(_0x541db9,_0x982fe6));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x580b9e){var _0x523192;const _0x35c9b8=_0x580b9e['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x35c9b8['minPasswordLength']??Nf,_0x35c9b8['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x35c9b8['maxPasswordLength']),_0x35c9b8['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x35c9b8['containsLowercaseCharacter']),_0x35c9b8['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x35c9b8['containsUppercaseCharacter']),_0x35c9b8['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x35c9b8['containsNumericCharacter']),_0x35c9b8['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x35c9b8['containsNonAlphanumericCharacter']),this['enforcementState']=_0x580b9e['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x523192=_0x580b9e['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x523192['join'](''))??'',this['forceUpgradeOnSignin']=_0x580b9e['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x580b9e['schemaVersion'];}['validatePassword'](_0x2e9e41){const _0x20efe5={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2e9e41,_0x20efe5),this['validatePasswordCharacterOptions'](_0x2e9e41,_0x20efe5),_0x20efe5['isValid']&&(_0x20efe5['isValid']=_0x20efe5['meetsMinPasswordLength']??!0x0),_0x20efe5['isValid']&&(_0x20efe5['isValid']=_0x20efe5['meetsMaxPasswordLength']??!0x0),_0x20efe5['isValid']&&(_0x20efe5['isValid']=_0x20efe5['containsLowercaseLetter']??!0x0),_0x20efe5['isValid']&&(_0x20efe5['isValid']=_0x20efe5['containsUppercaseLetter']??!0x0),_0x20efe5['isValid']&&(_0x20efe5['isValid']=_0x20efe5['containsNumericCharacter']??!0x0),_0x20efe5['isValid']&&(_0x20efe5['isValid']=_0x20efe5['containsNonAlphanumericCharacter']??!0x0),_0x20efe5;}['validatePasswordLengthOptions'](_0x5b1239,_0x2fd05a){const _0x4ef72b=this['customStrengthOptions']['minPasswordLength'],_0x542597=this['customStrengthOptions']['maxPasswordLength'];_0x4ef72b&&(_0x2fd05a['meetsMinPasswordLength']=_0x5b1239['length']>=_0x4ef72b),_0x542597&&(_0x2fd05a['meetsMaxPasswordLength']=_0x5b1239['length']<=_0x542597);}['validatePasswordCharacterOptions'](_0xa95ad4,_0x1feb26){this['updatePasswordCharacterOptionsStatuses'](_0x1feb26,!0x1,!0x1,!0x1,!0x1);let _0xa4470c;for(let _0x452941=0x0;_0x452941<_0xa95ad4['length'];_0x452941++)_0xa4470c=_0xa95ad4['charAt'](_0x452941),this['updatePasswordCharacterOptionsStatuses'](_0x1feb26,_0xa4470c>='a'&&_0xa4470c<='z',_0xa4470c>='A'&&_0xa4470c<='Z',_0xa4470c>='0'&&_0xa4470c<='9',this['allowedNonAlphanumericCharacters']['includes'](_0xa4470c));}['updatePasswordCharacterOptionsStatuses'](_0x123e6e,_0x558faf,_0x4fbbaa,_0x10e9da,_0x1ec0e8){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x123e6e['containsLowercaseLetter']||(_0x123e6e['containsLowercaseLetter']=_0x558faf)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x123e6e['containsUppercaseLetter']||(_0x123e6e['containsUppercaseLetter']=_0x4fbbaa)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x123e6e['containsNumericCharacter']||(_0x123e6e['containsNumericCharacter']=_0x10e9da)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x123e6e['containsNonAlphanumericCharacter']||(_0x123e6e['containsNonAlphanumericCharacter']=_0x1ec0e8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x2a6021,_0x1d6941,_0x5f2196,_0x24edec){this['app']=_0x2a6021,this['heartbeatServiceProvider']=_0x1d6941,this['appCheckServiceProvider']=_0x5f2196,this['config']=_0x24edec,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x2a6021['name'],this['clientVersion']=_0x24edec['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x21d074=>this['_resolvePersistenceManagerAvailable']=_0x21d074);}['_initializeWithPersistence'](_0x452698,_0x10c9bc){return _0x10c9bc&&(this['_popupRedirectResolver']=ie(_0x10c9bc)),this['_initializationPromise']=this['queue'](async()=>{var _0x425581,_0x562379,_0xbb7b7a;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x452698),(_0x425581=this['_resolvePersistenceManagerAvailable'])==null||_0x425581['call'](this),!this['_deleted'])){if((_0x562379=this['_popupRedirectResolver'])!=null&&_0x562379['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x10c9bc),this['lastNotifiedUid']=((_0xbb7b7a=this['currentUser'])==null?void 0x0:_0xbb7b7a['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x22b853=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x22b853)){if(this['currentUser']&&_0x22b853&&this['currentUser']['uid']===_0x22b853['uid']){this['_currentUser']['_assign'](_0x22b853),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x22b853,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x405225){try{const _0x2f4811=await Pn(this,{'idToken':_0x405225}),_0x40488c=await j['_fromGetAccountInfoResponse'](this,_0x2f4811,_0x405225);await this['directlySetCurrentUser'](_0x40488c);}catch(_0x4ff043){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4ff043),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2ec808){var _0x5aae42;if($(this['app'])){const _0x269454=this['app']['settings']['authIdToken'];return _0x269454?new Promise(_0x17c653=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x269454)['then'](_0x17c653,_0x17c653));}):this['directlySetCurrentUser'](null);}const _0x3c9143=await this['assertedPersistence']['getCurrentUser']();let _0x2b98e4=_0x3c9143,_0x1a6d22=!0x1;if(_0x2ec808&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5ee45c=(_0x5aae42=this['redirectUser'])==null?void 0x0:_0x5aae42['_redirectEventId'],_0x16b25c=_0x2b98e4==null?void 0x0:_0x2b98e4['_redirectEventId'],_0x268330=await this['tryRedirectSignIn'](_0x2ec808);(!_0x5ee45c||_0x5ee45c===_0x16b25c)&&(_0x268330!=null&&_0x268330['user'])&&(_0x2b98e4=_0x268330['user'],_0x1a6d22=!0x0);}if(!_0x2b98e4)return this['directlySetCurrentUser'](null);if(!_0x2b98e4['_redirectEventId']){if(_0x1a6d22)try{await this['beforeStateQueue']['runMiddleware'](_0x2b98e4);}catch(_0x567a26){_0x2b98e4=_0x3c9143,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x567a26));}return _0x2b98e4?this['reloadAndSetCurrentUserOrClear'](_0x2b98e4):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x2b98e4['_redirectEventId']?this['directlySetCurrentUser'](_0x2b98e4):this['reloadAndSetCurrentUserOrClear'](_0x2b98e4);}async['tryRedirectSignIn'](_0x472c74){let _0x1a1866=null;try{_0x1a1866=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x472c74,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1a1866;}async['reloadAndSetCurrentUserOrClear'](_0x1c9ed4){try{await Nn(_0x1c9ed4);}catch(_0x367804){if((_0x367804==null?void 0x0:_0x367804['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x1c9ed4);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x1e3d26){if($(this['app']))return Promise['reject'](re(this));const _0x3dc000=_0x1e3d26?P(_0x1e3d26):null;return _0x3dc000&&m(_0x3dc000['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3dc000&&_0x3dc000['_clone'](this));}async['_updateCurrentUser'](_0x3cf468,_0x12824a=!0x1){if(!this['_deleted'])return _0x3cf468&&m(this['tenantId']===_0x3cf468['tenantId'],this,'tenant-id-mismatch'),_0x12824a||await this['beforeStateQueue']['runMiddleware'](_0x3cf468),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x3cf468),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x14c1cb){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x14c1cb));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2a976d){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x273804=this['_getPasswordPolicyInternal']();return _0x273804['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x273804['validatePassword'](_0x2a976d);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3b4252=await Pf(this),_0x28df6b=new Of(_0x3b4252);this['tenantId']===null?this['_projectPasswordPolicy']=_0x28df6b:this['_tenantPasswordPolicies'][this['tenantId']]=_0x28df6b;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x56fc99){this['_errorFactory']=new Gt('auth','Firebase',_0x56fc99());}['onAuthStateChanged'](_0x7d7ae2,_0x5b18e5,_0x2c3096){return this['registerStateListener'](this['authStateSubscription'],_0x7d7ae2,_0x5b18e5,_0x2c3096);}['beforeAuthStateChanged'](_0x224054,_0x149d02){return this['beforeStateQueue']['pushCallback'](_0x224054,_0x149d02);}['onIdTokenChanged'](_0x2bd270,_0x1d72f2,_0x3e73fe){return this['registerStateListener'](this['idTokenSubscription'],_0x2bd270,_0x1d72f2,_0x3e73fe);}['authStateReady'](){return new Promise((_0x1e98f4,_0x36e342)=>{if(this['currentUser'])_0x1e98f4();else{const _0x24cf60=this['onAuthStateChanged'](()=>{_0x24cf60(),_0x1e98f4();},_0x36e342);}});}async['revokeAccessToken'](_0x1bd575){if(this['currentUser']){const _0xc40734=await this['currentUser']['getIdToken'](),_0x23780c={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1bd575,'idToken':_0xc40734};this['tenantId']!=null&&(_0x23780c['tenantId']=this['tenantId']),await bf(this,_0x23780c);}}['toJSON'](){var _0x11f5dc;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x11f5dc=this['_currentUser'])==null?void 0x0:_0x11f5dc['toJSON']()};}async['_setRedirectUser'](_0x487874,_0x1167b2){const _0x4f3b12=await this['getOrInitRedirectPersistenceManager'](_0x1167b2);return _0x487874===null?_0x4f3b12['removeCurrentUser']():_0x4f3b12['setCurrentUser'](_0x487874);}async['getOrInitRedirectPersistenceManager'](_0x27f60e){if(!this['redirectPersistenceManager']){const _0x25c45f=_0x27f60e&&ie(_0x27f60e)||this['_popupRedirectResolver'];m(_0x25c45f,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x25c45f['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x491e0d){var _0x2286db,_0x55d356;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2286db=this['_currentUser'])==null?void 0x0:_0x2286db['_redirectEventId'])===_0x491e0d?this['_currentUser']:((_0x55d356=this['redirectUser'])==null?void 0x0:_0x55d356['_redirectEventId'])===_0x491e0d?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5ea88f){if(_0x5ea88f===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5ea88f));}['_notifyListenersIfCurrent'](_0x41da71){_0x41da71===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x580416;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x354276=((_0x580416=this['currentUser'])==null?void 0x0:_0x580416['uid'])??null;this['lastNotifiedUid']!==_0x354276&&(this['lastNotifiedUid']=_0x354276,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1e82ec,_0x24ba4b,_0x46c1f6,_0x2a57f7){if(this['_deleted'])return()=>{};const _0x300d3c=typeof _0x24ba4b=='function'?_0x24ba4b:_0x24ba4b['next']['bind'](_0x24ba4b);let _0x1aeace=!0x1;const _0x112e1f=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x112e1f,this,'internal-error'),_0x112e1f['then'](()=>{_0x1aeace||_0x300d3c(this['currentUser']);}),typeof _0x24ba4b=='function'){const _0x37bac6=_0x1e82ec['addObserver'](_0x24ba4b,_0x46c1f6,_0x2a57f7);return()=>{_0x1aeace=!0x0,_0x37bac6();};}else{const _0x362ed4=_0x1e82ec['addObserver'](_0x24ba4b);return()=>{_0x1aeace=!0x0,_0x362ed4();};}}async['directlySetCurrentUser'](_0x598aa0){this['currentUser']&&this['currentUser']!==_0x598aa0&&this['_currentUser']['_stopProactiveRefresh'](),_0x598aa0&&this['isProactiveRefreshEnabled']&&_0x598aa0['_startProactiveRefresh'](),this['currentUser']=_0x598aa0,_0x598aa0?await this['assertedPersistence']['setCurrentUser'](_0x598aa0):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x446a24){return this['operations']=this['operations']['then'](_0x446a24,_0x446a24),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4c9e9d){!_0x4c9e9d||this['frameworks']['includes'](_0x4c9e9d)||(this['frameworks']['push'](_0x4c9e9d),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x20069a;const _0x3d9e38={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3d9e38['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4ba808=await((_0x20069a=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x20069a['getHeartbeatsHeader']());_0x4ba808&&(_0x3d9e38['X-Firebase-Client']=_0x4ba808);const _0x5cc09c=await this['_getAppCheckToken']();return _0x5cc09c&&(_0x3d9e38['X-Firebase-AppCheck']=_0x5cc09c),_0x3d9e38;}async['_getAppCheckToken'](){var _0x509c83;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x13b4d3=await((_0x509c83=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x509c83['getToken']());return _0x13b4d3!=null&&_0x13b4d3['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x13b4d3['error']),_0x13b4d3==null?void 0x0:_0x13b4d3['token'];}}function Ke(_0x4ec567){return P(_0x4ec567);}class Rr{constructor(_0x28dd89){this['auth']=_0x28dd89,this['observer']=null,this['addObserver']=Tc(_0x207601=>this['observer']=_0x207601);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x4b4555){Jn=_0x4b4555;}function xa(_0x581392){return Jn['loadJS'](_0x581392);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x1ee95a){return'__'+_0x1ee95a+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0xde54c7){_0xde54c7();}['execute'](_0x53388a,_0x4ea59e){return Promise['resolve']('token');}['render'](_0x2fcd6f,_0xa478b6){return'';}}class Wf{['ready'](_0x406361){_0x406361();}['execute'](_0x18216f,_0x710b94){return Promise['resolve']('token');}['render'](_0x58cf39,_0x26a832){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x236940){this['type']=Bf,this['auth']=Ke(_0x236940);}async['verify'](_0x1efcd0='verify',_0x113313=!0x1){async function _0x2d6327(_0x3de472){if(!_0x113313){if(_0x3de472['tenantId']==null&&_0x3de472['_agentRecaptchaConfig']!=null)return _0x3de472['_agentRecaptchaConfig']['siteKey'];if(_0x3de472['tenantId']!=null&&_0x3de472['_tenantRecaptchaConfigs'][_0x3de472['tenantId']]!==void 0x0)return _0x3de472['_tenantRecaptchaConfigs'][_0x3de472['tenantId']]['siteKey'];}return new Promise(async(_0x47cfc3,_0x504809)=>{yf(_0x3de472,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x21dea5=>{if(_0x21dea5['recaptchaKey']===void 0x0)_0x504809(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x404c27=new mf(_0x21dea5);return _0x3de472['tenantId']==null?_0x3de472['_agentRecaptchaConfig']=_0x404c27:_0x3de472['_tenantRecaptchaConfigs'][_0x3de472['tenantId']]=_0x404c27,_0x47cfc3(_0x404c27['siteKey']);}})['catch'](_0x522a7b=>{_0x504809(_0x522a7b);});});}function _0x3fabe4(_0x21e244,_0x2494ff,_0x82b0a5){const _0x35fa5e=window['grecaptcha'];wr(_0x35fa5e)?_0x35fa5e['enterprise']['ready'](()=>{_0x35fa5e['enterprise']['execute'](_0x21e244,{'action':_0x1efcd0})['then'](_0x2761f1=>{_0x2494ff(_0x2761f1);})['catch'](()=>{_0x2494ff(Fa);});}):_0x82b0a5(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x148391,_0x1c0691)=>{_0x2d6327(this['auth'])['then'](async _0x312919=>{if(!_0x113313&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x3fabe4(_0x312919,_0x148391,_0x1c0691);else{if(typeof window>'u'){_0x1c0691(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4df50b=Lf();_0x4df50b['length']!==0x0&&(_0x4df50b+=_0x312919+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x5f6fa5;(_0x5f6fa5=he['scriptInjectionDeferred'])==null||_0x5f6fa5['resolve']();},xa(_0x4df50b)['then'](()=>{var _0x429a11;return(_0x429a11=he['scriptInjectionDeferred'])==null?void 0x0:_0x429a11['promise'];})['then'](()=>{_0x3fabe4(_0x312919,_0x148391,_0x1c0691);})['catch'](_0x5d8cce=>{_0x1c0691(_0x5d8cce);});}})['catch'](_0x4fdf72=>{_0x1c0691(_0x4fdf72);});});}}he['scriptInjectionDeferred']=null;async function kr(_0xc268e8,_0x49d7dd,_0x57d1d5,_0x16274e=!0x1,_0x3346a1=!0x1){const _0x34e9ce=new he(_0xc268e8);let _0x5817a8;if(_0x3346a1)_0x5817a8=Fa;else try{_0x5817a8=await _0x34e9ce['verify'](_0x57d1d5);}catch{_0x5817a8=await _0x34e9ce['verify'](_0x57d1d5,!0x0);}const _0x3b8987={..._0x49d7dd};if(_0x57d1d5==='mfaSmsEnrollment'||_0x57d1d5==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3b8987){const _0x55483f=_0x3b8987['phoneEnrollmentInfo']['phoneNumber'],_0xe0579d=_0x3b8987['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3b8987,{'phoneEnrollmentInfo':{'phoneNumber':_0x55483f,'recaptchaToken':_0xe0579d,'captchaResponse':_0x5817a8,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3b8987){const _0x266fb2=_0x3b8987['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3b8987,{'phoneSignInInfo':{'recaptchaToken':_0x266fb2,'captchaResponse':_0x5817a8,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3b8987;}return _0x16274e?Object['assign'](_0x3b8987,{'captchaResp':_0x5817a8}):Object['assign'](_0x3b8987,{'captchaResponse':_0x5817a8}),Object['assign'](_0x3b8987,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3b8987,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3b8987;}async function xi(_0x52c7ee,_0x5ec496,_0x92f623,_0x2711b2,_0x2e3250){var _0x4aab11;if((_0x4aab11=_0x52c7ee['_getRecaptchaConfig']())!=null&&_0x4aab11['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x2d0ed3=await kr(_0x52c7ee,_0x5ec496,_0x92f623,_0x92f623==='getOobCode');return _0x2711b2(_0x52c7ee,_0x2d0ed3);}else return _0x2711b2(_0x52c7ee,_0x5ec496)['catch'](async _0x4b3df5=>{if(_0x4b3df5['code']==='auth/missing-recaptcha-token'){console['log'](_0x92f623+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5b8e94=await kr(_0x52c7ee,_0x5ec496,_0x92f623,_0x92f623==='getOobCode');return _0x2711b2(_0x52c7ee,_0x5b8e94);}else return Promise['reject'](_0x4b3df5);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x4db20d,_0xded6a4){const _0x3e0122=Hi(_0x4db20d,'auth');if(_0x3e0122['isInitialized']()){const _0x199dea=_0x3e0122['getImmediate'](),_0x92b456=_0x3e0122['getOptions']();if(xe(_0x92b456,_0xded6a4??{}))return _0x199dea;Y(_0x199dea,'already-initialized');}return _0x3e0122['initialize']({'options':_0xded6a4});}function Hf(_0x36e3dc,_0x1a720f){const _0xa58c83=(_0x1a720f==null?void 0x0:_0x1a720f['persistence'])||[],_0x34b235=(Array['isArray'](_0xa58c83)?_0xa58c83:[_0xa58c83])['map'](ie);_0x1a720f!=null&&_0x1a720f['errorMap']&&_0x36e3dc['_updateErrorMap'](_0x1a720f['errorMap']),_0x36e3dc['_initializeWithPersistence'](_0x34b235,_0x1a720f==null?void 0x0:_0x1a720f['popupRedirectResolver']);}function $f(_0x480c86,_0xdfa18c,_0x30c3e2){const _0x3cc334=Ke(_0x480c86);m(/^https?:\/\//['test'](_0xdfa18c),_0x3cc334,'invalid-emulator-scheme');const _0x10a8a6=!0x1,_0x4327bf=Ua(_0xdfa18c),{host:_0x4b5fb8,port:_0x12e472}=Gf(_0xdfa18c),_0x3c5883=_0x12e472===null?'':':'+_0x12e472,_0x28307b={'url':_0x4327bf+'//'+_0x4b5fb8+_0x3c5883+'/'},_0x214305=Object['freeze']({'host':_0x4b5fb8,'port':_0x12e472,'protocol':_0x4327bf['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x10a8a6})});if(!_0x3cc334['_canInitEmulator']){m(_0x3cc334['config']['emulator']&&_0x3cc334['emulatorConfig'],_0x3cc334,'emulator-config-failed'),m(xe(_0x28307b,_0x3cc334['config']['emulator'])&&xe(_0x214305,_0x3cc334['emulatorConfig']),_0x3cc334,'emulator-config-failed');return;}_0x3cc334['config']['emulator']=_0x28307b,_0x3cc334['emulatorConfig']=_0x214305,_0x3cc334['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x4b5fb8)?Qr(_0x4327bf+'//'+_0x4b5fb8+_0x3c5883):qf();}function Ua(_0x35e506){const _0x4da68a=_0x35e506['indexOf'](':');return _0x4da68a<0x0?'':_0x35e506['substr'](0x0,_0x4da68a+0x1);}function Gf(_0x12fe2f){const _0x39ed50=Ua(_0x12fe2f),_0x33d0c6=/(\/\/)?([^?#/]+)/['exec'](_0x12fe2f['substr'](_0x39ed50['length']));if(!_0x33d0c6)return{'host':'','port':null};const _0x5ae3c9=_0x33d0c6[0x2]['split']('@')['pop']()||'',_0x4187c1=/^(\[[^\]]+\])(:|$)/['exec'](_0x5ae3c9);if(_0x4187c1){const _0x42f588=_0x4187c1[0x1];return{'host':_0x42f588,'port':Pr(_0x5ae3c9['substr'](_0x42f588['length']+0x1))};}else{const [_0x598fc3,_0x1aa77d]=_0x5ae3c9['split'](':');return{'host':_0x598fc3,'port':Pr(_0x1aa77d)};}}function Pr(_0x51d59e){if(!_0x51d59e)return null;const _0x52fb5e=Number(_0x51d59e);return isNaN(_0x52fb5e)?null:_0x52fb5e;}function qf(){function _0x23a7fc(){const _0x4e35f4=document['createElement']('p'),_0x221436=_0x4e35f4['style'];_0x4e35f4['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x221436['position']='fixed',_0x221436['width']='100%',_0x221436['backgroundColor']='#ffffff',_0x221436['border']='.1em\x20solid\x20#000000',_0x221436['color']='#b50000',_0x221436['bottom']='0px',_0x221436['left']='0px',_0x221436['margin']='0px',_0x221436['zIndex']='10000',_0x221436['textAlign']='center',_0x4e35f4['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4e35f4);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x23a7fc):_0x23a7fc());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3018d6,_0xc0233c){this['providerId']=_0x3018d6,this['signInMethod']=_0xc0233c;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x357075){return ne('not\x20implemented');}['_linkToIdToken'](_0xd9e175,_0xcb158c){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x5bb251){return ne('not\x20implemented');}}async function zf(_0x572e7e,_0x3950a5){return Pe(_0x572e7e,'POST','/v1/accounts:signUp',_0x3950a5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x70cafa,_0x5a40b4){return en(_0x70cafa,'POST','/v1/accounts:signInWithPassword',ke(_0x70cafa,_0x5a40b4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x5d4de9,_0x47be96){return en(_0x5d4de9,'POST','/v1/accounts:signInWithEmailLink',ke(_0x5d4de9,_0x47be96));}async function Yf(_0x31c8e7,_0x29db8b){return en(_0x31c8e7,'POST','/v1/accounts:signInWithEmailLink',ke(_0x31c8e7,_0x29db8b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x377fea,_0x44356d,_0x289783,_0x11fa21=null){super('password',_0x289783),this['_email']=_0x377fea,this['_password']=_0x44356d,this['_tenantId']=_0x11fa21;}static['_fromEmailAndPassword'](_0x5c8824,_0x58eb44){return new $t(_0x5c8824,_0x58eb44,'password');}static['_fromEmailAndCode'](_0x1b06f5,_0x51c337,_0x322d47=null){return new $t(_0x1b06f5,_0x51c337,'emailLink',_0x322d47);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x36626f){const _0x177869=typeof _0x36626f=='string'?JSON['parse'](_0x36626f):_0x36626f;if(_0x177869!=null&&_0x177869['email']&&(_0x177869!=null&&_0x177869['password'])){if(_0x177869['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x177869['email'],_0x177869['password']);if(_0x177869['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x177869['email'],_0x177869['password'],_0x177869['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4d60a3){switch(this['signInMethod']){case'password':const _0x2604b0={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x4d60a3,_0x2604b0,'signInWithPassword',jf);case'emailLink':return Kf(_0x4d60a3,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x4d60a3,'internal-error');}}async['_linkToIdToken'](_0x17f212,_0xa4bd33){switch(this['signInMethod']){case'password':const _0x524b53={'idToken':_0xa4bd33,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x17f212,_0x524b53,'signUpPassword',zf);case'emailLink':return Yf(_0x17f212,{'idToken':_0xa4bd33,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x17f212,'internal-error');}}['_getReauthenticationResolver'](_0xb56bd2){return this['_getIdTokenResponse'](_0xb56bd2);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x53eb82,_0x287c33){return en(_0x53eb82,'POST','/v1/accounts:signInWithIdp',ke(_0x53eb82,_0x287c33));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x32dc20){const _0x3b7654=new $e(_0x32dc20['providerId'],_0x32dc20['signInMethod']);return _0x32dc20['idToken']||_0x32dc20['accessToken']?(_0x32dc20['idToken']&&(_0x3b7654['idToken']=_0x32dc20['idToken']),_0x32dc20['accessToken']&&(_0x3b7654['accessToken']=_0x32dc20['accessToken']),_0x32dc20['nonce']&&!_0x32dc20['pendingToken']&&(_0x3b7654['nonce']=_0x32dc20['nonce']),_0x32dc20['pendingToken']&&(_0x3b7654['pendingToken']=_0x32dc20['pendingToken'])):_0x32dc20['oauthToken']&&_0x32dc20['oauthTokenSecret']?(_0x3b7654['accessToken']=_0x32dc20['oauthToken'],_0x3b7654['secret']=_0x32dc20['oauthTokenSecret']):Y('argument-error'),_0x3b7654;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5bdfc2){const _0x51c8ad=typeof _0x5bdfc2=='string'?JSON['parse'](_0x5bdfc2):_0x5bdfc2,{providerId:_0x175c94,signInMethod:_0x577231,..._0x1f1ecf}=_0x51c8ad;if(!_0x175c94||!_0x577231)return null;const _0x1f353f=new $e(_0x175c94,_0x577231);return _0x1f353f['idToken']=_0x1f1ecf['idToken']||void 0x0,_0x1f353f['accessToken']=_0x1f1ecf['accessToken']||void 0x0,_0x1f353f['secret']=_0x1f1ecf['secret'],_0x1f353f['nonce']=_0x1f1ecf['nonce'],_0x1f353f['pendingToken']=_0x1f1ecf['pendingToken']||null,_0x1f353f;}['_getIdTokenResponse'](_0x50c466){const _0x2afb54=this['buildRequest']();return nt(_0x50c466,_0x2afb54);}['_linkToIdToken'](_0xcb330f,_0x4105e){const _0x25b309=this['buildRequest']();return _0x25b309['idToken']=_0x4105e,nt(_0xcb330f,_0x25b309);}['_getReauthenticationResolver'](_0x24d5df){const _0x5bf4b2=this['buildRequest']();return _0x5bf4b2['autoCreate']=!0x1,nt(_0x24d5df,_0x5bf4b2);}['buildRequest'](){const _0x2233e2={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x2233e2['pendingToken']=this['pendingToken'];else{const _0x122f47={};this['idToken']&&(_0x122f47['id_token']=this['idToken']),this['accessToken']&&(_0x122f47['access_token']=this['accessToken']),this['secret']&&(_0x122f47['oauth_token_secret']=this['secret']),_0x122f47['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x122f47['nonce']=this['nonce']),_0x2233e2['postBody']=ut(_0x122f47);}return _0x2233e2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x56ef4b){switch(_0x56ef4b){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x16244a){const _0x3a6f6c=Ct(Tt(_0x16244a))['link'],_0x20dde6=_0x3a6f6c?Ct(Tt(_0x3a6f6c))['deep_link_id']:null,_0x2e5c8d=Ct(Tt(_0x16244a))['deep_link_id'];return(_0x2e5c8d?Ct(Tt(_0x2e5c8d))['link']:null)||_0x2e5c8d||_0x20dde6||_0x3a6f6c||_0x16244a;}class Rs{constructor(_0x55f10d){const _0x51282a=Ct(Tt(_0x55f10d)),_0xcd16c=_0x51282a['apiKey']??null,_0x21dd0e=_0x51282a['oobCode']??null,_0x58ee20=Jf(_0x51282a['mode']??null);m(_0xcd16c&&_0x21dd0e&&_0x58ee20,'argument-error'),this['apiKey']=_0xcd16c,this['operation']=_0x58ee20,this['code']=_0x21dd0e,this['continueUrl']=_0x51282a['continueUrl']??null,this['languageCode']=_0x51282a['lang']??null,this['tenantId']=_0x51282a['tenantId']??null;}static['parseLink'](_0x2d948f){const _0x3f59db=Xf(_0x2d948f);try{return new Rs(_0x3f59db);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x515d7e,_0x3cd3e2){return $t['_fromEmailAndPassword'](_0x515d7e,_0x3cd3e2);}static['credentialWithLink'](_0x140e88,_0x52e587){const _0x16c0f5=Rs['parseLink'](_0x52e587);return m(_0x16c0f5,'argument-error'),$t['_fromEmailAndCode'](_0x140e88,_0x16c0f5['code'],_0x16c0f5['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x1033d5){this['providerId']=_0x1033d5,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x11c34d){this['defaultLanguageCode']=_0x11c34d;}['setCustomParameters'](_0x47a2a5){return this['customParameters']=_0x47a2a5,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x184e49){return this['scopes']['includes'](_0x184e49)||this['scopes']['push'](_0x184e49),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x5ba163){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x5ba163});}static['credentialFromResult'](_0x1bd43e){return ue['credentialFromTaggedObject'](_0x1bd43e);}static['credentialFromError'](_0x1c5522){return ue['credentialFromTaggedObject'](_0x1c5522['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x127c63}){if(!_0x127c63||!('oauthAccessToken'in _0x127c63)||!_0x127c63['oauthAccessToken'])return null;try{return ue['credential'](_0x127c63['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x17d23d,_0x47c5c4){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x17d23d,'accessToken':_0x47c5c4});}static['credentialFromResult'](_0x33850f){return de['credentialFromTaggedObject'](_0x33850f);}static['credentialFromError'](_0x5dee9b){return de['credentialFromTaggedObject'](_0x5dee9b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x319b75}){if(!_0x319b75)return null;const {oauthIdToken:_0x74760b,oauthAccessToken:_0x3d48e2}=_0x319b75;if(!_0x74760b&&!_0x3d48e2)return null;try{return de['credential'](_0x74760b,_0x3d48e2);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x55fc16){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x55fc16});}static['credentialFromResult'](_0x4b6a7b){return fe['credentialFromTaggedObject'](_0x4b6a7b);}static['credentialFromError'](_0x588733){return fe['credentialFromTaggedObject'](_0x588733['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x375c0d}){if(!_0x375c0d||!('oauthAccessToken'in _0x375c0d)||!_0x375c0d['oauthAccessToken'])return null;try{return fe['credential'](_0x375c0d['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x42a341,_0x7a6800){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x42a341,'oauthTokenSecret':_0x7a6800});}static['credentialFromResult'](_0x12a71c){return pe['credentialFromTaggedObject'](_0x12a71c);}static['credentialFromError'](_0x5a3de6){return pe['credentialFromTaggedObject'](_0x5a3de6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1ce858}){if(!_0x1ce858)return null;const {oauthAccessToken:_0x3583fe,oauthTokenSecret:_0x1e7fb4}=_0x1ce858;if(!_0x3583fe||!_0x1e7fb4)return null;try{return pe['credential'](_0x3583fe,_0x1e7fb4);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x337ede,_0x2bf10c){return en(_0x337ede,'POST','/v1/accounts:signUp',ke(_0x337ede,_0x2bf10c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x467818){this['user']=_0x467818['user'],this['providerId']=_0x467818['providerId'],this['_tokenResponse']=_0x467818['_tokenResponse'],this['operationType']=_0x467818['operationType'];}static async['_fromIdTokenResponse'](_0x149b61,_0x244083,_0x1623d6,_0x3cbc32=!0x1){const _0x652f27=await j['_fromIdTokenResponse'](_0x149b61,_0x1623d6,_0x3cbc32),_0x570a83=Nr(_0x1623d6);return new Ge({'user':_0x652f27,'providerId':_0x570a83,'_tokenResponse':_0x1623d6,'operationType':_0x244083});}static async['_forOperation'](_0x46f52a,_0xa4d2ac,_0x183d45){await _0x46f52a['_updateTokensIfNecessary'](_0x183d45,!0x0);const _0x2ea6dd=Nr(_0x183d45);return new Ge({'user':_0x46f52a,'providerId':_0x2ea6dd,'_tokenResponse':_0x183d45,'operationType':_0xa4d2ac});}}function Nr(_0xfc4e59){return _0xfc4e59['providerId']?_0xfc4e59['providerId']:'phoneNumber'in _0xfc4e59?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x4da84f,_0x59268e,_0xf3e50a,_0x11d808){super(_0x59268e['code'],_0x59268e['message']),this['operationType']=_0xf3e50a,this['user']=_0x11d808,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x4da84f['name'],'tenantId':_0x4da84f['tenantId']??void 0x0,'_serverResponse':_0x59268e['customData']['_serverResponse'],'operationType':_0xf3e50a};}static['_fromErrorAndOperation'](_0x42101b,_0x40c26a,_0x3c34fc,_0x5aac6a){return new On(_0x42101b,_0x40c26a,_0x3c34fc,_0x5aac6a);}}function Ba(_0x498561,_0x48ea4e,_0x2bfa51,_0x18cd8a){return(_0x48ea4e==='reauthenticate'?_0x2bfa51['_getReauthenticationResolver'](_0x498561):_0x2bfa51['_getIdTokenResponse'](_0x498561))['catch'](_0x29bdd6=>{throw _0x29bdd6['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x498561,_0x29bdd6,_0x48ea4e,_0x18cd8a):_0x29bdd6;});}async function ep(_0x42a759,_0x335331,_0x12f54b=!0x1){const _0x252fdd=await Ht(_0x42a759,_0x335331['_linkToIdToken'](_0x42a759['auth'],await _0x42a759['getIdToken']()),_0x12f54b);return Ge['_forOperation'](_0x42a759,'link',_0x252fdd);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x129fbd,_0x332af8,_0x1702f9=!0x1){const {auth:_0x4dd12c}=_0x129fbd;if($(_0x4dd12c['app']))return Promise['reject'](re(_0x4dd12c));const _0x92f188='reauthenticate';try{const _0x381f9a=await Ht(_0x129fbd,Ba(_0x4dd12c,_0x92f188,_0x332af8,_0x129fbd),_0x1702f9);m(_0x381f9a['idToken'],_0x4dd12c,'internal-error');const _0x37a99c=Ts(_0x381f9a['idToken']);m(_0x37a99c,_0x4dd12c,'internal-error');const {sub:_0x56857d}=_0x37a99c;return m(_0x129fbd['uid']===_0x56857d,_0x4dd12c,'user-mismatch'),Ge['_forOperation'](_0x129fbd,_0x92f188,_0x381f9a);}catch(_0x3ab47f){throw(_0x3ab47f==null?void 0x0:_0x3ab47f['code'])==='auth/user-not-found'&&Y(_0x4dd12c,'user-mismatch'),_0x3ab47f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x21711e,_0x529783,_0x533161=!0x1){if($(_0x21711e['app']))return Promise['reject'](re(_0x21711e));const _0x59e0fc='signIn',_0xb070e4=await Ba(_0x21711e,_0x59e0fc,_0x529783),_0x2d4dea=await Ge['_fromIdTokenResponse'](_0x21711e,_0x59e0fc,_0xb070e4);return _0x533161||await _0x21711e['_updateCurrentUser'](_0x2d4dea['user']),_0x2d4dea;}async function np(_0x320627,_0x380fcd){return Va(Ke(_0x320627),_0x380fcd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x4a2207){const _0x49a471=Ke(_0x4a2207);_0x49a471['_getPasswordPolicyInternal']()&&await _0x49a471['_updatePasswordPolicy']();}async function L_(_0x1841e4,_0x1bf3cd,_0x4c00fe){if($(_0x1841e4['app']))return Promise['reject'](re(_0x1841e4));const _0x1c8e51=Ke(_0x1841e4),_0x570350=await xi(_0x1c8e51,{'returnSecureToken':!0x0,'email':_0x1bf3cd,'password':_0x4c00fe,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x20d59c=>{throw _0x20d59c['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x1841e4),_0x20d59c;}),_0x58ef4d=await Ge['_fromIdTokenResponse'](_0x1c8e51,'signIn',_0x570350);return await _0x1c8e51['_updateCurrentUser'](_0x58ef4d['user']),_0x58ef4d;}function x_(_0xb34416,_0x4034a2,_0x525230){return $(_0xb34416['app'])?Promise['reject'](re(_0xb34416)):np(P(_0xb34416),yt['credential'](_0x4034a2,_0x525230))['catch'](async _0x1a1eac=>{throw _0x1a1eac['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xb34416),_0x1a1eac;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x46af94,_0x5071ba){return P(_0x46af94)['setPersistence'](_0x5071ba);}function ip(_0x28b155,_0x5757bd,_0x324bf1,_0x2acd43){return P(_0x28b155)['onIdTokenChanged'](_0x5757bd,_0x324bf1,_0x2acd43);}function sp(_0x52610c,_0x35bfd5,_0x10f1e0){return P(_0x52610c)['beforeAuthStateChanged'](_0x35bfd5,_0x10f1e0);}function U_(_0x565f0a,_0x1bf7ca,_0x1ac894,_0x351fbf){return P(_0x565f0a)['onAuthStateChanged'](_0x1bf7ca,_0x1ac894,_0x351fbf);}function W_(_0x3dd062){return P(_0x3dd062)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4ab5eb,_0x34e188){this['storageRetriever']=_0x4ab5eb,this['type']=_0x34e188;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x55ee45,_0x1b72f2){return this['storage']['setItem'](_0x55ee45,JSON['stringify'](_0x1b72f2)),Promise['resolve']();}['_get'](_0x21e797){const _0x113220=this['storage']['getItem'](_0x21e797);return Promise['resolve'](_0x113220?JSON['parse'](_0x113220):null);}['_remove'](_0x714600){return this['storage']['removeItem'](_0x714600),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1cd392,_0x38c862)=>this['onStorageEvent'](_0x1cd392,_0x38c862),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2f48f6){for(const _0x371453 of Object['keys'](this['listeners'])){const _0x46ab00=this['storage']['getItem'](_0x371453),_0x1de1e6=this['localCache'][_0x371453];_0x46ab00!==_0x1de1e6&&_0x2f48f6(_0x371453,_0x1de1e6,_0x46ab00);}}['onStorageEvent'](_0x435608,_0x4b35e9=!0x1){if(!_0x435608['key']){this['forAllChangedKeys']((_0x4f479a,_0x5c05a1,_0x4c07e9)=>{this['notifyListeners'](_0x4f479a,_0x4c07e9);});return;}const _0x33d5d9=_0x435608['key'];_0x4b35e9?this['detachListener']():this['stopPolling']();const _0x5c3082=()=>{const _0x1d9c81=this['storage']['getItem'](_0x33d5d9);!_0x4b35e9&&this['localCache'][_0x33d5d9]===_0x1d9c81||this['notifyListeners'](_0x33d5d9,_0x1d9c81);},_0x4523ff=this['storage']['getItem'](_0x33d5d9);Af()&&_0x4523ff!==_0x435608['newValue']&&_0x435608['newValue']!==_0x435608['oldValue']?setTimeout(_0x5c3082,op):_0x5c3082();}['notifyListeners'](_0x5aefca,_0x40a229){this['localCache'][_0x5aefca]=_0x40a229;const _0x4667ed=this['listeners'][_0x5aefca];if(_0x4667ed){for(const _0x1c8c9d of Array['from'](_0x4667ed))_0x1c8c9d(_0x40a229&&JSON['parse'](_0x40a229));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x407d9e,_0x406cce,_0x8eb90d)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x407d9e,'oldValue':_0x406cce,'newValue':_0x8eb90d}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4a18ee,_0x1b509b){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4a18ee]||(this['listeners'][_0x4a18ee]=new Set(),this['localCache'][_0x4a18ee]=this['storage']['getItem'](_0x4a18ee)),this['listeners'][_0x4a18ee]['add'](_0x1b509b);}['_removeListener'](_0x25a4e2,_0x566377){this['listeners'][_0x25a4e2]&&(this['listeners'][_0x25a4e2]['delete'](_0x566377),this['listeners'][_0x25a4e2]['size']===0x0&&delete this['listeners'][_0x25a4e2]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x33464e,_0xa99b2f){await super['_set'](_0x33464e,_0xa99b2f),this['localCache'][_0x33464e]=JSON['stringify'](_0xa99b2f);}async['_get'](_0x4fb1f6){const _0x3e9aa0=await super['_get'](_0x4fb1f6);return this['localCache'][_0x4fb1f6]=JSON['stringify'](_0x3e9aa0),_0x3e9aa0;}async['_remove'](_0x28df0f){await super['_remove'](_0x28df0f),delete this['localCache'][_0x28df0f];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xb8a6,_0x263039){}['_removeListener'](_0xabe006,_0x1bc952){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x343dd2){return Promise['all'](_0x343dd2['map'](async _0x2b4027=>{try{return{'fulfilled':!0x0,'value':await _0x2b4027};}catch(_0x1f441e){return{'fulfilled':!0x1,'reason':_0x1f441e};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x54092d){this['eventTarget']=_0x54092d,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x43731c){const _0x17b046=this['receivers']['find'](_0x268f36=>_0x268f36['isListeningto'](_0x43731c));if(_0x17b046)return _0x17b046;const _0x2cb7bc=new Xn(_0x43731c);return this['receivers']['push'](_0x2cb7bc),_0x2cb7bc;}['isListeningto'](_0xaefd9d){return this['eventTarget']===_0xaefd9d;}async['handleEvent'](_0x166b9b){const _0x37c3e4=_0x166b9b,{eventId:_0x4a969b,eventType:_0x5dab44,data:_0x1aff8a}=_0x37c3e4['data'],_0x35d476=this['handlersMap'][_0x5dab44];if(!(_0x35d476!=null&&_0x35d476['size']))return;_0x37c3e4['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4a969b,'eventType':_0x5dab44});const _0x253aa2=Array['from'](_0x35d476)['map'](async _0x3f3b8c=>_0x3f3b8c(_0x37c3e4['origin'],_0x1aff8a)),_0x1b2ec9=await cp(_0x253aa2);_0x37c3e4['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4a969b,'eventType':_0x5dab44,'response':_0x1b2ec9});}['_subscribe'](_0x1ea9d9,_0x29f47c){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1ea9d9]||(this['handlersMap'][_0x1ea9d9]=new Set()),this['handlersMap'][_0x1ea9d9]['add'](_0x29f47c);}['_unsubscribe'](_0x1b7070,_0x34e74f){this['handlersMap'][_0x1b7070]&&_0x34e74f&&this['handlersMap'][_0x1b7070]['delete'](_0x34e74f),(!_0x34e74f||this['handlersMap'][_0x1b7070]['size']===0x0)&&delete this['handlersMap'][_0x1b7070],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x1ca9c1='',_0x2e75c4=0xa){let _0x22a61d='';for(let _0x8c5c7e=0x0;_0x8c5c7e<_0x2e75c4;_0x8c5c7e++)_0x22a61d+=Math['floor'](Math['random']()*0xa);return _0x1ca9c1+_0x22a61d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x155532){this['target']=_0x155532,this['handlers']=new Set();}['removeMessageHandler'](_0x58ce34){_0x58ce34['messageChannel']&&(_0x58ce34['messageChannel']['port1']['removeEventListener']('message',_0x58ce34['onMessage']),_0x58ce34['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x58ce34);}async['_send'](_0x2129ed,_0x736877,_0x3d01aa=0x32){const _0x4094a0=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4094a0)throw new Error('connection_unavailable');let _0x34a8a6,_0xeacfc6;return new Promise((_0x2bc9ed,_0x5e6e1f)=>{const _0x260321=As('',0x14);_0x4094a0['port1']['start']();const _0x190da7=setTimeout(()=>{_0x5e6e1f(new Error('unsupported_event'));},_0x3d01aa);_0xeacfc6={'messageChannel':_0x4094a0,'onMessage'(_0x47b666){const _0x5649d7=_0x47b666;if(_0x5649d7['data']['eventId']===_0x260321)switch(_0x5649d7['data']['status']){case'ack':clearTimeout(_0x190da7),_0x34a8a6=setTimeout(()=>{_0x5e6e1f(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x34a8a6),_0x2bc9ed(_0x5649d7['data']['response']);break;default:clearTimeout(_0x190da7),clearTimeout(_0x34a8a6),_0x5e6e1f(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xeacfc6),_0x4094a0['port1']['addEventListener']('message',_0xeacfc6['onMessage']),this['target']['postMessage']({'eventType':_0x2129ed,'eventId':_0x260321,'data':_0x736877},[_0x4094a0['port2']]);})['finally'](()=>{_0xeacfc6&&this['removeMessageHandler'](_0xeacfc6);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x1a64c5){Z()['location']['href']=_0x1a64c5;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x26bd29;return((_0x26bd29=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x26bd29['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x4e6b78){this['request']=_0x4e6b78;}['toPromise'](){return new Promise((_0xd22db8,_0x4dcf33)=>{this['request']['addEventListener']('success',()=>{_0xd22db8(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x4dcf33(this['request']['error']);});});}}function Zn(_0x31f913,_0x3b8edf){return _0x31f913['transaction']([Mn],_0x3b8edf?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x37b607=indexedDB['deleteDatabase'](Ka);return new nn(_0x37b607)['toPromise']();}function Qa(){const _0x418fc3=indexedDB['open'](Ka,pp);return new Promise((_0x4ce929,_0x1d2779)=>{_0x418fc3['addEventListener']('error',()=>{_0x1d2779(_0x418fc3['error']);}),_0x418fc3['addEventListener']('upgradeneeded',()=>{const _0x47b829=_0x418fc3['result'];try{_0x47b829['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x4adc60){_0x1d2779(_0x4adc60);}}),_0x418fc3['addEventListener']('success',async()=>{const _0x2059f5=_0x418fc3['result'];_0x2059f5['objectStoreNames']['contains'](Mn)?_0x4ce929(_0x2059f5):(_0x2059f5['close'](),await _p(),_0x4ce929(await Qa()));});});}async function Or(_0x5adc96,_0x3ec856,_0x5214b8){const _0x5920dc=Zn(_0x5adc96,!0x0)['put']({[Ya]:_0x3ec856,'value':_0x5214b8});return new nn(_0x5920dc)['toPromise']();}async function gp(_0x945857,_0x272864){const _0x5853d2=Zn(_0x945857,!0x1)['get'](_0x272864),_0x429546=await new nn(_0x5853d2)['toPromise']();return _0x429546===void 0x0?null:_0x429546['value'];}function Dr(_0x192b62,_0x4359be){const _0x122082=Zn(_0x192b62,!0x0)['delete'](_0x4359be);return new nn(_0x122082)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x367dc1){let _0x412b0e=0x0;for(;;)try{const _0x17c083=await this['_openDb']();return await _0x367dc1(_0x17c083);}catch(_0x16e195){if(_0x412b0e++>yp)throw _0x16e195;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x57604b,_0x27c97f)=>({'keyProcessed':(await this['_poll']())['includes'](_0x27c97f['key'])})),this['receiver']['_subscribe']('ping',async(_0x2d33a3,_0x348644)=>['keyChanged']);}async['initializeSender'](){var _0x28ed86,_0x5f0689;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x3e66c2=await this['sender']['_send']('ping',{},0x320);_0x3e66c2&&(_0x28ed86=_0x3e66c2[0x0])!=null&&_0x28ed86['fulfilled']&&(_0x5f0689=_0x3e66c2[0x0])!=null&&_0x5f0689['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x40bb12){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x40bb12},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x63684a=>{await Or(_0x63684a,Dn,'1'),await Dr(_0x63684a,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x22f4f0){this['pendingWrites']++;try{await _0x22f4f0();}finally{this['pendingWrites']--;}}async['_set'](_0x342139,_0x775252){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1510bd=>Or(_0x1510bd,_0x342139,_0x775252)),this['localCache'][_0x342139]=_0x775252,this['notifyServiceWorker'](_0x342139)));}async['_get'](_0xfd2674){const _0x1eea76=await this['_withRetries'](_0x4e17b2=>gp(_0x4e17b2,_0xfd2674));return this['localCache'][_0xfd2674]=_0x1eea76,_0x1eea76;}async['_remove'](_0x24222a){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2d2912=>Dr(_0x2d2912,_0x24222a)),delete this['localCache'][_0x24222a],this['notifyServiceWorker'](_0x24222a)));}async['_poll'](){const _0x51f14d=await this['_withRetries'](_0x1054cd=>{const _0x181396=Zn(_0x1054cd,!0x1)['getAll']();return new nn(_0x181396)['toPromise']();});if(!_0x51f14d)return[];if(this['pendingWrites']!==0x0)return[];const _0x46a65f=[],_0x30e211=new Set();if(_0x51f14d['length']!==0x0){for(const {fbase_key:_0x28c030,value:_0x25402f}of _0x51f14d)_0x30e211['add'](_0x28c030),JSON['stringify'](this['localCache'][_0x28c030])!==JSON['stringify'](_0x25402f)&&(this['notifyListeners'](_0x28c030,_0x25402f),_0x46a65f['push'](_0x28c030));}for(const _0x3175f6 of Object['keys'](this['localCache']))this['localCache'][_0x3175f6]&&!_0x30e211['has'](_0x3175f6)&&(this['notifyListeners'](_0x3175f6,null),_0x46a65f['push'](_0x3175f6));return _0x46a65f;}['notifyListeners'](_0x1396ff,_0x4ce272){this['localCache'][_0x1396ff]=_0x4ce272;const _0x3bb7b2=this['listeners'][_0x1396ff];if(_0x3bb7b2){for(const _0x2ea285 of Array['from'](_0x3bb7b2))_0x2ea285(_0x4ce272);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0xbdebd4,_0x4df5c7){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0xbdebd4]||(this['listeners'][_0xbdebd4]=new Set(),this['_get'](_0xbdebd4)),this['listeners'][_0xbdebd4]['add'](_0x4df5c7);}['_removeListener'](_0x449c0e,_0x3ae6ac){this['listeners'][_0x449c0e]&&(this['listeners'][_0x449c0e]['delete'](_0x3ae6ac),this['listeners'][_0x449c0e]['size']===0x0&&delete this['listeners'][_0x449c0e]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x28f0ba,_0x4fba32){return _0x4fba32?ie(_0x4fba32):(m(_0x28f0ba['_popupRedirectResolver'],_0x28f0ba,'argument-error'),_0x28f0ba['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x38532b){super('custom','custom'),this['params']=_0x38532b;}['_getIdTokenResponse'](_0x1528a1){return nt(_0x1528a1,this['_buildIdpRequest']());}['_linkToIdToken'](_0x20e87c,_0x4cfcb9){return nt(_0x20e87c,this['_buildIdpRequest'](_0x4cfcb9));}['_getReauthenticationResolver'](_0x210449){return nt(_0x210449,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x2f8645){const _0x662fb3={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x2f8645&&(_0x662fb3['idToken']=_0x2f8645),_0x662fb3;}}function Ip(_0x1f2d22){return Va(_0x1f2d22['auth'],new ks(_0x1f2d22),_0x1f2d22['bypassAuthState']);}function wp(_0x2e234f){const {auth:_0x3824f9,user:_0xbbd337}=_0x2e234f;return m(_0xbbd337,_0x3824f9,'internal-error'),tp(_0xbbd337,new ks(_0x2e234f),_0x2e234f['bypassAuthState']);}async function Cp(_0x3a8b12){const {auth:_0x2f7e60,user:_0x998af0}=_0x3a8b12;return m(_0x998af0,_0x2f7e60,'internal-error'),ep(_0x998af0,new ks(_0x3a8b12),_0x3a8b12['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x25e319,_0x133892,_0x4b4eb8,_0x1a6690,_0x48e8c3=!0x1){this['auth']=_0x25e319,this['resolver']=_0x4b4eb8,this['user']=_0x1a6690,this['bypassAuthState']=_0x48e8c3,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x133892)?_0x133892:[_0x133892];}['execute'](){return new Promise(async(_0xcc0138,_0x4722bc)=>{this['pendingPromise']={'resolve':_0xcc0138,'reject':_0x4722bc};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2cf5b2){this['reject'](_0x2cf5b2);}});}async['onAuthEvent'](_0x4aec37){const {urlResponse:_0x274a01,sessionId:_0x3b37c4,postBody:_0x379986,tenantId:_0x193f54,error:_0x17d675,type:_0x4cbcfb}=_0x4aec37;if(_0x17d675){this['reject'](_0x17d675);return;}const _0x59ad4b={'auth':this['auth'],'requestUri':_0x274a01,'sessionId':_0x3b37c4,'tenantId':_0x193f54||void 0x0,'postBody':_0x379986||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4cbcfb)(_0x59ad4b));}catch(_0x5250ee){this['reject'](_0x5250ee);}}['onError'](_0xed084f){this['reject'](_0xed084f);}['getIdpTask'](_0x1aaf32){switch(_0x1aaf32){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x3197b7){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3197b7),this['unregisterAndCleanUp']();}['reject'](_0x27aa2d){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x27aa2d),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x3cff79,_0xc26d1b,_0x1f0c98,_0x540722,_0x29f2c0){super(_0x3cff79,_0xc26d1b,_0x540722,_0x29f2c0),this['provider']=_0x1f0c98,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0xd64d39=await this['execute']();return m(_0xd64d39,this['auth'],'internal-error'),_0xd64d39;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xf54b8f=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xf54b8f),this['authWindow']['associatedEvent']=_0xf54b8f,this['resolver']['_originValidation'](this['auth'])['catch'](_0x136116=>{this['reject'](_0x136116);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x492e5c=>{_0x492e5c||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x26fb77;return((_0x26fb77=this['authWindow'])==null?void 0x0:_0x26fb77['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x5bb75a=()=>{var _0x4d1314,_0x2293f8;if((_0x2293f8=(_0x4d1314=this['authWindow'])==null?void 0x0:_0x4d1314['window'])!=null&&_0x2293f8['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x5bb75a,Tp['get']());};_0x5bb75a();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x2f5008,_0x226ab1,_0x370810=!0x1){super(_0x2f5008,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x226ab1,void 0x0,_0x370810),this['eventId']=null;}async['execute'](){let _0x328b7c=hn['get'](this['auth']['_key']());if(!_0x328b7c){try{const _0x2472fc=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x328b7c=()=>Promise['resolve'](_0x2472fc);}catch(_0x4b4363){_0x328b7c=()=>Promise['reject'](_0x4b4363);}hn['set'](this['auth']['_key'](),_0x328b7c);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x328b7c();}async['onAuthEvent'](_0x39452e){if(_0x39452e['type']==='signInViaRedirect')return super['onAuthEvent'](_0x39452e);if(_0x39452e['type']==='unknown'){this['resolve'](null);return;}if(_0x39452e['eventId']){const _0xea3306=await this['auth']['_redirectUserForId'](_0x39452e['eventId']);if(_0xea3306)return this['user']=_0xea3306,super['onAuthEvent'](_0x39452e);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x277819,_0x1c2886){const _0x52888f=Pp(_0x1c2886),_0x3e264e=kp(_0x277819);if(!await _0x3e264e['_isAvailable']())return!0x1;const _0x4efb6e=await _0x3e264e['_get'](_0x52888f)==='true';return await _0x3e264e['_remove'](_0x52888f),_0x4efb6e;}function Ap(_0x4bba22,_0x13f508){hn['set'](_0x4bba22['_key'](),_0x13f508);}function kp(_0x4a0633){return ie(_0x4a0633['_redirectPersistence']);}function Pp(_0x248e14){return ln(Sp,_0x248e14['config']['apiKey'],_0x248e14['name']);}async function Np(_0x2147db,_0x486cb7,_0x42c9ff=!0x1){if($(_0x2147db['app']))return Promise['reject'](re(_0x2147db));const _0x1b09b2=Ke(_0x2147db),_0x2de46a=Ep(_0x1b09b2,_0x486cb7),_0x4d111f=await new bp(_0x1b09b2,_0x2de46a,_0x42c9ff)['execute']();return _0x4d111f&&!_0x42c9ff&&(delete _0x4d111f['user']['_redirectEventId'],await _0x1b09b2['_persistUserIfCurrent'](_0x4d111f['user']),await _0x1b09b2['_setRedirectUser'](null,_0x486cb7)),_0x4d111f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x42d356){this['auth']=_0x42d356,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3209ea){this['consumers']['add'](_0x3209ea),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3209ea)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3209ea),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3f2bb5){this['consumers']['delete'](_0x3f2bb5);}['onEvent'](_0x2530c5){if(this['hasEventBeenHandled'](_0x2530c5))return!0x1;let _0x2731b8=!0x1;return this['consumers']['forEach'](_0xad93e0=>{this['isEventForConsumer'](_0x2530c5,_0xad93e0)&&(_0x2731b8=!0x0,this['sendToConsumer'](_0x2530c5,_0xad93e0),this['saveEventToCache'](_0x2530c5));}),this['hasHandledPotentialRedirect']||!Mp(_0x2530c5)||(this['hasHandledPotentialRedirect']=!0x0,_0x2731b8||(this['queuedRedirectEvent']=_0x2530c5,_0x2731b8=!0x0)),_0x2731b8;}['sendToConsumer'](_0x3d8ce8,_0x507551){var _0x444bde;if(_0x3d8ce8['error']&&!Za(_0x3d8ce8)){const _0x5c4e5d=((_0x444bde=_0x3d8ce8['error']['code'])==null?void 0x0:_0x444bde['split']('auth/')[0x1])||'internal-error';_0x507551['onError'](X(this['auth'],_0x5c4e5d));}else _0x507551['onAuthEvent'](_0x3d8ce8);}['isEventForConsumer'](_0x12c61a,_0x566ecb){const _0x2311e9=_0x566ecb['eventId']===null||!!_0x12c61a['eventId']&&_0x12c61a['eventId']===_0x566ecb['eventId'];return _0x566ecb['filter']['includes'](_0x12c61a['type'])&&_0x2311e9;}['hasEventBeenHandled'](_0x130e18){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x130e18));}['saveEventToCache'](_0x3f41c9){this['cachedEventUids']['add'](Mr(_0x3f41c9)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x6bb715){return[_0x6bb715['type'],_0x6bb715['eventId'],_0x6bb715['sessionId'],_0x6bb715['tenantId']]['filter'](_0x5c2d6a=>_0x5c2d6a)['join']('-');}function Za({type:_0x2ca802,error:_0x3a088a}){return _0x2ca802==='unknown'&&(_0x3a088a==null?void 0x0:_0x3a088a['code'])==='auth/no-auth-event';}function Mp(_0x44e7c7){switch(_0x44e7c7['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x44e7c7);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x221979,_0x26aadf={}){return Pe(_0x221979,'GET','/v1/projects',_0x26aadf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0xea7d57){if(_0xea7d57['config']['emulator'])return;const {authorizedDomains:_0x1bf4e4}=await Lp(_0xea7d57);for(const _0x38432f of _0x1bf4e4)try{if(Wp(_0x38432f))return;}catch{}Y(_0xea7d57,'unauthorized-domain');}function Wp(_0x57a848){const _0x3b5f90=Mi(),{protocol:_0x523e37,hostname:_0xf791cb}=new URL(_0x3b5f90);if(_0x57a848['startsWith']('chrome-extension://')){const _0x3c8ffa=new URL(_0x57a848);return _0x3c8ffa['hostname']===''&&_0xf791cb===''?_0x523e37==='chrome-extension:'&&_0x57a848['replace']('chrome-extension://','')===_0x3b5f90['replace']('chrome-extension://',''):_0x523e37==='chrome-extension:'&&_0x3c8ffa['hostname']===_0xf791cb;}if(!Fp['test'](_0x523e37))return!0x1;if(xp['test'](_0x57a848))return _0xf791cb===_0x57a848;const _0x4fea95=_0x57a848['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x4fea95+'|'+_0x4fea95+')$','i')['test'](_0xf791cb);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x4ae988=Z()['___jsl'];if(_0x4ae988!=null&&_0x4ae988['H']){for(const _0x46e763 of Object['keys'](_0x4ae988['H']))if(_0x4ae988['H'][_0x46e763]['r']=_0x4ae988['H'][_0x46e763]['r']||[],_0x4ae988['H'][_0x46e763]['L']=_0x4ae988['H'][_0x46e763]['L']||[],_0x4ae988['H'][_0x46e763]['r']=[..._0x4ae988['H'][_0x46e763]['L']],_0x4ae988['CP']){for(let _0x5512be=0x0;_0x5512be<_0x4ae988['CP']['length'];_0x5512be++)_0x4ae988['CP'][_0x5512be]=null;}}}function Vp(_0x5fbf58){return new Promise((_0x19c633,_0x1e1d43)=>{var _0x47daea,_0x375b98,_0x1137a5;function _0x218215(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x19c633(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x1e1d43(X(_0x5fbf58,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x375b98=(_0x47daea=Z()['gapi'])==null?void 0x0:_0x47daea['iframes'])!=null&&_0x375b98['Iframe'])_0x19c633(gapi['iframes']['getContext']());else{if((_0x1137a5=Z()['gapi'])!=null&&_0x1137a5['load'])_0x218215();else{const _0x596bd2=Ff('iframefcb');return Z()[_0x596bd2]=()=>{gapi['load']?_0x218215():_0x1e1d43(X(_0x5fbf58,'network-request-failed'));},xa(xf()+'?onload='+_0x596bd2)['catch'](_0x173f70=>_0x1e1d43(_0x173f70));}}})['catch'](_0x546081=>{throw un=null,_0x546081;});}let un=null;function Hp(_0x1ca3dc){return un=un||Vp(_0x1ca3dc),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x201c2c){const _0x3dc43b=_0x201c2c['config'];m(_0x3dc43b['authDomain'],_0x201c2c,'auth-domain-config-required');const _0x54e0be=_0x3dc43b['emulator']?Cs(_0x3dc43b,qp):'https://'+_0x201c2c['config']['authDomain']+'/'+Gp,_0x4345c2={'apiKey':_0x3dc43b['apiKey'],'appName':_0x201c2c['name'],'v':dt},_0x351cab=jp['get'](_0x201c2c['config']['apiHost']);_0x351cab&&(_0x4345c2['eid']=_0x351cab);const _0x40082e=_0x201c2c['_getFrameworks']();return _0x40082e['length']&&(_0x4345c2['fw']=_0x40082e['join'](',')),_0x54e0be+'?'+ut(_0x4345c2)['slice'](0x1);}async function Yp(_0x3be4ef){const _0x5b7390=await Hp(_0x3be4ef),_0x158871=Z()['gapi'];return m(_0x158871,_0x3be4ef,'internal-error'),_0x5b7390['open']({'where':document['body'],'url':Kp(_0x3be4ef),'messageHandlersFilter':_0x158871['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x118e34=>new Promise(async(_0x2b41fd,_0x1c6435)=>{await _0x118e34['restyle']({'setHideOnLeave':!0x1});const _0x489430=X(_0x3be4ef,'network-request-failed'),_0x368fc5=Z()['setTimeout'](()=>{_0x1c6435(_0x489430);},$p['get']());function _0x33b119(){Z()['clearTimeout'](_0x368fc5),_0x2b41fd(_0x118e34);}_0x118e34['ping'](_0x33b119)['then'](_0x33b119,()=>{_0x1c6435(_0x489430);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x3629f3){this['window']=_0x3629f3,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x1bd0bb,_0x163593,_0x4c2b81,_0x413be7=Jp,_0x155603=Xp){const _0x50c189=Math['max']((window['screen']['availHeight']-_0x155603)/0x2,0x0)['toString'](),_0x528b35=Math['max']((window['screen']['availWidth']-_0x413be7)/0x2,0x0)['toString']();let _0x41da4d='';const _0x2742a6={...Qp,'width':_0x413be7['toString'](),'height':_0x155603['toString'](),'top':_0x50c189,'left':_0x528b35},_0x1e0c66=W()['toLowerCase']();_0x4c2b81&&(_0x41da4d=ka(_0x1e0c66)?Zp:_0x4c2b81),Ra(_0x1e0c66)&&(_0x163593=_0x163593||e_,_0x2742a6['scrollbars']='yes');const _0x3f6c12=Object['entries'](_0x2742a6)['reduce']((_0x12086d,[_0x1b9a1e,_0x525264])=>''+_0x12086d+_0x1b9a1e+'='+_0x525264+',','');if(Rf(_0x1e0c66)&&_0x41da4d!=='_self')return n_(_0x163593||'',_0x41da4d),new xr(null);const _0x25b6f1=window['open'](_0x163593||'',_0x41da4d,_0x3f6c12);m(_0x25b6f1,_0x1bd0bb,'popup-blocked');try{_0x25b6f1['focus']();}catch{}return new xr(_0x25b6f1);}function n_(_0x414d36,_0x10c04b){const _0x3c8954=document['createElement']('a');_0x3c8954['href']=_0x414d36,_0x3c8954['target']=_0x10c04b;const _0x259eb9=document['createEvent']('MouseEvent');_0x259eb9['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x3c8954['dispatchEvent'](_0x259eb9);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x58ec66,_0x37a3e9,_0xe5df1d,_0x3c1081,_0x57b88c,_0x15a2d8){m(_0x58ec66['config']['authDomain'],_0x58ec66,'auth-domain-config-required'),m(_0x58ec66['config']['apiKey'],_0x58ec66,'invalid-api-key');const _0x1498fd={'apiKey':_0x58ec66['config']['apiKey'],'appName':_0x58ec66['name'],'authType':_0xe5df1d,'redirectUrl':_0x3c1081,'v':dt,'eventId':_0x57b88c};if(_0x37a3e9 instanceof Wa){_0x37a3e9['setDefaultLanguage'](_0x58ec66['languageCode']),_0x1498fd['providerId']=_0x37a3e9['providerId']||'',pn(_0x37a3e9['getCustomParameters']())||(_0x1498fd['customParameters']=JSON['stringify'](_0x37a3e9['getCustomParameters']()));for(const [_0x1dbc35,_0x3c753c]of Object['entries']({}))_0x1498fd[_0x1dbc35]=_0x3c753c;}if(_0x37a3e9 instanceof tn){const _0x347237=_0x37a3e9['getScopes']()['filter'](_0x59568d=>_0x59568d!=='');_0x347237['length']>0x0&&(_0x1498fd['scopes']=_0x347237['join'](','));}_0x58ec66['tenantId']&&(_0x1498fd['tid']=_0x58ec66['tenantId']);const _0x503117=_0x1498fd;for(const _0x530227 of Object['keys'](_0x503117))_0x503117[_0x530227]===void 0x0&&delete _0x503117[_0x530227];const _0x35a3c4=await _0x58ec66['_getAppCheckToken'](),_0x181434=_0x35a3c4?'#'+r_+'='+encodeURIComponent(_0x35a3c4):'';return o_(_0x58ec66)+'?'+ut(_0x503117)['slice'](0x1)+_0x181434;}function o_({config:_0x59b70f}){return _0x59b70f['emulator']?Cs(_0x59b70f,s_):'https://'+_0x59b70f['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x141edd,_0x4b9afe,_0x574a8b,_0x4c6e77){var _0xc5ae20;ce((_0xc5ae20=this['eventManagers'][_0x141edd['_key']()])==null?void 0x0:_0xc5ae20['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4d30f7=await Fr(_0x141edd,_0x4b9afe,_0x574a8b,Mi(),_0x4c6e77);return t_(_0x141edd,_0x4d30f7,As());}async['_openRedirect'](_0x33f501,_0x371cbe,_0x21da8d,_0x17165a){await this['_originValidation'](_0x33f501);const _0x2aeae4=await Fr(_0x33f501,_0x371cbe,_0x21da8d,Mi(),_0x17165a);return hp(_0x2aeae4),new Promise(()=>{});}['_initialize'](_0x550218){const _0x5485ab=_0x550218['_key']();if(this['eventManagers'][_0x5485ab]){const {manager:_0x367ecd,promise:_0xa5bba0}=this['eventManagers'][_0x5485ab];return _0x367ecd?Promise['resolve'](_0x367ecd):(ce(_0xa5bba0,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xa5bba0);}const _0x5384bd=this['initAndGetManager'](_0x550218);return this['eventManagers'][_0x5485ab]={'promise':_0x5384bd},_0x5384bd['catch'](()=>{delete this['eventManagers'][_0x5485ab];}),_0x5384bd;}async['initAndGetManager'](_0x8c6fda){const _0x4bd9e3=await Yp(_0x8c6fda),_0x141512=new Dp(_0x8c6fda);return _0x4bd9e3['register']('authEvent',_0x2e68eb=>(m(_0x2e68eb==null?void 0x0:_0x2e68eb['authEvent'],_0x8c6fda,'invalid-auth-event'),{'status':_0x141512['onEvent'](_0x2e68eb['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x8c6fda['_key']()]={'manager':_0x141512},this['iframes'][_0x8c6fda['_key']()]=_0x4bd9e3,_0x141512;}['_isIframeWebStorageSupported'](_0x16346e,_0x3bb525){this['iframes'][_0x16346e['_key']()]['send'](pi,{'type':pi},_0x15fdb4=>{var _0x1e9f7d;const _0x1047f0=(_0x1e9f7d=_0x15fdb4==null?void 0x0:_0x15fdb4[0x0])==null?void 0x0:_0x1e9f7d[pi];_0x1047f0!==void 0x0&&_0x3bb525(!!_0x1047f0),Y(_0x16346e,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x407dde){const _0x518ca8=_0x407dde['_key']();return this['originValidationPromises'][_0x518ca8]||(this['originValidationPromises'][_0x518ca8]=Up(_0x407dde)),this['originValidationPromises'][_0x518ca8];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x1fde63){this['auth']=_0x1fde63,this['internalListeners']=new Map();}['getUid'](){var _0xf56678;return this['assertAuthConfigured'](),((_0xf56678=this['auth']['currentUser'])==null?void 0x0:_0xf56678['uid'])||null;}async['getToken'](_0x3c357b){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3c357b)}:null;}['addAuthTokenListener'](_0x5a1dc1){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5a1dc1))return;const _0x1f25de=this['auth']['onIdTokenChanged'](_0x38eac2=>{_0x5a1dc1((_0x38eac2==null?void 0x0:_0x38eac2['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5a1dc1,_0x1f25de),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x415244){this['assertAuthConfigured']();const _0x218d12=this['internalListeners']['get'](_0x415244);_0x218d12&&(this['internalListeners']['delete'](_0x415244),_0x218d12(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x5489ac){switch(_0x5489ac){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x1bc203){st(new Fe('auth',(_0x28f5fe,{options:_0x18fc23})=>{const _0x1736dd=_0x28f5fe['getProvider']('app')['getImmediate'](),_0xefebfa=_0x28f5fe['getProvider']('heartbeat'),_0x85c672=_0x28f5fe['getProvider']('app-check-internal'),{apiKey:_0x3e0f75,authDomain:_0x2f4628}=_0x1736dd['options'];m(_0x3e0f75&&!_0x3e0f75['includes'](':'),'invalid-api-key',{'appName':_0x1736dd['name']});const _0xf6bda7={'apiKey':_0x3e0f75,'authDomain':_0x2f4628,'clientPlatform':_0x1bc203,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x1bc203)},_0x1f5b98=new Df(_0x1736dd,_0xefebfa,_0x85c672,_0xf6bda7);return Hf(_0x1f5b98,_0x18fc23),_0x1f5b98;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x5e9912,_0x511316,_0x534f72)=>{_0x5e9912['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x5602d5=>{const _0x2c8695=Ke(_0x5602d5['getProvider']('auth')['getImmediate']());return(_0x4b57be=>new l_(_0x4b57be))(_0x2c8695);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x1bc203)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x546b33=>async _0x407e55=>{const _0xc0865c=_0x407e55&&await _0x407e55['getIdTokenResult'](),_0xa2aaef=_0xc0865c&&(new Date()['getTime']()-Date['parse'](_0xc0865c['issuedAtTime']))/0x3e8;if(_0xa2aaef&&_0xa2aaef>f_)return;const _0x43d43d=_0xc0865c==null?void 0x0:_0xc0865c['token'];Br!==_0x43d43d&&(Br=_0x43d43d,await fetch(_0x546b33,{'method':_0x43d43d?'POST':'DELETE','headers':_0x43d43d?{'Authorization':'Bearer\x20'+_0x43d43d}:{}}));};function B_(_0xd7cfb1=Zr()){const _0x3fbced=Hi(_0xd7cfb1,'auth');if(_0x3fbced['isInitialized']())return _0x3fbced['getImmediate']();const _0x1562e0=Vf(_0xd7cfb1,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x3b70bc=jr('authTokenSyncURL');if(_0x3b70bc&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x329ecc=new URL(_0x3b70bc,location['origin']);if(location['origin']===_0x329ecc['origin']){const _0x41a572=p_(_0x329ecc['toString']());sp(_0x1562e0,_0x41a572,()=>_0x41a572(_0x1562e0['currentUser'])),ip(_0x1562e0,_0x35ddcb=>_0x41a572(_0x35ddcb));}}const _0x131a7e=qr('auth');return _0x131a7e&&$f(_0x1562e0,'http://'+_0x131a7e),_0x1562e0;}function __(){var _0x541871;return((_0x541871=document['getElementsByTagName']('head'))==null?void 0x0:_0x541871[0x0])??document;}Mf({'loadJS'(_0x15043a){return new Promise((_0x3d3b9f,_0x18daa1)=>{const _0x1025d6=document['createElement']('script');_0x1025d6['setAttribute']('src',_0x15043a),_0x1025d6['onload']=_0x3d3b9f,_0x1025d6['onerror']=_0x4b01a1=>{const _0xa6acb8=X('internal-error');_0xa6acb8['customData']=_0x4b01a1,_0x18daa1(_0xa6acb8);},_0x1025d6['type']='text/javascript',_0x1025d6['charset']='UTF-8',__()['appendChild'](_0x1025d6);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};