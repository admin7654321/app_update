const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4db87e,_0x135c62){if(!_0x4db87e)throw ht(_0x135c62);},ht=function(_0x315d0e){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x315d0e);},Hr=function(_0x4fb329){const _0x505c9f=[];let _0x22e750=0x0;for(let _0x27624f=0x0;_0x27624f<_0x4fb329['length'];_0x27624f++){let _0x5ee766=_0x4fb329['charCodeAt'](_0x27624f);_0x5ee766<0x80?_0x505c9f[_0x22e750++]=_0x5ee766:_0x5ee766<0x800?(_0x505c9f[_0x22e750++]=_0x5ee766>>0x6|0xc0,_0x505c9f[_0x22e750++]=_0x5ee766&0x3f|0x80):(_0x5ee766&0xfc00)===0xd800&&_0x27624f+0x1<_0x4fb329['length']&&(_0x4fb329['charCodeAt'](_0x27624f+0x1)&0xfc00)===0xdc00?(_0x5ee766=0x10000+((_0x5ee766&0x3ff)<<0xa)+(_0x4fb329['charCodeAt'](++_0x27624f)&0x3ff),_0x505c9f[_0x22e750++]=_0x5ee766>>0x12|0xf0,_0x505c9f[_0x22e750++]=_0x5ee766>>0xc&0x3f|0x80,_0x505c9f[_0x22e750++]=_0x5ee766>>0x6&0x3f|0x80,_0x505c9f[_0x22e750++]=_0x5ee766&0x3f|0x80):(_0x505c9f[_0x22e750++]=_0x5ee766>>0xc|0xe0,_0x505c9f[_0x22e750++]=_0x5ee766>>0x6&0x3f|0x80,_0x505c9f[_0x22e750++]=_0x5ee766&0x3f|0x80);}return _0x505c9f;},nc=function(_0x19b1bd){const _0x3ad0e8=[];let _0x1e58b9=0x0,_0x39b06a=0x0;for(;_0x1e58b9<_0x19b1bd['length'];){const _0x16fb1c=_0x19b1bd[_0x1e58b9++];if(_0x16fb1c<0x80)_0x3ad0e8[_0x39b06a++]=String['fromCharCode'](_0x16fb1c);else{if(_0x16fb1c>0xbf&&_0x16fb1c<0xe0){const _0x846015=_0x19b1bd[_0x1e58b9++];_0x3ad0e8[_0x39b06a++]=String['fromCharCode']((_0x16fb1c&0x1f)<<0x6|_0x846015&0x3f);}else{if(_0x16fb1c>0xef&&_0x16fb1c<0x16d){const _0x288a62=_0x19b1bd[_0x1e58b9++],_0x316c92=_0x19b1bd[_0x1e58b9++],_0x7289e=_0x19b1bd[_0x1e58b9++],_0x3f7aa6=((_0x16fb1c&0x7)<<0x12|(_0x288a62&0x3f)<<0xc|(_0x316c92&0x3f)<<0x6|_0x7289e&0x3f)-0x10000;_0x3ad0e8[_0x39b06a++]=String['fromCharCode'](0xd800+(_0x3f7aa6>>0xa)),_0x3ad0e8[_0x39b06a++]=String['fromCharCode'](0xdc00+(_0x3f7aa6&0x3ff));}else{const _0x16ed42=_0x19b1bd[_0x1e58b9++],_0x203b5e=_0x19b1bd[_0x1e58b9++];_0x3ad0e8[_0x39b06a++]=String['fromCharCode']((_0x16fb1c&0xf)<<0xc|(_0x16ed42&0x3f)<<0x6|_0x203b5e&0x3f);}}}}return _0x3ad0e8['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xcab40b,_0x22a106){if(!Array['isArray'](_0xcab40b))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2a55e3=_0x22a106?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x346efe=[];for(let _0x2059f9=0x0;_0x2059f9<_0xcab40b['length'];_0x2059f9+=0x3){const _0x34a928=_0xcab40b[_0x2059f9],_0x5a0d35=_0x2059f9+0x1<_0xcab40b['length'],_0x479573=_0x5a0d35?_0xcab40b[_0x2059f9+0x1]:0x0,_0x4bb97e=_0x2059f9+0x2<_0xcab40b['length'],_0x578824=_0x4bb97e?_0xcab40b[_0x2059f9+0x2]:0x0,_0x4ff487=_0x34a928>>0x2,_0x19e1ba=(_0x34a928&0x3)<<0x4|_0x479573>>0x4;let _0x17399d=(_0x479573&0xf)<<0x2|_0x578824>>0x6,_0xd9867a=_0x578824&0x3f;_0x4bb97e||(_0xd9867a=0x40,_0x5a0d35||(_0x17399d=0x40)),_0x346efe['push'](_0x2a55e3[_0x4ff487],_0x2a55e3[_0x19e1ba],_0x2a55e3[_0x17399d],_0x2a55e3[_0xd9867a]);}return _0x346efe['join']('');},'encodeString'(_0x67293d,_0x584f21){return this['HAS_NATIVE_SUPPORT']&&!_0x584f21?btoa(_0x67293d):this['encodeByteArray'](Hr(_0x67293d),_0x584f21);},'decodeString'(_0x6aeeb2,_0x39c835){return this['HAS_NATIVE_SUPPORT']&&!_0x39c835?atob(_0x6aeeb2):nc(this['decodeStringToByteArray'](_0x6aeeb2,_0x39c835));},'decodeStringToByteArray'(_0x1d3a6f,_0x5afed2){this['init_']();const _0x168e95=_0x5afed2?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x857ffc=[];for(let _0x40f403=0x0;_0x40f403<_0x1d3a6f['length'];){const _0x32b279=_0x168e95[_0x1d3a6f['charAt'](_0x40f403++)],_0x330197=_0x40f403<_0x1d3a6f['length']?_0x168e95[_0x1d3a6f['charAt'](_0x40f403)]:0x0;++_0x40f403;const _0x47f8e7=_0x40f403<_0x1d3a6f['length']?_0x168e95[_0x1d3a6f['charAt'](_0x40f403)]:0x40;++_0x40f403;const _0x1ad1ab=_0x40f403<_0x1d3a6f['length']?_0x168e95[_0x1d3a6f['charAt'](_0x40f403)]:0x40;if(++_0x40f403,_0x32b279==null||_0x330197==null||_0x47f8e7==null||_0x1ad1ab==null)throw new ic();const _0xf3492c=_0x32b279<<0x2|_0x330197>>0x4;if(_0x857ffc['push'](_0xf3492c),_0x47f8e7!==0x40){const _0x2f93=_0x330197<<0x4&0xf0|_0x47f8e7>>0x2;if(_0x857ffc['push'](_0x2f93),_0x1ad1ab!==0x40){const _0x6ef7e9=_0x47f8e7<<0x6&0xc0|_0x1ad1ab;_0x857ffc['push'](_0x6ef7e9);}}}return _0x857ffc;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x26f05b=0x0;_0x26f05b<this['ENCODED_VALS']['length'];_0x26f05b++)this['byteToCharMap_'][_0x26f05b]=this['ENCODED_VALS']['charAt'](_0x26f05b),this['charToByteMap_'][this['byteToCharMap_'][_0x26f05b]]=_0x26f05b,this['byteToCharMapWebSafe_'][_0x26f05b]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x26f05b),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x26f05b]]=_0x26f05b,_0x26f05b>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x26f05b)]=_0x26f05b,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x26f05b)]=_0x26f05b);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x4843cf){const _0x2c9b6d=Hr(_0x4843cf);return Fi['encodeByteArray'](_0x2c9b6d,!0x0);},dn=function(_0x55e2f2){return $r(_0x55e2f2)['replace'](/\./g,'');},fn=function(_0x482875){try{return Fi['decodeString'](_0x482875,!0x0);}catch(_0x5c6ecf){console['error']('base64Decode\x20failed:\x20',_0x5c6ecf);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x253e44){return Gr(void 0x0,_0x253e44);}function Gr(_0x3b632a,_0x5dfc48){if(!(_0x5dfc48 instanceof Object))return _0x5dfc48;switch(_0x5dfc48['constructor']){case Date:const _0x894d43=_0x5dfc48;return new Date(_0x894d43['getTime']());case Object:_0x3b632a===void 0x0&&(_0x3b632a={});break;case Array:_0x3b632a=[];break;default:return _0x5dfc48;}for(const _0x5c7e05 in _0x5dfc48)!_0x5dfc48['hasOwnProperty'](_0x5c7e05)||!rc(_0x5c7e05)||(_0x3b632a[_0x5c7e05]=Gr(_0x3b632a[_0x5c7e05],_0x5dfc48[_0x5c7e05]));return _0x3b632a;}function rc(_0xc95321){return _0xc95321!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x473fd5=Ps['__FIREBASE_DEFAULTS__'];if(_0x473fd5)return JSON['parse'](_0x473fd5);},lc=()=>{if(typeof document>'u')return;let _0x3588d1;try{_0x3588d1=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xdcc1f9=_0x3588d1&&fn(_0x3588d1[0x1]);return _0xdcc1f9&&JSON['parse'](_0xdcc1f9);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0xd83a66){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xd83a66);return;}},qr=_0xff2378=>{var _0x1b70c6,_0x701e8e;return(_0x701e8e=(_0x1b70c6=Ui())==null?void 0x0:_0x1b70c6['emulatorHosts'])==null?void 0x0:_0x701e8e[_0xff2378];},hc=_0x323efb=>{const _0x53a545=qr(_0x323efb);if(!_0x53a545)return;const _0x4049ca=_0x53a545['lastIndexOf'](':');if(_0x4049ca<=0x0||_0x4049ca+0x1===_0x53a545['length'])throw new Error('Invalid\x20host\x20'+_0x53a545+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x10ae78=parseInt(_0x53a545['substring'](_0x4049ca+0x1),0xa);return _0x53a545[0x0]==='['?[_0x53a545['substring'](0x1,_0x4049ca-0x1),_0x10ae78]:[_0x53a545['substring'](0x0,_0x4049ca),_0x10ae78];},zr=()=>{var _0x37cb92;return(_0x37cb92=Ui())==null?void 0x0:_0x37cb92['config'];},jr=_0x4e5b2e=>{var _0x355798;return(_0x355798=Ui())==null?void 0x0:_0x355798['_'+_0x4e5b2e];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x14033c,_0x1a6936)=>{this['resolve']=_0x14033c,this['reject']=_0x1a6936;});}['wrapCallback'](_0x302a78){return(_0x479d92,_0x4595f3)=>{_0x479d92?this['reject'](_0x479d92):this['resolve'](_0x4595f3),typeof _0x302a78=='function'&&(this['promise']['catch'](()=>{}),_0x302a78['length']===0x1?_0x302a78(_0x479d92):_0x302a78(_0x479d92,_0x4595f3));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x58cf4a,_0x58f356){if(_0x58cf4a['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xfff865={'alg':'none','type':'JWT'},_0x38d2b4=_0x58f356||'demo-project',_0x1ed107=_0x58cf4a['iat']||0x0,_0x2ee3b8=_0x58cf4a['sub']||_0x58cf4a['user_id'];if(!_0x2ee3b8)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3178fa={'iss':'https://securetoken.google.com/'+_0x38d2b4,'aud':_0x38d2b4,'iat':_0x1ed107,'exp':_0x1ed107+0xe10,'auth_time':_0x1ed107,'sub':_0x2ee3b8,'user_id':_0x2ee3b8,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x58cf4a};return[dn(JSON['stringify'](_0xfff865)),dn(JSON['stringify'](_0x3178fa)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x22f9f2=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x22f9f2=='object'&&_0x22f9f2['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x265f1c=W();return _0x265f1c['indexOf']('MSIE\x20')>=0x0||_0x265f1c['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2378ff,_0x20bc6b)=>{try{let _0x563ba6=!0x0;const _0x2b9314='validate-browser-context-for-indexeddb-analytics-module',_0x21d65b=self['indexedDB']['open'](_0x2b9314);_0x21d65b['onsuccess']=()=>{_0x21d65b['result']['close'](),_0x563ba6||self['indexedDB']['deleteDatabase'](_0x2b9314),_0x2378ff(!0x0);},_0x21d65b['onupgradeneeded']=()=>{_0x563ba6=!0x1;},_0x21d65b['onerror']=()=>{var _0x259f5a;_0x20bc6b(((_0x259f5a=_0x21d65b['error'])==null?void 0x0:_0x259f5a['message'])||'');};}catch(_0x34c2d2){_0x20bc6b(_0x34c2d2);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x2d1dc6,_0x1f69a2,_0x5237ad){super(_0x1f69a2),this['code']=_0x2d1dc6,this['customData']=_0x5237ad,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x2438df,_0x253cc4,_0x1ade33){this['service']=_0x2438df,this['serviceName']=_0x253cc4,this['errors']=_0x1ade33;}['create'](_0x549adc,..._0x3f771e){const _0xb4079=_0x3f771e[0x0]||{},_0x2c93cb=this['service']+'/'+_0x549adc,_0x498fb7=this['errors'][_0x549adc],_0x110edc=_0x498fb7?vc(_0x498fb7,_0xb4079):'Error',_0x31ba4a=this['serviceName']+':\x20'+_0x110edc+'\x20('+_0x2c93cb+').';return new Re(_0x2c93cb,_0x31ba4a,_0xb4079);}}function vc(_0x2aa520,_0x45ed00){return _0x2aa520['replace'](Ec,(_0x1d63fb,_0x1138df)=>{const _0x476bc0=_0x45ed00[_0x1138df];return _0x476bc0!=null?String(_0x476bc0):'<'+_0x1138df+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x186e5d){return JSON['parse'](_0x186e5d);}function O(_0xb2f0a5){return JSON['stringify'](_0xb2f0a5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x38a7df){let _0x54c626={},_0x48a2f0={},_0x50c3af={},_0x21f618='';try{const _0x56eda6=_0x38a7df['split']('.');_0x54c626=Nt(fn(_0x56eda6[0x0])||''),_0x48a2f0=Nt(fn(_0x56eda6[0x1])||''),_0x21f618=_0x56eda6[0x2],_0x50c3af=_0x48a2f0['d']||{},delete _0x48a2f0['d'];}catch{}return{'header':_0x54c626,'claims':_0x48a2f0,'data':_0x50c3af,'signature':_0x21f618};},Ic=function(_0x15bd18){const _0x34b3c3=Yr(_0x15bd18),_0x5a3164=_0x34b3c3['claims'];return!!_0x5a3164&&typeof _0x5a3164=='object'&&_0x5a3164['hasOwnProperty']('iat');},wc=function(_0x429524){const _0x2e42ea=Yr(_0x429524)['claims'];return typeof _0x2e42ea=='object'&&_0x2e42ea['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x219b11,_0x3c5479){return Object['prototype']['hasOwnProperty']['call'](_0x219b11,_0x3c5479);}function Le(_0x1570a2,_0x4ec8ef){if(Object['prototype']['hasOwnProperty']['call'](_0x1570a2,_0x4ec8ef))return _0x1570a2[_0x4ec8ef];}function pn(_0x19931d){for(const _0x3311a4 in _0x19931d)if(Object['prototype']['hasOwnProperty']['call'](_0x19931d,_0x3311a4))return!0x1;return!0x0;}function _n(_0x10dad7,_0x36dc0a,_0x5852c3){const _0x3b84ec={};for(const _0x3ce1a8 in _0x10dad7)Object['prototype']['hasOwnProperty']['call'](_0x10dad7,_0x3ce1a8)&&(_0x3b84ec[_0x3ce1a8]=_0x36dc0a['call'](_0x5852c3,_0x10dad7[_0x3ce1a8],_0x3ce1a8,_0x10dad7));return _0x3b84ec;}function xe(_0x446e79,_0x58930e){if(_0x446e79===_0x58930e)return!0x0;const _0x53e19c=Object['keys'](_0x446e79),_0x48e500=Object['keys'](_0x58930e);for(const _0xb02cae of _0x53e19c){if(!_0x48e500['includes'](_0xb02cae))return!0x1;const _0x292c30=_0x446e79[_0xb02cae],_0x547411=_0x58930e[_0xb02cae];if(Ns(_0x292c30)&&Ns(_0x547411)){if(!xe(_0x292c30,_0x547411))return!0x1;}else{if(_0x292c30!==_0x547411)return!0x1;}}for(const _0x389bde of _0x48e500)if(!_0x53e19c['includes'](_0x389bde))return!0x1;return!0x0;}function Ns(_0xe0f56a){return _0xe0f56a!==null&&typeof _0xe0f56a=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x472ee4){const _0x53f4ba=[];for(const [_0x5dc95f,_0x563eff]of Object['entries'](_0x472ee4))Array['isArray'](_0x563eff)?_0x563eff['forEach'](_0x1d6b2a=>{_0x53f4ba['push'](encodeURIComponent(_0x5dc95f)+'='+encodeURIComponent(_0x1d6b2a));}):_0x53f4ba['push'](encodeURIComponent(_0x5dc95f)+'='+encodeURIComponent(_0x563eff));return _0x53f4ba['length']?'&'+_0x53f4ba['join']('&'):'';}function Ct(_0x43ac48){const _0x423e37={};return _0x43ac48['replace'](/^\?/,'')['split']('&')['forEach'](_0x1050e6=>{if(_0x1050e6){const [_0x4aa97d,_0x55491a]=_0x1050e6['split']('=');_0x423e37[decodeURIComponent(_0x4aa97d)]=decodeURIComponent(_0x55491a);}}),_0x423e37;}function Tt(_0x329751){const _0x158029=_0x329751['indexOf']('?');if(!_0x158029)return'';const _0x546492=_0x329751['indexOf']('#',_0x158029);return _0x329751['substring'](_0x158029,_0x546492>0x0?_0x546492:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x40c381=0x1;_0x40c381<this['blockSize'];++_0x40c381)this['pad_'][_0x40c381]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x4b5673,_0x1632cc){_0x1632cc||(_0x1632cc=0x0);const _0x53b562=this['W_'];if(typeof _0x4b5673=='string'){for(let _0x424ad4=0x0;_0x424ad4<0x10;_0x424ad4++)_0x53b562[_0x424ad4]=_0x4b5673['charCodeAt'](_0x1632cc)<<0x18|_0x4b5673['charCodeAt'](_0x1632cc+0x1)<<0x10|_0x4b5673['charCodeAt'](_0x1632cc+0x2)<<0x8|_0x4b5673['charCodeAt'](_0x1632cc+0x3),_0x1632cc+=0x4;}else{for(let _0x72f4da=0x0;_0x72f4da<0x10;_0x72f4da++)_0x53b562[_0x72f4da]=_0x4b5673[_0x1632cc]<<0x18|_0x4b5673[_0x1632cc+0x1]<<0x10|_0x4b5673[_0x1632cc+0x2]<<0x8|_0x4b5673[_0x1632cc+0x3],_0x1632cc+=0x4;}for(let _0x2877c6=0x10;_0x2877c6<0x50;_0x2877c6++){const _0x30a9b3=_0x53b562[_0x2877c6-0x3]^_0x53b562[_0x2877c6-0x8]^_0x53b562[_0x2877c6-0xe]^_0x53b562[_0x2877c6-0x10];_0x53b562[_0x2877c6]=(_0x30a9b3<<0x1|_0x30a9b3>>>0x1f)&0xffffffff;}let _0x17c34b=this['chain_'][0x0],_0x59aef4=this['chain_'][0x1],_0x3d8bf0=this['chain_'][0x2],_0x15d0ff=this['chain_'][0x3],_0x3b3c3a=this['chain_'][0x4],_0x5d465f,_0x1fdeca;for(let _0x13efe8=0x0;_0x13efe8<0x50;_0x13efe8++){_0x13efe8<0x28?_0x13efe8<0x14?(_0x5d465f=_0x15d0ff^_0x59aef4&(_0x3d8bf0^_0x15d0ff),_0x1fdeca=0x5a827999):(_0x5d465f=_0x59aef4^_0x3d8bf0^_0x15d0ff,_0x1fdeca=0x6ed9eba1):_0x13efe8<0x3c?(_0x5d465f=_0x59aef4&_0x3d8bf0|_0x15d0ff&(_0x59aef4|_0x3d8bf0),_0x1fdeca=0x8f1bbcdc):(_0x5d465f=_0x59aef4^_0x3d8bf0^_0x15d0ff,_0x1fdeca=0xca62c1d6);const _0x3680de=(_0x17c34b<<0x5|_0x17c34b>>>0x1b)+_0x5d465f+_0x3b3c3a+_0x1fdeca+_0x53b562[_0x13efe8]&0xffffffff;_0x3b3c3a=_0x15d0ff,_0x15d0ff=_0x3d8bf0,_0x3d8bf0=(_0x59aef4<<0x1e|_0x59aef4>>>0x2)&0xffffffff,_0x59aef4=_0x17c34b,_0x17c34b=_0x3680de;}this['chain_'][0x0]=this['chain_'][0x0]+_0x17c34b&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x59aef4&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3d8bf0&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x15d0ff&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3b3c3a&0xffffffff;}['update'](_0x5f2c25,_0x55eb88){if(_0x5f2c25==null)return;_0x55eb88===void 0x0&&(_0x55eb88=_0x5f2c25['length']);const _0x1e7443=_0x55eb88-this['blockSize'];let _0x263878=0x0;const _0x1f4f21=this['buf_'];let _0x498bc4=this['inbuf_'];for(;_0x263878<_0x55eb88;){if(_0x498bc4===0x0){for(;_0x263878<=_0x1e7443;)this['compress_'](_0x5f2c25,_0x263878),_0x263878+=this['blockSize'];}if(typeof _0x5f2c25=='string'){for(;_0x263878<_0x55eb88;)if(_0x1f4f21[_0x498bc4]=_0x5f2c25['charCodeAt'](_0x263878),++_0x498bc4,++_0x263878,_0x498bc4===this['blockSize']){this['compress_'](_0x1f4f21),_0x498bc4=0x0;break;}}else{for(;_0x263878<_0x55eb88;)if(_0x1f4f21[_0x498bc4]=_0x5f2c25[_0x263878],++_0x498bc4,++_0x263878,_0x498bc4===this['blockSize']){this['compress_'](_0x1f4f21),_0x498bc4=0x0;break;}}}this['inbuf_']=_0x498bc4,this['total_']+=_0x55eb88;}['digest'](){const _0x4650e5=[];let _0x5cbcef=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x3bc8d7=this['blockSize']-0x1;_0x3bc8d7>=0x38;_0x3bc8d7--)this['buf_'][_0x3bc8d7]=_0x5cbcef&0xff,_0x5cbcef/=0x100;this['compress_'](this['buf_']);let _0x2fc483=0x0;for(let _0x1b1fca=0x0;_0x1b1fca<0x5;_0x1b1fca++)for(let _0x25b7e3=0x18;_0x25b7e3>=0x0;_0x25b7e3-=0x8)_0x4650e5[_0x2fc483]=this['chain_'][_0x1b1fca]>>_0x25b7e3&0xff,++_0x2fc483;return _0x4650e5;}}function Tc(_0x3e03f9,_0x50ad7c){const _0x35982a=new Sc(_0x3e03f9,_0x50ad7c);return _0x35982a['subscribe']['bind'](_0x35982a);}class Sc{constructor(_0x500acb,_0x32481a){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x32481a,this['task']['then'](()=>{_0x500acb(this);})['catch'](_0x3c80e6=>{this['error'](_0x3c80e6);});}['next'](_0x10f061){this['forEachObserver'](_0xae28a7=>{_0xae28a7['next'](_0x10f061);});}['error'](_0x1a978b){this['forEachObserver'](_0x25b8bf=>{_0x25b8bf['error'](_0x1a978b);}),this['close'](_0x1a978b);}['complete'](){this['forEachObserver'](_0x3928be=>{_0x3928be['complete']();}),this['close']();}['subscribe'](_0x19eb63,_0x387b3a,_0x129689){let _0x3ab3e6;if(_0x19eb63===void 0x0&&_0x387b3a===void 0x0&&_0x129689===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x19eb63,['next','error','complete'])?_0x3ab3e6=_0x19eb63:_0x3ab3e6={'next':_0x19eb63,'error':_0x387b3a,'complete':_0x129689},_0x3ab3e6['next']===void 0x0&&(_0x3ab3e6['next']=ti),_0x3ab3e6['error']===void 0x0&&(_0x3ab3e6['error']=ti),_0x3ab3e6['complete']===void 0x0&&(_0x3ab3e6['complete']=ti);const _0x380e3c=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3ab3e6['error'](this['finalError']):_0x3ab3e6['complete']();}catch{}}),this['observers']['push'](_0x3ab3e6),_0x380e3c;}['unsubscribeOne'](_0x44fd84){this['observers']===void 0x0||this['observers'][_0x44fd84]===void 0x0||(delete this['observers'][_0x44fd84],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x555b23){if(!this['finalized']){for(let _0x18231b=0x0;_0x18231b<this['observers']['length'];_0x18231b++)this['sendOne'](_0x18231b,_0x555b23);}}['sendOne'](_0x25176d,_0x16866e){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x25176d]!==void 0x0)try{_0x16866e(this['observers'][_0x25176d]);}catch(_0x359b0b){typeof console<'u'&&console['error']&&console['error'](_0x359b0b);}});}['close'](_0x3d390a){this['finalized']||(this['finalized']=!0x0,_0x3d390a!==void 0x0&&(this['finalError']=_0x3d390a),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0xf58da6,_0x3e0361){if(typeof _0xf58da6!='object'||_0xf58da6===null)return!0x1;for(const _0x51a8d6 of _0x3e0361)if(_0x51a8d6 in _0xf58da6&&typeof _0xf58da6[_0x51a8d6]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x321dcb,_0x5a510e){return _0x321dcb+'\x20failed:\x20'+_0x5a510e+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x40145b){const _0x366930=[];let _0x232c65=0x0;for(let _0x5f573a=0x0;_0x5f573a<_0x40145b['length'];_0x5f573a++){let _0x17b008=_0x40145b['charCodeAt'](_0x5f573a);if(_0x17b008>=0xd800&&_0x17b008<=0xdbff){const _0x2d778e=_0x17b008-0xd800;_0x5f573a++,f(_0x5f573a<_0x40145b['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x399109=_0x40145b['charCodeAt'](_0x5f573a)-0xdc00;_0x17b008=0x10000+(_0x2d778e<<0xa)+_0x399109;}_0x17b008<0x80?_0x366930[_0x232c65++]=_0x17b008:_0x17b008<0x800?(_0x366930[_0x232c65++]=_0x17b008>>0x6|0xc0,_0x366930[_0x232c65++]=_0x17b008&0x3f|0x80):_0x17b008<0x10000?(_0x366930[_0x232c65++]=_0x17b008>>0xc|0xe0,_0x366930[_0x232c65++]=_0x17b008>>0x6&0x3f|0x80,_0x366930[_0x232c65++]=_0x17b008&0x3f|0x80):(_0x366930[_0x232c65++]=_0x17b008>>0x12|0xf0,_0x366930[_0x232c65++]=_0x17b008>>0xc&0x3f|0x80,_0x366930[_0x232c65++]=_0x17b008>>0x6&0x3f|0x80,_0x366930[_0x232c65++]=_0x17b008&0x3f|0x80);}return _0x366930;},Ln=function(_0x266dc2){let _0x140d8b=0x0;for(let _0x3aa240=0x0;_0x3aa240<_0x266dc2['length'];_0x3aa240++){const _0x38aa53=_0x266dc2['charCodeAt'](_0x3aa240);_0x38aa53<0x80?_0x140d8b++:_0x38aa53<0x800?_0x140d8b+=0x2:_0x38aa53>=0xd800&&_0x38aa53<=0xdbff?(_0x140d8b+=0x4,_0x3aa240++):_0x140d8b+=0x3;}return _0x140d8b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x15a81a){return _0x15a81a&&_0x15a81a['_delegate']?_0x15a81a['_delegate']:_0x15a81a;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x1115b5){try{return(_0x1115b5['startsWith']('http://')||_0x1115b5['startsWith']('https://')?new URL(_0x1115b5)['hostname']:_0x1115b5)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x481de1){return(await fetch(_0x481de1,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x3e8dff,_0x2055a8,_0x47b466){this['name']=_0x3e8dff,this['instanceFactory']=_0x2055a8,this['type']=_0x47b466,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x3056bd){return this['instantiationMode']=_0x3056bd,this;}['setMultipleInstances'](_0x1b2280){return this['multipleInstances']=_0x1b2280,this;}['setServiceProps'](_0x1b36e1){return this['serviceProps']=_0x1b36e1,this;}['setInstanceCreatedCallback'](_0x498fd7){return this['onInstanceCreated']=_0x498fd7,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x12235a,_0x1867e1){this['name']=_0x12235a,this['container']=_0x1867e1,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x9d5f48){const _0x1a83e6=this['normalizeInstanceIdentifier'](_0x9d5f48);if(!this['instancesDeferred']['has'](_0x1a83e6)){const _0x3d66af=new H();if(this['instancesDeferred']['set'](_0x1a83e6,_0x3d66af),this['isInitialized'](_0x1a83e6)||this['shouldAutoInitialize']())try{const _0x91d725=this['getOrInitializeService']({'instanceIdentifier':_0x1a83e6});_0x91d725&&_0x3d66af['resolve'](_0x91d725);}catch{}}return this['instancesDeferred']['get'](_0x1a83e6)['promise'];}['getImmediate'](_0x112618){const _0x1f0f0b=this['normalizeInstanceIdentifier'](_0x112618==null?void 0x0:_0x112618['identifier']),_0x359445=(_0x112618==null?void 0x0:_0x112618['optional'])??!0x1;if(this['isInitialized'](_0x1f0f0b)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1f0f0b});}catch(_0x2eccda){if(_0x359445)return null;throw _0x2eccda;}else{if(_0x359445)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1e4570){if(_0x1e4570['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1e4570['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1e4570,!!this['shouldAutoInitialize']()){if(Pc(_0x1e4570))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4cb2b8,_0x5c2bb4]of this['instancesDeferred']['entries']()){const _0x27e696=this['normalizeInstanceIdentifier'](_0x4cb2b8);try{const _0x19b8ea=this['getOrInitializeService']({'instanceIdentifier':_0x27e696});_0x5c2bb4['resolve'](_0x19b8ea);}catch{}}}}['clearInstance'](_0x2b1a5f=Ne){this['instancesDeferred']['delete'](_0x2b1a5f),this['instancesOptions']['delete'](_0x2b1a5f),this['instances']['delete'](_0x2b1a5f);}async['delete'](){const _0x260ec1=Array['from'](this['instances']['values']());await Promise['all']([..._0x260ec1['filter'](_0x59e319=>'INTERNAL'in _0x59e319)['map'](_0xa51541=>_0xa51541['INTERNAL']['delete']()),..._0x260ec1['filter'](_0x221019=>'_delete'in _0x221019)['map'](_0x5db586=>_0x5db586['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2ab2ac=Ne){return this['instances']['has'](_0x2ab2ac);}['getOptions'](_0x2ef262=Ne){return this['instancesOptions']['get'](_0x2ef262)||{};}['initialize'](_0x1a1cc7={}){const {options:_0x5b7f28={}}=_0x1a1cc7,_0xa0d930=this['normalizeInstanceIdentifier'](_0x1a1cc7['instanceIdentifier']);if(this['isInitialized'](_0xa0d930))throw Error(this['name']+'('+_0xa0d930+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x111c8b=this['getOrInitializeService']({'instanceIdentifier':_0xa0d930,'options':_0x5b7f28});for(const [_0x55d360,_0x496e58]of this['instancesDeferred']['entries']()){const _0x5057df=this['normalizeInstanceIdentifier'](_0x55d360);_0xa0d930===_0x5057df&&_0x496e58['resolve'](_0x111c8b);}return _0x111c8b;}['onInit'](_0x593fce,_0x42a35d){const _0xa73c13=this['normalizeInstanceIdentifier'](_0x42a35d),_0x3d3a6c=this['onInitCallbacks']['get'](_0xa73c13)??new Set();_0x3d3a6c['add'](_0x593fce),this['onInitCallbacks']['set'](_0xa73c13,_0x3d3a6c);const _0x304bdc=this['instances']['get'](_0xa73c13);return _0x304bdc&&_0x593fce(_0x304bdc,_0xa73c13),()=>{_0x3d3a6c['delete'](_0x593fce);};}['invokeOnInitCallbacks'](_0x22868f,_0x3f3ae6){const _0x7f8b7d=this['onInitCallbacks']['get'](_0x3f3ae6);if(_0x7f8b7d){for(const _0x2188cf of _0x7f8b7d)try{_0x2188cf(_0x22868f,_0x3f3ae6);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x56df3f,options:_0x472ab8={}}){let _0x4f85b3=this['instances']['get'](_0x56df3f);if(!_0x4f85b3&&this['component']&&(_0x4f85b3=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x56df3f),'options':_0x472ab8}),this['instances']['set'](_0x56df3f,_0x4f85b3),this['instancesOptions']['set'](_0x56df3f,_0x472ab8),this['invokeOnInitCallbacks'](_0x4f85b3,_0x56df3f),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x56df3f,_0x4f85b3);}catch{}return _0x4f85b3||null;}['normalizeInstanceIdentifier'](_0x481d64=Ne){return this['component']?this['component']['multipleInstances']?_0x481d64:Ne:_0x481d64;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x4bb776){return _0x4bb776===Ne?void 0x0:_0x4bb776;}function Pc(_0x2fd7ef){return _0x2fd7ef['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x42ec03){this['name']=_0x42ec03,this['providers']=new Map();}['addComponent'](_0x4be32f){const _0x4b2e8c=this['getProvider'](_0x4be32f['name']);if(_0x4b2e8c['isComponentSet']())throw new Error('Component\x20'+_0x4be32f['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4b2e8c['setComponent'](_0x4be32f);}['addOrOverwriteComponent'](_0xe575f1){this['getProvider'](_0xe575f1['name'])['isComponentSet']()&&this['providers']['delete'](_0xe575f1['name']),this['addComponent'](_0xe575f1);}['getProvider'](_0x17c2b1){if(this['providers']['has'](_0x17c2b1))return this['providers']['get'](_0x17c2b1);const _0xd61ef1=new Ac(_0x17c2b1,this);return this['providers']['set'](_0x17c2b1,_0xd61ef1),_0xd61ef1;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xc2209){_0xc2209[_0xc2209['DEBUG']=0x0]='DEBUG',_0xc2209[_0xc2209['VERBOSE']=0x1]='VERBOSE',_0xc2209[_0xc2209['INFO']=0x2]='INFO',_0xc2209[_0xc2209['WARN']=0x3]='WARN',_0xc2209[_0xc2209['ERROR']=0x4]='ERROR',_0xc2209[_0xc2209['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x32df5e,_0x39dc2b,..._0x17631f)=>{if(_0x39dc2b<_0x32df5e['logLevel'])return;const _0xda55f4=new Date()['toISOString'](),_0x110070=Mc[_0x39dc2b];if(_0x110070)console[_0x110070]('['+_0xda55f4+']\x20\x20'+_0x32df5e['name']+':',..._0x17631f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x39dc2b+')');};class Bi{constructor(_0x36ddce){this['name']=_0x36ddce,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x17d831){if(!(_0x17d831 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x17d831+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x17d831;}['setLogLevel'](_0x4ac6d0){this['_logLevel']=typeof _0x4ac6d0=='string'?Oc[_0x4ac6d0]:_0x4ac6d0;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x246a33){if(typeof _0x246a33!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x246a33;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x497d84){this['_userLogHandler']=_0x497d84;}['debug'](..._0x4efb4c){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4efb4c),this['_logHandler'](this,T['DEBUG'],..._0x4efb4c);}['log'](..._0x3006bc){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x3006bc),this['_logHandler'](this,T['VERBOSE'],..._0x3006bc);}['info'](..._0x5b1876){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5b1876),this['_logHandler'](this,T['INFO'],..._0x5b1876);}['warn'](..._0x103f71){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x103f71),this['_logHandler'](this,T['WARN'],..._0x103f71);}['error'](..._0x23b20f){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x23b20f),this['_logHandler'](this,T['ERROR'],..._0x23b20f);}}const xc=(_0x5cf694,_0x568b75)=>_0x568b75['some'](_0x3527db=>_0x5cf694 instanceof _0x3527db);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x530257){const _0x1afd10=new Promise((_0x59720e,_0x58bf56)=>{const _0x1d2daf=()=>{_0x530257['removeEventListener']('success',_0x389796),_0x530257['removeEventListener']('error',_0x2e5a8d);},_0x389796=()=>{_0x59720e(ge(_0x530257['result'])),_0x1d2daf();},_0x2e5a8d=()=>{_0x58bf56(_0x530257['error']),_0x1d2daf();};_0x530257['addEventListener']('success',_0x389796),_0x530257['addEventListener']('error',_0x2e5a8d);});return _0x1afd10['then'](_0xfc07df=>{_0xfc07df instanceof IDBCursor&&Jr['set'](_0xfc07df,_0x530257);})['catch'](()=>{}),Vi['set'](_0x1afd10,_0x530257),_0x1afd10;}function Bc(_0x334ab5){if(_i['has'](_0x334ab5))return;const _0x1c97c6=new Promise((_0x26873a,_0x42a097)=>{const _0x1b39e1=()=>{_0x334ab5['removeEventListener']('complete',_0x53d4d5),_0x334ab5['removeEventListener']('error',_0x3e7126),_0x334ab5['removeEventListener']('abort',_0x3e7126);},_0x53d4d5=()=>{_0x26873a(),_0x1b39e1();},_0x3e7126=()=>{_0x42a097(_0x334ab5['error']||new DOMException('AbortError','AbortError')),_0x1b39e1();};_0x334ab5['addEventListener']('complete',_0x53d4d5),_0x334ab5['addEventListener']('error',_0x3e7126),_0x334ab5['addEventListener']('abort',_0x3e7126);});_i['set'](_0x334ab5,_0x1c97c6);}let gi={'get'(_0x3c3c21,_0x3ab710,_0x31b118){if(_0x3c3c21 instanceof IDBTransaction){if(_0x3ab710==='done')return _i['get'](_0x3c3c21);if(_0x3ab710==='objectStoreNames')return _0x3c3c21['objectStoreNames']||Xr['get'](_0x3c3c21);if(_0x3ab710==='store')return _0x31b118['objectStoreNames'][0x1]?void 0x0:_0x31b118['objectStore'](_0x31b118['objectStoreNames'][0x0]);}return ge(_0x3c3c21[_0x3ab710]);},'set'(_0x4e1858,_0x19eb31,_0x2f0ac5){return _0x4e1858[_0x19eb31]=_0x2f0ac5,!0x0;},'has'(_0x58aae6,_0x16ab2a){return _0x58aae6 instanceof IDBTransaction&&(_0x16ab2a==='done'||_0x16ab2a==='store')?!0x0:_0x16ab2a in _0x58aae6;}};function Vc(_0xba3973){gi=_0xba3973(gi);}function Hc(_0x449d6d){return _0x449d6d===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x391c39,..._0x2d7196){const _0x69d4d4=_0x449d6d['call'](ii(this),_0x391c39,..._0x2d7196);return Xr['set'](_0x69d4d4,_0x391c39['sort']?_0x391c39['sort']():[_0x391c39]),ge(_0x69d4d4);}:Uc()['includes'](_0x449d6d)?function(..._0x433fc9){return _0x449d6d['apply'](ii(this),_0x433fc9),ge(Jr['get'](this));}:function(..._0x2eefbc){return ge(_0x449d6d['apply'](ii(this),_0x2eefbc));};}function $c(_0xdc1d6a){return typeof _0xdc1d6a=='function'?Hc(_0xdc1d6a):(_0xdc1d6a instanceof IDBTransaction&&Bc(_0xdc1d6a),xc(_0xdc1d6a,Fc())?new Proxy(_0xdc1d6a,gi):_0xdc1d6a);}function ge(_0x710bb6){if(_0x710bb6 instanceof IDBRequest)return Wc(_0x710bb6);if(ni['has'](_0x710bb6))return ni['get'](_0x710bb6);const _0x22d355=$c(_0x710bb6);return _0x22d355!==_0x710bb6&&(ni['set'](_0x710bb6,_0x22d355),Vi['set'](_0x22d355,_0x710bb6)),_0x22d355;}const ii=_0x2a36b0=>Vi['get'](_0x2a36b0);function Gc(_0x1124b3,_0x45aed3,{blocked:_0x2adafc,upgrade:_0x8fbaac,blocking:_0x501425,terminated:_0x2bb155}={}){const _0x49939c=indexedDB['open'](_0x1124b3,_0x45aed3),_0x251392=ge(_0x49939c);return _0x8fbaac&&_0x49939c['addEventListener']('upgradeneeded',_0x20393c=>{_0x8fbaac(ge(_0x49939c['result']),_0x20393c['oldVersion'],_0x20393c['newVersion'],ge(_0x49939c['transaction']),_0x20393c);}),_0x2adafc&&_0x49939c['addEventListener']('blocked',_0x3e40c4=>_0x2adafc(_0x3e40c4['oldVersion'],_0x3e40c4['newVersion'],_0x3e40c4)),_0x251392['then'](_0x586fdf=>{_0x2bb155&&_0x586fdf['addEventListener']('close',()=>_0x2bb155()),_0x501425&&_0x586fdf['addEventListener']('versionchange',_0xe68acd=>_0x501425(_0xe68acd['oldVersion'],_0xe68acd['newVersion'],_0xe68acd));})['catch'](()=>{}),_0x251392;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x375e80,_0x391533){if(!(_0x375e80 instanceof IDBDatabase&&!(_0x391533 in _0x375e80)&&typeof _0x391533=='string'))return;if(si['get'](_0x391533))return si['get'](_0x391533);const _0x287894=_0x391533['replace'](/FromIndex$/,''),_0x366144=_0x391533!==_0x287894,_0x16e28d=zc['includes'](_0x287894);if(!(_0x287894 in(_0x366144?IDBIndex:IDBObjectStore)['prototype'])||!(_0x16e28d||qc['includes'](_0x287894)))return;const _0x508abc=async function(_0x18833f,..._0x33b87d){const _0x557edb=this['transaction'](_0x18833f,_0x16e28d?'readwrite':'readonly');let _0x37dadd=_0x557edb['store'];return _0x366144&&(_0x37dadd=_0x37dadd['index'](_0x33b87d['shift']())),(await Promise['all']([_0x37dadd[_0x287894](..._0x33b87d),_0x16e28d&&_0x557edb['done']]))[0x0];};return si['set'](_0x391533,_0x508abc),_0x508abc;}Vc(_0x3c4a5a=>({..._0x3c4a5a,'get':(_0xdac802,_0x2824f1,_0x31f9da)=>Ms(_0xdac802,_0x2824f1)||_0x3c4a5a['get'](_0xdac802,_0x2824f1,_0x31f9da),'has':(_0xb55d5f,_0x111090)=>!!Ms(_0xb55d5f,_0x111090)||_0x3c4a5a['has'](_0xb55d5f,_0x111090)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x5f1818){this['container']=_0x5f1818;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xdaec5e=>{if(Kc(_0xdaec5e)){const _0x3beb14=_0xdaec5e['getImmediate']();return _0x3beb14['library']+'/'+_0x3beb14['version'];}else return null;})['filter'](_0x58abb3=>_0x58abb3)['join']('\x20');}}function Kc(_0x3cab97){const _0x5b3cc8=_0x3cab97['getComponent']();return(_0x5b3cc8==null?void 0x0:_0x5b3cc8['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x2e44b0,_0x54b6dc){try{_0x2e44b0['container']['addComponent'](_0x54b6dc);}catch(_0x1abc31){oe['debug']('Component\x20'+_0x54b6dc['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2e44b0['name'],_0x1abc31);}}function st(_0x416768){const _0x2cc9a4=_0x416768['name'];if(Ei['has'](_0x2cc9a4))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x2cc9a4+'.'),!0x1;Ei['set'](_0x2cc9a4,_0x416768);for(const _0x28c6f7 of Ue['values']())xs(_0x28c6f7,_0x416768);for(const _0x3a9c5c of vi['values']())xs(_0x3a9c5c,_0x416768);return!0x0;}function Hi(_0xad1eb8,_0x56581d){const _0x30f569=_0xad1eb8['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x30f569&&_0x30f569['triggerHeartbeat'](),_0xad1eb8['container']['getProvider'](_0x56581d);}function $(_0x4d7f76){return _0x4d7f76==null?!0x1:_0x4d7f76['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x14217b,_0x24f6ef,_0x23263){this['_isDeleted']=!0x1,this['_options']={..._0x14217b},this['_config']={..._0x24f6ef},this['_name']=_0x24f6ef['name'],this['_automaticDataCollectionEnabled']=_0x24f6ef['automaticDataCollectionEnabled'],this['_container']=_0x23263,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x1de114){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x1de114;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x2de5b3){this['_isDeleted']=_0x2de5b3;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x2814fa,_0x549d04={}){let _0x244ace=_0x2814fa;typeof _0x549d04!='object'&&(_0x549d04={'name':_0x549d04});const _0xa41a5d={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x549d04},_0x50ca08=_0xa41a5d['name'];if(typeof _0x50ca08!='string'||!_0x50ca08)throw me['create']('bad-app-name',{'appName':String(_0x50ca08)});if(_0x244ace||(_0x244ace=zr()),!_0x244ace)throw me['create']('no-options');const _0x24f988=Ue['get'](_0x50ca08);if(_0x24f988){if(xe(_0x244ace,_0x24f988['options'])&&xe(_0xa41a5d,_0x24f988['config']))return _0x24f988;throw me['create']('duplicate-app',{'appName':_0x50ca08});}const _0x54d8e1=new Nc(_0x50ca08);for(const _0x28574c of Ei['values']())_0x54d8e1['addComponent'](_0x28574c);const _0x3aab86=new Tl(_0x244ace,_0xa41a5d,_0x54d8e1);return Ue['set'](_0x50ca08,_0x3aab86),_0x3aab86;}function Zr(_0x366bb4=yi){const _0x2a4c76=Ue['get'](_0x366bb4);if(!_0x2a4c76&&_0x366bb4===yi&&zr())return Sl();if(!_0x2a4c76)throw me['create']('no-app',{'appName':_0x366bb4});return _0x2a4c76;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x5bf697){let _0x37beec=!0x1;const _0x5d90e5=_0x5bf697['name'];Ue['has'](_0x5d90e5)?(_0x37beec=!0x0,Ue['delete'](_0x5d90e5)):vi['has'](_0x5d90e5)&&_0x5bf697['decRefCount']()<=0x0&&(vi['delete'](_0x5d90e5),_0x37beec=!0x0),_0x37beec&&(await Promise['all'](_0x5bf697['container']['getProviders']()['map'](_0x4a496d=>_0x4a496d['delete']())),_0x5bf697['isDeleted']=!0x0);}function ye(_0x28c291,_0x4404ba,_0x4e6bf8){let _0x2079a1=wl[_0x28c291]??_0x28c291;_0x4e6bf8&&(_0x2079a1+='-'+_0x4e6bf8);const _0x47b68c=_0x2079a1['match'](/\s|\//),_0x3b2de1=_0x4404ba['match'](/\s|\//);if(_0x47b68c||_0x3b2de1){const _0x125a8f=['Unable\x20to\x20register\x20library\x20\x22'+_0x2079a1+'\x22\x20with\x20version\x20\x22'+_0x4404ba+'\x22:'];_0x47b68c&&_0x125a8f['push']('library\x20name\x20\x22'+_0x2079a1+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x47b68c&&_0x3b2de1&&_0x125a8f['push']('and'),_0x3b2de1&&_0x125a8f['push']('version\x20name\x20\x22'+_0x4404ba+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x125a8f['join']('\x20'));return;}st(new Fe(_0x2079a1+'-version',()=>({'library':_0x2079a1,'version':_0x4404ba}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x16e3d0,_0x2c519a)=>{switch(_0x2c519a){case 0x0:try{_0x16e3d0['createObjectStore'](Ot);}catch(_0x329291){console['warn'](_0x329291);}}}})['catch'](_0x325a5c=>{throw me['create']('idb-open',{'originalErrorMessage':_0x325a5c['message']});})),ri;}async function Al(_0x85cca8){try{const _0x1e6abd=(await eo())['transaction'](Ot),_0x2b1fab=await _0x1e6abd['objectStore'](Ot)['get'](to(_0x85cca8));return await _0x1e6abd['done'],_0x2b1fab;}catch(_0x41d82f){if(_0x41d82f instanceof Re)oe['warn'](_0x41d82f['message']);else{const _0x16ac9f=me['create']('idb-get',{'originalErrorMessage':_0x41d82f==null?void 0x0:_0x41d82f['message']});oe['warn'](_0x16ac9f['message']);}}}async function Fs(_0x431a19,_0x65a460){try{const _0x3a7691=(await eo())['transaction'](Ot,'readwrite');await _0x3a7691['objectStore'](Ot)['put'](_0x65a460,to(_0x431a19)),await _0x3a7691['done'];}catch(_0x4579a5){if(_0x4579a5 instanceof Re)oe['warn'](_0x4579a5['message']);else{const _0x1c6ea2=me['create']('idb-set',{'originalErrorMessage':_0x4579a5==null?void 0x0:_0x4579a5['message']});oe['warn'](_0x1c6ea2['message']);}}}function to(_0x53036e){return _0x53036e['name']+'!'+_0x53036e['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x33426c){this['container']=_0x33426c,this['_heartbeatsCache']=null;const _0x21a799=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x21a799),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4f740a=>(this['_heartbeatsCache']=_0x4f740a,_0x4f740a));}async['triggerHeartbeat'](){var _0x5a6401,_0x496c50;try{const _0x52d308=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2b540d=Us();if(((_0x5a6401=this['_heartbeatsCache'])==null?void 0x0:_0x5a6401['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x496c50=this['_heartbeatsCache'])==null?void 0x0:_0x496c50['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2b540d||this['_heartbeatsCache']['heartbeats']['some'](_0x380a39=>_0x380a39['date']===_0x2b540d))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2b540d,'agent':_0x52d308}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x506446=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x506446,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x1039db){oe['warn'](_0x1039db);}}async['getHeartbeatsHeader'](){var _0x9dc1c8;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x9dc1c8=this['_heartbeatsCache'])==null?void 0x0:_0x9dc1c8['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x28be57=Us(),{heartbeatsToSend:_0x392a28,unsentEntries:_0x3ebb41}=Ol(this['_heartbeatsCache']['heartbeats']),_0x38faab=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x392a28}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x28be57,_0x3ebb41['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3ebb41,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x38faab;}catch(_0x242bba){return oe['warn'](_0x242bba),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x10c4e3,_0x531272=kl){const _0x2d61cb=[];let _0x4135ad=_0x10c4e3['slice']();for(const _0xd46b70 of _0x10c4e3){const _0x34a4c7=_0x2d61cb['find'](_0x57cc51=>_0x57cc51['agent']===_0xd46b70['agent']);if(_0x34a4c7){if(_0x34a4c7['dates']['push'](_0xd46b70['date']),Ws(_0x2d61cb)>_0x531272){_0x34a4c7['dates']['pop']();break;}}else{if(_0x2d61cb['push']({'agent':_0xd46b70['agent'],'dates':[_0xd46b70['date']]}),Ws(_0x2d61cb)>_0x531272){_0x2d61cb['pop']();break;}}_0x4135ad=_0x4135ad['slice'](0x1);}return{'heartbeatsToSend':_0x2d61cb,'unsentEntries':_0x4135ad};}class Dl{constructor(_0x32f504){this['app']=_0x32f504,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2370c3=await Al(this['app']);return _0x2370c3!=null&&_0x2370c3['heartbeats']?_0x2370c3:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0xbfed1d){if(await this['_canUseIndexedDBPromise']){const _0x172096=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0xbfed1d['lastSentHeartbeatDate']??_0x172096['lastSentHeartbeatDate'],'heartbeats':_0xbfed1d['heartbeats']});}else return;}async['add'](_0x9bf960){if(await this['_canUseIndexedDBPromise']){const _0x404045=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x9bf960['lastSentHeartbeatDate']??_0x404045['lastSentHeartbeatDate'],'heartbeats':[..._0x404045['heartbeats'],..._0x9bf960['heartbeats']]});}else return;}}function Ws(_0x275463){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x275463}))['length'];}function Ml(_0x1b1e80){if(_0x1b1e80['length']===0x0)return-0x1;let _0x590b18=0x0,_0x11d712=_0x1b1e80[0x0]['date'];for(let _0x438640=0x1;_0x438640<_0x1b1e80['length'];_0x438640++)_0x1b1e80[_0x438640]['date']<_0x11d712&&(_0x11d712=_0x1b1e80[_0x438640]['date'],_0x590b18=_0x438640);return _0x590b18;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1c858d){st(new Fe('platform-logger',_0x55ecd=>new jc(_0x55ecd),'PRIVATE')),st(new Fe('heartbeat',_0x4450cb=>new Nl(_0x4450cb),'PRIVATE')),ye(mi,Ls,_0x1c858d),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x5b6bdb){no=_0x5b6bdb;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x6b8b91){this['domStorage_']=_0x6b8b91,this['prefix_']='firebase:';}['set'](_0x3fb9dc,_0xb4cc94){_0xb4cc94==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3fb9dc)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3fb9dc),O(_0xb4cc94));}['get'](_0x10b1a6){const _0xaf280c=this['domStorage_']['getItem'](this['prefixedName_'](_0x10b1a6));return _0xaf280c==null?null:Nt(_0xaf280c);}['remove'](_0x501970){this['domStorage_']['removeItem'](this['prefixedName_'](_0x501970));}['prefixedName_'](_0x3f23ac){return this['prefix_']+_0x3f23ac;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x3b58cc,_0x16be36){_0x16be36==null?delete this['cache_'][_0x3b58cc]:this['cache_'][_0x3b58cc]=_0x16be36;}['get'](_0x55164a){return Q(this['cache_'],_0x55164a)?this['cache_'][_0x55164a]:null;}['remove'](_0x1c33b2){delete this['cache_'][_0x1c33b2];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x1583f9){try{if(typeof window<'u'&&typeof window[_0x1583f9]<'u'){const _0x15b554=window[_0x1583f9];return _0x15b554['setItem']('firebase:sentinel','cache'),_0x15b554['removeItem']('firebase:sentinel'),new Wl(_0x15b554);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x1fe7e6=0x1;return function(){return _0x1fe7e6++;};}()),ro=function(_0x218058){const _0x50a0fc=Rc(_0x218058),_0x5abb6f=new Cc();_0x5abb6f['update'](_0x50a0fc);const _0x17670a=_0x5abb6f['digest']();return Fi['encodeByteArray'](_0x17670a);},zt=function(..._0x5ba5a2){let _0x175587='';for(let _0x1e6527=0x0;_0x1e6527<_0x5ba5a2['length'];_0x1e6527++){const _0x17cc1a=_0x5ba5a2[_0x1e6527];Array['isArray'](_0x17cc1a)||_0x17cc1a&&typeof _0x17cc1a=='object'&&typeof _0x17cc1a['length']=='number'?_0x175587+=zt['apply'](null,_0x17cc1a):typeof _0x17cc1a=='object'?_0x175587+=O(_0x17cc1a):_0x175587+=_0x17cc1a,_0x175587+='\x20';}return _0x175587;};let St=null,$s=!0x0;const Hl=function(_0x1c0bbd,_0x304528){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x4830a0){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x4daf9c=zt['apply'](null,_0x4830a0);St(_0x4daf9c);}},jt=function(_0x2526d4){return function(..._0x5231c9){L(_0x2526d4,..._0x5231c9);};},Ii=function(..._0x1c72f3){const _0x21b7a2='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x1c72f3);Ze['error'](_0x21b7a2);},ae=function(..._0x229531){const _0x577bde='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x229531);throw Ze['error'](_0x577bde),new Error(_0x577bde);},U=function(..._0x168aaf){const _0x30e5dd='FIREBASE\x20WARNING:\x20'+zt(..._0x168aaf);Ze['warn'](_0x30e5dd);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x517918){return typeof _0x517918=='number'&&(_0x517918!==_0x517918||_0x517918===Number['POSITIVE_INFINITY']||_0x517918===Number['NEGATIVE_INFINITY']);},Gl=function(_0x55892b){if(document['readyState']==='complete')_0x55892b();else{let _0x3c033d=!0x1;const _0x4a3862=function(){if(!document['body']){setTimeout(_0x4a3862,Math['floor'](0xa));return;}_0x3c033d||(_0x3c033d=!0x0,_0x55892b());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4a3862,!0x1),window['addEventListener']('load',_0x4a3862,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4a3862();}),window['attachEvent']('onload',_0x4a3862));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x52fbfe,_0x337462){if(_0x52fbfe===_0x337462)return 0x0;if(_0x52fbfe===We||_0x337462===we)return-0x1;if(_0x337462===We||_0x52fbfe===we)return 0x1;{const _0x50854c=Gs(_0x52fbfe),_0x365b71=Gs(_0x337462);return _0x50854c!==null?_0x365b71!==null?_0x50854c-_0x365b71===0x0?_0x52fbfe['length']-_0x337462['length']:_0x50854c-_0x365b71:-0x1:_0x365b71!==null?0x1:_0x52fbfe<_0x337462?-0x1:0x1;}},ql=function(_0x34f98c,_0x38a1b2){return _0x34f98c===_0x38a1b2?0x0:_0x34f98c<_0x38a1b2?-0x1:0x1;},vt=function(_0x233518,_0x170dda){if(_0x170dda&&_0x233518 in _0x170dda)return _0x170dda[_0x233518];throw new Error('Missing\x20required\x20key\x20('+_0x233518+')\x20in\x20object:\x20'+O(_0x170dda));},$i=function(_0x3ce27d){if(typeof _0x3ce27d!='object'||_0x3ce27d===null)return O(_0x3ce27d);const _0x1829e5=[];for(const _0x40a35a in _0x3ce27d)_0x1829e5['push'](_0x40a35a);_0x1829e5['sort']();let _0xf4f2f9='{';for(let _0x4e3814=0x0;_0x4e3814<_0x1829e5['length'];_0x4e3814++)_0x4e3814!==0x0&&(_0xf4f2f9+=','),_0xf4f2f9+=O(_0x1829e5[_0x4e3814]),_0xf4f2f9+=':',_0xf4f2f9+=$i(_0x3ce27d[_0x1829e5[_0x4e3814]]);return _0xf4f2f9+='}',_0xf4f2f9;},oo=function(_0x410499,_0x1dc6e6){const _0x357831=_0x410499['length'];if(_0x357831<=_0x1dc6e6)return[_0x410499];const _0x1358e5=[];for(let _0x21369b=0x0;_0x21369b<_0x357831;_0x21369b+=_0x1dc6e6)_0x21369b+_0x1dc6e6>_0x357831?_0x1358e5['push'](_0x410499['substring'](_0x21369b,_0x357831)):_0x1358e5['push'](_0x410499['substring'](_0x21369b,_0x21369b+_0x1dc6e6));return _0x1358e5;};function x(_0x53151d,_0x10531d){for(const _0x2a7b3d in _0x53151d)_0x53151d['hasOwnProperty'](_0x2a7b3d)&&_0x10531d(_0x2a7b3d,_0x53151d[_0x2a7b3d]);}const ao=function(_0x35710f){f(!xn(_0x35710f),'Invalid\x20JSON\x20number');const _0x33b7b9=0xb,_0x1444ad=0x34,_0x2d9672=(0x1<<_0x33b7b9-0x1)-0x1;let _0x4e252e,_0x5a0371,_0x5e58a4,_0x33bfd9,_0x372015;_0x35710f===0x0?(_0x5a0371=0x0,_0x5e58a4=0x0,_0x4e252e=0x1/_0x35710f===-0x1/0x0?0x1:0x0):(_0x4e252e=_0x35710f<0x0,_0x35710f=Math['abs'](_0x35710f),_0x35710f>=Math['pow'](0x2,0x1-_0x2d9672)?(_0x33bfd9=Math['min'](Math['floor'](Math['log'](_0x35710f)/Math['LN2']),_0x2d9672),_0x5a0371=_0x33bfd9+_0x2d9672,_0x5e58a4=Math['round'](_0x35710f*Math['pow'](0x2,_0x1444ad-_0x33bfd9)-Math['pow'](0x2,_0x1444ad))):(_0x5a0371=0x0,_0x5e58a4=Math['round'](_0x35710f/Math['pow'](0x2,0x1-_0x2d9672-_0x1444ad))));const _0x5f5b99=[];for(_0x372015=_0x1444ad;_0x372015;_0x372015-=0x1)_0x5f5b99['push'](_0x5e58a4%0x2?0x1:0x0),_0x5e58a4=Math['floor'](_0x5e58a4/0x2);for(_0x372015=_0x33b7b9;_0x372015;_0x372015-=0x1)_0x5f5b99['push'](_0x5a0371%0x2?0x1:0x0),_0x5a0371=Math['floor'](_0x5a0371/0x2);_0x5f5b99['push'](_0x4e252e?0x1:0x0),_0x5f5b99['reverse']();const _0xfa488f=_0x5f5b99['join']('');let _0x5b1087='';for(_0x372015=0x0;_0x372015<0x40;_0x372015+=0x8){let _0x1c72b3=parseInt(_0xfa488f['substr'](_0x372015,0x8),0x2)['toString'](0x10);_0x1c72b3['length']===0x1&&(_0x1c72b3='0'+_0x1c72b3),_0x5b1087=_0x5b1087+_0x1c72b3;}return _0x5b1087['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x57540c,_0x5343f4){let _0x404deb='Unknown\x20Error';_0x57540c==='too_big'?_0x404deb='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x57540c==='permission_denied'?_0x404deb='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x57540c==='unavailable'&&(_0x404deb='The\x20service\x20is\x20unavailable');const _0x125827=new Error(_0x57540c+'\x20at\x20'+_0x5343f4['_path']['toString']()+':\x20'+_0x404deb);return _0x125827['code']=_0x57540c['toUpperCase'](),_0x125827;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x17281d){if(Yl['test'](_0x17281d)){const _0xde6ab2=Number(_0x17281d);if(_0xde6ab2>=Ql&&_0xde6ab2<=Jl)return _0xde6ab2;}return null;},ft=function(_0x1e593f){try{_0x1e593f();}catch(_0x225508){setTimeout(()=>{const _0x5e048e=_0x225508['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5e048e),_0x225508;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x57d10b,_0x1186c6){const _0x6af12a=setTimeout(_0x57d10b,_0x1186c6);return typeof _0x6af12a=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x6af12a):typeof _0x6af12a=='object'&&_0x6af12a['unref']&&_0x6af12a['unref'](),_0x6af12a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x558add,_0x26099f){this['appCheckProvider']=_0x26099f,this['appName']=_0x558add['name'],$(_0x558add)&&_0x558add['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x558add['settings']['appCheckToken']),this['appCheck']=_0x26099f==null?void 0x0:_0x26099f['getImmediate']({'optional':!0x0}),this['appCheck']||_0x26099f==null||_0x26099f['get']()['then'](_0x3897c6=>this['appCheck']=_0x3897c6);}['getToken'](_0x20de7e){if(this['serverAppAppCheckToken']){if(_0x20de7e)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x20de7e):new Promise((_0x1c34fe,_0x1d68fd)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x20de7e)['then'](_0x1c34fe,_0x1d68fd):_0x1c34fe(null);},0x0);});}['addTokenChangeListener'](_0xcfb715){var _0xfdfbab;(_0xfdfbab=this['appCheckProvider'])==null||_0xfdfbab['get']()['then'](_0x395e22=>_0x395e22['addTokenListener'](_0xcfb715));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x5d94b7,_0x44d704,_0xdbab21){this['appName_']=_0x5d94b7,this['firebaseOptions_']=_0x44d704,this['authProvider_']=_0xdbab21,this['auth_']=null,this['auth_']=_0xdbab21['getImmediate']({'optional':!0x0}),this['auth_']||_0xdbab21['onInit'](_0x4ae4b2=>this['auth_']=_0x4ae4b2);}['getToken'](_0x1ebdf7){return this['auth_']?this['auth_']['getToken'](_0x1ebdf7)['catch'](_0x39950f=>_0x39950f&&_0x39950f['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x39950f)):new Promise((_0x1fd857,_0x1673c6)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x1ebdf7)['then'](_0x1fd857,_0x1673c6):_0x1fd857(null);},0x0);});}['addTokenChangeListener'](_0x26a803){this['auth_']?this['auth_']['addAuthTokenListener'](_0x26a803):this['authProvider_']['get']()['then'](_0x37365d=>_0x37365d['addAuthTokenListener'](_0x26a803));}['removeTokenChangeListener'](_0x21dc88){this['authProvider_']['get']()['then'](_0x2dc34b=>_0x2dc34b['removeAuthTokenListener'](_0x21dc88));}['notifyForInvalidToken'](){let _0x4446fa='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4446fa+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4446fa+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4446fa+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4446fa);}}class an{constructor(_0x227aa8){this['accessToken']=_0x227aa8;}['getToken'](_0x5f56b4){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4ace2f){_0x4ace2f(this['accessToken']);}['removeTokenChangeListener'](_0xdd86bf){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x518493,_0x5746ca,_0x1cc694,_0x461ecf,_0x32e237=!0x1,_0x1d9d1d='',_0x31ee69=!0x1,_0x2b3308=!0x1,_0x5a6539=null){this['secure']=_0x5746ca,this['namespace']=_0x1cc694,this['webSocketOnly']=_0x461ecf,this['nodeAdmin']=_0x32e237,this['persistenceKey']=_0x1d9d1d,this['includeNamespaceInQueryParams']=_0x31ee69,this['isUsingEmulator']=_0x2b3308,this['emulatorOptions']=_0x5a6539,this['_host']=_0x518493['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x518493)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x52f0df){_0x52f0df!==this['internalHost']&&(this['internalHost']=_0x52f0df,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4774c5=this['toURLString']();return this['persistenceKey']&&(_0x4774c5+='<'+this['persistenceKey']+'>'),_0x4774c5;}['toURLString'](){const _0x134978=this['secure']?'https://':'http://',_0x39a4e6=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x134978+this['host']+'/'+_0x39a4e6;}}function th(_0x46e130){return _0x46e130['host']!==_0x46e130['internalHost']||_0x46e130['isCustomHost']()||_0x46e130['includeNamespaceInQueryParams'];}function vo(_0x488590,_0x21d9ee,_0x2abe0c){f(typeof _0x21d9ee=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2abe0c=='object','typeof\x20params\x20must\x20==\x20object');let _0x532688;if(_0x21d9ee===go)_0x532688=(_0x488590['secure']?'wss://':'ws://')+_0x488590['internalHost']+'/.ws?';else{if(_0x21d9ee===mo)_0x532688=(_0x488590['secure']?'https://':'http://')+_0x488590['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x21d9ee);}th(_0x488590)&&(_0x2abe0c['ns']=_0x488590['namespace']);const _0x319cb6=[];return x(_0x2abe0c,(_0x2e2437,_0x3aa11a)=>{_0x319cb6['push'](_0x2e2437+'='+_0x3aa11a);}),_0x532688+_0x319cb6['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0xd96b56,_0x502e8b=0x1){Q(this['counters_'],_0xd96b56)||(this['counters_'][_0xd96b56]=0x0),this['counters_'][_0xd96b56]+=_0x502e8b;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x221a4a){const _0x272a07=_0x221a4a['toString']();return oi[_0x272a07]||(oi[_0x272a07]=new nh()),oi[_0x272a07];}function ih(_0x5b95be,_0x258948){const _0x1211c5=_0x5b95be['toString']();return ai[_0x1211c5]||(ai[_0x1211c5]=_0x258948()),ai[_0x1211c5];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0xf5b0e2){this['onMessage_']=_0xf5b0e2,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5a005f,_0x5cf4bf){this['closeAfterResponse']=_0x5a005f,this['onClose']=_0x5cf4bf,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xf64171,_0x40df5f){for(this['pendingResponses'][_0xf64171]=_0x40df5f;this['pendingResponses'][this['currentResponseNum']];){const _0x153360=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x34e1a6=0x0;_0x34e1a6<_0x153360['length'];++_0x34e1a6)_0x153360[_0x34e1a6]&&ft(()=>{this['onMessage_'](_0x153360[_0x34e1a6]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x2f3c1a,_0x1f0b99,_0x46db48,_0x10ef20,_0x348161,_0x134148,_0x11e399){this['connId']=_0x2f3c1a,this['repoInfo']=_0x1f0b99,this['applicationId']=_0x46db48,this['appCheckToken']=_0x10ef20,this['authToken']=_0x348161,this['transportSessionId']=_0x134148,this['lastSessionId']=_0x11e399,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x2f3c1a),this['stats_']=qi(_0x1f0b99),this['urlFn']=_0x24e4cf=>(this['appCheckToken']&&(_0x24e4cf[wi]=this['appCheckToken']),vo(_0x1f0b99,mo,_0x24e4cf));}['open'](_0x20dd58,_0x4e3ac2){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x4e3ac2,this['myPacketOrderer']=new sh(_0x20dd58),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x552ade)=>{const [_0x3cc58a,_0x4c42aa,_0xa7d404,_0x5d3730,_0x516a66]=_0x552ade;if(this['incrementIncomingBytes_'](_0x552ade),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3cc58a===qs)this['id']=_0x4c42aa,this['password']=_0xa7d404;else{if(_0x3cc58a===rh)_0x4c42aa?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x4c42aa,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3cc58a);}}},(..._0x31e94d)=>{const [_0x4fccb2,_0x52eecc]=_0x31e94d;this['incrementIncomingBytes_'](_0x31e94d),this['myPacketOrderer']['handleResponse'](_0x4fccb2,_0x52eecc);},()=>{this['onClosed_']();},this['urlFn']);const _0x578439={};_0x578439[qs]='t',_0x578439[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x578439[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x578439[co]=Gi,this['transportSessionId']&&(_0x578439[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x578439[po]=this['lastSessionId']),this['applicationId']&&(_0x578439[_o]=this['applicationId']),this['appCheckToken']&&(_0x578439[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x578439[ho]=uo);const _0x2c8911=this['urlFn'](_0x578439);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x2c8911),this['scriptTagHolder']['addTag'](_0x2c8911,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x386d45){const _0x3a1fde=O(_0x386d45);this['bytesSent']+=_0x3a1fde['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3a1fde['length']);const _0x1f94df=$r(_0x3a1fde),_0x572180=oo(_0x1f94df,fh);for(let _0x13cfce=0x0;_0x13cfce<_0x572180['length'];_0x13cfce++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x572180['length'],_0x572180[_0x13cfce]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xe33eaf,_0x469858){this['myDisconnFrame']=document['createElement']('iframe');const _0x553845={};_0x553845[dh]='t',_0x553845[Eo]=_0xe33eaf,_0x553845[Io]=_0x469858,this['myDisconnFrame']['src']=this['urlFn'](_0x553845),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x17ecdb){const _0x2e1e33=O(_0x17ecdb)['length'];this['bytesReceived']+=_0x2e1e33,this['stats_']['incrementCounter']('bytes_received',_0x2e1e33);}}class zi{constructor(_0x2cb04b,_0xe8c0c,_0x4dd2ea,_0x591c1e){this['onDisconnect']=_0x4dd2ea,this['urlFn']=_0x591c1e,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x2cb04b,window[ah+this['uniqueCallbackIdentifier']]=_0xe8c0c,this['myIFrame']=zi['createIFrame_']();let _0x39bc1f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x39bc1f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x29f671='<html><body>'+_0x39bc1f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x29f671),this['myIFrame']['doc']['close']();}catch(_0x1b704f){L('frame\x20writing\x20exception'),_0x1b704f['stack']&&L(_0x1b704f['stack']),L(_0x1b704f);}}}static['createIFrame_'](){const _0x1ddef3=document['createElement']('iframe');if(_0x1ddef3['style']['display']='none',document['body']){document['body']['appendChild'](_0x1ddef3);try{_0x1ddef3['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x389fd4=document['domain'];_0x1ddef3['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x389fd4+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1ddef3['contentDocument']?_0x1ddef3['doc']=_0x1ddef3['contentDocument']:_0x1ddef3['contentWindow']?_0x1ddef3['doc']=_0x1ddef3['contentWindow']['document']:_0x1ddef3['document']&&(_0x1ddef3['doc']=_0x1ddef3['document']),_0x1ddef3;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x4ee0a4=this['onDisconnect'];_0x4ee0a4&&(this['onDisconnect']=null,_0x4ee0a4());}['startLongPoll'](_0x247075,_0x1ffdfc){for(this['myID']=_0x247075,this['myPW']=_0x1ffdfc,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x204afd={};_0x204afd[Eo]=this['myID'],_0x204afd[Io]=this['myPW'],_0x204afd[wo]=this['currentSerial'];let _0x557c25=this['urlFn'](_0x204afd),_0x5b4235='',_0x45848b=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x5b4235['length']<=Co;){const _0x4695b8=this['pendingSegs']['shift']();_0x5b4235=_0x5b4235+'&'+lh+_0x45848b+'='+_0x4695b8['seg']+'&'+hh+_0x45848b+'='+_0x4695b8['ts']+'&'+uh+_0x45848b+'='+_0x4695b8['d'],_0x45848b++;}return _0x557c25=_0x557c25+_0x5b4235,this['addLongPollTag_'](_0x557c25,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x28f67a,_0x19f6b5,_0x3f344f){this['pendingSegs']['push']({'seg':_0x28f67a,'ts':_0x19f6b5,'d':_0x3f344f}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5467b5,_0x3dd558){this['outstandingRequests']['add'](_0x3dd558);const _0x16cd2d=()=>{this['outstandingRequests']['delete'](_0x3dd558),this['newRequest_']();},_0x4dcd02=setTimeout(_0x16cd2d,Math['floor'](ph)),_0x2cc5a3=()=>{clearTimeout(_0x4dcd02),_0x16cd2d();};this['addTag'](_0x5467b5,_0x2cc5a3);}['addTag'](_0x22fce4,_0xcb473b){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5a6240=this['myIFrame']['doc']['createElement']('script');_0x5a6240['type']='text/javascript',_0x5a6240['async']=!0x0,_0x5a6240['src']=_0x22fce4,_0x5a6240['onload']=_0x5a6240['onreadystatechange']=function(){const _0x429552=_0x5a6240['readyState'];(!_0x429552||_0x429552==='loaded'||_0x429552==='complete')&&(_0x5a6240['onload']=_0x5a6240['onreadystatechange']=null,_0x5a6240['parentNode']&&_0x5a6240['parentNode']['removeChild'](_0x5a6240),_0xcb473b());},_0x5a6240['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x22fce4),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5a6240);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x53ffcf,_0x4cc581,_0x4733cf,_0x2a5a17,_0xba605b,_0x23deb9,_0x3abf83){this['connId']=_0x53ffcf,this['applicationId']=_0x4733cf,this['appCheckToken']=_0x2a5a17,this['authToken']=_0xba605b,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x4cc581),this['connURL']=q['connectionURL_'](_0x4cc581,_0x23deb9,_0x3abf83,_0x2a5a17,_0x4733cf),this['nodeAdmin']=_0x4cc581['nodeAdmin'];}static['connectionURL_'](_0x46f245,_0x56936a,_0x533683,_0x1ab14e,_0x5004da){const _0x4a4632={};return _0x4a4632[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4a4632[ho]=uo),_0x56936a&&(_0x4a4632[lo]=_0x56936a),_0x533683&&(_0x4a4632[po]=_0x533683),_0x1ab14e&&(_0x4a4632[wi]=_0x1ab14e),_0x5004da&&(_0x4a4632[_o]=_0x5004da),vo(_0x46f245,go,_0x4a4632);}['open'](_0x3ae40c,_0x56d7c0){this['onDisconnect']=_0x56d7c0,this['onMessage']=_0x3ae40c,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x318229;_c(),this['mySock']=new gn(this['connURL'],[],_0x318229);}catch(_0x53bae6){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x148122=_0x53bae6['message']||_0x53bae6['data'];_0x148122&&this['log_'](_0x148122),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2b6732=>{this['handleIncomingFrame'](_0x2b6732);},this['mySock']['onerror']=_0x58bbf2=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xa31a26=_0x58bbf2['message']||_0x58bbf2['data'];_0xa31a26&&this['log_'](_0xa31a26),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x31f52a=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x25123c=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x251590=navigator['userAgent']['match'](_0x25123c);_0x251590&&_0x251590['length']>0x1&&parseFloat(_0x251590[0x1])<4.4&&(_0x31f52a=!0x0);}return!_0x31f52a&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x2074bc){if(this['frames']['push'](_0x2074bc),this['frames']['length']===this['totalFrames']){const _0x3d2e25=this['frames']['join']('');this['frames']=null;const _0x32f421=Nt(_0x3d2e25);this['onMessage'](_0x32f421);}}['handleNewFrameCount_'](_0x321788){this['totalFrames']=_0x321788,this['frames']=[];}['extractFrameCount_'](_0x35bd7e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x35bd7e['length']<=0x6){const _0x12fdef=Number(_0x35bd7e);if(!isNaN(_0x12fdef))return this['handleNewFrameCount_'](_0x12fdef),null;}return this['handleNewFrameCount_'](0x1),_0x35bd7e;}['handleIncomingFrame'](_0x3255e0){if(this['mySock']===null)return;const _0x15b467=_0x3255e0['data'];if(this['bytesReceived']+=_0x15b467['length'],this['stats_']['incrementCounter']('bytes_received',_0x15b467['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x15b467);else{const _0x1987f5=this['extractFrameCount_'](_0x15b467);_0x1987f5!==null&&this['appendFrame_'](_0x1987f5);}}['send'](_0x109f57){this['resetKeepAlive']();const _0x155a2f=O(_0x109f57);this['bytesSent']+=_0x155a2f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x155a2f['length']);const _0xc33523=oo(_0x155a2f,gh);_0xc33523['length']>0x1&&this['sendString_'](String(_0xc33523['length']));for(let _0x30c47a=0x0;_0x30c47a<_0xc33523['length'];_0x30c47a++)this['sendString_'](_0xc33523[_0x30c47a]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x1feec7){try{this['mySock']['send'](_0x1feec7);}catch(_0x3c0ed9){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3c0ed9['message']||_0x3c0ed9['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x3fa85c){this['initTransports_'](_0x3fa85c);}['initTransports_'](_0x170aff){const _0x53e26d=q&&q['isAvailable']();let _0x105851=_0x53e26d&&!q['previouslyFailed']();if(_0x170aff['webSocketOnly']&&(_0x53e26d||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x105851=!0x0),_0x105851)this['transports_']=[q];else{const _0x2464bd=this['transports_']=[];for(const _0x408312 of Dt['ALL_TRANSPORTS'])_0x408312&&_0x408312['isAvailable']()&&_0x2464bd['push'](_0x408312);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x3dd71d,_0x5c2511,_0x57248f,_0x10739c,_0x14dc08,_0x2effef,_0x3920be,_0x9b20d4,_0x24718a,_0x293a5d){this['id']=_0x3dd71d,this['repoInfo_']=_0x5c2511,this['applicationId_']=_0x57248f,this['appCheckToken_']=_0x10739c,this['authToken_']=_0x14dc08,this['onMessage_']=_0x2effef,this['onReady_']=_0x3920be,this['onDisconnect_']=_0x9b20d4,this['onKill_']=_0x24718a,this['lastSessionId']=_0x293a5d,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x5c2511),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1cd462=this['transportManager_']['initialTransport']();this['conn_']=new _0x1cd462(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1cd462['responsesRequiredToBeHealthy']||0x0;const _0x29f173=this['connReceiver_'](this['conn_']),_0x2748ed=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x29f173,_0x2748ed);},Math['floor'](0x0));const _0x5a4bff=_0x1cd462['healthyTimeout']||0x0;_0x5a4bff>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5a4bff)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5d39ac){return _0x45b0aa=>{_0x5d39ac===this['conn_']?this['onConnectionLost_'](_0x45b0aa):_0x5d39ac===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xb4b2d8){return _0x12430b=>{this['state_']!==0x2&&(_0xb4b2d8===this['rx_']?this['onPrimaryMessageReceived_'](_0x12430b):_0xb4b2d8===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x12430b):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2da5d3){const _0x103eac={'t':'d','d':_0x2da5d3};this['sendData_'](_0x103eac);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x6ef86c){if(ci in _0x6ef86c){const _0x2c52bf=_0x6ef86c[ci];_0x2c52bf===Ys?this['upgradeIfSecondaryHealthy_']():_0x2c52bf===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x2c52bf===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x41039b){const _0x58ddec=vt('t',_0x41039b),_0x1b622d=vt('d',_0x41039b);if(_0x58ddec==='c')this['onSecondaryControl_'](_0x1b622d);else{if(_0x58ddec==='d')this['pendingDataMessages']['push'](_0x1b622d);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x58ddec);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x530c3f){const _0x51002a=vt('t',_0x530c3f),_0xbeb793=vt('d',_0x530c3f);_0x51002a==='c'?this['onControl_'](_0xbeb793):_0x51002a==='d'&&this['onDataMessage_'](_0xbeb793);}['onDataMessage_'](_0x281bd7){this['onPrimaryResponse_'](),this['onMessage_'](_0x281bd7);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3de1cc){const _0x8de7fc=vt(ci,_0x3de1cc);if(zs in _0x3de1cc){const _0x574a60=_0x3de1cc[zs];if(_0x8de7fc===Th){const _0x5bef0f={..._0x574a60};this['repoInfo_']['isUsingEmulator']&&(_0x5bef0f['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x5bef0f);}else{if(_0x8de7fc===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x5c6f36=0x0;_0x5c6f36<this['pendingDataMessages']['length'];++_0x5c6f36)this['onDataMessage_'](this['pendingDataMessages'][_0x5c6f36]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x8de7fc===wh?this['onConnectionShutdown_'](_0x574a60):_0x8de7fc===js?this['onReset_'](_0x574a60):_0x8de7fc===Ch?Ii('Server\x20Error:\x20'+_0x574a60):_0x8de7fc===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x8de7fc);}}}['onHandshake_'](_0x2c57dd){const _0x16ea7d=_0x2c57dd['ts'],_0x439bc5=_0x2c57dd['v'],_0x194b06=_0x2c57dd['h'];this['sessionId']=_0x2c57dd['s'],this['repoInfo_']['host']=_0x194b06,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x16ea7d),Gi!==_0x439bc5&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x58094e=this['transportManager_']['upgradeTransport']();_0x58094e&&this['startUpgrade_'](_0x58094e);}['startUpgrade_'](_0x45044c){this['secondaryConn_']=new _0x45044c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x45044c['responsesRequiredToBeHealthy']||0x0;const _0x6e710b=this['connReceiver_'](this['secondaryConn_']),_0x1be845=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x6e710b,_0x1be845),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x250bf2){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x250bf2),this['repoInfo_']['host']=_0x250bf2,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x44ee53,_0x3073f8){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x44ee53,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3073f8,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3e6389=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3e6389||this['rx_']===_0x3e6389)&&this['close']();}['onConnectionLost_'](_0x490f56){this['conn_']=null,!_0x490f56&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0xc9c4e0){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0xc9c4e0),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x76e6d1){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x76e6d1);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3300f4,_0x4e6f2f,_0x1cd3f2,_0xeb052f){}['merge'](_0x4709b0,_0x55c961,_0x2e6f93,_0x27c8bb){}['refreshAuthToken'](_0x58ba91){}['refreshAppCheckToken'](_0xe8f169){}['onDisconnectPut'](_0x52f558,_0x338615,_0x564312){}['onDisconnectMerge'](_0x588c08,_0x5744a8,_0x9d59f0){}['onDisconnectCancel'](_0x17c6b1,_0x3e6f27){}['reportStats'](_0x397c14){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0xad4a){this['allowedEvents_']=_0xad4a,this['listeners_']={},f(Array['isArray'](_0xad4a)&&_0xad4a['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5aab87,..._0x5e56ff){if(Array['isArray'](this['listeners_'][_0x5aab87])){const _0x26ad44=[...this['listeners_'][_0x5aab87]];for(let _0x3adb18=0x0;_0x3adb18<_0x26ad44['length'];_0x3adb18++)_0x26ad44[_0x3adb18]['callback']['apply'](_0x26ad44[_0x3adb18]['context'],_0x5e56ff);}}['on'](_0x275f1f,_0x5ec5a9,_0x18e3ac){this['validateEventType_'](_0x275f1f),this['listeners_'][_0x275f1f]=this['listeners_'][_0x275f1f]||[],this['listeners_'][_0x275f1f]['push']({'callback':_0x5ec5a9,'context':_0x18e3ac});const _0x17c188=this['getInitialEvent'](_0x275f1f);_0x17c188&&_0x5ec5a9['apply'](_0x18e3ac,_0x17c188);}['off'](_0x4b1eab,_0x5a1653,_0x37b11a){this['validateEventType_'](_0x4b1eab);const _0x112f08=this['listeners_'][_0x4b1eab]||[];for(let _0xb574ce=0x0;_0xb574ce<_0x112f08['length'];_0xb574ce++)if(_0x112f08[_0xb574ce]['callback']===_0x5a1653&&(!_0x37b11a||_0x37b11a===_0x112f08[_0xb574ce]['context'])){_0x112f08['splice'](_0xb574ce,0x1);return;}}['validateEventType_'](_0x54478b){f(this['allowedEvents_']['find'](_0x13ea46=>_0x13ea46===_0x54478b),'Unknown\x20event:\x20'+_0x54478b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1870a0){return f(_0x1870a0==='online','Unknown\x20event\x20type:\x20'+_0x1870a0),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x5e7892,_0x16a526){if(_0x16a526===void 0x0){this['pieces_']=_0x5e7892['split']('/');let _0x520d7c=0x0;for(let _0x4ed0d0=0x0;_0x4ed0d0<this['pieces_']['length'];_0x4ed0d0++)this['pieces_'][_0x4ed0d0]['length']>0x0&&(this['pieces_'][_0x520d7c]=this['pieces_'][_0x4ed0d0],_0x520d7c++);this['pieces_']['length']=_0x520d7c,this['pieceNum_']=0x0;}else this['pieces_']=_0x5e7892,this['pieceNum_']=_0x16a526;}['toString'](){let _0x3143f8='';for(let _0x49b552=this['pieceNum_'];_0x49b552<this['pieces_']['length'];_0x49b552++)this['pieces_'][_0x49b552]!==''&&(_0x3143f8+='/'+this['pieces_'][_0x49b552]);return _0x3143f8||'/';}}function w(){return new C('');}function y(_0x59aab0){return _0x59aab0['pieceNum_']>=_0x59aab0['pieces_']['length']?null:_0x59aab0['pieces_'][_0x59aab0['pieceNum_']];}function Ce(_0x5bd077){return _0x5bd077['pieces_']['length']-_0x5bd077['pieceNum_'];}function S(_0x366b5a){let _0x133d19=_0x366b5a['pieceNum_'];return _0x133d19<_0x366b5a['pieces_']['length']&&_0x133d19++,new C(_0x366b5a['pieces_'],_0x133d19);}function ji(_0x485ea8){return _0x485ea8['pieceNum_']<_0x485ea8['pieces_']['length']?_0x485ea8['pieces_'][_0x485ea8['pieces_']['length']-0x1]:null;}function bh(_0xd517fa){let _0x29d217='';for(let _0x3d1f85=_0xd517fa['pieceNum_'];_0x3d1f85<_0xd517fa['pieces_']['length'];_0x3d1f85++)_0xd517fa['pieces_'][_0x3d1f85]!==''&&(_0x29d217+='/'+encodeURIComponent(String(_0xd517fa['pieces_'][_0x3d1f85])));return _0x29d217||'/';}function Mt(_0x4f883e,_0x319317=0x0){return _0x4f883e['pieces_']['slice'](_0x4f883e['pieceNum_']+_0x319317);}function Ro(_0x4efa38){if(_0x4efa38['pieceNum_']>=_0x4efa38['pieces_']['length'])return null;const _0x3ead38=[];for(let _0x4b4306=_0x4efa38['pieceNum_'];_0x4b4306<_0x4efa38['pieces_']['length']-0x1;_0x4b4306++)_0x3ead38['push'](_0x4efa38['pieces_'][_0x4b4306]);return new C(_0x3ead38,0x0);}function k(_0x4cd52b,_0x353ef9){const _0x284209=[];for(let _0x514068=_0x4cd52b['pieceNum_'];_0x514068<_0x4cd52b['pieces_']['length'];_0x514068++)_0x284209['push'](_0x4cd52b['pieces_'][_0x514068]);if(_0x353ef9 instanceof C){for(let _0x1b39c4=_0x353ef9['pieceNum_'];_0x1b39c4<_0x353ef9['pieces_']['length'];_0x1b39c4++)_0x284209['push'](_0x353ef9['pieces_'][_0x1b39c4]);}else{const _0x2a8ea2=_0x353ef9['split']('/');for(let _0x23cd0a=0x0;_0x23cd0a<_0x2a8ea2['length'];_0x23cd0a++)_0x2a8ea2[_0x23cd0a]['length']>0x0&&_0x284209['push'](_0x2a8ea2[_0x23cd0a]);}return new C(_0x284209,0x0);}function v(_0x1f3bea){return _0x1f3bea['pieceNum_']>=_0x1f3bea['pieces_']['length'];}function F(_0x379459,_0x4edbeb){const _0x18336d=y(_0x379459),_0x2121f2=y(_0x4edbeb);if(_0x18336d===null)return _0x4edbeb;if(_0x18336d===_0x2121f2)return F(S(_0x379459),S(_0x4edbeb));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x4edbeb+')\x20is\x20not\x20within\x20outerPath\x20('+_0x379459+')');}function Rh(_0x5156c6,_0x5bc8e7){const _0x45d292=Mt(_0x5156c6,0x0),_0x3432f4=Mt(_0x5bc8e7,0x0);for(let _0x3ee301=0x0;_0x3ee301<_0x45d292['length']&&_0x3ee301<_0x3432f4['length'];_0x3ee301++){const _0x3057b5=qe(_0x45d292[_0x3ee301],_0x3432f4[_0x3ee301]);if(_0x3057b5!==0x0)return _0x3057b5;}return _0x45d292['length']===_0x3432f4['length']?0x0:_0x45d292['length']<_0x3432f4['length']?-0x1:0x1;}function Ki(_0x472185,_0x57e9ec){if(Ce(_0x472185)!==Ce(_0x57e9ec))return!0x1;for(let _0x53b7f5=_0x472185['pieceNum_'],_0x340a5f=_0x57e9ec['pieceNum_'];_0x53b7f5<=_0x472185['pieces_']['length'];_0x53b7f5++,_0x340a5f++)if(_0x472185['pieces_'][_0x53b7f5]!==_0x57e9ec['pieces_'][_0x340a5f])return!0x1;return!0x0;}function G(_0x37061b,_0x536f2f){let _0x2379e0=_0x37061b['pieceNum_'],_0x1b99a9=_0x536f2f['pieceNum_'];if(Ce(_0x37061b)>Ce(_0x536f2f))return!0x1;for(;_0x2379e0<_0x37061b['pieces_']['length'];){if(_0x37061b['pieces_'][_0x2379e0]!==_0x536f2f['pieces_'][_0x1b99a9])return!0x1;++_0x2379e0,++_0x1b99a9;}return!0x0;}class Ah{constructor(_0xc2ec09,_0x1e5c2e){this['errorPrefix_']=_0x1e5c2e,this['parts_']=Mt(_0xc2ec09,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x571c45=0x0;_0x571c45<this['parts_']['length'];_0x571c45++)this['byteLength_']+=Ln(this['parts_'][_0x571c45]);Ao(this);}}function kh(_0x4cea43,_0x353ccd){_0x4cea43['parts_']['length']>0x0&&(_0x4cea43['byteLength_']+=0x1),_0x4cea43['parts_']['push'](_0x353ccd),_0x4cea43['byteLength_']+=Ln(_0x353ccd),Ao(_0x4cea43);}function Ph(_0x331d31){const _0x5992d8=_0x331d31['parts_']['pop']();_0x331d31['byteLength_']-=Ln(_0x5992d8),_0x331d31['parts_']['length']>0x0&&(_0x331d31['byteLength_']-=0x1);}function Ao(_0x4ff15d){if(_0x4ff15d['byteLength_']>Zs)throw new Error(_0x4ff15d['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x4ff15d['byteLength_']+').');if(_0x4ff15d['parts_']['length']>Xs)throw new Error(_0x4ff15d['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x4ff15d));}function Oe(_0x241641){return _0x241641['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x241641['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x372ae1,_0x52a550;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x52a550='visibilitychange',_0x372ae1='hidden'):typeof document['mozHidden']<'u'?(_0x52a550='mozvisibilitychange',_0x372ae1='mozHidden'):typeof document['msHidden']<'u'?(_0x52a550='msvisibilitychange',_0x372ae1='msHidden'):typeof document['webkitHidden']<'u'&&(_0x52a550='webkitvisibilitychange',_0x372ae1='webkitHidden')),this['visible_']=!0x0,_0x52a550&&document['addEventListener'](_0x52a550,()=>{const _0x224eda=!document[_0x372ae1];_0x224eda!==this['visible_']&&(this['visible_']=_0x224eda,this['trigger']('visible',_0x224eda));},!0x1);}['getInitialEvent'](_0x167923){return f(_0x167923==='visible','Unknown\x20event\x20type:\x20'+_0x167923),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x9a1940,_0x20c5d2,_0x14fa9d,_0x5bf00e,_0xa97219,_0x59d2c6,_0x27e59e,_0xab8091){if(super(),this['repoInfo_']=_0x9a1940,this['applicationId_']=_0x20c5d2,this['onDataUpdate_']=_0x14fa9d,this['onConnectStatus_']=_0x5bf00e,this['onServerInfoUpdate_']=_0xa97219,this['authTokenProvider_']=_0x59d2c6,this['appCheckTokenProvider_']=_0x27e59e,this['authOverride_']=_0xab8091,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xab8091)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x9a1940['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x580f5d,_0x35498a,_0x4c7977){const _0x42173a=++this['requestNumber_'],_0x2412a4={'r':_0x42173a,'a':_0x580f5d,'b':_0x35498a};this['log_'](O(_0x2412a4)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2412a4),_0x4c7977&&(this['requestCBHash_'][_0x42173a]=_0x4c7977);}['get'](_0x4c0030){this['initConnection_']();const _0x55f3c6=new H(),_0x16d23a={'action':'g','request':{'p':_0x4c0030['_path']['toString'](),'q':_0x4c0030['_queryObject']},'onComplete':_0x34af83=>{const _0x17b478=_0x34af83['d'];_0x34af83['s']==='ok'?_0x55f3c6['resolve'](_0x17b478):_0x55f3c6['reject'](_0x17b478);}};this['outstandingGets_']['push'](_0x16d23a),this['outstandingGetCount_']++;const _0x589458=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x589458),_0x55f3c6['promise'];}['listen'](_0x2fa620,_0xa3cebc,_0xec1f74,_0x40a821){this['initConnection_']();const _0x2a4299=_0x2fa620['_queryIdentifier'],_0x50f2fc=_0x2fa620['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x50f2fc+'\x20'+_0x2a4299),this['listens']['has'](_0x50f2fc)||this['listens']['set'](_0x50f2fc,new Map()),f(_0x2fa620['_queryParams']['isDefault']()||!_0x2fa620['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x50f2fc)['has'](_0x2a4299),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x171c39={'onComplete':_0x40a821,'hashFn':_0xa3cebc,'query':_0x2fa620,'tag':_0xec1f74};this['listens']['get'](_0x50f2fc)['set'](_0x2a4299,_0x171c39),this['connected_']&&this['sendListen_'](_0x171c39);}['sendGet_'](_0x1befff){const _0x394311=this['outstandingGets_'][_0x1befff];this['sendRequest']('g',_0x394311['request'],_0x4d5715=>{delete this['outstandingGets_'][_0x1befff],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x394311['onComplete']&&_0x394311['onComplete'](_0x4d5715);});}['sendListen_'](_0x178853){const _0x53d7ec=_0x178853['query'],_0x24b903=_0x53d7ec['_path']['toString'](),_0x987ff=_0x53d7ec['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x24b903+'\x20for\x20'+_0x987ff);const _0x2f85d1={'p':_0x24b903},_0x50288c='q';_0x178853['tag']&&(_0x2f85d1['q']=_0x53d7ec['_queryObject'],_0x2f85d1['t']=_0x178853['tag']),_0x2f85d1['h']=_0x178853['hashFn'](),this['sendRequest'](_0x50288c,_0x2f85d1,_0x544a34=>{const _0x56d60a=_0x544a34['d'],_0x3bff55=_0x544a34['s'];se['warnOnListenWarnings_'](_0x56d60a,_0x53d7ec),(this['listens']['get'](_0x24b903)&&this['listens']['get'](_0x24b903)['get'](_0x987ff))===_0x178853&&(this['log_']('listen\x20response',_0x544a34),_0x3bff55!=='ok'&&this['removeListen_'](_0x24b903,_0x987ff),_0x178853['onComplete']&&_0x178853['onComplete'](_0x3bff55,_0x56d60a));});}static['warnOnListenWarnings_'](_0x25c482,_0xcb499b){if(_0x25c482&&typeof _0x25c482=='object'&&Q(_0x25c482,'w')){const _0x52e5fb=Le(_0x25c482,'w');if(Array['isArray'](_0x52e5fb)&&~_0x52e5fb['indexOf']('no_index')){const _0x470ba4='\x22.indexOn\x22:\x20\x22'+_0xcb499b['_queryParams']['getIndex']()['toString']()+'\x22',_0x3f266b=_0xcb499b['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x470ba4+'\x20at\x20'+_0x3f266b+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x30aafb){this['authToken_']=_0x30aafb,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x30aafb);}['reduceReconnectDelayIfAdminCredential_'](_0x5a2c1c){(_0x5a2c1c&&_0x5a2c1c['length']===0x28||wc(_0x5a2c1c))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x3436eb){this['appCheckToken_']=_0x3436eb,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x488bde=this['authToken_'],_0x21d375=Ic(_0x488bde)?'auth':'gauth',_0x525e61={'cred':_0x488bde};this['authOverride_']===null?_0x525e61['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x525e61['authvar']=this['authOverride_']),this['sendRequest'](_0x21d375,_0x525e61,_0x4b2336=>{const _0x25f349=_0x4b2336['s'],_0xa52874=_0x4b2336['d']||'error';this['authToken_']===_0x488bde&&(_0x25f349==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x25f349,_0xa52874));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x25afe0=>{const _0x208802=_0x25afe0['s'],_0x3c0ba2=_0x25afe0['d']||'error';_0x208802==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x208802,_0x3c0ba2);});}['unlisten'](_0xdd1859,_0x17573b){const _0x1a2a92=_0xdd1859['_path']['toString'](),_0x451158=_0xdd1859['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1a2a92+'\x20'+_0x451158),f(_0xdd1859['_queryParams']['isDefault']()||!_0xdd1859['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1a2a92,_0x451158)&&this['connected_']&&this['sendUnlisten_'](_0x1a2a92,_0x451158,_0xdd1859['_queryObject'],_0x17573b);}['sendUnlisten_'](_0x26acc3,_0x11aea9,_0xb79bc2,_0x479e5e){this['log_']('Unlisten\x20on\x20'+_0x26acc3+'\x20for\x20'+_0x11aea9);const _0x2c99dd={'p':_0x26acc3},_0x503170='n';_0x479e5e&&(_0x2c99dd['q']=_0xb79bc2,_0x2c99dd['t']=_0x479e5e),this['sendRequest'](_0x503170,_0x2c99dd);}['onDisconnectPut'](_0x51bc86,_0x1c4718,_0x59d4e2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x51bc86,_0x1c4718,_0x59d4e2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x51bc86,'action':'o','data':_0x1c4718,'onComplete':_0x59d4e2});}['onDisconnectMerge'](_0x5584d4,_0x5583a2,_0x2fd803){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x5584d4,_0x5583a2,_0x2fd803):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5584d4,'action':'om','data':_0x5583a2,'onComplete':_0x2fd803});}['onDisconnectCancel'](_0x39c317,_0x3be41a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x39c317,null,_0x3be41a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x39c317,'action':'oc','data':null,'onComplete':_0x3be41a});}['sendOnDisconnect_'](_0xc40c5d,_0x173933,_0x25b9ca,_0x2d74c4){const _0x45e015={'p':_0x173933,'d':_0x25b9ca};this['log_']('onDisconnect\x20'+_0xc40c5d,_0x45e015),this['sendRequest'](_0xc40c5d,_0x45e015,_0xcb9ddc=>{_0x2d74c4&&setTimeout(()=>{_0x2d74c4(_0xcb9ddc['s'],_0xcb9ddc['d']);},Math['floor'](0x0));});}['put'](_0x22b014,_0x5324cb,_0x376fe5,_0x4fa864){this['putInternal']('p',_0x22b014,_0x5324cb,_0x376fe5,_0x4fa864);}['merge'](_0x3d13ef,_0x1e9d3d,_0x2fe880,_0x5b7940){this['putInternal']('m',_0x3d13ef,_0x1e9d3d,_0x2fe880,_0x5b7940);}['putInternal'](_0x36e311,_0x2aeb9f,_0x5e8f15,_0x3fb531,_0x465a32){this['initConnection_']();const _0x354af4={'p':_0x2aeb9f,'d':_0x5e8f15};_0x465a32!==void 0x0&&(_0x354af4['h']=_0x465a32),this['outstandingPuts_']['push']({'action':_0x36e311,'request':_0x354af4,'onComplete':_0x3fb531}),this['outstandingPutCount_']++;const _0x2b55d8=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2b55d8):this['log_']('Buffering\x20put:\x20'+_0x2aeb9f);}['sendPut_'](_0x495a78){const _0x4413de=this['outstandingPuts_'][_0x495a78]['action'],_0x56808b=this['outstandingPuts_'][_0x495a78]['request'],_0x18ee01=this['outstandingPuts_'][_0x495a78]['onComplete'];this['outstandingPuts_'][_0x495a78]['queued']=this['connected_'],this['sendRequest'](_0x4413de,_0x56808b,_0x4188ee=>{this['log_'](_0x4413de+'\x20response',_0x4188ee),delete this['outstandingPuts_'][_0x495a78],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x18ee01&&_0x18ee01(_0x4188ee['s'],_0x4188ee['d']);});}['reportStats'](_0x241084){if(this['connected_']){const _0x9d98a3={'c':_0x241084};this['log_']('reportStats',_0x9d98a3),this['sendRequest']('s',_0x9d98a3,_0x24f409=>{if(_0x24f409['s']!=='ok'){const _0x29cbd5=_0x24f409['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x29cbd5);}});}}['onDataMessage_'](_0x43c5da){if('r'in _0x43c5da){this['log_']('from\x20server:\x20'+O(_0x43c5da));const _0x1fa548=_0x43c5da['r'],_0x1ca31f=this['requestCBHash_'][_0x1fa548];_0x1ca31f&&(delete this['requestCBHash_'][_0x1fa548],_0x1ca31f(_0x43c5da['b']));}else{if('error'in _0x43c5da)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x43c5da['error'];'a'in _0x43c5da&&this['onDataPush_'](_0x43c5da['a'],_0x43c5da['b']);}}['onDataPush_'](_0x3030dc,_0x198128){this['log_']('handleServerMessage',_0x3030dc,_0x198128),_0x3030dc==='d'?this['onDataUpdate_'](_0x198128['p'],_0x198128['d'],!0x1,_0x198128['t']):_0x3030dc==='m'?this['onDataUpdate_'](_0x198128['p'],_0x198128['d'],!0x0,_0x198128['t']):_0x3030dc==='c'?this['onListenRevoked_'](_0x198128['p'],_0x198128['q']):_0x3030dc==='ac'?this['onAuthRevoked_'](_0x198128['s'],_0x198128['d']):_0x3030dc==='apc'?this['onAppCheckRevoked_'](_0x198128['s'],_0x198128['d']):_0x3030dc==='sd'?this['onSecurityDebugPacket_'](_0x198128):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3030dc)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3b4d7e,_0x42404a){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3b4d7e),this['lastSessionId']=_0x42404a,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x10b9ee){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x10b9ee));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x76a775){_0x76a775&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x76a775;}['onOnline_'](_0x1bc93c){_0x1bc93c?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5888e5=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x672c5d=Math['max'](0x0,this['reconnectDelay_']-_0x5888e5);_0x672c5d=Math['random']()*_0x672c5d,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x672c5d+'ms'),this['scheduleConnect_'](_0x672c5d),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x54d1e9=this['onDataMessage_']['bind'](this),_0x51af7d=this['onReady_']['bind'](this),_0x39f26e=this['onRealtimeDisconnect_']['bind'](this),_0x14755d=this['id']+':'+se['nextConnectionId_']++,_0x3add9a=this['lastSessionId'];let _0x300cee=!0x1,_0x51aec6=null;const _0x40df14=function(){_0x51aec6?_0x51aec6['close']():(_0x300cee=!0x0,_0x39f26e());},_0x534363=function(_0x582718){f(_0x51aec6,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x51aec6['sendRequest'](_0x582718);};this['realtime_']={'close':_0x40df14,'sendRequest':_0x534363};const _0x1601f9=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x240fc3,_0x2fd7f7]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x1601f9),this['appCheckTokenProvider_']['getToken'](_0x1601f9)]);_0x300cee?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x240fc3&&_0x240fc3['accessToken'],this['appCheckToken_']=_0x2fd7f7&&_0x2fd7f7['token'],_0x51aec6=new Sh(_0x14755d,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x54d1e9,_0x51af7d,_0x39f26e,_0xdc2a56=>{U(_0xdc2a56+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x3add9a));}catch(_0x24db2d){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x24db2d),_0x300cee||(this['repoInfo_']['nodeAdmin']&&U(_0x24db2d),_0x40df14());}}}['interrupt'](_0x1f608f){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1f608f),this['interruptReasons_'][_0x1f608f]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0xee82bc){L('Resuming\x20connection\x20for\x20reason:\x20'+_0xee82bc),delete this['interruptReasons_'][_0xee82bc],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3a4a4b){const _0x57f3fa=_0x3a4a4b-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x57f3fa});}['cancelSentTransactions_'](){for(let _0xed544a=0x0;_0xed544a<this['outstandingPuts_']['length'];_0xed544a++){const _0xab78ff=this['outstandingPuts_'][_0xed544a];_0xab78ff&&'h'in _0xab78ff['request']&&_0xab78ff['queued']&&(_0xab78ff['onComplete']&&_0xab78ff['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xed544a],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x430706,_0x106831){let _0x193660;_0x106831?_0x193660=_0x106831['map'](_0x14ff09=>$i(_0x14ff09))['join']('$'):_0x193660='default';const _0x2aba15=this['removeListen_'](_0x430706,_0x193660);_0x2aba15&&_0x2aba15['onComplete']&&_0x2aba15['onComplete']('permission_denied');}['removeListen_'](_0x1db5d3,_0x24bac7){const _0x509c29=new C(_0x1db5d3)['toString']();let _0x16dde8;if(this['listens']['has'](_0x509c29)){const _0x13d70f=this['listens']['get'](_0x509c29);_0x16dde8=_0x13d70f['get'](_0x24bac7),_0x13d70f['delete'](_0x24bac7),_0x13d70f['size']===0x0&&this['listens']['delete'](_0x509c29);}else _0x16dde8=void 0x0;return _0x16dde8;}['onAuthRevoked_'](_0x5304fa,_0x561bed){L('Auth\x20token\x20revoked:\x20'+_0x5304fa+'/'+_0x561bed),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5304fa==='invalid_token'||_0x5304fa==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5b81f5,_0x2a1d99){L('App\x20check\x20token\x20revoked:\x20'+_0x5b81f5+'/'+_0x2a1d99),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5b81f5==='invalid_token'||_0x5b81f5==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x55ff63){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x55ff63):'msg'in _0x55ff63&&console['log']('FIREBASE:\x20'+_0x55ff63['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x21229a of this['listens']['values']())for(const _0xac82c9 of _0x21229a['values']())this['sendListen_'](_0xac82c9);for(let _0x12ee98=0x0;_0x12ee98<this['outstandingPuts_']['length'];_0x12ee98++)this['outstandingPuts_'][_0x12ee98]&&this['sendPut_'](_0x12ee98);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4f24e8=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4f24e8['action'],_0x4f24e8['pathString'],_0x4f24e8['data'],_0x4f24e8['onComplete']);}for(let _0x3ba3d0=0x0;_0x3ba3d0<this['outstandingGets_']['length'];_0x3ba3d0++)this['outstandingGets_'][_0x3ba3d0]&&this['sendGet_'](_0x3ba3d0);}['sendConnectStats_'](){const _0x2d092e={};let _0x18cc8e='js';_0x2d092e['sdk.'+_0x18cc8e+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x2d092e['framework.cordova']=0x1:Kr()&&(_0x2d092e['framework.reactnative']=0x1),this['reportStats'](_0x2d092e);}['shouldReconnect_'](){const _0xec334=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0xec334;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x261741,_0x3b77e2){this['name']=_0x261741,this['node']=_0x3b77e2;}static['Wrap'](_0x53ddae,_0x121065){return new E(_0x53ddae,_0x121065);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x4dc23d,_0x460e84){const _0x144228=new E(We,_0x4dc23d),_0x101ddd=new E(We,_0x460e84);return this['compare'](_0x144228,_0x101ddd)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x40efd5){sn=_0x40efd5;}['compare'](_0x165dc6,_0x3b398a){return qe(_0x165dc6['name'],_0x3b398a['name']);}['isDefinedOn'](_0x3eddda){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x29f3c7,_0x5a8bab){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x3963ba,_0x1d16f){return f(typeof _0x3963ba=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3963ba,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x4782f6,_0x9ed20b,_0x137fb9,_0x2577e5,_0x2e1ca3=null){this['isReverse_']=_0x2577e5,this['resultGenerator_']=_0x2e1ca3,this['nodeStack_']=[];let _0x52dc19=0x1;for(;!_0x4782f6['isEmpty']();)if(_0x4782f6=_0x4782f6,_0x52dc19=_0x9ed20b?_0x137fb9(_0x4782f6['key'],_0x9ed20b):0x1,_0x2577e5&&(_0x52dc19*=-0x1),_0x52dc19<0x0)this['isReverse_']?_0x4782f6=_0x4782f6['left']:_0x4782f6=_0x4782f6['right'];else{if(_0x52dc19===0x0){this['nodeStack_']['push'](_0x4782f6);break;}else this['nodeStack_']['push'](_0x4782f6),this['isReverse_']?_0x4782f6=_0x4782f6['right']:_0x4782f6=_0x4782f6['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1f88d7=this['nodeStack_']['pop'](),_0x41d103;if(this['resultGenerator_']?_0x41d103=this['resultGenerator_'](_0x1f88d7['key'],_0x1f88d7['value']):_0x41d103={'key':_0x1f88d7['key'],'value':_0x1f88d7['value']},this['isReverse_']){for(_0x1f88d7=_0x1f88d7['left'];!_0x1f88d7['isEmpty']();)this['nodeStack_']['push'](_0x1f88d7),_0x1f88d7=_0x1f88d7['right'];}else{for(_0x1f88d7=_0x1f88d7['right'];!_0x1f88d7['isEmpty']();)this['nodeStack_']['push'](_0x1f88d7),_0x1f88d7=_0x1f88d7['left'];}return _0x41d103;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x26fa1d=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x26fa1d['key'],_0x26fa1d['value']):{'key':_0x26fa1d['key'],'value':_0x26fa1d['value']};}}class M{constructor(_0x3be458,_0x2f6d9d,_0x5f598b,_0x4874a1,_0x525921){this['key']=_0x3be458,this['value']=_0x2f6d9d,this['color']=_0x5f598b??M['RED'],this['left']=_0x4874a1??B['EMPTY_NODE'],this['right']=_0x525921??B['EMPTY_NODE'];}['copy'](_0x101921,_0x530046,_0x1729b2,_0x1514a0,_0x4b7418){return new M(_0x101921??this['key'],_0x530046??this['value'],_0x1729b2??this['color'],_0x1514a0??this['left'],_0x4b7418??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x57ed34){return this['left']['inorderTraversal'](_0x57ed34)||!!_0x57ed34(this['key'],this['value'])||this['right']['inorderTraversal'](_0x57ed34);}['reverseTraversal'](_0x3417e2){return this['right']['reverseTraversal'](_0x3417e2)||_0x3417e2(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3417e2);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x469eae,_0xa0e3e6,_0x20fdb8){let _0x4eb763=this;const _0x3cc45d=_0x20fdb8(_0x469eae,_0x4eb763['key']);return _0x3cc45d<0x0?_0x4eb763=_0x4eb763['copy'](null,null,null,_0x4eb763['left']['insert'](_0x469eae,_0xa0e3e6,_0x20fdb8),null):_0x3cc45d===0x0?_0x4eb763=_0x4eb763['copy'](null,_0xa0e3e6,null,null,null):_0x4eb763=_0x4eb763['copy'](null,null,null,null,_0x4eb763['right']['insert'](_0x469eae,_0xa0e3e6,_0x20fdb8)),_0x4eb763['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x340b77=this;return!_0x340b77['left']['isRed_']()&&!_0x340b77['left']['left']['isRed_']()&&(_0x340b77=_0x340b77['moveRedLeft_']()),_0x340b77=_0x340b77['copy'](null,null,null,_0x340b77['left']['removeMin_'](),null),_0x340b77['fixUp_']();}['remove'](_0x1ba7eb,_0x3454da){let _0x5b4716,_0x1354e4;if(_0x5b4716=this,_0x3454da(_0x1ba7eb,_0x5b4716['key'])<0x0)!_0x5b4716['left']['isEmpty']()&&!_0x5b4716['left']['isRed_']()&&!_0x5b4716['left']['left']['isRed_']()&&(_0x5b4716=_0x5b4716['moveRedLeft_']()),_0x5b4716=_0x5b4716['copy'](null,null,null,_0x5b4716['left']['remove'](_0x1ba7eb,_0x3454da),null);else{if(_0x5b4716['left']['isRed_']()&&(_0x5b4716=_0x5b4716['rotateRight_']()),!_0x5b4716['right']['isEmpty']()&&!_0x5b4716['right']['isRed_']()&&!_0x5b4716['right']['left']['isRed_']()&&(_0x5b4716=_0x5b4716['moveRedRight_']()),_0x3454da(_0x1ba7eb,_0x5b4716['key'])===0x0){if(_0x5b4716['right']['isEmpty']())return B['EMPTY_NODE'];_0x1354e4=_0x5b4716['right']['min_'](),_0x5b4716=_0x5b4716['copy'](_0x1354e4['key'],_0x1354e4['value'],null,null,_0x5b4716['right']['removeMin_']());}_0x5b4716=_0x5b4716['copy'](null,null,null,null,_0x5b4716['right']['remove'](_0x1ba7eb,_0x3454da));}return _0x5b4716['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1aaa1c=this;return _0x1aaa1c['right']['isRed_']()&&!_0x1aaa1c['left']['isRed_']()&&(_0x1aaa1c=_0x1aaa1c['rotateLeft_']()),_0x1aaa1c['left']['isRed_']()&&_0x1aaa1c['left']['left']['isRed_']()&&(_0x1aaa1c=_0x1aaa1c['rotateRight_']()),_0x1aaa1c['left']['isRed_']()&&_0x1aaa1c['right']['isRed_']()&&(_0x1aaa1c=_0x1aaa1c['colorFlip_']()),_0x1aaa1c;}['moveRedLeft_'](){let _0x419c43=this['colorFlip_']();return _0x419c43['right']['left']['isRed_']()&&(_0x419c43=_0x419c43['copy'](null,null,null,null,_0x419c43['right']['rotateRight_']()),_0x419c43=_0x419c43['rotateLeft_'](),_0x419c43=_0x419c43['colorFlip_']()),_0x419c43;}['moveRedRight_'](){let _0x197638=this['colorFlip_']();return _0x197638['left']['left']['isRed_']()&&(_0x197638=_0x197638['rotateRight_'](),_0x197638=_0x197638['colorFlip_']()),_0x197638;}['rotateLeft_'](){const _0x4d9029=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4d9029,null);}['rotateRight_'](){const _0x26644d=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x26644d);}['colorFlip_'](){const _0x5796d6=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x304072=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5796d6,_0x304072);}['checkMaxDepth_'](){const _0x29e266=this['check_']();return Math['pow'](0x2,_0x29e266)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x50438e=this['left']['check_']();if(_0x50438e!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x50438e+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4eadb8,_0x258073,_0x503c26,_0x40114b,_0x4683cf){return this;}['insert'](_0x178bd8,_0x681c5d,_0x57a265){return new M(_0x178bd8,_0x681c5d,null);}['remove'](_0x307679,_0x294f75){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1569ad){return!0x1;}['reverseTraversal'](_0xd2114a){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x900e78,_0x571346=B['EMPTY_NODE']){this['comparator_']=_0x900e78,this['root_']=_0x571346;}['insert'](_0x4963e5,_0x436102){return new B(this['comparator_'],this['root_']['insert'](_0x4963e5,_0x436102,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x155ca2){return new B(this['comparator_'],this['root_']['remove'](_0x155ca2,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0xef778e){let _0x40aeb7,_0x7ccc87=this['root_'];for(;!_0x7ccc87['isEmpty']();){if(_0x40aeb7=this['comparator_'](_0xef778e,_0x7ccc87['key']),_0x40aeb7===0x0)return _0x7ccc87['value'];_0x40aeb7<0x0?_0x7ccc87=_0x7ccc87['left']:_0x40aeb7>0x0&&(_0x7ccc87=_0x7ccc87['right']);}return null;}['getPredecessorKey'](_0x323b15){let _0x32bce2,_0xe1ff1a=this['root_'],_0x488dcb=null;for(;!_0xe1ff1a['isEmpty']();)if(_0x32bce2=this['comparator_'](_0x323b15,_0xe1ff1a['key']),_0x32bce2===0x0){if(_0xe1ff1a['left']['isEmpty']())return _0x488dcb?_0x488dcb['key']:null;for(_0xe1ff1a=_0xe1ff1a['left'];!_0xe1ff1a['right']['isEmpty']();)_0xe1ff1a=_0xe1ff1a['right'];return _0xe1ff1a['key'];}else _0x32bce2<0x0?_0xe1ff1a=_0xe1ff1a['left']:_0x32bce2>0x0&&(_0x488dcb=_0xe1ff1a,_0xe1ff1a=_0xe1ff1a['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2907a3){return this['root_']['inorderTraversal'](_0x2907a3);}['reverseTraversal'](_0x3eca34){return this['root_']['reverseTraversal'](_0x3eca34);}['getIterator'](_0x492d38){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x492d38);}['getIteratorFrom'](_0x33599a,_0xf04002){return new rn(this['root_'],_0x33599a,this['comparator_'],!0x1,_0xf04002);}['getReverseIteratorFrom'](_0x3d2576,_0x74138e){return new rn(this['root_'],_0x3d2576,this['comparator_'],!0x0,_0x74138e);}['getReverseIterator'](_0x122628){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x122628);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1b0157,_0x304534){return qe(_0x1b0157['name'],_0x304534['name']);}function Qi(_0x1d5868,_0x44a0b1){return qe(_0x1d5868,_0x44a0b1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x488b86){Ci=_0x488b86;}const Po=function(_0x5d8cb4){return typeof _0x5d8cb4=='number'?'number:'+ao(_0x5d8cb4):'string:'+_0x5d8cb4;},No=function(_0x609280){if(_0x609280['isLeafNode']()){const _0xe1be28=_0x609280['val']();f(typeof _0xe1be28=='string'||typeof _0xe1be28=='number'||typeof _0xe1be28=='object'&&Q(_0xe1be28,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x609280===Ci||_0x609280['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x609280===Ci||_0x609280['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x29d509){nr=_0x29d509;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x456224,_0x330a5b=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x456224,this['priorityNode_']=_0x330a5b,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x49480a){return new D(this['value_'],_0x49480a);}['getImmediateChild'](_0xa85970){return _0xa85970==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x279e9e){return v(_0x279e9e)?this:y(_0x279e9e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1f41d8,_0xb40118){return null;}['updateImmediateChild'](_0x58e2d6,_0x1dd38c){return _0x58e2d6==='.priority'?this['updatePriority'](_0x1dd38c):_0x1dd38c['isEmpty']()&&_0x58e2d6!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x58e2d6,_0x1dd38c)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1577b0,_0x150ad2){const _0x405e3d=y(_0x1577b0);return _0x405e3d===null?_0x150ad2:_0x150ad2['isEmpty']()&&_0x405e3d!=='.priority'?this:(f(_0x405e3d!=='.priority'||Ce(_0x1577b0)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x405e3d,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x1577b0),_0x150ad2)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4e4f63,_0x405716){return!0x1;}['val'](_0x4c5407){return _0x4c5407&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x23bbd4='';this['priorityNode_']['isEmpty']()||(_0x23bbd4+='priority:'+Po(this['priorityNode_']['val']())+':');const _0xb892e3=typeof this['value_'];_0x23bbd4+=_0xb892e3+':',_0xb892e3==='number'?_0x23bbd4+=ao(this['value_']):_0x23bbd4+=this['value_'],this['lazyHash_']=ro(_0x23bbd4);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2ce3c5){return _0x2ce3c5===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2ce3c5 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2ce3c5['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2ce3c5));}['compareToLeafNode_'](_0x5dbd05){const _0x38f12d=typeof _0x5dbd05['value_'],_0x4c10a9=typeof this['value_'],_0x2ddedf=D['VALUE_TYPE_ORDER']['indexOf'](_0x38f12d),_0x3c3fde=D['VALUE_TYPE_ORDER']['indexOf'](_0x4c10a9);return f(_0x2ddedf>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x38f12d),f(_0x3c3fde>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4c10a9),_0x2ddedf===_0x3c3fde?_0x4c10a9==='object'?0x0:this['value_']<_0x5dbd05['value_']?-0x1:this['value_']===_0x5dbd05['value_']?0x0:0x1:_0x3c3fde-_0x2ddedf;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2e8e82){if(_0x2e8e82===this)return!0x0;if(_0x2e8e82['isLeafNode']()){const _0x14f318=_0x2e8e82;return this['value_']===_0x14f318['value_']&&this['priorityNode_']['equals'](_0x14f318['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x36fae1){Oo=_0x36fae1;}function Wh(_0x3d1fe0){Do=_0x3d1fe0;}class Bh extends Fn{['compare'](_0x5b6aca,_0x1db506){const _0x3e552a=_0x5b6aca['node']['getPriority'](),_0x34ff90=_0x1db506['node']['getPriority'](),_0x3db3f4=_0x3e552a['compareTo'](_0x34ff90);return _0x3db3f4===0x0?qe(_0x5b6aca['name'],_0x1db506['name']):_0x3db3f4;}['isDefinedOn'](_0x53d7f9){return!_0x53d7f9['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2d2c5a,_0x34b45d){return!_0x2d2c5a['getPriority']()['equals'](_0x34b45d['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x10f087,_0x3a1fa0){const _0xa39874=Oo(_0x10f087);return new E(_0x3a1fa0,new D('[PRIORITY-POST]',_0xa39874));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3a5abc){const _0x4010a5=_0x3e993b=>parseInt(Math['log'](_0x3e993b)/Vh,0xa),_0x13d2e6=_0x55c6ec=>parseInt(Array(_0x55c6ec+0x1)['join']('1'),0x2);this['count']=_0x4010a5(_0x3a5abc+0x1),this['current_']=this['count']-0x1;const _0x45abfc=_0x13d2e6(this['count']);this['bits_']=_0x3a5abc+0x1&_0x45abfc;}['nextBitIsOne'](){const _0x486c46=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x486c46;}}const yn=function(_0x58984d,_0x52a45b,_0x305de9,_0x505546){_0x58984d['sort'](_0x52a45b);const _0x45a45a=function(_0x44806b,_0x17ca8b){const _0x5e13dc=_0x17ca8b-_0x44806b;let _0xbb1dd4,_0xc685ff;if(_0x5e13dc===0x0)return null;if(_0x5e13dc===0x1)return _0xbb1dd4=_0x58984d[_0x44806b],_0xc685ff=_0x305de9?_0x305de9(_0xbb1dd4):_0xbb1dd4,new M(_0xc685ff,_0xbb1dd4['node'],M['BLACK'],null,null);{const _0x57bfb6=parseInt(_0x5e13dc/0x2,0xa)+_0x44806b,_0xc5b831=_0x45a45a(_0x44806b,_0x57bfb6),_0x4c259a=_0x45a45a(_0x57bfb6+0x1,_0x17ca8b);return _0xbb1dd4=_0x58984d[_0x57bfb6],_0xc685ff=_0x305de9?_0x305de9(_0xbb1dd4):_0xbb1dd4,new M(_0xc685ff,_0xbb1dd4['node'],M['BLACK'],_0xc5b831,_0x4c259a);}},_0xc9334f=function(_0x483d25){let _0xc0d5af=null,_0x41bdae=null,_0x1bfa1c=_0x58984d['length'];const _0xeace37=function(_0x5b4fec,_0x8ed424){const _0x58fa4d=_0x1bfa1c-_0x5b4fec,_0x1f8855=_0x1bfa1c;_0x1bfa1c-=_0x5b4fec;const _0x4144cd=_0x45a45a(_0x58fa4d+0x1,_0x1f8855),_0x5382bb=_0x58984d[_0x58fa4d],_0x3026a3=_0x305de9?_0x305de9(_0x5382bb):_0x5382bb;_0x118951(new M(_0x3026a3,_0x5382bb['node'],_0x8ed424,null,_0x4144cd));},_0x118951=function(_0x48abc5){_0xc0d5af?(_0xc0d5af['left']=_0x48abc5,_0xc0d5af=_0x48abc5):(_0x41bdae=_0x48abc5,_0xc0d5af=_0x48abc5);};for(let _0x2112e8=0x0;_0x2112e8<_0x483d25['count'];++_0x2112e8){const _0x23d052=_0x483d25['nextBitIsOne'](),_0x4579ea=Math['pow'](0x2,_0x483d25['count']-(_0x2112e8+0x1));_0x23d052?_0xeace37(_0x4579ea,M['BLACK']):(_0xeace37(_0x4579ea,M['BLACK']),_0xeace37(_0x4579ea,M['RED']));}return _0x41bdae;},_0x218a6b=new Hh(_0x58984d['length']),_0x1ad1c5=_0xc9334f(_0x218a6b);return new B(_0x505546||_0x52a45b,_0x1ad1c5);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x39150e,_0x4fea80){this['indexes_']=_0x39150e,this['indexSet_']=_0x4fea80;}['get'](_0x3b36a4){const _0x33ca3b=Le(this['indexes_'],_0x3b36a4);if(!_0x33ca3b)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3b36a4);return _0x33ca3b instanceof B?_0x33ca3b:null;}['hasIndex'](_0xfa2525){return Q(this['indexSet_'],_0xfa2525['toString']());}['addIndex'](_0x248223,_0x6b5c0d){f(_0x248223!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x59d886=[];let _0x404a74=!0x1;const _0x4abb78=_0x6b5c0d['getIterator'](E['Wrap']);let _0x47f77a=_0x4abb78['getNext']();for(;_0x47f77a;)_0x404a74=_0x404a74||_0x248223['isDefinedOn'](_0x47f77a['node']),_0x59d886['push'](_0x47f77a),_0x47f77a=_0x4abb78['getNext']();let _0x149594;_0x404a74?_0x149594=yn(_0x59d886,_0x248223['getCompare']()):_0x149594=Qe;const _0x56cffe=_0x248223['toString'](),_0x4684bc={...this['indexSet_']};_0x4684bc[_0x56cffe]=_0x248223;const _0x222c17={...this['indexes_']};return _0x222c17[_0x56cffe]=_0x149594,new te(_0x222c17,_0x4684bc);}['addToIndexes'](_0x36cf5a,_0x238da0){const _0x4222aa=_n(this['indexes_'],(_0x351be9,_0x27fa1e)=>{const _0x17cb29=Le(this['indexSet_'],_0x27fa1e);if(f(_0x17cb29,'Missing\x20index\x20implementation\x20for\x20'+_0x27fa1e),_0x351be9===Qe){if(_0x17cb29['isDefinedOn'](_0x36cf5a['node'])){const _0x4c38bf=[],_0x473cf3=_0x238da0['getIterator'](E['Wrap']);let _0x3417ea=_0x473cf3['getNext']();for(;_0x3417ea;)_0x3417ea['name']!==_0x36cf5a['name']&&_0x4c38bf['push'](_0x3417ea),_0x3417ea=_0x473cf3['getNext']();return _0x4c38bf['push'](_0x36cf5a),yn(_0x4c38bf,_0x17cb29['getCompare']());}else return Qe;}else{const _0x471430=_0x238da0['get'](_0x36cf5a['name']);let _0x20a2da=_0x351be9;return _0x471430&&(_0x20a2da=_0x20a2da['remove'](new E(_0x36cf5a['name'],_0x471430))),_0x20a2da['insert'](_0x36cf5a,_0x36cf5a['node']);}});return new te(_0x4222aa,this['indexSet_']);}['removeFromIndexes'](_0x5b3903,_0x27c6d4){const _0x4075f3=_n(this['indexes_'],_0x21d4bb=>{if(_0x21d4bb===Qe)return _0x21d4bb;{const _0x4f81b0=_0x27c6d4['get'](_0x5b3903['name']);return _0x4f81b0?_0x21d4bb['remove'](new E(_0x5b3903['name'],_0x4f81b0)):_0x21d4bb;}});return new te(_0x4075f3,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x43861f,_0x3fc937,_0x3a3d9){this['children_']=_0x43861f,this['priorityNode_']=_0x3fc937,this['indexMap_']=_0x3a3d9,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x556592){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x556592,this['indexMap_']);}['getImmediateChild'](_0x4e4332){if(_0x4e4332==='.priority')return this['getPriority']();{const _0x1ab504=this['children_']['get'](_0x4e4332);return _0x1ab504===null?It:_0x1ab504;}}['getChild'](_0x4b8d55){const _0x1da83e=y(_0x4b8d55);return _0x1da83e===null?this:this['getImmediateChild'](_0x1da83e)['getChild'](S(_0x4b8d55));}['hasChild'](_0x50491d){return this['children_']['get'](_0x50491d)!==null;}['updateImmediateChild'](_0x5e12b0,_0x3231d5){if(f(_0x3231d5,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5e12b0==='.priority')return this['updatePriority'](_0x3231d5);{const _0x474ca1=new E(_0x5e12b0,_0x3231d5);let _0x5184ab,_0x2b5754;_0x3231d5['isEmpty']()?(_0x5184ab=this['children_']['remove'](_0x5e12b0),_0x2b5754=this['indexMap_']['removeFromIndexes'](_0x474ca1,this['children_'])):(_0x5184ab=this['children_']['insert'](_0x5e12b0,_0x3231d5),_0x2b5754=this['indexMap_']['addToIndexes'](_0x474ca1,this['children_']));const _0xf6e232=_0x5184ab['isEmpty']()?It:this['priorityNode_'];return new g(_0x5184ab,_0xf6e232,_0x2b5754);}}['updateChild'](_0x110e3d,_0x128255){const _0x1d134b=y(_0x110e3d);if(_0x1d134b===null)return _0x128255;{f(y(_0x110e3d)!=='.priority'||Ce(_0x110e3d)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x25d35c=this['getImmediateChild'](_0x1d134b)['updateChild'](S(_0x110e3d),_0x128255);return this['updateImmediateChild'](_0x1d134b,_0x25d35c);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x26c6cc){if(this['isEmpty']())return null;const _0x7357f1={};let _0x1da27a=0x0,_0x5b20fc=0x0,_0x39e3bc=!0x0;if(this['forEachChild'](R,(_0x8f053a,_0x435542)=>{_0x7357f1[_0x8f053a]=_0x435542['val'](_0x26c6cc),_0x1da27a++,_0x39e3bc&&g['INTEGER_REGEXP_']['test'](_0x8f053a)?_0x5b20fc=Math['max'](_0x5b20fc,Number(_0x8f053a)):_0x39e3bc=!0x1;}),!_0x26c6cc&&_0x39e3bc&&_0x5b20fc<0x2*_0x1da27a){const _0xe6f8c9=[];for(const _0x3f7f09 in _0x7357f1)_0xe6f8c9[_0x3f7f09]=_0x7357f1[_0x3f7f09];return _0xe6f8c9;}else return _0x26c6cc&&!this['getPriority']()['isEmpty']()&&(_0x7357f1['.priority']=this['getPriority']()['val']()),_0x7357f1;}['hash'](){if(this['lazyHash_']===null){let _0x25a0b1='';this['getPriority']()['isEmpty']()||(_0x25a0b1+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x12ceab,_0x1667da)=>{const _0x1f4fab=_0x1667da['hash']();_0x1f4fab!==''&&(_0x25a0b1+=':'+_0x12ceab+':'+_0x1f4fab);}),this['lazyHash_']=_0x25a0b1===''?'':ro(_0x25a0b1);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3874de,_0x2680b4,_0x95dd73){const _0xe83bfb=this['resolveIndex_'](_0x95dd73);if(_0xe83bfb){const _0x3660e2=_0xe83bfb['getPredecessorKey'](new E(_0x3874de,_0x2680b4));return _0x3660e2?_0x3660e2['name']:null;}else return this['children_']['getPredecessorKey'](_0x3874de);}['getFirstChildName'](_0x4f8a7e){const _0x1d4a75=this['resolveIndex_'](_0x4f8a7e);if(_0x1d4a75){const _0x5ac1e3=_0x1d4a75['minKey']();return _0x5ac1e3&&_0x5ac1e3['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x596415){const _0x47dbe2=this['getFirstChildName'](_0x596415);return _0x47dbe2?new E(_0x47dbe2,this['children_']['get'](_0x47dbe2)):null;}['getLastChildName'](_0x35d7d1){const _0x1f5fd8=this['resolveIndex_'](_0x35d7d1);if(_0x1f5fd8){const _0x193189=_0x1f5fd8['maxKey']();return _0x193189&&_0x193189['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4d9473){const _0x30cea3=this['getLastChildName'](_0x4d9473);return _0x30cea3?new E(_0x30cea3,this['children_']['get'](_0x30cea3)):null;}['forEachChild'](_0x53e5ab,_0x395c3b){const _0x224e53=this['resolveIndex_'](_0x53e5ab);return _0x224e53?_0x224e53['inorderTraversal'](_0x3581ef=>_0x395c3b(_0x3581ef['name'],_0x3581ef['node'])):this['children_']['inorderTraversal'](_0x395c3b);}['getIterator'](_0x5f5593){return this['getIteratorFrom'](_0x5f5593['minPost'](),_0x5f5593);}['getIteratorFrom'](_0x5daf8d,_0x3e4a4b){const _0x132695=this['resolveIndex_'](_0x3e4a4b);if(_0x132695)return _0x132695['getIteratorFrom'](_0x5daf8d,_0x5d49ef=>_0x5d49ef);{const _0x1c9dc0=this['children_']['getIteratorFrom'](_0x5daf8d['name'],E['Wrap']);let _0x1fe572=_0x1c9dc0['peek']();for(;_0x1fe572!=null&&_0x3e4a4b['compare'](_0x1fe572,_0x5daf8d)<0x0;)_0x1c9dc0['getNext'](),_0x1fe572=_0x1c9dc0['peek']();return _0x1c9dc0;}}['getReverseIterator'](_0x52f6c9){return this['getReverseIteratorFrom'](_0x52f6c9['maxPost'](),_0x52f6c9);}['getReverseIteratorFrom'](_0x272cb5,_0x479477){const _0x2148d5=this['resolveIndex_'](_0x479477);if(_0x2148d5)return _0x2148d5['getReverseIteratorFrom'](_0x272cb5,_0x137ef2=>_0x137ef2);{const _0x4658c6=this['children_']['getReverseIteratorFrom'](_0x272cb5['name'],E['Wrap']);let _0x36530d=_0x4658c6['peek']();for(;_0x36530d!=null&&_0x479477['compare'](_0x36530d,_0x272cb5)>0x0;)_0x4658c6['getNext'](),_0x36530d=_0x4658c6['peek']();return _0x4658c6;}}['compareTo'](_0x86836b){return this['isEmpty']()?_0x86836b['isEmpty']()?0x0:-0x1:_0x86836b['isLeafNode']()||_0x86836b['isEmpty']()?0x1:_0x86836b===Kt?-0x1:0x0;}['withIndex'](_0x25ffde){if(_0x25ffde===ve||this['indexMap_']['hasIndex'](_0x25ffde))return this;{const _0x216f58=this['indexMap_']['addIndex'](_0x25ffde,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x216f58);}}['isIndexed'](_0xe9be0b){return _0xe9be0b===ve||this['indexMap_']['hasIndex'](_0xe9be0b);}['equals'](_0xf00880){if(_0xf00880===this)return!0x0;if(_0xf00880['isLeafNode']())return!0x1;{const _0x3e60de=_0xf00880;if(this['getPriority']()['equals'](_0x3e60de['getPriority']())){if(this['children_']['count']()===_0x3e60de['children_']['count']()){const _0x5b20a4=this['getIterator'](R),_0x412d0c=_0x3e60de['getIterator'](R);let _0x234596=_0x5b20a4['getNext'](),_0x37d72f=_0x412d0c['getNext']();for(;_0x234596&&_0x37d72f;){if(_0x234596['name']!==_0x37d72f['name']||!_0x234596['node']['equals'](_0x37d72f['node']))return!0x1;_0x234596=_0x5b20a4['getNext'](),_0x37d72f=_0x412d0c['getNext']();}return _0x234596===null&&_0x37d72f===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4a651e){return _0x4a651e===ve?null:this['indexMap_']['get'](_0x4a651e['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0xbcd573){return _0xbcd573===this?0x0:0x1;}['equals'](_0x5b2bf7){return _0x5b2bf7===this;}['getPriority'](){return this;}['getImmediateChild'](_0x13cbac){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x504033,_0x36a2c3=null){if(_0x504033===null)return g['EMPTY_NODE'];if(typeof _0x504033=='object'&&'.priority'in _0x504033&&(_0x36a2c3=_0x504033['.priority']),f(_0x36a2c3===null||typeof _0x36a2c3=='string'||typeof _0x36a2c3=='number'||typeof _0x36a2c3=='object'&&'.sv'in _0x36a2c3,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x36a2c3),typeof _0x504033=='object'&&'.value'in _0x504033&&_0x504033['.value']!==null&&(_0x504033=_0x504033['.value']),typeof _0x504033!='object'||'.sv'in _0x504033){const _0x5cba65=_0x504033;return new D(_0x5cba65,A(_0x36a2c3));}if(!(_0x504033 instanceof Array)&&Gh){const _0x4f71a0=[];let _0x4b4e00=!0x1;if(x(_0x504033,(_0x294ef1,_0xbb4b94)=>{if(_0x294ef1['substring'](0x0,0x1)!=='.'){const _0x473396=A(_0xbb4b94);_0x473396['isEmpty']()||(_0x4b4e00=_0x4b4e00||!_0x473396['getPriority']()['isEmpty'](),_0x4f71a0['push'](new E(_0x294ef1,_0x473396)));}}),_0x4f71a0['length']===0x0)return g['EMPTY_NODE'];const _0x413c2f=yn(_0x4f71a0,xh,_0x539e90=>_0x539e90['name'],Qi);if(_0x4b4e00){const _0x8d265d=yn(_0x4f71a0,R['getCompare']());return new g(_0x413c2f,A(_0x36a2c3),new te({'.priority':_0x8d265d},{'.priority':R}));}else return new g(_0x413c2f,A(_0x36a2c3),te['Default']);}else{let _0xf821bd=g['EMPTY_NODE'];return x(_0x504033,(_0x158f5a,_0x21edcb)=>{if(Q(_0x504033,_0x158f5a)&&_0x158f5a['substring'](0x0,0x1)!=='.'){const _0x2e71b6=A(_0x21edcb);(_0x2e71b6['isLeafNode']()||!_0x2e71b6['isEmpty']())&&(_0xf821bd=_0xf821bd['updateImmediateChild'](_0x158f5a,_0x2e71b6));}}),_0xf821bd['updatePriority'](A(_0x36a2c3));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x29cd53){super(),this['indexPath_']=_0x29cd53,f(!v(_0x29cd53)&&y(_0x29cd53)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x23055a){return _0x23055a['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3af107){return!_0x3af107['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x8a7692,_0x7093ed){const _0x46a501=this['extractChild'](_0x8a7692['node']),_0x188903=this['extractChild'](_0x7093ed['node']),_0x57dcb1=_0x46a501['compareTo'](_0x188903);return _0x57dcb1===0x0?qe(_0x8a7692['name'],_0x7093ed['name']):_0x57dcb1;}['makePost'](_0x5d1e7f,_0x58f7f1){const _0x8755fb=A(_0x5d1e7f),_0x42f64d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x8755fb);return new E(_0x58f7f1,_0x42f64d);}['maxPost'](){const _0x405b49=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x405b49);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x123bef,_0x571555){const _0x2ee826=_0x123bef['node']['compareTo'](_0x571555['node']);return _0x2ee826===0x0?qe(_0x123bef['name'],_0x571555['name']):_0x2ee826;}['isDefinedOn'](_0x57181f){return!0x0;}['indexedValueChanged'](_0x48145b,_0x2e6628){return!_0x48145b['equals'](_0x2e6628);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3666fb,_0x4f6d55){const _0x376799=A(_0x3666fb);return new E(_0x4f6d55,_0x376799);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x26d257){return{'type':'value','snapshotNode':_0x26d257};}function rt(_0x372b8b,_0x21832d){return{'type':'child_added','snapshotNode':_0x21832d,'childName':_0x372b8b};}function Lt(_0x5bf83d,_0x370b0b){return{'type':'child_removed','snapshotNode':_0x370b0b,'childName':_0x5bf83d};}function xt(_0x54a01c,_0x5203ee,_0x22ad9d){return{'type':'child_changed','snapshotNode':_0x5203ee,'childName':_0x54a01c,'oldSnap':_0x22ad9d};}function zh(_0x3716b5,_0x5294f7){return{'type':'child_moved','snapshotNode':_0x5294f7,'childName':_0x3716b5};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x1b4e8b){this['index_']=_0x1b4e8b;}['updateChild'](_0x3eb33b,_0x38cc7e,_0x2a2bf7,_0x44204c,_0xefd7aa,_0x399455){f(_0x3eb33b['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0xcfa3a0=_0x3eb33b['getImmediateChild'](_0x38cc7e);return _0xcfa3a0['getChild'](_0x44204c)['equals'](_0x2a2bf7['getChild'](_0x44204c))&&_0xcfa3a0['isEmpty']()===_0x2a2bf7['isEmpty']()||(_0x399455!=null&&(_0x2a2bf7['isEmpty']()?_0x3eb33b['hasChild'](_0x38cc7e)?_0x399455['trackChildChange'](Lt(_0x38cc7e,_0xcfa3a0)):f(_0x3eb33b['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0xcfa3a0['isEmpty']()?_0x399455['trackChildChange'](rt(_0x38cc7e,_0x2a2bf7)):_0x399455['trackChildChange'](xt(_0x38cc7e,_0x2a2bf7,_0xcfa3a0))),_0x3eb33b['isLeafNode']()&&_0x2a2bf7['isEmpty']())?_0x3eb33b:_0x3eb33b['updateImmediateChild'](_0x38cc7e,_0x2a2bf7)['withIndex'](this['index_']);}['updateFullNode'](_0xcd129a,_0x433ab3,_0x12fcf0){return _0x12fcf0!=null&&(_0xcd129a['isLeafNode']()||_0xcd129a['forEachChild'](R,(_0x27b581,_0x4d87cd)=>{_0x433ab3['hasChild'](_0x27b581)||_0x12fcf0['trackChildChange'](Lt(_0x27b581,_0x4d87cd));}),_0x433ab3['isLeafNode']()||_0x433ab3['forEachChild'](R,(_0x2081f2,_0x2b053c)=>{if(_0xcd129a['hasChild'](_0x2081f2)){const _0x24d0c5=_0xcd129a['getImmediateChild'](_0x2081f2);_0x24d0c5['equals'](_0x2b053c)||_0x12fcf0['trackChildChange'](xt(_0x2081f2,_0x2b053c,_0x24d0c5));}else _0x12fcf0['trackChildChange'](rt(_0x2081f2,_0x2b053c));})),_0x433ab3['withIndex'](this['index_']);}['updatePriority'](_0x5736b2,_0x9c0872){return _0x5736b2['isEmpty']()?g['EMPTY_NODE']:_0x5736b2['updatePriority'](_0x9c0872);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x5d3f4b){this['indexedFilter_']=new Xi(_0x5d3f4b['getIndex']()),this['index_']=_0x5d3f4b['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x5d3f4b),this['endPost_']=Ft['getEndPost_'](_0x5d3f4b),this['startIsInclusive_']=!_0x5d3f4b['startAfterSet_'],this['endIsInclusive_']=!_0x5d3f4b['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x954d32){const _0xc71688=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x954d32)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x954d32)<0x0,_0x2a4c4e=this['endIsInclusive_']?this['index_']['compare'](_0x954d32,this['getEndPost']())<=0x0:this['index_']['compare'](_0x954d32,this['getEndPost']())<0x0;return _0xc71688&&_0x2a4c4e;}['updateChild'](_0x2f1de6,_0x593c79,_0x21882c,_0x4df5c4,_0x1c9a55,_0x25b300){return this['matches'](new E(_0x593c79,_0x21882c))||(_0x21882c=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2f1de6,_0x593c79,_0x21882c,_0x4df5c4,_0x1c9a55,_0x25b300);}['updateFullNode'](_0x44c517,_0xa516f1,_0x4e233d){_0xa516f1['isLeafNode']()&&(_0xa516f1=g['EMPTY_NODE']);let _0x451a83=_0xa516f1['withIndex'](this['index_']);_0x451a83=_0x451a83['updatePriority'](g['EMPTY_NODE']);const _0x999bd=this;return _0xa516f1['forEachChild'](R,(_0x20daf0,_0x103359)=>{_0x999bd['matches'](new E(_0x20daf0,_0x103359))||(_0x451a83=_0x451a83['updateImmediateChild'](_0x20daf0,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x44c517,_0x451a83,_0x4e233d);}['updatePriority'](_0x4a17dd,_0x516e8){return _0x4a17dd;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3cca7a){if(_0x3cca7a['hasStart']()){const _0x22d7cf=_0x3cca7a['getIndexStartName']();return _0x3cca7a['getIndex']()['makePost'](_0x3cca7a['getIndexStartValue'](),_0x22d7cf);}else return _0x3cca7a['getIndex']()['minPost']();}static['getEndPost_'](_0x24f647){if(_0x24f647['hasEnd']()){const _0x43b9d9=_0x24f647['getIndexEndName']();return _0x24f647['getIndex']()['makePost'](_0x24f647['getIndexEndValue'](),_0x43b9d9);}else return _0x24f647['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x36b298){this['withinDirectionalStart']=_0x46d5fe=>this['reverse_']?this['withinEndPost'](_0x46d5fe):this['withinStartPost'](_0x46d5fe),this['withinDirectionalEnd']=_0x1b9518=>this['reverse_']?this['withinStartPost'](_0x1b9518):this['withinEndPost'](_0x1b9518),this['withinStartPost']=_0x229129=>{const _0x518590=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x229129);return this['startIsInclusive_']?_0x518590<=0x0:_0x518590<0x0;},this['withinEndPost']=_0x53d859=>{const _0x1d15de=this['index_']['compare'](_0x53d859,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1d15de<=0x0:_0x1d15de<0x0;},this['rangedFilter_']=new Ft(_0x36b298),this['index_']=_0x36b298['getIndex'](),this['limit_']=_0x36b298['getLimit'](),this['reverse_']=!_0x36b298['isViewFromLeft'](),this['startIsInclusive_']=!_0x36b298['startAfterSet_'],this['endIsInclusive_']=!_0x36b298['endBeforeSet_'];}['updateChild'](_0x4ed9ae,_0x200801,_0x401639,_0x25bd5f,_0x511978,_0x2c37c9){return this['rangedFilter_']['matches'](new E(_0x200801,_0x401639))||(_0x401639=g['EMPTY_NODE']),_0x4ed9ae['getImmediateChild'](_0x200801)['equals'](_0x401639)?_0x4ed9ae:_0x4ed9ae['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x4ed9ae,_0x200801,_0x401639,_0x25bd5f,_0x511978,_0x2c37c9):this['fullLimitUpdateChild_'](_0x4ed9ae,_0x200801,_0x401639,_0x511978,_0x2c37c9);}['updateFullNode'](_0x2fd190,_0x8b0ecc,_0x5ea31a){let _0x35f575;if(_0x8b0ecc['isLeafNode']()||_0x8b0ecc['isEmpty']())_0x35f575=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x8b0ecc['numChildren']()&&_0x8b0ecc['isIndexed'](this['index_'])){_0x35f575=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x21555e;this['reverse_']?_0x21555e=_0x8b0ecc['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x21555e=_0x8b0ecc['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x177cf1=0x0;for(;_0x21555e['hasNext']()&&_0x177cf1<this['limit_'];){const _0x57b153=_0x21555e['getNext']();if(this['withinDirectionalStart'](_0x57b153)){if(this['withinDirectionalEnd'](_0x57b153))_0x35f575=_0x35f575['updateImmediateChild'](_0x57b153['name'],_0x57b153['node']),_0x177cf1++;else break;}else continue;}}else{_0x35f575=_0x8b0ecc['withIndex'](this['index_']),_0x35f575=_0x35f575['updatePriority'](g['EMPTY_NODE']);let _0x43ed59;this['reverse_']?_0x43ed59=_0x35f575['getReverseIterator'](this['index_']):_0x43ed59=_0x35f575['getIterator'](this['index_']);let _0x550648=0x0;for(;_0x43ed59['hasNext']();){const _0x593aa1=_0x43ed59['getNext']();_0x550648<this['limit_']&&this['withinDirectionalStart'](_0x593aa1)&&this['withinDirectionalEnd'](_0x593aa1)?_0x550648++:_0x35f575=_0x35f575['updateImmediateChild'](_0x593aa1['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2fd190,_0x35f575,_0x5ea31a);}['updatePriority'](_0x10e98d,_0x39c6e7){return _0x10e98d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2b6fbd,_0x294ea3,_0x4cb5cb,_0x3cb8d4,_0x3c1f7f){let _0x2f5384;if(this['reverse_']){const _0x2a8c8b=this['index_']['getCompare']();_0x2f5384=(_0x3829d3,_0x1e444b)=>_0x2a8c8b(_0x1e444b,_0x3829d3);}else _0x2f5384=this['index_']['getCompare']();const _0x156a8a=_0x2b6fbd;f(_0x156a8a['numChildren']()===this['limit_'],'');const _0x253c01=new E(_0x294ea3,_0x4cb5cb),_0x1bbcbf=this['reverse_']?_0x156a8a['getFirstChild'](this['index_']):_0x156a8a['getLastChild'](this['index_']),_0x215b5c=this['rangedFilter_']['matches'](_0x253c01);if(_0x156a8a['hasChild'](_0x294ea3)){const _0x1ebe4d=_0x156a8a['getImmediateChild'](_0x294ea3);let _0x356bfe=_0x3cb8d4['getChildAfterChild'](this['index_'],_0x1bbcbf,this['reverse_']);for(;_0x356bfe!=null&&(_0x356bfe['name']===_0x294ea3||_0x156a8a['hasChild'](_0x356bfe['name']));)_0x356bfe=_0x3cb8d4['getChildAfterChild'](this['index_'],_0x356bfe,this['reverse_']);const _0xe0b28b=_0x356bfe==null?0x1:_0x2f5384(_0x356bfe,_0x253c01);if(_0x215b5c&&!_0x4cb5cb['isEmpty']()&&_0xe0b28b>=0x0)return _0x3c1f7f!=null&&_0x3c1f7f['trackChildChange'](xt(_0x294ea3,_0x4cb5cb,_0x1ebe4d)),_0x156a8a['updateImmediateChild'](_0x294ea3,_0x4cb5cb);{_0x3c1f7f!=null&&_0x3c1f7f['trackChildChange'](Lt(_0x294ea3,_0x1ebe4d));const _0x2fb67f=_0x156a8a['updateImmediateChild'](_0x294ea3,g['EMPTY_NODE']);return _0x356bfe!=null&&this['rangedFilter_']['matches'](_0x356bfe)?(_0x3c1f7f!=null&&_0x3c1f7f['trackChildChange'](rt(_0x356bfe['name'],_0x356bfe['node'])),_0x2fb67f['updateImmediateChild'](_0x356bfe['name'],_0x356bfe['node'])):_0x2fb67f;}}else return _0x4cb5cb['isEmpty']()?_0x2b6fbd:_0x215b5c&&_0x2f5384(_0x1bbcbf,_0x253c01)>=0x0?(_0x3c1f7f!=null&&(_0x3c1f7f['trackChildChange'](Lt(_0x1bbcbf['name'],_0x1bbcbf['node'])),_0x3c1f7f['trackChildChange'](rt(_0x294ea3,_0x4cb5cb))),_0x156a8a['updateImmediateChild'](_0x294ea3,_0x4cb5cb)['updateImmediateChild'](_0x1bbcbf['name'],g['EMPTY_NODE'])):_0x2b6fbd;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3b9b1b=new Zi();return _0x3b9b1b['limitSet_']=this['limitSet_'],_0x3b9b1b['limit_']=this['limit_'],_0x3b9b1b['startSet_']=this['startSet_'],_0x3b9b1b['startAfterSet_']=this['startAfterSet_'],_0x3b9b1b['indexStartValue_']=this['indexStartValue_'],_0x3b9b1b['startNameSet_']=this['startNameSet_'],_0x3b9b1b['indexStartName_']=this['indexStartName_'],_0x3b9b1b['endSet_']=this['endSet_'],_0x3b9b1b['endBeforeSet_']=this['endBeforeSet_'],_0x3b9b1b['indexEndValue_']=this['indexEndValue_'],_0x3b9b1b['endNameSet_']=this['endNameSet_'],_0x3b9b1b['indexEndName_']=this['indexEndName_'],_0x3b9b1b['index_']=this['index_'],_0x3b9b1b['viewFrom_']=this['viewFrom_'],_0x3b9b1b;}}function Kh(_0x274dc7){return _0x274dc7['loadsAllData']()?new Xi(_0x274dc7['getIndex']()):_0x274dc7['hasLimit']()?new jh(_0x274dc7):new Ft(_0x274dc7);}function Yh(_0x2943a7,_0x2a5e36){const _0x141ab3=_0x2943a7['copy']();return _0x141ab3['limitSet_']=!0x0,_0x141ab3['limit_']=_0x2a5e36,_0x141ab3['viewFrom_']='l',_0x141ab3;}function Qh(_0x3b27dd,_0x34528c,_0xfcc4ce){const _0x2c26b0=_0x3b27dd['copy']();return _0x2c26b0['startSet_']=!0x0,_0x34528c===void 0x0&&(_0x34528c=null),_0x2c26b0['indexStartValue_']=_0x34528c,_0xfcc4ce!=null?(_0x2c26b0['startNameSet_']=!0x0,_0x2c26b0['indexStartName_']=_0xfcc4ce):(_0x2c26b0['startNameSet_']=!0x1,_0x2c26b0['indexStartName_']=''),_0x2c26b0;}function Jh(_0x44f1a9,_0x1be40b,_0x91bdd0){const _0x3b680f=_0x44f1a9['copy']();return _0x3b680f['endSet_']=!0x0,_0x1be40b===void 0x0&&(_0x1be40b=null),_0x3b680f['indexEndValue_']=_0x1be40b,_0x91bdd0!==void 0x0?(_0x3b680f['endNameSet_']=!0x0,_0x3b680f['indexEndName_']=_0x91bdd0):(_0x3b680f['endNameSet_']=!0x1,_0x3b680f['indexEndName_']=''),_0x3b680f;}function xo(_0x221f68,_0x581c15){const _0x2be084=_0x221f68['copy']();return _0x2be084['index_']=_0x581c15,_0x2be084;}function ir(_0x355195){const _0x19de37={};if(_0x355195['isDefault']())return _0x19de37;let _0x487ef5;if(_0x355195['index_']===R?_0x487ef5='$priority':_0x355195['index_']===Mo?_0x487ef5='$value':_0x355195['index_']===ve?_0x487ef5='$key':(f(_0x355195['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x487ef5=_0x355195['index_']['toString']()),_0x19de37['orderBy']=O(_0x487ef5),_0x355195['startSet_']){const _0x2cec76=_0x355195['startAfterSet_']?'startAfter':'startAt';_0x19de37[_0x2cec76]=O(_0x355195['indexStartValue_']),_0x355195['startNameSet_']&&(_0x19de37[_0x2cec76]+=','+O(_0x355195['indexStartName_']));}if(_0x355195['endSet_']){const _0x2b2d90=_0x355195['endBeforeSet_']?'endBefore':'endAt';_0x19de37[_0x2b2d90]=O(_0x355195['indexEndValue_']),_0x355195['endNameSet_']&&(_0x19de37[_0x2b2d90]+=','+O(_0x355195['indexEndName_']));}return _0x355195['limitSet_']&&(_0x355195['isViewFromLeft']()?_0x19de37['limitToFirst']=_0x355195['limit_']:_0x19de37['limitToLast']=_0x355195['limit_']),_0x19de37;}function sr(_0x52b629){const _0x8562fc={};if(_0x52b629['startSet_']&&(_0x8562fc['sp']=_0x52b629['indexStartValue_'],_0x52b629['startNameSet_']&&(_0x8562fc['sn']=_0x52b629['indexStartName_']),_0x8562fc['sin']=!_0x52b629['startAfterSet_']),_0x52b629['endSet_']&&(_0x8562fc['ep']=_0x52b629['indexEndValue_'],_0x52b629['endNameSet_']&&(_0x8562fc['en']=_0x52b629['indexEndName_']),_0x8562fc['ein']=!_0x52b629['endBeforeSet_']),_0x52b629['limitSet_']){_0x8562fc['l']=_0x52b629['limit_'];let _0x201031=_0x52b629['viewFrom_'];_0x201031===''&&(_0x52b629['isViewFromLeft']()?_0x201031='l':_0x201031='r'),_0x8562fc['vf']=_0x201031;}return _0x52b629['index_']!==R&&(_0x8562fc['i']=_0x52b629['index_']['toString']()),_0x8562fc;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x3318e2){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x2fb3fd,_0x206c59){return _0x206c59!==void 0x0?'tag$'+_0x206c59:(f(_0x2fb3fd['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x2fb3fd['_path']['toString']());}constructor(_0x229550,_0x555506,_0x81b7d1,_0x28b4f9){super(),this['repoInfo_']=_0x229550,this['onDataUpdate_']=_0x555506,this['authTokenProvider_']=_0x81b7d1,this['appCheckTokenProvider_']=_0x28b4f9,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x4e9134,_0x7ed496,_0x2df002,_0x50bead){const _0x1796ce=_0x4e9134['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1796ce+'\x20'+_0x4e9134['_queryIdentifier']);const _0xbd4c02=vn['getListenId_'](_0x4e9134,_0x2df002),_0x59d0d4={};this['listens_'][_0xbd4c02]=_0x59d0d4;const _0x1119dc=ir(_0x4e9134['_queryParams']);this['restRequest_'](_0x1796ce+'.json',_0x1119dc,(_0x5b4276,_0x36487d)=>{let _0x18460e=_0x36487d;if(_0x5b4276===0x194&&(_0x18460e=null,_0x5b4276=null),_0x5b4276===null&&this['onDataUpdate_'](_0x1796ce,_0x18460e,!0x1,_0x2df002),Le(this['listens_'],_0xbd4c02)===_0x59d0d4){let _0x33fc07;_0x5b4276?_0x5b4276===0x191?_0x33fc07='permission_denied':_0x33fc07='rest_error:'+_0x5b4276:_0x33fc07='ok',_0x50bead(_0x33fc07,null);}});}['unlisten'](_0x2661e2,_0x39c173){const _0x5ea3e7=vn['getListenId_'](_0x2661e2,_0x39c173);delete this['listens_'][_0x5ea3e7];}['get'](_0x5a8bd0){const _0xe3d33=ir(_0x5a8bd0['_queryParams']),_0x2c7941=_0x5a8bd0['_path']['toString'](),_0x192c41=new H();return this['restRequest_'](_0x2c7941+'.json',_0xe3d33,(_0x5d89b7,_0x2cbf4e)=>{let _0x30f7b6=_0x2cbf4e;_0x5d89b7===0x194&&(_0x30f7b6=null,_0x5d89b7=null),_0x5d89b7===null?(this['onDataUpdate_'](_0x2c7941,_0x30f7b6,!0x1,null),_0x192c41['resolve'](_0x30f7b6)):_0x192c41['reject'](new Error(_0x30f7b6));}),_0x192c41['promise'];}['refreshAuthToken'](_0x4836f5){}['restRequest_'](_0x53b7c2,_0x579545={},_0x4447c6){return _0x579545['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x321a91,_0x3cd898])=>{_0x321a91&&_0x321a91['accessToken']&&(_0x579545['auth']=_0x321a91['accessToken']),_0x3cd898&&_0x3cd898['token']&&(_0x579545['ac']=_0x3cd898['token']);const _0x3a4058=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x53b7c2+'?ns='+this['repoInfo_']['namespace']+ut(_0x579545);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x3a4058);const _0xc3bd55=new XMLHttpRequest();_0xc3bd55['onreadystatechange']=()=>{if(_0x4447c6&&_0xc3bd55['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x3a4058+'\x20received.\x20status:',_0xc3bd55['status'],'response:',_0xc3bd55['responseText']);let _0x115118=null;if(_0xc3bd55['status']>=0xc8&&_0xc3bd55['status']<0x12c){try{_0x115118=Nt(_0xc3bd55['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x3a4058+':\x20'+_0xc3bd55['responseText']);}_0x4447c6(null,_0x115118);}else _0xc3bd55['status']!==0x191&&_0xc3bd55['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x3a4058+'\x20Status:\x20'+_0xc3bd55['status']),_0x4447c6(_0xc3bd55['status']);_0x4447c6=null;}},_0xc3bd55['open']('GET',_0x3a4058,!0x0),_0xc3bd55['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x259537){return this['rootNode_']['getChild'](_0x259537);}['updateSnapshot'](_0x5bbbea,_0x33b816){this['rootNode_']=this['rootNode_']['updateChild'](_0x5bbbea,_0x33b816);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x2b5f65,_0x4c53a4,_0x31c0e4){if(v(_0x4c53a4))_0x2b5f65['value']=_0x31c0e4,_0x2b5f65['children']['clear']();else{if(_0x2b5f65['value']!==null)_0x2b5f65['value']=_0x2b5f65['value']['updateChild'](_0x4c53a4,_0x31c0e4);else{const _0x378cda=y(_0x4c53a4);_0x2b5f65['children']['has'](_0x378cda)||_0x2b5f65['children']['set'](_0x378cda,En());const _0x263240=_0x2b5f65['children']['get'](_0x378cda);_0x4c53a4=S(_0x4c53a4),pt(_0x263240,_0x4c53a4,_0x31c0e4);}}}function Ti(_0x185dd5,_0x1adcdc){if(v(_0x1adcdc))return _0x185dd5['value']=null,_0x185dd5['children']['clear'](),!0x0;if(_0x185dd5['value']!==null){if(_0x185dd5['value']['isLeafNode']())return!0x1;{const _0x319878=_0x185dd5['value'];return _0x185dd5['value']=null,_0x319878['forEachChild'](R,(_0x5a99ea,_0x303467)=>{pt(_0x185dd5,new C(_0x5a99ea),_0x303467);}),Ti(_0x185dd5,_0x1adcdc);}}else{if(_0x185dd5['children']['size']>0x0){const _0x4997ed=y(_0x1adcdc);return _0x1adcdc=S(_0x1adcdc),_0x185dd5['children']['has'](_0x4997ed)&&Ti(_0x185dd5['children']['get'](_0x4997ed),_0x1adcdc)&&_0x185dd5['children']['delete'](_0x4997ed),_0x185dd5['children']['size']===0x0;}else return!0x0;}}function Si(_0x247a4a,_0xfaac5b,_0x5b4868){_0x247a4a['value']!==null?_0x5b4868(_0xfaac5b,_0x247a4a['value']):Zh(_0x247a4a,(_0x1ed8ef,_0x3366be)=>{const _0x1ec614=new C(_0xfaac5b['toString']()+'/'+_0x1ed8ef);Si(_0x3366be,_0x1ec614,_0x5b4868);});}function Zh(_0x3d643a,_0x4c24c2){_0x3d643a['children']['forEach']((_0x5eb4a5,_0x44a5bc)=>{_0x4c24c2(_0x44a5bc,_0x5eb4a5);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x2dd862){this['collection_']=_0x2dd862,this['last_']=null;}['get'](){const _0xab811d=this['collection_']['get'](),_0x4d438e={..._0xab811d};return this['last_']&&x(this['last_'],(_0x414bf4,_0xca8b7a)=>{_0x4d438e[_0x414bf4]=_0x4d438e[_0x414bf4]-_0xca8b7a;}),this['last_']=_0xab811d,_0x4d438e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x5f2e3d,_0x56c830){this['server_']=_0x56c830,this['statsToReport_']={},this['statsListener_']=new eu(_0x5f2e3d);const _0x445f6b=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x445f6b));}['reportStats_'](){const _0x831dcf=this['statsListener_']['get'](),_0x59fc56={};let _0x395989=!0x1;x(_0x831dcf,(_0x177da5,_0x468318)=>{_0x468318>0x0&&Q(this['statsToReport_'],_0x177da5)&&(_0x59fc56[_0x177da5]=_0x468318,_0x395989=!0x0);}),_0x395989&&this['server_']['reportStats'](_0x59fc56),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x234b39){_0x234b39[_0x234b39['OVERWRITE']=0x0]='OVERWRITE',_0x234b39[_0x234b39['MERGE']=0x1]='MERGE',_0x234b39[_0x234b39['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x234b39[_0x234b39['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x5124a5){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x5124a5,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x397b13,_0x2018e6,_0x1a7002){this['path']=_0x397b13,this['affectedTree']=_0x2018e6,this['revert']=_0x1a7002,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x4fbde8){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2a8bfd=this['affectedTree']['subtree'](new C(_0x4fbde8));return new In(w(),_0x2a8bfd,this['revert']);}}else return f(y(this['path'])===_0x4fbde8,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x2b615e,_0x2af705){this['source']=_0x2b615e,this['path']=_0x2af705,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x469239){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x4f4a66,_0x44911c,_0x154ca4){this['source']=_0x4f4a66,this['path']=_0x44911c,this['snap']=_0x154ca4,this['type']=z['OVERWRITE'];}['operationForChild'](_0x4c2536){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x4c2536)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x9d0ce6,_0x3f6631,_0x201097){this['source']=_0x9d0ce6,this['path']=_0x3f6631,this['children']=_0x201097,this['type']=z['MERGE'];}['operationForChild'](_0x26b9fa){if(v(this['path'])){const _0x1d8004=this['children']['subtree'](new C(_0x26b9fa));return _0x1d8004['isEmpty']()?null:_0x1d8004['value']?new Be(this['source'],w(),_0x1d8004['value']):new ot(this['source'],w(),_0x1d8004);}else return f(y(this['path'])===_0x26b9fa,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x579f28,_0x133f2e,_0x182a9f){this['node_']=_0x579f28,this['fullyInitialized_']=_0x133f2e,this['filtered_']=_0x182a9f;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x9e9d66){if(v(_0x9e9d66))return this['isFullyInitialized']()&&!this['filtered_'];const _0x154d76=y(_0x9e9d66);return this['isCompleteForChild'](_0x154d76);}['isCompleteForChild'](_0x345263){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x345263);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0xafa4c0){this['query_']=_0xafa4c0,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x1e09ec,_0x41805b,_0x29760b,_0x4cb906){const _0x1135e7=[],_0x45bcf9=[];return _0x41805b['forEach'](_0x2c8624=>{_0x2c8624['type']==='child_changed'&&_0x1e09ec['index_']['indexedValueChanged'](_0x2c8624['oldSnap'],_0x2c8624['snapshotNode'])&&_0x45bcf9['push'](zh(_0x2c8624['childName'],_0x2c8624['snapshotNode']));}),wt(_0x1e09ec,_0x1135e7,'child_removed',_0x41805b,_0x4cb906,_0x29760b),wt(_0x1e09ec,_0x1135e7,'child_added',_0x41805b,_0x4cb906,_0x29760b),wt(_0x1e09ec,_0x1135e7,'child_moved',_0x45bcf9,_0x4cb906,_0x29760b),wt(_0x1e09ec,_0x1135e7,'child_changed',_0x41805b,_0x4cb906,_0x29760b),wt(_0x1e09ec,_0x1135e7,'value',_0x41805b,_0x4cb906,_0x29760b),_0x1135e7;}function wt(_0x52af2d,_0xbc18d1,_0x38b57f,_0x54d400,_0x335098,_0x7e317e){const _0x3091e7=_0x54d400['filter'](_0x453de4=>_0x453de4['type']===_0x38b57f);_0x3091e7['sort']((_0x4487ed,_0x360b85)=>au(_0x52af2d,_0x4487ed,_0x360b85)),_0x3091e7['forEach'](_0xe71e8d=>{const _0x53beaa=ou(_0x52af2d,_0xe71e8d,_0x7e317e);_0x335098['forEach'](_0x353d21=>{_0x353d21['respondsTo'](_0xe71e8d['type'])&&_0xbc18d1['push'](_0x353d21['createEvent'](_0x53beaa,_0x52af2d['query_']));});});}function ou(_0x9be5a6,_0x412ac9,_0x1eb123){return _0x412ac9['type']==='value'||_0x412ac9['type']==='child_removed'||(_0x412ac9['prevName']=_0x1eb123['getPredecessorChildName'](_0x412ac9['childName'],_0x412ac9['snapshotNode'],_0x9be5a6['index_'])),_0x412ac9;}function au(_0x3754ce,_0x1510bf,_0x16cde5){if(_0x1510bf['childName']==null||_0x16cde5['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1c336f=new E(_0x1510bf['childName'],_0x1510bf['snapshotNode']),_0x41cdcf=new E(_0x16cde5['childName'],_0x16cde5['snapshotNode']);return _0x3754ce['index_']['compare'](_0x1c336f,_0x41cdcf);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x4c40e0,_0x516df0){return{'eventCache':_0x4c40e0,'serverCache':_0x516df0};}function Rt(_0x59d05f,_0x14bbe0,_0x4d7756,_0x22e8b1){return Un(new Te(_0x14bbe0,_0x4d7756,_0x22e8b1),_0x59d05f['serverCache']);}function Fo(_0x2ce579,_0x4886a2,_0x3dfc04,_0x4c32d9){return Un(_0x2ce579['eventCache'],new Te(_0x4886a2,_0x3dfc04,_0x4c32d9));}function wn(_0x2bd6cd){return _0x2bd6cd['eventCache']['isFullyInitialized']()?_0x2bd6cd['eventCache']['getNode']():null;}function Ve(_0x2be6d0){return _0x2be6d0['serverCache']['isFullyInitialized']()?_0x2be6d0['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x56f8ec){let _0x3cac2f=new b(null);return x(_0x56f8ec,(_0x14560f,_0x403213)=>{_0x3cac2f=_0x3cac2f['set'](new C(_0x14560f),_0x403213);}),_0x3cac2f;}constructor(_0x277b9c,_0x13c77b=cu()){this['value']=_0x277b9c,this['children']=_0x13c77b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2ca1f2,_0x157e4b){if(this['value']!=null&&_0x157e4b(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2ca1f2))return null;{const _0x218d3e=y(_0x2ca1f2),_0x329701=this['children']['get'](_0x218d3e);if(_0x329701!==null){const _0x137dc6=_0x329701['findRootMostMatchingPathAndValue'](S(_0x2ca1f2),_0x157e4b);return _0x137dc6!=null?{'path':k(new C(_0x218d3e),_0x137dc6['path']),'value':_0x137dc6['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xd784ce){return this['findRootMostMatchingPathAndValue'](_0xd784ce,()=>!0x0);}['subtree'](_0x521426){if(v(_0x521426))return this;{const _0x1d712e=y(_0x521426),_0x1272f5=this['children']['get'](_0x1d712e);return _0x1272f5!==null?_0x1272f5['subtree'](S(_0x521426)):new b(null);}}['set'](_0x49afa6,_0x387bc9){if(v(_0x49afa6))return new b(_0x387bc9,this['children']);{const _0x80b96b=y(_0x49afa6),_0x7b66a9=(this['children']['get'](_0x80b96b)||new b(null))['set'](S(_0x49afa6),_0x387bc9),_0x4d415b=this['children']['insert'](_0x80b96b,_0x7b66a9);return new b(this['value'],_0x4d415b);}}['remove'](_0x5d1045){if(v(_0x5d1045))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x5530f3=y(_0x5d1045),_0x4b18f8=this['children']['get'](_0x5530f3);if(_0x4b18f8){const _0x24039b=_0x4b18f8['remove'](S(_0x5d1045));let _0x1c2459;return _0x24039b['isEmpty']()?_0x1c2459=this['children']['remove'](_0x5530f3):_0x1c2459=this['children']['insert'](_0x5530f3,_0x24039b),this['value']===null&&_0x1c2459['isEmpty']()?new b(null):new b(this['value'],_0x1c2459);}else return this;}}['get'](_0x595b10){if(v(_0x595b10))return this['value'];{const _0x342f1b=y(_0x595b10),_0x2c5348=this['children']['get'](_0x342f1b);return _0x2c5348?_0x2c5348['get'](S(_0x595b10)):null;}}['setTree'](_0x311e46,_0x4b5d96){if(v(_0x311e46))return _0x4b5d96;{const _0x3821aa=y(_0x311e46),_0x5f0a16=(this['children']['get'](_0x3821aa)||new b(null))['setTree'](S(_0x311e46),_0x4b5d96);let _0x426b96;return _0x5f0a16['isEmpty']()?_0x426b96=this['children']['remove'](_0x3821aa):_0x426b96=this['children']['insert'](_0x3821aa,_0x5f0a16),new b(this['value'],_0x426b96);}}['fold'](_0x468da4){return this['fold_'](w(),_0x468da4);}['fold_'](_0x5d7c7e,_0x1e7fb6){const _0x1f6450={};return this['children']['inorderTraversal']((_0x50900b,_0x580a83)=>{_0x1f6450[_0x50900b]=_0x580a83['fold_'](k(_0x5d7c7e,_0x50900b),_0x1e7fb6);}),_0x1e7fb6(_0x5d7c7e,this['value'],_0x1f6450);}['findOnPath'](_0x1fd346,_0x24c746){return this['findOnPath_'](_0x1fd346,w(),_0x24c746);}['findOnPath_'](_0x264ffc,_0x5680ad,_0x3a3fc6){const _0x2b1629=this['value']?_0x3a3fc6(_0x5680ad,this['value']):!0x1;if(_0x2b1629)return _0x2b1629;if(v(_0x264ffc))return null;{const _0x51d018=y(_0x264ffc),_0x21b063=this['children']['get'](_0x51d018);return _0x21b063?_0x21b063['findOnPath_'](S(_0x264ffc),k(_0x5680ad,_0x51d018),_0x3a3fc6):null;}}['foreachOnPath'](_0x54d880,_0x5a076d){return this['foreachOnPath_'](_0x54d880,w(),_0x5a076d);}['foreachOnPath_'](_0x293255,_0x148719,_0x29cc33){if(v(_0x293255))return this;{this['value']&&_0x29cc33(_0x148719,this['value']);const _0x4aacd4=y(_0x293255),_0x259a02=this['children']['get'](_0x4aacd4);return _0x259a02?_0x259a02['foreachOnPath_'](S(_0x293255),k(_0x148719,_0x4aacd4),_0x29cc33):new b(null);}}['foreach'](_0x1a5922){this['foreach_'](w(),_0x1a5922);}['foreach_'](_0x1f6886,_0xc715ac){this['children']['inorderTraversal']((_0x4b6e14,_0x3d4f90)=>{_0x3d4f90['foreach_'](k(_0x1f6886,_0x4b6e14),_0xc715ac);}),this['value']&&_0xc715ac(_0x1f6886,this['value']);}['foreachChild'](_0x4f09cb){this['children']['inorderTraversal']((_0x29c70b,_0x51dc8b)=>{_0x51dc8b['value']&&_0x4f09cb(_0x29c70b,_0x51dc8b['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x3e3b4c){this['writeTree_']=_0x3e3b4c;}static['empty'](){return new K(new b(null));}}function At(_0x368dbf,_0x4a85c1,_0x2e4e7f){if(v(_0x4a85c1))return new K(new b(_0x2e4e7f));{const _0x57ce13=_0x368dbf['writeTree_']['findRootMostValueAndPath'](_0x4a85c1);if(_0x57ce13!=null){const _0xbd2b6b=_0x57ce13['path'];let _0x26d4c0=_0x57ce13['value'];const _0x2af8d5=F(_0xbd2b6b,_0x4a85c1);return _0x26d4c0=_0x26d4c0['updateChild'](_0x2af8d5,_0x2e4e7f),new K(_0x368dbf['writeTree_']['set'](_0xbd2b6b,_0x26d4c0));}else{const _0x4a702b=new b(_0x2e4e7f),_0x3670ef=_0x368dbf['writeTree_']['setTree'](_0x4a85c1,_0x4a702b);return new K(_0x3670ef);}}}function bi(_0x4de028,_0x75e91c,_0x2c6b98){let _0x5f47a1=_0x4de028;return x(_0x2c6b98,(_0x4952c5,_0x2baef8)=>{_0x5f47a1=At(_0x5f47a1,k(_0x75e91c,_0x4952c5),_0x2baef8);}),_0x5f47a1;}function or(_0x48ec0f,_0x476fa4){if(v(_0x476fa4))return K['empty']();{const _0x1c154e=_0x48ec0f['writeTree_']['setTree'](_0x476fa4,new b(null));return new K(_0x1c154e);}}function Ri(_0x3cc74d,_0x4405ed){return ze(_0x3cc74d,_0x4405ed)!=null;}function ze(_0x5c65ab,_0x4cd856){const _0x4da99f=_0x5c65ab['writeTree_']['findRootMostValueAndPath'](_0x4cd856);return _0x4da99f!=null?_0x5c65ab['writeTree_']['get'](_0x4da99f['path'])['getChild'](F(_0x4da99f['path'],_0x4cd856)):null;}function ar(_0x4961c5){const _0x12e452=[],_0x43b8dc=_0x4961c5['writeTree_']['value'];return _0x43b8dc!=null?_0x43b8dc['isLeafNode']()||_0x43b8dc['forEachChild'](R,(_0x3f3b75,_0x555ad3)=>{_0x12e452['push'](new E(_0x3f3b75,_0x555ad3));}):_0x4961c5['writeTree_']['children']['inorderTraversal']((_0x48a627,_0x532f8d)=>{_0x532f8d['value']!=null&&_0x12e452['push'](new E(_0x48a627,_0x532f8d['value']));}),_0x12e452;}function Ee(_0x110649,_0x30bae3){if(v(_0x30bae3))return _0x110649;{const _0x4674ff=ze(_0x110649,_0x30bae3);return _0x4674ff!=null?new K(new b(_0x4674ff)):new K(_0x110649['writeTree_']['subtree'](_0x30bae3));}}function Ai(_0x5353fa){return _0x5353fa['writeTree_']['isEmpty']();}function at(_0x38a1bb,_0x40a33e){return Uo(w(),_0x38a1bb['writeTree_'],_0x40a33e);}function Uo(_0x1ba4dd,_0xc9417b,_0x5e3a14){if(_0xc9417b['value']!=null)return _0x5e3a14['updateChild'](_0x1ba4dd,_0xc9417b['value']);{let _0x5d140d=null;return _0xc9417b['children']['inorderTraversal']((_0x15e5ea,_0x148fa2)=>{_0x15e5ea==='.priority'?(f(_0x148fa2['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5d140d=_0x148fa2['value']):_0x5e3a14=Uo(k(_0x1ba4dd,_0x15e5ea),_0x148fa2,_0x5e3a14);}),!_0x5e3a14['getChild'](_0x1ba4dd)['isEmpty']()&&_0x5d140d!==null&&(_0x5e3a14=_0x5e3a14['updateChild'](k(_0x1ba4dd,'.priority'),_0x5d140d)),_0x5e3a14;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x5a6f8d,_0x46b11f){return Ho(_0x46b11f,_0x5a6f8d);}function lu(_0x505b69,_0x234883,_0x13da88,_0x1ad741,_0xe521df){f(_0x1ad741>_0x505b69['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0xe521df===void 0x0&&(_0xe521df=!0x0),_0x505b69['allWrites']['push']({'path':_0x234883,'snap':_0x13da88,'writeId':_0x1ad741,'visible':_0xe521df}),_0xe521df&&(_0x505b69['visibleWrites']=At(_0x505b69['visibleWrites'],_0x234883,_0x13da88)),_0x505b69['lastWriteId']=_0x1ad741;}function hu(_0x39a013,_0xba291e,_0x55205e,_0x5981d2){f(_0x5981d2>_0x39a013['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x39a013['allWrites']['push']({'path':_0xba291e,'children':_0x55205e,'writeId':_0x5981d2,'visible':!0x0}),_0x39a013['visibleWrites']=bi(_0x39a013['visibleWrites'],_0xba291e,_0x55205e),_0x39a013['lastWriteId']=_0x5981d2;}function uu(_0x4f7957,_0x4bf763){for(let _0x4d85fd=0x0;_0x4d85fd<_0x4f7957['allWrites']['length'];_0x4d85fd++){const _0xe4ab7d=_0x4f7957['allWrites'][_0x4d85fd];if(_0xe4ab7d['writeId']===_0x4bf763)return _0xe4ab7d;}return null;}function du(_0x4d72e9,_0x5158f8){const _0xfefa63=_0x4d72e9['allWrites']['findIndex'](_0x3fe4aa=>_0x3fe4aa['writeId']===_0x5158f8);f(_0xfefa63>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x3afb21=_0x4d72e9['allWrites'][_0xfefa63];_0x4d72e9['allWrites']['splice'](_0xfefa63,0x1);let _0xee9001=_0x3afb21['visible'],_0x38cf80=!0x1,_0x48e79e=_0x4d72e9['allWrites']['length']-0x1;for(;_0xee9001&&_0x48e79e>=0x0;){const _0x3456ce=_0x4d72e9['allWrites'][_0x48e79e];_0x3456ce['visible']&&(_0x48e79e>=_0xfefa63&&fu(_0x3456ce,_0x3afb21['path'])?_0xee9001=!0x1:G(_0x3afb21['path'],_0x3456ce['path'])&&(_0x38cf80=!0x0)),_0x48e79e--;}if(_0xee9001){if(_0x38cf80)return pu(_0x4d72e9),!0x0;if(_0x3afb21['snap'])_0x4d72e9['visibleWrites']=or(_0x4d72e9['visibleWrites'],_0x3afb21['path']);else{const _0x175154=_0x3afb21['children'];x(_0x175154,_0x8e6165=>{_0x4d72e9['visibleWrites']=or(_0x4d72e9['visibleWrites'],k(_0x3afb21['path'],_0x8e6165));});}return!0x0;}else return!0x1;}function fu(_0xa10aa0,_0x5a47e5){if(_0xa10aa0['snap'])return G(_0xa10aa0['path'],_0x5a47e5);for(const _0xbfd613 in _0xa10aa0['children'])if(_0xa10aa0['children']['hasOwnProperty'](_0xbfd613)&&G(k(_0xa10aa0['path'],_0xbfd613),_0x5a47e5))return!0x0;return!0x1;}function pu(_0x2546bf){_0x2546bf['visibleWrites']=Wo(_0x2546bf['allWrites'],_u,w()),_0x2546bf['allWrites']['length']>0x0?_0x2546bf['lastWriteId']=_0x2546bf['allWrites'][_0x2546bf['allWrites']['length']-0x1]['writeId']:_0x2546bf['lastWriteId']=-0x1;}function _u(_0x43122f){return _0x43122f['visible'];}function Wo(_0x3bb30e,_0x5aa676,_0x2b8296){let _0x48c3bb=K['empty']();for(let _0x492e62=0x0;_0x492e62<_0x3bb30e['length'];++_0x492e62){const _0x4d1c00=_0x3bb30e[_0x492e62];if(_0x5aa676(_0x4d1c00)){const _0x32feb8=_0x4d1c00['path'];let _0x4bce48;if(_0x4d1c00['snap'])G(_0x2b8296,_0x32feb8)?(_0x4bce48=F(_0x2b8296,_0x32feb8),_0x48c3bb=At(_0x48c3bb,_0x4bce48,_0x4d1c00['snap'])):G(_0x32feb8,_0x2b8296)&&(_0x4bce48=F(_0x32feb8,_0x2b8296),_0x48c3bb=At(_0x48c3bb,w(),_0x4d1c00['snap']['getChild'](_0x4bce48)));else{if(_0x4d1c00['children']){if(G(_0x2b8296,_0x32feb8))_0x4bce48=F(_0x2b8296,_0x32feb8),_0x48c3bb=bi(_0x48c3bb,_0x4bce48,_0x4d1c00['children']);else{if(G(_0x32feb8,_0x2b8296)){if(_0x4bce48=F(_0x32feb8,_0x2b8296),v(_0x4bce48))_0x48c3bb=bi(_0x48c3bb,w(),_0x4d1c00['children']);else{const _0x5006fa=Le(_0x4d1c00['children'],y(_0x4bce48));if(_0x5006fa){const _0x24c63e=_0x5006fa['getChild'](S(_0x4bce48));_0x48c3bb=At(_0x48c3bb,w(),_0x24c63e);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x48c3bb;}function Bo(_0x285359,_0x56babf,_0x3fe925,_0x2b3473,_0x1b64ed){if(!_0x2b3473&&!_0x1b64ed){const _0x448f64=ze(_0x285359['visibleWrites'],_0x56babf);if(_0x448f64!=null)return _0x448f64;{const _0x39d3a8=Ee(_0x285359['visibleWrites'],_0x56babf);if(Ai(_0x39d3a8))return _0x3fe925;if(_0x3fe925==null&&!Ri(_0x39d3a8,w()))return null;{const _0x4a901b=_0x3fe925||g['EMPTY_NODE'];return at(_0x39d3a8,_0x4a901b);}}}else{const _0xd595ae=Ee(_0x285359['visibleWrites'],_0x56babf);if(!_0x1b64ed&&Ai(_0xd595ae))return _0x3fe925;if(!_0x1b64ed&&_0x3fe925==null&&!Ri(_0xd595ae,w()))return null;{const _0x15ea50=function(_0x16ecf8){return(_0x16ecf8['visible']||_0x1b64ed)&&(!_0x2b3473||!~_0x2b3473['indexOf'](_0x16ecf8['writeId']))&&(G(_0x16ecf8['path'],_0x56babf)||G(_0x56babf,_0x16ecf8['path']));},_0x27f5b1=Wo(_0x285359['allWrites'],_0x15ea50,_0x56babf),_0x1917a4=_0x3fe925||g['EMPTY_NODE'];return at(_0x27f5b1,_0x1917a4);}}}function gu(_0x108c6d,_0x23e5f9,_0x1759f0){let _0x466c3a=g['EMPTY_NODE'];const _0xf98e3c=ze(_0x108c6d['visibleWrites'],_0x23e5f9);if(_0xf98e3c)return _0xf98e3c['isLeafNode']()||_0xf98e3c['forEachChild'](R,(_0x171652,_0x5f357d)=>{_0x466c3a=_0x466c3a['updateImmediateChild'](_0x171652,_0x5f357d);}),_0x466c3a;if(_0x1759f0){const _0x34c6b8=Ee(_0x108c6d['visibleWrites'],_0x23e5f9);return _0x1759f0['forEachChild'](R,(_0x4aed19,_0x585474)=>{const _0x2664e0=at(Ee(_0x34c6b8,new C(_0x4aed19)),_0x585474);_0x466c3a=_0x466c3a['updateImmediateChild'](_0x4aed19,_0x2664e0);}),ar(_0x34c6b8)['forEach'](_0x2bad4c=>{_0x466c3a=_0x466c3a['updateImmediateChild'](_0x2bad4c['name'],_0x2bad4c['node']);}),_0x466c3a;}else{const _0x4c9e26=Ee(_0x108c6d['visibleWrites'],_0x23e5f9);return ar(_0x4c9e26)['forEach'](_0x2c964b=>{_0x466c3a=_0x466c3a['updateImmediateChild'](_0x2c964b['name'],_0x2c964b['node']);}),_0x466c3a;}}function mu(_0x185042,_0x47158e,_0x4874c4,_0x1cd786,_0x292d71){f(_0x1cd786||_0x292d71,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x398c98=k(_0x47158e,_0x4874c4);if(Ri(_0x185042['visibleWrites'],_0x398c98))return null;{const _0x15eaf3=Ee(_0x185042['visibleWrites'],_0x398c98);return Ai(_0x15eaf3)?_0x292d71['getChild'](_0x4874c4):at(_0x15eaf3,_0x292d71['getChild'](_0x4874c4));}}function yu(_0x4f6f24,_0x3d5906,_0x399fa8,_0x4c30d0){const _0x454465=k(_0x3d5906,_0x399fa8),_0xded58f=ze(_0x4f6f24['visibleWrites'],_0x454465);if(_0xded58f!=null)return _0xded58f;if(_0x4c30d0['isCompleteForChild'](_0x399fa8)){const _0xf1c03c=Ee(_0x4f6f24['visibleWrites'],_0x454465);return at(_0xf1c03c,_0x4c30d0['getNode']()['getImmediateChild'](_0x399fa8));}else return null;}function vu(_0x31aa94,_0x5269d3){return ze(_0x31aa94['visibleWrites'],_0x5269d3);}function Eu(_0x5db5b4,_0x1bbcc7,_0x4777e9,_0x27c572,_0x2a66e1,_0x1ec30c,_0x4a400b){let _0x379933;const _0x27df30=Ee(_0x5db5b4['visibleWrites'],_0x1bbcc7),_0x522c91=ze(_0x27df30,w());if(_0x522c91!=null)_0x379933=_0x522c91;else{if(_0x4777e9!=null)_0x379933=at(_0x27df30,_0x4777e9);else return[];}if(_0x379933=_0x379933['withIndex'](_0x4a400b),!_0x379933['isEmpty']()&&!_0x379933['isLeafNode']()){const _0x56ac13=[],_0x5a783d=_0x4a400b['getCompare'](),_0x22bdaa=_0x1ec30c?_0x379933['getReverseIteratorFrom'](_0x27c572,_0x4a400b):_0x379933['getIteratorFrom'](_0x27c572,_0x4a400b);let _0x527227=_0x22bdaa['getNext']();for(;_0x527227&&_0x56ac13['length']<_0x2a66e1;)_0x5a783d(_0x527227,_0x27c572)!==0x0&&_0x56ac13['push'](_0x527227),_0x527227=_0x22bdaa['getNext']();return _0x56ac13;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x835eb1,_0x419f9c,_0x5ce2aa,_0x4368d9){return Bo(_0x835eb1['writeTree'],_0x835eb1['treePath'],_0x419f9c,_0x5ce2aa,_0x4368d9);}function is(_0x2ebdcc,_0x37b807){return gu(_0x2ebdcc['writeTree'],_0x2ebdcc['treePath'],_0x37b807);}function cr(_0x4e3cad,_0x21ca0a,_0x5a3494,_0x49279b){return mu(_0x4e3cad['writeTree'],_0x4e3cad['treePath'],_0x21ca0a,_0x5a3494,_0x49279b);}function Tn(_0x1c178d,_0x22f7ae){return vu(_0x1c178d['writeTree'],k(_0x1c178d['treePath'],_0x22f7ae));}function wu(_0x2061df,_0x50bfce,_0x183c6d,_0x130603,_0x4dc599,_0x5ead53){return Eu(_0x2061df['writeTree'],_0x2061df['treePath'],_0x50bfce,_0x183c6d,_0x130603,_0x4dc599,_0x5ead53);}function ss(_0x396baa,_0x446d9e,_0x114656){return yu(_0x396baa['writeTree'],_0x396baa['treePath'],_0x446d9e,_0x114656);}function Vo(_0x3cd909,_0x397401){return Ho(k(_0x3cd909['treePath'],_0x397401),_0x3cd909['writeTree']);}function Ho(_0xc438df,_0x1780c9){return{'treePath':_0xc438df,'writeTree':_0x1780c9};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3b8012){const _0x4c8fa6=_0x3b8012['type'],_0x5be53e=_0x3b8012['childName'];f(_0x4c8fa6==='child_added'||_0x4c8fa6==='child_changed'||_0x4c8fa6==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5be53e!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3cdeb5=this['changeMap']['get'](_0x5be53e);if(_0x3cdeb5){const _0x2df36b=_0x3cdeb5['type'];if(_0x4c8fa6==='child_added'&&_0x2df36b==='child_removed')this['changeMap']['set'](_0x5be53e,xt(_0x5be53e,_0x3b8012['snapshotNode'],_0x3cdeb5['snapshotNode']));else{if(_0x4c8fa6==='child_removed'&&_0x2df36b==='child_added')this['changeMap']['delete'](_0x5be53e);else{if(_0x4c8fa6==='child_removed'&&_0x2df36b==='child_changed')this['changeMap']['set'](_0x5be53e,Lt(_0x5be53e,_0x3cdeb5['oldSnap']));else{if(_0x4c8fa6==='child_changed'&&_0x2df36b==='child_added')this['changeMap']['set'](_0x5be53e,rt(_0x5be53e,_0x3b8012['snapshotNode']));else{if(_0x4c8fa6==='child_changed'&&_0x2df36b==='child_changed')this['changeMap']['set'](_0x5be53e,xt(_0x5be53e,_0x3b8012['snapshotNode'],_0x3cdeb5['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x3b8012+'\x20occurred\x20after\x20'+_0x3cdeb5);}}}}}else this['changeMap']['set'](_0x5be53e,_0x3b8012);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x144b2d){return null;}['getChildAfterChild'](_0x545bd2,_0x186a1b,_0x131656){return null;}}const $o=new Tu();class rs{constructor(_0x1cbf6a,_0x114d68,_0x23813e=null){this['writes_']=_0x1cbf6a,this['viewCache_']=_0x114d68,this['optCompleteServerCache_']=_0x23813e;}['getCompleteChild'](_0x166a25){const _0x452e15=this['viewCache_']['eventCache'];if(_0x452e15['isCompleteForChild'](_0x166a25))return _0x452e15['getNode']()['getImmediateChild'](_0x166a25);{const _0x4c7b01=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x166a25,_0x4c7b01);}}['getChildAfterChild'](_0x60db84,_0x5be766,_0x43f2fa){const _0x558dcb=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x1046e6=wu(this['writes_'],_0x558dcb,_0x5be766,0x1,_0x43f2fa,_0x60db84);return _0x1046e6['length']===0x0?null:_0x1046e6[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x236b30){return{'filter':_0x236b30};}function bu(_0x440d3f,_0x46d1f7){f(_0x46d1f7['eventCache']['getNode']()['isIndexed'](_0x440d3f['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x46d1f7['serverCache']['getNode']()['isIndexed'](_0x440d3f['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x5cdf05,_0x58befb,_0x3d9d43,_0x3144fa,_0x429157){const _0x4c7dab=new Cu();let _0x4cf2e1,_0x2e69ef;if(_0x3d9d43['type']===z['OVERWRITE']){const _0x38bbb0=_0x3d9d43;_0x38bbb0['source']['fromUser']?_0x4cf2e1=ki(_0x5cdf05,_0x58befb,_0x38bbb0['path'],_0x38bbb0['snap'],_0x3144fa,_0x429157,_0x4c7dab):(f(_0x38bbb0['source']['fromServer'],'Unknown\x20source.'),_0x2e69ef=_0x38bbb0['source']['tagged']||_0x58befb['serverCache']['isFiltered']()&&!v(_0x38bbb0['path']),_0x4cf2e1=Sn(_0x5cdf05,_0x58befb,_0x38bbb0['path'],_0x38bbb0['snap'],_0x3144fa,_0x429157,_0x2e69ef,_0x4c7dab));}else{if(_0x3d9d43['type']===z['MERGE']){const _0x3c6f52=_0x3d9d43;_0x3c6f52['source']['fromUser']?_0x4cf2e1=ku(_0x5cdf05,_0x58befb,_0x3c6f52['path'],_0x3c6f52['children'],_0x3144fa,_0x429157,_0x4c7dab):(f(_0x3c6f52['source']['fromServer'],'Unknown\x20source.'),_0x2e69ef=_0x3c6f52['source']['tagged']||_0x58befb['serverCache']['isFiltered'](),_0x4cf2e1=Pi(_0x5cdf05,_0x58befb,_0x3c6f52['path'],_0x3c6f52['children'],_0x3144fa,_0x429157,_0x2e69ef,_0x4c7dab));}else{if(_0x3d9d43['type']===z['ACK_USER_WRITE']){const _0xdb6396=_0x3d9d43;_0xdb6396['revert']?_0x4cf2e1=Ou(_0x5cdf05,_0x58befb,_0xdb6396['path'],_0x3144fa,_0x429157,_0x4c7dab):_0x4cf2e1=Pu(_0x5cdf05,_0x58befb,_0xdb6396['path'],_0xdb6396['affectedTree'],_0x3144fa,_0x429157,_0x4c7dab);}else{if(_0x3d9d43['type']===z['LISTEN_COMPLETE'])_0x4cf2e1=Nu(_0x5cdf05,_0x58befb,_0x3d9d43['path'],_0x3144fa,_0x4c7dab);else throw ht('Unknown\x20operation\x20type:\x20'+_0x3d9d43['type']);}}}const _0x1678ff=_0x4c7dab['getChanges']();return Au(_0x58befb,_0x4cf2e1,_0x1678ff),{'viewCache':_0x4cf2e1,'changes':_0x1678ff};}function Au(_0x1b63be,_0x12700c,_0x56e149){const _0x22b171=_0x12700c['eventCache'];if(_0x22b171['isFullyInitialized']()){const _0x53e690=_0x22b171['getNode']()['isLeafNode']()||_0x22b171['getNode']()['isEmpty'](),_0xb6b39a=wn(_0x1b63be);(_0x56e149['length']>0x0||!_0x1b63be['eventCache']['isFullyInitialized']()||_0x53e690&&!_0x22b171['getNode']()['equals'](_0xb6b39a)||!_0x22b171['getNode']()['getPriority']()['equals'](_0xb6b39a['getPriority']()))&&_0x56e149['push'](Lo(wn(_0x12700c)));}}function Go(_0x27243a,_0x44828f,_0x456b8b,_0x5eda4f,_0x5f2abb,_0x1e7f58){const _0x3ef34c=_0x44828f['eventCache'];if(Tn(_0x5eda4f,_0x456b8b)!=null)return _0x44828f;{let _0x1c152a,_0x231fa8;if(v(_0x456b8b)){if(f(_0x44828f['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x44828f['serverCache']['isFiltered']()){const _0x112af6=Ve(_0x44828f),_0x41baab=_0x112af6 instanceof g?_0x112af6:g['EMPTY_NODE'],_0x25150b=is(_0x5eda4f,_0x41baab);_0x1c152a=_0x27243a['filter']['updateFullNode'](_0x44828f['eventCache']['getNode'](),_0x25150b,_0x1e7f58);}else{const _0x5d81ae=Cn(_0x5eda4f,Ve(_0x44828f));_0x1c152a=_0x27243a['filter']['updateFullNode'](_0x44828f['eventCache']['getNode'](),_0x5d81ae,_0x1e7f58);}}else{const _0x2cfe51=y(_0x456b8b);if(_0x2cfe51==='.priority'){f(Ce(_0x456b8b)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3c6282=_0x3ef34c['getNode']();_0x231fa8=_0x44828f['serverCache']['getNode']();const _0x5d947e=cr(_0x5eda4f,_0x456b8b,_0x3c6282,_0x231fa8);_0x5d947e!=null?_0x1c152a=_0x27243a['filter']['updatePriority'](_0x3c6282,_0x5d947e):_0x1c152a=_0x3ef34c['getNode']();}else{const _0x43d502=S(_0x456b8b);let _0x6e9f3d;if(_0x3ef34c['isCompleteForChild'](_0x2cfe51)){_0x231fa8=_0x44828f['serverCache']['getNode']();const _0x177bbc=cr(_0x5eda4f,_0x456b8b,_0x3ef34c['getNode'](),_0x231fa8);_0x177bbc!=null?_0x6e9f3d=_0x3ef34c['getNode']()['getImmediateChild'](_0x2cfe51)['updateChild'](_0x43d502,_0x177bbc):_0x6e9f3d=_0x3ef34c['getNode']()['getImmediateChild'](_0x2cfe51);}else _0x6e9f3d=ss(_0x5eda4f,_0x2cfe51,_0x44828f['serverCache']);_0x6e9f3d!=null?_0x1c152a=_0x27243a['filter']['updateChild'](_0x3ef34c['getNode'](),_0x2cfe51,_0x6e9f3d,_0x43d502,_0x5f2abb,_0x1e7f58):_0x1c152a=_0x3ef34c['getNode']();}}return Rt(_0x44828f,_0x1c152a,_0x3ef34c['isFullyInitialized']()||v(_0x456b8b),_0x27243a['filter']['filtersNodes']());}}function Sn(_0x5c6102,_0x184b03,_0x141352,_0x93da11,_0x311321,_0x21f316,_0x3047a0,_0x47cfcb){const _0x4b7abb=_0x184b03['serverCache'];let _0x381225;const _0x28cbe4=_0x3047a0?_0x5c6102['filter']:_0x5c6102['filter']['getIndexedFilter']();if(v(_0x141352))_0x381225=_0x28cbe4['updateFullNode'](_0x4b7abb['getNode'](),_0x93da11,null);else{if(_0x28cbe4['filtersNodes']()&&!_0x4b7abb['isFiltered']()){const _0x165bb5=_0x4b7abb['getNode']()['updateChild'](_0x141352,_0x93da11);_0x381225=_0x28cbe4['updateFullNode'](_0x4b7abb['getNode'](),_0x165bb5,null);}else{const _0x33c3bc=y(_0x141352);if(!_0x4b7abb['isCompleteForPath'](_0x141352)&&Ce(_0x141352)>0x1)return _0x184b03;const _0x251280=S(_0x141352),_0x1a4cba=_0x4b7abb['getNode']()['getImmediateChild'](_0x33c3bc)['updateChild'](_0x251280,_0x93da11);_0x33c3bc==='.priority'?_0x381225=_0x28cbe4['updatePriority'](_0x4b7abb['getNode'](),_0x1a4cba):_0x381225=_0x28cbe4['updateChild'](_0x4b7abb['getNode'](),_0x33c3bc,_0x1a4cba,_0x251280,$o,null);}}const _0x22b959=Fo(_0x184b03,_0x381225,_0x4b7abb['isFullyInitialized']()||v(_0x141352),_0x28cbe4['filtersNodes']()),_0x33e8f8=new rs(_0x311321,_0x22b959,_0x21f316);return Go(_0x5c6102,_0x22b959,_0x141352,_0x311321,_0x33e8f8,_0x47cfcb);}function ki(_0x577583,_0x41db8b,_0x4687fe,_0x6846e8,_0x4311e1,_0x2ecbcf,_0xef883e){const _0x339384=_0x41db8b['eventCache'];let _0x231fbc,_0x2951ca;const _0x5e2d5c=new rs(_0x4311e1,_0x41db8b,_0x2ecbcf);if(v(_0x4687fe))_0x2951ca=_0x577583['filter']['updateFullNode'](_0x41db8b['eventCache']['getNode'](),_0x6846e8,_0xef883e),_0x231fbc=Rt(_0x41db8b,_0x2951ca,!0x0,_0x577583['filter']['filtersNodes']());else{const _0x113a19=y(_0x4687fe);if(_0x113a19==='.priority')_0x2951ca=_0x577583['filter']['updatePriority'](_0x41db8b['eventCache']['getNode'](),_0x6846e8),_0x231fbc=Rt(_0x41db8b,_0x2951ca,_0x339384['isFullyInitialized'](),_0x339384['isFiltered']());else{const _0x39717b=S(_0x4687fe),_0x495d1a=_0x339384['getNode']()['getImmediateChild'](_0x113a19);let _0x1cceb8;if(v(_0x39717b))_0x1cceb8=_0x6846e8;else{const _0x12ddb2=_0x5e2d5c['getCompleteChild'](_0x113a19);_0x12ddb2!=null?ji(_0x39717b)==='.priority'&&_0x12ddb2['getChild'](Ro(_0x39717b))['isEmpty']()?_0x1cceb8=_0x12ddb2:_0x1cceb8=_0x12ddb2['updateChild'](_0x39717b,_0x6846e8):_0x1cceb8=g['EMPTY_NODE'];}if(_0x495d1a['equals'](_0x1cceb8))_0x231fbc=_0x41db8b;else{const _0x3199d2=_0x577583['filter']['updateChild'](_0x339384['getNode'](),_0x113a19,_0x1cceb8,_0x39717b,_0x5e2d5c,_0xef883e);_0x231fbc=Rt(_0x41db8b,_0x3199d2,_0x339384['isFullyInitialized'](),_0x577583['filter']['filtersNodes']());}}}return _0x231fbc;}function lr(_0x13916a,_0x4d64e4){return _0x13916a['eventCache']['isCompleteForChild'](_0x4d64e4);}function ku(_0x425436,_0x27c85b,_0x46ae02,_0x28e460,_0x1d8b47,_0xb42f86,_0x4322d9){let _0x434108=_0x27c85b;return _0x28e460['foreach']((_0x4bf1e4,_0x391b68)=>{const _0x3be1d7=k(_0x46ae02,_0x4bf1e4);lr(_0x27c85b,y(_0x3be1d7))&&(_0x434108=ki(_0x425436,_0x434108,_0x3be1d7,_0x391b68,_0x1d8b47,_0xb42f86,_0x4322d9));}),_0x28e460['foreach']((_0x4c762a,_0x5788f3)=>{const _0x2f6d34=k(_0x46ae02,_0x4c762a);lr(_0x27c85b,y(_0x2f6d34))||(_0x434108=ki(_0x425436,_0x434108,_0x2f6d34,_0x5788f3,_0x1d8b47,_0xb42f86,_0x4322d9));}),_0x434108;}function hr(_0x2869cf,_0x4d9a26,_0x32c7b9){return _0x32c7b9['foreach']((_0x37576b,_0x5cd211)=>{_0x4d9a26=_0x4d9a26['updateChild'](_0x37576b,_0x5cd211);}),_0x4d9a26;}function Pi(_0x4a7d33,_0x873d17,_0x11572d,_0x3480b6,_0x310691,_0x391009,_0xcda4f6,_0x521230){if(_0x873d17['serverCache']['getNode']()['isEmpty']()&&!_0x873d17['serverCache']['isFullyInitialized']())return _0x873d17;let _0x311b81=_0x873d17,_0x562fa6;v(_0x11572d)?_0x562fa6=_0x3480b6:_0x562fa6=new b(null)['setTree'](_0x11572d,_0x3480b6);const _0x15135f=_0x873d17['serverCache']['getNode']();return _0x562fa6['children']['inorderTraversal']((_0x5f14d3,_0x7f00a1)=>{if(_0x15135f['hasChild'](_0x5f14d3)){const _0x156acf=_0x873d17['serverCache']['getNode']()['getImmediateChild'](_0x5f14d3),_0x1d6896=hr(_0x4a7d33,_0x156acf,_0x7f00a1);_0x311b81=Sn(_0x4a7d33,_0x311b81,new C(_0x5f14d3),_0x1d6896,_0x310691,_0x391009,_0xcda4f6,_0x521230);}}),_0x562fa6['children']['inorderTraversal']((_0x2d0518,_0x56f3b1)=>{const _0x11181e=!_0x873d17['serverCache']['isCompleteForChild'](_0x2d0518)&&_0x56f3b1['value']===null;if(!_0x15135f['hasChild'](_0x2d0518)&&!_0x11181e){const _0x138724=_0x873d17['serverCache']['getNode']()['getImmediateChild'](_0x2d0518),_0x584f1f=hr(_0x4a7d33,_0x138724,_0x56f3b1);_0x311b81=Sn(_0x4a7d33,_0x311b81,new C(_0x2d0518),_0x584f1f,_0x310691,_0x391009,_0xcda4f6,_0x521230);}}),_0x311b81;}function Pu(_0x2e43f8,_0x3aa53d,_0x48be39,_0x2c69aa,_0x4c860d,_0x4d8367,_0x55b988){if(Tn(_0x4c860d,_0x48be39)!=null)return _0x3aa53d;const _0xa877fc=_0x3aa53d['serverCache']['isFiltered'](),_0x4d6c83=_0x3aa53d['serverCache'];if(_0x2c69aa['value']!=null){if(v(_0x48be39)&&_0x4d6c83['isFullyInitialized']()||_0x4d6c83['isCompleteForPath'](_0x48be39))return Sn(_0x2e43f8,_0x3aa53d,_0x48be39,_0x4d6c83['getNode']()['getChild'](_0x48be39),_0x4c860d,_0x4d8367,_0xa877fc,_0x55b988);if(v(_0x48be39)){let _0x4ba347=new b(null);return _0x4d6c83['getNode']()['forEachChild'](ve,(_0x30ee6c,_0x40ea06)=>{_0x4ba347=_0x4ba347['set'](new C(_0x30ee6c),_0x40ea06);}),Pi(_0x2e43f8,_0x3aa53d,_0x48be39,_0x4ba347,_0x4c860d,_0x4d8367,_0xa877fc,_0x55b988);}else return _0x3aa53d;}else{let _0x4a3c14=new b(null);return _0x2c69aa['foreach']((_0x48f07b,_0x1f9e81)=>{const _0x28ba69=k(_0x48be39,_0x48f07b);_0x4d6c83['isCompleteForPath'](_0x28ba69)&&(_0x4a3c14=_0x4a3c14['set'](_0x48f07b,_0x4d6c83['getNode']()['getChild'](_0x28ba69)));}),Pi(_0x2e43f8,_0x3aa53d,_0x48be39,_0x4a3c14,_0x4c860d,_0x4d8367,_0xa877fc,_0x55b988);}}function Nu(_0x48ab06,_0x3e79ed,_0x58c623,_0xbe19c1,_0x3e2ff5){const _0x3a424e=_0x3e79ed['serverCache'],_0x163ede=Fo(_0x3e79ed,_0x3a424e['getNode'](),_0x3a424e['isFullyInitialized']()||v(_0x58c623),_0x3a424e['isFiltered']());return Go(_0x48ab06,_0x163ede,_0x58c623,_0xbe19c1,$o,_0x3e2ff5);}function Ou(_0x340410,_0x2b21e4,_0x134b91,_0x1fd6d1,_0xceb3c1,_0x16d011){let _0x1bad30;if(Tn(_0x1fd6d1,_0x134b91)!=null)return _0x2b21e4;{const _0x30d690=new rs(_0x1fd6d1,_0x2b21e4,_0xceb3c1),_0x5e1100=_0x2b21e4['eventCache']['getNode']();let _0x3a93ed;if(v(_0x134b91)||y(_0x134b91)==='.priority'){let _0x79d042;if(_0x2b21e4['serverCache']['isFullyInitialized']())_0x79d042=Cn(_0x1fd6d1,Ve(_0x2b21e4));else{const _0x377930=_0x2b21e4['serverCache']['getNode']();f(_0x377930 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x79d042=is(_0x1fd6d1,_0x377930);}_0x79d042=_0x79d042,_0x3a93ed=_0x340410['filter']['updateFullNode'](_0x5e1100,_0x79d042,_0x16d011);}else{const _0x5429b6=y(_0x134b91);let _0x43b3d4=ss(_0x1fd6d1,_0x5429b6,_0x2b21e4['serverCache']);_0x43b3d4==null&&_0x2b21e4['serverCache']['isCompleteForChild'](_0x5429b6)&&(_0x43b3d4=_0x5e1100['getImmediateChild'](_0x5429b6)),_0x43b3d4!=null?_0x3a93ed=_0x340410['filter']['updateChild'](_0x5e1100,_0x5429b6,_0x43b3d4,S(_0x134b91),_0x30d690,_0x16d011):_0x2b21e4['eventCache']['getNode']()['hasChild'](_0x5429b6)?_0x3a93ed=_0x340410['filter']['updateChild'](_0x5e1100,_0x5429b6,g['EMPTY_NODE'],S(_0x134b91),_0x30d690,_0x16d011):_0x3a93ed=_0x5e1100,_0x3a93ed['isEmpty']()&&_0x2b21e4['serverCache']['isFullyInitialized']()&&(_0x1bad30=Cn(_0x1fd6d1,Ve(_0x2b21e4)),_0x1bad30['isLeafNode']()&&(_0x3a93ed=_0x340410['filter']['updateFullNode'](_0x3a93ed,_0x1bad30,_0x16d011)));}return _0x1bad30=_0x2b21e4['serverCache']['isFullyInitialized']()||Tn(_0x1fd6d1,w())!=null,Rt(_0x2b21e4,_0x3a93ed,_0x1bad30,_0x340410['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x1e7364,_0x4cc065){this['query_']=_0x1e7364,this['eventRegistrations_']=[];const _0x396b40=this['query_']['_queryParams'],_0x26f771=new Xi(_0x396b40['getIndex']()),_0x6164c0=Kh(_0x396b40);this['processor_']=Su(_0x6164c0);const _0x5bee31=_0x4cc065['serverCache'],_0x32d28e=_0x4cc065['eventCache'],_0x410243=_0x26f771['updateFullNode'](g['EMPTY_NODE'],_0x5bee31['getNode'](),null),_0x3943f0=_0x6164c0['updateFullNode'](g['EMPTY_NODE'],_0x32d28e['getNode'](),null),_0x700f7e=new Te(_0x410243,_0x5bee31['isFullyInitialized'](),_0x26f771['filtersNodes']()),_0x2b9914=new Te(_0x3943f0,_0x32d28e['isFullyInitialized'](),_0x6164c0['filtersNodes']());this['viewCache_']=Un(_0x2b9914,_0x700f7e),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x36b0be){return _0x36b0be['viewCache_']['serverCache']['getNode']();}function Lu(_0x231074){return wn(_0x231074['viewCache_']);}function xu(_0x26430d,_0x53de2d){const _0x59796b=Ve(_0x26430d['viewCache_']);return _0x59796b&&(_0x26430d['query']['_queryParams']['loadsAllData']()||!v(_0x53de2d)&&!_0x59796b['getImmediateChild'](y(_0x53de2d))['isEmpty']())?_0x59796b['getChild'](_0x53de2d):null;}function ur(_0x32b911){return _0x32b911['eventRegistrations_']['length']===0x0;}function Fu(_0x2c7df9,_0x3aec01){_0x2c7df9['eventRegistrations_']['push'](_0x3aec01);}function dr(_0x55e8d2,_0x48e99f,_0x6b88e3){const _0x221f49=[];if(_0x6b88e3){f(_0x48e99f==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3da29e=_0x55e8d2['query']['_path'];_0x55e8d2['eventRegistrations_']['forEach'](_0x476721=>{const _0x308f13=_0x476721['createCancelEvent'](_0x6b88e3,_0x3da29e);_0x308f13&&_0x221f49['push'](_0x308f13);});}if(_0x48e99f){let _0x3d983b=[];for(let _0x27dd56=0x0;_0x27dd56<_0x55e8d2['eventRegistrations_']['length'];++_0x27dd56){const _0xfc7423=_0x55e8d2['eventRegistrations_'][_0x27dd56];if(!_0xfc7423['matches'](_0x48e99f))_0x3d983b['push'](_0xfc7423);else{if(_0x48e99f['hasAnyCallback']()){_0x3d983b=_0x3d983b['concat'](_0x55e8d2['eventRegistrations_']['slice'](_0x27dd56+0x1));break;}}}_0x55e8d2['eventRegistrations_']=_0x3d983b;}else _0x55e8d2['eventRegistrations_']=[];return _0x221f49;}function fr(_0x320c2c,_0x1c94b3,_0x4b9fd2,_0x18b348){_0x1c94b3['type']===z['MERGE']&&_0x1c94b3['source']['queryId']!==null&&(f(Ve(_0x320c2c['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x320c2c['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x313f65=_0x320c2c['viewCache_'],_0x4004a5=Ru(_0x320c2c['processor_'],_0x313f65,_0x1c94b3,_0x4b9fd2,_0x18b348);return bu(_0x320c2c['processor_'],_0x4004a5['viewCache']),f(_0x4004a5['viewCache']['serverCache']['isFullyInitialized']()||!_0x313f65['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x320c2c['viewCache_']=_0x4004a5['viewCache'],qo(_0x320c2c,_0x4004a5['changes'],_0x4004a5['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x2804d9,_0xa1d1d4){const _0x466720=_0x2804d9['viewCache_']['eventCache'],_0x4b78c7=[];return _0x466720['getNode']()['isLeafNode']()||_0x466720['getNode']()['forEachChild'](R,(_0x34d426,_0x4bbfe7)=>{_0x4b78c7['push'](rt(_0x34d426,_0x4bbfe7));}),_0x466720['isFullyInitialized']()&&_0x4b78c7['push'](Lo(_0x466720['getNode']())),qo(_0x2804d9,_0x4b78c7,_0x466720['getNode'](),_0xa1d1d4);}function qo(_0x328ae3,_0xe0bea7,_0xd4a683,_0x376207){const _0x4048c1=_0x376207?[_0x376207]:_0x328ae3['eventRegistrations_'];return ru(_0x328ae3['eventGenerator_'],_0xe0bea7,_0xd4a683,_0x4048c1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0xec3d4d){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0xec3d4d;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x2e151f){return _0x2e151f['views']['size']===0x0;}function os(_0x312855,_0xd38dcb,_0x412b23,_0x4ce711){const _0x1f0eb5=_0xd38dcb['source']['queryId'];if(_0x1f0eb5!==null){const _0x1a0a1d=_0x312855['views']['get'](_0x1f0eb5);return f(_0x1a0a1d!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x1a0a1d,_0xd38dcb,_0x412b23,_0x4ce711);}else{let _0x366619=[];for(const _0x1a9b67 of _0x312855['views']['values']())_0x366619=_0x366619['concat'](fr(_0x1a9b67,_0xd38dcb,_0x412b23,_0x4ce711));return _0x366619;}}function jo(_0x2e51ce,_0x1e8ac3,_0x46b59b,_0x11864f,_0x46725d){const _0x55d607=_0x1e8ac3['_queryIdentifier'],_0x7a736a=_0x2e51ce['views']['get'](_0x55d607);if(!_0x7a736a){let _0x5d63ec=Cn(_0x46b59b,_0x46725d?_0x11864f:null),_0x275500=!0x1;_0x5d63ec?_0x275500=!0x0:_0x11864f instanceof g?(_0x5d63ec=is(_0x46b59b,_0x11864f),_0x275500=!0x1):(_0x5d63ec=g['EMPTY_NODE'],_0x275500=!0x1);const _0x22b4c7=Un(new Te(_0x5d63ec,_0x275500,!0x1),new Te(_0x11864f,_0x46725d,!0x1));return new Du(_0x1e8ac3,_0x22b4c7);}return _0x7a736a;}function Hu(_0x471a73,_0x5704fe,_0x1d3aed,_0x5db9e6,_0x347397,_0x5e5e2e){const _0x64d31b=jo(_0x471a73,_0x5704fe,_0x5db9e6,_0x347397,_0x5e5e2e);return _0x471a73['views']['has'](_0x5704fe['_queryIdentifier'])||_0x471a73['views']['set'](_0x5704fe['_queryIdentifier'],_0x64d31b),Fu(_0x64d31b,_0x1d3aed),Uu(_0x64d31b,_0x1d3aed);}function $u(_0x4eb1bb,_0x32cc34,_0x34930e,_0x5bfaf2){const _0x2eaa9b=_0x32cc34['_queryIdentifier'],_0x40f3c1=[];let _0x1613c9=[];const _0x2de986=Se(_0x4eb1bb);if(_0x2eaa9b==='default'){for(const [_0x20dec0,_0x28ae0b]of _0x4eb1bb['views']['entries']())_0x1613c9=_0x1613c9['concat'](dr(_0x28ae0b,_0x34930e,_0x5bfaf2)),ur(_0x28ae0b)&&(_0x4eb1bb['views']['delete'](_0x20dec0),_0x28ae0b['query']['_queryParams']['loadsAllData']()||_0x40f3c1['push'](_0x28ae0b['query']));}else{const _0x18de27=_0x4eb1bb['views']['get'](_0x2eaa9b);_0x18de27&&(_0x1613c9=_0x1613c9['concat'](dr(_0x18de27,_0x34930e,_0x5bfaf2)),ur(_0x18de27)&&(_0x4eb1bb['views']['delete'](_0x2eaa9b),_0x18de27['query']['_queryParams']['loadsAllData']()||_0x40f3c1['push'](_0x18de27['query'])));}return _0x2de986&&!Se(_0x4eb1bb)&&_0x40f3c1['push'](new(Bu())(_0x32cc34['_repo'],_0x32cc34['_path'])),{'removed':_0x40f3c1,'events':_0x1613c9};}function Ko(_0xefadc6){const _0x23e823=[];for(const _0x11b1d1 of _0xefadc6['views']['values']())_0x11b1d1['query']['_queryParams']['loadsAllData']()||_0x23e823['push'](_0x11b1d1);return _0x23e823;}function Ie(_0x417f6e,_0x16eb87){let _0x357909=null;for(const _0x19a665 of _0x417f6e['views']['values']())_0x357909=_0x357909||xu(_0x19a665,_0x16eb87);return _0x357909;}function Yo(_0x315ff2,_0x478fbf){if(_0x478fbf['_queryParams']['loadsAllData']())return Bn(_0x315ff2);{const _0x5c5825=_0x478fbf['_queryIdentifier'];return _0x315ff2['views']['get'](_0x5c5825);}}function Qo(_0x1f2302,_0x1ed1d4){return Yo(_0x1f2302,_0x1ed1d4)!=null;}function Se(_0x1c1134){return Bn(_0x1c1134)!=null;}function Bn(_0xd9dc6f){for(const _0x17b0ad of _0xd9dc6f['views']['values']())if(_0x17b0ad['query']['_queryParams']['loadsAllData']())return _0x17b0ad;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x285dc7){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x285dc7;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x3fbfda){this['listenProvider_']=_0x3fbfda,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x363eb0,_0x3966ea,_0x2c5dc2,_0x36d3ed,_0x5da782){return lu(_0x363eb0['pendingWriteTree_'],_0x3966ea,_0x2c5dc2,_0x36d3ed,_0x5da782),_0x5da782?_t(_0x363eb0,new Be(es(),_0x3966ea,_0x2c5dc2)):[];}function ju(_0x28bbc3,_0xa745d9,_0x403bd3,_0x44fc19){hu(_0x28bbc3['pendingWriteTree_'],_0xa745d9,_0x403bd3,_0x44fc19);const _0x2ccc32=b['fromObject'](_0x403bd3);return _t(_0x28bbc3,new ot(es(),_0xa745d9,_0x2ccc32));}function _e(_0x210f6e,_0xa8b3f8,_0x454847=!0x1){const _0x221c2a=uu(_0x210f6e['pendingWriteTree_'],_0xa8b3f8);if(du(_0x210f6e['pendingWriteTree_'],_0xa8b3f8)){let _0x3e480f=new b(null);return _0x221c2a['snap']!=null?_0x3e480f=_0x3e480f['set'](w(),!0x0):x(_0x221c2a['children'],_0x13d13d=>{_0x3e480f=_0x3e480f['set'](new C(_0x13d13d),!0x0);}),_t(_0x210f6e,new In(_0x221c2a['path'],_0x3e480f,_0x454847));}else return[];}function Yt(_0x1dc264,_0x4f9af7,_0x46d00b){return _t(_0x1dc264,new Be(ts(),_0x4f9af7,_0x46d00b));}function Ku(_0x5a2511,_0x2e4c25,_0x423a31){const _0x2632f=b['fromObject'](_0x423a31);return _t(_0x5a2511,new ot(ts(),_0x2e4c25,_0x2632f));}function Yu(_0x33ceb9,_0x5c249e){return _t(_0x33ceb9,new Ut(ts(),_0x5c249e));}function Qu(_0x1eb5da,_0x540337,_0x2b46b6){const _0x3ebfdc=cs(_0x1eb5da,_0x2b46b6);if(_0x3ebfdc){const _0x43a475=ls(_0x3ebfdc),_0x2bd65c=_0x43a475['path'],_0x24af48=_0x43a475['queryId'],_0x440e0c=F(_0x2bd65c,_0x540337),_0xe7d7b5=new Ut(ns(_0x24af48),_0x440e0c);return hs(_0x1eb5da,_0x2bd65c,_0xe7d7b5);}else return[];}function An(_0x558ea7,_0x49c637,_0x4b5394,_0x1f7b32,_0x1f99a5=!0x1){const _0x69ce2e=_0x49c637['_path'],_0x49308b=_0x558ea7['syncPointTree_']['get'](_0x69ce2e);let _0x365133=[];if(_0x49308b&&(_0x49c637['_queryIdentifier']==='default'||Qo(_0x49308b,_0x49c637))){const _0x59a700=$u(_0x49308b,_0x49c637,_0x4b5394,_0x1f7b32);Vu(_0x49308b)&&(_0x558ea7['syncPointTree_']=_0x558ea7['syncPointTree_']['remove'](_0x69ce2e));const _0x2a8c63=_0x59a700['removed'];if(_0x365133=_0x59a700['events'],!_0x1f99a5){const _0x23a03b=_0x2a8c63['findIndex'](_0xc000ce=>_0xc000ce['_queryParams']['loadsAllData']())!==-0x1,_0x518d65=_0x558ea7['syncPointTree_']['findOnPath'](_0x69ce2e,(_0x14e1ad,_0x4601e0)=>Se(_0x4601e0));if(_0x23a03b&&!_0x518d65){const _0x27dad0=_0x558ea7['syncPointTree_']['subtree'](_0x69ce2e);if(!_0x27dad0['isEmpty']()){const _0x1677c6=Zu(_0x27dad0);for(let _0x1391e8=0x0;_0x1391e8<_0x1677c6['length'];++_0x1391e8){const _0x37ba8b=_0x1677c6[_0x1391e8],_0x5517df=_0x37ba8b['query'],_0x3b7f49=ea(_0x558ea7,_0x37ba8b);_0x558ea7['listenProvider_']['startListening'](kt(_0x5517df),Wt(_0x558ea7,_0x5517df),_0x3b7f49['hashFn'],_0x3b7f49['onComplete']);}}}!_0x518d65&&_0x2a8c63['length']>0x0&&!_0x1f7b32&&(_0x23a03b?_0x558ea7['listenProvider_']['stopListening'](kt(_0x49c637),null):_0x2a8c63['forEach'](_0x11740b=>{const _0x3453c6=_0x558ea7['queryToTagMap']['get'](Hn(_0x11740b));_0x558ea7['listenProvider_']['stopListening'](kt(_0x11740b),_0x3453c6);}));}ed(_0x558ea7,_0x2a8c63);}return _0x365133;}function Jo(_0x275d52,_0x47e1f2,_0x14b426,_0x55dc17){const _0x4d5e4d=cs(_0x275d52,_0x55dc17);if(_0x4d5e4d!=null){const _0x4da7e0=ls(_0x4d5e4d),_0x57c530=_0x4da7e0['path'],_0x1e5b8d=_0x4da7e0['queryId'],_0x462d18=F(_0x57c530,_0x47e1f2),_0x2f4455=new Be(ns(_0x1e5b8d),_0x462d18,_0x14b426);return hs(_0x275d52,_0x57c530,_0x2f4455);}else return[];}function Ju(_0x85fc6,_0x386f85,_0x2efa80,_0x9ed755){const _0x258f74=cs(_0x85fc6,_0x9ed755);if(_0x258f74){const _0x30bffb=ls(_0x258f74),_0x4dd5c9=_0x30bffb['path'],_0x46eb4f=_0x30bffb['queryId'],_0x2acb8b=F(_0x4dd5c9,_0x386f85),_0x49b100=b['fromObject'](_0x2efa80),_0x8bb2af=new ot(ns(_0x46eb4f),_0x2acb8b,_0x49b100);return hs(_0x85fc6,_0x4dd5c9,_0x8bb2af);}else return[];}function Ni(_0x56dffd,_0x862963,_0x1d1c56,_0x497337=!0x1){const _0x1a97bb=_0x862963['_path'];let _0x3be1ff=null,_0x5c20c6=!0x1;_0x56dffd['syncPointTree_']['foreachOnPath'](_0x1a97bb,(_0x282eb5,_0x1fe58c)=>{const _0x23afc1=F(_0x282eb5,_0x1a97bb);_0x3be1ff=_0x3be1ff||Ie(_0x1fe58c,_0x23afc1),_0x5c20c6=_0x5c20c6||Se(_0x1fe58c);});let _0x3cbd72=_0x56dffd['syncPointTree_']['get'](_0x1a97bb);_0x3cbd72?(_0x5c20c6=_0x5c20c6||Se(_0x3cbd72),_0x3be1ff=_0x3be1ff||Ie(_0x3cbd72,w())):(_0x3cbd72=new zo(),_0x56dffd['syncPointTree_']=_0x56dffd['syncPointTree_']['set'](_0x1a97bb,_0x3cbd72));let _0x1a1957;_0x3be1ff!=null?_0x1a1957=!0x0:(_0x1a1957=!0x1,_0x3be1ff=g['EMPTY_NODE'],_0x56dffd['syncPointTree_']['subtree'](_0x1a97bb)['foreachChild']((_0x54b779,_0x5bf652)=>{const _0x4108ee=Ie(_0x5bf652,w());_0x4108ee&&(_0x3be1ff=_0x3be1ff['updateImmediateChild'](_0x54b779,_0x4108ee));}));const _0x454c1a=Qo(_0x3cbd72,_0x862963);if(!_0x454c1a&&!_0x862963['_queryParams']['loadsAllData']()){const _0xad2282=Hn(_0x862963);f(!_0x56dffd['queryToTagMap']['has'](_0xad2282),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1ee8db=td();_0x56dffd['queryToTagMap']['set'](_0xad2282,_0x1ee8db),_0x56dffd['tagToQueryMap']['set'](_0x1ee8db,_0xad2282);}const _0x9a20d=Wn(_0x56dffd['pendingWriteTree_'],_0x1a97bb);let _0xd4ca2f=Hu(_0x3cbd72,_0x862963,_0x1d1c56,_0x9a20d,_0x3be1ff,_0x1a1957);if(!_0x454c1a&&!_0x5c20c6&&!_0x497337){const _0x4c830d=Yo(_0x3cbd72,_0x862963);_0xd4ca2f=_0xd4ca2f['concat'](nd(_0x56dffd,_0x862963,_0x4c830d));}return _0xd4ca2f;}function Vn(_0x40e9f2,_0x32b3a5,_0x5bcd21){const _0x372b9b=_0x40e9f2['pendingWriteTree_'],_0x30a012=_0x40e9f2['syncPointTree_']['findOnPath'](_0x32b3a5,(_0x5da518,_0x27a4dd)=>{const _0x39afcd=F(_0x5da518,_0x32b3a5),_0x510f39=Ie(_0x27a4dd,_0x39afcd);if(_0x510f39)return _0x510f39;});return Bo(_0x372b9b,_0x32b3a5,_0x30a012,_0x5bcd21,!0x0);}function Xu(_0x31298b,_0x11c74d){const _0x2930ad=_0x11c74d['_path'];let _0x347cf0=null;_0x31298b['syncPointTree_']['foreachOnPath'](_0x2930ad,(_0x307201,_0x212668)=>{const _0x409cbf=F(_0x307201,_0x2930ad);_0x347cf0=_0x347cf0||Ie(_0x212668,_0x409cbf);});let _0x2c9acd=_0x31298b['syncPointTree_']['get'](_0x2930ad);_0x2c9acd?_0x347cf0=_0x347cf0||Ie(_0x2c9acd,w()):(_0x2c9acd=new zo(),_0x31298b['syncPointTree_']=_0x31298b['syncPointTree_']['set'](_0x2930ad,_0x2c9acd));const _0x500d63=_0x347cf0!=null,_0x33eea1=_0x500d63?new Te(_0x347cf0,!0x0,!0x1):null,_0xbbe000=Wn(_0x31298b['pendingWriteTree_'],_0x11c74d['_path']),_0x442e93=jo(_0x2c9acd,_0x11c74d,_0xbbe000,_0x500d63?_0x33eea1['getNode']():g['EMPTY_NODE'],_0x500d63);return Lu(_0x442e93);}function _t(_0x2ba3f6,_0x1f2c7b){return Xo(_0x1f2c7b,_0x2ba3f6['syncPointTree_'],null,Wn(_0x2ba3f6['pendingWriteTree_'],w()));}function Xo(_0x6e0464,_0x3b52b8,_0x22b633,_0x2dbc02){if(v(_0x6e0464['path']))return Zo(_0x6e0464,_0x3b52b8,_0x22b633,_0x2dbc02);{const _0x2b3cd5=_0x3b52b8['get'](w());_0x22b633==null&&_0x2b3cd5!=null&&(_0x22b633=Ie(_0x2b3cd5,w()));let _0x1559de=[];const _0xde7254=y(_0x6e0464['path']),_0x11709a=_0x6e0464['operationForChild'](_0xde7254),_0x5a2374=_0x3b52b8['children']['get'](_0xde7254);if(_0x5a2374&&_0x11709a){const _0x420eb5=_0x22b633?_0x22b633['getImmediateChild'](_0xde7254):null,_0x5f2f9a=Vo(_0x2dbc02,_0xde7254);_0x1559de=_0x1559de['concat'](Xo(_0x11709a,_0x5a2374,_0x420eb5,_0x5f2f9a));}return _0x2b3cd5&&(_0x1559de=_0x1559de['concat'](os(_0x2b3cd5,_0x6e0464,_0x2dbc02,_0x22b633))),_0x1559de;}}function Zo(_0x85c21a,_0x1fd980,_0x4a0b17,_0x38c5dc){const _0x495db3=_0x1fd980['get'](w());_0x4a0b17==null&&_0x495db3!=null&&(_0x4a0b17=Ie(_0x495db3,w()));let _0x5f3f80=[];return _0x1fd980['children']['inorderTraversal']((_0x14a6ae,_0x201013)=>{const _0x3657b7=_0x4a0b17?_0x4a0b17['getImmediateChild'](_0x14a6ae):null,_0x4b547d=Vo(_0x38c5dc,_0x14a6ae),_0x5ea1d7=_0x85c21a['operationForChild'](_0x14a6ae);_0x5ea1d7&&(_0x5f3f80=_0x5f3f80['concat'](Zo(_0x5ea1d7,_0x201013,_0x3657b7,_0x4b547d)));}),_0x495db3&&(_0x5f3f80=_0x5f3f80['concat'](os(_0x495db3,_0x85c21a,_0x38c5dc,_0x4a0b17))),_0x5f3f80;}function ea(_0x2b02be,_0x16c47d){const _0x543cd9=_0x16c47d['query'],_0x53da5e=Wt(_0x2b02be,_0x543cd9);return{'hashFn':()=>(Mu(_0x16c47d)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x30d0a5=>{if(_0x30d0a5==='ok')return _0x53da5e?Qu(_0x2b02be,_0x543cd9['_path'],_0x53da5e):Yu(_0x2b02be,_0x543cd9['_path']);{const _0x11790c=Kl(_0x30d0a5,_0x543cd9);return An(_0x2b02be,_0x543cd9,null,_0x11790c);}}};}function Wt(_0x156fcb,_0x225eed){const _0xb0057a=Hn(_0x225eed);return _0x156fcb['queryToTagMap']['get'](_0xb0057a);}function Hn(_0x23e9ca){return _0x23e9ca['_path']['toString']()+'$'+_0x23e9ca['_queryIdentifier'];}function cs(_0xcaaf2c,_0x4ecc9c){return _0xcaaf2c['tagToQueryMap']['get'](_0x4ecc9c);}function ls(_0x48efdf){const _0x474f87=_0x48efdf['indexOf']('$');return f(_0x474f87!==-0x1&&_0x474f87<_0x48efdf['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x48efdf['substr'](_0x474f87+0x1),'path':new C(_0x48efdf['substr'](0x0,_0x474f87))};}function hs(_0x2a02ea,_0x3e9950,_0x5671c5){const _0x1bb8b2=_0x2a02ea['syncPointTree_']['get'](_0x3e9950);f(_0x1bb8b2,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0xdccede=Wn(_0x2a02ea['pendingWriteTree_'],_0x3e9950);return os(_0x1bb8b2,_0x5671c5,_0xdccede,null);}function Zu(_0x54fe5e){return _0x54fe5e['fold']((_0x413750,_0x495c21,_0x1f9ab7)=>{if(_0x495c21&&Se(_0x495c21))return[Bn(_0x495c21)];{let _0x3383f6=[];return _0x495c21&&(_0x3383f6=Ko(_0x495c21)),x(_0x1f9ab7,(_0x1e96ec,_0x45f579)=>{_0x3383f6=_0x3383f6['concat'](_0x45f579);}),_0x3383f6;}});}function kt(_0x37975b){return _0x37975b['_queryParams']['loadsAllData']()&&!_0x37975b['_queryParams']['isDefault']()?new(qu())(_0x37975b['_repo'],_0x37975b['_path']):_0x37975b;}function ed(_0x2ff15d,_0x347aa3){for(let _0x2d722b=0x0;_0x2d722b<_0x347aa3['length'];++_0x2d722b){const _0x203cc1=_0x347aa3[_0x2d722b];if(!_0x203cc1['_queryParams']['loadsAllData']()){const _0x46c971=Hn(_0x203cc1),_0x557b89=_0x2ff15d['queryToTagMap']['get'](_0x46c971);_0x2ff15d['queryToTagMap']['delete'](_0x46c971),_0x2ff15d['tagToQueryMap']['delete'](_0x557b89);}}}function td(){return zu++;}function nd(_0x42e482,_0x170208,_0x1bf565){const _0x56488a=_0x170208['_path'],_0x5902e0=Wt(_0x42e482,_0x170208),_0x595377=ea(_0x42e482,_0x1bf565),_0xa69946=_0x42e482['listenProvider_']['startListening'](kt(_0x170208),_0x5902e0,_0x595377['hashFn'],_0x595377['onComplete']),_0x385c44=_0x42e482['syncPointTree_']['subtree'](_0x56488a);if(_0x5902e0)f(!Se(_0x385c44['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x428a7d=_0x385c44['fold']((_0x63c999,_0xe0b677,_0x1e2fe0)=>{if(!v(_0x63c999)&&_0xe0b677&&Se(_0xe0b677))return[Bn(_0xe0b677)['query']];{let _0xd180e4=[];return _0xe0b677&&(_0xd180e4=_0xd180e4['concat'](Ko(_0xe0b677)['map'](_0xfe1c78=>_0xfe1c78['query']))),x(_0x1e2fe0,(_0x2b2bf4,_0x221f09)=>{_0xd180e4=_0xd180e4['concat'](_0x221f09);}),_0xd180e4;}});for(let _0x328fe4=0x0;_0x328fe4<_0x428a7d['length'];++_0x328fe4){const _0x4c9f6c=_0x428a7d[_0x328fe4];_0x42e482['listenProvider_']['stopListening'](kt(_0x4c9f6c),Wt(_0x42e482,_0x4c9f6c));}}return _0xa69946;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x34aa53){this['node_']=_0x34aa53;}['getImmediateChild'](_0x3daf4c){const _0x143a40=this['node_']['getImmediateChild'](_0x3daf4c);return new us(_0x143a40);}['node'](){return this['node_'];}}class ds{constructor(_0x1fc6c2,_0x3114f3){this['syncTree_']=_0x1fc6c2,this['path_']=_0x3114f3;}['getImmediateChild'](_0x5d9015){const _0x380b39=k(this['path_'],_0x5d9015);return new ds(this['syncTree_'],_0x380b39);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x5e05b5){return _0x5e05b5=_0x5e05b5||{},_0x5e05b5['timestamp']=_0x5e05b5['timestamp']||new Date()['getTime'](),_0x5e05b5;},_r=function(_0x1299ab,_0x225bad,_0x4d5d75){if(!_0x1299ab||typeof _0x1299ab!='object')return _0x1299ab;if(f('.sv'in _0x1299ab,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1299ab['.sv']=='string')return sd(_0x1299ab['.sv'],_0x225bad,_0x4d5d75);if(typeof _0x1299ab['.sv']=='object')return rd(_0x1299ab['.sv'],_0x225bad);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1299ab,null,0x2));},sd=function(_0xc22bfd,_0x5a3814,_0x206247){switch(_0xc22bfd){case'timestamp':return _0x206247['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0xc22bfd);}},rd=function(_0x45e733,_0x4d9e56,_0x1bd8ee){_0x45e733['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x45e733,null,0x2));const _0x1e702b=_0x45e733['increment'];typeof _0x1e702b!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1e702b);const _0x665c19=_0x4d9e56['node']();if(f(_0x665c19!==null&&typeof _0x665c19<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x665c19['isLeafNode']())return _0x1e702b;const _0x1326ea=_0x665c19['getValue']();return typeof _0x1326ea!='number'?_0x1e702b:_0x1326ea+_0x1e702b;},ta=function(_0x261a82,_0x48e1f0,_0x29af2b,_0x5e899f){return ps(_0x48e1f0,new ds(_0x29af2b,_0x261a82),_0x5e899f);},fs=function(_0xfab475,_0x575aad,_0x1480a9){return ps(_0xfab475,new us(_0x575aad),_0x1480a9);};function ps(_0x1c5650,_0x5361b4,_0x2f2e7d){const _0x4413a4=_0x1c5650['getPriority']()['val'](),_0x405577=_r(_0x4413a4,_0x5361b4['getImmediateChild']('.priority'),_0x2f2e7d);let _0x3bac1b;if(_0x1c5650['isLeafNode']()){const _0x41e63c=_0x1c5650,_0x159fcb=_r(_0x41e63c['getValue'](),_0x5361b4,_0x2f2e7d);return _0x159fcb!==_0x41e63c['getValue']()||_0x405577!==_0x41e63c['getPriority']()['val']()?new D(_0x159fcb,A(_0x405577)):_0x1c5650;}else{const _0x4850e6=_0x1c5650;return _0x3bac1b=_0x4850e6,_0x405577!==_0x4850e6['getPriority']()['val']()&&(_0x3bac1b=_0x3bac1b['updatePriority'](new D(_0x405577))),_0x4850e6['forEachChild'](R,(_0x5a278c,_0x513e3a)=>{const _0x53dc9f=ps(_0x513e3a,_0x5361b4['getImmediateChild'](_0x5a278c),_0x2f2e7d);_0x53dc9f!==_0x513e3a&&(_0x3bac1b=_0x3bac1b['updateImmediateChild'](_0x5a278c,_0x53dc9f));}),_0x3bac1b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x749cfc='',_0x691d3a=null,_0x324dba={'children':{},'childCount':0x0}){this['name']=_0x749cfc,this['parent']=_0x691d3a,this['node']=_0x324dba;}}function $n(_0x50a09e,_0x57154e){let _0x739f9b=_0x57154e instanceof C?_0x57154e:new C(_0x57154e),_0x1aced0=_0x50a09e,_0x3b9788=y(_0x739f9b);for(;_0x3b9788!==null;){const _0x1b2a4a=Le(_0x1aced0['node']['children'],_0x3b9788)||{'children':{},'childCount':0x0};_0x1aced0=new _s(_0x3b9788,_0x1aced0,_0x1b2a4a),_0x739f9b=S(_0x739f9b),_0x3b9788=y(_0x739f9b);}return _0x1aced0;}function je(_0x9bd32f){return _0x9bd32f['node']['value'];}function gs(_0x46a6c9,_0x105da7){_0x46a6c9['node']['value']=_0x105da7,Oi(_0x46a6c9);}function na(_0x52b4a1){return _0x52b4a1['node']['childCount']>0x0;}function od(_0x5cd971){return je(_0x5cd971)===void 0x0&&!na(_0x5cd971);}function Gn(_0x426546,_0xbeec73){x(_0x426546['node']['children'],(_0x120286,_0x3ae84a)=>{_0xbeec73(new _s(_0x120286,_0x426546,_0x3ae84a));});}function ia(_0x21b4d2,_0x43968f,_0x551352,_0x1c1bb0){_0x551352&&_0x43968f(_0x21b4d2),Gn(_0x21b4d2,_0x3df430=>{ia(_0x3df430,_0x43968f,!0x0);});}function ad(_0x38ece8,_0x595218,_0x296c23){let _0x2b8304=_0x38ece8['parent'];for(;_0x2b8304!==null;){if(_0x595218(_0x2b8304))return!0x0;_0x2b8304=_0x2b8304['parent'];}return!0x1;}function Qt(_0x186be0){return new C(_0x186be0['parent']===null?_0x186be0['name']:Qt(_0x186be0['parent'])+'/'+_0x186be0['name']);}function Oi(_0x421a14){_0x421a14['parent']!==null&&cd(_0x421a14['parent'],_0x421a14['name'],_0x421a14);}function cd(_0x2c6aca,_0xd098d,_0x37a2cc){const _0x492156=od(_0x37a2cc),_0xf004fa=Q(_0x2c6aca['node']['children'],_0xd098d);_0x492156&&_0xf004fa?(delete _0x2c6aca['node']['children'][_0xd098d],_0x2c6aca['node']['childCount']--,Oi(_0x2c6aca)):!_0x492156&&!_0xf004fa&&(_0x2c6aca['node']['children'][_0xd098d]=_0x37a2cc['node'],_0x2c6aca['node']['childCount']++,Oi(_0x2c6aca));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x482efe){return typeof _0x482efe=='string'&&_0x482efe['length']!==0x0&&!ld['test'](_0x482efe);},sa=function(_0x3710a8){return typeof _0x3710a8=='string'&&_0x3710a8['length']!==0x0&&!hd['test'](_0x3710a8);},ud=function(_0x17f88b){return _0x17f88b&&(_0x17f88b=_0x17f88b['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x17f88b);},Bt=function(_0x155e9f){return _0x155e9f===null||typeof _0x155e9f=='string'||typeof _0x155e9f=='number'&&!xn(_0x155e9f)||_0x155e9f&&typeof _0x155e9f=='object'&&Q(_0x155e9f,'.sv');},He=function(_0x1f61c5,_0x4c0c9a,_0x4561f7,_0x5ef221){_0x5ef221&&_0x4c0c9a===void 0x0||Jt(it(_0x1f61c5,'value'),_0x4c0c9a,_0x4561f7);},Jt=function(_0x3b8450,_0x2dd9f0,_0x2cb941){const _0xca41d=_0x2cb941 instanceof C?new Ah(_0x2cb941,_0x3b8450):_0x2cb941;if(_0x2dd9f0===void 0x0)throw new Error(_0x3b8450+'contains\x20undefined\x20'+Oe(_0xca41d));if(typeof _0x2dd9f0=='function')throw new Error(_0x3b8450+'contains\x20a\x20function\x20'+Oe(_0xca41d)+'\x20with\x20contents\x20=\x20'+_0x2dd9f0['toString']());if(xn(_0x2dd9f0))throw new Error(_0x3b8450+'contains\x20'+_0x2dd9f0['toString']()+'\x20'+Oe(_0xca41d));if(typeof _0x2dd9f0=='string'&&_0x2dd9f0['length']>ui/0x3&&Ln(_0x2dd9f0)>ui)throw new Error(_0x3b8450+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0xca41d)+'\x20(\x27'+_0x2dd9f0['substring'](0x0,0x32)+'...\x27)');if(_0x2dd9f0&&typeof _0x2dd9f0=='object'){let _0x49f01e=!0x1,_0x51bcbe=!0x1;if(x(_0x2dd9f0,(_0x35b87c,_0x977638)=>{if(_0x35b87c==='.value')_0x49f01e=!0x0;else{if(_0x35b87c!=='.priority'&&_0x35b87c!=='.sv'&&(_0x51bcbe=!0x0,!ms(_0x35b87c)))throw new Error(_0x3b8450+'\x20contains\x20an\x20invalid\x20key\x20('+_0x35b87c+')\x20'+Oe(_0xca41d)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0xca41d,_0x35b87c),Jt(_0x3b8450,_0x977638,_0xca41d),Ph(_0xca41d);}),_0x49f01e&&_0x51bcbe)throw new Error(_0x3b8450+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0xca41d)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x3f4026,_0x5076f3){let _0xe9aae1,_0x2adf40;for(_0xe9aae1=0x0;_0xe9aae1<_0x5076f3['length'];_0xe9aae1++){_0x2adf40=_0x5076f3[_0xe9aae1];const _0x65f3f2=Mt(_0x2adf40);for(let _0x10d849=0x0;_0x10d849<_0x65f3f2['length'];_0x10d849++)if(!(_0x65f3f2[_0x10d849]==='.priority'&&_0x10d849===_0x65f3f2['length']-0x1)){if(!ms(_0x65f3f2[_0x10d849]))throw new Error(_0x3f4026+'contains\x20an\x20invalid\x20key\x20('+_0x65f3f2[_0x10d849]+')\x20in\x20path\x20'+_0x2adf40['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5076f3['sort'](Rh);let _0x3851a0=null;for(_0xe9aae1=0x0;_0xe9aae1<_0x5076f3['length'];_0xe9aae1++){if(_0x2adf40=_0x5076f3[_0xe9aae1],_0x3851a0!==null&&G(_0x3851a0,_0x2adf40))throw new Error(_0x3f4026+'contains\x20a\x20path\x20'+_0x3851a0['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2adf40['toString']());_0x3851a0=_0x2adf40;}},ra=function(_0x1ea862,_0x352d1c,_0x496a12,_0x4ce799){const _0x3e3930=it(_0x1ea862,'values');if(!(_0x352d1c&&typeof _0x352d1c=='object')||Array['isArray'](_0x352d1c))throw new Error(_0x3e3930+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3f3cdb=[];x(_0x352d1c,(_0x51d32e,_0x5bdfcc)=>{const _0x224cc9=new C(_0x51d32e);if(Jt(_0x3e3930,_0x5bdfcc,k(_0x496a12,_0x224cc9)),ji(_0x224cc9)==='.priority'&&!Bt(_0x5bdfcc))throw new Error(_0x3e3930+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x224cc9['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3f3cdb['push'](_0x224cc9);}),dd(_0x3e3930,_0x3f3cdb);},fd=function(_0x355cab,_0x2ea4c2,_0x2bbb8c){if(xn(_0x2ea4c2))throw new Error(it(_0x355cab,'priority')+'is\x20'+_0x2ea4c2['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x2ea4c2))throw new Error(it(_0x355cab,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x3300ba,_0x2e32fb,_0x1f521e,_0x36b374){if(!sa(_0x1f521e))throw new Error(it(_0x3300ba,_0x2e32fb)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1f521e+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x40b627,_0x23342c,_0x674909,_0x4378d2){_0x674909&&(_0x674909=_0x674909['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x40b627,_0x23342c,_0x674909);},Me=function(_0x414bdb,_0x3c0009){if(y(_0x3c0009)==='.info')throw new Error(_0x414bdb+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x5ee148,_0x1c94f1){const _0x3feac3=_0x1c94f1['path']['toString']();if(typeof _0x1c94f1['repoInfo']['host']!='string'||_0x1c94f1['repoInfo']['host']['length']===0x0||!ms(_0x1c94f1['repoInfo']['namespace'])&&_0x1c94f1['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x3feac3['length']!==0x0&&!ud(_0x3feac3))throw new Error(it(_0x5ee148,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x5dd5e5,_0x498352){let _0x3511d5=null;for(let _0x240ff1=0x0;_0x240ff1<_0x498352['length'];_0x240ff1++){const _0x31f53f=_0x498352[_0x240ff1],_0x588730=_0x31f53f['getPath']();_0x3511d5!==null&&!Ki(_0x588730,_0x3511d5['path'])&&(_0x5dd5e5['eventLists_']['push'](_0x3511d5),_0x3511d5=null),_0x3511d5===null&&(_0x3511d5={'events':[],'path':_0x588730}),_0x3511d5['events']['push'](_0x31f53f);}_0x3511d5&&_0x5dd5e5['eventLists_']['push'](_0x3511d5);}function oa(_0x5d6d37,_0x32c55e,_0x28f092){qn(_0x5d6d37,_0x28f092),aa(_0x5d6d37,_0x564acc=>Ki(_0x564acc,_0x32c55e));}function V(_0x393e2e,_0x1399d5,_0x2fe430){qn(_0x393e2e,_0x2fe430),aa(_0x393e2e,_0x37cb7e=>G(_0x37cb7e,_0x1399d5)||G(_0x1399d5,_0x37cb7e));}function aa(_0x5ba8ab,_0x2c4716){_0x5ba8ab['recursionDepth_']++;let _0x4cffdb=!0x0;for(let _0x413f43=0x0;_0x413f43<_0x5ba8ab['eventLists_']['length'];_0x413f43++){const _0x4ab125=_0x5ba8ab['eventLists_'][_0x413f43];if(_0x4ab125){const _0x1544ed=_0x4ab125['path'];_0x2c4716(_0x1544ed)?(md(_0x5ba8ab['eventLists_'][_0x413f43]),_0x5ba8ab['eventLists_'][_0x413f43]=null):_0x4cffdb=!0x1;}}_0x4cffdb&&(_0x5ba8ab['eventLists_']=[]),_0x5ba8ab['recursionDepth_']--;}function md(_0x46d405){for(let _0x51a2e0=0x0;_0x51a2e0<_0x46d405['events']['length'];_0x51a2e0++){const _0x35f2d8=_0x46d405['events'][_0x51a2e0];if(_0x35f2d8!==null){_0x46d405['events'][_0x51a2e0]=null;const _0x499b90=_0x35f2d8['getEventRunner']();St&&L('event:\x20'+_0x35f2d8['toString']()),ft(_0x499b90);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x179bf2,_0x1a97d9,_0x7d46b5,_0x53cf73){this['repoInfo_']=_0x179bf2,this['forceRestClient_']=_0x1a97d9,this['authTokenProvider_']=_0x7d46b5,this['appCheckProvider_']=_0x53cf73,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x280fb2,_0xafab49,_0x564e4d){if(_0x280fb2['stats_']=qi(_0x280fb2['repoInfo_']),_0x280fb2['forceRestClient_']||Xl())_0x280fb2['server_']=new vn(_0x280fb2['repoInfo_'],(_0x502541,_0x4909bc,_0xbf41fa,_0x1ac440)=>{gr(_0x280fb2,_0x502541,_0x4909bc,_0xbf41fa,_0x1ac440);},_0x280fb2['authTokenProvider_'],_0x280fb2['appCheckProvider_']),setTimeout(()=>mr(_0x280fb2,!0x0),0x0);else{if(typeof _0x564e4d<'u'&&_0x564e4d!==null){if(typeof _0x564e4d!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x564e4d);}catch(_0x27f3d2){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x27f3d2);}}_0x280fb2['persistentConnection_']=new se(_0x280fb2['repoInfo_'],_0xafab49,(_0x5c749c,_0x162115,_0x28185f,_0x2c47a4)=>{gr(_0x280fb2,_0x5c749c,_0x162115,_0x28185f,_0x2c47a4);},_0x2967ea=>{mr(_0x280fb2,_0x2967ea);},_0x3fd26c=>{Id(_0x280fb2,_0x3fd26c);},_0x280fb2['authTokenProvider_'],_0x280fb2['appCheckProvider_'],_0x564e4d),_0x280fb2['server_']=_0x280fb2['persistentConnection_'];}_0x280fb2['authTokenProvider_']['addTokenChangeListener'](_0x22e902=>{_0x280fb2['server_']['refreshAuthToken'](_0x22e902);}),_0x280fb2['appCheckProvider_']['addTokenChangeListener'](_0x507fc8=>{_0x280fb2['server_']['refreshAppCheckToken'](_0x507fc8['token']);}),_0x280fb2['statsReporter_']=ih(_0x280fb2['repoInfo_'],()=>new iu(_0x280fb2['stats_'],_0x280fb2['server_'])),_0x280fb2['infoData_']=new Xh(),_0x280fb2['infoSyncTree_']=new pr({'startListening':(_0x1529ed,_0x112c55,_0x422685,_0x2e602f)=>{let _0x2885d9=[];const _0x4196ca=_0x280fb2['infoData_']['getNode'](_0x1529ed['_path']);return _0x4196ca['isEmpty']()||(_0x2885d9=Yt(_0x280fb2['infoSyncTree_'],_0x1529ed['_path'],_0x4196ca),setTimeout(()=>{_0x2e602f('ok');},0x0)),_0x2885d9;},'stopListening':()=>{}}),vs(_0x280fb2,'connected',!0x1),_0x280fb2['serverSyncTree_']=new pr({'startListening':(_0x289eea,_0x23c4da,_0x257b69,_0x2089d7)=>(_0x280fb2['server_']['listen'](_0x289eea,_0x257b69,_0x23c4da,(_0x25101c,_0x4ffd38)=>{const _0x26d204=_0x2089d7(_0x25101c,_0x4ffd38);V(_0x280fb2['eventQueue_'],_0x289eea['_path'],_0x26d204);}),[]),'stopListening':(_0x5bf198,_0x2da2d7)=>{_0x280fb2['server_']['unlisten'](_0x5bf198,_0x2da2d7);}});}function la(_0x166aee){const _0x42e7bb=_0x166aee['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x42e7bb;}function Xt(_0x4623d5){return id({'timestamp':la(_0x4623d5)});}function gr(_0x51cbd2,_0x2c87d6,_0x53e694,_0x2b77e0,_0x10edc7){_0x51cbd2['dataUpdateCount']++;const _0x2b1982=new C(_0x2c87d6);_0x53e694=_0x51cbd2['interceptServerDataCallback_']?_0x51cbd2['interceptServerDataCallback_'](_0x2c87d6,_0x53e694):_0x53e694;let _0x4840ed=[];if(_0x10edc7){if(_0x2b77e0){const _0x28d23a=_n(_0x53e694,_0x599aed=>A(_0x599aed));_0x4840ed=Ju(_0x51cbd2['serverSyncTree_'],_0x2b1982,_0x28d23a,_0x10edc7);}else{const _0x5ebdba=A(_0x53e694);_0x4840ed=Jo(_0x51cbd2['serverSyncTree_'],_0x2b1982,_0x5ebdba,_0x10edc7);}}else{if(_0x2b77e0){const _0x33c340=_n(_0x53e694,_0x5ddfca=>A(_0x5ddfca));_0x4840ed=Ku(_0x51cbd2['serverSyncTree_'],_0x2b1982,_0x33c340);}else{const _0x5091fd=A(_0x53e694);_0x4840ed=Yt(_0x51cbd2['serverSyncTree_'],_0x2b1982,_0x5091fd);}}let _0x595275=_0x2b1982;_0x4840ed['length']>0x0&&(_0x595275=ct(_0x51cbd2,_0x2b1982)),V(_0x51cbd2['eventQueue_'],_0x595275,_0x4840ed);}function mr(_0x476ec9,_0x2acedf){vs(_0x476ec9,'connected',_0x2acedf),_0x2acedf===!0x1&&Sd(_0x476ec9);}function Id(_0x52b81a,_0x140f6b){x(_0x140f6b,(_0x250472,_0x9d36dd)=>{vs(_0x52b81a,_0x250472,_0x9d36dd);});}function vs(_0x4da190,_0x122641,_0x32e5e2){const _0x4a856a=new C('/.info/'+_0x122641),_0x266f71=A(_0x32e5e2);_0x4da190['infoData_']['updateSnapshot'](_0x4a856a,_0x266f71);const _0x3d44f8=Yt(_0x4da190['infoSyncTree_'],_0x4a856a,_0x266f71);V(_0x4da190['eventQueue_'],_0x4a856a,_0x3d44f8);}function zn(_0x17698d){return _0x17698d['nextWriteId_']++;}function wd(_0x359767,_0x297cec,_0x5bd7e9){const _0x58f536=Xu(_0x359767['serverSyncTree_'],_0x297cec);return _0x58f536!=null?Promise['resolve'](_0x58f536):_0x359767['server_']['get'](_0x297cec)['then'](_0x270357=>{const _0x5e57ca=A(_0x270357)['withIndex'](_0x297cec['_queryParams']['getIndex']());Ni(_0x359767['serverSyncTree_'],_0x297cec,_0x5bd7e9,!0x0);let _0x4ae2d8;if(_0x297cec['_queryParams']['loadsAllData']())_0x4ae2d8=Yt(_0x359767['serverSyncTree_'],_0x297cec['_path'],_0x5e57ca);else{const _0x3d5890=Wt(_0x359767['serverSyncTree_'],_0x297cec);_0x4ae2d8=Jo(_0x359767['serverSyncTree_'],_0x297cec['_path'],_0x5e57ca,_0x3d5890);}return V(_0x359767['eventQueue_'],_0x297cec['_path'],_0x4ae2d8),An(_0x359767['serverSyncTree_'],_0x297cec,_0x5bd7e9,null,!0x0),_0x5e57ca;},_0x5a432a=>(gt(_0x359767,'get\x20for\x20query\x20'+O(_0x297cec)+'\x20failed:\x20'+_0x5a432a),Promise['reject'](new Error(_0x5a432a))));}function Cd(_0x4d7068,_0x102987,_0x3c3dba,_0x2b1e80,_0x3915ee){gt(_0x4d7068,'set',{'path':_0x102987['toString'](),'value':_0x3c3dba,'priority':_0x2b1e80});const _0x3bd7b4=Xt(_0x4d7068),_0x93ef7f=A(_0x3c3dba,_0x2b1e80),_0x5f4644=Vn(_0x4d7068['serverSyncTree_'],_0x102987),_0x577188=fs(_0x93ef7f,_0x5f4644,_0x3bd7b4),_0x2e330b=zn(_0x4d7068),_0x2a48a4=as(_0x4d7068['serverSyncTree_'],_0x102987,_0x577188,_0x2e330b,!0x0);qn(_0x4d7068['eventQueue_'],_0x2a48a4),_0x4d7068['server_']['put'](_0x102987['toString'](),_0x93ef7f['val'](!0x0),(_0x50e19c,_0x13915e)=>{const _0x525727=_0x50e19c==='ok';_0x525727||U('set\x20at\x20'+_0x102987+'\x20failed:\x20'+_0x50e19c);const _0x3e1a18=_e(_0x4d7068['serverSyncTree_'],_0x2e330b,!_0x525727);V(_0x4d7068['eventQueue_'],_0x102987,_0x3e1a18),be(_0x4d7068,_0x3915ee,_0x50e19c,_0x13915e);});const _0x4081a9=Is(_0x4d7068,_0x102987);ct(_0x4d7068,_0x4081a9),V(_0x4d7068['eventQueue_'],_0x4081a9,[]);}function Td(_0xeca149,_0x5997aa,_0x4c0dcd,_0x14fe2d){gt(_0xeca149,'update',{'path':_0x5997aa['toString'](),'value':_0x4c0dcd});let _0x4922ac=!0x0;const _0x1df465=Xt(_0xeca149),_0x47c64f={};if(x(_0x4c0dcd,(_0x302bc0,_0x24a69a)=>{_0x4922ac=!0x1,_0x47c64f[_0x302bc0]=ta(k(_0x5997aa,_0x302bc0),A(_0x24a69a),_0xeca149['serverSyncTree_'],_0x1df465);}),_0x4922ac)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0xeca149,_0x14fe2d,'ok',void 0x0);else{const _0x38b631=zn(_0xeca149),_0x5d979a=ju(_0xeca149['serverSyncTree_'],_0x5997aa,_0x47c64f,_0x38b631);qn(_0xeca149['eventQueue_'],_0x5d979a),_0xeca149['server_']['merge'](_0x5997aa['toString'](),_0x4c0dcd,(_0x3403bb,_0x5dbe04)=>{const _0x1f6731=_0x3403bb==='ok';_0x1f6731||U('update\x20at\x20'+_0x5997aa+'\x20failed:\x20'+_0x3403bb);const _0x244a61=_e(_0xeca149['serverSyncTree_'],_0x38b631,!_0x1f6731),_0x16f1c1=_0x244a61['length']>0x0?ct(_0xeca149,_0x5997aa):_0x5997aa;V(_0xeca149['eventQueue_'],_0x16f1c1,_0x244a61),be(_0xeca149,_0x14fe2d,_0x3403bb,_0x5dbe04);}),x(_0x4c0dcd,_0x459121=>{const _0x22bba3=Is(_0xeca149,k(_0x5997aa,_0x459121));ct(_0xeca149,_0x22bba3);}),V(_0xeca149['eventQueue_'],_0x5997aa,[]);}}function Sd(_0x4784d7){gt(_0x4784d7,'onDisconnectEvents');const _0x2cd675=Xt(_0x4784d7),_0x3a8f06=En();Si(_0x4784d7['onDisconnect_'],w(),(_0x17ddd7,_0x75efd0)=>{const _0x576232=ta(_0x17ddd7,_0x75efd0,_0x4784d7['serverSyncTree_'],_0x2cd675);pt(_0x3a8f06,_0x17ddd7,_0x576232);});let _0x48c930=[];Si(_0x3a8f06,w(),(_0x512fad,_0x484538)=>{_0x48c930=_0x48c930['concat'](Yt(_0x4784d7['serverSyncTree_'],_0x512fad,_0x484538));const _0x4089cb=Is(_0x4784d7,_0x512fad);ct(_0x4784d7,_0x4089cb);}),_0x4784d7['onDisconnect_']=En(),V(_0x4784d7['eventQueue_'],w(),_0x48c930);}function bd(_0x3d42c1,_0x3a3244,_0x3d923d){_0x3d42c1['server_']['onDisconnectCancel'](_0x3a3244['toString'](),(_0x4a2bcb,_0xded5c1)=>{_0x4a2bcb==='ok'&&Ti(_0x3d42c1['onDisconnect_'],_0x3a3244),be(_0x3d42c1,_0x3d923d,_0x4a2bcb,_0xded5c1);});}function yr(_0x3b7c5e,_0x4931a0,_0x22a4f6,_0x257dd0){const _0x351597=A(_0x22a4f6);_0x3b7c5e['server_']['onDisconnectPut'](_0x4931a0['toString'](),_0x351597['val'](!0x0),(_0x5938ef,_0x1b83c3)=>{_0x5938ef==='ok'&&pt(_0x3b7c5e['onDisconnect_'],_0x4931a0,_0x351597),be(_0x3b7c5e,_0x257dd0,_0x5938ef,_0x1b83c3);});}function Rd(_0x1680d2,_0x3fc244,_0x9def46,_0x12f584,_0x57b51c){const _0x2ced6d=A(_0x9def46,_0x12f584);_0x1680d2['server_']['onDisconnectPut'](_0x3fc244['toString'](),_0x2ced6d['val'](!0x0),(_0x4ac649,_0x50a48d)=>{_0x4ac649==='ok'&&pt(_0x1680d2['onDisconnect_'],_0x3fc244,_0x2ced6d),be(_0x1680d2,_0x57b51c,_0x4ac649,_0x50a48d);});}function Ad(_0x69cc78,_0x4f5fb4,_0x20a88d,_0x4cab2c){if(pn(_0x20a88d)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x69cc78,_0x4cab2c,'ok',void 0x0);return;}_0x69cc78['server_']['onDisconnectMerge'](_0x4f5fb4['toString'](),_0x20a88d,(_0x104772,_0x5a5b1d)=>{_0x104772==='ok'&&x(_0x20a88d,(_0x2b0311,_0x4a07d7)=>{const _0x54da60=A(_0x4a07d7);pt(_0x69cc78['onDisconnect_'],k(_0x4f5fb4,_0x2b0311),_0x54da60);}),be(_0x69cc78,_0x4cab2c,_0x104772,_0x5a5b1d);});}function kd(_0x13b83c,_0x28cc9d,_0x19c759){let _0x4d998c;y(_0x28cc9d['_path'])==='.info'?_0x4d998c=Ni(_0x13b83c['infoSyncTree_'],_0x28cc9d,_0x19c759):_0x4d998c=Ni(_0x13b83c['serverSyncTree_'],_0x28cc9d,_0x19c759),oa(_0x13b83c['eventQueue_'],_0x28cc9d['_path'],_0x4d998c);}function Pd(_0x2e53f2,_0x149662,_0x3cd84c){let _0x3fe39b;y(_0x149662['_path'])==='.info'?_0x3fe39b=An(_0x2e53f2['infoSyncTree_'],_0x149662,_0x3cd84c):_0x3fe39b=An(_0x2e53f2['serverSyncTree_'],_0x149662,_0x3cd84c),oa(_0x2e53f2['eventQueue_'],_0x149662['_path'],_0x3fe39b);}function ha(_0x302b85){_0x302b85['persistentConnection_']&&_0x302b85['persistentConnection_']['interrupt'](ca);}function Nd(_0x147faf){_0x147faf['persistentConnection_']&&_0x147faf['persistentConnection_']['resume'](ca);}function gt(_0x47c5cb,..._0x22e8b5){let _0x34b48a='';_0x47c5cb['persistentConnection_']&&(_0x34b48a=_0x47c5cb['persistentConnection_']['id']+':'),L(_0x34b48a,..._0x22e8b5);}function be(_0x352dca,_0x5d1758,_0xd388,_0x31cce5){_0x5d1758&&ft(()=>{if(_0xd388==='ok')_0x5d1758(null);else{const _0x462613=(_0xd388||'error')['toUpperCase']();let _0x4c59f2=_0x462613;_0x31cce5&&(_0x4c59f2+=':\x20'+_0x31cce5);const _0x483741=new Error(_0x4c59f2);_0x483741['code']=_0x462613,_0x5d1758(_0x483741);}});}function Od(_0x378466,_0x392b03,_0x45ab64,_0x1b035d,_0x568d7d,_0xda8f5b){gt(_0x378466,'transaction\x20on\x20'+_0x392b03);const _0x2e568c={'path':_0x392b03,'update':_0x45ab64,'onComplete':_0x1b035d,'status':null,'order':so(),'applyLocally':_0xda8f5b,'retryCount':0x0,'unwatcher':_0x568d7d,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3e36f0=Es(_0x378466,_0x392b03,void 0x0);_0x2e568c['currentInputSnapshot']=_0x3e36f0;const _0x230d16=_0x2e568c['update'](_0x3e36f0['val']());if(_0x230d16===void 0x0)_0x2e568c['unwatcher'](),_0x2e568c['currentOutputSnapshotRaw']=null,_0x2e568c['currentOutputSnapshotResolved']=null,_0x2e568c['onComplete']&&_0x2e568c['onComplete'](null,!0x1,_0x2e568c['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x230d16,_0x2e568c['path']),_0x2e568c['status']=0x0;const _0x37d6ec=$n(_0x378466['transactionQueueTree_'],_0x392b03),_0x2f53b0=je(_0x37d6ec)||[];_0x2f53b0['push'](_0x2e568c),gs(_0x37d6ec,_0x2f53b0);let _0x57dc9d;typeof _0x230d16=='object'&&_0x230d16!==null&&Q(_0x230d16,'.priority')?(_0x57dc9d=Le(_0x230d16,'.priority'),f(Bt(_0x57dc9d),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x57dc9d=(Vn(_0x378466['serverSyncTree_'],_0x392b03)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x2b8120=Xt(_0x378466),_0x2687e5=A(_0x230d16,_0x57dc9d),_0x22153a=fs(_0x2687e5,_0x3e36f0,_0x2b8120);_0x2e568c['currentOutputSnapshotRaw']=_0x2687e5,_0x2e568c['currentOutputSnapshotResolved']=_0x22153a,_0x2e568c['currentWriteId']=zn(_0x378466);const _0x80864b=as(_0x378466['serverSyncTree_'],_0x392b03,_0x22153a,_0x2e568c['currentWriteId'],_0x2e568c['applyLocally']);V(_0x378466['eventQueue_'],_0x392b03,_0x80864b),jn(_0x378466,_0x378466['transactionQueueTree_']);}}function Es(_0x4be156,_0x5f1bb2,_0x3cee68){return Vn(_0x4be156['serverSyncTree_'],_0x5f1bb2,_0x3cee68)||g['EMPTY_NODE'];}function jn(_0x4634aa,_0x29f813=_0x4634aa['transactionQueueTree_']){if(_0x29f813||Kn(_0x4634aa,_0x29f813),je(_0x29f813)){const _0x4d98cd=da(_0x4634aa,_0x29f813);f(_0x4d98cd['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4d98cd['every'](_0x38fdf4=>_0x38fdf4['status']===0x0)&&Dd(_0x4634aa,Qt(_0x29f813),_0x4d98cd);}else na(_0x29f813)&&Gn(_0x29f813,_0x23e9a1=>{jn(_0x4634aa,_0x23e9a1);});}function Dd(_0x3e4f61,_0x1b0488,_0x99177a){const _0x4a76cc=_0x99177a['map'](_0x5ace29=>_0x5ace29['currentWriteId']),_0x10c963=Es(_0x3e4f61,_0x1b0488,_0x4a76cc);let _0x1d5125=_0x10c963;const _0x33c6a6=_0x10c963['hash']();for(let _0xec3fce=0x0;_0xec3fce<_0x99177a['length'];_0xec3fce++){const _0x125abe=_0x99177a[_0xec3fce];f(_0x125abe['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x125abe['status']=0x1,_0x125abe['retryCount']++;const _0x5193d9=F(_0x1b0488,_0x125abe['path']);_0x1d5125=_0x1d5125['updateChild'](_0x5193d9,_0x125abe['currentOutputSnapshotRaw']);}const _0x1f696f=_0x1d5125['val'](!0x0),_0xe680c2=_0x1b0488;_0x3e4f61['server_']['put'](_0xe680c2['toString'](),_0x1f696f,_0x59763f=>{gt(_0x3e4f61,'transaction\x20put\x20response',{'path':_0xe680c2['toString'](),'status':_0x59763f});let _0x534ec5=[];if(_0x59763f==='ok'){const _0x3bf57d=[];for(let _0x44a04f=0x0;_0x44a04f<_0x99177a['length'];_0x44a04f++)_0x99177a[_0x44a04f]['status']=0x2,_0x534ec5=_0x534ec5['concat'](_e(_0x3e4f61['serverSyncTree_'],_0x99177a[_0x44a04f]['currentWriteId'])),_0x99177a[_0x44a04f]['onComplete']&&_0x3bf57d['push'](()=>_0x99177a[_0x44a04f]['onComplete'](null,!0x0,_0x99177a[_0x44a04f]['currentOutputSnapshotResolved'])),_0x99177a[_0x44a04f]['unwatcher']();Kn(_0x3e4f61,$n(_0x3e4f61['transactionQueueTree_'],_0x1b0488)),jn(_0x3e4f61,_0x3e4f61['transactionQueueTree_']),V(_0x3e4f61['eventQueue_'],_0x1b0488,_0x534ec5);for(let _0x14f394=0x0;_0x14f394<_0x3bf57d['length'];_0x14f394++)ft(_0x3bf57d[_0x14f394]);}else{if(_0x59763f==='datastale'){for(let _0x3ab451=0x0;_0x3ab451<_0x99177a['length'];_0x3ab451++)_0x99177a[_0x3ab451]['status']===0x3?_0x99177a[_0x3ab451]['status']=0x4:_0x99177a[_0x3ab451]['status']=0x0;}else{U('transaction\x20at\x20'+_0xe680c2['toString']()+'\x20failed:\x20'+_0x59763f);for(let _0xb90317=0x0;_0xb90317<_0x99177a['length'];_0xb90317++)_0x99177a[_0xb90317]['status']=0x4,_0x99177a[_0xb90317]['abortReason']=_0x59763f;}ct(_0x3e4f61,_0x1b0488);}},_0x33c6a6);}function ct(_0x889828,_0x1338b9){const _0x950684=ua(_0x889828,_0x1338b9),_0x12949b=Qt(_0x950684),_0x3d7e01=da(_0x889828,_0x950684);return Md(_0x889828,_0x3d7e01,_0x12949b),_0x12949b;}function Md(_0x2ee3d5,_0x11a068,_0x39c5fb){if(_0x11a068['length']===0x0)return;const _0xd4c678=[];let _0x4a9501=[];const _0x35e91f=_0x11a068['filter'](_0x2a5a23=>_0x2a5a23['status']===0x0)['map'](_0x4733ef=>_0x4733ef['currentWriteId']);for(let _0x55ed5e=0x0;_0x55ed5e<_0x11a068['length'];_0x55ed5e++){const _0xdbf249=_0x11a068[_0x55ed5e],_0x4478ed=F(_0x39c5fb,_0xdbf249['path']);let _0x46e44b=!0x1,_0x1aa6aa;if(f(_0x4478ed!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xdbf249['status']===0x4)_0x46e44b=!0x0,_0x1aa6aa=_0xdbf249['abortReason'],_0x4a9501=_0x4a9501['concat'](_e(_0x2ee3d5['serverSyncTree_'],_0xdbf249['currentWriteId'],!0x0));else{if(_0xdbf249['status']===0x0){if(_0xdbf249['retryCount']>=yd)_0x46e44b=!0x0,_0x1aa6aa='maxretry',_0x4a9501=_0x4a9501['concat'](_e(_0x2ee3d5['serverSyncTree_'],_0xdbf249['currentWriteId'],!0x0));else{const _0x1bc088=Es(_0x2ee3d5,_0xdbf249['path'],_0x35e91f);_0xdbf249['currentInputSnapshot']=_0x1bc088;const _0x13040a=_0x11a068[_0x55ed5e]['update'](_0x1bc088['val']());if(_0x13040a!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x13040a,_0xdbf249['path']);let _0x46691e=A(_0x13040a);typeof _0x13040a=='object'&&_0x13040a!=null&&Q(_0x13040a,'.priority')||(_0x46691e=_0x46691e['updatePriority'](_0x1bc088['getPriority']()));const _0x4e5d4b=_0xdbf249['currentWriteId'],_0x2389e0=Xt(_0x2ee3d5),_0x5d154a=fs(_0x46691e,_0x1bc088,_0x2389e0);_0xdbf249['currentOutputSnapshotRaw']=_0x46691e,_0xdbf249['currentOutputSnapshotResolved']=_0x5d154a,_0xdbf249['currentWriteId']=zn(_0x2ee3d5),_0x35e91f['splice'](_0x35e91f['indexOf'](_0x4e5d4b),0x1),_0x4a9501=_0x4a9501['concat'](as(_0x2ee3d5['serverSyncTree_'],_0xdbf249['path'],_0x5d154a,_0xdbf249['currentWriteId'],_0xdbf249['applyLocally'])),_0x4a9501=_0x4a9501['concat'](_e(_0x2ee3d5['serverSyncTree_'],_0x4e5d4b,!0x0));}else _0x46e44b=!0x0,_0x1aa6aa='nodata',_0x4a9501=_0x4a9501['concat'](_e(_0x2ee3d5['serverSyncTree_'],_0xdbf249['currentWriteId'],!0x0));}}}V(_0x2ee3d5['eventQueue_'],_0x39c5fb,_0x4a9501),_0x4a9501=[],_0x46e44b&&(_0x11a068[_0x55ed5e]['status']=0x2,function(_0x5e9b0e){setTimeout(_0x5e9b0e,Math['floor'](0x0));}(_0x11a068[_0x55ed5e]['unwatcher']),_0x11a068[_0x55ed5e]['onComplete']&&(_0x1aa6aa==='nodata'?_0xd4c678['push'](()=>_0x11a068[_0x55ed5e]['onComplete'](null,!0x1,_0x11a068[_0x55ed5e]['currentInputSnapshot'])):_0xd4c678['push'](()=>_0x11a068[_0x55ed5e]['onComplete'](new Error(_0x1aa6aa),!0x1,null))));}Kn(_0x2ee3d5,_0x2ee3d5['transactionQueueTree_']);for(let _0xd207c6=0x0;_0xd207c6<_0xd4c678['length'];_0xd207c6++)ft(_0xd4c678[_0xd207c6]);jn(_0x2ee3d5,_0x2ee3d5['transactionQueueTree_']);}function ua(_0x55bf6a,_0x43cc6b){let _0x4bdb6a,_0x35eb2e=_0x55bf6a['transactionQueueTree_'];for(_0x4bdb6a=y(_0x43cc6b);_0x4bdb6a!==null&&je(_0x35eb2e)===void 0x0;)_0x35eb2e=$n(_0x35eb2e,_0x4bdb6a),_0x43cc6b=S(_0x43cc6b),_0x4bdb6a=y(_0x43cc6b);return _0x35eb2e;}function da(_0x5b820a,_0xf6129e){const _0x55f6ea=[];return fa(_0x5b820a,_0xf6129e,_0x55f6ea),_0x55f6ea['sort']((_0x4b122a,_0x612316)=>_0x4b122a['order']-_0x612316['order']),_0x55f6ea;}function fa(_0x1b816b,_0x6fbc23,_0x5b6757){const _0x1db498=je(_0x6fbc23);if(_0x1db498){for(let _0x17a0ba=0x0;_0x17a0ba<_0x1db498['length'];_0x17a0ba++)_0x5b6757['push'](_0x1db498[_0x17a0ba]);}Gn(_0x6fbc23,_0x490972=>{fa(_0x1b816b,_0x490972,_0x5b6757);});}function Kn(_0x58758e,_0x4e5cbb){const _0x40260b=je(_0x4e5cbb);if(_0x40260b){let _0x43ee1c=0x0;for(let _0x4333ac=0x0;_0x4333ac<_0x40260b['length'];_0x4333ac++)_0x40260b[_0x4333ac]['status']!==0x2&&(_0x40260b[_0x43ee1c]=_0x40260b[_0x4333ac],_0x43ee1c++);_0x40260b['length']=_0x43ee1c,gs(_0x4e5cbb,_0x40260b['length']>0x0?_0x40260b:void 0x0);}Gn(_0x4e5cbb,_0x5bcd75=>{Kn(_0x58758e,_0x5bcd75);});}function Is(_0x46f5cf,_0x5e3a9a){const _0x4075d2=Qt(ua(_0x46f5cf,_0x5e3a9a)),_0x562689=$n(_0x46f5cf['transactionQueueTree_'],_0x5e3a9a);return ad(_0x562689,_0x11e59d=>{di(_0x46f5cf,_0x11e59d);}),di(_0x46f5cf,_0x562689),ia(_0x562689,_0x507da8=>{di(_0x46f5cf,_0x507da8);}),_0x4075d2;}function di(_0x93360a,_0x5b8e78){const _0x348c52=je(_0x5b8e78);if(_0x348c52){const _0x1986b0=[];let _0x3b95c6=[],_0x556b75=-0x1;for(let _0x4ca2df=0x0;_0x4ca2df<_0x348c52['length'];_0x4ca2df++)_0x348c52[_0x4ca2df]['status']===0x3||(_0x348c52[_0x4ca2df]['status']===0x1?(f(_0x556b75===_0x4ca2df-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x556b75=_0x4ca2df,_0x348c52[_0x4ca2df]['status']=0x3,_0x348c52[_0x4ca2df]['abortReason']='set'):(f(_0x348c52[_0x4ca2df]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x348c52[_0x4ca2df]['unwatcher'](),_0x3b95c6=_0x3b95c6['concat'](_e(_0x93360a['serverSyncTree_'],_0x348c52[_0x4ca2df]['currentWriteId'],!0x0)),_0x348c52[_0x4ca2df]['onComplete']&&_0x1986b0['push'](_0x348c52[_0x4ca2df]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x556b75===-0x1?gs(_0x5b8e78,void 0x0):_0x348c52['length']=_0x556b75+0x1,V(_0x93360a['eventQueue_'],Qt(_0x5b8e78),_0x3b95c6);for(let _0x59335c=0x0;_0x59335c<_0x1986b0['length'];_0x59335c++)ft(_0x1986b0[_0x59335c]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x5283fe){let _0x4d6188='';const _0x95f355=_0x5283fe['split']('/');for(let _0x21a220=0x0;_0x21a220<_0x95f355['length'];_0x21a220++)if(_0x95f355[_0x21a220]['length']>0x0){let _0x386fc3=_0x95f355[_0x21a220];try{_0x386fc3=decodeURIComponent(_0x386fc3['replace'](/\+/g,'\x20'));}catch{}_0x4d6188+='/'+_0x386fc3;}return _0x4d6188;}function xd(_0x1da44f){const _0x5ce956={};_0x1da44f['charAt'](0x0)==='?'&&(_0x1da44f=_0x1da44f['substring'](0x1));for(const _0x5e52c9 of _0x1da44f['split']('&')){if(_0x5e52c9['length']===0x0)continue;const _0x542d83=_0x5e52c9['split']('=');_0x542d83['length']===0x2?_0x5ce956[decodeURIComponent(_0x542d83[0x0])]=decodeURIComponent(_0x542d83[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x5e52c9+'\x27\x20in\x20query\x20\x27'+_0x1da44f+'\x27');}return _0x5ce956;}const vr=function(_0x702cb5,_0x35ea89){const _0x436837=Fd(_0x702cb5),_0x27a9c6=_0x436837['namespace'];_0x436837['domain']==='firebase.com'&&ae(_0x436837['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x27a9c6||_0x27a9c6==='undefined')&&_0x436837['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x436837['secure']||$l();const _0x555ec6=_0x436837['scheme']==='ws'||_0x436837['scheme']==='wss';return{'repoInfo':new yo(_0x436837['host'],_0x436837['secure'],_0x27a9c6,_0x555ec6,_0x35ea89,'',_0x27a9c6!==_0x436837['subdomain']),'path':new C(_0x436837['pathString'])};},Fd=function(_0x55377c){let _0x115e5b='',_0x1c53b4='',_0x46c324='',_0x5bc7ea='',_0x55d802='',_0x3ebc76=!0x0,_0x3719d0='https',_0x3ca415=0x1bb;if(typeof _0x55377c=='string'){let _0x52790a=_0x55377c['indexOf']('//');_0x52790a>=0x0&&(_0x3719d0=_0x55377c['substring'](0x0,_0x52790a-0x1),_0x55377c=_0x55377c['substring'](_0x52790a+0x2));let _0x5bb485=_0x55377c['indexOf']('/');_0x5bb485===-0x1&&(_0x5bb485=_0x55377c['length']);let _0x2c6197=_0x55377c['indexOf']('?');_0x2c6197===-0x1&&(_0x2c6197=_0x55377c['length']),_0x115e5b=_0x55377c['substring'](0x0,Math['min'](_0x5bb485,_0x2c6197)),_0x5bb485<_0x2c6197&&(_0x5bc7ea=Ld(_0x55377c['substring'](_0x5bb485,_0x2c6197)));const _0x1b0406=xd(_0x55377c['substring'](Math['min'](_0x55377c['length'],_0x2c6197)));_0x52790a=_0x115e5b['indexOf'](':'),_0x52790a>=0x0?(_0x3ebc76=_0x3719d0==='https'||_0x3719d0==='wss',_0x3ca415=parseInt(_0x115e5b['substring'](_0x52790a+0x1),0xa)):_0x52790a=_0x115e5b['length'];const _0x3ee6d7=_0x115e5b['slice'](0x0,_0x52790a);if(_0x3ee6d7['toLowerCase']()==='localhost')_0x1c53b4='localhost';else{if(_0x3ee6d7['split']('.')['length']<=0x2)_0x1c53b4=_0x3ee6d7;else{const _0x1b2720=_0x115e5b['indexOf']('.');_0x46c324=_0x115e5b['substring'](0x0,_0x1b2720)['toLowerCase'](),_0x1c53b4=_0x115e5b['substring'](_0x1b2720+0x1),_0x55d802=_0x46c324;}}'ns'in _0x1b0406&&(_0x55d802=_0x1b0406['ns']);}return{'host':_0x115e5b,'port':_0x3ca415,'domain':_0x1c53b4,'subdomain':_0x46c324,'secure':_0x3ebc76,'scheme':_0x3719d0,'pathString':_0x5bc7ea,'namespace':_0x55d802};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x2fc523=0x0;const _0x471a9d=[];return function(_0x3f32a1){const _0x54329a=_0x3f32a1===_0x2fc523;_0x2fc523=_0x3f32a1;let _0x2ab408;const _0x82cd45=new Array(0x8);for(_0x2ab408=0x7;_0x2ab408>=0x0;_0x2ab408--)_0x82cd45[_0x2ab408]=Er['charAt'](_0x3f32a1%0x40),_0x3f32a1=Math['floor'](_0x3f32a1/0x40);f(_0x3f32a1===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x421af5=_0x82cd45['join']('');if(_0x54329a){for(_0x2ab408=0xb;_0x2ab408>=0x0&&_0x471a9d[_0x2ab408]===0x3f;_0x2ab408--)_0x471a9d[_0x2ab408]=0x0;_0x471a9d[_0x2ab408]++;}else{for(_0x2ab408=0x0;_0x2ab408<0xc;_0x2ab408++)_0x471a9d[_0x2ab408]=Math['floor'](Math['random']()*0x40);}for(_0x2ab408=0x0;_0x2ab408<0xc;_0x2ab408++)_0x421af5+=Er['charAt'](_0x471a9d[_0x2ab408]);return f(_0x421af5['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x421af5;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x127b39,_0x42c79c,_0x2312fd,_0x4e1de2){this['eventType']=_0x127b39,this['eventRegistration']=_0x42c79c,this['snapshot']=_0x2312fd,this['prevName']=_0x4e1de2;}['getPath'](){const _0xb5b4e4=this['snapshot']['ref'];return this['eventType']==='value'?_0xb5b4e4['_path']:_0xb5b4e4['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x108d35,_0x4de046,_0x54ee28){this['eventRegistration']=_0x108d35,this['error']=_0x4de046,this['path']=_0x54ee28;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x20f70d,_0x56e45b){this['snapshotCallback']=_0x20f70d,this['cancelCallback']=_0x56e45b;}['onValue'](_0x2278e3,_0x38ca57){this['snapshotCallback']['call'](null,_0x2278e3,_0x38ca57);}['onCancel'](_0x2ca3ce){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2ca3ce);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x381430){return this['snapshotCallback']===_0x381430['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x381430['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x381430['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x415ae6,_0x5524f9){this['_repo']=_0x415ae6,this['_path']=_0x5524f9;}['cancel'](){const _0x51a14f=new H();return bd(this['_repo'],this['_path'],_0x51a14f['wrapCallback'](()=>{})),_0x51a14f['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x3f2319=new H();return yr(this['_repo'],this['_path'],null,_0x3f2319['wrapCallback'](()=>{})),_0x3f2319['promise'];}['set'](_0x232112){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x232112,this['_path'],!0x1);const _0x58925a=new H();return yr(this['_repo'],this['_path'],_0x232112,_0x58925a['wrapCallback'](()=>{})),_0x58925a['promise'];}['setWithPriority'](_0x212256,_0x63d157){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x212256,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x63d157);const _0x4808bb=new H();return Rd(this['_repo'],this['_path'],_0x212256,_0x63d157,_0x4808bb['wrapCallback'](()=>{})),_0x4808bb['promise'];}['update'](_0x5dd2f6){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x5dd2f6,this['_path']);const _0xc57541=new H();return Ad(this['_repo'],this['_path'],_0x5dd2f6,_0xc57541['wrapCallback'](()=>{})),_0xc57541['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x44aa52,_0x117a05,_0x4ee15d,_0xf47ec4){this['_repo']=_0x44aa52,this['_path']=_0x117a05,this['_queryParams']=_0x4ee15d,this['_orderByCalled']=_0xf47ec4;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x45e4a9=sr(this['_queryParams']),_0x419b10=$i(_0x45e4a9);return _0x419b10==='{}'?'default':_0x419b10;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x1fecf7){if(_0x1fecf7=P(_0x1fecf7),!(_0x1fecf7 instanceof Ae))return!0x1;const _0x55ae69=this['_repo']===_0x1fecf7['_repo'],_0x530212=Ki(this['_path'],_0x1fecf7['_path']),_0x2eeddf=this['_queryIdentifier']===_0x1fecf7['_queryIdentifier'];return _0x55ae69&&_0x530212&&_0x2eeddf;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x41e558,_0x3d2517){if(_0x41e558['_orderByCalled']===!0x0)throw new Error(_0x3d2517+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0xf5517f){let _0x50091e=null,_0x110dbf=null;if(_0xf5517f['hasStart']()&&(_0x50091e=_0xf5517f['getIndexStartValue']()),_0xf5517f['hasEnd']()&&(_0x110dbf=_0xf5517f['getIndexEndValue']()),_0xf5517f['getIndex']()===ve){const _0x577388='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x540b80='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0xf5517f['hasStart']()){if(_0xf5517f['getIndexStartName']()!==We)throw new Error(_0x577388);if(typeof _0x50091e!='string')throw new Error(_0x540b80);}if(_0xf5517f['hasEnd']()){if(_0xf5517f['getIndexEndName']()!==we)throw new Error(_0x577388);if(typeof _0x110dbf!='string')throw new Error(_0x540b80);}}else{if(_0xf5517f['getIndex']()===R){if(_0x50091e!=null&&!Bt(_0x50091e)||_0x110dbf!=null&&!Bt(_0x110dbf))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0xf5517f['getIndex']()instanceof Ji||_0xf5517f['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x50091e!=null&&typeof _0x50091e=='object'||_0x110dbf!=null&&typeof _0x110dbf=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x2b468c){if(_0x2b468c['hasStart']()&&_0x2b468c['hasEnd']()&&_0x2b468c['hasLimit']()&&!_0x2b468c['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x20e4f1,_0x13ad96){super(_0x20e4f1,_0x13ad96,new Zi(),!0x1);}get['parent'](){const _0x52fc02=Ro(this['_path']);return _0x52fc02===null?null:new ee(this['_repo'],_0x52fc02);}get['root'](){let _0x36ac6d=this;for(;_0x36ac6d['parent']!==null;)_0x36ac6d=_0x36ac6d['parent'];return _0x36ac6d;}}class lt{constructor(_0x5cd633,_0x48d534,_0x301627){this['_node']=_0x5cd633,this['ref']=_0x48d534,this['_index']=_0x301627;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x23e746){const _0x3614e6=new C(_0x23e746),_0x5f4d66=Vt(this['ref'],_0x23e746);return new lt(this['_node']['getChild'](_0x3614e6),_0x5f4d66,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0xc5ee60){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5e4f99,_0x45030e)=>_0xc5ee60(new lt(_0x45030e,Vt(this['ref'],_0x5e4f99),R)));}['hasChild'](_0x1aa575){const _0x210a58=new C(_0x1aa575);return!this['_node']['getChild'](_0x210a58)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x52b25b,_0x4346cf){return _0x52b25b=P(_0x52b25b),_0x52b25b['_checkNotDeleted']('ref'),_0x4346cf!==void 0x0?Vt(_0x52b25b['_root'],_0x4346cf):_0x52b25b['_root'];}function Vt(_0x37674c,_0xaac0ec){return _0x37674c=P(_0x37674c),y(_0x37674c['_path'])===null?pd('child','path',_0xaac0ec):ys('child','path',_0xaac0ec),new ee(_0x37674c['_repo'],k(_0x37674c['_path'],_0xaac0ec));}function v_(_0x580e0b){return _0x580e0b=P(_0x580e0b),new Vd(_0x580e0b['_repo'],_0x580e0b['_path']);}function E_(_0x113dbb,_0x396390){_0x113dbb=P(_0x113dbb),Me('push',_0x113dbb['_path']),He('push',_0x396390,_0x113dbb['_path'],!0x0);const _0x5e8dab=la(_0x113dbb['_repo']),_0xe59c20=Ud(_0x5e8dab),_0x35a0f5=Vt(_0x113dbb,_0xe59c20),_0x32c174=Vt(_0x113dbb,_0xe59c20);let _0x14aff3;return _0x396390!=null?_0x14aff3=Hd(_0x32c174,_0x396390)['then'](()=>_0x32c174):_0x14aff3=Promise['resolve'](_0x32c174),_0x35a0f5['then']=_0x14aff3['then']['bind'](_0x14aff3),_0x35a0f5['catch']=_0x14aff3['then']['bind'](_0x14aff3,void 0x0),_0x35a0f5;}function Hd(_0xc17a9a,_0x357920){_0xc17a9a=P(_0xc17a9a),Me('set',_0xc17a9a['_path']),He('set',_0x357920,_0xc17a9a['_path'],!0x1);const _0x3e051e=new H();return Cd(_0xc17a9a['_repo'],_0xc17a9a['_path'],_0x357920,null,_0x3e051e['wrapCallback'](()=>{})),_0x3e051e['promise'];}function I_(_0x24afa5,_0x2a645){ra('update',_0x2a645,_0x24afa5['_path']);const _0x4b4090=new H();return Td(_0x24afa5['_repo'],_0x24afa5['_path'],_0x2a645,_0x4b4090['wrapCallback'](()=>{})),_0x4b4090['promise'];}function w_(_0x46373a){_0x46373a=P(_0x46373a);const _0x225b8e=new pa(()=>{}),_0xaf8ae5=new Qn(_0x225b8e);return wd(_0x46373a['_repo'],_0x46373a,_0xaf8ae5)['then'](_0x3aaac3=>new lt(_0x3aaac3,new ee(_0x46373a['_repo'],_0x46373a['_path']),_0x46373a['_queryParams']['getIndex']()));}class Qn{constructor(_0x2ac2f7){this['callbackContext']=_0x2ac2f7;}['respondsTo'](_0x4216fb){return _0x4216fb==='value';}['createEvent'](_0x31c38e,_0x27e3fe){const _0x3b869f=_0x27e3fe['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x31c38e['snapshotNode'],new ee(_0x27e3fe['_repo'],_0x27e3fe['_path']),_0x3b869f));}['getEventRunner'](_0x1e1715){return _0x1e1715['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1e1715['error']):()=>this['callbackContext']['onValue'](_0x1e1715['snapshot'],null);}['createCancelEvent'](_0x5a6445,_0x5c0c17){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x5a6445,_0x5c0c17):null;}['matches'](_0x4ad6e6){return _0x4ad6e6 instanceof Qn?!_0x4ad6e6['callbackContext']||!this['callbackContext']?!0x0:_0x4ad6e6['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x2e3e08,_0x55891d,_0x200e46,_0x404cc9,_0x3ec87f){const _0x31adef=new pa(_0x200e46,void 0x0),_0x52ae2d=new Qn(_0x31adef);return kd(_0x2e3e08['_repo'],_0x2e3e08,_0x52ae2d),()=>Pd(_0x2e3e08['_repo'],_0x2e3e08,_0x52ae2d);}function Gd(_0x5751bf,_0x1ea9b3,_0x553fbc,_0x4db8b3){return $d(_0x5751bf,'value',_0x1ea9b3);}class mt{}class ma extends mt{constructor(_0x558467,_0x735a37){super(),this['_value']=_0x558467,this['_key']=_0x735a37,this['type']='endAt';}['_apply'](_0x8b3001){He('endAt',this['_value'],_0x8b3001['_path'],!0x0);const _0x5688d8=Jh(_0x8b3001['_queryParams'],this['_value'],this['_key']);if(ga(_0x5688d8),Yn(_0x5688d8),_0x8b3001['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x8b3001['_repo'],_0x8b3001['_path'],_0x5688d8,_0x8b3001['_orderByCalled']);}}function C_(_0x48137c,_0x52202b){return new ma(_0x48137c,_0x52202b);}class ya extends mt{constructor(_0x205ae6,_0x140017){super(),this['_value']=_0x205ae6,this['_key']=_0x140017,this['type']='startAt';}['_apply'](_0x3d1df7){He('startAt',this['_value'],_0x3d1df7['_path'],!0x0);const _0x1e02b7=Qh(_0x3d1df7['_queryParams'],this['_value'],this['_key']);if(ga(_0x1e02b7),Yn(_0x1e02b7),_0x3d1df7['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x3d1df7['_repo'],_0x3d1df7['_path'],_0x1e02b7,_0x3d1df7['_orderByCalled']);}}function T_(_0x1cfa10=null,_0x349a31){return new ya(_0x1cfa10,_0x349a31);}class qd extends mt{constructor(_0x2ff40d){super(),this['_limit']=_0x2ff40d,this['type']='limitToFirst';}['_apply'](_0x57f2c3){if(_0x57f2c3['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x57f2c3['_repo'],_0x57f2c3['_path'],Yh(_0x57f2c3['_queryParams'],this['_limit']),_0x57f2c3['_orderByCalled']);}}function S_(_0x3f3177){if(Math['floor'](_0x3f3177)!==_0x3f3177||_0x3f3177<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x3f3177);}class zd extends mt{constructor(_0x2dfeae){super(),this['_path']=_0x2dfeae,this['type']='orderByChild';}['_apply'](_0x39c99b){_a(_0x39c99b,'orderByChild');const _0x46ca5d=new C(this['_path']);if(v(_0x46ca5d))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x491c23=new Ji(_0x46ca5d),_0x19fcd0=xo(_0x39c99b['_queryParams'],_0x491c23);return Yn(_0x19fcd0),new Ae(_0x39c99b['_repo'],_0x39c99b['_path'],_0x19fcd0,!0x0);}}function b_(_0x36fdba){if(_0x36fdba==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x36fdba==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x36fdba==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x36fdba),new zd(_0x36fdba);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xe2cc07){_a(_0xe2cc07,'orderByKey');const _0x52767a=xo(_0xe2cc07['_queryParams'],ve);return Yn(_0x52767a),new Ae(_0xe2cc07['_repo'],_0xe2cc07['_path'],_0x52767a,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x1ee121,_0x1cc55c){super(),this['_value']=_0x1ee121,this['_key']=_0x1cc55c,this['type']='equalTo';}['_apply'](_0x20e9ea){if(He('equalTo',this['_value'],_0x20e9ea['_path'],!0x1),_0x20e9ea['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x20e9ea['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x20e9ea));}}function A_(_0x557d3e,_0x243227){return new Kd(_0x557d3e,_0x243227);}function k_(_0x3c8acd,..._0x4eb66a){let _0x526c7a=P(_0x3c8acd);for(const _0x5d500d of _0x4eb66a)_0x526c7a=_0x5d500d['_apply'](_0x526c7a);return _0x526c7a;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x3d0d17,_0x37fd04,_0x14e885,_0x557e88){const _0x3ee1c4=_0x37fd04['lastIndexOf'](':'),_0x43baa4=_0x37fd04['substring'](0x0,_0x3ee1c4),_0xd79b59=qt(_0x43baa4);_0x3d0d17['repoInfo_']=new yo(_0x37fd04,_0xd79b59,_0x3d0d17['repoInfo_']['namespace'],_0x3d0d17['repoInfo_']['webSocketOnly'],_0x3d0d17['repoInfo_']['nodeAdmin'],_0x3d0d17['repoInfo_']['persistenceKey'],_0x3d0d17['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x14e885),_0x557e88&&(_0x3d0d17['authTokenProvider_']=_0x557e88);}function Xd(_0x56637b,_0x3f9c8f,_0x550045,_0x359830,_0x694cae){let _0x535062=_0x359830||_0x56637b['options']['databaseURL'];_0x535062===void 0x0&&(_0x56637b['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x56637b['options']['projectId']),_0x535062=_0x56637b['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x21eb8b=vr(_0x535062,_0x694cae),_0x1833d2=_0x21eb8b['repoInfo'],_0x5e685c;typeof process<'u'&&Bs&&(_0x5e685c=Bs[Yd]),_0x5e685c?(_0x535062='http://'+_0x5e685c+'?ns='+_0x1833d2['namespace'],_0x21eb8b=vr(_0x535062,_0x694cae),_0x1833d2=_0x21eb8b['repoInfo']):_0x21eb8b['repoInfo']['secure'];const _0x432064=new eh(_0x56637b['name'],_0x56637b['options'],_0x3f9c8f);_d('Invalid\x20Firebase\x20Database\x20URL',_0x21eb8b),v(_0x21eb8b['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x212101=ef(_0x1833d2,_0x56637b,_0x432064,new Zl(_0x56637b,_0x550045));return new tf(_0x212101,_0x56637b);}function Zd(_0x49e445,_0x56e84c){const _0x163537=Di[_0x56e84c];(!_0x163537||_0x163537[_0x49e445['key']]!==_0x49e445)&&ae('Database\x20'+_0x56e84c+'('+_0x49e445['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x49e445),delete _0x163537[_0x49e445['key']];}function ef(_0x1ec0dc,_0x2cd6f0,_0xcd44f3,_0x22b4c9){let _0x1a0e6a=Di[_0x2cd6f0['name']];_0x1a0e6a||(_0x1a0e6a={},Di[_0x2cd6f0['name']]=_0x1a0e6a);let _0x41fb92=_0x1a0e6a[_0x1ec0dc['toURLString']()];return _0x41fb92&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x41fb92=new vd(_0x1ec0dc,Qd,_0xcd44f3,_0x22b4c9),_0x1a0e6a[_0x1ec0dc['toURLString']()]=_0x41fb92,_0x41fb92;}class tf{constructor(_0x3e04e8,_0x15dd8){this['_repoInternal']=_0x3e04e8,this['app']=_0x15dd8,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x34c9a8){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x34c9a8+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x3e256f=Zr(),_0x288cdf){const _0x447ec6=Hi(_0x3e256f,'database')['getImmediate']({'identifier':_0x288cdf});if(!_0x447ec6['_instanceStarted']){const _0x2b17a1=hc('database');_0x2b17a1&&nf(_0x447ec6,..._0x2b17a1);}return _0x447ec6;}function nf(_0x55ace6,_0x55b0c7,_0x479a77,_0x5d0ca0={}){_0x55ace6=P(_0x55ace6),_0x55ace6['_checkNotDeleted']('useEmulator');const _0x1d77ea=_0x55b0c7+':'+_0x479a77,_0x36124f=_0x55ace6['_repoInternal'];if(_0x55ace6['_instanceStarted']){if(_0x1d77ea===_0x55ace6['_repoInternal']['repoInfo_']['host']&&xe(_0x5d0ca0,_0x36124f['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x20a775;if(_0x36124f['repoInfo_']['nodeAdmin'])_0x5d0ca0['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x20a775=new an(an['OWNER']);else{if(_0x5d0ca0['mockUserToken']){const _0x635bd=typeof _0x5d0ca0['mockUserToken']=='string'?_0x5d0ca0['mockUserToken']:uc(_0x5d0ca0['mockUserToken'],_0x55ace6['app']['options']['projectId']);_0x20a775=new an(_0x635bd);}}qt(_0x55b0c7)&&Qr(_0x55b0c7),Jd(_0x36124f,_0x1d77ea,_0x5d0ca0,_0x20a775);}function N_(_0x54ed4b){_0x54ed4b=P(_0x54ed4b),_0x54ed4b['_checkNotDeleted']('goOffline'),ha(_0x54ed4b['_repo']);}function O_(_0x11ead8){_0x11ead8=P(_0x11ead8),_0x11ead8['_checkNotDeleted']('goOnline'),Nd(_0x11ead8['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x233d5c){Ul(dt),st(new Fe('database',(_0x101bad,{instanceIdentifier:_0x4289a3})=>{const _0x30139f=_0x101bad['getProvider']('app')['getImmediate'](),_0x510268=_0x101bad['getProvider']('auth-internal'),_0x342c3e=_0x101bad['getProvider']('app-check-internal');return Xd(_0x30139f,_0x510268,_0x342c3e,_0x4289a3);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x233d5c),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x20704a,_0x5f3018){this['committed']=_0x20704a,this['snapshot']=_0x5f3018;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x11f637,_0x441859,_0x160c03){if(_0x11f637=P(_0x11f637),Me('Reference.transaction',_0x11f637['_path']),_0x11f637['key']==='.length'||_0x11f637['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x11f637['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5c049a=!0x0,_0x3eb4d7=new H(),_0x1ce186=(_0x38ae6e,_0x2a597e,_0x435580)=>{let _0xb4d58b=null;_0x38ae6e?_0x3eb4d7['reject'](_0x38ae6e):(_0xb4d58b=new lt(_0x435580,new ee(_0x11f637['_repo'],_0x11f637['_path']),R),_0x3eb4d7['resolve'](new of(_0x2a597e,_0xb4d58b)));},_0x57b58f=Gd(_0x11f637,()=>{});return Od(_0x11f637['_repo'],_0x11f637['_path'],_0x441859,_0x1ce186,_0x57b58f,_0x5c049a),_0x3eb4d7['promise'];}se['prototype']['simpleListen']=function(_0x294485,_0x395c7d){this['sendRequest']('q',{'p':_0x294485},_0x395c7d);},se['prototype']['echo']=function(_0x245ae4,_0x37074d){this['sendRequest']('echo',{'d':_0x245ae4},_0x37074d);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x404cda,..._0x51b572){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x404cda,..._0x51b572);}function cn(_0x414d0e,..._0x1514a3){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x414d0e,..._0x1514a3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x46c975,..._0xcf5605){throw ws(_0x46c975,..._0xcf5605);}function X(_0x56fa70,..._0x3992fb){return ws(_0x56fa70,..._0x3992fb);}function Ia(_0xb1ecc2,_0x43f6ef,_0xb34d18){const _0xc96a42={...af(),[_0x43f6ef]:_0xb34d18};return new Gt('auth','Firebase',_0xc96a42)['create'](_0x43f6ef,{'appName':_0xb1ecc2['name']});}function re(_0x112b0b){return Ia(_0x112b0b,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1b206c,..._0x22b90b){if(typeof _0x1b206c!='string'){const _0x1389ba=_0x22b90b[0x0],_0x2ab327=[..._0x22b90b['slice'](0x1)];return _0x2ab327[0x0]&&(_0x2ab327[0x0]['appName']=_0x1b206c['name']),_0x1b206c['_errorFactory']['create'](_0x1389ba,..._0x2ab327);}return Ea['create'](_0x1b206c,..._0x22b90b);}function m(_0x216438,_0x244c55,..._0xe30ce8){if(!_0x216438)throw ws(_0x244c55,..._0xe30ce8);}function ne(_0x7b70ec){const _0x3f383c='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x7b70ec;throw cn(_0x3f383c),new Error(_0x3f383c);}function ce(_0x5b5cfa,_0x1f9bd2){_0x5b5cfa||ne(_0x1f9bd2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x46aa73;return typeof self<'u'&&((_0x46aa73=self['location'])==null?void 0x0:_0x46aa73['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x22ec74;return typeof self<'u'&&((_0x22ec74=self['location'])==null?void 0x0:_0x22ec74['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x33d2b8=navigator;return _0x33d2b8['languages']&&_0x33d2b8['languages'][0x0]||_0x33d2b8['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x16ada8,_0x3c1d58){this['shortDelay']=_0x16ada8,this['longDelay']=_0x3c1d58,ce(_0x3c1d58>_0x16ada8,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0xd4012a,_0x3680ba){ce(_0xd4012a['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x58763b}=_0xd4012a['emulator'];return _0x3680ba?''+_0x58763b+(_0x3680ba['startsWith']('/')?_0x3680ba['slice'](0x1):_0x3680ba):_0x58763b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x558a0f,_0x5d6e8f,_0x5c64d8){this['fetchImpl']=_0x558a0f,_0x5d6e8f&&(this['headersImpl']=_0x5d6e8f),_0x5c64d8&&(this['responseImpl']=_0x5c64d8);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x4ed3fe,_0x115b38){return _0x4ed3fe['tenantId']&&!_0x115b38['tenantId']?{..._0x115b38,'tenantId':_0x4ed3fe['tenantId']}:_0x115b38;}async function Pe(_0x2bba18,_0xc6cbf6,_0x5815b8,_0x3f08d4,_0xab1dd8={}){return Ca(_0x2bba18,_0xab1dd8,async()=>{let _0x32000f={},_0xfab65f={};_0x3f08d4&&(_0xc6cbf6==='GET'?_0xfab65f=_0x3f08d4:_0x32000f={'body':JSON['stringify'](_0x3f08d4)});const _0x3f0d79=ut({..._0xfab65f,'key':_0x2bba18['config']['apiKey']})['slice'](0x1),_0x208f2f=await _0x2bba18['_getAdditionalHeaders']();_0x208f2f['Content-Type']='application/json',_0x2bba18['languageCode']&&(_0x208f2f['X-Firebase-Locale']=_0x2bba18['languageCode']);const _0x5cd274={'method':_0xc6cbf6,'headers':_0x208f2f,..._0x32000f};return dc()||(_0x5cd274['referrerPolicy']='strict-origin-when-cross-origin'),_0x2bba18['emulatorConfig']&&qt(_0x2bba18['emulatorConfig']['host'])&&(_0x5cd274['credentials']='include'),wa['fetch']()(await Ta(_0x2bba18,_0x2bba18['config']['apiHost'],_0x5815b8,_0x3f0d79),_0x5cd274);});}async function Ca(_0x95b0a1,_0x3a9b69,_0x19e741){_0x95b0a1['_canInitEmulator']=!0x1;const _0x2ebacf={...df,..._0x3a9b69};try{const _0x4f0533=new gf(_0x95b0a1),_0x411998=await Promise['race']([_0x19e741(),_0x4f0533['promise']]);_0x4f0533['clearNetworkTimeout']();const _0x4b140f=await _0x411998['json']();if('needConfirmation'in _0x4b140f)throw on(_0x95b0a1,'account-exists-with-different-credential',_0x4b140f);if(_0x411998['ok']&&!('errorMessage'in _0x4b140f))return _0x4b140f;{const _0xc0c037=_0x411998['ok']?_0x4b140f['errorMessage']:_0x4b140f['error']['message'],[_0x38a190,_0x106ff1]=_0xc0c037['split']('\x20:\x20');if(_0x38a190==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x95b0a1,'credential-already-in-use',_0x4b140f);if(_0x38a190==='EMAIL_EXISTS')throw on(_0x95b0a1,'email-already-in-use',_0x4b140f);if(_0x38a190==='USER_DISABLED')throw on(_0x95b0a1,'user-disabled',_0x4b140f);const _0xe86a91=_0x2ebacf[_0x38a190]||_0x38a190['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x106ff1)throw Ia(_0x95b0a1,_0xe86a91,_0x106ff1);Y(_0x95b0a1,_0xe86a91);}}catch(_0x57750c){if(_0x57750c instanceof Re)throw _0x57750c;Y(_0x95b0a1,'network-request-failed',{'message':String(_0x57750c)});}}async function en(_0x22dbe9,_0x101d9c,_0x2e4add,_0x4ea128,_0x162206={}){const _0x4f7a9d=await Pe(_0x22dbe9,_0x101d9c,_0x2e4add,_0x4ea128,_0x162206);return'mfaPendingCredential'in _0x4f7a9d&&Y(_0x22dbe9,'multi-factor-auth-required',{'_serverResponse':_0x4f7a9d}),_0x4f7a9d;}async function Ta(_0x4aa305,_0x2dc603,_0x15af96,_0x5e7d51){const _0x40e69c=''+_0x2dc603+_0x15af96+'?'+_0x5e7d51,_0x578143=_0x4aa305,_0x546e34=_0x578143['config']['emulator']?Cs(_0x4aa305['config'],_0x40e69c):_0x4aa305['config']['apiScheme']+'://'+_0x40e69c;return ff['includes'](_0x15af96)&&(await _0x578143['_persistenceManagerAvailable'],_0x578143['_getPersistenceType']()==='COOKIE')?_0x578143['_getPersistence']()['_getFinalTarget'](_0x546e34)['toString']():_0x546e34;}function _f(_0x494277){switch(_0x494277){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x491e37){this['auth']=_0x491e37,this['timer']=null,this['promise']=new Promise((_0x1d6fff,_0x347682)=>{this['timer']=setTimeout(()=>_0x347682(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0xca4eff,_0x31dd24,_0x450015){const _0x1bfb2c={'appName':_0xca4eff['name']};_0x450015['email']&&(_0x1bfb2c['email']=_0x450015['email']),_0x450015['phoneNumber']&&(_0x1bfb2c['phoneNumber']=_0x450015['phoneNumber']);const _0x1430f7=X(_0xca4eff,_0x31dd24,_0x1bfb2c);return _0x1430f7['customData']['_tokenResponse']=_0x450015,_0x1430f7;}function wr(_0x152a93){return _0x152a93!==void 0x0&&_0x152a93['enterprise']!==void 0x0;}class mf{constructor(_0x43dc98){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x43dc98['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x43dc98['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x43dc98['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x569be2){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x2114a5 of this['recaptchaEnforcementState'])if(_0x2114a5['provider']&&_0x2114a5['provider']===_0x569be2)return _f(_0x2114a5['enforcementState']);return null;}['isProviderEnabled'](_0x72da92){return this['getProviderEnforcementState'](_0x72da92)==='ENFORCE'||this['getProviderEnforcementState'](_0x72da92)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5b14f3,_0x3cd357){return Pe(_0x5b14f3,'GET','/v2/recaptchaConfig',ke(_0x5b14f3,_0x3cd357));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x38759b,_0x5c6a71){return Pe(_0x38759b,'POST','/v1/accounts:delete',_0x5c6a71);}async function Pn(_0x538925,_0x11d98a){return Pe(_0x538925,'POST','/v1/accounts:lookup',_0x11d98a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x2a19a4){if(_0x2a19a4)try{const _0x498a0b=new Date(Number(_0x2a19a4));if(!isNaN(_0x498a0b['getTime']()))return _0x498a0b['toUTCString']();}catch{}}async function Ef(_0x3289ad,_0x45d3b4=!0x1){const _0x5b15a4=P(_0x3289ad),_0x167a5f=await _0x5b15a4['getIdToken'](_0x45d3b4),_0x4294c8=Ts(_0x167a5f);m(_0x4294c8&&_0x4294c8['exp']&&_0x4294c8['auth_time']&&_0x4294c8['iat'],_0x5b15a4['auth'],'internal-error');const _0x4ecf31=typeof _0x4294c8['firebase']=='object'?_0x4294c8['firebase']:void 0x0,_0xd6614f=_0x4ecf31==null?void 0x0:_0x4ecf31['sign_in_provider'];return{'claims':_0x4294c8,'token':_0x167a5f,'authTime':Pt(fi(_0x4294c8['auth_time'])),'issuedAtTime':Pt(fi(_0x4294c8['iat'])),'expirationTime':Pt(fi(_0x4294c8['exp'])),'signInProvider':_0xd6614f||null,'signInSecondFactor':(_0x4ecf31==null?void 0x0:_0x4ecf31['sign_in_second_factor'])||null};}function fi(_0x150723){return Number(_0x150723)*0x3e8;}function Ts(_0x4d73d8){const [_0x5737c4,_0x15f007,_0x6e02b3]=_0x4d73d8['split']('.');if(_0x5737c4===void 0x0||_0x15f007===void 0x0||_0x6e02b3===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x23ad36=fn(_0x15f007);return _0x23ad36?JSON['parse'](_0x23ad36):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x7bb3fd){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x7bb3fd==null?void 0x0:_0x7bb3fd['toString']()),null;}}function Cr(_0x1645d6){const _0x3f83e5=Ts(_0x1645d6);return m(_0x3f83e5,'internal-error'),m(typeof _0x3f83e5['exp']<'u','internal-error'),m(typeof _0x3f83e5['iat']<'u','internal-error'),Number(_0x3f83e5['exp'])-Number(_0x3f83e5['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x992a53,_0x56c9e8,_0x23739c=!0x1){if(_0x23739c)return _0x56c9e8;try{return await _0x56c9e8;}catch(_0x507436){throw _0x507436 instanceof Re&&If(_0x507436)&&_0x992a53['auth']['currentUser']===_0x992a53&&await _0x992a53['auth']['signOut'](),_0x507436;}}function If({code:_0x2ba39e}){return _0x2ba39e==='auth/user-disabled'||_0x2ba39e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x587d32){this['user']=_0x587d32,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5eb559){if(_0x5eb559){const _0x10b29a=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x10b29a;}else{this['errorBackoff']=0x7530;const _0x5863d8=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5863d8);}}['schedule'](_0x41defa=!0x1){if(!this['isRunning'])return;const _0x470865=this['getInterval'](_0x41defa);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x470865);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x3fa048){(_0x3fa048==null?void 0x0:_0x3fa048['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x4e8f07,_0x481f54){this['createdAt']=_0x4e8f07,this['lastLoginAt']=_0x481f54,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x53816c){this['createdAt']=_0x53816c['createdAt'],this['lastLoginAt']=_0x53816c['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x2a8e82){var _0x39ff87;const _0x3e3552=_0x2a8e82['auth'],_0x841194=await _0x2a8e82['getIdToken'](),_0x2fb4e3=await Ht(_0x2a8e82,Pn(_0x3e3552,{'idToken':_0x841194}));m(_0x2fb4e3==null?void 0x0:_0x2fb4e3['users']['length'],_0x3e3552,'internal-error');const _0x26db0c=_0x2fb4e3['users'][0x0];_0x2a8e82['_notifyReloadListener'](_0x26db0c);const _0x417052=(_0x39ff87=_0x26db0c['providerUserInfo'])!=null&&_0x39ff87['length']?Sa(_0x26db0c['providerUserInfo']):[],_0x1880a3=Tf(_0x2a8e82['providerData'],_0x417052),_0x137edf=_0x2a8e82['isAnonymous'],_0x1e5fac=!(_0x2a8e82['email']&&_0x26db0c['passwordHash'])&&!(_0x1880a3!=null&&_0x1880a3['length']),_0x126484=_0x137edf?_0x1e5fac:!0x1,_0x52dbaa={'uid':_0x26db0c['localId'],'displayName':_0x26db0c['displayName']||null,'photoURL':_0x26db0c['photoUrl']||null,'email':_0x26db0c['email']||null,'emailVerified':_0x26db0c['emailVerified']||!0x1,'phoneNumber':_0x26db0c['phoneNumber']||null,'tenantId':_0x26db0c['tenantId']||null,'providerData':_0x1880a3,'metadata':new Li(_0x26db0c['createdAt'],_0x26db0c['lastLoginAt']),'isAnonymous':_0x126484};Object['assign'](_0x2a8e82,_0x52dbaa);}async function Cf(_0x5a94aa){const _0x4520b2=P(_0x5a94aa);await Nn(_0x4520b2),await _0x4520b2['auth']['_persistUserIfCurrent'](_0x4520b2),_0x4520b2['auth']['_notifyListenersIfCurrent'](_0x4520b2);}function Tf(_0x8d08a6,_0x2c3850){return[..._0x8d08a6['filter'](_0x1659a9=>!_0x2c3850['some'](_0x57aff1=>_0x57aff1['providerId']===_0x1659a9['providerId'])),..._0x2c3850];}function Sa(_0x4a5596){return _0x4a5596['map'](({providerId:_0x14d8e9,..._0x19d828})=>({'providerId':_0x14d8e9,'uid':_0x19d828['rawId']||'','displayName':_0x19d828['displayName']||null,'email':_0x19d828['email']||null,'phoneNumber':_0x19d828['phoneNumber']||null,'photoURL':_0x19d828['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x28ccb7,_0x54ab75){const _0x1ddca3=await Ca(_0x28ccb7,{},async()=>{const _0x31fbf5=ut({'grant_type':'refresh_token','refresh_token':_0x54ab75})['slice'](0x1),{tokenApiHost:_0x516838,apiKey:_0x299e42}=_0x28ccb7['config'],_0x1828fd=await Ta(_0x28ccb7,_0x516838,'/v1/token','key='+_0x299e42),_0x433139=await _0x28ccb7['_getAdditionalHeaders']();_0x433139['Content-Type']='application/x-www-form-urlencoded';const _0x506952={'method':'POST','headers':_0x433139,'body':_0x31fbf5};return _0x28ccb7['emulatorConfig']&&qt(_0x28ccb7['emulatorConfig']['host'])&&(_0x506952['credentials']='include'),wa['fetch']()(_0x1828fd,_0x506952);});return{'accessToken':_0x1ddca3['access_token'],'expiresIn':_0x1ddca3['expires_in'],'refreshToken':_0x1ddca3['refresh_token']};}async function bf(_0x21f269,_0x1d1c2d){return Pe(_0x21f269,'POST','/v2/accounts:revokeToken',ke(_0x21f269,_0x1d1c2d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x263886){m(_0x263886['idToken'],'internal-error'),m(typeof _0x263886['idToken']<'u','internal-error'),m(typeof _0x263886['refreshToken']<'u','internal-error');const _0x6e53e3='expiresIn'in _0x263886&&typeof _0x263886['expiresIn']<'u'?Number(_0x263886['expiresIn']):Cr(_0x263886['idToken']);this['updateTokensAndExpiration'](_0x263886['idToken'],_0x263886['refreshToken'],_0x6e53e3);}['updateFromIdToken'](_0xa4293a){m(_0xa4293a['length']!==0x0,'internal-error');const _0xb5a20c=Cr(_0xa4293a);this['updateTokensAndExpiration'](_0xa4293a,null,_0xb5a20c);}async['getToken'](_0x322d8a,_0x24bb77=!0x1){return!_0x24bb77&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x322d8a,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x322d8a,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x477f7f,_0x29ec26){const {accessToken:_0xa7dd12,refreshToken:_0xb3be2f,expiresIn:_0x34aad4}=await Sf(_0x477f7f,_0x29ec26);this['updateTokensAndExpiration'](_0xa7dd12,_0xb3be2f,Number(_0x34aad4));}['updateTokensAndExpiration'](_0x533c68,_0x158a9a,_0x3084b6){this['refreshToken']=_0x158a9a||null,this['accessToken']=_0x533c68||null,this['expirationTime']=Date['now']()+_0x3084b6*0x3e8;}static['fromJSON'](_0x54e83e,_0x3a0639){const {refreshToken:_0x211b8f,accessToken:_0x2c1556,expirationTime:_0x26dafb}=_0x3a0639,_0x276999=new et();return _0x211b8f&&(m(typeof _0x211b8f=='string','internal-error',{'appName':_0x54e83e}),_0x276999['refreshToken']=_0x211b8f),_0x2c1556&&(m(typeof _0x2c1556=='string','internal-error',{'appName':_0x54e83e}),_0x276999['accessToken']=_0x2c1556),_0x26dafb&&(m(typeof _0x26dafb=='number','internal-error',{'appName':_0x54e83e}),_0x276999['expirationTime']=_0x26dafb),_0x276999;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x22eb1d){this['accessToken']=_0x22eb1d['accessToken'],this['refreshToken']=_0x22eb1d['refreshToken'],this['expirationTime']=_0x22eb1d['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0xa36082,_0x29e3d4){m(typeof _0xa36082=='string'||typeof _0xa36082>'u','internal-error',{'appName':_0x29e3d4});}class j{constructor({uid:_0x5cc5f6,auth:_0x167d14,stsTokenManager:_0x3c1eea,..._0x4170ea}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5cc5f6,this['auth']=_0x167d14,this['stsTokenManager']=_0x3c1eea,this['accessToken']=_0x3c1eea['accessToken'],this['displayName']=_0x4170ea['displayName']||null,this['email']=_0x4170ea['email']||null,this['emailVerified']=_0x4170ea['emailVerified']||!0x1,this['phoneNumber']=_0x4170ea['phoneNumber']||null,this['photoURL']=_0x4170ea['photoURL']||null,this['isAnonymous']=_0x4170ea['isAnonymous']||!0x1,this['tenantId']=_0x4170ea['tenantId']||null,this['providerData']=_0x4170ea['providerData']?[..._0x4170ea['providerData']]:[],this['metadata']=new Li(_0x4170ea['createdAt']||void 0x0,_0x4170ea['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5b578b){const _0x238a41=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x5b578b));return m(_0x238a41,this['auth'],'internal-error'),this['accessToken']!==_0x238a41&&(this['accessToken']=_0x238a41,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x238a41;}['getIdTokenResult'](_0x5c67cb){return Ef(this,_0x5c67cb);}['reload'](){return Cf(this);}['_assign'](_0x1a91c1){this!==_0x1a91c1&&(m(this['uid']===_0x1a91c1['uid'],this['auth'],'internal-error'),this['displayName']=_0x1a91c1['displayName'],this['photoURL']=_0x1a91c1['photoURL'],this['email']=_0x1a91c1['email'],this['emailVerified']=_0x1a91c1['emailVerified'],this['phoneNumber']=_0x1a91c1['phoneNumber'],this['isAnonymous']=_0x1a91c1['isAnonymous'],this['tenantId']=_0x1a91c1['tenantId'],this['providerData']=_0x1a91c1['providerData']['map'](_0x75c32b=>({..._0x75c32b})),this['metadata']['_copy'](_0x1a91c1['metadata']),this['stsTokenManager']['_assign'](_0x1a91c1['stsTokenManager']));}['_clone'](_0x15c2d2){const _0x140378=new j({...this,'auth':_0x15c2d2,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x140378['metadata']['_copy'](this['metadata']),_0x140378;}['_onReload'](_0x2c5422){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2c5422,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x452ee5){this['reloadListener']?this['reloadListener'](_0x452ee5):this['reloadUserInfo']=_0x452ee5;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x1c76d0,_0x71b52=!0x1){let _0x3c4f0e=!0x1;_0x1c76d0['idToken']&&_0x1c76d0['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x1c76d0),_0x3c4f0e=!0x0),_0x71b52&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3c4f0e&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1ebb8d=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x1ebb8d})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x625ca9=>({..._0x625ca9})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0xe13725,_0x4ae85d){const _0x3e39f7=_0x4ae85d['displayName']??void 0x0,_0x26c646=_0x4ae85d['email']??void 0x0,_0x2eaf14=_0x4ae85d['phoneNumber']??void 0x0,_0x2bc41b=_0x4ae85d['photoURL']??void 0x0,_0xc8baa1=_0x4ae85d['tenantId']??void 0x0,_0x14026b=_0x4ae85d['_redirectEventId']??void 0x0,_0x7903c8=_0x4ae85d['createdAt']??void 0x0,_0x41e7b=_0x4ae85d['lastLoginAt']??void 0x0,{uid:_0x5b25af,emailVerified:_0x5d3c0b,isAnonymous:_0x326af6,providerData:_0xeda8ef,stsTokenManager:_0x2690d6}=_0x4ae85d;m(_0x5b25af&&_0x2690d6,_0xe13725,'internal-error');const _0x4ec4ab=et['fromJSON'](this['name'],_0x2690d6);m(typeof _0x5b25af=='string',_0xe13725,'internal-error'),le(_0x3e39f7,_0xe13725['name']),le(_0x26c646,_0xe13725['name']),m(typeof _0x5d3c0b=='boolean',_0xe13725,'internal-error'),m(typeof _0x326af6=='boolean',_0xe13725,'internal-error'),le(_0x2eaf14,_0xe13725['name']),le(_0x2bc41b,_0xe13725['name']),le(_0xc8baa1,_0xe13725['name']),le(_0x14026b,_0xe13725['name']),le(_0x7903c8,_0xe13725['name']),le(_0x41e7b,_0xe13725['name']);const _0x1230c6=new j({'uid':_0x5b25af,'auth':_0xe13725,'email':_0x26c646,'emailVerified':_0x5d3c0b,'displayName':_0x3e39f7,'isAnonymous':_0x326af6,'photoURL':_0x2bc41b,'phoneNumber':_0x2eaf14,'tenantId':_0xc8baa1,'stsTokenManager':_0x4ec4ab,'createdAt':_0x7903c8,'lastLoginAt':_0x41e7b});return _0xeda8ef&&Array['isArray'](_0xeda8ef)&&(_0x1230c6['providerData']=_0xeda8ef['map'](_0x13b496=>({..._0x13b496}))),_0x14026b&&(_0x1230c6['_redirectEventId']=_0x14026b),_0x1230c6;}static async['_fromIdTokenResponse'](_0x37ba0f,_0x4cbb82,_0x19faa1=!0x1){const _0x5ba563=new et();_0x5ba563['updateFromServerResponse'](_0x4cbb82);const _0x9b148d=new j({'uid':_0x4cbb82['localId'],'auth':_0x37ba0f,'stsTokenManager':_0x5ba563,'isAnonymous':_0x19faa1});return await Nn(_0x9b148d),_0x9b148d;}static async['_fromGetAccountInfoResponse'](_0x140b51,_0x29b53b,_0x3ac392){const _0x38d5b7=_0x29b53b['users'][0x0];m(_0x38d5b7['localId']!==void 0x0,'internal-error');const _0x301086=_0x38d5b7['providerUserInfo']!==void 0x0?Sa(_0x38d5b7['providerUserInfo']):[],_0x343c2e=!(_0x38d5b7['email']&&_0x38d5b7['passwordHash'])&&!(_0x301086!=null&&_0x301086['length']),_0x438c23=new et();_0x438c23['updateFromIdToken'](_0x3ac392);const _0x2e6732=new j({'uid':_0x38d5b7['localId'],'auth':_0x140b51,'stsTokenManager':_0x438c23,'isAnonymous':_0x343c2e}),_0x2110cf={'uid':_0x38d5b7['localId'],'displayName':_0x38d5b7['displayName']||null,'photoURL':_0x38d5b7['photoUrl']||null,'email':_0x38d5b7['email']||null,'emailVerified':_0x38d5b7['emailVerified']||!0x1,'phoneNumber':_0x38d5b7['phoneNumber']||null,'tenantId':_0x38d5b7['tenantId']||null,'providerData':_0x301086,'metadata':new Li(_0x38d5b7['createdAt'],_0x38d5b7['lastLoginAt']),'isAnonymous':!(_0x38d5b7['email']&&_0x38d5b7['passwordHash'])&&!(_0x301086!=null&&_0x301086['length'])};return Object['assign'](_0x2e6732,_0x2110cf),_0x2e6732;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x551ef7){ce(_0x551ef7 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x10319d=Tr['get'](_0x551ef7);return _0x10319d?(ce(_0x10319d instanceof _0x551ef7,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x10319d):(_0x10319d=new _0x551ef7(),Tr['set'](_0x551ef7,_0x10319d),_0x10319d);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x165a01,_0x4a7fb5){this['storage'][_0x165a01]=_0x4a7fb5;}async['_get'](_0x383825){const _0x5b1716=this['storage'][_0x383825];return _0x5b1716===void 0x0?null:_0x5b1716;}async['_remove'](_0x170519){delete this['storage'][_0x170519];}['_addListener'](_0x2fe2bf,_0x87386b){}['_removeListener'](_0x2ade22,_0x219284){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x3545b8,_0x40c172,_0x19917b){return'firebase:'+_0x3545b8+':'+_0x40c172+':'+_0x19917b;}class tt{constructor(_0xba6e37,_0x5beb07,_0xa782cc){this['persistence']=_0xba6e37,this['auth']=_0x5beb07,this['userKey']=_0xa782cc;const {config:_0x4343b5,name:_0x44b9a8}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x4343b5['apiKey'],_0x44b9a8),this['fullPersistenceKey']=ln('persistence',_0x4343b5['apiKey'],_0x44b9a8),this['boundEventHandler']=_0x5beb07['_onStorageEvent']['bind'](_0x5beb07),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4cd35a){return this['persistence']['_set'](this['fullUserKey'],_0x4cd35a['toJSON']());}async['getCurrentUser'](){const _0xbafec7=await this['persistence']['_get'](this['fullUserKey']);if(!_0xbafec7)return null;if(typeof _0xbafec7=='string'){const _0x4c6f7b=await Pn(this['auth'],{'idToken':_0xbafec7})['catch'](()=>{});return _0x4c6f7b?j['_fromGetAccountInfoResponse'](this['auth'],_0x4c6f7b,_0xbafec7):null;}return j['_fromJSON'](this['auth'],_0xbafec7);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5a5ea4){if(this['persistence']===_0x5a5ea4)return;const _0xe3dc63=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5a5ea4,_0xe3dc63)return this['setCurrentUser'](_0xe3dc63);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5e274c,_0x1099e2,_0xfaf52f='authUser'){if(!_0x1099e2['length'])return new tt(ie(Sr),_0x5e274c,_0xfaf52f);const _0x4983c5=(await Promise['all'](_0x1099e2['map'](async _0x5c5732=>{if(await _0x5c5732['_isAvailable']())return _0x5c5732;})))['filter'](_0x4fa5a7=>_0x4fa5a7);let _0x2a7383=_0x4983c5[0x0]||ie(Sr);const _0x49b848=ln(_0xfaf52f,_0x5e274c['config']['apiKey'],_0x5e274c['name']);let _0x27d864=null;for(const _0x4c111e of _0x1099e2)try{const _0x4bf6f9=await _0x4c111e['_get'](_0x49b848);if(_0x4bf6f9){let _0x36fe2b;if(typeof _0x4bf6f9=='string'){const _0x810ef8=await Pn(_0x5e274c,{'idToken':_0x4bf6f9})['catch'](()=>{});if(!_0x810ef8)break;_0x36fe2b=await j['_fromGetAccountInfoResponse'](_0x5e274c,_0x810ef8,_0x4bf6f9);}else _0x36fe2b=j['_fromJSON'](_0x5e274c,_0x4bf6f9);_0x4c111e!==_0x2a7383&&(_0x27d864=_0x36fe2b),_0x2a7383=_0x4c111e;break;}}catch{}const _0x23a676=_0x4983c5['filter'](_0x2bdb55=>_0x2bdb55['_shouldAllowMigration']);return!_0x2a7383['_shouldAllowMigration']||!_0x23a676['length']?new tt(_0x2a7383,_0x5e274c,_0xfaf52f):(_0x2a7383=_0x23a676[0x0],_0x27d864&&await _0x2a7383['_set'](_0x49b848,_0x27d864['toJSON']()),await Promise['all'](_0x1099e2['map'](async _0x54318e=>{if(_0x54318e!==_0x2a7383)try{await _0x54318e['_remove'](_0x49b848);}catch{}})),new tt(_0x2a7383,_0x5e274c,_0xfaf52f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x363d48){const _0x564d58=_0x363d48['toLowerCase']();if(_0x564d58['includes']('opera/')||_0x564d58['includes']('opr/')||_0x564d58['includes']('opios/'))return'Opera';if(Pa(_0x564d58))return'IEMobile';if(_0x564d58['includes']('msie')||_0x564d58['includes']('trident/'))return'IE';if(_0x564d58['includes']('edge/'))return'Edge';if(Ra(_0x564d58))return'Firefox';if(_0x564d58['includes']('silk/'))return'Silk';if(Oa(_0x564d58))return'Blackberry';if(Da(_0x564d58))return'Webos';if(Aa(_0x564d58))return'Safari';if((_0x564d58['includes']('chrome/')||ka(_0x564d58))&&!_0x564d58['includes']('edge/'))return'Chrome';if(Na(_0x564d58))return'Android';{const _0x430047=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x6d9cc7=_0x363d48['match'](_0x430047);if((_0x6d9cc7==null?void 0x0:_0x6d9cc7['length'])===0x2)return _0x6d9cc7[0x1];}return'Other';}function Ra(_0x493a06=W()){return/firefox\//i['test'](_0x493a06);}function Aa(_0x324792=W()){const _0x426d4b=_0x324792['toLowerCase']();return _0x426d4b['includes']('safari/')&&!_0x426d4b['includes']('chrome/')&&!_0x426d4b['includes']('crios/')&&!_0x426d4b['includes']('android');}function ka(_0x506798=W()){return/crios\//i['test'](_0x506798);}function Pa(_0x5529f6=W()){return/iemobile/i['test'](_0x5529f6);}function Na(_0x52932f=W()){return/android/i['test'](_0x52932f);}function Oa(_0x4a44f5=W()){return/blackberry/i['test'](_0x4a44f5);}function Da(_0x161e3b=W()){return/webos/i['test'](_0x161e3b);}function Ss(_0x351f6e=W()){return/iphone|ipad|ipod/i['test'](_0x351f6e)||/macintosh/i['test'](_0x351f6e)&&/mobile/i['test'](_0x351f6e);}function Rf(_0x414dc3=W()){var _0x55eaf1;return Ss(_0x414dc3)&&!!((_0x55eaf1=window['navigator'])!=null&&_0x55eaf1['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x5cdc2a=W()){return Ss(_0x5cdc2a)||Na(_0x5cdc2a)||Da(_0x5cdc2a)||Oa(_0x5cdc2a)||/windows phone/i['test'](_0x5cdc2a)||Pa(_0x5cdc2a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x583926,_0xb8edfa=[]){let _0x540271;switch(_0x583926){case'Browser':_0x540271=br(W());break;case'Worker':_0x540271=br(W())+'-'+_0x583926;break;default:_0x540271=_0x583926;}const _0x518575=_0xb8edfa['length']?_0xb8edfa['join'](','):'FirebaseCore-web';return _0x540271+'/JsCore/'+dt+'/'+_0x518575;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x1db8ab){this['auth']=_0x1db8ab,this['queue']=[];}['pushCallback'](_0x440739,_0x44f7c0){const _0x5afc4a=_0x238589=>new Promise((_0x2028cf,_0x14ed57)=>{try{const _0x8061e3=_0x440739(_0x238589);_0x2028cf(_0x8061e3);}catch(_0x32b56c){_0x14ed57(_0x32b56c);}});_0x5afc4a['onAbort']=_0x44f7c0,this['queue']['push'](_0x5afc4a);const _0x346edf=this['queue']['length']-0x1;return()=>{this['queue'][_0x346edf]=()=>Promise['resolve']();};}async['runMiddleware'](_0xa6fd27){if(this['auth']['currentUser']===_0xa6fd27)return;const _0x3b930d=[];try{for(const _0x3e3ab9 of this['queue'])await _0x3e3ab9(_0xa6fd27),_0x3e3ab9['onAbort']&&_0x3b930d['push'](_0x3e3ab9['onAbort']);}catch(_0x54da66){_0x3b930d['reverse']();for(const _0x5446f0 of _0x3b930d)try{_0x5446f0();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x54da66==null?void 0x0:_0x54da66['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x1e2020,_0x2efeb1={}){return Pe(_0x1e2020,'GET','/v2/passwordPolicy',ke(_0x1e2020,_0x2efeb1));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0xb94d23){var _0xadd7e7;const _0x34377a=_0xb94d23['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x34377a['minPasswordLength']??Nf,_0x34377a['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x34377a['maxPasswordLength']),_0x34377a['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x34377a['containsLowercaseCharacter']),_0x34377a['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x34377a['containsUppercaseCharacter']),_0x34377a['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x34377a['containsNumericCharacter']),_0x34377a['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x34377a['containsNonAlphanumericCharacter']),this['enforcementState']=_0xb94d23['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xadd7e7=_0xb94d23['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xadd7e7['join'](''))??'',this['forceUpgradeOnSignin']=_0xb94d23['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xb94d23['schemaVersion'];}['validatePassword'](_0x15ffbb){const _0x57d21d={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x15ffbb,_0x57d21d),this['validatePasswordCharacterOptions'](_0x15ffbb,_0x57d21d),_0x57d21d['isValid']&&(_0x57d21d['isValid']=_0x57d21d['meetsMinPasswordLength']??!0x0),_0x57d21d['isValid']&&(_0x57d21d['isValid']=_0x57d21d['meetsMaxPasswordLength']??!0x0),_0x57d21d['isValid']&&(_0x57d21d['isValid']=_0x57d21d['containsLowercaseLetter']??!0x0),_0x57d21d['isValid']&&(_0x57d21d['isValid']=_0x57d21d['containsUppercaseLetter']??!0x0),_0x57d21d['isValid']&&(_0x57d21d['isValid']=_0x57d21d['containsNumericCharacter']??!0x0),_0x57d21d['isValid']&&(_0x57d21d['isValid']=_0x57d21d['containsNonAlphanumericCharacter']??!0x0),_0x57d21d;}['validatePasswordLengthOptions'](_0x5a37dd,_0x569801){const _0x4433a6=this['customStrengthOptions']['minPasswordLength'],_0x44664a=this['customStrengthOptions']['maxPasswordLength'];_0x4433a6&&(_0x569801['meetsMinPasswordLength']=_0x5a37dd['length']>=_0x4433a6),_0x44664a&&(_0x569801['meetsMaxPasswordLength']=_0x5a37dd['length']<=_0x44664a);}['validatePasswordCharacterOptions'](_0x1e684,_0x447ab3){this['updatePasswordCharacterOptionsStatuses'](_0x447ab3,!0x1,!0x1,!0x1,!0x1);let _0x57637a;for(let _0x2fffe7=0x0;_0x2fffe7<_0x1e684['length'];_0x2fffe7++)_0x57637a=_0x1e684['charAt'](_0x2fffe7),this['updatePasswordCharacterOptionsStatuses'](_0x447ab3,_0x57637a>='a'&&_0x57637a<='z',_0x57637a>='A'&&_0x57637a<='Z',_0x57637a>='0'&&_0x57637a<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x57637a));}['updatePasswordCharacterOptionsStatuses'](_0x5f3a5d,_0x4e339b,_0x362f99,_0x1aed98,_0x49e7c0){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5f3a5d['containsLowercaseLetter']||(_0x5f3a5d['containsLowercaseLetter']=_0x4e339b)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5f3a5d['containsUppercaseLetter']||(_0x5f3a5d['containsUppercaseLetter']=_0x362f99)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5f3a5d['containsNumericCharacter']||(_0x5f3a5d['containsNumericCharacter']=_0x1aed98)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5f3a5d['containsNonAlphanumericCharacter']||(_0x5f3a5d['containsNonAlphanumericCharacter']=_0x49e7c0));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x15d983,_0x39feb9,_0x1e690f,_0x398b07){this['app']=_0x15d983,this['heartbeatServiceProvider']=_0x39feb9,this['appCheckServiceProvider']=_0x1e690f,this['config']=_0x398b07,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x15d983['name'],this['clientVersion']=_0x398b07['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x3da8b0=>this['_resolvePersistenceManagerAvailable']=_0x3da8b0);}['_initializeWithPersistence'](_0x3ad3e1,_0x736754){return _0x736754&&(this['_popupRedirectResolver']=ie(_0x736754)),this['_initializationPromise']=this['queue'](async()=>{var _0x4385d1,_0x10a73d,_0x3ad829;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x3ad3e1),(_0x4385d1=this['_resolvePersistenceManagerAvailable'])==null||_0x4385d1['call'](this),!this['_deleted'])){if((_0x10a73d=this['_popupRedirectResolver'])!=null&&_0x10a73d['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x736754),this['lastNotifiedUid']=((_0x3ad829=this['currentUser'])==null?void 0x0:_0x3ad829['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x9970c9=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x9970c9)){if(this['currentUser']&&_0x9970c9&&this['currentUser']['uid']===_0x9970c9['uid']){this['_currentUser']['_assign'](_0x9970c9),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x9970c9,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x185ac9){try{const _0x6eaaa9=await Pn(this,{'idToken':_0x185ac9}),_0x294e15=await j['_fromGetAccountInfoResponse'](this,_0x6eaaa9,_0x185ac9);await this['directlySetCurrentUser'](_0x294e15);}catch(_0x476941){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x476941),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3c4efe){var _0x433510;if($(this['app'])){const _0x4e71c1=this['app']['settings']['authIdToken'];return _0x4e71c1?new Promise(_0x2d45c6=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4e71c1)['then'](_0x2d45c6,_0x2d45c6));}):this['directlySetCurrentUser'](null);}const _0xc3b53e=await this['assertedPersistence']['getCurrentUser']();let _0x73d85d=_0xc3b53e,_0x1d5885=!0x1;if(_0x3c4efe&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x51c76b=(_0x433510=this['redirectUser'])==null?void 0x0:_0x433510['_redirectEventId'],_0x191871=_0x73d85d==null?void 0x0:_0x73d85d['_redirectEventId'],_0x25d495=await this['tryRedirectSignIn'](_0x3c4efe);(!_0x51c76b||_0x51c76b===_0x191871)&&(_0x25d495!=null&&_0x25d495['user'])&&(_0x73d85d=_0x25d495['user'],_0x1d5885=!0x0);}if(!_0x73d85d)return this['directlySetCurrentUser'](null);if(!_0x73d85d['_redirectEventId']){if(_0x1d5885)try{await this['beforeStateQueue']['runMiddleware'](_0x73d85d);}catch(_0x3f90f9){_0x73d85d=_0xc3b53e,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3f90f9));}return _0x73d85d?this['reloadAndSetCurrentUserOrClear'](_0x73d85d):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x73d85d['_redirectEventId']?this['directlySetCurrentUser'](_0x73d85d):this['reloadAndSetCurrentUserOrClear'](_0x73d85d);}async['tryRedirectSignIn'](_0xd9c89){let _0x13cd17=null;try{_0x13cd17=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0xd9c89,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x13cd17;}async['reloadAndSetCurrentUserOrClear'](_0x36c414){try{await Nn(_0x36c414);}catch(_0x22e6f0){if((_0x22e6f0==null?void 0x0:_0x22e6f0['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x36c414);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x580a88){if($(this['app']))return Promise['reject'](re(this));const _0x54f102=_0x580a88?P(_0x580a88):null;return _0x54f102&&m(_0x54f102['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x54f102&&_0x54f102['_clone'](this));}async['_updateCurrentUser'](_0x4b9424,_0x555826=!0x1){if(!this['_deleted'])return _0x4b9424&&m(this['tenantId']===_0x4b9424['tenantId'],this,'tenant-id-mismatch'),_0x555826||await this['beforeStateQueue']['runMiddleware'](_0x4b9424),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x4b9424),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x5352a2){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x5352a2));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x481a59){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x415c6e=this['_getPasswordPolicyInternal']();return _0x415c6e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x415c6e['validatePassword'](_0x481a59);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0xc28af9=await Pf(this),_0x2f698c=new Of(_0xc28af9);this['tenantId']===null?this['_projectPasswordPolicy']=_0x2f698c:this['_tenantPasswordPolicies'][this['tenantId']]=_0x2f698c;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x259453){this['_errorFactory']=new Gt('auth','Firebase',_0x259453());}['onAuthStateChanged'](_0x2ff5be,_0x207577,_0x26b29d){return this['registerStateListener'](this['authStateSubscription'],_0x2ff5be,_0x207577,_0x26b29d);}['beforeAuthStateChanged'](_0x1b0d16,_0x1a4337){return this['beforeStateQueue']['pushCallback'](_0x1b0d16,_0x1a4337);}['onIdTokenChanged'](_0x10cba8,_0x2b4346,_0x312710){return this['registerStateListener'](this['idTokenSubscription'],_0x10cba8,_0x2b4346,_0x312710);}['authStateReady'](){return new Promise((_0x46bb33,_0x36f6f5)=>{if(this['currentUser'])_0x46bb33();else{const _0x4757d3=this['onAuthStateChanged'](()=>{_0x4757d3(),_0x46bb33();},_0x36f6f5);}});}async['revokeAccessToken'](_0x2fc5dc){if(this['currentUser']){const _0x74ca3e=await this['currentUser']['getIdToken'](),_0x1aab69={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2fc5dc,'idToken':_0x74ca3e};this['tenantId']!=null&&(_0x1aab69['tenantId']=this['tenantId']),await bf(this,_0x1aab69);}}['toJSON'](){var _0x527f15;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x527f15=this['_currentUser'])==null?void 0x0:_0x527f15['toJSON']()};}async['_setRedirectUser'](_0x280475,_0x48e81b){const _0x467a1f=await this['getOrInitRedirectPersistenceManager'](_0x48e81b);return _0x280475===null?_0x467a1f['removeCurrentUser']():_0x467a1f['setCurrentUser'](_0x280475);}async['getOrInitRedirectPersistenceManager'](_0x498f93){if(!this['redirectPersistenceManager']){const _0x3d02bd=_0x498f93&&ie(_0x498f93)||this['_popupRedirectResolver'];m(_0x3d02bd,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x3d02bd['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x453004){var _0xeeb13d,_0x3a9e40;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0xeeb13d=this['_currentUser'])==null?void 0x0:_0xeeb13d['_redirectEventId'])===_0x453004?this['_currentUser']:((_0x3a9e40=this['redirectUser'])==null?void 0x0:_0x3a9e40['_redirectEventId'])===_0x453004?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2927cf){if(_0x2927cf===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2927cf));}['_notifyListenersIfCurrent'](_0x1409e1){_0x1409e1===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x22cb95;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x5d4319=((_0x22cb95=this['currentUser'])==null?void 0x0:_0x22cb95['uid'])??null;this['lastNotifiedUid']!==_0x5d4319&&(this['lastNotifiedUid']=_0x5d4319,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x24cca8,_0x10dd97,_0x314d38,_0x5d8ec1){if(this['_deleted'])return()=>{};const _0x32abaa=typeof _0x10dd97=='function'?_0x10dd97:_0x10dd97['next']['bind'](_0x10dd97);let _0x1118d2=!0x1;const _0x4b5e07=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4b5e07,this,'internal-error'),_0x4b5e07['then'](()=>{_0x1118d2||_0x32abaa(this['currentUser']);}),typeof _0x10dd97=='function'){const _0x25ed3f=_0x24cca8['addObserver'](_0x10dd97,_0x314d38,_0x5d8ec1);return()=>{_0x1118d2=!0x0,_0x25ed3f();};}else{const _0x28e4b9=_0x24cca8['addObserver'](_0x10dd97);return()=>{_0x1118d2=!0x0,_0x28e4b9();};}}async['directlySetCurrentUser'](_0x3ac0e4){this['currentUser']&&this['currentUser']!==_0x3ac0e4&&this['_currentUser']['_stopProactiveRefresh'](),_0x3ac0e4&&this['isProactiveRefreshEnabled']&&_0x3ac0e4['_startProactiveRefresh'](),this['currentUser']=_0x3ac0e4,_0x3ac0e4?await this['assertedPersistence']['setCurrentUser'](_0x3ac0e4):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x390e8c){return this['operations']=this['operations']['then'](_0x390e8c,_0x390e8c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x11d8af){!_0x11d8af||this['frameworks']['includes'](_0x11d8af)||(this['frameworks']['push'](_0x11d8af),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5737f9;const _0xbefc2d={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0xbefc2d['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3591b9=await((_0x5737f9=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5737f9['getHeartbeatsHeader']());_0x3591b9&&(_0xbefc2d['X-Firebase-Client']=_0x3591b9);const _0x24acd9=await this['_getAppCheckToken']();return _0x24acd9&&(_0xbefc2d['X-Firebase-AppCheck']=_0x24acd9),_0xbefc2d;}async['_getAppCheckToken'](){var _0x3d64f3;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5bf31d=await((_0x3d64f3=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3d64f3['getToken']());return _0x5bf31d!=null&&_0x5bf31d['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5bf31d['error']),_0x5bf31d==null?void 0x0:_0x5bf31d['token'];}}function Ke(_0x3ecaf8){return P(_0x3ecaf8);}class Rr{constructor(_0x4ea7bc){this['auth']=_0x4ea7bc,this['observer']=null,this['addObserver']=Tc(_0x50322b=>this['observer']=_0x50322b);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x1bb026){Jn=_0x1bb026;}function xa(_0x5cc7f7){return Jn['loadJS'](_0x5cc7f7);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x48359e){return'__'+_0x48359e+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x2e6aca){_0x2e6aca();}['execute'](_0x5d84f9,_0xbc832b){return Promise['resolve']('token');}['render'](_0x3b9be3,_0x4c7aed){return'';}}class Wf{['ready'](_0x31bc72){_0x31bc72();}['execute'](_0x496e43,_0x596a7a){return Promise['resolve']('token');}['render'](_0xd3b909,_0x49f136){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x3daedf){this['type']=Bf,this['auth']=Ke(_0x3daedf);}async['verify'](_0x191b0c='verify',_0x245d30=!0x1){async function _0x4ab082(_0x31e685){if(!_0x245d30){if(_0x31e685['tenantId']==null&&_0x31e685['_agentRecaptchaConfig']!=null)return _0x31e685['_agentRecaptchaConfig']['siteKey'];if(_0x31e685['tenantId']!=null&&_0x31e685['_tenantRecaptchaConfigs'][_0x31e685['tenantId']]!==void 0x0)return _0x31e685['_tenantRecaptchaConfigs'][_0x31e685['tenantId']]['siteKey'];}return new Promise(async(_0x2a5449,_0x3afe58)=>{yf(_0x31e685,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xe06bd3=>{if(_0xe06bd3['recaptchaKey']===void 0x0)_0x3afe58(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2d6cae=new mf(_0xe06bd3);return _0x31e685['tenantId']==null?_0x31e685['_agentRecaptchaConfig']=_0x2d6cae:_0x31e685['_tenantRecaptchaConfigs'][_0x31e685['tenantId']]=_0x2d6cae,_0x2a5449(_0x2d6cae['siteKey']);}})['catch'](_0x3fe137=>{_0x3afe58(_0x3fe137);});});}function _0x79499b(_0x4026f0,_0x2feae0,_0x1bc35b){const _0x1473a4=window['grecaptcha'];wr(_0x1473a4)?_0x1473a4['enterprise']['ready'](()=>{_0x1473a4['enterprise']['execute'](_0x4026f0,{'action':_0x191b0c})['then'](_0x561e17=>{_0x2feae0(_0x561e17);})['catch'](()=>{_0x2feae0(Fa);});}):_0x1bc35b(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0xaf9cba,_0x894235)=>{_0x4ab082(this['auth'])['then'](async _0x4c1a3c=>{if(!_0x245d30&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x79499b(_0x4c1a3c,_0xaf9cba,_0x894235);else{if(typeof window>'u'){_0x894235(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x23e0fa=Lf();_0x23e0fa['length']!==0x0&&(_0x23e0fa+=_0x4c1a3c+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x57b226;(_0x57b226=he['scriptInjectionDeferred'])==null||_0x57b226['resolve']();},xa(_0x23e0fa)['then'](()=>{var _0x50a1c8;return(_0x50a1c8=he['scriptInjectionDeferred'])==null?void 0x0:_0x50a1c8['promise'];})['then'](()=>{_0x79499b(_0x4c1a3c,_0xaf9cba,_0x894235);})['catch'](_0x215f5a=>{_0x894235(_0x215f5a);});}})['catch'](_0x4b8008=>{_0x894235(_0x4b8008);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x3ddaef,_0x5d7b82,_0x339ff9,_0x3d4617=!0x1,_0x380c95=!0x1){const _0x5099da=new he(_0x3ddaef);let _0x47828d;if(_0x380c95)_0x47828d=Fa;else try{_0x47828d=await _0x5099da['verify'](_0x339ff9);}catch{_0x47828d=await _0x5099da['verify'](_0x339ff9,!0x0);}const _0xdc997f={..._0x5d7b82};if(_0x339ff9==='mfaSmsEnrollment'||_0x339ff9==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0xdc997f){const _0x4f62ff=_0xdc997f['phoneEnrollmentInfo']['phoneNumber'],_0x44775f=_0xdc997f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0xdc997f,{'phoneEnrollmentInfo':{'phoneNumber':_0x4f62ff,'recaptchaToken':_0x44775f,'captchaResponse':_0x47828d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0xdc997f){const _0x18f2c8=_0xdc997f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0xdc997f,{'phoneSignInInfo':{'recaptchaToken':_0x18f2c8,'captchaResponse':_0x47828d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0xdc997f;}return _0x3d4617?Object['assign'](_0xdc997f,{'captchaResp':_0x47828d}):Object['assign'](_0xdc997f,{'captchaResponse':_0x47828d}),Object['assign'](_0xdc997f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0xdc997f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0xdc997f;}async function xi(_0x158cbb,_0x2e0a9e,_0x57cbf3,_0x48f004,_0x27b90e){var _0x33ae6f;if((_0x33ae6f=_0x158cbb['_getRecaptchaConfig']())!=null&&_0x33ae6f['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x124b0c=await kr(_0x158cbb,_0x2e0a9e,_0x57cbf3,_0x57cbf3==='getOobCode');return _0x48f004(_0x158cbb,_0x124b0c);}else return _0x48f004(_0x158cbb,_0x2e0a9e)['catch'](async _0x2dbb0c=>{if(_0x2dbb0c['code']==='auth/missing-recaptcha-token'){console['log'](_0x57cbf3+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x223440=await kr(_0x158cbb,_0x2e0a9e,_0x57cbf3,_0x57cbf3==='getOobCode');return _0x48f004(_0x158cbb,_0x223440);}else return Promise['reject'](_0x2dbb0c);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x2cea14,_0x48020c){const _0x2b3448=Hi(_0x2cea14,'auth');if(_0x2b3448['isInitialized']()){const _0x2adb83=_0x2b3448['getImmediate'](),_0x11cafb=_0x2b3448['getOptions']();if(xe(_0x11cafb,_0x48020c??{}))return _0x2adb83;Y(_0x2adb83,'already-initialized');}return _0x2b3448['initialize']({'options':_0x48020c});}function Hf(_0x3456c0,_0x31091e){const _0x11b9b4=(_0x31091e==null?void 0x0:_0x31091e['persistence'])||[],_0x183855=(Array['isArray'](_0x11b9b4)?_0x11b9b4:[_0x11b9b4])['map'](ie);_0x31091e!=null&&_0x31091e['errorMap']&&_0x3456c0['_updateErrorMap'](_0x31091e['errorMap']),_0x3456c0['_initializeWithPersistence'](_0x183855,_0x31091e==null?void 0x0:_0x31091e['popupRedirectResolver']);}function $f(_0xf9af1c,_0x9921bb,_0x2ed2a2){const _0x2d56c6=Ke(_0xf9af1c);m(/^https?:\/\//['test'](_0x9921bb),_0x2d56c6,'invalid-emulator-scheme');const _0x4f0e67=!0x1,_0x2f103f=Ua(_0x9921bb),{host:_0x14cae9,port:_0x473fc8}=Gf(_0x9921bb),_0x4e9b36=_0x473fc8===null?'':':'+_0x473fc8,_0x27c1ee={'url':_0x2f103f+'//'+_0x14cae9+_0x4e9b36+'/'},_0x6773bb=Object['freeze']({'host':_0x14cae9,'port':_0x473fc8,'protocol':_0x2f103f['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4f0e67})});if(!_0x2d56c6['_canInitEmulator']){m(_0x2d56c6['config']['emulator']&&_0x2d56c6['emulatorConfig'],_0x2d56c6,'emulator-config-failed'),m(xe(_0x27c1ee,_0x2d56c6['config']['emulator'])&&xe(_0x6773bb,_0x2d56c6['emulatorConfig']),_0x2d56c6,'emulator-config-failed');return;}_0x2d56c6['config']['emulator']=_0x27c1ee,_0x2d56c6['emulatorConfig']=_0x6773bb,_0x2d56c6['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x14cae9)?Qr(_0x2f103f+'//'+_0x14cae9+_0x4e9b36):qf();}function Ua(_0x327cc1){const _0x1120bf=_0x327cc1['indexOf'](':');return _0x1120bf<0x0?'':_0x327cc1['substr'](0x0,_0x1120bf+0x1);}function Gf(_0x12a6de){const _0x3b920b=Ua(_0x12a6de),_0x1a1608=/(\/\/)?([^?#/]+)/['exec'](_0x12a6de['substr'](_0x3b920b['length']));if(!_0x1a1608)return{'host':'','port':null};const _0xab091c=_0x1a1608[0x2]['split']('@')['pop']()||'',_0x6b4e5f=/^(\[[^\]]+\])(:|$)/['exec'](_0xab091c);if(_0x6b4e5f){const _0x4921e0=_0x6b4e5f[0x1];return{'host':_0x4921e0,'port':Pr(_0xab091c['substr'](_0x4921e0['length']+0x1))};}else{const [_0x58210c,_0x3ddbdc]=_0xab091c['split'](':');return{'host':_0x58210c,'port':Pr(_0x3ddbdc)};}}function Pr(_0x45d18e){if(!_0x45d18e)return null;const _0x2118ea=Number(_0x45d18e);return isNaN(_0x2118ea)?null:_0x2118ea;}function qf(){function _0x4ff851(){const _0x4b3456=document['createElement']('p'),_0xde87f0=_0x4b3456['style'];_0x4b3456['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xde87f0['position']='fixed',_0xde87f0['width']='100%',_0xde87f0['backgroundColor']='#ffffff',_0xde87f0['border']='.1em\x20solid\x20#000000',_0xde87f0['color']='#b50000',_0xde87f0['bottom']='0px',_0xde87f0['left']='0px',_0xde87f0['margin']='0px',_0xde87f0['zIndex']='10000',_0xde87f0['textAlign']='center',_0x4b3456['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4b3456);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x4ff851):_0x4ff851());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x339a4d,_0x4bf00f){this['providerId']=_0x339a4d,this['signInMethod']=_0x4bf00f;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2c1a04){return ne('not\x20implemented');}['_linkToIdToken'](_0x2c62c2,_0x7dc191){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2c887f){return ne('not\x20implemented');}}async function zf(_0x326295,_0x38ddd2){return Pe(_0x326295,'POST','/v1/accounts:signUp',_0x38ddd2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x37f990,_0xa12dbc){return en(_0x37f990,'POST','/v1/accounts:signInWithPassword',ke(_0x37f990,_0xa12dbc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x4ac029,_0x13af39){return en(_0x4ac029,'POST','/v1/accounts:signInWithEmailLink',ke(_0x4ac029,_0x13af39));}async function Yf(_0x281722,_0x4628dc){return en(_0x281722,'POST','/v1/accounts:signInWithEmailLink',ke(_0x281722,_0x4628dc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x4df897,_0x145dc3,_0x7b5cac,_0x1b4c3d=null){super('password',_0x7b5cac),this['_email']=_0x4df897,this['_password']=_0x145dc3,this['_tenantId']=_0x1b4c3d;}static['_fromEmailAndPassword'](_0x2c92b9,_0x58a7ba){return new $t(_0x2c92b9,_0x58a7ba,'password');}static['_fromEmailAndCode'](_0x450066,_0x54ef1c,_0x157d69=null){return new $t(_0x450066,_0x54ef1c,'emailLink',_0x157d69);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x410314){const _0x597c5c=typeof _0x410314=='string'?JSON['parse'](_0x410314):_0x410314;if(_0x597c5c!=null&&_0x597c5c['email']&&(_0x597c5c!=null&&_0x597c5c['password'])){if(_0x597c5c['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x597c5c['email'],_0x597c5c['password']);if(_0x597c5c['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x597c5c['email'],_0x597c5c['password'],_0x597c5c['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2c08a1){switch(this['signInMethod']){case'password':const _0x45b3d={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2c08a1,_0x45b3d,'signInWithPassword',jf);case'emailLink':return Kf(_0x2c08a1,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2c08a1,'internal-error');}}async['_linkToIdToken'](_0x3b9af2,_0xb13044){switch(this['signInMethod']){case'password':const _0x5e1be1={'idToken':_0xb13044,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x3b9af2,_0x5e1be1,'signUpPassword',zf);case'emailLink':return Yf(_0x3b9af2,{'idToken':_0xb13044,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x3b9af2,'internal-error');}}['_getReauthenticationResolver'](_0xe9d3c8){return this['_getIdTokenResponse'](_0xe9d3c8);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x58a23b,_0x6820f9){return en(_0x58a23b,'POST','/v1/accounts:signInWithIdp',ke(_0x58a23b,_0x6820f9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1ac432){const _0x28dc3e=new $e(_0x1ac432['providerId'],_0x1ac432['signInMethod']);return _0x1ac432['idToken']||_0x1ac432['accessToken']?(_0x1ac432['idToken']&&(_0x28dc3e['idToken']=_0x1ac432['idToken']),_0x1ac432['accessToken']&&(_0x28dc3e['accessToken']=_0x1ac432['accessToken']),_0x1ac432['nonce']&&!_0x1ac432['pendingToken']&&(_0x28dc3e['nonce']=_0x1ac432['nonce']),_0x1ac432['pendingToken']&&(_0x28dc3e['pendingToken']=_0x1ac432['pendingToken'])):_0x1ac432['oauthToken']&&_0x1ac432['oauthTokenSecret']?(_0x28dc3e['accessToken']=_0x1ac432['oauthToken'],_0x28dc3e['secret']=_0x1ac432['oauthTokenSecret']):Y('argument-error'),_0x28dc3e;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x23e32a){const _0x195d32=typeof _0x23e32a=='string'?JSON['parse'](_0x23e32a):_0x23e32a,{providerId:_0x13b46e,signInMethod:_0x42c57c,..._0x11bb56}=_0x195d32;if(!_0x13b46e||!_0x42c57c)return null;const _0x31aa42=new $e(_0x13b46e,_0x42c57c);return _0x31aa42['idToken']=_0x11bb56['idToken']||void 0x0,_0x31aa42['accessToken']=_0x11bb56['accessToken']||void 0x0,_0x31aa42['secret']=_0x11bb56['secret'],_0x31aa42['nonce']=_0x11bb56['nonce'],_0x31aa42['pendingToken']=_0x11bb56['pendingToken']||null,_0x31aa42;}['_getIdTokenResponse'](_0x487e1e){const _0x52c0e7=this['buildRequest']();return nt(_0x487e1e,_0x52c0e7);}['_linkToIdToken'](_0x4f5961,_0x5a4ac6){const _0x49d4d8=this['buildRequest']();return _0x49d4d8['idToken']=_0x5a4ac6,nt(_0x4f5961,_0x49d4d8);}['_getReauthenticationResolver'](_0xfe7dba){const _0x434dc5=this['buildRequest']();return _0x434dc5['autoCreate']=!0x1,nt(_0xfe7dba,_0x434dc5);}['buildRequest'](){const _0x377bed={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x377bed['pendingToken']=this['pendingToken'];else{const _0x396c28={};this['idToken']&&(_0x396c28['id_token']=this['idToken']),this['accessToken']&&(_0x396c28['access_token']=this['accessToken']),this['secret']&&(_0x396c28['oauth_token_secret']=this['secret']),_0x396c28['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x396c28['nonce']=this['nonce']),_0x377bed['postBody']=ut(_0x396c28);}return _0x377bed;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x5060a4){switch(_0x5060a4){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x525d61){const _0x3fc3c2=Ct(Tt(_0x525d61))['link'],_0x3aaeb=_0x3fc3c2?Ct(Tt(_0x3fc3c2))['deep_link_id']:null,_0x3d3f08=Ct(Tt(_0x525d61))['deep_link_id'];return(_0x3d3f08?Ct(Tt(_0x3d3f08))['link']:null)||_0x3d3f08||_0x3aaeb||_0x3fc3c2||_0x525d61;}class Rs{constructor(_0x34e6d4){const _0x324edf=Ct(Tt(_0x34e6d4)),_0x3e6bf6=_0x324edf['apiKey']??null,_0x15e370=_0x324edf['oobCode']??null,_0x2d2d4e=Jf(_0x324edf['mode']??null);m(_0x3e6bf6&&_0x15e370&&_0x2d2d4e,'argument-error'),this['apiKey']=_0x3e6bf6,this['operation']=_0x2d2d4e,this['code']=_0x15e370,this['continueUrl']=_0x324edf['continueUrl']??null,this['languageCode']=_0x324edf['lang']??null,this['tenantId']=_0x324edf['tenantId']??null;}static['parseLink'](_0x84e25b){const _0x4e1f66=Xf(_0x84e25b);try{return new Rs(_0x4e1f66);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x67155b,_0x1efa00){return $t['_fromEmailAndPassword'](_0x67155b,_0x1efa00);}static['credentialWithLink'](_0x5360cb,_0x267cea){const _0x24abdf=Rs['parseLink'](_0x267cea);return m(_0x24abdf,'argument-error'),$t['_fromEmailAndCode'](_0x5360cb,_0x24abdf['code'],_0x24abdf['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x40812f){this['providerId']=_0x40812f,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x5caa93){this['defaultLanguageCode']=_0x5caa93;}['setCustomParameters'](_0x3b3bb1){return this['customParameters']=_0x3b3bb1,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x223a93){return this['scopes']['includes'](_0x223a93)||this['scopes']['push'](_0x223a93),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x389bac){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x389bac});}static['credentialFromResult'](_0x5ec7cf){return ue['credentialFromTaggedObject'](_0x5ec7cf);}static['credentialFromError'](_0x8d55cc){return ue['credentialFromTaggedObject'](_0x8d55cc['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x59c072}){if(!_0x59c072||!('oauthAccessToken'in _0x59c072)||!_0x59c072['oauthAccessToken'])return null;try{return ue['credential'](_0x59c072['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5b6b21,_0xaec8d3){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5b6b21,'accessToken':_0xaec8d3});}static['credentialFromResult'](_0x579e5e){return de['credentialFromTaggedObject'](_0x579e5e);}static['credentialFromError'](_0x308d6e){return de['credentialFromTaggedObject'](_0x308d6e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x234694}){if(!_0x234694)return null;const {oauthIdToken:_0x3ea06e,oauthAccessToken:_0x26d199}=_0x234694;if(!_0x3ea06e&&!_0x26d199)return null;try{return de['credential'](_0x3ea06e,_0x26d199);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x2c96b0){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x2c96b0});}static['credentialFromResult'](_0x43d3e8){return fe['credentialFromTaggedObject'](_0x43d3e8);}static['credentialFromError'](_0x1a30a4){return fe['credentialFromTaggedObject'](_0x1a30a4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2c60bf}){if(!_0x2c60bf||!('oauthAccessToken'in _0x2c60bf)||!_0x2c60bf['oauthAccessToken'])return null;try{return fe['credential'](_0x2c60bf['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x22f860,_0x1a4470){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x22f860,'oauthTokenSecret':_0x1a4470});}static['credentialFromResult'](_0x47dd0d){return pe['credentialFromTaggedObject'](_0x47dd0d);}static['credentialFromError'](_0x2e5173){return pe['credentialFromTaggedObject'](_0x2e5173['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2f26db}){if(!_0x2f26db)return null;const {oauthAccessToken:_0x47b384,oauthTokenSecret:_0x3b96de}=_0x2f26db;if(!_0x47b384||!_0x3b96de)return null;try{return pe['credential'](_0x47b384,_0x3b96de);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0xfa35a4,_0x3ce4db){return en(_0xfa35a4,'POST','/v1/accounts:signUp',ke(_0xfa35a4,_0x3ce4db));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x5942e8){this['user']=_0x5942e8['user'],this['providerId']=_0x5942e8['providerId'],this['_tokenResponse']=_0x5942e8['_tokenResponse'],this['operationType']=_0x5942e8['operationType'];}static async['_fromIdTokenResponse'](_0x23599b,_0x21789e,_0x2bfc16,_0x1d5412=!0x1){const _0x514622=await j['_fromIdTokenResponse'](_0x23599b,_0x2bfc16,_0x1d5412),_0x445a80=Nr(_0x2bfc16);return new Ge({'user':_0x514622,'providerId':_0x445a80,'_tokenResponse':_0x2bfc16,'operationType':_0x21789e});}static async['_forOperation'](_0x2c9fac,_0x56abed,_0x432c2f){await _0x2c9fac['_updateTokensIfNecessary'](_0x432c2f,!0x0);const _0x9db9dd=Nr(_0x432c2f);return new Ge({'user':_0x2c9fac,'providerId':_0x9db9dd,'_tokenResponse':_0x432c2f,'operationType':_0x56abed});}}function Nr(_0x5600d6){return _0x5600d6['providerId']?_0x5600d6['providerId']:'phoneNumber'in _0x5600d6?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x4f8bd5,_0x2957dd,_0x4fe294,_0x5d4790){super(_0x2957dd['code'],_0x2957dd['message']),this['operationType']=_0x4fe294,this['user']=_0x5d4790,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x4f8bd5['name'],'tenantId':_0x4f8bd5['tenantId']??void 0x0,'_serverResponse':_0x2957dd['customData']['_serverResponse'],'operationType':_0x4fe294};}static['_fromErrorAndOperation'](_0x1e03d2,_0x5341b0,_0x34542c,_0x319d1b){return new On(_0x1e03d2,_0x5341b0,_0x34542c,_0x319d1b);}}function Ba(_0xcaa58f,_0x2cbcc3,_0xe6aa09,_0x409267){return(_0x2cbcc3==='reauthenticate'?_0xe6aa09['_getReauthenticationResolver'](_0xcaa58f):_0xe6aa09['_getIdTokenResponse'](_0xcaa58f))['catch'](_0x4d2308=>{throw _0x4d2308['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0xcaa58f,_0x4d2308,_0x2cbcc3,_0x409267):_0x4d2308;});}async function ep(_0x5acba3,_0x2864a9,_0x1c55c4=!0x1){const _0x3d3be3=await Ht(_0x5acba3,_0x2864a9['_linkToIdToken'](_0x5acba3['auth'],await _0x5acba3['getIdToken']()),_0x1c55c4);return Ge['_forOperation'](_0x5acba3,'link',_0x3d3be3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x25a178,_0x2bf661,_0x154ed7=!0x1){const {auth:_0x260c2c}=_0x25a178;if($(_0x260c2c['app']))return Promise['reject'](re(_0x260c2c));const _0x14a896='reauthenticate';try{const _0x58cdba=await Ht(_0x25a178,Ba(_0x260c2c,_0x14a896,_0x2bf661,_0x25a178),_0x154ed7);m(_0x58cdba['idToken'],_0x260c2c,'internal-error');const _0x33958c=Ts(_0x58cdba['idToken']);m(_0x33958c,_0x260c2c,'internal-error');const {sub:_0x43028b}=_0x33958c;return m(_0x25a178['uid']===_0x43028b,_0x260c2c,'user-mismatch'),Ge['_forOperation'](_0x25a178,_0x14a896,_0x58cdba);}catch(_0x4b5dcb){throw(_0x4b5dcb==null?void 0x0:_0x4b5dcb['code'])==='auth/user-not-found'&&Y(_0x260c2c,'user-mismatch'),_0x4b5dcb;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x67ade5,_0x74c402,_0x5d8ecc=!0x1){if($(_0x67ade5['app']))return Promise['reject'](re(_0x67ade5));const _0x28bc8a='signIn',_0x220773=await Ba(_0x67ade5,_0x28bc8a,_0x74c402),_0x46f617=await Ge['_fromIdTokenResponse'](_0x67ade5,_0x28bc8a,_0x220773);return _0x5d8ecc||await _0x67ade5['_updateCurrentUser'](_0x46f617['user']),_0x46f617;}async function np(_0x22b407,_0x4ea955){return Va(Ke(_0x22b407),_0x4ea955);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x2976d8){const _0x1a6e46=Ke(_0x2976d8);_0x1a6e46['_getPasswordPolicyInternal']()&&await _0x1a6e46['_updatePasswordPolicy']();}async function L_(_0x393bd8,_0x3fd5c7,_0x47ee2f){if($(_0x393bd8['app']))return Promise['reject'](re(_0x393bd8));const _0x42efdd=Ke(_0x393bd8),_0x1fe745=await xi(_0x42efdd,{'returnSecureToken':!0x0,'email':_0x3fd5c7,'password':_0x47ee2f,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x302651=>{throw _0x302651['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x393bd8),_0x302651;}),_0x26f95d=await Ge['_fromIdTokenResponse'](_0x42efdd,'signIn',_0x1fe745);return await _0x42efdd['_updateCurrentUser'](_0x26f95d['user']),_0x26f95d;}function x_(_0x29268b,_0x20904c,_0x635393){return $(_0x29268b['app'])?Promise['reject'](re(_0x29268b)):np(P(_0x29268b),yt['credential'](_0x20904c,_0x635393))['catch'](async _0x466a6b=>{throw _0x466a6b['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x29268b),_0x466a6b;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x8b530d,_0x55ae6c){return P(_0x8b530d)['setPersistence'](_0x55ae6c);}function ip(_0x4de7d9,_0x442f92,_0x38d61f,_0x512aac){return P(_0x4de7d9)['onIdTokenChanged'](_0x442f92,_0x38d61f,_0x512aac);}function sp(_0x2c1476,_0x31816b,_0x1db5b5){return P(_0x2c1476)['beforeAuthStateChanged'](_0x31816b,_0x1db5b5);}function U_(_0x39f807,_0x56674d,_0x41f775,_0xee2c9f){return P(_0x39f807)['onAuthStateChanged'](_0x56674d,_0x41f775,_0xee2c9f);}function W_(_0x11ff9a){return P(_0x11ff9a)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x48dd86,_0x1391d0){this['storageRetriever']=_0x48dd86,this['type']=_0x1391d0;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x29c15b,_0x430a8c){return this['storage']['setItem'](_0x29c15b,JSON['stringify'](_0x430a8c)),Promise['resolve']();}['_get'](_0x149885){const _0x10f9cd=this['storage']['getItem'](_0x149885);return Promise['resolve'](_0x10f9cd?JSON['parse'](_0x10f9cd):null);}['_remove'](_0x171782){return this['storage']['removeItem'](_0x171782),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1bb4e9,_0x1b1c45)=>this['onStorageEvent'](_0x1bb4e9,_0x1b1c45),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5ee28b){for(const _0x82b5d5 of Object['keys'](this['listeners'])){const _0x4deac1=this['storage']['getItem'](_0x82b5d5),_0x3c4d1d=this['localCache'][_0x82b5d5];_0x4deac1!==_0x3c4d1d&&_0x5ee28b(_0x82b5d5,_0x3c4d1d,_0x4deac1);}}['onStorageEvent'](_0x4551f1,_0x4f62fc=!0x1){if(!_0x4551f1['key']){this['forAllChangedKeys']((_0x25985b,_0x17617a,_0xd2b18f)=>{this['notifyListeners'](_0x25985b,_0xd2b18f);});return;}const _0x5b3f81=_0x4551f1['key'];_0x4f62fc?this['detachListener']():this['stopPolling']();const _0x12eeb2=()=>{const _0x7a0b00=this['storage']['getItem'](_0x5b3f81);!_0x4f62fc&&this['localCache'][_0x5b3f81]===_0x7a0b00||this['notifyListeners'](_0x5b3f81,_0x7a0b00);},_0x232dc9=this['storage']['getItem'](_0x5b3f81);Af()&&_0x232dc9!==_0x4551f1['newValue']&&_0x4551f1['newValue']!==_0x4551f1['oldValue']?setTimeout(_0x12eeb2,op):_0x12eeb2();}['notifyListeners'](_0x2155c0,_0x3a9048){this['localCache'][_0x2155c0]=_0x3a9048;const _0x423edb=this['listeners'][_0x2155c0];if(_0x423edb){for(const _0x3c288c of Array['from'](_0x423edb))_0x3c288c(_0x3a9048&&JSON['parse'](_0x3a9048));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2f6fe7,_0x476831,_0x48d3ef)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2f6fe7,'oldValue':_0x476831,'newValue':_0x48d3ef}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x236d88,_0x29236){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x236d88]||(this['listeners'][_0x236d88]=new Set(),this['localCache'][_0x236d88]=this['storage']['getItem'](_0x236d88)),this['listeners'][_0x236d88]['add'](_0x29236);}['_removeListener'](_0x3d4950,_0x5f309e){this['listeners'][_0x3d4950]&&(this['listeners'][_0x3d4950]['delete'](_0x5f309e),this['listeners'][_0x3d4950]['size']===0x0&&delete this['listeners'][_0x3d4950]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x5accf0,_0x3df7e1){await super['_set'](_0x5accf0,_0x3df7e1),this['localCache'][_0x5accf0]=JSON['stringify'](_0x3df7e1);}async['_get'](_0x505bdf){const _0x5f73f4=await super['_get'](_0x505bdf);return this['localCache'][_0x505bdf]=JSON['stringify'](_0x5f73f4),_0x5f73f4;}async['_remove'](_0x24724d){await super['_remove'](_0x24724d),delete this['localCache'][_0x24724d];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x22cf22,_0xb0f44e){}['_removeListener'](_0xb6c186,_0x157b2e){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x472aad){return Promise['all'](_0x472aad['map'](async _0x4e0a87=>{try{return{'fulfilled':!0x0,'value':await _0x4e0a87};}catch(_0x5bfa11){return{'fulfilled':!0x1,'reason':_0x5bfa11};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x581387){this['eventTarget']=_0x581387,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2a2514){const _0xfcae83=this['receivers']['find'](_0x1a95c9=>_0x1a95c9['isListeningto'](_0x2a2514));if(_0xfcae83)return _0xfcae83;const _0x15efb5=new Xn(_0x2a2514);return this['receivers']['push'](_0x15efb5),_0x15efb5;}['isListeningto'](_0x286ff2){return this['eventTarget']===_0x286ff2;}async['handleEvent'](_0x2a97eb){const _0x528946=_0x2a97eb,{eventId:_0x3197c4,eventType:_0x4badcf,data:_0x3c78a4}=_0x528946['data'],_0x5c07d3=this['handlersMap'][_0x4badcf];if(!(_0x5c07d3!=null&&_0x5c07d3['size']))return;_0x528946['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3197c4,'eventType':_0x4badcf});const _0x1acb11=Array['from'](_0x5c07d3)['map'](async _0x4db55b=>_0x4db55b(_0x528946['origin'],_0x3c78a4)),_0x2552e9=await cp(_0x1acb11);_0x528946['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3197c4,'eventType':_0x4badcf,'response':_0x2552e9});}['_subscribe'](_0xe51029,_0x248424){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0xe51029]||(this['handlersMap'][_0xe51029]=new Set()),this['handlersMap'][_0xe51029]['add'](_0x248424);}['_unsubscribe'](_0x43b962,_0x475e77){this['handlersMap'][_0x43b962]&&_0x475e77&&this['handlersMap'][_0x43b962]['delete'](_0x475e77),(!_0x475e77||this['handlersMap'][_0x43b962]['size']===0x0)&&delete this['handlersMap'][_0x43b962],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x56da58='',_0x24bc37=0xa){let _0xb472ae='';for(let _0x331f22=0x0;_0x331f22<_0x24bc37;_0x331f22++)_0xb472ae+=Math['floor'](Math['random']()*0xa);return _0x56da58+_0xb472ae;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x354c9c){this['target']=_0x354c9c,this['handlers']=new Set();}['removeMessageHandler'](_0x5ef354){_0x5ef354['messageChannel']&&(_0x5ef354['messageChannel']['port1']['removeEventListener']('message',_0x5ef354['onMessage']),_0x5ef354['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x5ef354);}async['_send'](_0x32850e,_0x3ce1b7,_0x293830=0x32){const _0x4aa7e7=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4aa7e7)throw new Error('connection_unavailable');let _0x533383,_0x286044;return new Promise((_0x273b1b,_0x50cd33)=>{const _0x2e0023=As('',0x14);_0x4aa7e7['port1']['start']();const _0x265b89=setTimeout(()=>{_0x50cd33(new Error('unsupported_event'));},_0x293830);_0x286044={'messageChannel':_0x4aa7e7,'onMessage'(_0x5a3aa9){const _0x1fd81b=_0x5a3aa9;if(_0x1fd81b['data']['eventId']===_0x2e0023)switch(_0x1fd81b['data']['status']){case'ack':clearTimeout(_0x265b89),_0x533383=setTimeout(()=>{_0x50cd33(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x533383),_0x273b1b(_0x1fd81b['data']['response']);break;default:clearTimeout(_0x265b89),clearTimeout(_0x533383),_0x50cd33(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x286044),_0x4aa7e7['port1']['addEventListener']('message',_0x286044['onMessage']),this['target']['postMessage']({'eventType':_0x32850e,'eventId':_0x2e0023,'data':_0x3ce1b7},[_0x4aa7e7['port2']]);})['finally'](()=>{_0x286044&&this['removeMessageHandler'](_0x286044);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x29ec47){Z()['location']['href']=_0x29ec47;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x25d527;return((_0x25d527=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x25d527['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x3a786c){this['request']=_0x3a786c;}['toPromise'](){return new Promise((_0x4eff99,_0x26b667)=>{this['request']['addEventListener']('success',()=>{_0x4eff99(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x26b667(this['request']['error']);});});}}function Zn(_0x49eb0c,_0x48a378){return _0x49eb0c['transaction']([Mn],_0x48a378?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x42fa21=indexedDB['deleteDatabase'](Ka);return new nn(_0x42fa21)['toPromise']();}function Qa(){const _0x345334=indexedDB['open'](Ka,pp);return new Promise((_0x53412c,_0x154fa2)=>{_0x345334['addEventListener']('error',()=>{_0x154fa2(_0x345334['error']);}),_0x345334['addEventListener']('upgradeneeded',()=>{const _0x2e0559=_0x345334['result'];try{_0x2e0559['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x116b64){_0x154fa2(_0x116b64);}}),_0x345334['addEventListener']('success',async()=>{const _0x161a9e=_0x345334['result'];_0x161a9e['objectStoreNames']['contains'](Mn)?_0x53412c(_0x161a9e):(_0x161a9e['close'](),await _p(),_0x53412c(await Qa()));});});}async function Or(_0x1b690d,_0x349967,_0x1252ae){const _0x437b2a=Zn(_0x1b690d,!0x0)['put']({[Ya]:_0x349967,'value':_0x1252ae});return new nn(_0x437b2a)['toPromise']();}async function gp(_0x40f4cf,_0x5ced1f){const _0x47b383=Zn(_0x40f4cf,!0x1)['get'](_0x5ced1f),_0x226211=await new nn(_0x47b383)['toPromise']();return _0x226211===void 0x0?null:_0x226211['value'];}function Dr(_0x1365eb,_0x1ad951){const _0x1c293f=Zn(_0x1365eb,!0x0)['delete'](_0x1ad951);return new nn(_0x1c293f)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x516f90){let _0x4e1f70=0x0;for(;;)try{const _0x515716=await this['_openDb']();return await _0x516f90(_0x515716);}catch(_0x249850){if(_0x4e1f70++>yp)throw _0x249850;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0xe8e03c,_0x25c665)=>({'keyProcessed':(await this['_poll']())['includes'](_0x25c665['key'])})),this['receiver']['_subscribe']('ping',async(_0x2ab809,_0x49f951)=>['keyChanged']);}async['initializeSender'](){var _0x2caa65,_0x41779b;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x27274f=await this['sender']['_send']('ping',{},0x320);_0x27274f&&(_0x2caa65=_0x27274f[0x0])!=null&&_0x2caa65['fulfilled']&&(_0x41779b=_0x27274f[0x0])!=null&&_0x41779b['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2174b9){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2174b9},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5e930d=>{await Or(_0x5e930d,Dn,'1'),await Dr(_0x5e930d,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x45ca17){this['pendingWrites']++;try{await _0x45ca17();}finally{this['pendingWrites']--;}}async['_set'](_0x5338b1,_0x24a8ef){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3c686f=>Or(_0x3c686f,_0x5338b1,_0x24a8ef)),this['localCache'][_0x5338b1]=_0x24a8ef,this['notifyServiceWorker'](_0x5338b1)));}async['_get'](_0x1d18bb){const _0xaeaf4e=await this['_withRetries'](_0x5c80dd=>gp(_0x5c80dd,_0x1d18bb));return this['localCache'][_0x1d18bb]=_0xaeaf4e,_0xaeaf4e;}async['_remove'](_0x5d36f7){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x352250=>Dr(_0x352250,_0x5d36f7)),delete this['localCache'][_0x5d36f7],this['notifyServiceWorker'](_0x5d36f7)));}async['_poll'](){const _0x57ae2c=await this['_withRetries'](_0x2b871d=>{const _0x5e2b44=Zn(_0x2b871d,!0x1)['getAll']();return new nn(_0x5e2b44)['toPromise']();});if(!_0x57ae2c)return[];if(this['pendingWrites']!==0x0)return[];const _0x3d070d=[],_0x2ef8f3=new Set();if(_0x57ae2c['length']!==0x0){for(const {fbase_key:_0x679114,value:_0x3bef1b}of _0x57ae2c)_0x2ef8f3['add'](_0x679114),JSON['stringify'](this['localCache'][_0x679114])!==JSON['stringify'](_0x3bef1b)&&(this['notifyListeners'](_0x679114,_0x3bef1b),_0x3d070d['push'](_0x679114));}for(const _0x39ca49 of Object['keys'](this['localCache']))this['localCache'][_0x39ca49]&&!_0x2ef8f3['has'](_0x39ca49)&&(this['notifyListeners'](_0x39ca49,null),_0x3d070d['push'](_0x39ca49));return _0x3d070d;}['notifyListeners'](_0x52db49,_0x5a8e4c){this['localCache'][_0x52db49]=_0x5a8e4c;const _0x27cb63=this['listeners'][_0x52db49];if(_0x27cb63){for(const _0x4d968a of Array['from'](_0x27cb63))_0x4d968a(_0x5a8e4c);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x1d8133,_0x135441){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x1d8133]||(this['listeners'][_0x1d8133]=new Set(),this['_get'](_0x1d8133)),this['listeners'][_0x1d8133]['add'](_0x135441);}['_removeListener'](_0x53679c,_0x3bd995){this['listeners'][_0x53679c]&&(this['listeners'][_0x53679c]['delete'](_0x3bd995),this['listeners'][_0x53679c]['size']===0x0&&delete this['listeners'][_0x53679c]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x51ecb1,_0x2e854d){return _0x2e854d?ie(_0x2e854d):(m(_0x51ecb1['_popupRedirectResolver'],_0x51ecb1,'argument-error'),_0x51ecb1['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x4dc708){super('custom','custom'),this['params']=_0x4dc708;}['_getIdTokenResponse'](_0x592e7d){return nt(_0x592e7d,this['_buildIdpRequest']());}['_linkToIdToken'](_0x387802,_0x191168){return nt(_0x387802,this['_buildIdpRequest'](_0x191168));}['_getReauthenticationResolver'](_0x235552){return nt(_0x235552,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1d46f5){const _0x3effc2={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1d46f5&&(_0x3effc2['idToken']=_0x1d46f5),_0x3effc2;}}function Ip(_0x4d08b0){return Va(_0x4d08b0['auth'],new ks(_0x4d08b0),_0x4d08b0['bypassAuthState']);}function wp(_0x3fe949){const {auth:_0x4d5c4f,user:_0x5139fe}=_0x3fe949;return m(_0x5139fe,_0x4d5c4f,'internal-error'),tp(_0x5139fe,new ks(_0x3fe949),_0x3fe949['bypassAuthState']);}async function Cp(_0x4b1760){const {auth:_0x4c1c78,user:_0x51d01d}=_0x4b1760;return m(_0x51d01d,_0x4c1c78,'internal-error'),ep(_0x51d01d,new ks(_0x4b1760),_0x4b1760['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x256262,_0x4925d2,_0x7557b9,_0x421c82,_0x61ab17=!0x1){this['auth']=_0x256262,this['resolver']=_0x7557b9,this['user']=_0x421c82,this['bypassAuthState']=_0x61ab17,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4925d2)?_0x4925d2:[_0x4925d2];}['execute'](){return new Promise(async(_0x3d11c8,_0x3ee564)=>{this['pendingPromise']={'resolve':_0x3d11c8,'reject':_0x3ee564};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x6f24){this['reject'](_0x6f24);}});}async['onAuthEvent'](_0x49fd7c){const {urlResponse:_0x5453fd,sessionId:_0x3bdc44,postBody:_0x24eb2c,tenantId:_0x237e61,error:_0x5b0d16,type:_0x455cd6}=_0x49fd7c;if(_0x5b0d16){this['reject'](_0x5b0d16);return;}const _0x1705ea={'auth':this['auth'],'requestUri':_0x5453fd,'sessionId':_0x3bdc44,'tenantId':_0x237e61||void 0x0,'postBody':_0x24eb2c||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x455cd6)(_0x1705ea));}catch(_0x157b6b){this['reject'](_0x157b6b);}}['onError'](_0xd48b61){this['reject'](_0xd48b61);}['getIdpTask'](_0x560115){switch(_0x560115){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x9649c4){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x9649c4),this['unregisterAndCleanUp']();}['reject'](_0x5bae97){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5bae97),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x42f61e,_0x2508b2,_0x557170,_0x52a151,_0x580086){super(_0x42f61e,_0x2508b2,_0x52a151,_0x580086),this['provider']=_0x557170,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0xe09d7f=await this['execute']();return m(_0xe09d7f,this['auth'],'internal-error'),_0xe09d7f;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x421d11=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x421d11),this['authWindow']['associatedEvent']=_0x421d11,this['resolver']['_originValidation'](this['auth'])['catch'](_0xd04c74=>{this['reject'](_0xd04c74);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x19568c=>{_0x19568c||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4e1bb3;return((_0x4e1bb3=this['authWindow'])==null?void 0x0:_0x4e1bb3['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x27c4ee=()=>{var _0x296c90,_0x1dc548;if((_0x1dc548=(_0x296c90=this['authWindow'])==null?void 0x0:_0x296c90['window'])!=null&&_0x1dc548['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x27c4ee,Tp['get']());};_0x27c4ee();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x36d5c8,_0x32f1c4,_0xa0be45=!0x1){super(_0x36d5c8,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x32f1c4,void 0x0,_0xa0be45),this['eventId']=null;}async['execute'](){let _0x271a4e=hn['get'](this['auth']['_key']());if(!_0x271a4e){try{const _0x5b12ca=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x271a4e=()=>Promise['resolve'](_0x5b12ca);}catch(_0x2bbe0a){_0x271a4e=()=>Promise['reject'](_0x2bbe0a);}hn['set'](this['auth']['_key'](),_0x271a4e);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x271a4e();}async['onAuthEvent'](_0x333d1c){if(_0x333d1c['type']==='signInViaRedirect')return super['onAuthEvent'](_0x333d1c);if(_0x333d1c['type']==='unknown'){this['resolve'](null);return;}if(_0x333d1c['eventId']){const _0xaf5400=await this['auth']['_redirectUserForId'](_0x333d1c['eventId']);if(_0xaf5400)return this['user']=_0xaf5400,super['onAuthEvent'](_0x333d1c);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x24370c,_0x4d1a04){const _0x54a74f=Pp(_0x4d1a04),_0x57be15=kp(_0x24370c);if(!await _0x57be15['_isAvailable']())return!0x1;const _0x46ce2b=await _0x57be15['_get'](_0x54a74f)==='true';return await _0x57be15['_remove'](_0x54a74f),_0x46ce2b;}function Ap(_0xedf424,_0x43cf51){hn['set'](_0xedf424['_key'](),_0x43cf51);}function kp(_0x3f4f58){return ie(_0x3f4f58['_redirectPersistence']);}function Pp(_0x2c28ca){return ln(Sp,_0x2c28ca['config']['apiKey'],_0x2c28ca['name']);}async function Np(_0x150c52,_0x1de829,_0x55b44a=!0x1){if($(_0x150c52['app']))return Promise['reject'](re(_0x150c52));const _0x124f65=Ke(_0x150c52),_0x31813a=Ep(_0x124f65,_0x1de829),_0x3dc7fe=await new bp(_0x124f65,_0x31813a,_0x55b44a)['execute']();return _0x3dc7fe&&!_0x55b44a&&(delete _0x3dc7fe['user']['_redirectEventId'],await _0x124f65['_persistUserIfCurrent'](_0x3dc7fe['user']),await _0x124f65['_setRedirectUser'](null,_0x1de829)),_0x3dc7fe;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x196d71){this['auth']=_0x196d71,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x59c068){this['consumers']['add'](_0x59c068),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x59c068)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x59c068),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x4068bf){this['consumers']['delete'](_0x4068bf);}['onEvent'](_0x44c057){if(this['hasEventBeenHandled'](_0x44c057))return!0x1;let _0x5ed678=!0x1;return this['consumers']['forEach'](_0xc7111c=>{this['isEventForConsumer'](_0x44c057,_0xc7111c)&&(_0x5ed678=!0x0,this['sendToConsumer'](_0x44c057,_0xc7111c),this['saveEventToCache'](_0x44c057));}),this['hasHandledPotentialRedirect']||!Mp(_0x44c057)||(this['hasHandledPotentialRedirect']=!0x0,_0x5ed678||(this['queuedRedirectEvent']=_0x44c057,_0x5ed678=!0x0)),_0x5ed678;}['sendToConsumer'](_0x3bbfb3,_0x490cec){var _0x32920c;if(_0x3bbfb3['error']&&!Za(_0x3bbfb3)){const _0xa708ca=((_0x32920c=_0x3bbfb3['error']['code'])==null?void 0x0:_0x32920c['split']('auth/')[0x1])||'internal-error';_0x490cec['onError'](X(this['auth'],_0xa708ca));}else _0x490cec['onAuthEvent'](_0x3bbfb3);}['isEventForConsumer'](_0x34c9c9,_0x18d9c6){const _0xa7d501=_0x18d9c6['eventId']===null||!!_0x34c9c9['eventId']&&_0x34c9c9['eventId']===_0x18d9c6['eventId'];return _0x18d9c6['filter']['includes'](_0x34c9c9['type'])&&_0xa7d501;}['hasEventBeenHandled'](_0x392360){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x392360));}['saveEventToCache'](_0x1d7c20){this['cachedEventUids']['add'](Mr(_0x1d7c20)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x37fdd7){return[_0x37fdd7['type'],_0x37fdd7['eventId'],_0x37fdd7['sessionId'],_0x37fdd7['tenantId']]['filter'](_0x32a947=>_0x32a947)['join']('-');}function Za({type:_0x121e57,error:_0x2d6c1b}){return _0x121e57==='unknown'&&(_0x2d6c1b==null?void 0x0:_0x2d6c1b['code'])==='auth/no-auth-event';}function Mp(_0x1ea996){switch(_0x1ea996['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x1ea996);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x57598e,_0x431095={}){return Pe(_0x57598e,'GET','/v1/projects',_0x431095);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x2ad8a0){if(_0x2ad8a0['config']['emulator'])return;const {authorizedDomains:_0x391e02}=await Lp(_0x2ad8a0);for(const _0x37f610 of _0x391e02)try{if(Wp(_0x37f610))return;}catch{}Y(_0x2ad8a0,'unauthorized-domain');}function Wp(_0x3268b3){const _0x4c8231=Mi(),{protocol:_0x2d48b0,hostname:_0x218673}=new URL(_0x4c8231);if(_0x3268b3['startsWith']('chrome-extension://')){const _0xc0bc91=new URL(_0x3268b3);return _0xc0bc91['hostname']===''&&_0x218673===''?_0x2d48b0==='chrome-extension:'&&_0x3268b3['replace']('chrome-extension://','')===_0x4c8231['replace']('chrome-extension://',''):_0x2d48b0==='chrome-extension:'&&_0xc0bc91['hostname']===_0x218673;}if(!Fp['test'](_0x2d48b0))return!0x1;if(xp['test'](_0x3268b3))return _0x218673===_0x3268b3;const _0x5b165e=_0x3268b3['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5b165e+'|'+_0x5b165e+')$','i')['test'](_0x218673);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x532475=Z()['___jsl'];if(_0x532475!=null&&_0x532475['H']){for(const _0x4194ea of Object['keys'](_0x532475['H']))if(_0x532475['H'][_0x4194ea]['r']=_0x532475['H'][_0x4194ea]['r']||[],_0x532475['H'][_0x4194ea]['L']=_0x532475['H'][_0x4194ea]['L']||[],_0x532475['H'][_0x4194ea]['r']=[..._0x532475['H'][_0x4194ea]['L']],_0x532475['CP']){for(let _0xc73333=0x0;_0xc73333<_0x532475['CP']['length'];_0xc73333++)_0x532475['CP'][_0xc73333]=null;}}}function Vp(_0xb1bbc4){return new Promise((_0x589743,_0x1f429e)=>{var _0x3248e3,_0x572f69,_0x40d3f9;function _0xc19ea1(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x589743(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x1f429e(X(_0xb1bbc4,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x572f69=(_0x3248e3=Z()['gapi'])==null?void 0x0:_0x3248e3['iframes'])!=null&&_0x572f69['Iframe'])_0x589743(gapi['iframes']['getContext']());else{if((_0x40d3f9=Z()['gapi'])!=null&&_0x40d3f9['load'])_0xc19ea1();else{const _0x28dacf=Ff('iframefcb');return Z()[_0x28dacf]=()=>{gapi['load']?_0xc19ea1():_0x1f429e(X(_0xb1bbc4,'network-request-failed'));},xa(xf()+'?onload='+_0x28dacf)['catch'](_0x28fcf7=>_0x1f429e(_0x28fcf7));}}})['catch'](_0x2920f2=>{throw un=null,_0x2920f2;});}let un=null;function Hp(_0x486495){return un=un||Vp(_0x486495),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0xb42e03){const _0xe2e9b8=_0xb42e03['config'];m(_0xe2e9b8['authDomain'],_0xb42e03,'auth-domain-config-required');const _0x4a21d1=_0xe2e9b8['emulator']?Cs(_0xe2e9b8,qp):'https://'+_0xb42e03['config']['authDomain']+'/'+Gp,_0x2aeff8={'apiKey':_0xe2e9b8['apiKey'],'appName':_0xb42e03['name'],'v':dt},_0x33dbbf=jp['get'](_0xb42e03['config']['apiHost']);_0x33dbbf&&(_0x2aeff8['eid']=_0x33dbbf);const _0x2dff21=_0xb42e03['_getFrameworks']();return _0x2dff21['length']&&(_0x2aeff8['fw']=_0x2dff21['join'](',')),_0x4a21d1+'?'+ut(_0x2aeff8)['slice'](0x1);}async function Yp(_0xb2f986){const _0x151031=await Hp(_0xb2f986),_0xcb37f3=Z()['gapi'];return m(_0xcb37f3,_0xb2f986,'internal-error'),_0x151031['open']({'where':document['body'],'url':Kp(_0xb2f986),'messageHandlersFilter':_0xcb37f3['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x4412ad=>new Promise(async(_0x523347,_0x373a7f)=>{await _0x4412ad['restyle']({'setHideOnLeave':!0x1});const _0x4bd5bc=X(_0xb2f986,'network-request-failed'),_0x14fab2=Z()['setTimeout'](()=>{_0x373a7f(_0x4bd5bc);},$p['get']());function _0x3f8e9e(){Z()['clearTimeout'](_0x14fab2),_0x523347(_0x4412ad);}_0x4412ad['ping'](_0x3f8e9e)['then'](_0x3f8e9e,()=>{_0x373a7f(_0x4bd5bc);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x348fd2){this['window']=_0x348fd2,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x3f7d3c,_0x39b874,_0x15516c,_0x12c6cf=Jp,_0x2b2494=Xp){const _0x18f1cc=Math['max']((window['screen']['availHeight']-_0x2b2494)/0x2,0x0)['toString'](),_0x352f03=Math['max']((window['screen']['availWidth']-_0x12c6cf)/0x2,0x0)['toString']();let _0x39c175='';const _0x1b5154={...Qp,'width':_0x12c6cf['toString'](),'height':_0x2b2494['toString'](),'top':_0x18f1cc,'left':_0x352f03},_0x2633fa=W()['toLowerCase']();_0x15516c&&(_0x39c175=ka(_0x2633fa)?Zp:_0x15516c),Ra(_0x2633fa)&&(_0x39b874=_0x39b874||e_,_0x1b5154['scrollbars']='yes');const _0x4240e9=Object['entries'](_0x1b5154)['reduce']((_0x35efe5,[_0x35bfe9,_0x4e3a6b])=>''+_0x35efe5+_0x35bfe9+'='+_0x4e3a6b+',','');if(Rf(_0x2633fa)&&_0x39c175!=='_self')return n_(_0x39b874||'',_0x39c175),new xr(null);const _0x395c67=window['open'](_0x39b874||'',_0x39c175,_0x4240e9);m(_0x395c67,_0x3f7d3c,'popup-blocked');try{_0x395c67['focus']();}catch{}return new xr(_0x395c67);}function n_(_0x4fcfbe,_0x36a603){const _0x12e2b2=document['createElement']('a');_0x12e2b2['href']=_0x4fcfbe,_0x12e2b2['target']=_0x36a603;const _0x1bf2bc=document['createEvent']('MouseEvent');_0x1bf2bc['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x12e2b2['dispatchEvent'](_0x1bf2bc);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x5d64a0,_0xffdc5d,_0x19986a,_0xa4002,_0x456590,_0x3214e6){m(_0x5d64a0['config']['authDomain'],_0x5d64a0,'auth-domain-config-required'),m(_0x5d64a0['config']['apiKey'],_0x5d64a0,'invalid-api-key');const _0x22e467={'apiKey':_0x5d64a0['config']['apiKey'],'appName':_0x5d64a0['name'],'authType':_0x19986a,'redirectUrl':_0xa4002,'v':dt,'eventId':_0x456590};if(_0xffdc5d instanceof Wa){_0xffdc5d['setDefaultLanguage'](_0x5d64a0['languageCode']),_0x22e467['providerId']=_0xffdc5d['providerId']||'',pn(_0xffdc5d['getCustomParameters']())||(_0x22e467['customParameters']=JSON['stringify'](_0xffdc5d['getCustomParameters']()));for(const [_0x516b9f,_0x204589]of Object['entries']({}))_0x22e467[_0x516b9f]=_0x204589;}if(_0xffdc5d instanceof tn){const _0x4a07a0=_0xffdc5d['getScopes']()['filter'](_0x31d215=>_0x31d215!=='');_0x4a07a0['length']>0x0&&(_0x22e467['scopes']=_0x4a07a0['join'](','));}_0x5d64a0['tenantId']&&(_0x22e467['tid']=_0x5d64a0['tenantId']);const _0x533147=_0x22e467;for(const _0x51816e of Object['keys'](_0x533147))_0x533147[_0x51816e]===void 0x0&&delete _0x533147[_0x51816e];const _0x161d0b=await _0x5d64a0['_getAppCheckToken'](),_0x42909f=_0x161d0b?'#'+r_+'='+encodeURIComponent(_0x161d0b):'';return o_(_0x5d64a0)+'?'+ut(_0x533147)['slice'](0x1)+_0x42909f;}function o_({config:_0x11b47b}){return _0x11b47b['emulator']?Cs(_0x11b47b,s_):'https://'+_0x11b47b['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x395e3e,_0xe258ee,_0x3bb12c,_0x1547a0){var _0x6fd31c;ce((_0x6fd31c=this['eventManagers'][_0x395e3e['_key']()])==null?void 0x0:_0x6fd31c['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x176036=await Fr(_0x395e3e,_0xe258ee,_0x3bb12c,Mi(),_0x1547a0);return t_(_0x395e3e,_0x176036,As());}async['_openRedirect'](_0xeffcb8,_0x14e912,_0x3d9f70,_0xa25d91){await this['_originValidation'](_0xeffcb8);const _0x506718=await Fr(_0xeffcb8,_0x14e912,_0x3d9f70,Mi(),_0xa25d91);return hp(_0x506718),new Promise(()=>{});}['_initialize'](_0x2bc580){const _0x17c004=_0x2bc580['_key']();if(this['eventManagers'][_0x17c004]){const {manager:_0x6bcff1,promise:_0x3a215b}=this['eventManagers'][_0x17c004];return _0x6bcff1?Promise['resolve'](_0x6bcff1):(ce(_0x3a215b,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3a215b);}const _0x2a3dda=this['initAndGetManager'](_0x2bc580);return this['eventManagers'][_0x17c004]={'promise':_0x2a3dda},_0x2a3dda['catch'](()=>{delete this['eventManagers'][_0x17c004];}),_0x2a3dda;}async['initAndGetManager'](_0x140845){const _0x4356d6=await Yp(_0x140845),_0x19922d=new Dp(_0x140845);return _0x4356d6['register']('authEvent',_0x24fcfb=>(m(_0x24fcfb==null?void 0x0:_0x24fcfb['authEvent'],_0x140845,'invalid-auth-event'),{'status':_0x19922d['onEvent'](_0x24fcfb['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x140845['_key']()]={'manager':_0x19922d},this['iframes'][_0x140845['_key']()]=_0x4356d6,_0x19922d;}['_isIframeWebStorageSupported'](_0x52929e,_0x50dbae){this['iframes'][_0x52929e['_key']()]['send'](pi,{'type':pi},_0x3825c4=>{var _0x1e1c1a;const _0x3df6a2=(_0x1e1c1a=_0x3825c4==null?void 0x0:_0x3825c4[0x0])==null?void 0x0:_0x1e1c1a[pi];_0x3df6a2!==void 0x0&&_0x50dbae(!!_0x3df6a2),Y(_0x52929e,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3e0dfa){const _0x38e438=_0x3e0dfa['_key']();return this['originValidationPromises'][_0x38e438]||(this['originValidationPromises'][_0x38e438]=Up(_0x3e0dfa)),this['originValidationPromises'][_0x38e438];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x1d5657){this['auth']=_0x1d5657,this['internalListeners']=new Map();}['getUid'](){var _0x4abcca;return this['assertAuthConfigured'](),((_0x4abcca=this['auth']['currentUser'])==null?void 0x0:_0x4abcca['uid'])||null;}async['getToken'](_0xf58c26){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xf58c26)}:null;}['addAuthTokenListener'](_0x36cfc1){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x36cfc1))return;const _0x3c00cd=this['auth']['onIdTokenChanged'](_0x172681=>{_0x36cfc1((_0x172681==null?void 0x0:_0x172681['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x36cfc1,_0x3c00cd),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3fdde5){this['assertAuthConfigured']();const _0x5bb6dc=this['internalListeners']['get'](_0x3fdde5);_0x5bb6dc&&(this['internalListeners']['delete'](_0x3fdde5),_0x5bb6dc(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x317312){switch(_0x317312){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x28f35e){st(new Fe('auth',(_0x22d046,{options:_0x4444c3})=>{const _0x378dce=_0x22d046['getProvider']('app')['getImmediate'](),_0x471c0f=_0x22d046['getProvider']('heartbeat'),_0x2edc6e=_0x22d046['getProvider']('app-check-internal'),{apiKey:_0xeee28a,authDomain:_0x4aa9f8}=_0x378dce['options'];m(_0xeee28a&&!_0xeee28a['includes'](':'),'invalid-api-key',{'appName':_0x378dce['name']});const _0x3fb953={'apiKey':_0xeee28a,'authDomain':_0x4aa9f8,'clientPlatform':_0x28f35e,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x28f35e)},_0x2a40ca=new Df(_0x378dce,_0x471c0f,_0x2edc6e,_0x3fb953);return Hf(_0x2a40ca,_0x4444c3),_0x2a40ca;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x12b173,_0x5107d8,_0x17f332)=>{_0x12b173['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x57042c=>{const _0x449ec8=Ke(_0x57042c['getProvider']('auth')['getImmediate']());return(_0x57510b=>new l_(_0x57510b))(_0x449ec8);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x28f35e)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x1f2034=>async _0x4671c7=>{const _0x333170=_0x4671c7&&await _0x4671c7['getIdTokenResult'](),_0x14af01=_0x333170&&(new Date()['getTime']()-Date['parse'](_0x333170['issuedAtTime']))/0x3e8;if(_0x14af01&&_0x14af01>f_)return;const _0x445aee=_0x333170==null?void 0x0:_0x333170['token'];Br!==_0x445aee&&(Br=_0x445aee,await fetch(_0x1f2034,{'method':_0x445aee?'POST':'DELETE','headers':_0x445aee?{'Authorization':'Bearer\x20'+_0x445aee}:{}}));};function B_(_0x53a8d3=Zr()){const _0x4ba13c=Hi(_0x53a8d3,'auth');if(_0x4ba13c['isInitialized']())return _0x4ba13c['getImmediate']();const _0x17197b=Vf(_0x53a8d3,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x2827b6=jr('authTokenSyncURL');if(_0x2827b6&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x38af99=new URL(_0x2827b6,location['origin']);if(location['origin']===_0x38af99['origin']){const _0x5acb2f=p_(_0x38af99['toString']());sp(_0x17197b,_0x5acb2f,()=>_0x5acb2f(_0x17197b['currentUser'])),ip(_0x17197b,_0x2f9e53=>_0x5acb2f(_0x2f9e53));}}const _0x3a0d34=qr('auth');return _0x3a0d34&&$f(_0x17197b,'http://'+_0x3a0d34),_0x17197b;}function __(){var _0x1094db;return((_0x1094db=document['getElementsByTagName']('head'))==null?void 0x0:_0x1094db[0x0])??document;}Mf({'loadJS'(_0x509b25){return new Promise((_0xa3d83f,_0x472698)=>{const _0x1f06c6=document['createElement']('script');_0x1f06c6['setAttribute']('src',_0x509b25),_0x1f06c6['onload']=_0xa3d83f,_0x1f06c6['onerror']=_0x595894=>{const _0x2286bd=X('internal-error');_0x2286bd['customData']=_0x595894,_0x472698(_0x2286bd);},_0x1f06c6['type']='text/javascript',_0x1f06c6['charset']='UTF-8',__()['appendChild'](_0x1f06c6);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};