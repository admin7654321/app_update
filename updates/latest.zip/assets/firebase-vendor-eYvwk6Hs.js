const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4f0d0a,_0x33c1a0){if(!_0x4f0d0a)throw ht(_0x33c1a0);},ht=function(_0x1df16b){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1df16b);},Hr=function(_0x5c652c){const _0x4a32e2=[];let _0x48de55=0x0;for(let _0x20262f=0x0;_0x20262f<_0x5c652c['length'];_0x20262f++){let _0x2a3b74=_0x5c652c['charCodeAt'](_0x20262f);_0x2a3b74<0x80?_0x4a32e2[_0x48de55++]=_0x2a3b74:_0x2a3b74<0x800?(_0x4a32e2[_0x48de55++]=_0x2a3b74>>0x6|0xc0,_0x4a32e2[_0x48de55++]=_0x2a3b74&0x3f|0x80):(_0x2a3b74&0xfc00)===0xd800&&_0x20262f+0x1<_0x5c652c['length']&&(_0x5c652c['charCodeAt'](_0x20262f+0x1)&0xfc00)===0xdc00?(_0x2a3b74=0x10000+((_0x2a3b74&0x3ff)<<0xa)+(_0x5c652c['charCodeAt'](++_0x20262f)&0x3ff),_0x4a32e2[_0x48de55++]=_0x2a3b74>>0x12|0xf0,_0x4a32e2[_0x48de55++]=_0x2a3b74>>0xc&0x3f|0x80,_0x4a32e2[_0x48de55++]=_0x2a3b74>>0x6&0x3f|0x80,_0x4a32e2[_0x48de55++]=_0x2a3b74&0x3f|0x80):(_0x4a32e2[_0x48de55++]=_0x2a3b74>>0xc|0xe0,_0x4a32e2[_0x48de55++]=_0x2a3b74>>0x6&0x3f|0x80,_0x4a32e2[_0x48de55++]=_0x2a3b74&0x3f|0x80);}return _0x4a32e2;},nc=function(_0x5cca18){const _0x34cb52=[];let _0x19ae49=0x0,_0x5d817e=0x0;for(;_0x19ae49<_0x5cca18['length'];){const _0x1cea0d=_0x5cca18[_0x19ae49++];if(_0x1cea0d<0x80)_0x34cb52[_0x5d817e++]=String['fromCharCode'](_0x1cea0d);else{if(_0x1cea0d>0xbf&&_0x1cea0d<0xe0){const _0xc348bc=_0x5cca18[_0x19ae49++];_0x34cb52[_0x5d817e++]=String['fromCharCode']((_0x1cea0d&0x1f)<<0x6|_0xc348bc&0x3f);}else{if(_0x1cea0d>0xef&&_0x1cea0d<0x16d){const _0x380607=_0x5cca18[_0x19ae49++],_0x3e454c=_0x5cca18[_0x19ae49++],_0xabe54e=_0x5cca18[_0x19ae49++],_0xad7ef7=((_0x1cea0d&0x7)<<0x12|(_0x380607&0x3f)<<0xc|(_0x3e454c&0x3f)<<0x6|_0xabe54e&0x3f)-0x10000;_0x34cb52[_0x5d817e++]=String['fromCharCode'](0xd800+(_0xad7ef7>>0xa)),_0x34cb52[_0x5d817e++]=String['fromCharCode'](0xdc00+(_0xad7ef7&0x3ff));}else{const _0x136c8d=_0x5cca18[_0x19ae49++],_0x5b5986=_0x5cca18[_0x19ae49++];_0x34cb52[_0x5d817e++]=String['fromCharCode']((_0x1cea0d&0xf)<<0xc|(_0x136c8d&0x3f)<<0x6|_0x5b5986&0x3f);}}}}return _0x34cb52['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2a9a47,_0x29fc38){if(!Array['isArray'](_0x2a9a47))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1877a4=_0x29fc38?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3ff4be=[];for(let _0x144f4a=0x0;_0x144f4a<_0x2a9a47['length'];_0x144f4a+=0x3){const _0x252a53=_0x2a9a47[_0x144f4a],_0x376036=_0x144f4a+0x1<_0x2a9a47['length'],_0x3a54d0=_0x376036?_0x2a9a47[_0x144f4a+0x1]:0x0,_0x52f8db=_0x144f4a+0x2<_0x2a9a47['length'],_0x402356=_0x52f8db?_0x2a9a47[_0x144f4a+0x2]:0x0,_0x3ae891=_0x252a53>>0x2,_0x4ceb37=(_0x252a53&0x3)<<0x4|_0x3a54d0>>0x4;let _0x39aec8=(_0x3a54d0&0xf)<<0x2|_0x402356>>0x6,_0x507667=_0x402356&0x3f;_0x52f8db||(_0x507667=0x40,_0x376036||(_0x39aec8=0x40)),_0x3ff4be['push'](_0x1877a4[_0x3ae891],_0x1877a4[_0x4ceb37],_0x1877a4[_0x39aec8],_0x1877a4[_0x507667]);}return _0x3ff4be['join']('');},'encodeString'(_0x15cdb9,_0xba10d4){return this['HAS_NATIVE_SUPPORT']&&!_0xba10d4?btoa(_0x15cdb9):this['encodeByteArray'](Hr(_0x15cdb9),_0xba10d4);},'decodeString'(_0x2015a6,_0x562432){return this['HAS_NATIVE_SUPPORT']&&!_0x562432?atob(_0x2015a6):nc(this['decodeStringToByteArray'](_0x2015a6,_0x562432));},'decodeStringToByteArray'(_0x50b212,_0x38165e){this['init_']();const _0x54444e=_0x38165e?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x45661c=[];for(let _0x36fd3d=0x0;_0x36fd3d<_0x50b212['length'];){const _0x1b3f11=_0x54444e[_0x50b212['charAt'](_0x36fd3d++)],_0x152e8f=_0x36fd3d<_0x50b212['length']?_0x54444e[_0x50b212['charAt'](_0x36fd3d)]:0x0;++_0x36fd3d;const _0x2092ef=_0x36fd3d<_0x50b212['length']?_0x54444e[_0x50b212['charAt'](_0x36fd3d)]:0x40;++_0x36fd3d;const _0x48259d=_0x36fd3d<_0x50b212['length']?_0x54444e[_0x50b212['charAt'](_0x36fd3d)]:0x40;if(++_0x36fd3d,_0x1b3f11==null||_0x152e8f==null||_0x2092ef==null||_0x48259d==null)throw new ic();const _0x3e64c2=_0x1b3f11<<0x2|_0x152e8f>>0x4;if(_0x45661c['push'](_0x3e64c2),_0x2092ef!==0x40){const _0x420d24=_0x152e8f<<0x4&0xf0|_0x2092ef>>0x2;if(_0x45661c['push'](_0x420d24),_0x48259d!==0x40){const _0xe44f45=_0x2092ef<<0x6&0xc0|_0x48259d;_0x45661c['push'](_0xe44f45);}}}return _0x45661c;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xa7f64d=0x0;_0xa7f64d<this['ENCODED_VALS']['length'];_0xa7f64d++)this['byteToCharMap_'][_0xa7f64d]=this['ENCODED_VALS']['charAt'](_0xa7f64d),this['charToByteMap_'][this['byteToCharMap_'][_0xa7f64d]]=_0xa7f64d,this['byteToCharMapWebSafe_'][_0xa7f64d]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xa7f64d),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xa7f64d]]=_0xa7f64d,_0xa7f64d>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xa7f64d)]=_0xa7f64d,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xa7f64d)]=_0xa7f64d);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x8d5730){const _0x49fe51=Hr(_0x8d5730);return Fi['encodeByteArray'](_0x49fe51,!0x0);},dn=function(_0x1acf82){return $r(_0x1acf82)['replace'](/\./g,'');},fn=function(_0x57dddb){try{return Fi['decodeString'](_0x57dddb,!0x0);}catch(_0x2d1d64){console['error']('base64Decode\x20failed:\x20',_0x2d1d64);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0xe882e){return Gr(void 0x0,_0xe882e);}function Gr(_0x5534fa,_0x1b8c66){if(!(_0x1b8c66 instanceof Object))return _0x1b8c66;switch(_0x1b8c66['constructor']){case Date:const _0x2f697b=_0x1b8c66;return new Date(_0x2f697b['getTime']());case Object:_0x5534fa===void 0x0&&(_0x5534fa={});break;case Array:_0x5534fa=[];break;default:return _0x1b8c66;}for(const _0x4d07b0 in _0x1b8c66)!_0x1b8c66['hasOwnProperty'](_0x4d07b0)||!rc(_0x4d07b0)||(_0x5534fa[_0x4d07b0]=Gr(_0x5534fa[_0x4d07b0],_0x1b8c66[_0x4d07b0]));return _0x5534fa;}function rc(_0x3b08c1){return _0x3b08c1!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x41d915=Ps['__FIREBASE_DEFAULTS__'];if(_0x41d915)return JSON['parse'](_0x41d915);},lc=()=>{if(typeof document>'u')return;let _0x3683fb;try{_0x3683fb=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5b26f6=_0x3683fb&&fn(_0x3683fb[0x1]);return _0x5b26f6&&JSON['parse'](_0x5b26f6);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x4824e9){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4824e9);return;}},qr=_0x299097=>{var _0x335f17,_0xc9e057;return(_0xc9e057=(_0x335f17=Ui())==null?void 0x0:_0x335f17['emulatorHosts'])==null?void 0x0:_0xc9e057[_0x299097];},hc=_0x263a7c=>{const _0x5c3916=qr(_0x263a7c);if(!_0x5c3916)return;const _0x5eecf8=_0x5c3916['lastIndexOf'](':');if(_0x5eecf8<=0x0||_0x5eecf8+0x1===_0x5c3916['length'])throw new Error('Invalid\x20host\x20'+_0x5c3916+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5d47db=parseInt(_0x5c3916['substring'](_0x5eecf8+0x1),0xa);return _0x5c3916[0x0]==='['?[_0x5c3916['substring'](0x1,_0x5eecf8-0x1),_0x5d47db]:[_0x5c3916['substring'](0x0,_0x5eecf8),_0x5d47db];},zr=()=>{var _0x57769c;return(_0x57769c=Ui())==null?void 0x0:_0x57769c['config'];},jr=_0x45ec37=>{var _0x1ee308;return(_0x1ee308=Ui())==null?void 0x0:_0x1ee308['_'+_0x45ec37];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3587d5,_0x1d85be)=>{this['resolve']=_0x3587d5,this['reject']=_0x1d85be;});}['wrapCallback'](_0x1a5a8b){return(_0x203115,_0x1b019b)=>{_0x203115?this['reject'](_0x203115):this['resolve'](_0x1b019b),typeof _0x1a5a8b=='function'&&(this['promise']['catch'](()=>{}),_0x1a5a8b['length']===0x1?_0x1a5a8b(_0x203115):_0x1a5a8b(_0x203115,_0x1b019b));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x4fafed,_0x19e33a){if(_0x4fafed['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x4eb9e2={'alg':'none','type':'JWT'},_0x222212=_0x19e33a||'demo-project',_0x121cbb=_0x4fafed['iat']||0x0,_0x15d715=_0x4fafed['sub']||_0x4fafed['user_id'];if(!_0x15d715)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x4d182b={'iss':'https://securetoken.google.com/'+_0x222212,'aud':_0x222212,'iat':_0x121cbb,'exp':_0x121cbb+0xe10,'auth_time':_0x121cbb,'sub':_0x15d715,'user_id':_0x15d715,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4fafed};return[dn(JSON['stringify'](_0x4eb9e2)),dn(JSON['stringify'](_0x4d182b)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x4a26db=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4a26db=='object'&&_0x4a26db['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x3c0040=W();return _0x3c0040['indexOf']('MSIE\x20')>=0x0||_0x3c0040['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x446d7c,_0x440ffd)=>{try{let _0x219535=!0x0;const _0x5d792c='validate-browser-context-for-indexeddb-analytics-module',_0x4e1369=self['indexedDB']['open'](_0x5d792c);_0x4e1369['onsuccess']=()=>{_0x4e1369['result']['close'](),_0x219535||self['indexedDB']['deleteDatabase'](_0x5d792c),_0x446d7c(!0x0);},_0x4e1369['onupgradeneeded']=()=>{_0x219535=!0x1;},_0x4e1369['onerror']=()=>{var _0x5bd1ec;_0x440ffd(((_0x5bd1ec=_0x4e1369['error'])==null?void 0x0:_0x5bd1ec['message'])||'');};}catch(_0x2ad163){_0x440ffd(_0x2ad163);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x222de1,_0x161fd8,_0x543125){super(_0x161fd8),this['code']=_0x222de1,this['customData']=_0x543125,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x4f6c2a,_0x5e9cbe,_0x525c8b){this['service']=_0x4f6c2a,this['serviceName']=_0x5e9cbe,this['errors']=_0x525c8b;}['create'](_0xf3e11d,..._0x586532){const _0x371a42=_0x586532[0x0]||{},_0x4895f8=this['service']+'/'+_0xf3e11d,_0x4219b4=this['errors'][_0xf3e11d],_0x1da1dc=_0x4219b4?vc(_0x4219b4,_0x371a42):'Error',_0x47fcd4=this['serviceName']+':\x20'+_0x1da1dc+'\x20('+_0x4895f8+').';return new Re(_0x4895f8,_0x47fcd4,_0x371a42);}}function vc(_0x59ea71,_0x5a3f7d){return _0x59ea71['replace'](Ec,(_0x436eb8,_0x30c96c)=>{const _0x3c63ce=_0x5a3f7d[_0x30c96c];return _0x3c63ce!=null?String(_0x3c63ce):'<'+_0x30c96c+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x522e76){return JSON['parse'](_0x522e76);}function O(_0x2b49a3){return JSON['stringify'](_0x2b49a3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x3ca64d){let _0x3f49ba={},_0x4446ab={},_0x2ac37f={},_0x228ebc='';try{const _0x2b70df=_0x3ca64d['split']('.');_0x3f49ba=Nt(fn(_0x2b70df[0x0])||''),_0x4446ab=Nt(fn(_0x2b70df[0x1])||''),_0x228ebc=_0x2b70df[0x2],_0x2ac37f=_0x4446ab['d']||{},delete _0x4446ab['d'];}catch{}return{'header':_0x3f49ba,'claims':_0x4446ab,'data':_0x2ac37f,'signature':_0x228ebc};},Ic=function(_0x497833){const _0x17d525=Yr(_0x497833),_0x8d971=_0x17d525['claims'];return!!_0x8d971&&typeof _0x8d971=='object'&&_0x8d971['hasOwnProperty']('iat');},wc=function(_0x4cf82f){const _0x5b968e=Yr(_0x4cf82f)['claims'];return typeof _0x5b968e=='object'&&_0x5b968e['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x2209b0,_0x3d51bd){return Object['prototype']['hasOwnProperty']['call'](_0x2209b0,_0x3d51bd);}function Le(_0x565c98,_0x3c2d2e){if(Object['prototype']['hasOwnProperty']['call'](_0x565c98,_0x3c2d2e))return _0x565c98[_0x3c2d2e];}function pn(_0x4ae76e){for(const _0x177e66 in _0x4ae76e)if(Object['prototype']['hasOwnProperty']['call'](_0x4ae76e,_0x177e66))return!0x1;return!0x0;}function _n(_0x54d317,_0x5cbd71,_0x548398){const _0x3d7dc8={};for(const _0x108edf in _0x54d317)Object['prototype']['hasOwnProperty']['call'](_0x54d317,_0x108edf)&&(_0x3d7dc8[_0x108edf]=_0x5cbd71['call'](_0x548398,_0x54d317[_0x108edf],_0x108edf,_0x54d317));return _0x3d7dc8;}function xe(_0xe5d74d,_0x4680b6){if(_0xe5d74d===_0x4680b6)return!0x0;const _0x35ee44=Object['keys'](_0xe5d74d),_0x460bd4=Object['keys'](_0x4680b6);for(const _0x7d7941 of _0x35ee44){if(!_0x460bd4['includes'](_0x7d7941))return!0x1;const _0x3e9d00=_0xe5d74d[_0x7d7941],_0x2b1964=_0x4680b6[_0x7d7941];if(Ns(_0x3e9d00)&&Ns(_0x2b1964)){if(!xe(_0x3e9d00,_0x2b1964))return!0x1;}else{if(_0x3e9d00!==_0x2b1964)return!0x1;}}for(const _0x2cc10c of _0x460bd4)if(!_0x35ee44['includes'](_0x2cc10c))return!0x1;return!0x0;}function Ns(_0x5bf995){return _0x5bf995!==null&&typeof _0x5bf995=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x3d2ce7){const _0x371677=[];for(const [_0x528f7b,_0x454925]of Object['entries'](_0x3d2ce7))Array['isArray'](_0x454925)?_0x454925['forEach'](_0x3f27c3=>{_0x371677['push'](encodeURIComponent(_0x528f7b)+'='+encodeURIComponent(_0x3f27c3));}):_0x371677['push'](encodeURIComponent(_0x528f7b)+'='+encodeURIComponent(_0x454925));return _0x371677['length']?'&'+_0x371677['join']('&'):'';}function Ct(_0x3be0ca){const _0x4e88ff={};return _0x3be0ca['replace'](/^\?/,'')['split']('&')['forEach'](_0x382c17=>{if(_0x382c17){const [_0x2e1407,_0x214a51]=_0x382c17['split']('=');_0x4e88ff[decodeURIComponent(_0x2e1407)]=decodeURIComponent(_0x214a51);}}),_0x4e88ff;}function Tt(_0x2811cb){const _0x509aa7=_0x2811cb['indexOf']('?');if(!_0x509aa7)return'';const _0x413223=_0x2811cb['indexOf']('#',_0x509aa7);return _0x2811cb['substring'](_0x509aa7,_0x413223>0x0?_0x413223:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5bf009=0x1;_0x5bf009<this['blockSize'];++_0x5bf009)this['pad_'][_0x5bf009]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x13b669,_0x3132c4){_0x3132c4||(_0x3132c4=0x0);const _0xe8c708=this['W_'];if(typeof _0x13b669=='string'){for(let _0x3fd9b5=0x0;_0x3fd9b5<0x10;_0x3fd9b5++)_0xe8c708[_0x3fd9b5]=_0x13b669['charCodeAt'](_0x3132c4)<<0x18|_0x13b669['charCodeAt'](_0x3132c4+0x1)<<0x10|_0x13b669['charCodeAt'](_0x3132c4+0x2)<<0x8|_0x13b669['charCodeAt'](_0x3132c4+0x3),_0x3132c4+=0x4;}else{for(let _0x43af9b=0x0;_0x43af9b<0x10;_0x43af9b++)_0xe8c708[_0x43af9b]=_0x13b669[_0x3132c4]<<0x18|_0x13b669[_0x3132c4+0x1]<<0x10|_0x13b669[_0x3132c4+0x2]<<0x8|_0x13b669[_0x3132c4+0x3],_0x3132c4+=0x4;}for(let _0x2d7892=0x10;_0x2d7892<0x50;_0x2d7892++){const _0x3406f8=_0xe8c708[_0x2d7892-0x3]^_0xe8c708[_0x2d7892-0x8]^_0xe8c708[_0x2d7892-0xe]^_0xe8c708[_0x2d7892-0x10];_0xe8c708[_0x2d7892]=(_0x3406f8<<0x1|_0x3406f8>>>0x1f)&0xffffffff;}let _0x3a25b7=this['chain_'][0x0],_0x5a45c5=this['chain_'][0x1],_0x58cdf8=this['chain_'][0x2],_0x2d9724=this['chain_'][0x3],_0x495045=this['chain_'][0x4],_0x3d7570,_0x11ad55;for(let _0x1a1980=0x0;_0x1a1980<0x50;_0x1a1980++){_0x1a1980<0x28?_0x1a1980<0x14?(_0x3d7570=_0x2d9724^_0x5a45c5&(_0x58cdf8^_0x2d9724),_0x11ad55=0x5a827999):(_0x3d7570=_0x5a45c5^_0x58cdf8^_0x2d9724,_0x11ad55=0x6ed9eba1):_0x1a1980<0x3c?(_0x3d7570=_0x5a45c5&_0x58cdf8|_0x2d9724&(_0x5a45c5|_0x58cdf8),_0x11ad55=0x8f1bbcdc):(_0x3d7570=_0x5a45c5^_0x58cdf8^_0x2d9724,_0x11ad55=0xca62c1d6);const _0x111719=(_0x3a25b7<<0x5|_0x3a25b7>>>0x1b)+_0x3d7570+_0x495045+_0x11ad55+_0xe8c708[_0x1a1980]&0xffffffff;_0x495045=_0x2d9724,_0x2d9724=_0x58cdf8,_0x58cdf8=(_0x5a45c5<<0x1e|_0x5a45c5>>>0x2)&0xffffffff,_0x5a45c5=_0x3a25b7,_0x3a25b7=_0x111719;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3a25b7&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5a45c5&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x58cdf8&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2d9724&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x495045&0xffffffff;}['update'](_0x4a5f7c,_0x59892b){if(_0x4a5f7c==null)return;_0x59892b===void 0x0&&(_0x59892b=_0x4a5f7c['length']);const _0x25f546=_0x59892b-this['blockSize'];let _0x24e2ac=0x0;const _0x34d6aa=this['buf_'];let _0x2fcf2d=this['inbuf_'];for(;_0x24e2ac<_0x59892b;){if(_0x2fcf2d===0x0){for(;_0x24e2ac<=_0x25f546;)this['compress_'](_0x4a5f7c,_0x24e2ac),_0x24e2ac+=this['blockSize'];}if(typeof _0x4a5f7c=='string'){for(;_0x24e2ac<_0x59892b;)if(_0x34d6aa[_0x2fcf2d]=_0x4a5f7c['charCodeAt'](_0x24e2ac),++_0x2fcf2d,++_0x24e2ac,_0x2fcf2d===this['blockSize']){this['compress_'](_0x34d6aa),_0x2fcf2d=0x0;break;}}else{for(;_0x24e2ac<_0x59892b;)if(_0x34d6aa[_0x2fcf2d]=_0x4a5f7c[_0x24e2ac],++_0x2fcf2d,++_0x24e2ac,_0x2fcf2d===this['blockSize']){this['compress_'](_0x34d6aa),_0x2fcf2d=0x0;break;}}}this['inbuf_']=_0x2fcf2d,this['total_']+=_0x59892b;}['digest'](){const _0x5929b4=[];let _0xa781e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x22d132=this['blockSize']-0x1;_0x22d132>=0x38;_0x22d132--)this['buf_'][_0x22d132]=_0xa781e&0xff,_0xa781e/=0x100;this['compress_'](this['buf_']);let _0x5ddace=0x0;for(let _0x19505b=0x0;_0x19505b<0x5;_0x19505b++)for(let _0x538de1=0x18;_0x538de1>=0x0;_0x538de1-=0x8)_0x5929b4[_0x5ddace]=this['chain_'][_0x19505b]>>_0x538de1&0xff,++_0x5ddace;return _0x5929b4;}}function Tc(_0x2b03c4,_0x5f0b91){const _0x25932e=new Sc(_0x2b03c4,_0x5f0b91);return _0x25932e['subscribe']['bind'](_0x25932e);}class Sc{constructor(_0x547da1,_0x468379){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x468379,this['task']['then'](()=>{_0x547da1(this);})['catch'](_0x414354=>{this['error'](_0x414354);});}['next'](_0x43f56b){this['forEachObserver'](_0x347c5c=>{_0x347c5c['next'](_0x43f56b);});}['error'](_0x5a735a){this['forEachObserver'](_0x3b3c39=>{_0x3b3c39['error'](_0x5a735a);}),this['close'](_0x5a735a);}['complete'](){this['forEachObserver'](_0x3ddc96=>{_0x3ddc96['complete']();}),this['close']();}['subscribe'](_0x4518d2,_0x3d65b8,_0x3eace6){let _0x1893aa;if(_0x4518d2===void 0x0&&_0x3d65b8===void 0x0&&_0x3eace6===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x4518d2,['next','error','complete'])?_0x1893aa=_0x4518d2:_0x1893aa={'next':_0x4518d2,'error':_0x3d65b8,'complete':_0x3eace6},_0x1893aa['next']===void 0x0&&(_0x1893aa['next']=ti),_0x1893aa['error']===void 0x0&&(_0x1893aa['error']=ti),_0x1893aa['complete']===void 0x0&&(_0x1893aa['complete']=ti);const _0x1dfbff=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x1893aa['error'](this['finalError']):_0x1893aa['complete']();}catch{}}),this['observers']['push'](_0x1893aa),_0x1dfbff;}['unsubscribeOne'](_0x34bd91){this['observers']===void 0x0||this['observers'][_0x34bd91]===void 0x0||(delete this['observers'][_0x34bd91],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x569100){if(!this['finalized']){for(let _0x57fc72=0x0;_0x57fc72<this['observers']['length'];_0x57fc72++)this['sendOne'](_0x57fc72,_0x569100);}}['sendOne'](_0x51d617,_0x21ec5a){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x51d617]!==void 0x0)try{_0x21ec5a(this['observers'][_0x51d617]);}catch(_0x2d9325){typeof console<'u'&&console['error']&&console['error'](_0x2d9325);}});}['close'](_0x2acb2f){this['finalized']||(this['finalized']=!0x0,_0x2acb2f!==void 0x0&&(this['finalError']=_0x2acb2f),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x3cf4c4,_0x41b9f6){if(typeof _0x3cf4c4!='object'||_0x3cf4c4===null)return!0x1;for(const _0x377e2d of _0x41b9f6)if(_0x377e2d in _0x3cf4c4&&typeof _0x3cf4c4[_0x377e2d]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x1e0937,_0x25c7cd){return _0x1e0937+'\x20failed:\x20'+_0x25c7cd+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4ddd69){const _0x31403f=[];let _0x1f13f3=0x0;for(let _0x411145=0x0;_0x411145<_0x4ddd69['length'];_0x411145++){let _0x36ff8d=_0x4ddd69['charCodeAt'](_0x411145);if(_0x36ff8d>=0xd800&&_0x36ff8d<=0xdbff){const _0x127624=_0x36ff8d-0xd800;_0x411145++,f(_0x411145<_0x4ddd69['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5c081b=_0x4ddd69['charCodeAt'](_0x411145)-0xdc00;_0x36ff8d=0x10000+(_0x127624<<0xa)+_0x5c081b;}_0x36ff8d<0x80?_0x31403f[_0x1f13f3++]=_0x36ff8d:_0x36ff8d<0x800?(_0x31403f[_0x1f13f3++]=_0x36ff8d>>0x6|0xc0,_0x31403f[_0x1f13f3++]=_0x36ff8d&0x3f|0x80):_0x36ff8d<0x10000?(_0x31403f[_0x1f13f3++]=_0x36ff8d>>0xc|0xe0,_0x31403f[_0x1f13f3++]=_0x36ff8d>>0x6&0x3f|0x80,_0x31403f[_0x1f13f3++]=_0x36ff8d&0x3f|0x80):(_0x31403f[_0x1f13f3++]=_0x36ff8d>>0x12|0xf0,_0x31403f[_0x1f13f3++]=_0x36ff8d>>0xc&0x3f|0x80,_0x31403f[_0x1f13f3++]=_0x36ff8d>>0x6&0x3f|0x80,_0x31403f[_0x1f13f3++]=_0x36ff8d&0x3f|0x80);}return _0x31403f;},Ln=function(_0x32b6e3){let _0x5c3035=0x0;for(let _0x2753e7=0x0;_0x2753e7<_0x32b6e3['length'];_0x2753e7++){const _0x36bca8=_0x32b6e3['charCodeAt'](_0x2753e7);_0x36bca8<0x80?_0x5c3035++:_0x36bca8<0x800?_0x5c3035+=0x2:_0x36bca8>=0xd800&&_0x36bca8<=0xdbff?(_0x5c3035+=0x4,_0x2753e7++):_0x5c3035+=0x3;}return _0x5c3035;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x31bbee){return _0x31bbee&&_0x31bbee['_delegate']?_0x31bbee['_delegate']:_0x31bbee;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x50ee97){try{return(_0x50ee97['startsWith']('http://')||_0x50ee97['startsWith']('https://')?new URL(_0x50ee97)['hostname']:_0x50ee97)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x179ec4){return(await fetch(_0x179ec4,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x424559,_0x4f6c4b,_0x5e71be){this['name']=_0x424559,this['instanceFactory']=_0x4f6c4b,this['type']=_0x5e71be,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x417f3c){return this['instantiationMode']=_0x417f3c,this;}['setMultipleInstances'](_0x108a6f){return this['multipleInstances']=_0x108a6f,this;}['setServiceProps'](_0x28f475){return this['serviceProps']=_0x28f475,this;}['setInstanceCreatedCallback'](_0x130ed4){return this['onInstanceCreated']=_0x130ed4,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x22b22d,_0x367562){this['name']=_0x22b22d,this['container']=_0x367562,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x3de225){const _0x26e1d7=this['normalizeInstanceIdentifier'](_0x3de225);if(!this['instancesDeferred']['has'](_0x26e1d7)){const _0x548adf=new H();if(this['instancesDeferred']['set'](_0x26e1d7,_0x548adf),this['isInitialized'](_0x26e1d7)||this['shouldAutoInitialize']())try{const _0x31ec79=this['getOrInitializeService']({'instanceIdentifier':_0x26e1d7});_0x31ec79&&_0x548adf['resolve'](_0x31ec79);}catch{}}return this['instancesDeferred']['get'](_0x26e1d7)['promise'];}['getImmediate'](_0x18c375){const _0x16abfd=this['normalizeInstanceIdentifier'](_0x18c375==null?void 0x0:_0x18c375['identifier']),_0x29a5cb=(_0x18c375==null?void 0x0:_0x18c375['optional'])??!0x1;if(this['isInitialized'](_0x16abfd)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x16abfd});}catch(_0x17952c){if(_0x29a5cb)return null;throw _0x17952c;}else{if(_0x29a5cb)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x459a57){if(_0x459a57['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x459a57['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x459a57,!!this['shouldAutoInitialize']()){if(Pc(_0x459a57))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x405f0c,_0x34e749]of this['instancesDeferred']['entries']()){const _0x3954be=this['normalizeInstanceIdentifier'](_0x405f0c);try{const _0x37f2f0=this['getOrInitializeService']({'instanceIdentifier':_0x3954be});_0x34e749['resolve'](_0x37f2f0);}catch{}}}}['clearInstance'](_0x24a1a2=Ne){this['instancesDeferred']['delete'](_0x24a1a2),this['instancesOptions']['delete'](_0x24a1a2),this['instances']['delete'](_0x24a1a2);}async['delete'](){const _0x2d183d=Array['from'](this['instances']['values']());await Promise['all']([..._0x2d183d['filter'](_0x227ed6=>'INTERNAL'in _0x227ed6)['map'](_0x465fa5=>_0x465fa5['INTERNAL']['delete']()),..._0x2d183d['filter'](_0x237a60=>'_delete'in _0x237a60)['map'](_0x4ed85c=>_0x4ed85c['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x18ca06=Ne){return this['instances']['has'](_0x18ca06);}['getOptions'](_0x630122=Ne){return this['instancesOptions']['get'](_0x630122)||{};}['initialize'](_0x2d7522={}){const {options:_0x437a35={}}=_0x2d7522,_0x248a32=this['normalizeInstanceIdentifier'](_0x2d7522['instanceIdentifier']);if(this['isInitialized'](_0x248a32))throw Error(this['name']+'('+_0x248a32+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1c4184=this['getOrInitializeService']({'instanceIdentifier':_0x248a32,'options':_0x437a35});for(const [_0x431f7c,_0x1b7f07]of this['instancesDeferred']['entries']()){const _0x1218d0=this['normalizeInstanceIdentifier'](_0x431f7c);_0x248a32===_0x1218d0&&_0x1b7f07['resolve'](_0x1c4184);}return _0x1c4184;}['onInit'](_0x3522f6,_0x27087b){const _0x8cda8c=this['normalizeInstanceIdentifier'](_0x27087b),_0x115418=this['onInitCallbacks']['get'](_0x8cda8c)??new Set();_0x115418['add'](_0x3522f6),this['onInitCallbacks']['set'](_0x8cda8c,_0x115418);const _0x48f498=this['instances']['get'](_0x8cda8c);return _0x48f498&&_0x3522f6(_0x48f498,_0x8cda8c),()=>{_0x115418['delete'](_0x3522f6);};}['invokeOnInitCallbacks'](_0x1a5dcd,_0x38e06f){const _0x35cc94=this['onInitCallbacks']['get'](_0x38e06f);if(_0x35cc94){for(const _0x11e814 of _0x35cc94)try{_0x11e814(_0x1a5dcd,_0x38e06f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x33b89c,options:_0x128de8={}}){let _0x5cad14=this['instances']['get'](_0x33b89c);if(!_0x5cad14&&this['component']&&(_0x5cad14=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x33b89c),'options':_0x128de8}),this['instances']['set'](_0x33b89c,_0x5cad14),this['instancesOptions']['set'](_0x33b89c,_0x128de8),this['invokeOnInitCallbacks'](_0x5cad14,_0x33b89c),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x33b89c,_0x5cad14);}catch{}return _0x5cad14||null;}['normalizeInstanceIdentifier'](_0x338d52=Ne){return this['component']?this['component']['multipleInstances']?_0x338d52:Ne:_0x338d52;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x2f27e8){return _0x2f27e8===Ne?void 0x0:_0x2f27e8;}function Pc(_0x47919b){return _0x47919b['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x519e0a){this['name']=_0x519e0a,this['providers']=new Map();}['addComponent'](_0x10d826){const _0x19c38c=this['getProvider'](_0x10d826['name']);if(_0x19c38c['isComponentSet']())throw new Error('Component\x20'+_0x10d826['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x19c38c['setComponent'](_0x10d826);}['addOrOverwriteComponent'](_0x316c87){this['getProvider'](_0x316c87['name'])['isComponentSet']()&&this['providers']['delete'](_0x316c87['name']),this['addComponent'](_0x316c87);}['getProvider'](_0x25842c){if(this['providers']['has'](_0x25842c))return this['providers']['get'](_0x25842c);const _0x44f0fa=new Ac(_0x25842c,this);return this['providers']['set'](_0x25842c,_0x44f0fa),_0x44f0fa;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x336673){_0x336673[_0x336673['DEBUG']=0x0]='DEBUG',_0x336673[_0x336673['VERBOSE']=0x1]='VERBOSE',_0x336673[_0x336673['INFO']=0x2]='INFO',_0x336673[_0x336673['WARN']=0x3]='WARN',_0x336673[_0x336673['ERROR']=0x4]='ERROR',_0x336673[_0x336673['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x225232,_0x11fd4b,..._0x120bad)=>{if(_0x11fd4b<_0x225232['logLevel'])return;const _0xab17ec=new Date()['toISOString'](),_0x10ce21=Mc[_0x11fd4b];if(_0x10ce21)console[_0x10ce21]('['+_0xab17ec+']\x20\x20'+_0x225232['name']+':',..._0x120bad);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x11fd4b+')');};class Bi{constructor(_0x2656f1){this['name']=_0x2656f1,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5202b9){if(!(_0x5202b9 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5202b9+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5202b9;}['setLogLevel'](_0x115104){this['_logLevel']=typeof _0x115104=='string'?Oc[_0x115104]:_0x115104;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x2adea6){if(typeof _0x2adea6!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x2adea6;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x507461){this['_userLogHandler']=_0x507461;}['debug'](..._0x4209d6){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4209d6),this['_logHandler'](this,T['DEBUG'],..._0x4209d6);}['log'](..._0x3fe6b6){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x3fe6b6),this['_logHandler'](this,T['VERBOSE'],..._0x3fe6b6);}['info'](..._0x49a494){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x49a494),this['_logHandler'](this,T['INFO'],..._0x49a494);}['warn'](..._0x578dca){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x578dca),this['_logHandler'](this,T['WARN'],..._0x578dca);}['error'](..._0x17e0a8){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x17e0a8),this['_logHandler'](this,T['ERROR'],..._0x17e0a8);}}const xc=(_0x131171,_0x25cc07)=>_0x25cc07['some'](_0x4f859a=>_0x131171 instanceof _0x4f859a);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x4af336){const _0x447b1a=new Promise((_0x1b99bf,_0x566da9)=>{const _0x33347e=()=>{_0x4af336['removeEventListener']('success',_0xd36bc8),_0x4af336['removeEventListener']('error',_0x55aa97);},_0xd36bc8=()=>{_0x1b99bf(ge(_0x4af336['result'])),_0x33347e();},_0x55aa97=()=>{_0x566da9(_0x4af336['error']),_0x33347e();};_0x4af336['addEventListener']('success',_0xd36bc8),_0x4af336['addEventListener']('error',_0x55aa97);});return _0x447b1a['then'](_0x358325=>{_0x358325 instanceof IDBCursor&&Jr['set'](_0x358325,_0x4af336);})['catch'](()=>{}),Vi['set'](_0x447b1a,_0x4af336),_0x447b1a;}function Bc(_0x342ebf){if(_i['has'](_0x342ebf))return;const _0x8c869f=new Promise((_0x44ab60,_0x4a9fbf)=>{const _0x18efb1=()=>{_0x342ebf['removeEventListener']('complete',_0x18093a),_0x342ebf['removeEventListener']('error',_0x1d3530),_0x342ebf['removeEventListener']('abort',_0x1d3530);},_0x18093a=()=>{_0x44ab60(),_0x18efb1();},_0x1d3530=()=>{_0x4a9fbf(_0x342ebf['error']||new DOMException('AbortError','AbortError')),_0x18efb1();};_0x342ebf['addEventListener']('complete',_0x18093a),_0x342ebf['addEventListener']('error',_0x1d3530),_0x342ebf['addEventListener']('abort',_0x1d3530);});_i['set'](_0x342ebf,_0x8c869f);}let gi={'get'(_0x249745,_0xbbb87c,_0x1fd81d){if(_0x249745 instanceof IDBTransaction){if(_0xbbb87c==='done')return _i['get'](_0x249745);if(_0xbbb87c==='objectStoreNames')return _0x249745['objectStoreNames']||Xr['get'](_0x249745);if(_0xbbb87c==='store')return _0x1fd81d['objectStoreNames'][0x1]?void 0x0:_0x1fd81d['objectStore'](_0x1fd81d['objectStoreNames'][0x0]);}return ge(_0x249745[_0xbbb87c]);},'set'(_0x37601d,_0x228090,_0xc389ed){return _0x37601d[_0x228090]=_0xc389ed,!0x0;},'has'(_0x640cf4,_0x379b15){return _0x640cf4 instanceof IDBTransaction&&(_0x379b15==='done'||_0x379b15==='store')?!0x0:_0x379b15 in _0x640cf4;}};function Vc(_0x376a8a){gi=_0x376a8a(gi);}function Hc(_0x5142cb){return _0x5142cb===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x57b48b,..._0x3a0df8){const _0x520394=_0x5142cb['call'](ii(this),_0x57b48b,..._0x3a0df8);return Xr['set'](_0x520394,_0x57b48b['sort']?_0x57b48b['sort']():[_0x57b48b]),ge(_0x520394);}:Uc()['includes'](_0x5142cb)?function(..._0x41d67b){return _0x5142cb['apply'](ii(this),_0x41d67b),ge(Jr['get'](this));}:function(..._0x2ba786){return ge(_0x5142cb['apply'](ii(this),_0x2ba786));};}function $c(_0x191b6e){return typeof _0x191b6e=='function'?Hc(_0x191b6e):(_0x191b6e instanceof IDBTransaction&&Bc(_0x191b6e),xc(_0x191b6e,Fc())?new Proxy(_0x191b6e,gi):_0x191b6e);}function ge(_0x2e63b6){if(_0x2e63b6 instanceof IDBRequest)return Wc(_0x2e63b6);if(ni['has'](_0x2e63b6))return ni['get'](_0x2e63b6);const _0x17dfa3=$c(_0x2e63b6);return _0x17dfa3!==_0x2e63b6&&(ni['set'](_0x2e63b6,_0x17dfa3),Vi['set'](_0x17dfa3,_0x2e63b6)),_0x17dfa3;}const ii=_0x358730=>Vi['get'](_0x358730);function Gc(_0x5c6c6c,_0x1d0764,{blocked:_0x2331e2,upgrade:_0x4d61d1,blocking:_0x5278de,terminated:_0x1cd8af}={}){const _0x3f8ec7=indexedDB['open'](_0x5c6c6c,_0x1d0764),_0x5b824f=ge(_0x3f8ec7);return _0x4d61d1&&_0x3f8ec7['addEventListener']('upgradeneeded',_0x312714=>{_0x4d61d1(ge(_0x3f8ec7['result']),_0x312714['oldVersion'],_0x312714['newVersion'],ge(_0x3f8ec7['transaction']),_0x312714);}),_0x2331e2&&_0x3f8ec7['addEventListener']('blocked',_0x37ac78=>_0x2331e2(_0x37ac78['oldVersion'],_0x37ac78['newVersion'],_0x37ac78)),_0x5b824f['then'](_0x3b93a4=>{_0x1cd8af&&_0x3b93a4['addEventListener']('close',()=>_0x1cd8af()),_0x5278de&&_0x3b93a4['addEventListener']('versionchange',_0x4b8bc3=>_0x5278de(_0x4b8bc3['oldVersion'],_0x4b8bc3['newVersion'],_0x4b8bc3));})['catch'](()=>{}),_0x5b824f;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x59a577,_0x302706){if(!(_0x59a577 instanceof IDBDatabase&&!(_0x302706 in _0x59a577)&&typeof _0x302706=='string'))return;if(si['get'](_0x302706))return si['get'](_0x302706);const _0x667a0d=_0x302706['replace'](/FromIndex$/,''),_0x4a4851=_0x302706!==_0x667a0d,_0x5c6e5f=zc['includes'](_0x667a0d);if(!(_0x667a0d in(_0x4a4851?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5c6e5f||qc['includes'](_0x667a0d)))return;const _0x274665=async function(_0x41e10f,..._0x486b94){const _0x196034=this['transaction'](_0x41e10f,_0x5c6e5f?'readwrite':'readonly');let _0x1794fc=_0x196034['store'];return _0x4a4851&&(_0x1794fc=_0x1794fc['index'](_0x486b94['shift']())),(await Promise['all']([_0x1794fc[_0x667a0d](..._0x486b94),_0x5c6e5f&&_0x196034['done']]))[0x0];};return si['set'](_0x302706,_0x274665),_0x274665;}Vc(_0x5d149a=>({..._0x5d149a,'get':(_0x100b97,_0x51c81a,_0x1c7424)=>Ms(_0x100b97,_0x51c81a)||_0x5d149a['get'](_0x100b97,_0x51c81a,_0x1c7424),'has':(_0x37b315,_0xe21252)=>!!Ms(_0x37b315,_0xe21252)||_0x5d149a['has'](_0x37b315,_0xe21252)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0xae051){this['container']=_0xae051;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x243467=>{if(Kc(_0x243467)){const _0x3a1411=_0x243467['getImmediate']();return _0x3a1411['library']+'/'+_0x3a1411['version'];}else return null;})['filter'](_0x19fda0=>_0x19fda0)['join']('\x20');}}function Kc(_0x13387c){const _0x5a2c7f=_0x13387c['getComponent']();return(_0x5a2c7f==null?void 0x0:_0x5a2c7f['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x2a64c7,_0x4b0b81){try{_0x2a64c7['container']['addComponent'](_0x4b0b81);}catch(_0x3852d2){oe['debug']('Component\x20'+_0x4b0b81['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2a64c7['name'],_0x3852d2);}}function st(_0x4fd34c){const _0x28e1fe=_0x4fd34c['name'];if(Ei['has'](_0x28e1fe))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x28e1fe+'.'),!0x1;Ei['set'](_0x28e1fe,_0x4fd34c);for(const _0x67c1c of Ue['values']())xs(_0x67c1c,_0x4fd34c);for(const _0x30efd5 of vi['values']())xs(_0x30efd5,_0x4fd34c);return!0x0;}function Hi(_0x9e15b5,_0x488b31){const _0x6118fe=_0x9e15b5['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x6118fe&&_0x6118fe['triggerHeartbeat'](),_0x9e15b5['container']['getProvider'](_0x488b31);}function $(_0x4cf070){return _0x4cf070==null?!0x1:_0x4cf070['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x2d7061,_0x1873a5,_0x4c8f2a){this['_isDeleted']=!0x1,this['_options']={..._0x2d7061},this['_config']={..._0x1873a5},this['_name']=_0x1873a5['name'],this['_automaticDataCollectionEnabled']=_0x1873a5['automaticDataCollectionEnabled'],this['_container']=_0x4c8f2a,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x50863d){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x50863d;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x3b05b1){this['_isDeleted']=_0x3b05b1;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0xdd65c3,_0x3a01c4={}){let _0x4c7d31=_0xdd65c3;typeof _0x3a01c4!='object'&&(_0x3a01c4={'name':_0x3a01c4});const _0x3b8e62={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x3a01c4},_0x3e3ec8=_0x3b8e62['name'];if(typeof _0x3e3ec8!='string'||!_0x3e3ec8)throw me['create']('bad-app-name',{'appName':String(_0x3e3ec8)});if(_0x4c7d31||(_0x4c7d31=zr()),!_0x4c7d31)throw me['create']('no-options');const _0x2e03e8=Ue['get'](_0x3e3ec8);if(_0x2e03e8){if(xe(_0x4c7d31,_0x2e03e8['options'])&&xe(_0x3b8e62,_0x2e03e8['config']))return _0x2e03e8;throw me['create']('duplicate-app',{'appName':_0x3e3ec8});}const _0x4ada0a=new Nc(_0x3e3ec8);for(const _0x5a1ccc of Ei['values']())_0x4ada0a['addComponent'](_0x5a1ccc);const _0x55b0b2=new Tl(_0x4c7d31,_0x3b8e62,_0x4ada0a);return Ue['set'](_0x3e3ec8,_0x55b0b2),_0x55b0b2;}function Zr(_0x4cb4a6=yi){const _0x4ace62=Ue['get'](_0x4cb4a6);if(!_0x4ace62&&_0x4cb4a6===yi&&zr())return Sl();if(!_0x4ace62)throw me['create']('no-app',{'appName':_0x4cb4a6});return _0x4ace62;}function g_(){return Array['from'](Ue['values']());}async function m_(_0xeb93df){let _0x42e5c0=!0x1;const _0x1475ca=_0xeb93df['name'];Ue['has'](_0x1475ca)?(_0x42e5c0=!0x0,Ue['delete'](_0x1475ca)):vi['has'](_0x1475ca)&&_0xeb93df['decRefCount']()<=0x0&&(vi['delete'](_0x1475ca),_0x42e5c0=!0x0),_0x42e5c0&&(await Promise['all'](_0xeb93df['container']['getProviders']()['map'](_0x41a927=>_0x41a927['delete']())),_0xeb93df['isDeleted']=!0x0);}function ye(_0x1dda86,_0xedd2bc,_0x3592ad){let _0x58340a=wl[_0x1dda86]??_0x1dda86;_0x3592ad&&(_0x58340a+='-'+_0x3592ad);const _0x12da71=_0x58340a['match'](/\s|\//),_0x473b21=_0xedd2bc['match'](/\s|\//);if(_0x12da71||_0x473b21){const _0x5a012a=['Unable\x20to\x20register\x20library\x20\x22'+_0x58340a+'\x22\x20with\x20version\x20\x22'+_0xedd2bc+'\x22:'];_0x12da71&&_0x5a012a['push']('library\x20name\x20\x22'+_0x58340a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x12da71&&_0x473b21&&_0x5a012a['push']('and'),_0x473b21&&_0x5a012a['push']('version\x20name\x20\x22'+_0xedd2bc+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x5a012a['join']('\x20'));return;}st(new Fe(_0x58340a+'-version',()=>({'library':_0x58340a,'version':_0xedd2bc}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x166906,_0x503579)=>{switch(_0x503579){case 0x0:try{_0x166906['createObjectStore'](Ot);}catch(_0x5a17c3){console['warn'](_0x5a17c3);}}}})['catch'](_0x1eb197=>{throw me['create']('idb-open',{'originalErrorMessage':_0x1eb197['message']});})),ri;}async function Al(_0x5b2150){try{const _0x4a418d=(await eo())['transaction'](Ot),_0x2a84da=await _0x4a418d['objectStore'](Ot)['get'](to(_0x5b2150));return await _0x4a418d['done'],_0x2a84da;}catch(_0x52ef9d){if(_0x52ef9d instanceof Re)oe['warn'](_0x52ef9d['message']);else{const _0x154a7b=me['create']('idb-get',{'originalErrorMessage':_0x52ef9d==null?void 0x0:_0x52ef9d['message']});oe['warn'](_0x154a7b['message']);}}}async function Fs(_0x14bd93,_0x314750){try{const _0x8447c5=(await eo())['transaction'](Ot,'readwrite');await _0x8447c5['objectStore'](Ot)['put'](_0x314750,to(_0x14bd93)),await _0x8447c5['done'];}catch(_0x37906f){if(_0x37906f instanceof Re)oe['warn'](_0x37906f['message']);else{const _0x298a62=me['create']('idb-set',{'originalErrorMessage':_0x37906f==null?void 0x0:_0x37906f['message']});oe['warn'](_0x298a62['message']);}}}function to(_0x37b9b2){return _0x37b9b2['name']+'!'+_0x37b9b2['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x19ae01){this['container']=_0x19ae01,this['_heartbeatsCache']=null;const _0x2000fa=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x2000fa),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x8375d8=>(this['_heartbeatsCache']=_0x8375d8,_0x8375d8));}async['triggerHeartbeat'](){var _0xc92905,_0xf79189;try{const _0x26effb=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x5b99ed=Us();if(((_0xc92905=this['_heartbeatsCache'])==null?void 0x0:_0xc92905['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0xf79189=this['_heartbeatsCache'])==null?void 0x0:_0xf79189['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x5b99ed||this['_heartbeatsCache']['heartbeats']['some'](_0x558ecf=>_0x558ecf['date']===_0x5b99ed))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x5b99ed,'agent':_0x26effb}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x5ec31a=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5ec31a,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5ccc15){oe['warn'](_0x5ccc15);}}async['getHeartbeatsHeader'](){var _0x5bdf91;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x5bdf91=this['_heartbeatsCache'])==null?void 0x0:_0x5bdf91['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3eacfc=Us(),{heartbeatsToSend:_0x536f49,unsentEntries:_0x48eef3}=Ol(this['_heartbeatsCache']['heartbeats']),_0x1b3c13=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x536f49}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3eacfc,_0x48eef3['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x48eef3,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1b3c13;}catch(_0x52d713){return oe['warn'](_0x52d713),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x12a352,_0x433398=kl){const _0x23c0eb=[];let _0x331b40=_0x12a352['slice']();for(const _0x4a55a7 of _0x12a352){const _0xe92f9a=_0x23c0eb['find'](_0x1079f6=>_0x1079f6['agent']===_0x4a55a7['agent']);if(_0xe92f9a){if(_0xe92f9a['dates']['push'](_0x4a55a7['date']),Ws(_0x23c0eb)>_0x433398){_0xe92f9a['dates']['pop']();break;}}else{if(_0x23c0eb['push']({'agent':_0x4a55a7['agent'],'dates':[_0x4a55a7['date']]}),Ws(_0x23c0eb)>_0x433398){_0x23c0eb['pop']();break;}}_0x331b40=_0x331b40['slice'](0x1);}return{'heartbeatsToSend':_0x23c0eb,'unsentEntries':_0x331b40};}class Dl{constructor(_0x2839bc){this['app']=_0x2839bc,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5358ff=await Al(this['app']);return _0x5358ff!=null&&_0x5358ff['heartbeats']?_0x5358ff:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x7a2a11){if(await this['_canUseIndexedDBPromise']){const _0x1a14f0=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x7a2a11['lastSentHeartbeatDate']??_0x1a14f0['lastSentHeartbeatDate'],'heartbeats':_0x7a2a11['heartbeats']});}else return;}async['add'](_0x38e419){if(await this['_canUseIndexedDBPromise']){const _0x238103=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x38e419['lastSentHeartbeatDate']??_0x238103['lastSentHeartbeatDate'],'heartbeats':[..._0x238103['heartbeats'],..._0x38e419['heartbeats']]});}else return;}}function Ws(_0x2eb7d5){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2eb7d5}))['length'];}function Ml(_0x304ace){if(_0x304ace['length']===0x0)return-0x1;let _0x36ad88=0x0,_0x4c4d34=_0x304ace[0x0]['date'];for(let _0x301393=0x1;_0x301393<_0x304ace['length'];_0x301393++)_0x304ace[_0x301393]['date']<_0x4c4d34&&(_0x4c4d34=_0x304ace[_0x301393]['date'],_0x36ad88=_0x301393);return _0x36ad88;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x377af0){st(new Fe('platform-logger',_0x1f70f6=>new jc(_0x1f70f6),'PRIVATE')),st(new Fe('heartbeat',_0x334008=>new Nl(_0x334008),'PRIVATE')),ye(mi,Ls,_0x377af0),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x35dc7d){no=_0x35dc7d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0xf9d146){this['domStorage_']=_0xf9d146,this['prefix_']='firebase:';}['set'](_0x19bb5c,_0x3ef435){_0x3ef435==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x19bb5c)):this['domStorage_']['setItem'](this['prefixedName_'](_0x19bb5c),O(_0x3ef435));}['get'](_0x31a9e2){const _0x2ee00e=this['domStorage_']['getItem'](this['prefixedName_'](_0x31a9e2));return _0x2ee00e==null?null:Nt(_0x2ee00e);}['remove'](_0x11863b){this['domStorage_']['removeItem'](this['prefixedName_'](_0x11863b));}['prefixedName_'](_0x6d4856){return this['prefix_']+_0x6d4856;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x55a923,_0x430536){_0x430536==null?delete this['cache_'][_0x55a923]:this['cache_'][_0x55a923]=_0x430536;}['get'](_0x585e6c){return Q(this['cache_'],_0x585e6c)?this['cache_'][_0x585e6c]:null;}['remove'](_0x12d856){delete this['cache_'][_0x12d856];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x581e17){try{if(typeof window<'u'&&typeof window[_0x581e17]<'u'){const _0x15fea9=window[_0x581e17];return _0x15fea9['setItem']('firebase:sentinel','cache'),_0x15fea9['removeItem']('firebase:sentinel'),new Wl(_0x15fea9);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x536b68=0x1;return function(){return _0x536b68++;};}()),ro=function(_0x2c5223){const _0x9a6dce=Rc(_0x2c5223),_0x5e2096=new Cc();_0x5e2096['update'](_0x9a6dce);const _0x4942a2=_0x5e2096['digest']();return Fi['encodeByteArray'](_0x4942a2);},zt=function(..._0x262801){let _0x170d6b='';for(let _0x7bb518=0x0;_0x7bb518<_0x262801['length'];_0x7bb518++){const _0x10025=_0x262801[_0x7bb518];Array['isArray'](_0x10025)||_0x10025&&typeof _0x10025=='object'&&typeof _0x10025['length']=='number'?_0x170d6b+=zt['apply'](null,_0x10025):typeof _0x10025=='object'?_0x170d6b+=O(_0x10025):_0x170d6b+=_0x10025,_0x170d6b+='\x20';}return _0x170d6b;};let St=null,$s=!0x0;const Hl=function(_0xae9ff3,_0x1fdf10){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x255124){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x56f50b=zt['apply'](null,_0x255124);St(_0x56f50b);}},jt=function(_0x4b7ada){return function(..._0x52481d){L(_0x4b7ada,..._0x52481d);};},Ii=function(..._0x54f8a8){const _0x3dacb9='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x54f8a8);Ze['error'](_0x3dacb9);},ae=function(..._0xbbfb98){const _0x34a76c='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0xbbfb98);throw Ze['error'](_0x34a76c),new Error(_0x34a76c);},U=function(..._0x12101f){const _0x3b1650='FIREBASE\x20WARNING:\x20'+zt(..._0x12101f);Ze['warn'](_0x3b1650);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0xe4b840){return typeof _0xe4b840=='number'&&(_0xe4b840!==_0xe4b840||_0xe4b840===Number['POSITIVE_INFINITY']||_0xe4b840===Number['NEGATIVE_INFINITY']);},Gl=function(_0x1dbdb6){if(document['readyState']==='complete')_0x1dbdb6();else{let _0x19d96b=!0x1;const _0x284af5=function(){if(!document['body']){setTimeout(_0x284af5,Math['floor'](0xa));return;}_0x19d96b||(_0x19d96b=!0x0,_0x1dbdb6());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x284af5,!0x1),window['addEventListener']('load',_0x284af5,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x284af5();}),window['attachEvent']('onload',_0x284af5));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x44bbff,_0x5a28eb){if(_0x44bbff===_0x5a28eb)return 0x0;if(_0x44bbff===We||_0x5a28eb===we)return-0x1;if(_0x5a28eb===We||_0x44bbff===we)return 0x1;{const _0x898f3d=Gs(_0x44bbff),_0x498e01=Gs(_0x5a28eb);return _0x898f3d!==null?_0x498e01!==null?_0x898f3d-_0x498e01===0x0?_0x44bbff['length']-_0x5a28eb['length']:_0x898f3d-_0x498e01:-0x1:_0x498e01!==null?0x1:_0x44bbff<_0x5a28eb?-0x1:0x1;}},ql=function(_0x18fb85,_0x383fe9){return _0x18fb85===_0x383fe9?0x0:_0x18fb85<_0x383fe9?-0x1:0x1;},vt=function(_0x5b50d9,_0x3246d6){if(_0x3246d6&&_0x5b50d9 in _0x3246d6)return _0x3246d6[_0x5b50d9];throw new Error('Missing\x20required\x20key\x20('+_0x5b50d9+')\x20in\x20object:\x20'+O(_0x3246d6));},$i=function(_0x21d067){if(typeof _0x21d067!='object'||_0x21d067===null)return O(_0x21d067);const _0x392a29=[];for(const _0x1a3028 in _0x21d067)_0x392a29['push'](_0x1a3028);_0x392a29['sort']();let _0x5cc12d='{';for(let _0x173ccc=0x0;_0x173ccc<_0x392a29['length'];_0x173ccc++)_0x173ccc!==0x0&&(_0x5cc12d+=','),_0x5cc12d+=O(_0x392a29[_0x173ccc]),_0x5cc12d+=':',_0x5cc12d+=$i(_0x21d067[_0x392a29[_0x173ccc]]);return _0x5cc12d+='}',_0x5cc12d;},oo=function(_0x54141e,_0x24dffe){const _0x229379=_0x54141e['length'];if(_0x229379<=_0x24dffe)return[_0x54141e];const _0x275159=[];for(let _0x1ced77=0x0;_0x1ced77<_0x229379;_0x1ced77+=_0x24dffe)_0x1ced77+_0x24dffe>_0x229379?_0x275159['push'](_0x54141e['substring'](_0x1ced77,_0x229379)):_0x275159['push'](_0x54141e['substring'](_0x1ced77,_0x1ced77+_0x24dffe));return _0x275159;};function x(_0x51dcf5,_0x5863ba){for(const _0x33e0e5 in _0x51dcf5)_0x51dcf5['hasOwnProperty'](_0x33e0e5)&&_0x5863ba(_0x33e0e5,_0x51dcf5[_0x33e0e5]);}const ao=function(_0x578cfa){f(!xn(_0x578cfa),'Invalid\x20JSON\x20number');const _0x41b0ee=0xb,_0x937e90=0x34,_0xffed9b=(0x1<<_0x41b0ee-0x1)-0x1;let _0x4e35b3,_0x41de20,_0x2a11b2,_0x2c71e2,_0x1e75aa;_0x578cfa===0x0?(_0x41de20=0x0,_0x2a11b2=0x0,_0x4e35b3=0x1/_0x578cfa===-0x1/0x0?0x1:0x0):(_0x4e35b3=_0x578cfa<0x0,_0x578cfa=Math['abs'](_0x578cfa),_0x578cfa>=Math['pow'](0x2,0x1-_0xffed9b)?(_0x2c71e2=Math['min'](Math['floor'](Math['log'](_0x578cfa)/Math['LN2']),_0xffed9b),_0x41de20=_0x2c71e2+_0xffed9b,_0x2a11b2=Math['round'](_0x578cfa*Math['pow'](0x2,_0x937e90-_0x2c71e2)-Math['pow'](0x2,_0x937e90))):(_0x41de20=0x0,_0x2a11b2=Math['round'](_0x578cfa/Math['pow'](0x2,0x1-_0xffed9b-_0x937e90))));const _0x399d47=[];for(_0x1e75aa=_0x937e90;_0x1e75aa;_0x1e75aa-=0x1)_0x399d47['push'](_0x2a11b2%0x2?0x1:0x0),_0x2a11b2=Math['floor'](_0x2a11b2/0x2);for(_0x1e75aa=_0x41b0ee;_0x1e75aa;_0x1e75aa-=0x1)_0x399d47['push'](_0x41de20%0x2?0x1:0x0),_0x41de20=Math['floor'](_0x41de20/0x2);_0x399d47['push'](_0x4e35b3?0x1:0x0),_0x399d47['reverse']();const _0x5881ed=_0x399d47['join']('');let _0x2fcff9='';for(_0x1e75aa=0x0;_0x1e75aa<0x40;_0x1e75aa+=0x8){let _0x35d54d=parseInt(_0x5881ed['substr'](_0x1e75aa,0x8),0x2)['toString'](0x10);_0x35d54d['length']===0x1&&(_0x35d54d='0'+_0x35d54d),_0x2fcff9=_0x2fcff9+_0x35d54d;}return _0x2fcff9['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x574410,_0x26511d){let _0x2697f4='Unknown\x20Error';_0x574410==='too_big'?_0x2697f4='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x574410==='permission_denied'?_0x2697f4='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x574410==='unavailable'&&(_0x2697f4='The\x20service\x20is\x20unavailable');const _0x4c69dc=new Error(_0x574410+'\x20at\x20'+_0x26511d['_path']['toString']()+':\x20'+_0x2697f4);return _0x4c69dc['code']=_0x574410['toUpperCase'](),_0x4c69dc;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x86853e){if(Yl['test'](_0x86853e)){const _0x2983cc=Number(_0x86853e);if(_0x2983cc>=Ql&&_0x2983cc<=Jl)return _0x2983cc;}return null;},ft=function(_0x2c8ad0){try{_0x2c8ad0();}catch(_0x360cd6){setTimeout(()=>{const _0x486359=_0x360cd6['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x486359),_0x360cd6;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x5598a3,_0x5bf4e9){const _0x53cf85=setTimeout(_0x5598a3,_0x5bf4e9);return typeof _0x53cf85=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x53cf85):typeof _0x53cf85=='object'&&_0x53cf85['unref']&&_0x53cf85['unref'](),_0x53cf85;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x3394bf,_0x4bc89d){this['appCheckProvider']=_0x4bc89d,this['appName']=_0x3394bf['name'],$(_0x3394bf)&&_0x3394bf['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3394bf['settings']['appCheckToken']),this['appCheck']=_0x4bc89d==null?void 0x0:_0x4bc89d['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4bc89d==null||_0x4bc89d['get']()['then'](_0x5ba3f3=>this['appCheck']=_0x5ba3f3);}['getToken'](_0x382260){if(this['serverAppAppCheckToken']){if(_0x382260)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x382260):new Promise((_0x101bd6,_0x52527c)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x382260)['then'](_0x101bd6,_0x52527c):_0x101bd6(null);},0x0);});}['addTokenChangeListener'](_0x324fcf){var _0xde37f4;(_0xde37f4=this['appCheckProvider'])==null||_0xde37f4['get']()['then'](_0x60eb96=>_0x60eb96['addTokenListener'](_0x324fcf));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x14a064,_0x5bf1cf,_0x18dce9){this['appName_']=_0x14a064,this['firebaseOptions_']=_0x5bf1cf,this['authProvider_']=_0x18dce9,this['auth_']=null,this['auth_']=_0x18dce9['getImmediate']({'optional':!0x0}),this['auth_']||_0x18dce9['onInit'](_0x38967d=>this['auth_']=_0x38967d);}['getToken'](_0x175224){return this['auth_']?this['auth_']['getToken'](_0x175224)['catch'](_0x44e1c0=>_0x44e1c0&&_0x44e1c0['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x44e1c0)):new Promise((_0x390b54,_0x2eceea)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x175224)['then'](_0x390b54,_0x2eceea):_0x390b54(null);},0x0);});}['addTokenChangeListener'](_0x5871a4){this['auth_']?this['auth_']['addAuthTokenListener'](_0x5871a4):this['authProvider_']['get']()['then'](_0x4507e8=>_0x4507e8['addAuthTokenListener'](_0x5871a4));}['removeTokenChangeListener'](_0x202d1b){this['authProvider_']['get']()['then'](_0x3fa486=>_0x3fa486['removeAuthTokenListener'](_0x202d1b));}['notifyForInvalidToken'](){let _0x7f8408='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x7f8408+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x7f8408+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x7f8408+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x7f8408);}}class an{constructor(_0xcd5dba){this['accessToken']=_0xcd5dba;}['getToken'](_0x22f44f){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x480756){_0x480756(this['accessToken']);}['removeTokenChangeListener'](_0x592361){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0xcdf067,_0x519d92,_0x3c06c8,_0x43e690,_0x542efd=!0x1,_0xf31e42='',_0x2c265f=!0x1,_0x9cb8e3=!0x1,_0x224fbe=null){this['secure']=_0x519d92,this['namespace']=_0x3c06c8,this['webSocketOnly']=_0x43e690,this['nodeAdmin']=_0x542efd,this['persistenceKey']=_0xf31e42,this['includeNamespaceInQueryParams']=_0x2c265f,this['isUsingEmulator']=_0x9cb8e3,this['emulatorOptions']=_0x224fbe,this['_host']=_0xcdf067['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0xcdf067)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0xd8415f){_0xd8415f!==this['internalHost']&&(this['internalHost']=_0xd8415f,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x76407f=this['toURLString']();return this['persistenceKey']&&(_0x76407f+='<'+this['persistenceKey']+'>'),_0x76407f;}['toURLString'](){const _0x23320c=this['secure']?'https://':'http://',_0x2d4ca0=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x23320c+this['host']+'/'+_0x2d4ca0;}}function th(_0xaffa47){return _0xaffa47['host']!==_0xaffa47['internalHost']||_0xaffa47['isCustomHost']()||_0xaffa47['includeNamespaceInQueryParams'];}function vo(_0x111fba,_0x37ad12,_0x346249){f(typeof _0x37ad12=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x346249=='object','typeof\x20params\x20must\x20==\x20object');let _0x9a3c80;if(_0x37ad12===go)_0x9a3c80=(_0x111fba['secure']?'wss://':'ws://')+_0x111fba['internalHost']+'/.ws?';else{if(_0x37ad12===mo)_0x9a3c80=(_0x111fba['secure']?'https://':'http://')+_0x111fba['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x37ad12);}th(_0x111fba)&&(_0x346249['ns']=_0x111fba['namespace']);const _0x5bf2de=[];return x(_0x346249,(_0x55cfbd,_0x53211d)=>{_0x5bf2de['push'](_0x55cfbd+'='+_0x53211d);}),_0x9a3c80+_0x5bf2de['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x534c54,_0x38637f=0x1){Q(this['counters_'],_0x534c54)||(this['counters_'][_0x534c54]=0x0),this['counters_'][_0x534c54]+=_0x38637f;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x17f988){const _0x11c32f=_0x17f988['toString']();return oi[_0x11c32f]||(oi[_0x11c32f]=new nh()),oi[_0x11c32f];}function ih(_0x47d1a6,_0x1b85ab){const _0x456fd1=_0x47d1a6['toString']();return ai[_0x456fd1]||(ai[_0x456fd1]=_0x1b85ab()),ai[_0x456fd1];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x63ec24){this['onMessage_']=_0x63ec24,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x344137,_0x3958a9){this['closeAfterResponse']=_0x344137,this['onClose']=_0x3958a9,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x16929a,_0x4c4ec2){for(this['pendingResponses'][_0x16929a]=_0x4c4ec2;this['pendingResponses'][this['currentResponseNum']];){const _0x59a630=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xee679c=0x0;_0xee679c<_0x59a630['length'];++_0xee679c)_0x59a630[_0xee679c]&&ft(()=>{this['onMessage_'](_0x59a630[_0xee679c]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x4fcff8,_0x442fca,_0x366f6c,_0x427122,_0x30176f,_0x4efa7c,_0x3e81c7){this['connId']=_0x4fcff8,this['repoInfo']=_0x442fca,this['applicationId']=_0x366f6c,this['appCheckToken']=_0x427122,this['authToken']=_0x30176f,this['transportSessionId']=_0x4efa7c,this['lastSessionId']=_0x3e81c7,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x4fcff8),this['stats_']=qi(_0x442fca),this['urlFn']=_0x1f0e1=>(this['appCheckToken']&&(_0x1f0e1[wi]=this['appCheckToken']),vo(_0x442fca,mo,_0x1f0e1));}['open'](_0x27af6a,_0x3976ee){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3976ee,this['myPacketOrderer']=new sh(_0x27af6a),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x5264f1)=>{const [_0x27c15b,_0x375f87,_0x2871ae,_0x3a002d,_0x4f5b0b]=_0x5264f1;if(this['incrementIncomingBytes_'](_0x5264f1),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x27c15b===qs)this['id']=_0x375f87,this['password']=_0x2871ae;else{if(_0x27c15b===rh)_0x375f87?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x375f87,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x27c15b);}}},(..._0x355840)=>{const [_0xa7583d,_0x1ff907]=_0x355840;this['incrementIncomingBytes_'](_0x355840),this['myPacketOrderer']['handleResponse'](_0xa7583d,_0x1ff907);},()=>{this['onClosed_']();},this['urlFn']);const _0x5f3853={};_0x5f3853[qs]='t',_0x5f3853[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5f3853[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5f3853[co]=Gi,this['transportSessionId']&&(_0x5f3853[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x5f3853[po]=this['lastSessionId']),this['applicationId']&&(_0x5f3853[_o]=this['applicationId']),this['appCheckToken']&&(_0x5f3853[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x5f3853[ho]=uo);const _0x107229=this['urlFn'](_0x5f3853);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x107229),this['scriptTagHolder']['addTag'](_0x107229,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x12e00c){const _0x3d0da8=O(_0x12e00c);this['bytesSent']+=_0x3d0da8['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3d0da8['length']);const _0x4df175=$r(_0x3d0da8),_0xd65761=oo(_0x4df175,fh);for(let _0x531ce2=0x0;_0x531ce2<_0xd65761['length'];_0x531ce2++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xd65761['length'],_0xd65761[_0x531ce2]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x3b7572,_0x4e5cae){this['myDisconnFrame']=document['createElement']('iframe');const _0x314729={};_0x314729[dh]='t',_0x314729[Eo]=_0x3b7572,_0x314729[Io]=_0x4e5cae,this['myDisconnFrame']['src']=this['urlFn'](_0x314729),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x545bca){const _0x454c9c=O(_0x545bca)['length'];this['bytesReceived']+=_0x454c9c,this['stats_']['incrementCounter']('bytes_received',_0x454c9c);}}class zi{constructor(_0x4eeaf4,_0x9ef48a,_0x1691b9,_0x1965f4){this['onDisconnect']=_0x1691b9,this['urlFn']=_0x1965f4,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x4eeaf4,window[ah+this['uniqueCallbackIdentifier']]=_0x9ef48a,this['myIFrame']=zi['createIFrame_']();let _0x5cf42b='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x5cf42b='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x12e1e7='<html><body>'+_0x5cf42b+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x12e1e7),this['myIFrame']['doc']['close']();}catch(_0x2ef523){L('frame\x20writing\x20exception'),_0x2ef523['stack']&&L(_0x2ef523['stack']),L(_0x2ef523);}}}static['createIFrame_'](){const _0x4c4db3=document['createElement']('iframe');if(_0x4c4db3['style']['display']='none',document['body']){document['body']['appendChild'](_0x4c4db3);try{_0x4c4db3['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x173cfa=document['domain'];_0x4c4db3['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x173cfa+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4c4db3['contentDocument']?_0x4c4db3['doc']=_0x4c4db3['contentDocument']:_0x4c4db3['contentWindow']?_0x4c4db3['doc']=_0x4c4db3['contentWindow']['document']:_0x4c4db3['document']&&(_0x4c4db3['doc']=_0x4c4db3['document']),_0x4c4db3;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x46cb19=this['onDisconnect'];_0x46cb19&&(this['onDisconnect']=null,_0x46cb19());}['startLongPoll'](_0x4f1149,_0x2713e1){for(this['myID']=_0x4f1149,this['myPW']=_0x2713e1,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x40cc53={};_0x40cc53[Eo]=this['myID'],_0x40cc53[Io]=this['myPW'],_0x40cc53[wo]=this['currentSerial'];let _0x218283=this['urlFn'](_0x40cc53),_0x4c2950='',_0x552625=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x4c2950['length']<=Co;){const _0xbbfe50=this['pendingSegs']['shift']();_0x4c2950=_0x4c2950+'&'+lh+_0x552625+'='+_0xbbfe50['seg']+'&'+hh+_0x552625+'='+_0xbbfe50['ts']+'&'+uh+_0x552625+'='+_0xbbfe50['d'],_0x552625++;}return _0x218283=_0x218283+_0x4c2950,this['addLongPollTag_'](_0x218283,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1b5139,_0x311275,_0x71135c){this['pendingSegs']['push']({'seg':_0x1b5139,'ts':_0x311275,'d':_0x71135c}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x249b47,_0x4ceb29){this['outstandingRequests']['add'](_0x4ceb29);const _0x6af98e=()=>{this['outstandingRequests']['delete'](_0x4ceb29),this['newRequest_']();},_0x4d8512=setTimeout(_0x6af98e,Math['floor'](ph)),_0xc75cee=()=>{clearTimeout(_0x4d8512),_0x6af98e();};this['addTag'](_0x249b47,_0xc75cee);}['addTag'](_0x159aa8,_0x161e82){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x1275e4=this['myIFrame']['doc']['createElement']('script');_0x1275e4['type']='text/javascript',_0x1275e4['async']=!0x0,_0x1275e4['src']=_0x159aa8,_0x1275e4['onload']=_0x1275e4['onreadystatechange']=function(){const _0x4acb06=_0x1275e4['readyState'];(!_0x4acb06||_0x4acb06==='loaded'||_0x4acb06==='complete')&&(_0x1275e4['onload']=_0x1275e4['onreadystatechange']=null,_0x1275e4['parentNode']&&_0x1275e4['parentNode']['removeChild'](_0x1275e4),_0x161e82());},_0x1275e4['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x159aa8),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x1275e4);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x3cce7a,_0x4c7d0b,_0x1ac518,_0xc92f07,_0x531639,_0x31d57e,_0x1b7ab9){this['connId']=_0x3cce7a,this['applicationId']=_0x1ac518,this['appCheckToken']=_0xc92f07,this['authToken']=_0x531639,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x4c7d0b),this['connURL']=q['connectionURL_'](_0x4c7d0b,_0x31d57e,_0x1b7ab9,_0xc92f07,_0x1ac518),this['nodeAdmin']=_0x4c7d0b['nodeAdmin'];}static['connectionURL_'](_0x337e9d,_0xd52d51,_0x120404,_0x5bfe94,_0x5b20b6){const _0x57d53c={};return _0x57d53c[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x57d53c[ho]=uo),_0xd52d51&&(_0x57d53c[lo]=_0xd52d51),_0x120404&&(_0x57d53c[po]=_0x120404),_0x5bfe94&&(_0x57d53c[wi]=_0x5bfe94),_0x5b20b6&&(_0x57d53c[_o]=_0x5b20b6),vo(_0x337e9d,go,_0x57d53c);}['open'](_0x16e7af,_0x42126f){this['onDisconnect']=_0x42126f,this['onMessage']=_0x16e7af,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x5ddf9f;_c(),this['mySock']=new gn(this['connURL'],[],_0x5ddf9f);}catch(_0x3bce06){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x338b10=_0x3bce06['message']||_0x3bce06['data'];_0x338b10&&this['log_'](_0x338b10),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x347736=>{this['handleIncomingFrame'](_0x347736);},this['mySock']['onerror']=_0x4c82a8=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x16ca33=_0x4c82a8['message']||_0x4c82a8['data'];_0x16ca33&&this['log_'](_0x16ca33),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x203aed=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2687a1=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x47e7e1=navigator['userAgent']['match'](_0x2687a1);_0x47e7e1&&_0x47e7e1['length']>0x1&&parseFloat(_0x47e7e1[0x1])<4.4&&(_0x203aed=!0x0);}return!_0x203aed&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x3ab402){if(this['frames']['push'](_0x3ab402),this['frames']['length']===this['totalFrames']){const _0x3a8e82=this['frames']['join']('');this['frames']=null;const _0x3db57a=Nt(_0x3a8e82);this['onMessage'](_0x3db57a);}}['handleNewFrameCount_'](_0x233f9e){this['totalFrames']=_0x233f9e,this['frames']=[];}['extractFrameCount_'](_0x44025d){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x44025d['length']<=0x6){const _0x6fabda=Number(_0x44025d);if(!isNaN(_0x6fabda))return this['handleNewFrameCount_'](_0x6fabda),null;}return this['handleNewFrameCount_'](0x1),_0x44025d;}['handleIncomingFrame'](_0x2d7ef4){if(this['mySock']===null)return;const _0x5bd43b=_0x2d7ef4['data'];if(this['bytesReceived']+=_0x5bd43b['length'],this['stats_']['incrementCounter']('bytes_received',_0x5bd43b['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x5bd43b);else{const _0x26920c=this['extractFrameCount_'](_0x5bd43b);_0x26920c!==null&&this['appendFrame_'](_0x26920c);}}['send'](_0x330ff1){this['resetKeepAlive']();const _0x30417a=O(_0x330ff1);this['bytesSent']+=_0x30417a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x30417a['length']);const _0x540765=oo(_0x30417a,gh);_0x540765['length']>0x1&&this['sendString_'](String(_0x540765['length']));for(let _0x59b5c2=0x0;_0x59b5c2<_0x540765['length'];_0x59b5c2++)this['sendString_'](_0x540765[_0x59b5c2]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x3447bf){try{this['mySock']['send'](_0x3447bf);}catch(_0x4701e8){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4701e8['message']||_0x4701e8['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x596ed8){this['initTransports_'](_0x596ed8);}['initTransports_'](_0xdc424a){const _0x936f2e=q&&q['isAvailable']();let _0x348857=_0x936f2e&&!q['previouslyFailed']();if(_0xdc424a['webSocketOnly']&&(_0x936f2e||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x348857=!0x0),_0x348857)this['transports_']=[q];else{const _0x17c25a=this['transports_']=[];for(const _0x4a7d34 of Dt['ALL_TRANSPORTS'])_0x4a7d34&&_0x4a7d34['isAvailable']()&&_0x17c25a['push'](_0x4a7d34);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x132047,_0x34556d,_0x348eb1,_0x2693b8,_0x1d1393,_0x18f916,_0x6c0c4e,_0x482655,_0x59aa37,_0x2dbfd8){this['id']=_0x132047,this['repoInfo_']=_0x34556d,this['applicationId_']=_0x348eb1,this['appCheckToken_']=_0x2693b8,this['authToken_']=_0x1d1393,this['onMessage_']=_0x18f916,this['onReady_']=_0x6c0c4e,this['onDisconnect_']=_0x482655,this['onKill_']=_0x59aa37,this['lastSessionId']=_0x2dbfd8,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x34556d),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2d718c=this['transportManager_']['initialTransport']();this['conn_']=new _0x2d718c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2d718c['responsesRequiredToBeHealthy']||0x0;const _0x575fa2=this['connReceiver_'](this['conn_']),_0x1b83b9=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x575fa2,_0x1b83b9);},Math['floor'](0x0));const _0x31fb2e=_0x2d718c['healthyTimeout']||0x0;_0x31fb2e>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x31fb2e)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x3321d9){return _0x586f72=>{_0x3321d9===this['conn_']?this['onConnectionLost_'](_0x586f72):_0x3321d9===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3a3c6f){return _0x4777db=>{this['state_']!==0x2&&(_0x3a3c6f===this['rx_']?this['onPrimaryMessageReceived_'](_0x4777db):_0x3a3c6f===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4777db):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1e9f5c){const _0x45cbd1={'t':'d','d':_0x1e9f5c};this['sendData_'](_0x45cbd1);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x40c256){if(ci in _0x40c256){const _0x22d32f=_0x40c256[ci];_0x22d32f===Ys?this['upgradeIfSecondaryHealthy_']():_0x22d32f===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x22d32f===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x4a4a9b){const _0x3a9032=vt('t',_0x4a4a9b),_0x47001d=vt('d',_0x4a4a9b);if(_0x3a9032==='c')this['onSecondaryControl_'](_0x47001d);else{if(_0x3a9032==='d')this['pendingDataMessages']['push'](_0x47001d);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3a9032);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x363493){const _0x53214e=vt('t',_0x363493),_0x1e5812=vt('d',_0x363493);_0x53214e==='c'?this['onControl_'](_0x1e5812):_0x53214e==='d'&&this['onDataMessage_'](_0x1e5812);}['onDataMessage_'](_0x14982e){this['onPrimaryResponse_'](),this['onMessage_'](_0x14982e);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x502291){const _0x195677=vt(ci,_0x502291);if(zs in _0x502291){const _0x5f2e3d=_0x502291[zs];if(_0x195677===Th){const _0x2e0bc2={..._0x5f2e3d};this['repoInfo_']['isUsingEmulator']&&(_0x2e0bc2['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x2e0bc2);}else{if(_0x195677===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2d90e6=0x0;_0x2d90e6<this['pendingDataMessages']['length'];++_0x2d90e6)this['onDataMessage_'](this['pendingDataMessages'][_0x2d90e6]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x195677===wh?this['onConnectionShutdown_'](_0x5f2e3d):_0x195677===js?this['onReset_'](_0x5f2e3d):_0x195677===Ch?Ii('Server\x20Error:\x20'+_0x5f2e3d):_0x195677===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x195677);}}}['onHandshake_'](_0x4dc809){const _0xb2be1c=_0x4dc809['ts'],_0x4676b2=_0x4dc809['v'],_0x5c1c86=_0x4dc809['h'];this['sessionId']=_0x4dc809['s'],this['repoInfo_']['host']=_0x5c1c86,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xb2be1c),Gi!==_0x4676b2&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2e7bec=this['transportManager_']['upgradeTransport']();_0x2e7bec&&this['startUpgrade_'](_0x2e7bec);}['startUpgrade_'](_0x112565){this['secondaryConn_']=new _0x112565(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x112565['responsesRequiredToBeHealthy']||0x0;const _0x44c52d=this['connReceiver_'](this['secondaryConn_']),_0x58df3c=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x44c52d,_0x58df3c),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x54b212){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x54b212),this['repoInfo_']['host']=_0x54b212,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x56ced2,_0x5f57a5){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x56ced2,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x5f57a5,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x24445a=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x24445a||this['rx_']===_0x24445a)&&this['close']();}['onConnectionLost_'](_0x2c66f9){this['conn_']=null,!_0x2c66f9&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5431e5){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5431e5),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x515b3b){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x515b3b);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x393362,_0x2e6ed4,_0x59d91b,_0x41a803){}['merge'](_0x2201f1,_0x11cd1f,_0x297a3f,_0x209349){}['refreshAuthToken'](_0x1b197b){}['refreshAppCheckToken'](_0x2381b4){}['onDisconnectPut'](_0x247073,_0x24a203,_0xf4a081){}['onDisconnectMerge'](_0xc59341,_0x3618ab,_0x45bc57){}['onDisconnectCancel'](_0x31c491,_0x35a69f){}['reportStats'](_0x57d5f3){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x4c47f0){this['allowedEvents_']=_0x4c47f0,this['listeners_']={},f(Array['isArray'](_0x4c47f0)&&_0x4c47f0['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x172f48,..._0x45867d){if(Array['isArray'](this['listeners_'][_0x172f48])){const _0x2adf3b=[...this['listeners_'][_0x172f48]];for(let _0x1c417e=0x0;_0x1c417e<_0x2adf3b['length'];_0x1c417e++)_0x2adf3b[_0x1c417e]['callback']['apply'](_0x2adf3b[_0x1c417e]['context'],_0x45867d);}}['on'](_0x1b3fb3,_0x26b265,_0x540125){this['validateEventType_'](_0x1b3fb3),this['listeners_'][_0x1b3fb3]=this['listeners_'][_0x1b3fb3]||[],this['listeners_'][_0x1b3fb3]['push']({'callback':_0x26b265,'context':_0x540125});const _0x3d0c90=this['getInitialEvent'](_0x1b3fb3);_0x3d0c90&&_0x26b265['apply'](_0x540125,_0x3d0c90);}['off'](_0x4165be,_0x4aac8d,_0x208d76){this['validateEventType_'](_0x4165be);const _0x58db78=this['listeners_'][_0x4165be]||[];for(let _0x3617e1=0x0;_0x3617e1<_0x58db78['length'];_0x3617e1++)if(_0x58db78[_0x3617e1]['callback']===_0x4aac8d&&(!_0x208d76||_0x208d76===_0x58db78[_0x3617e1]['context'])){_0x58db78['splice'](_0x3617e1,0x1);return;}}['validateEventType_'](_0x599b6){f(this['allowedEvents_']['find'](_0x4843e4=>_0x4843e4===_0x599b6),'Unknown\x20event:\x20'+_0x599b6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1e12e0){return f(_0x1e12e0==='online','Unknown\x20event\x20type:\x20'+_0x1e12e0),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0xb1348f,_0x2e876c){if(_0x2e876c===void 0x0){this['pieces_']=_0xb1348f['split']('/');let _0xf25c32=0x0;for(let _0x2c6473=0x0;_0x2c6473<this['pieces_']['length'];_0x2c6473++)this['pieces_'][_0x2c6473]['length']>0x0&&(this['pieces_'][_0xf25c32]=this['pieces_'][_0x2c6473],_0xf25c32++);this['pieces_']['length']=_0xf25c32,this['pieceNum_']=0x0;}else this['pieces_']=_0xb1348f,this['pieceNum_']=_0x2e876c;}['toString'](){let _0x5877b3='';for(let _0x146456=this['pieceNum_'];_0x146456<this['pieces_']['length'];_0x146456++)this['pieces_'][_0x146456]!==''&&(_0x5877b3+='/'+this['pieces_'][_0x146456]);return _0x5877b3||'/';}}function w(){return new C('');}function y(_0x165f90){return _0x165f90['pieceNum_']>=_0x165f90['pieces_']['length']?null:_0x165f90['pieces_'][_0x165f90['pieceNum_']];}function Ce(_0x166034){return _0x166034['pieces_']['length']-_0x166034['pieceNum_'];}function S(_0x1c7329){let _0x219708=_0x1c7329['pieceNum_'];return _0x219708<_0x1c7329['pieces_']['length']&&_0x219708++,new C(_0x1c7329['pieces_'],_0x219708);}function ji(_0x1011dc){return _0x1011dc['pieceNum_']<_0x1011dc['pieces_']['length']?_0x1011dc['pieces_'][_0x1011dc['pieces_']['length']-0x1]:null;}function bh(_0x6a5364){let _0xee90ce='';for(let _0x161dd6=_0x6a5364['pieceNum_'];_0x161dd6<_0x6a5364['pieces_']['length'];_0x161dd6++)_0x6a5364['pieces_'][_0x161dd6]!==''&&(_0xee90ce+='/'+encodeURIComponent(String(_0x6a5364['pieces_'][_0x161dd6])));return _0xee90ce||'/';}function Mt(_0x4ae05c,_0x3ea1fd=0x0){return _0x4ae05c['pieces_']['slice'](_0x4ae05c['pieceNum_']+_0x3ea1fd);}function Ro(_0x5364bd){if(_0x5364bd['pieceNum_']>=_0x5364bd['pieces_']['length'])return null;const _0x1d0b6a=[];for(let _0x27ccd8=_0x5364bd['pieceNum_'];_0x27ccd8<_0x5364bd['pieces_']['length']-0x1;_0x27ccd8++)_0x1d0b6a['push'](_0x5364bd['pieces_'][_0x27ccd8]);return new C(_0x1d0b6a,0x0);}function k(_0x3ff0d7,_0x3012ef){const _0x4331b3=[];for(let _0x4a2a04=_0x3ff0d7['pieceNum_'];_0x4a2a04<_0x3ff0d7['pieces_']['length'];_0x4a2a04++)_0x4331b3['push'](_0x3ff0d7['pieces_'][_0x4a2a04]);if(_0x3012ef instanceof C){for(let _0x1388c4=_0x3012ef['pieceNum_'];_0x1388c4<_0x3012ef['pieces_']['length'];_0x1388c4++)_0x4331b3['push'](_0x3012ef['pieces_'][_0x1388c4]);}else{const _0x445c8d=_0x3012ef['split']('/');for(let _0x488e81=0x0;_0x488e81<_0x445c8d['length'];_0x488e81++)_0x445c8d[_0x488e81]['length']>0x0&&_0x4331b3['push'](_0x445c8d[_0x488e81]);}return new C(_0x4331b3,0x0);}function v(_0x425bae){return _0x425bae['pieceNum_']>=_0x425bae['pieces_']['length'];}function F(_0x2896c9,_0x5090f2){const _0x14a4ee=y(_0x2896c9),_0x178695=y(_0x5090f2);if(_0x14a4ee===null)return _0x5090f2;if(_0x14a4ee===_0x178695)return F(S(_0x2896c9),S(_0x5090f2));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5090f2+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2896c9+')');}function Rh(_0x5d6888,_0x59dfc9){const _0x342e36=Mt(_0x5d6888,0x0),_0x2b690d=Mt(_0x59dfc9,0x0);for(let _0x2d4b73=0x0;_0x2d4b73<_0x342e36['length']&&_0x2d4b73<_0x2b690d['length'];_0x2d4b73++){const _0x12dc47=qe(_0x342e36[_0x2d4b73],_0x2b690d[_0x2d4b73]);if(_0x12dc47!==0x0)return _0x12dc47;}return _0x342e36['length']===_0x2b690d['length']?0x0:_0x342e36['length']<_0x2b690d['length']?-0x1:0x1;}function Ki(_0x3df178,_0x2b3a49){if(Ce(_0x3df178)!==Ce(_0x2b3a49))return!0x1;for(let _0x2d9092=_0x3df178['pieceNum_'],_0x28c49b=_0x2b3a49['pieceNum_'];_0x2d9092<=_0x3df178['pieces_']['length'];_0x2d9092++,_0x28c49b++)if(_0x3df178['pieces_'][_0x2d9092]!==_0x2b3a49['pieces_'][_0x28c49b])return!0x1;return!0x0;}function G(_0x57a20b,_0x28e1dd){let _0x2b636f=_0x57a20b['pieceNum_'],_0x54ce16=_0x28e1dd['pieceNum_'];if(Ce(_0x57a20b)>Ce(_0x28e1dd))return!0x1;for(;_0x2b636f<_0x57a20b['pieces_']['length'];){if(_0x57a20b['pieces_'][_0x2b636f]!==_0x28e1dd['pieces_'][_0x54ce16])return!0x1;++_0x2b636f,++_0x54ce16;}return!0x0;}class Ah{constructor(_0x49b323,_0x317c1b){this['errorPrefix_']=_0x317c1b,this['parts_']=Mt(_0x49b323,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x463d61=0x0;_0x463d61<this['parts_']['length'];_0x463d61++)this['byteLength_']+=Ln(this['parts_'][_0x463d61]);Ao(this);}}function kh(_0x5adb8d,_0xf99f28){_0x5adb8d['parts_']['length']>0x0&&(_0x5adb8d['byteLength_']+=0x1),_0x5adb8d['parts_']['push'](_0xf99f28),_0x5adb8d['byteLength_']+=Ln(_0xf99f28),Ao(_0x5adb8d);}function Ph(_0x5415cb){const _0x367f09=_0x5415cb['parts_']['pop']();_0x5415cb['byteLength_']-=Ln(_0x367f09),_0x5415cb['parts_']['length']>0x0&&(_0x5415cb['byteLength_']-=0x1);}function Ao(_0x35c3e6){if(_0x35c3e6['byteLength_']>Zs)throw new Error(_0x35c3e6['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x35c3e6['byteLength_']+').');if(_0x35c3e6['parts_']['length']>Xs)throw new Error(_0x35c3e6['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x35c3e6));}function Oe(_0x469382){return _0x469382['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x469382['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0xf80b56,_0x1f216d;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1f216d='visibilitychange',_0xf80b56='hidden'):typeof document['mozHidden']<'u'?(_0x1f216d='mozvisibilitychange',_0xf80b56='mozHidden'):typeof document['msHidden']<'u'?(_0x1f216d='msvisibilitychange',_0xf80b56='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1f216d='webkitvisibilitychange',_0xf80b56='webkitHidden')),this['visible_']=!0x0,_0x1f216d&&document['addEventListener'](_0x1f216d,()=>{const _0x4ff662=!document[_0xf80b56];_0x4ff662!==this['visible_']&&(this['visible_']=_0x4ff662,this['trigger']('visible',_0x4ff662));},!0x1);}['getInitialEvent'](_0x1905af){return f(_0x1905af==='visible','Unknown\x20event\x20type:\x20'+_0x1905af),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x122dcd,_0x228917,_0x1f94d2,_0x5cb6b1,_0x2fe5b3,_0x2bcdd0,_0x4a64fd,_0x43bc76){if(super(),this['repoInfo_']=_0x122dcd,this['applicationId_']=_0x228917,this['onDataUpdate_']=_0x1f94d2,this['onConnectStatus_']=_0x5cb6b1,this['onServerInfoUpdate_']=_0x2fe5b3,this['authTokenProvider_']=_0x2bcdd0,this['appCheckTokenProvider_']=_0x4a64fd,this['authOverride_']=_0x43bc76,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x43bc76)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x122dcd['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x22c9ed,_0x284289,_0x56df21){const _0x4a2775=++this['requestNumber_'],_0x44a0f4={'r':_0x4a2775,'a':_0x22c9ed,'b':_0x284289};this['log_'](O(_0x44a0f4)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x44a0f4),_0x56df21&&(this['requestCBHash_'][_0x4a2775]=_0x56df21);}['get'](_0x1bba49){this['initConnection_']();const _0xbc0e6d=new H(),_0x4ea55c={'action':'g','request':{'p':_0x1bba49['_path']['toString'](),'q':_0x1bba49['_queryObject']},'onComplete':_0x3edc4e=>{const _0x40c4ce=_0x3edc4e['d'];_0x3edc4e['s']==='ok'?_0xbc0e6d['resolve'](_0x40c4ce):_0xbc0e6d['reject'](_0x40c4ce);}};this['outstandingGets_']['push'](_0x4ea55c),this['outstandingGetCount_']++;const _0x277514=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x277514),_0xbc0e6d['promise'];}['listen'](_0x5b6743,_0x3b5988,_0x16fd50,_0x165243){this['initConnection_']();const _0x8bc81e=_0x5b6743['_queryIdentifier'],_0x28d755=_0x5b6743['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x28d755+'\x20'+_0x8bc81e),this['listens']['has'](_0x28d755)||this['listens']['set'](_0x28d755,new Map()),f(_0x5b6743['_queryParams']['isDefault']()||!_0x5b6743['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x28d755)['has'](_0x8bc81e),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x24c617={'onComplete':_0x165243,'hashFn':_0x3b5988,'query':_0x5b6743,'tag':_0x16fd50};this['listens']['get'](_0x28d755)['set'](_0x8bc81e,_0x24c617),this['connected_']&&this['sendListen_'](_0x24c617);}['sendGet_'](_0x5e4be2){const _0x11131e=this['outstandingGets_'][_0x5e4be2];this['sendRequest']('g',_0x11131e['request'],_0x326a05=>{delete this['outstandingGets_'][_0x5e4be2],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x11131e['onComplete']&&_0x11131e['onComplete'](_0x326a05);});}['sendListen_'](_0x37ab51){const _0x47ba1f=_0x37ab51['query'],_0x469f7f=_0x47ba1f['_path']['toString'](),_0x46fa7e=_0x47ba1f['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x469f7f+'\x20for\x20'+_0x46fa7e);const _0x6c51f3={'p':_0x469f7f},_0x4f6f74='q';_0x37ab51['tag']&&(_0x6c51f3['q']=_0x47ba1f['_queryObject'],_0x6c51f3['t']=_0x37ab51['tag']),_0x6c51f3['h']=_0x37ab51['hashFn'](),this['sendRequest'](_0x4f6f74,_0x6c51f3,_0xfe52b=>{const _0x4d7873=_0xfe52b['d'],_0x500505=_0xfe52b['s'];se['warnOnListenWarnings_'](_0x4d7873,_0x47ba1f),(this['listens']['get'](_0x469f7f)&&this['listens']['get'](_0x469f7f)['get'](_0x46fa7e))===_0x37ab51&&(this['log_']('listen\x20response',_0xfe52b),_0x500505!=='ok'&&this['removeListen_'](_0x469f7f,_0x46fa7e),_0x37ab51['onComplete']&&_0x37ab51['onComplete'](_0x500505,_0x4d7873));});}static['warnOnListenWarnings_'](_0x5e9be6,_0xc36a0f){if(_0x5e9be6&&typeof _0x5e9be6=='object'&&Q(_0x5e9be6,'w')){const _0x3182e5=Le(_0x5e9be6,'w');if(Array['isArray'](_0x3182e5)&&~_0x3182e5['indexOf']('no_index')){const _0x8f41a0='\x22.indexOn\x22:\x20\x22'+_0xc36a0f['_queryParams']['getIndex']()['toString']()+'\x22',_0x88ccbd=_0xc36a0f['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x8f41a0+'\x20at\x20'+_0x88ccbd+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x531c8d){this['authToken_']=_0x531c8d,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x531c8d);}['reduceReconnectDelayIfAdminCredential_'](_0x297e2a){(_0x297e2a&&_0x297e2a['length']===0x28||wc(_0x297e2a))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x480ffe){this['appCheckToken_']=_0x480ffe,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x3ee9cf=this['authToken_'],_0xc8cb41=Ic(_0x3ee9cf)?'auth':'gauth',_0x400d21={'cred':_0x3ee9cf};this['authOverride_']===null?_0x400d21['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x400d21['authvar']=this['authOverride_']),this['sendRequest'](_0xc8cb41,_0x400d21,_0x2137ef=>{const _0x433264=_0x2137ef['s'],_0x124a97=_0x2137ef['d']||'error';this['authToken_']===_0x3ee9cf&&(_0x433264==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x433264,_0x124a97));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5e6c79=>{const _0x57b753=_0x5e6c79['s'],_0x1313ca=_0x5e6c79['d']||'error';_0x57b753==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x57b753,_0x1313ca);});}['unlisten'](_0xa5c100,_0x356398){const _0x6a9b3b=_0xa5c100['_path']['toString'](),_0x28c6ea=_0xa5c100['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x6a9b3b+'\x20'+_0x28c6ea),f(_0xa5c100['_queryParams']['isDefault']()||!_0xa5c100['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x6a9b3b,_0x28c6ea)&&this['connected_']&&this['sendUnlisten_'](_0x6a9b3b,_0x28c6ea,_0xa5c100['_queryObject'],_0x356398);}['sendUnlisten_'](_0x262c44,_0x2934c3,_0x2fea5c,_0x3c7b87){this['log_']('Unlisten\x20on\x20'+_0x262c44+'\x20for\x20'+_0x2934c3);const _0x6ab25c={'p':_0x262c44},_0x6f1b8c='n';_0x3c7b87&&(_0x6ab25c['q']=_0x2fea5c,_0x6ab25c['t']=_0x3c7b87),this['sendRequest'](_0x6f1b8c,_0x6ab25c);}['onDisconnectPut'](_0x4b3ed2,_0x370259,_0x3a8a14){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4b3ed2,_0x370259,_0x3a8a14):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4b3ed2,'action':'o','data':_0x370259,'onComplete':_0x3a8a14});}['onDisconnectMerge'](_0xb75f98,_0x2b73be,_0xc73262){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0xb75f98,_0x2b73be,_0xc73262):this['onDisconnectRequestQueue_']['push']({'pathString':_0xb75f98,'action':'om','data':_0x2b73be,'onComplete':_0xc73262});}['onDisconnectCancel'](_0x47d106,_0x4c920c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x47d106,null,_0x4c920c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x47d106,'action':'oc','data':null,'onComplete':_0x4c920c});}['sendOnDisconnect_'](_0x56e07f,_0x1ac3e2,_0x4df5ed,_0x27956b){const _0x7abe11={'p':_0x1ac3e2,'d':_0x4df5ed};this['log_']('onDisconnect\x20'+_0x56e07f,_0x7abe11),this['sendRequest'](_0x56e07f,_0x7abe11,_0x3c8c2a=>{_0x27956b&&setTimeout(()=>{_0x27956b(_0x3c8c2a['s'],_0x3c8c2a['d']);},Math['floor'](0x0));});}['put'](_0xf933b8,_0x13cb84,_0xd7e5b,_0x12a156){this['putInternal']('p',_0xf933b8,_0x13cb84,_0xd7e5b,_0x12a156);}['merge'](_0xae1afb,_0x29c680,_0x4ece2a,_0x4364ec){this['putInternal']('m',_0xae1afb,_0x29c680,_0x4ece2a,_0x4364ec);}['putInternal'](_0x354b80,_0x1cb430,_0x40da88,_0x38740c,_0xf08c60){this['initConnection_']();const _0x2918a1={'p':_0x1cb430,'d':_0x40da88};_0xf08c60!==void 0x0&&(_0x2918a1['h']=_0xf08c60),this['outstandingPuts_']['push']({'action':_0x354b80,'request':_0x2918a1,'onComplete':_0x38740c}),this['outstandingPutCount_']++;const _0x542708=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x542708):this['log_']('Buffering\x20put:\x20'+_0x1cb430);}['sendPut_'](_0x4df365){const _0x23f527=this['outstandingPuts_'][_0x4df365]['action'],_0x28b77d=this['outstandingPuts_'][_0x4df365]['request'],_0x293cee=this['outstandingPuts_'][_0x4df365]['onComplete'];this['outstandingPuts_'][_0x4df365]['queued']=this['connected_'],this['sendRequest'](_0x23f527,_0x28b77d,_0x4027c6=>{this['log_'](_0x23f527+'\x20response',_0x4027c6),delete this['outstandingPuts_'][_0x4df365],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x293cee&&_0x293cee(_0x4027c6['s'],_0x4027c6['d']);});}['reportStats'](_0x18e6df){if(this['connected_']){const _0x4cf48c={'c':_0x18e6df};this['log_']('reportStats',_0x4cf48c),this['sendRequest']('s',_0x4cf48c,_0x555433=>{if(_0x555433['s']!=='ok'){const _0x30379d=_0x555433['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x30379d);}});}}['onDataMessage_'](_0xc2357e){if('r'in _0xc2357e){this['log_']('from\x20server:\x20'+O(_0xc2357e));const _0x331b87=_0xc2357e['r'],_0x2d58c8=this['requestCBHash_'][_0x331b87];_0x2d58c8&&(delete this['requestCBHash_'][_0x331b87],_0x2d58c8(_0xc2357e['b']));}else{if('error'in _0xc2357e)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xc2357e['error'];'a'in _0xc2357e&&this['onDataPush_'](_0xc2357e['a'],_0xc2357e['b']);}}['onDataPush_'](_0x4c0c50,_0x56b95c){this['log_']('handleServerMessage',_0x4c0c50,_0x56b95c),_0x4c0c50==='d'?this['onDataUpdate_'](_0x56b95c['p'],_0x56b95c['d'],!0x1,_0x56b95c['t']):_0x4c0c50==='m'?this['onDataUpdate_'](_0x56b95c['p'],_0x56b95c['d'],!0x0,_0x56b95c['t']):_0x4c0c50==='c'?this['onListenRevoked_'](_0x56b95c['p'],_0x56b95c['q']):_0x4c0c50==='ac'?this['onAuthRevoked_'](_0x56b95c['s'],_0x56b95c['d']):_0x4c0c50==='apc'?this['onAppCheckRevoked_'](_0x56b95c['s'],_0x56b95c['d']):_0x4c0c50==='sd'?this['onSecurityDebugPacket_'](_0x56b95c):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x4c0c50)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x24aec3,_0x5f0d7c){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x24aec3),this['lastSessionId']=_0x5f0d7c,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x1a03a9){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x1a03a9));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1345c3){_0x1345c3&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1345c3;}['onOnline_'](_0x363dc1){_0x363dc1?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x431e24=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x284135=Math['max'](0x0,this['reconnectDelay_']-_0x431e24);_0x284135=Math['random']()*_0x284135,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x284135+'ms'),this['scheduleConnect_'](_0x284135),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x13bb3d=this['onDataMessage_']['bind'](this),_0x4c28cf=this['onReady_']['bind'](this),_0x25a0b5=this['onRealtimeDisconnect_']['bind'](this),_0xc7e80=this['id']+':'+se['nextConnectionId_']++,_0x5b6429=this['lastSessionId'];let _0x287464=!0x1,_0x56e243=null;const _0xcd75e2=function(){_0x56e243?_0x56e243['close']():(_0x287464=!0x0,_0x25a0b5());},_0x452f80=function(_0x478838){f(_0x56e243,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x56e243['sendRequest'](_0x478838);};this['realtime_']={'close':_0xcd75e2,'sendRequest':_0x452f80};const _0x5e74aa=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x409e39,_0x4e81cb]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x5e74aa),this['appCheckTokenProvider_']['getToken'](_0x5e74aa)]);_0x287464?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x409e39&&_0x409e39['accessToken'],this['appCheckToken_']=_0x4e81cb&&_0x4e81cb['token'],_0x56e243=new Sh(_0xc7e80,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x13bb3d,_0x4c28cf,_0x25a0b5,_0x1e755e=>{U(_0x1e755e+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x5b6429));}catch(_0x322d26){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x322d26),_0x287464||(this['repoInfo_']['nodeAdmin']&&U(_0x322d26),_0xcd75e2());}}}['interrupt'](_0x448fc3){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x448fc3),this['interruptReasons_'][_0x448fc3]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x34c3e7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x34c3e7),delete this['interruptReasons_'][_0x34c3e7],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x42d6c7){const _0x5f095d=_0x42d6c7-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5f095d});}['cancelSentTransactions_'](){for(let _0x2bf0eb=0x0;_0x2bf0eb<this['outstandingPuts_']['length'];_0x2bf0eb++){const _0x46bc1e=this['outstandingPuts_'][_0x2bf0eb];_0x46bc1e&&'h'in _0x46bc1e['request']&&_0x46bc1e['queued']&&(_0x46bc1e['onComplete']&&_0x46bc1e['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2bf0eb],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xa41d29,_0x55527c){let _0x22cf43;_0x55527c?_0x22cf43=_0x55527c['map'](_0x540baa=>$i(_0x540baa))['join']('$'):_0x22cf43='default';const _0x126332=this['removeListen_'](_0xa41d29,_0x22cf43);_0x126332&&_0x126332['onComplete']&&_0x126332['onComplete']('permission_denied');}['removeListen_'](_0x28b293,_0x55e91c){const _0x345c8d=new C(_0x28b293)['toString']();let _0x2dfd42;if(this['listens']['has'](_0x345c8d)){const _0xfcf6f0=this['listens']['get'](_0x345c8d);_0x2dfd42=_0xfcf6f0['get'](_0x55e91c),_0xfcf6f0['delete'](_0x55e91c),_0xfcf6f0['size']===0x0&&this['listens']['delete'](_0x345c8d);}else _0x2dfd42=void 0x0;return _0x2dfd42;}['onAuthRevoked_'](_0x669797,_0x245a88){L('Auth\x20token\x20revoked:\x20'+_0x669797+'/'+_0x245a88),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x669797==='invalid_token'||_0x669797==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5ec926,_0x570c1a){L('App\x20check\x20token\x20revoked:\x20'+_0x5ec926+'/'+_0x570c1a),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5ec926==='invalid_token'||_0x5ec926==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x551bf1){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x551bf1):'msg'in _0x551bf1&&console['log']('FIREBASE:\x20'+_0x551bf1['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0xc83ffb of this['listens']['values']())for(const _0x2ce4cf of _0xc83ffb['values']())this['sendListen_'](_0x2ce4cf);for(let _0x6ba12b=0x0;_0x6ba12b<this['outstandingPuts_']['length'];_0x6ba12b++)this['outstandingPuts_'][_0x6ba12b]&&this['sendPut_'](_0x6ba12b);for(;this['onDisconnectRequestQueue_']['length'];){const _0x301160=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x301160['action'],_0x301160['pathString'],_0x301160['data'],_0x301160['onComplete']);}for(let _0x2fa684=0x0;_0x2fa684<this['outstandingGets_']['length'];_0x2fa684++)this['outstandingGets_'][_0x2fa684]&&this['sendGet_'](_0x2fa684);}['sendConnectStats_'](){const _0x259693={};let _0x424d5a='js';_0x259693['sdk.'+_0x424d5a+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x259693['framework.cordova']=0x1:Kr()&&(_0x259693['framework.reactnative']=0x1),this['reportStats'](_0x259693);}['shouldReconnect_'](){const _0x38f0d3=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x38f0d3;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x259e6f,_0x193550){this['name']=_0x259e6f,this['node']=_0x193550;}static['Wrap'](_0x3d70f3,_0xe08276){return new E(_0x3d70f3,_0xe08276);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1d8aa5,_0x166336){const _0x174834=new E(We,_0x1d8aa5),_0x224149=new E(We,_0x166336);return this['compare'](_0x174834,_0x224149)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x5d2368){sn=_0x5d2368;}['compare'](_0x23c21f,_0xdd3e6a){return qe(_0x23c21f['name'],_0xdd3e6a['name']);}['isDefinedOn'](_0x173b0b){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x377052,_0x37d79a){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x4d53a8,_0x4a3de5){return f(typeof _0x4d53a8=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4d53a8,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x8488b3,_0x51b96a,_0x5e30c4,_0x17a8d3,_0x50afdf=null){this['isReverse_']=_0x17a8d3,this['resultGenerator_']=_0x50afdf,this['nodeStack_']=[];let _0x131289=0x1;for(;!_0x8488b3['isEmpty']();)if(_0x8488b3=_0x8488b3,_0x131289=_0x51b96a?_0x5e30c4(_0x8488b3['key'],_0x51b96a):0x1,_0x17a8d3&&(_0x131289*=-0x1),_0x131289<0x0)this['isReverse_']?_0x8488b3=_0x8488b3['left']:_0x8488b3=_0x8488b3['right'];else{if(_0x131289===0x0){this['nodeStack_']['push'](_0x8488b3);break;}else this['nodeStack_']['push'](_0x8488b3),this['isReverse_']?_0x8488b3=_0x8488b3['right']:_0x8488b3=_0x8488b3['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x457694=this['nodeStack_']['pop'](),_0x42c830;if(this['resultGenerator_']?_0x42c830=this['resultGenerator_'](_0x457694['key'],_0x457694['value']):_0x42c830={'key':_0x457694['key'],'value':_0x457694['value']},this['isReverse_']){for(_0x457694=_0x457694['left'];!_0x457694['isEmpty']();)this['nodeStack_']['push'](_0x457694),_0x457694=_0x457694['right'];}else{for(_0x457694=_0x457694['right'];!_0x457694['isEmpty']();)this['nodeStack_']['push'](_0x457694),_0x457694=_0x457694['left'];}return _0x42c830;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x381027=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x381027['key'],_0x381027['value']):{'key':_0x381027['key'],'value':_0x381027['value']};}}class M{constructor(_0x13f3cd,_0x41c785,_0x5618c7,_0x1cd213,_0x393b07){this['key']=_0x13f3cd,this['value']=_0x41c785,this['color']=_0x5618c7??M['RED'],this['left']=_0x1cd213??B['EMPTY_NODE'],this['right']=_0x393b07??B['EMPTY_NODE'];}['copy'](_0x15f031,_0x2b2a40,_0x526da4,_0x592091,_0x355058){return new M(_0x15f031??this['key'],_0x2b2a40??this['value'],_0x526da4??this['color'],_0x592091??this['left'],_0x355058??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x476465){return this['left']['inorderTraversal'](_0x476465)||!!_0x476465(this['key'],this['value'])||this['right']['inorderTraversal'](_0x476465);}['reverseTraversal'](_0x253efd){return this['right']['reverseTraversal'](_0x253efd)||_0x253efd(this['key'],this['value'])||this['left']['reverseTraversal'](_0x253efd);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4341a2,_0x212099,_0xf41960){let _0x5f201c=this;const _0x3fe21c=_0xf41960(_0x4341a2,_0x5f201c['key']);return _0x3fe21c<0x0?_0x5f201c=_0x5f201c['copy'](null,null,null,_0x5f201c['left']['insert'](_0x4341a2,_0x212099,_0xf41960),null):_0x3fe21c===0x0?_0x5f201c=_0x5f201c['copy'](null,_0x212099,null,null,null):_0x5f201c=_0x5f201c['copy'](null,null,null,null,_0x5f201c['right']['insert'](_0x4341a2,_0x212099,_0xf41960)),_0x5f201c['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x554f0f=this;return!_0x554f0f['left']['isRed_']()&&!_0x554f0f['left']['left']['isRed_']()&&(_0x554f0f=_0x554f0f['moveRedLeft_']()),_0x554f0f=_0x554f0f['copy'](null,null,null,_0x554f0f['left']['removeMin_'](),null),_0x554f0f['fixUp_']();}['remove'](_0x55194c,_0x1da891){let _0x2b2327,_0x1579a6;if(_0x2b2327=this,_0x1da891(_0x55194c,_0x2b2327['key'])<0x0)!_0x2b2327['left']['isEmpty']()&&!_0x2b2327['left']['isRed_']()&&!_0x2b2327['left']['left']['isRed_']()&&(_0x2b2327=_0x2b2327['moveRedLeft_']()),_0x2b2327=_0x2b2327['copy'](null,null,null,_0x2b2327['left']['remove'](_0x55194c,_0x1da891),null);else{if(_0x2b2327['left']['isRed_']()&&(_0x2b2327=_0x2b2327['rotateRight_']()),!_0x2b2327['right']['isEmpty']()&&!_0x2b2327['right']['isRed_']()&&!_0x2b2327['right']['left']['isRed_']()&&(_0x2b2327=_0x2b2327['moveRedRight_']()),_0x1da891(_0x55194c,_0x2b2327['key'])===0x0){if(_0x2b2327['right']['isEmpty']())return B['EMPTY_NODE'];_0x1579a6=_0x2b2327['right']['min_'](),_0x2b2327=_0x2b2327['copy'](_0x1579a6['key'],_0x1579a6['value'],null,null,_0x2b2327['right']['removeMin_']());}_0x2b2327=_0x2b2327['copy'](null,null,null,null,_0x2b2327['right']['remove'](_0x55194c,_0x1da891));}return _0x2b2327['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x176365=this;return _0x176365['right']['isRed_']()&&!_0x176365['left']['isRed_']()&&(_0x176365=_0x176365['rotateLeft_']()),_0x176365['left']['isRed_']()&&_0x176365['left']['left']['isRed_']()&&(_0x176365=_0x176365['rotateRight_']()),_0x176365['left']['isRed_']()&&_0x176365['right']['isRed_']()&&(_0x176365=_0x176365['colorFlip_']()),_0x176365;}['moveRedLeft_'](){let _0x2ee5fd=this['colorFlip_']();return _0x2ee5fd['right']['left']['isRed_']()&&(_0x2ee5fd=_0x2ee5fd['copy'](null,null,null,null,_0x2ee5fd['right']['rotateRight_']()),_0x2ee5fd=_0x2ee5fd['rotateLeft_'](),_0x2ee5fd=_0x2ee5fd['colorFlip_']()),_0x2ee5fd;}['moveRedRight_'](){let _0x30048d=this['colorFlip_']();return _0x30048d['left']['left']['isRed_']()&&(_0x30048d=_0x30048d['rotateRight_'](),_0x30048d=_0x30048d['colorFlip_']()),_0x30048d;}['rotateLeft_'](){const _0x549239=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x549239,null);}['rotateRight_'](){const _0x5e3cf1=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5e3cf1);}['colorFlip_'](){const _0x1e9638=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x1fc4a1=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1e9638,_0x1fc4a1);}['checkMaxDepth_'](){const _0x95024f=this['check_']();return Math['pow'](0x2,_0x95024f)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x459c06=this['left']['check_']();if(_0x459c06!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x459c06+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x868b56,_0x2c1b80,_0x1a8bf2,_0x287402,_0x511df7){return this;}['insert'](_0x1f580c,_0x164b81,_0x35f5ce){return new M(_0x1f580c,_0x164b81,null);}['remove'](_0xbd420b,_0x23475f){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4bb216){return!0x1;}['reverseTraversal'](_0x2e1e7a){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4d2586,_0x774603=B['EMPTY_NODE']){this['comparator_']=_0x4d2586,this['root_']=_0x774603;}['insert'](_0x2d277b,_0x3f28d8){return new B(this['comparator_'],this['root_']['insert'](_0x2d277b,_0x3f28d8,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x417f77){return new B(this['comparator_'],this['root_']['remove'](_0x417f77,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x15bfce){let _0x4684db,_0x741b9e=this['root_'];for(;!_0x741b9e['isEmpty']();){if(_0x4684db=this['comparator_'](_0x15bfce,_0x741b9e['key']),_0x4684db===0x0)return _0x741b9e['value'];_0x4684db<0x0?_0x741b9e=_0x741b9e['left']:_0x4684db>0x0&&(_0x741b9e=_0x741b9e['right']);}return null;}['getPredecessorKey'](_0x4a8300){let _0xdfe4f,_0x28e886=this['root_'],_0x38e554=null;for(;!_0x28e886['isEmpty']();)if(_0xdfe4f=this['comparator_'](_0x4a8300,_0x28e886['key']),_0xdfe4f===0x0){if(_0x28e886['left']['isEmpty']())return _0x38e554?_0x38e554['key']:null;for(_0x28e886=_0x28e886['left'];!_0x28e886['right']['isEmpty']();)_0x28e886=_0x28e886['right'];return _0x28e886['key'];}else _0xdfe4f<0x0?_0x28e886=_0x28e886['left']:_0xdfe4f>0x0&&(_0x38e554=_0x28e886,_0x28e886=_0x28e886['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x4c9101){return this['root_']['inorderTraversal'](_0x4c9101);}['reverseTraversal'](_0x5dba5e){return this['root_']['reverseTraversal'](_0x5dba5e);}['getIterator'](_0x286081){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x286081);}['getIteratorFrom'](_0x4520ab,_0x560b54){return new rn(this['root_'],_0x4520ab,this['comparator_'],!0x1,_0x560b54);}['getReverseIteratorFrom'](_0x4c8b92,_0x10b87d){return new rn(this['root_'],_0x4c8b92,this['comparator_'],!0x0,_0x10b87d);}['getReverseIterator'](_0x4f3948){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x4f3948);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x389afe,_0xec71bc){return qe(_0x389afe['name'],_0xec71bc['name']);}function Qi(_0x3e5351,_0x22246a){return qe(_0x3e5351,_0x22246a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x2199c4){Ci=_0x2199c4;}const Po=function(_0x4497e5){return typeof _0x4497e5=='number'?'number:'+ao(_0x4497e5):'string:'+_0x4497e5;},No=function(_0x77760b){if(_0x77760b['isLeafNode']()){const _0x3916e4=_0x77760b['val']();f(typeof _0x3916e4=='string'||typeof _0x3916e4=='number'||typeof _0x3916e4=='object'&&Q(_0x3916e4,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x77760b===Ci||_0x77760b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x77760b===Ci||_0x77760b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x40cdf6){nr=_0x40cdf6;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x2d85f9,_0x315884=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2d85f9,this['priorityNode_']=_0x315884,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x179f2b){return new D(this['value_'],_0x179f2b);}['getImmediateChild'](_0x4fa51b){return _0x4fa51b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4b9201){return v(_0x4b9201)?this:y(_0x4b9201)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x12cde2,_0x56a344){return null;}['updateImmediateChild'](_0x5ab9b5,_0x4817f7){return _0x5ab9b5==='.priority'?this['updatePriority'](_0x4817f7):_0x4817f7['isEmpty']()&&_0x5ab9b5!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5ab9b5,_0x4817f7)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3c2527,_0x4280b8){const _0x40fcc9=y(_0x3c2527);return _0x40fcc9===null?_0x4280b8:_0x4280b8['isEmpty']()&&_0x40fcc9!=='.priority'?this:(f(_0x40fcc9!=='.priority'||Ce(_0x3c2527)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x40fcc9,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x3c2527),_0x4280b8)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x50a343,_0x2a674d){return!0x1;}['val'](_0x3646ac){return _0x3646ac&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xa7048b='';this['priorityNode_']['isEmpty']()||(_0xa7048b+='priority:'+Po(this['priorityNode_']['val']())+':');const _0xc73f4b=typeof this['value_'];_0xa7048b+=_0xc73f4b+':',_0xc73f4b==='number'?_0xa7048b+=ao(this['value_']):_0xa7048b+=this['value_'],this['lazyHash_']=ro(_0xa7048b);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x42623c){return _0x42623c===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x42623c instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x42623c['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x42623c));}['compareToLeafNode_'](_0x2d27c4){const _0x28c49f=typeof _0x2d27c4['value_'],_0xd8164d=typeof this['value_'],_0x5d2018=D['VALUE_TYPE_ORDER']['indexOf'](_0x28c49f),_0x1bc643=D['VALUE_TYPE_ORDER']['indexOf'](_0xd8164d);return f(_0x5d2018>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x28c49f),f(_0x1bc643>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xd8164d),_0x5d2018===_0x1bc643?_0xd8164d==='object'?0x0:this['value_']<_0x2d27c4['value_']?-0x1:this['value_']===_0x2d27c4['value_']?0x0:0x1:_0x1bc643-_0x5d2018;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x576cec){if(_0x576cec===this)return!0x0;if(_0x576cec['isLeafNode']()){const _0x44bdfd=_0x576cec;return this['value_']===_0x44bdfd['value_']&&this['priorityNode_']['equals'](_0x44bdfd['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x337f09){Oo=_0x337f09;}function Wh(_0x16091b){Do=_0x16091b;}class Bh extends Fn{['compare'](_0x145d55,_0x34b4e4){const _0x2a8fc9=_0x145d55['node']['getPriority'](),_0x13d1a1=_0x34b4e4['node']['getPriority'](),_0x10277e=_0x2a8fc9['compareTo'](_0x13d1a1);return _0x10277e===0x0?qe(_0x145d55['name'],_0x34b4e4['name']):_0x10277e;}['isDefinedOn'](_0x9407cd){return!_0x9407cd['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2b5173,_0x290d99){return!_0x2b5173['getPriority']()['equals'](_0x290d99['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x43379d,_0x1da4a5){const _0x16f24b=Oo(_0x43379d);return new E(_0x1da4a5,new D('[PRIORITY-POST]',_0x16f24b));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3c31f7){const _0x19a263=_0x9ec7cf=>parseInt(Math['log'](_0x9ec7cf)/Vh,0xa),_0x3d6445=_0x1d7516=>parseInt(Array(_0x1d7516+0x1)['join']('1'),0x2);this['count']=_0x19a263(_0x3c31f7+0x1),this['current_']=this['count']-0x1;const _0x17ceea=_0x3d6445(this['count']);this['bits_']=_0x3c31f7+0x1&_0x17ceea;}['nextBitIsOne'](){const _0x101abe=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x101abe;}}const yn=function(_0x334bba,_0xf43068,_0x23a1f4,_0xf1fb67){_0x334bba['sort'](_0xf43068);const _0x3a7d32=function(_0x4d7720,_0x34fd73){const _0x3ec378=_0x34fd73-_0x4d7720;let _0x3988e0,_0xd50562;if(_0x3ec378===0x0)return null;if(_0x3ec378===0x1)return _0x3988e0=_0x334bba[_0x4d7720],_0xd50562=_0x23a1f4?_0x23a1f4(_0x3988e0):_0x3988e0,new M(_0xd50562,_0x3988e0['node'],M['BLACK'],null,null);{const _0x4d6d72=parseInt(_0x3ec378/0x2,0xa)+_0x4d7720,_0x5be35a=_0x3a7d32(_0x4d7720,_0x4d6d72),_0x4b2d01=_0x3a7d32(_0x4d6d72+0x1,_0x34fd73);return _0x3988e0=_0x334bba[_0x4d6d72],_0xd50562=_0x23a1f4?_0x23a1f4(_0x3988e0):_0x3988e0,new M(_0xd50562,_0x3988e0['node'],M['BLACK'],_0x5be35a,_0x4b2d01);}},_0x4fd3e0=function(_0x50bd43){let _0x153098=null,_0x7f0af=null,_0x522cd7=_0x334bba['length'];const _0x1d1144=function(_0x192120,_0x24ab7f){const _0x601343=_0x522cd7-_0x192120,_0x4bab1c=_0x522cd7;_0x522cd7-=_0x192120;const _0x361c58=_0x3a7d32(_0x601343+0x1,_0x4bab1c),_0x219cc4=_0x334bba[_0x601343],_0x8ab2b3=_0x23a1f4?_0x23a1f4(_0x219cc4):_0x219cc4;_0x3e7484(new M(_0x8ab2b3,_0x219cc4['node'],_0x24ab7f,null,_0x361c58));},_0x3e7484=function(_0x2a3e8a){_0x153098?(_0x153098['left']=_0x2a3e8a,_0x153098=_0x2a3e8a):(_0x7f0af=_0x2a3e8a,_0x153098=_0x2a3e8a);};for(let _0x5206fd=0x0;_0x5206fd<_0x50bd43['count'];++_0x5206fd){const _0x5ad816=_0x50bd43['nextBitIsOne'](),_0xe841dc=Math['pow'](0x2,_0x50bd43['count']-(_0x5206fd+0x1));_0x5ad816?_0x1d1144(_0xe841dc,M['BLACK']):(_0x1d1144(_0xe841dc,M['BLACK']),_0x1d1144(_0xe841dc,M['RED']));}return _0x7f0af;},_0x557772=new Hh(_0x334bba['length']),_0x1972b8=_0x4fd3e0(_0x557772);return new B(_0xf1fb67||_0xf43068,_0x1972b8);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x274dea,_0x547f18){this['indexes_']=_0x274dea,this['indexSet_']=_0x547f18;}['get'](_0x35a727){const _0x240cf5=Le(this['indexes_'],_0x35a727);if(!_0x240cf5)throw new Error('No\x20index\x20defined\x20for\x20'+_0x35a727);return _0x240cf5 instanceof B?_0x240cf5:null;}['hasIndex'](_0x1554e6){return Q(this['indexSet_'],_0x1554e6['toString']());}['addIndex'](_0x3e465e,_0x5cc091){f(_0x3e465e!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x3ba9b2=[];let _0x49ecc9=!0x1;const _0x42b546=_0x5cc091['getIterator'](E['Wrap']);let _0x483687=_0x42b546['getNext']();for(;_0x483687;)_0x49ecc9=_0x49ecc9||_0x3e465e['isDefinedOn'](_0x483687['node']),_0x3ba9b2['push'](_0x483687),_0x483687=_0x42b546['getNext']();let _0x552ef5;_0x49ecc9?_0x552ef5=yn(_0x3ba9b2,_0x3e465e['getCompare']()):_0x552ef5=Qe;const _0xea9e47=_0x3e465e['toString'](),_0x45ba82={...this['indexSet_']};_0x45ba82[_0xea9e47]=_0x3e465e;const _0x384d1f={...this['indexes_']};return _0x384d1f[_0xea9e47]=_0x552ef5,new te(_0x384d1f,_0x45ba82);}['addToIndexes'](_0x5f2be0,_0x4db797){const _0x34c073=_n(this['indexes_'],(_0x8c1f74,_0x3e5e2b)=>{const _0x8276c3=Le(this['indexSet_'],_0x3e5e2b);if(f(_0x8276c3,'Missing\x20index\x20implementation\x20for\x20'+_0x3e5e2b),_0x8c1f74===Qe){if(_0x8276c3['isDefinedOn'](_0x5f2be0['node'])){const _0x51d76c=[],_0x425209=_0x4db797['getIterator'](E['Wrap']);let _0x4f33fa=_0x425209['getNext']();for(;_0x4f33fa;)_0x4f33fa['name']!==_0x5f2be0['name']&&_0x51d76c['push'](_0x4f33fa),_0x4f33fa=_0x425209['getNext']();return _0x51d76c['push'](_0x5f2be0),yn(_0x51d76c,_0x8276c3['getCompare']());}else return Qe;}else{const _0x1c1cdf=_0x4db797['get'](_0x5f2be0['name']);let _0x25852f=_0x8c1f74;return _0x1c1cdf&&(_0x25852f=_0x25852f['remove'](new E(_0x5f2be0['name'],_0x1c1cdf))),_0x25852f['insert'](_0x5f2be0,_0x5f2be0['node']);}});return new te(_0x34c073,this['indexSet_']);}['removeFromIndexes'](_0x2f97df,_0x2d9c1f){const _0x2afa1a=_n(this['indexes_'],_0x146edd=>{if(_0x146edd===Qe)return _0x146edd;{const _0x4d89d8=_0x2d9c1f['get'](_0x2f97df['name']);return _0x4d89d8?_0x146edd['remove'](new E(_0x2f97df['name'],_0x4d89d8)):_0x146edd;}});return new te(_0x2afa1a,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0xfd3ff0,_0x5d84d9,_0x33f630){this['children_']=_0xfd3ff0,this['priorityNode_']=_0x5d84d9,this['indexMap_']=_0x33f630,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x449a47){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x449a47,this['indexMap_']);}['getImmediateChild'](_0xb69d09){if(_0xb69d09==='.priority')return this['getPriority']();{const _0x5318ed=this['children_']['get'](_0xb69d09);return _0x5318ed===null?It:_0x5318ed;}}['getChild'](_0xea7de8){const _0x5bc323=y(_0xea7de8);return _0x5bc323===null?this:this['getImmediateChild'](_0x5bc323)['getChild'](S(_0xea7de8));}['hasChild'](_0x52e4d0){return this['children_']['get'](_0x52e4d0)!==null;}['updateImmediateChild'](_0x42cbd2,_0x30f801){if(f(_0x30f801,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x42cbd2==='.priority')return this['updatePriority'](_0x30f801);{const _0xaf85ce=new E(_0x42cbd2,_0x30f801);let _0x34b365,_0x23e28e;_0x30f801['isEmpty']()?(_0x34b365=this['children_']['remove'](_0x42cbd2),_0x23e28e=this['indexMap_']['removeFromIndexes'](_0xaf85ce,this['children_'])):(_0x34b365=this['children_']['insert'](_0x42cbd2,_0x30f801),_0x23e28e=this['indexMap_']['addToIndexes'](_0xaf85ce,this['children_']));const _0x353973=_0x34b365['isEmpty']()?It:this['priorityNode_'];return new g(_0x34b365,_0x353973,_0x23e28e);}}['updateChild'](_0x2a6825,_0x6042db){const _0x25070e=y(_0x2a6825);if(_0x25070e===null)return _0x6042db;{f(y(_0x2a6825)!=='.priority'||Ce(_0x2a6825)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2af82e=this['getImmediateChild'](_0x25070e)['updateChild'](S(_0x2a6825),_0x6042db);return this['updateImmediateChild'](_0x25070e,_0x2af82e);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1b1934){if(this['isEmpty']())return null;const _0x3a081f={};let _0x3e8840=0x0,_0x11956e=0x0,_0x295819=!0x0;if(this['forEachChild'](R,(_0xd40c18,_0x5e35aa)=>{_0x3a081f[_0xd40c18]=_0x5e35aa['val'](_0x1b1934),_0x3e8840++,_0x295819&&g['INTEGER_REGEXP_']['test'](_0xd40c18)?_0x11956e=Math['max'](_0x11956e,Number(_0xd40c18)):_0x295819=!0x1;}),!_0x1b1934&&_0x295819&&_0x11956e<0x2*_0x3e8840){const _0x339de5=[];for(const _0x2e42ff in _0x3a081f)_0x339de5[_0x2e42ff]=_0x3a081f[_0x2e42ff];return _0x339de5;}else return _0x1b1934&&!this['getPriority']()['isEmpty']()&&(_0x3a081f['.priority']=this['getPriority']()['val']()),_0x3a081f;}['hash'](){if(this['lazyHash_']===null){let _0x29b094='';this['getPriority']()['isEmpty']()||(_0x29b094+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x50e5dd,_0x433232)=>{const _0x4bbd26=_0x433232['hash']();_0x4bbd26!==''&&(_0x29b094+=':'+_0x50e5dd+':'+_0x4bbd26);}),this['lazyHash_']=_0x29b094===''?'':ro(_0x29b094);}return this['lazyHash_'];}['getPredecessorChildName'](_0x424ca6,_0x2a1f8d,_0x4e0e48){const _0x50432b=this['resolveIndex_'](_0x4e0e48);if(_0x50432b){const _0x495932=_0x50432b['getPredecessorKey'](new E(_0x424ca6,_0x2a1f8d));return _0x495932?_0x495932['name']:null;}else return this['children_']['getPredecessorKey'](_0x424ca6);}['getFirstChildName'](_0x14b97d){const _0x532554=this['resolveIndex_'](_0x14b97d);if(_0x532554){const _0x179fbf=_0x532554['minKey']();return _0x179fbf&&_0x179fbf['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x328956){const _0x2e1091=this['getFirstChildName'](_0x328956);return _0x2e1091?new E(_0x2e1091,this['children_']['get'](_0x2e1091)):null;}['getLastChildName'](_0x3cdbe2){const _0x909342=this['resolveIndex_'](_0x3cdbe2);if(_0x909342){const _0x418b68=_0x909342['maxKey']();return _0x418b68&&_0x418b68['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3b716b){const _0x395efd=this['getLastChildName'](_0x3b716b);return _0x395efd?new E(_0x395efd,this['children_']['get'](_0x395efd)):null;}['forEachChild'](_0x2899ad,_0x2fbfe9){const _0x5447ec=this['resolveIndex_'](_0x2899ad);return _0x5447ec?_0x5447ec['inorderTraversal'](_0x2e404a=>_0x2fbfe9(_0x2e404a['name'],_0x2e404a['node'])):this['children_']['inorderTraversal'](_0x2fbfe9);}['getIterator'](_0x171890){return this['getIteratorFrom'](_0x171890['minPost'](),_0x171890);}['getIteratorFrom'](_0x3b58a1,_0xcf0bab){const _0x242a6e=this['resolveIndex_'](_0xcf0bab);if(_0x242a6e)return _0x242a6e['getIteratorFrom'](_0x3b58a1,_0x1c2599=>_0x1c2599);{const _0x508b58=this['children_']['getIteratorFrom'](_0x3b58a1['name'],E['Wrap']);let _0x51c12e=_0x508b58['peek']();for(;_0x51c12e!=null&&_0xcf0bab['compare'](_0x51c12e,_0x3b58a1)<0x0;)_0x508b58['getNext'](),_0x51c12e=_0x508b58['peek']();return _0x508b58;}}['getReverseIterator'](_0x55383f){return this['getReverseIteratorFrom'](_0x55383f['maxPost'](),_0x55383f);}['getReverseIteratorFrom'](_0x1fb788,_0x160d6a){const _0x4548ca=this['resolveIndex_'](_0x160d6a);if(_0x4548ca)return _0x4548ca['getReverseIteratorFrom'](_0x1fb788,_0x5de704=>_0x5de704);{const _0x243f6a=this['children_']['getReverseIteratorFrom'](_0x1fb788['name'],E['Wrap']);let _0x44ca1a=_0x243f6a['peek']();for(;_0x44ca1a!=null&&_0x160d6a['compare'](_0x44ca1a,_0x1fb788)>0x0;)_0x243f6a['getNext'](),_0x44ca1a=_0x243f6a['peek']();return _0x243f6a;}}['compareTo'](_0x5d7c81){return this['isEmpty']()?_0x5d7c81['isEmpty']()?0x0:-0x1:_0x5d7c81['isLeafNode']()||_0x5d7c81['isEmpty']()?0x1:_0x5d7c81===Kt?-0x1:0x0;}['withIndex'](_0x2af66f){if(_0x2af66f===ve||this['indexMap_']['hasIndex'](_0x2af66f))return this;{const _0x32a317=this['indexMap_']['addIndex'](_0x2af66f,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x32a317);}}['isIndexed'](_0x5d60b8){return _0x5d60b8===ve||this['indexMap_']['hasIndex'](_0x5d60b8);}['equals'](_0x5ad45a){if(_0x5ad45a===this)return!0x0;if(_0x5ad45a['isLeafNode']())return!0x1;{const _0x3443bf=_0x5ad45a;if(this['getPriority']()['equals'](_0x3443bf['getPriority']())){if(this['children_']['count']()===_0x3443bf['children_']['count']()){const _0x3f7922=this['getIterator'](R),_0x31cb09=_0x3443bf['getIterator'](R);let _0x475624=_0x3f7922['getNext'](),_0x59c0ac=_0x31cb09['getNext']();for(;_0x475624&&_0x59c0ac;){if(_0x475624['name']!==_0x59c0ac['name']||!_0x475624['node']['equals'](_0x59c0ac['node']))return!0x1;_0x475624=_0x3f7922['getNext'](),_0x59c0ac=_0x31cb09['getNext']();}return _0x475624===null&&_0x59c0ac===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x41e0e7){return _0x41e0e7===ve?null:this['indexMap_']['get'](_0x41e0e7['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x24a394){return _0x24a394===this?0x0:0x1;}['equals'](_0x46cfed){return _0x46cfed===this;}['getPriority'](){return this;}['getImmediateChild'](_0x538832){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x19cafc,_0x429c14=null){if(_0x19cafc===null)return g['EMPTY_NODE'];if(typeof _0x19cafc=='object'&&'.priority'in _0x19cafc&&(_0x429c14=_0x19cafc['.priority']),f(_0x429c14===null||typeof _0x429c14=='string'||typeof _0x429c14=='number'||typeof _0x429c14=='object'&&'.sv'in _0x429c14,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x429c14),typeof _0x19cafc=='object'&&'.value'in _0x19cafc&&_0x19cafc['.value']!==null&&(_0x19cafc=_0x19cafc['.value']),typeof _0x19cafc!='object'||'.sv'in _0x19cafc){const _0xd7f171=_0x19cafc;return new D(_0xd7f171,A(_0x429c14));}if(!(_0x19cafc instanceof Array)&&Gh){const _0x57bc64=[];let _0x58d640=!0x1;if(x(_0x19cafc,(_0x544e28,_0x18d24c)=>{if(_0x544e28['substring'](0x0,0x1)!=='.'){const _0xdab090=A(_0x18d24c);_0xdab090['isEmpty']()||(_0x58d640=_0x58d640||!_0xdab090['getPriority']()['isEmpty'](),_0x57bc64['push'](new E(_0x544e28,_0xdab090)));}}),_0x57bc64['length']===0x0)return g['EMPTY_NODE'];const _0x5782ab=yn(_0x57bc64,xh,_0x448f39=>_0x448f39['name'],Qi);if(_0x58d640){const _0x3962bd=yn(_0x57bc64,R['getCompare']());return new g(_0x5782ab,A(_0x429c14),new te({'.priority':_0x3962bd},{'.priority':R}));}else return new g(_0x5782ab,A(_0x429c14),te['Default']);}else{let _0x5b4f29=g['EMPTY_NODE'];return x(_0x19cafc,(_0x2b294f,_0x27ffae)=>{if(Q(_0x19cafc,_0x2b294f)&&_0x2b294f['substring'](0x0,0x1)!=='.'){const _0x6e31d4=A(_0x27ffae);(_0x6e31d4['isLeafNode']()||!_0x6e31d4['isEmpty']())&&(_0x5b4f29=_0x5b4f29['updateImmediateChild'](_0x2b294f,_0x6e31d4));}}),_0x5b4f29['updatePriority'](A(_0x429c14));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x395068){super(),this['indexPath_']=_0x395068,f(!v(_0x395068)&&y(_0x395068)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1c7d8a){return _0x1c7d8a['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3fb801){return!_0x3fb801['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x44b7f0,_0x46fcd8){const _0x318d92=this['extractChild'](_0x44b7f0['node']),_0xcc61fc=this['extractChild'](_0x46fcd8['node']),_0x285dac=_0x318d92['compareTo'](_0xcc61fc);return _0x285dac===0x0?qe(_0x44b7f0['name'],_0x46fcd8['name']):_0x285dac;}['makePost'](_0xd38f0e,_0xf581db){const _0x30018f=A(_0xd38f0e),_0x139498=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x30018f);return new E(_0xf581db,_0x139498);}['maxPost'](){const _0x2c0208=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x2c0208);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x508b97,_0x2d5e69){const _0x1879ba=_0x508b97['node']['compareTo'](_0x2d5e69['node']);return _0x1879ba===0x0?qe(_0x508b97['name'],_0x2d5e69['name']):_0x1879ba;}['isDefinedOn'](_0x2fe243){return!0x0;}['indexedValueChanged'](_0x2c1e76,_0x11e36a){return!_0x2c1e76['equals'](_0x11e36a);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5b5cde,_0x1a8995){const _0x2bc2c6=A(_0x5b5cde);return new E(_0x1a8995,_0x2bc2c6);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0xe54c76){return{'type':'value','snapshotNode':_0xe54c76};}function rt(_0x10b1f3,_0x378d8c){return{'type':'child_added','snapshotNode':_0x378d8c,'childName':_0x10b1f3};}function Lt(_0x2c2332,_0x27cb69){return{'type':'child_removed','snapshotNode':_0x27cb69,'childName':_0x2c2332};}function xt(_0x34a610,_0x1d54db,_0x5dea4f){return{'type':'child_changed','snapshotNode':_0x1d54db,'childName':_0x34a610,'oldSnap':_0x5dea4f};}function zh(_0xd11758,_0xb0a8cb){return{'type':'child_moved','snapshotNode':_0xb0a8cb,'childName':_0xd11758};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x11fbe){this['index_']=_0x11fbe;}['updateChild'](_0x41403d,_0x2bbb68,_0x29ad80,_0x21f0b1,_0xf4bd43,_0x152975){f(_0x41403d['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x293def=_0x41403d['getImmediateChild'](_0x2bbb68);return _0x293def['getChild'](_0x21f0b1)['equals'](_0x29ad80['getChild'](_0x21f0b1))&&_0x293def['isEmpty']()===_0x29ad80['isEmpty']()||(_0x152975!=null&&(_0x29ad80['isEmpty']()?_0x41403d['hasChild'](_0x2bbb68)?_0x152975['trackChildChange'](Lt(_0x2bbb68,_0x293def)):f(_0x41403d['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x293def['isEmpty']()?_0x152975['trackChildChange'](rt(_0x2bbb68,_0x29ad80)):_0x152975['trackChildChange'](xt(_0x2bbb68,_0x29ad80,_0x293def))),_0x41403d['isLeafNode']()&&_0x29ad80['isEmpty']())?_0x41403d:_0x41403d['updateImmediateChild'](_0x2bbb68,_0x29ad80)['withIndex'](this['index_']);}['updateFullNode'](_0xb83838,_0x3250ba,_0x97da7){return _0x97da7!=null&&(_0xb83838['isLeafNode']()||_0xb83838['forEachChild'](R,(_0x54d499,_0x74aa31)=>{_0x3250ba['hasChild'](_0x54d499)||_0x97da7['trackChildChange'](Lt(_0x54d499,_0x74aa31));}),_0x3250ba['isLeafNode']()||_0x3250ba['forEachChild'](R,(_0x456be0,_0xad758e)=>{if(_0xb83838['hasChild'](_0x456be0)){const _0x8e0ad5=_0xb83838['getImmediateChild'](_0x456be0);_0x8e0ad5['equals'](_0xad758e)||_0x97da7['trackChildChange'](xt(_0x456be0,_0xad758e,_0x8e0ad5));}else _0x97da7['trackChildChange'](rt(_0x456be0,_0xad758e));})),_0x3250ba['withIndex'](this['index_']);}['updatePriority'](_0x2917da,_0x3473c7){return _0x2917da['isEmpty']()?g['EMPTY_NODE']:_0x2917da['updatePriority'](_0x3473c7);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x509a16){this['indexedFilter_']=new Xi(_0x509a16['getIndex']()),this['index_']=_0x509a16['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x509a16),this['endPost_']=Ft['getEndPost_'](_0x509a16),this['startIsInclusive_']=!_0x509a16['startAfterSet_'],this['endIsInclusive_']=!_0x509a16['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x135cc8){const _0x5a232e=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x135cc8)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x135cc8)<0x0,_0x270835=this['endIsInclusive_']?this['index_']['compare'](_0x135cc8,this['getEndPost']())<=0x0:this['index_']['compare'](_0x135cc8,this['getEndPost']())<0x0;return _0x5a232e&&_0x270835;}['updateChild'](_0x1dac6f,_0x299cc0,_0x42fa15,_0x400ecc,_0x5d2877,_0x5d128b){return this['matches'](new E(_0x299cc0,_0x42fa15))||(_0x42fa15=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1dac6f,_0x299cc0,_0x42fa15,_0x400ecc,_0x5d2877,_0x5d128b);}['updateFullNode'](_0x356b23,_0x393021,_0x2fbfb6){_0x393021['isLeafNode']()&&(_0x393021=g['EMPTY_NODE']);let _0x58e932=_0x393021['withIndex'](this['index_']);_0x58e932=_0x58e932['updatePriority'](g['EMPTY_NODE']);const _0x5f1831=this;return _0x393021['forEachChild'](R,(_0x50e4ec,_0x325167)=>{_0x5f1831['matches'](new E(_0x50e4ec,_0x325167))||(_0x58e932=_0x58e932['updateImmediateChild'](_0x50e4ec,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x356b23,_0x58e932,_0x2fbfb6);}['updatePriority'](_0x3fc3a7,_0x42351b){return _0x3fc3a7;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x22cbaf){if(_0x22cbaf['hasStart']()){const _0x24e981=_0x22cbaf['getIndexStartName']();return _0x22cbaf['getIndex']()['makePost'](_0x22cbaf['getIndexStartValue'](),_0x24e981);}else return _0x22cbaf['getIndex']()['minPost']();}static['getEndPost_'](_0x14732e){if(_0x14732e['hasEnd']()){const _0x13dde4=_0x14732e['getIndexEndName']();return _0x14732e['getIndex']()['makePost'](_0x14732e['getIndexEndValue'](),_0x13dde4);}else return _0x14732e['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x4543da){this['withinDirectionalStart']=_0x4b0c9c=>this['reverse_']?this['withinEndPost'](_0x4b0c9c):this['withinStartPost'](_0x4b0c9c),this['withinDirectionalEnd']=_0x13df76=>this['reverse_']?this['withinStartPost'](_0x13df76):this['withinEndPost'](_0x13df76),this['withinStartPost']=_0xee6919=>{const _0x944f3d=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xee6919);return this['startIsInclusive_']?_0x944f3d<=0x0:_0x944f3d<0x0;},this['withinEndPost']=_0x4c2cf6=>{const _0x5b0814=this['index_']['compare'](_0x4c2cf6,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x5b0814<=0x0:_0x5b0814<0x0;},this['rangedFilter_']=new Ft(_0x4543da),this['index_']=_0x4543da['getIndex'](),this['limit_']=_0x4543da['getLimit'](),this['reverse_']=!_0x4543da['isViewFromLeft'](),this['startIsInclusive_']=!_0x4543da['startAfterSet_'],this['endIsInclusive_']=!_0x4543da['endBeforeSet_'];}['updateChild'](_0x4d1a1d,_0x2c735f,_0x311964,_0x29a45b,_0x405e60,_0x6962dd){return this['rangedFilter_']['matches'](new E(_0x2c735f,_0x311964))||(_0x311964=g['EMPTY_NODE']),_0x4d1a1d['getImmediateChild'](_0x2c735f)['equals'](_0x311964)?_0x4d1a1d:_0x4d1a1d['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x4d1a1d,_0x2c735f,_0x311964,_0x29a45b,_0x405e60,_0x6962dd):this['fullLimitUpdateChild_'](_0x4d1a1d,_0x2c735f,_0x311964,_0x405e60,_0x6962dd);}['updateFullNode'](_0x3b0542,_0x20d36e,_0x451fa6){let _0x110135;if(_0x20d36e['isLeafNode']()||_0x20d36e['isEmpty']())_0x110135=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x20d36e['numChildren']()&&_0x20d36e['isIndexed'](this['index_'])){_0x110135=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x441319;this['reverse_']?_0x441319=_0x20d36e['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x441319=_0x20d36e['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x283158=0x0;for(;_0x441319['hasNext']()&&_0x283158<this['limit_'];){const _0x3b45b9=_0x441319['getNext']();if(this['withinDirectionalStart'](_0x3b45b9)){if(this['withinDirectionalEnd'](_0x3b45b9))_0x110135=_0x110135['updateImmediateChild'](_0x3b45b9['name'],_0x3b45b9['node']),_0x283158++;else break;}else continue;}}else{_0x110135=_0x20d36e['withIndex'](this['index_']),_0x110135=_0x110135['updatePriority'](g['EMPTY_NODE']);let _0x4a2f52;this['reverse_']?_0x4a2f52=_0x110135['getReverseIterator'](this['index_']):_0x4a2f52=_0x110135['getIterator'](this['index_']);let _0x5a672c=0x0;for(;_0x4a2f52['hasNext']();){const _0x7cc356=_0x4a2f52['getNext']();_0x5a672c<this['limit_']&&this['withinDirectionalStart'](_0x7cc356)&&this['withinDirectionalEnd'](_0x7cc356)?_0x5a672c++:_0x110135=_0x110135['updateImmediateChild'](_0x7cc356['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x3b0542,_0x110135,_0x451fa6);}['updatePriority'](_0x44d71e,_0x1c3b26){return _0x44d71e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x170657,_0x5ccaef,_0x578d5e,_0x350c61,_0xb7b500){let _0x5f3538;if(this['reverse_']){const _0x1ee6b8=this['index_']['getCompare']();_0x5f3538=(_0xa759cb,_0x1c66f9)=>_0x1ee6b8(_0x1c66f9,_0xa759cb);}else _0x5f3538=this['index_']['getCompare']();const _0x1e588d=_0x170657;f(_0x1e588d['numChildren']()===this['limit_'],'');const _0x5cf1cf=new E(_0x5ccaef,_0x578d5e),_0x535958=this['reverse_']?_0x1e588d['getFirstChild'](this['index_']):_0x1e588d['getLastChild'](this['index_']),_0x9af8cf=this['rangedFilter_']['matches'](_0x5cf1cf);if(_0x1e588d['hasChild'](_0x5ccaef)){const _0x22cc66=_0x1e588d['getImmediateChild'](_0x5ccaef);let _0x11f4bb=_0x350c61['getChildAfterChild'](this['index_'],_0x535958,this['reverse_']);for(;_0x11f4bb!=null&&(_0x11f4bb['name']===_0x5ccaef||_0x1e588d['hasChild'](_0x11f4bb['name']));)_0x11f4bb=_0x350c61['getChildAfterChild'](this['index_'],_0x11f4bb,this['reverse_']);const _0x205070=_0x11f4bb==null?0x1:_0x5f3538(_0x11f4bb,_0x5cf1cf);if(_0x9af8cf&&!_0x578d5e['isEmpty']()&&_0x205070>=0x0)return _0xb7b500!=null&&_0xb7b500['trackChildChange'](xt(_0x5ccaef,_0x578d5e,_0x22cc66)),_0x1e588d['updateImmediateChild'](_0x5ccaef,_0x578d5e);{_0xb7b500!=null&&_0xb7b500['trackChildChange'](Lt(_0x5ccaef,_0x22cc66));const _0x509dba=_0x1e588d['updateImmediateChild'](_0x5ccaef,g['EMPTY_NODE']);return _0x11f4bb!=null&&this['rangedFilter_']['matches'](_0x11f4bb)?(_0xb7b500!=null&&_0xb7b500['trackChildChange'](rt(_0x11f4bb['name'],_0x11f4bb['node'])),_0x509dba['updateImmediateChild'](_0x11f4bb['name'],_0x11f4bb['node'])):_0x509dba;}}else return _0x578d5e['isEmpty']()?_0x170657:_0x9af8cf&&_0x5f3538(_0x535958,_0x5cf1cf)>=0x0?(_0xb7b500!=null&&(_0xb7b500['trackChildChange'](Lt(_0x535958['name'],_0x535958['node'])),_0xb7b500['trackChildChange'](rt(_0x5ccaef,_0x578d5e))),_0x1e588d['updateImmediateChild'](_0x5ccaef,_0x578d5e)['updateImmediateChild'](_0x535958['name'],g['EMPTY_NODE'])):_0x170657;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1b5025=new Zi();return _0x1b5025['limitSet_']=this['limitSet_'],_0x1b5025['limit_']=this['limit_'],_0x1b5025['startSet_']=this['startSet_'],_0x1b5025['startAfterSet_']=this['startAfterSet_'],_0x1b5025['indexStartValue_']=this['indexStartValue_'],_0x1b5025['startNameSet_']=this['startNameSet_'],_0x1b5025['indexStartName_']=this['indexStartName_'],_0x1b5025['endSet_']=this['endSet_'],_0x1b5025['endBeforeSet_']=this['endBeforeSet_'],_0x1b5025['indexEndValue_']=this['indexEndValue_'],_0x1b5025['endNameSet_']=this['endNameSet_'],_0x1b5025['indexEndName_']=this['indexEndName_'],_0x1b5025['index_']=this['index_'],_0x1b5025['viewFrom_']=this['viewFrom_'],_0x1b5025;}}function Kh(_0x2bcd26){return _0x2bcd26['loadsAllData']()?new Xi(_0x2bcd26['getIndex']()):_0x2bcd26['hasLimit']()?new jh(_0x2bcd26):new Ft(_0x2bcd26);}function Yh(_0x1db6a7,_0x452ae0){const _0x162717=_0x1db6a7['copy']();return _0x162717['limitSet_']=!0x0,_0x162717['limit_']=_0x452ae0,_0x162717['viewFrom_']='l',_0x162717;}function Qh(_0x2d8ed9,_0x2e6870,_0x468bd8){const _0x10beff=_0x2d8ed9['copy']();return _0x10beff['startSet_']=!0x0,_0x2e6870===void 0x0&&(_0x2e6870=null),_0x10beff['indexStartValue_']=_0x2e6870,_0x468bd8!=null?(_0x10beff['startNameSet_']=!0x0,_0x10beff['indexStartName_']=_0x468bd8):(_0x10beff['startNameSet_']=!0x1,_0x10beff['indexStartName_']=''),_0x10beff;}function Jh(_0x373755,_0x2e886f,_0x510fcf){const _0x11a00b=_0x373755['copy']();return _0x11a00b['endSet_']=!0x0,_0x2e886f===void 0x0&&(_0x2e886f=null),_0x11a00b['indexEndValue_']=_0x2e886f,_0x510fcf!==void 0x0?(_0x11a00b['endNameSet_']=!0x0,_0x11a00b['indexEndName_']=_0x510fcf):(_0x11a00b['endNameSet_']=!0x1,_0x11a00b['indexEndName_']=''),_0x11a00b;}function xo(_0x1a3b6f,_0x5441ea){const _0x2e463b=_0x1a3b6f['copy']();return _0x2e463b['index_']=_0x5441ea,_0x2e463b;}function ir(_0x5a702d){const _0x16e648={};if(_0x5a702d['isDefault']())return _0x16e648;let _0x48a94b;if(_0x5a702d['index_']===R?_0x48a94b='$priority':_0x5a702d['index_']===Mo?_0x48a94b='$value':_0x5a702d['index_']===ve?_0x48a94b='$key':(f(_0x5a702d['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x48a94b=_0x5a702d['index_']['toString']()),_0x16e648['orderBy']=O(_0x48a94b),_0x5a702d['startSet_']){const _0x1072b1=_0x5a702d['startAfterSet_']?'startAfter':'startAt';_0x16e648[_0x1072b1]=O(_0x5a702d['indexStartValue_']),_0x5a702d['startNameSet_']&&(_0x16e648[_0x1072b1]+=','+O(_0x5a702d['indexStartName_']));}if(_0x5a702d['endSet_']){const _0x534729=_0x5a702d['endBeforeSet_']?'endBefore':'endAt';_0x16e648[_0x534729]=O(_0x5a702d['indexEndValue_']),_0x5a702d['endNameSet_']&&(_0x16e648[_0x534729]+=','+O(_0x5a702d['indexEndName_']));}return _0x5a702d['limitSet_']&&(_0x5a702d['isViewFromLeft']()?_0x16e648['limitToFirst']=_0x5a702d['limit_']:_0x16e648['limitToLast']=_0x5a702d['limit_']),_0x16e648;}function sr(_0x42f72b){const _0xfa33c1={};if(_0x42f72b['startSet_']&&(_0xfa33c1['sp']=_0x42f72b['indexStartValue_'],_0x42f72b['startNameSet_']&&(_0xfa33c1['sn']=_0x42f72b['indexStartName_']),_0xfa33c1['sin']=!_0x42f72b['startAfterSet_']),_0x42f72b['endSet_']&&(_0xfa33c1['ep']=_0x42f72b['indexEndValue_'],_0x42f72b['endNameSet_']&&(_0xfa33c1['en']=_0x42f72b['indexEndName_']),_0xfa33c1['ein']=!_0x42f72b['endBeforeSet_']),_0x42f72b['limitSet_']){_0xfa33c1['l']=_0x42f72b['limit_'];let _0x3eb992=_0x42f72b['viewFrom_'];_0x3eb992===''&&(_0x42f72b['isViewFromLeft']()?_0x3eb992='l':_0x3eb992='r'),_0xfa33c1['vf']=_0x3eb992;}return _0x42f72b['index_']!==R&&(_0xfa33c1['i']=_0x42f72b['index_']['toString']()),_0xfa33c1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0xdf63a8){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4d7fe5,_0x5c560b){return _0x5c560b!==void 0x0?'tag$'+_0x5c560b:(f(_0x4d7fe5['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4d7fe5['_path']['toString']());}constructor(_0x9e4a5c,_0x8c15ab,_0x34978c,_0x141101){super(),this['repoInfo_']=_0x9e4a5c,this['onDataUpdate_']=_0x8c15ab,this['authTokenProvider_']=_0x34978c,this['appCheckTokenProvider_']=_0x141101,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x36e300,_0x4fc846,_0x1c50f7,_0x4e2f95){const _0x31bf83=_0x36e300['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x31bf83+'\x20'+_0x36e300['_queryIdentifier']);const _0x2e792c=vn['getListenId_'](_0x36e300,_0x1c50f7),_0x96a03a={};this['listens_'][_0x2e792c]=_0x96a03a;const _0x4baf4a=ir(_0x36e300['_queryParams']);this['restRequest_'](_0x31bf83+'.json',_0x4baf4a,(_0x5d6a9a,_0x254ff2)=>{let _0x45a5c1=_0x254ff2;if(_0x5d6a9a===0x194&&(_0x45a5c1=null,_0x5d6a9a=null),_0x5d6a9a===null&&this['onDataUpdate_'](_0x31bf83,_0x45a5c1,!0x1,_0x1c50f7),Le(this['listens_'],_0x2e792c)===_0x96a03a){let _0x1d80ba;_0x5d6a9a?_0x5d6a9a===0x191?_0x1d80ba='permission_denied':_0x1d80ba='rest_error:'+_0x5d6a9a:_0x1d80ba='ok',_0x4e2f95(_0x1d80ba,null);}});}['unlisten'](_0x4bfcce,_0x42a7f8){const _0x36c24d=vn['getListenId_'](_0x4bfcce,_0x42a7f8);delete this['listens_'][_0x36c24d];}['get'](_0x4a7b9a){const _0x1cdcd1=ir(_0x4a7b9a['_queryParams']),_0x4b37fb=_0x4a7b9a['_path']['toString'](),_0x3a6839=new H();return this['restRequest_'](_0x4b37fb+'.json',_0x1cdcd1,(_0x4c209c,_0x4bbf9a)=>{let _0x5aa842=_0x4bbf9a;_0x4c209c===0x194&&(_0x5aa842=null,_0x4c209c=null),_0x4c209c===null?(this['onDataUpdate_'](_0x4b37fb,_0x5aa842,!0x1,null),_0x3a6839['resolve'](_0x5aa842)):_0x3a6839['reject'](new Error(_0x5aa842));}),_0x3a6839['promise'];}['refreshAuthToken'](_0x5558fc){}['restRequest_'](_0x4ead57,_0x240820={},_0x3057eb){return _0x240820['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x41b374,_0x3554e2])=>{_0x41b374&&_0x41b374['accessToken']&&(_0x240820['auth']=_0x41b374['accessToken']),_0x3554e2&&_0x3554e2['token']&&(_0x240820['ac']=_0x3554e2['token']);const _0x13c708=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4ead57+'?ns='+this['repoInfo_']['namespace']+ut(_0x240820);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x13c708);const _0x34128d=new XMLHttpRequest();_0x34128d['onreadystatechange']=()=>{if(_0x3057eb&&_0x34128d['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x13c708+'\x20received.\x20status:',_0x34128d['status'],'response:',_0x34128d['responseText']);let _0xb0f8b2=null;if(_0x34128d['status']>=0xc8&&_0x34128d['status']<0x12c){try{_0xb0f8b2=Nt(_0x34128d['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x13c708+':\x20'+_0x34128d['responseText']);}_0x3057eb(null,_0xb0f8b2);}else _0x34128d['status']!==0x191&&_0x34128d['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x13c708+'\x20Status:\x20'+_0x34128d['status']),_0x3057eb(_0x34128d['status']);_0x3057eb=null;}},_0x34128d['open']('GET',_0x13c708,!0x0),_0x34128d['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x1d4907){return this['rootNode_']['getChild'](_0x1d4907);}['updateSnapshot'](_0x3ed2c9,_0x214981){this['rootNode_']=this['rootNode_']['updateChild'](_0x3ed2c9,_0x214981);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x2f97d3,_0x470b0f,_0x361d67){if(v(_0x470b0f))_0x2f97d3['value']=_0x361d67,_0x2f97d3['children']['clear']();else{if(_0x2f97d3['value']!==null)_0x2f97d3['value']=_0x2f97d3['value']['updateChild'](_0x470b0f,_0x361d67);else{const _0x1b88b9=y(_0x470b0f);_0x2f97d3['children']['has'](_0x1b88b9)||_0x2f97d3['children']['set'](_0x1b88b9,En());const _0x324580=_0x2f97d3['children']['get'](_0x1b88b9);_0x470b0f=S(_0x470b0f),pt(_0x324580,_0x470b0f,_0x361d67);}}}function Ti(_0x878f77,_0x16d810){if(v(_0x16d810))return _0x878f77['value']=null,_0x878f77['children']['clear'](),!0x0;if(_0x878f77['value']!==null){if(_0x878f77['value']['isLeafNode']())return!0x1;{const _0x48a646=_0x878f77['value'];return _0x878f77['value']=null,_0x48a646['forEachChild'](R,(_0x2fbb7d,_0x1f6871)=>{pt(_0x878f77,new C(_0x2fbb7d),_0x1f6871);}),Ti(_0x878f77,_0x16d810);}}else{if(_0x878f77['children']['size']>0x0){const _0x2815b3=y(_0x16d810);return _0x16d810=S(_0x16d810),_0x878f77['children']['has'](_0x2815b3)&&Ti(_0x878f77['children']['get'](_0x2815b3),_0x16d810)&&_0x878f77['children']['delete'](_0x2815b3),_0x878f77['children']['size']===0x0;}else return!0x0;}}function Si(_0x4adeca,_0x4be378,_0xef7806){_0x4adeca['value']!==null?_0xef7806(_0x4be378,_0x4adeca['value']):Zh(_0x4adeca,(_0x44ed56,_0x3749e9)=>{const _0x889c50=new C(_0x4be378['toString']()+'/'+_0x44ed56);Si(_0x3749e9,_0x889c50,_0xef7806);});}function Zh(_0x548786,_0x5d305b){_0x548786['children']['forEach']((_0x1ba42a,_0x4391c6)=>{_0x5d305b(_0x4391c6,_0x1ba42a);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x120668){this['collection_']=_0x120668,this['last_']=null;}['get'](){const _0x1fc106=this['collection_']['get'](),_0xcfe1db={..._0x1fc106};return this['last_']&&x(this['last_'],(_0x509846,_0x21dd73)=>{_0xcfe1db[_0x509846]=_0xcfe1db[_0x509846]-_0x21dd73;}),this['last_']=_0x1fc106,_0xcfe1db;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x8d08a0,_0xa28007){this['server_']=_0xa28007,this['statsToReport_']={},this['statsListener_']=new eu(_0x8d08a0);const _0x4889ef=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x4889ef));}['reportStats_'](){const _0x1547e3=this['statsListener_']['get'](),_0x518678={};let _0x569ebf=!0x1;x(_0x1547e3,(_0x4347a3,_0x160732)=>{_0x160732>0x0&&Q(this['statsToReport_'],_0x4347a3)&&(_0x518678[_0x4347a3]=_0x160732,_0x569ebf=!0x0);}),_0x569ebf&&this['server_']['reportStats'](_0x518678),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x318f72){_0x318f72[_0x318f72['OVERWRITE']=0x0]='OVERWRITE',_0x318f72[_0x318f72['MERGE']=0x1]='MERGE',_0x318f72[_0x318f72['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x318f72[_0x318f72['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x4ba68d){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4ba68d,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x5c40d1,_0x22a94a,_0x235dc2){this['path']=_0x5c40d1,this['affectedTree']=_0x22a94a,this['revert']=_0x235dc2,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x352c48){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2c6015=this['affectedTree']['subtree'](new C(_0x352c48));return new In(w(),_0x2c6015,this['revert']);}}else return f(y(this['path'])===_0x352c48,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x2cabf2,_0x1e2cfd){this['source']=_0x2cabf2,this['path']=_0x1e2cfd,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x341491){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x2b40eb,_0x295803,_0x40f833){this['source']=_0x2b40eb,this['path']=_0x295803,this['snap']=_0x40f833,this['type']=z['OVERWRITE'];}['operationForChild'](_0x3bfaeb){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x3bfaeb)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x2433fb,_0xa3616b,_0x57d25f){this['source']=_0x2433fb,this['path']=_0xa3616b,this['children']=_0x57d25f,this['type']=z['MERGE'];}['operationForChild'](_0x31e71b){if(v(this['path'])){const _0x18098a=this['children']['subtree'](new C(_0x31e71b));return _0x18098a['isEmpty']()?null:_0x18098a['value']?new Be(this['source'],w(),_0x18098a['value']):new ot(this['source'],w(),_0x18098a);}else return f(y(this['path'])===_0x31e71b,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x209ddd,_0x19ef09,_0x552308){this['node_']=_0x209ddd,this['fullyInitialized_']=_0x19ef09,this['filtered_']=_0x552308;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x101d2b){if(v(_0x101d2b))return this['isFullyInitialized']()&&!this['filtered_'];const _0xe1b01b=y(_0x101d2b);return this['isCompleteForChild'](_0xe1b01b);}['isCompleteForChild'](_0x2fc18d){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2fc18d);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x3b0aee){this['query_']=_0x3b0aee,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0xe9e144,_0x13095d,_0x977a16,_0x4096bd){const _0x14a502=[],_0x4cc422=[];return _0x13095d['forEach'](_0xe545c4=>{_0xe545c4['type']==='child_changed'&&_0xe9e144['index_']['indexedValueChanged'](_0xe545c4['oldSnap'],_0xe545c4['snapshotNode'])&&_0x4cc422['push'](zh(_0xe545c4['childName'],_0xe545c4['snapshotNode']));}),wt(_0xe9e144,_0x14a502,'child_removed',_0x13095d,_0x4096bd,_0x977a16),wt(_0xe9e144,_0x14a502,'child_added',_0x13095d,_0x4096bd,_0x977a16),wt(_0xe9e144,_0x14a502,'child_moved',_0x4cc422,_0x4096bd,_0x977a16),wt(_0xe9e144,_0x14a502,'child_changed',_0x13095d,_0x4096bd,_0x977a16),wt(_0xe9e144,_0x14a502,'value',_0x13095d,_0x4096bd,_0x977a16),_0x14a502;}function wt(_0x58014f,_0x27b42b,_0x1d5de2,_0x272b3b,_0x348c54,_0x496cff){const _0x10fb13=_0x272b3b['filter'](_0x5be5ff=>_0x5be5ff['type']===_0x1d5de2);_0x10fb13['sort']((_0x20e262,_0x4fa05c)=>au(_0x58014f,_0x20e262,_0x4fa05c)),_0x10fb13['forEach'](_0x1d24e0=>{const _0x4aa584=ou(_0x58014f,_0x1d24e0,_0x496cff);_0x348c54['forEach'](_0xd298f3=>{_0xd298f3['respondsTo'](_0x1d24e0['type'])&&_0x27b42b['push'](_0xd298f3['createEvent'](_0x4aa584,_0x58014f['query_']));});});}function ou(_0x421a69,_0x1c5c2e,_0x417734){return _0x1c5c2e['type']==='value'||_0x1c5c2e['type']==='child_removed'||(_0x1c5c2e['prevName']=_0x417734['getPredecessorChildName'](_0x1c5c2e['childName'],_0x1c5c2e['snapshotNode'],_0x421a69['index_'])),_0x1c5c2e;}function au(_0x463fb4,_0x29f1dd,_0x388ecd){if(_0x29f1dd['childName']==null||_0x388ecd['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1c3ce3=new E(_0x29f1dd['childName'],_0x29f1dd['snapshotNode']),_0x279fbe=new E(_0x388ecd['childName'],_0x388ecd['snapshotNode']);return _0x463fb4['index_']['compare'](_0x1c3ce3,_0x279fbe);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x2f9747,_0x2c50a0){return{'eventCache':_0x2f9747,'serverCache':_0x2c50a0};}function Rt(_0x55fffa,_0x124908,_0x11469d,_0x1018ad){return Un(new Te(_0x124908,_0x11469d,_0x1018ad),_0x55fffa['serverCache']);}function Fo(_0x36ce7a,_0x592bb2,_0xccaa29,_0x144f69){return Un(_0x36ce7a['eventCache'],new Te(_0x592bb2,_0xccaa29,_0x144f69));}function wn(_0x2eefa2){return _0x2eefa2['eventCache']['isFullyInitialized']()?_0x2eefa2['eventCache']['getNode']():null;}function Ve(_0x4f1628){return _0x4f1628['serverCache']['isFullyInitialized']()?_0x4f1628['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x11027d){let _0x2a2f4c=new b(null);return x(_0x11027d,(_0xc35727,_0x2b732d)=>{_0x2a2f4c=_0x2a2f4c['set'](new C(_0xc35727),_0x2b732d);}),_0x2a2f4c;}constructor(_0x3ab404,_0x53efa1=cu()){this['value']=_0x3ab404,this['children']=_0x53efa1;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1b3f9,_0x59b1a8){if(this['value']!=null&&_0x59b1a8(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1b3f9))return null;{const _0x9139f5=y(_0x1b3f9),_0x3a4279=this['children']['get'](_0x9139f5);if(_0x3a4279!==null){const _0x12a948=_0x3a4279['findRootMostMatchingPathAndValue'](S(_0x1b3f9),_0x59b1a8);return _0x12a948!=null?{'path':k(new C(_0x9139f5),_0x12a948['path']),'value':_0x12a948['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4e0552){return this['findRootMostMatchingPathAndValue'](_0x4e0552,()=>!0x0);}['subtree'](_0x5a27de){if(v(_0x5a27de))return this;{const _0x87cb1a=y(_0x5a27de),_0x59e277=this['children']['get'](_0x87cb1a);return _0x59e277!==null?_0x59e277['subtree'](S(_0x5a27de)):new b(null);}}['set'](_0x47a1e0,_0x1e6a9f){if(v(_0x47a1e0))return new b(_0x1e6a9f,this['children']);{const _0x22b035=y(_0x47a1e0),_0x1ba623=(this['children']['get'](_0x22b035)||new b(null))['set'](S(_0x47a1e0),_0x1e6a9f),_0x5b0cfa=this['children']['insert'](_0x22b035,_0x1ba623);return new b(this['value'],_0x5b0cfa);}}['remove'](_0x19c40a){if(v(_0x19c40a))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x22cbf5=y(_0x19c40a),_0x40b39a=this['children']['get'](_0x22cbf5);if(_0x40b39a){const _0x5e3182=_0x40b39a['remove'](S(_0x19c40a));let _0x583d75;return _0x5e3182['isEmpty']()?_0x583d75=this['children']['remove'](_0x22cbf5):_0x583d75=this['children']['insert'](_0x22cbf5,_0x5e3182),this['value']===null&&_0x583d75['isEmpty']()?new b(null):new b(this['value'],_0x583d75);}else return this;}}['get'](_0x84dee8){if(v(_0x84dee8))return this['value'];{const _0x5d6415=y(_0x84dee8),_0x128b9a=this['children']['get'](_0x5d6415);return _0x128b9a?_0x128b9a['get'](S(_0x84dee8)):null;}}['setTree'](_0x4fbfc0,_0x130e76){if(v(_0x4fbfc0))return _0x130e76;{const _0x4dec55=y(_0x4fbfc0),_0xeec4a=(this['children']['get'](_0x4dec55)||new b(null))['setTree'](S(_0x4fbfc0),_0x130e76);let _0x27ec34;return _0xeec4a['isEmpty']()?_0x27ec34=this['children']['remove'](_0x4dec55):_0x27ec34=this['children']['insert'](_0x4dec55,_0xeec4a),new b(this['value'],_0x27ec34);}}['fold'](_0x3c375c){return this['fold_'](w(),_0x3c375c);}['fold_'](_0x284176,_0x4cf9a0){const _0x38a29c={};return this['children']['inorderTraversal']((_0x4131ad,_0x5cf0d2)=>{_0x38a29c[_0x4131ad]=_0x5cf0d2['fold_'](k(_0x284176,_0x4131ad),_0x4cf9a0);}),_0x4cf9a0(_0x284176,this['value'],_0x38a29c);}['findOnPath'](_0x11b85c,_0xee6731){return this['findOnPath_'](_0x11b85c,w(),_0xee6731);}['findOnPath_'](_0x3af309,_0x17ce99,_0x5aa5c7){const _0x2945d7=this['value']?_0x5aa5c7(_0x17ce99,this['value']):!0x1;if(_0x2945d7)return _0x2945d7;if(v(_0x3af309))return null;{const _0x37319a=y(_0x3af309),_0x4b9288=this['children']['get'](_0x37319a);return _0x4b9288?_0x4b9288['findOnPath_'](S(_0x3af309),k(_0x17ce99,_0x37319a),_0x5aa5c7):null;}}['foreachOnPath'](_0x5d74d0,_0x562ecb){return this['foreachOnPath_'](_0x5d74d0,w(),_0x562ecb);}['foreachOnPath_'](_0x42597a,_0x1e2502,_0x1c1b0c){if(v(_0x42597a))return this;{this['value']&&_0x1c1b0c(_0x1e2502,this['value']);const _0x1e2d2b=y(_0x42597a),_0x42dca0=this['children']['get'](_0x1e2d2b);return _0x42dca0?_0x42dca0['foreachOnPath_'](S(_0x42597a),k(_0x1e2502,_0x1e2d2b),_0x1c1b0c):new b(null);}}['foreach'](_0x281867){this['foreach_'](w(),_0x281867);}['foreach_'](_0x377e57,_0x511e79){this['children']['inorderTraversal']((_0x5e5713,_0x524959)=>{_0x524959['foreach_'](k(_0x377e57,_0x5e5713),_0x511e79);}),this['value']&&_0x511e79(_0x377e57,this['value']);}['foreachChild'](_0x4096e3){this['children']['inorderTraversal']((_0x12341c,_0x54ac8e)=>{_0x54ac8e['value']&&_0x4096e3(_0x12341c,_0x54ac8e['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x1c01e3){this['writeTree_']=_0x1c01e3;}static['empty'](){return new K(new b(null));}}function At(_0x41e7e4,_0x3edb26,_0x2a2881){if(v(_0x3edb26))return new K(new b(_0x2a2881));{const _0x425f20=_0x41e7e4['writeTree_']['findRootMostValueAndPath'](_0x3edb26);if(_0x425f20!=null){const _0x48cdcd=_0x425f20['path'];let _0x2153de=_0x425f20['value'];const _0xa1df85=F(_0x48cdcd,_0x3edb26);return _0x2153de=_0x2153de['updateChild'](_0xa1df85,_0x2a2881),new K(_0x41e7e4['writeTree_']['set'](_0x48cdcd,_0x2153de));}else{const _0x40c0cb=new b(_0x2a2881),_0x6d3e2b=_0x41e7e4['writeTree_']['setTree'](_0x3edb26,_0x40c0cb);return new K(_0x6d3e2b);}}}function bi(_0x451f46,_0x2ec98d,_0x49af62){let _0x1eb36b=_0x451f46;return x(_0x49af62,(_0x47f9e3,_0x40ca66)=>{_0x1eb36b=At(_0x1eb36b,k(_0x2ec98d,_0x47f9e3),_0x40ca66);}),_0x1eb36b;}function or(_0x13bdfe,_0x28a18c){if(v(_0x28a18c))return K['empty']();{const _0x323115=_0x13bdfe['writeTree_']['setTree'](_0x28a18c,new b(null));return new K(_0x323115);}}function Ri(_0x51c3fe,_0x554357){return ze(_0x51c3fe,_0x554357)!=null;}function ze(_0x36b82a,_0x282b09){const _0x3e3c9f=_0x36b82a['writeTree_']['findRootMostValueAndPath'](_0x282b09);return _0x3e3c9f!=null?_0x36b82a['writeTree_']['get'](_0x3e3c9f['path'])['getChild'](F(_0x3e3c9f['path'],_0x282b09)):null;}function ar(_0x585edc){const _0x1c04c4=[],_0x4a9348=_0x585edc['writeTree_']['value'];return _0x4a9348!=null?_0x4a9348['isLeafNode']()||_0x4a9348['forEachChild'](R,(_0x2c31d0,_0x117347)=>{_0x1c04c4['push'](new E(_0x2c31d0,_0x117347));}):_0x585edc['writeTree_']['children']['inorderTraversal']((_0x136943,_0x21adec)=>{_0x21adec['value']!=null&&_0x1c04c4['push'](new E(_0x136943,_0x21adec['value']));}),_0x1c04c4;}function Ee(_0x581e62,_0xedfe2e){if(v(_0xedfe2e))return _0x581e62;{const _0x6911f2=ze(_0x581e62,_0xedfe2e);return _0x6911f2!=null?new K(new b(_0x6911f2)):new K(_0x581e62['writeTree_']['subtree'](_0xedfe2e));}}function Ai(_0x361ff3){return _0x361ff3['writeTree_']['isEmpty']();}function at(_0x56158d,_0x299149){return Uo(w(),_0x56158d['writeTree_'],_0x299149);}function Uo(_0x587069,_0x14c3ef,_0xee7bd2){if(_0x14c3ef['value']!=null)return _0xee7bd2['updateChild'](_0x587069,_0x14c3ef['value']);{let _0x2a5179=null;return _0x14c3ef['children']['inorderTraversal']((_0x32b8be,_0x31e52c)=>{_0x32b8be==='.priority'?(f(_0x31e52c['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2a5179=_0x31e52c['value']):_0xee7bd2=Uo(k(_0x587069,_0x32b8be),_0x31e52c,_0xee7bd2);}),!_0xee7bd2['getChild'](_0x587069)['isEmpty']()&&_0x2a5179!==null&&(_0xee7bd2=_0xee7bd2['updateChild'](k(_0x587069,'.priority'),_0x2a5179)),_0xee7bd2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x19a274,_0x4ad0aa){return Ho(_0x4ad0aa,_0x19a274);}function lu(_0x2ec33b,_0x27be0c,_0x176ed6,_0x186fdb,_0x347e2d){f(_0x186fdb>_0x2ec33b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x347e2d===void 0x0&&(_0x347e2d=!0x0),_0x2ec33b['allWrites']['push']({'path':_0x27be0c,'snap':_0x176ed6,'writeId':_0x186fdb,'visible':_0x347e2d}),_0x347e2d&&(_0x2ec33b['visibleWrites']=At(_0x2ec33b['visibleWrites'],_0x27be0c,_0x176ed6)),_0x2ec33b['lastWriteId']=_0x186fdb;}function hu(_0x3dbf59,_0x5dbaa6,_0x111c97,_0x5e5c3b){f(_0x5e5c3b>_0x3dbf59['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3dbf59['allWrites']['push']({'path':_0x5dbaa6,'children':_0x111c97,'writeId':_0x5e5c3b,'visible':!0x0}),_0x3dbf59['visibleWrites']=bi(_0x3dbf59['visibleWrites'],_0x5dbaa6,_0x111c97),_0x3dbf59['lastWriteId']=_0x5e5c3b;}function uu(_0x1175a5,_0x23e786){for(let _0x53ffcf=0x0;_0x53ffcf<_0x1175a5['allWrites']['length'];_0x53ffcf++){const _0x519de9=_0x1175a5['allWrites'][_0x53ffcf];if(_0x519de9['writeId']===_0x23e786)return _0x519de9;}return null;}function du(_0x23aca0,_0x5b832e){const _0x43c29b=_0x23aca0['allWrites']['findIndex'](_0x37195f=>_0x37195f['writeId']===_0x5b832e);f(_0x43c29b>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4a3887=_0x23aca0['allWrites'][_0x43c29b];_0x23aca0['allWrites']['splice'](_0x43c29b,0x1);let _0x3e4f92=_0x4a3887['visible'],_0x4af3b6=!0x1,_0xd98d4b=_0x23aca0['allWrites']['length']-0x1;for(;_0x3e4f92&&_0xd98d4b>=0x0;){const _0x380a2f=_0x23aca0['allWrites'][_0xd98d4b];_0x380a2f['visible']&&(_0xd98d4b>=_0x43c29b&&fu(_0x380a2f,_0x4a3887['path'])?_0x3e4f92=!0x1:G(_0x4a3887['path'],_0x380a2f['path'])&&(_0x4af3b6=!0x0)),_0xd98d4b--;}if(_0x3e4f92){if(_0x4af3b6)return pu(_0x23aca0),!0x0;if(_0x4a3887['snap'])_0x23aca0['visibleWrites']=or(_0x23aca0['visibleWrites'],_0x4a3887['path']);else{const _0x506b2e=_0x4a3887['children'];x(_0x506b2e,_0x5153b1=>{_0x23aca0['visibleWrites']=or(_0x23aca0['visibleWrites'],k(_0x4a3887['path'],_0x5153b1));});}return!0x0;}else return!0x1;}function fu(_0x1ac99f,_0x1874c2){if(_0x1ac99f['snap'])return G(_0x1ac99f['path'],_0x1874c2);for(const _0x4d533f in _0x1ac99f['children'])if(_0x1ac99f['children']['hasOwnProperty'](_0x4d533f)&&G(k(_0x1ac99f['path'],_0x4d533f),_0x1874c2))return!0x0;return!0x1;}function pu(_0x1c6d06){_0x1c6d06['visibleWrites']=Wo(_0x1c6d06['allWrites'],_u,w()),_0x1c6d06['allWrites']['length']>0x0?_0x1c6d06['lastWriteId']=_0x1c6d06['allWrites'][_0x1c6d06['allWrites']['length']-0x1]['writeId']:_0x1c6d06['lastWriteId']=-0x1;}function _u(_0xee58a5){return _0xee58a5['visible'];}function Wo(_0x3a63c5,_0x365c30,_0x2f6aac){let _0x580d5c=K['empty']();for(let _0x9cc7c0=0x0;_0x9cc7c0<_0x3a63c5['length'];++_0x9cc7c0){const _0x48fd00=_0x3a63c5[_0x9cc7c0];if(_0x365c30(_0x48fd00)){const _0x3b5651=_0x48fd00['path'];let _0xe33fdb;if(_0x48fd00['snap'])G(_0x2f6aac,_0x3b5651)?(_0xe33fdb=F(_0x2f6aac,_0x3b5651),_0x580d5c=At(_0x580d5c,_0xe33fdb,_0x48fd00['snap'])):G(_0x3b5651,_0x2f6aac)&&(_0xe33fdb=F(_0x3b5651,_0x2f6aac),_0x580d5c=At(_0x580d5c,w(),_0x48fd00['snap']['getChild'](_0xe33fdb)));else{if(_0x48fd00['children']){if(G(_0x2f6aac,_0x3b5651))_0xe33fdb=F(_0x2f6aac,_0x3b5651),_0x580d5c=bi(_0x580d5c,_0xe33fdb,_0x48fd00['children']);else{if(G(_0x3b5651,_0x2f6aac)){if(_0xe33fdb=F(_0x3b5651,_0x2f6aac),v(_0xe33fdb))_0x580d5c=bi(_0x580d5c,w(),_0x48fd00['children']);else{const _0x3a3b1d=Le(_0x48fd00['children'],y(_0xe33fdb));if(_0x3a3b1d){const _0x449271=_0x3a3b1d['getChild'](S(_0xe33fdb));_0x580d5c=At(_0x580d5c,w(),_0x449271);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x580d5c;}function Bo(_0x27cc27,_0x1451a7,_0x869967,_0x47104f,_0x1ebb15){if(!_0x47104f&&!_0x1ebb15){const _0x5d736c=ze(_0x27cc27['visibleWrites'],_0x1451a7);if(_0x5d736c!=null)return _0x5d736c;{const _0x4e46d5=Ee(_0x27cc27['visibleWrites'],_0x1451a7);if(Ai(_0x4e46d5))return _0x869967;if(_0x869967==null&&!Ri(_0x4e46d5,w()))return null;{const _0x4d2e85=_0x869967||g['EMPTY_NODE'];return at(_0x4e46d5,_0x4d2e85);}}}else{const _0x135764=Ee(_0x27cc27['visibleWrites'],_0x1451a7);if(!_0x1ebb15&&Ai(_0x135764))return _0x869967;if(!_0x1ebb15&&_0x869967==null&&!Ri(_0x135764,w()))return null;{const _0x6d5bcc=function(_0x3af2bb){return(_0x3af2bb['visible']||_0x1ebb15)&&(!_0x47104f||!~_0x47104f['indexOf'](_0x3af2bb['writeId']))&&(G(_0x3af2bb['path'],_0x1451a7)||G(_0x1451a7,_0x3af2bb['path']));},_0x1f01c5=Wo(_0x27cc27['allWrites'],_0x6d5bcc,_0x1451a7),_0x256ac6=_0x869967||g['EMPTY_NODE'];return at(_0x1f01c5,_0x256ac6);}}}function gu(_0x59cfb1,_0x506efb,_0x59329e){let _0x132904=g['EMPTY_NODE'];const _0x1329bf=ze(_0x59cfb1['visibleWrites'],_0x506efb);if(_0x1329bf)return _0x1329bf['isLeafNode']()||_0x1329bf['forEachChild'](R,(_0x10b7ff,_0x198ce0)=>{_0x132904=_0x132904['updateImmediateChild'](_0x10b7ff,_0x198ce0);}),_0x132904;if(_0x59329e){const _0x57a1db=Ee(_0x59cfb1['visibleWrites'],_0x506efb);return _0x59329e['forEachChild'](R,(_0x52ba50,_0x5f2c75)=>{const _0x4e46ff=at(Ee(_0x57a1db,new C(_0x52ba50)),_0x5f2c75);_0x132904=_0x132904['updateImmediateChild'](_0x52ba50,_0x4e46ff);}),ar(_0x57a1db)['forEach'](_0x12f047=>{_0x132904=_0x132904['updateImmediateChild'](_0x12f047['name'],_0x12f047['node']);}),_0x132904;}else{const _0x2d70ec=Ee(_0x59cfb1['visibleWrites'],_0x506efb);return ar(_0x2d70ec)['forEach'](_0x4c2b1f=>{_0x132904=_0x132904['updateImmediateChild'](_0x4c2b1f['name'],_0x4c2b1f['node']);}),_0x132904;}}function mu(_0x222bce,_0x1bd0b2,_0x5c593d,_0x104baa,_0x48a60b){f(_0x104baa||_0x48a60b,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3f3843=k(_0x1bd0b2,_0x5c593d);if(Ri(_0x222bce['visibleWrites'],_0x3f3843))return null;{const _0x25a9cd=Ee(_0x222bce['visibleWrites'],_0x3f3843);return Ai(_0x25a9cd)?_0x48a60b['getChild'](_0x5c593d):at(_0x25a9cd,_0x48a60b['getChild'](_0x5c593d));}}function yu(_0x5db591,_0x1f59d1,_0xf89573,_0x1453cb){const _0x2cc27e=k(_0x1f59d1,_0xf89573),_0x1d9a1c=ze(_0x5db591['visibleWrites'],_0x2cc27e);if(_0x1d9a1c!=null)return _0x1d9a1c;if(_0x1453cb['isCompleteForChild'](_0xf89573)){const _0x4bd75f=Ee(_0x5db591['visibleWrites'],_0x2cc27e);return at(_0x4bd75f,_0x1453cb['getNode']()['getImmediateChild'](_0xf89573));}else return null;}function vu(_0x1ebbdc,_0x151437){return ze(_0x1ebbdc['visibleWrites'],_0x151437);}function Eu(_0x3fea90,_0x24da50,_0x49a5d6,_0x345a14,_0x32ddc0,_0x585be0,_0x21cd49){let _0x34331f;const _0x5b4260=Ee(_0x3fea90['visibleWrites'],_0x24da50),_0x102b8a=ze(_0x5b4260,w());if(_0x102b8a!=null)_0x34331f=_0x102b8a;else{if(_0x49a5d6!=null)_0x34331f=at(_0x5b4260,_0x49a5d6);else return[];}if(_0x34331f=_0x34331f['withIndex'](_0x21cd49),!_0x34331f['isEmpty']()&&!_0x34331f['isLeafNode']()){const _0x1193fd=[],_0x518ce6=_0x21cd49['getCompare'](),_0x113b34=_0x585be0?_0x34331f['getReverseIteratorFrom'](_0x345a14,_0x21cd49):_0x34331f['getIteratorFrom'](_0x345a14,_0x21cd49);let _0x4f753d=_0x113b34['getNext']();for(;_0x4f753d&&_0x1193fd['length']<_0x32ddc0;)_0x518ce6(_0x4f753d,_0x345a14)!==0x0&&_0x1193fd['push'](_0x4f753d),_0x4f753d=_0x113b34['getNext']();return _0x1193fd;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x43349c,_0x2d2971,_0x223520,_0x5bf8b9){return Bo(_0x43349c['writeTree'],_0x43349c['treePath'],_0x2d2971,_0x223520,_0x5bf8b9);}function is(_0x270238,_0xcc016f){return gu(_0x270238['writeTree'],_0x270238['treePath'],_0xcc016f);}function cr(_0x19049a,_0x6aefdd,_0x1ef2e3,_0x2dd13c){return mu(_0x19049a['writeTree'],_0x19049a['treePath'],_0x6aefdd,_0x1ef2e3,_0x2dd13c);}function Tn(_0x462968,_0x52ff87){return vu(_0x462968['writeTree'],k(_0x462968['treePath'],_0x52ff87));}function wu(_0x1fe271,_0x18493d,_0x398a68,_0x5288d7,_0xad9f68,_0x45b825){return Eu(_0x1fe271['writeTree'],_0x1fe271['treePath'],_0x18493d,_0x398a68,_0x5288d7,_0xad9f68,_0x45b825);}function ss(_0x2d102d,_0x4cb2dd,_0x3ee810){return yu(_0x2d102d['writeTree'],_0x2d102d['treePath'],_0x4cb2dd,_0x3ee810);}function Vo(_0x3961d8,_0x6bd2d3){return Ho(k(_0x3961d8['treePath'],_0x6bd2d3),_0x3961d8['writeTree']);}function Ho(_0xc74b91,_0x34aba2){return{'treePath':_0xc74b91,'writeTree':_0x34aba2};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x47c596){const _0x599072=_0x47c596['type'],_0x2825ba=_0x47c596['childName'];f(_0x599072==='child_added'||_0x599072==='child_changed'||_0x599072==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2825ba!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4f2c16=this['changeMap']['get'](_0x2825ba);if(_0x4f2c16){const _0x26c9c6=_0x4f2c16['type'];if(_0x599072==='child_added'&&_0x26c9c6==='child_removed')this['changeMap']['set'](_0x2825ba,xt(_0x2825ba,_0x47c596['snapshotNode'],_0x4f2c16['snapshotNode']));else{if(_0x599072==='child_removed'&&_0x26c9c6==='child_added')this['changeMap']['delete'](_0x2825ba);else{if(_0x599072==='child_removed'&&_0x26c9c6==='child_changed')this['changeMap']['set'](_0x2825ba,Lt(_0x2825ba,_0x4f2c16['oldSnap']));else{if(_0x599072==='child_changed'&&_0x26c9c6==='child_added')this['changeMap']['set'](_0x2825ba,rt(_0x2825ba,_0x47c596['snapshotNode']));else{if(_0x599072==='child_changed'&&_0x26c9c6==='child_changed')this['changeMap']['set'](_0x2825ba,xt(_0x2825ba,_0x47c596['snapshotNode'],_0x4f2c16['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x47c596+'\x20occurred\x20after\x20'+_0x4f2c16);}}}}}else this['changeMap']['set'](_0x2825ba,_0x47c596);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x172071){return null;}['getChildAfterChild'](_0x4ef8e1,_0x322276,_0x2da009){return null;}}const $o=new Tu();class rs{constructor(_0x348d92,_0x138711,_0x34a595=null){this['writes_']=_0x348d92,this['viewCache_']=_0x138711,this['optCompleteServerCache_']=_0x34a595;}['getCompleteChild'](_0x296ef2){const _0x14efb7=this['viewCache_']['eventCache'];if(_0x14efb7['isCompleteForChild'](_0x296ef2))return _0x14efb7['getNode']()['getImmediateChild'](_0x296ef2);{const _0x3eb43d=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x296ef2,_0x3eb43d);}}['getChildAfterChild'](_0x51b46e,_0xbcbf32,_0x20ef83){const _0x150b5a=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x518bb4=wu(this['writes_'],_0x150b5a,_0xbcbf32,0x1,_0x20ef83,_0x51b46e);return _0x518bb4['length']===0x0?null:_0x518bb4[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3cce53){return{'filter':_0x3cce53};}function bu(_0x564900,_0x3e6192){f(_0x3e6192['eventCache']['getNode']()['isIndexed'](_0x564900['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3e6192['serverCache']['getNode']()['isIndexed'](_0x564900['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x35655a,_0x4664e6,_0x44449d,_0xa8314b,_0x3d52b7){const _0xe5c5d5=new Cu();let _0xbca1ae,_0x4d6ed3;if(_0x44449d['type']===z['OVERWRITE']){const _0x27ad89=_0x44449d;_0x27ad89['source']['fromUser']?_0xbca1ae=ki(_0x35655a,_0x4664e6,_0x27ad89['path'],_0x27ad89['snap'],_0xa8314b,_0x3d52b7,_0xe5c5d5):(f(_0x27ad89['source']['fromServer'],'Unknown\x20source.'),_0x4d6ed3=_0x27ad89['source']['tagged']||_0x4664e6['serverCache']['isFiltered']()&&!v(_0x27ad89['path']),_0xbca1ae=Sn(_0x35655a,_0x4664e6,_0x27ad89['path'],_0x27ad89['snap'],_0xa8314b,_0x3d52b7,_0x4d6ed3,_0xe5c5d5));}else{if(_0x44449d['type']===z['MERGE']){const _0x33367b=_0x44449d;_0x33367b['source']['fromUser']?_0xbca1ae=ku(_0x35655a,_0x4664e6,_0x33367b['path'],_0x33367b['children'],_0xa8314b,_0x3d52b7,_0xe5c5d5):(f(_0x33367b['source']['fromServer'],'Unknown\x20source.'),_0x4d6ed3=_0x33367b['source']['tagged']||_0x4664e6['serverCache']['isFiltered'](),_0xbca1ae=Pi(_0x35655a,_0x4664e6,_0x33367b['path'],_0x33367b['children'],_0xa8314b,_0x3d52b7,_0x4d6ed3,_0xe5c5d5));}else{if(_0x44449d['type']===z['ACK_USER_WRITE']){const _0x1cc0b2=_0x44449d;_0x1cc0b2['revert']?_0xbca1ae=Ou(_0x35655a,_0x4664e6,_0x1cc0b2['path'],_0xa8314b,_0x3d52b7,_0xe5c5d5):_0xbca1ae=Pu(_0x35655a,_0x4664e6,_0x1cc0b2['path'],_0x1cc0b2['affectedTree'],_0xa8314b,_0x3d52b7,_0xe5c5d5);}else{if(_0x44449d['type']===z['LISTEN_COMPLETE'])_0xbca1ae=Nu(_0x35655a,_0x4664e6,_0x44449d['path'],_0xa8314b,_0xe5c5d5);else throw ht('Unknown\x20operation\x20type:\x20'+_0x44449d['type']);}}}const _0x21d890=_0xe5c5d5['getChanges']();return Au(_0x4664e6,_0xbca1ae,_0x21d890),{'viewCache':_0xbca1ae,'changes':_0x21d890};}function Au(_0x444438,_0x4c6e39,_0x113089){const _0x40abd5=_0x4c6e39['eventCache'];if(_0x40abd5['isFullyInitialized']()){const _0x5a5fc6=_0x40abd5['getNode']()['isLeafNode']()||_0x40abd5['getNode']()['isEmpty'](),_0x3fd483=wn(_0x444438);(_0x113089['length']>0x0||!_0x444438['eventCache']['isFullyInitialized']()||_0x5a5fc6&&!_0x40abd5['getNode']()['equals'](_0x3fd483)||!_0x40abd5['getNode']()['getPriority']()['equals'](_0x3fd483['getPriority']()))&&_0x113089['push'](Lo(wn(_0x4c6e39)));}}function Go(_0xfb62d4,_0x17f39a,_0x3e40fb,_0x2a9d27,_0xbeeacd,_0x3071a8){const _0x5256a6=_0x17f39a['eventCache'];if(Tn(_0x2a9d27,_0x3e40fb)!=null)return _0x17f39a;{let _0x55cf45,_0x4b0420;if(v(_0x3e40fb)){if(f(_0x17f39a['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x17f39a['serverCache']['isFiltered']()){const _0x275bcb=Ve(_0x17f39a),_0x175f9b=_0x275bcb instanceof g?_0x275bcb:g['EMPTY_NODE'],_0xfad3de=is(_0x2a9d27,_0x175f9b);_0x55cf45=_0xfb62d4['filter']['updateFullNode'](_0x17f39a['eventCache']['getNode'](),_0xfad3de,_0x3071a8);}else{const _0x14d9a6=Cn(_0x2a9d27,Ve(_0x17f39a));_0x55cf45=_0xfb62d4['filter']['updateFullNode'](_0x17f39a['eventCache']['getNode'](),_0x14d9a6,_0x3071a8);}}else{const _0x48f909=y(_0x3e40fb);if(_0x48f909==='.priority'){f(Ce(_0x3e40fb)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2377cd=_0x5256a6['getNode']();_0x4b0420=_0x17f39a['serverCache']['getNode']();const _0xe36802=cr(_0x2a9d27,_0x3e40fb,_0x2377cd,_0x4b0420);_0xe36802!=null?_0x55cf45=_0xfb62d4['filter']['updatePriority'](_0x2377cd,_0xe36802):_0x55cf45=_0x5256a6['getNode']();}else{const _0xb251ab=S(_0x3e40fb);let _0x266c72;if(_0x5256a6['isCompleteForChild'](_0x48f909)){_0x4b0420=_0x17f39a['serverCache']['getNode']();const _0xdc4eed=cr(_0x2a9d27,_0x3e40fb,_0x5256a6['getNode'](),_0x4b0420);_0xdc4eed!=null?_0x266c72=_0x5256a6['getNode']()['getImmediateChild'](_0x48f909)['updateChild'](_0xb251ab,_0xdc4eed):_0x266c72=_0x5256a6['getNode']()['getImmediateChild'](_0x48f909);}else _0x266c72=ss(_0x2a9d27,_0x48f909,_0x17f39a['serverCache']);_0x266c72!=null?_0x55cf45=_0xfb62d4['filter']['updateChild'](_0x5256a6['getNode'](),_0x48f909,_0x266c72,_0xb251ab,_0xbeeacd,_0x3071a8):_0x55cf45=_0x5256a6['getNode']();}}return Rt(_0x17f39a,_0x55cf45,_0x5256a6['isFullyInitialized']()||v(_0x3e40fb),_0xfb62d4['filter']['filtersNodes']());}}function Sn(_0x52d78c,_0x2509de,_0x485d5f,_0x2b46a6,_0x418f76,_0x2fe3bc,_0x8bc8fb,_0x4b9011){const _0x22d84a=_0x2509de['serverCache'];let _0x4cdb10;const _0x1783e2=_0x8bc8fb?_0x52d78c['filter']:_0x52d78c['filter']['getIndexedFilter']();if(v(_0x485d5f))_0x4cdb10=_0x1783e2['updateFullNode'](_0x22d84a['getNode'](),_0x2b46a6,null);else{if(_0x1783e2['filtersNodes']()&&!_0x22d84a['isFiltered']()){const _0x2259bd=_0x22d84a['getNode']()['updateChild'](_0x485d5f,_0x2b46a6);_0x4cdb10=_0x1783e2['updateFullNode'](_0x22d84a['getNode'](),_0x2259bd,null);}else{const _0x132c6c=y(_0x485d5f);if(!_0x22d84a['isCompleteForPath'](_0x485d5f)&&Ce(_0x485d5f)>0x1)return _0x2509de;const _0x46d219=S(_0x485d5f),_0x40c6a9=_0x22d84a['getNode']()['getImmediateChild'](_0x132c6c)['updateChild'](_0x46d219,_0x2b46a6);_0x132c6c==='.priority'?_0x4cdb10=_0x1783e2['updatePriority'](_0x22d84a['getNode'](),_0x40c6a9):_0x4cdb10=_0x1783e2['updateChild'](_0x22d84a['getNode'](),_0x132c6c,_0x40c6a9,_0x46d219,$o,null);}}const _0x33ddbb=Fo(_0x2509de,_0x4cdb10,_0x22d84a['isFullyInitialized']()||v(_0x485d5f),_0x1783e2['filtersNodes']()),_0x1d16dd=new rs(_0x418f76,_0x33ddbb,_0x2fe3bc);return Go(_0x52d78c,_0x33ddbb,_0x485d5f,_0x418f76,_0x1d16dd,_0x4b9011);}function ki(_0x496dc9,_0x489b0c,_0x449780,_0x5f0349,_0x5723d4,_0x26c417,_0x5e7a39){const _0x4d00e7=_0x489b0c['eventCache'];let _0x1c2e61,_0x56dd7d;const _0x5e86ea=new rs(_0x5723d4,_0x489b0c,_0x26c417);if(v(_0x449780))_0x56dd7d=_0x496dc9['filter']['updateFullNode'](_0x489b0c['eventCache']['getNode'](),_0x5f0349,_0x5e7a39),_0x1c2e61=Rt(_0x489b0c,_0x56dd7d,!0x0,_0x496dc9['filter']['filtersNodes']());else{const _0x394f4d=y(_0x449780);if(_0x394f4d==='.priority')_0x56dd7d=_0x496dc9['filter']['updatePriority'](_0x489b0c['eventCache']['getNode'](),_0x5f0349),_0x1c2e61=Rt(_0x489b0c,_0x56dd7d,_0x4d00e7['isFullyInitialized'](),_0x4d00e7['isFiltered']());else{const _0x35c109=S(_0x449780),_0x21e9ea=_0x4d00e7['getNode']()['getImmediateChild'](_0x394f4d);let _0x4754cb;if(v(_0x35c109))_0x4754cb=_0x5f0349;else{const _0x593d87=_0x5e86ea['getCompleteChild'](_0x394f4d);_0x593d87!=null?ji(_0x35c109)==='.priority'&&_0x593d87['getChild'](Ro(_0x35c109))['isEmpty']()?_0x4754cb=_0x593d87:_0x4754cb=_0x593d87['updateChild'](_0x35c109,_0x5f0349):_0x4754cb=g['EMPTY_NODE'];}if(_0x21e9ea['equals'](_0x4754cb))_0x1c2e61=_0x489b0c;else{const _0x1fe853=_0x496dc9['filter']['updateChild'](_0x4d00e7['getNode'](),_0x394f4d,_0x4754cb,_0x35c109,_0x5e86ea,_0x5e7a39);_0x1c2e61=Rt(_0x489b0c,_0x1fe853,_0x4d00e7['isFullyInitialized'](),_0x496dc9['filter']['filtersNodes']());}}}return _0x1c2e61;}function lr(_0x4ab452,_0x2fa5fe){return _0x4ab452['eventCache']['isCompleteForChild'](_0x2fa5fe);}function ku(_0x5b9e44,_0x2cbeb3,_0x358d43,_0x13936d,_0x1a16b2,_0xd12aa2,_0x3bedeb){let _0x38e6a5=_0x2cbeb3;return _0x13936d['foreach']((_0x21ea76,_0x9e3cf1)=>{const _0x4e906f=k(_0x358d43,_0x21ea76);lr(_0x2cbeb3,y(_0x4e906f))&&(_0x38e6a5=ki(_0x5b9e44,_0x38e6a5,_0x4e906f,_0x9e3cf1,_0x1a16b2,_0xd12aa2,_0x3bedeb));}),_0x13936d['foreach']((_0x3ccfc5,_0x216f76)=>{const _0x512e12=k(_0x358d43,_0x3ccfc5);lr(_0x2cbeb3,y(_0x512e12))||(_0x38e6a5=ki(_0x5b9e44,_0x38e6a5,_0x512e12,_0x216f76,_0x1a16b2,_0xd12aa2,_0x3bedeb));}),_0x38e6a5;}function hr(_0x65765a,_0x185028,_0x2648b6){return _0x2648b6['foreach']((_0x3ae096,_0x2a5bde)=>{_0x185028=_0x185028['updateChild'](_0x3ae096,_0x2a5bde);}),_0x185028;}function Pi(_0x434a3a,_0x1fc2e7,_0xb23958,_0x14965d,_0x1d4a90,_0x1c9c10,_0x260e03,_0xd84d9b){if(_0x1fc2e7['serverCache']['getNode']()['isEmpty']()&&!_0x1fc2e7['serverCache']['isFullyInitialized']())return _0x1fc2e7;let _0x5198c1=_0x1fc2e7,_0x10bbbe;v(_0xb23958)?_0x10bbbe=_0x14965d:_0x10bbbe=new b(null)['setTree'](_0xb23958,_0x14965d);const _0x1138df=_0x1fc2e7['serverCache']['getNode']();return _0x10bbbe['children']['inorderTraversal']((_0x5b34a9,_0x3600c5)=>{if(_0x1138df['hasChild'](_0x5b34a9)){const _0x3f3bd3=_0x1fc2e7['serverCache']['getNode']()['getImmediateChild'](_0x5b34a9),_0x13c60f=hr(_0x434a3a,_0x3f3bd3,_0x3600c5);_0x5198c1=Sn(_0x434a3a,_0x5198c1,new C(_0x5b34a9),_0x13c60f,_0x1d4a90,_0x1c9c10,_0x260e03,_0xd84d9b);}}),_0x10bbbe['children']['inorderTraversal']((_0x238762,_0x2ce34e)=>{const _0x14059b=!_0x1fc2e7['serverCache']['isCompleteForChild'](_0x238762)&&_0x2ce34e['value']===null;if(!_0x1138df['hasChild'](_0x238762)&&!_0x14059b){const _0x25a69d=_0x1fc2e7['serverCache']['getNode']()['getImmediateChild'](_0x238762),_0x140895=hr(_0x434a3a,_0x25a69d,_0x2ce34e);_0x5198c1=Sn(_0x434a3a,_0x5198c1,new C(_0x238762),_0x140895,_0x1d4a90,_0x1c9c10,_0x260e03,_0xd84d9b);}}),_0x5198c1;}function Pu(_0x51ce21,_0x22cb4f,_0x3264f2,_0xdb577d,_0x5674b1,_0xf31560,_0x483b60){if(Tn(_0x5674b1,_0x3264f2)!=null)return _0x22cb4f;const _0x3f1fcb=_0x22cb4f['serverCache']['isFiltered'](),_0x23dfa0=_0x22cb4f['serverCache'];if(_0xdb577d['value']!=null){if(v(_0x3264f2)&&_0x23dfa0['isFullyInitialized']()||_0x23dfa0['isCompleteForPath'](_0x3264f2))return Sn(_0x51ce21,_0x22cb4f,_0x3264f2,_0x23dfa0['getNode']()['getChild'](_0x3264f2),_0x5674b1,_0xf31560,_0x3f1fcb,_0x483b60);if(v(_0x3264f2)){let _0x421798=new b(null);return _0x23dfa0['getNode']()['forEachChild'](ve,(_0x3f90c6,_0x4e0298)=>{_0x421798=_0x421798['set'](new C(_0x3f90c6),_0x4e0298);}),Pi(_0x51ce21,_0x22cb4f,_0x3264f2,_0x421798,_0x5674b1,_0xf31560,_0x3f1fcb,_0x483b60);}else return _0x22cb4f;}else{let _0xcde65e=new b(null);return _0xdb577d['foreach']((_0x182ac8,_0x1b9492)=>{const _0x249e58=k(_0x3264f2,_0x182ac8);_0x23dfa0['isCompleteForPath'](_0x249e58)&&(_0xcde65e=_0xcde65e['set'](_0x182ac8,_0x23dfa0['getNode']()['getChild'](_0x249e58)));}),Pi(_0x51ce21,_0x22cb4f,_0x3264f2,_0xcde65e,_0x5674b1,_0xf31560,_0x3f1fcb,_0x483b60);}}function Nu(_0x483ae0,_0x5da1ec,_0x327b38,_0x546b4e,_0x190046){const _0x56f31b=_0x5da1ec['serverCache'],_0x2fa615=Fo(_0x5da1ec,_0x56f31b['getNode'](),_0x56f31b['isFullyInitialized']()||v(_0x327b38),_0x56f31b['isFiltered']());return Go(_0x483ae0,_0x2fa615,_0x327b38,_0x546b4e,$o,_0x190046);}function Ou(_0x542e85,_0x2ddb77,_0x4c6aa2,_0x19e741,_0x552152,_0x43bdeb){let _0x420a1f;if(Tn(_0x19e741,_0x4c6aa2)!=null)return _0x2ddb77;{const _0x658411=new rs(_0x19e741,_0x2ddb77,_0x552152),_0xc31bd7=_0x2ddb77['eventCache']['getNode']();let _0xe7a985;if(v(_0x4c6aa2)||y(_0x4c6aa2)==='.priority'){let _0x437091;if(_0x2ddb77['serverCache']['isFullyInitialized']())_0x437091=Cn(_0x19e741,Ve(_0x2ddb77));else{const _0xc89378=_0x2ddb77['serverCache']['getNode']();f(_0xc89378 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x437091=is(_0x19e741,_0xc89378);}_0x437091=_0x437091,_0xe7a985=_0x542e85['filter']['updateFullNode'](_0xc31bd7,_0x437091,_0x43bdeb);}else{const _0x59e72e=y(_0x4c6aa2);let _0x577a8e=ss(_0x19e741,_0x59e72e,_0x2ddb77['serverCache']);_0x577a8e==null&&_0x2ddb77['serverCache']['isCompleteForChild'](_0x59e72e)&&(_0x577a8e=_0xc31bd7['getImmediateChild'](_0x59e72e)),_0x577a8e!=null?_0xe7a985=_0x542e85['filter']['updateChild'](_0xc31bd7,_0x59e72e,_0x577a8e,S(_0x4c6aa2),_0x658411,_0x43bdeb):_0x2ddb77['eventCache']['getNode']()['hasChild'](_0x59e72e)?_0xe7a985=_0x542e85['filter']['updateChild'](_0xc31bd7,_0x59e72e,g['EMPTY_NODE'],S(_0x4c6aa2),_0x658411,_0x43bdeb):_0xe7a985=_0xc31bd7,_0xe7a985['isEmpty']()&&_0x2ddb77['serverCache']['isFullyInitialized']()&&(_0x420a1f=Cn(_0x19e741,Ve(_0x2ddb77)),_0x420a1f['isLeafNode']()&&(_0xe7a985=_0x542e85['filter']['updateFullNode'](_0xe7a985,_0x420a1f,_0x43bdeb)));}return _0x420a1f=_0x2ddb77['serverCache']['isFullyInitialized']()||Tn(_0x19e741,w())!=null,Rt(_0x2ddb77,_0xe7a985,_0x420a1f,_0x542e85['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x577313,_0x5ed915){this['query_']=_0x577313,this['eventRegistrations_']=[];const _0x321acb=this['query_']['_queryParams'],_0x37110b=new Xi(_0x321acb['getIndex']()),_0x1db4b9=Kh(_0x321acb);this['processor_']=Su(_0x1db4b9);const _0x480a5b=_0x5ed915['serverCache'],_0x5dd5e6=_0x5ed915['eventCache'],_0x46bd17=_0x37110b['updateFullNode'](g['EMPTY_NODE'],_0x480a5b['getNode'](),null),_0xe840e=_0x1db4b9['updateFullNode'](g['EMPTY_NODE'],_0x5dd5e6['getNode'](),null),_0x5eb1a6=new Te(_0x46bd17,_0x480a5b['isFullyInitialized'](),_0x37110b['filtersNodes']()),_0x4ca7e9=new Te(_0xe840e,_0x5dd5e6['isFullyInitialized'](),_0x1db4b9['filtersNodes']());this['viewCache_']=Un(_0x4ca7e9,_0x5eb1a6),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x3c1508){return _0x3c1508['viewCache_']['serverCache']['getNode']();}function Lu(_0x212213){return wn(_0x212213['viewCache_']);}function xu(_0x480f0c,_0x47575e){const _0x4b0f33=Ve(_0x480f0c['viewCache_']);return _0x4b0f33&&(_0x480f0c['query']['_queryParams']['loadsAllData']()||!v(_0x47575e)&&!_0x4b0f33['getImmediateChild'](y(_0x47575e))['isEmpty']())?_0x4b0f33['getChild'](_0x47575e):null;}function ur(_0x2ff84a){return _0x2ff84a['eventRegistrations_']['length']===0x0;}function Fu(_0x596c2b,_0xe70715){_0x596c2b['eventRegistrations_']['push'](_0xe70715);}function dr(_0x457b38,_0x47e370,_0xa63987){const _0xea18af=[];if(_0xa63987){f(_0x47e370==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x41f822=_0x457b38['query']['_path'];_0x457b38['eventRegistrations_']['forEach'](_0x246ea4=>{const _0x4a9607=_0x246ea4['createCancelEvent'](_0xa63987,_0x41f822);_0x4a9607&&_0xea18af['push'](_0x4a9607);});}if(_0x47e370){let _0x35f1f9=[];for(let _0x1a38d4=0x0;_0x1a38d4<_0x457b38['eventRegistrations_']['length'];++_0x1a38d4){const _0x1be752=_0x457b38['eventRegistrations_'][_0x1a38d4];if(!_0x1be752['matches'](_0x47e370))_0x35f1f9['push'](_0x1be752);else{if(_0x47e370['hasAnyCallback']()){_0x35f1f9=_0x35f1f9['concat'](_0x457b38['eventRegistrations_']['slice'](_0x1a38d4+0x1));break;}}}_0x457b38['eventRegistrations_']=_0x35f1f9;}else _0x457b38['eventRegistrations_']=[];return _0xea18af;}function fr(_0x54b3b3,_0xf34ca2,_0xd65bad,_0x2f7ff0){_0xf34ca2['type']===z['MERGE']&&_0xf34ca2['source']['queryId']!==null&&(f(Ve(_0x54b3b3['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x54b3b3['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x45cfbc=_0x54b3b3['viewCache_'],_0xc854d7=Ru(_0x54b3b3['processor_'],_0x45cfbc,_0xf34ca2,_0xd65bad,_0x2f7ff0);return bu(_0x54b3b3['processor_'],_0xc854d7['viewCache']),f(_0xc854d7['viewCache']['serverCache']['isFullyInitialized']()||!_0x45cfbc['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x54b3b3['viewCache_']=_0xc854d7['viewCache'],qo(_0x54b3b3,_0xc854d7['changes'],_0xc854d7['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x10bf2e,_0x473bf8){const _0xa21e6b=_0x10bf2e['viewCache_']['eventCache'],_0x5c9506=[];return _0xa21e6b['getNode']()['isLeafNode']()||_0xa21e6b['getNode']()['forEachChild'](R,(_0x4ed1c5,_0x11089d)=>{_0x5c9506['push'](rt(_0x4ed1c5,_0x11089d));}),_0xa21e6b['isFullyInitialized']()&&_0x5c9506['push'](Lo(_0xa21e6b['getNode']())),qo(_0x10bf2e,_0x5c9506,_0xa21e6b['getNode'](),_0x473bf8);}function qo(_0x3e01b9,_0x5aaea7,_0x56f494,_0x53f025){const _0x531570=_0x53f025?[_0x53f025]:_0x3e01b9['eventRegistrations_'];return ru(_0x3e01b9['eventGenerator_'],_0x5aaea7,_0x56f494,_0x531570);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x1418f4){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x1418f4;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x5812aa){return _0x5812aa['views']['size']===0x0;}function os(_0x580509,_0x1fa248,_0x50346a,_0x57da49){const _0x4ccf60=_0x1fa248['source']['queryId'];if(_0x4ccf60!==null){const _0x41b7cd=_0x580509['views']['get'](_0x4ccf60);return f(_0x41b7cd!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x41b7cd,_0x1fa248,_0x50346a,_0x57da49);}else{let _0x296e15=[];for(const _0x2a71cb of _0x580509['views']['values']())_0x296e15=_0x296e15['concat'](fr(_0x2a71cb,_0x1fa248,_0x50346a,_0x57da49));return _0x296e15;}}function jo(_0x57f021,_0x13a587,_0x377095,_0x1615c2,_0x3c138f){const _0x5da5a6=_0x13a587['_queryIdentifier'],_0x1c69c2=_0x57f021['views']['get'](_0x5da5a6);if(!_0x1c69c2){let _0x4df160=Cn(_0x377095,_0x3c138f?_0x1615c2:null),_0x4358f7=!0x1;_0x4df160?_0x4358f7=!0x0:_0x1615c2 instanceof g?(_0x4df160=is(_0x377095,_0x1615c2),_0x4358f7=!0x1):(_0x4df160=g['EMPTY_NODE'],_0x4358f7=!0x1);const _0x2cbbc2=Un(new Te(_0x4df160,_0x4358f7,!0x1),new Te(_0x1615c2,_0x3c138f,!0x1));return new Du(_0x13a587,_0x2cbbc2);}return _0x1c69c2;}function Hu(_0x3394ad,_0x1e5756,_0x315920,_0x13f548,_0x559dd6,_0x49d1d0){const _0x800228=jo(_0x3394ad,_0x1e5756,_0x13f548,_0x559dd6,_0x49d1d0);return _0x3394ad['views']['has'](_0x1e5756['_queryIdentifier'])||_0x3394ad['views']['set'](_0x1e5756['_queryIdentifier'],_0x800228),Fu(_0x800228,_0x315920),Uu(_0x800228,_0x315920);}function $u(_0x57d82e,_0x103d78,_0xfdf5b0,_0x1dc050){const _0x5159e1=_0x103d78['_queryIdentifier'],_0x27480b=[];let _0x27163b=[];const _0xd39f65=Se(_0x57d82e);if(_0x5159e1==='default'){for(const [_0x3dae76,_0x14dd2c]of _0x57d82e['views']['entries']())_0x27163b=_0x27163b['concat'](dr(_0x14dd2c,_0xfdf5b0,_0x1dc050)),ur(_0x14dd2c)&&(_0x57d82e['views']['delete'](_0x3dae76),_0x14dd2c['query']['_queryParams']['loadsAllData']()||_0x27480b['push'](_0x14dd2c['query']));}else{const _0x34392a=_0x57d82e['views']['get'](_0x5159e1);_0x34392a&&(_0x27163b=_0x27163b['concat'](dr(_0x34392a,_0xfdf5b0,_0x1dc050)),ur(_0x34392a)&&(_0x57d82e['views']['delete'](_0x5159e1),_0x34392a['query']['_queryParams']['loadsAllData']()||_0x27480b['push'](_0x34392a['query'])));}return _0xd39f65&&!Se(_0x57d82e)&&_0x27480b['push'](new(Bu())(_0x103d78['_repo'],_0x103d78['_path'])),{'removed':_0x27480b,'events':_0x27163b};}function Ko(_0x501a9b){const _0x574db5=[];for(const _0x4e9adf of _0x501a9b['views']['values']())_0x4e9adf['query']['_queryParams']['loadsAllData']()||_0x574db5['push'](_0x4e9adf);return _0x574db5;}function Ie(_0xad256e,_0x5a1617){let _0x20c8df=null;for(const _0x1a6cc4 of _0xad256e['views']['values']())_0x20c8df=_0x20c8df||xu(_0x1a6cc4,_0x5a1617);return _0x20c8df;}function Yo(_0x4de2a6,_0x36cb12){if(_0x36cb12['_queryParams']['loadsAllData']())return Bn(_0x4de2a6);{const _0xf47d02=_0x36cb12['_queryIdentifier'];return _0x4de2a6['views']['get'](_0xf47d02);}}function Qo(_0x2fc6ce,_0x5fb53b){return Yo(_0x2fc6ce,_0x5fb53b)!=null;}function Se(_0x58c880){return Bn(_0x58c880)!=null;}function Bn(_0x54278d){for(const _0x59ccf4 of _0x54278d['views']['values']())if(_0x59ccf4['query']['_queryParams']['loadsAllData']())return _0x59ccf4;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x3fdc2b){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x3fdc2b;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x120ac3){this['listenProvider_']=_0x120ac3,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x32fb41,_0x23f723,_0x4d4ba0,_0x185471,_0x227040){return lu(_0x32fb41['pendingWriteTree_'],_0x23f723,_0x4d4ba0,_0x185471,_0x227040),_0x227040?_t(_0x32fb41,new Be(es(),_0x23f723,_0x4d4ba0)):[];}function ju(_0xe9c282,_0x4216af,_0x3718cc,_0x239901){hu(_0xe9c282['pendingWriteTree_'],_0x4216af,_0x3718cc,_0x239901);const _0x2e3700=b['fromObject'](_0x3718cc);return _t(_0xe9c282,new ot(es(),_0x4216af,_0x2e3700));}function _e(_0x4c3d20,_0xb52418,_0x942eab=!0x1){const _0x589147=uu(_0x4c3d20['pendingWriteTree_'],_0xb52418);if(du(_0x4c3d20['pendingWriteTree_'],_0xb52418)){let _0x425f01=new b(null);return _0x589147['snap']!=null?_0x425f01=_0x425f01['set'](w(),!0x0):x(_0x589147['children'],_0x453ece=>{_0x425f01=_0x425f01['set'](new C(_0x453ece),!0x0);}),_t(_0x4c3d20,new In(_0x589147['path'],_0x425f01,_0x942eab));}else return[];}function Yt(_0x441292,_0x184906,_0x22da43){return _t(_0x441292,new Be(ts(),_0x184906,_0x22da43));}function Ku(_0x1f64ac,_0x332b55,_0x2fede7){const _0x491ea7=b['fromObject'](_0x2fede7);return _t(_0x1f64ac,new ot(ts(),_0x332b55,_0x491ea7));}function Yu(_0x3d6d2e,_0x4f63c4){return _t(_0x3d6d2e,new Ut(ts(),_0x4f63c4));}function Qu(_0x2b5b75,_0x2794cc,_0x1911ab){const _0x598723=cs(_0x2b5b75,_0x1911ab);if(_0x598723){const _0x4a4f3c=ls(_0x598723),_0x3005bc=_0x4a4f3c['path'],_0x1e6f84=_0x4a4f3c['queryId'],_0x43c2a9=F(_0x3005bc,_0x2794cc),_0x5adb21=new Ut(ns(_0x1e6f84),_0x43c2a9);return hs(_0x2b5b75,_0x3005bc,_0x5adb21);}else return[];}function An(_0x1f94ca,_0x286fb6,_0x3a7d36,_0x59f5ae,_0x9ce92=!0x1){const _0x5e8687=_0x286fb6['_path'],_0x20d0cd=_0x1f94ca['syncPointTree_']['get'](_0x5e8687);let _0x5f3f55=[];if(_0x20d0cd&&(_0x286fb6['_queryIdentifier']==='default'||Qo(_0x20d0cd,_0x286fb6))){const _0x43b95b=$u(_0x20d0cd,_0x286fb6,_0x3a7d36,_0x59f5ae);Vu(_0x20d0cd)&&(_0x1f94ca['syncPointTree_']=_0x1f94ca['syncPointTree_']['remove'](_0x5e8687));const _0x95a45d=_0x43b95b['removed'];if(_0x5f3f55=_0x43b95b['events'],!_0x9ce92){const _0x38b11f=_0x95a45d['findIndex'](_0x44a6af=>_0x44a6af['_queryParams']['loadsAllData']())!==-0x1,_0x12d2fb=_0x1f94ca['syncPointTree_']['findOnPath'](_0x5e8687,(_0x145ebf,_0x44b4a3)=>Se(_0x44b4a3));if(_0x38b11f&&!_0x12d2fb){const _0x2a12f5=_0x1f94ca['syncPointTree_']['subtree'](_0x5e8687);if(!_0x2a12f5['isEmpty']()){const _0x2ad1e3=Zu(_0x2a12f5);for(let _0x4bc331=0x0;_0x4bc331<_0x2ad1e3['length'];++_0x4bc331){const _0x199f12=_0x2ad1e3[_0x4bc331],_0x3efceb=_0x199f12['query'],_0x170def=ea(_0x1f94ca,_0x199f12);_0x1f94ca['listenProvider_']['startListening'](kt(_0x3efceb),Wt(_0x1f94ca,_0x3efceb),_0x170def['hashFn'],_0x170def['onComplete']);}}}!_0x12d2fb&&_0x95a45d['length']>0x0&&!_0x59f5ae&&(_0x38b11f?_0x1f94ca['listenProvider_']['stopListening'](kt(_0x286fb6),null):_0x95a45d['forEach'](_0x507b95=>{const _0x458597=_0x1f94ca['queryToTagMap']['get'](Hn(_0x507b95));_0x1f94ca['listenProvider_']['stopListening'](kt(_0x507b95),_0x458597);}));}ed(_0x1f94ca,_0x95a45d);}return _0x5f3f55;}function Jo(_0x21610a,_0x50799c,_0x39e9af,_0x32c11e){const _0x23172c=cs(_0x21610a,_0x32c11e);if(_0x23172c!=null){const _0x344465=ls(_0x23172c),_0x253687=_0x344465['path'],_0x1d27a3=_0x344465['queryId'],_0x597663=F(_0x253687,_0x50799c),_0x3fb76c=new Be(ns(_0x1d27a3),_0x597663,_0x39e9af);return hs(_0x21610a,_0x253687,_0x3fb76c);}else return[];}function Ju(_0x3949f6,_0x14735f,_0x26f7e8,_0x3bdfa4){const _0x3bc4e5=cs(_0x3949f6,_0x3bdfa4);if(_0x3bc4e5){const _0xb98594=ls(_0x3bc4e5),_0x45ff21=_0xb98594['path'],_0x222050=_0xb98594['queryId'],_0x11b9b8=F(_0x45ff21,_0x14735f),_0x937ee3=b['fromObject'](_0x26f7e8),_0x556960=new ot(ns(_0x222050),_0x11b9b8,_0x937ee3);return hs(_0x3949f6,_0x45ff21,_0x556960);}else return[];}function Ni(_0x1b6a68,_0x280aea,_0x2d4e4a,_0x48ce47=!0x1){const _0x1c813b=_0x280aea['_path'];let _0xf0b5d3=null,_0x5bea28=!0x1;_0x1b6a68['syncPointTree_']['foreachOnPath'](_0x1c813b,(_0xc0e548,_0x4407b8)=>{const _0x16bdf7=F(_0xc0e548,_0x1c813b);_0xf0b5d3=_0xf0b5d3||Ie(_0x4407b8,_0x16bdf7),_0x5bea28=_0x5bea28||Se(_0x4407b8);});let _0x12c4a0=_0x1b6a68['syncPointTree_']['get'](_0x1c813b);_0x12c4a0?(_0x5bea28=_0x5bea28||Se(_0x12c4a0),_0xf0b5d3=_0xf0b5d3||Ie(_0x12c4a0,w())):(_0x12c4a0=new zo(),_0x1b6a68['syncPointTree_']=_0x1b6a68['syncPointTree_']['set'](_0x1c813b,_0x12c4a0));let _0xf255ad;_0xf0b5d3!=null?_0xf255ad=!0x0:(_0xf255ad=!0x1,_0xf0b5d3=g['EMPTY_NODE'],_0x1b6a68['syncPointTree_']['subtree'](_0x1c813b)['foreachChild']((_0x589e23,_0x1fa13d)=>{const _0x32333d=Ie(_0x1fa13d,w());_0x32333d&&(_0xf0b5d3=_0xf0b5d3['updateImmediateChild'](_0x589e23,_0x32333d));}));const _0x463f40=Qo(_0x12c4a0,_0x280aea);if(!_0x463f40&&!_0x280aea['_queryParams']['loadsAllData']()){const _0x50b394=Hn(_0x280aea);f(!_0x1b6a68['queryToTagMap']['has'](_0x50b394),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1032ab=td();_0x1b6a68['queryToTagMap']['set'](_0x50b394,_0x1032ab),_0x1b6a68['tagToQueryMap']['set'](_0x1032ab,_0x50b394);}const _0x42bc68=Wn(_0x1b6a68['pendingWriteTree_'],_0x1c813b);let _0x58017e=Hu(_0x12c4a0,_0x280aea,_0x2d4e4a,_0x42bc68,_0xf0b5d3,_0xf255ad);if(!_0x463f40&&!_0x5bea28&&!_0x48ce47){const _0x2f90dc=Yo(_0x12c4a0,_0x280aea);_0x58017e=_0x58017e['concat'](nd(_0x1b6a68,_0x280aea,_0x2f90dc));}return _0x58017e;}function Vn(_0x2d9975,_0x25f5bb,_0x43757f){const _0x5e3bed=_0x2d9975['pendingWriteTree_'],_0x25514f=_0x2d9975['syncPointTree_']['findOnPath'](_0x25f5bb,(_0x257035,_0x26be56)=>{const _0x2c3b7c=F(_0x257035,_0x25f5bb),_0x5201ae=Ie(_0x26be56,_0x2c3b7c);if(_0x5201ae)return _0x5201ae;});return Bo(_0x5e3bed,_0x25f5bb,_0x25514f,_0x43757f,!0x0);}function Xu(_0x5e2f02,_0x1af221){const _0x5e9acf=_0x1af221['_path'];let _0x28c7fe=null;_0x5e2f02['syncPointTree_']['foreachOnPath'](_0x5e9acf,(_0x1e41e6,_0x12e679)=>{const _0x303e09=F(_0x1e41e6,_0x5e9acf);_0x28c7fe=_0x28c7fe||Ie(_0x12e679,_0x303e09);});let _0x1b4e8b=_0x5e2f02['syncPointTree_']['get'](_0x5e9acf);_0x1b4e8b?_0x28c7fe=_0x28c7fe||Ie(_0x1b4e8b,w()):(_0x1b4e8b=new zo(),_0x5e2f02['syncPointTree_']=_0x5e2f02['syncPointTree_']['set'](_0x5e9acf,_0x1b4e8b));const _0x26005f=_0x28c7fe!=null,_0x45c8a6=_0x26005f?new Te(_0x28c7fe,!0x0,!0x1):null,_0x2e7a7c=Wn(_0x5e2f02['pendingWriteTree_'],_0x1af221['_path']),_0x498cb7=jo(_0x1b4e8b,_0x1af221,_0x2e7a7c,_0x26005f?_0x45c8a6['getNode']():g['EMPTY_NODE'],_0x26005f);return Lu(_0x498cb7);}function _t(_0x499b39,_0x329142){return Xo(_0x329142,_0x499b39['syncPointTree_'],null,Wn(_0x499b39['pendingWriteTree_'],w()));}function Xo(_0x4e5ad5,_0x1de708,_0x1af793,_0x2288c6){if(v(_0x4e5ad5['path']))return Zo(_0x4e5ad5,_0x1de708,_0x1af793,_0x2288c6);{const _0x3ba264=_0x1de708['get'](w());_0x1af793==null&&_0x3ba264!=null&&(_0x1af793=Ie(_0x3ba264,w()));let _0x5908ce=[];const _0x1201cb=y(_0x4e5ad5['path']),_0x1804f7=_0x4e5ad5['operationForChild'](_0x1201cb),_0x20db05=_0x1de708['children']['get'](_0x1201cb);if(_0x20db05&&_0x1804f7){const _0x3daaf4=_0x1af793?_0x1af793['getImmediateChild'](_0x1201cb):null,_0x4b9c9b=Vo(_0x2288c6,_0x1201cb);_0x5908ce=_0x5908ce['concat'](Xo(_0x1804f7,_0x20db05,_0x3daaf4,_0x4b9c9b));}return _0x3ba264&&(_0x5908ce=_0x5908ce['concat'](os(_0x3ba264,_0x4e5ad5,_0x2288c6,_0x1af793))),_0x5908ce;}}function Zo(_0x58e888,_0xb3831c,_0xffc170,_0x58ff81){const _0xf65c76=_0xb3831c['get'](w());_0xffc170==null&&_0xf65c76!=null&&(_0xffc170=Ie(_0xf65c76,w()));let _0x166020=[];return _0xb3831c['children']['inorderTraversal']((_0x3fe3e0,_0x6e8e90)=>{const _0x43c8c3=_0xffc170?_0xffc170['getImmediateChild'](_0x3fe3e0):null,_0x19e755=Vo(_0x58ff81,_0x3fe3e0),_0xe18a2a=_0x58e888['operationForChild'](_0x3fe3e0);_0xe18a2a&&(_0x166020=_0x166020['concat'](Zo(_0xe18a2a,_0x6e8e90,_0x43c8c3,_0x19e755)));}),_0xf65c76&&(_0x166020=_0x166020['concat'](os(_0xf65c76,_0x58e888,_0x58ff81,_0xffc170))),_0x166020;}function ea(_0x4fc157,_0x11e3f1){const _0x55439b=_0x11e3f1['query'],_0x4adc94=Wt(_0x4fc157,_0x55439b);return{'hashFn':()=>(Mu(_0x11e3f1)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x238d5c=>{if(_0x238d5c==='ok')return _0x4adc94?Qu(_0x4fc157,_0x55439b['_path'],_0x4adc94):Yu(_0x4fc157,_0x55439b['_path']);{const _0x594c22=Kl(_0x238d5c,_0x55439b);return An(_0x4fc157,_0x55439b,null,_0x594c22);}}};}function Wt(_0x534e39,_0x464e11){const _0x5b1d18=Hn(_0x464e11);return _0x534e39['queryToTagMap']['get'](_0x5b1d18);}function Hn(_0x31e605){return _0x31e605['_path']['toString']()+'$'+_0x31e605['_queryIdentifier'];}function cs(_0xce52d8,_0x3d92c0){return _0xce52d8['tagToQueryMap']['get'](_0x3d92c0);}function ls(_0x28b8f3){const _0x624962=_0x28b8f3['indexOf']('$');return f(_0x624962!==-0x1&&_0x624962<_0x28b8f3['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x28b8f3['substr'](_0x624962+0x1),'path':new C(_0x28b8f3['substr'](0x0,_0x624962))};}function hs(_0x42465a,_0x27d8f2,_0x4e300b){const _0x280c33=_0x42465a['syncPointTree_']['get'](_0x27d8f2);f(_0x280c33,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2900d1=Wn(_0x42465a['pendingWriteTree_'],_0x27d8f2);return os(_0x280c33,_0x4e300b,_0x2900d1,null);}function Zu(_0x48d134){return _0x48d134['fold']((_0xbafe17,_0x5535fc,_0xeb0f45)=>{if(_0x5535fc&&Se(_0x5535fc))return[Bn(_0x5535fc)];{let _0x310bbd=[];return _0x5535fc&&(_0x310bbd=Ko(_0x5535fc)),x(_0xeb0f45,(_0x42d831,_0x46bba1)=>{_0x310bbd=_0x310bbd['concat'](_0x46bba1);}),_0x310bbd;}});}function kt(_0x2cda1d){return _0x2cda1d['_queryParams']['loadsAllData']()&&!_0x2cda1d['_queryParams']['isDefault']()?new(qu())(_0x2cda1d['_repo'],_0x2cda1d['_path']):_0x2cda1d;}function ed(_0x19aea1,_0x4df52d){for(let _0x293190=0x0;_0x293190<_0x4df52d['length'];++_0x293190){const _0x396ae0=_0x4df52d[_0x293190];if(!_0x396ae0['_queryParams']['loadsAllData']()){const _0x3fa569=Hn(_0x396ae0),_0x369dfa=_0x19aea1['queryToTagMap']['get'](_0x3fa569);_0x19aea1['queryToTagMap']['delete'](_0x3fa569),_0x19aea1['tagToQueryMap']['delete'](_0x369dfa);}}}function td(){return zu++;}function nd(_0x5d6346,_0x4533b9,_0x324c86){const _0xc801e1=_0x4533b9['_path'],_0x53581a=Wt(_0x5d6346,_0x4533b9),_0x4f719e=ea(_0x5d6346,_0x324c86),_0x183975=_0x5d6346['listenProvider_']['startListening'](kt(_0x4533b9),_0x53581a,_0x4f719e['hashFn'],_0x4f719e['onComplete']),_0x2d524d=_0x5d6346['syncPointTree_']['subtree'](_0xc801e1);if(_0x53581a)f(!Se(_0x2d524d['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x38891b=_0x2d524d['fold']((_0x1b244d,_0x1cb0e5,_0x373f38)=>{if(!v(_0x1b244d)&&_0x1cb0e5&&Se(_0x1cb0e5))return[Bn(_0x1cb0e5)['query']];{let _0x312f27=[];return _0x1cb0e5&&(_0x312f27=_0x312f27['concat'](Ko(_0x1cb0e5)['map'](_0x1220f2=>_0x1220f2['query']))),x(_0x373f38,(_0x4ed259,_0x48fbc2)=>{_0x312f27=_0x312f27['concat'](_0x48fbc2);}),_0x312f27;}});for(let _0x43db6c=0x0;_0x43db6c<_0x38891b['length'];++_0x43db6c){const _0x3ea4ec=_0x38891b[_0x43db6c];_0x5d6346['listenProvider_']['stopListening'](kt(_0x3ea4ec),Wt(_0x5d6346,_0x3ea4ec));}}return _0x183975;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x27a4b4){this['node_']=_0x27a4b4;}['getImmediateChild'](_0x5d55ed){const _0x2e8bc8=this['node_']['getImmediateChild'](_0x5d55ed);return new us(_0x2e8bc8);}['node'](){return this['node_'];}}class ds{constructor(_0x49377a,_0x36ec52){this['syncTree_']=_0x49377a,this['path_']=_0x36ec52;}['getImmediateChild'](_0x3dfcb1){const _0x3dbf66=k(this['path_'],_0x3dfcb1);return new ds(this['syncTree_'],_0x3dbf66);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x3917fc){return _0x3917fc=_0x3917fc||{},_0x3917fc['timestamp']=_0x3917fc['timestamp']||new Date()['getTime'](),_0x3917fc;},_r=function(_0x5c7d8e,_0x380665,_0x457f4f){if(!_0x5c7d8e||typeof _0x5c7d8e!='object')return _0x5c7d8e;if(f('.sv'in _0x5c7d8e,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5c7d8e['.sv']=='string')return sd(_0x5c7d8e['.sv'],_0x380665,_0x457f4f);if(typeof _0x5c7d8e['.sv']=='object')return rd(_0x5c7d8e['.sv'],_0x380665);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5c7d8e,null,0x2));},sd=function(_0x1aebf1,_0x4e5ce1,_0x5d80c9){switch(_0x1aebf1){case'timestamp':return _0x5d80c9['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1aebf1);}},rd=function(_0x58257c,_0x59bfd3,_0x1624ce){_0x58257c['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x58257c,null,0x2));const _0x22cace=_0x58257c['increment'];typeof _0x22cace!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x22cace);const _0x2e7019=_0x59bfd3['node']();if(f(_0x2e7019!==null&&typeof _0x2e7019<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x2e7019['isLeafNode']())return _0x22cace;const _0x46f323=_0x2e7019['getValue']();return typeof _0x46f323!='number'?_0x22cace:_0x46f323+_0x22cace;},ta=function(_0x1400c1,_0x3e1419,_0x58af40,_0x2dfebc){return ps(_0x3e1419,new ds(_0x58af40,_0x1400c1),_0x2dfebc);},fs=function(_0xeb9d87,_0x18b0ff,_0x34be27){return ps(_0xeb9d87,new us(_0x18b0ff),_0x34be27);};function ps(_0x2a5b45,_0x43ae38,_0x1ee4ce){const _0x3239ce=_0x2a5b45['getPriority']()['val'](),_0x3b0aa4=_r(_0x3239ce,_0x43ae38['getImmediateChild']('.priority'),_0x1ee4ce);let _0x139787;if(_0x2a5b45['isLeafNode']()){const _0x260956=_0x2a5b45,_0x38c6e9=_r(_0x260956['getValue'](),_0x43ae38,_0x1ee4ce);return _0x38c6e9!==_0x260956['getValue']()||_0x3b0aa4!==_0x260956['getPriority']()['val']()?new D(_0x38c6e9,A(_0x3b0aa4)):_0x2a5b45;}else{const _0x2fca3c=_0x2a5b45;return _0x139787=_0x2fca3c,_0x3b0aa4!==_0x2fca3c['getPriority']()['val']()&&(_0x139787=_0x139787['updatePriority'](new D(_0x3b0aa4))),_0x2fca3c['forEachChild'](R,(_0x265ba7,_0xe48dba)=>{const _0x3877b7=ps(_0xe48dba,_0x43ae38['getImmediateChild'](_0x265ba7),_0x1ee4ce);_0x3877b7!==_0xe48dba&&(_0x139787=_0x139787['updateImmediateChild'](_0x265ba7,_0x3877b7));}),_0x139787;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x5f2411='',_0x4ccf30=null,_0x112986={'children':{},'childCount':0x0}){this['name']=_0x5f2411,this['parent']=_0x4ccf30,this['node']=_0x112986;}}function $n(_0x3b3d3f,_0xbf1489){let _0x4af2e5=_0xbf1489 instanceof C?_0xbf1489:new C(_0xbf1489),_0x520f74=_0x3b3d3f,_0xa625b9=y(_0x4af2e5);for(;_0xa625b9!==null;){const _0x52685e=Le(_0x520f74['node']['children'],_0xa625b9)||{'children':{},'childCount':0x0};_0x520f74=new _s(_0xa625b9,_0x520f74,_0x52685e),_0x4af2e5=S(_0x4af2e5),_0xa625b9=y(_0x4af2e5);}return _0x520f74;}function je(_0x27f363){return _0x27f363['node']['value'];}function gs(_0x420b8d,_0x1bbd04){_0x420b8d['node']['value']=_0x1bbd04,Oi(_0x420b8d);}function na(_0x1db69f){return _0x1db69f['node']['childCount']>0x0;}function od(_0x1b8579){return je(_0x1b8579)===void 0x0&&!na(_0x1b8579);}function Gn(_0x566e31,_0x33f6ed){x(_0x566e31['node']['children'],(_0x246ae4,_0x11f597)=>{_0x33f6ed(new _s(_0x246ae4,_0x566e31,_0x11f597));});}function ia(_0xc20662,_0x58498a,_0x28d9e2,_0x47de28){_0x28d9e2&&_0x58498a(_0xc20662),Gn(_0xc20662,_0x203e16=>{ia(_0x203e16,_0x58498a,!0x0);});}function ad(_0x2f04fb,_0xa0d1cc,_0x210108){let _0x486c36=_0x2f04fb['parent'];for(;_0x486c36!==null;){if(_0xa0d1cc(_0x486c36))return!0x0;_0x486c36=_0x486c36['parent'];}return!0x1;}function Qt(_0x902339){return new C(_0x902339['parent']===null?_0x902339['name']:Qt(_0x902339['parent'])+'/'+_0x902339['name']);}function Oi(_0x441af4){_0x441af4['parent']!==null&&cd(_0x441af4['parent'],_0x441af4['name'],_0x441af4);}function cd(_0x6252f6,_0x548ac7,_0x4e0ea4){const _0x5c9692=od(_0x4e0ea4),_0x2ab7c8=Q(_0x6252f6['node']['children'],_0x548ac7);_0x5c9692&&_0x2ab7c8?(delete _0x6252f6['node']['children'][_0x548ac7],_0x6252f6['node']['childCount']--,Oi(_0x6252f6)):!_0x5c9692&&!_0x2ab7c8&&(_0x6252f6['node']['children'][_0x548ac7]=_0x4e0ea4['node'],_0x6252f6['node']['childCount']++,Oi(_0x6252f6));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x4c03b4){return typeof _0x4c03b4=='string'&&_0x4c03b4['length']!==0x0&&!ld['test'](_0x4c03b4);},sa=function(_0x3201e0){return typeof _0x3201e0=='string'&&_0x3201e0['length']!==0x0&&!hd['test'](_0x3201e0);},ud=function(_0x10abd4){return _0x10abd4&&(_0x10abd4=_0x10abd4['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x10abd4);},Bt=function(_0x4160d3){return _0x4160d3===null||typeof _0x4160d3=='string'||typeof _0x4160d3=='number'&&!xn(_0x4160d3)||_0x4160d3&&typeof _0x4160d3=='object'&&Q(_0x4160d3,'.sv');},He=function(_0x1f6a7a,_0xbe87fc,_0x40f222,_0x320f1e){_0x320f1e&&_0xbe87fc===void 0x0||Jt(it(_0x1f6a7a,'value'),_0xbe87fc,_0x40f222);},Jt=function(_0x3804fa,_0x31cce8,_0x5cba1c){const _0x3df4f8=_0x5cba1c instanceof C?new Ah(_0x5cba1c,_0x3804fa):_0x5cba1c;if(_0x31cce8===void 0x0)throw new Error(_0x3804fa+'contains\x20undefined\x20'+Oe(_0x3df4f8));if(typeof _0x31cce8=='function')throw new Error(_0x3804fa+'contains\x20a\x20function\x20'+Oe(_0x3df4f8)+'\x20with\x20contents\x20=\x20'+_0x31cce8['toString']());if(xn(_0x31cce8))throw new Error(_0x3804fa+'contains\x20'+_0x31cce8['toString']()+'\x20'+Oe(_0x3df4f8));if(typeof _0x31cce8=='string'&&_0x31cce8['length']>ui/0x3&&Ln(_0x31cce8)>ui)throw new Error(_0x3804fa+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x3df4f8)+'\x20(\x27'+_0x31cce8['substring'](0x0,0x32)+'...\x27)');if(_0x31cce8&&typeof _0x31cce8=='object'){let _0x421f13=!0x1,_0xb8f678=!0x1;if(x(_0x31cce8,(_0x1dd1ee,_0x27b8a9)=>{if(_0x1dd1ee==='.value')_0x421f13=!0x0;else{if(_0x1dd1ee!=='.priority'&&_0x1dd1ee!=='.sv'&&(_0xb8f678=!0x0,!ms(_0x1dd1ee)))throw new Error(_0x3804fa+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1dd1ee+')\x20'+Oe(_0x3df4f8)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x3df4f8,_0x1dd1ee),Jt(_0x3804fa,_0x27b8a9,_0x3df4f8),Ph(_0x3df4f8);}),_0x421f13&&_0xb8f678)throw new Error(_0x3804fa+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x3df4f8)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x1fbb7c,_0x58023a){let _0x2fadc9,_0x3e5b38;for(_0x2fadc9=0x0;_0x2fadc9<_0x58023a['length'];_0x2fadc9++){_0x3e5b38=_0x58023a[_0x2fadc9];const _0x13b11b=Mt(_0x3e5b38);for(let _0x553439=0x0;_0x553439<_0x13b11b['length'];_0x553439++)if(!(_0x13b11b[_0x553439]==='.priority'&&_0x553439===_0x13b11b['length']-0x1)){if(!ms(_0x13b11b[_0x553439]))throw new Error(_0x1fbb7c+'contains\x20an\x20invalid\x20key\x20('+_0x13b11b[_0x553439]+')\x20in\x20path\x20'+_0x3e5b38['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x58023a['sort'](Rh);let _0x536cff=null;for(_0x2fadc9=0x0;_0x2fadc9<_0x58023a['length'];_0x2fadc9++){if(_0x3e5b38=_0x58023a[_0x2fadc9],_0x536cff!==null&&G(_0x536cff,_0x3e5b38))throw new Error(_0x1fbb7c+'contains\x20a\x20path\x20'+_0x536cff['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3e5b38['toString']());_0x536cff=_0x3e5b38;}},ra=function(_0x18811a,_0x22b038,_0x341ea2,_0x482979){const _0x50bc07=it(_0x18811a,'values');if(!(_0x22b038&&typeof _0x22b038=='object')||Array['isArray'](_0x22b038))throw new Error(_0x50bc07+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3a631e=[];x(_0x22b038,(_0x4c5192,_0x102281)=>{const _0xe133c9=new C(_0x4c5192);if(Jt(_0x50bc07,_0x102281,k(_0x341ea2,_0xe133c9)),ji(_0xe133c9)==='.priority'&&!Bt(_0x102281))throw new Error(_0x50bc07+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0xe133c9['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3a631e['push'](_0xe133c9);}),dd(_0x50bc07,_0x3a631e);},fd=function(_0x479ac9,_0x69ab96,_0x3c1459){if(xn(_0x69ab96))throw new Error(it(_0x479ac9,'priority')+'is\x20'+_0x69ab96['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x69ab96))throw new Error(it(_0x479ac9,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x1a0574,_0xc9df38,_0x5a7976,_0x4680a6){if(!sa(_0x5a7976))throw new Error(it(_0x1a0574,_0xc9df38)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5a7976+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x20e7a0,_0x245915,_0x2c4e96,_0x43491f){_0x2c4e96&&(_0x2c4e96=_0x2c4e96['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x20e7a0,_0x245915,_0x2c4e96);},Me=function(_0x5d1424,_0xc52bf7){if(y(_0xc52bf7)==='.info')throw new Error(_0x5d1424+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x3d4bd4,_0x2fb21e){const _0xc5c7d5=_0x2fb21e['path']['toString']();if(typeof _0x2fb21e['repoInfo']['host']!='string'||_0x2fb21e['repoInfo']['host']['length']===0x0||!ms(_0x2fb21e['repoInfo']['namespace'])&&_0x2fb21e['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xc5c7d5['length']!==0x0&&!ud(_0xc5c7d5))throw new Error(it(_0x3d4bd4,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x274cfb,_0x27cc83){let _0x4a6e6e=null;for(let _0x1b0919=0x0;_0x1b0919<_0x27cc83['length'];_0x1b0919++){const _0x328c33=_0x27cc83[_0x1b0919],_0x120d33=_0x328c33['getPath']();_0x4a6e6e!==null&&!Ki(_0x120d33,_0x4a6e6e['path'])&&(_0x274cfb['eventLists_']['push'](_0x4a6e6e),_0x4a6e6e=null),_0x4a6e6e===null&&(_0x4a6e6e={'events':[],'path':_0x120d33}),_0x4a6e6e['events']['push'](_0x328c33);}_0x4a6e6e&&_0x274cfb['eventLists_']['push'](_0x4a6e6e);}function oa(_0x59ecc3,_0x31b3e3,_0x1f3a6c){qn(_0x59ecc3,_0x1f3a6c),aa(_0x59ecc3,_0x33796f=>Ki(_0x33796f,_0x31b3e3));}function V(_0x27e4bf,_0x2b46b5,_0x290d71){qn(_0x27e4bf,_0x290d71),aa(_0x27e4bf,_0x2ac873=>G(_0x2ac873,_0x2b46b5)||G(_0x2b46b5,_0x2ac873));}function aa(_0x2a5637,_0x533e14){_0x2a5637['recursionDepth_']++;let _0x3bda4e=!0x0;for(let _0x57cd9b=0x0;_0x57cd9b<_0x2a5637['eventLists_']['length'];_0x57cd9b++){const _0x29cfcb=_0x2a5637['eventLists_'][_0x57cd9b];if(_0x29cfcb){const _0x53dd52=_0x29cfcb['path'];_0x533e14(_0x53dd52)?(md(_0x2a5637['eventLists_'][_0x57cd9b]),_0x2a5637['eventLists_'][_0x57cd9b]=null):_0x3bda4e=!0x1;}}_0x3bda4e&&(_0x2a5637['eventLists_']=[]),_0x2a5637['recursionDepth_']--;}function md(_0x4180a9){for(let _0x292ddb=0x0;_0x292ddb<_0x4180a9['events']['length'];_0x292ddb++){const _0x2241bf=_0x4180a9['events'][_0x292ddb];if(_0x2241bf!==null){_0x4180a9['events'][_0x292ddb]=null;const _0x2936ee=_0x2241bf['getEventRunner']();St&&L('event:\x20'+_0x2241bf['toString']()),ft(_0x2936ee);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x594dc9,_0x2fa65a,_0x4216de,_0x401947){this['repoInfo_']=_0x594dc9,this['forceRestClient_']=_0x2fa65a,this['authTokenProvider_']=_0x4216de,this['appCheckProvider_']=_0x401947,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x29f9ba,_0x304a3f,_0xd0be63){if(_0x29f9ba['stats_']=qi(_0x29f9ba['repoInfo_']),_0x29f9ba['forceRestClient_']||Xl())_0x29f9ba['server_']=new vn(_0x29f9ba['repoInfo_'],(_0x3de6b7,_0x29cf62,_0x468031,_0x373f7f)=>{gr(_0x29f9ba,_0x3de6b7,_0x29cf62,_0x468031,_0x373f7f);},_0x29f9ba['authTokenProvider_'],_0x29f9ba['appCheckProvider_']),setTimeout(()=>mr(_0x29f9ba,!0x0),0x0);else{if(typeof _0xd0be63<'u'&&_0xd0be63!==null){if(typeof _0xd0be63!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xd0be63);}catch(_0x588111){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x588111);}}_0x29f9ba['persistentConnection_']=new se(_0x29f9ba['repoInfo_'],_0x304a3f,(_0x47e61b,_0x52b447,_0x32a31f,_0x5926e4)=>{gr(_0x29f9ba,_0x47e61b,_0x52b447,_0x32a31f,_0x5926e4);},_0x15eb79=>{mr(_0x29f9ba,_0x15eb79);},_0x14ea67=>{Id(_0x29f9ba,_0x14ea67);},_0x29f9ba['authTokenProvider_'],_0x29f9ba['appCheckProvider_'],_0xd0be63),_0x29f9ba['server_']=_0x29f9ba['persistentConnection_'];}_0x29f9ba['authTokenProvider_']['addTokenChangeListener'](_0xc2a5b=>{_0x29f9ba['server_']['refreshAuthToken'](_0xc2a5b);}),_0x29f9ba['appCheckProvider_']['addTokenChangeListener'](_0x279ebe=>{_0x29f9ba['server_']['refreshAppCheckToken'](_0x279ebe['token']);}),_0x29f9ba['statsReporter_']=ih(_0x29f9ba['repoInfo_'],()=>new iu(_0x29f9ba['stats_'],_0x29f9ba['server_'])),_0x29f9ba['infoData_']=new Xh(),_0x29f9ba['infoSyncTree_']=new pr({'startListening':(_0x27e234,_0x4b0271,_0x31ec1d,_0x219cf9)=>{let _0x409f74=[];const _0x1d35b3=_0x29f9ba['infoData_']['getNode'](_0x27e234['_path']);return _0x1d35b3['isEmpty']()||(_0x409f74=Yt(_0x29f9ba['infoSyncTree_'],_0x27e234['_path'],_0x1d35b3),setTimeout(()=>{_0x219cf9('ok');},0x0)),_0x409f74;},'stopListening':()=>{}}),vs(_0x29f9ba,'connected',!0x1),_0x29f9ba['serverSyncTree_']=new pr({'startListening':(_0xa945aa,_0xc92324,_0x65328a,_0x1ff189)=>(_0x29f9ba['server_']['listen'](_0xa945aa,_0x65328a,_0xc92324,(_0x2b0c51,_0x3757bf)=>{const _0x1f74a9=_0x1ff189(_0x2b0c51,_0x3757bf);V(_0x29f9ba['eventQueue_'],_0xa945aa['_path'],_0x1f74a9);}),[]),'stopListening':(_0x3fe8ea,_0x1a0775)=>{_0x29f9ba['server_']['unlisten'](_0x3fe8ea,_0x1a0775);}});}function la(_0x18b5c8){const _0xa219a6=_0x18b5c8['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xa219a6;}function Xt(_0x5c6838){return id({'timestamp':la(_0x5c6838)});}function gr(_0x5b0569,_0x100463,_0x269585,_0x3db13a,_0x462303){_0x5b0569['dataUpdateCount']++;const _0x5219f6=new C(_0x100463);_0x269585=_0x5b0569['interceptServerDataCallback_']?_0x5b0569['interceptServerDataCallback_'](_0x100463,_0x269585):_0x269585;let _0x19f502=[];if(_0x462303){if(_0x3db13a){const _0x15eb3b=_n(_0x269585,_0x34d19b=>A(_0x34d19b));_0x19f502=Ju(_0x5b0569['serverSyncTree_'],_0x5219f6,_0x15eb3b,_0x462303);}else{const _0x296e58=A(_0x269585);_0x19f502=Jo(_0x5b0569['serverSyncTree_'],_0x5219f6,_0x296e58,_0x462303);}}else{if(_0x3db13a){const _0x13fa63=_n(_0x269585,_0x2aeef5=>A(_0x2aeef5));_0x19f502=Ku(_0x5b0569['serverSyncTree_'],_0x5219f6,_0x13fa63);}else{const _0x4ec54b=A(_0x269585);_0x19f502=Yt(_0x5b0569['serverSyncTree_'],_0x5219f6,_0x4ec54b);}}let _0x42495f=_0x5219f6;_0x19f502['length']>0x0&&(_0x42495f=ct(_0x5b0569,_0x5219f6)),V(_0x5b0569['eventQueue_'],_0x42495f,_0x19f502);}function mr(_0x1f1ed7,_0x10b9d2){vs(_0x1f1ed7,'connected',_0x10b9d2),_0x10b9d2===!0x1&&Sd(_0x1f1ed7);}function Id(_0x4d17d7,_0x16a4ec){x(_0x16a4ec,(_0x6b8db4,_0x2b64df)=>{vs(_0x4d17d7,_0x6b8db4,_0x2b64df);});}function vs(_0xc2023d,_0xcfe558,_0xf48eb9){const _0x21df7b=new C('/.info/'+_0xcfe558),_0x53763c=A(_0xf48eb9);_0xc2023d['infoData_']['updateSnapshot'](_0x21df7b,_0x53763c);const _0x2285bc=Yt(_0xc2023d['infoSyncTree_'],_0x21df7b,_0x53763c);V(_0xc2023d['eventQueue_'],_0x21df7b,_0x2285bc);}function zn(_0x469bb5){return _0x469bb5['nextWriteId_']++;}function wd(_0x686c41,_0xd2a1f6,_0x3b6a65){const _0xfc2877=Xu(_0x686c41['serverSyncTree_'],_0xd2a1f6);return _0xfc2877!=null?Promise['resolve'](_0xfc2877):_0x686c41['server_']['get'](_0xd2a1f6)['then'](_0x383696=>{const _0x53b12e=A(_0x383696)['withIndex'](_0xd2a1f6['_queryParams']['getIndex']());Ni(_0x686c41['serverSyncTree_'],_0xd2a1f6,_0x3b6a65,!0x0);let _0x221579;if(_0xd2a1f6['_queryParams']['loadsAllData']())_0x221579=Yt(_0x686c41['serverSyncTree_'],_0xd2a1f6['_path'],_0x53b12e);else{const _0x2926f9=Wt(_0x686c41['serverSyncTree_'],_0xd2a1f6);_0x221579=Jo(_0x686c41['serverSyncTree_'],_0xd2a1f6['_path'],_0x53b12e,_0x2926f9);}return V(_0x686c41['eventQueue_'],_0xd2a1f6['_path'],_0x221579),An(_0x686c41['serverSyncTree_'],_0xd2a1f6,_0x3b6a65,null,!0x0),_0x53b12e;},_0x978af4=>(gt(_0x686c41,'get\x20for\x20query\x20'+O(_0xd2a1f6)+'\x20failed:\x20'+_0x978af4),Promise['reject'](new Error(_0x978af4))));}function Cd(_0x4698f4,_0x167202,_0x3aaf25,_0x44d11c,_0x1a03f4){gt(_0x4698f4,'set',{'path':_0x167202['toString'](),'value':_0x3aaf25,'priority':_0x44d11c});const _0x5da096=Xt(_0x4698f4),_0x72a222=A(_0x3aaf25,_0x44d11c),_0x44d351=Vn(_0x4698f4['serverSyncTree_'],_0x167202),_0xeedabe=fs(_0x72a222,_0x44d351,_0x5da096),_0x108c1a=zn(_0x4698f4),_0x25cc83=as(_0x4698f4['serverSyncTree_'],_0x167202,_0xeedabe,_0x108c1a,!0x0);qn(_0x4698f4['eventQueue_'],_0x25cc83),_0x4698f4['server_']['put'](_0x167202['toString'](),_0x72a222['val'](!0x0),(_0x3a8bb5,_0x243e15)=>{const _0x12a28e=_0x3a8bb5==='ok';_0x12a28e||U('set\x20at\x20'+_0x167202+'\x20failed:\x20'+_0x3a8bb5);const _0x1706b7=_e(_0x4698f4['serverSyncTree_'],_0x108c1a,!_0x12a28e);V(_0x4698f4['eventQueue_'],_0x167202,_0x1706b7),be(_0x4698f4,_0x1a03f4,_0x3a8bb5,_0x243e15);});const _0x3fb396=Is(_0x4698f4,_0x167202);ct(_0x4698f4,_0x3fb396),V(_0x4698f4['eventQueue_'],_0x3fb396,[]);}function Td(_0xbb9249,_0x3c2c70,_0x178802,_0xfebeb0){gt(_0xbb9249,'update',{'path':_0x3c2c70['toString'](),'value':_0x178802});let _0x4174bd=!0x0;const _0x58f8f2=Xt(_0xbb9249),_0x7fc7d7={};if(x(_0x178802,(_0x34d498,_0x5e6c2d)=>{_0x4174bd=!0x1,_0x7fc7d7[_0x34d498]=ta(k(_0x3c2c70,_0x34d498),A(_0x5e6c2d),_0xbb9249['serverSyncTree_'],_0x58f8f2);}),_0x4174bd)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0xbb9249,_0xfebeb0,'ok',void 0x0);else{const _0x1c437e=zn(_0xbb9249),_0x51123c=ju(_0xbb9249['serverSyncTree_'],_0x3c2c70,_0x7fc7d7,_0x1c437e);qn(_0xbb9249['eventQueue_'],_0x51123c),_0xbb9249['server_']['merge'](_0x3c2c70['toString'](),_0x178802,(_0x5e2c35,_0x38e536)=>{const _0x4a2f6b=_0x5e2c35==='ok';_0x4a2f6b||U('update\x20at\x20'+_0x3c2c70+'\x20failed:\x20'+_0x5e2c35);const _0x4b5ca8=_e(_0xbb9249['serverSyncTree_'],_0x1c437e,!_0x4a2f6b),_0x58766b=_0x4b5ca8['length']>0x0?ct(_0xbb9249,_0x3c2c70):_0x3c2c70;V(_0xbb9249['eventQueue_'],_0x58766b,_0x4b5ca8),be(_0xbb9249,_0xfebeb0,_0x5e2c35,_0x38e536);}),x(_0x178802,_0x13fef9=>{const _0x58e1cd=Is(_0xbb9249,k(_0x3c2c70,_0x13fef9));ct(_0xbb9249,_0x58e1cd);}),V(_0xbb9249['eventQueue_'],_0x3c2c70,[]);}}function Sd(_0x218015){gt(_0x218015,'onDisconnectEvents');const _0x410359=Xt(_0x218015),_0xf528d9=En();Si(_0x218015['onDisconnect_'],w(),(_0x37e281,_0x43c10f)=>{const _0x30a7b2=ta(_0x37e281,_0x43c10f,_0x218015['serverSyncTree_'],_0x410359);pt(_0xf528d9,_0x37e281,_0x30a7b2);});let _0x378933=[];Si(_0xf528d9,w(),(_0x3a0b38,_0x37069c)=>{_0x378933=_0x378933['concat'](Yt(_0x218015['serverSyncTree_'],_0x3a0b38,_0x37069c));const _0x51ffb3=Is(_0x218015,_0x3a0b38);ct(_0x218015,_0x51ffb3);}),_0x218015['onDisconnect_']=En(),V(_0x218015['eventQueue_'],w(),_0x378933);}function bd(_0x2fa232,_0xf0c83d,_0x1d6d13){_0x2fa232['server_']['onDisconnectCancel'](_0xf0c83d['toString'](),(_0x5d8e74,_0x34beb8)=>{_0x5d8e74==='ok'&&Ti(_0x2fa232['onDisconnect_'],_0xf0c83d),be(_0x2fa232,_0x1d6d13,_0x5d8e74,_0x34beb8);});}function yr(_0x1714c2,_0x220276,_0x4f743d,_0x156b06){const _0x4c3fe0=A(_0x4f743d);_0x1714c2['server_']['onDisconnectPut'](_0x220276['toString'](),_0x4c3fe0['val'](!0x0),(_0x150705,_0x3f0715)=>{_0x150705==='ok'&&pt(_0x1714c2['onDisconnect_'],_0x220276,_0x4c3fe0),be(_0x1714c2,_0x156b06,_0x150705,_0x3f0715);});}function Rd(_0x168140,_0x2d6839,_0x3ac000,_0x50866b,_0x31a4b4){const _0x229a06=A(_0x3ac000,_0x50866b);_0x168140['server_']['onDisconnectPut'](_0x2d6839['toString'](),_0x229a06['val'](!0x0),(_0x13e340,_0xf06421)=>{_0x13e340==='ok'&&pt(_0x168140['onDisconnect_'],_0x2d6839,_0x229a06),be(_0x168140,_0x31a4b4,_0x13e340,_0xf06421);});}function Ad(_0x7f3c3e,_0x308b30,_0x3dce83,_0x4911c7){if(pn(_0x3dce83)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x7f3c3e,_0x4911c7,'ok',void 0x0);return;}_0x7f3c3e['server_']['onDisconnectMerge'](_0x308b30['toString'](),_0x3dce83,(_0x10716e,_0x56fc0e)=>{_0x10716e==='ok'&&x(_0x3dce83,(_0xb9de3c,_0x3e4408)=>{const _0x55d122=A(_0x3e4408);pt(_0x7f3c3e['onDisconnect_'],k(_0x308b30,_0xb9de3c),_0x55d122);}),be(_0x7f3c3e,_0x4911c7,_0x10716e,_0x56fc0e);});}function kd(_0x45f5e4,_0x35e145,_0x4097a5){let _0x3e42e0;y(_0x35e145['_path'])==='.info'?_0x3e42e0=Ni(_0x45f5e4['infoSyncTree_'],_0x35e145,_0x4097a5):_0x3e42e0=Ni(_0x45f5e4['serverSyncTree_'],_0x35e145,_0x4097a5),oa(_0x45f5e4['eventQueue_'],_0x35e145['_path'],_0x3e42e0);}function Pd(_0x7e2290,_0x2f0cc2,_0x2003b4){let _0x52b95b;y(_0x2f0cc2['_path'])==='.info'?_0x52b95b=An(_0x7e2290['infoSyncTree_'],_0x2f0cc2,_0x2003b4):_0x52b95b=An(_0x7e2290['serverSyncTree_'],_0x2f0cc2,_0x2003b4),oa(_0x7e2290['eventQueue_'],_0x2f0cc2['_path'],_0x52b95b);}function ha(_0x101bd1){_0x101bd1['persistentConnection_']&&_0x101bd1['persistentConnection_']['interrupt'](ca);}function Nd(_0x1c7fe1){_0x1c7fe1['persistentConnection_']&&_0x1c7fe1['persistentConnection_']['resume'](ca);}function gt(_0x573620,..._0x214798){let _0x39130d='';_0x573620['persistentConnection_']&&(_0x39130d=_0x573620['persistentConnection_']['id']+':'),L(_0x39130d,..._0x214798);}function be(_0x3bd964,_0x3fe3ab,_0x48e2c5,_0x18f27a){_0x3fe3ab&&ft(()=>{if(_0x48e2c5==='ok')_0x3fe3ab(null);else{const _0x5c498c=(_0x48e2c5||'error')['toUpperCase']();let _0x5d8123=_0x5c498c;_0x18f27a&&(_0x5d8123+=':\x20'+_0x18f27a);const _0x279447=new Error(_0x5d8123);_0x279447['code']=_0x5c498c,_0x3fe3ab(_0x279447);}});}function Od(_0x41e7f7,_0xa24bf7,_0x6ee1c6,_0x23c78e,_0x3a4349,_0x368c5c){gt(_0x41e7f7,'transaction\x20on\x20'+_0xa24bf7);const _0x45a3aa={'path':_0xa24bf7,'update':_0x6ee1c6,'onComplete':_0x23c78e,'status':null,'order':so(),'applyLocally':_0x368c5c,'retryCount':0x0,'unwatcher':_0x3a4349,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0xed2fee=Es(_0x41e7f7,_0xa24bf7,void 0x0);_0x45a3aa['currentInputSnapshot']=_0xed2fee;const _0x50e30e=_0x45a3aa['update'](_0xed2fee['val']());if(_0x50e30e===void 0x0)_0x45a3aa['unwatcher'](),_0x45a3aa['currentOutputSnapshotRaw']=null,_0x45a3aa['currentOutputSnapshotResolved']=null,_0x45a3aa['onComplete']&&_0x45a3aa['onComplete'](null,!0x1,_0x45a3aa['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x50e30e,_0x45a3aa['path']),_0x45a3aa['status']=0x0;const _0x4093c1=$n(_0x41e7f7['transactionQueueTree_'],_0xa24bf7),_0x2ac41e=je(_0x4093c1)||[];_0x2ac41e['push'](_0x45a3aa),gs(_0x4093c1,_0x2ac41e);let _0x425bf7;typeof _0x50e30e=='object'&&_0x50e30e!==null&&Q(_0x50e30e,'.priority')?(_0x425bf7=Le(_0x50e30e,'.priority'),f(Bt(_0x425bf7),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x425bf7=(Vn(_0x41e7f7['serverSyncTree_'],_0xa24bf7)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x29914f=Xt(_0x41e7f7),_0x3e054b=A(_0x50e30e,_0x425bf7),_0x565af4=fs(_0x3e054b,_0xed2fee,_0x29914f);_0x45a3aa['currentOutputSnapshotRaw']=_0x3e054b,_0x45a3aa['currentOutputSnapshotResolved']=_0x565af4,_0x45a3aa['currentWriteId']=zn(_0x41e7f7);const _0x494a75=as(_0x41e7f7['serverSyncTree_'],_0xa24bf7,_0x565af4,_0x45a3aa['currentWriteId'],_0x45a3aa['applyLocally']);V(_0x41e7f7['eventQueue_'],_0xa24bf7,_0x494a75),jn(_0x41e7f7,_0x41e7f7['transactionQueueTree_']);}}function Es(_0xbcabdd,_0x490586,_0x4dd7c3){return Vn(_0xbcabdd['serverSyncTree_'],_0x490586,_0x4dd7c3)||g['EMPTY_NODE'];}function jn(_0x3e18c6,_0x840c1b=_0x3e18c6['transactionQueueTree_']){if(_0x840c1b||Kn(_0x3e18c6,_0x840c1b),je(_0x840c1b)){const _0x3f6da6=da(_0x3e18c6,_0x840c1b);f(_0x3f6da6['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3f6da6['every'](_0x3e47df=>_0x3e47df['status']===0x0)&&Dd(_0x3e18c6,Qt(_0x840c1b),_0x3f6da6);}else na(_0x840c1b)&&Gn(_0x840c1b,_0x29faed=>{jn(_0x3e18c6,_0x29faed);});}function Dd(_0x4d03e8,_0x193abd,_0x14eefc){const _0x3c8cef=_0x14eefc['map'](_0x5bb308=>_0x5bb308['currentWriteId']),_0x193b91=Es(_0x4d03e8,_0x193abd,_0x3c8cef);let _0x679781=_0x193b91;const _0x4e89c1=_0x193b91['hash']();for(let _0x422c9f=0x0;_0x422c9f<_0x14eefc['length'];_0x422c9f++){const _0x5e23c7=_0x14eefc[_0x422c9f];f(_0x5e23c7['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x5e23c7['status']=0x1,_0x5e23c7['retryCount']++;const _0x58c141=F(_0x193abd,_0x5e23c7['path']);_0x679781=_0x679781['updateChild'](_0x58c141,_0x5e23c7['currentOutputSnapshotRaw']);}const _0x11c9a8=_0x679781['val'](!0x0),_0x198574=_0x193abd;_0x4d03e8['server_']['put'](_0x198574['toString'](),_0x11c9a8,_0x3ca3db=>{gt(_0x4d03e8,'transaction\x20put\x20response',{'path':_0x198574['toString'](),'status':_0x3ca3db});let _0xb86f11=[];if(_0x3ca3db==='ok'){const _0x2fdf58=[];for(let _0x305e07=0x0;_0x305e07<_0x14eefc['length'];_0x305e07++)_0x14eefc[_0x305e07]['status']=0x2,_0xb86f11=_0xb86f11['concat'](_e(_0x4d03e8['serverSyncTree_'],_0x14eefc[_0x305e07]['currentWriteId'])),_0x14eefc[_0x305e07]['onComplete']&&_0x2fdf58['push'](()=>_0x14eefc[_0x305e07]['onComplete'](null,!0x0,_0x14eefc[_0x305e07]['currentOutputSnapshotResolved'])),_0x14eefc[_0x305e07]['unwatcher']();Kn(_0x4d03e8,$n(_0x4d03e8['transactionQueueTree_'],_0x193abd)),jn(_0x4d03e8,_0x4d03e8['transactionQueueTree_']),V(_0x4d03e8['eventQueue_'],_0x193abd,_0xb86f11);for(let _0x86fb71=0x0;_0x86fb71<_0x2fdf58['length'];_0x86fb71++)ft(_0x2fdf58[_0x86fb71]);}else{if(_0x3ca3db==='datastale'){for(let _0x4913ed=0x0;_0x4913ed<_0x14eefc['length'];_0x4913ed++)_0x14eefc[_0x4913ed]['status']===0x3?_0x14eefc[_0x4913ed]['status']=0x4:_0x14eefc[_0x4913ed]['status']=0x0;}else{U('transaction\x20at\x20'+_0x198574['toString']()+'\x20failed:\x20'+_0x3ca3db);for(let _0x157c74=0x0;_0x157c74<_0x14eefc['length'];_0x157c74++)_0x14eefc[_0x157c74]['status']=0x4,_0x14eefc[_0x157c74]['abortReason']=_0x3ca3db;}ct(_0x4d03e8,_0x193abd);}},_0x4e89c1);}function ct(_0x4a6fcb,_0x2cdcc0){const _0x368d0b=ua(_0x4a6fcb,_0x2cdcc0),_0x265d1b=Qt(_0x368d0b),_0x6c6587=da(_0x4a6fcb,_0x368d0b);return Md(_0x4a6fcb,_0x6c6587,_0x265d1b),_0x265d1b;}function Md(_0x2de272,_0x51554c,_0x167457){if(_0x51554c['length']===0x0)return;const _0x1d85a7=[];let _0x5388c2=[];const _0x54e73e=_0x51554c['filter'](_0x22ccf9=>_0x22ccf9['status']===0x0)['map'](_0x462672=>_0x462672['currentWriteId']);for(let _0x32d0df=0x0;_0x32d0df<_0x51554c['length'];_0x32d0df++){const _0x7d56c4=_0x51554c[_0x32d0df],_0x53c5a4=F(_0x167457,_0x7d56c4['path']);let _0x251985=!0x1,_0x42075e;if(f(_0x53c5a4!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x7d56c4['status']===0x4)_0x251985=!0x0,_0x42075e=_0x7d56c4['abortReason'],_0x5388c2=_0x5388c2['concat'](_e(_0x2de272['serverSyncTree_'],_0x7d56c4['currentWriteId'],!0x0));else{if(_0x7d56c4['status']===0x0){if(_0x7d56c4['retryCount']>=yd)_0x251985=!0x0,_0x42075e='maxretry',_0x5388c2=_0x5388c2['concat'](_e(_0x2de272['serverSyncTree_'],_0x7d56c4['currentWriteId'],!0x0));else{const _0x5cade2=Es(_0x2de272,_0x7d56c4['path'],_0x54e73e);_0x7d56c4['currentInputSnapshot']=_0x5cade2;const _0x273a35=_0x51554c[_0x32d0df]['update'](_0x5cade2['val']());if(_0x273a35!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x273a35,_0x7d56c4['path']);let _0x35246e=A(_0x273a35);typeof _0x273a35=='object'&&_0x273a35!=null&&Q(_0x273a35,'.priority')||(_0x35246e=_0x35246e['updatePriority'](_0x5cade2['getPriority']()));const _0x30e1bc=_0x7d56c4['currentWriteId'],_0xb02a40=Xt(_0x2de272),_0x5a3b36=fs(_0x35246e,_0x5cade2,_0xb02a40);_0x7d56c4['currentOutputSnapshotRaw']=_0x35246e,_0x7d56c4['currentOutputSnapshotResolved']=_0x5a3b36,_0x7d56c4['currentWriteId']=zn(_0x2de272),_0x54e73e['splice'](_0x54e73e['indexOf'](_0x30e1bc),0x1),_0x5388c2=_0x5388c2['concat'](as(_0x2de272['serverSyncTree_'],_0x7d56c4['path'],_0x5a3b36,_0x7d56c4['currentWriteId'],_0x7d56c4['applyLocally'])),_0x5388c2=_0x5388c2['concat'](_e(_0x2de272['serverSyncTree_'],_0x30e1bc,!0x0));}else _0x251985=!0x0,_0x42075e='nodata',_0x5388c2=_0x5388c2['concat'](_e(_0x2de272['serverSyncTree_'],_0x7d56c4['currentWriteId'],!0x0));}}}V(_0x2de272['eventQueue_'],_0x167457,_0x5388c2),_0x5388c2=[],_0x251985&&(_0x51554c[_0x32d0df]['status']=0x2,function(_0xc6d309){setTimeout(_0xc6d309,Math['floor'](0x0));}(_0x51554c[_0x32d0df]['unwatcher']),_0x51554c[_0x32d0df]['onComplete']&&(_0x42075e==='nodata'?_0x1d85a7['push'](()=>_0x51554c[_0x32d0df]['onComplete'](null,!0x1,_0x51554c[_0x32d0df]['currentInputSnapshot'])):_0x1d85a7['push'](()=>_0x51554c[_0x32d0df]['onComplete'](new Error(_0x42075e),!0x1,null))));}Kn(_0x2de272,_0x2de272['transactionQueueTree_']);for(let _0x1507a1=0x0;_0x1507a1<_0x1d85a7['length'];_0x1507a1++)ft(_0x1d85a7[_0x1507a1]);jn(_0x2de272,_0x2de272['transactionQueueTree_']);}function ua(_0x1fb3ee,_0x4145fe){let _0x57c8ed,_0x5edfba=_0x1fb3ee['transactionQueueTree_'];for(_0x57c8ed=y(_0x4145fe);_0x57c8ed!==null&&je(_0x5edfba)===void 0x0;)_0x5edfba=$n(_0x5edfba,_0x57c8ed),_0x4145fe=S(_0x4145fe),_0x57c8ed=y(_0x4145fe);return _0x5edfba;}function da(_0x3a8c7f,_0x17ac1c){const _0x143b32=[];return fa(_0x3a8c7f,_0x17ac1c,_0x143b32),_0x143b32['sort']((_0x111a8,_0x4ad997)=>_0x111a8['order']-_0x4ad997['order']),_0x143b32;}function fa(_0x2e43a7,_0x186bb0,_0x138512){const _0x217de5=je(_0x186bb0);if(_0x217de5){for(let _0x51058b=0x0;_0x51058b<_0x217de5['length'];_0x51058b++)_0x138512['push'](_0x217de5[_0x51058b]);}Gn(_0x186bb0,_0x1983a7=>{fa(_0x2e43a7,_0x1983a7,_0x138512);});}function Kn(_0x1e25dc,_0x55d622){const _0x11d07a=je(_0x55d622);if(_0x11d07a){let _0x47ec69=0x0;for(let _0x47837d=0x0;_0x47837d<_0x11d07a['length'];_0x47837d++)_0x11d07a[_0x47837d]['status']!==0x2&&(_0x11d07a[_0x47ec69]=_0x11d07a[_0x47837d],_0x47ec69++);_0x11d07a['length']=_0x47ec69,gs(_0x55d622,_0x11d07a['length']>0x0?_0x11d07a:void 0x0);}Gn(_0x55d622,_0x419ee5=>{Kn(_0x1e25dc,_0x419ee5);});}function Is(_0x459834,_0x257c84){const _0x4adb86=Qt(ua(_0x459834,_0x257c84)),_0x236a26=$n(_0x459834['transactionQueueTree_'],_0x257c84);return ad(_0x236a26,_0x3c5cd0=>{di(_0x459834,_0x3c5cd0);}),di(_0x459834,_0x236a26),ia(_0x236a26,_0x3481a2=>{di(_0x459834,_0x3481a2);}),_0x4adb86;}function di(_0x1411b8,_0x596688){const _0x43e9e2=je(_0x596688);if(_0x43e9e2){const _0x6074de=[];let _0x572d9c=[],_0xa56e3b=-0x1;for(let _0x375805=0x0;_0x375805<_0x43e9e2['length'];_0x375805++)_0x43e9e2[_0x375805]['status']===0x3||(_0x43e9e2[_0x375805]['status']===0x1?(f(_0xa56e3b===_0x375805-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0xa56e3b=_0x375805,_0x43e9e2[_0x375805]['status']=0x3,_0x43e9e2[_0x375805]['abortReason']='set'):(f(_0x43e9e2[_0x375805]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x43e9e2[_0x375805]['unwatcher'](),_0x572d9c=_0x572d9c['concat'](_e(_0x1411b8['serverSyncTree_'],_0x43e9e2[_0x375805]['currentWriteId'],!0x0)),_0x43e9e2[_0x375805]['onComplete']&&_0x6074de['push'](_0x43e9e2[_0x375805]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0xa56e3b===-0x1?gs(_0x596688,void 0x0):_0x43e9e2['length']=_0xa56e3b+0x1,V(_0x1411b8['eventQueue_'],Qt(_0x596688),_0x572d9c);for(let _0x3a97bf=0x0;_0x3a97bf<_0x6074de['length'];_0x3a97bf++)ft(_0x6074de[_0x3a97bf]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x147522){let _0x28b077='';const _0x1e845b=_0x147522['split']('/');for(let _0x2ab948=0x0;_0x2ab948<_0x1e845b['length'];_0x2ab948++)if(_0x1e845b[_0x2ab948]['length']>0x0){let _0x46ad9d=_0x1e845b[_0x2ab948];try{_0x46ad9d=decodeURIComponent(_0x46ad9d['replace'](/\+/g,'\x20'));}catch{}_0x28b077+='/'+_0x46ad9d;}return _0x28b077;}function xd(_0x2cb011){const _0x2f3e06={};_0x2cb011['charAt'](0x0)==='?'&&(_0x2cb011=_0x2cb011['substring'](0x1));for(const _0x26570a of _0x2cb011['split']('&')){if(_0x26570a['length']===0x0)continue;const _0x444d1d=_0x26570a['split']('=');_0x444d1d['length']===0x2?_0x2f3e06[decodeURIComponent(_0x444d1d[0x0])]=decodeURIComponent(_0x444d1d[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x26570a+'\x27\x20in\x20query\x20\x27'+_0x2cb011+'\x27');}return _0x2f3e06;}const vr=function(_0x134874,_0x29896c){const _0x40dc1e=Fd(_0x134874),_0x447966=_0x40dc1e['namespace'];_0x40dc1e['domain']==='firebase.com'&&ae(_0x40dc1e['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x447966||_0x447966==='undefined')&&_0x40dc1e['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x40dc1e['secure']||$l();const _0x122dc3=_0x40dc1e['scheme']==='ws'||_0x40dc1e['scheme']==='wss';return{'repoInfo':new yo(_0x40dc1e['host'],_0x40dc1e['secure'],_0x447966,_0x122dc3,_0x29896c,'',_0x447966!==_0x40dc1e['subdomain']),'path':new C(_0x40dc1e['pathString'])};},Fd=function(_0x544d1b){let _0x3a4cc6='',_0x3872cc='',_0x1a9a4a='',_0x3a2bb5='',_0x23222d='',_0x401d43=!0x0,_0x518a88='https',_0x469d4f=0x1bb;if(typeof _0x544d1b=='string'){let _0x336a61=_0x544d1b['indexOf']('//');_0x336a61>=0x0&&(_0x518a88=_0x544d1b['substring'](0x0,_0x336a61-0x1),_0x544d1b=_0x544d1b['substring'](_0x336a61+0x2));let _0xd7c449=_0x544d1b['indexOf']('/');_0xd7c449===-0x1&&(_0xd7c449=_0x544d1b['length']);let _0x543876=_0x544d1b['indexOf']('?');_0x543876===-0x1&&(_0x543876=_0x544d1b['length']),_0x3a4cc6=_0x544d1b['substring'](0x0,Math['min'](_0xd7c449,_0x543876)),_0xd7c449<_0x543876&&(_0x3a2bb5=Ld(_0x544d1b['substring'](_0xd7c449,_0x543876)));const _0xb0dac0=xd(_0x544d1b['substring'](Math['min'](_0x544d1b['length'],_0x543876)));_0x336a61=_0x3a4cc6['indexOf'](':'),_0x336a61>=0x0?(_0x401d43=_0x518a88==='https'||_0x518a88==='wss',_0x469d4f=parseInt(_0x3a4cc6['substring'](_0x336a61+0x1),0xa)):_0x336a61=_0x3a4cc6['length'];const _0x5b2b39=_0x3a4cc6['slice'](0x0,_0x336a61);if(_0x5b2b39['toLowerCase']()==='localhost')_0x3872cc='localhost';else{if(_0x5b2b39['split']('.')['length']<=0x2)_0x3872cc=_0x5b2b39;else{const _0xe8d323=_0x3a4cc6['indexOf']('.');_0x1a9a4a=_0x3a4cc6['substring'](0x0,_0xe8d323)['toLowerCase'](),_0x3872cc=_0x3a4cc6['substring'](_0xe8d323+0x1),_0x23222d=_0x1a9a4a;}}'ns'in _0xb0dac0&&(_0x23222d=_0xb0dac0['ns']);}return{'host':_0x3a4cc6,'port':_0x469d4f,'domain':_0x3872cc,'subdomain':_0x1a9a4a,'secure':_0x401d43,'scheme':_0x518a88,'pathString':_0x3a2bb5,'namespace':_0x23222d};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x2729d8=0x0;const _0x4ce026=[];return function(_0xeb65c2){const _0x31ee75=_0xeb65c2===_0x2729d8;_0x2729d8=_0xeb65c2;let _0xe15392;const _0x17d261=new Array(0x8);for(_0xe15392=0x7;_0xe15392>=0x0;_0xe15392--)_0x17d261[_0xe15392]=Er['charAt'](_0xeb65c2%0x40),_0xeb65c2=Math['floor'](_0xeb65c2/0x40);f(_0xeb65c2===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5ab016=_0x17d261['join']('');if(_0x31ee75){for(_0xe15392=0xb;_0xe15392>=0x0&&_0x4ce026[_0xe15392]===0x3f;_0xe15392--)_0x4ce026[_0xe15392]=0x0;_0x4ce026[_0xe15392]++;}else{for(_0xe15392=0x0;_0xe15392<0xc;_0xe15392++)_0x4ce026[_0xe15392]=Math['floor'](Math['random']()*0x40);}for(_0xe15392=0x0;_0xe15392<0xc;_0xe15392++)_0x5ab016+=Er['charAt'](_0x4ce026[_0xe15392]);return f(_0x5ab016['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5ab016;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x18ddfd,_0x587e56,_0x56f53b,_0x1b9e69){this['eventType']=_0x18ddfd,this['eventRegistration']=_0x587e56,this['snapshot']=_0x56f53b,this['prevName']=_0x1b9e69;}['getPath'](){const _0x3dc1c6=this['snapshot']['ref'];return this['eventType']==='value'?_0x3dc1c6['_path']:_0x3dc1c6['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x264e4e,_0x129a8a,_0x2b2a25){this['eventRegistration']=_0x264e4e,this['error']=_0x129a8a,this['path']=_0x2b2a25;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x4fa317,_0x2224bd){this['snapshotCallback']=_0x4fa317,this['cancelCallback']=_0x2224bd;}['onValue'](_0x3a9a73,_0x27f245){this['snapshotCallback']['call'](null,_0x3a9a73,_0x27f245);}['onCancel'](_0x38cbb9){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x38cbb9);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5aee01){return this['snapshotCallback']===_0x5aee01['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5aee01['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5aee01['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x490078,_0x4c64c4){this['_repo']=_0x490078,this['_path']=_0x4c64c4;}['cancel'](){const _0x1a7804=new H();return bd(this['_repo'],this['_path'],_0x1a7804['wrapCallback'](()=>{})),_0x1a7804['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x2f4b71=new H();return yr(this['_repo'],this['_path'],null,_0x2f4b71['wrapCallback'](()=>{})),_0x2f4b71['promise'];}['set'](_0x14af50){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x14af50,this['_path'],!0x1);const _0x51e217=new H();return yr(this['_repo'],this['_path'],_0x14af50,_0x51e217['wrapCallback'](()=>{})),_0x51e217['promise'];}['setWithPriority'](_0x11d0ad,_0x3fe18f){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x11d0ad,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x3fe18f);const _0x12c9cf=new H();return Rd(this['_repo'],this['_path'],_0x11d0ad,_0x3fe18f,_0x12c9cf['wrapCallback'](()=>{})),_0x12c9cf['promise'];}['update'](_0x4e9d00){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x4e9d00,this['_path']);const _0x26f7dd=new H();return Ad(this['_repo'],this['_path'],_0x4e9d00,_0x26f7dd['wrapCallback'](()=>{})),_0x26f7dd['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x3ab826,_0x49f207,_0x5e2efd,_0x5d4871){this['_repo']=_0x3ab826,this['_path']=_0x49f207,this['_queryParams']=_0x5e2efd,this['_orderByCalled']=_0x5d4871;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x41a4e9=sr(this['_queryParams']),_0x2532be=$i(_0x41a4e9);return _0x2532be==='{}'?'default':_0x2532be;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x382b9e){if(_0x382b9e=P(_0x382b9e),!(_0x382b9e instanceof Ae))return!0x1;const _0x225c49=this['_repo']===_0x382b9e['_repo'],_0x579f79=Ki(this['_path'],_0x382b9e['_path']),_0x495e30=this['_queryIdentifier']===_0x382b9e['_queryIdentifier'];return _0x225c49&&_0x579f79&&_0x495e30;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x291661,_0x51f254){if(_0x291661['_orderByCalled']===!0x0)throw new Error(_0x51f254+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x588019){let _0x345e59=null,_0x58c39c=null;if(_0x588019['hasStart']()&&(_0x345e59=_0x588019['getIndexStartValue']()),_0x588019['hasEnd']()&&(_0x58c39c=_0x588019['getIndexEndValue']()),_0x588019['getIndex']()===ve){const _0xd0a454='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x420ce4='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x588019['hasStart']()){if(_0x588019['getIndexStartName']()!==We)throw new Error(_0xd0a454);if(typeof _0x345e59!='string')throw new Error(_0x420ce4);}if(_0x588019['hasEnd']()){if(_0x588019['getIndexEndName']()!==we)throw new Error(_0xd0a454);if(typeof _0x58c39c!='string')throw new Error(_0x420ce4);}}else{if(_0x588019['getIndex']()===R){if(_0x345e59!=null&&!Bt(_0x345e59)||_0x58c39c!=null&&!Bt(_0x58c39c))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x588019['getIndex']()instanceof Ji||_0x588019['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x345e59!=null&&typeof _0x345e59=='object'||_0x58c39c!=null&&typeof _0x58c39c=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x5b3ed8){if(_0x5b3ed8['hasStart']()&&_0x5b3ed8['hasEnd']()&&_0x5b3ed8['hasLimit']()&&!_0x5b3ed8['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x6d3a83,_0x899aed){super(_0x6d3a83,_0x899aed,new Zi(),!0x1);}get['parent'](){const _0x17e99b=Ro(this['_path']);return _0x17e99b===null?null:new ee(this['_repo'],_0x17e99b);}get['root'](){let _0x280c95=this;for(;_0x280c95['parent']!==null;)_0x280c95=_0x280c95['parent'];return _0x280c95;}}class lt{constructor(_0x3c11bc,_0x4bff36,_0x5551ee){this['_node']=_0x3c11bc,this['ref']=_0x4bff36,this['_index']=_0x5551ee;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x29100a){const _0x327d75=new C(_0x29100a),_0x9ca10=Vt(this['ref'],_0x29100a);return new lt(this['_node']['getChild'](_0x327d75),_0x9ca10,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x15fe13){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x41a9be,_0x313bad)=>_0x15fe13(new lt(_0x313bad,Vt(this['ref'],_0x41a9be),R)));}['hasChild'](_0x15ea4c){const _0x498022=new C(_0x15ea4c);return!this['_node']['getChild'](_0x498022)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x51fa35,_0x9c775e){return _0x51fa35=P(_0x51fa35),_0x51fa35['_checkNotDeleted']('ref'),_0x9c775e!==void 0x0?Vt(_0x51fa35['_root'],_0x9c775e):_0x51fa35['_root'];}function Vt(_0x57f6b5,_0x237dde){return _0x57f6b5=P(_0x57f6b5),y(_0x57f6b5['_path'])===null?pd('child','path',_0x237dde):ys('child','path',_0x237dde),new ee(_0x57f6b5['_repo'],k(_0x57f6b5['_path'],_0x237dde));}function v_(_0x3e7443){return _0x3e7443=P(_0x3e7443),new Vd(_0x3e7443['_repo'],_0x3e7443['_path']);}function E_(_0x119eba,_0x470645){_0x119eba=P(_0x119eba),Me('push',_0x119eba['_path']),He('push',_0x470645,_0x119eba['_path'],!0x0);const _0xee7a26=la(_0x119eba['_repo']),_0x1b0acd=Ud(_0xee7a26),_0x58fc4b=Vt(_0x119eba,_0x1b0acd),_0x7b4e9c=Vt(_0x119eba,_0x1b0acd);let _0x259d56;return _0x470645!=null?_0x259d56=Hd(_0x7b4e9c,_0x470645)['then'](()=>_0x7b4e9c):_0x259d56=Promise['resolve'](_0x7b4e9c),_0x58fc4b['then']=_0x259d56['then']['bind'](_0x259d56),_0x58fc4b['catch']=_0x259d56['then']['bind'](_0x259d56,void 0x0),_0x58fc4b;}function Hd(_0x244d00,_0x496eee){_0x244d00=P(_0x244d00),Me('set',_0x244d00['_path']),He('set',_0x496eee,_0x244d00['_path'],!0x1);const _0x4fac38=new H();return Cd(_0x244d00['_repo'],_0x244d00['_path'],_0x496eee,null,_0x4fac38['wrapCallback'](()=>{})),_0x4fac38['promise'];}function I_(_0x14e8a6,_0x51b072){ra('update',_0x51b072,_0x14e8a6['_path']);const _0xe1c2dc=new H();return Td(_0x14e8a6['_repo'],_0x14e8a6['_path'],_0x51b072,_0xe1c2dc['wrapCallback'](()=>{})),_0xe1c2dc['promise'];}function w_(_0x35f887){_0x35f887=P(_0x35f887);const _0x3e941b=new pa(()=>{}),_0x5477c3=new Qn(_0x3e941b);return wd(_0x35f887['_repo'],_0x35f887,_0x5477c3)['then'](_0x192608=>new lt(_0x192608,new ee(_0x35f887['_repo'],_0x35f887['_path']),_0x35f887['_queryParams']['getIndex']()));}class Qn{constructor(_0x42609c){this['callbackContext']=_0x42609c;}['respondsTo'](_0xdc9b27){return _0xdc9b27==='value';}['createEvent'](_0x2dd426,_0x385eb9){const _0x164b1a=_0x385eb9['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x2dd426['snapshotNode'],new ee(_0x385eb9['_repo'],_0x385eb9['_path']),_0x164b1a));}['getEventRunner'](_0x37d140){return _0x37d140['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x37d140['error']):()=>this['callbackContext']['onValue'](_0x37d140['snapshot'],null);}['createCancelEvent'](_0x2b16c5,_0x564c34){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x2b16c5,_0x564c34):null;}['matches'](_0x145768){return _0x145768 instanceof Qn?!_0x145768['callbackContext']||!this['callbackContext']?!0x0:_0x145768['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x993d87,_0x5bb9db,_0xa585d0,_0x4bea0e,_0x34ad01){const _0x112585=new pa(_0xa585d0,void 0x0),_0x84116d=new Qn(_0x112585);return kd(_0x993d87['_repo'],_0x993d87,_0x84116d),()=>Pd(_0x993d87['_repo'],_0x993d87,_0x84116d);}function Gd(_0x1f8fef,_0xf9d1dd,_0x35d296,_0x22d1d8){return $d(_0x1f8fef,'value',_0xf9d1dd);}class mt{}class ma extends mt{constructor(_0x33b820,_0x3f8e4d){super(),this['_value']=_0x33b820,this['_key']=_0x3f8e4d,this['type']='endAt';}['_apply'](_0x3b0367){He('endAt',this['_value'],_0x3b0367['_path'],!0x0);const _0x24f1f1=Jh(_0x3b0367['_queryParams'],this['_value'],this['_key']);if(ga(_0x24f1f1),Yn(_0x24f1f1),_0x3b0367['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x3b0367['_repo'],_0x3b0367['_path'],_0x24f1f1,_0x3b0367['_orderByCalled']);}}function C_(_0x893eaa,_0xbbd1a0){return new ma(_0x893eaa,_0xbbd1a0);}class ya extends mt{constructor(_0x412a54,_0x3df368){super(),this['_value']=_0x412a54,this['_key']=_0x3df368,this['type']='startAt';}['_apply'](_0x2d9f2b){He('startAt',this['_value'],_0x2d9f2b['_path'],!0x0);const _0x4e3161=Qh(_0x2d9f2b['_queryParams'],this['_value'],this['_key']);if(ga(_0x4e3161),Yn(_0x4e3161),_0x2d9f2b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x2d9f2b['_repo'],_0x2d9f2b['_path'],_0x4e3161,_0x2d9f2b['_orderByCalled']);}}function T_(_0x1dfba6=null,_0x190e3e){return new ya(_0x1dfba6,_0x190e3e);}class qd extends mt{constructor(_0x52a1c3){super(),this['_limit']=_0x52a1c3,this['type']='limitToFirst';}['_apply'](_0x23e7da){if(_0x23e7da['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x23e7da['_repo'],_0x23e7da['_path'],Yh(_0x23e7da['_queryParams'],this['_limit']),_0x23e7da['_orderByCalled']);}}function S_(_0x480ff3){if(Math['floor'](_0x480ff3)!==_0x480ff3||_0x480ff3<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x480ff3);}class zd extends mt{constructor(_0x404f54){super(),this['_path']=_0x404f54,this['type']='orderByChild';}['_apply'](_0x543efc){_a(_0x543efc,'orderByChild');const _0x45b241=new C(this['_path']);if(v(_0x45b241))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4db0f3=new Ji(_0x45b241),_0xcc940=xo(_0x543efc['_queryParams'],_0x4db0f3);return Yn(_0xcc940),new Ae(_0x543efc['_repo'],_0x543efc['_path'],_0xcc940,!0x0);}}function b_(_0x1f9a9a){if(_0x1f9a9a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1f9a9a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1f9a9a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x1f9a9a),new zd(_0x1f9a9a);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x6526bd){_a(_0x6526bd,'orderByKey');const _0x3d11f1=xo(_0x6526bd['_queryParams'],ve);return Yn(_0x3d11f1),new Ae(_0x6526bd['_repo'],_0x6526bd['_path'],_0x3d11f1,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x83d583,_0x17431d){super(),this['_value']=_0x83d583,this['_key']=_0x17431d,this['type']='equalTo';}['_apply'](_0x362414){if(He('equalTo',this['_value'],_0x362414['_path'],!0x1),_0x362414['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x362414['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x362414));}}function A_(_0x129488,_0xbc8d45){return new Kd(_0x129488,_0xbc8d45);}function k_(_0xc170c1,..._0x4c12a5){let _0xad129d=P(_0xc170c1);for(const _0x2189df of _0x4c12a5)_0xad129d=_0x2189df['_apply'](_0xad129d);return _0xad129d;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x288cab,_0x197d83,_0x1c1545,_0x200eed){const _0x3e9550=_0x197d83['lastIndexOf'](':'),_0xbe479e=_0x197d83['substring'](0x0,_0x3e9550),_0x120104=qt(_0xbe479e);_0x288cab['repoInfo_']=new yo(_0x197d83,_0x120104,_0x288cab['repoInfo_']['namespace'],_0x288cab['repoInfo_']['webSocketOnly'],_0x288cab['repoInfo_']['nodeAdmin'],_0x288cab['repoInfo_']['persistenceKey'],_0x288cab['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x1c1545),_0x200eed&&(_0x288cab['authTokenProvider_']=_0x200eed);}function Xd(_0x1c3cc3,_0x29e9c0,_0x44f4e6,_0x5a131b,_0x4c8311){let _0x502dad=_0x5a131b||_0x1c3cc3['options']['databaseURL'];_0x502dad===void 0x0&&(_0x1c3cc3['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x1c3cc3['options']['projectId']),_0x502dad=_0x1c3cc3['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x13f91f=vr(_0x502dad,_0x4c8311),_0x1298f2=_0x13f91f['repoInfo'],_0x139770;typeof process<'u'&&Bs&&(_0x139770=Bs[Yd]),_0x139770?(_0x502dad='http://'+_0x139770+'?ns='+_0x1298f2['namespace'],_0x13f91f=vr(_0x502dad,_0x4c8311),_0x1298f2=_0x13f91f['repoInfo']):_0x13f91f['repoInfo']['secure'];const _0x538294=new eh(_0x1c3cc3['name'],_0x1c3cc3['options'],_0x29e9c0);_d('Invalid\x20Firebase\x20Database\x20URL',_0x13f91f),v(_0x13f91f['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x131538=ef(_0x1298f2,_0x1c3cc3,_0x538294,new Zl(_0x1c3cc3,_0x44f4e6));return new tf(_0x131538,_0x1c3cc3);}function Zd(_0x537c9a,_0x2d10a9){const _0x1a641d=Di[_0x2d10a9];(!_0x1a641d||_0x1a641d[_0x537c9a['key']]!==_0x537c9a)&&ae('Database\x20'+_0x2d10a9+'('+_0x537c9a['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x537c9a),delete _0x1a641d[_0x537c9a['key']];}function ef(_0x93a274,_0x4f2630,_0x507993,_0x14b50e){let _0xad07e6=Di[_0x4f2630['name']];_0xad07e6||(_0xad07e6={},Di[_0x4f2630['name']]=_0xad07e6);let _0x24dbb0=_0xad07e6[_0x93a274['toURLString']()];return _0x24dbb0&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x24dbb0=new vd(_0x93a274,Qd,_0x507993,_0x14b50e),_0xad07e6[_0x93a274['toURLString']()]=_0x24dbb0,_0x24dbb0;}class tf{constructor(_0x1f4977,_0x258709){this['_repoInternal']=_0x1f4977,this['app']=_0x258709,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x385f52){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x385f52+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x4edca2=Zr(),_0x5a03d6){const _0x2bf04d=Hi(_0x4edca2,'database')['getImmediate']({'identifier':_0x5a03d6});if(!_0x2bf04d['_instanceStarted']){const _0x30ab85=hc('database');_0x30ab85&&nf(_0x2bf04d,..._0x30ab85);}return _0x2bf04d;}function nf(_0x4b4fa1,_0xc9ce0f,_0x277fa5,_0x84fa99={}){_0x4b4fa1=P(_0x4b4fa1),_0x4b4fa1['_checkNotDeleted']('useEmulator');const _0x551c98=_0xc9ce0f+':'+_0x277fa5,_0x3cb5e5=_0x4b4fa1['_repoInternal'];if(_0x4b4fa1['_instanceStarted']){if(_0x551c98===_0x4b4fa1['_repoInternal']['repoInfo_']['host']&&xe(_0x84fa99,_0x3cb5e5['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x44a96b;if(_0x3cb5e5['repoInfo_']['nodeAdmin'])_0x84fa99['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x44a96b=new an(an['OWNER']);else{if(_0x84fa99['mockUserToken']){const _0x33fc1b=typeof _0x84fa99['mockUserToken']=='string'?_0x84fa99['mockUserToken']:uc(_0x84fa99['mockUserToken'],_0x4b4fa1['app']['options']['projectId']);_0x44a96b=new an(_0x33fc1b);}}qt(_0xc9ce0f)&&Qr(_0xc9ce0f),Jd(_0x3cb5e5,_0x551c98,_0x84fa99,_0x44a96b);}function N_(_0x4b923f){_0x4b923f=P(_0x4b923f),_0x4b923f['_checkNotDeleted']('goOffline'),ha(_0x4b923f['_repo']);}function O_(_0x27f1a9){_0x27f1a9=P(_0x27f1a9),_0x27f1a9['_checkNotDeleted']('goOnline'),Nd(_0x27f1a9['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x59d99b){Ul(dt),st(new Fe('database',(_0x238f3e,{instanceIdentifier:_0x16de5e})=>{const _0x851dbe=_0x238f3e['getProvider']('app')['getImmediate'](),_0x262eab=_0x238f3e['getProvider']('auth-internal'),_0x40d7ef=_0x238f3e['getProvider']('app-check-internal');return Xd(_0x851dbe,_0x262eab,_0x40d7ef,_0x16de5e);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x59d99b),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x594229,_0x6749f1){this['committed']=_0x594229,this['snapshot']=_0x6749f1;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x6254c0,_0x337c1d,_0x443a7a){if(_0x6254c0=P(_0x6254c0),Me('Reference.transaction',_0x6254c0['_path']),_0x6254c0['key']==='.length'||_0x6254c0['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x6254c0['key']+'\x20is\x20a\x20read-only\x20object.';const _0x32751e=!0x0,_0x10323c=new H(),_0x489884=(_0x5c6089,_0xb3a2d6,_0x4ceeb5)=>{let _0x435be6=null;_0x5c6089?_0x10323c['reject'](_0x5c6089):(_0x435be6=new lt(_0x4ceeb5,new ee(_0x6254c0['_repo'],_0x6254c0['_path']),R),_0x10323c['resolve'](new of(_0xb3a2d6,_0x435be6)));},_0x3d98cd=Gd(_0x6254c0,()=>{});return Od(_0x6254c0['_repo'],_0x6254c0['_path'],_0x337c1d,_0x489884,_0x3d98cd,_0x32751e),_0x10323c['promise'];}se['prototype']['simpleListen']=function(_0x418b9a,_0x2876c1){this['sendRequest']('q',{'p':_0x418b9a},_0x2876c1);},se['prototype']['echo']=function(_0x2296c4,_0x290c5d){this['sendRequest']('echo',{'d':_0x2296c4},_0x290c5d);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x2bbfd7,..._0x30739f){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x2bbfd7,..._0x30739f);}function cn(_0x577610,..._0x5e9263){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x577610,..._0x5e9263);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x190955,..._0x4851e3){throw ws(_0x190955,..._0x4851e3);}function X(_0x35db20,..._0x25153f){return ws(_0x35db20,..._0x25153f);}function Ia(_0x5c596a,_0x5ca8dd,_0x46ad40){const _0x98d5e1={...af(),[_0x5ca8dd]:_0x46ad40};return new Gt('auth','Firebase',_0x98d5e1)['create'](_0x5ca8dd,{'appName':_0x5c596a['name']});}function re(_0x5e0f1e){return Ia(_0x5e0f1e,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1bebc5,..._0x4f0cc8){if(typeof _0x1bebc5!='string'){const _0x528eaa=_0x4f0cc8[0x0],_0x43134d=[..._0x4f0cc8['slice'](0x1)];return _0x43134d[0x0]&&(_0x43134d[0x0]['appName']=_0x1bebc5['name']),_0x1bebc5['_errorFactory']['create'](_0x528eaa,..._0x43134d);}return Ea['create'](_0x1bebc5,..._0x4f0cc8);}function m(_0x53d798,_0x1ab092,..._0xd8a130){if(!_0x53d798)throw ws(_0x1ab092,..._0xd8a130);}function ne(_0x3c0a41){const _0xbe706c='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3c0a41;throw cn(_0xbe706c),new Error(_0xbe706c);}function ce(_0x5090e2,_0x31086e){_0x5090e2||ne(_0x31086e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x2a21d2;return typeof self<'u'&&((_0x2a21d2=self['location'])==null?void 0x0:_0x2a21d2['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x4c7e7d;return typeof self<'u'&&((_0x4c7e7d=self['location'])==null?void 0x0:_0x4c7e7d['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x1affa5=navigator;return _0x1affa5['languages']&&_0x1affa5['languages'][0x0]||_0x1affa5['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x251d25,_0x3be840){this['shortDelay']=_0x251d25,this['longDelay']=_0x3be840,ce(_0x3be840>_0x251d25,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x5ba375,_0x1c5dc9){ce(_0x5ba375['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x4e5c1b}=_0x5ba375['emulator'];return _0x1c5dc9?''+_0x4e5c1b+(_0x1c5dc9['startsWith']('/')?_0x1c5dc9['slice'](0x1):_0x1c5dc9):_0x4e5c1b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x4b28d1,_0xcad24b,_0x3cf652){this['fetchImpl']=_0x4b28d1,_0xcad24b&&(this['headersImpl']=_0xcad24b),_0x3cf652&&(this['responseImpl']=_0x3cf652);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x10487e,_0xd2fd44){return _0x10487e['tenantId']&&!_0xd2fd44['tenantId']?{..._0xd2fd44,'tenantId':_0x10487e['tenantId']}:_0xd2fd44;}async function Pe(_0x28b544,_0x2824d1,_0x2f5b73,_0x20aa35,_0x8bec5d={}){return Ca(_0x28b544,_0x8bec5d,async()=>{let _0x31b6c1={},_0x369fb2={};_0x20aa35&&(_0x2824d1==='GET'?_0x369fb2=_0x20aa35:_0x31b6c1={'body':JSON['stringify'](_0x20aa35)});const _0x241957=ut({..._0x369fb2,'key':_0x28b544['config']['apiKey']})['slice'](0x1),_0x35f95c=await _0x28b544['_getAdditionalHeaders']();_0x35f95c['Content-Type']='application/json',_0x28b544['languageCode']&&(_0x35f95c['X-Firebase-Locale']=_0x28b544['languageCode']);const _0x461cc9={'method':_0x2824d1,'headers':_0x35f95c,..._0x31b6c1};return dc()||(_0x461cc9['referrerPolicy']='strict-origin-when-cross-origin'),_0x28b544['emulatorConfig']&&qt(_0x28b544['emulatorConfig']['host'])&&(_0x461cc9['credentials']='include'),wa['fetch']()(await Ta(_0x28b544,_0x28b544['config']['apiHost'],_0x2f5b73,_0x241957),_0x461cc9);});}async function Ca(_0x360eaa,_0x27a45c,_0x318013){_0x360eaa['_canInitEmulator']=!0x1;const _0x2c9da5={...df,..._0x27a45c};try{const _0x23486f=new gf(_0x360eaa),_0x5b3580=await Promise['race']([_0x318013(),_0x23486f['promise']]);_0x23486f['clearNetworkTimeout']();const _0x3f8b4a=await _0x5b3580['json']();if('needConfirmation'in _0x3f8b4a)throw on(_0x360eaa,'account-exists-with-different-credential',_0x3f8b4a);if(_0x5b3580['ok']&&!('errorMessage'in _0x3f8b4a))return _0x3f8b4a;{const _0x252c51=_0x5b3580['ok']?_0x3f8b4a['errorMessage']:_0x3f8b4a['error']['message'],[_0x16acf4,_0x38d82e]=_0x252c51['split']('\x20:\x20');if(_0x16acf4==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x360eaa,'credential-already-in-use',_0x3f8b4a);if(_0x16acf4==='EMAIL_EXISTS')throw on(_0x360eaa,'email-already-in-use',_0x3f8b4a);if(_0x16acf4==='USER_DISABLED')throw on(_0x360eaa,'user-disabled',_0x3f8b4a);const _0x4c0d51=_0x2c9da5[_0x16acf4]||_0x16acf4['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x38d82e)throw Ia(_0x360eaa,_0x4c0d51,_0x38d82e);Y(_0x360eaa,_0x4c0d51);}}catch(_0x3519f6){if(_0x3519f6 instanceof Re)throw _0x3519f6;Y(_0x360eaa,'network-request-failed',{'message':String(_0x3519f6)});}}async function en(_0x467679,_0xefd649,_0x3635d8,_0x4d34c4,_0x338ded={}){const _0x18a064=await Pe(_0x467679,_0xefd649,_0x3635d8,_0x4d34c4,_0x338ded);return'mfaPendingCredential'in _0x18a064&&Y(_0x467679,'multi-factor-auth-required',{'_serverResponse':_0x18a064}),_0x18a064;}async function Ta(_0xbe96eb,_0x51fb00,_0x14febf,_0x210247){const _0x55e990=''+_0x51fb00+_0x14febf+'?'+_0x210247,_0x127f99=_0xbe96eb,_0x1808c7=_0x127f99['config']['emulator']?Cs(_0xbe96eb['config'],_0x55e990):_0xbe96eb['config']['apiScheme']+'://'+_0x55e990;return ff['includes'](_0x14febf)&&(await _0x127f99['_persistenceManagerAvailable'],_0x127f99['_getPersistenceType']()==='COOKIE')?_0x127f99['_getPersistence']()['_getFinalTarget'](_0x1808c7)['toString']():_0x1808c7;}function _f(_0x20d35f){switch(_0x20d35f){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3ed4d7){this['auth']=_0x3ed4d7,this['timer']=null,this['promise']=new Promise((_0x3f52f5,_0x2e3fb5)=>{this['timer']=setTimeout(()=>_0x2e3fb5(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x2410d8,_0x25bf32,_0x4a5f85){const _0x467f76={'appName':_0x2410d8['name']};_0x4a5f85['email']&&(_0x467f76['email']=_0x4a5f85['email']),_0x4a5f85['phoneNumber']&&(_0x467f76['phoneNumber']=_0x4a5f85['phoneNumber']);const _0x32eea1=X(_0x2410d8,_0x25bf32,_0x467f76);return _0x32eea1['customData']['_tokenResponse']=_0x4a5f85,_0x32eea1;}function wr(_0xb65328){return _0xb65328!==void 0x0&&_0xb65328['enterprise']!==void 0x0;}class mf{constructor(_0x2bc4d6){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2bc4d6['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2bc4d6['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2bc4d6['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x14a77a){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x2fc6b7 of this['recaptchaEnforcementState'])if(_0x2fc6b7['provider']&&_0x2fc6b7['provider']===_0x14a77a)return _f(_0x2fc6b7['enforcementState']);return null;}['isProviderEnabled'](_0x2fc7af){return this['getProviderEnforcementState'](_0x2fc7af)==='ENFORCE'||this['getProviderEnforcementState'](_0x2fc7af)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x1e2d61,_0x1c6369){return Pe(_0x1e2d61,'GET','/v2/recaptchaConfig',ke(_0x1e2d61,_0x1c6369));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x564657,_0x4775cc){return Pe(_0x564657,'POST','/v1/accounts:delete',_0x4775cc);}async function Pn(_0x183e30,_0xb9c83c){return Pe(_0x183e30,'POST','/v1/accounts:lookup',_0xb9c83c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x10742f){if(_0x10742f)try{const _0x4623b6=new Date(Number(_0x10742f));if(!isNaN(_0x4623b6['getTime']()))return _0x4623b6['toUTCString']();}catch{}}async function Ef(_0x1160f4,_0x57fdd6=!0x1){const _0x1b9b4b=P(_0x1160f4),_0x500d6b=await _0x1b9b4b['getIdToken'](_0x57fdd6),_0x22c746=Ts(_0x500d6b);m(_0x22c746&&_0x22c746['exp']&&_0x22c746['auth_time']&&_0x22c746['iat'],_0x1b9b4b['auth'],'internal-error');const _0x33c8f3=typeof _0x22c746['firebase']=='object'?_0x22c746['firebase']:void 0x0,_0x51a09a=_0x33c8f3==null?void 0x0:_0x33c8f3['sign_in_provider'];return{'claims':_0x22c746,'token':_0x500d6b,'authTime':Pt(fi(_0x22c746['auth_time'])),'issuedAtTime':Pt(fi(_0x22c746['iat'])),'expirationTime':Pt(fi(_0x22c746['exp'])),'signInProvider':_0x51a09a||null,'signInSecondFactor':(_0x33c8f3==null?void 0x0:_0x33c8f3['sign_in_second_factor'])||null};}function fi(_0x1bb657){return Number(_0x1bb657)*0x3e8;}function Ts(_0x56c35f){const [_0x434294,_0x339f70,_0x53da73]=_0x56c35f['split']('.');if(_0x434294===void 0x0||_0x339f70===void 0x0||_0x53da73===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2fa1e9=fn(_0x339f70);return _0x2fa1e9?JSON['parse'](_0x2fa1e9):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4cf57e){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4cf57e==null?void 0x0:_0x4cf57e['toString']()),null;}}function Cr(_0x2131b9){const _0x2e7525=Ts(_0x2131b9);return m(_0x2e7525,'internal-error'),m(typeof _0x2e7525['exp']<'u','internal-error'),m(typeof _0x2e7525['iat']<'u','internal-error'),Number(_0x2e7525['exp'])-Number(_0x2e7525['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x2fa25a,_0x5d7de5,_0xacb4ac=!0x1){if(_0xacb4ac)return _0x5d7de5;try{return await _0x5d7de5;}catch(_0x2fe5b0){throw _0x2fe5b0 instanceof Re&&If(_0x2fe5b0)&&_0x2fa25a['auth']['currentUser']===_0x2fa25a&&await _0x2fa25a['auth']['signOut'](),_0x2fe5b0;}}function If({code:_0x370cb4}){return _0x370cb4==='auth/user-disabled'||_0x370cb4==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x4cd290){this['user']=_0x4cd290,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x28264a){if(_0x28264a){const _0x16e807=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x16e807;}else{this['errorBackoff']=0x7530;const _0x452f0e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x452f0e);}}['schedule'](_0x3b9b9d=!0x1){if(!this['isRunning'])return;const _0x36ceb8=this['getInterval'](_0x3b9b9d);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x36ceb8);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x56ecea){(_0x56ecea==null?void 0x0:_0x56ecea['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x1c0f99,_0x5f1112){this['createdAt']=_0x1c0f99,this['lastLoginAt']=_0x5f1112,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x133b1d){this['createdAt']=_0x133b1d['createdAt'],this['lastLoginAt']=_0x133b1d['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0xa387d4){var _0x336517;const _0x2740fc=_0xa387d4['auth'],_0x531894=await _0xa387d4['getIdToken'](),_0x393d2b=await Ht(_0xa387d4,Pn(_0x2740fc,{'idToken':_0x531894}));m(_0x393d2b==null?void 0x0:_0x393d2b['users']['length'],_0x2740fc,'internal-error');const _0x52a248=_0x393d2b['users'][0x0];_0xa387d4['_notifyReloadListener'](_0x52a248);const _0x265ff6=(_0x336517=_0x52a248['providerUserInfo'])!=null&&_0x336517['length']?Sa(_0x52a248['providerUserInfo']):[],_0x5d3b69=Tf(_0xa387d4['providerData'],_0x265ff6),_0x15c065=_0xa387d4['isAnonymous'],_0x152964=!(_0xa387d4['email']&&_0x52a248['passwordHash'])&&!(_0x5d3b69!=null&&_0x5d3b69['length']),_0x490e57=_0x15c065?_0x152964:!0x1,_0x5cbb62={'uid':_0x52a248['localId'],'displayName':_0x52a248['displayName']||null,'photoURL':_0x52a248['photoUrl']||null,'email':_0x52a248['email']||null,'emailVerified':_0x52a248['emailVerified']||!0x1,'phoneNumber':_0x52a248['phoneNumber']||null,'tenantId':_0x52a248['tenantId']||null,'providerData':_0x5d3b69,'metadata':new Li(_0x52a248['createdAt'],_0x52a248['lastLoginAt']),'isAnonymous':_0x490e57};Object['assign'](_0xa387d4,_0x5cbb62);}async function Cf(_0x435a3e){const _0x38ea75=P(_0x435a3e);await Nn(_0x38ea75),await _0x38ea75['auth']['_persistUserIfCurrent'](_0x38ea75),_0x38ea75['auth']['_notifyListenersIfCurrent'](_0x38ea75);}function Tf(_0x17392a,_0x3aa628){return[..._0x17392a['filter'](_0x25d5bc=>!_0x3aa628['some'](_0x1d08c3=>_0x1d08c3['providerId']===_0x25d5bc['providerId'])),..._0x3aa628];}function Sa(_0x37eb57){return _0x37eb57['map'](({providerId:_0x33ae80,..._0x1c7cbb})=>({'providerId':_0x33ae80,'uid':_0x1c7cbb['rawId']||'','displayName':_0x1c7cbb['displayName']||null,'email':_0x1c7cbb['email']||null,'phoneNumber':_0x1c7cbb['phoneNumber']||null,'photoURL':_0x1c7cbb['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x1174d5,_0x3217eb){const _0x1e1143=await Ca(_0x1174d5,{},async()=>{const _0x4c4329=ut({'grant_type':'refresh_token','refresh_token':_0x3217eb})['slice'](0x1),{tokenApiHost:_0xaebd06,apiKey:_0x962769}=_0x1174d5['config'],_0xee48ca=await Ta(_0x1174d5,_0xaebd06,'/v1/token','key='+_0x962769),_0x553bd8=await _0x1174d5['_getAdditionalHeaders']();_0x553bd8['Content-Type']='application/x-www-form-urlencoded';const _0x29bb15={'method':'POST','headers':_0x553bd8,'body':_0x4c4329};return _0x1174d5['emulatorConfig']&&qt(_0x1174d5['emulatorConfig']['host'])&&(_0x29bb15['credentials']='include'),wa['fetch']()(_0xee48ca,_0x29bb15);});return{'accessToken':_0x1e1143['access_token'],'expiresIn':_0x1e1143['expires_in'],'refreshToken':_0x1e1143['refresh_token']};}async function bf(_0x5c3ef5,_0x235909){return Pe(_0x5c3ef5,'POST','/v2/accounts:revokeToken',ke(_0x5c3ef5,_0x235909));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x457360){m(_0x457360['idToken'],'internal-error'),m(typeof _0x457360['idToken']<'u','internal-error'),m(typeof _0x457360['refreshToken']<'u','internal-error');const _0x190d51='expiresIn'in _0x457360&&typeof _0x457360['expiresIn']<'u'?Number(_0x457360['expiresIn']):Cr(_0x457360['idToken']);this['updateTokensAndExpiration'](_0x457360['idToken'],_0x457360['refreshToken'],_0x190d51);}['updateFromIdToken'](_0x1e885e){m(_0x1e885e['length']!==0x0,'internal-error');const _0x497e54=Cr(_0x1e885e);this['updateTokensAndExpiration'](_0x1e885e,null,_0x497e54);}async['getToken'](_0x1d2395,_0x357bdf=!0x1){return!_0x357bdf&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1d2395,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1d2395,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1bb331,_0x3d3cda){const {accessToken:_0x56bb67,refreshToken:_0x477c3b,expiresIn:_0x3668f4}=await Sf(_0x1bb331,_0x3d3cda);this['updateTokensAndExpiration'](_0x56bb67,_0x477c3b,Number(_0x3668f4));}['updateTokensAndExpiration'](_0x417c8f,_0x3ccb7e,_0x415fd3){this['refreshToken']=_0x3ccb7e||null,this['accessToken']=_0x417c8f||null,this['expirationTime']=Date['now']()+_0x415fd3*0x3e8;}static['fromJSON'](_0x142d99,_0x519c03){const {refreshToken:_0x4d211c,accessToken:_0x17a9a6,expirationTime:_0x2ef344}=_0x519c03,_0x3c531a=new et();return _0x4d211c&&(m(typeof _0x4d211c=='string','internal-error',{'appName':_0x142d99}),_0x3c531a['refreshToken']=_0x4d211c),_0x17a9a6&&(m(typeof _0x17a9a6=='string','internal-error',{'appName':_0x142d99}),_0x3c531a['accessToken']=_0x17a9a6),_0x2ef344&&(m(typeof _0x2ef344=='number','internal-error',{'appName':_0x142d99}),_0x3c531a['expirationTime']=_0x2ef344),_0x3c531a;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4e86df){this['accessToken']=_0x4e86df['accessToken'],this['refreshToken']=_0x4e86df['refreshToken'],this['expirationTime']=_0x4e86df['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x9ea953,_0x280b88){m(typeof _0x9ea953=='string'||typeof _0x9ea953>'u','internal-error',{'appName':_0x280b88});}class j{constructor({uid:_0x408c60,auth:_0x1bc4b4,stsTokenManager:_0x544c9e,..._0x57e01a}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x408c60,this['auth']=_0x1bc4b4,this['stsTokenManager']=_0x544c9e,this['accessToken']=_0x544c9e['accessToken'],this['displayName']=_0x57e01a['displayName']||null,this['email']=_0x57e01a['email']||null,this['emailVerified']=_0x57e01a['emailVerified']||!0x1,this['phoneNumber']=_0x57e01a['phoneNumber']||null,this['photoURL']=_0x57e01a['photoURL']||null,this['isAnonymous']=_0x57e01a['isAnonymous']||!0x1,this['tenantId']=_0x57e01a['tenantId']||null,this['providerData']=_0x57e01a['providerData']?[..._0x57e01a['providerData']]:[],this['metadata']=new Li(_0x57e01a['createdAt']||void 0x0,_0x57e01a['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2e8496){const _0x21bba9=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x2e8496));return m(_0x21bba9,this['auth'],'internal-error'),this['accessToken']!==_0x21bba9&&(this['accessToken']=_0x21bba9,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x21bba9;}['getIdTokenResult'](_0x553a5e){return Ef(this,_0x553a5e);}['reload'](){return Cf(this);}['_assign'](_0x82d13c){this!==_0x82d13c&&(m(this['uid']===_0x82d13c['uid'],this['auth'],'internal-error'),this['displayName']=_0x82d13c['displayName'],this['photoURL']=_0x82d13c['photoURL'],this['email']=_0x82d13c['email'],this['emailVerified']=_0x82d13c['emailVerified'],this['phoneNumber']=_0x82d13c['phoneNumber'],this['isAnonymous']=_0x82d13c['isAnonymous'],this['tenantId']=_0x82d13c['tenantId'],this['providerData']=_0x82d13c['providerData']['map'](_0x18bb93=>({..._0x18bb93})),this['metadata']['_copy'](_0x82d13c['metadata']),this['stsTokenManager']['_assign'](_0x82d13c['stsTokenManager']));}['_clone'](_0x2f12b1){const _0x4d3691=new j({...this,'auth':_0x2f12b1,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4d3691['metadata']['_copy'](this['metadata']),_0x4d3691;}['_onReload'](_0x5101d5){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x5101d5,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3934e3){this['reloadListener']?this['reloadListener'](_0x3934e3):this['reloadUserInfo']=_0x3934e3;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4f702d,_0x97fef6=!0x1){let _0x29c10f=!0x1;_0x4f702d['idToken']&&_0x4f702d['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4f702d),_0x29c10f=!0x0),_0x97fef6&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x29c10f&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x188f50=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x188f50})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x56d326=>({..._0x56d326})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5887eb,_0x12f82f){const _0x474fef=_0x12f82f['displayName']??void 0x0,_0x5b55e2=_0x12f82f['email']??void 0x0,_0x5347a4=_0x12f82f['phoneNumber']??void 0x0,_0x2b825e=_0x12f82f['photoURL']??void 0x0,_0x5ab83d=_0x12f82f['tenantId']??void 0x0,_0x373278=_0x12f82f['_redirectEventId']??void 0x0,_0x453d2d=_0x12f82f['createdAt']??void 0x0,_0x4ce2cd=_0x12f82f['lastLoginAt']??void 0x0,{uid:_0x46e011,emailVerified:_0x55dada,isAnonymous:_0x19f84c,providerData:_0x4828b1,stsTokenManager:_0x24831c}=_0x12f82f;m(_0x46e011&&_0x24831c,_0x5887eb,'internal-error');const _0x2b03d8=et['fromJSON'](this['name'],_0x24831c);m(typeof _0x46e011=='string',_0x5887eb,'internal-error'),le(_0x474fef,_0x5887eb['name']),le(_0x5b55e2,_0x5887eb['name']),m(typeof _0x55dada=='boolean',_0x5887eb,'internal-error'),m(typeof _0x19f84c=='boolean',_0x5887eb,'internal-error'),le(_0x5347a4,_0x5887eb['name']),le(_0x2b825e,_0x5887eb['name']),le(_0x5ab83d,_0x5887eb['name']),le(_0x373278,_0x5887eb['name']),le(_0x453d2d,_0x5887eb['name']),le(_0x4ce2cd,_0x5887eb['name']);const _0x1d3131=new j({'uid':_0x46e011,'auth':_0x5887eb,'email':_0x5b55e2,'emailVerified':_0x55dada,'displayName':_0x474fef,'isAnonymous':_0x19f84c,'photoURL':_0x2b825e,'phoneNumber':_0x5347a4,'tenantId':_0x5ab83d,'stsTokenManager':_0x2b03d8,'createdAt':_0x453d2d,'lastLoginAt':_0x4ce2cd});return _0x4828b1&&Array['isArray'](_0x4828b1)&&(_0x1d3131['providerData']=_0x4828b1['map'](_0x4f6562=>({..._0x4f6562}))),_0x373278&&(_0x1d3131['_redirectEventId']=_0x373278),_0x1d3131;}static async['_fromIdTokenResponse'](_0x1e784d,_0x270a3e,_0x46b76d=!0x1){const _0x50f67f=new et();_0x50f67f['updateFromServerResponse'](_0x270a3e);const _0x42476a=new j({'uid':_0x270a3e['localId'],'auth':_0x1e784d,'stsTokenManager':_0x50f67f,'isAnonymous':_0x46b76d});return await Nn(_0x42476a),_0x42476a;}static async['_fromGetAccountInfoResponse'](_0x2c5b83,_0x269b9a,_0x363d76){const _0x54eb59=_0x269b9a['users'][0x0];m(_0x54eb59['localId']!==void 0x0,'internal-error');const _0x529543=_0x54eb59['providerUserInfo']!==void 0x0?Sa(_0x54eb59['providerUserInfo']):[],_0x637e9b=!(_0x54eb59['email']&&_0x54eb59['passwordHash'])&&!(_0x529543!=null&&_0x529543['length']),_0xf89dbe=new et();_0xf89dbe['updateFromIdToken'](_0x363d76);const _0x47f86f=new j({'uid':_0x54eb59['localId'],'auth':_0x2c5b83,'stsTokenManager':_0xf89dbe,'isAnonymous':_0x637e9b}),_0x468734={'uid':_0x54eb59['localId'],'displayName':_0x54eb59['displayName']||null,'photoURL':_0x54eb59['photoUrl']||null,'email':_0x54eb59['email']||null,'emailVerified':_0x54eb59['emailVerified']||!0x1,'phoneNumber':_0x54eb59['phoneNumber']||null,'tenantId':_0x54eb59['tenantId']||null,'providerData':_0x529543,'metadata':new Li(_0x54eb59['createdAt'],_0x54eb59['lastLoginAt']),'isAnonymous':!(_0x54eb59['email']&&_0x54eb59['passwordHash'])&&!(_0x529543!=null&&_0x529543['length'])};return Object['assign'](_0x47f86f,_0x468734),_0x47f86f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x2f1473){ce(_0x2f1473 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x37cdc3=Tr['get'](_0x2f1473);return _0x37cdc3?(ce(_0x37cdc3 instanceof _0x2f1473,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x37cdc3):(_0x37cdc3=new _0x2f1473(),Tr['set'](_0x2f1473,_0x37cdc3),_0x37cdc3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x97f8ce,_0x1f46e0){this['storage'][_0x97f8ce]=_0x1f46e0;}async['_get'](_0x3fdfc4){const _0x4bb39f=this['storage'][_0x3fdfc4];return _0x4bb39f===void 0x0?null:_0x4bb39f;}async['_remove'](_0x1139aa){delete this['storage'][_0x1139aa];}['_addListener'](_0x2cb819,_0x462ac5){}['_removeListener'](_0x299d68,_0x33e9ee){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x4ddb14,_0x11aa3a,_0x5659e9){return'firebase:'+_0x4ddb14+':'+_0x11aa3a+':'+_0x5659e9;}class tt{constructor(_0x244d3d,_0x5660e1,_0x35af9b){this['persistence']=_0x244d3d,this['auth']=_0x5660e1,this['userKey']=_0x35af9b;const {config:_0x2eaf4e,name:_0x5cc735}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x2eaf4e['apiKey'],_0x5cc735),this['fullPersistenceKey']=ln('persistence',_0x2eaf4e['apiKey'],_0x5cc735),this['boundEventHandler']=_0x5660e1['_onStorageEvent']['bind'](_0x5660e1),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x494dcf){return this['persistence']['_set'](this['fullUserKey'],_0x494dcf['toJSON']());}async['getCurrentUser'](){const _0x3d11db=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3d11db)return null;if(typeof _0x3d11db=='string'){const _0x1e968f=await Pn(this['auth'],{'idToken':_0x3d11db})['catch'](()=>{});return _0x1e968f?j['_fromGetAccountInfoResponse'](this['auth'],_0x1e968f,_0x3d11db):null;}return j['_fromJSON'](this['auth'],_0x3d11db);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1fe3e7){if(this['persistence']===_0x1fe3e7)return;const _0x3ce966=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1fe3e7,_0x3ce966)return this['setCurrentUser'](_0x3ce966);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x48c177,_0x4396eb,_0x376a32='authUser'){if(!_0x4396eb['length'])return new tt(ie(Sr),_0x48c177,_0x376a32);const _0x1c28cd=(await Promise['all'](_0x4396eb['map'](async _0x305395=>{if(await _0x305395['_isAvailable']())return _0x305395;})))['filter'](_0x51cf2d=>_0x51cf2d);let _0x37c5ef=_0x1c28cd[0x0]||ie(Sr);const _0x512149=ln(_0x376a32,_0x48c177['config']['apiKey'],_0x48c177['name']);let _0x38f6c4=null;for(const _0x59364b of _0x4396eb)try{const _0x24ceb6=await _0x59364b['_get'](_0x512149);if(_0x24ceb6){let _0x2cc01;if(typeof _0x24ceb6=='string'){const _0x61e1c2=await Pn(_0x48c177,{'idToken':_0x24ceb6})['catch'](()=>{});if(!_0x61e1c2)break;_0x2cc01=await j['_fromGetAccountInfoResponse'](_0x48c177,_0x61e1c2,_0x24ceb6);}else _0x2cc01=j['_fromJSON'](_0x48c177,_0x24ceb6);_0x59364b!==_0x37c5ef&&(_0x38f6c4=_0x2cc01),_0x37c5ef=_0x59364b;break;}}catch{}const _0x3bf023=_0x1c28cd['filter'](_0x3f200e=>_0x3f200e['_shouldAllowMigration']);return!_0x37c5ef['_shouldAllowMigration']||!_0x3bf023['length']?new tt(_0x37c5ef,_0x48c177,_0x376a32):(_0x37c5ef=_0x3bf023[0x0],_0x38f6c4&&await _0x37c5ef['_set'](_0x512149,_0x38f6c4['toJSON']()),await Promise['all'](_0x4396eb['map'](async _0x404009=>{if(_0x404009!==_0x37c5ef)try{await _0x404009['_remove'](_0x512149);}catch{}})),new tt(_0x37c5ef,_0x48c177,_0x376a32));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x4a00bc){const _0x114d13=_0x4a00bc['toLowerCase']();if(_0x114d13['includes']('opera/')||_0x114d13['includes']('opr/')||_0x114d13['includes']('opios/'))return'Opera';if(Pa(_0x114d13))return'IEMobile';if(_0x114d13['includes']('msie')||_0x114d13['includes']('trident/'))return'IE';if(_0x114d13['includes']('edge/'))return'Edge';if(Ra(_0x114d13))return'Firefox';if(_0x114d13['includes']('silk/'))return'Silk';if(Oa(_0x114d13))return'Blackberry';if(Da(_0x114d13))return'Webos';if(Aa(_0x114d13))return'Safari';if((_0x114d13['includes']('chrome/')||ka(_0x114d13))&&!_0x114d13['includes']('edge/'))return'Chrome';if(Na(_0x114d13))return'Android';{const _0x27dc8c=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x124c30=_0x4a00bc['match'](_0x27dc8c);if((_0x124c30==null?void 0x0:_0x124c30['length'])===0x2)return _0x124c30[0x1];}return'Other';}function Ra(_0x171003=W()){return/firefox\//i['test'](_0x171003);}function Aa(_0x583e5b=W()){const _0x4c860f=_0x583e5b['toLowerCase']();return _0x4c860f['includes']('safari/')&&!_0x4c860f['includes']('chrome/')&&!_0x4c860f['includes']('crios/')&&!_0x4c860f['includes']('android');}function ka(_0x4f370a=W()){return/crios\//i['test'](_0x4f370a);}function Pa(_0x3c52a7=W()){return/iemobile/i['test'](_0x3c52a7);}function Na(_0x502468=W()){return/android/i['test'](_0x502468);}function Oa(_0x313400=W()){return/blackberry/i['test'](_0x313400);}function Da(_0x244413=W()){return/webos/i['test'](_0x244413);}function Ss(_0x5abfd2=W()){return/iphone|ipad|ipod/i['test'](_0x5abfd2)||/macintosh/i['test'](_0x5abfd2)&&/mobile/i['test'](_0x5abfd2);}function Rf(_0x24e7c1=W()){var _0x70dd54;return Ss(_0x24e7c1)&&!!((_0x70dd54=window['navigator'])!=null&&_0x70dd54['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x1d9125=W()){return Ss(_0x1d9125)||Na(_0x1d9125)||Da(_0x1d9125)||Oa(_0x1d9125)||/windows phone/i['test'](_0x1d9125)||Pa(_0x1d9125);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x4cabd,_0x4d6cbe=[]){let _0x4a2b03;switch(_0x4cabd){case'Browser':_0x4a2b03=br(W());break;case'Worker':_0x4a2b03=br(W())+'-'+_0x4cabd;break;default:_0x4a2b03=_0x4cabd;}const _0x42a5e7=_0x4d6cbe['length']?_0x4d6cbe['join'](','):'FirebaseCore-web';return _0x4a2b03+'/JsCore/'+dt+'/'+_0x42a5e7;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x43ba64){this['auth']=_0x43ba64,this['queue']=[];}['pushCallback'](_0x192ad3,_0x4eb079){const _0xb9aee7=_0x4e7c1c=>new Promise((_0x10b138,_0x51999e)=>{try{const _0x2d8f58=_0x192ad3(_0x4e7c1c);_0x10b138(_0x2d8f58);}catch(_0x498cf4){_0x51999e(_0x498cf4);}});_0xb9aee7['onAbort']=_0x4eb079,this['queue']['push'](_0xb9aee7);const _0x2ce036=this['queue']['length']-0x1;return()=>{this['queue'][_0x2ce036]=()=>Promise['resolve']();};}async['runMiddleware'](_0x2ba6fa){if(this['auth']['currentUser']===_0x2ba6fa)return;const _0x3262e9=[];try{for(const _0x51d693 of this['queue'])await _0x51d693(_0x2ba6fa),_0x51d693['onAbort']&&_0x3262e9['push'](_0x51d693['onAbort']);}catch(_0x255b47){_0x3262e9['reverse']();for(const _0xee9dbf of _0x3262e9)try{_0xee9dbf();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x255b47==null?void 0x0:_0x255b47['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x59acca,_0x1a236b={}){return Pe(_0x59acca,'GET','/v2/passwordPolicy',ke(_0x59acca,_0x1a236b));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x3f8174){var _0x2584d3;const _0x4868ab=_0x3f8174['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4868ab['minPasswordLength']??Nf,_0x4868ab['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4868ab['maxPasswordLength']),_0x4868ab['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4868ab['containsLowercaseCharacter']),_0x4868ab['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4868ab['containsUppercaseCharacter']),_0x4868ab['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4868ab['containsNumericCharacter']),_0x4868ab['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4868ab['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3f8174['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x2584d3=_0x3f8174['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x2584d3['join'](''))??'',this['forceUpgradeOnSignin']=_0x3f8174['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3f8174['schemaVersion'];}['validatePassword'](_0x44b6a6){const _0x1e3543={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x44b6a6,_0x1e3543),this['validatePasswordCharacterOptions'](_0x44b6a6,_0x1e3543),_0x1e3543['isValid']&&(_0x1e3543['isValid']=_0x1e3543['meetsMinPasswordLength']??!0x0),_0x1e3543['isValid']&&(_0x1e3543['isValid']=_0x1e3543['meetsMaxPasswordLength']??!0x0),_0x1e3543['isValid']&&(_0x1e3543['isValid']=_0x1e3543['containsLowercaseLetter']??!0x0),_0x1e3543['isValid']&&(_0x1e3543['isValid']=_0x1e3543['containsUppercaseLetter']??!0x0),_0x1e3543['isValid']&&(_0x1e3543['isValid']=_0x1e3543['containsNumericCharacter']??!0x0),_0x1e3543['isValid']&&(_0x1e3543['isValid']=_0x1e3543['containsNonAlphanumericCharacter']??!0x0),_0x1e3543;}['validatePasswordLengthOptions'](_0x22631a,_0x4294f7){const _0x4eb6c5=this['customStrengthOptions']['minPasswordLength'],_0x68481b=this['customStrengthOptions']['maxPasswordLength'];_0x4eb6c5&&(_0x4294f7['meetsMinPasswordLength']=_0x22631a['length']>=_0x4eb6c5),_0x68481b&&(_0x4294f7['meetsMaxPasswordLength']=_0x22631a['length']<=_0x68481b);}['validatePasswordCharacterOptions'](_0x3dda53,_0x136242){this['updatePasswordCharacterOptionsStatuses'](_0x136242,!0x1,!0x1,!0x1,!0x1);let _0x3d77c4;for(let _0x242030=0x0;_0x242030<_0x3dda53['length'];_0x242030++)_0x3d77c4=_0x3dda53['charAt'](_0x242030),this['updatePasswordCharacterOptionsStatuses'](_0x136242,_0x3d77c4>='a'&&_0x3d77c4<='z',_0x3d77c4>='A'&&_0x3d77c4<='Z',_0x3d77c4>='0'&&_0x3d77c4<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3d77c4));}['updatePasswordCharacterOptionsStatuses'](_0x1933f6,_0x36943a,_0x5dc18e,_0xc76b96,_0x14bbce){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1933f6['containsLowercaseLetter']||(_0x1933f6['containsLowercaseLetter']=_0x36943a)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1933f6['containsUppercaseLetter']||(_0x1933f6['containsUppercaseLetter']=_0x5dc18e)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1933f6['containsNumericCharacter']||(_0x1933f6['containsNumericCharacter']=_0xc76b96)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1933f6['containsNonAlphanumericCharacter']||(_0x1933f6['containsNonAlphanumericCharacter']=_0x14bbce));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x3bd968,_0x49a9e5,_0x313f39,_0x7c7ee8){this['app']=_0x3bd968,this['heartbeatServiceProvider']=_0x49a9e5,this['appCheckServiceProvider']=_0x313f39,this['config']=_0x7c7ee8,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3bd968['name'],this['clientVersion']=_0x7c7ee8['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x29338c=>this['_resolvePersistenceManagerAvailable']=_0x29338c);}['_initializeWithPersistence'](_0x22edd0,_0x5f15b5){return _0x5f15b5&&(this['_popupRedirectResolver']=ie(_0x5f15b5)),this['_initializationPromise']=this['queue'](async()=>{var _0x1958c5,_0x2d1372,_0x270df8;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x22edd0),(_0x1958c5=this['_resolvePersistenceManagerAvailable'])==null||_0x1958c5['call'](this),!this['_deleted'])){if((_0x2d1372=this['_popupRedirectResolver'])!=null&&_0x2d1372['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5f15b5),this['lastNotifiedUid']=((_0x270df8=this['currentUser'])==null?void 0x0:_0x270df8['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x167c42=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x167c42)){if(this['currentUser']&&_0x167c42&&this['currentUser']['uid']===_0x167c42['uid']){this['_currentUser']['_assign'](_0x167c42),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x167c42,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x88000e){try{const _0x2b4df9=await Pn(this,{'idToken':_0x88000e}),_0x3a51ee=await j['_fromGetAccountInfoResponse'](this,_0x2b4df9,_0x88000e);await this['directlySetCurrentUser'](_0x3a51ee);}catch(_0x41c304){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x41c304),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xc06239){var _0x55ba42;if($(this['app'])){const _0xff3d1=this['app']['settings']['authIdToken'];return _0xff3d1?new Promise(_0x9aeb2=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0xff3d1)['then'](_0x9aeb2,_0x9aeb2));}):this['directlySetCurrentUser'](null);}const _0x48d2da=await this['assertedPersistence']['getCurrentUser']();let _0x59eb3f=_0x48d2da,_0x190689=!0x1;if(_0xc06239&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x427019=(_0x55ba42=this['redirectUser'])==null?void 0x0:_0x55ba42['_redirectEventId'],_0x4185d5=_0x59eb3f==null?void 0x0:_0x59eb3f['_redirectEventId'],_0x1fdeca=await this['tryRedirectSignIn'](_0xc06239);(!_0x427019||_0x427019===_0x4185d5)&&(_0x1fdeca!=null&&_0x1fdeca['user'])&&(_0x59eb3f=_0x1fdeca['user'],_0x190689=!0x0);}if(!_0x59eb3f)return this['directlySetCurrentUser'](null);if(!_0x59eb3f['_redirectEventId']){if(_0x190689)try{await this['beforeStateQueue']['runMiddleware'](_0x59eb3f);}catch(_0x49213b){_0x59eb3f=_0x48d2da,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x49213b));}return _0x59eb3f?this['reloadAndSetCurrentUserOrClear'](_0x59eb3f):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x59eb3f['_redirectEventId']?this['directlySetCurrentUser'](_0x59eb3f):this['reloadAndSetCurrentUserOrClear'](_0x59eb3f);}async['tryRedirectSignIn'](_0x4bb0ba){let _0x7c99ef=null;try{_0x7c99ef=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4bb0ba,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x7c99ef;}async['reloadAndSetCurrentUserOrClear'](_0x3e14f3){try{await Nn(_0x3e14f3);}catch(_0x47146a){if((_0x47146a==null?void 0x0:_0x47146a['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3e14f3);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x40caa5){if($(this['app']))return Promise['reject'](re(this));const _0x1d0084=_0x40caa5?P(_0x40caa5):null;return _0x1d0084&&m(_0x1d0084['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x1d0084&&_0x1d0084['_clone'](this));}async['_updateCurrentUser'](_0x3d03a3,_0x705e09=!0x1){if(!this['_deleted'])return _0x3d03a3&&m(this['tenantId']===_0x3d03a3['tenantId'],this,'tenant-id-mismatch'),_0x705e09||await this['beforeStateQueue']['runMiddleware'](_0x3d03a3),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x3d03a3),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3b41eb){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3b41eb));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2a5b6b){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5c7d2e=this['_getPasswordPolicyInternal']();return _0x5c7d2e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5c7d2e['validatePassword'](_0x2a5b6b);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3d9026=await Pf(this),_0x401856=new Of(_0x3d9026);this['tenantId']===null?this['_projectPasswordPolicy']=_0x401856:this['_tenantPasswordPolicies'][this['tenantId']]=_0x401856;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x145012){this['_errorFactory']=new Gt('auth','Firebase',_0x145012());}['onAuthStateChanged'](_0x38af58,_0x30f5e3,_0x49d034){return this['registerStateListener'](this['authStateSubscription'],_0x38af58,_0x30f5e3,_0x49d034);}['beforeAuthStateChanged'](_0x12a520,_0x2e4929){return this['beforeStateQueue']['pushCallback'](_0x12a520,_0x2e4929);}['onIdTokenChanged'](_0x2e3c2d,_0x35cd55,_0x1d115f){return this['registerStateListener'](this['idTokenSubscription'],_0x2e3c2d,_0x35cd55,_0x1d115f);}['authStateReady'](){return new Promise((_0x472b32,_0x4c0d86)=>{if(this['currentUser'])_0x472b32();else{const _0x4a9282=this['onAuthStateChanged'](()=>{_0x4a9282(),_0x472b32();},_0x4c0d86);}});}async['revokeAccessToken'](_0x2cfc75){if(this['currentUser']){const _0x34ad0f=await this['currentUser']['getIdToken'](),_0x3a33b1={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2cfc75,'idToken':_0x34ad0f};this['tenantId']!=null&&(_0x3a33b1['tenantId']=this['tenantId']),await bf(this,_0x3a33b1);}}['toJSON'](){var _0xd576ba;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xd576ba=this['_currentUser'])==null?void 0x0:_0xd576ba['toJSON']()};}async['_setRedirectUser'](_0x7cd763,_0x3e9734){const _0x4cdd2b=await this['getOrInitRedirectPersistenceManager'](_0x3e9734);return _0x7cd763===null?_0x4cdd2b['removeCurrentUser']():_0x4cdd2b['setCurrentUser'](_0x7cd763);}async['getOrInitRedirectPersistenceManager'](_0x14fb31){if(!this['redirectPersistenceManager']){const _0x54aa91=_0x14fb31&&ie(_0x14fb31)||this['_popupRedirectResolver'];m(_0x54aa91,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x54aa91['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3fab8f){var _0x3250c2,_0x42bde2;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3250c2=this['_currentUser'])==null?void 0x0:_0x3250c2['_redirectEventId'])===_0x3fab8f?this['_currentUser']:((_0x42bde2=this['redirectUser'])==null?void 0x0:_0x42bde2['_redirectEventId'])===_0x3fab8f?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x457836){if(_0x457836===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x457836));}['_notifyListenersIfCurrent'](_0x3bcdd6){_0x3bcdd6===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0xd9f9a0;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x15c912=((_0xd9f9a0=this['currentUser'])==null?void 0x0:_0xd9f9a0['uid'])??null;this['lastNotifiedUid']!==_0x15c912&&(this['lastNotifiedUid']=_0x15c912,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2c8339,_0x23c8fa,_0xa32e6,_0xcea3ab){if(this['_deleted'])return()=>{};const _0x14d8fb=typeof _0x23c8fa=='function'?_0x23c8fa:_0x23c8fa['next']['bind'](_0x23c8fa);let _0x141d34=!0x1;const _0x32076c=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x32076c,this,'internal-error'),_0x32076c['then'](()=>{_0x141d34||_0x14d8fb(this['currentUser']);}),typeof _0x23c8fa=='function'){const _0x3074fd=_0x2c8339['addObserver'](_0x23c8fa,_0xa32e6,_0xcea3ab);return()=>{_0x141d34=!0x0,_0x3074fd();};}else{const _0x518fe9=_0x2c8339['addObserver'](_0x23c8fa);return()=>{_0x141d34=!0x0,_0x518fe9();};}}async['directlySetCurrentUser'](_0x279753){this['currentUser']&&this['currentUser']!==_0x279753&&this['_currentUser']['_stopProactiveRefresh'](),_0x279753&&this['isProactiveRefreshEnabled']&&_0x279753['_startProactiveRefresh'](),this['currentUser']=_0x279753,_0x279753?await this['assertedPersistence']['setCurrentUser'](_0x279753):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x17876e){return this['operations']=this['operations']['then'](_0x17876e,_0x17876e),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5e7ada){!_0x5e7ada||this['frameworks']['includes'](_0x5e7ada)||(this['frameworks']['push'](_0x5e7ada),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1dce98;const _0x3ab358={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3ab358['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x256839=await((_0x1dce98=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1dce98['getHeartbeatsHeader']());_0x256839&&(_0x3ab358['X-Firebase-Client']=_0x256839);const _0x361c7b=await this['_getAppCheckToken']();return _0x361c7b&&(_0x3ab358['X-Firebase-AppCheck']=_0x361c7b),_0x3ab358;}async['_getAppCheckToken'](){var _0x3c0225;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0xf55d52=await((_0x3c0225=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3c0225['getToken']());return _0xf55d52!=null&&_0xf55d52['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0xf55d52['error']),_0xf55d52==null?void 0x0:_0xf55d52['token'];}}function Ke(_0x3fa006){return P(_0x3fa006);}class Rr{constructor(_0x565c0c){this['auth']=_0x565c0c,this['observer']=null,this['addObserver']=Tc(_0x5bb0f9=>this['observer']=_0x5bb0f9);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x2f9b52){Jn=_0x2f9b52;}function xa(_0x301cb3){return Jn['loadJS'](_0x301cb3);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x49fd0c){return'__'+_0x49fd0c+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x4b20aa){_0x4b20aa();}['execute'](_0x43a5f2,_0x40e589){return Promise['resolve']('token');}['render'](_0x5884a9,_0x3921fa){return'';}}class Wf{['ready'](_0x5cf5fc){_0x5cf5fc();}['execute'](_0x31f009,_0x16b2e2){return Promise['resolve']('token');}['render'](_0x3e7e7e,_0x462880){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x4abdec){this['type']=Bf,this['auth']=Ke(_0x4abdec);}async['verify'](_0x525d24='verify',_0x18d3a3=!0x1){async function _0x109130(_0x44689d){if(!_0x18d3a3){if(_0x44689d['tenantId']==null&&_0x44689d['_agentRecaptchaConfig']!=null)return _0x44689d['_agentRecaptchaConfig']['siteKey'];if(_0x44689d['tenantId']!=null&&_0x44689d['_tenantRecaptchaConfigs'][_0x44689d['tenantId']]!==void 0x0)return _0x44689d['_tenantRecaptchaConfigs'][_0x44689d['tenantId']]['siteKey'];}return new Promise(async(_0x28663b,_0x32b694)=>{yf(_0x44689d,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x53db96=>{if(_0x53db96['recaptchaKey']===void 0x0)_0x32b694(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x196b9d=new mf(_0x53db96);return _0x44689d['tenantId']==null?_0x44689d['_agentRecaptchaConfig']=_0x196b9d:_0x44689d['_tenantRecaptchaConfigs'][_0x44689d['tenantId']]=_0x196b9d,_0x28663b(_0x196b9d['siteKey']);}})['catch'](_0x50c27f=>{_0x32b694(_0x50c27f);});});}function _0x17d502(_0x2d4445,_0x16026d,_0x1f2573){const _0x4ed349=window['grecaptcha'];wr(_0x4ed349)?_0x4ed349['enterprise']['ready'](()=>{_0x4ed349['enterprise']['execute'](_0x2d4445,{'action':_0x525d24})['then'](_0x34650a=>{_0x16026d(_0x34650a);})['catch'](()=>{_0x16026d(Fa);});}):_0x1f2573(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4a7a1e,_0x53bcf0)=>{_0x109130(this['auth'])['then'](async _0x2b14f6=>{if(!_0x18d3a3&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x17d502(_0x2b14f6,_0x4a7a1e,_0x53bcf0);else{if(typeof window>'u'){_0x53bcf0(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xcbd6c0=Lf();_0xcbd6c0['length']!==0x0&&(_0xcbd6c0+=_0x2b14f6+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x25a24e;(_0x25a24e=he['scriptInjectionDeferred'])==null||_0x25a24e['resolve']();},xa(_0xcbd6c0)['then'](()=>{var _0x5a2f4e;return(_0x5a2f4e=he['scriptInjectionDeferred'])==null?void 0x0:_0x5a2f4e['promise'];})['then'](()=>{_0x17d502(_0x2b14f6,_0x4a7a1e,_0x53bcf0);})['catch'](_0xb4a1f2=>{_0x53bcf0(_0xb4a1f2);});}})['catch'](_0x408c91=>{_0x53bcf0(_0x408c91);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x153913,_0x4d322a,_0x5b95ea,_0xd9b82e=!0x1,_0x467d16=!0x1){const _0x4686e2=new he(_0x153913);let _0x12283c;if(_0x467d16)_0x12283c=Fa;else try{_0x12283c=await _0x4686e2['verify'](_0x5b95ea);}catch{_0x12283c=await _0x4686e2['verify'](_0x5b95ea,!0x0);}const _0x4057ef={..._0x4d322a};if(_0x5b95ea==='mfaSmsEnrollment'||_0x5b95ea==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x4057ef){const _0x88e9fe=_0x4057ef['phoneEnrollmentInfo']['phoneNumber'],_0x539b9c=_0x4057ef['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x4057ef,{'phoneEnrollmentInfo':{'phoneNumber':_0x88e9fe,'recaptchaToken':_0x539b9c,'captchaResponse':_0x12283c,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x4057ef){const _0x1ce6b2=_0x4057ef['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x4057ef,{'phoneSignInInfo':{'recaptchaToken':_0x1ce6b2,'captchaResponse':_0x12283c,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x4057ef;}return _0xd9b82e?Object['assign'](_0x4057ef,{'captchaResp':_0x12283c}):Object['assign'](_0x4057ef,{'captchaResponse':_0x12283c}),Object['assign'](_0x4057ef,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x4057ef,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x4057ef;}async function xi(_0x209f4b,_0x220b7e,_0x3dcd9f,_0x44fbd8,_0xf8fd29){var _0x1408e8;if((_0x1408e8=_0x209f4b['_getRecaptchaConfig']())!=null&&_0x1408e8['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x10e5fc=await kr(_0x209f4b,_0x220b7e,_0x3dcd9f,_0x3dcd9f==='getOobCode');return _0x44fbd8(_0x209f4b,_0x10e5fc);}else return _0x44fbd8(_0x209f4b,_0x220b7e)['catch'](async _0x3acd79=>{if(_0x3acd79['code']==='auth/missing-recaptcha-token'){console['log'](_0x3dcd9f+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xd4640f=await kr(_0x209f4b,_0x220b7e,_0x3dcd9f,_0x3dcd9f==='getOobCode');return _0x44fbd8(_0x209f4b,_0xd4640f);}else return Promise['reject'](_0x3acd79);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x43ad53,_0x1a02a4){const _0x2ccbda=Hi(_0x43ad53,'auth');if(_0x2ccbda['isInitialized']()){const _0x166a44=_0x2ccbda['getImmediate'](),_0x12d135=_0x2ccbda['getOptions']();if(xe(_0x12d135,_0x1a02a4??{}))return _0x166a44;Y(_0x166a44,'already-initialized');}return _0x2ccbda['initialize']({'options':_0x1a02a4});}function Hf(_0xa15457,_0x24243b){const _0x692926=(_0x24243b==null?void 0x0:_0x24243b['persistence'])||[],_0x14d86e=(Array['isArray'](_0x692926)?_0x692926:[_0x692926])['map'](ie);_0x24243b!=null&&_0x24243b['errorMap']&&_0xa15457['_updateErrorMap'](_0x24243b['errorMap']),_0xa15457['_initializeWithPersistence'](_0x14d86e,_0x24243b==null?void 0x0:_0x24243b['popupRedirectResolver']);}function $f(_0x4edb9c,_0x155f68,_0x1dbba3){const _0x352ed6=Ke(_0x4edb9c);m(/^https?:\/\//['test'](_0x155f68),_0x352ed6,'invalid-emulator-scheme');const _0x233036=!0x1,_0x40b6ef=Ua(_0x155f68),{host:_0x59c857,port:_0x310629}=Gf(_0x155f68),_0x801812=_0x310629===null?'':':'+_0x310629,_0x3a3a75={'url':_0x40b6ef+'//'+_0x59c857+_0x801812+'/'},_0x28a16e=Object['freeze']({'host':_0x59c857,'port':_0x310629,'protocol':_0x40b6ef['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x233036})});if(!_0x352ed6['_canInitEmulator']){m(_0x352ed6['config']['emulator']&&_0x352ed6['emulatorConfig'],_0x352ed6,'emulator-config-failed'),m(xe(_0x3a3a75,_0x352ed6['config']['emulator'])&&xe(_0x28a16e,_0x352ed6['emulatorConfig']),_0x352ed6,'emulator-config-failed');return;}_0x352ed6['config']['emulator']=_0x3a3a75,_0x352ed6['emulatorConfig']=_0x28a16e,_0x352ed6['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x59c857)?Qr(_0x40b6ef+'//'+_0x59c857+_0x801812):qf();}function Ua(_0x3f496c){const _0x4feb4f=_0x3f496c['indexOf'](':');return _0x4feb4f<0x0?'':_0x3f496c['substr'](0x0,_0x4feb4f+0x1);}function Gf(_0x47b19c){const _0x3210ca=Ua(_0x47b19c),_0x491257=/(\/\/)?([^?#/]+)/['exec'](_0x47b19c['substr'](_0x3210ca['length']));if(!_0x491257)return{'host':'','port':null};const _0x6d5cf3=_0x491257[0x2]['split']('@')['pop']()||'',_0x201155=/^(\[[^\]]+\])(:|$)/['exec'](_0x6d5cf3);if(_0x201155){const _0x21f298=_0x201155[0x1];return{'host':_0x21f298,'port':Pr(_0x6d5cf3['substr'](_0x21f298['length']+0x1))};}else{const [_0x8ab528,_0x4b0a7f]=_0x6d5cf3['split'](':');return{'host':_0x8ab528,'port':Pr(_0x4b0a7f)};}}function Pr(_0x41a3ca){if(!_0x41a3ca)return null;const _0x49092a=Number(_0x41a3ca);return isNaN(_0x49092a)?null:_0x49092a;}function qf(){function _0xb1261c(){const _0x3bf398=document['createElement']('p'),_0x184fe9=_0x3bf398['style'];_0x3bf398['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x184fe9['position']='fixed',_0x184fe9['width']='100%',_0x184fe9['backgroundColor']='#ffffff',_0x184fe9['border']='.1em\x20solid\x20#000000',_0x184fe9['color']='#b50000',_0x184fe9['bottom']='0px',_0x184fe9['left']='0px',_0x184fe9['margin']='0px',_0x184fe9['zIndex']='10000',_0x184fe9['textAlign']='center',_0x3bf398['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3bf398);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xb1261c):_0xb1261c());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x4fef69,_0x3e7bff){this['providerId']=_0x4fef69,this['signInMethod']=_0x3e7bff;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x13a060){return ne('not\x20implemented');}['_linkToIdToken'](_0x291286,_0x4bd086){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x5db52b){return ne('not\x20implemented');}}async function zf(_0x51e9c6,_0x172d10){return Pe(_0x51e9c6,'POST','/v1/accounts:signUp',_0x172d10);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x2afc78,_0x5254d7){return en(_0x2afc78,'POST','/v1/accounts:signInWithPassword',ke(_0x2afc78,_0x5254d7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x29be76,_0x5427b0){return en(_0x29be76,'POST','/v1/accounts:signInWithEmailLink',ke(_0x29be76,_0x5427b0));}async function Yf(_0x33f480,_0x1287c9){return en(_0x33f480,'POST','/v1/accounts:signInWithEmailLink',ke(_0x33f480,_0x1287c9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x2428a8,_0x2a6c5e,_0x433ff6,_0x3fbb94=null){super('password',_0x433ff6),this['_email']=_0x2428a8,this['_password']=_0x2a6c5e,this['_tenantId']=_0x3fbb94;}static['_fromEmailAndPassword'](_0xaf889,_0x2d87c9){return new $t(_0xaf889,_0x2d87c9,'password');}static['_fromEmailAndCode'](_0x594e0e,_0x22b556,_0x175dc9=null){return new $t(_0x594e0e,_0x22b556,'emailLink',_0x175dc9);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x10d7ae){const _0x3949e7=typeof _0x10d7ae=='string'?JSON['parse'](_0x10d7ae):_0x10d7ae;if(_0x3949e7!=null&&_0x3949e7['email']&&(_0x3949e7!=null&&_0x3949e7['password'])){if(_0x3949e7['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3949e7['email'],_0x3949e7['password']);if(_0x3949e7['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3949e7['email'],_0x3949e7['password'],_0x3949e7['tenantId']);}return null;}async['_getIdTokenResponse'](_0x48e898){switch(this['signInMethod']){case'password':const _0x4a6d86={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x48e898,_0x4a6d86,'signInWithPassword',jf);case'emailLink':return Kf(_0x48e898,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x48e898,'internal-error');}}async['_linkToIdToken'](_0x183361,_0x5a8b7b){switch(this['signInMethod']){case'password':const _0x4af27e={'idToken':_0x5a8b7b,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x183361,_0x4af27e,'signUpPassword',zf);case'emailLink':return Yf(_0x183361,{'idToken':_0x5a8b7b,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x183361,'internal-error');}}['_getReauthenticationResolver'](_0x3e8871){return this['_getIdTokenResponse'](_0x3e8871);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x3e9af8,_0x5c37ef){return en(_0x3e9af8,'POST','/v1/accounts:signInWithIdp',ke(_0x3e9af8,_0x5c37ef));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x497260){const _0xb9c6d8=new $e(_0x497260['providerId'],_0x497260['signInMethod']);return _0x497260['idToken']||_0x497260['accessToken']?(_0x497260['idToken']&&(_0xb9c6d8['idToken']=_0x497260['idToken']),_0x497260['accessToken']&&(_0xb9c6d8['accessToken']=_0x497260['accessToken']),_0x497260['nonce']&&!_0x497260['pendingToken']&&(_0xb9c6d8['nonce']=_0x497260['nonce']),_0x497260['pendingToken']&&(_0xb9c6d8['pendingToken']=_0x497260['pendingToken'])):_0x497260['oauthToken']&&_0x497260['oauthTokenSecret']?(_0xb9c6d8['accessToken']=_0x497260['oauthToken'],_0xb9c6d8['secret']=_0x497260['oauthTokenSecret']):Y('argument-error'),_0xb9c6d8;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3ca2f9){const _0x11336b=typeof _0x3ca2f9=='string'?JSON['parse'](_0x3ca2f9):_0x3ca2f9,{providerId:_0x46a160,signInMethod:_0xfaf0cc,..._0x4b3618}=_0x11336b;if(!_0x46a160||!_0xfaf0cc)return null;const _0x585348=new $e(_0x46a160,_0xfaf0cc);return _0x585348['idToken']=_0x4b3618['idToken']||void 0x0,_0x585348['accessToken']=_0x4b3618['accessToken']||void 0x0,_0x585348['secret']=_0x4b3618['secret'],_0x585348['nonce']=_0x4b3618['nonce'],_0x585348['pendingToken']=_0x4b3618['pendingToken']||null,_0x585348;}['_getIdTokenResponse'](_0x2cd1b7){const _0x306c30=this['buildRequest']();return nt(_0x2cd1b7,_0x306c30);}['_linkToIdToken'](_0xe2c866,_0x546e5b){const _0x502dc1=this['buildRequest']();return _0x502dc1['idToken']=_0x546e5b,nt(_0xe2c866,_0x502dc1);}['_getReauthenticationResolver'](_0x2a5ee6){const _0xa1c973=this['buildRequest']();return _0xa1c973['autoCreate']=!0x1,nt(_0x2a5ee6,_0xa1c973);}['buildRequest'](){const _0x247aae={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x247aae['pendingToken']=this['pendingToken'];else{const _0x1918e4={};this['idToken']&&(_0x1918e4['id_token']=this['idToken']),this['accessToken']&&(_0x1918e4['access_token']=this['accessToken']),this['secret']&&(_0x1918e4['oauth_token_secret']=this['secret']),_0x1918e4['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x1918e4['nonce']=this['nonce']),_0x247aae['postBody']=ut(_0x1918e4);}return _0x247aae;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x572cc6){switch(_0x572cc6){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x5be611){const _0x3bf55d=Ct(Tt(_0x5be611))['link'],_0x4e184c=_0x3bf55d?Ct(Tt(_0x3bf55d))['deep_link_id']:null,_0x2467f8=Ct(Tt(_0x5be611))['deep_link_id'];return(_0x2467f8?Ct(Tt(_0x2467f8))['link']:null)||_0x2467f8||_0x4e184c||_0x3bf55d||_0x5be611;}class Rs{constructor(_0x41fd0a){const _0x504490=Ct(Tt(_0x41fd0a)),_0x2267f4=_0x504490['apiKey']??null,_0xedf0dd=_0x504490['oobCode']??null,_0x5cb81b=Jf(_0x504490['mode']??null);m(_0x2267f4&&_0xedf0dd&&_0x5cb81b,'argument-error'),this['apiKey']=_0x2267f4,this['operation']=_0x5cb81b,this['code']=_0xedf0dd,this['continueUrl']=_0x504490['continueUrl']??null,this['languageCode']=_0x504490['lang']??null,this['tenantId']=_0x504490['tenantId']??null;}static['parseLink'](_0x590e17){const _0x1027fa=Xf(_0x590e17);try{return new Rs(_0x1027fa);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x548b6d,_0x298e93){return $t['_fromEmailAndPassword'](_0x548b6d,_0x298e93);}static['credentialWithLink'](_0x4ed29c,_0x4b2b85){const _0x449564=Rs['parseLink'](_0x4b2b85);return m(_0x449564,'argument-error'),$t['_fromEmailAndCode'](_0x4ed29c,_0x449564['code'],_0x449564['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x74f9c3){this['providerId']=_0x74f9c3,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4517a4){this['defaultLanguageCode']=_0x4517a4;}['setCustomParameters'](_0x343a84){return this['customParameters']=_0x343a84,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3a1819){return this['scopes']['includes'](_0x3a1819)||this['scopes']['push'](_0x3a1819),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x3b2297){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3b2297});}static['credentialFromResult'](_0x7f8649){return ue['credentialFromTaggedObject'](_0x7f8649);}static['credentialFromError'](_0x114bc9){return ue['credentialFromTaggedObject'](_0x114bc9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x6f7248}){if(!_0x6f7248||!('oauthAccessToken'in _0x6f7248)||!_0x6f7248['oauthAccessToken'])return null;try{return ue['credential'](_0x6f7248['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x279cab,_0x4d983a){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x279cab,'accessToken':_0x4d983a});}static['credentialFromResult'](_0x56ce3b){return de['credentialFromTaggedObject'](_0x56ce3b);}static['credentialFromError'](_0x395f56){return de['credentialFromTaggedObject'](_0x395f56['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5c2194}){if(!_0x5c2194)return null;const {oauthIdToken:_0x563d96,oauthAccessToken:_0x115a82}=_0x5c2194;if(!_0x563d96&&!_0x115a82)return null;try{return de['credential'](_0x563d96,_0x115a82);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x4b3edc){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4b3edc});}static['credentialFromResult'](_0x5c6fd9){return fe['credentialFromTaggedObject'](_0x5c6fd9);}static['credentialFromError'](_0x179bae){return fe['credentialFromTaggedObject'](_0x179bae['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x20b2c5}){if(!_0x20b2c5||!('oauthAccessToken'in _0x20b2c5)||!_0x20b2c5['oauthAccessToken'])return null;try{return fe['credential'](_0x20b2c5['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x44ff93,_0x51d2f9){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x44ff93,'oauthTokenSecret':_0x51d2f9});}static['credentialFromResult'](_0x1e6831){return pe['credentialFromTaggedObject'](_0x1e6831);}static['credentialFromError'](_0x1de0c7){return pe['credentialFromTaggedObject'](_0x1de0c7['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1ac2cf}){if(!_0x1ac2cf)return null;const {oauthAccessToken:_0x5bb5bf,oauthTokenSecret:_0x5c0cb5}=_0x1ac2cf;if(!_0x5bb5bf||!_0x5c0cb5)return null;try{return pe['credential'](_0x5bb5bf,_0x5c0cb5);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x7b1b84,_0xb0ffe8){return en(_0x7b1b84,'POST','/v1/accounts:signUp',ke(_0x7b1b84,_0xb0ffe8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x444577){this['user']=_0x444577['user'],this['providerId']=_0x444577['providerId'],this['_tokenResponse']=_0x444577['_tokenResponse'],this['operationType']=_0x444577['operationType'];}static async['_fromIdTokenResponse'](_0x6e0a22,_0x26589c,_0xff6070,_0x305752=!0x1){const _0x221846=await j['_fromIdTokenResponse'](_0x6e0a22,_0xff6070,_0x305752),_0x3e5866=Nr(_0xff6070);return new Ge({'user':_0x221846,'providerId':_0x3e5866,'_tokenResponse':_0xff6070,'operationType':_0x26589c});}static async['_forOperation'](_0x11490b,_0x4c016f,_0x1996ea){await _0x11490b['_updateTokensIfNecessary'](_0x1996ea,!0x0);const _0x576d07=Nr(_0x1996ea);return new Ge({'user':_0x11490b,'providerId':_0x576d07,'_tokenResponse':_0x1996ea,'operationType':_0x4c016f});}}function Nr(_0x84b3cc){return _0x84b3cc['providerId']?_0x84b3cc['providerId']:'phoneNumber'in _0x84b3cc?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0xbb1d09,_0x399af6,_0x3017b2,_0x4b9496){super(_0x399af6['code'],_0x399af6['message']),this['operationType']=_0x3017b2,this['user']=_0x4b9496,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0xbb1d09['name'],'tenantId':_0xbb1d09['tenantId']??void 0x0,'_serverResponse':_0x399af6['customData']['_serverResponse'],'operationType':_0x3017b2};}static['_fromErrorAndOperation'](_0x3501fa,_0x4763f9,_0x120821,_0x3d85d2){return new On(_0x3501fa,_0x4763f9,_0x120821,_0x3d85d2);}}function Ba(_0x4f27b4,_0xa20588,_0x2a9a49,_0x321de7){return(_0xa20588==='reauthenticate'?_0x2a9a49['_getReauthenticationResolver'](_0x4f27b4):_0x2a9a49['_getIdTokenResponse'](_0x4f27b4))['catch'](_0x51d017=>{throw _0x51d017['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x4f27b4,_0x51d017,_0xa20588,_0x321de7):_0x51d017;});}async function ep(_0x5ca7fd,_0x246646,_0x51e87c=!0x1){const _0x23f4e6=await Ht(_0x5ca7fd,_0x246646['_linkToIdToken'](_0x5ca7fd['auth'],await _0x5ca7fd['getIdToken']()),_0x51e87c);return Ge['_forOperation'](_0x5ca7fd,'link',_0x23f4e6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x549994,_0x23daea,_0x12c5a9=!0x1){const {auth:_0xb45803}=_0x549994;if($(_0xb45803['app']))return Promise['reject'](re(_0xb45803));const _0x58fffb='reauthenticate';try{const _0x14e1f9=await Ht(_0x549994,Ba(_0xb45803,_0x58fffb,_0x23daea,_0x549994),_0x12c5a9);m(_0x14e1f9['idToken'],_0xb45803,'internal-error');const _0x501bda=Ts(_0x14e1f9['idToken']);m(_0x501bda,_0xb45803,'internal-error');const {sub:_0xdb864d}=_0x501bda;return m(_0x549994['uid']===_0xdb864d,_0xb45803,'user-mismatch'),Ge['_forOperation'](_0x549994,_0x58fffb,_0x14e1f9);}catch(_0x4580b9){throw(_0x4580b9==null?void 0x0:_0x4580b9['code'])==='auth/user-not-found'&&Y(_0xb45803,'user-mismatch'),_0x4580b9;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x1230a8,_0x18d9a7,_0x5d608d=!0x1){if($(_0x1230a8['app']))return Promise['reject'](re(_0x1230a8));const _0xc59bc9='signIn',_0x13133f=await Ba(_0x1230a8,_0xc59bc9,_0x18d9a7),_0x225504=await Ge['_fromIdTokenResponse'](_0x1230a8,_0xc59bc9,_0x13133f);return _0x5d608d||await _0x1230a8['_updateCurrentUser'](_0x225504['user']),_0x225504;}async function np(_0xdc80c8,_0x14bdcf){return Va(Ke(_0xdc80c8),_0x14bdcf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0xce7e7b){const _0x1cb74d=Ke(_0xce7e7b);_0x1cb74d['_getPasswordPolicyInternal']()&&await _0x1cb74d['_updatePasswordPolicy']();}async function L_(_0x5b5f65,_0x50e0b5,_0x28d901){if($(_0x5b5f65['app']))return Promise['reject'](re(_0x5b5f65));const _0x317527=Ke(_0x5b5f65),_0x402868=await xi(_0x317527,{'returnSecureToken':!0x0,'email':_0x50e0b5,'password':_0x28d901,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x83ff4e=>{throw _0x83ff4e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5b5f65),_0x83ff4e;}),_0x1155e8=await Ge['_fromIdTokenResponse'](_0x317527,'signIn',_0x402868);return await _0x317527['_updateCurrentUser'](_0x1155e8['user']),_0x1155e8;}function x_(_0xad8fc,_0x561b24,_0x552149){return $(_0xad8fc['app'])?Promise['reject'](re(_0xad8fc)):np(P(_0xad8fc),yt['credential'](_0x561b24,_0x552149))['catch'](async _0x2b806d=>{throw _0x2b806d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xad8fc),_0x2b806d;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x4f803d,_0x136f6f){return P(_0x4f803d)['setPersistence'](_0x136f6f);}function ip(_0x372870,_0x572922,_0x5a3858,_0x4412d5){return P(_0x372870)['onIdTokenChanged'](_0x572922,_0x5a3858,_0x4412d5);}function sp(_0x84e8db,_0x25a62f,_0x447b80){return P(_0x84e8db)['beforeAuthStateChanged'](_0x25a62f,_0x447b80);}function U_(_0x589845,_0x5cd531,_0x318b7a,_0x121b58){return P(_0x589845)['onAuthStateChanged'](_0x5cd531,_0x318b7a,_0x121b58);}function W_(_0x409f93){return P(_0x409f93)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5a2e87,_0x1a8d53){this['storageRetriever']=_0x5a2e87,this['type']=_0x1a8d53;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x331cf5,_0xe3d065){return this['storage']['setItem'](_0x331cf5,JSON['stringify'](_0xe3d065)),Promise['resolve']();}['_get'](_0x179225){const _0x40e008=this['storage']['getItem'](_0x179225);return Promise['resolve'](_0x40e008?JSON['parse'](_0x40e008):null);}['_remove'](_0x43ea3e){return this['storage']['removeItem'](_0x43ea3e),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4a559a,_0x6296fe)=>this['onStorageEvent'](_0x4a559a,_0x6296fe),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xce84dd){for(const _0x589b3 of Object['keys'](this['listeners'])){const _0x3621ae=this['storage']['getItem'](_0x589b3),_0x2a8c32=this['localCache'][_0x589b3];_0x3621ae!==_0x2a8c32&&_0xce84dd(_0x589b3,_0x2a8c32,_0x3621ae);}}['onStorageEvent'](_0x179372,_0x758d3b=!0x1){if(!_0x179372['key']){this['forAllChangedKeys']((_0x59f3b4,_0x8099c9,_0x52edd8)=>{this['notifyListeners'](_0x59f3b4,_0x52edd8);});return;}const _0x5f52ab=_0x179372['key'];_0x758d3b?this['detachListener']():this['stopPolling']();const _0x355efb=()=>{const _0x1789d5=this['storage']['getItem'](_0x5f52ab);!_0x758d3b&&this['localCache'][_0x5f52ab]===_0x1789d5||this['notifyListeners'](_0x5f52ab,_0x1789d5);},_0x2f33a5=this['storage']['getItem'](_0x5f52ab);Af()&&_0x2f33a5!==_0x179372['newValue']&&_0x179372['newValue']!==_0x179372['oldValue']?setTimeout(_0x355efb,op):_0x355efb();}['notifyListeners'](_0x224c4d,_0x3af5c5){this['localCache'][_0x224c4d]=_0x3af5c5;const _0x26450f=this['listeners'][_0x224c4d];if(_0x26450f){for(const _0x47eff2 of Array['from'](_0x26450f))_0x47eff2(_0x3af5c5&&JSON['parse'](_0x3af5c5));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x21ea66,_0x4050ff,_0x1b22be)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x21ea66,'oldValue':_0x4050ff,'newValue':_0x1b22be}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x5739e3,_0x51a212){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x5739e3]||(this['listeners'][_0x5739e3]=new Set(),this['localCache'][_0x5739e3]=this['storage']['getItem'](_0x5739e3)),this['listeners'][_0x5739e3]['add'](_0x51a212);}['_removeListener'](_0x4a6680,_0x496db9){this['listeners'][_0x4a6680]&&(this['listeners'][_0x4a6680]['delete'](_0x496db9),this['listeners'][_0x4a6680]['size']===0x0&&delete this['listeners'][_0x4a6680]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x51b274,_0x5bd461){await super['_set'](_0x51b274,_0x5bd461),this['localCache'][_0x51b274]=JSON['stringify'](_0x5bd461);}async['_get'](_0x1ec856){const _0x42d10a=await super['_get'](_0x1ec856);return this['localCache'][_0x1ec856]=JSON['stringify'](_0x42d10a),_0x42d10a;}async['_remove'](_0x51e332){await super['_remove'](_0x51e332),delete this['localCache'][_0x51e332];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xd1f532,_0x3a0f8a){}['_removeListener'](_0x34ed04,_0x47e970){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x5cfecc){return Promise['all'](_0x5cfecc['map'](async _0xaf1539=>{try{return{'fulfilled':!0x0,'value':await _0xaf1539};}catch(_0x5c0562){return{'fulfilled':!0x1,'reason':_0x5c0562};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x1578c4){this['eventTarget']=_0x1578c4,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x31da57){const _0x292a86=this['receivers']['find'](_0x2e1af0=>_0x2e1af0['isListeningto'](_0x31da57));if(_0x292a86)return _0x292a86;const _0x5e1276=new Xn(_0x31da57);return this['receivers']['push'](_0x5e1276),_0x5e1276;}['isListeningto'](_0x134bd5){return this['eventTarget']===_0x134bd5;}async['handleEvent'](_0x322bf6){const _0xf16d13=_0x322bf6,{eventId:_0x5ba37f,eventType:_0x4d5671,data:_0x307e5f}=_0xf16d13['data'],_0x2c0407=this['handlersMap'][_0x4d5671];if(!(_0x2c0407!=null&&_0x2c0407['size']))return;_0xf16d13['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x5ba37f,'eventType':_0x4d5671});const _0x6d98ec=Array['from'](_0x2c0407)['map'](async _0x429f49=>_0x429f49(_0xf16d13['origin'],_0x307e5f)),_0x4ed1aa=await cp(_0x6d98ec);_0xf16d13['ports'][0x0]['postMessage']({'status':'done','eventId':_0x5ba37f,'eventType':_0x4d5671,'response':_0x4ed1aa});}['_subscribe'](_0x4c5511,_0x252f0e){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x4c5511]||(this['handlersMap'][_0x4c5511]=new Set()),this['handlersMap'][_0x4c5511]['add'](_0x252f0e);}['_unsubscribe'](_0xde815,_0x450ea8){this['handlersMap'][_0xde815]&&_0x450ea8&&this['handlersMap'][_0xde815]['delete'](_0x450ea8),(!_0x450ea8||this['handlersMap'][_0xde815]['size']===0x0)&&delete this['handlersMap'][_0xde815],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0xd0fc96='',_0x3a6624=0xa){let _0x46e134='';for(let _0x59b895=0x0;_0x59b895<_0x3a6624;_0x59b895++)_0x46e134+=Math['floor'](Math['random']()*0xa);return _0xd0fc96+_0x46e134;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x3687c2){this['target']=_0x3687c2,this['handlers']=new Set();}['removeMessageHandler'](_0x390991){_0x390991['messageChannel']&&(_0x390991['messageChannel']['port1']['removeEventListener']('message',_0x390991['onMessage']),_0x390991['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x390991);}async['_send'](_0x1efc76,_0x4e10b8,_0x533725=0x32){const _0x49ec58=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x49ec58)throw new Error('connection_unavailable');let _0x34b29b,_0x2d054e;return new Promise((_0x206fe3,_0x2ab8d2)=>{const _0x345cce=As('',0x14);_0x49ec58['port1']['start']();const _0x209651=setTimeout(()=>{_0x2ab8d2(new Error('unsupported_event'));},_0x533725);_0x2d054e={'messageChannel':_0x49ec58,'onMessage'(_0x364fd0){const _0x2e9265=_0x364fd0;if(_0x2e9265['data']['eventId']===_0x345cce)switch(_0x2e9265['data']['status']){case'ack':clearTimeout(_0x209651),_0x34b29b=setTimeout(()=>{_0x2ab8d2(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x34b29b),_0x206fe3(_0x2e9265['data']['response']);break;default:clearTimeout(_0x209651),clearTimeout(_0x34b29b),_0x2ab8d2(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2d054e),_0x49ec58['port1']['addEventListener']('message',_0x2d054e['onMessage']),this['target']['postMessage']({'eventType':_0x1efc76,'eventId':_0x345cce,'data':_0x4e10b8},[_0x49ec58['port2']]);})['finally'](()=>{_0x2d054e&&this['removeMessageHandler'](_0x2d054e);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x4797d2){Z()['location']['href']=_0x4797d2;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x149b53;return((_0x149b53=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x149b53['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x367df6){this['request']=_0x367df6;}['toPromise'](){return new Promise((_0x2294de,_0x346f93)=>{this['request']['addEventListener']('success',()=>{_0x2294de(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x346f93(this['request']['error']);});});}}function Zn(_0x4ae0fc,_0x397235){return _0x4ae0fc['transaction']([Mn],_0x397235?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x5571d9=indexedDB['deleteDatabase'](Ka);return new nn(_0x5571d9)['toPromise']();}function Qa(){const _0xf6ac7a=indexedDB['open'](Ka,pp);return new Promise((_0x410ac6,_0x30d637)=>{_0xf6ac7a['addEventListener']('error',()=>{_0x30d637(_0xf6ac7a['error']);}),_0xf6ac7a['addEventListener']('upgradeneeded',()=>{const _0x4041f2=_0xf6ac7a['result'];try{_0x4041f2['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x3dbaba){_0x30d637(_0x3dbaba);}}),_0xf6ac7a['addEventListener']('success',async()=>{const _0x14e8da=_0xf6ac7a['result'];_0x14e8da['objectStoreNames']['contains'](Mn)?_0x410ac6(_0x14e8da):(_0x14e8da['close'](),await _p(),_0x410ac6(await Qa()));});});}async function Or(_0x3a0f91,_0x27c037,_0x293740){const _0x559d00=Zn(_0x3a0f91,!0x0)['put']({[Ya]:_0x27c037,'value':_0x293740});return new nn(_0x559d00)['toPromise']();}async function gp(_0x3c4e35,_0x2657e5){const _0x4e221f=Zn(_0x3c4e35,!0x1)['get'](_0x2657e5),_0x137c07=await new nn(_0x4e221f)['toPromise']();return _0x137c07===void 0x0?null:_0x137c07['value'];}function Dr(_0x2e636d,_0x137b6c){const _0x3ee028=Zn(_0x2e636d,!0x0)['delete'](_0x137b6c);return new nn(_0x3ee028)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x40406){let _0x119d11=0x0;for(;;)try{const _0x25b757=await this['_openDb']();return await _0x40406(_0x25b757);}catch(_0x1078a8){if(_0x119d11++>yp)throw _0x1078a8;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x36eea7,_0x21aece)=>({'keyProcessed':(await this['_poll']())['includes'](_0x21aece['key'])})),this['receiver']['_subscribe']('ping',async(_0xbf1524,_0x386f44)=>['keyChanged']);}async['initializeSender'](){var _0x5c6317,_0x55062e;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x2c8606=await this['sender']['_send']('ping',{},0x320);_0x2c8606&&(_0x5c6317=_0x2c8606[0x0])!=null&&_0x5c6317['fulfilled']&&(_0x55062e=_0x2c8606[0x0])!=null&&_0x55062e['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x218199){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x218199},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3ef0a1=>{await Or(_0x3ef0a1,Dn,'1'),await Dr(_0x3ef0a1,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x236f6c){this['pendingWrites']++;try{await _0x236f6c();}finally{this['pendingWrites']--;}}async['_set'](_0x37458f,_0x3391d7){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x437b7c=>Or(_0x437b7c,_0x37458f,_0x3391d7)),this['localCache'][_0x37458f]=_0x3391d7,this['notifyServiceWorker'](_0x37458f)));}async['_get'](_0x31ee65){const _0x4528b7=await this['_withRetries'](_0x46bd94=>gp(_0x46bd94,_0x31ee65));return this['localCache'][_0x31ee65]=_0x4528b7,_0x4528b7;}async['_remove'](_0x270c85){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5e6ba7=>Dr(_0x5e6ba7,_0x270c85)),delete this['localCache'][_0x270c85],this['notifyServiceWorker'](_0x270c85)));}async['_poll'](){const _0x98297b=await this['_withRetries'](_0x3fa61d=>{const _0x45bd7d=Zn(_0x3fa61d,!0x1)['getAll']();return new nn(_0x45bd7d)['toPromise']();});if(!_0x98297b)return[];if(this['pendingWrites']!==0x0)return[];const _0x4d3e19=[],_0xf6b201=new Set();if(_0x98297b['length']!==0x0){for(const {fbase_key:_0x141f51,value:_0x311ec2}of _0x98297b)_0xf6b201['add'](_0x141f51),JSON['stringify'](this['localCache'][_0x141f51])!==JSON['stringify'](_0x311ec2)&&(this['notifyListeners'](_0x141f51,_0x311ec2),_0x4d3e19['push'](_0x141f51));}for(const _0x37a8d2 of Object['keys'](this['localCache']))this['localCache'][_0x37a8d2]&&!_0xf6b201['has'](_0x37a8d2)&&(this['notifyListeners'](_0x37a8d2,null),_0x4d3e19['push'](_0x37a8d2));return _0x4d3e19;}['notifyListeners'](_0x32b00a,_0x4d2f60){this['localCache'][_0x32b00a]=_0x4d2f60;const _0x30cdb3=this['listeners'][_0x32b00a];if(_0x30cdb3){for(const _0x2b7697 of Array['from'](_0x30cdb3))_0x2b7697(_0x4d2f60);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4ef56a,_0x185894){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4ef56a]||(this['listeners'][_0x4ef56a]=new Set(),this['_get'](_0x4ef56a)),this['listeners'][_0x4ef56a]['add'](_0x185894);}['_removeListener'](_0x1fb0fc,_0x4a8251){this['listeners'][_0x1fb0fc]&&(this['listeners'][_0x1fb0fc]['delete'](_0x4a8251),this['listeners'][_0x1fb0fc]['size']===0x0&&delete this['listeners'][_0x1fb0fc]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x31ea35,_0x4649c7){return _0x4649c7?ie(_0x4649c7):(m(_0x31ea35['_popupRedirectResolver'],_0x31ea35,'argument-error'),_0x31ea35['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x14ed2f){super('custom','custom'),this['params']=_0x14ed2f;}['_getIdTokenResponse'](_0x193069){return nt(_0x193069,this['_buildIdpRequest']());}['_linkToIdToken'](_0x51bbf4,_0x4588d8){return nt(_0x51bbf4,this['_buildIdpRequest'](_0x4588d8));}['_getReauthenticationResolver'](_0x6fa21e){return nt(_0x6fa21e,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3955d5){const _0x4c50d0={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3955d5&&(_0x4c50d0['idToken']=_0x3955d5),_0x4c50d0;}}function Ip(_0x2a96f9){return Va(_0x2a96f9['auth'],new ks(_0x2a96f9),_0x2a96f9['bypassAuthState']);}function wp(_0x4d9a64){const {auth:_0x8f3bf1,user:_0x13c985}=_0x4d9a64;return m(_0x13c985,_0x8f3bf1,'internal-error'),tp(_0x13c985,new ks(_0x4d9a64),_0x4d9a64['bypassAuthState']);}async function Cp(_0x4afd66){const {auth:_0x15de07,user:_0x3ba628}=_0x4afd66;return m(_0x3ba628,_0x15de07,'internal-error'),ep(_0x3ba628,new ks(_0x4afd66),_0x4afd66['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x284de3,_0x2b1bd8,_0x483d9c,_0x112e8b,_0x3d4977=!0x1){this['auth']=_0x284de3,this['resolver']=_0x483d9c,this['user']=_0x112e8b,this['bypassAuthState']=_0x3d4977,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2b1bd8)?_0x2b1bd8:[_0x2b1bd8];}['execute'](){return new Promise(async(_0x1e66c9,_0x5d7694)=>{this['pendingPromise']={'resolve':_0x1e66c9,'reject':_0x5d7694};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3feaf){this['reject'](_0x3feaf);}});}async['onAuthEvent'](_0x4c4389){const {urlResponse:_0x4bf268,sessionId:_0x41b179,postBody:_0x2450d7,tenantId:_0x5dd39e,error:_0xf536dd,type:_0x2188fd}=_0x4c4389;if(_0xf536dd){this['reject'](_0xf536dd);return;}const _0x1b1355={'auth':this['auth'],'requestUri':_0x4bf268,'sessionId':_0x41b179,'tenantId':_0x5dd39e||void 0x0,'postBody':_0x2450d7||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2188fd)(_0x1b1355));}catch(_0x118780){this['reject'](_0x118780);}}['onError'](_0x13b1a2){this['reject'](_0x13b1a2);}['getIdpTask'](_0x2c9bd9){switch(_0x2c9bd9){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0xb9dc11){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xb9dc11),this['unregisterAndCleanUp']();}['reject'](_0x52a7ed){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x52a7ed),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x318bb3,_0x4ab42b,_0x211493,_0x358f95,_0x567c02){super(_0x318bb3,_0x4ab42b,_0x358f95,_0x567c02),this['provider']=_0x211493,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x3f86b8=await this['execute']();return m(_0x3f86b8,this['auth'],'internal-error'),_0x3f86b8;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2d5bcb=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2d5bcb),this['authWindow']['associatedEvent']=_0x2d5bcb,this['resolver']['_originValidation'](this['auth'])['catch'](_0xf5500f=>{this['reject'](_0xf5500f);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3b2743=>{_0x3b2743||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0xf08107;return((_0xf08107=this['authWindow'])==null?void 0x0:_0xf08107['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x4c44b1=()=>{var _0x39673a,_0x1b5014;if((_0x1b5014=(_0x39673a=this['authWindow'])==null?void 0x0:_0x39673a['window'])!=null&&_0x1b5014['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x4c44b1,Tp['get']());};_0x4c44b1();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x253739,_0x64cd74,_0x10976a=!0x1){super(_0x253739,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x64cd74,void 0x0,_0x10976a),this['eventId']=null;}async['execute'](){let _0x111fdf=hn['get'](this['auth']['_key']());if(!_0x111fdf){try{const _0x337232=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x111fdf=()=>Promise['resolve'](_0x337232);}catch(_0x7f95c){_0x111fdf=()=>Promise['reject'](_0x7f95c);}hn['set'](this['auth']['_key'](),_0x111fdf);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x111fdf();}async['onAuthEvent'](_0xba39bb){if(_0xba39bb['type']==='signInViaRedirect')return super['onAuthEvent'](_0xba39bb);if(_0xba39bb['type']==='unknown'){this['resolve'](null);return;}if(_0xba39bb['eventId']){const _0x10e02c=await this['auth']['_redirectUserForId'](_0xba39bb['eventId']);if(_0x10e02c)return this['user']=_0x10e02c,super['onAuthEvent'](_0xba39bb);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0xcccd8a,_0x2013ea){const _0x13c9f0=Pp(_0x2013ea),_0x5d8e13=kp(_0xcccd8a);if(!await _0x5d8e13['_isAvailable']())return!0x1;const _0x4a709c=await _0x5d8e13['_get'](_0x13c9f0)==='true';return await _0x5d8e13['_remove'](_0x13c9f0),_0x4a709c;}function Ap(_0x48df92,_0x38b5e0){hn['set'](_0x48df92['_key'](),_0x38b5e0);}function kp(_0x26ffa7){return ie(_0x26ffa7['_redirectPersistence']);}function Pp(_0x2c3aac){return ln(Sp,_0x2c3aac['config']['apiKey'],_0x2c3aac['name']);}async function Np(_0x2c5a1d,_0x2eb0fd,_0x3350b8=!0x1){if($(_0x2c5a1d['app']))return Promise['reject'](re(_0x2c5a1d));const _0x3f0c81=Ke(_0x2c5a1d),_0x33003a=Ep(_0x3f0c81,_0x2eb0fd),_0xd5bf73=await new bp(_0x3f0c81,_0x33003a,_0x3350b8)['execute']();return _0xd5bf73&&!_0x3350b8&&(delete _0xd5bf73['user']['_redirectEventId'],await _0x3f0c81['_persistUserIfCurrent'](_0xd5bf73['user']),await _0x3f0c81['_setRedirectUser'](null,_0x2eb0fd)),_0xd5bf73;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x44ecf7){this['auth']=_0x44ecf7,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x2ba9af){this['consumers']['add'](_0x2ba9af),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x2ba9af)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x2ba9af),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2fb305){this['consumers']['delete'](_0x2fb305);}['onEvent'](_0x4dac18){if(this['hasEventBeenHandled'](_0x4dac18))return!0x1;let _0x29c541=!0x1;return this['consumers']['forEach'](_0x55eef0=>{this['isEventForConsumer'](_0x4dac18,_0x55eef0)&&(_0x29c541=!0x0,this['sendToConsumer'](_0x4dac18,_0x55eef0),this['saveEventToCache'](_0x4dac18));}),this['hasHandledPotentialRedirect']||!Mp(_0x4dac18)||(this['hasHandledPotentialRedirect']=!0x0,_0x29c541||(this['queuedRedirectEvent']=_0x4dac18,_0x29c541=!0x0)),_0x29c541;}['sendToConsumer'](_0x9f8624,_0x1f508d){var _0x35248b;if(_0x9f8624['error']&&!Za(_0x9f8624)){const _0x30a9b3=((_0x35248b=_0x9f8624['error']['code'])==null?void 0x0:_0x35248b['split']('auth/')[0x1])||'internal-error';_0x1f508d['onError'](X(this['auth'],_0x30a9b3));}else _0x1f508d['onAuthEvent'](_0x9f8624);}['isEventForConsumer'](_0x774d30,_0x13077f){const _0x2170d5=_0x13077f['eventId']===null||!!_0x774d30['eventId']&&_0x774d30['eventId']===_0x13077f['eventId'];return _0x13077f['filter']['includes'](_0x774d30['type'])&&_0x2170d5;}['hasEventBeenHandled'](_0x59b9f3){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x59b9f3));}['saveEventToCache'](_0x4117dd){this['cachedEventUids']['add'](Mr(_0x4117dd)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x3265c1){return[_0x3265c1['type'],_0x3265c1['eventId'],_0x3265c1['sessionId'],_0x3265c1['tenantId']]['filter'](_0x3d91b4=>_0x3d91b4)['join']('-');}function Za({type:_0x289409,error:_0x4bf5b4}){return _0x289409==='unknown'&&(_0x4bf5b4==null?void 0x0:_0x4bf5b4['code'])==='auth/no-auth-event';}function Mp(_0x389982){switch(_0x389982['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x389982);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0xafed6a,_0x2ce8e9={}){return Pe(_0xafed6a,'GET','/v1/projects',_0x2ce8e9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x1d3d7a){if(_0x1d3d7a['config']['emulator'])return;const {authorizedDomains:_0x4ae4f3}=await Lp(_0x1d3d7a);for(const _0x33ca1e of _0x4ae4f3)try{if(Wp(_0x33ca1e))return;}catch{}Y(_0x1d3d7a,'unauthorized-domain');}function Wp(_0x2bb65a){const _0x3c7296=Mi(),{protocol:_0x2ac271,hostname:_0x19fbc8}=new URL(_0x3c7296);if(_0x2bb65a['startsWith']('chrome-extension://')){const _0x2bafe8=new URL(_0x2bb65a);return _0x2bafe8['hostname']===''&&_0x19fbc8===''?_0x2ac271==='chrome-extension:'&&_0x2bb65a['replace']('chrome-extension://','')===_0x3c7296['replace']('chrome-extension://',''):_0x2ac271==='chrome-extension:'&&_0x2bafe8['hostname']===_0x19fbc8;}if(!Fp['test'](_0x2ac271))return!0x1;if(xp['test'](_0x2bb65a))return _0x19fbc8===_0x2bb65a;const _0x35c000=_0x2bb65a['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x35c000+'|'+_0x35c000+')$','i')['test'](_0x19fbc8);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x49bd85=Z()['___jsl'];if(_0x49bd85!=null&&_0x49bd85['H']){for(const _0x3c55ca of Object['keys'](_0x49bd85['H']))if(_0x49bd85['H'][_0x3c55ca]['r']=_0x49bd85['H'][_0x3c55ca]['r']||[],_0x49bd85['H'][_0x3c55ca]['L']=_0x49bd85['H'][_0x3c55ca]['L']||[],_0x49bd85['H'][_0x3c55ca]['r']=[..._0x49bd85['H'][_0x3c55ca]['L']],_0x49bd85['CP']){for(let _0x32dcf5=0x0;_0x32dcf5<_0x49bd85['CP']['length'];_0x32dcf5++)_0x49bd85['CP'][_0x32dcf5]=null;}}}function Vp(_0x3ee527){return new Promise((_0x42fc51,_0xd3d63c)=>{var _0x599048,_0x5f21d2,_0x3348df;function _0x519a32(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x42fc51(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0xd3d63c(X(_0x3ee527,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x5f21d2=(_0x599048=Z()['gapi'])==null?void 0x0:_0x599048['iframes'])!=null&&_0x5f21d2['Iframe'])_0x42fc51(gapi['iframes']['getContext']());else{if((_0x3348df=Z()['gapi'])!=null&&_0x3348df['load'])_0x519a32();else{const _0x445022=Ff('iframefcb');return Z()[_0x445022]=()=>{gapi['load']?_0x519a32():_0xd3d63c(X(_0x3ee527,'network-request-failed'));},xa(xf()+'?onload='+_0x445022)['catch'](_0x514030=>_0xd3d63c(_0x514030));}}})['catch'](_0x19fd9b=>{throw un=null,_0x19fd9b;});}let un=null;function Hp(_0x33cab1){return un=un||Vp(_0x33cab1),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x417eca){const _0xe2d062=_0x417eca['config'];m(_0xe2d062['authDomain'],_0x417eca,'auth-domain-config-required');const _0x22c135=_0xe2d062['emulator']?Cs(_0xe2d062,qp):'https://'+_0x417eca['config']['authDomain']+'/'+Gp,_0x55b39c={'apiKey':_0xe2d062['apiKey'],'appName':_0x417eca['name'],'v':dt},_0x5bd470=jp['get'](_0x417eca['config']['apiHost']);_0x5bd470&&(_0x55b39c['eid']=_0x5bd470);const _0x3538e7=_0x417eca['_getFrameworks']();return _0x3538e7['length']&&(_0x55b39c['fw']=_0x3538e7['join'](',')),_0x22c135+'?'+ut(_0x55b39c)['slice'](0x1);}async function Yp(_0xa9fb74){const _0x5a4618=await Hp(_0xa9fb74),_0x5e81c6=Z()['gapi'];return m(_0x5e81c6,_0xa9fb74,'internal-error'),_0x5a4618['open']({'where':document['body'],'url':Kp(_0xa9fb74),'messageHandlersFilter':_0x5e81c6['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x108f28=>new Promise(async(_0x4394ea,_0x14544b)=>{await _0x108f28['restyle']({'setHideOnLeave':!0x1});const _0x31f94f=X(_0xa9fb74,'network-request-failed'),_0x41d899=Z()['setTimeout'](()=>{_0x14544b(_0x31f94f);},$p['get']());function _0x5c95a7(){Z()['clearTimeout'](_0x41d899),_0x4394ea(_0x108f28);}_0x108f28['ping'](_0x5c95a7)['then'](_0x5c95a7,()=>{_0x14544b(_0x31f94f);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x39b7bf){this['window']=_0x39b7bf,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x15a315,_0xbcd0a2,_0x4ba528,_0x5340f3=Jp,_0x3a7350=Xp){const _0x4cb3c3=Math['max']((window['screen']['availHeight']-_0x3a7350)/0x2,0x0)['toString'](),_0x37d9fc=Math['max']((window['screen']['availWidth']-_0x5340f3)/0x2,0x0)['toString']();let _0x3cbd4f='';const _0x44235d={...Qp,'width':_0x5340f3['toString'](),'height':_0x3a7350['toString'](),'top':_0x4cb3c3,'left':_0x37d9fc},_0x2ed1c3=W()['toLowerCase']();_0x4ba528&&(_0x3cbd4f=ka(_0x2ed1c3)?Zp:_0x4ba528),Ra(_0x2ed1c3)&&(_0xbcd0a2=_0xbcd0a2||e_,_0x44235d['scrollbars']='yes');const _0x369d80=Object['entries'](_0x44235d)['reduce']((_0x14d3a2,[_0x2b1d27,_0x21ba0f])=>''+_0x14d3a2+_0x2b1d27+'='+_0x21ba0f+',','');if(Rf(_0x2ed1c3)&&_0x3cbd4f!=='_self')return n_(_0xbcd0a2||'',_0x3cbd4f),new xr(null);const _0x578d53=window['open'](_0xbcd0a2||'',_0x3cbd4f,_0x369d80);m(_0x578d53,_0x15a315,'popup-blocked');try{_0x578d53['focus']();}catch{}return new xr(_0x578d53);}function n_(_0x47da5a,_0x2f48ad){const _0x38e52a=document['createElement']('a');_0x38e52a['href']=_0x47da5a,_0x38e52a['target']=_0x2f48ad;const _0x39b241=document['createEvent']('MouseEvent');_0x39b241['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x38e52a['dispatchEvent'](_0x39b241);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x26207f,_0x2e4c45,_0x39676e,_0x245e0d,_0x1e3b40,_0x588274){m(_0x26207f['config']['authDomain'],_0x26207f,'auth-domain-config-required'),m(_0x26207f['config']['apiKey'],_0x26207f,'invalid-api-key');const _0x90b35b={'apiKey':_0x26207f['config']['apiKey'],'appName':_0x26207f['name'],'authType':_0x39676e,'redirectUrl':_0x245e0d,'v':dt,'eventId':_0x1e3b40};if(_0x2e4c45 instanceof Wa){_0x2e4c45['setDefaultLanguage'](_0x26207f['languageCode']),_0x90b35b['providerId']=_0x2e4c45['providerId']||'',pn(_0x2e4c45['getCustomParameters']())||(_0x90b35b['customParameters']=JSON['stringify'](_0x2e4c45['getCustomParameters']()));for(const [_0x4ede89,_0x2a310d]of Object['entries']({}))_0x90b35b[_0x4ede89]=_0x2a310d;}if(_0x2e4c45 instanceof tn){const _0x4f9417=_0x2e4c45['getScopes']()['filter'](_0x4321ec=>_0x4321ec!=='');_0x4f9417['length']>0x0&&(_0x90b35b['scopes']=_0x4f9417['join'](','));}_0x26207f['tenantId']&&(_0x90b35b['tid']=_0x26207f['tenantId']);const _0x3c8a5f=_0x90b35b;for(const _0x235a93 of Object['keys'](_0x3c8a5f))_0x3c8a5f[_0x235a93]===void 0x0&&delete _0x3c8a5f[_0x235a93];const _0x4ad5d2=await _0x26207f['_getAppCheckToken'](),_0x47fb50=_0x4ad5d2?'#'+r_+'='+encodeURIComponent(_0x4ad5d2):'';return o_(_0x26207f)+'?'+ut(_0x3c8a5f)['slice'](0x1)+_0x47fb50;}function o_({config:_0x4be913}){return _0x4be913['emulator']?Cs(_0x4be913,s_):'https://'+_0x4be913['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0xd41a68,_0x441f20,_0x8dfc73,_0x687fa9){var _0x127959;ce((_0x127959=this['eventManagers'][_0xd41a68['_key']()])==null?void 0x0:_0x127959['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x439944=await Fr(_0xd41a68,_0x441f20,_0x8dfc73,Mi(),_0x687fa9);return t_(_0xd41a68,_0x439944,As());}async['_openRedirect'](_0x48a87c,_0x1868a5,_0x1c393f,_0xc70782){await this['_originValidation'](_0x48a87c);const _0x3a3450=await Fr(_0x48a87c,_0x1868a5,_0x1c393f,Mi(),_0xc70782);return hp(_0x3a3450),new Promise(()=>{});}['_initialize'](_0x28f907){const _0x514622=_0x28f907['_key']();if(this['eventManagers'][_0x514622]){const {manager:_0x1b69ec,promise:_0x61094}=this['eventManagers'][_0x514622];return _0x1b69ec?Promise['resolve'](_0x1b69ec):(ce(_0x61094,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x61094);}const _0x4f5465=this['initAndGetManager'](_0x28f907);return this['eventManagers'][_0x514622]={'promise':_0x4f5465},_0x4f5465['catch'](()=>{delete this['eventManagers'][_0x514622];}),_0x4f5465;}async['initAndGetManager'](_0x4d3c34){const _0x79dca3=await Yp(_0x4d3c34),_0x54852c=new Dp(_0x4d3c34);return _0x79dca3['register']('authEvent',_0x5a3fc2=>(m(_0x5a3fc2==null?void 0x0:_0x5a3fc2['authEvent'],_0x4d3c34,'invalid-auth-event'),{'status':_0x54852c['onEvent'](_0x5a3fc2['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x4d3c34['_key']()]={'manager':_0x54852c},this['iframes'][_0x4d3c34['_key']()]=_0x79dca3,_0x54852c;}['_isIframeWebStorageSupported'](_0x409b94,_0xe1dbad){this['iframes'][_0x409b94['_key']()]['send'](pi,{'type':pi},_0x589367=>{var _0x50648b;const _0x739221=(_0x50648b=_0x589367==null?void 0x0:_0x589367[0x0])==null?void 0x0:_0x50648b[pi];_0x739221!==void 0x0&&_0xe1dbad(!!_0x739221),Y(_0x409b94,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x408b96){const _0x4c3197=_0x408b96['_key']();return this['originValidationPromises'][_0x4c3197]||(this['originValidationPromises'][_0x4c3197]=Up(_0x408b96)),this['originValidationPromises'][_0x4c3197];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x1168fe){this['auth']=_0x1168fe,this['internalListeners']=new Map();}['getUid'](){var _0x4ef5d2;return this['assertAuthConfigured'](),((_0x4ef5d2=this['auth']['currentUser'])==null?void 0x0:_0x4ef5d2['uid'])||null;}async['getToken'](_0x28d631){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x28d631)}:null;}['addAuthTokenListener'](_0x24308b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x24308b))return;const _0x27fd20=this['auth']['onIdTokenChanged'](_0x2a9bb2=>{_0x24308b((_0x2a9bb2==null?void 0x0:_0x2a9bb2['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x24308b,_0x27fd20),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2157c7){this['assertAuthConfigured']();const _0x22eb36=this['internalListeners']['get'](_0x2157c7);_0x22eb36&&(this['internalListeners']['delete'](_0x2157c7),_0x22eb36(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x30d12c){switch(_0x30d12c){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x5a56bf){st(new Fe('auth',(_0x414086,{options:_0x56170e})=>{const _0x439fe6=_0x414086['getProvider']('app')['getImmediate'](),_0x179a4b=_0x414086['getProvider']('heartbeat'),_0x48bc18=_0x414086['getProvider']('app-check-internal'),{apiKey:_0x33ecdf,authDomain:_0x551695}=_0x439fe6['options'];m(_0x33ecdf&&!_0x33ecdf['includes'](':'),'invalid-api-key',{'appName':_0x439fe6['name']});const _0x10fab8={'apiKey':_0x33ecdf,'authDomain':_0x551695,'clientPlatform':_0x5a56bf,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5a56bf)},_0x36b0f8=new Df(_0x439fe6,_0x179a4b,_0x48bc18,_0x10fab8);return Hf(_0x36b0f8,_0x56170e),_0x36b0f8;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3835e9,_0x372bf9,_0x50716d)=>{_0x3835e9['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x693b8e=>{const _0x344574=Ke(_0x693b8e['getProvider']('auth')['getImmediate']());return(_0x48d8cb=>new l_(_0x48d8cb))(_0x344574);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x5a56bf)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x39a2b5=>async _0x8dfae4=>{const _0x4b47d5=_0x8dfae4&&await _0x8dfae4['getIdTokenResult'](),_0x362b90=_0x4b47d5&&(new Date()['getTime']()-Date['parse'](_0x4b47d5['issuedAtTime']))/0x3e8;if(_0x362b90&&_0x362b90>f_)return;const _0x2229a4=_0x4b47d5==null?void 0x0:_0x4b47d5['token'];Br!==_0x2229a4&&(Br=_0x2229a4,await fetch(_0x39a2b5,{'method':_0x2229a4?'POST':'DELETE','headers':_0x2229a4?{'Authorization':'Bearer\x20'+_0x2229a4}:{}}));};function B_(_0x217657=Zr()){const _0x5d282e=Hi(_0x217657,'auth');if(_0x5d282e['isInitialized']())return _0x5d282e['getImmediate']();const _0x2773b7=Vf(_0x217657,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x59c571=jr('authTokenSyncURL');if(_0x59c571&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5e2522=new URL(_0x59c571,location['origin']);if(location['origin']===_0x5e2522['origin']){const _0x7aa504=p_(_0x5e2522['toString']());sp(_0x2773b7,_0x7aa504,()=>_0x7aa504(_0x2773b7['currentUser'])),ip(_0x2773b7,_0x572265=>_0x7aa504(_0x572265));}}const _0x2c87cc=qr('auth');return _0x2c87cc&&$f(_0x2773b7,'http://'+_0x2c87cc),_0x2773b7;}function __(){var _0x43d992;return((_0x43d992=document['getElementsByTagName']('head'))==null?void 0x0:_0x43d992[0x0])??document;}Mf({'loadJS'(_0x19dda0){return new Promise((_0x22550f,_0x437e07)=>{const _0x1be463=document['createElement']('script');_0x1be463['setAttribute']('src',_0x19dda0),_0x1be463['onload']=_0x22550f,_0x1be463['onerror']=_0x48ba1c=>{const _0xaa4beb=X('internal-error');_0xaa4beb['customData']=_0x48ba1c,_0x437e07(_0xaa4beb);},_0x1be463['type']='text/javascript',_0x1be463['charset']='UTF-8',__()['appendChild'](_0x1be463);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};