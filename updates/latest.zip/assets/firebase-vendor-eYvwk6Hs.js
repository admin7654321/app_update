const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3a243e,_0x54842a){if(!_0x3a243e)throw ht(_0x54842a);},ht=function(_0x52b7c6){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x52b7c6);},Hr=function(_0x8dcbca){const _0x4cd76b=[];let _0x1c5a3c=0x0;for(let _0x32903e=0x0;_0x32903e<_0x8dcbca['length'];_0x32903e++){let _0x4ee12b=_0x8dcbca['charCodeAt'](_0x32903e);_0x4ee12b<0x80?_0x4cd76b[_0x1c5a3c++]=_0x4ee12b:_0x4ee12b<0x800?(_0x4cd76b[_0x1c5a3c++]=_0x4ee12b>>0x6|0xc0,_0x4cd76b[_0x1c5a3c++]=_0x4ee12b&0x3f|0x80):(_0x4ee12b&0xfc00)===0xd800&&_0x32903e+0x1<_0x8dcbca['length']&&(_0x8dcbca['charCodeAt'](_0x32903e+0x1)&0xfc00)===0xdc00?(_0x4ee12b=0x10000+((_0x4ee12b&0x3ff)<<0xa)+(_0x8dcbca['charCodeAt'](++_0x32903e)&0x3ff),_0x4cd76b[_0x1c5a3c++]=_0x4ee12b>>0x12|0xf0,_0x4cd76b[_0x1c5a3c++]=_0x4ee12b>>0xc&0x3f|0x80,_0x4cd76b[_0x1c5a3c++]=_0x4ee12b>>0x6&0x3f|0x80,_0x4cd76b[_0x1c5a3c++]=_0x4ee12b&0x3f|0x80):(_0x4cd76b[_0x1c5a3c++]=_0x4ee12b>>0xc|0xe0,_0x4cd76b[_0x1c5a3c++]=_0x4ee12b>>0x6&0x3f|0x80,_0x4cd76b[_0x1c5a3c++]=_0x4ee12b&0x3f|0x80);}return _0x4cd76b;},nc=function(_0x15d94a){const _0x408391=[];let _0x3a193d=0x0,_0x343a78=0x0;for(;_0x3a193d<_0x15d94a['length'];){const _0x39c4d5=_0x15d94a[_0x3a193d++];if(_0x39c4d5<0x80)_0x408391[_0x343a78++]=String['fromCharCode'](_0x39c4d5);else{if(_0x39c4d5>0xbf&&_0x39c4d5<0xe0){const _0x1e2cbf=_0x15d94a[_0x3a193d++];_0x408391[_0x343a78++]=String['fromCharCode']((_0x39c4d5&0x1f)<<0x6|_0x1e2cbf&0x3f);}else{if(_0x39c4d5>0xef&&_0x39c4d5<0x16d){const _0x31626a=_0x15d94a[_0x3a193d++],_0x5261d5=_0x15d94a[_0x3a193d++],_0x2df7c3=_0x15d94a[_0x3a193d++],_0x36c0d9=((_0x39c4d5&0x7)<<0x12|(_0x31626a&0x3f)<<0xc|(_0x5261d5&0x3f)<<0x6|_0x2df7c3&0x3f)-0x10000;_0x408391[_0x343a78++]=String['fromCharCode'](0xd800+(_0x36c0d9>>0xa)),_0x408391[_0x343a78++]=String['fromCharCode'](0xdc00+(_0x36c0d9&0x3ff));}else{const _0xccf4ab=_0x15d94a[_0x3a193d++],_0x4164d2=_0x15d94a[_0x3a193d++];_0x408391[_0x343a78++]=String['fromCharCode']((_0x39c4d5&0xf)<<0xc|(_0xccf4ab&0x3f)<<0x6|_0x4164d2&0x3f);}}}}return _0x408391['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xf34838,_0x270c9c){if(!Array['isArray'](_0xf34838))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x41c2be=_0x270c9c?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x243054=[];for(let _0xe56e68=0x0;_0xe56e68<_0xf34838['length'];_0xe56e68+=0x3){const _0x28694f=_0xf34838[_0xe56e68],_0x54aea8=_0xe56e68+0x1<_0xf34838['length'],_0x2e277d=_0x54aea8?_0xf34838[_0xe56e68+0x1]:0x0,_0x4c5930=_0xe56e68+0x2<_0xf34838['length'],_0x22d465=_0x4c5930?_0xf34838[_0xe56e68+0x2]:0x0,_0x260e08=_0x28694f>>0x2,_0x3b4a09=(_0x28694f&0x3)<<0x4|_0x2e277d>>0x4;let _0xbbebc2=(_0x2e277d&0xf)<<0x2|_0x22d465>>0x6,_0x7ca1db=_0x22d465&0x3f;_0x4c5930||(_0x7ca1db=0x40,_0x54aea8||(_0xbbebc2=0x40)),_0x243054['push'](_0x41c2be[_0x260e08],_0x41c2be[_0x3b4a09],_0x41c2be[_0xbbebc2],_0x41c2be[_0x7ca1db]);}return _0x243054['join']('');},'encodeString'(_0x5e0b8e,_0x10513b){return this['HAS_NATIVE_SUPPORT']&&!_0x10513b?btoa(_0x5e0b8e):this['encodeByteArray'](Hr(_0x5e0b8e),_0x10513b);},'decodeString'(_0x8d4398,_0x4ccfaf){return this['HAS_NATIVE_SUPPORT']&&!_0x4ccfaf?atob(_0x8d4398):nc(this['decodeStringToByteArray'](_0x8d4398,_0x4ccfaf));},'decodeStringToByteArray'(_0x1990dd,_0x5eaf7a){this['init_']();const _0x2b20aa=_0x5eaf7a?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x9b569b=[];for(let _0x579233=0x0;_0x579233<_0x1990dd['length'];){const _0x5b62f4=_0x2b20aa[_0x1990dd['charAt'](_0x579233++)],_0x501f20=_0x579233<_0x1990dd['length']?_0x2b20aa[_0x1990dd['charAt'](_0x579233)]:0x0;++_0x579233;const _0x4cb841=_0x579233<_0x1990dd['length']?_0x2b20aa[_0x1990dd['charAt'](_0x579233)]:0x40;++_0x579233;const _0x2a6fa9=_0x579233<_0x1990dd['length']?_0x2b20aa[_0x1990dd['charAt'](_0x579233)]:0x40;if(++_0x579233,_0x5b62f4==null||_0x501f20==null||_0x4cb841==null||_0x2a6fa9==null)throw new ic();const _0x3c4bcf=_0x5b62f4<<0x2|_0x501f20>>0x4;if(_0x9b569b['push'](_0x3c4bcf),_0x4cb841!==0x40){const _0x275b43=_0x501f20<<0x4&0xf0|_0x4cb841>>0x2;if(_0x9b569b['push'](_0x275b43),_0x2a6fa9!==0x40){const _0x10b7bd=_0x4cb841<<0x6&0xc0|_0x2a6fa9;_0x9b569b['push'](_0x10b7bd);}}}return _0x9b569b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x377a64=0x0;_0x377a64<this['ENCODED_VALS']['length'];_0x377a64++)this['byteToCharMap_'][_0x377a64]=this['ENCODED_VALS']['charAt'](_0x377a64),this['charToByteMap_'][this['byteToCharMap_'][_0x377a64]]=_0x377a64,this['byteToCharMapWebSafe_'][_0x377a64]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x377a64),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x377a64]]=_0x377a64,_0x377a64>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x377a64)]=_0x377a64,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x377a64)]=_0x377a64);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x171e0a){const _0x2b2f9c=Hr(_0x171e0a);return Fi['encodeByteArray'](_0x2b2f9c,!0x0);},dn=function(_0x209551){return $r(_0x209551)['replace'](/\./g,'');},fn=function(_0x20fe57){try{return Fi['decodeString'](_0x20fe57,!0x0);}catch(_0x519729){console['error']('base64Decode\x20failed:\x20',_0x519729);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x40f1b8){return Gr(void 0x0,_0x40f1b8);}function Gr(_0x5479c5,_0x480d7e){if(!(_0x480d7e instanceof Object))return _0x480d7e;switch(_0x480d7e['constructor']){case Date:const _0x4dda05=_0x480d7e;return new Date(_0x4dda05['getTime']());case Object:_0x5479c5===void 0x0&&(_0x5479c5={});break;case Array:_0x5479c5=[];break;default:return _0x480d7e;}for(const _0x3b6883 in _0x480d7e)!_0x480d7e['hasOwnProperty'](_0x3b6883)||!rc(_0x3b6883)||(_0x5479c5[_0x3b6883]=Gr(_0x5479c5[_0x3b6883],_0x480d7e[_0x3b6883]));return _0x5479c5;}function rc(_0x4f073f){return _0x4f073f!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x402eeb=Ps['__FIREBASE_DEFAULTS__'];if(_0x402eeb)return JSON['parse'](_0x402eeb);},lc=()=>{if(typeof document>'u')return;let _0x4e32d0;try{_0x4e32d0=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x148cee=_0x4e32d0&&fn(_0x4e32d0[0x1]);return _0x148cee&&JSON['parse'](_0x148cee);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x4f2696){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4f2696);return;}},qr=_0x55eb07=>{var _0x3a8682,_0x5dd193;return(_0x5dd193=(_0x3a8682=Ui())==null?void 0x0:_0x3a8682['emulatorHosts'])==null?void 0x0:_0x5dd193[_0x55eb07];},hc=_0x50542b=>{const _0x491102=qr(_0x50542b);if(!_0x491102)return;const _0x36061c=_0x491102['lastIndexOf'](':');if(_0x36061c<=0x0||_0x36061c+0x1===_0x491102['length'])throw new Error('Invalid\x20host\x20'+_0x491102+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x3d9fa3=parseInt(_0x491102['substring'](_0x36061c+0x1),0xa);return _0x491102[0x0]==='['?[_0x491102['substring'](0x1,_0x36061c-0x1),_0x3d9fa3]:[_0x491102['substring'](0x0,_0x36061c),_0x3d9fa3];},zr=()=>{var _0x3a751e;return(_0x3a751e=Ui())==null?void 0x0:_0x3a751e['config'];},jr=_0x2b951a=>{var _0x383560;return(_0x383560=Ui())==null?void 0x0:_0x383560['_'+_0x2b951a];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3a8ab7,_0x1f3a21)=>{this['resolve']=_0x3a8ab7,this['reject']=_0x1f3a21;});}['wrapCallback'](_0x40982d){return(_0x58b4a6,_0x525809)=>{_0x58b4a6?this['reject'](_0x58b4a6):this['resolve'](_0x525809),typeof _0x40982d=='function'&&(this['promise']['catch'](()=>{}),_0x40982d['length']===0x1?_0x40982d(_0x58b4a6):_0x40982d(_0x58b4a6,_0x525809));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x3b431e,_0x45e746){if(_0x3b431e['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5e4afd={'alg':'none','type':'JWT'},_0xaa1e98=_0x45e746||'demo-project',_0x4e237c=_0x3b431e['iat']||0x0,_0x3ac963=_0x3b431e['sub']||_0x3b431e['user_id'];if(!_0x3ac963)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x275808={'iss':'https://securetoken.google.com/'+_0xaa1e98,'aud':_0xaa1e98,'iat':_0x4e237c,'exp':_0x4e237c+0xe10,'auth_time':_0x4e237c,'sub':_0x3ac963,'user_id':_0x3ac963,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3b431e};return[dn(JSON['stringify'](_0x5e4afd)),dn(JSON['stringify'](_0x275808)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x313556=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x313556=='object'&&_0x313556['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x16003c=W();return _0x16003c['indexOf']('MSIE\x20')>=0x0||_0x16003c['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x58aa1b,_0x356d28)=>{try{let _0x206932=!0x0;const _0x9c8ffd='validate-browser-context-for-indexeddb-analytics-module',_0x183d33=self['indexedDB']['open'](_0x9c8ffd);_0x183d33['onsuccess']=()=>{_0x183d33['result']['close'](),_0x206932||self['indexedDB']['deleteDatabase'](_0x9c8ffd),_0x58aa1b(!0x0);},_0x183d33['onupgradeneeded']=()=>{_0x206932=!0x1;},_0x183d33['onerror']=()=>{var _0x297f68;_0x356d28(((_0x297f68=_0x183d33['error'])==null?void 0x0:_0x297f68['message'])||'');};}catch(_0x4761b7){_0x356d28(_0x4761b7);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x50549e,_0x2660b9,_0x15dd1e){super(_0x2660b9),this['code']=_0x50549e,this['customData']=_0x15dd1e,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x5b48ce,_0x4e2921,_0x330611){this['service']=_0x5b48ce,this['serviceName']=_0x4e2921,this['errors']=_0x330611;}['create'](_0xd1d4a3,..._0x4c8305){const _0x45e68e=_0x4c8305[0x0]||{},_0x546d4a=this['service']+'/'+_0xd1d4a3,_0x1022fe=this['errors'][_0xd1d4a3],_0x312efd=_0x1022fe?vc(_0x1022fe,_0x45e68e):'Error',_0x25fae7=this['serviceName']+':\x20'+_0x312efd+'\x20('+_0x546d4a+').';return new Re(_0x546d4a,_0x25fae7,_0x45e68e);}}function vc(_0x537ae9,_0x4c8e24){return _0x537ae9['replace'](Ec,(_0x2270fa,_0x50b184)=>{const _0x5e0447=_0x4c8e24[_0x50b184];return _0x5e0447!=null?String(_0x5e0447):'<'+_0x50b184+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x317dfc){return JSON['parse'](_0x317dfc);}function O(_0x2173a7){return JSON['stringify'](_0x2173a7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x496c47){let _0x49b560={},_0x6e78d9={},_0x20dca8={},_0x333b87='';try{const _0x1536d2=_0x496c47['split']('.');_0x49b560=Nt(fn(_0x1536d2[0x0])||''),_0x6e78d9=Nt(fn(_0x1536d2[0x1])||''),_0x333b87=_0x1536d2[0x2],_0x20dca8=_0x6e78d9['d']||{},delete _0x6e78d9['d'];}catch{}return{'header':_0x49b560,'claims':_0x6e78d9,'data':_0x20dca8,'signature':_0x333b87};},Ic=function(_0x27d5fd){const _0x4cb034=Yr(_0x27d5fd),_0x9d9098=_0x4cb034['claims'];return!!_0x9d9098&&typeof _0x9d9098=='object'&&_0x9d9098['hasOwnProperty']('iat');},wc=function(_0x3ae28c){const _0x2da105=Yr(_0x3ae28c)['claims'];return typeof _0x2da105=='object'&&_0x2da105['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x153b81,_0x4ead54){return Object['prototype']['hasOwnProperty']['call'](_0x153b81,_0x4ead54);}function Le(_0x137313,_0x3798ab){if(Object['prototype']['hasOwnProperty']['call'](_0x137313,_0x3798ab))return _0x137313[_0x3798ab];}function pn(_0x1ef616){for(const _0x4f0167 in _0x1ef616)if(Object['prototype']['hasOwnProperty']['call'](_0x1ef616,_0x4f0167))return!0x1;return!0x0;}function _n(_0xf39e3,_0x5c16d6,_0x1ad10a){const _0x54b4e1={};for(const _0x22c1e4 in _0xf39e3)Object['prototype']['hasOwnProperty']['call'](_0xf39e3,_0x22c1e4)&&(_0x54b4e1[_0x22c1e4]=_0x5c16d6['call'](_0x1ad10a,_0xf39e3[_0x22c1e4],_0x22c1e4,_0xf39e3));return _0x54b4e1;}function xe(_0x1ffdb9,_0xfacbf7){if(_0x1ffdb9===_0xfacbf7)return!0x0;const _0x2f430c=Object['keys'](_0x1ffdb9),_0x8da59f=Object['keys'](_0xfacbf7);for(const _0x48e8b1 of _0x2f430c){if(!_0x8da59f['includes'](_0x48e8b1))return!0x1;const _0x1dc330=_0x1ffdb9[_0x48e8b1],_0x25c5cd=_0xfacbf7[_0x48e8b1];if(Ns(_0x1dc330)&&Ns(_0x25c5cd)){if(!xe(_0x1dc330,_0x25c5cd))return!0x1;}else{if(_0x1dc330!==_0x25c5cd)return!0x1;}}for(const _0x50b9ca of _0x8da59f)if(!_0x2f430c['includes'](_0x50b9ca))return!0x1;return!0x0;}function Ns(_0x49aaa6){return _0x49aaa6!==null&&typeof _0x49aaa6=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x281475){const _0x29d58d=[];for(const [_0x407dd9,_0xad02b6]of Object['entries'](_0x281475))Array['isArray'](_0xad02b6)?_0xad02b6['forEach'](_0x391eae=>{_0x29d58d['push'](encodeURIComponent(_0x407dd9)+'='+encodeURIComponent(_0x391eae));}):_0x29d58d['push'](encodeURIComponent(_0x407dd9)+'='+encodeURIComponent(_0xad02b6));return _0x29d58d['length']?'&'+_0x29d58d['join']('&'):'';}function Ct(_0x1442d1){const _0x454811={};return _0x1442d1['replace'](/^\?/,'')['split']('&')['forEach'](_0x5e3a78=>{if(_0x5e3a78){const [_0x25eb12,_0x435f61]=_0x5e3a78['split']('=');_0x454811[decodeURIComponent(_0x25eb12)]=decodeURIComponent(_0x435f61);}}),_0x454811;}function Tt(_0x1f88cc){const _0x3301ce=_0x1f88cc['indexOf']('?');if(!_0x3301ce)return'';const _0x4c66a4=_0x1f88cc['indexOf']('#',_0x3301ce);return _0x1f88cc['substring'](_0x3301ce,_0x4c66a4>0x0?_0x4c66a4:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x48ebed=0x1;_0x48ebed<this['blockSize'];++_0x48ebed)this['pad_'][_0x48ebed]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1269be,_0x419984){_0x419984||(_0x419984=0x0);const _0x22a263=this['W_'];if(typeof _0x1269be=='string'){for(let _0x5e631e=0x0;_0x5e631e<0x10;_0x5e631e++)_0x22a263[_0x5e631e]=_0x1269be['charCodeAt'](_0x419984)<<0x18|_0x1269be['charCodeAt'](_0x419984+0x1)<<0x10|_0x1269be['charCodeAt'](_0x419984+0x2)<<0x8|_0x1269be['charCodeAt'](_0x419984+0x3),_0x419984+=0x4;}else{for(let _0x529016=0x0;_0x529016<0x10;_0x529016++)_0x22a263[_0x529016]=_0x1269be[_0x419984]<<0x18|_0x1269be[_0x419984+0x1]<<0x10|_0x1269be[_0x419984+0x2]<<0x8|_0x1269be[_0x419984+0x3],_0x419984+=0x4;}for(let _0x4e3656=0x10;_0x4e3656<0x50;_0x4e3656++){const _0x2d30be=_0x22a263[_0x4e3656-0x3]^_0x22a263[_0x4e3656-0x8]^_0x22a263[_0x4e3656-0xe]^_0x22a263[_0x4e3656-0x10];_0x22a263[_0x4e3656]=(_0x2d30be<<0x1|_0x2d30be>>>0x1f)&0xffffffff;}let _0x1ed936=this['chain_'][0x0],_0x360c4a=this['chain_'][0x1],_0x54946e=this['chain_'][0x2],_0x584cf9=this['chain_'][0x3],_0x44a61b=this['chain_'][0x4],_0x37f27f,_0x1d64ca;for(let _0x10af88=0x0;_0x10af88<0x50;_0x10af88++){_0x10af88<0x28?_0x10af88<0x14?(_0x37f27f=_0x584cf9^_0x360c4a&(_0x54946e^_0x584cf9),_0x1d64ca=0x5a827999):(_0x37f27f=_0x360c4a^_0x54946e^_0x584cf9,_0x1d64ca=0x6ed9eba1):_0x10af88<0x3c?(_0x37f27f=_0x360c4a&_0x54946e|_0x584cf9&(_0x360c4a|_0x54946e),_0x1d64ca=0x8f1bbcdc):(_0x37f27f=_0x360c4a^_0x54946e^_0x584cf9,_0x1d64ca=0xca62c1d6);const _0x10439d=(_0x1ed936<<0x5|_0x1ed936>>>0x1b)+_0x37f27f+_0x44a61b+_0x1d64ca+_0x22a263[_0x10af88]&0xffffffff;_0x44a61b=_0x584cf9,_0x584cf9=_0x54946e,_0x54946e=(_0x360c4a<<0x1e|_0x360c4a>>>0x2)&0xffffffff,_0x360c4a=_0x1ed936,_0x1ed936=_0x10439d;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1ed936&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x360c4a&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x54946e&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x584cf9&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x44a61b&0xffffffff;}['update'](_0x499701,_0x4aac4c){if(_0x499701==null)return;_0x4aac4c===void 0x0&&(_0x4aac4c=_0x499701['length']);const _0x188de4=_0x4aac4c-this['blockSize'];let _0x1b98bf=0x0;const _0xc5bf35=this['buf_'];let _0x24a767=this['inbuf_'];for(;_0x1b98bf<_0x4aac4c;){if(_0x24a767===0x0){for(;_0x1b98bf<=_0x188de4;)this['compress_'](_0x499701,_0x1b98bf),_0x1b98bf+=this['blockSize'];}if(typeof _0x499701=='string'){for(;_0x1b98bf<_0x4aac4c;)if(_0xc5bf35[_0x24a767]=_0x499701['charCodeAt'](_0x1b98bf),++_0x24a767,++_0x1b98bf,_0x24a767===this['blockSize']){this['compress_'](_0xc5bf35),_0x24a767=0x0;break;}}else{for(;_0x1b98bf<_0x4aac4c;)if(_0xc5bf35[_0x24a767]=_0x499701[_0x1b98bf],++_0x24a767,++_0x1b98bf,_0x24a767===this['blockSize']){this['compress_'](_0xc5bf35),_0x24a767=0x0;break;}}}this['inbuf_']=_0x24a767,this['total_']+=_0x4aac4c;}['digest'](){const _0x53ca3f=[];let _0x18d6bc=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x188918=this['blockSize']-0x1;_0x188918>=0x38;_0x188918--)this['buf_'][_0x188918]=_0x18d6bc&0xff,_0x18d6bc/=0x100;this['compress_'](this['buf_']);let _0x12bc20=0x0;for(let _0x4fb5e9=0x0;_0x4fb5e9<0x5;_0x4fb5e9++)for(let _0x21b37c=0x18;_0x21b37c>=0x0;_0x21b37c-=0x8)_0x53ca3f[_0x12bc20]=this['chain_'][_0x4fb5e9]>>_0x21b37c&0xff,++_0x12bc20;return _0x53ca3f;}}function Tc(_0x48baa0,_0x1ee22f){const _0x4b8b7f=new Sc(_0x48baa0,_0x1ee22f);return _0x4b8b7f['subscribe']['bind'](_0x4b8b7f);}class Sc{constructor(_0x24b9eb,_0x43d80d){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x43d80d,this['task']['then'](()=>{_0x24b9eb(this);})['catch'](_0x485d34=>{this['error'](_0x485d34);});}['next'](_0x43e5e9){this['forEachObserver'](_0x596635=>{_0x596635['next'](_0x43e5e9);});}['error'](_0x5562ec){this['forEachObserver'](_0x2a01f0=>{_0x2a01f0['error'](_0x5562ec);}),this['close'](_0x5562ec);}['complete'](){this['forEachObserver'](_0x4f6d37=>{_0x4f6d37['complete']();}),this['close']();}['subscribe'](_0x8c0bc4,_0x4b3648,_0x455a0d){let _0x23c583;if(_0x8c0bc4===void 0x0&&_0x4b3648===void 0x0&&_0x455a0d===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x8c0bc4,['next','error','complete'])?_0x23c583=_0x8c0bc4:_0x23c583={'next':_0x8c0bc4,'error':_0x4b3648,'complete':_0x455a0d},_0x23c583['next']===void 0x0&&(_0x23c583['next']=ti),_0x23c583['error']===void 0x0&&(_0x23c583['error']=ti),_0x23c583['complete']===void 0x0&&(_0x23c583['complete']=ti);const _0x5ba997=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x23c583['error'](this['finalError']):_0x23c583['complete']();}catch{}}),this['observers']['push'](_0x23c583),_0x5ba997;}['unsubscribeOne'](_0x4539fb){this['observers']===void 0x0||this['observers'][_0x4539fb]===void 0x0||(delete this['observers'][_0x4539fb],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x90e2de){if(!this['finalized']){for(let _0x4b0999=0x0;_0x4b0999<this['observers']['length'];_0x4b0999++)this['sendOne'](_0x4b0999,_0x90e2de);}}['sendOne'](_0x4e4989,_0x54426c){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4e4989]!==void 0x0)try{_0x54426c(this['observers'][_0x4e4989]);}catch(_0x145155){typeof console<'u'&&console['error']&&console['error'](_0x145155);}});}['close'](_0x1b1408){this['finalized']||(this['finalized']=!0x0,_0x1b1408!==void 0x0&&(this['finalError']=_0x1b1408),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x509b1b,_0x168a0e){if(typeof _0x509b1b!='object'||_0x509b1b===null)return!0x1;for(const _0x22e183 of _0x168a0e)if(_0x22e183 in _0x509b1b&&typeof _0x509b1b[_0x22e183]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x10e7da,_0x3d5a03){return _0x10e7da+'\x20failed:\x20'+_0x3d5a03+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x11cc68){const _0x4af91=[];let _0x413f2d=0x0;for(let _0x56a2a1=0x0;_0x56a2a1<_0x11cc68['length'];_0x56a2a1++){let _0x3bfa69=_0x11cc68['charCodeAt'](_0x56a2a1);if(_0x3bfa69>=0xd800&&_0x3bfa69<=0xdbff){const _0x1b11ca=_0x3bfa69-0xd800;_0x56a2a1++,f(_0x56a2a1<_0x11cc68['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1aaf26=_0x11cc68['charCodeAt'](_0x56a2a1)-0xdc00;_0x3bfa69=0x10000+(_0x1b11ca<<0xa)+_0x1aaf26;}_0x3bfa69<0x80?_0x4af91[_0x413f2d++]=_0x3bfa69:_0x3bfa69<0x800?(_0x4af91[_0x413f2d++]=_0x3bfa69>>0x6|0xc0,_0x4af91[_0x413f2d++]=_0x3bfa69&0x3f|0x80):_0x3bfa69<0x10000?(_0x4af91[_0x413f2d++]=_0x3bfa69>>0xc|0xe0,_0x4af91[_0x413f2d++]=_0x3bfa69>>0x6&0x3f|0x80,_0x4af91[_0x413f2d++]=_0x3bfa69&0x3f|0x80):(_0x4af91[_0x413f2d++]=_0x3bfa69>>0x12|0xf0,_0x4af91[_0x413f2d++]=_0x3bfa69>>0xc&0x3f|0x80,_0x4af91[_0x413f2d++]=_0x3bfa69>>0x6&0x3f|0x80,_0x4af91[_0x413f2d++]=_0x3bfa69&0x3f|0x80);}return _0x4af91;},Ln=function(_0x5bef91){let _0x1a5580=0x0;for(let _0x603ec1=0x0;_0x603ec1<_0x5bef91['length'];_0x603ec1++){const _0x6652f3=_0x5bef91['charCodeAt'](_0x603ec1);_0x6652f3<0x80?_0x1a5580++:_0x6652f3<0x800?_0x1a5580+=0x2:_0x6652f3>=0xd800&&_0x6652f3<=0xdbff?(_0x1a5580+=0x4,_0x603ec1++):_0x1a5580+=0x3;}return _0x1a5580;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x58acd2){return _0x58acd2&&_0x58acd2['_delegate']?_0x58acd2['_delegate']:_0x58acd2;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x121b9a){try{return(_0x121b9a['startsWith']('http://')||_0x121b9a['startsWith']('https://')?new URL(_0x121b9a)['hostname']:_0x121b9a)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x332421){return(await fetch(_0x332421,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x4cd51b,_0x594f58,_0x18cc68){this['name']=_0x4cd51b,this['instanceFactory']=_0x594f58,this['type']=_0x18cc68,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x453405){return this['instantiationMode']=_0x453405,this;}['setMultipleInstances'](_0x171542){return this['multipleInstances']=_0x171542,this;}['setServiceProps'](_0x95c846){return this['serviceProps']=_0x95c846,this;}['setInstanceCreatedCallback'](_0x16f8d7){return this['onInstanceCreated']=_0x16f8d7,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x80b8d0,_0x407195){this['name']=_0x80b8d0,this['container']=_0x407195,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x516c58){const _0x8038de=this['normalizeInstanceIdentifier'](_0x516c58);if(!this['instancesDeferred']['has'](_0x8038de)){const _0x7b7ff9=new H();if(this['instancesDeferred']['set'](_0x8038de,_0x7b7ff9),this['isInitialized'](_0x8038de)||this['shouldAutoInitialize']())try{const _0x864a70=this['getOrInitializeService']({'instanceIdentifier':_0x8038de});_0x864a70&&_0x7b7ff9['resolve'](_0x864a70);}catch{}}return this['instancesDeferred']['get'](_0x8038de)['promise'];}['getImmediate'](_0x3e8071){const _0x1f81ef=this['normalizeInstanceIdentifier'](_0x3e8071==null?void 0x0:_0x3e8071['identifier']),_0x2b241f=(_0x3e8071==null?void 0x0:_0x3e8071['optional'])??!0x1;if(this['isInitialized'](_0x1f81ef)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1f81ef});}catch(_0xb74df8){if(_0x2b241f)return null;throw _0xb74df8;}else{if(_0x2b241f)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1d3fbc){if(_0x1d3fbc['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1d3fbc['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1d3fbc,!!this['shouldAutoInitialize']()){if(Pc(_0x1d3fbc))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x1dc258,_0x18f157]of this['instancesDeferred']['entries']()){const _0x66552b=this['normalizeInstanceIdentifier'](_0x1dc258);try{const _0x29c2be=this['getOrInitializeService']({'instanceIdentifier':_0x66552b});_0x18f157['resolve'](_0x29c2be);}catch{}}}}['clearInstance'](_0x4e6a06=Ne){this['instancesDeferred']['delete'](_0x4e6a06),this['instancesOptions']['delete'](_0x4e6a06),this['instances']['delete'](_0x4e6a06);}async['delete'](){const _0x12fcaf=Array['from'](this['instances']['values']());await Promise['all']([..._0x12fcaf['filter'](_0x26714e=>'INTERNAL'in _0x26714e)['map'](_0x1c7d68=>_0x1c7d68['INTERNAL']['delete']()),..._0x12fcaf['filter'](_0x7ada34=>'_delete'in _0x7ada34)['map'](_0x5040cb=>_0x5040cb['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x13e3f8=Ne){return this['instances']['has'](_0x13e3f8);}['getOptions'](_0x1c3964=Ne){return this['instancesOptions']['get'](_0x1c3964)||{};}['initialize'](_0x20a4e3={}){const {options:_0x359109={}}=_0x20a4e3,_0x2b33d4=this['normalizeInstanceIdentifier'](_0x20a4e3['instanceIdentifier']);if(this['isInitialized'](_0x2b33d4))throw Error(this['name']+'('+_0x2b33d4+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x17cf68=this['getOrInitializeService']({'instanceIdentifier':_0x2b33d4,'options':_0x359109});for(const [_0xc97ec0,_0x3b40c5]of this['instancesDeferred']['entries']()){const _0x1c5715=this['normalizeInstanceIdentifier'](_0xc97ec0);_0x2b33d4===_0x1c5715&&_0x3b40c5['resolve'](_0x17cf68);}return _0x17cf68;}['onInit'](_0x55771f,_0xfc257a){const _0x6a64ee=this['normalizeInstanceIdentifier'](_0xfc257a),_0x1cfb48=this['onInitCallbacks']['get'](_0x6a64ee)??new Set();_0x1cfb48['add'](_0x55771f),this['onInitCallbacks']['set'](_0x6a64ee,_0x1cfb48);const _0x2c4c22=this['instances']['get'](_0x6a64ee);return _0x2c4c22&&_0x55771f(_0x2c4c22,_0x6a64ee),()=>{_0x1cfb48['delete'](_0x55771f);};}['invokeOnInitCallbacks'](_0x25fa1e,_0x2f9cdc){const _0x1b6d1a=this['onInitCallbacks']['get'](_0x2f9cdc);if(_0x1b6d1a){for(const _0x4b39a7 of _0x1b6d1a)try{_0x4b39a7(_0x25fa1e,_0x2f9cdc);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1fb544,options:_0x5adb66={}}){let _0x367819=this['instances']['get'](_0x1fb544);if(!_0x367819&&this['component']&&(_0x367819=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x1fb544),'options':_0x5adb66}),this['instances']['set'](_0x1fb544,_0x367819),this['instancesOptions']['set'](_0x1fb544,_0x5adb66),this['invokeOnInitCallbacks'](_0x367819,_0x1fb544),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1fb544,_0x367819);}catch{}return _0x367819||null;}['normalizeInstanceIdentifier'](_0x518084=Ne){return this['component']?this['component']['multipleInstances']?_0x518084:Ne:_0x518084;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x131dc0){return _0x131dc0===Ne?void 0x0:_0x131dc0;}function Pc(_0x1398dc){return _0x1398dc['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x3d5b73){this['name']=_0x3d5b73,this['providers']=new Map();}['addComponent'](_0x3e8567){const _0x3ce3c5=this['getProvider'](_0x3e8567['name']);if(_0x3ce3c5['isComponentSet']())throw new Error('Component\x20'+_0x3e8567['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3ce3c5['setComponent'](_0x3e8567);}['addOrOverwriteComponent'](_0x194281){this['getProvider'](_0x194281['name'])['isComponentSet']()&&this['providers']['delete'](_0x194281['name']),this['addComponent'](_0x194281);}['getProvider'](_0x4f6701){if(this['providers']['has'](_0x4f6701))return this['providers']['get'](_0x4f6701);const _0x1db4d0=new Ac(_0x4f6701,this);return this['providers']['set'](_0x4f6701,_0x1db4d0),_0x1db4d0;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x348507){_0x348507[_0x348507['DEBUG']=0x0]='DEBUG',_0x348507[_0x348507['VERBOSE']=0x1]='VERBOSE',_0x348507[_0x348507['INFO']=0x2]='INFO',_0x348507[_0x348507['WARN']=0x3]='WARN',_0x348507[_0x348507['ERROR']=0x4]='ERROR',_0x348507[_0x348507['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x5721cf,_0xdff78e,..._0x584b9c)=>{if(_0xdff78e<_0x5721cf['logLevel'])return;const _0x41da25=new Date()['toISOString'](),_0x4fd520=Mc[_0xdff78e];if(_0x4fd520)console[_0x4fd520]('['+_0x41da25+']\x20\x20'+_0x5721cf['name']+':',..._0x584b9c);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0xdff78e+')');};class Bi{constructor(_0x31c7ef){this['name']=_0x31c7ef,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x7e46e5){if(!(_0x7e46e5 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x7e46e5+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x7e46e5;}['setLogLevel'](_0x47d1e9){this['_logLevel']=typeof _0x47d1e9=='string'?Oc[_0x47d1e9]:_0x47d1e9;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4dc607){if(typeof _0x4dc607!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4dc607;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x3e0463){this['_userLogHandler']=_0x3e0463;}['debug'](..._0x231d82){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x231d82),this['_logHandler'](this,T['DEBUG'],..._0x231d82);}['log'](..._0x1fecee){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1fecee),this['_logHandler'](this,T['VERBOSE'],..._0x1fecee);}['info'](..._0x451c02){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x451c02),this['_logHandler'](this,T['INFO'],..._0x451c02);}['warn'](..._0x120f97){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x120f97),this['_logHandler'](this,T['WARN'],..._0x120f97);}['error'](..._0x341cd1){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x341cd1),this['_logHandler'](this,T['ERROR'],..._0x341cd1);}}const xc=(_0x2e6aeb,_0x170285)=>_0x170285['some'](_0x263162=>_0x2e6aeb instanceof _0x263162);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x1cf40a){const _0x17b51a=new Promise((_0x2ae8d3,_0x34bae9)=>{const _0x522f70=()=>{_0x1cf40a['removeEventListener']('success',_0x1242a3),_0x1cf40a['removeEventListener']('error',_0x1b8f72);},_0x1242a3=()=>{_0x2ae8d3(ge(_0x1cf40a['result'])),_0x522f70();},_0x1b8f72=()=>{_0x34bae9(_0x1cf40a['error']),_0x522f70();};_0x1cf40a['addEventListener']('success',_0x1242a3),_0x1cf40a['addEventListener']('error',_0x1b8f72);});return _0x17b51a['then'](_0x1a5838=>{_0x1a5838 instanceof IDBCursor&&Jr['set'](_0x1a5838,_0x1cf40a);})['catch'](()=>{}),Vi['set'](_0x17b51a,_0x1cf40a),_0x17b51a;}function Bc(_0x36b206){if(_i['has'](_0x36b206))return;const _0x1b4ddc=new Promise((_0x3f54f5,_0x7c1fcc)=>{const _0x12399a=()=>{_0x36b206['removeEventListener']('complete',_0x3487d8),_0x36b206['removeEventListener']('error',_0x4232ae),_0x36b206['removeEventListener']('abort',_0x4232ae);},_0x3487d8=()=>{_0x3f54f5(),_0x12399a();},_0x4232ae=()=>{_0x7c1fcc(_0x36b206['error']||new DOMException('AbortError','AbortError')),_0x12399a();};_0x36b206['addEventListener']('complete',_0x3487d8),_0x36b206['addEventListener']('error',_0x4232ae),_0x36b206['addEventListener']('abort',_0x4232ae);});_i['set'](_0x36b206,_0x1b4ddc);}let gi={'get'(_0x5c70c4,_0x2bf31f,_0x366e5b){if(_0x5c70c4 instanceof IDBTransaction){if(_0x2bf31f==='done')return _i['get'](_0x5c70c4);if(_0x2bf31f==='objectStoreNames')return _0x5c70c4['objectStoreNames']||Xr['get'](_0x5c70c4);if(_0x2bf31f==='store')return _0x366e5b['objectStoreNames'][0x1]?void 0x0:_0x366e5b['objectStore'](_0x366e5b['objectStoreNames'][0x0]);}return ge(_0x5c70c4[_0x2bf31f]);},'set'(_0x2f87c0,_0x3c863b,_0x2c0d04){return _0x2f87c0[_0x3c863b]=_0x2c0d04,!0x0;},'has'(_0x3f0591,_0x1796bd){return _0x3f0591 instanceof IDBTransaction&&(_0x1796bd==='done'||_0x1796bd==='store')?!0x0:_0x1796bd in _0x3f0591;}};function Vc(_0x4651fd){gi=_0x4651fd(gi);}function Hc(_0x107aa5){return _0x107aa5===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x880127,..._0x166cc5){const _0x4db17f=_0x107aa5['call'](ii(this),_0x880127,..._0x166cc5);return Xr['set'](_0x4db17f,_0x880127['sort']?_0x880127['sort']():[_0x880127]),ge(_0x4db17f);}:Uc()['includes'](_0x107aa5)?function(..._0x2d8721){return _0x107aa5['apply'](ii(this),_0x2d8721),ge(Jr['get'](this));}:function(..._0x566424){return ge(_0x107aa5['apply'](ii(this),_0x566424));};}function $c(_0x2f38bd){return typeof _0x2f38bd=='function'?Hc(_0x2f38bd):(_0x2f38bd instanceof IDBTransaction&&Bc(_0x2f38bd),xc(_0x2f38bd,Fc())?new Proxy(_0x2f38bd,gi):_0x2f38bd);}function ge(_0x53104f){if(_0x53104f instanceof IDBRequest)return Wc(_0x53104f);if(ni['has'](_0x53104f))return ni['get'](_0x53104f);const _0x31b40d=$c(_0x53104f);return _0x31b40d!==_0x53104f&&(ni['set'](_0x53104f,_0x31b40d),Vi['set'](_0x31b40d,_0x53104f)),_0x31b40d;}const ii=_0x3b16af=>Vi['get'](_0x3b16af);function Gc(_0x52ae63,_0x15bc17,{blocked:_0x151633,upgrade:_0x3a29da,blocking:_0x331d31,terminated:_0x392bfe}={}){const _0x1eadc0=indexedDB['open'](_0x52ae63,_0x15bc17),_0x5a1c7b=ge(_0x1eadc0);return _0x3a29da&&_0x1eadc0['addEventListener']('upgradeneeded',_0x2ec965=>{_0x3a29da(ge(_0x1eadc0['result']),_0x2ec965['oldVersion'],_0x2ec965['newVersion'],ge(_0x1eadc0['transaction']),_0x2ec965);}),_0x151633&&_0x1eadc0['addEventListener']('blocked',_0x2c838e=>_0x151633(_0x2c838e['oldVersion'],_0x2c838e['newVersion'],_0x2c838e)),_0x5a1c7b['then'](_0x425f14=>{_0x392bfe&&_0x425f14['addEventListener']('close',()=>_0x392bfe()),_0x331d31&&_0x425f14['addEventListener']('versionchange',_0xdcd347=>_0x331d31(_0xdcd347['oldVersion'],_0xdcd347['newVersion'],_0xdcd347));})['catch'](()=>{}),_0x5a1c7b;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x49e58e,_0x1a28d1){if(!(_0x49e58e instanceof IDBDatabase&&!(_0x1a28d1 in _0x49e58e)&&typeof _0x1a28d1=='string'))return;if(si['get'](_0x1a28d1))return si['get'](_0x1a28d1);const _0x593fba=_0x1a28d1['replace'](/FromIndex$/,''),_0x7f1919=_0x1a28d1!==_0x593fba,_0x5d0fee=zc['includes'](_0x593fba);if(!(_0x593fba in(_0x7f1919?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5d0fee||qc['includes'](_0x593fba)))return;const _0xe7f924=async function(_0xf613d6,..._0x489788){const _0x162a1e=this['transaction'](_0xf613d6,_0x5d0fee?'readwrite':'readonly');let _0x5181c7=_0x162a1e['store'];return _0x7f1919&&(_0x5181c7=_0x5181c7['index'](_0x489788['shift']())),(await Promise['all']([_0x5181c7[_0x593fba](..._0x489788),_0x5d0fee&&_0x162a1e['done']]))[0x0];};return si['set'](_0x1a28d1,_0xe7f924),_0xe7f924;}Vc(_0x106f03=>({..._0x106f03,'get':(_0x2bd31b,_0x440363,_0x29f899)=>Ms(_0x2bd31b,_0x440363)||_0x106f03['get'](_0x2bd31b,_0x440363,_0x29f899),'has':(_0x45c98d,_0x4fe61a)=>!!Ms(_0x45c98d,_0x4fe61a)||_0x106f03['has'](_0x45c98d,_0x4fe61a)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x21c691){this['container']=_0x21c691;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x15e76a=>{if(Kc(_0x15e76a)){const _0x1d52b9=_0x15e76a['getImmediate']();return _0x1d52b9['library']+'/'+_0x1d52b9['version'];}else return null;})['filter'](_0x1925ce=>_0x1925ce)['join']('\x20');}}function Kc(_0x2d6b4e){const _0x2c3e1f=_0x2d6b4e['getComponent']();return(_0x2c3e1f==null?void 0x0:_0x2c3e1f['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x3425b5,_0x399d9a){try{_0x3425b5['container']['addComponent'](_0x399d9a);}catch(_0x5cf595){oe['debug']('Component\x20'+_0x399d9a['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3425b5['name'],_0x5cf595);}}function st(_0x3ba2ef){const _0x4d0e6f=_0x3ba2ef['name'];if(Ei['has'](_0x4d0e6f))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4d0e6f+'.'),!0x1;Ei['set'](_0x4d0e6f,_0x3ba2ef);for(const _0x25b93d of Ue['values']())xs(_0x25b93d,_0x3ba2ef);for(const _0x31d171 of vi['values']())xs(_0x31d171,_0x3ba2ef);return!0x0;}function Hi(_0x2fd8a0,_0x364270){const _0x584a04=_0x2fd8a0['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x584a04&&_0x584a04['triggerHeartbeat'](),_0x2fd8a0['container']['getProvider'](_0x364270);}function $(_0x4a4310){return _0x4a4310==null?!0x1:_0x4a4310['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x4b2500,_0x25655d,_0x48a88c){this['_isDeleted']=!0x1,this['_options']={..._0x4b2500},this['_config']={..._0x25655d},this['_name']=_0x25655d['name'],this['_automaticDataCollectionEnabled']=_0x25655d['automaticDataCollectionEnabled'],this['_container']=_0x48a88c,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3caf44){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3caf44;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5b3fc0){this['_isDeleted']=_0x5b3fc0;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x46e02d,_0x15cf5e={}){let _0x18e637=_0x46e02d;typeof _0x15cf5e!='object'&&(_0x15cf5e={'name':_0x15cf5e});const _0x117c6d={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x15cf5e},_0x3aa563=_0x117c6d['name'];if(typeof _0x3aa563!='string'||!_0x3aa563)throw me['create']('bad-app-name',{'appName':String(_0x3aa563)});if(_0x18e637||(_0x18e637=zr()),!_0x18e637)throw me['create']('no-options');const _0x4a4de9=Ue['get'](_0x3aa563);if(_0x4a4de9){if(xe(_0x18e637,_0x4a4de9['options'])&&xe(_0x117c6d,_0x4a4de9['config']))return _0x4a4de9;throw me['create']('duplicate-app',{'appName':_0x3aa563});}const _0x42f0a2=new Nc(_0x3aa563);for(const _0x2ea1f9 of Ei['values']())_0x42f0a2['addComponent'](_0x2ea1f9);const _0x4a69b2=new Tl(_0x18e637,_0x117c6d,_0x42f0a2);return Ue['set'](_0x3aa563,_0x4a69b2),_0x4a69b2;}function Zr(_0x2f9dea=yi){const _0x331fd7=Ue['get'](_0x2f9dea);if(!_0x331fd7&&_0x2f9dea===yi&&zr())return Sl();if(!_0x331fd7)throw me['create']('no-app',{'appName':_0x2f9dea});return _0x331fd7;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x4b3e1b){let _0x193dec=!0x1;const _0x13df38=_0x4b3e1b['name'];Ue['has'](_0x13df38)?(_0x193dec=!0x0,Ue['delete'](_0x13df38)):vi['has'](_0x13df38)&&_0x4b3e1b['decRefCount']()<=0x0&&(vi['delete'](_0x13df38),_0x193dec=!0x0),_0x193dec&&(await Promise['all'](_0x4b3e1b['container']['getProviders']()['map'](_0x2b2307=>_0x2b2307['delete']())),_0x4b3e1b['isDeleted']=!0x0);}function ye(_0x34c916,_0x4fdee8,_0x206916){let _0x21f04f=wl[_0x34c916]??_0x34c916;_0x206916&&(_0x21f04f+='-'+_0x206916);const _0x457b8c=_0x21f04f['match'](/\s|\//),_0x538fe8=_0x4fdee8['match'](/\s|\//);if(_0x457b8c||_0x538fe8){const _0x3a0a81=['Unable\x20to\x20register\x20library\x20\x22'+_0x21f04f+'\x22\x20with\x20version\x20\x22'+_0x4fdee8+'\x22:'];_0x457b8c&&_0x3a0a81['push']('library\x20name\x20\x22'+_0x21f04f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x457b8c&&_0x538fe8&&_0x3a0a81['push']('and'),_0x538fe8&&_0x3a0a81['push']('version\x20name\x20\x22'+_0x4fdee8+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x3a0a81['join']('\x20'));return;}st(new Fe(_0x21f04f+'-version',()=>({'library':_0x21f04f,'version':_0x4fdee8}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x1aecbd,_0x4771db)=>{switch(_0x4771db){case 0x0:try{_0x1aecbd['createObjectStore'](Ot);}catch(_0x11dc97){console['warn'](_0x11dc97);}}}})['catch'](_0xb7dce=>{throw me['create']('idb-open',{'originalErrorMessage':_0xb7dce['message']});})),ri;}async function Al(_0x4a2672){try{const _0x19f09d=(await eo())['transaction'](Ot),_0x36c76e=await _0x19f09d['objectStore'](Ot)['get'](to(_0x4a2672));return await _0x19f09d['done'],_0x36c76e;}catch(_0x51bff9){if(_0x51bff9 instanceof Re)oe['warn'](_0x51bff9['message']);else{const _0x1f408b=me['create']('idb-get',{'originalErrorMessage':_0x51bff9==null?void 0x0:_0x51bff9['message']});oe['warn'](_0x1f408b['message']);}}}async function Fs(_0x376378,_0x61f45b){try{const _0x494d03=(await eo())['transaction'](Ot,'readwrite');await _0x494d03['objectStore'](Ot)['put'](_0x61f45b,to(_0x376378)),await _0x494d03['done'];}catch(_0x103cfd){if(_0x103cfd instanceof Re)oe['warn'](_0x103cfd['message']);else{const _0x370dc7=me['create']('idb-set',{'originalErrorMessage':_0x103cfd==null?void 0x0:_0x103cfd['message']});oe['warn'](_0x370dc7['message']);}}}function to(_0x6c675c){return _0x6c675c['name']+'!'+_0x6c675c['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x2ccacf){this['container']=_0x2ccacf,this['_heartbeatsCache']=null;const _0x5a3c00=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x5a3c00),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2acffd=>(this['_heartbeatsCache']=_0x2acffd,_0x2acffd));}async['triggerHeartbeat'](){var _0x1e139d,_0x4ad2ad;try{const _0x2c8f6b=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3d2895=Us();if(((_0x1e139d=this['_heartbeatsCache'])==null?void 0x0:_0x1e139d['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4ad2ad=this['_heartbeatsCache'])==null?void 0x0:_0x4ad2ad['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3d2895||this['_heartbeatsCache']['heartbeats']['some'](_0x208590=>_0x208590['date']===_0x3d2895))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3d2895,'agent':_0x2c8f6b}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x438a91=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x438a91,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x145b82){oe['warn'](_0x145b82);}}async['getHeartbeatsHeader'](){var _0x1cf60f;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1cf60f=this['_heartbeatsCache'])==null?void 0x0:_0x1cf60f['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x2736d2=Us(),{heartbeatsToSend:_0x495103,unsentEntries:_0x214250}=Ol(this['_heartbeatsCache']['heartbeats']),_0x4938eb=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x495103}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x2736d2,_0x214250['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x214250,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4938eb;}catch(_0x483efc){return oe['warn'](_0x483efc),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x383af4,_0x325c8d=kl){const _0x266a7e=[];let _0x2f7b23=_0x383af4['slice']();for(const _0x8aabb of _0x383af4){const _0x49c666=_0x266a7e['find'](_0x4ae5e0=>_0x4ae5e0['agent']===_0x8aabb['agent']);if(_0x49c666){if(_0x49c666['dates']['push'](_0x8aabb['date']),Ws(_0x266a7e)>_0x325c8d){_0x49c666['dates']['pop']();break;}}else{if(_0x266a7e['push']({'agent':_0x8aabb['agent'],'dates':[_0x8aabb['date']]}),Ws(_0x266a7e)>_0x325c8d){_0x266a7e['pop']();break;}}_0x2f7b23=_0x2f7b23['slice'](0x1);}return{'heartbeatsToSend':_0x266a7e,'unsentEntries':_0x2f7b23};}class Dl{constructor(_0x47f204){this['app']=_0x47f204,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x545e72=await Al(this['app']);return _0x545e72!=null&&_0x545e72['heartbeats']?_0x545e72:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5e75b3){if(await this['_canUseIndexedDBPromise']){const _0x3822f0=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5e75b3['lastSentHeartbeatDate']??_0x3822f0['lastSentHeartbeatDate'],'heartbeats':_0x5e75b3['heartbeats']});}else return;}async['add'](_0x3b55ed){if(await this['_canUseIndexedDBPromise']){const _0x2eb1c7=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x3b55ed['lastSentHeartbeatDate']??_0x2eb1c7['lastSentHeartbeatDate'],'heartbeats':[..._0x2eb1c7['heartbeats'],..._0x3b55ed['heartbeats']]});}else return;}}function Ws(_0x2503e1){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2503e1}))['length'];}function Ml(_0x1f3d9e){if(_0x1f3d9e['length']===0x0)return-0x1;let _0x3eeccd=0x0,_0x429767=_0x1f3d9e[0x0]['date'];for(let _0x4cc978=0x1;_0x4cc978<_0x1f3d9e['length'];_0x4cc978++)_0x1f3d9e[_0x4cc978]['date']<_0x429767&&(_0x429767=_0x1f3d9e[_0x4cc978]['date'],_0x3eeccd=_0x4cc978);return _0x3eeccd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x2c0f0b){st(new Fe('platform-logger',_0x555934=>new jc(_0x555934),'PRIVATE')),st(new Fe('heartbeat',_0x44cbca=>new Nl(_0x44cbca),'PRIVATE')),ye(mi,Ls,_0x2c0f0b),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x35e749){no=_0x35e749;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x477e93){this['domStorage_']=_0x477e93,this['prefix_']='firebase:';}['set'](_0x3e1376,_0x250cab){_0x250cab==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3e1376)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3e1376),O(_0x250cab));}['get'](_0x447bfb){const _0xa666b1=this['domStorage_']['getItem'](this['prefixedName_'](_0x447bfb));return _0xa666b1==null?null:Nt(_0xa666b1);}['remove'](_0x6fe33b){this['domStorage_']['removeItem'](this['prefixedName_'](_0x6fe33b));}['prefixedName_'](_0x3c4fe4){return this['prefix_']+_0x3c4fe4;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x35ae8a,_0x5d3eb3){_0x5d3eb3==null?delete this['cache_'][_0x35ae8a]:this['cache_'][_0x35ae8a]=_0x5d3eb3;}['get'](_0x29ecd6){return Q(this['cache_'],_0x29ecd6)?this['cache_'][_0x29ecd6]:null;}['remove'](_0x3b1098){delete this['cache_'][_0x3b1098];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x18e106){try{if(typeof window<'u'&&typeof window[_0x18e106]<'u'){const _0x56b0fd=window[_0x18e106];return _0x56b0fd['setItem']('firebase:sentinel','cache'),_0x56b0fd['removeItem']('firebase:sentinel'),new Wl(_0x56b0fd);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x2d7f16=0x1;return function(){return _0x2d7f16++;};}()),ro=function(_0x371454){const _0x333d7b=Rc(_0x371454),_0x185efe=new Cc();_0x185efe['update'](_0x333d7b);const _0x569611=_0x185efe['digest']();return Fi['encodeByteArray'](_0x569611);},zt=function(..._0x2a38c5){let _0x43a107='';for(let _0x3fc5bc=0x0;_0x3fc5bc<_0x2a38c5['length'];_0x3fc5bc++){const _0x4f3758=_0x2a38c5[_0x3fc5bc];Array['isArray'](_0x4f3758)||_0x4f3758&&typeof _0x4f3758=='object'&&typeof _0x4f3758['length']=='number'?_0x43a107+=zt['apply'](null,_0x4f3758):typeof _0x4f3758=='object'?_0x43a107+=O(_0x4f3758):_0x43a107+=_0x4f3758,_0x43a107+='\x20';}return _0x43a107;};let St=null,$s=!0x0;const Hl=function(_0x39a252,_0x176024){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0xf20370){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x16b9a7=zt['apply'](null,_0xf20370);St(_0x16b9a7);}},jt=function(_0x497ed0){return function(..._0x1d60f3){L(_0x497ed0,..._0x1d60f3);};},Ii=function(..._0x573372){const _0x49c6b7='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x573372);Ze['error'](_0x49c6b7);},ae=function(..._0x1fdee4){const _0x782ab8='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x1fdee4);throw Ze['error'](_0x782ab8),new Error(_0x782ab8);},U=function(..._0x2e5c5b){const _0x146219='FIREBASE\x20WARNING:\x20'+zt(..._0x2e5c5b);Ze['warn'](_0x146219);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x5e9c56){return typeof _0x5e9c56=='number'&&(_0x5e9c56!==_0x5e9c56||_0x5e9c56===Number['POSITIVE_INFINITY']||_0x5e9c56===Number['NEGATIVE_INFINITY']);},Gl=function(_0x468fd0){if(document['readyState']==='complete')_0x468fd0();else{let _0x5e4615=!0x1;const _0x294211=function(){if(!document['body']){setTimeout(_0x294211,Math['floor'](0xa));return;}_0x5e4615||(_0x5e4615=!0x0,_0x468fd0());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x294211,!0x1),window['addEventListener']('load',_0x294211,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x294211();}),window['attachEvent']('onload',_0x294211));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x451aee,_0x4c44d8){if(_0x451aee===_0x4c44d8)return 0x0;if(_0x451aee===We||_0x4c44d8===we)return-0x1;if(_0x4c44d8===We||_0x451aee===we)return 0x1;{const _0x3c8ca5=Gs(_0x451aee),_0x1da5a9=Gs(_0x4c44d8);return _0x3c8ca5!==null?_0x1da5a9!==null?_0x3c8ca5-_0x1da5a9===0x0?_0x451aee['length']-_0x4c44d8['length']:_0x3c8ca5-_0x1da5a9:-0x1:_0x1da5a9!==null?0x1:_0x451aee<_0x4c44d8?-0x1:0x1;}},ql=function(_0x539e75,_0x437f66){return _0x539e75===_0x437f66?0x0:_0x539e75<_0x437f66?-0x1:0x1;},vt=function(_0x272002,_0x280e65){if(_0x280e65&&_0x272002 in _0x280e65)return _0x280e65[_0x272002];throw new Error('Missing\x20required\x20key\x20('+_0x272002+')\x20in\x20object:\x20'+O(_0x280e65));},$i=function(_0x835920){if(typeof _0x835920!='object'||_0x835920===null)return O(_0x835920);const _0x502383=[];for(const _0x23baeb in _0x835920)_0x502383['push'](_0x23baeb);_0x502383['sort']();let _0x316bc7='{';for(let _0x2203fd=0x0;_0x2203fd<_0x502383['length'];_0x2203fd++)_0x2203fd!==0x0&&(_0x316bc7+=','),_0x316bc7+=O(_0x502383[_0x2203fd]),_0x316bc7+=':',_0x316bc7+=$i(_0x835920[_0x502383[_0x2203fd]]);return _0x316bc7+='}',_0x316bc7;},oo=function(_0x20b2bb,_0x4cd955){const _0x24c667=_0x20b2bb['length'];if(_0x24c667<=_0x4cd955)return[_0x20b2bb];const _0x303ade=[];for(let _0x2c40b0=0x0;_0x2c40b0<_0x24c667;_0x2c40b0+=_0x4cd955)_0x2c40b0+_0x4cd955>_0x24c667?_0x303ade['push'](_0x20b2bb['substring'](_0x2c40b0,_0x24c667)):_0x303ade['push'](_0x20b2bb['substring'](_0x2c40b0,_0x2c40b0+_0x4cd955));return _0x303ade;};function x(_0x508729,_0x59a36d){for(const _0x617607 in _0x508729)_0x508729['hasOwnProperty'](_0x617607)&&_0x59a36d(_0x617607,_0x508729[_0x617607]);}const ao=function(_0x5f2f73){f(!xn(_0x5f2f73),'Invalid\x20JSON\x20number');const _0x53a803=0xb,_0x349285=0x34,_0x14c9fa=(0x1<<_0x53a803-0x1)-0x1;let _0x17655d,_0x270f8e,_0x571ccf,_0x1ccbe4,_0x43f1a8;_0x5f2f73===0x0?(_0x270f8e=0x0,_0x571ccf=0x0,_0x17655d=0x1/_0x5f2f73===-0x1/0x0?0x1:0x0):(_0x17655d=_0x5f2f73<0x0,_0x5f2f73=Math['abs'](_0x5f2f73),_0x5f2f73>=Math['pow'](0x2,0x1-_0x14c9fa)?(_0x1ccbe4=Math['min'](Math['floor'](Math['log'](_0x5f2f73)/Math['LN2']),_0x14c9fa),_0x270f8e=_0x1ccbe4+_0x14c9fa,_0x571ccf=Math['round'](_0x5f2f73*Math['pow'](0x2,_0x349285-_0x1ccbe4)-Math['pow'](0x2,_0x349285))):(_0x270f8e=0x0,_0x571ccf=Math['round'](_0x5f2f73/Math['pow'](0x2,0x1-_0x14c9fa-_0x349285))));const _0x5bbbb4=[];for(_0x43f1a8=_0x349285;_0x43f1a8;_0x43f1a8-=0x1)_0x5bbbb4['push'](_0x571ccf%0x2?0x1:0x0),_0x571ccf=Math['floor'](_0x571ccf/0x2);for(_0x43f1a8=_0x53a803;_0x43f1a8;_0x43f1a8-=0x1)_0x5bbbb4['push'](_0x270f8e%0x2?0x1:0x0),_0x270f8e=Math['floor'](_0x270f8e/0x2);_0x5bbbb4['push'](_0x17655d?0x1:0x0),_0x5bbbb4['reverse']();const _0x5babc5=_0x5bbbb4['join']('');let _0x5c1f37='';for(_0x43f1a8=0x0;_0x43f1a8<0x40;_0x43f1a8+=0x8){let _0x12adbc=parseInt(_0x5babc5['substr'](_0x43f1a8,0x8),0x2)['toString'](0x10);_0x12adbc['length']===0x1&&(_0x12adbc='0'+_0x12adbc),_0x5c1f37=_0x5c1f37+_0x12adbc;}return _0x5c1f37['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x3c7594,_0x3fd828){let _0x260fa5='Unknown\x20Error';_0x3c7594==='too_big'?_0x260fa5='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x3c7594==='permission_denied'?_0x260fa5='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x3c7594==='unavailable'&&(_0x260fa5='The\x20service\x20is\x20unavailable');const _0x3ff7bd=new Error(_0x3c7594+'\x20at\x20'+_0x3fd828['_path']['toString']()+':\x20'+_0x260fa5);return _0x3ff7bd['code']=_0x3c7594['toUpperCase'](),_0x3ff7bd;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x39610e){if(Yl['test'](_0x39610e)){const _0x329b11=Number(_0x39610e);if(_0x329b11>=Ql&&_0x329b11<=Jl)return _0x329b11;}return null;},ft=function(_0x2b254b){try{_0x2b254b();}catch(_0x1cb540){setTimeout(()=>{const _0x5c5507=_0x1cb540['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5c5507),_0x1cb540;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x47a249,_0x2c6e49){const _0x5173f1=setTimeout(_0x47a249,_0x2c6e49);return typeof _0x5173f1=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x5173f1):typeof _0x5173f1=='object'&&_0x5173f1['unref']&&_0x5173f1['unref'](),_0x5173f1;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x34e84b,_0x2cb2de){this['appCheckProvider']=_0x2cb2de,this['appName']=_0x34e84b['name'],$(_0x34e84b)&&_0x34e84b['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x34e84b['settings']['appCheckToken']),this['appCheck']=_0x2cb2de==null?void 0x0:_0x2cb2de['getImmediate']({'optional':!0x0}),this['appCheck']||_0x2cb2de==null||_0x2cb2de['get']()['then'](_0x6ecbe9=>this['appCheck']=_0x6ecbe9);}['getToken'](_0x2e315f){if(this['serverAppAppCheckToken']){if(_0x2e315f)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2e315f):new Promise((_0x507212,_0xe6c8f)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2e315f)['then'](_0x507212,_0xe6c8f):_0x507212(null);},0x0);});}['addTokenChangeListener'](_0x6dea0b){var _0x2aa399;(_0x2aa399=this['appCheckProvider'])==null||_0x2aa399['get']()['then'](_0x4db7f6=>_0x4db7f6['addTokenListener'](_0x6dea0b));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x1ccfd4,_0x5cd4a5,_0x45e073){this['appName_']=_0x1ccfd4,this['firebaseOptions_']=_0x5cd4a5,this['authProvider_']=_0x45e073,this['auth_']=null,this['auth_']=_0x45e073['getImmediate']({'optional':!0x0}),this['auth_']||_0x45e073['onInit'](_0x4e2ae5=>this['auth_']=_0x4e2ae5);}['getToken'](_0x733247){return this['auth_']?this['auth_']['getToken'](_0x733247)['catch'](_0x26f81e=>_0x26f81e&&_0x26f81e['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x26f81e)):new Promise((_0x271382,_0x163751)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x733247)['then'](_0x271382,_0x163751):_0x271382(null);},0x0);});}['addTokenChangeListener'](_0x502103){this['auth_']?this['auth_']['addAuthTokenListener'](_0x502103):this['authProvider_']['get']()['then'](_0x209d6d=>_0x209d6d['addAuthTokenListener'](_0x502103));}['removeTokenChangeListener'](_0x23056d){this['authProvider_']['get']()['then'](_0x3692cb=>_0x3692cb['removeAuthTokenListener'](_0x23056d));}['notifyForInvalidToken'](){let _0x3c346='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3c346+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3c346+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3c346+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3c346);}}class an{constructor(_0x1cbbc2){this['accessToken']=_0x1cbbc2;}['getToken'](_0x5f1337){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x809fd5){_0x809fd5(this['accessToken']);}['removeTokenChangeListener'](_0x566cbb){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x15e4a6,_0x18f7cb,_0x1b0652,_0x5e67ef,_0x508e3d=!0x1,_0x321526='',_0x377182=!0x1,_0x154b1e=!0x1,_0x18a74c=null){this['secure']=_0x18f7cb,this['namespace']=_0x1b0652,this['webSocketOnly']=_0x5e67ef,this['nodeAdmin']=_0x508e3d,this['persistenceKey']=_0x321526,this['includeNamespaceInQueryParams']=_0x377182,this['isUsingEmulator']=_0x154b1e,this['emulatorOptions']=_0x18a74c,this['_host']=_0x15e4a6['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x15e4a6)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x3bcb5a){_0x3bcb5a!==this['internalHost']&&(this['internalHost']=_0x3bcb5a,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x11a2fa=this['toURLString']();return this['persistenceKey']&&(_0x11a2fa+='<'+this['persistenceKey']+'>'),_0x11a2fa;}['toURLString'](){const _0x67e30d=this['secure']?'https://':'http://',_0x21f900=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x67e30d+this['host']+'/'+_0x21f900;}}function th(_0x3f8375){return _0x3f8375['host']!==_0x3f8375['internalHost']||_0x3f8375['isCustomHost']()||_0x3f8375['includeNamespaceInQueryParams'];}function vo(_0x38a367,_0x48de80,_0x3a2918){f(typeof _0x48de80=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3a2918=='object','typeof\x20params\x20must\x20==\x20object');let _0x9706b1;if(_0x48de80===go)_0x9706b1=(_0x38a367['secure']?'wss://':'ws://')+_0x38a367['internalHost']+'/.ws?';else{if(_0x48de80===mo)_0x9706b1=(_0x38a367['secure']?'https://':'http://')+_0x38a367['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x48de80);}th(_0x38a367)&&(_0x3a2918['ns']=_0x38a367['namespace']);const _0xb3b5e8=[];return x(_0x3a2918,(_0x34023a,_0x50953a)=>{_0xb3b5e8['push'](_0x34023a+'='+_0x50953a);}),_0x9706b1+_0xb3b5e8['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x475552,_0x47e9a1=0x1){Q(this['counters_'],_0x475552)||(this['counters_'][_0x475552]=0x0),this['counters_'][_0x475552]+=_0x47e9a1;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x5a7bea){const _0x19738f=_0x5a7bea['toString']();return oi[_0x19738f]||(oi[_0x19738f]=new nh()),oi[_0x19738f];}function ih(_0x1f6084,_0xe75d6f){const _0xf7bd6e=_0x1f6084['toString']();return ai[_0xf7bd6e]||(ai[_0xf7bd6e]=_0xe75d6f()),ai[_0xf7bd6e];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x188cf4){this['onMessage_']=_0x188cf4,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2d0bbc,_0x23aec1){this['closeAfterResponse']=_0x2d0bbc,this['onClose']=_0x23aec1,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x338bd4,_0x5cc109){for(this['pendingResponses'][_0x338bd4]=_0x5cc109;this['pendingResponses'][this['currentResponseNum']];){const _0x133bfa=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3d1750=0x0;_0x3d1750<_0x133bfa['length'];++_0x3d1750)_0x133bfa[_0x3d1750]&&ft(()=>{this['onMessage_'](_0x133bfa[_0x3d1750]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x215921,_0x2b1d48,_0x540ecd,_0x17d0fb,_0x2850da,_0x38f690,_0x4a4a56){this['connId']=_0x215921,this['repoInfo']=_0x2b1d48,this['applicationId']=_0x540ecd,this['appCheckToken']=_0x17d0fb,this['authToken']=_0x2850da,this['transportSessionId']=_0x38f690,this['lastSessionId']=_0x4a4a56,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x215921),this['stats_']=qi(_0x2b1d48),this['urlFn']=_0x56edb7=>(this['appCheckToken']&&(_0x56edb7[wi]=this['appCheckToken']),vo(_0x2b1d48,mo,_0x56edb7));}['open'](_0x275778,_0x1df8bc){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1df8bc,this['myPacketOrderer']=new sh(_0x275778),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x182816)=>{const [_0x39768d,_0x151ca1,_0x96f90c,_0x4c7ce4,_0x338e93]=_0x182816;if(this['incrementIncomingBytes_'](_0x182816),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x39768d===qs)this['id']=_0x151ca1,this['password']=_0x96f90c;else{if(_0x39768d===rh)_0x151ca1?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x151ca1,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x39768d);}}},(..._0x4ddcd6)=>{const [_0x240beb,_0x150d46]=_0x4ddcd6;this['incrementIncomingBytes_'](_0x4ddcd6),this['myPacketOrderer']['handleResponse'](_0x240beb,_0x150d46);},()=>{this['onClosed_']();},this['urlFn']);const _0x3aedd2={};_0x3aedd2[qs]='t',_0x3aedd2[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3aedd2[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3aedd2[co]=Gi,this['transportSessionId']&&(_0x3aedd2[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x3aedd2[po]=this['lastSessionId']),this['applicationId']&&(_0x3aedd2[_o]=this['applicationId']),this['appCheckToken']&&(_0x3aedd2[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3aedd2[ho]=uo);const _0x39efdd=this['urlFn'](_0x3aedd2);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x39efdd),this['scriptTagHolder']['addTag'](_0x39efdd,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x166ba9){const _0x51d343=O(_0x166ba9);this['bytesSent']+=_0x51d343['length'],this['stats_']['incrementCounter']('bytes_sent',_0x51d343['length']);const _0x925787=$r(_0x51d343),_0x175432=oo(_0x925787,fh);for(let _0x503d39=0x0;_0x503d39<_0x175432['length'];_0x503d39++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x175432['length'],_0x175432[_0x503d39]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x37837a,_0x598008){this['myDisconnFrame']=document['createElement']('iframe');const _0x464d27={};_0x464d27[dh]='t',_0x464d27[Eo]=_0x37837a,_0x464d27[Io]=_0x598008,this['myDisconnFrame']['src']=this['urlFn'](_0x464d27),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x31c8ff){const _0x4c985f=O(_0x31c8ff)['length'];this['bytesReceived']+=_0x4c985f,this['stats_']['incrementCounter']('bytes_received',_0x4c985f);}}class zi{constructor(_0x466005,_0x122efe,_0x9ae07f,_0x36a3ed){this['onDisconnect']=_0x9ae07f,this['urlFn']=_0x36a3ed,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x466005,window[ah+this['uniqueCallbackIdentifier']]=_0x122efe,this['myIFrame']=zi['createIFrame_']();let _0x2c4925='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2c4925='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x377b0b='<html><body>'+_0x2c4925+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x377b0b),this['myIFrame']['doc']['close']();}catch(_0x8726d9){L('frame\x20writing\x20exception'),_0x8726d9['stack']&&L(_0x8726d9['stack']),L(_0x8726d9);}}}static['createIFrame_'](){const _0x3ef04e=document['createElement']('iframe');if(_0x3ef04e['style']['display']='none',document['body']){document['body']['appendChild'](_0x3ef04e);try{_0x3ef04e['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x7701e8=document['domain'];_0x3ef04e['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x7701e8+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3ef04e['contentDocument']?_0x3ef04e['doc']=_0x3ef04e['contentDocument']:_0x3ef04e['contentWindow']?_0x3ef04e['doc']=_0x3ef04e['contentWindow']['document']:_0x3ef04e['document']&&(_0x3ef04e['doc']=_0x3ef04e['document']),_0x3ef04e;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x231e32=this['onDisconnect'];_0x231e32&&(this['onDisconnect']=null,_0x231e32());}['startLongPoll'](_0x45d7e5,_0x4df133){for(this['myID']=_0x45d7e5,this['myPW']=_0x4df133,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x652203={};_0x652203[Eo]=this['myID'],_0x652203[Io]=this['myPW'],_0x652203[wo]=this['currentSerial'];let _0x4812da=this['urlFn'](_0x652203),_0x4c0065='',_0x11bb56=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x4c0065['length']<=Co;){const _0x5f4d03=this['pendingSegs']['shift']();_0x4c0065=_0x4c0065+'&'+lh+_0x11bb56+'='+_0x5f4d03['seg']+'&'+hh+_0x11bb56+'='+_0x5f4d03['ts']+'&'+uh+_0x11bb56+'='+_0x5f4d03['d'],_0x11bb56++;}return _0x4812da=_0x4812da+_0x4c0065,this['addLongPollTag_'](_0x4812da,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x48e642,_0x54b140,_0x47dcd4){this['pendingSegs']['push']({'seg':_0x48e642,'ts':_0x54b140,'d':_0x47dcd4}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x20c526,_0x3419f9){this['outstandingRequests']['add'](_0x3419f9);const _0x4c2475=()=>{this['outstandingRequests']['delete'](_0x3419f9),this['newRequest_']();},_0x557025=setTimeout(_0x4c2475,Math['floor'](ph)),_0x581241=()=>{clearTimeout(_0x557025),_0x4c2475();};this['addTag'](_0x20c526,_0x581241);}['addTag'](_0x5f1fac,_0x51b981){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x26a30d=this['myIFrame']['doc']['createElement']('script');_0x26a30d['type']='text/javascript',_0x26a30d['async']=!0x0,_0x26a30d['src']=_0x5f1fac,_0x26a30d['onload']=_0x26a30d['onreadystatechange']=function(){const _0x4418e5=_0x26a30d['readyState'];(!_0x4418e5||_0x4418e5==='loaded'||_0x4418e5==='complete')&&(_0x26a30d['onload']=_0x26a30d['onreadystatechange']=null,_0x26a30d['parentNode']&&_0x26a30d['parentNode']['removeChild'](_0x26a30d),_0x51b981());},_0x26a30d['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5f1fac),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x26a30d);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x437f20,_0x3b5237,_0x42db0f,_0x1cfbb5,_0x5a5f0f,_0x224373,_0x17cc9b){this['connId']=_0x437f20,this['applicationId']=_0x42db0f,this['appCheckToken']=_0x1cfbb5,this['authToken']=_0x5a5f0f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x3b5237),this['connURL']=q['connectionURL_'](_0x3b5237,_0x224373,_0x17cc9b,_0x1cfbb5,_0x42db0f),this['nodeAdmin']=_0x3b5237['nodeAdmin'];}static['connectionURL_'](_0x245160,_0xad3e17,_0xab0cbb,_0x118a16,_0x1c3c47){const _0x270c27={};return _0x270c27[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x270c27[ho]=uo),_0xad3e17&&(_0x270c27[lo]=_0xad3e17),_0xab0cbb&&(_0x270c27[po]=_0xab0cbb),_0x118a16&&(_0x270c27[wi]=_0x118a16),_0x1c3c47&&(_0x270c27[_o]=_0x1c3c47),vo(_0x245160,go,_0x270c27);}['open'](_0xe08031,_0x3560f6){this['onDisconnect']=_0x3560f6,this['onMessage']=_0xe08031,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x98fa4b;_c(),this['mySock']=new gn(this['connURL'],[],_0x98fa4b);}catch(_0x248e1d){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x58a185=_0x248e1d['message']||_0x248e1d['data'];_0x58a185&&this['log_'](_0x58a185),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x5599b3=>{this['handleIncomingFrame'](_0x5599b3);},this['mySock']['onerror']=_0x293a76=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3efad8=_0x293a76['message']||_0x293a76['data'];_0x3efad8&&this['log_'](_0x3efad8),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x7f1ed7=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x208927=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xde3ba6=navigator['userAgent']['match'](_0x208927);_0xde3ba6&&_0xde3ba6['length']>0x1&&parseFloat(_0xde3ba6[0x1])<4.4&&(_0x7f1ed7=!0x0);}return!_0x7f1ed7&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x2a5b8a){if(this['frames']['push'](_0x2a5b8a),this['frames']['length']===this['totalFrames']){const _0x4dcf9d=this['frames']['join']('');this['frames']=null;const _0x2feafc=Nt(_0x4dcf9d);this['onMessage'](_0x2feafc);}}['handleNewFrameCount_'](_0x36b7dc){this['totalFrames']=_0x36b7dc,this['frames']=[];}['extractFrameCount_'](_0x4c35ba){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4c35ba['length']<=0x6){const _0x4abd2f=Number(_0x4c35ba);if(!isNaN(_0x4abd2f))return this['handleNewFrameCount_'](_0x4abd2f),null;}return this['handleNewFrameCount_'](0x1),_0x4c35ba;}['handleIncomingFrame'](_0x5b04b3){if(this['mySock']===null)return;const _0x4f0da6=_0x5b04b3['data'];if(this['bytesReceived']+=_0x4f0da6['length'],this['stats_']['incrementCounter']('bytes_received',_0x4f0da6['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4f0da6);else{const _0x1c2dfe=this['extractFrameCount_'](_0x4f0da6);_0x1c2dfe!==null&&this['appendFrame_'](_0x1c2dfe);}}['send'](_0x19f6cc){this['resetKeepAlive']();const _0x2c1f84=O(_0x19f6cc);this['bytesSent']+=_0x2c1f84['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2c1f84['length']);const _0x50aefd=oo(_0x2c1f84,gh);_0x50aefd['length']>0x1&&this['sendString_'](String(_0x50aefd['length']));for(let _0x58f340=0x0;_0x58f340<_0x50aefd['length'];_0x58f340++)this['sendString_'](_0x50aefd[_0x58f340]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x286270){try{this['mySock']['send'](_0x286270);}catch(_0x3e9244){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3e9244['message']||_0x3e9244['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5a3bdf){this['initTransports_'](_0x5a3bdf);}['initTransports_'](_0x275076){const _0x56f6a9=q&&q['isAvailable']();let _0x3c75cc=_0x56f6a9&&!q['previouslyFailed']();if(_0x275076['webSocketOnly']&&(_0x56f6a9||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x3c75cc=!0x0),_0x3c75cc)this['transports_']=[q];else{const _0x2b14ee=this['transports_']=[];for(const _0x2e44b6 of Dt['ALL_TRANSPORTS'])_0x2e44b6&&_0x2e44b6['isAvailable']()&&_0x2b14ee['push'](_0x2e44b6);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x1f9b2d,_0x33175c,_0x2ac9f8,_0x428b96,_0x538cac,_0x42e9f5,_0x1be1d1,_0x4be370,_0x5ecfa9,_0x3a076e){this['id']=_0x1f9b2d,this['repoInfo_']=_0x33175c,this['applicationId_']=_0x2ac9f8,this['appCheckToken_']=_0x428b96,this['authToken_']=_0x538cac,this['onMessage_']=_0x42e9f5,this['onReady_']=_0x1be1d1,this['onDisconnect_']=_0x4be370,this['onKill_']=_0x5ecfa9,this['lastSessionId']=_0x3a076e,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x33175c),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x281481=this['transportManager_']['initialTransport']();this['conn_']=new _0x281481(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x281481['responsesRequiredToBeHealthy']||0x0;const _0x39372e=this['connReceiver_'](this['conn_']),_0x52a6d1=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x39372e,_0x52a6d1);},Math['floor'](0x0));const _0x53e921=_0x281481['healthyTimeout']||0x0;_0x53e921>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x53e921)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x15f461){return _0x422f95=>{_0x15f461===this['conn_']?this['onConnectionLost_'](_0x422f95):_0x15f461===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x343ee2){return _0x3a75a5=>{this['state_']!==0x2&&(_0x343ee2===this['rx_']?this['onPrimaryMessageReceived_'](_0x3a75a5):_0x343ee2===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3a75a5):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x100820){const _0x4eca8c={'t':'d','d':_0x100820};this['sendData_'](_0x4eca8c);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x3dc18b){if(ci in _0x3dc18b){const _0x44cecd=_0x3dc18b[ci];_0x44cecd===Ys?this['upgradeIfSecondaryHealthy_']():_0x44cecd===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x44cecd===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x5783a6){const _0xc4732c=vt('t',_0x5783a6),_0x3c0bf5=vt('d',_0x5783a6);if(_0xc4732c==='c')this['onSecondaryControl_'](_0x3c0bf5);else{if(_0xc4732c==='d')this['pendingDataMessages']['push'](_0x3c0bf5);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0xc4732c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x88069b){const _0x2a3935=vt('t',_0x88069b),_0x354d98=vt('d',_0x88069b);_0x2a3935==='c'?this['onControl_'](_0x354d98):_0x2a3935==='d'&&this['onDataMessage_'](_0x354d98);}['onDataMessage_'](_0x2e68a7){this['onPrimaryResponse_'](),this['onMessage_'](_0x2e68a7);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x102552){const _0x2008c2=vt(ci,_0x102552);if(zs in _0x102552){const _0x19b4c0=_0x102552[zs];if(_0x2008c2===Th){const _0x506920={..._0x19b4c0};this['repoInfo_']['isUsingEmulator']&&(_0x506920['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x506920);}else{if(_0x2008c2===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x211714=0x0;_0x211714<this['pendingDataMessages']['length'];++_0x211714)this['onDataMessage_'](this['pendingDataMessages'][_0x211714]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2008c2===wh?this['onConnectionShutdown_'](_0x19b4c0):_0x2008c2===js?this['onReset_'](_0x19b4c0):_0x2008c2===Ch?Ii('Server\x20Error:\x20'+_0x19b4c0):_0x2008c2===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x2008c2);}}}['onHandshake_'](_0x3eb53e){const _0x1dd257=_0x3eb53e['ts'],_0x553468=_0x3eb53e['v'],_0x4ea998=_0x3eb53e['h'];this['sessionId']=_0x3eb53e['s'],this['repoInfo_']['host']=_0x4ea998,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x1dd257),Gi!==_0x553468&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xf13bce=this['transportManager_']['upgradeTransport']();_0xf13bce&&this['startUpgrade_'](_0xf13bce);}['startUpgrade_'](_0x1438e0){this['secondaryConn_']=new _0x1438e0(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1438e0['responsesRequiredToBeHealthy']||0x0;const _0x333d80=this['connReceiver_'](this['secondaryConn_']),_0x313423=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x333d80,_0x313423),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x18503d){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x18503d),this['repoInfo_']['host']=_0x18503d,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x71c71b,_0x196f11){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x71c71b,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x196f11,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x268223=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x268223||this['rx_']===_0x268223)&&this['close']();}['onConnectionLost_'](_0x1d14af){this['conn_']=null,!_0x1d14af&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x517262){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x517262),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x50bee5){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x50bee5);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x1289f2,_0x1622f3,_0x50ca9c,_0x1ae75a){}['merge'](_0x118886,_0x50cff5,_0x1e4fbf,_0x125c40){}['refreshAuthToken'](_0x584667){}['refreshAppCheckToken'](_0xf087ca){}['onDisconnectPut'](_0x2c4ea2,_0xa1decd,_0x32c088){}['onDisconnectMerge'](_0x453516,_0x5f181c,_0x48e677){}['onDisconnectCancel'](_0x5ed758,_0x157546){}['reportStats'](_0x3796ef){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x39e2bc){this['allowedEvents_']=_0x39e2bc,this['listeners_']={},f(Array['isArray'](_0x39e2bc)&&_0x39e2bc['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x20e7ea,..._0x3f31d2){if(Array['isArray'](this['listeners_'][_0x20e7ea])){const _0x5b7f19=[...this['listeners_'][_0x20e7ea]];for(let _0x3a2711=0x0;_0x3a2711<_0x5b7f19['length'];_0x3a2711++)_0x5b7f19[_0x3a2711]['callback']['apply'](_0x5b7f19[_0x3a2711]['context'],_0x3f31d2);}}['on'](_0x2f1c0d,_0x5a6476,_0xe88331){this['validateEventType_'](_0x2f1c0d),this['listeners_'][_0x2f1c0d]=this['listeners_'][_0x2f1c0d]||[],this['listeners_'][_0x2f1c0d]['push']({'callback':_0x5a6476,'context':_0xe88331});const _0x8e4da8=this['getInitialEvent'](_0x2f1c0d);_0x8e4da8&&_0x5a6476['apply'](_0xe88331,_0x8e4da8);}['off'](_0x152942,_0x9b8af0,_0x45559a){this['validateEventType_'](_0x152942);const _0x47dbb0=this['listeners_'][_0x152942]||[];for(let _0x2e38b1=0x0;_0x2e38b1<_0x47dbb0['length'];_0x2e38b1++)if(_0x47dbb0[_0x2e38b1]['callback']===_0x9b8af0&&(!_0x45559a||_0x45559a===_0x47dbb0[_0x2e38b1]['context'])){_0x47dbb0['splice'](_0x2e38b1,0x1);return;}}['validateEventType_'](_0x29b189){f(this['allowedEvents_']['find'](_0x31c72c=>_0x31c72c===_0x29b189),'Unknown\x20event:\x20'+_0x29b189);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x43cb01){return f(_0x43cb01==='online','Unknown\x20event\x20type:\x20'+_0x43cb01),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x85cb7b,_0x5d3465){if(_0x5d3465===void 0x0){this['pieces_']=_0x85cb7b['split']('/');let _0x5dfaa1=0x0;for(let _0x2c911e=0x0;_0x2c911e<this['pieces_']['length'];_0x2c911e++)this['pieces_'][_0x2c911e]['length']>0x0&&(this['pieces_'][_0x5dfaa1]=this['pieces_'][_0x2c911e],_0x5dfaa1++);this['pieces_']['length']=_0x5dfaa1,this['pieceNum_']=0x0;}else this['pieces_']=_0x85cb7b,this['pieceNum_']=_0x5d3465;}['toString'](){let _0x473541='';for(let _0x41ad20=this['pieceNum_'];_0x41ad20<this['pieces_']['length'];_0x41ad20++)this['pieces_'][_0x41ad20]!==''&&(_0x473541+='/'+this['pieces_'][_0x41ad20]);return _0x473541||'/';}}function w(){return new C('');}function y(_0x4fbee9){return _0x4fbee9['pieceNum_']>=_0x4fbee9['pieces_']['length']?null:_0x4fbee9['pieces_'][_0x4fbee9['pieceNum_']];}function Ce(_0x12e0f8){return _0x12e0f8['pieces_']['length']-_0x12e0f8['pieceNum_'];}function S(_0x15da67){let _0x4ef39b=_0x15da67['pieceNum_'];return _0x4ef39b<_0x15da67['pieces_']['length']&&_0x4ef39b++,new C(_0x15da67['pieces_'],_0x4ef39b);}function ji(_0x1aff6d){return _0x1aff6d['pieceNum_']<_0x1aff6d['pieces_']['length']?_0x1aff6d['pieces_'][_0x1aff6d['pieces_']['length']-0x1]:null;}function bh(_0x1e93c0){let _0x452c66='';for(let _0x566d95=_0x1e93c0['pieceNum_'];_0x566d95<_0x1e93c0['pieces_']['length'];_0x566d95++)_0x1e93c0['pieces_'][_0x566d95]!==''&&(_0x452c66+='/'+encodeURIComponent(String(_0x1e93c0['pieces_'][_0x566d95])));return _0x452c66||'/';}function Mt(_0x460b36,_0x2b3db5=0x0){return _0x460b36['pieces_']['slice'](_0x460b36['pieceNum_']+_0x2b3db5);}function Ro(_0x30e34d){if(_0x30e34d['pieceNum_']>=_0x30e34d['pieces_']['length'])return null;const _0x930bf5=[];for(let _0x5ab0b3=_0x30e34d['pieceNum_'];_0x5ab0b3<_0x30e34d['pieces_']['length']-0x1;_0x5ab0b3++)_0x930bf5['push'](_0x30e34d['pieces_'][_0x5ab0b3]);return new C(_0x930bf5,0x0);}function k(_0x362ace,_0x2d2ac0){const _0x5d13a4=[];for(let _0x3c8a0d=_0x362ace['pieceNum_'];_0x3c8a0d<_0x362ace['pieces_']['length'];_0x3c8a0d++)_0x5d13a4['push'](_0x362ace['pieces_'][_0x3c8a0d]);if(_0x2d2ac0 instanceof C){for(let _0x599bf2=_0x2d2ac0['pieceNum_'];_0x599bf2<_0x2d2ac0['pieces_']['length'];_0x599bf2++)_0x5d13a4['push'](_0x2d2ac0['pieces_'][_0x599bf2]);}else{const _0x20ad0c=_0x2d2ac0['split']('/');for(let _0x1aa0af=0x0;_0x1aa0af<_0x20ad0c['length'];_0x1aa0af++)_0x20ad0c[_0x1aa0af]['length']>0x0&&_0x5d13a4['push'](_0x20ad0c[_0x1aa0af]);}return new C(_0x5d13a4,0x0);}function v(_0x5c1039){return _0x5c1039['pieceNum_']>=_0x5c1039['pieces_']['length'];}function F(_0x271b52,_0x18099a){const _0x22599b=y(_0x271b52),_0xb8c890=y(_0x18099a);if(_0x22599b===null)return _0x18099a;if(_0x22599b===_0xb8c890)return F(S(_0x271b52),S(_0x18099a));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x18099a+')\x20is\x20not\x20within\x20outerPath\x20('+_0x271b52+')');}function Rh(_0x48ec0a,_0x4a189a){const _0x33d8c5=Mt(_0x48ec0a,0x0),_0x264d2c=Mt(_0x4a189a,0x0);for(let _0x1015ae=0x0;_0x1015ae<_0x33d8c5['length']&&_0x1015ae<_0x264d2c['length'];_0x1015ae++){const _0x5b6c4c=qe(_0x33d8c5[_0x1015ae],_0x264d2c[_0x1015ae]);if(_0x5b6c4c!==0x0)return _0x5b6c4c;}return _0x33d8c5['length']===_0x264d2c['length']?0x0:_0x33d8c5['length']<_0x264d2c['length']?-0x1:0x1;}function Ki(_0x17b453,_0x102c19){if(Ce(_0x17b453)!==Ce(_0x102c19))return!0x1;for(let _0x2ae616=_0x17b453['pieceNum_'],_0x26201b=_0x102c19['pieceNum_'];_0x2ae616<=_0x17b453['pieces_']['length'];_0x2ae616++,_0x26201b++)if(_0x17b453['pieces_'][_0x2ae616]!==_0x102c19['pieces_'][_0x26201b])return!0x1;return!0x0;}function G(_0x14a84b,_0x21f99a){let _0x4ed025=_0x14a84b['pieceNum_'],_0x29561d=_0x21f99a['pieceNum_'];if(Ce(_0x14a84b)>Ce(_0x21f99a))return!0x1;for(;_0x4ed025<_0x14a84b['pieces_']['length'];){if(_0x14a84b['pieces_'][_0x4ed025]!==_0x21f99a['pieces_'][_0x29561d])return!0x1;++_0x4ed025,++_0x29561d;}return!0x0;}class Ah{constructor(_0x158144,_0x40f6bf){this['errorPrefix_']=_0x40f6bf,this['parts_']=Mt(_0x158144,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x518498=0x0;_0x518498<this['parts_']['length'];_0x518498++)this['byteLength_']+=Ln(this['parts_'][_0x518498]);Ao(this);}}function kh(_0x4bf83e,_0x16c466){_0x4bf83e['parts_']['length']>0x0&&(_0x4bf83e['byteLength_']+=0x1),_0x4bf83e['parts_']['push'](_0x16c466),_0x4bf83e['byteLength_']+=Ln(_0x16c466),Ao(_0x4bf83e);}function Ph(_0x399df7){const _0x263edc=_0x399df7['parts_']['pop']();_0x399df7['byteLength_']-=Ln(_0x263edc),_0x399df7['parts_']['length']>0x0&&(_0x399df7['byteLength_']-=0x1);}function Ao(_0x9a3c3e){if(_0x9a3c3e['byteLength_']>Zs)throw new Error(_0x9a3c3e['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x9a3c3e['byteLength_']+').');if(_0x9a3c3e['parts_']['length']>Xs)throw new Error(_0x9a3c3e['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x9a3c3e));}function Oe(_0x293982){return _0x293982['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x293982['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x598c6d,_0x29e2fe;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x29e2fe='visibilitychange',_0x598c6d='hidden'):typeof document['mozHidden']<'u'?(_0x29e2fe='mozvisibilitychange',_0x598c6d='mozHidden'):typeof document['msHidden']<'u'?(_0x29e2fe='msvisibilitychange',_0x598c6d='msHidden'):typeof document['webkitHidden']<'u'&&(_0x29e2fe='webkitvisibilitychange',_0x598c6d='webkitHidden')),this['visible_']=!0x0,_0x29e2fe&&document['addEventListener'](_0x29e2fe,()=>{const _0x474009=!document[_0x598c6d];_0x474009!==this['visible_']&&(this['visible_']=_0x474009,this['trigger']('visible',_0x474009));},!0x1);}['getInitialEvent'](_0x27fe8d){return f(_0x27fe8d==='visible','Unknown\x20event\x20type:\x20'+_0x27fe8d),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x20a6d3,_0x282ba7,_0x40b251,_0x470f7b,_0x35ac97,_0x25b01e,_0x4a9c2e,_0x414dcb){if(super(),this['repoInfo_']=_0x20a6d3,this['applicationId_']=_0x282ba7,this['onDataUpdate_']=_0x40b251,this['onConnectStatus_']=_0x470f7b,this['onServerInfoUpdate_']=_0x35ac97,this['authTokenProvider_']=_0x25b01e,this['appCheckTokenProvider_']=_0x4a9c2e,this['authOverride_']=_0x414dcb,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x414dcb)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x20a6d3['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4582dc,_0x201cc9,_0x24dc64){const _0xfd050a=++this['requestNumber_'],_0x1e0702={'r':_0xfd050a,'a':_0x4582dc,'b':_0x201cc9};this['log_'](O(_0x1e0702)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x1e0702),_0x24dc64&&(this['requestCBHash_'][_0xfd050a]=_0x24dc64);}['get'](_0x4aac39){this['initConnection_']();const _0x2289b8=new H(),_0x21943a={'action':'g','request':{'p':_0x4aac39['_path']['toString'](),'q':_0x4aac39['_queryObject']},'onComplete':_0x1103ec=>{const _0xa848f6=_0x1103ec['d'];_0x1103ec['s']==='ok'?_0x2289b8['resolve'](_0xa848f6):_0x2289b8['reject'](_0xa848f6);}};this['outstandingGets_']['push'](_0x21943a),this['outstandingGetCount_']++;const _0x1e5308=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1e5308),_0x2289b8['promise'];}['listen'](_0x55a7fb,_0x514853,_0xd8f0d6,_0x167cf8){this['initConnection_']();const _0x52e174=_0x55a7fb['_queryIdentifier'],_0x4ca45a=_0x55a7fb['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4ca45a+'\x20'+_0x52e174),this['listens']['has'](_0x4ca45a)||this['listens']['set'](_0x4ca45a,new Map()),f(_0x55a7fb['_queryParams']['isDefault']()||!_0x55a7fb['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4ca45a)['has'](_0x52e174),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x5f5b21={'onComplete':_0x167cf8,'hashFn':_0x514853,'query':_0x55a7fb,'tag':_0xd8f0d6};this['listens']['get'](_0x4ca45a)['set'](_0x52e174,_0x5f5b21),this['connected_']&&this['sendListen_'](_0x5f5b21);}['sendGet_'](_0x41de5e){const _0x3531f3=this['outstandingGets_'][_0x41de5e];this['sendRequest']('g',_0x3531f3['request'],_0x5b0331=>{delete this['outstandingGets_'][_0x41de5e],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x3531f3['onComplete']&&_0x3531f3['onComplete'](_0x5b0331);});}['sendListen_'](_0x281f7b){const _0x5e80bc=_0x281f7b['query'],_0x1bb6dd=_0x5e80bc['_path']['toString'](),_0x25821e=_0x5e80bc['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1bb6dd+'\x20for\x20'+_0x25821e);const _0x327bc5={'p':_0x1bb6dd},_0x449e4d='q';_0x281f7b['tag']&&(_0x327bc5['q']=_0x5e80bc['_queryObject'],_0x327bc5['t']=_0x281f7b['tag']),_0x327bc5['h']=_0x281f7b['hashFn'](),this['sendRequest'](_0x449e4d,_0x327bc5,_0x2c9367=>{const _0x4be4bf=_0x2c9367['d'],_0x3ec7fd=_0x2c9367['s'];se['warnOnListenWarnings_'](_0x4be4bf,_0x5e80bc),(this['listens']['get'](_0x1bb6dd)&&this['listens']['get'](_0x1bb6dd)['get'](_0x25821e))===_0x281f7b&&(this['log_']('listen\x20response',_0x2c9367),_0x3ec7fd!=='ok'&&this['removeListen_'](_0x1bb6dd,_0x25821e),_0x281f7b['onComplete']&&_0x281f7b['onComplete'](_0x3ec7fd,_0x4be4bf));});}static['warnOnListenWarnings_'](_0x3f8431,_0x37a072){if(_0x3f8431&&typeof _0x3f8431=='object'&&Q(_0x3f8431,'w')){const _0x4c446f=Le(_0x3f8431,'w');if(Array['isArray'](_0x4c446f)&&~_0x4c446f['indexOf']('no_index')){const _0x110879='\x22.indexOn\x22:\x20\x22'+_0x37a072['_queryParams']['getIndex']()['toString']()+'\x22',_0x15432f=_0x37a072['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x110879+'\x20at\x20'+_0x15432f+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x329843){this['authToken_']=_0x329843,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x329843);}['reduceReconnectDelayIfAdminCredential_'](_0x31d5a5){(_0x31d5a5&&_0x31d5a5['length']===0x28||wc(_0x31d5a5))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x456d21){this['appCheckToken_']=_0x456d21,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5578b4=this['authToken_'],_0x5ba64d=Ic(_0x5578b4)?'auth':'gauth',_0xb01e86={'cred':_0x5578b4};this['authOverride_']===null?_0xb01e86['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xb01e86['authvar']=this['authOverride_']),this['sendRequest'](_0x5ba64d,_0xb01e86,_0x41822a=>{const _0x8d72f8=_0x41822a['s'],_0x22685d=_0x41822a['d']||'error';this['authToken_']===_0x5578b4&&(_0x8d72f8==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x8d72f8,_0x22685d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3f675f=>{const _0x4d4048=_0x3f675f['s'],_0x584527=_0x3f675f['d']||'error';_0x4d4048==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4d4048,_0x584527);});}['unlisten'](_0x23b709,_0x4c0422){const _0x4bb3c5=_0x23b709['_path']['toString'](),_0x2d2801=_0x23b709['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x4bb3c5+'\x20'+_0x2d2801),f(_0x23b709['_queryParams']['isDefault']()||!_0x23b709['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x4bb3c5,_0x2d2801)&&this['connected_']&&this['sendUnlisten_'](_0x4bb3c5,_0x2d2801,_0x23b709['_queryObject'],_0x4c0422);}['sendUnlisten_'](_0xd6ecb9,_0x53619f,_0x61fd4e,_0x2f13ec){this['log_']('Unlisten\x20on\x20'+_0xd6ecb9+'\x20for\x20'+_0x53619f);const _0x4b99ef={'p':_0xd6ecb9},_0x3dfe34='n';_0x2f13ec&&(_0x4b99ef['q']=_0x61fd4e,_0x4b99ef['t']=_0x2f13ec),this['sendRequest'](_0x3dfe34,_0x4b99ef);}['onDisconnectPut'](_0x1264ea,_0x421a96,_0xa2a493){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1264ea,_0x421a96,_0xa2a493):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1264ea,'action':'o','data':_0x421a96,'onComplete':_0xa2a493});}['onDisconnectMerge'](_0x2f87a8,_0x381fbd,_0x413c9c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2f87a8,_0x381fbd,_0x413c9c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2f87a8,'action':'om','data':_0x381fbd,'onComplete':_0x413c9c});}['onDisconnectCancel'](_0x235792,_0x48a28a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x235792,null,_0x48a28a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x235792,'action':'oc','data':null,'onComplete':_0x48a28a});}['sendOnDisconnect_'](_0x2b87ff,_0x487f21,_0x3f4fd0,_0x148780){const _0x3401a={'p':_0x487f21,'d':_0x3f4fd0};this['log_']('onDisconnect\x20'+_0x2b87ff,_0x3401a),this['sendRequest'](_0x2b87ff,_0x3401a,_0x38e1d0=>{_0x148780&&setTimeout(()=>{_0x148780(_0x38e1d0['s'],_0x38e1d0['d']);},Math['floor'](0x0));});}['put'](_0x1f68e4,_0x518008,_0x200650,_0x20aa40){this['putInternal']('p',_0x1f68e4,_0x518008,_0x200650,_0x20aa40);}['merge'](_0x48ea28,_0x4a2ec0,_0x35b152,_0x465be3){this['putInternal']('m',_0x48ea28,_0x4a2ec0,_0x35b152,_0x465be3);}['putInternal'](_0x155161,_0x5963c2,_0x4ce122,_0x2808da,_0x40f271){this['initConnection_']();const _0x172b8d={'p':_0x5963c2,'d':_0x4ce122};_0x40f271!==void 0x0&&(_0x172b8d['h']=_0x40f271),this['outstandingPuts_']['push']({'action':_0x155161,'request':_0x172b8d,'onComplete':_0x2808da}),this['outstandingPutCount_']++;const _0x4ca1bd=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4ca1bd):this['log_']('Buffering\x20put:\x20'+_0x5963c2);}['sendPut_'](_0x120658){const _0x54f9a1=this['outstandingPuts_'][_0x120658]['action'],_0x3053d8=this['outstandingPuts_'][_0x120658]['request'],_0xb940ea=this['outstandingPuts_'][_0x120658]['onComplete'];this['outstandingPuts_'][_0x120658]['queued']=this['connected_'],this['sendRequest'](_0x54f9a1,_0x3053d8,_0x253ffc=>{this['log_'](_0x54f9a1+'\x20response',_0x253ffc),delete this['outstandingPuts_'][_0x120658],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0xb940ea&&_0xb940ea(_0x253ffc['s'],_0x253ffc['d']);});}['reportStats'](_0x56ba21){if(this['connected_']){const _0x491aa6={'c':_0x56ba21};this['log_']('reportStats',_0x491aa6),this['sendRequest']('s',_0x491aa6,_0x4c2dc4=>{if(_0x4c2dc4['s']!=='ok'){const _0x55936e=_0x4c2dc4['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x55936e);}});}}['onDataMessage_'](_0x1d4003){if('r'in _0x1d4003){this['log_']('from\x20server:\x20'+O(_0x1d4003));const _0x18bf7a=_0x1d4003['r'],_0x2b0100=this['requestCBHash_'][_0x18bf7a];_0x2b0100&&(delete this['requestCBHash_'][_0x18bf7a],_0x2b0100(_0x1d4003['b']));}else{if('error'in _0x1d4003)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1d4003['error'];'a'in _0x1d4003&&this['onDataPush_'](_0x1d4003['a'],_0x1d4003['b']);}}['onDataPush_'](_0x41c60b,_0x181d8a){this['log_']('handleServerMessage',_0x41c60b,_0x181d8a),_0x41c60b==='d'?this['onDataUpdate_'](_0x181d8a['p'],_0x181d8a['d'],!0x1,_0x181d8a['t']):_0x41c60b==='m'?this['onDataUpdate_'](_0x181d8a['p'],_0x181d8a['d'],!0x0,_0x181d8a['t']):_0x41c60b==='c'?this['onListenRevoked_'](_0x181d8a['p'],_0x181d8a['q']):_0x41c60b==='ac'?this['onAuthRevoked_'](_0x181d8a['s'],_0x181d8a['d']):_0x41c60b==='apc'?this['onAppCheckRevoked_'](_0x181d8a['s'],_0x181d8a['d']):_0x41c60b==='sd'?this['onSecurityDebugPacket_'](_0x181d8a):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x41c60b)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x5acf59,_0x2bef4f){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x5acf59),this['lastSessionId']=_0x2bef4f,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0xfa04c7){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0xfa04c7));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x596543){_0x596543&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x596543;}['onOnline_'](_0x3e3a6b){_0x3e3a6b?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0xa00a2b=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x1555ad=Math['max'](0x0,this['reconnectDelay_']-_0xa00a2b);_0x1555ad=Math['random']()*_0x1555ad,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x1555ad+'ms'),this['scheduleConnect_'](_0x1555ad),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2363bb=this['onDataMessage_']['bind'](this),_0x213186=this['onReady_']['bind'](this),_0x2d53dc=this['onRealtimeDisconnect_']['bind'](this),_0x6b00ca=this['id']+':'+se['nextConnectionId_']++,_0x38705c=this['lastSessionId'];let _0x2b9cd6=!0x1,_0x28a775=null;const _0x370af2=function(){_0x28a775?_0x28a775['close']():(_0x2b9cd6=!0x0,_0x2d53dc());},_0x1aca88=function(_0x5b384f){f(_0x28a775,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x28a775['sendRequest'](_0x5b384f);};this['realtime_']={'close':_0x370af2,'sendRequest':_0x1aca88};const _0xdcba7=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0xc65b75,_0x1217c7]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xdcba7),this['appCheckTokenProvider_']['getToken'](_0xdcba7)]);_0x2b9cd6?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0xc65b75&&_0xc65b75['accessToken'],this['appCheckToken_']=_0x1217c7&&_0x1217c7['token'],_0x28a775=new Sh(_0x6b00ca,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2363bb,_0x213186,_0x2d53dc,_0x5774a1=>{U(_0x5774a1+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x38705c));}catch(_0x4d4012){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4d4012),_0x2b9cd6||(this['repoInfo_']['nodeAdmin']&&U(_0x4d4012),_0x370af2());}}}['interrupt'](_0x58ba2b){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x58ba2b),this['interruptReasons_'][_0x58ba2b]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2d1f26){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2d1f26),delete this['interruptReasons_'][_0x2d1f26],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x31086e){const _0x1d6b47=_0x31086e-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1d6b47});}['cancelSentTransactions_'](){for(let _0x41bc58=0x0;_0x41bc58<this['outstandingPuts_']['length'];_0x41bc58++){const _0x5bfef5=this['outstandingPuts_'][_0x41bc58];_0x5bfef5&&'h'in _0x5bfef5['request']&&_0x5bfef5['queued']&&(_0x5bfef5['onComplete']&&_0x5bfef5['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x41bc58],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2a00f3,_0x4e799b){let _0x327595;_0x4e799b?_0x327595=_0x4e799b['map'](_0x37a463=>$i(_0x37a463))['join']('$'):_0x327595='default';const _0x3d00f5=this['removeListen_'](_0x2a00f3,_0x327595);_0x3d00f5&&_0x3d00f5['onComplete']&&_0x3d00f5['onComplete']('permission_denied');}['removeListen_'](_0x495be6,_0x2ee930){const _0x137155=new C(_0x495be6)['toString']();let _0x5d0dec;if(this['listens']['has'](_0x137155)){const _0x47581a=this['listens']['get'](_0x137155);_0x5d0dec=_0x47581a['get'](_0x2ee930),_0x47581a['delete'](_0x2ee930),_0x47581a['size']===0x0&&this['listens']['delete'](_0x137155);}else _0x5d0dec=void 0x0;return _0x5d0dec;}['onAuthRevoked_'](_0x19ca39,_0x96e626){L('Auth\x20token\x20revoked:\x20'+_0x19ca39+'/'+_0x96e626),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x19ca39==='invalid_token'||_0x19ca39==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5ea34b,_0x5ec7e4){L('App\x20check\x20token\x20revoked:\x20'+_0x5ea34b+'/'+_0x5ec7e4),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5ea34b==='invalid_token'||_0x5ea34b==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x30f0f8){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x30f0f8):'msg'in _0x30f0f8&&console['log']('FIREBASE:\x20'+_0x30f0f8['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4efaaa of this['listens']['values']())for(const _0x343982 of _0x4efaaa['values']())this['sendListen_'](_0x343982);for(let _0x212ee7=0x0;_0x212ee7<this['outstandingPuts_']['length'];_0x212ee7++)this['outstandingPuts_'][_0x212ee7]&&this['sendPut_'](_0x212ee7);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1c391f=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1c391f['action'],_0x1c391f['pathString'],_0x1c391f['data'],_0x1c391f['onComplete']);}for(let _0x103c16=0x0;_0x103c16<this['outstandingGets_']['length'];_0x103c16++)this['outstandingGets_'][_0x103c16]&&this['sendGet_'](_0x103c16);}['sendConnectStats_'](){const _0x3c9db2={};let _0x5ec41c='js';_0x3c9db2['sdk.'+_0x5ec41c+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x3c9db2['framework.cordova']=0x1:Kr()&&(_0x3c9db2['framework.reactnative']=0x1),this['reportStats'](_0x3c9db2);}['shouldReconnect_'](){const _0x21a366=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x21a366;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3a5355,_0x5dc243){this['name']=_0x3a5355,this['node']=_0x5dc243;}static['Wrap'](_0x5aff92,_0x25809d){return new E(_0x5aff92,_0x25809d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x46b605,_0x878783){const _0x499a07=new E(We,_0x46b605),_0x128515=new E(We,_0x878783);return this['compare'](_0x499a07,_0x128515)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x2db797){sn=_0x2db797;}['compare'](_0x2a0178,_0x5f5230){return qe(_0x2a0178['name'],_0x5f5230['name']);}['isDefinedOn'](_0x4a3f2a){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x5a9f0,_0x802736){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x3adc14,_0x2b6e79){return f(typeof _0x3adc14=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3adc14,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x1c5b83,_0x1e2b18,_0x7dded4,_0x496e0c,_0xb7486d=null){this['isReverse_']=_0x496e0c,this['resultGenerator_']=_0xb7486d,this['nodeStack_']=[];let _0x5d1b56=0x1;for(;!_0x1c5b83['isEmpty']();)if(_0x1c5b83=_0x1c5b83,_0x5d1b56=_0x1e2b18?_0x7dded4(_0x1c5b83['key'],_0x1e2b18):0x1,_0x496e0c&&(_0x5d1b56*=-0x1),_0x5d1b56<0x0)this['isReverse_']?_0x1c5b83=_0x1c5b83['left']:_0x1c5b83=_0x1c5b83['right'];else{if(_0x5d1b56===0x0){this['nodeStack_']['push'](_0x1c5b83);break;}else this['nodeStack_']['push'](_0x1c5b83),this['isReverse_']?_0x1c5b83=_0x1c5b83['right']:_0x1c5b83=_0x1c5b83['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x51d50d=this['nodeStack_']['pop'](),_0x5aea37;if(this['resultGenerator_']?_0x5aea37=this['resultGenerator_'](_0x51d50d['key'],_0x51d50d['value']):_0x5aea37={'key':_0x51d50d['key'],'value':_0x51d50d['value']},this['isReverse_']){for(_0x51d50d=_0x51d50d['left'];!_0x51d50d['isEmpty']();)this['nodeStack_']['push'](_0x51d50d),_0x51d50d=_0x51d50d['right'];}else{for(_0x51d50d=_0x51d50d['right'];!_0x51d50d['isEmpty']();)this['nodeStack_']['push'](_0x51d50d),_0x51d50d=_0x51d50d['left'];}return _0x5aea37;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2d5e9f=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2d5e9f['key'],_0x2d5e9f['value']):{'key':_0x2d5e9f['key'],'value':_0x2d5e9f['value']};}}class M{constructor(_0x283abf,_0x32fd98,_0x5454bd,_0x36eebf,_0x18a127){this['key']=_0x283abf,this['value']=_0x32fd98,this['color']=_0x5454bd??M['RED'],this['left']=_0x36eebf??B['EMPTY_NODE'],this['right']=_0x18a127??B['EMPTY_NODE'];}['copy'](_0x3f6c61,_0x169be8,_0x2b36a8,_0xbc533b,_0xcaec8e){return new M(_0x3f6c61??this['key'],_0x169be8??this['value'],_0x2b36a8??this['color'],_0xbc533b??this['left'],_0xcaec8e??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x1a577f){return this['left']['inorderTraversal'](_0x1a577f)||!!_0x1a577f(this['key'],this['value'])||this['right']['inorderTraversal'](_0x1a577f);}['reverseTraversal'](_0xdb2d55){return this['right']['reverseTraversal'](_0xdb2d55)||_0xdb2d55(this['key'],this['value'])||this['left']['reverseTraversal'](_0xdb2d55);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x46e78c,_0x1b3389,_0x54ece0){let _0x16c241=this;const _0x23893e=_0x54ece0(_0x46e78c,_0x16c241['key']);return _0x23893e<0x0?_0x16c241=_0x16c241['copy'](null,null,null,_0x16c241['left']['insert'](_0x46e78c,_0x1b3389,_0x54ece0),null):_0x23893e===0x0?_0x16c241=_0x16c241['copy'](null,_0x1b3389,null,null,null):_0x16c241=_0x16c241['copy'](null,null,null,null,_0x16c241['right']['insert'](_0x46e78c,_0x1b3389,_0x54ece0)),_0x16c241['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0xc647d5=this;return!_0xc647d5['left']['isRed_']()&&!_0xc647d5['left']['left']['isRed_']()&&(_0xc647d5=_0xc647d5['moveRedLeft_']()),_0xc647d5=_0xc647d5['copy'](null,null,null,_0xc647d5['left']['removeMin_'](),null),_0xc647d5['fixUp_']();}['remove'](_0x3a6164,_0x514ded){let _0x555da4,_0x3cd72d;if(_0x555da4=this,_0x514ded(_0x3a6164,_0x555da4['key'])<0x0)!_0x555da4['left']['isEmpty']()&&!_0x555da4['left']['isRed_']()&&!_0x555da4['left']['left']['isRed_']()&&(_0x555da4=_0x555da4['moveRedLeft_']()),_0x555da4=_0x555da4['copy'](null,null,null,_0x555da4['left']['remove'](_0x3a6164,_0x514ded),null);else{if(_0x555da4['left']['isRed_']()&&(_0x555da4=_0x555da4['rotateRight_']()),!_0x555da4['right']['isEmpty']()&&!_0x555da4['right']['isRed_']()&&!_0x555da4['right']['left']['isRed_']()&&(_0x555da4=_0x555da4['moveRedRight_']()),_0x514ded(_0x3a6164,_0x555da4['key'])===0x0){if(_0x555da4['right']['isEmpty']())return B['EMPTY_NODE'];_0x3cd72d=_0x555da4['right']['min_'](),_0x555da4=_0x555da4['copy'](_0x3cd72d['key'],_0x3cd72d['value'],null,null,_0x555da4['right']['removeMin_']());}_0x555da4=_0x555da4['copy'](null,null,null,null,_0x555da4['right']['remove'](_0x3a6164,_0x514ded));}return _0x555da4['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0xd221a9=this;return _0xd221a9['right']['isRed_']()&&!_0xd221a9['left']['isRed_']()&&(_0xd221a9=_0xd221a9['rotateLeft_']()),_0xd221a9['left']['isRed_']()&&_0xd221a9['left']['left']['isRed_']()&&(_0xd221a9=_0xd221a9['rotateRight_']()),_0xd221a9['left']['isRed_']()&&_0xd221a9['right']['isRed_']()&&(_0xd221a9=_0xd221a9['colorFlip_']()),_0xd221a9;}['moveRedLeft_'](){let _0x545523=this['colorFlip_']();return _0x545523['right']['left']['isRed_']()&&(_0x545523=_0x545523['copy'](null,null,null,null,_0x545523['right']['rotateRight_']()),_0x545523=_0x545523['rotateLeft_'](),_0x545523=_0x545523['colorFlip_']()),_0x545523;}['moveRedRight_'](){let _0xde7ff0=this['colorFlip_']();return _0xde7ff0['left']['left']['isRed_']()&&(_0xde7ff0=_0xde7ff0['rotateRight_'](),_0xde7ff0=_0xde7ff0['colorFlip_']()),_0xde7ff0;}['rotateLeft_'](){const _0x372780=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x372780,null);}['rotateRight_'](){const _0x30772c=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x30772c);}['colorFlip_'](){const _0x5e83f8=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x41bd84=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5e83f8,_0x41bd84);}['checkMaxDepth_'](){const _0x25760b=this['check_']();return Math['pow'](0x2,_0x25760b)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x74532f=this['left']['check_']();if(_0x74532f!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x74532f+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x2bf598,_0x36a481,_0x2786d4,_0xf41a12,_0x123a6c){return this;}['insert'](_0x4ba8d3,_0x5d9d41,_0x4543b7){return new M(_0x4ba8d3,_0x5d9d41,null);}['remove'](_0x1403df,_0xcd09b0){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x37c87e){return!0x1;}['reverseTraversal'](_0x3cff27){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x420d28,_0x40193a=B['EMPTY_NODE']){this['comparator_']=_0x420d28,this['root_']=_0x40193a;}['insert'](_0x3c9ade,_0x395ac4){return new B(this['comparator_'],this['root_']['insert'](_0x3c9ade,_0x395ac4,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x36eb12){return new B(this['comparator_'],this['root_']['remove'](_0x36eb12,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2faf44){let _0x5085b8,_0x4ad07d=this['root_'];for(;!_0x4ad07d['isEmpty']();){if(_0x5085b8=this['comparator_'](_0x2faf44,_0x4ad07d['key']),_0x5085b8===0x0)return _0x4ad07d['value'];_0x5085b8<0x0?_0x4ad07d=_0x4ad07d['left']:_0x5085b8>0x0&&(_0x4ad07d=_0x4ad07d['right']);}return null;}['getPredecessorKey'](_0x4faa61){let _0x20792c,_0x545687=this['root_'],_0x236fe2=null;for(;!_0x545687['isEmpty']();)if(_0x20792c=this['comparator_'](_0x4faa61,_0x545687['key']),_0x20792c===0x0){if(_0x545687['left']['isEmpty']())return _0x236fe2?_0x236fe2['key']:null;for(_0x545687=_0x545687['left'];!_0x545687['right']['isEmpty']();)_0x545687=_0x545687['right'];return _0x545687['key'];}else _0x20792c<0x0?_0x545687=_0x545687['left']:_0x20792c>0x0&&(_0x236fe2=_0x545687,_0x545687=_0x545687['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5321be){return this['root_']['inorderTraversal'](_0x5321be);}['reverseTraversal'](_0x42a8fb){return this['root_']['reverseTraversal'](_0x42a8fb);}['getIterator'](_0x55f578){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x55f578);}['getIteratorFrom'](_0x1f2ac0,_0x195cff){return new rn(this['root_'],_0x1f2ac0,this['comparator_'],!0x1,_0x195cff);}['getReverseIteratorFrom'](_0x39771d,_0x22a7e8){return new rn(this['root_'],_0x39771d,this['comparator_'],!0x0,_0x22a7e8);}['getReverseIterator'](_0x41b7ef){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x41b7ef);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x5efb63,_0x51efa9){return qe(_0x5efb63['name'],_0x51efa9['name']);}function Qi(_0x277c67,_0x113eb4){return qe(_0x277c67,_0x113eb4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x5e3a5d){Ci=_0x5e3a5d;}const Po=function(_0x4a67ba){return typeof _0x4a67ba=='number'?'number:'+ao(_0x4a67ba):'string:'+_0x4a67ba;},No=function(_0x502420){if(_0x502420['isLeafNode']()){const _0x2ea3bb=_0x502420['val']();f(typeof _0x2ea3bb=='string'||typeof _0x2ea3bb=='number'||typeof _0x2ea3bb=='object'&&Q(_0x2ea3bb,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x502420===Ci||_0x502420['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x502420===Ci||_0x502420['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x17b2fb){nr=_0x17b2fb;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x391e7b,_0x3f5529=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x391e7b,this['priorityNode_']=_0x3f5529,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5dc0cf){return new D(this['value_'],_0x5dc0cf);}['getImmediateChild'](_0x5a77fc){return _0x5a77fc==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x352c26){return v(_0x352c26)?this:y(_0x352c26)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2b17e4,_0x4dad66){return null;}['updateImmediateChild'](_0x291dcb,_0x16f686){return _0x291dcb==='.priority'?this['updatePriority'](_0x16f686):_0x16f686['isEmpty']()&&_0x291dcb!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x291dcb,_0x16f686)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x41a2a1,_0x3617c3){const _0x4dfed8=y(_0x41a2a1);return _0x4dfed8===null?_0x3617c3:_0x3617c3['isEmpty']()&&_0x4dfed8!=='.priority'?this:(f(_0x4dfed8!=='.priority'||Ce(_0x41a2a1)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4dfed8,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x41a2a1),_0x3617c3)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1094c3,_0xf72d86){return!0x1;}['val'](_0x24f646){return _0x24f646&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x296697='';this['priorityNode_']['isEmpty']()||(_0x296697+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3b45d2=typeof this['value_'];_0x296697+=_0x3b45d2+':',_0x3b45d2==='number'?_0x296697+=ao(this['value_']):_0x296697+=this['value_'],this['lazyHash_']=ro(_0x296697);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x219888){return _0x219888===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x219888 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x219888['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x219888));}['compareToLeafNode_'](_0x3fe52c){const _0x5bc918=typeof _0x3fe52c['value_'],_0x42c4fa=typeof this['value_'],_0x1cd205=D['VALUE_TYPE_ORDER']['indexOf'](_0x5bc918),_0x466121=D['VALUE_TYPE_ORDER']['indexOf'](_0x42c4fa);return f(_0x1cd205>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5bc918),f(_0x466121>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x42c4fa),_0x1cd205===_0x466121?_0x42c4fa==='object'?0x0:this['value_']<_0x3fe52c['value_']?-0x1:this['value_']===_0x3fe52c['value_']?0x0:0x1:_0x466121-_0x1cd205;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x28afcf){if(_0x28afcf===this)return!0x0;if(_0x28afcf['isLeafNode']()){const _0x4c4413=_0x28afcf;return this['value_']===_0x4c4413['value_']&&this['priorityNode_']['equals'](_0x4c4413['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x2cfd14){Oo=_0x2cfd14;}function Wh(_0x1467d0){Do=_0x1467d0;}class Bh extends Fn{['compare'](_0xd55d84,_0x38caa8){const _0x2c5d84=_0xd55d84['node']['getPriority'](),_0x545728=_0x38caa8['node']['getPriority'](),_0x535113=_0x2c5d84['compareTo'](_0x545728);return _0x535113===0x0?qe(_0xd55d84['name'],_0x38caa8['name']):_0x535113;}['isDefinedOn'](_0x1ac2e9){return!_0x1ac2e9['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3e2c5c,_0x4b1ad1){return!_0x3e2c5c['getPriority']()['equals'](_0x4b1ad1['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x350b68,_0x6f4692){const _0x91f637=Oo(_0x350b68);return new E(_0x6f4692,new D('[PRIORITY-POST]',_0x91f637));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3178e3){const _0x557240=_0x2bf190=>parseInt(Math['log'](_0x2bf190)/Vh,0xa),_0x2e47d5=_0x3f360d=>parseInt(Array(_0x3f360d+0x1)['join']('1'),0x2);this['count']=_0x557240(_0x3178e3+0x1),this['current_']=this['count']-0x1;const _0x2188cb=_0x2e47d5(this['count']);this['bits_']=_0x3178e3+0x1&_0x2188cb;}['nextBitIsOne'](){const _0x9b0f0b=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x9b0f0b;}}const yn=function(_0xbcd49c,_0x57da84,_0x46d1ab,_0x58507d){_0xbcd49c['sort'](_0x57da84);const _0x1faf51=function(_0x43f744,_0x3d6b24){const _0x31d8f4=_0x3d6b24-_0x43f744;let _0x4039ca,_0xf340af;if(_0x31d8f4===0x0)return null;if(_0x31d8f4===0x1)return _0x4039ca=_0xbcd49c[_0x43f744],_0xf340af=_0x46d1ab?_0x46d1ab(_0x4039ca):_0x4039ca,new M(_0xf340af,_0x4039ca['node'],M['BLACK'],null,null);{const _0xfcc3ef=parseInt(_0x31d8f4/0x2,0xa)+_0x43f744,_0x19ed96=_0x1faf51(_0x43f744,_0xfcc3ef),_0x4766e1=_0x1faf51(_0xfcc3ef+0x1,_0x3d6b24);return _0x4039ca=_0xbcd49c[_0xfcc3ef],_0xf340af=_0x46d1ab?_0x46d1ab(_0x4039ca):_0x4039ca,new M(_0xf340af,_0x4039ca['node'],M['BLACK'],_0x19ed96,_0x4766e1);}},_0x28c5f9=function(_0x323c0b){let _0x5199c1=null,_0x46ed45=null,_0x203900=_0xbcd49c['length'];const _0x5270c3=function(_0x9e9f5f,_0x46f9d0){const _0x334abb=_0x203900-_0x9e9f5f,_0x185e9b=_0x203900;_0x203900-=_0x9e9f5f;const _0x573a6a=_0x1faf51(_0x334abb+0x1,_0x185e9b),_0x25963c=_0xbcd49c[_0x334abb],_0x71fc83=_0x46d1ab?_0x46d1ab(_0x25963c):_0x25963c;_0x16806f(new M(_0x71fc83,_0x25963c['node'],_0x46f9d0,null,_0x573a6a));},_0x16806f=function(_0x3358ba){_0x5199c1?(_0x5199c1['left']=_0x3358ba,_0x5199c1=_0x3358ba):(_0x46ed45=_0x3358ba,_0x5199c1=_0x3358ba);};for(let _0x2e2fc0=0x0;_0x2e2fc0<_0x323c0b['count'];++_0x2e2fc0){const _0x241bbe=_0x323c0b['nextBitIsOne'](),_0x248f0e=Math['pow'](0x2,_0x323c0b['count']-(_0x2e2fc0+0x1));_0x241bbe?_0x5270c3(_0x248f0e,M['BLACK']):(_0x5270c3(_0x248f0e,M['BLACK']),_0x5270c3(_0x248f0e,M['RED']));}return _0x46ed45;},_0x2a169f=new Hh(_0xbcd49c['length']),_0xb9149a=_0x28c5f9(_0x2a169f);return new B(_0x58507d||_0x57da84,_0xb9149a);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x34f5c3,_0xe97b65){this['indexes_']=_0x34f5c3,this['indexSet_']=_0xe97b65;}['get'](_0x1e9052){const _0x1c7ae3=Le(this['indexes_'],_0x1e9052);if(!_0x1c7ae3)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1e9052);return _0x1c7ae3 instanceof B?_0x1c7ae3:null;}['hasIndex'](_0x4810a9){return Q(this['indexSet_'],_0x4810a9['toString']());}['addIndex'](_0x21f2b4,_0x24637a){f(_0x21f2b4!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x56fba3=[];let _0x47bba0=!0x1;const _0x39e5b9=_0x24637a['getIterator'](E['Wrap']);let _0x17db31=_0x39e5b9['getNext']();for(;_0x17db31;)_0x47bba0=_0x47bba0||_0x21f2b4['isDefinedOn'](_0x17db31['node']),_0x56fba3['push'](_0x17db31),_0x17db31=_0x39e5b9['getNext']();let _0x4b03e7;_0x47bba0?_0x4b03e7=yn(_0x56fba3,_0x21f2b4['getCompare']()):_0x4b03e7=Qe;const _0xc6008c=_0x21f2b4['toString'](),_0x35e30c={...this['indexSet_']};_0x35e30c[_0xc6008c]=_0x21f2b4;const _0x3fbf48={...this['indexes_']};return _0x3fbf48[_0xc6008c]=_0x4b03e7,new te(_0x3fbf48,_0x35e30c);}['addToIndexes'](_0x52d06b,_0x48c8dd){const _0x24877c=_n(this['indexes_'],(_0x386b61,_0x3ab29c)=>{const _0x2674f1=Le(this['indexSet_'],_0x3ab29c);if(f(_0x2674f1,'Missing\x20index\x20implementation\x20for\x20'+_0x3ab29c),_0x386b61===Qe){if(_0x2674f1['isDefinedOn'](_0x52d06b['node'])){const _0x3565bb=[],_0x4b99a1=_0x48c8dd['getIterator'](E['Wrap']);let _0x2e6f93=_0x4b99a1['getNext']();for(;_0x2e6f93;)_0x2e6f93['name']!==_0x52d06b['name']&&_0x3565bb['push'](_0x2e6f93),_0x2e6f93=_0x4b99a1['getNext']();return _0x3565bb['push'](_0x52d06b),yn(_0x3565bb,_0x2674f1['getCompare']());}else return Qe;}else{const _0x18fe0a=_0x48c8dd['get'](_0x52d06b['name']);let _0x33abae=_0x386b61;return _0x18fe0a&&(_0x33abae=_0x33abae['remove'](new E(_0x52d06b['name'],_0x18fe0a))),_0x33abae['insert'](_0x52d06b,_0x52d06b['node']);}});return new te(_0x24877c,this['indexSet_']);}['removeFromIndexes'](_0x4ef06d,_0x3af503){const _0x45cd41=_n(this['indexes_'],_0x44ce49=>{if(_0x44ce49===Qe)return _0x44ce49;{const _0x67f0f3=_0x3af503['get'](_0x4ef06d['name']);return _0x67f0f3?_0x44ce49['remove'](new E(_0x4ef06d['name'],_0x67f0f3)):_0x44ce49;}});return new te(_0x45cd41,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x1fbe09,_0x563d9e,_0x5041ce){this['children_']=_0x1fbe09,this['priorityNode_']=_0x563d9e,this['indexMap_']=_0x5041ce,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x4d9192){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x4d9192,this['indexMap_']);}['getImmediateChild'](_0x139f18){if(_0x139f18==='.priority')return this['getPriority']();{const _0x3833f0=this['children_']['get'](_0x139f18);return _0x3833f0===null?It:_0x3833f0;}}['getChild'](_0x39e51e){const _0x480d49=y(_0x39e51e);return _0x480d49===null?this:this['getImmediateChild'](_0x480d49)['getChild'](S(_0x39e51e));}['hasChild'](_0x39ecea){return this['children_']['get'](_0x39ecea)!==null;}['updateImmediateChild'](_0x251ea0,_0x107358){if(f(_0x107358,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x251ea0==='.priority')return this['updatePriority'](_0x107358);{const _0x3d8c4a=new E(_0x251ea0,_0x107358);let _0x4f89e4,_0x439494;_0x107358['isEmpty']()?(_0x4f89e4=this['children_']['remove'](_0x251ea0),_0x439494=this['indexMap_']['removeFromIndexes'](_0x3d8c4a,this['children_'])):(_0x4f89e4=this['children_']['insert'](_0x251ea0,_0x107358),_0x439494=this['indexMap_']['addToIndexes'](_0x3d8c4a,this['children_']));const _0x1edd0f=_0x4f89e4['isEmpty']()?It:this['priorityNode_'];return new g(_0x4f89e4,_0x1edd0f,_0x439494);}}['updateChild'](_0x32a28c,_0xf241af){const _0x33e275=y(_0x32a28c);if(_0x33e275===null)return _0xf241af;{f(y(_0x32a28c)!=='.priority'||Ce(_0x32a28c)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x424086=this['getImmediateChild'](_0x33e275)['updateChild'](S(_0x32a28c),_0xf241af);return this['updateImmediateChild'](_0x33e275,_0x424086);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2dd3a6){if(this['isEmpty']())return null;const _0x367f43={};let _0x2c9234=0x0,_0xaac945=0x0,_0x2d6189=!0x0;if(this['forEachChild'](R,(_0x31ca15,_0x33f2be)=>{_0x367f43[_0x31ca15]=_0x33f2be['val'](_0x2dd3a6),_0x2c9234++,_0x2d6189&&g['INTEGER_REGEXP_']['test'](_0x31ca15)?_0xaac945=Math['max'](_0xaac945,Number(_0x31ca15)):_0x2d6189=!0x1;}),!_0x2dd3a6&&_0x2d6189&&_0xaac945<0x2*_0x2c9234){const _0x3c48d6=[];for(const _0x3049ac in _0x367f43)_0x3c48d6[_0x3049ac]=_0x367f43[_0x3049ac];return _0x3c48d6;}else return _0x2dd3a6&&!this['getPriority']()['isEmpty']()&&(_0x367f43['.priority']=this['getPriority']()['val']()),_0x367f43;}['hash'](){if(this['lazyHash_']===null){let _0x723f84='';this['getPriority']()['isEmpty']()||(_0x723f84+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2d1e72,_0x143e64)=>{const _0x4b829b=_0x143e64['hash']();_0x4b829b!==''&&(_0x723f84+=':'+_0x2d1e72+':'+_0x4b829b);}),this['lazyHash_']=_0x723f84===''?'':ro(_0x723f84);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3c4769,_0x451400,_0x249892){const _0x385a98=this['resolveIndex_'](_0x249892);if(_0x385a98){const _0x7d04bd=_0x385a98['getPredecessorKey'](new E(_0x3c4769,_0x451400));return _0x7d04bd?_0x7d04bd['name']:null;}else return this['children_']['getPredecessorKey'](_0x3c4769);}['getFirstChildName'](_0x1a5d5c){const _0x3d7391=this['resolveIndex_'](_0x1a5d5c);if(_0x3d7391){const _0x5675f1=_0x3d7391['minKey']();return _0x5675f1&&_0x5675f1['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x28e800){const _0x4ed4d1=this['getFirstChildName'](_0x28e800);return _0x4ed4d1?new E(_0x4ed4d1,this['children_']['get'](_0x4ed4d1)):null;}['getLastChildName'](_0x4ee615){const _0x317829=this['resolveIndex_'](_0x4ee615);if(_0x317829){const _0x4df84b=_0x317829['maxKey']();return _0x4df84b&&_0x4df84b['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x55b460){const _0x2f1a2f=this['getLastChildName'](_0x55b460);return _0x2f1a2f?new E(_0x2f1a2f,this['children_']['get'](_0x2f1a2f)):null;}['forEachChild'](_0x528c46,_0x54ecab){const _0x480849=this['resolveIndex_'](_0x528c46);return _0x480849?_0x480849['inorderTraversal'](_0x3e03cf=>_0x54ecab(_0x3e03cf['name'],_0x3e03cf['node'])):this['children_']['inorderTraversal'](_0x54ecab);}['getIterator'](_0x3f9710){return this['getIteratorFrom'](_0x3f9710['minPost'](),_0x3f9710);}['getIteratorFrom'](_0x16b1f1,_0x5b9438){const _0x5d4407=this['resolveIndex_'](_0x5b9438);if(_0x5d4407)return _0x5d4407['getIteratorFrom'](_0x16b1f1,_0x4fcbfb=>_0x4fcbfb);{const _0x33f24a=this['children_']['getIteratorFrom'](_0x16b1f1['name'],E['Wrap']);let _0x192a03=_0x33f24a['peek']();for(;_0x192a03!=null&&_0x5b9438['compare'](_0x192a03,_0x16b1f1)<0x0;)_0x33f24a['getNext'](),_0x192a03=_0x33f24a['peek']();return _0x33f24a;}}['getReverseIterator'](_0x25be82){return this['getReverseIteratorFrom'](_0x25be82['maxPost'](),_0x25be82);}['getReverseIteratorFrom'](_0x36d388,_0x2bc1a6){const _0x5ccc6a=this['resolveIndex_'](_0x2bc1a6);if(_0x5ccc6a)return _0x5ccc6a['getReverseIteratorFrom'](_0x36d388,_0x10aa8a=>_0x10aa8a);{const _0x3f2546=this['children_']['getReverseIteratorFrom'](_0x36d388['name'],E['Wrap']);let _0x5f258f=_0x3f2546['peek']();for(;_0x5f258f!=null&&_0x2bc1a6['compare'](_0x5f258f,_0x36d388)>0x0;)_0x3f2546['getNext'](),_0x5f258f=_0x3f2546['peek']();return _0x3f2546;}}['compareTo'](_0x5b6a6d){return this['isEmpty']()?_0x5b6a6d['isEmpty']()?0x0:-0x1:_0x5b6a6d['isLeafNode']()||_0x5b6a6d['isEmpty']()?0x1:_0x5b6a6d===Kt?-0x1:0x0;}['withIndex'](_0x2c29b6){if(_0x2c29b6===ve||this['indexMap_']['hasIndex'](_0x2c29b6))return this;{const _0x2a637e=this['indexMap_']['addIndex'](_0x2c29b6,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2a637e);}}['isIndexed'](_0x7af1c1){return _0x7af1c1===ve||this['indexMap_']['hasIndex'](_0x7af1c1);}['equals'](_0x307e28){if(_0x307e28===this)return!0x0;if(_0x307e28['isLeafNode']())return!0x1;{const _0x2f7061=_0x307e28;if(this['getPriority']()['equals'](_0x2f7061['getPriority']())){if(this['children_']['count']()===_0x2f7061['children_']['count']()){const _0x1b7829=this['getIterator'](R),_0x38075f=_0x2f7061['getIterator'](R);let _0x284d4e=_0x1b7829['getNext'](),_0x1fa014=_0x38075f['getNext']();for(;_0x284d4e&&_0x1fa014;){if(_0x284d4e['name']!==_0x1fa014['name']||!_0x284d4e['node']['equals'](_0x1fa014['node']))return!0x1;_0x284d4e=_0x1b7829['getNext'](),_0x1fa014=_0x38075f['getNext']();}return _0x284d4e===null&&_0x1fa014===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x14d72b){return _0x14d72b===ve?null:this['indexMap_']['get'](_0x14d72b['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x1dc8d7){return _0x1dc8d7===this?0x0:0x1;}['equals'](_0x2f881e){return _0x2f881e===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5f5ae1){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x4bed41,_0x32f0cf=null){if(_0x4bed41===null)return g['EMPTY_NODE'];if(typeof _0x4bed41=='object'&&'.priority'in _0x4bed41&&(_0x32f0cf=_0x4bed41['.priority']),f(_0x32f0cf===null||typeof _0x32f0cf=='string'||typeof _0x32f0cf=='number'||typeof _0x32f0cf=='object'&&'.sv'in _0x32f0cf,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x32f0cf),typeof _0x4bed41=='object'&&'.value'in _0x4bed41&&_0x4bed41['.value']!==null&&(_0x4bed41=_0x4bed41['.value']),typeof _0x4bed41!='object'||'.sv'in _0x4bed41){const _0x18fe13=_0x4bed41;return new D(_0x18fe13,A(_0x32f0cf));}if(!(_0x4bed41 instanceof Array)&&Gh){const _0x56095e=[];let _0x4dad59=!0x1;if(x(_0x4bed41,(_0x101dff,_0x275404)=>{if(_0x101dff['substring'](0x0,0x1)!=='.'){const _0x13cbc6=A(_0x275404);_0x13cbc6['isEmpty']()||(_0x4dad59=_0x4dad59||!_0x13cbc6['getPriority']()['isEmpty'](),_0x56095e['push'](new E(_0x101dff,_0x13cbc6)));}}),_0x56095e['length']===0x0)return g['EMPTY_NODE'];const _0x249f51=yn(_0x56095e,xh,_0x53b5e3=>_0x53b5e3['name'],Qi);if(_0x4dad59){const _0x598e72=yn(_0x56095e,R['getCompare']());return new g(_0x249f51,A(_0x32f0cf),new te({'.priority':_0x598e72},{'.priority':R}));}else return new g(_0x249f51,A(_0x32f0cf),te['Default']);}else{let _0x1b3e2a=g['EMPTY_NODE'];return x(_0x4bed41,(_0x5bd91a,_0x58d09d)=>{if(Q(_0x4bed41,_0x5bd91a)&&_0x5bd91a['substring'](0x0,0x1)!=='.'){const _0x557a4=A(_0x58d09d);(_0x557a4['isLeafNode']()||!_0x557a4['isEmpty']())&&(_0x1b3e2a=_0x1b3e2a['updateImmediateChild'](_0x5bd91a,_0x557a4));}}),_0x1b3e2a['updatePriority'](A(_0x32f0cf));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x17870d){super(),this['indexPath_']=_0x17870d,f(!v(_0x17870d)&&y(_0x17870d)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x6fb62f){return _0x6fb62f['getChild'](this['indexPath_']);}['isDefinedOn'](_0x23124a){return!_0x23124a['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0xa5ed8a,_0x356b19){const _0x3cb5a0=this['extractChild'](_0xa5ed8a['node']),_0x216540=this['extractChild'](_0x356b19['node']),_0x55dcc7=_0x3cb5a0['compareTo'](_0x216540);return _0x55dcc7===0x0?qe(_0xa5ed8a['name'],_0x356b19['name']):_0x55dcc7;}['makePost'](_0xe3dd37,_0x10a3f4){const _0x3a05a1=A(_0xe3dd37),_0x1538a4=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x3a05a1);return new E(_0x10a3f4,_0x1538a4);}['maxPost'](){const _0x11ad0e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x11ad0e);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x465d62,_0x3d64ed){const _0x4bd2e9=_0x465d62['node']['compareTo'](_0x3d64ed['node']);return _0x4bd2e9===0x0?qe(_0x465d62['name'],_0x3d64ed['name']):_0x4bd2e9;}['isDefinedOn'](_0x459c22){return!0x0;}['indexedValueChanged'](_0x24f457,_0xe22ac7){return!_0x24f457['equals'](_0xe22ac7);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x36a190,_0x2a1171){const _0x545be7=A(_0x36a190);return new E(_0x2a1171,_0x545be7);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x555e64){return{'type':'value','snapshotNode':_0x555e64};}function rt(_0x3463af,_0x4462dc){return{'type':'child_added','snapshotNode':_0x4462dc,'childName':_0x3463af};}function Lt(_0x1fc45e,_0x483b9f){return{'type':'child_removed','snapshotNode':_0x483b9f,'childName':_0x1fc45e};}function xt(_0x53f9cc,_0x2db81e,_0xca00c2){return{'type':'child_changed','snapshotNode':_0x2db81e,'childName':_0x53f9cc,'oldSnap':_0xca00c2};}function zh(_0x3bc0eb,_0x1f54da){return{'type':'child_moved','snapshotNode':_0x1f54da,'childName':_0x3bc0eb};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x4f95d4){this['index_']=_0x4f95d4;}['updateChild'](_0x4159c0,_0x4fad51,_0x1b46ac,_0x2278b7,_0x3c61a8,_0x16203d){f(_0x4159c0['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2fb420=_0x4159c0['getImmediateChild'](_0x4fad51);return _0x2fb420['getChild'](_0x2278b7)['equals'](_0x1b46ac['getChild'](_0x2278b7))&&_0x2fb420['isEmpty']()===_0x1b46ac['isEmpty']()||(_0x16203d!=null&&(_0x1b46ac['isEmpty']()?_0x4159c0['hasChild'](_0x4fad51)?_0x16203d['trackChildChange'](Lt(_0x4fad51,_0x2fb420)):f(_0x4159c0['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2fb420['isEmpty']()?_0x16203d['trackChildChange'](rt(_0x4fad51,_0x1b46ac)):_0x16203d['trackChildChange'](xt(_0x4fad51,_0x1b46ac,_0x2fb420))),_0x4159c0['isLeafNode']()&&_0x1b46ac['isEmpty']())?_0x4159c0:_0x4159c0['updateImmediateChild'](_0x4fad51,_0x1b46ac)['withIndex'](this['index_']);}['updateFullNode'](_0x114e72,_0x288986,_0x2f20e5){return _0x2f20e5!=null&&(_0x114e72['isLeafNode']()||_0x114e72['forEachChild'](R,(_0x3eedf2,_0x34bfd0)=>{_0x288986['hasChild'](_0x3eedf2)||_0x2f20e5['trackChildChange'](Lt(_0x3eedf2,_0x34bfd0));}),_0x288986['isLeafNode']()||_0x288986['forEachChild'](R,(_0x1f32d8,_0x516352)=>{if(_0x114e72['hasChild'](_0x1f32d8)){const _0x309804=_0x114e72['getImmediateChild'](_0x1f32d8);_0x309804['equals'](_0x516352)||_0x2f20e5['trackChildChange'](xt(_0x1f32d8,_0x516352,_0x309804));}else _0x2f20e5['trackChildChange'](rt(_0x1f32d8,_0x516352));})),_0x288986['withIndex'](this['index_']);}['updatePriority'](_0x1159dc,_0x42c686){return _0x1159dc['isEmpty']()?g['EMPTY_NODE']:_0x1159dc['updatePriority'](_0x42c686);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x2a85cf){this['indexedFilter_']=new Xi(_0x2a85cf['getIndex']()),this['index_']=_0x2a85cf['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x2a85cf),this['endPost_']=Ft['getEndPost_'](_0x2a85cf),this['startIsInclusive_']=!_0x2a85cf['startAfterSet_'],this['endIsInclusive_']=!_0x2a85cf['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5589e8){const _0x42da3a=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5589e8)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5589e8)<0x0,_0x166ad1=this['endIsInclusive_']?this['index_']['compare'](_0x5589e8,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5589e8,this['getEndPost']())<0x0;return _0x42da3a&&_0x166ad1;}['updateChild'](_0x463980,_0x1a1748,_0x5dbd31,_0x3a7d19,_0x1dadd6,_0x42814b){return this['matches'](new E(_0x1a1748,_0x5dbd31))||(_0x5dbd31=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x463980,_0x1a1748,_0x5dbd31,_0x3a7d19,_0x1dadd6,_0x42814b);}['updateFullNode'](_0x2a14ca,_0x4a99c5,_0x42d2c2){_0x4a99c5['isLeafNode']()&&(_0x4a99c5=g['EMPTY_NODE']);let _0x13d441=_0x4a99c5['withIndex'](this['index_']);_0x13d441=_0x13d441['updatePriority'](g['EMPTY_NODE']);const _0x4658b4=this;return _0x4a99c5['forEachChild'](R,(_0x3a83d9,_0x4a9fb4)=>{_0x4658b4['matches'](new E(_0x3a83d9,_0x4a9fb4))||(_0x13d441=_0x13d441['updateImmediateChild'](_0x3a83d9,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x2a14ca,_0x13d441,_0x42d2c2);}['updatePriority'](_0x584464,_0x3a74a5){return _0x584464;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3d14d5){if(_0x3d14d5['hasStart']()){const _0x58602d=_0x3d14d5['getIndexStartName']();return _0x3d14d5['getIndex']()['makePost'](_0x3d14d5['getIndexStartValue'](),_0x58602d);}else return _0x3d14d5['getIndex']()['minPost']();}static['getEndPost_'](_0xdde38){if(_0xdde38['hasEnd']()){const _0x3a6cc0=_0xdde38['getIndexEndName']();return _0xdde38['getIndex']()['makePost'](_0xdde38['getIndexEndValue'](),_0x3a6cc0);}else return _0xdde38['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1154e9){this['withinDirectionalStart']=_0x1f6925=>this['reverse_']?this['withinEndPost'](_0x1f6925):this['withinStartPost'](_0x1f6925),this['withinDirectionalEnd']=_0x268502=>this['reverse_']?this['withinStartPost'](_0x268502):this['withinEndPost'](_0x268502),this['withinStartPost']=_0x35f5d1=>{const _0x3681ec=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x35f5d1);return this['startIsInclusive_']?_0x3681ec<=0x0:_0x3681ec<0x0;},this['withinEndPost']=_0x805a0=>{const _0x205ab3=this['index_']['compare'](_0x805a0,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x205ab3<=0x0:_0x205ab3<0x0;},this['rangedFilter_']=new Ft(_0x1154e9),this['index_']=_0x1154e9['getIndex'](),this['limit_']=_0x1154e9['getLimit'](),this['reverse_']=!_0x1154e9['isViewFromLeft'](),this['startIsInclusive_']=!_0x1154e9['startAfterSet_'],this['endIsInclusive_']=!_0x1154e9['endBeforeSet_'];}['updateChild'](_0x514cff,_0x15552b,_0x18a1d4,_0x5453bc,_0x27a921,_0x63970c){return this['rangedFilter_']['matches'](new E(_0x15552b,_0x18a1d4))||(_0x18a1d4=g['EMPTY_NODE']),_0x514cff['getImmediateChild'](_0x15552b)['equals'](_0x18a1d4)?_0x514cff:_0x514cff['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x514cff,_0x15552b,_0x18a1d4,_0x5453bc,_0x27a921,_0x63970c):this['fullLimitUpdateChild_'](_0x514cff,_0x15552b,_0x18a1d4,_0x27a921,_0x63970c);}['updateFullNode'](_0x6c2eae,_0x570b47,_0x11dcf5){let _0x4c0831;if(_0x570b47['isLeafNode']()||_0x570b47['isEmpty']())_0x4c0831=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x570b47['numChildren']()&&_0x570b47['isIndexed'](this['index_'])){_0x4c0831=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x23fcfb;this['reverse_']?_0x23fcfb=_0x570b47['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x23fcfb=_0x570b47['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x1612d6=0x0;for(;_0x23fcfb['hasNext']()&&_0x1612d6<this['limit_'];){const _0x2587eb=_0x23fcfb['getNext']();if(this['withinDirectionalStart'](_0x2587eb)){if(this['withinDirectionalEnd'](_0x2587eb))_0x4c0831=_0x4c0831['updateImmediateChild'](_0x2587eb['name'],_0x2587eb['node']),_0x1612d6++;else break;}else continue;}}else{_0x4c0831=_0x570b47['withIndex'](this['index_']),_0x4c0831=_0x4c0831['updatePriority'](g['EMPTY_NODE']);let _0x104ae6;this['reverse_']?_0x104ae6=_0x4c0831['getReverseIterator'](this['index_']):_0x104ae6=_0x4c0831['getIterator'](this['index_']);let _0x37ccbf=0x0;for(;_0x104ae6['hasNext']();){const _0x3e311c=_0x104ae6['getNext']();_0x37ccbf<this['limit_']&&this['withinDirectionalStart'](_0x3e311c)&&this['withinDirectionalEnd'](_0x3e311c)?_0x37ccbf++:_0x4c0831=_0x4c0831['updateImmediateChild'](_0x3e311c['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x6c2eae,_0x4c0831,_0x11dcf5);}['updatePriority'](_0x6bb057,_0x2477f3){return _0x6bb057;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0xae9dce,_0x4f76a3,_0x425d24,_0x15b822,_0x1032a){let _0x5afcce;if(this['reverse_']){const _0x34f7e6=this['index_']['getCompare']();_0x5afcce=(_0x27a562,_0x48161b)=>_0x34f7e6(_0x48161b,_0x27a562);}else _0x5afcce=this['index_']['getCompare']();const _0x481a0d=_0xae9dce;f(_0x481a0d['numChildren']()===this['limit_'],'');const _0x3d45cc=new E(_0x4f76a3,_0x425d24),_0x1e3cfc=this['reverse_']?_0x481a0d['getFirstChild'](this['index_']):_0x481a0d['getLastChild'](this['index_']),_0xed54dd=this['rangedFilter_']['matches'](_0x3d45cc);if(_0x481a0d['hasChild'](_0x4f76a3)){const _0x2f1434=_0x481a0d['getImmediateChild'](_0x4f76a3);let _0x565a7f=_0x15b822['getChildAfterChild'](this['index_'],_0x1e3cfc,this['reverse_']);for(;_0x565a7f!=null&&(_0x565a7f['name']===_0x4f76a3||_0x481a0d['hasChild'](_0x565a7f['name']));)_0x565a7f=_0x15b822['getChildAfterChild'](this['index_'],_0x565a7f,this['reverse_']);const _0x2dd09b=_0x565a7f==null?0x1:_0x5afcce(_0x565a7f,_0x3d45cc);if(_0xed54dd&&!_0x425d24['isEmpty']()&&_0x2dd09b>=0x0)return _0x1032a!=null&&_0x1032a['trackChildChange'](xt(_0x4f76a3,_0x425d24,_0x2f1434)),_0x481a0d['updateImmediateChild'](_0x4f76a3,_0x425d24);{_0x1032a!=null&&_0x1032a['trackChildChange'](Lt(_0x4f76a3,_0x2f1434));const _0xc7a759=_0x481a0d['updateImmediateChild'](_0x4f76a3,g['EMPTY_NODE']);return _0x565a7f!=null&&this['rangedFilter_']['matches'](_0x565a7f)?(_0x1032a!=null&&_0x1032a['trackChildChange'](rt(_0x565a7f['name'],_0x565a7f['node'])),_0xc7a759['updateImmediateChild'](_0x565a7f['name'],_0x565a7f['node'])):_0xc7a759;}}else return _0x425d24['isEmpty']()?_0xae9dce:_0xed54dd&&_0x5afcce(_0x1e3cfc,_0x3d45cc)>=0x0?(_0x1032a!=null&&(_0x1032a['trackChildChange'](Lt(_0x1e3cfc['name'],_0x1e3cfc['node'])),_0x1032a['trackChildChange'](rt(_0x4f76a3,_0x425d24))),_0x481a0d['updateImmediateChild'](_0x4f76a3,_0x425d24)['updateImmediateChild'](_0x1e3cfc['name'],g['EMPTY_NODE'])):_0xae9dce;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x30714d=new Zi();return _0x30714d['limitSet_']=this['limitSet_'],_0x30714d['limit_']=this['limit_'],_0x30714d['startSet_']=this['startSet_'],_0x30714d['startAfterSet_']=this['startAfterSet_'],_0x30714d['indexStartValue_']=this['indexStartValue_'],_0x30714d['startNameSet_']=this['startNameSet_'],_0x30714d['indexStartName_']=this['indexStartName_'],_0x30714d['endSet_']=this['endSet_'],_0x30714d['endBeforeSet_']=this['endBeforeSet_'],_0x30714d['indexEndValue_']=this['indexEndValue_'],_0x30714d['endNameSet_']=this['endNameSet_'],_0x30714d['indexEndName_']=this['indexEndName_'],_0x30714d['index_']=this['index_'],_0x30714d['viewFrom_']=this['viewFrom_'],_0x30714d;}}function Kh(_0x3dda27){return _0x3dda27['loadsAllData']()?new Xi(_0x3dda27['getIndex']()):_0x3dda27['hasLimit']()?new jh(_0x3dda27):new Ft(_0x3dda27);}function Yh(_0xf32e92,_0x4deb74){const _0x7e82f2=_0xf32e92['copy']();return _0x7e82f2['limitSet_']=!0x0,_0x7e82f2['limit_']=_0x4deb74,_0x7e82f2['viewFrom_']='l',_0x7e82f2;}function Qh(_0xd60208,_0x30f809,_0xfb64b1){const _0x2f5c13=_0xd60208['copy']();return _0x2f5c13['startSet_']=!0x0,_0x30f809===void 0x0&&(_0x30f809=null),_0x2f5c13['indexStartValue_']=_0x30f809,_0xfb64b1!=null?(_0x2f5c13['startNameSet_']=!0x0,_0x2f5c13['indexStartName_']=_0xfb64b1):(_0x2f5c13['startNameSet_']=!0x1,_0x2f5c13['indexStartName_']=''),_0x2f5c13;}function Jh(_0x4c8ebe,_0x5fb914,_0x2d7fcc){const _0x2eeb71=_0x4c8ebe['copy']();return _0x2eeb71['endSet_']=!0x0,_0x5fb914===void 0x0&&(_0x5fb914=null),_0x2eeb71['indexEndValue_']=_0x5fb914,_0x2d7fcc!==void 0x0?(_0x2eeb71['endNameSet_']=!0x0,_0x2eeb71['indexEndName_']=_0x2d7fcc):(_0x2eeb71['endNameSet_']=!0x1,_0x2eeb71['indexEndName_']=''),_0x2eeb71;}function xo(_0x1a2388,_0x32a3d4){const _0x46f74f=_0x1a2388['copy']();return _0x46f74f['index_']=_0x32a3d4,_0x46f74f;}function ir(_0x93e2f){const _0x8c0ddc={};if(_0x93e2f['isDefault']())return _0x8c0ddc;let _0x5e1109;if(_0x93e2f['index_']===R?_0x5e1109='$priority':_0x93e2f['index_']===Mo?_0x5e1109='$value':_0x93e2f['index_']===ve?_0x5e1109='$key':(f(_0x93e2f['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x5e1109=_0x93e2f['index_']['toString']()),_0x8c0ddc['orderBy']=O(_0x5e1109),_0x93e2f['startSet_']){const _0x2859ce=_0x93e2f['startAfterSet_']?'startAfter':'startAt';_0x8c0ddc[_0x2859ce]=O(_0x93e2f['indexStartValue_']),_0x93e2f['startNameSet_']&&(_0x8c0ddc[_0x2859ce]+=','+O(_0x93e2f['indexStartName_']));}if(_0x93e2f['endSet_']){const _0x392518=_0x93e2f['endBeforeSet_']?'endBefore':'endAt';_0x8c0ddc[_0x392518]=O(_0x93e2f['indexEndValue_']),_0x93e2f['endNameSet_']&&(_0x8c0ddc[_0x392518]+=','+O(_0x93e2f['indexEndName_']));}return _0x93e2f['limitSet_']&&(_0x93e2f['isViewFromLeft']()?_0x8c0ddc['limitToFirst']=_0x93e2f['limit_']:_0x8c0ddc['limitToLast']=_0x93e2f['limit_']),_0x8c0ddc;}function sr(_0x685dcd){const _0x5fb891={};if(_0x685dcd['startSet_']&&(_0x5fb891['sp']=_0x685dcd['indexStartValue_'],_0x685dcd['startNameSet_']&&(_0x5fb891['sn']=_0x685dcd['indexStartName_']),_0x5fb891['sin']=!_0x685dcd['startAfterSet_']),_0x685dcd['endSet_']&&(_0x5fb891['ep']=_0x685dcd['indexEndValue_'],_0x685dcd['endNameSet_']&&(_0x5fb891['en']=_0x685dcd['indexEndName_']),_0x5fb891['ein']=!_0x685dcd['endBeforeSet_']),_0x685dcd['limitSet_']){_0x5fb891['l']=_0x685dcd['limit_'];let _0x4c646a=_0x685dcd['viewFrom_'];_0x4c646a===''&&(_0x685dcd['isViewFromLeft']()?_0x4c646a='l':_0x4c646a='r'),_0x5fb891['vf']=_0x4c646a;}return _0x685dcd['index_']!==R&&(_0x5fb891['i']=_0x685dcd['index_']['toString']()),_0x5fb891;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x38f6a7){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x1b308e,_0x558acc){return _0x558acc!==void 0x0?'tag$'+_0x558acc:(f(_0x1b308e['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x1b308e['_path']['toString']());}constructor(_0x68cf39,_0x4a2414,_0x20c370,_0x3f8f17){super(),this['repoInfo_']=_0x68cf39,this['onDataUpdate_']=_0x4a2414,this['authTokenProvider_']=_0x20c370,this['appCheckTokenProvider_']=_0x3f8f17,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x4543b6,_0x49b7a6,_0x24db9e,_0x46d030){const _0x42cdd6=_0x4543b6['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x42cdd6+'\x20'+_0x4543b6['_queryIdentifier']);const _0xfaec55=vn['getListenId_'](_0x4543b6,_0x24db9e),_0x4af254={};this['listens_'][_0xfaec55]=_0x4af254;const _0x3ec01f=ir(_0x4543b6['_queryParams']);this['restRequest_'](_0x42cdd6+'.json',_0x3ec01f,(_0x2e950e,_0x4b3cd5)=>{let _0x353e11=_0x4b3cd5;if(_0x2e950e===0x194&&(_0x353e11=null,_0x2e950e=null),_0x2e950e===null&&this['onDataUpdate_'](_0x42cdd6,_0x353e11,!0x1,_0x24db9e),Le(this['listens_'],_0xfaec55)===_0x4af254){let _0x35cc9c;_0x2e950e?_0x2e950e===0x191?_0x35cc9c='permission_denied':_0x35cc9c='rest_error:'+_0x2e950e:_0x35cc9c='ok',_0x46d030(_0x35cc9c,null);}});}['unlisten'](_0x3a3d49,_0x100f06){const _0x3c9e10=vn['getListenId_'](_0x3a3d49,_0x100f06);delete this['listens_'][_0x3c9e10];}['get'](_0x346b5a){const _0x879287=ir(_0x346b5a['_queryParams']),_0x14e22d=_0x346b5a['_path']['toString'](),_0x1d31fc=new H();return this['restRequest_'](_0x14e22d+'.json',_0x879287,(_0x1dc199,_0x59214b)=>{let _0x1f775f=_0x59214b;_0x1dc199===0x194&&(_0x1f775f=null,_0x1dc199=null),_0x1dc199===null?(this['onDataUpdate_'](_0x14e22d,_0x1f775f,!0x1,null),_0x1d31fc['resolve'](_0x1f775f)):_0x1d31fc['reject'](new Error(_0x1f775f));}),_0x1d31fc['promise'];}['refreshAuthToken'](_0x468953){}['restRequest_'](_0x4db502,_0x176333={},_0xabf537){return _0x176333['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x12c457,_0x3cbae6])=>{_0x12c457&&_0x12c457['accessToken']&&(_0x176333['auth']=_0x12c457['accessToken']),_0x3cbae6&&_0x3cbae6['token']&&(_0x176333['ac']=_0x3cbae6['token']);const _0x4725c9=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4db502+'?ns='+this['repoInfo_']['namespace']+ut(_0x176333);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x4725c9);const _0x4d932d=new XMLHttpRequest();_0x4d932d['onreadystatechange']=()=>{if(_0xabf537&&_0x4d932d['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x4725c9+'\x20received.\x20status:',_0x4d932d['status'],'response:',_0x4d932d['responseText']);let _0x141157=null;if(_0x4d932d['status']>=0xc8&&_0x4d932d['status']<0x12c){try{_0x141157=Nt(_0x4d932d['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x4725c9+':\x20'+_0x4d932d['responseText']);}_0xabf537(null,_0x141157);}else _0x4d932d['status']!==0x191&&_0x4d932d['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x4725c9+'\x20Status:\x20'+_0x4d932d['status']),_0xabf537(_0x4d932d['status']);_0xabf537=null;}},_0x4d932d['open']('GET',_0x4725c9,!0x0),_0x4d932d['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2522ba){return this['rootNode_']['getChild'](_0x2522ba);}['updateSnapshot'](_0x138287,_0x3edf7d){this['rootNode_']=this['rootNode_']['updateChild'](_0x138287,_0x3edf7d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x321106,_0x44625b,_0x166fba){if(v(_0x44625b))_0x321106['value']=_0x166fba,_0x321106['children']['clear']();else{if(_0x321106['value']!==null)_0x321106['value']=_0x321106['value']['updateChild'](_0x44625b,_0x166fba);else{const _0x580fd7=y(_0x44625b);_0x321106['children']['has'](_0x580fd7)||_0x321106['children']['set'](_0x580fd7,En());const _0xaca32e=_0x321106['children']['get'](_0x580fd7);_0x44625b=S(_0x44625b),pt(_0xaca32e,_0x44625b,_0x166fba);}}}function Ti(_0x4bb1d8,_0x15039b){if(v(_0x15039b))return _0x4bb1d8['value']=null,_0x4bb1d8['children']['clear'](),!0x0;if(_0x4bb1d8['value']!==null){if(_0x4bb1d8['value']['isLeafNode']())return!0x1;{const _0x180a0b=_0x4bb1d8['value'];return _0x4bb1d8['value']=null,_0x180a0b['forEachChild'](R,(_0x1c8c7e,_0x3c0e0a)=>{pt(_0x4bb1d8,new C(_0x1c8c7e),_0x3c0e0a);}),Ti(_0x4bb1d8,_0x15039b);}}else{if(_0x4bb1d8['children']['size']>0x0){const _0x1b8e1b=y(_0x15039b);return _0x15039b=S(_0x15039b),_0x4bb1d8['children']['has'](_0x1b8e1b)&&Ti(_0x4bb1d8['children']['get'](_0x1b8e1b),_0x15039b)&&_0x4bb1d8['children']['delete'](_0x1b8e1b),_0x4bb1d8['children']['size']===0x0;}else return!0x0;}}function Si(_0x3c914f,_0xbd88a7,_0x442bcc){_0x3c914f['value']!==null?_0x442bcc(_0xbd88a7,_0x3c914f['value']):Zh(_0x3c914f,(_0x3e08fa,_0x7483a9)=>{const _0x278521=new C(_0xbd88a7['toString']()+'/'+_0x3e08fa);Si(_0x7483a9,_0x278521,_0x442bcc);});}function Zh(_0x3c898f,_0x445f7a){_0x3c898f['children']['forEach']((_0x25ac0f,_0x1c040f)=>{_0x445f7a(_0x1c040f,_0x25ac0f);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x1adff6){this['collection_']=_0x1adff6,this['last_']=null;}['get'](){const _0x11807a=this['collection_']['get'](),_0xa85538={..._0x11807a};return this['last_']&&x(this['last_'],(_0x5580f0,_0x239eb2)=>{_0xa85538[_0x5580f0]=_0xa85538[_0x5580f0]-_0x239eb2;}),this['last_']=_0x11807a,_0xa85538;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0xc2101b,_0x59179b){this['server_']=_0x59179b,this['statsToReport_']={},this['statsListener_']=new eu(_0xc2101b);const _0x5503aa=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x5503aa));}['reportStats_'](){const _0xdf196a=this['statsListener_']['get'](),_0x2f5c5d={};let _0x1f9ac1=!0x1;x(_0xdf196a,(_0x3d39ea,_0x163ff4)=>{_0x163ff4>0x0&&Q(this['statsToReport_'],_0x3d39ea)&&(_0x2f5c5d[_0x3d39ea]=_0x163ff4,_0x1f9ac1=!0x0);}),_0x1f9ac1&&this['server_']['reportStats'](_0x2f5c5d),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0xbe993f){_0xbe993f[_0xbe993f['OVERWRITE']=0x0]='OVERWRITE',_0xbe993f[_0xbe993f['MERGE']=0x1]='MERGE',_0xbe993f[_0xbe993f['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xbe993f[_0xbe993f['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x6ba197){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x6ba197,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x5d0efc,_0x277c44,_0x5b3184){this['path']=_0x5d0efc,this['affectedTree']=_0x277c44,this['revert']=_0x5b3184,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x1d5d0a){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3f5d5d=this['affectedTree']['subtree'](new C(_0x1d5d0a));return new In(w(),_0x3f5d5d,this['revert']);}}else return f(y(this['path'])===_0x1d5d0a,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0xb2692,_0x2c7e8f){this['source']=_0xb2692,this['path']=_0x2c7e8f,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x1a141c){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x182ec3,_0x25c856,_0x44bffb){this['source']=_0x182ec3,this['path']=_0x25c856,this['snap']=_0x44bffb,this['type']=z['OVERWRITE'];}['operationForChild'](_0x40f160){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x40f160)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x6bfa6a,_0x31a087,_0x520755){this['source']=_0x6bfa6a,this['path']=_0x31a087,this['children']=_0x520755,this['type']=z['MERGE'];}['operationForChild'](_0x1a7a19){if(v(this['path'])){const _0x2cb71f=this['children']['subtree'](new C(_0x1a7a19));return _0x2cb71f['isEmpty']()?null:_0x2cb71f['value']?new Be(this['source'],w(),_0x2cb71f['value']):new ot(this['source'],w(),_0x2cb71f);}else return f(y(this['path'])===_0x1a7a19,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x1dfe51,_0x43ba79,_0x10cf7f){this['node_']=_0x1dfe51,this['fullyInitialized_']=_0x43ba79,this['filtered_']=_0x10cf7f;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x3e3c34){if(v(_0x3e3c34))return this['isFullyInitialized']()&&!this['filtered_'];const _0x30df11=y(_0x3e3c34);return this['isCompleteForChild'](_0x30df11);}['isCompleteForChild'](_0x187ccc){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x187ccc);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x81f419){this['query_']=_0x81f419,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x513fe4,_0xc37367,_0x45329e,_0x485e37){const _0x15ca08=[],_0x39eb9a=[];return _0xc37367['forEach'](_0xcbbbc7=>{_0xcbbbc7['type']==='child_changed'&&_0x513fe4['index_']['indexedValueChanged'](_0xcbbbc7['oldSnap'],_0xcbbbc7['snapshotNode'])&&_0x39eb9a['push'](zh(_0xcbbbc7['childName'],_0xcbbbc7['snapshotNode']));}),wt(_0x513fe4,_0x15ca08,'child_removed',_0xc37367,_0x485e37,_0x45329e),wt(_0x513fe4,_0x15ca08,'child_added',_0xc37367,_0x485e37,_0x45329e),wt(_0x513fe4,_0x15ca08,'child_moved',_0x39eb9a,_0x485e37,_0x45329e),wt(_0x513fe4,_0x15ca08,'child_changed',_0xc37367,_0x485e37,_0x45329e),wt(_0x513fe4,_0x15ca08,'value',_0xc37367,_0x485e37,_0x45329e),_0x15ca08;}function wt(_0x2093ea,_0x110fd9,_0x5098ba,_0x4c9ef3,_0x4d81ef,_0x57d93c){const _0x14373e=_0x4c9ef3['filter'](_0x5bf06f=>_0x5bf06f['type']===_0x5098ba);_0x14373e['sort']((_0x3dd93c,_0x444ba8)=>au(_0x2093ea,_0x3dd93c,_0x444ba8)),_0x14373e['forEach'](_0x2e40c2=>{const _0x21ad14=ou(_0x2093ea,_0x2e40c2,_0x57d93c);_0x4d81ef['forEach'](_0x5e20d4=>{_0x5e20d4['respondsTo'](_0x2e40c2['type'])&&_0x110fd9['push'](_0x5e20d4['createEvent'](_0x21ad14,_0x2093ea['query_']));});});}function ou(_0x18318d,_0x5d0992,_0x2f328b){return _0x5d0992['type']==='value'||_0x5d0992['type']==='child_removed'||(_0x5d0992['prevName']=_0x2f328b['getPredecessorChildName'](_0x5d0992['childName'],_0x5d0992['snapshotNode'],_0x18318d['index_'])),_0x5d0992;}function au(_0xf7c24d,_0x3cce52,_0x23c67e){if(_0x3cce52['childName']==null||_0x23c67e['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x257517=new E(_0x3cce52['childName'],_0x3cce52['snapshotNode']),_0x239b35=new E(_0x23c67e['childName'],_0x23c67e['snapshotNode']);return _0xf7c24d['index_']['compare'](_0x257517,_0x239b35);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x5e4d83,_0x20ab45){return{'eventCache':_0x5e4d83,'serverCache':_0x20ab45};}function Rt(_0x38a4e9,_0x24e383,_0x55483b,_0x2fb855){return Un(new Te(_0x24e383,_0x55483b,_0x2fb855),_0x38a4e9['serverCache']);}function Fo(_0x1efe90,_0x16205d,_0xefcea6,_0xde045c){return Un(_0x1efe90['eventCache'],new Te(_0x16205d,_0xefcea6,_0xde045c));}function wn(_0x4ff305){return _0x4ff305['eventCache']['isFullyInitialized']()?_0x4ff305['eventCache']['getNode']():null;}function Ve(_0x7ba1cd){return _0x7ba1cd['serverCache']['isFullyInitialized']()?_0x7ba1cd['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x20b40a){let _0x57dc71=new b(null);return x(_0x20b40a,(_0x5d0b4a,_0x5a102e)=>{_0x57dc71=_0x57dc71['set'](new C(_0x5d0b4a),_0x5a102e);}),_0x57dc71;}constructor(_0x348463,_0xf36226=cu()){this['value']=_0x348463,this['children']=_0xf36226;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x35aa21,_0x182b7a){if(this['value']!=null&&_0x182b7a(this['value']))return{'path':w(),'value':this['value']};if(v(_0x35aa21))return null;{const _0x6a48ae=y(_0x35aa21),_0x2dbac8=this['children']['get'](_0x6a48ae);if(_0x2dbac8!==null){const _0x3b91f5=_0x2dbac8['findRootMostMatchingPathAndValue'](S(_0x35aa21),_0x182b7a);return _0x3b91f5!=null?{'path':k(new C(_0x6a48ae),_0x3b91f5['path']),'value':_0x3b91f5['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x169969){return this['findRootMostMatchingPathAndValue'](_0x169969,()=>!0x0);}['subtree'](_0x11ca83){if(v(_0x11ca83))return this;{const _0x233a18=y(_0x11ca83),_0x3b2b38=this['children']['get'](_0x233a18);return _0x3b2b38!==null?_0x3b2b38['subtree'](S(_0x11ca83)):new b(null);}}['set'](_0xca7738,_0x597d32){if(v(_0xca7738))return new b(_0x597d32,this['children']);{const _0x218876=y(_0xca7738),_0x2a5276=(this['children']['get'](_0x218876)||new b(null))['set'](S(_0xca7738),_0x597d32),_0x4be2d7=this['children']['insert'](_0x218876,_0x2a5276);return new b(this['value'],_0x4be2d7);}}['remove'](_0x19d26d){if(v(_0x19d26d))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x452f65=y(_0x19d26d),_0x730d03=this['children']['get'](_0x452f65);if(_0x730d03){const _0x43ee65=_0x730d03['remove'](S(_0x19d26d));let _0xfd158;return _0x43ee65['isEmpty']()?_0xfd158=this['children']['remove'](_0x452f65):_0xfd158=this['children']['insert'](_0x452f65,_0x43ee65),this['value']===null&&_0xfd158['isEmpty']()?new b(null):new b(this['value'],_0xfd158);}else return this;}}['get'](_0x2032b0){if(v(_0x2032b0))return this['value'];{const _0x16b145=y(_0x2032b0),_0x52ea97=this['children']['get'](_0x16b145);return _0x52ea97?_0x52ea97['get'](S(_0x2032b0)):null;}}['setTree'](_0x29c6c4,_0x13080e){if(v(_0x29c6c4))return _0x13080e;{const _0x2743b3=y(_0x29c6c4),_0xfb2bc=(this['children']['get'](_0x2743b3)||new b(null))['setTree'](S(_0x29c6c4),_0x13080e);let _0x48aa7b;return _0xfb2bc['isEmpty']()?_0x48aa7b=this['children']['remove'](_0x2743b3):_0x48aa7b=this['children']['insert'](_0x2743b3,_0xfb2bc),new b(this['value'],_0x48aa7b);}}['fold'](_0x321be1){return this['fold_'](w(),_0x321be1);}['fold_'](_0x3217b3,_0x164fac){const _0x2a7364={};return this['children']['inorderTraversal']((_0x10d8cb,_0x12d864)=>{_0x2a7364[_0x10d8cb]=_0x12d864['fold_'](k(_0x3217b3,_0x10d8cb),_0x164fac);}),_0x164fac(_0x3217b3,this['value'],_0x2a7364);}['findOnPath'](_0x3da0ae,_0x38666d){return this['findOnPath_'](_0x3da0ae,w(),_0x38666d);}['findOnPath_'](_0x57b70a,_0x3511d3,_0x39a185){const _0x5618e1=this['value']?_0x39a185(_0x3511d3,this['value']):!0x1;if(_0x5618e1)return _0x5618e1;if(v(_0x57b70a))return null;{const _0x19218a=y(_0x57b70a),_0xdabea=this['children']['get'](_0x19218a);return _0xdabea?_0xdabea['findOnPath_'](S(_0x57b70a),k(_0x3511d3,_0x19218a),_0x39a185):null;}}['foreachOnPath'](_0x4113f2,_0x23b30b){return this['foreachOnPath_'](_0x4113f2,w(),_0x23b30b);}['foreachOnPath_'](_0x45733b,_0xbecca8,_0x19607b){if(v(_0x45733b))return this;{this['value']&&_0x19607b(_0xbecca8,this['value']);const _0xdc138b=y(_0x45733b),_0x9c515c=this['children']['get'](_0xdc138b);return _0x9c515c?_0x9c515c['foreachOnPath_'](S(_0x45733b),k(_0xbecca8,_0xdc138b),_0x19607b):new b(null);}}['foreach'](_0x1c8ce0){this['foreach_'](w(),_0x1c8ce0);}['foreach_'](_0x4b6064,_0x6d3dc0){this['children']['inorderTraversal']((_0x1809d7,_0xf4c281)=>{_0xf4c281['foreach_'](k(_0x4b6064,_0x1809d7),_0x6d3dc0);}),this['value']&&_0x6d3dc0(_0x4b6064,this['value']);}['foreachChild'](_0x5ef4a0){this['children']['inorderTraversal']((_0x1f35f6,_0x369be1)=>{_0x369be1['value']&&_0x5ef4a0(_0x1f35f6,_0x369be1['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x1d2c89){this['writeTree_']=_0x1d2c89;}static['empty'](){return new K(new b(null));}}function At(_0x38f79d,_0xd21ecd,_0x1b0463){if(v(_0xd21ecd))return new K(new b(_0x1b0463));{const _0x4642e6=_0x38f79d['writeTree_']['findRootMostValueAndPath'](_0xd21ecd);if(_0x4642e6!=null){const _0x43003d=_0x4642e6['path'];let _0x123120=_0x4642e6['value'];const _0x13f65d=F(_0x43003d,_0xd21ecd);return _0x123120=_0x123120['updateChild'](_0x13f65d,_0x1b0463),new K(_0x38f79d['writeTree_']['set'](_0x43003d,_0x123120));}else{const _0x2fabb5=new b(_0x1b0463),_0x22d89b=_0x38f79d['writeTree_']['setTree'](_0xd21ecd,_0x2fabb5);return new K(_0x22d89b);}}}function bi(_0xfe34aa,_0x27b7da,_0xd946f9){let _0x516c52=_0xfe34aa;return x(_0xd946f9,(_0x3c62f2,_0x4a5e41)=>{_0x516c52=At(_0x516c52,k(_0x27b7da,_0x3c62f2),_0x4a5e41);}),_0x516c52;}function or(_0x12e6de,_0x1124dd){if(v(_0x1124dd))return K['empty']();{const _0xa67e39=_0x12e6de['writeTree_']['setTree'](_0x1124dd,new b(null));return new K(_0xa67e39);}}function Ri(_0x434ab1,_0x47c8c7){return ze(_0x434ab1,_0x47c8c7)!=null;}function ze(_0x1ebc07,_0x48ffe7){const _0x4716a6=_0x1ebc07['writeTree_']['findRootMostValueAndPath'](_0x48ffe7);return _0x4716a6!=null?_0x1ebc07['writeTree_']['get'](_0x4716a6['path'])['getChild'](F(_0x4716a6['path'],_0x48ffe7)):null;}function ar(_0x5c97c4){const _0x2982ea=[],_0x4e0c19=_0x5c97c4['writeTree_']['value'];return _0x4e0c19!=null?_0x4e0c19['isLeafNode']()||_0x4e0c19['forEachChild'](R,(_0x2c32d1,_0x45d0cb)=>{_0x2982ea['push'](new E(_0x2c32d1,_0x45d0cb));}):_0x5c97c4['writeTree_']['children']['inorderTraversal']((_0x529df0,_0x48e367)=>{_0x48e367['value']!=null&&_0x2982ea['push'](new E(_0x529df0,_0x48e367['value']));}),_0x2982ea;}function Ee(_0x439447,_0x313f10){if(v(_0x313f10))return _0x439447;{const _0x52fbb5=ze(_0x439447,_0x313f10);return _0x52fbb5!=null?new K(new b(_0x52fbb5)):new K(_0x439447['writeTree_']['subtree'](_0x313f10));}}function Ai(_0x5ad0db){return _0x5ad0db['writeTree_']['isEmpty']();}function at(_0x267480,_0x55ce40){return Uo(w(),_0x267480['writeTree_'],_0x55ce40);}function Uo(_0x296939,_0x513220,_0x2ac7a9){if(_0x513220['value']!=null)return _0x2ac7a9['updateChild'](_0x296939,_0x513220['value']);{let _0x519a95=null;return _0x513220['children']['inorderTraversal']((_0x157d1c,_0x2abf17)=>{_0x157d1c==='.priority'?(f(_0x2abf17['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x519a95=_0x2abf17['value']):_0x2ac7a9=Uo(k(_0x296939,_0x157d1c),_0x2abf17,_0x2ac7a9);}),!_0x2ac7a9['getChild'](_0x296939)['isEmpty']()&&_0x519a95!==null&&(_0x2ac7a9=_0x2ac7a9['updateChild'](k(_0x296939,'.priority'),_0x519a95)),_0x2ac7a9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x13d2a2,_0x36c694){return Ho(_0x36c694,_0x13d2a2);}function lu(_0xcc9b60,_0x44fba5,_0x2f570b,_0x5ce346,_0x1b72b0){f(_0x5ce346>_0xcc9b60['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1b72b0===void 0x0&&(_0x1b72b0=!0x0),_0xcc9b60['allWrites']['push']({'path':_0x44fba5,'snap':_0x2f570b,'writeId':_0x5ce346,'visible':_0x1b72b0}),_0x1b72b0&&(_0xcc9b60['visibleWrites']=At(_0xcc9b60['visibleWrites'],_0x44fba5,_0x2f570b)),_0xcc9b60['lastWriteId']=_0x5ce346;}function hu(_0x556481,_0x9a6a9a,_0x178fed,_0x1a1a61){f(_0x1a1a61>_0x556481['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x556481['allWrites']['push']({'path':_0x9a6a9a,'children':_0x178fed,'writeId':_0x1a1a61,'visible':!0x0}),_0x556481['visibleWrites']=bi(_0x556481['visibleWrites'],_0x9a6a9a,_0x178fed),_0x556481['lastWriteId']=_0x1a1a61;}function uu(_0x2577c6,_0x3c25a6){for(let _0x55b507=0x0;_0x55b507<_0x2577c6['allWrites']['length'];_0x55b507++){const _0x45a968=_0x2577c6['allWrites'][_0x55b507];if(_0x45a968['writeId']===_0x3c25a6)return _0x45a968;}return null;}function du(_0x3eaf7c,_0x2a9a11){const _0x2f312a=_0x3eaf7c['allWrites']['findIndex'](_0x927d83=>_0x927d83['writeId']===_0x2a9a11);f(_0x2f312a>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x120da8=_0x3eaf7c['allWrites'][_0x2f312a];_0x3eaf7c['allWrites']['splice'](_0x2f312a,0x1);let _0x3f5990=_0x120da8['visible'],_0x3e2c59=!0x1,_0x1824f5=_0x3eaf7c['allWrites']['length']-0x1;for(;_0x3f5990&&_0x1824f5>=0x0;){const _0x3577e9=_0x3eaf7c['allWrites'][_0x1824f5];_0x3577e9['visible']&&(_0x1824f5>=_0x2f312a&&fu(_0x3577e9,_0x120da8['path'])?_0x3f5990=!0x1:G(_0x120da8['path'],_0x3577e9['path'])&&(_0x3e2c59=!0x0)),_0x1824f5--;}if(_0x3f5990){if(_0x3e2c59)return pu(_0x3eaf7c),!0x0;if(_0x120da8['snap'])_0x3eaf7c['visibleWrites']=or(_0x3eaf7c['visibleWrites'],_0x120da8['path']);else{const _0x110624=_0x120da8['children'];x(_0x110624,_0x434527=>{_0x3eaf7c['visibleWrites']=or(_0x3eaf7c['visibleWrites'],k(_0x120da8['path'],_0x434527));});}return!0x0;}else return!0x1;}function fu(_0x13328d,_0x2e6351){if(_0x13328d['snap'])return G(_0x13328d['path'],_0x2e6351);for(const _0x51ac7b in _0x13328d['children'])if(_0x13328d['children']['hasOwnProperty'](_0x51ac7b)&&G(k(_0x13328d['path'],_0x51ac7b),_0x2e6351))return!0x0;return!0x1;}function pu(_0x510a1){_0x510a1['visibleWrites']=Wo(_0x510a1['allWrites'],_u,w()),_0x510a1['allWrites']['length']>0x0?_0x510a1['lastWriteId']=_0x510a1['allWrites'][_0x510a1['allWrites']['length']-0x1]['writeId']:_0x510a1['lastWriteId']=-0x1;}function _u(_0x17f6dc){return _0x17f6dc['visible'];}function Wo(_0x160086,_0x1f0c22,_0x3e9c3c){let _0x144e11=K['empty']();for(let _0x3c6d74=0x0;_0x3c6d74<_0x160086['length'];++_0x3c6d74){const _0x5a8769=_0x160086[_0x3c6d74];if(_0x1f0c22(_0x5a8769)){const _0x1ffbdb=_0x5a8769['path'];let _0x3066cd;if(_0x5a8769['snap'])G(_0x3e9c3c,_0x1ffbdb)?(_0x3066cd=F(_0x3e9c3c,_0x1ffbdb),_0x144e11=At(_0x144e11,_0x3066cd,_0x5a8769['snap'])):G(_0x1ffbdb,_0x3e9c3c)&&(_0x3066cd=F(_0x1ffbdb,_0x3e9c3c),_0x144e11=At(_0x144e11,w(),_0x5a8769['snap']['getChild'](_0x3066cd)));else{if(_0x5a8769['children']){if(G(_0x3e9c3c,_0x1ffbdb))_0x3066cd=F(_0x3e9c3c,_0x1ffbdb),_0x144e11=bi(_0x144e11,_0x3066cd,_0x5a8769['children']);else{if(G(_0x1ffbdb,_0x3e9c3c)){if(_0x3066cd=F(_0x1ffbdb,_0x3e9c3c),v(_0x3066cd))_0x144e11=bi(_0x144e11,w(),_0x5a8769['children']);else{const _0x1dfd02=Le(_0x5a8769['children'],y(_0x3066cd));if(_0x1dfd02){const _0x5b178b=_0x1dfd02['getChild'](S(_0x3066cd));_0x144e11=At(_0x144e11,w(),_0x5b178b);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x144e11;}function Bo(_0x500387,_0x39c6a6,_0x5a057e,_0x33ca8b,_0x1daca1){if(!_0x33ca8b&&!_0x1daca1){const _0x22cecd=ze(_0x500387['visibleWrites'],_0x39c6a6);if(_0x22cecd!=null)return _0x22cecd;{const _0x3c31d9=Ee(_0x500387['visibleWrites'],_0x39c6a6);if(Ai(_0x3c31d9))return _0x5a057e;if(_0x5a057e==null&&!Ri(_0x3c31d9,w()))return null;{const _0x184ac8=_0x5a057e||g['EMPTY_NODE'];return at(_0x3c31d9,_0x184ac8);}}}else{const _0x1bbb7f=Ee(_0x500387['visibleWrites'],_0x39c6a6);if(!_0x1daca1&&Ai(_0x1bbb7f))return _0x5a057e;if(!_0x1daca1&&_0x5a057e==null&&!Ri(_0x1bbb7f,w()))return null;{const _0x4bd7b6=function(_0x20fc49){return(_0x20fc49['visible']||_0x1daca1)&&(!_0x33ca8b||!~_0x33ca8b['indexOf'](_0x20fc49['writeId']))&&(G(_0x20fc49['path'],_0x39c6a6)||G(_0x39c6a6,_0x20fc49['path']));},_0x2cd591=Wo(_0x500387['allWrites'],_0x4bd7b6,_0x39c6a6),_0x16b4da=_0x5a057e||g['EMPTY_NODE'];return at(_0x2cd591,_0x16b4da);}}}function gu(_0xea3904,_0x50b9ce,_0x1d42ff){let _0x5c30f6=g['EMPTY_NODE'];const _0x58609e=ze(_0xea3904['visibleWrites'],_0x50b9ce);if(_0x58609e)return _0x58609e['isLeafNode']()||_0x58609e['forEachChild'](R,(_0x5cb116,_0x2f3f0b)=>{_0x5c30f6=_0x5c30f6['updateImmediateChild'](_0x5cb116,_0x2f3f0b);}),_0x5c30f6;if(_0x1d42ff){const _0x50da02=Ee(_0xea3904['visibleWrites'],_0x50b9ce);return _0x1d42ff['forEachChild'](R,(_0x29fc7e,_0x111c62)=>{const _0x287c9d=at(Ee(_0x50da02,new C(_0x29fc7e)),_0x111c62);_0x5c30f6=_0x5c30f6['updateImmediateChild'](_0x29fc7e,_0x287c9d);}),ar(_0x50da02)['forEach'](_0x30d3aa=>{_0x5c30f6=_0x5c30f6['updateImmediateChild'](_0x30d3aa['name'],_0x30d3aa['node']);}),_0x5c30f6;}else{const _0x355a52=Ee(_0xea3904['visibleWrites'],_0x50b9ce);return ar(_0x355a52)['forEach'](_0x3c91c6=>{_0x5c30f6=_0x5c30f6['updateImmediateChild'](_0x3c91c6['name'],_0x3c91c6['node']);}),_0x5c30f6;}}function mu(_0x198c28,_0x3b8d8b,_0x4b16d9,_0x52b225,_0x83c565){f(_0x52b225||_0x83c565,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0xa840fc=k(_0x3b8d8b,_0x4b16d9);if(Ri(_0x198c28['visibleWrites'],_0xa840fc))return null;{const _0x5028c6=Ee(_0x198c28['visibleWrites'],_0xa840fc);return Ai(_0x5028c6)?_0x83c565['getChild'](_0x4b16d9):at(_0x5028c6,_0x83c565['getChild'](_0x4b16d9));}}function yu(_0x78d56a,_0x44ac80,_0x316c57,_0xee69dd){const _0x6b58c=k(_0x44ac80,_0x316c57),_0x356874=ze(_0x78d56a['visibleWrites'],_0x6b58c);if(_0x356874!=null)return _0x356874;if(_0xee69dd['isCompleteForChild'](_0x316c57)){const _0x207bc6=Ee(_0x78d56a['visibleWrites'],_0x6b58c);return at(_0x207bc6,_0xee69dd['getNode']()['getImmediateChild'](_0x316c57));}else return null;}function vu(_0x1d177f,_0x5c6fd9){return ze(_0x1d177f['visibleWrites'],_0x5c6fd9);}function Eu(_0x520f4c,_0x219d04,_0x46f594,_0x3f3ecc,_0x33ffa9,_0x45dcc7,_0x5cc4fa){let _0x5526bd;const _0x10293f=Ee(_0x520f4c['visibleWrites'],_0x219d04),_0x9843ab=ze(_0x10293f,w());if(_0x9843ab!=null)_0x5526bd=_0x9843ab;else{if(_0x46f594!=null)_0x5526bd=at(_0x10293f,_0x46f594);else return[];}if(_0x5526bd=_0x5526bd['withIndex'](_0x5cc4fa),!_0x5526bd['isEmpty']()&&!_0x5526bd['isLeafNode']()){const _0x1337ed=[],_0x38fb45=_0x5cc4fa['getCompare'](),_0x239898=_0x45dcc7?_0x5526bd['getReverseIteratorFrom'](_0x3f3ecc,_0x5cc4fa):_0x5526bd['getIteratorFrom'](_0x3f3ecc,_0x5cc4fa);let _0xebc206=_0x239898['getNext']();for(;_0xebc206&&_0x1337ed['length']<_0x33ffa9;)_0x38fb45(_0xebc206,_0x3f3ecc)!==0x0&&_0x1337ed['push'](_0xebc206),_0xebc206=_0x239898['getNext']();return _0x1337ed;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x197a31,_0x511d8b,_0x3f3c92,_0xe4f670){return Bo(_0x197a31['writeTree'],_0x197a31['treePath'],_0x511d8b,_0x3f3c92,_0xe4f670);}function is(_0x2e4af4,_0x423493){return gu(_0x2e4af4['writeTree'],_0x2e4af4['treePath'],_0x423493);}function cr(_0x431705,_0x3dfa29,_0x493f7c,_0x599e2d){return mu(_0x431705['writeTree'],_0x431705['treePath'],_0x3dfa29,_0x493f7c,_0x599e2d);}function Tn(_0x2b2839,_0x292948){return vu(_0x2b2839['writeTree'],k(_0x2b2839['treePath'],_0x292948));}function wu(_0x3bd97b,_0x506ec7,_0x88f930,_0x581704,_0x3b4685,_0x71544){return Eu(_0x3bd97b['writeTree'],_0x3bd97b['treePath'],_0x506ec7,_0x88f930,_0x581704,_0x3b4685,_0x71544);}function ss(_0x1fe404,_0x5f1945,_0x509996){return yu(_0x1fe404['writeTree'],_0x1fe404['treePath'],_0x5f1945,_0x509996);}function Vo(_0x3c3438,_0x362388){return Ho(k(_0x3c3438['treePath'],_0x362388),_0x3c3438['writeTree']);}function Ho(_0x16bacb,_0x5960c1){return{'treePath':_0x16bacb,'writeTree':_0x5960c1};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x27c714){const _0x1d55d1=_0x27c714['type'],_0x47752e=_0x27c714['childName'];f(_0x1d55d1==='child_added'||_0x1d55d1==='child_changed'||_0x1d55d1==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x47752e!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4a4ec9=this['changeMap']['get'](_0x47752e);if(_0x4a4ec9){const _0x5bf3f3=_0x4a4ec9['type'];if(_0x1d55d1==='child_added'&&_0x5bf3f3==='child_removed')this['changeMap']['set'](_0x47752e,xt(_0x47752e,_0x27c714['snapshotNode'],_0x4a4ec9['snapshotNode']));else{if(_0x1d55d1==='child_removed'&&_0x5bf3f3==='child_added')this['changeMap']['delete'](_0x47752e);else{if(_0x1d55d1==='child_removed'&&_0x5bf3f3==='child_changed')this['changeMap']['set'](_0x47752e,Lt(_0x47752e,_0x4a4ec9['oldSnap']));else{if(_0x1d55d1==='child_changed'&&_0x5bf3f3==='child_added')this['changeMap']['set'](_0x47752e,rt(_0x47752e,_0x27c714['snapshotNode']));else{if(_0x1d55d1==='child_changed'&&_0x5bf3f3==='child_changed')this['changeMap']['set'](_0x47752e,xt(_0x47752e,_0x27c714['snapshotNode'],_0x4a4ec9['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x27c714+'\x20occurred\x20after\x20'+_0x4a4ec9);}}}}}else this['changeMap']['set'](_0x47752e,_0x27c714);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x2c6ce7){return null;}['getChildAfterChild'](_0x2dfe4e,_0x2c12a,_0x5b9e8e){return null;}}const $o=new Tu();class rs{constructor(_0x33f89a,_0x136125,_0x18c950=null){this['writes_']=_0x33f89a,this['viewCache_']=_0x136125,this['optCompleteServerCache_']=_0x18c950;}['getCompleteChild'](_0x5921c6){const _0x1fd3b4=this['viewCache_']['eventCache'];if(_0x1fd3b4['isCompleteForChild'](_0x5921c6))return _0x1fd3b4['getNode']()['getImmediateChild'](_0x5921c6);{const _0x5717b6=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x5921c6,_0x5717b6);}}['getChildAfterChild'](_0x57805d,_0x2fd493,_0x58145b){const _0x4dd19d=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x17beb9=wu(this['writes_'],_0x4dd19d,_0x2fd493,0x1,_0x58145b,_0x57805d);return _0x17beb9['length']===0x0?null:_0x17beb9[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x2385ee){return{'filter':_0x2385ee};}function bu(_0x150936,_0x3477ff){f(_0x3477ff['eventCache']['getNode']()['isIndexed'](_0x150936['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3477ff['serverCache']['getNode']()['isIndexed'](_0x150936['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x20f0ee,_0x15e7b6,_0x45bd1f,_0x2cc9be,_0x5dc817){const _0x1b53ba=new Cu();let _0x843cb7,_0x326b0b;if(_0x45bd1f['type']===z['OVERWRITE']){const _0x54a29d=_0x45bd1f;_0x54a29d['source']['fromUser']?_0x843cb7=ki(_0x20f0ee,_0x15e7b6,_0x54a29d['path'],_0x54a29d['snap'],_0x2cc9be,_0x5dc817,_0x1b53ba):(f(_0x54a29d['source']['fromServer'],'Unknown\x20source.'),_0x326b0b=_0x54a29d['source']['tagged']||_0x15e7b6['serverCache']['isFiltered']()&&!v(_0x54a29d['path']),_0x843cb7=Sn(_0x20f0ee,_0x15e7b6,_0x54a29d['path'],_0x54a29d['snap'],_0x2cc9be,_0x5dc817,_0x326b0b,_0x1b53ba));}else{if(_0x45bd1f['type']===z['MERGE']){const _0x2ff80b=_0x45bd1f;_0x2ff80b['source']['fromUser']?_0x843cb7=ku(_0x20f0ee,_0x15e7b6,_0x2ff80b['path'],_0x2ff80b['children'],_0x2cc9be,_0x5dc817,_0x1b53ba):(f(_0x2ff80b['source']['fromServer'],'Unknown\x20source.'),_0x326b0b=_0x2ff80b['source']['tagged']||_0x15e7b6['serverCache']['isFiltered'](),_0x843cb7=Pi(_0x20f0ee,_0x15e7b6,_0x2ff80b['path'],_0x2ff80b['children'],_0x2cc9be,_0x5dc817,_0x326b0b,_0x1b53ba));}else{if(_0x45bd1f['type']===z['ACK_USER_WRITE']){const _0x493928=_0x45bd1f;_0x493928['revert']?_0x843cb7=Ou(_0x20f0ee,_0x15e7b6,_0x493928['path'],_0x2cc9be,_0x5dc817,_0x1b53ba):_0x843cb7=Pu(_0x20f0ee,_0x15e7b6,_0x493928['path'],_0x493928['affectedTree'],_0x2cc9be,_0x5dc817,_0x1b53ba);}else{if(_0x45bd1f['type']===z['LISTEN_COMPLETE'])_0x843cb7=Nu(_0x20f0ee,_0x15e7b6,_0x45bd1f['path'],_0x2cc9be,_0x1b53ba);else throw ht('Unknown\x20operation\x20type:\x20'+_0x45bd1f['type']);}}}const _0x470a50=_0x1b53ba['getChanges']();return Au(_0x15e7b6,_0x843cb7,_0x470a50),{'viewCache':_0x843cb7,'changes':_0x470a50};}function Au(_0x50f16f,_0x49a6c7,_0x2f9521){const _0x93a7c8=_0x49a6c7['eventCache'];if(_0x93a7c8['isFullyInitialized']()){const _0x5e58bf=_0x93a7c8['getNode']()['isLeafNode']()||_0x93a7c8['getNode']()['isEmpty'](),_0x41de87=wn(_0x50f16f);(_0x2f9521['length']>0x0||!_0x50f16f['eventCache']['isFullyInitialized']()||_0x5e58bf&&!_0x93a7c8['getNode']()['equals'](_0x41de87)||!_0x93a7c8['getNode']()['getPriority']()['equals'](_0x41de87['getPriority']()))&&_0x2f9521['push'](Lo(wn(_0x49a6c7)));}}function Go(_0x456e78,_0xd4b692,_0x1e4e2c,_0x432252,_0x14724d,_0x295c3a){const _0x11940f=_0xd4b692['eventCache'];if(Tn(_0x432252,_0x1e4e2c)!=null)return _0xd4b692;{let _0xfec3d5,_0x2f5eaf;if(v(_0x1e4e2c)){if(f(_0xd4b692['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xd4b692['serverCache']['isFiltered']()){const _0x2a39f4=Ve(_0xd4b692),_0x205704=_0x2a39f4 instanceof g?_0x2a39f4:g['EMPTY_NODE'],_0x496c7b=is(_0x432252,_0x205704);_0xfec3d5=_0x456e78['filter']['updateFullNode'](_0xd4b692['eventCache']['getNode'](),_0x496c7b,_0x295c3a);}else{const _0x4496d0=Cn(_0x432252,Ve(_0xd4b692));_0xfec3d5=_0x456e78['filter']['updateFullNode'](_0xd4b692['eventCache']['getNode'](),_0x4496d0,_0x295c3a);}}else{const _0x2a82f7=y(_0x1e4e2c);if(_0x2a82f7==='.priority'){f(Ce(_0x1e4e2c)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x58d6f1=_0x11940f['getNode']();_0x2f5eaf=_0xd4b692['serverCache']['getNode']();const _0x56b9fa=cr(_0x432252,_0x1e4e2c,_0x58d6f1,_0x2f5eaf);_0x56b9fa!=null?_0xfec3d5=_0x456e78['filter']['updatePriority'](_0x58d6f1,_0x56b9fa):_0xfec3d5=_0x11940f['getNode']();}else{const _0x364ec0=S(_0x1e4e2c);let _0x29469d;if(_0x11940f['isCompleteForChild'](_0x2a82f7)){_0x2f5eaf=_0xd4b692['serverCache']['getNode']();const _0x57eced=cr(_0x432252,_0x1e4e2c,_0x11940f['getNode'](),_0x2f5eaf);_0x57eced!=null?_0x29469d=_0x11940f['getNode']()['getImmediateChild'](_0x2a82f7)['updateChild'](_0x364ec0,_0x57eced):_0x29469d=_0x11940f['getNode']()['getImmediateChild'](_0x2a82f7);}else _0x29469d=ss(_0x432252,_0x2a82f7,_0xd4b692['serverCache']);_0x29469d!=null?_0xfec3d5=_0x456e78['filter']['updateChild'](_0x11940f['getNode'](),_0x2a82f7,_0x29469d,_0x364ec0,_0x14724d,_0x295c3a):_0xfec3d5=_0x11940f['getNode']();}}return Rt(_0xd4b692,_0xfec3d5,_0x11940f['isFullyInitialized']()||v(_0x1e4e2c),_0x456e78['filter']['filtersNodes']());}}function Sn(_0x2c996e,_0xfbe838,_0x1917e9,_0x55e433,_0x5bef15,_0x345c9b,_0x4ae168,_0x2c4ee7){const _0x446755=_0xfbe838['serverCache'];let _0x5845b5;const _0x21431b=_0x4ae168?_0x2c996e['filter']:_0x2c996e['filter']['getIndexedFilter']();if(v(_0x1917e9))_0x5845b5=_0x21431b['updateFullNode'](_0x446755['getNode'](),_0x55e433,null);else{if(_0x21431b['filtersNodes']()&&!_0x446755['isFiltered']()){const _0x2ad79f=_0x446755['getNode']()['updateChild'](_0x1917e9,_0x55e433);_0x5845b5=_0x21431b['updateFullNode'](_0x446755['getNode'](),_0x2ad79f,null);}else{const _0x2db5ad=y(_0x1917e9);if(!_0x446755['isCompleteForPath'](_0x1917e9)&&Ce(_0x1917e9)>0x1)return _0xfbe838;const _0x44d158=S(_0x1917e9),_0xa3bb2a=_0x446755['getNode']()['getImmediateChild'](_0x2db5ad)['updateChild'](_0x44d158,_0x55e433);_0x2db5ad==='.priority'?_0x5845b5=_0x21431b['updatePriority'](_0x446755['getNode'](),_0xa3bb2a):_0x5845b5=_0x21431b['updateChild'](_0x446755['getNode'](),_0x2db5ad,_0xa3bb2a,_0x44d158,$o,null);}}const _0xeef4df=Fo(_0xfbe838,_0x5845b5,_0x446755['isFullyInitialized']()||v(_0x1917e9),_0x21431b['filtersNodes']()),_0x44a5da=new rs(_0x5bef15,_0xeef4df,_0x345c9b);return Go(_0x2c996e,_0xeef4df,_0x1917e9,_0x5bef15,_0x44a5da,_0x2c4ee7);}function ki(_0x578f72,_0x5bd62e,_0x40ed93,_0x2c5b60,_0x9cc684,_0x55b8d8,_0x34fcf9){const _0x19a6f2=_0x5bd62e['eventCache'];let _0x509a08,_0x5986ae;const _0x3a6420=new rs(_0x9cc684,_0x5bd62e,_0x55b8d8);if(v(_0x40ed93))_0x5986ae=_0x578f72['filter']['updateFullNode'](_0x5bd62e['eventCache']['getNode'](),_0x2c5b60,_0x34fcf9),_0x509a08=Rt(_0x5bd62e,_0x5986ae,!0x0,_0x578f72['filter']['filtersNodes']());else{const _0x26285f=y(_0x40ed93);if(_0x26285f==='.priority')_0x5986ae=_0x578f72['filter']['updatePriority'](_0x5bd62e['eventCache']['getNode'](),_0x2c5b60),_0x509a08=Rt(_0x5bd62e,_0x5986ae,_0x19a6f2['isFullyInitialized'](),_0x19a6f2['isFiltered']());else{const _0x631b03=S(_0x40ed93),_0x31224a=_0x19a6f2['getNode']()['getImmediateChild'](_0x26285f);let _0x2a9389;if(v(_0x631b03))_0x2a9389=_0x2c5b60;else{const _0x2b30b5=_0x3a6420['getCompleteChild'](_0x26285f);_0x2b30b5!=null?ji(_0x631b03)==='.priority'&&_0x2b30b5['getChild'](Ro(_0x631b03))['isEmpty']()?_0x2a9389=_0x2b30b5:_0x2a9389=_0x2b30b5['updateChild'](_0x631b03,_0x2c5b60):_0x2a9389=g['EMPTY_NODE'];}if(_0x31224a['equals'](_0x2a9389))_0x509a08=_0x5bd62e;else{const _0x2950d1=_0x578f72['filter']['updateChild'](_0x19a6f2['getNode'](),_0x26285f,_0x2a9389,_0x631b03,_0x3a6420,_0x34fcf9);_0x509a08=Rt(_0x5bd62e,_0x2950d1,_0x19a6f2['isFullyInitialized'](),_0x578f72['filter']['filtersNodes']());}}}return _0x509a08;}function lr(_0x76b84b,_0x1c009f){return _0x76b84b['eventCache']['isCompleteForChild'](_0x1c009f);}function ku(_0x515e4e,_0x825811,_0x24029f,_0x269642,_0x1b50d6,_0x5784e4,_0x32b06b){let _0x4a210a=_0x825811;return _0x269642['foreach']((_0x110f7e,_0x5c4b97)=>{const _0x575d8c=k(_0x24029f,_0x110f7e);lr(_0x825811,y(_0x575d8c))&&(_0x4a210a=ki(_0x515e4e,_0x4a210a,_0x575d8c,_0x5c4b97,_0x1b50d6,_0x5784e4,_0x32b06b));}),_0x269642['foreach']((_0x15ce73,_0x214860)=>{const _0x551419=k(_0x24029f,_0x15ce73);lr(_0x825811,y(_0x551419))||(_0x4a210a=ki(_0x515e4e,_0x4a210a,_0x551419,_0x214860,_0x1b50d6,_0x5784e4,_0x32b06b));}),_0x4a210a;}function hr(_0x20e1c8,_0x454e21,_0x26242f){return _0x26242f['foreach']((_0x7426c7,_0x1346ac)=>{_0x454e21=_0x454e21['updateChild'](_0x7426c7,_0x1346ac);}),_0x454e21;}function Pi(_0x1ff55b,_0x401b1b,_0x1c14c7,_0x3ffea9,_0x2ae47d,_0x43dbe0,_0x5a38e1,_0x37c5d9){if(_0x401b1b['serverCache']['getNode']()['isEmpty']()&&!_0x401b1b['serverCache']['isFullyInitialized']())return _0x401b1b;let _0x2ba754=_0x401b1b,_0x1ed09e;v(_0x1c14c7)?_0x1ed09e=_0x3ffea9:_0x1ed09e=new b(null)['setTree'](_0x1c14c7,_0x3ffea9);const _0x2e821c=_0x401b1b['serverCache']['getNode']();return _0x1ed09e['children']['inorderTraversal']((_0x17f189,_0x3ddf96)=>{if(_0x2e821c['hasChild'](_0x17f189)){const _0x45d0f7=_0x401b1b['serverCache']['getNode']()['getImmediateChild'](_0x17f189),_0x15a32b=hr(_0x1ff55b,_0x45d0f7,_0x3ddf96);_0x2ba754=Sn(_0x1ff55b,_0x2ba754,new C(_0x17f189),_0x15a32b,_0x2ae47d,_0x43dbe0,_0x5a38e1,_0x37c5d9);}}),_0x1ed09e['children']['inorderTraversal']((_0x48dfe1,_0x3c43fb)=>{const _0x2a1bfd=!_0x401b1b['serverCache']['isCompleteForChild'](_0x48dfe1)&&_0x3c43fb['value']===null;if(!_0x2e821c['hasChild'](_0x48dfe1)&&!_0x2a1bfd){const _0x4ef6dd=_0x401b1b['serverCache']['getNode']()['getImmediateChild'](_0x48dfe1),_0x3566b6=hr(_0x1ff55b,_0x4ef6dd,_0x3c43fb);_0x2ba754=Sn(_0x1ff55b,_0x2ba754,new C(_0x48dfe1),_0x3566b6,_0x2ae47d,_0x43dbe0,_0x5a38e1,_0x37c5d9);}}),_0x2ba754;}function Pu(_0x249288,_0x42164a,_0x15aa45,_0x28290a,_0x27cf5b,_0x31d391,_0x242146){if(Tn(_0x27cf5b,_0x15aa45)!=null)return _0x42164a;const _0x2928d2=_0x42164a['serverCache']['isFiltered'](),_0x58f2b7=_0x42164a['serverCache'];if(_0x28290a['value']!=null){if(v(_0x15aa45)&&_0x58f2b7['isFullyInitialized']()||_0x58f2b7['isCompleteForPath'](_0x15aa45))return Sn(_0x249288,_0x42164a,_0x15aa45,_0x58f2b7['getNode']()['getChild'](_0x15aa45),_0x27cf5b,_0x31d391,_0x2928d2,_0x242146);if(v(_0x15aa45)){let _0x25415e=new b(null);return _0x58f2b7['getNode']()['forEachChild'](ve,(_0x30d912,_0x171376)=>{_0x25415e=_0x25415e['set'](new C(_0x30d912),_0x171376);}),Pi(_0x249288,_0x42164a,_0x15aa45,_0x25415e,_0x27cf5b,_0x31d391,_0x2928d2,_0x242146);}else return _0x42164a;}else{let _0xb2a996=new b(null);return _0x28290a['foreach']((_0x28ded9,_0x12b8b2)=>{const _0x563961=k(_0x15aa45,_0x28ded9);_0x58f2b7['isCompleteForPath'](_0x563961)&&(_0xb2a996=_0xb2a996['set'](_0x28ded9,_0x58f2b7['getNode']()['getChild'](_0x563961)));}),Pi(_0x249288,_0x42164a,_0x15aa45,_0xb2a996,_0x27cf5b,_0x31d391,_0x2928d2,_0x242146);}}function Nu(_0x7ea630,_0x1fb059,_0x46b3ea,_0x244cc3,_0x29e0bc){const _0x4fbd75=_0x1fb059['serverCache'],_0x16d17d=Fo(_0x1fb059,_0x4fbd75['getNode'](),_0x4fbd75['isFullyInitialized']()||v(_0x46b3ea),_0x4fbd75['isFiltered']());return Go(_0x7ea630,_0x16d17d,_0x46b3ea,_0x244cc3,$o,_0x29e0bc);}function Ou(_0x21cda6,_0xac6b2,_0x2d9181,_0x2cc115,_0x12f212,_0x272926){let _0x4ff1bc;if(Tn(_0x2cc115,_0x2d9181)!=null)return _0xac6b2;{const _0x2851a9=new rs(_0x2cc115,_0xac6b2,_0x12f212),_0x2705cb=_0xac6b2['eventCache']['getNode']();let _0x148a2f;if(v(_0x2d9181)||y(_0x2d9181)==='.priority'){let _0x45e482;if(_0xac6b2['serverCache']['isFullyInitialized']())_0x45e482=Cn(_0x2cc115,Ve(_0xac6b2));else{const _0x1631aa=_0xac6b2['serverCache']['getNode']();f(_0x1631aa instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x45e482=is(_0x2cc115,_0x1631aa);}_0x45e482=_0x45e482,_0x148a2f=_0x21cda6['filter']['updateFullNode'](_0x2705cb,_0x45e482,_0x272926);}else{const _0x313fee=y(_0x2d9181);let _0x234be4=ss(_0x2cc115,_0x313fee,_0xac6b2['serverCache']);_0x234be4==null&&_0xac6b2['serverCache']['isCompleteForChild'](_0x313fee)&&(_0x234be4=_0x2705cb['getImmediateChild'](_0x313fee)),_0x234be4!=null?_0x148a2f=_0x21cda6['filter']['updateChild'](_0x2705cb,_0x313fee,_0x234be4,S(_0x2d9181),_0x2851a9,_0x272926):_0xac6b2['eventCache']['getNode']()['hasChild'](_0x313fee)?_0x148a2f=_0x21cda6['filter']['updateChild'](_0x2705cb,_0x313fee,g['EMPTY_NODE'],S(_0x2d9181),_0x2851a9,_0x272926):_0x148a2f=_0x2705cb,_0x148a2f['isEmpty']()&&_0xac6b2['serverCache']['isFullyInitialized']()&&(_0x4ff1bc=Cn(_0x2cc115,Ve(_0xac6b2)),_0x4ff1bc['isLeafNode']()&&(_0x148a2f=_0x21cda6['filter']['updateFullNode'](_0x148a2f,_0x4ff1bc,_0x272926)));}return _0x4ff1bc=_0xac6b2['serverCache']['isFullyInitialized']()||Tn(_0x2cc115,w())!=null,Rt(_0xac6b2,_0x148a2f,_0x4ff1bc,_0x21cda6['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x1ef033,_0x16f36b){this['query_']=_0x1ef033,this['eventRegistrations_']=[];const _0x3e0d65=this['query_']['_queryParams'],_0x5c3ae4=new Xi(_0x3e0d65['getIndex']()),_0x394ff2=Kh(_0x3e0d65);this['processor_']=Su(_0x394ff2);const _0x573269=_0x16f36b['serverCache'],_0x208d31=_0x16f36b['eventCache'],_0x190f28=_0x5c3ae4['updateFullNode'](g['EMPTY_NODE'],_0x573269['getNode'](),null),_0x294d0e=_0x394ff2['updateFullNode'](g['EMPTY_NODE'],_0x208d31['getNode'](),null),_0x2c3143=new Te(_0x190f28,_0x573269['isFullyInitialized'](),_0x5c3ae4['filtersNodes']()),_0x56a3dc=new Te(_0x294d0e,_0x208d31['isFullyInitialized'](),_0x394ff2['filtersNodes']());this['viewCache_']=Un(_0x56a3dc,_0x2c3143),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x37055f){return _0x37055f['viewCache_']['serverCache']['getNode']();}function Lu(_0x5a0d9d){return wn(_0x5a0d9d['viewCache_']);}function xu(_0x128772,_0x475d32){const _0x5dabca=Ve(_0x128772['viewCache_']);return _0x5dabca&&(_0x128772['query']['_queryParams']['loadsAllData']()||!v(_0x475d32)&&!_0x5dabca['getImmediateChild'](y(_0x475d32))['isEmpty']())?_0x5dabca['getChild'](_0x475d32):null;}function ur(_0x76054e){return _0x76054e['eventRegistrations_']['length']===0x0;}function Fu(_0x22e07f,_0x219f89){_0x22e07f['eventRegistrations_']['push'](_0x219f89);}function dr(_0x1fc87c,_0x4f3d2f,_0x8cbf0d){const _0x418bea=[];if(_0x8cbf0d){f(_0x4f3d2f==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2939eb=_0x1fc87c['query']['_path'];_0x1fc87c['eventRegistrations_']['forEach'](_0x2c20cf=>{const _0x65b185=_0x2c20cf['createCancelEvent'](_0x8cbf0d,_0x2939eb);_0x65b185&&_0x418bea['push'](_0x65b185);});}if(_0x4f3d2f){let _0x27d22f=[];for(let _0x35af45=0x0;_0x35af45<_0x1fc87c['eventRegistrations_']['length'];++_0x35af45){const _0x4f998c=_0x1fc87c['eventRegistrations_'][_0x35af45];if(!_0x4f998c['matches'](_0x4f3d2f))_0x27d22f['push'](_0x4f998c);else{if(_0x4f3d2f['hasAnyCallback']()){_0x27d22f=_0x27d22f['concat'](_0x1fc87c['eventRegistrations_']['slice'](_0x35af45+0x1));break;}}}_0x1fc87c['eventRegistrations_']=_0x27d22f;}else _0x1fc87c['eventRegistrations_']=[];return _0x418bea;}function fr(_0x325211,_0x1b01cd,_0x1a0ed7,_0x3f31df){_0x1b01cd['type']===z['MERGE']&&_0x1b01cd['source']['queryId']!==null&&(f(Ve(_0x325211['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x325211['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5315ae=_0x325211['viewCache_'],_0x2210c6=Ru(_0x325211['processor_'],_0x5315ae,_0x1b01cd,_0x1a0ed7,_0x3f31df);return bu(_0x325211['processor_'],_0x2210c6['viewCache']),f(_0x2210c6['viewCache']['serverCache']['isFullyInitialized']()||!_0x5315ae['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x325211['viewCache_']=_0x2210c6['viewCache'],qo(_0x325211,_0x2210c6['changes'],_0x2210c6['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x37ebf1,_0x157c7e){const _0x500072=_0x37ebf1['viewCache_']['eventCache'],_0x4ec31f=[];return _0x500072['getNode']()['isLeafNode']()||_0x500072['getNode']()['forEachChild'](R,(_0x41029c,_0x50e095)=>{_0x4ec31f['push'](rt(_0x41029c,_0x50e095));}),_0x500072['isFullyInitialized']()&&_0x4ec31f['push'](Lo(_0x500072['getNode']())),qo(_0x37ebf1,_0x4ec31f,_0x500072['getNode'](),_0x157c7e);}function qo(_0x8f2598,_0x592df3,_0x5ca59b,_0x15ff9f){const _0x5f02dc=_0x15ff9f?[_0x15ff9f]:_0x8f2598['eventRegistrations_'];return ru(_0x8f2598['eventGenerator_'],_0x592df3,_0x5ca59b,_0x5f02dc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x4686dc){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x4686dc;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x27149f){return _0x27149f['views']['size']===0x0;}function os(_0x3ef673,_0x93a4be,_0x51228f,_0x4c7f36){const _0x4ddd5d=_0x93a4be['source']['queryId'];if(_0x4ddd5d!==null){const _0x2c968e=_0x3ef673['views']['get'](_0x4ddd5d);return f(_0x2c968e!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x2c968e,_0x93a4be,_0x51228f,_0x4c7f36);}else{let _0x2b269b=[];for(const _0x529b52 of _0x3ef673['views']['values']())_0x2b269b=_0x2b269b['concat'](fr(_0x529b52,_0x93a4be,_0x51228f,_0x4c7f36));return _0x2b269b;}}function jo(_0x447a42,_0x43affc,_0x43e962,_0x5631a2,_0x3eb83b){const _0x4e906=_0x43affc['_queryIdentifier'],_0x5286b8=_0x447a42['views']['get'](_0x4e906);if(!_0x5286b8){let _0x17146e=Cn(_0x43e962,_0x3eb83b?_0x5631a2:null),_0x23a8f4=!0x1;_0x17146e?_0x23a8f4=!0x0:_0x5631a2 instanceof g?(_0x17146e=is(_0x43e962,_0x5631a2),_0x23a8f4=!0x1):(_0x17146e=g['EMPTY_NODE'],_0x23a8f4=!0x1);const _0x3fdcf1=Un(new Te(_0x17146e,_0x23a8f4,!0x1),new Te(_0x5631a2,_0x3eb83b,!0x1));return new Du(_0x43affc,_0x3fdcf1);}return _0x5286b8;}function Hu(_0x4ce063,_0x4111f5,_0xda9001,_0x48a9e6,_0x4b8731,_0x4dcd9c){const _0x5cc99b=jo(_0x4ce063,_0x4111f5,_0x48a9e6,_0x4b8731,_0x4dcd9c);return _0x4ce063['views']['has'](_0x4111f5['_queryIdentifier'])||_0x4ce063['views']['set'](_0x4111f5['_queryIdentifier'],_0x5cc99b),Fu(_0x5cc99b,_0xda9001),Uu(_0x5cc99b,_0xda9001);}function $u(_0x4da58d,_0x42d4d7,_0x52f070,_0x8d7c7c){const _0x144db8=_0x42d4d7['_queryIdentifier'],_0x15d621=[];let _0x540473=[];const _0x211249=Se(_0x4da58d);if(_0x144db8==='default'){for(const [_0x2f1801,_0x5b5edc]of _0x4da58d['views']['entries']())_0x540473=_0x540473['concat'](dr(_0x5b5edc,_0x52f070,_0x8d7c7c)),ur(_0x5b5edc)&&(_0x4da58d['views']['delete'](_0x2f1801),_0x5b5edc['query']['_queryParams']['loadsAllData']()||_0x15d621['push'](_0x5b5edc['query']));}else{const _0x4d0e92=_0x4da58d['views']['get'](_0x144db8);_0x4d0e92&&(_0x540473=_0x540473['concat'](dr(_0x4d0e92,_0x52f070,_0x8d7c7c)),ur(_0x4d0e92)&&(_0x4da58d['views']['delete'](_0x144db8),_0x4d0e92['query']['_queryParams']['loadsAllData']()||_0x15d621['push'](_0x4d0e92['query'])));}return _0x211249&&!Se(_0x4da58d)&&_0x15d621['push'](new(Bu())(_0x42d4d7['_repo'],_0x42d4d7['_path'])),{'removed':_0x15d621,'events':_0x540473};}function Ko(_0x142d2d){const _0x5299ba=[];for(const _0x5b64c8 of _0x142d2d['views']['values']())_0x5b64c8['query']['_queryParams']['loadsAllData']()||_0x5299ba['push'](_0x5b64c8);return _0x5299ba;}function Ie(_0x5c4e7e,_0x1e8f0e){let _0x26d7a1=null;for(const _0x36a494 of _0x5c4e7e['views']['values']())_0x26d7a1=_0x26d7a1||xu(_0x36a494,_0x1e8f0e);return _0x26d7a1;}function Yo(_0xc507ce,_0x4ba2e4){if(_0x4ba2e4['_queryParams']['loadsAllData']())return Bn(_0xc507ce);{const _0xccfa6f=_0x4ba2e4['_queryIdentifier'];return _0xc507ce['views']['get'](_0xccfa6f);}}function Qo(_0x29e6da,_0xc56b10){return Yo(_0x29e6da,_0xc56b10)!=null;}function Se(_0x241949){return Bn(_0x241949)!=null;}function Bn(_0x26580d){for(const _0x3a3f74 of _0x26580d['views']['values']())if(_0x3a3f74['query']['_queryParams']['loadsAllData']())return _0x3a3f74;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x399133){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x399133;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x21d2a8){this['listenProvider_']=_0x21d2a8,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x986f54,_0x1edd62,_0x4450fd,_0x30172c,_0x4cacec){return lu(_0x986f54['pendingWriteTree_'],_0x1edd62,_0x4450fd,_0x30172c,_0x4cacec),_0x4cacec?_t(_0x986f54,new Be(es(),_0x1edd62,_0x4450fd)):[];}function ju(_0x3d08bb,_0x302a21,_0x124c7f,_0x447b7d){hu(_0x3d08bb['pendingWriteTree_'],_0x302a21,_0x124c7f,_0x447b7d);const _0x369f35=b['fromObject'](_0x124c7f);return _t(_0x3d08bb,new ot(es(),_0x302a21,_0x369f35));}function _e(_0x5c6cc5,_0x272695,_0x559d39=!0x1){const _0x25ffb2=uu(_0x5c6cc5['pendingWriteTree_'],_0x272695);if(du(_0x5c6cc5['pendingWriteTree_'],_0x272695)){let _0x37a87f=new b(null);return _0x25ffb2['snap']!=null?_0x37a87f=_0x37a87f['set'](w(),!0x0):x(_0x25ffb2['children'],_0x1125d1=>{_0x37a87f=_0x37a87f['set'](new C(_0x1125d1),!0x0);}),_t(_0x5c6cc5,new In(_0x25ffb2['path'],_0x37a87f,_0x559d39));}else return[];}function Yt(_0x3b38c3,_0x1adf3c,_0x53e7ed){return _t(_0x3b38c3,new Be(ts(),_0x1adf3c,_0x53e7ed));}function Ku(_0x1f8bd5,_0x3f42be,_0x3e288c){const _0x270092=b['fromObject'](_0x3e288c);return _t(_0x1f8bd5,new ot(ts(),_0x3f42be,_0x270092));}function Yu(_0x584060,_0x170806){return _t(_0x584060,new Ut(ts(),_0x170806));}function Qu(_0x239e7f,_0x128335,_0x53d923){const _0x3713db=cs(_0x239e7f,_0x53d923);if(_0x3713db){const _0x56b6da=ls(_0x3713db),_0x22880=_0x56b6da['path'],_0x282c97=_0x56b6da['queryId'],_0x414b13=F(_0x22880,_0x128335),_0x2412de=new Ut(ns(_0x282c97),_0x414b13);return hs(_0x239e7f,_0x22880,_0x2412de);}else return[];}function An(_0x34a519,_0x2521d6,_0x58c9cd,_0xe049ec,_0x992119=!0x1){const _0x3d74d1=_0x2521d6['_path'],_0x222d1a=_0x34a519['syncPointTree_']['get'](_0x3d74d1);let _0x2a2013=[];if(_0x222d1a&&(_0x2521d6['_queryIdentifier']==='default'||Qo(_0x222d1a,_0x2521d6))){const _0x1e5541=$u(_0x222d1a,_0x2521d6,_0x58c9cd,_0xe049ec);Vu(_0x222d1a)&&(_0x34a519['syncPointTree_']=_0x34a519['syncPointTree_']['remove'](_0x3d74d1));const _0x14515d=_0x1e5541['removed'];if(_0x2a2013=_0x1e5541['events'],!_0x992119){const _0x8946b5=_0x14515d['findIndex'](_0x1a007d=>_0x1a007d['_queryParams']['loadsAllData']())!==-0x1,_0x5e3d08=_0x34a519['syncPointTree_']['findOnPath'](_0x3d74d1,(_0x45111e,_0x4e53fe)=>Se(_0x4e53fe));if(_0x8946b5&&!_0x5e3d08){const _0x21ca3f=_0x34a519['syncPointTree_']['subtree'](_0x3d74d1);if(!_0x21ca3f['isEmpty']()){const _0x2fd049=Zu(_0x21ca3f);for(let _0x527801=0x0;_0x527801<_0x2fd049['length'];++_0x527801){const _0x595a88=_0x2fd049[_0x527801],_0x358677=_0x595a88['query'],_0xbc02ca=ea(_0x34a519,_0x595a88);_0x34a519['listenProvider_']['startListening'](kt(_0x358677),Wt(_0x34a519,_0x358677),_0xbc02ca['hashFn'],_0xbc02ca['onComplete']);}}}!_0x5e3d08&&_0x14515d['length']>0x0&&!_0xe049ec&&(_0x8946b5?_0x34a519['listenProvider_']['stopListening'](kt(_0x2521d6),null):_0x14515d['forEach'](_0x46ccc3=>{const _0x2d2453=_0x34a519['queryToTagMap']['get'](Hn(_0x46ccc3));_0x34a519['listenProvider_']['stopListening'](kt(_0x46ccc3),_0x2d2453);}));}ed(_0x34a519,_0x14515d);}return _0x2a2013;}function Jo(_0xe56cdb,_0x4b8f95,_0x53ebcd,_0x2fd5a0){const _0x3cfeee=cs(_0xe56cdb,_0x2fd5a0);if(_0x3cfeee!=null){const _0x2fab4f=ls(_0x3cfeee),_0x4c3a93=_0x2fab4f['path'],_0x46c658=_0x2fab4f['queryId'],_0x2b9b9a=F(_0x4c3a93,_0x4b8f95),_0x3957f1=new Be(ns(_0x46c658),_0x2b9b9a,_0x53ebcd);return hs(_0xe56cdb,_0x4c3a93,_0x3957f1);}else return[];}function Ju(_0x7874ab,_0x59daac,_0x11b045,_0x1170f1){const _0x4ade40=cs(_0x7874ab,_0x1170f1);if(_0x4ade40){const _0x3a2c91=ls(_0x4ade40),_0x23bb93=_0x3a2c91['path'],_0x207afb=_0x3a2c91['queryId'],_0x17eef3=F(_0x23bb93,_0x59daac),_0x1dcd83=b['fromObject'](_0x11b045),_0x2fa403=new ot(ns(_0x207afb),_0x17eef3,_0x1dcd83);return hs(_0x7874ab,_0x23bb93,_0x2fa403);}else return[];}function Ni(_0x5b6afe,_0x5643d1,_0xcad18,_0x3fe22e=!0x1){const _0x4cf8dd=_0x5643d1['_path'];let _0x5f4a51=null,_0x24fa42=!0x1;_0x5b6afe['syncPointTree_']['foreachOnPath'](_0x4cf8dd,(_0x1bf569,_0x2e3a0f)=>{const _0x1f5ff6=F(_0x1bf569,_0x4cf8dd);_0x5f4a51=_0x5f4a51||Ie(_0x2e3a0f,_0x1f5ff6),_0x24fa42=_0x24fa42||Se(_0x2e3a0f);});let _0x49cecc=_0x5b6afe['syncPointTree_']['get'](_0x4cf8dd);_0x49cecc?(_0x24fa42=_0x24fa42||Se(_0x49cecc),_0x5f4a51=_0x5f4a51||Ie(_0x49cecc,w())):(_0x49cecc=new zo(),_0x5b6afe['syncPointTree_']=_0x5b6afe['syncPointTree_']['set'](_0x4cf8dd,_0x49cecc));let _0x5762fe;_0x5f4a51!=null?_0x5762fe=!0x0:(_0x5762fe=!0x1,_0x5f4a51=g['EMPTY_NODE'],_0x5b6afe['syncPointTree_']['subtree'](_0x4cf8dd)['foreachChild']((_0x1e4e72,_0x4259df)=>{const _0x42c627=Ie(_0x4259df,w());_0x42c627&&(_0x5f4a51=_0x5f4a51['updateImmediateChild'](_0x1e4e72,_0x42c627));}));const _0x1d990d=Qo(_0x49cecc,_0x5643d1);if(!_0x1d990d&&!_0x5643d1['_queryParams']['loadsAllData']()){const _0x10ecf8=Hn(_0x5643d1);f(!_0x5b6afe['queryToTagMap']['has'](_0x10ecf8),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x490536=td();_0x5b6afe['queryToTagMap']['set'](_0x10ecf8,_0x490536),_0x5b6afe['tagToQueryMap']['set'](_0x490536,_0x10ecf8);}const _0x12c9d7=Wn(_0x5b6afe['pendingWriteTree_'],_0x4cf8dd);let _0x154277=Hu(_0x49cecc,_0x5643d1,_0xcad18,_0x12c9d7,_0x5f4a51,_0x5762fe);if(!_0x1d990d&&!_0x24fa42&&!_0x3fe22e){const _0x4f6c7a=Yo(_0x49cecc,_0x5643d1);_0x154277=_0x154277['concat'](nd(_0x5b6afe,_0x5643d1,_0x4f6c7a));}return _0x154277;}function Vn(_0x3976bb,_0x3e631a,_0x6d597d){const _0x4f3259=_0x3976bb['pendingWriteTree_'],_0x3d3a34=_0x3976bb['syncPointTree_']['findOnPath'](_0x3e631a,(_0x342492,_0x3f1430)=>{const _0x196a10=F(_0x342492,_0x3e631a),_0x4b441c=Ie(_0x3f1430,_0x196a10);if(_0x4b441c)return _0x4b441c;});return Bo(_0x4f3259,_0x3e631a,_0x3d3a34,_0x6d597d,!0x0);}function Xu(_0x56b9ec,_0x48e679){const _0x5da56f=_0x48e679['_path'];let _0x4d279f=null;_0x56b9ec['syncPointTree_']['foreachOnPath'](_0x5da56f,(_0x4770f3,_0x459335)=>{const _0x53176d=F(_0x4770f3,_0x5da56f);_0x4d279f=_0x4d279f||Ie(_0x459335,_0x53176d);});let _0x203938=_0x56b9ec['syncPointTree_']['get'](_0x5da56f);_0x203938?_0x4d279f=_0x4d279f||Ie(_0x203938,w()):(_0x203938=new zo(),_0x56b9ec['syncPointTree_']=_0x56b9ec['syncPointTree_']['set'](_0x5da56f,_0x203938));const _0x533e67=_0x4d279f!=null,_0x242536=_0x533e67?new Te(_0x4d279f,!0x0,!0x1):null,_0x271bab=Wn(_0x56b9ec['pendingWriteTree_'],_0x48e679['_path']),_0x47aae3=jo(_0x203938,_0x48e679,_0x271bab,_0x533e67?_0x242536['getNode']():g['EMPTY_NODE'],_0x533e67);return Lu(_0x47aae3);}function _t(_0x46b23f,_0xab86db){return Xo(_0xab86db,_0x46b23f['syncPointTree_'],null,Wn(_0x46b23f['pendingWriteTree_'],w()));}function Xo(_0x3bd6bb,_0x37f521,_0x36c6ac,_0x530d16){if(v(_0x3bd6bb['path']))return Zo(_0x3bd6bb,_0x37f521,_0x36c6ac,_0x530d16);{const _0x13bc5c=_0x37f521['get'](w());_0x36c6ac==null&&_0x13bc5c!=null&&(_0x36c6ac=Ie(_0x13bc5c,w()));let _0x9ab4c4=[];const _0x3b282d=y(_0x3bd6bb['path']),_0x41f3cb=_0x3bd6bb['operationForChild'](_0x3b282d),_0x80a97=_0x37f521['children']['get'](_0x3b282d);if(_0x80a97&&_0x41f3cb){const _0x38ea89=_0x36c6ac?_0x36c6ac['getImmediateChild'](_0x3b282d):null,_0x572120=Vo(_0x530d16,_0x3b282d);_0x9ab4c4=_0x9ab4c4['concat'](Xo(_0x41f3cb,_0x80a97,_0x38ea89,_0x572120));}return _0x13bc5c&&(_0x9ab4c4=_0x9ab4c4['concat'](os(_0x13bc5c,_0x3bd6bb,_0x530d16,_0x36c6ac))),_0x9ab4c4;}}function Zo(_0x47788a,_0xa35413,_0x3feda5,_0x37a950){const _0x1791a6=_0xa35413['get'](w());_0x3feda5==null&&_0x1791a6!=null&&(_0x3feda5=Ie(_0x1791a6,w()));let _0x4bab5b=[];return _0xa35413['children']['inorderTraversal']((_0xb2191d,_0x27af88)=>{const _0x2f5e97=_0x3feda5?_0x3feda5['getImmediateChild'](_0xb2191d):null,_0x1a76aa=Vo(_0x37a950,_0xb2191d),_0x49ac51=_0x47788a['operationForChild'](_0xb2191d);_0x49ac51&&(_0x4bab5b=_0x4bab5b['concat'](Zo(_0x49ac51,_0x27af88,_0x2f5e97,_0x1a76aa)));}),_0x1791a6&&(_0x4bab5b=_0x4bab5b['concat'](os(_0x1791a6,_0x47788a,_0x37a950,_0x3feda5))),_0x4bab5b;}function ea(_0x5888ae,_0x51e004){const _0x3fa6b8=_0x51e004['query'],_0x273709=Wt(_0x5888ae,_0x3fa6b8);return{'hashFn':()=>(Mu(_0x51e004)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x36dea2=>{if(_0x36dea2==='ok')return _0x273709?Qu(_0x5888ae,_0x3fa6b8['_path'],_0x273709):Yu(_0x5888ae,_0x3fa6b8['_path']);{const _0x3d21f9=Kl(_0x36dea2,_0x3fa6b8);return An(_0x5888ae,_0x3fa6b8,null,_0x3d21f9);}}};}function Wt(_0x6627ea,_0x5ee340){const _0x5a173d=Hn(_0x5ee340);return _0x6627ea['queryToTagMap']['get'](_0x5a173d);}function Hn(_0x8ecc77){return _0x8ecc77['_path']['toString']()+'$'+_0x8ecc77['_queryIdentifier'];}function cs(_0x3b9804,_0x4f26fb){return _0x3b9804['tagToQueryMap']['get'](_0x4f26fb);}function ls(_0x40b470){const _0x4065ee=_0x40b470['indexOf']('$');return f(_0x4065ee!==-0x1&&_0x4065ee<_0x40b470['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x40b470['substr'](_0x4065ee+0x1),'path':new C(_0x40b470['substr'](0x0,_0x4065ee))};}function hs(_0x2f4d9c,_0x16b881,_0x280fab){const _0x16af23=_0x2f4d9c['syncPointTree_']['get'](_0x16b881);f(_0x16af23,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x571b48=Wn(_0x2f4d9c['pendingWriteTree_'],_0x16b881);return os(_0x16af23,_0x280fab,_0x571b48,null);}function Zu(_0x28eee1){return _0x28eee1['fold']((_0x5b7363,_0x41d365,_0x466686)=>{if(_0x41d365&&Se(_0x41d365))return[Bn(_0x41d365)];{let _0x324643=[];return _0x41d365&&(_0x324643=Ko(_0x41d365)),x(_0x466686,(_0x430266,_0x4329f9)=>{_0x324643=_0x324643['concat'](_0x4329f9);}),_0x324643;}});}function kt(_0x4b0626){return _0x4b0626['_queryParams']['loadsAllData']()&&!_0x4b0626['_queryParams']['isDefault']()?new(qu())(_0x4b0626['_repo'],_0x4b0626['_path']):_0x4b0626;}function ed(_0x1776ea,_0x393b79){for(let _0x2c5d44=0x0;_0x2c5d44<_0x393b79['length'];++_0x2c5d44){const _0x373bfd=_0x393b79[_0x2c5d44];if(!_0x373bfd['_queryParams']['loadsAllData']()){const _0x59fcb3=Hn(_0x373bfd),_0x3c2c1e=_0x1776ea['queryToTagMap']['get'](_0x59fcb3);_0x1776ea['queryToTagMap']['delete'](_0x59fcb3),_0x1776ea['tagToQueryMap']['delete'](_0x3c2c1e);}}}function td(){return zu++;}function nd(_0xb40a52,_0x13bef9,_0x3d0fcc){const _0x46d8cb=_0x13bef9['_path'],_0x2a8ed0=Wt(_0xb40a52,_0x13bef9),_0x470c07=ea(_0xb40a52,_0x3d0fcc),_0x2dc9a3=_0xb40a52['listenProvider_']['startListening'](kt(_0x13bef9),_0x2a8ed0,_0x470c07['hashFn'],_0x470c07['onComplete']),_0x3d4497=_0xb40a52['syncPointTree_']['subtree'](_0x46d8cb);if(_0x2a8ed0)f(!Se(_0x3d4497['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5c564c=_0x3d4497['fold']((_0x37bfcf,_0xda8ee,_0x1edf70)=>{if(!v(_0x37bfcf)&&_0xda8ee&&Se(_0xda8ee))return[Bn(_0xda8ee)['query']];{let _0x5e6ada=[];return _0xda8ee&&(_0x5e6ada=_0x5e6ada['concat'](Ko(_0xda8ee)['map'](_0x5042bf=>_0x5042bf['query']))),x(_0x1edf70,(_0x2e51ae,_0x3af8ac)=>{_0x5e6ada=_0x5e6ada['concat'](_0x3af8ac);}),_0x5e6ada;}});for(let _0x415774=0x0;_0x415774<_0x5c564c['length'];++_0x415774){const _0x1996b5=_0x5c564c[_0x415774];_0xb40a52['listenProvider_']['stopListening'](kt(_0x1996b5),Wt(_0xb40a52,_0x1996b5));}}return _0x2dc9a3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0xb98bdb){this['node_']=_0xb98bdb;}['getImmediateChild'](_0x2ab88e){const _0x4ce4fa=this['node_']['getImmediateChild'](_0x2ab88e);return new us(_0x4ce4fa);}['node'](){return this['node_'];}}class ds{constructor(_0x38877b,_0x348133){this['syncTree_']=_0x38877b,this['path_']=_0x348133;}['getImmediateChild'](_0x4335c2){const _0x56c68e=k(this['path_'],_0x4335c2);return new ds(this['syncTree_'],_0x56c68e);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x482ac3){return _0x482ac3=_0x482ac3||{},_0x482ac3['timestamp']=_0x482ac3['timestamp']||new Date()['getTime'](),_0x482ac3;},_r=function(_0x5a354a,_0x11449b,_0x296328){if(!_0x5a354a||typeof _0x5a354a!='object')return _0x5a354a;if(f('.sv'in _0x5a354a,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5a354a['.sv']=='string')return sd(_0x5a354a['.sv'],_0x11449b,_0x296328);if(typeof _0x5a354a['.sv']=='object')return rd(_0x5a354a['.sv'],_0x11449b);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5a354a,null,0x2));},sd=function(_0x432bf4,_0x202c58,_0x55524b){switch(_0x432bf4){case'timestamp':return _0x55524b['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x432bf4);}},rd=function(_0x1868b8,_0x4cfc75,_0x5a0423){_0x1868b8['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1868b8,null,0x2));const _0x4fe679=_0x1868b8['increment'];typeof _0x4fe679!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4fe679);const _0x426cb4=_0x4cfc75['node']();if(f(_0x426cb4!==null&&typeof _0x426cb4<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x426cb4['isLeafNode']())return _0x4fe679;const _0x421438=_0x426cb4['getValue']();return typeof _0x421438!='number'?_0x4fe679:_0x421438+_0x4fe679;},ta=function(_0x272f21,_0x2f0bd0,_0x52a576,_0x1c1af6){return ps(_0x2f0bd0,new ds(_0x52a576,_0x272f21),_0x1c1af6);},fs=function(_0x5cdf09,_0x23ae62,_0x56a751){return ps(_0x5cdf09,new us(_0x23ae62),_0x56a751);};function ps(_0x1878dd,_0x4fda01,_0x3975c9){const _0x4a2765=_0x1878dd['getPriority']()['val'](),_0x56dd66=_r(_0x4a2765,_0x4fda01['getImmediateChild']('.priority'),_0x3975c9);let _0x4bb875;if(_0x1878dd['isLeafNode']()){const _0x4d195b=_0x1878dd,_0x9638de=_r(_0x4d195b['getValue'](),_0x4fda01,_0x3975c9);return _0x9638de!==_0x4d195b['getValue']()||_0x56dd66!==_0x4d195b['getPriority']()['val']()?new D(_0x9638de,A(_0x56dd66)):_0x1878dd;}else{const _0x4f771d=_0x1878dd;return _0x4bb875=_0x4f771d,_0x56dd66!==_0x4f771d['getPriority']()['val']()&&(_0x4bb875=_0x4bb875['updatePriority'](new D(_0x56dd66))),_0x4f771d['forEachChild'](R,(_0x458836,_0x346844)=>{const _0x2f1c=ps(_0x346844,_0x4fda01['getImmediateChild'](_0x458836),_0x3975c9);_0x2f1c!==_0x346844&&(_0x4bb875=_0x4bb875['updateImmediateChild'](_0x458836,_0x2f1c));}),_0x4bb875;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x4d1669='',_0x3e8c82=null,_0x120082={'children':{},'childCount':0x0}){this['name']=_0x4d1669,this['parent']=_0x3e8c82,this['node']=_0x120082;}}function $n(_0x4d41b2,_0x503639){let _0x425015=_0x503639 instanceof C?_0x503639:new C(_0x503639),_0x4ddc28=_0x4d41b2,_0x117a54=y(_0x425015);for(;_0x117a54!==null;){const _0x1c3453=Le(_0x4ddc28['node']['children'],_0x117a54)||{'children':{},'childCount':0x0};_0x4ddc28=new _s(_0x117a54,_0x4ddc28,_0x1c3453),_0x425015=S(_0x425015),_0x117a54=y(_0x425015);}return _0x4ddc28;}function je(_0x3d9581){return _0x3d9581['node']['value'];}function gs(_0x4283e3,_0x126991){_0x4283e3['node']['value']=_0x126991,Oi(_0x4283e3);}function na(_0x252dfb){return _0x252dfb['node']['childCount']>0x0;}function od(_0x409e61){return je(_0x409e61)===void 0x0&&!na(_0x409e61);}function Gn(_0x18f018,_0x57dffe){x(_0x18f018['node']['children'],(_0x4778f9,_0x351b30)=>{_0x57dffe(new _s(_0x4778f9,_0x18f018,_0x351b30));});}function ia(_0x4262dc,_0xc75d5b,_0x179f1f,_0x29c3a3){_0x179f1f&&_0xc75d5b(_0x4262dc),Gn(_0x4262dc,_0x5ad96e=>{ia(_0x5ad96e,_0xc75d5b,!0x0);});}function ad(_0x1e8d65,_0x51ee56,_0x291f2b){let _0x4f5d28=_0x1e8d65['parent'];for(;_0x4f5d28!==null;){if(_0x51ee56(_0x4f5d28))return!0x0;_0x4f5d28=_0x4f5d28['parent'];}return!0x1;}function Qt(_0x8befaa){return new C(_0x8befaa['parent']===null?_0x8befaa['name']:Qt(_0x8befaa['parent'])+'/'+_0x8befaa['name']);}function Oi(_0x19b28f){_0x19b28f['parent']!==null&&cd(_0x19b28f['parent'],_0x19b28f['name'],_0x19b28f);}function cd(_0x2b0cac,_0x40c5ed,_0x731375){const _0x31cc04=od(_0x731375),_0x2433e1=Q(_0x2b0cac['node']['children'],_0x40c5ed);_0x31cc04&&_0x2433e1?(delete _0x2b0cac['node']['children'][_0x40c5ed],_0x2b0cac['node']['childCount']--,Oi(_0x2b0cac)):!_0x31cc04&&!_0x2433e1&&(_0x2b0cac['node']['children'][_0x40c5ed]=_0x731375['node'],_0x2b0cac['node']['childCount']++,Oi(_0x2b0cac));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x327c91){return typeof _0x327c91=='string'&&_0x327c91['length']!==0x0&&!ld['test'](_0x327c91);},sa=function(_0x4295e5){return typeof _0x4295e5=='string'&&_0x4295e5['length']!==0x0&&!hd['test'](_0x4295e5);},ud=function(_0x182e6b){return _0x182e6b&&(_0x182e6b=_0x182e6b['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x182e6b);},Bt=function(_0x408c94){return _0x408c94===null||typeof _0x408c94=='string'||typeof _0x408c94=='number'&&!xn(_0x408c94)||_0x408c94&&typeof _0x408c94=='object'&&Q(_0x408c94,'.sv');},He=function(_0x1bf1d9,_0x187ebe,_0x5a478b,_0x6a9669){_0x6a9669&&_0x187ebe===void 0x0||Jt(it(_0x1bf1d9,'value'),_0x187ebe,_0x5a478b);},Jt=function(_0x3a01f8,_0x18ee29,_0x4c3c45){const _0x4b172b=_0x4c3c45 instanceof C?new Ah(_0x4c3c45,_0x3a01f8):_0x4c3c45;if(_0x18ee29===void 0x0)throw new Error(_0x3a01f8+'contains\x20undefined\x20'+Oe(_0x4b172b));if(typeof _0x18ee29=='function')throw new Error(_0x3a01f8+'contains\x20a\x20function\x20'+Oe(_0x4b172b)+'\x20with\x20contents\x20=\x20'+_0x18ee29['toString']());if(xn(_0x18ee29))throw new Error(_0x3a01f8+'contains\x20'+_0x18ee29['toString']()+'\x20'+Oe(_0x4b172b));if(typeof _0x18ee29=='string'&&_0x18ee29['length']>ui/0x3&&Ln(_0x18ee29)>ui)throw new Error(_0x3a01f8+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x4b172b)+'\x20(\x27'+_0x18ee29['substring'](0x0,0x32)+'...\x27)');if(_0x18ee29&&typeof _0x18ee29=='object'){let _0x152207=!0x1,_0x37e007=!0x1;if(x(_0x18ee29,(_0x1c598a,_0x4ffbb8)=>{if(_0x1c598a==='.value')_0x152207=!0x0;else{if(_0x1c598a!=='.priority'&&_0x1c598a!=='.sv'&&(_0x37e007=!0x0,!ms(_0x1c598a)))throw new Error(_0x3a01f8+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1c598a+')\x20'+Oe(_0x4b172b)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x4b172b,_0x1c598a),Jt(_0x3a01f8,_0x4ffbb8,_0x4b172b),Ph(_0x4b172b);}),_0x152207&&_0x37e007)throw new Error(_0x3a01f8+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x4b172b)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x12e204,_0x5156cc){let _0x1c2934,_0x41ab87;for(_0x1c2934=0x0;_0x1c2934<_0x5156cc['length'];_0x1c2934++){_0x41ab87=_0x5156cc[_0x1c2934];const _0x2c8d45=Mt(_0x41ab87);for(let _0x24b91c=0x0;_0x24b91c<_0x2c8d45['length'];_0x24b91c++)if(!(_0x2c8d45[_0x24b91c]==='.priority'&&_0x24b91c===_0x2c8d45['length']-0x1)){if(!ms(_0x2c8d45[_0x24b91c]))throw new Error(_0x12e204+'contains\x20an\x20invalid\x20key\x20('+_0x2c8d45[_0x24b91c]+')\x20in\x20path\x20'+_0x41ab87['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5156cc['sort'](Rh);let _0x4c6754=null;for(_0x1c2934=0x0;_0x1c2934<_0x5156cc['length'];_0x1c2934++){if(_0x41ab87=_0x5156cc[_0x1c2934],_0x4c6754!==null&&G(_0x4c6754,_0x41ab87))throw new Error(_0x12e204+'contains\x20a\x20path\x20'+_0x4c6754['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x41ab87['toString']());_0x4c6754=_0x41ab87;}},ra=function(_0x3ed997,_0x1adae8,_0x28f52a,_0x4d1df0){const _0x46b93d=it(_0x3ed997,'values');if(!(_0x1adae8&&typeof _0x1adae8=='object')||Array['isArray'](_0x1adae8))throw new Error(_0x46b93d+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x53c9c3=[];x(_0x1adae8,(_0x23a952,_0x1d4a93)=>{const _0x12e45c=new C(_0x23a952);if(Jt(_0x46b93d,_0x1d4a93,k(_0x28f52a,_0x12e45c)),ji(_0x12e45c)==='.priority'&&!Bt(_0x1d4a93))throw new Error(_0x46b93d+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x12e45c['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x53c9c3['push'](_0x12e45c);}),dd(_0x46b93d,_0x53c9c3);},fd=function(_0x310ad3,_0x2b11c2,_0x3001c0){if(xn(_0x2b11c2))throw new Error(it(_0x310ad3,'priority')+'is\x20'+_0x2b11c2['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x2b11c2))throw new Error(it(_0x310ad3,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x5cc388,_0x5cb050,_0x1959bb,_0xf3a7af){if(!sa(_0x1959bb))throw new Error(it(_0x5cc388,_0x5cb050)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1959bb+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x178e15,_0x404b5b,_0x4f7eb4,_0x4858b6){_0x4f7eb4&&(_0x4f7eb4=_0x4f7eb4['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x178e15,_0x404b5b,_0x4f7eb4);},Me=function(_0x533ae1,_0x49e48d){if(y(_0x49e48d)==='.info')throw new Error(_0x533ae1+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x25ff53,_0x46a8bd){const _0x267fa9=_0x46a8bd['path']['toString']();if(typeof _0x46a8bd['repoInfo']['host']!='string'||_0x46a8bd['repoInfo']['host']['length']===0x0||!ms(_0x46a8bd['repoInfo']['namespace'])&&_0x46a8bd['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x267fa9['length']!==0x0&&!ud(_0x267fa9))throw new Error(it(_0x25ff53,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0xc1556b,_0x16f2bf){let _0x4284a9=null;for(let _0x5a41d3=0x0;_0x5a41d3<_0x16f2bf['length'];_0x5a41d3++){const _0x225fae=_0x16f2bf[_0x5a41d3],_0x5a7892=_0x225fae['getPath']();_0x4284a9!==null&&!Ki(_0x5a7892,_0x4284a9['path'])&&(_0xc1556b['eventLists_']['push'](_0x4284a9),_0x4284a9=null),_0x4284a9===null&&(_0x4284a9={'events':[],'path':_0x5a7892}),_0x4284a9['events']['push'](_0x225fae);}_0x4284a9&&_0xc1556b['eventLists_']['push'](_0x4284a9);}function oa(_0x362110,_0x41846a,_0x2df9a1){qn(_0x362110,_0x2df9a1),aa(_0x362110,_0x3e6b51=>Ki(_0x3e6b51,_0x41846a));}function V(_0x42ba66,_0x14ef14,_0xf0c955){qn(_0x42ba66,_0xf0c955),aa(_0x42ba66,_0x5e235b=>G(_0x5e235b,_0x14ef14)||G(_0x14ef14,_0x5e235b));}function aa(_0xb5c941,_0x23215a){_0xb5c941['recursionDepth_']++;let _0x57f914=!0x0;for(let _0x330d6d=0x0;_0x330d6d<_0xb5c941['eventLists_']['length'];_0x330d6d++){const _0x4ebebe=_0xb5c941['eventLists_'][_0x330d6d];if(_0x4ebebe){const _0x57b751=_0x4ebebe['path'];_0x23215a(_0x57b751)?(md(_0xb5c941['eventLists_'][_0x330d6d]),_0xb5c941['eventLists_'][_0x330d6d]=null):_0x57f914=!0x1;}}_0x57f914&&(_0xb5c941['eventLists_']=[]),_0xb5c941['recursionDepth_']--;}function md(_0x1ebf05){for(let _0x339b60=0x0;_0x339b60<_0x1ebf05['events']['length'];_0x339b60++){const _0x4dca65=_0x1ebf05['events'][_0x339b60];if(_0x4dca65!==null){_0x1ebf05['events'][_0x339b60]=null;const _0xaaa1=_0x4dca65['getEventRunner']();St&&L('event:\x20'+_0x4dca65['toString']()),ft(_0xaaa1);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x192935,_0x16b9aa,_0x5ad109,_0x2d9cf0){this['repoInfo_']=_0x192935,this['forceRestClient_']=_0x16b9aa,this['authTokenProvider_']=_0x5ad109,this['appCheckProvider_']=_0x2d9cf0,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x34e31b,_0x4a13c8,_0x222fbe){if(_0x34e31b['stats_']=qi(_0x34e31b['repoInfo_']),_0x34e31b['forceRestClient_']||Xl())_0x34e31b['server_']=new vn(_0x34e31b['repoInfo_'],(_0x2c9696,_0x436dc0,_0x10aa6a,_0xadd64e)=>{gr(_0x34e31b,_0x2c9696,_0x436dc0,_0x10aa6a,_0xadd64e);},_0x34e31b['authTokenProvider_'],_0x34e31b['appCheckProvider_']),setTimeout(()=>mr(_0x34e31b,!0x0),0x0);else{if(typeof _0x222fbe<'u'&&_0x222fbe!==null){if(typeof _0x222fbe!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x222fbe);}catch(_0x4b96e1){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4b96e1);}}_0x34e31b['persistentConnection_']=new se(_0x34e31b['repoInfo_'],_0x4a13c8,(_0x2bde14,_0x3bfce6,_0x26510c,_0x3b43d0)=>{gr(_0x34e31b,_0x2bde14,_0x3bfce6,_0x26510c,_0x3b43d0);},_0x220ce8=>{mr(_0x34e31b,_0x220ce8);},_0x5edff5=>{Id(_0x34e31b,_0x5edff5);},_0x34e31b['authTokenProvider_'],_0x34e31b['appCheckProvider_'],_0x222fbe),_0x34e31b['server_']=_0x34e31b['persistentConnection_'];}_0x34e31b['authTokenProvider_']['addTokenChangeListener'](_0x46445d=>{_0x34e31b['server_']['refreshAuthToken'](_0x46445d);}),_0x34e31b['appCheckProvider_']['addTokenChangeListener'](_0x27eb4c=>{_0x34e31b['server_']['refreshAppCheckToken'](_0x27eb4c['token']);}),_0x34e31b['statsReporter_']=ih(_0x34e31b['repoInfo_'],()=>new iu(_0x34e31b['stats_'],_0x34e31b['server_'])),_0x34e31b['infoData_']=new Xh(),_0x34e31b['infoSyncTree_']=new pr({'startListening':(_0x11cb63,_0x118a46,_0x42865f,_0x19f811)=>{let _0x5dd5b6=[];const _0x5717d2=_0x34e31b['infoData_']['getNode'](_0x11cb63['_path']);return _0x5717d2['isEmpty']()||(_0x5dd5b6=Yt(_0x34e31b['infoSyncTree_'],_0x11cb63['_path'],_0x5717d2),setTimeout(()=>{_0x19f811('ok');},0x0)),_0x5dd5b6;},'stopListening':()=>{}}),vs(_0x34e31b,'connected',!0x1),_0x34e31b['serverSyncTree_']=new pr({'startListening':(_0x47d785,_0x3ba4ab,_0x9e66aa,_0x5e7e20)=>(_0x34e31b['server_']['listen'](_0x47d785,_0x9e66aa,_0x3ba4ab,(_0x1d6e11,_0x142f88)=>{const _0x1537c3=_0x5e7e20(_0x1d6e11,_0x142f88);V(_0x34e31b['eventQueue_'],_0x47d785['_path'],_0x1537c3);}),[]),'stopListening':(_0x3189fb,_0x36600a)=>{_0x34e31b['server_']['unlisten'](_0x3189fb,_0x36600a);}});}function la(_0x1c26c5){const _0x676e92=_0x1c26c5['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x676e92;}function Xt(_0x22b7ea){return id({'timestamp':la(_0x22b7ea)});}function gr(_0x221440,_0x245199,_0x4061b6,_0x44fa6c,_0x4c6a10){_0x221440['dataUpdateCount']++;const _0x5fa739=new C(_0x245199);_0x4061b6=_0x221440['interceptServerDataCallback_']?_0x221440['interceptServerDataCallback_'](_0x245199,_0x4061b6):_0x4061b6;let _0xc5b392=[];if(_0x4c6a10){if(_0x44fa6c){const _0x474c3e=_n(_0x4061b6,_0xe22342=>A(_0xe22342));_0xc5b392=Ju(_0x221440['serverSyncTree_'],_0x5fa739,_0x474c3e,_0x4c6a10);}else{const _0x42cf08=A(_0x4061b6);_0xc5b392=Jo(_0x221440['serverSyncTree_'],_0x5fa739,_0x42cf08,_0x4c6a10);}}else{if(_0x44fa6c){const _0xbd1197=_n(_0x4061b6,_0x4ad32a=>A(_0x4ad32a));_0xc5b392=Ku(_0x221440['serverSyncTree_'],_0x5fa739,_0xbd1197);}else{const _0x9c95aa=A(_0x4061b6);_0xc5b392=Yt(_0x221440['serverSyncTree_'],_0x5fa739,_0x9c95aa);}}let _0x29f2d2=_0x5fa739;_0xc5b392['length']>0x0&&(_0x29f2d2=ct(_0x221440,_0x5fa739)),V(_0x221440['eventQueue_'],_0x29f2d2,_0xc5b392);}function mr(_0x4ddc91,_0x2334d8){vs(_0x4ddc91,'connected',_0x2334d8),_0x2334d8===!0x1&&Sd(_0x4ddc91);}function Id(_0x16d6b0,_0x309182){x(_0x309182,(_0x45d61e,_0x476862)=>{vs(_0x16d6b0,_0x45d61e,_0x476862);});}function vs(_0x218dad,_0x5b5c70,_0x5af223){const _0x28099e=new C('/.info/'+_0x5b5c70),_0x4a79d7=A(_0x5af223);_0x218dad['infoData_']['updateSnapshot'](_0x28099e,_0x4a79d7);const _0x5bef9f=Yt(_0x218dad['infoSyncTree_'],_0x28099e,_0x4a79d7);V(_0x218dad['eventQueue_'],_0x28099e,_0x5bef9f);}function zn(_0x154e5a){return _0x154e5a['nextWriteId_']++;}function wd(_0x481e60,_0x5db928,_0x1a082c){const _0xe9ad9d=Xu(_0x481e60['serverSyncTree_'],_0x5db928);return _0xe9ad9d!=null?Promise['resolve'](_0xe9ad9d):_0x481e60['server_']['get'](_0x5db928)['then'](_0x237f3c=>{const _0x349a25=A(_0x237f3c)['withIndex'](_0x5db928['_queryParams']['getIndex']());Ni(_0x481e60['serverSyncTree_'],_0x5db928,_0x1a082c,!0x0);let _0x3855fb;if(_0x5db928['_queryParams']['loadsAllData']())_0x3855fb=Yt(_0x481e60['serverSyncTree_'],_0x5db928['_path'],_0x349a25);else{const _0xe27aef=Wt(_0x481e60['serverSyncTree_'],_0x5db928);_0x3855fb=Jo(_0x481e60['serverSyncTree_'],_0x5db928['_path'],_0x349a25,_0xe27aef);}return V(_0x481e60['eventQueue_'],_0x5db928['_path'],_0x3855fb),An(_0x481e60['serverSyncTree_'],_0x5db928,_0x1a082c,null,!0x0),_0x349a25;},_0x3ef27b=>(gt(_0x481e60,'get\x20for\x20query\x20'+O(_0x5db928)+'\x20failed:\x20'+_0x3ef27b),Promise['reject'](new Error(_0x3ef27b))));}function Cd(_0x2765ab,_0x32d2f3,_0x53362c,_0x5233c8,_0x148880){gt(_0x2765ab,'set',{'path':_0x32d2f3['toString'](),'value':_0x53362c,'priority':_0x5233c8});const _0x32e001=Xt(_0x2765ab),_0xe1cda0=A(_0x53362c,_0x5233c8),_0x3e922e=Vn(_0x2765ab['serverSyncTree_'],_0x32d2f3),_0xef52af=fs(_0xe1cda0,_0x3e922e,_0x32e001),_0x93756=zn(_0x2765ab),_0x467e06=as(_0x2765ab['serverSyncTree_'],_0x32d2f3,_0xef52af,_0x93756,!0x0);qn(_0x2765ab['eventQueue_'],_0x467e06),_0x2765ab['server_']['put'](_0x32d2f3['toString'](),_0xe1cda0['val'](!0x0),(_0x4a6ebd,_0x42d88a)=>{const _0x492809=_0x4a6ebd==='ok';_0x492809||U('set\x20at\x20'+_0x32d2f3+'\x20failed:\x20'+_0x4a6ebd);const _0x25ea04=_e(_0x2765ab['serverSyncTree_'],_0x93756,!_0x492809);V(_0x2765ab['eventQueue_'],_0x32d2f3,_0x25ea04),be(_0x2765ab,_0x148880,_0x4a6ebd,_0x42d88a);});const _0x45c61f=Is(_0x2765ab,_0x32d2f3);ct(_0x2765ab,_0x45c61f),V(_0x2765ab['eventQueue_'],_0x45c61f,[]);}function Td(_0xe3207b,_0x174d42,_0x5168bb,_0x1a4cc5){gt(_0xe3207b,'update',{'path':_0x174d42['toString'](),'value':_0x5168bb});let _0x2cc9d3=!0x0;const _0x3563fc=Xt(_0xe3207b),_0x19e318={};if(x(_0x5168bb,(_0x26067a,_0x578b7d)=>{_0x2cc9d3=!0x1,_0x19e318[_0x26067a]=ta(k(_0x174d42,_0x26067a),A(_0x578b7d),_0xe3207b['serverSyncTree_'],_0x3563fc);}),_0x2cc9d3)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0xe3207b,_0x1a4cc5,'ok',void 0x0);else{const _0x189c3b=zn(_0xe3207b),_0x54d95a=ju(_0xe3207b['serverSyncTree_'],_0x174d42,_0x19e318,_0x189c3b);qn(_0xe3207b['eventQueue_'],_0x54d95a),_0xe3207b['server_']['merge'](_0x174d42['toString'](),_0x5168bb,(_0x535b49,_0x3085a5)=>{const _0x2de95e=_0x535b49==='ok';_0x2de95e||U('update\x20at\x20'+_0x174d42+'\x20failed:\x20'+_0x535b49);const _0x2b3e67=_e(_0xe3207b['serverSyncTree_'],_0x189c3b,!_0x2de95e),_0x4e656c=_0x2b3e67['length']>0x0?ct(_0xe3207b,_0x174d42):_0x174d42;V(_0xe3207b['eventQueue_'],_0x4e656c,_0x2b3e67),be(_0xe3207b,_0x1a4cc5,_0x535b49,_0x3085a5);}),x(_0x5168bb,_0x5dbbe8=>{const _0x17d01d=Is(_0xe3207b,k(_0x174d42,_0x5dbbe8));ct(_0xe3207b,_0x17d01d);}),V(_0xe3207b['eventQueue_'],_0x174d42,[]);}}function Sd(_0x320542){gt(_0x320542,'onDisconnectEvents');const _0x258990=Xt(_0x320542),_0x2b47e2=En();Si(_0x320542['onDisconnect_'],w(),(_0xe9da00,_0x49b024)=>{const _0x3991b3=ta(_0xe9da00,_0x49b024,_0x320542['serverSyncTree_'],_0x258990);pt(_0x2b47e2,_0xe9da00,_0x3991b3);});let _0x1fd43f=[];Si(_0x2b47e2,w(),(_0x2024d4,_0x2b4f9a)=>{_0x1fd43f=_0x1fd43f['concat'](Yt(_0x320542['serverSyncTree_'],_0x2024d4,_0x2b4f9a));const _0x9a37ac=Is(_0x320542,_0x2024d4);ct(_0x320542,_0x9a37ac);}),_0x320542['onDisconnect_']=En(),V(_0x320542['eventQueue_'],w(),_0x1fd43f);}function bd(_0x232ce2,_0x32e306,_0x482c11){_0x232ce2['server_']['onDisconnectCancel'](_0x32e306['toString'](),(_0x4d40b9,_0x5562af)=>{_0x4d40b9==='ok'&&Ti(_0x232ce2['onDisconnect_'],_0x32e306),be(_0x232ce2,_0x482c11,_0x4d40b9,_0x5562af);});}function yr(_0x3fbe4a,_0x4cf878,_0xf35532,_0x57020a){const _0x2a76a3=A(_0xf35532);_0x3fbe4a['server_']['onDisconnectPut'](_0x4cf878['toString'](),_0x2a76a3['val'](!0x0),(_0x51018b,_0x3932bf)=>{_0x51018b==='ok'&&pt(_0x3fbe4a['onDisconnect_'],_0x4cf878,_0x2a76a3),be(_0x3fbe4a,_0x57020a,_0x51018b,_0x3932bf);});}function Rd(_0x4f789b,_0x30ceb9,_0x8fa474,_0x334670,_0x479745){const _0x54735e=A(_0x8fa474,_0x334670);_0x4f789b['server_']['onDisconnectPut'](_0x30ceb9['toString'](),_0x54735e['val'](!0x0),(_0x4e2951,_0x4cd447)=>{_0x4e2951==='ok'&&pt(_0x4f789b['onDisconnect_'],_0x30ceb9,_0x54735e),be(_0x4f789b,_0x479745,_0x4e2951,_0x4cd447);});}function Ad(_0x59bc19,_0x194721,_0x1c07e0,_0x5ebeca){if(pn(_0x1c07e0)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x59bc19,_0x5ebeca,'ok',void 0x0);return;}_0x59bc19['server_']['onDisconnectMerge'](_0x194721['toString'](),_0x1c07e0,(_0xc0b208,_0x4ef2c0)=>{_0xc0b208==='ok'&&x(_0x1c07e0,(_0x2306fd,_0x19828a)=>{const _0x56a838=A(_0x19828a);pt(_0x59bc19['onDisconnect_'],k(_0x194721,_0x2306fd),_0x56a838);}),be(_0x59bc19,_0x5ebeca,_0xc0b208,_0x4ef2c0);});}function kd(_0x211902,_0x325fd5,_0x1aefdb){let _0x4f1ff3;y(_0x325fd5['_path'])==='.info'?_0x4f1ff3=Ni(_0x211902['infoSyncTree_'],_0x325fd5,_0x1aefdb):_0x4f1ff3=Ni(_0x211902['serverSyncTree_'],_0x325fd5,_0x1aefdb),oa(_0x211902['eventQueue_'],_0x325fd5['_path'],_0x4f1ff3);}function Pd(_0x545cae,_0x368e33,_0xad6801){let _0x1aefed;y(_0x368e33['_path'])==='.info'?_0x1aefed=An(_0x545cae['infoSyncTree_'],_0x368e33,_0xad6801):_0x1aefed=An(_0x545cae['serverSyncTree_'],_0x368e33,_0xad6801),oa(_0x545cae['eventQueue_'],_0x368e33['_path'],_0x1aefed);}function ha(_0x240575){_0x240575['persistentConnection_']&&_0x240575['persistentConnection_']['interrupt'](ca);}function Nd(_0x1f08c2){_0x1f08c2['persistentConnection_']&&_0x1f08c2['persistentConnection_']['resume'](ca);}function gt(_0x53bf52,..._0x2b1c34){let _0x1a5621='';_0x53bf52['persistentConnection_']&&(_0x1a5621=_0x53bf52['persistentConnection_']['id']+':'),L(_0x1a5621,..._0x2b1c34);}function be(_0x374c31,_0x225f4a,_0x3d8cb5,_0x524d5f){_0x225f4a&&ft(()=>{if(_0x3d8cb5==='ok')_0x225f4a(null);else{const _0x17d05d=(_0x3d8cb5||'error')['toUpperCase']();let _0x35f59b=_0x17d05d;_0x524d5f&&(_0x35f59b+=':\x20'+_0x524d5f);const _0x6228a=new Error(_0x35f59b);_0x6228a['code']=_0x17d05d,_0x225f4a(_0x6228a);}});}function Od(_0xb359bb,_0x474b4d,_0x54d6ce,_0x4dbf73,_0x2918ee,_0x54dd47){gt(_0xb359bb,'transaction\x20on\x20'+_0x474b4d);const _0x238be3={'path':_0x474b4d,'update':_0x54d6ce,'onComplete':_0x4dbf73,'status':null,'order':so(),'applyLocally':_0x54dd47,'retryCount':0x0,'unwatcher':_0x2918ee,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x45cccc=Es(_0xb359bb,_0x474b4d,void 0x0);_0x238be3['currentInputSnapshot']=_0x45cccc;const _0x4d270e=_0x238be3['update'](_0x45cccc['val']());if(_0x4d270e===void 0x0)_0x238be3['unwatcher'](),_0x238be3['currentOutputSnapshotRaw']=null,_0x238be3['currentOutputSnapshotResolved']=null,_0x238be3['onComplete']&&_0x238be3['onComplete'](null,!0x1,_0x238be3['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4d270e,_0x238be3['path']),_0x238be3['status']=0x0;const _0x213830=$n(_0xb359bb['transactionQueueTree_'],_0x474b4d),_0x45d4e7=je(_0x213830)||[];_0x45d4e7['push'](_0x238be3),gs(_0x213830,_0x45d4e7);let _0x14b0c7;typeof _0x4d270e=='object'&&_0x4d270e!==null&&Q(_0x4d270e,'.priority')?(_0x14b0c7=Le(_0x4d270e,'.priority'),f(Bt(_0x14b0c7),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x14b0c7=(Vn(_0xb359bb['serverSyncTree_'],_0x474b4d)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xfa946c=Xt(_0xb359bb),_0x19d544=A(_0x4d270e,_0x14b0c7),_0xc53381=fs(_0x19d544,_0x45cccc,_0xfa946c);_0x238be3['currentOutputSnapshotRaw']=_0x19d544,_0x238be3['currentOutputSnapshotResolved']=_0xc53381,_0x238be3['currentWriteId']=zn(_0xb359bb);const _0x11061c=as(_0xb359bb['serverSyncTree_'],_0x474b4d,_0xc53381,_0x238be3['currentWriteId'],_0x238be3['applyLocally']);V(_0xb359bb['eventQueue_'],_0x474b4d,_0x11061c),jn(_0xb359bb,_0xb359bb['transactionQueueTree_']);}}function Es(_0x4fa5a3,_0x320c5e,_0x15e675){return Vn(_0x4fa5a3['serverSyncTree_'],_0x320c5e,_0x15e675)||g['EMPTY_NODE'];}function jn(_0x5dd594,_0x118b8f=_0x5dd594['transactionQueueTree_']){if(_0x118b8f||Kn(_0x5dd594,_0x118b8f),je(_0x118b8f)){const _0x2f5108=da(_0x5dd594,_0x118b8f);f(_0x2f5108['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2f5108['every'](_0x469fea=>_0x469fea['status']===0x0)&&Dd(_0x5dd594,Qt(_0x118b8f),_0x2f5108);}else na(_0x118b8f)&&Gn(_0x118b8f,_0x408851=>{jn(_0x5dd594,_0x408851);});}function Dd(_0x110be0,_0x3009e9,_0xbc2927){const _0xb66ed7=_0xbc2927['map'](_0x1dee43=>_0x1dee43['currentWriteId']),_0x5f256e=Es(_0x110be0,_0x3009e9,_0xb66ed7);let _0x54141b=_0x5f256e;const _0x4498c8=_0x5f256e['hash']();for(let _0x405375=0x0;_0x405375<_0xbc2927['length'];_0x405375++){const _0x668c1e=_0xbc2927[_0x405375];f(_0x668c1e['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x668c1e['status']=0x1,_0x668c1e['retryCount']++;const _0x424ba0=F(_0x3009e9,_0x668c1e['path']);_0x54141b=_0x54141b['updateChild'](_0x424ba0,_0x668c1e['currentOutputSnapshotRaw']);}const _0x35d87b=_0x54141b['val'](!0x0),_0x19519b=_0x3009e9;_0x110be0['server_']['put'](_0x19519b['toString'](),_0x35d87b,_0x220ff4=>{gt(_0x110be0,'transaction\x20put\x20response',{'path':_0x19519b['toString'](),'status':_0x220ff4});let _0x124ed7=[];if(_0x220ff4==='ok'){const _0x4e4b63=[];for(let _0x30df7c=0x0;_0x30df7c<_0xbc2927['length'];_0x30df7c++)_0xbc2927[_0x30df7c]['status']=0x2,_0x124ed7=_0x124ed7['concat'](_e(_0x110be0['serverSyncTree_'],_0xbc2927[_0x30df7c]['currentWriteId'])),_0xbc2927[_0x30df7c]['onComplete']&&_0x4e4b63['push'](()=>_0xbc2927[_0x30df7c]['onComplete'](null,!0x0,_0xbc2927[_0x30df7c]['currentOutputSnapshotResolved'])),_0xbc2927[_0x30df7c]['unwatcher']();Kn(_0x110be0,$n(_0x110be0['transactionQueueTree_'],_0x3009e9)),jn(_0x110be0,_0x110be0['transactionQueueTree_']),V(_0x110be0['eventQueue_'],_0x3009e9,_0x124ed7);for(let _0x5a20ac=0x0;_0x5a20ac<_0x4e4b63['length'];_0x5a20ac++)ft(_0x4e4b63[_0x5a20ac]);}else{if(_0x220ff4==='datastale'){for(let _0x3400f3=0x0;_0x3400f3<_0xbc2927['length'];_0x3400f3++)_0xbc2927[_0x3400f3]['status']===0x3?_0xbc2927[_0x3400f3]['status']=0x4:_0xbc2927[_0x3400f3]['status']=0x0;}else{U('transaction\x20at\x20'+_0x19519b['toString']()+'\x20failed:\x20'+_0x220ff4);for(let _0x515c25=0x0;_0x515c25<_0xbc2927['length'];_0x515c25++)_0xbc2927[_0x515c25]['status']=0x4,_0xbc2927[_0x515c25]['abortReason']=_0x220ff4;}ct(_0x110be0,_0x3009e9);}},_0x4498c8);}function ct(_0x5178ef,_0x4b26aa){const _0x3e3f91=ua(_0x5178ef,_0x4b26aa),_0x1cf1b2=Qt(_0x3e3f91),_0xd05147=da(_0x5178ef,_0x3e3f91);return Md(_0x5178ef,_0xd05147,_0x1cf1b2),_0x1cf1b2;}function Md(_0x3c8cd5,_0x4523be,_0x34a714){if(_0x4523be['length']===0x0)return;const _0x1eaa9d=[];let _0x3b9c55=[];const _0x3055ee=_0x4523be['filter'](_0x22609a=>_0x22609a['status']===0x0)['map'](_0x3f2f3d=>_0x3f2f3d['currentWriteId']);for(let _0x2cf6cd=0x0;_0x2cf6cd<_0x4523be['length'];_0x2cf6cd++){const _0x39b355=_0x4523be[_0x2cf6cd],_0x4b5f19=F(_0x34a714,_0x39b355['path']);let _0x11f0dc=!0x1,_0x5145f5;if(f(_0x4b5f19!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x39b355['status']===0x4)_0x11f0dc=!0x0,_0x5145f5=_0x39b355['abortReason'],_0x3b9c55=_0x3b9c55['concat'](_e(_0x3c8cd5['serverSyncTree_'],_0x39b355['currentWriteId'],!0x0));else{if(_0x39b355['status']===0x0){if(_0x39b355['retryCount']>=yd)_0x11f0dc=!0x0,_0x5145f5='maxretry',_0x3b9c55=_0x3b9c55['concat'](_e(_0x3c8cd5['serverSyncTree_'],_0x39b355['currentWriteId'],!0x0));else{const _0x509b7b=Es(_0x3c8cd5,_0x39b355['path'],_0x3055ee);_0x39b355['currentInputSnapshot']=_0x509b7b;const _0x38aad9=_0x4523be[_0x2cf6cd]['update'](_0x509b7b['val']());if(_0x38aad9!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x38aad9,_0x39b355['path']);let _0x72d745=A(_0x38aad9);typeof _0x38aad9=='object'&&_0x38aad9!=null&&Q(_0x38aad9,'.priority')||(_0x72d745=_0x72d745['updatePriority'](_0x509b7b['getPriority']()));const _0x35d910=_0x39b355['currentWriteId'],_0x1837d5=Xt(_0x3c8cd5),_0x1d3c1f=fs(_0x72d745,_0x509b7b,_0x1837d5);_0x39b355['currentOutputSnapshotRaw']=_0x72d745,_0x39b355['currentOutputSnapshotResolved']=_0x1d3c1f,_0x39b355['currentWriteId']=zn(_0x3c8cd5),_0x3055ee['splice'](_0x3055ee['indexOf'](_0x35d910),0x1),_0x3b9c55=_0x3b9c55['concat'](as(_0x3c8cd5['serverSyncTree_'],_0x39b355['path'],_0x1d3c1f,_0x39b355['currentWriteId'],_0x39b355['applyLocally'])),_0x3b9c55=_0x3b9c55['concat'](_e(_0x3c8cd5['serverSyncTree_'],_0x35d910,!0x0));}else _0x11f0dc=!0x0,_0x5145f5='nodata',_0x3b9c55=_0x3b9c55['concat'](_e(_0x3c8cd5['serverSyncTree_'],_0x39b355['currentWriteId'],!0x0));}}}V(_0x3c8cd5['eventQueue_'],_0x34a714,_0x3b9c55),_0x3b9c55=[],_0x11f0dc&&(_0x4523be[_0x2cf6cd]['status']=0x2,function(_0xaec8a3){setTimeout(_0xaec8a3,Math['floor'](0x0));}(_0x4523be[_0x2cf6cd]['unwatcher']),_0x4523be[_0x2cf6cd]['onComplete']&&(_0x5145f5==='nodata'?_0x1eaa9d['push'](()=>_0x4523be[_0x2cf6cd]['onComplete'](null,!0x1,_0x4523be[_0x2cf6cd]['currentInputSnapshot'])):_0x1eaa9d['push'](()=>_0x4523be[_0x2cf6cd]['onComplete'](new Error(_0x5145f5),!0x1,null))));}Kn(_0x3c8cd5,_0x3c8cd5['transactionQueueTree_']);for(let _0x46a23b=0x0;_0x46a23b<_0x1eaa9d['length'];_0x46a23b++)ft(_0x1eaa9d[_0x46a23b]);jn(_0x3c8cd5,_0x3c8cd5['transactionQueueTree_']);}function ua(_0x328cc9,_0x40509f){let _0x1ed68a,_0x2eae8e=_0x328cc9['transactionQueueTree_'];for(_0x1ed68a=y(_0x40509f);_0x1ed68a!==null&&je(_0x2eae8e)===void 0x0;)_0x2eae8e=$n(_0x2eae8e,_0x1ed68a),_0x40509f=S(_0x40509f),_0x1ed68a=y(_0x40509f);return _0x2eae8e;}function da(_0x3394ab,_0x30d186){const _0x13c649=[];return fa(_0x3394ab,_0x30d186,_0x13c649),_0x13c649['sort']((_0x4a2134,_0x5060ed)=>_0x4a2134['order']-_0x5060ed['order']),_0x13c649;}function fa(_0x21ba82,_0x353dc2,_0x30baf0){const _0x222b77=je(_0x353dc2);if(_0x222b77){for(let _0x299fcc=0x0;_0x299fcc<_0x222b77['length'];_0x299fcc++)_0x30baf0['push'](_0x222b77[_0x299fcc]);}Gn(_0x353dc2,_0x2edc9f=>{fa(_0x21ba82,_0x2edc9f,_0x30baf0);});}function Kn(_0x3e26ad,_0x21002a){const _0x157c51=je(_0x21002a);if(_0x157c51){let _0x4868f5=0x0;for(let _0x265e64=0x0;_0x265e64<_0x157c51['length'];_0x265e64++)_0x157c51[_0x265e64]['status']!==0x2&&(_0x157c51[_0x4868f5]=_0x157c51[_0x265e64],_0x4868f5++);_0x157c51['length']=_0x4868f5,gs(_0x21002a,_0x157c51['length']>0x0?_0x157c51:void 0x0);}Gn(_0x21002a,_0x5cee0c=>{Kn(_0x3e26ad,_0x5cee0c);});}function Is(_0x3eae70,_0x7ae819){const _0x39694d=Qt(ua(_0x3eae70,_0x7ae819)),_0x4705a8=$n(_0x3eae70['transactionQueueTree_'],_0x7ae819);return ad(_0x4705a8,_0x538cfb=>{di(_0x3eae70,_0x538cfb);}),di(_0x3eae70,_0x4705a8),ia(_0x4705a8,_0xe3438a=>{di(_0x3eae70,_0xe3438a);}),_0x39694d;}function di(_0x595f40,_0x6d3db9){const _0xa00663=je(_0x6d3db9);if(_0xa00663){const _0xb45b2e=[];let _0xc8c05d=[],_0xcc097c=-0x1;for(let _0x1a9f15=0x0;_0x1a9f15<_0xa00663['length'];_0x1a9f15++)_0xa00663[_0x1a9f15]['status']===0x3||(_0xa00663[_0x1a9f15]['status']===0x1?(f(_0xcc097c===_0x1a9f15-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0xcc097c=_0x1a9f15,_0xa00663[_0x1a9f15]['status']=0x3,_0xa00663[_0x1a9f15]['abortReason']='set'):(f(_0xa00663[_0x1a9f15]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0xa00663[_0x1a9f15]['unwatcher'](),_0xc8c05d=_0xc8c05d['concat'](_e(_0x595f40['serverSyncTree_'],_0xa00663[_0x1a9f15]['currentWriteId'],!0x0)),_0xa00663[_0x1a9f15]['onComplete']&&_0xb45b2e['push'](_0xa00663[_0x1a9f15]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0xcc097c===-0x1?gs(_0x6d3db9,void 0x0):_0xa00663['length']=_0xcc097c+0x1,V(_0x595f40['eventQueue_'],Qt(_0x6d3db9),_0xc8c05d);for(let _0x46236a=0x0;_0x46236a<_0xb45b2e['length'];_0x46236a++)ft(_0xb45b2e[_0x46236a]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x241bba){let _0x1fb1fe='';const _0x872f82=_0x241bba['split']('/');for(let _0x5988c7=0x0;_0x5988c7<_0x872f82['length'];_0x5988c7++)if(_0x872f82[_0x5988c7]['length']>0x0){let _0x52f158=_0x872f82[_0x5988c7];try{_0x52f158=decodeURIComponent(_0x52f158['replace'](/\+/g,'\x20'));}catch{}_0x1fb1fe+='/'+_0x52f158;}return _0x1fb1fe;}function xd(_0xf6a0fb){const _0x3fbd09={};_0xf6a0fb['charAt'](0x0)==='?'&&(_0xf6a0fb=_0xf6a0fb['substring'](0x1));for(const _0x467b64 of _0xf6a0fb['split']('&')){if(_0x467b64['length']===0x0)continue;const _0x63bf5=_0x467b64['split']('=');_0x63bf5['length']===0x2?_0x3fbd09[decodeURIComponent(_0x63bf5[0x0])]=decodeURIComponent(_0x63bf5[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x467b64+'\x27\x20in\x20query\x20\x27'+_0xf6a0fb+'\x27');}return _0x3fbd09;}const vr=function(_0x54398f,_0x2bd03c){const _0x3eaa0d=Fd(_0x54398f),_0x429c77=_0x3eaa0d['namespace'];_0x3eaa0d['domain']==='firebase.com'&&ae(_0x3eaa0d['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x429c77||_0x429c77==='undefined')&&_0x3eaa0d['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x3eaa0d['secure']||$l();const _0x710b77=_0x3eaa0d['scheme']==='ws'||_0x3eaa0d['scheme']==='wss';return{'repoInfo':new yo(_0x3eaa0d['host'],_0x3eaa0d['secure'],_0x429c77,_0x710b77,_0x2bd03c,'',_0x429c77!==_0x3eaa0d['subdomain']),'path':new C(_0x3eaa0d['pathString'])};},Fd=function(_0x5ecdf7){let _0x3c7903='',_0x10e192='',_0x239358='',_0x2aba62='',_0x59384f='',_0x1f6b04=!0x0,_0x2e9eef='https',_0x5d69a0=0x1bb;if(typeof _0x5ecdf7=='string'){let _0x46232a=_0x5ecdf7['indexOf']('//');_0x46232a>=0x0&&(_0x2e9eef=_0x5ecdf7['substring'](0x0,_0x46232a-0x1),_0x5ecdf7=_0x5ecdf7['substring'](_0x46232a+0x2));let _0x2f7b9c=_0x5ecdf7['indexOf']('/');_0x2f7b9c===-0x1&&(_0x2f7b9c=_0x5ecdf7['length']);let _0x2898ed=_0x5ecdf7['indexOf']('?');_0x2898ed===-0x1&&(_0x2898ed=_0x5ecdf7['length']),_0x3c7903=_0x5ecdf7['substring'](0x0,Math['min'](_0x2f7b9c,_0x2898ed)),_0x2f7b9c<_0x2898ed&&(_0x2aba62=Ld(_0x5ecdf7['substring'](_0x2f7b9c,_0x2898ed)));const _0x4746b2=xd(_0x5ecdf7['substring'](Math['min'](_0x5ecdf7['length'],_0x2898ed)));_0x46232a=_0x3c7903['indexOf'](':'),_0x46232a>=0x0?(_0x1f6b04=_0x2e9eef==='https'||_0x2e9eef==='wss',_0x5d69a0=parseInt(_0x3c7903['substring'](_0x46232a+0x1),0xa)):_0x46232a=_0x3c7903['length'];const _0x482244=_0x3c7903['slice'](0x0,_0x46232a);if(_0x482244['toLowerCase']()==='localhost')_0x10e192='localhost';else{if(_0x482244['split']('.')['length']<=0x2)_0x10e192=_0x482244;else{const _0x53a62d=_0x3c7903['indexOf']('.');_0x239358=_0x3c7903['substring'](0x0,_0x53a62d)['toLowerCase'](),_0x10e192=_0x3c7903['substring'](_0x53a62d+0x1),_0x59384f=_0x239358;}}'ns'in _0x4746b2&&(_0x59384f=_0x4746b2['ns']);}return{'host':_0x3c7903,'port':_0x5d69a0,'domain':_0x10e192,'subdomain':_0x239358,'secure':_0x1f6b04,'scheme':_0x2e9eef,'pathString':_0x2aba62,'namespace':_0x59384f};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x575cd1=0x0;const _0x51013c=[];return function(_0x27d1f2){const _0x4e933b=_0x27d1f2===_0x575cd1;_0x575cd1=_0x27d1f2;let _0x1f9de9;const _0x26908a=new Array(0x8);for(_0x1f9de9=0x7;_0x1f9de9>=0x0;_0x1f9de9--)_0x26908a[_0x1f9de9]=Er['charAt'](_0x27d1f2%0x40),_0x27d1f2=Math['floor'](_0x27d1f2/0x40);f(_0x27d1f2===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x4a034f=_0x26908a['join']('');if(_0x4e933b){for(_0x1f9de9=0xb;_0x1f9de9>=0x0&&_0x51013c[_0x1f9de9]===0x3f;_0x1f9de9--)_0x51013c[_0x1f9de9]=0x0;_0x51013c[_0x1f9de9]++;}else{for(_0x1f9de9=0x0;_0x1f9de9<0xc;_0x1f9de9++)_0x51013c[_0x1f9de9]=Math['floor'](Math['random']()*0x40);}for(_0x1f9de9=0x0;_0x1f9de9<0xc;_0x1f9de9++)_0x4a034f+=Er['charAt'](_0x51013c[_0x1f9de9]);return f(_0x4a034f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x4a034f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x1600a5,_0x4114cc,_0x436661,_0x5966b4){this['eventType']=_0x1600a5,this['eventRegistration']=_0x4114cc,this['snapshot']=_0x436661,this['prevName']=_0x5966b4;}['getPath'](){const _0x509db0=this['snapshot']['ref'];return this['eventType']==='value'?_0x509db0['_path']:_0x509db0['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x3cb488,_0x2895cb,_0x5a912b){this['eventRegistration']=_0x3cb488,this['error']=_0x2895cb,this['path']=_0x5a912b;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x208943,_0x1b5ffb){this['snapshotCallback']=_0x208943,this['cancelCallback']=_0x1b5ffb;}['onValue'](_0x84ffc,_0x3dca9f){this['snapshotCallback']['call'](null,_0x84ffc,_0x3dca9f);}['onCancel'](_0x32faa5){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x32faa5);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1550bb){return this['snapshotCallback']===_0x1550bb['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1550bb['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1550bb['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x29ce4f,_0x1c7795){this['_repo']=_0x29ce4f,this['_path']=_0x1c7795;}['cancel'](){const _0x24ebe9=new H();return bd(this['_repo'],this['_path'],_0x24ebe9['wrapCallback'](()=>{})),_0x24ebe9['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x53a67a=new H();return yr(this['_repo'],this['_path'],null,_0x53a67a['wrapCallback'](()=>{})),_0x53a67a['promise'];}['set'](_0x115837){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x115837,this['_path'],!0x1);const _0x5cddba=new H();return yr(this['_repo'],this['_path'],_0x115837,_0x5cddba['wrapCallback'](()=>{})),_0x5cddba['promise'];}['setWithPriority'](_0x855bd2,_0x4f3164){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x855bd2,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x4f3164);const _0x3ea2de=new H();return Rd(this['_repo'],this['_path'],_0x855bd2,_0x4f3164,_0x3ea2de['wrapCallback'](()=>{})),_0x3ea2de['promise'];}['update'](_0x38d605){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x38d605,this['_path']);const _0x29a1e9=new H();return Ad(this['_repo'],this['_path'],_0x38d605,_0x29a1e9['wrapCallback'](()=>{})),_0x29a1e9['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x4a6190,_0x368175,_0x10d7c2,_0x1823f5){this['_repo']=_0x4a6190,this['_path']=_0x368175,this['_queryParams']=_0x10d7c2,this['_orderByCalled']=_0x1823f5;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x473ca7=sr(this['_queryParams']),_0x25afdf=$i(_0x473ca7);return _0x25afdf==='{}'?'default':_0x25afdf;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x48166e){if(_0x48166e=P(_0x48166e),!(_0x48166e instanceof Ae))return!0x1;const _0x3f6e5a=this['_repo']===_0x48166e['_repo'],_0x1e7bbf=Ki(this['_path'],_0x48166e['_path']),_0x3a4239=this['_queryIdentifier']===_0x48166e['_queryIdentifier'];return _0x3f6e5a&&_0x1e7bbf&&_0x3a4239;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x3ffab8,_0x4a9944){if(_0x3ffab8['_orderByCalled']===!0x0)throw new Error(_0x4a9944+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x24d9e3){let _0x5e38d2=null,_0x2aca09=null;if(_0x24d9e3['hasStart']()&&(_0x5e38d2=_0x24d9e3['getIndexStartValue']()),_0x24d9e3['hasEnd']()&&(_0x2aca09=_0x24d9e3['getIndexEndValue']()),_0x24d9e3['getIndex']()===ve){const _0x5a53a8='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x455f33='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x24d9e3['hasStart']()){if(_0x24d9e3['getIndexStartName']()!==We)throw new Error(_0x5a53a8);if(typeof _0x5e38d2!='string')throw new Error(_0x455f33);}if(_0x24d9e3['hasEnd']()){if(_0x24d9e3['getIndexEndName']()!==we)throw new Error(_0x5a53a8);if(typeof _0x2aca09!='string')throw new Error(_0x455f33);}}else{if(_0x24d9e3['getIndex']()===R){if(_0x5e38d2!=null&&!Bt(_0x5e38d2)||_0x2aca09!=null&&!Bt(_0x2aca09))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x24d9e3['getIndex']()instanceof Ji||_0x24d9e3['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x5e38d2!=null&&typeof _0x5e38d2=='object'||_0x2aca09!=null&&typeof _0x2aca09=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x406c73){if(_0x406c73['hasStart']()&&_0x406c73['hasEnd']()&&_0x406c73['hasLimit']()&&!_0x406c73['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x3562fa,_0x44a1e9){super(_0x3562fa,_0x44a1e9,new Zi(),!0x1);}get['parent'](){const _0x5bea8f=Ro(this['_path']);return _0x5bea8f===null?null:new ee(this['_repo'],_0x5bea8f);}get['root'](){let _0x477d79=this;for(;_0x477d79['parent']!==null;)_0x477d79=_0x477d79['parent'];return _0x477d79;}}class lt{constructor(_0x49c15a,_0x176db5,_0x250270){this['_node']=_0x49c15a,this['ref']=_0x176db5,this['_index']=_0x250270;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5838c9){const _0x30018f=new C(_0x5838c9),_0x5773e1=Vt(this['ref'],_0x5838c9);return new lt(this['_node']['getChild'](_0x30018f),_0x5773e1,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x352631){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x434c41,_0xa3639e)=>_0x352631(new lt(_0xa3639e,Vt(this['ref'],_0x434c41),R)));}['hasChild'](_0x21343b){const _0x2d244d=new C(_0x21343b);return!this['_node']['getChild'](_0x2d244d)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x44c6f7,_0x2aa6e0){return _0x44c6f7=P(_0x44c6f7),_0x44c6f7['_checkNotDeleted']('ref'),_0x2aa6e0!==void 0x0?Vt(_0x44c6f7['_root'],_0x2aa6e0):_0x44c6f7['_root'];}function Vt(_0x537cf9,_0x308ffb){return _0x537cf9=P(_0x537cf9),y(_0x537cf9['_path'])===null?pd('child','path',_0x308ffb):ys('child','path',_0x308ffb),new ee(_0x537cf9['_repo'],k(_0x537cf9['_path'],_0x308ffb));}function v_(_0x39fff3){return _0x39fff3=P(_0x39fff3),new Vd(_0x39fff3['_repo'],_0x39fff3['_path']);}function E_(_0x16dd00,_0x572cc7){_0x16dd00=P(_0x16dd00),Me('push',_0x16dd00['_path']),He('push',_0x572cc7,_0x16dd00['_path'],!0x0);const _0x1fc86c=la(_0x16dd00['_repo']),_0x247830=Ud(_0x1fc86c),_0x1660c5=Vt(_0x16dd00,_0x247830),_0x3c7b32=Vt(_0x16dd00,_0x247830);let _0x576842;return _0x572cc7!=null?_0x576842=Hd(_0x3c7b32,_0x572cc7)['then'](()=>_0x3c7b32):_0x576842=Promise['resolve'](_0x3c7b32),_0x1660c5['then']=_0x576842['then']['bind'](_0x576842),_0x1660c5['catch']=_0x576842['then']['bind'](_0x576842,void 0x0),_0x1660c5;}function Hd(_0x3c84c3,_0x44fb78){_0x3c84c3=P(_0x3c84c3),Me('set',_0x3c84c3['_path']),He('set',_0x44fb78,_0x3c84c3['_path'],!0x1);const _0x5f2528=new H();return Cd(_0x3c84c3['_repo'],_0x3c84c3['_path'],_0x44fb78,null,_0x5f2528['wrapCallback'](()=>{})),_0x5f2528['promise'];}function I_(_0x59d11d,_0x23fa82){ra('update',_0x23fa82,_0x59d11d['_path']);const _0x161473=new H();return Td(_0x59d11d['_repo'],_0x59d11d['_path'],_0x23fa82,_0x161473['wrapCallback'](()=>{})),_0x161473['promise'];}function w_(_0x44c91e){_0x44c91e=P(_0x44c91e);const _0x2c9b5a=new pa(()=>{}),_0x2414c3=new Qn(_0x2c9b5a);return wd(_0x44c91e['_repo'],_0x44c91e,_0x2414c3)['then'](_0x1b5189=>new lt(_0x1b5189,new ee(_0x44c91e['_repo'],_0x44c91e['_path']),_0x44c91e['_queryParams']['getIndex']()));}class Qn{constructor(_0x28af9f){this['callbackContext']=_0x28af9f;}['respondsTo'](_0x4e91bc){return _0x4e91bc==='value';}['createEvent'](_0x1c187b,_0x5b9e11){const _0x4cfae3=_0x5b9e11['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x1c187b['snapshotNode'],new ee(_0x5b9e11['_repo'],_0x5b9e11['_path']),_0x4cfae3));}['getEventRunner'](_0x409184){return _0x409184['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x409184['error']):()=>this['callbackContext']['onValue'](_0x409184['snapshot'],null);}['createCancelEvent'](_0x4388f9,_0x123f18){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x4388f9,_0x123f18):null;}['matches'](_0x41c9a2){return _0x41c9a2 instanceof Qn?!_0x41c9a2['callbackContext']||!this['callbackContext']?!0x0:_0x41c9a2['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x34cd13,_0x290658,_0xb20317,_0x33426e,_0xa7f5a0){const _0x3830b2=new pa(_0xb20317,void 0x0),_0x22286d=new Qn(_0x3830b2);return kd(_0x34cd13['_repo'],_0x34cd13,_0x22286d),()=>Pd(_0x34cd13['_repo'],_0x34cd13,_0x22286d);}function Gd(_0x4884f8,_0x50322b,_0x425a23,_0x47a439){return $d(_0x4884f8,'value',_0x50322b);}class mt{}class ma extends mt{constructor(_0x41da10,_0x14b251){super(),this['_value']=_0x41da10,this['_key']=_0x14b251,this['type']='endAt';}['_apply'](_0x4d6838){He('endAt',this['_value'],_0x4d6838['_path'],!0x0);const _0x246496=Jh(_0x4d6838['_queryParams'],this['_value'],this['_key']);if(ga(_0x246496),Yn(_0x246496),_0x4d6838['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x4d6838['_repo'],_0x4d6838['_path'],_0x246496,_0x4d6838['_orderByCalled']);}}function C_(_0x28bd0c,_0x797da5){return new ma(_0x28bd0c,_0x797da5);}class ya extends mt{constructor(_0x5ce90b,_0x3da6c6){super(),this['_value']=_0x5ce90b,this['_key']=_0x3da6c6,this['type']='startAt';}['_apply'](_0x20190e){He('startAt',this['_value'],_0x20190e['_path'],!0x0);const _0x19b7a8=Qh(_0x20190e['_queryParams'],this['_value'],this['_key']);if(ga(_0x19b7a8),Yn(_0x19b7a8),_0x20190e['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x20190e['_repo'],_0x20190e['_path'],_0x19b7a8,_0x20190e['_orderByCalled']);}}function T_(_0x597a5b=null,_0x3477eb){return new ya(_0x597a5b,_0x3477eb);}class qd extends mt{constructor(_0x4a8433){super(),this['_limit']=_0x4a8433,this['type']='limitToFirst';}['_apply'](_0x3924d0){if(_0x3924d0['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x3924d0['_repo'],_0x3924d0['_path'],Yh(_0x3924d0['_queryParams'],this['_limit']),_0x3924d0['_orderByCalled']);}}function S_(_0x1822a1){if(Math['floor'](_0x1822a1)!==_0x1822a1||_0x1822a1<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x1822a1);}class zd extends mt{constructor(_0x2c2ea3){super(),this['_path']=_0x2c2ea3,this['type']='orderByChild';}['_apply'](_0x34b09c){_a(_0x34b09c,'orderByChild');const _0x1b407d=new C(this['_path']);if(v(_0x1b407d))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3cbe4d=new Ji(_0x1b407d),_0x5630b5=xo(_0x34b09c['_queryParams'],_0x3cbe4d);return Yn(_0x5630b5),new Ae(_0x34b09c['_repo'],_0x34b09c['_path'],_0x5630b5,!0x0);}}function b_(_0x27f165){if(_0x27f165==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x27f165==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x27f165==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x27f165),new zd(_0x27f165);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x333a3b){_a(_0x333a3b,'orderByKey');const _0x510ec9=xo(_0x333a3b['_queryParams'],ve);return Yn(_0x510ec9),new Ae(_0x333a3b['_repo'],_0x333a3b['_path'],_0x510ec9,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x140220,_0x16f5c2){super(),this['_value']=_0x140220,this['_key']=_0x16f5c2,this['type']='equalTo';}['_apply'](_0x556fe4){if(He('equalTo',this['_value'],_0x556fe4['_path'],!0x1),_0x556fe4['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x556fe4['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x556fe4));}}function A_(_0x1ff4ff,_0x57e77b){return new Kd(_0x1ff4ff,_0x57e77b);}function k_(_0x396767,..._0x1c4fae){let _0x2fbc17=P(_0x396767);for(const _0x49731d of _0x1c4fae)_0x2fbc17=_0x49731d['_apply'](_0x2fbc17);return _0x2fbc17;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x1ddbd5,_0x131158,_0x411739,_0x58c5d4){const _0x2009a7=_0x131158['lastIndexOf'](':'),_0x8d9031=_0x131158['substring'](0x0,_0x2009a7),_0x29e33d=qt(_0x8d9031);_0x1ddbd5['repoInfo_']=new yo(_0x131158,_0x29e33d,_0x1ddbd5['repoInfo_']['namespace'],_0x1ddbd5['repoInfo_']['webSocketOnly'],_0x1ddbd5['repoInfo_']['nodeAdmin'],_0x1ddbd5['repoInfo_']['persistenceKey'],_0x1ddbd5['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x411739),_0x58c5d4&&(_0x1ddbd5['authTokenProvider_']=_0x58c5d4);}function Xd(_0x335f17,_0x694cba,_0x482af5,_0x2c0702,_0x5b6850){let _0x30896b=_0x2c0702||_0x335f17['options']['databaseURL'];_0x30896b===void 0x0&&(_0x335f17['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x335f17['options']['projectId']),_0x30896b=_0x335f17['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x19233b=vr(_0x30896b,_0x5b6850),_0x154a69=_0x19233b['repoInfo'],_0x1a16b2;typeof process<'u'&&Bs&&(_0x1a16b2=Bs[Yd]),_0x1a16b2?(_0x30896b='http://'+_0x1a16b2+'?ns='+_0x154a69['namespace'],_0x19233b=vr(_0x30896b,_0x5b6850),_0x154a69=_0x19233b['repoInfo']):_0x19233b['repoInfo']['secure'];const _0x49d473=new eh(_0x335f17['name'],_0x335f17['options'],_0x694cba);_d('Invalid\x20Firebase\x20Database\x20URL',_0x19233b),v(_0x19233b['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3d9c6f=ef(_0x154a69,_0x335f17,_0x49d473,new Zl(_0x335f17,_0x482af5));return new tf(_0x3d9c6f,_0x335f17);}function Zd(_0x1ab16c,_0x5a5f86){const _0x4e3a99=Di[_0x5a5f86];(!_0x4e3a99||_0x4e3a99[_0x1ab16c['key']]!==_0x1ab16c)&&ae('Database\x20'+_0x5a5f86+'('+_0x1ab16c['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x1ab16c),delete _0x4e3a99[_0x1ab16c['key']];}function ef(_0x34c49a,_0x788b2a,_0x336dea,_0x31d9d6){let _0x86e1c4=Di[_0x788b2a['name']];_0x86e1c4||(_0x86e1c4={},Di[_0x788b2a['name']]=_0x86e1c4);let _0x229233=_0x86e1c4[_0x34c49a['toURLString']()];return _0x229233&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x229233=new vd(_0x34c49a,Qd,_0x336dea,_0x31d9d6),_0x86e1c4[_0x34c49a['toURLString']()]=_0x229233,_0x229233;}class tf{constructor(_0x26e86e,_0x13d7e3){this['_repoInternal']=_0x26e86e,this['app']=_0x13d7e3,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x240b6b){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x240b6b+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x54ca98=Zr(),_0x4a46c5){const _0x49342d=Hi(_0x54ca98,'database')['getImmediate']({'identifier':_0x4a46c5});if(!_0x49342d['_instanceStarted']){const _0x490696=hc('database');_0x490696&&nf(_0x49342d,..._0x490696);}return _0x49342d;}function nf(_0x3fce7e,_0x34f4a9,_0x20d6a1,_0x5bb59a={}){_0x3fce7e=P(_0x3fce7e),_0x3fce7e['_checkNotDeleted']('useEmulator');const _0x1aa1c6=_0x34f4a9+':'+_0x20d6a1,_0x5d4f31=_0x3fce7e['_repoInternal'];if(_0x3fce7e['_instanceStarted']){if(_0x1aa1c6===_0x3fce7e['_repoInternal']['repoInfo_']['host']&&xe(_0x5bb59a,_0x5d4f31['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x435fe7;if(_0x5d4f31['repoInfo_']['nodeAdmin'])_0x5bb59a['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x435fe7=new an(an['OWNER']);else{if(_0x5bb59a['mockUserToken']){const _0x115005=typeof _0x5bb59a['mockUserToken']=='string'?_0x5bb59a['mockUserToken']:uc(_0x5bb59a['mockUserToken'],_0x3fce7e['app']['options']['projectId']);_0x435fe7=new an(_0x115005);}}qt(_0x34f4a9)&&Qr(_0x34f4a9),Jd(_0x5d4f31,_0x1aa1c6,_0x5bb59a,_0x435fe7);}function N_(_0x17ef8c){_0x17ef8c=P(_0x17ef8c),_0x17ef8c['_checkNotDeleted']('goOffline'),ha(_0x17ef8c['_repo']);}function O_(_0xfbb7fe){_0xfbb7fe=P(_0xfbb7fe),_0xfbb7fe['_checkNotDeleted']('goOnline'),Nd(_0xfbb7fe['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x30322b){Ul(dt),st(new Fe('database',(_0x748975,{instanceIdentifier:_0x248785})=>{const _0x391128=_0x748975['getProvider']('app')['getImmediate'](),_0x2d2264=_0x748975['getProvider']('auth-internal'),_0x320ccf=_0x748975['getProvider']('app-check-internal');return Xd(_0x391128,_0x2d2264,_0x320ccf,_0x248785);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x30322b),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x20798c,_0x49f84d){this['committed']=_0x20798c,this['snapshot']=_0x49f84d;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x4e8e3d,_0x3dc95e,_0xa4570a){if(_0x4e8e3d=P(_0x4e8e3d),Me('Reference.transaction',_0x4e8e3d['_path']),_0x4e8e3d['key']==='.length'||_0x4e8e3d['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4e8e3d['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1e27bd=!0x0,_0x3038d8=new H(),_0x2c7e1c=(_0x4fb3b1,_0x2b3f21,_0x4ae458)=>{let _0x48859e=null;_0x4fb3b1?_0x3038d8['reject'](_0x4fb3b1):(_0x48859e=new lt(_0x4ae458,new ee(_0x4e8e3d['_repo'],_0x4e8e3d['_path']),R),_0x3038d8['resolve'](new of(_0x2b3f21,_0x48859e)));},_0x1f3ed8=Gd(_0x4e8e3d,()=>{});return Od(_0x4e8e3d['_repo'],_0x4e8e3d['_path'],_0x3dc95e,_0x2c7e1c,_0x1f3ed8,_0x1e27bd),_0x3038d8['promise'];}se['prototype']['simpleListen']=function(_0x23a2a0,_0x104790){this['sendRequest']('q',{'p':_0x23a2a0},_0x104790);},se['prototype']['echo']=function(_0x102765,_0x1c1b07){this['sendRequest']('echo',{'d':_0x102765},_0x1c1b07);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x123a7e,..._0x261c6){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x123a7e,..._0x261c6);}function cn(_0x16da15,..._0x3f06b3){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x16da15,..._0x3f06b3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x594958,..._0x2c3684){throw ws(_0x594958,..._0x2c3684);}function X(_0x908789,..._0x49fb4c){return ws(_0x908789,..._0x49fb4c);}function Ia(_0x3e7242,_0x1780a5,_0x50f1f5){const _0x5df9f3={...af(),[_0x1780a5]:_0x50f1f5};return new Gt('auth','Firebase',_0x5df9f3)['create'](_0x1780a5,{'appName':_0x3e7242['name']});}function re(_0x1e86f8){return Ia(_0x1e86f8,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x5d0947,..._0x18243c){if(typeof _0x5d0947!='string'){const _0x514792=_0x18243c[0x0],_0x1a46d0=[..._0x18243c['slice'](0x1)];return _0x1a46d0[0x0]&&(_0x1a46d0[0x0]['appName']=_0x5d0947['name']),_0x5d0947['_errorFactory']['create'](_0x514792,..._0x1a46d0);}return Ea['create'](_0x5d0947,..._0x18243c);}function m(_0xeabe03,_0x26ab33,..._0xa876eb){if(!_0xeabe03)throw ws(_0x26ab33,..._0xa876eb);}function ne(_0x5586ca){const _0x471c67='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x5586ca;throw cn(_0x471c67),new Error(_0x471c67);}function ce(_0x447405,_0x502f7c){_0x447405||ne(_0x502f7c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0xe340a6;return typeof self<'u'&&((_0xe340a6=self['location'])==null?void 0x0:_0xe340a6['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0xd1297c;return typeof self<'u'&&((_0xd1297c=self['location'])==null?void 0x0:_0xd1297c['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x5cbc4c=navigator;return _0x5cbc4c['languages']&&_0x5cbc4c['languages'][0x0]||_0x5cbc4c['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x1832b1,_0x34621e){this['shortDelay']=_0x1832b1,this['longDelay']=_0x34621e,ce(_0x34621e>_0x1832b1,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0xc49c1a,_0x49fd94){ce(_0xc49c1a['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x418f26}=_0xc49c1a['emulator'];return _0x49fd94?''+_0x418f26+(_0x49fd94['startsWith']('/')?_0x49fd94['slice'](0x1):_0x49fd94):_0x418f26;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x566137,_0x4dc6e0,_0x4520ec){this['fetchImpl']=_0x566137,_0x4dc6e0&&(this['headersImpl']=_0x4dc6e0),_0x4520ec&&(this['responseImpl']=_0x4520ec);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0xedcc87,_0x52ccfa){return _0xedcc87['tenantId']&&!_0x52ccfa['tenantId']?{..._0x52ccfa,'tenantId':_0xedcc87['tenantId']}:_0x52ccfa;}async function Pe(_0x3bce75,_0x4e283b,_0x3db75d,_0x402f9f,_0x5b91bc={}){return Ca(_0x3bce75,_0x5b91bc,async()=>{let _0x408486={},_0x552da6={};_0x402f9f&&(_0x4e283b==='GET'?_0x552da6=_0x402f9f:_0x408486={'body':JSON['stringify'](_0x402f9f)});const _0x6facf4=ut({..._0x552da6,'key':_0x3bce75['config']['apiKey']})['slice'](0x1),_0x38c136=await _0x3bce75['_getAdditionalHeaders']();_0x38c136['Content-Type']='application/json',_0x3bce75['languageCode']&&(_0x38c136['X-Firebase-Locale']=_0x3bce75['languageCode']);const _0x1adab5={'method':_0x4e283b,'headers':_0x38c136,..._0x408486};return dc()||(_0x1adab5['referrerPolicy']='strict-origin-when-cross-origin'),_0x3bce75['emulatorConfig']&&qt(_0x3bce75['emulatorConfig']['host'])&&(_0x1adab5['credentials']='include'),wa['fetch']()(await Ta(_0x3bce75,_0x3bce75['config']['apiHost'],_0x3db75d,_0x6facf4),_0x1adab5);});}async function Ca(_0x131dc1,_0x16322a,_0x3c8934){_0x131dc1['_canInitEmulator']=!0x1;const _0x2b1faf={...df,..._0x16322a};try{const _0x363477=new gf(_0x131dc1),_0x2887b8=await Promise['race']([_0x3c8934(),_0x363477['promise']]);_0x363477['clearNetworkTimeout']();const _0x5635c5=await _0x2887b8['json']();if('needConfirmation'in _0x5635c5)throw on(_0x131dc1,'account-exists-with-different-credential',_0x5635c5);if(_0x2887b8['ok']&&!('errorMessage'in _0x5635c5))return _0x5635c5;{const _0x182313=_0x2887b8['ok']?_0x5635c5['errorMessage']:_0x5635c5['error']['message'],[_0x3003a0,_0x3707cf]=_0x182313['split']('\x20:\x20');if(_0x3003a0==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x131dc1,'credential-already-in-use',_0x5635c5);if(_0x3003a0==='EMAIL_EXISTS')throw on(_0x131dc1,'email-already-in-use',_0x5635c5);if(_0x3003a0==='USER_DISABLED')throw on(_0x131dc1,'user-disabled',_0x5635c5);const _0x5b2a18=_0x2b1faf[_0x3003a0]||_0x3003a0['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x3707cf)throw Ia(_0x131dc1,_0x5b2a18,_0x3707cf);Y(_0x131dc1,_0x5b2a18);}}catch(_0x4f4e9e){if(_0x4f4e9e instanceof Re)throw _0x4f4e9e;Y(_0x131dc1,'network-request-failed',{'message':String(_0x4f4e9e)});}}async function en(_0x38ada3,_0x37b884,_0x3f0db0,_0x675738,_0x2484f9={}){const _0x27abd6=await Pe(_0x38ada3,_0x37b884,_0x3f0db0,_0x675738,_0x2484f9);return'mfaPendingCredential'in _0x27abd6&&Y(_0x38ada3,'multi-factor-auth-required',{'_serverResponse':_0x27abd6}),_0x27abd6;}async function Ta(_0x53869b,_0x28492b,_0xfa5dc1,_0x126953){const _0x54cbe6=''+_0x28492b+_0xfa5dc1+'?'+_0x126953,_0x5385d3=_0x53869b,_0x14d672=_0x5385d3['config']['emulator']?Cs(_0x53869b['config'],_0x54cbe6):_0x53869b['config']['apiScheme']+'://'+_0x54cbe6;return ff['includes'](_0xfa5dc1)&&(await _0x5385d3['_persistenceManagerAvailable'],_0x5385d3['_getPersistenceType']()==='COOKIE')?_0x5385d3['_getPersistence']()['_getFinalTarget'](_0x14d672)['toString']():_0x14d672;}function _f(_0x39dc40){switch(_0x39dc40){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x262f12){this['auth']=_0x262f12,this['timer']=null,this['promise']=new Promise((_0x3f0e7a,_0xec6eb7)=>{this['timer']=setTimeout(()=>_0xec6eb7(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x237fde,_0xc1b487,_0x5b524d){const _0x42aa55={'appName':_0x237fde['name']};_0x5b524d['email']&&(_0x42aa55['email']=_0x5b524d['email']),_0x5b524d['phoneNumber']&&(_0x42aa55['phoneNumber']=_0x5b524d['phoneNumber']);const _0x1542e7=X(_0x237fde,_0xc1b487,_0x42aa55);return _0x1542e7['customData']['_tokenResponse']=_0x5b524d,_0x1542e7;}function wr(_0xac4fec){return _0xac4fec!==void 0x0&&_0xac4fec['enterprise']!==void 0x0;}class mf{constructor(_0x1840ec){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x1840ec['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x1840ec['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x1840ec['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x293e8c){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3f4411 of this['recaptchaEnforcementState'])if(_0x3f4411['provider']&&_0x3f4411['provider']===_0x293e8c)return _f(_0x3f4411['enforcementState']);return null;}['isProviderEnabled'](_0x49eb45){return this['getProviderEnforcementState'](_0x49eb45)==='ENFORCE'||this['getProviderEnforcementState'](_0x49eb45)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0xd64a82,_0x5c3ff2){return Pe(_0xd64a82,'GET','/v2/recaptchaConfig',ke(_0xd64a82,_0x5c3ff2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x10d8a2,_0x46f13e){return Pe(_0x10d8a2,'POST','/v1/accounts:delete',_0x46f13e);}async function Pn(_0x59a124,_0x52ab8e){return Pe(_0x59a124,'POST','/v1/accounts:lookup',_0x52ab8e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x8e93c6){if(_0x8e93c6)try{const _0x26b1bd=new Date(Number(_0x8e93c6));if(!isNaN(_0x26b1bd['getTime']()))return _0x26b1bd['toUTCString']();}catch{}}async function Ef(_0x4e8291,_0x208416=!0x1){const _0x71d0c2=P(_0x4e8291),_0x56af04=await _0x71d0c2['getIdToken'](_0x208416),_0x2541e9=Ts(_0x56af04);m(_0x2541e9&&_0x2541e9['exp']&&_0x2541e9['auth_time']&&_0x2541e9['iat'],_0x71d0c2['auth'],'internal-error');const _0x56d3ad=typeof _0x2541e9['firebase']=='object'?_0x2541e9['firebase']:void 0x0,_0x44049d=_0x56d3ad==null?void 0x0:_0x56d3ad['sign_in_provider'];return{'claims':_0x2541e9,'token':_0x56af04,'authTime':Pt(fi(_0x2541e9['auth_time'])),'issuedAtTime':Pt(fi(_0x2541e9['iat'])),'expirationTime':Pt(fi(_0x2541e9['exp'])),'signInProvider':_0x44049d||null,'signInSecondFactor':(_0x56d3ad==null?void 0x0:_0x56d3ad['sign_in_second_factor'])||null};}function fi(_0x6314a7){return Number(_0x6314a7)*0x3e8;}function Ts(_0x158149){const [_0x1a662e,_0x1c49dc,_0x46c3f6]=_0x158149['split']('.');if(_0x1a662e===void 0x0||_0x1c49dc===void 0x0||_0x46c3f6===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0xf1ad62=fn(_0x1c49dc);return _0xf1ad62?JSON['parse'](_0xf1ad62):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2f3a54){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2f3a54==null?void 0x0:_0x2f3a54['toString']()),null;}}function Cr(_0x3042c4){const _0x33d6bc=Ts(_0x3042c4);return m(_0x33d6bc,'internal-error'),m(typeof _0x33d6bc['exp']<'u','internal-error'),m(typeof _0x33d6bc['iat']<'u','internal-error'),Number(_0x33d6bc['exp'])-Number(_0x33d6bc['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x1e9bae,_0x10d0de,_0x3f5ad0=!0x1){if(_0x3f5ad0)return _0x10d0de;try{return await _0x10d0de;}catch(_0x14345c){throw _0x14345c instanceof Re&&If(_0x14345c)&&_0x1e9bae['auth']['currentUser']===_0x1e9bae&&await _0x1e9bae['auth']['signOut'](),_0x14345c;}}function If({code:_0x3257f9}){return _0x3257f9==='auth/user-disabled'||_0x3257f9==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x391622){this['user']=_0x391622,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x18f842){if(_0x18f842){const _0x22e60a=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x22e60a;}else{this['errorBackoff']=0x7530;const _0x4ce6c0=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4ce6c0);}}['schedule'](_0x604ccc=!0x1){if(!this['isRunning'])return;const _0x4c07bf=this['getInterval'](_0x604ccc);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4c07bf);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x189bab){(_0x189bab==null?void 0x0:_0x189bab['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x112764,_0x48d108){this['createdAt']=_0x112764,this['lastLoginAt']=_0x48d108,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x48bf64){this['createdAt']=_0x48bf64['createdAt'],this['lastLoginAt']=_0x48bf64['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x4c8a64){var _0xa6c373;const _0x647e12=_0x4c8a64['auth'],_0x1f1577=await _0x4c8a64['getIdToken'](),_0xee781c=await Ht(_0x4c8a64,Pn(_0x647e12,{'idToken':_0x1f1577}));m(_0xee781c==null?void 0x0:_0xee781c['users']['length'],_0x647e12,'internal-error');const _0x4e4455=_0xee781c['users'][0x0];_0x4c8a64['_notifyReloadListener'](_0x4e4455);const _0x1d0428=(_0xa6c373=_0x4e4455['providerUserInfo'])!=null&&_0xa6c373['length']?Sa(_0x4e4455['providerUserInfo']):[],_0x470eae=Tf(_0x4c8a64['providerData'],_0x1d0428),_0x5f3c7e=_0x4c8a64['isAnonymous'],_0x7a27ff=!(_0x4c8a64['email']&&_0x4e4455['passwordHash'])&&!(_0x470eae!=null&&_0x470eae['length']),_0x59f39e=_0x5f3c7e?_0x7a27ff:!0x1,_0x15bb16={'uid':_0x4e4455['localId'],'displayName':_0x4e4455['displayName']||null,'photoURL':_0x4e4455['photoUrl']||null,'email':_0x4e4455['email']||null,'emailVerified':_0x4e4455['emailVerified']||!0x1,'phoneNumber':_0x4e4455['phoneNumber']||null,'tenantId':_0x4e4455['tenantId']||null,'providerData':_0x470eae,'metadata':new Li(_0x4e4455['createdAt'],_0x4e4455['lastLoginAt']),'isAnonymous':_0x59f39e};Object['assign'](_0x4c8a64,_0x15bb16);}async function Cf(_0x17ccde){const _0x4e0c1a=P(_0x17ccde);await Nn(_0x4e0c1a),await _0x4e0c1a['auth']['_persistUserIfCurrent'](_0x4e0c1a),_0x4e0c1a['auth']['_notifyListenersIfCurrent'](_0x4e0c1a);}function Tf(_0x10deb0,_0x1c29c7){return[..._0x10deb0['filter'](_0x311f0b=>!_0x1c29c7['some'](_0x2ccdc0=>_0x2ccdc0['providerId']===_0x311f0b['providerId'])),..._0x1c29c7];}function Sa(_0x46e497){return _0x46e497['map'](({providerId:_0x2b88e1,..._0x146db9})=>({'providerId':_0x2b88e1,'uid':_0x146db9['rawId']||'','displayName':_0x146db9['displayName']||null,'email':_0x146db9['email']||null,'phoneNumber':_0x146db9['phoneNumber']||null,'photoURL':_0x146db9['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x5d8dfc,_0x54b498){const _0x8e68bf=await Ca(_0x5d8dfc,{},async()=>{const _0x4ebf09=ut({'grant_type':'refresh_token','refresh_token':_0x54b498})['slice'](0x1),{tokenApiHost:_0x38e41c,apiKey:_0x4519f7}=_0x5d8dfc['config'],_0x2e25a8=await Ta(_0x5d8dfc,_0x38e41c,'/v1/token','key='+_0x4519f7),_0x962cca=await _0x5d8dfc['_getAdditionalHeaders']();_0x962cca['Content-Type']='application/x-www-form-urlencoded';const _0x22d428={'method':'POST','headers':_0x962cca,'body':_0x4ebf09};return _0x5d8dfc['emulatorConfig']&&qt(_0x5d8dfc['emulatorConfig']['host'])&&(_0x22d428['credentials']='include'),wa['fetch']()(_0x2e25a8,_0x22d428);});return{'accessToken':_0x8e68bf['access_token'],'expiresIn':_0x8e68bf['expires_in'],'refreshToken':_0x8e68bf['refresh_token']};}async function bf(_0x642e50,_0x10fe99){return Pe(_0x642e50,'POST','/v2/accounts:revokeToken',ke(_0x642e50,_0x10fe99));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x45bfd0){m(_0x45bfd0['idToken'],'internal-error'),m(typeof _0x45bfd0['idToken']<'u','internal-error'),m(typeof _0x45bfd0['refreshToken']<'u','internal-error');const _0x4c00d3='expiresIn'in _0x45bfd0&&typeof _0x45bfd0['expiresIn']<'u'?Number(_0x45bfd0['expiresIn']):Cr(_0x45bfd0['idToken']);this['updateTokensAndExpiration'](_0x45bfd0['idToken'],_0x45bfd0['refreshToken'],_0x4c00d3);}['updateFromIdToken'](_0x14537f){m(_0x14537f['length']!==0x0,'internal-error');const _0x1d1f4b=Cr(_0x14537f);this['updateTokensAndExpiration'](_0x14537f,null,_0x1d1f4b);}async['getToken'](_0x48045c,_0x47764c=!0x1){return!_0x47764c&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x48045c,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x48045c,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0xf0d3a5,_0x3f78a5){const {accessToken:_0x183bf7,refreshToken:_0x205d8f,expiresIn:_0x52c1e1}=await Sf(_0xf0d3a5,_0x3f78a5);this['updateTokensAndExpiration'](_0x183bf7,_0x205d8f,Number(_0x52c1e1));}['updateTokensAndExpiration'](_0x577329,_0x3fc435,_0x4d65ca){this['refreshToken']=_0x3fc435||null,this['accessToken']=_0x577329||null,this['expirationTime']=Date['now']()+_0x4d65ca*0x3e8;}static['fromJSON'](_0x52ee4b,_0x56ff1a){const {refreshToken:_0x474e16,accessToken:_0x5e7ce4,expirationTime:_0x8c8775}=_0x56ff1a,_0x5eae7d=new et();return _0x474e16&&(m(typeof _0x474e16=='string','internal-error',{'appName':_0x52ee4b}),_0x5eae7d['refreshToken']=_0x474e16),_0x5e7ce4&&(m(typeof _0x5e7ce4=='string','internal-error',{'appName':_0x52ee4b}),_0x5eae7d['accessToken']=_0x5e7ce4),_0x8c8775&&(m(typeof _0x8c8775=='number','internal-error',{'appName':_0x52ee4b}),_0x5eae7d['expirationTime']=_0x8c8775),_0x5eae7d;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5f07c3){this['accessToken']=_0x5f07c3['accessToken'],this['refreshToken']=_0x5f07c3['refreshToken'],this['expirationTime']=_0x5f07c3['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x4f85c0,_0x16f02e){m(typeof _0x4f85c0=='string'||typeof _0x4f85c0>'u','internal-error',{'appName':_0x16f02e});}class j{constructor({uid:_0x126baa,auth:_0x546857,stsTokenManager:_0x115212,..._0x1f8d8c}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x126baa,this['auth']=_0x546857,this['stsTokenManager']=_0x115212,this['accessToken']=_0x115212['accessToken'],this['displayName']=_0x1f8d8c['displayName']||null,this['email']=_0x1f8d8c['email']||null,this['emailVerified']=_0x1f8d8c['emailVerified']||!0x1,this['phoneNumber']=_0x1f8d8c['phoneNumber']||null,this['photoURL']=_0x1f8d8c['photoURL']||null,this['isAnonymous']=_0x1f8d8c['isAnonymous']||!0x1,this['tenantId']=_0x1f8d8c['tenantId']||null,this['providerData']=_0x1f8d8c['providerData']?[..._0x1f8d8c['providerData']]:[],this['metadata']=new Li(_0x1f8d8c['createdAt']||void 0x0,_0x1f8d8c['lastLoginAt']||void 0x0);}async['getIdToken'](_0x457324){const _0x354cdd=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x457324));return m(_0x354cdd,this['auth'],'internal-error'),this['accessToken']!==_0x354cdd&&(this['accessToken']=_0x354cdd,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x354cdd;}['getIdTokenResult'](_0x551cb0){return Ef(this,_0x551cb0);}['reload'](){return Cf(this);}['_assign'](_0x54618c){this!==_0x54618c&&(m(this['uid']===_0x54618c['uid'],this['auth'],'internal-error'),this['displayName']=_0x54618c['displayName'],this['photoURL']=_0x54618c['photoURL'],this['email']=_0x54618c['email'],this['emailVerified']=_0x54618c['emailVerified'],this['phoneNumber']=_0x54618c['phoneNumber'],this['isAnonymous']=_0x54618c['isAnonymous'],this['tenantId']=_0x54618c['tenantId'],this['providerData']=_0x54618c['providerData']['map'](_0x2e17f5=>({..._0x2e17f5})),this['metadata']['_copy'](_0x54618c['metadata']),this['stsTokenManager']['_assign'](_0x54618c['stsTokenManager']));}['_clone'](_0x3d3bb0){const _0x5f232d=new j({...this,'auth':_0x3d3bb0,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5f232d['metadata']['_copy'](this['metadata']),_0x5f232d;}['_onReload'](_0x55336d){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x55336d,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x20d20e){this['reloadListener']?this['reloadListener'](_0x20d20e):this['reloadUserInfo']=_0x20d20e;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x574a20,_0x1a2e26=!0x1){let _0x5e20fb=!0x1;_0x574a20['idToken']&&_0x574a20['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x574a20),_0x5e20fb=!0x0),_0x1a2e26&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5e20fb&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x200087=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x200087})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x117ccb=>({..._0x117ccb})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x20be49,_0x31492b){const _0x5afc03=_0x31492b['displayName']??void 0x0,_0x583d9b=_0x31492b['email']??void 0x0,_0x1f868d=_0x31492b['phoneNumber']??void 0x0,_0x4e75cb=_0x31492b['photoURL']??void 0x0,_0x12fc42=_0x31492b['tenantId']??void 0x0,_0x16144c=_0x31492b['_redirectEventId']??void 0x0,_0x1de096=_0x31492b['createdAt']??void 0x0,_0x514b9d=_0x31492b['lastLoginAt']??void 0x0,{uid:_0xb4efbe,emailVerified:_0x4f522a,isAnonymous:_0x1511fc,providerData:_0x2db33a,stsTokenManager:_0xd8c4fc}=_0x31492b;m(_0xb4efbe&&_0xd8c4fc,_0x20be49,'internal-error');const _0x47e753=et['fromJSON'](this['name'],_0xd8c4fc);m(typeof _0xb4efbe=='string',_0x20be49,'internal-error'),le(_0x5afc03,_0x20be49['name']),le(_0x583d9b,_0x20be49['name']),m(typeof _0x4f522a=='boolean',_0x20be49,'internal-error'),m(typeof _0x1511fc=='boolean',_0x20be49,'internal-error'),le(_0x1f868d,_0x20be49['name']),le(_0x4e75cb,_0x20be49['name']),le(_0x12fc42,_0x20be49['name']),le(_0x16144c,_0x20be49['name']),le(_0x1de096,_0x20be49['name']),le(_0x514b9d,_0x20be49['name']);const _0x68263e=new j({'uid':_0xb4efbe,'auth':_0x20be49,'email':_0x583d9b,'emailVerified':_0x4f522a,'displayName':_0x5afc03,'isAnonymous':_0x1511fc,'photoURL':_0x4e75cb,'phoneNumber':_0x1f868d,'tenantId':_0x12fc42,'stsTokenManager':_0x47e753,'createdAt':_0x1de096,'lastLoginAt':_0x514b9d});return _0x2db33a&&Array['isArray'](_0x2db33a)&&(_0x68263e['providerData']=_0x2db33a['map'](_0x3f78c2=>({..._0x3f78c2}))),_0x16144c&&(_0x68263e['_redirectEventId']=_0x16144c),_0x68263e;}static async['_fromIdTokenResponse'](_0x570963,_0x489b99,_0x2b723e=!0x1){const _0x2c231f=new et();_0x2c231f['updateFromServerResponse'](_0x489b99);const _0x58964c=new j({'uid':_0x489b99['localId'],'auth':_0x570963,'stsTokenManager':_0x2c231f,'isAnonymous':_0x2b723e});return await Nn(_0x58964c),_0x58964c;}static async['_fromGetAccountInfoResponse'](_0x1e2eb4,_0x4e238e,_0xa36763){const _0x391031=_0x4e238e['users'][0x0];m(_0x391031['localId']!==void 0x0,'internal-error');const _0x4e829f=_0x391031['providerUserInfo']!==void 0x0?Sa(_0x391031['providerUserInfo']):[],_0x5d80ee=!(_0x391031['email']&&_0x391031['passwordHash'])&&!(_0x4e829f!=null&&_0x4e829f['length']),_0x4bbbe0=new et();_0x4bbbe0['updateFromIdToken'](_0xa36763);const _0x5a9b7a=new j({'uid':_0x391031['localId'],'auth':_0x1e2eb4,'stsTokenManager':_0x4bbbe0,'isAnonymous':_0x5d80ee}),_0x15a982={'uid':_0x391031['localId'],'displayName':_0x391031['displayName']||null,'photoURL':_0x391031['photoUrl']||null,'email':_0x391031['email']||null,'emailVerified':_0x391031['emailVerified']||!0x1,'phoneNumber':_0x391031['phoneNumber']||null,'tenantId':_0x391031['tenantId']||null,'providerData':_0x4e829f,'metadata':new Li(_0x391031['createdAt'],_0x391031['lastLoginAt']),'isAnonymous':!(_0x391031['email']&&_0x391031['passwordHash'])&&!(_0x4e829f!=null&&_0x4e829f['length'])};return Object['assign'](_0x5a9b7a,_0x15a982),_0x5a9b7a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x1b5e5d){ce(_0x1b5e5d instanceof Function,'Expected\x20a\x20class\x20definition');let _0x239680=Tr['get'](_0x1b5e5d);return _0x239680?(ce(_0x239680 instanceof _0x1b5e5d,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x239680):(_0x239680=new _0x1b5e5d(),Tr['set'](_0x1b5e5d,_0x239680),_0x239680);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x4906cd,_0x10229f){this['storage'][_0x4906cd]=_0x10229f;}async['_get'](_0x1543bb){const _0x282485=this['storage'][_0x1543bb];return _0x282485===void 0x0?null:_0x282485;}async['_remove'](_0x534d63){delete this['storage'][_0x534d63];}['_addListener'](_0x3e930d,_0x18a2e3){}['_removeListener'](_0x7de016,_0x11c9e0){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x1827e9,_0x56e186,_0x529922){return'firebase:'+_0x1827e9+':'+_0x56e186+':'+_0x529922;}class tt{constructor(_0x2bde24,_0x3730dc,_0x74f834){this['persistence']=_0x2bde24,this['auth']=_0x3730dc,this['userKey']=_0x74f834;const {config:_0x260077,name:_0x29dd2a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x260077['apiKey'],_0x29dd2a),this['fullPersistenceKey']=ln('persistence',_0x260077['apiKey'],_0x29dd2a),this['boundEventHandler']=_0x3730dc['_onStorageEvent']['bind'](_0x3730dc),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x105b07){return this['persistence']['_set'](this['fullUserKey'],_0x105b07['toJSON']());}async['getCurrentUser'](){const _0x324b5d=await this['persistence']['_get'](this['fullUserKey']);if(!_0x324b5d)return null;if(typeof _0x324b5d=='string'){const _0x5e669e=await Pn(this['auth'],{'idToken':_0x324b5d})['catch'](()=>{});return _0x5e669e?j['_fromGetAccountInfoResponse'](this['auth'],_0x5e669e,_0x324b5d):null;}return j['_fromJSON'](this['auth'],_0x324b5d);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x197237){if(this['persistence']===_0x197237)return;const _0x3dea77=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x197237,_0x3dea77)return this['setCurrentUser'](_0x3dea77);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x87a4a4,_0x3bf26d,_0x55bf33='authUser'){if(!_0x3bf26d['length'])return new tt(ie(Sr),_0x87a4a4,_0x55bf33);const _0x48cf24=(await Promise['all'](_0x3bf26d['map'](async _0x25166c=>{if(await _0x25166c['_isAvailable']())return _0x25166c;})))['filter'](_0x5c5151=>_0x5c5151);let _0x35ec6d=_0x48cf24[0x0]||ie(Sr);const _0x43be91=ln(_0x55bf33,_0x87a4a4['config']['apiKey'],_0x87a4a4['name']);let _0x9bdfd6=null;for(const _0x88e532 of _0x3bf26d)try{const _0x3da001=await _0x88e532['_get'](_0x43be91);if(_0x3da001){let _0x11faec;if(typeof _0x3da001=='string'){const _0x1bf679=await Pn(_0x87a4a4,{'idToken':_0x3da001})['catch'](()=>{});if(!_0x1bf679)break;_0x11faec=await j['_fromGetAccountInfoResponse'](_0x87a4a4,_0x1bf679,_0x3da001);}else _0x11faec=j['_fromJSON'](_0x87a4a4,_0x3da001);_0x88e532!==_0x35ec6d&&(_0x9bdfd6=_0x11faec),_0x35ec6d=_0x88e532;break;}}catch{}const _0x674498=_0x48cf24['filter'](_0x2dbe6b=>_0x2dbe6b['_shouldAllowMigration']);return!_0x35ec6d['_shouldAllowMigration']||!_0x674498['length']?new tt(_0x35ec6d,_0x87a4a4,_0x55bf33):(_0x35ec6d=_0x674498[0x0],_0x9bdfd6&&await _0x35ec6d['_set'](_0x43be91,_0x9bdfd6['toJSON']()),await Promise['all'](_0x3bf26d['map'](async _0x2ae739=>{if(_0x2ae739!==_0x35ec6d)try{await _0x2ae739['_remove'](_0x43be91);}catch{}})),new tt(_0x35ec6d,_0x87a4a4,_0x55bf33));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x50ebb9){const _0x40c747=_0x50ebb9['toLowerCase']();if(_0x40c747['includes']('opera/')||_0x40c747['includes']('opr/')||_0x40c747['includes']('opios/'))return'Opera';if(Pa(_0x40c747))return'IEMobile';if(_0x40c747['includes']('msie')||_0x40c747['includes']('trident/'))return'IE';if(_0x40c747['includes']('edge/'))return'Edge';if(Ra(_0x40c747))return'Firefox';if(_0x40c747['includes']('silk/'))return'Silk';if(Oa(_0x40c747))return'Blackberry';if(Da(_0x40c747))return'Webos';if(Aa(_0x40c747))return'Safari';if((_0x40c747['includes']('chrome/')||ka(_0x40c747))&&!_0x40c747['includes']('edge/'))return'Chrome';if(Na(_0x40c747))return'Android';{const _0x1eee88=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x23a3d0=_0x50ebb9['match'](_0x1eee88);if((_0x23a3d0==null?void 0x0:_0x23a3d0['length'])===0x2)return _0x23a3d0[0x1];}return'Other';}function Ra(_0x2be095=W()){return/firefox\//i['test'](_0x2be095);}function Aa(_0x5638ed=W()){const _0x31cb19=_0x5638ed['toLowerCase']();return _0x31cb19['includes']('safari/')&&!_0x31cb19['includes']('chrome/')&&!_0x31cb19['includes']('crios/')&&!_0x31cb19['includes']('android');}function ka(_0x5c4a1d=W()){return/crios\//i['test'](_0x5c4a1d);}function Pa(_0x40b0fe=W()){return/iemobile/i['test'](_0x40b0fe);}function Na(_0x2532b4=W()){return/android/i['test'](_0x2532b4);}function Oa(_0x222821=W()){return/blackberry/i['test'](_0x222821);}function Da(_0x35a638=W()){return/webos/i['test'](_0x35a638);}function Ss(_0x2ba79f=W()){return/iphone|ipad|ipod/i['test'](_0x2ba79f)||/macintosh/i['test'](_0x2ba79f)&&/mobile/i['test'](_0x2ba79f);}function Rf(_0x5108c6=W()){var _0x3cdf8d;return Ss(_0x5108c6)&&!!((_0x3cdf8d=window['navigator'])!=null&&_0x3cdf8d['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x56b2ba=W()){return Ss(_0x56b2ba)||Na(_0x56b2ba)||Da(_0x56b2ba)||Oa(_0x56b2ba)||/windows phone/i['test'](_0x56b2ba)||Pa(_0x56b2ba);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x30c93c,_0x41ddb3=[]){let _0x47f12d;switch(_0x30c93c){case'Browser':_0x47f12d=br(W());break;case'Worker':_0x47f12d=br(W())+'-'+_0x30c93c;break;default:_0x47f12d=_0x30c93c;}const _0x2c3331=_0x41ddb3['length']?_0x41ddb3['join'](','):'FirebaseCore-web';return _0x47f12d+'/JsCore/'+dt+'/'+_0x2c3331;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x24fbd8){this['auth']=_0x24fbd8,this['queue']=[];}['pushCallback'](_0x377fc3,_0x3f26ec){const _0x3acbb7=_0x3b3c31=>new Promise((_0x4418ed,_0x9324dd)=>{try{const _0x5b34d1=_0x377fc3(_0x3b3c31);_0x4418ed(_0x5b34d1);}catch(_0x25cbb5){_0x9324dd(_0x25cbb5);}});_0x3acbb7['onAbort']=_0x3f26ec,this['queue']['push'](_0x3acbb7);const _0x5a6873=this['queue']['length']-0x1;return()=>{this['queue'][_0x5a6873]=()=>Promise['resolve']();};}async['runMiddleware'](_0x177982){if(this['auth']['currentUser']===_0x177982)return;const _0x10a828=[];try{for(const _0x4bbb23 of this['queue'])await _0x4bbb23(_0x177982),_0x4bbb23['onAbort']&&_0x10a828['push'](_0x4bbb23['onAbort']);}catch(_0x55ea44){_0x10a828['reverse']();for(const _0x5e67e6 of _0x10a828)try{_0x5e67e6();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x55ea44==null?void 0x0:_0x55ea44['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x2eef6a,_0xc08cc7={}){return Pe(_0x2eef6a,'GET','/v2/passwordPolicy',ke(_0x2eef6a,_0xc08cc7));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x3de8c3){var _0xe23fd9;const _0x4bf107=_0x3de8c3['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4bf107['minPasswordLength']??Nf,_0x4bf107['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4bf107['maxPasswordLength']),_0x4bf107['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4bf107['containsLowercaseCharacter']),_0x4bf107['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4bf107['containsUppercaseCharacter']),_0x4bf107['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4bf107['containsNumericCharacter']),_0x4bf107['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4bf107['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3de8c3['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xe23fd9=_0x3de8c3['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xe23fd9['join'](''))??'',this['forceUpgradeOnSignin']=_0x3de8c3['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3de8c3['schemaVersion'];}['validatePassword'](_0x7b582a){const _0x24eec9={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x7b582a,_0x24eec9),this['validatePasswordCharacterOptions'](_0x7b582a,_0x24eec9),_0x24eec9['isValid']&&(_0x24eec9['isValid']=_0x24eec9['meetsMinPasswordLength']??!0x0),_0x24eec9['isValid']&&(_0x24eec9['isValid']=_0x24eec9['meetsMaxPasswordLength']??!0x0),_0x24eec9['isValid']&&(_0x24eec9['isValid']=_0x24eec9['containsLowercaseLetter']??!0x0),_0x24eec9['isValid']&&(_0x24eec9['isValid']=_0x24eec9['containsUppercaseLetter']??!0x0),_0x24eec9['isValid']&&(_0x24eec9['isValid']=_0x24eec9['containsNumericCharacter']??!0x0),_0x24eec9['isValid']&&(_0x24eec9['isValid']=_0x24eec9['containsNonAlphanumericCharacter']??!0x0),_0x24eec9;}['validatePasswordLengthOptions'](_0x58bc0c,_0x398fd7){const _0x22c2a9=this['customStrengthOptions']['minPasswordLength'],_0x26cc1b=this['customStrengthOptions']['maxPasswordLength'];_0x22c2a9&&(_0x398fd7['meetsMinPasswordLength']=_0x58bc0c['length']>=_0x22c2a9),_0x26cc1b&&(_0x398fd7['meetsMaxPasswordLength']=_0x58bc0c['length']<=_0x26cc1b);}['validatePasswordCharacterOptions'](_0x25e100,_0x2af698){this['updatePasswordCharacterOptionsStatuses'](_0x2af698,!0x1,!0x1,!0x1,!0x1);let _0x3d358d;for(let _0x20bd12=0x0;_0x20bd12<_0x25e100['length'];_0x20bd12++)_0x3d358d=_0x25e100['charAt'](_0x20bd12),this['updatePasswordCharacterOptionsStatuses'](_0x2af698,_0x3d358d>='a'&&_0x3d358d<='z',_0x3d358d>='A'&&_0x3d358d<='Z',_0x3d358d>='0'&&_0x3d358d<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3d358d));}['updatePasswordCharacterOptionsStatuses'](_0x415b54,_0x20db69,_0x3778c9,_0x38f557,_0x2f943e){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x415b54['containsLowercaseLetter']||(_0x415b54['containsLowercaseLetter']=_0x20db69)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x415b54['containsUppercaseLetter']||(_0x415b54['containsUppercaseLetter']=_0x3778c9)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x415b54['containsNumericCharacter']||(_0x415b54['containsNumericCharacter']=_0x38f557)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x415b54['containsNonAlphanumericCharacter']||(_0x415b54['containsNonAlphanumericCharacter']=_0x2f943e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x12b66d,_0xbb82e1,_0x690aec,_0x2b9e76){this['app']=_0x12b66d,this['heartbeatServiceProvider']=_0xbb82e1,this['appCheckServiceProvider']=_0x690aec,this['config']=_0x2b9e76,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x12b66d['name'],this['clientVersion']=_0x2b9e76['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x3d6a06=>this['_resolvePersistenceManagerAvailable']=_0x3d6a06);}['_initializeWithPersistence'](_0x8b0be5,_0x4e742e){return _0x4e742e&&(this['_popupRedirectResolver']=ie(_0x4e742e)),this['_initializationPromise']=this['queue'](async()=>{var _0xecb48e,_0x3c1201,_0x1f3402;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x8b0be5),(_0xecb48e=this['_resolvePersistenceManagerAvailable'])==null||_0xecb48e['call'](this),!this['_deleted'])){if((_0x3c1201=this['_popupRedirectResolver'])!=null&&_0x3c1201['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x4e742e),this['lastNotifiedUid']=((_0x1f3402=this['currentUser'])==null?void 0x0:_0x1f3402['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x1fd2a1=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x1fd2a1)){if(this['currentUser']&&_0x1fd2a1&&this['currentUser']['uid']===_0x1fd2a1['uid']){this['_currentUser']['_assign'](_0x1fd2a1),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x1fd2a1,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1b1604){try{const _0x450d76=await Pn(this,{'idToken':_0x1b1604}),_0xb07362=await j['_fromGetAccountInfoResponse'](this,_0x450d76,_0x1b1604);await this['directlySetCurrentUser'](_0xb07362);}catch(_0x597ad1){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x597ad1),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x234247){var _0x13e308;if($(this['app'])){const _0x59f6e4=this['app']['settings']['authIdToken'];return _0x59f6e4?new Promise(_0x397bef=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x59f6e4)['then'](_0x397bef,_0x397bef));}):this['directlySetCurrentUser'](null);}const _0x1e2746=await this['assertedPersistence']['getCurrentUser']();let _0x10f244=_0x1e2746,_0x5f2426=!0x1;if(_0x234247&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5c693a=(_0x13e308=this['redirectUser'])==null?void 0x0:_0x13e308['_redirectEventId'],_0x3f341a=_0x10f244==null?void 0x0:_0x10f244['_redirectEventId'],_0x55d998=await this['tryRedirectSignIn'](_0x234247);(!_0x5c693a||_0x5c693a===_0x3f341a)&&(_0x55d998!=null&&_0x55d998['user'])&&(_0x10f244=_0x55d998['user'],_0x5f2426=!0x0);}if(!_0x10f244)return this['directlySetCurrentUser'](null);if(!_0x10f244['_redirectEventId']){if(_0x5f2426)try{await this['beforeStateQueue']['runMiddleware'](_0x10f244);}catch(_0x25e8a1){_0x10f244=_0x1e2746,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x25e8a1));}return _0x10f244?this['reloadAndSetCurrentUserOrClear'](_0x10f244):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x10f244['_redirectEventId']?this['directlySetCurrentUser'](_0x10f244):this['reloadAndSetCurrentUserOrClear'](_0x10f244);}async['tryRedirectSignIn'](_0x5decb8){let _0x2429e4=null;try{_0x2429e4=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x5decb8,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2429e4;}async['reloadAndSetCurrentUserOrClear'](_0x1c6b20){try{await Nn(_0x1c6b20);}catch(_0x40083b){if((_0x40083b==null?void 0x0:_0x40083b['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x1c6b20);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x254d19){if($(this['app']))return Promise['reject'](re(this));const _0x20a15b=_0x254d19?P(_0x254d19):null;return _0x20a15b&&m(_0x20a15b['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x20a15b&&_0x20a15b['_clone'](this));}async['_updateCurrentUser'](_0x405688,_0x48b7f8=!0x1){if(!this['_deleted'])return _0x405688&&m(this['tenantId']===_0x405688['tenantId'],this,'tenant-id-mismatch'),_0x48b7f8||await this['beforeStateQueue']['runMiddleware'](_0x405688),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x405688),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1e61d6){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x1e61d6));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x4157c6){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x271227=this['_getPasswordPolicyInternal']();return _0x271227['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x271227['validatePassword'](_0x4157c6);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x427be0=await Pf(this),_0x3cac36=new Of(_0x427be0);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3cac36:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3cac36;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x28cb9f){this['_errorFactory']=new Gt('auth','Firebase',_0x28cb9f());}['onAuthStateChanged'](_0x65ca16,_0x19252c,_0x2489b0){return this['registerStateListener'](this['authStateSubscription'],_0x65ca16,_0x19252c,_0x2489b0);}['beforeAuthStateChanged'](_0x580444,_0x122ddf){return this['beforeStateQueue']['pushCallback'](_0x580444,_0x122ddf);}['onIdTokenChanged'](_0x3a0177,_0x169adb,_0x29ba9b){return this['registerStateListener'](this['idTokenSubscription'],_0x3a0177,_0x169adb,_0x29ba9b);}['authStateReady'](){return new Promise((_0x32a1ed,_0xb3bd84)=>{if(this['currentUser'])_0x32a1ed();else{const _0x10bd7c=this['onAuthStateChanged'](()=>{_0x10bd7c(),_0x32a1ed();},_0xb3bd84);}});}async['revokeAccessToken'](_0x2989d0){if(this['currentUser']){const _0x3ce1d1=await this['currentUser']['getIdToken'](),_0x4ed4ba={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2989d0,'idToken':_0x3ce1d1};this['tenantId']!=null&&(_0x4ed4ba['tenantId']=this['tenantId']),await bf(this,_0x4ed4ba);}}['toJSON'](){var _0x2b3239;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2b3239=this['_currentUser'])==null?void 0x0:_0x2b3239['toJSON']()};}async['_setRedirectUser'](_0x296894,_0xc2c70a){const _0x5b052f=await this['getOrInitRedirectPersistenceManager'](_0xc2c70a);return _0x296894===null?_0x5b052f['removeCurrentUser']():_0x5b052f['setCurrentUser'](_0x296894);}async['getOrInitRedirectPersistenceManager'](_0x5e33c3){if(!this['redirectPersistenceManager']){const _0x2534c0=_0x5e33c3&&ie(_0x5e33c3)||this['_popupRedirectResolver'];m(_0x2534c0,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x2534c0['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2b492d){var _0x20f664,_0x500af5;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x20f664=this['_currentUser'])==null?void 0x0:_0x20f664['_redirectEventId'])===_0x2b492d?this['_currentUser']:((_0x500af5=this['redirectUser'])==null?void 0x0:_0x500af5['_redirectEventId'])===_0x2b492d?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0xd48648){if(_0xd48648===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0xd48648));}['_notifyListenersIfCurrent'](_0x1b37ec){_0x1b37ec===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0xd7de91;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x597a18=((_0xd7de91=this['currentUser'])==null?void 0x0:_0xd7de91['uid'])??null;this['lastNotifiedUid']!==_0x597a18&&(this['lastNotifiedUid']=_0x597a18,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1c9715,_0x1e72cb,_0x183ea5,_0x5ab1ab){if(this['_deleted'])return()=>{};const _0x44631f=typeof _0x1e72cb=='function'?_0x1e72cb:_0x1e72cb['next']['bind'](_0x1e72cb);let _0x4939d7=!0x1;const _0x4f26ef=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4f26ef,this,'internal-error'),_0x4f26ef['then'](()=>{_0x4939d7||_0x44631f(this['currentUser']);}),typeof _0x1e72cb=='function'){const _0x482e97=_0x1c9715['addObserver'](_0x1e72cb,_0x183ea5,_0x5ab1ab);return()=>{_0x4939d7=!0x0,_0x482e97();};}else{const _0x499d0d=_0x1c9715['addObserver'](_0x1e72cb);return()=>{_0x4939d7=!0x0,_0x499d0d();};}}async['directlySetCurrentUser'](_0x537020){this['currentUser']&&this['currentUser']!==_0x537020&&this['_currentUser']['_stopProactiveRefresh'](),_0x537020&&this['isProactiveRefreshEnabled']&&_0x537020['_startProactiveRefresh'](),this['currentUser']=_0x537020,_0x537020?await this['assertedPersistence']['setCurrentUser'](_0x537020):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5fa5fc){return this['operations']=this['operations']['then'](_0x5fa5fc,_0x5fa5fc),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5ab8f8){!_0x5ab8f8||this['frameworks']['includes'](_0x5ab8f8)||(this['frameworks']['push'](_0x5ab8f8),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x4b8074;const _0x445f67={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x445f67['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x2ccb01=await((_0x4b8074=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4b8074['getHeartbeatsHeader']());_0x2ccb01&&(_0x445f67['X-Firebase-Client']=_0x2ccb01);const _0x4062bf=await this['_getAppCheckToken']();return _0x4062bf&&(_0x445f67['X-Firebase-AppCheck']=_0x4062bf),_0x445f67;}async['_getAppCheckToken'](){var _0x119181;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0xcee0a4=await((_0x119181=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x119181['getToken']());return _0xcee0a4!=null&&_0xcee0a4['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0xcee0a4['error']),_0xcee0a4==null?void 0x0:_0xcee0a4['token'];}}function Ke(_0x5655f6){return P(_0x5655f6);}class Rr{constructor(_0x21babb){this['auth']=_0x21babb,this['observer']=null,this['addObserver']=Tc(_0x16d1d7=>this['observer']=_0x16d1d7);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x1effdb){Jn=_0x1effdb;}function xa(_0x183521){return Jn['loadJS'](_0x183521);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x518dc4){return'__'+_0x518dc4+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x1b9fbe){_0x1b9fbe();}['execute'](_0x561b4a,_0x131be5){return Promise['resolve']('token');}['render'](_0x4e9031,_0x1683cd){return'';}}class Wf{['ready'](_0x4d4af0){_0x4d4af0();}['execute'](_0x172e65,_0x540da2){return Promise['resolve']('token');}['render'](_0x595bf2,_0xc1f8b1){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x10e201){this['type']=Bf,this['auth']=Ke(_0x10e201);}async['verify'](_0x5a54e9='verify',_0x41fb40=!0x1){async function _0x359251(_0x46e7d4){if(!_0x41fb40){if(_0x46e7d4['tenantId']==null&&_0x46e7d4['_agentRecaptchaConfig']!=null)return _0x46e7d4['_agentRecaptchaConfig']['siteKey'];if(_0x46e7d4['tenantId']!=null&&_0x46e7d4['_tenantRecaptchaConfigs'][_0x46e7d4['tenantId']]!==void 0x0)return _0x46e7d4['_tenantRecaptchaConfigs'][_0x46e7d4['tenantId']]['siteKey'];}return new Promise(async(_0xe483ac,_0x3a4974)=>{yf(_0x46e7d4,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4db9b8=>{if(_0x4db9b8['recaptchaKey']===void 0x0)_0x3a4974(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x57be73=new mf(_0x4db9b8);return _0x46e7d4['tenantId']==null?_0x46e7d4['_agentRecaptchaConfig']=_0x57be73:_0x46e7d4['_tenantRecaptchaConfigs'][_0x46e7d4['tenantId']]=_0x57be73,_0xe483ac(_0x57be73['siteKey']);}})['catch'](_0x23568b=>{_0x3a4974(_0x23568b);});});}function _0x5d6d59(_0x13ae32,_0x37d148,_0x4fe759){const _0x34244f=window['grecaptcha'];wr(_0x34244f)?_0x34244f['enterprise']['ready'](()=>{_0x34244f['enterprise']['execute'](_0x13ae32,{'action':_0x5a54e9})['then'](_0x4a81fb=>{_0x37d148(_0x4a81fb);})['catch'](()=>{_0x37d148(Fa);});}):_0x4fe759(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x36fa27,_0x420917)=>{_0x359251(this['auth'])['then'](async _0x2fa4e7=>{if(!_0x41fb40&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x5d6d59(_0x2fa4e7,_0x36fa27,_0x420917);else{if(typeof window>'u'){_0x420917(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x268b1a=Lf();_0x268b1a['length']!==0x0&&(_0x268b1a+=_0x2fa4e7+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x10ef9f;(_0x10ef9f=he['scriptInjectionDeferred'])==null||_0x10ef9f['resolve']();},xa(_0x268b1a)['then'](()=>{var _0x30d988;return(_0x30d988=he['scriptInjectionDeferred'])==null?void 0x0:_0x30d988['promise'];})['then'](()=>{_0x5d6d59(_0x2fa4e7,_0x36fa27,_0x420917);})['catch'](_0xac927d=>{_0x420917(_0xac927d);});}})['catch'](_0x49b8d0=>{_0x420917(_0x49b8d0);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x34a07a,_0x37b42f,_0x183196,_0x2b0695=!0x1,_0x100766=!0x1){const _0x27c507=new he(_0x34a07a);let _0x1ea3f2;if(_0x100766)_0x1ea3f2=Fa;else try{_0x1ea3f2=await _0x27c507['verify'](_0x183196);}catch{_0x1ea3f2=await _0x27c507['verify'](_0x183196,!0x0);}const _0x4bb9e1={..._0x37b42f};if(_0x183196==='mfaSmsEnrollment'||_0x183196==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x4bb9e1){const _0x539668=_0x4bb9e1['phoneEnrollmentInfo']['phoneNumber'],_0x136133=_0x4bb9e1['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x4bb9e1,{'phoneEnrollmentInfo':{'phoneNumber':_0x539668,'recaptchaToken':_0x136133,'captchaResponse':_0x1ea3f2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x4bb9e1){const _0x43e466=_0x4bb9e1['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x4bb9e1,{'phoneSignInInfo':{'recaptchaToken':_0x43e466,'captchaResponse':_0x1ea3f2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x4bb9e1;}return _0x2b0695?Object['assign'](_0x4bb9e1,{'captchaResp':_0x1ea3f2}):Object['assign'](_0x4bb9e1,{'captchaResponse':_0x1ea3f2}),Object['assign'](_0x4bb9e1,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x4bb9e1,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x4bb9e1;}async function xi(_0xe39416,_0x24f6d2,_0x2f690f,_0x585f8d,_0x5a7624){var _0x509756;if((_0x509756=_0xe39416['_getRecaptchaConfig']())!=null&&_0x509756['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x2f6ae8=await kr(_0xe39416,_0x24f6d2,_0x2f690f,_0x2f690f==='getOobCode');return _0x585f8d(_0xe39416,_0x2f6ae8);}else return _0x585f8d(_0xe39416,_0x24f6d2)['catch'](async _0x411ec7=>{if(_0x411ec7['code']==='auth/missing-recaptcha-token'){console['log'](_0x2f690f+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4db5e2=await kr(_0xe39416,_0x24f6d2,_0x2f690f,_0x2f690f==='getOobCode');return _0x585f8d(_0xe39416,_0x4db5e2);}else return Promise['reject'](_0x411ec7);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x3064a0,_0x5d258a){const _0x399633=Hi(_0x3064a0,'auth');if(_0x399633['isInitialized']()){const _0x3258b6=_0x399633['getImmediate'](),_0x12ab31=_0x399633['getOptions']();if(xe(_0x12ab31,_0x5d258a??{}))return _0x3258b6;Y(_0x3258b6,'already-initialized');}return _0x399633['initialize']({'options':_0x5d258a});}function Hf(_0x90def1,_0x34e32b){const _0x5df48c=(_0x34e32b==null?void 0x0:_0x34e32b['persistence'])||[],_0x5099ee=(Array['isArray'](_0x5df48c)?_0x5df48c:[_0x5df48c])['map'](ie);_0x34e32b!=null&&_0x34e32b['errorMap']&&_0x90def1['_updateErrorMap'](_0x34e32b['errorMap']),_0x90def1['_initializeWithPersistence'](_0x5099ee,_0x34e32b==null?void 0x0:_0x34e32b['popupRedirectResolver']);}function $f(_0x19e2a1,_0x38e768,_0x546551){const _0xc47ab3=Ke(_0x19e2a1);m(/^https?:\/\//['test'](_0x38e768),_0xc47ab3,'invalid-emulator-scheme');const _0x16ea1a=!0x1,_0x20c81f=Ua(_0x38e768),{host:_0x585736,port:_0x524d56}=Gf(_0x38e768),_0xd6ab2c=_0x524d56===null?'':':'+_0x524d56,_0x5f59b6={'url':_0x20c81f+'//'+_0x585736+_0xd6ab2c+'/'},_0x1bdc22=Object['freeze']({'host':_0x585736,'port':_0x524d56,'protocol':_0x20c81f['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x16ea1a})});if(!_0xc47ab3['_canInitEmulator']){m(_0xc47ab3['config']['emulator']&&_0xc47ab3['emulatorConfig'],_0xc47ab3,'emulator-config-failed'),m(xe(_0x5f59b6,_0xc47ab3['config']['emulator'])&&xe(_0x1bdc22,_0xc47ab3['emulatorConfig']),_0xc47ab3,'emulator-config-failed');return;}_0xc47ab3['config']['emulator']=_0x5f59b6,_0xc47ab3['emulatorConfig']=_0x1bdc22,_0xc47ab3['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x585736)?Qr(_0x20c81f+'//'+_0x585736+_0xd6ab2c):qf();}function Ua(_0x1c19d5){const _0x163497=_0x1c19d5['indexOf'](':');return _0x163497<0x0?'':_0x1c19d5['substr'](0x0,_0x163497+0x1);}function Gf(_0x317868){const _0x475d5d=Ua(_0x317868),_0x64039d=/(\/\/)?([^?#/]+)/['exec'](_0x317868['substr'](_0x475d5d['length']));if(!_0x64039d)return{'host':'','port':null};const _0x16a765=_0x64039d[0x2]['split']('@')['pop']()||'',_0x1b6597=/^(\[[^\]]+\])(:|$)/['exec'](_0x16a765);if(_0x1b6597){const _0x42ef28=_0x1b6597[0x1];return{'host':_0x42ef28,'port':Pr(_0x16a765['substr'](_0x42ef28['length']+0x1))};}else{const [_0x41c02b,_0x280dc4]=_0x16a765['split'](':');return{'host':_0x41c02b,'port':Pr(_0x280dc4)};}}function Pr(_0x387619){if(!_0x387619)return null;const _0x4da130=Number(_0x387619);return isNaN(_0x4da130)?null:_0x4da130;}function qf(){function _0x5b6d1f(){const _0x391080=document['createElement']('p'),_0x20a6ed=_0x391080['style'];_0x391080['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x20a6ed['position']='fixed',_0x20a6ed['width']='100%',_0x20a6ed['backgroundColor']='#ffffff',_0x20a6ed['border']='.1em\x20solid\x20#000000',_0x20a6ed['color']='#b50000',_0x20a6ed['bottom']='0px',_0x20a6ed['left']='0px',_0x20a6ed['margin']='0px',_0x20a6ed['zIndex']='10000',_0x20a6ed['textAlign']='center',_0x391080['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x391080);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x5b6d1f):_0x5b6d1f());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x44723e,_0x3b850f){this['providerId']=_0x44723e,this['signInMethod']=_0x3b850f;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3b01e8){return ne('not\x20implemented');}['_linkToIdToken'](_0x2ccb3b,_0x4f0656){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x548287){return ne('not\x20implemented');}}async function zf(_0x2fc6f9,_0x1611fc){return Pe(_0x2fc6f9,'POST','/v1/accounts:signUp',_0x1611fc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x8640a1,_0x3a947b){return en(_0x8640a1,'POST','/v1/accounts:signInWithPassword',ke(_0x8640a1,_0x3a947b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x306012,_0x2e918a){return en(_0x306012,'POST','/v1/accounts:signInWithEmailLink',ke(_0x306012,_0x2e918a));}async function Yf(_0x560922,_0x489e98){return en(_0x560922,'POST','/v1/accounts:signInWithEmailLink',ke(_0x560922,_0x489e98));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x22211d,_0x483475,_0x1a71bd,_0x4237a3=null){super('password',_0x1a71bd),this['_email']=_0x22211d,this['_password']=_0x483475,this['_tenantId']=_0x4237a3;}static['_fromEmailAndPassword'](_0x151aaa,_0x32de88){return new $t(_0x151aaa,_0x32de88,'password');}static['_fromEmailAndCode'](_0x5256b9,_0x55ea74,_0x1b963a=null){return new $t(_0x5256b9,_0x55ea74,'emailLink',_0x1b963a);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2dc69e){const _0x2b98a5=typeof _0x2dc69e=='string'?JSON['parse'](_0x2dc69e):_0x2dc69e;if(_0x2b98a5!=null&&_0x2b98a5['email']&&(_0x2b98a5!=null&&_0x2b98a5['password'])){if(_0x2b98a5['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2b98a5['email'],_0x2b98a5['password']);if(_0x2b98a5['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2b98a5['email'],_0x2b98a5['password'],_0x2b98a5['tenantId']);}return null;}async['_getIdTokenResponse'](_0x26540a){switch(this['signInMethod']){case'password':const _0x8a1005={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x26540a,_0x8a1005,'signInWithPassword',jf);case'emailLink':return Kf(_0x26540a,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x26540a,'internal-error');}}async['_linkToIdToken'](_0x581150,_0x46a882){switch(this['signInMethod']){case'password':const _0x474668={'idToken':_0x46a882,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x581150,_0x474668,'signUpPassword',zf);case'emailLink':return Yf(_0x581150,{'idToken':_0x46a882,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x581150,'internal-error');}}['_getReauthenticationResolver'](_0x2a0ca8){return this['_getIdTokenResponse'](_0x2a0ca8);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x15f9da,_0x5a5a06){return en(_0x15f9da,'POST','/v1/accounts:signInWithIdp',ke(_0x15f9da,_0x5a5a06));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1c1ffa){const _0x377db3=new $e(_0x1c1ffa['providerId'],_0x1c1ffa['signInMethod']);return _0x1c1ffa['idToken']||_0x1c1ffa['accessToken']?(_0x1c1ffa['idToken']&&(_0x377db3['idToken']=_0x1c1ffa['idToken']),_0x1c1ffa['accessToken']&&(_0x377db3['accessToken']=_0x1c1ffa['accessToken']),_0x1c1ffa['nonce']&&!_0x1c1ffa['pendingToken']&&(_0x377db3['nonce']=_0x1c1ffa['nonce']),_0x1c1ffa['pendingToken']&&(_0x377db3['pendingToken']=_0x1c1ffa['pendingToken'])):_0x1c1ffa['oauthToken']&&_0x1c1ffa['oauthTokenSecret']?(_0x377db3['accessToken']=_0x1c1ffa['oauthToken'],_0x377db3['secret']=_0x1c1ffa['oauthTokenSecret']):Y('argument-error'),_0x377db3;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x37ee79){const _0x16f565=typeof _0x37ee79=='string'?JSON['parse'](_0x37ee79):_0x37ee79,{providerId:_0x3941d6,signInMethod:_0x455758,..._0x350dba}=_0x16f565;if(!_0x3941d6||!_0x455758)return null;const _0x29ab5a=new $e(_0x3941d6,_0x455758);return _0x29ab5a['idToken']=_0x350dba['idToken']||void 0x0,_0x29ab5a['accessToken']=_0x350dba['accessToken']||void 0x0,_0x29ab5a['secret']=_0x350dba['secret'],_0x29ab5a['nonce']=_0x350dba['nonce'],_0x29ab5a['pendingToken']=_0x350dba['pendingToken']||null,_0x29ab5a;}['_getIdTokenResponse'](_0x60a50a){const _0x46b215=this['buildRequest']();return nt(_0x60a50a,_0x46b215);}['_linkToIdToken'](_0x221ee3,_0x3acda4){const _0x2631d7=this['buildRequest']();return _0x2631d7['idToken']=_0x3acda4,nt(_0x221ee3,_0x2631d7);}['_getReauthenticationResolver'](_0x518720){const _0x4ac2ad=this['buildRequest']();return _0x4ac2ad['autoCreate']=!0x1,nt(_0x518720,_0x4ac2ad);}['buildRequest'](){const _0xf5d8b7={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0xf5d8b7['pendingToken']=this['pendingToken'];else{const _0xdbb87a={};this['idToken']&&(_0xdbb87a['id_token']=this['idToken']),this['accessToken']&&(_0xdbb87a['access_token']=this['accessToken']),this['secret']&&(_0xdbb87a['oauth_token_secret']=this['secret']),_0xdbb87a['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0xdbb87a['nonce']=this['nonce']),_0xf5d8b7['postBody']=ut(_0xdbb87a);}return _0xf5d8b7;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x1c05a1){switch(_0x1c05a1){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x1f575c){const _0x7aab48=Ct(Tt(_0x1f575c))['link'],_0x1d8f75=_0x7aab48?Ct(Tt(_0x7aab48))['deep_link_id']:null,_0x56798a=Ct(Tt(_0x1f575c))['deep_link_id'];return(_0x56798a?Ct(Tt(_0x56798a))['link']:null)||_0x56798a||_0x1d8f75||_0x7aab48||_0x1f575c;}class Rs{constructor(_0x46c60d){const _0x503375=Ct(Tt(_0x46c60d)),_0x6a9a7b=_0x503375['apiKey']??null,_0x1e78a0=_0x503375['oobCode']??null,_0x4888b4=Jf(_0x503375['mode']??null);m(_0x6a9a7b&&_0x1e78a0&&_0x4888b4,'argument-error'),this['apiKey']=_0x6a9a7b,this['operation']=_0x4888b4,this['code']=_0x1e78a0,this['continueUrl']=_0x503375['continueUrl']??null,this['languageCode']=_0x503375['lang']??null,this['tenantId']=_0x503375['tenantId']??null;}static['parseLink'](_0x20128f){const _0x47f258=Xf(_0x20128f);try{return new Rs(_0x47f258);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x5c073d,_0x41391f){return $t['_fromEmailAndPassword'](_0x5c073d,_0x41391f);}static['credentialWithLink'](_0x58fce9,_0x3eca56){const _0x3d4501=Rs['parseLink'](_0x3eca56);return m(_0x3d4501,'argument-error'),$t['_fromEmailAndCode'](_0x58fce9,_0x3d4501['code'],_0x3d4501['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x34b511){this['providerId']=_0x34b511,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x57cda5){this['defaultLanguageCode']=_0x57cda5;}['setCustomParameters'](_0x256135){return this['customParameters']=_0x256135,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x274460){return this['scopes']['includes'](_0x274460)||this['scopes']['push'](_0x274460),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x513bbb){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x513bbb});}static['credentialFromResult'](_0x4c05cb){return ue['credentialFromTaggedObject'](_0x4c05cb);}static['credentialFromError'](_0x4803a9){return ue['credentialFromTaggedObject'](_0x4803a9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5b8a79}){if(!_0x5b8a79||!('oauthAccessToken'in _0x5b8a79)||!_0x5b8a79['oauthAccessToken'])return null;try{return ue['credential'](_0x5b8a79['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2f1856,_0x431a08){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2f1856,'accessToken':_0x431a08});}static['credentialFromResult'](_0x13f8da){return de['credentialFromTaggedObject'](_0x13f8da);}static['credentialFromError'](_0x57da39){return de['credentialFromTaggedObject'](_0x57da39['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x40c61c}){if(!_0x40c61c)return null;const {oauthIdToken:_0x4b110d,oauthAccessToken:_0x4d6024}=_0x40c61c;if(!_0x4b110d&&!_0x4d6024)return null;try{return de['credential'](_0x4b110d,_0x4d6024);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x3efb0b){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3efb0b});}static['credentialFromResult'](_0x495818){return fe['credentialFromTaggedObject'](_0x495818);}static['credentialFromError'](_0x2b7ab9){return fe['credentialFromTaggedObject'](_0x2b7ab9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x297c66}){if(!_0x297c66||!('oauthAccessToken'in _0x297c66)||!_0x297c66['oauthAccessToken'])return null;try{return fe['credential'](_0x297c66['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x140b6c,_0x18445e){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x140b6c,'oauthTokenSecret':_0x18445e});}static['credentialFromResult'](_0xb3f4da){return pe['credentialFromTaggedObject'](_0xb3f4da);}static['credentialFromError'](_0x3c5beb){return pe['credentialFromTaggedObject'](_0x3c5beb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3bf341}){if(!_0x3bf341)return null;const {oauthAccessToken:_0x113d94,oauthTokenSecret:_0xc855b8}=_0x3bf341;if(!_0x113d94||!_0xc855b8)return null;try{return pe['credential'](_0x113d94,_0xc855b8);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x23a5bf,_0x29b74a){return en(_0x23a5bf,'POST','/v1/accounts:signUp',ke(_0x23a5bf,_0x29b74a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x4a9812){this['user']=_0x4a9812['user'],this['providerId']=_0x4a9812['providerId'],this['_tokenResponse']=_0x4a9812['_tokenResponse'],this['operationType']=_0x4a9812['operationType'];}static async['_fromIdTokenResponse'](_0x33c52f,_0x423dcd,_0x1ce38a,_0x1c46e3=!0x1){const _0x416716=await j['_fromIdTokenResponse'](_0x33c52f,_0x1ce38a,_0x1c46e3),_0x30cef9=Nr(_0x1ce38a);return new Ge({'user':_0x416716,'providerId':_0x30cef9,'_tokenResponse':_0x1ce38a,'operationType':_0x423dcd});}static async['_forOperation'](_0x2b6bfb,_0x417783,_0x3d0380){await _0x2b6bfb['_updateTokensIfNecessary'](_0x3d0380,!0x0);const _0x8e5239=Nr(_0x3d0380);return new Ge({'user':_0x2b6bfb,'providerId':_0x8e5239,'_tokenResponse':_0x3d0380,'operationType':_0x417783});}}function Nr(_0x30ae0d){return _0x30ae0d['providerId']?_0x30ae0d['providerId']:'phoneNumber'in _0x30ae0d?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x135aae,_0x1f3f9a,_0x3e6498,_0x580be0){super(_0x1f3f9a['code'],_0x1f3f9a['message']),this['operationType']=_0x3e6498,this['user']=_0x580be0,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x135aae['name'],'tenantId':_0x135aae['tenantId']??void 0x0,'_serverResponse':_0x1f3f9a['customData']['_serverResponse'],'operationType':_0x3e6498};}static['_fromErrorAndOperation'](_0x4f7775,_0x2e8695,_0x24bed7,_0x1d6f3b){return new On(_0x4f7775,_0x2e8695,_0x24bed7,_0x1d6f3b);}}function Ba(_0x2b58cb,_0x4736bd,_0x3db591,_0x562eaa){return(_0x4736bd==='reauthenticate'?_0x3db591['_getReauthenticationResolver'](_0x2b58cb):_0x3db591['_getIdTokenResponse'](_0x2b58cb))['catch'](_0x4f553c=>{throw _0x4f553c['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x2b58cb,_0x4f553c,_0x4736bd,_0x562eaa):_0x4f553c;});}async function ep(_0x127001,_0x25d786,_0x3bc698=!0x1){const _0x1baf1c=await Ht(_0x127001,_0x25d786['_linkToIdToken'](_0x127001['auth'],await _0x127001['getIdToken']()),_0x3bc698);return Ge['_forOperation'](_0x127001,'link',_0x1baf1c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x29720a,_0x3d158d,_0x31b6f4=!0x1){const {auth:_0x28f231}=_0x29720a;if($(_0x28f231['app']))return Promise['reject'](re(_0x28f231));const _0x3b1b37='reauthenticate';try{const _0x130d85=await Ht(_0x29720a,Ba(_0x28f231,_0x3b1b37,_0x3d158d,_0x29720a),_0x31b6f4);m(_0x130d85['idToken'],_0x28f231,'internal-error');const _0x2b781c=Ts(_0x130d85['idToken']);m(_0x2b781c,_0x28f231,'internal-error');const {sub:_0x1eb4ff}=_0x2b781c;return m(_0x29720a['uid']===_0x1eb4ff,_0x28f231,'user-mismatch'),Ge['_forOperation'](_0x29720a,_0x3b1b37,_0x130d85);}catch(_0x14be7a){throw(_0x14be7a==null?void 0x0:_0x14be7a['code'])==='auth/user-not-found'&&Y(_0x28f231,'user-mismatch'),_0x14be7a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x51e752,_0xad95c1,_0x1a9e31=!0x1){if($(_0x51e752['app']))return Promise['reject'](re(_0x51e752));const _0xf2d065='signIn',_0x3bc0a7=await Ba(_0x51e752,_0xf2d065,_0xad95c1),_0x5906cf=await Ge['_fromIdTokenResponse'](_0x51e752,_0xf2d065,_0x3bc0a7);return _0x1a9e31||await _0x51e752['_updateCurrentUser'](_0x5906cf['user']),_0x5906cf;}async function np(_0x9712b8,_0x58eb80){return Va(Ke(_0x9712b8),_0x58eb80);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x598bf8){const _0x334eac=Ke(_0x598bf8);_0x334eac['_getPasswordPolicyInternal']()&&await _0x334eac['_updatePasswordPolicy']();}async function L_(_0x4d2bec,_0x542a97,_0x710090){if($(_0x4d2bec['app']))return Promise['reject'](re(_0x4d2bec));const _0x4f15b6=Ke(_0x4d2bec),_0x28f311=await xi(_0x4f15b6,{'returnSecureToken':!0x0,'email':_0x542a97,'password':_0x710090,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x66484=>{throw _0x66484['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4d2bec),_0x66484;}),_0x781456=await Ge['_fromIdTokenResponse'](_0x4f15b6,'signIn',_0x28f311);return await _0x4f15b6['_updateCurrentUser'](_0x781456['user']),_0x781456;}function x_(_0x16ccb4,_0x485b1f,_0x319f99){return $(_0x16ccb4['app'])?Promise['reject'](re(_0x16ccb4)):np(P(_0x16ccb4),yt['credential'](_0x485b1f,_0x319f99))['catch'](async _0x5e1b2e=>{throw _0x5e1b2e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x16ccb4),_0x5e1b2e;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0xd05ff3,_0x5735c5){return P(_0xd05ff3)['setPersistence'](_0x5735c5);}function ip(_0x588ce2,_0x287a22,_0x2e1efe,_0x1dd969){return P(_0x588ce2)['onIdTokenChanged'](_0x287a22,_0x2e1efe,_0x1dd969);}function sp(_0x17eb67,_0x1336b3,_0x53d6cb){return P(_0x17eb67)['beforeAuthStateChanged'](_0x1336b3,_0x53d6cb);}function U_(_0x25d1c7,_0x538130,_0x23abf0,_0x3b2b37){return P(_0x25d1c7)['onAuthStateChanged'](_0x538130,_0x23abf0,_0x3b2b37);}function W_(_0x297553){return P(_0x297553)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4a608e,_0xda550b){this['storageRetriever']=_0x4a608e,this['type']=_0xda550b;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0xcba414,_0x5949bf){return this['storage']['setItem'](_0xcba414,JSON['stringify'](_0x5949bf)),Promise['resolve']();}['_get'](_0x2acb09){const _0x1ddaba=this['storage']['getItem'](_0x2acb09);return Promise['resolve'](_0x1ddaba?JSON['parse'](_0x1ddaba):null);}['_remove'](_0x2d6f2b){return this['storage']['removeItem'](_0x2d6f2b),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x20d130,_0x5b7196)=>this['onStorageEvent'](_0x20d130,_0x5b7196),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x106a28){for(const _0x10866b of Object['keys'](this['listeners'])){const _0x5d2342=this['storage']['getItem'](_0x10866b),_0x46be04=this['localCache'][_0x10866b];_0x5d2342!==_0x46be04&&_0x106a28(_0x10866b,_0x46be04,_0x5d2342);}}['onStorageEvent'](_0x2bd98f,_0x32573b=!0x1){if(!_0x2bd98f['key']){this['forAllChangedKeys']((_0xe63ca3,_0x494d4e,_0x5068a4)=>{this['notifyListeners'](_0xe63ca3,_0x5068a4);});return;}const _0xe759b2=_0x2bd98f['key'];_0x32573b?this['detachListener']():this['stopPolling']();const _0x41fb89=()=>{const _0x1a0769=this['storage']['getItem'](_0xe759b2);!_0x32573b&&this['localCache'][_0xe759b2]===_0x1a0769||this['notifyListeners'](_0xe759b2,_0x1a0769);},_0x50f0f5=this['storage']['getItem'](_0xe759b2);Af()&&_0x50f0f5!==_0x2bd98f['newValue']&&_0x2bd98f['newValue']!==_0x2bd98f['oldValue']?setTimeout(_0x41fb89,op):_0x41fb89();}['notifyListeners'](_0x488fb1,_0x3f3c70){this['localCache'][_0x488fb1]=_0x3f3c70;const _0x598c58=this['listeners'][_0x488fb1];if(_0x598c58){for(const _0x2f12f3 of Array['from'](_0x598c58))_0x2f12f3(_0x3f3c70&&JSON['parse'](_0x3f3c70));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x15b474,_0x281ff5,_0x20e1e7)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x15b474,'oldValue':_0x281ff5,'newValue':_0x20e1e7}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0xd9e7b8,_0x59c852){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0xd9e7b8]||(this['listeners'][_0xd9e7b8]=new Set(),this['localCache'][_0xd9e7b8]=this['storage']['getItem'](_0xd9e7b8)),this['listeners'][_0xd9e7b8]['add'](_0x59c852);}['_removeListener'](_0x103074,_0x547c49){this['listeners'][_0x103074]&&(this['listeners'][_0x103074]['delete'](_0x547c49),this['listeners'][_0x103074]['size']===0x0&&delete this['listeners'][_0x103074]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0xa129fb,_0x3c6762){await super['_set'](_0xa129fb,_0x3c6762),this['localCache'][_0xa129fb]=JSON['stringify'](_0x3c6762);}async['_get'](_0x96d9e8){const _0x8f94e4=await super['_get'](_0x96d9e8);return this['localCache'][_0x96d9e8]=JSON['stringify'](_0x8f94e4),_0x8f94e4;}async['_remove'](_0x3f622e){await super['_remove'](_0x3f622e),delete this['localCache'][_0x3f622e];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3b58fc,_0x59be32){}['_removeListener'](_0x3f5a32,_0x723d83){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x1f0d7c){return Promise['all'](_0x1f0d7c['map'](async _0x8b3b60=>{try{return{'fulfilled':!0x0,'value':await _0x8b3b60};}catch(_0xd46a25){return{'fulfilled':!0x1,'reason':_0xd46a25};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x1a165b){this['eventTarget']=_0x1a165b,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1b3a54){const _0x2e4a75=this['receivers']['find'](_0x25460c=>_0x25460c['isListeningto'](_0x1b3a54));if(_0x2e4a75)return _0x2e4a75;const _0x559d2d=new Xn(_0x1b3a54);return this['receivers']['push'](_0x559d2d),_0x559d2d;}['isListeningto'](_0x5d3bf8){return this['eventTarget']===_0x5d3bf8;}async['handleEvent'](_0x1705e1){const _0x1a7281=_0x1705e1,{eventId:_0x231208,eventType:_0x5db851,data:_0xedb264}=_0x1a7281['data'],_0x5f1bb1=this['handlersMap'][_0x5db851];if(!(_0x5f1bb1!=null&&_0x5f1bb1['size']))return;_0x1a7281['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x231208,'eventType':_0x5db851});const _0x26aa98=Array['from'](_0x5f1bb1)['map'](async _0x44ec6a=>_0x44ec6a(_0x1a7281['origin'],_0xedb264)),_0x21cf17=await cp(_0x26aa98);_0x1a7281['ports'][0x0]['postMessage']({'status':'done','eventId':_0x231208,'eventType':_0x5db851,'response':_0x21cf17});}['_subscribe'](_0x5074be,_0x177593){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5074be]||(this['handlersMap'][_0x5074be]=new Set()),this['handlersMap'][_0x5074be]['add'](_0x177593);}['_unsubscribe'](_0x322cb7,_0x35fbfa){this['handlersMap'][_0x322cb7]&&_0x35fbfa&&this['handlersMap'][_0x322cb7]['delete'](_0x35fbfa),(!_0x35fbfa||this['handlersMap'][_0x322cb7]['size']===0x0)&&delete this['handlersMap'][_0x322cb7],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x4c52fb='',_0x115d48=0xa){let _0x2bc0ff='';for(let _0x4c2ea1=0x0;_0x4c2ea1<_0x115d48;_0x4c2ea1++)_0x2bc0ff+=Math['floor'](Math['random']()*0xa);return _0x4c52fb+_0x2bc0ff;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x1609ac){this['target']=_0x1609ac,this['handlers']=new Set();}['removeMessageHandler'](_0x1e61e4){_0x1e61e4['messageChannel']&&(_0x1e61e4['messageChannel']['port1']['removeEventListener']('message',_0x1e61e4['onMessage']),_0x1e61e4['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1e61e4);}async['_send'](_0x4830a3,_0x394600,_0x3fe541=0x32){const _0x5bdd2e=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x5bdd2e)throw new Error('connection_unavailable');let _0x3174c5,_0x505c79;return new Promise((_0x53a712,_0x3b200d)=>{const _0x5e6c54=As('',0x14);_0x5bdd2e['port1']['start']();const _0x46b737=setTimeout(()=>{_0x3b200d(new Error('unsupported_event'));},_0x3fe541);_0x505c79={'messageChannel':_0x5bdd2e,'onMessage'(_0x51a026){const _0x3b000e=_0x51a026;if(_0x3b000e['data']['eventId']===_0x5e6c54)switch(_0x3b000e['data']['status']){case'ack':clearTimeout(_0x46b737),_0x3174c5=setTimeout(()=>{_0x3b200d(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x3174c5),_0x53a712(_0x3b000e['data']['response']);break;default:clearTimeout(_0x46b737),clearTimeout(_0x3174c5),_0x3b200d(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x505c79),_0x5bdd2e['port1']['addEventListener']('message',_0x505c79['onMessage']),this['target']['postMessage']({'eventType':_0x4830a3,'eventId':_0x5e6c54,'data':_0x394600},[_0x5bdd2e['port2']]);})['finally'](()=>{_0x505c79&&this['removeMessageHandler'](_0x505c79);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x28a3aa){Z()['location']['href']=_0x28a3aa;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x2265e5;return((_0x2265e5=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2265e5['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x421777){this['request']=_0x421777;}['toPromise'](){return new Promise((_0x2ee12d,_0x161848)=>{this['request']['addEventListener']('success',()=>{_0x2ee12d(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x161848(this['request']['error']);});});}}function Zn(_0x5d001f,_0x2a8523){return _0x5d001f['transaction']([Mn],_0x2a8523?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x534d8e=indexedDB['deleteDatabase'](Ka);return new nn(_0x534d8e)['toPromise']();}function Qa(){const _0x39e94f=indexedDB['open'](Ka,pp);return new Promise((_0x30efd3,_0x5600f3)=>{_0x39e94f['addEventListener']('error',()=>{_0x5600f3(_0x39e94f['error']);}),_0x39e94f['addEventListener']('upgradeneeded',()=>{const _0x41bd00=_0x39e94f['result'];try{_0x41bd00['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x2558d0){_0x5600f3(_0x2558d0);}}),_0x39e94f['addEventListener']('success',async()=>{const _0x407280=_0x39e94f['result'];_0x407280['objectStoreNames']['contains'](Mn)?_0x30efd3(_0x407280):(_0x407280['close'](),await _p(),_0x30efd3(await Qa()));});});}async function Or(_0x5496e2,_0x435381,_0x3483be){const _0x22f58c=Zn(_0x5496e2,!0x0)['put']({[Ya]:_0x435381,'value':_0x3483be});return new nn(_0x22f58c)['toPromise']();}async function gp(_0x438dc0,_0x2f9119){const _0x548e59=Zn(_0x438dc0,!0x1)['get'](_0x2f9119),_0x3e72d7=await new nn(_0x548e59)['toPromise']();return _0x3e72d7===void 0x0?null:_0x3e72d7['value'];}function Dr(_0x22f377,_0x3dc6f0){const _0x564e25=Zn(_0x22f377,!0x0)['delete'](_0x3dc6f0);return new nn(_0x564e25)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x277acf){let _0x3e0036=0x0;for(;;)try{const _0x28aa00=await this['_openDb']();return await _0x277acf(_0x28aa00);}catch(_0x517a32){if(_0x3e0036++>yp)throw _0x517a32;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x483484,_0x30ad75)=>({'keyProcessed':(await this['_poll']())['includes'](_0x30ad75['key'])})),this['receiver']['_subscribe']('ping',async(_0x592708,_0x4194bf)=>['keyChanged']);}async['initializeSender'](){var _0x48647b,_0x4b9a54;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x1e8fb5=await this['sender']['_send']('ping',{},0x320);_0x1e8fb5&&(_0x48647b=_0x1e8fb5[0x0])!=null&&_0x48647b['fulfilled']&&(_0x4b9a54=_0x1e8fb5[0x0])!=null&&_0x4b9a54['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x5dbb2a){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x5dbb2a},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x458f41=>{await Or(_0x458f41,Dn,'1'),await Dr(_0x458f41,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x570b8b){this['pendingWrites']++;try{await _0x570b8b();}finally{this['pendingWrites']--;}}async['_set'](_0x5f0396,_0x5aa1e2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x552117=>Or(_0x552117,_0x5f0396,_0x5aa1e2)),this['localCache'][_0x5f0396]=_0x5aa1e2,this['notifyServiceWorker'](_0x5f0396)));}async['_get'](_0x3d3fde){const _0x49f501=await this['_withRetries'](_0x335cab=>gp(_0x335cab,_0x3d3fde));return this['localCache'][_0x3d3fde]=_0x49f501,_0x49f501;}async['_remove'](_0x4c373c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1abf34=>Dr(_0x1abf34,_0x4c373c)),delete this['localCache'][_0x4c373c],this['notifyServiceWorker'](_0x4c373c)));}async['_poll'](){const _0x20b72d=await this['_withRetries'](_0x41deb1=>{const _0x23281e=Zn(_0x41deb1,!0x1)['getAll']();return new nn(_0x23281e)['toPromise']();});if(!_0x20b72d)return[];if(this['pendingWrites']!==0x0)return[];const _0xebc691=[],_0x2d5637=new Set();if(_0x20b72d['length']!==0x0){for(const {fbase_key:_0x82d728,value:_0x3eef7e}of _0x20b72d)_0x2d5637['add'](_0x82d728),JSON['stringify'](this['localCache'][_0x82d728])!==JSON['stringify'](_0x3eef7e)&&(this['notifyListeners'](_0x82d728,_0x3eef7e),_0xebc691['push'](_0x82d728));}for(const _0x514286 of Object['keys'](this['localCache']))this['localCache'][_0x514286]&&!_0x2d5637['has'](_0x514286)&&(this['notifyListeners'](_0x514286,null),_0xebc691['push'](_0x514286));return _0xebc691;}['notifyListeners'](_0xda5bfb,_0x3fae33){this['localCache'][_0xda5bfb]=_0x3fae33;const _0x5a1436=this['listeners'][_0xda5bfb];if(_0x5a1436){for(const _0x5219cb of Array['from'](_0x5a1436))_0x5219cb(_0x3fae33);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3dc9b8,_0x369798){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3dc9b8]||(this['listeners'][_0x3dc9b8]=new Set(),this['_get'](_0x3dc9b8)),this['listeners'][_0x3dc9b8]['add'](_0x369798);}['_removeListener'](_0x13c70a,_0x444aab){this['listeners'][_0x13c70a]&&(this['listeners'][_0x13c70a]['delete'](_0x444aab),this['listeners'][_0x13c70a]['size']===0x0&&delete this['listeners'][_0x13c70a]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0xad6b71,_0x388559){return _0x388559?ie(_0x388559):(m(_0xad6b71['_popupRedirectResolver'],_0xad6b71,'argument-error'),_0xad6b71['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x324c95){super('custom','custom'),this['params']=_0x324c95;}['_getIdTokenResponse'](_0x20df79){return nt(_0x20df79,this['_buildIdpRequest']());}['_linkToIdToken'](_0x35bd73,_0x1dd700){return nt(_0x35bd73,this['_buildIdpRequest'](_0x1dd700));}['_getReauthenticationResolver'](_0x5a0ad6){return nt(_0x5a0ad6,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x53ceea){const _0x1c3228={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x53ceea&&(_0x1c3228['idToken']=_0x53ceea),_0x1c3228;}}function Ip(_0x55e36a){return Va(_0x55e36a['auth'],new ks(_0x55e36a),_0x55e36a['bypassAuthState']);}function wp(_0x5b8f21){const {auth:_0x175d7f,user:_0x190ee6}=_0x5b8f21;return m(_0x190ee6,_0x175d7f,'internal-error'),tp(_0x190ee6,new ks(_0x5b8f21),_0x5b8f21['bypassAuthState']);}async function Cp(_0x3c2c8b){const {auth:_0x451e09,user:_0x4987bc}=_0x3c2c8b;return m(_0x4987bc,_0x451e09,'internal-error'),ep(_0x4987bc,new ks(_0x3c2c8b),_0x3c2c8b['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x17cc1e,_0x125393,_0x538492,_0x35b810,_0x53184e=!0x1){this['auth']=_0x17cc1e,this['resolver']=_0x538492,this['user']=_0x35b810,this['bypassAuthState']=_0x53184e,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x125393)?_0x125393:[_0x125393];}['execute'](){return new Promise(async(_0x5002a9,_0x5d807d)=>{this['pendingPromise']={'resolve':_0x5002a9,'reject':_0x5d807d};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xaac993){this['reject'](_0xaac993);}});}async['onAuthEvent'](_0x8f1f22){const {urlResponse:_0x4eb335,sessionId:_0x311bd3,postBody:_0xccfff5,tenantId:_0xd687d4,error:_0x22c3d3,type:_0x45f1f4}=_0x8f1f22;if(_0x22c3d3){this['reject'](_0x22c3d3);return;}const _0x3f5285={'auth':this['auth'],'requestUri':_0x4eb335,'sessionId':_0x311bd3,'tenantId':_0xd687d4||void 0x0,'postBody':_0xccfff5||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x45f1f4)(_0x3f5285));}catch(_0x512fa4){this['reject'](_0x512fa4);}}['onError'](_0x48bb04){this['reject'](_0x48bb04);}['getIdpTask'](_0x5bf23b){switch(_0x5bf23b){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x4e558b){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4e558b),this['unregisterAndCleanUp']();}['reject'](_0x3c1cdc){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3c1cdc),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x42a023,_0x358884,_0x5b5f42,_0xf91c3,_0x266cbf){super(_0x42a023,_0x358884,_0xf91c3,_0x266cbf),this['provider']=_0x5b5f42,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x416b70=await this['execute']();return m(_0x416b70,this['auth'],'internal-error'),_0x416b70;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xfb90ef=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xfb90ef),this['authWindow']['associatedEvent']=_0xfb90ef,this['resolver']['_originValidation'](this['auth'])['catch'](_0x501ab8=>{this['reject'](_0x501ab8);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1d9eac=>{_0x1d9eac||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1877f6;return((_0x1877f6=this['authWindow'])==null?void 0x0:_0x1877f6['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x73b0af=()=>{var _0x556da1,_0x527b2c;if((_0x527b2c=(_0x556da1=this['authWindow'])==null?void 0x0:_0x556da1['window'])!=null&&_0x527b2c['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x73b0af,Tp['get']());};_0x73b0af();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x2bd6f6,_0xd7df76,_0x5807c7=!0x1){super(_0x2bd6f6,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0xd7df76,void 0x0,_0x5807c7),this['eventId']=null;}async['execute'](){let _0x574d9f=hn['get'](this['auth']['_key']());if(!_0x574d9f){try{const _0x44ab4e=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x574d9f=()=>Promise['resolve'](_0x44ab4e);}catch(_0x42d5a1){_0x574d9f=()=>Promise['reject'](_0x42d5a1);}hn['set'](this['auth']['_key'](),_0x574d9f);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x574d9f();}async['onAuthEvent'](_0x576938){if(_0x576938['type']==='signInViaRedirect')return super['onAuthEvent'](_0x576938);if(_0x576938['type']==='unknown'){this['resolve'](null);return;}if(_0x576938['eventId']){const _0x4e70b6=await this['auth']['_redirectUserForId'](_0x576938['eventId']);if(_0x4e70b6)return this['user']=_0x4e70b6,super['onAuthEvent'](_0x576938);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x25b1cd,_0x53b804){const _0x446003=Pp(_0x53b804),_0x3293da=kp(_0x25b1cd);if(!await _0x3293da['_isAvailable']())return!0x1;const _0x9b1855=await _0x3293da['_get'](_0x446003)==='true';return await _0x3293da['_remove'](_0x446003),_0x9b1855;}function Ap(_0x15ecb1,_0x2cdebe){hn['set'](_0x15ecb1['_key'](),_0x2cdebe);}function kp(_0x2e2bf2){return ie(_0x2e2bf2['_redirectPersistence']);}function Pp(_0x5e65ce){return ln(Sp,_0x5e65ce['config']['apiKey'],_0x5e65ce['name']);}async function Np(_0x494bcc,_0x1cd5b4,_0x5d0534=!0x1){if($(_0x494bcc['app']))return Promise['reject'](re(_0x494bcc));const _0x41cd57=Ke(_0x494bcc),_0x5382dc=Ep(_0x41cd57,_0x1cd5b4),_0x17e356=await new bp(_0x41cd57,_0x5382dc,_0x5d0534)['execute']();return _0x17e356&&!_0x5d0534&&(delete _0x17e356['user']['_redirectEventId'],await _0x41cd57['_persistUserIfCurrent'](_0x17e356['user']),await _0x41cd57['_setRedirectUser'](null,_0x1cd5b4)),_0x17e356;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x4adf49){this['auth']=_0x4adf49,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x94c112){this['consumers']['add'](_0x94c112),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x94c112)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x94c112),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2097d0){this['consumers']['delete'](_0x2097d0);}['onEvent'](_0x48801a){if(this['hasEventBeenHandled'](_0x48801a))return!0x1;let _0xeaaab8=!0x1;return this['consumers']['forEach'](_0x1fb988=>{this['isEventForConsumer'](_0x48801a,_0x1fb988)&&(_0xeaaab8=!0x0,this['sendToConsumer'](_0x48801a,_0x1fb988),this['saveEventToCache'](_0x48801a));}),this['hasHandledPotentialRedirect']||!Mp(_0x48801a)||(this['hasHandledPotentialRedirect']=!0x0,_0xeaaab8||(this['queuedRedirectEvent']=_0x48801a,_0xeaaab8=!0x0)),_0xeaaab8;}['sendToConsumer'](_0x4da721,_0x56d4a9){var _0x3ec868;if(_0x4da721['error']&&!Za(_0x4da721)){const _0x4b939f=((_0x3ec868=_0x4da721['error']['code'])==null?void 0x0:_0x3ec868['split']('auth/')[0x1])||'internal-error';_0x56d4a9['onError'](X(this['auth'],_0x4b939f));}else _0x56d4a9['onAuthEvent'](_0x4da721);}['isEventForConsumer'](_0x12af10,_0x2b3646){const _0x15844e=_0x2b3646['eventId']===null||!!_0x12af10['eventId']&&_0x12af10['eventId']===_0x2b3646['eventId'];return _0x2b3646['filter']['includes'](_0x12af10['type'])&&_0x15844e;}['hasEventBeenHandled'](_0x5bac08){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x5bac08));}['saveEventToCache'](_0x43de34){this['cachedEventUids']['add'](Mr(_0x43de34)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x28ef0c){return[_0x28ef0c['type'],_0x28ef0c['eventId'],_0x28ef0c['sessionId'],_0x28ef0c['tenantId']]['filter'](_0x43a177=>_0x43a177)['join']('-');}function Za({type:_0x58be11,error:_0x2f07ec}){return _0x58be11==='unknown'&&(_0x2f07ec==null?void 0x0:_0x2f07ec['code'])==='auth/no-auth-event';}function Mp(_0x132446){switch(_0x132446['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x132446);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x4a0e77,_0x59f9ed={}){return Pe(_0x4a0e77,'GET','/v1/projects',_0x59f9ed);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x137642){if(_0x137642['config']['emulator'])return;const {authorizedDomains:_0x245b06}=await Lp(_0x137642);for(const _0x204d4e of _0x245b06)try{if(Wp(_0x204d4e))return;}catch{}Y(_0x137642,'unauthorized-domain');}function Wp(_0x251293){const _0x38764e=Mi(),{protocol:_0x18c381,hostname:_0x342e31}=new URL(_0x38764e);if(_0x251293['startsWith']('chrome-extension://')){const _0x20f0a7=new URL(_0x251293);return _0x20f0a7['hostname']===''&&_0x342e31===''?_0x18c381==='chrome-extension:'&&_0x251293['replace']('chrome-extension://','')===_0x38764e['replace']('chrome-extension://',''):_0x18c381==='chrome-extension:'&&_0x20f0a7['hostname']===_0x342e31;}if(!Fp['test'](_0x18c381))return!0x1;if(xp['test'](_0x251293))return _0x342e31===_0x251293;const _0x3a2cd0=_0x251293['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3a2cd0+'|'+_0x3a2cd0+')$','i')['test'](_0x342e31);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x23279d=Z()['___jsl'];if(_0x23279d!=null&&_0x23279d['H']){for(const _0x1773e1 of Object['keys'](_0x23279d['H']))if(_0x23279d['H'][_0x1773e1]['r']=_0x23279d['H'][_0x1773e1]['r']||[],_0x23279d['H'][_0x1773e1]['L']=_0x23279d['H'][_0x1773e1]['L']||[],_0x23279d['H'][_0x1773e1]['r']=[..._0x23279d['H'][_0x1773e1]['L']],_0x23279d['CP']){for(let _0x306121=0x0;_0x306121<_0x23279d['CP']['length'];_0x306121++)_0x23279d['CP'][_0x306121]=null;}}}function Vp(_0x4c7434){return new Promise((_0x2a5394,_0x2e4fc2)=>{var _0xa1a122,_0x5c9d70,_0x378dba;function _0x48f8e1(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2a5394(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x2e4fc2(X(_0x4c7434,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x5c9d70=(_0xa1a122=Z()['gapi'])==null?void 0x0:_0xa1a122['iframes'])!=null&&_0x5c9d70['Iframe'])_0x2a5394(gapi['iframes']['getContext']());else{if((_0x378dba=Z()['gapi'])!=null&&_0x378dba['load'])_0x48f8e1();else{const _0x501098=Ff('iframefcb');return Z()[_0x501098]=()=>{gapi['load']?_0x48f8e1():_0x2e4fc2(X(_0x4c7434,'network-request-failed'));},xa(xf()+'?onload='+_0x501098)['catch'](_0x1a681c=>_0x2e4fc2(_0x1a681c));}}})['catch'](_0x53cd0e=>{throw un=null,_0x53cd0e;});}let un=null;function Hp(_0x5b81ec){return un=un||Vp(_0x5b81ec),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x13d218){const _0x71aea1=_0x13d218['config'];m(_0x71aea1['authDomain'],_0x13d218,'auth-domain-config-required');const _0xa1ed8f=_0x71aea1['emulator']?Cs(_0x71aea1,qp):'https://'+_0x13d218['config']['authDomain']+'/'+Gp,_0x380c4a={'apiKey':_0x71aea1['apiKey'],'appName':_0x13d218['name'],'v':dt},_0x465822=jp['get'](_0x13d218['config']['apiHost']);_0x465822&&(_0x380c4a['eid']=_0x465822);const _0x29740c=_0x13d218['_getFrameworks']();return _0x29740c['length']&&(_0x380c4a['fw']=_0x29740c['join'](',')),_0xa1ed8f+'?'+ut(_0x380c4a)['slice'](0x1);}async function Yp(_0x423404){const _0x59a138=await Hp(_0x423404),_0x203d58=Z()['gapi'];return m(_0x203d58,_0x423404,'internal-error'),_0x59a138['open']({'where':document['body'],'url':Kp(_0x423404),'messageHandlersFilter':_0x203d58['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x12c7da=>new Promise(async(_0x959ce8,_0x9ebe63)=>{await _0x12c7da['restyle']({'setHideOnLeave':!0x1});const _0x55b145=X(_0x423404,'network-request-failed'),_0x3a8c1a=Z()['setTimeout'](()=>{_0x9ebe63(_0x55b145);},$p['get']());function _0x3ccfb9(){Z()['clearTimeout'](_0x3a8c1a),_0x959ce8(_0x12c7da);}_0x12c7da['ping'](_0x3ccfb9)['then'](_0x3ccfb9,()=>{_0x9ebe63(_0x55b145);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x18c98b){this['window']=_0x18c98b,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0xefaf56,_0x9da00f,_0x177bf4,_0x4646ae=Jp,_0x27383b=Xp){const _0x2d2cd8=Math['max']((window['screen']['availHeight']-_0x27383b)/0x2,0x0)['toString'](),_0x578b0c=Math['max']((window['screen']['availWidth']-_0x4646ae)/0x2,0x0)['toString']();let _0x533c06='';const _0x5d0f37={...Qp,'width':_0x4646ae['toString'](),'height':_0x27383b['toString'](),'top':_0x2d2cd8,'left':_0x578b0c},_0x93fc02=W()['toLowerCase']();_0x177bf4&&(_0x533c06=ka(_0x93fc02)?Zp:_0x177bf4),Ra(_0x93fc02)&&(_0x9da00f=_0x9da00f||e_,_0x5d0f37['scrollbars']='yes');const _0x1c4d42=Object['entries'](_0x5d0f37)['reduce']((_0x2be75e,[_0x1f327d,_0x3a8e66])=>''+_0x2be75e+_0x1f327d+'='+_0x3a8e66+',','');if(Rf(_0x93fc02)&&_0x533c06!=='_self')return n_(_0x9da00f||'',_0x533c06),new xr(null);const _0x20d746=window['open'](_0x9da00f||'',_0x533c06,_0x1c4d42);m(_0x20d746,_0xefaf56,'popup-blocked');try{_0x20d746['focus']();}catch{}return new xr(_0x20d746);}function n_(_0x4fdd2d,_0x39958b){const _0x1ed97f=document['createElement']('a');_0x1ed97f['href']=_0x4fdd2d,_0x1ed97f['target']=_0x39958b;const _0x34f2dc=document['createEvent']('MouseEvent');_0x34f2dc['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1ed97f['dispatchEvent'](_0x34f2dc);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x490be8,_0x46d1dc,_0x47db86,_0x2e67ac,_0x56a753,_0x244622){m(_0x490be8['config']['authDomain'],_0x490be8,'auth-domain-config-required'),m(_0x490be8['config']['apiKey'],_0x490be8,'invalid-api-key');const _0x368a59={'apiKey':_0x490be8['config']['apiKey'],'appName':_0x490be8['name'],'authType':_0x47db86,'redirectUrl':_0x2e67ac,'v':dt,'eventId':_0x56a753};if(_0x46d1dc instanceof Wa){_0x46d1dc['setDefaultLanguage'](_0x490be8['languageCode']),_0x368a59['providerId']=_0x46d1dc['providerId']||'',pn(_0x46d1dc['getCustomParameters']())||(_0x368a59['customParameters']=JSON['stringify'](_0x46d1dc['getCustomParameters']()));for(const [_0x40d804,_0x2c8eea]of Object['entries']({}))_0x368a59[_0x40d804]=_0x2c8eea;}if(_0x46d1dc instanceof tn){const _0x10feea=_0x46d1dc['getScopes']()['filter'](_0x1a7115=>_0x1a7115!=='');_0x10feea['length']>0x0&&(_0x368a59['scopes']=_0x10feea['join'](','));}_0x490be8['tenantId']&&(_0x368a59['tid']=_0x490be8['tenantId']);const _0x120221=_0x368a59;for(const _0x22e18b of Object['keys'](_0x120221))_0x120221[_0x22e18b]===void 0x0&&delete _0x120221[_0x22e18b];const _0x185106=await _0x490be8['_getAppCheckToken'](),_0x275d72=_0x185106?'#'+r_+'='+encodeURIComponent(_0x185106):'';return o_(_0x490be8)+'?'+ut(_0x120221)['slice'](0x1)+_0x275d72;}function o_({config:_0x3585da}){return _0x3585da['emulator']?Cs(_0x3585da,s_):'https://'+_0x3585da['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x485d3d,_0x1bc10d,_0x300563,_0x5c701a){var _0x2fc3dc;ce((_0x2fc3dc=this['eventManagers'][_0x485d3d['_key']()])==null?void 0x0:_0x2fc3dc['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2c4400=await Fr(_0x485d3d,_0x1bc10d,_0x300563,Mi(),_0x5c701a);return t_(_0x485d3d,_0x2c4400,As());}async['_openRedirect'](_0x397e68,_0xf69922,_0x1d9d9d,_0x3a5a2a){await this['_originValidation'](_0x397e68);const _0x3d1ac0=await Fr(_0x397e68,_0xf69922,_0x1d9d9d,Mi(),_0x3a5a2a);return hp(_0x3d1ac0),new Promise(()=>{});}['_initialize'](_0x453fed){const _0x3ff90f=_0x453fed['_key']();if(this['eventManagers'][_0x3ff90f]){const {manager:_0x27b7fb,promise:_0x56a986}=this['eventManagers'][_0x3ff90f];return _0x27b7fb?Promise['resolve'](_0x27b7fb):(ce(_0x56a986,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x56a986);}const _0x4dd160=this['initAndGetManager'](_0x453fed);return this['eventManagers'][_0x3ff90f]={'promise':_0x4dd160},_0x4dd160['catch'](()=>{delete this['eventManagers'][_0x3ff90f];}),_0x4dd160;}async['initAndGetManager'](_0x4ccd08){const _0x5377ad=await Yp(_0x4ccd08),_0x3b9655=new Dp(_0x4ccd08);return _0x5377ad['register']('authEvent',_0x14928b=>(m(_0x14928b==null?void 0x0:_0x14928b['authEvent'],_0x4ccd08,'invalid-auth-event'),{'status':_0x3b9655['onEvent'](_0x14928b['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x4ccd08['_key']()]={'manager':_0x3b9655},this['iframes'][_0x4ccd08['_key']()]=_0x5377ad,_0x3b9655;}['_isIframeWebStorageSupported'](_0x5eb986,_0x4bdb3b){this['iframes'][_0x5eb986['_key']()]['send'](pi,{'type':pi},_0x37881c=>{var _0x164f75;const _0x47f02d=(_0x164f75=_0x37881c==null?void 0x0:_0x37881c[0x0])==null?void 0x0:_0x164f75[pi];_0x47f02d!==void 0x0&&_0x4bdb3b(!!_0x47f02d),Y(_0x5eb986,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0xe76d78){const _0x507be5=_0xe76d78['_key']();return this['originValidationPromises'][_0x507be5]||(this['originValidationPromises'][_0x507be5]=Up(_0xe76d78)),this['originValidationPromises'][_0x507be5];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x66d07f){this['auth']=_0x66d07f,this['internalListeners']=new Map();}['getUid'](){var _0x3d36c9;return this['assertAuthConfigured'](),((_0x3d36c9=this['auth']['currentUser'])==null?void 0x0:_0x3d36c9['uid'])||null;}async['getToken'](_0x29f8e3){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x29f8e3)}:null;}['addAuthTokenListener'](_0x1308b5){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x1308b5))return;const _0x7ef8a=this['auth']['onIdTokenChanged'](_0x5d4700=>{_0x1308b5((_0x5d4700==null?void 0x0:_0x5d4700['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x1308b5,_0x7ef8a),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2f3671){this['assertAuthConfigured']();const _0x22d88d=this['internalListeners']['get'](_0x2f3671);_0x22d88d&&(this['internalListeners']['delete'](_0x2f3671),_0x22d88d(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x3924f6){switch(_0x3924f6){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x3c63c8){st(new Fe('auth',(_0x41d841,{options:_0x55d6c0})=>{const _0x2b7bdf=_0x41d841['getProvider']('app')['getImmediate'](),_0x517096=_0x41d841['getProvider']('heartbeat'),_0x88f460=_0x41d841['getProvider']('app-check-internal'),{apiKey:_0x3dcd6e,authDomain:_0x128d0d}=_0x2b7bdf['options'];m(_0x3dcd6e&&!_0x3dcd6e['includes'](':'),'invalid-api-key',{'appName':_0x2b7bdf['name']});const _0x4553b9={'apiKey':_0x3dcd6e,'authDomain':_0x128d0d,'clientPlatform':_0x3c63c8,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x3c63c8)},_0x476850=new Df(_0x2b7bdf,_0x517096,_0x88f460,_0x4553b9);return Hf(_0x476850,_0x55d6c0),_0x476850;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x5ae896,_0xa7c5c2,_0x9a92f6)=>{_0x5ae896['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x2bc0d0=>{const _0xb283fa=Ke(_0x2bc0d0['getProvider']('auth')['getImmediate']());return(_0x521fe9=>new l_(_0x521fe9))(_0xb283fa);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x3c63c8)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x19166e=>async _0x467a91=>{const _0x3d1694=_0x467a91&&await _0x467a91['getIdTokenResult'](),_0x4a5040=_0x3d1694&&(new Date()['getTime']()-Date['parse'](_0x3d1694['issuedAtTime']))/0x3e8;if(_0x4a5040&&_0x4a5040>f_)return;const _0x2d2ed0=_0x3d1694==null?void 0x0:_0x3d1694['token'];Br!==_0x2d2ed0&&(Br=_0x2d2ed0,await fetch(_0x19166e,{'method':_0x2d2ed0?'POST':'DELETE','headers':_0x2d2ed0?{'Authorization':'Bearer\x20'+_0x2d2ed0}:{}}));};function B_(_0xdc0be4=Zr()){const _0x43fb82=Hi(_0xdc0be4,'auth');if(_0x43fb82['isInitialized']())return _0x43fb82['getImmediate']();const _0x40bb72=Vf(_0xdc0be4,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x52c74a=jr('authTokenSyncURL');if(_0x52c74a&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x39fb57=new URL(_0x52c74a,location['origin']);if(location['origin']===_0x39fb57['origin']){const _0x4cd13b=p_(_0x39fb57['toString']());sp(_0x40bb72,_0x4cd13b,()=>_0x4cd13b(_0x40bb72['currentUser'])),ip(_0x40bb72,_0x3fe9db=>_0x4cd13b(_0x3fe9db));}}const _0xa99f8a=qr('auth');return _0xa99f8a&&$f(_0x40bb72,'http://'+_0xa99f8a),_0x40bb72;}function __(){var _0x39160b;return((_0x39160b=document['getElementsByTagName']('head'))==null?void 0x0:_0x39160b[0x0])??document;}Mf({'loadJS'(_0x3534b9){return new Promise((_0x5a2e0d,_0x525fb5)=>{const _0x2784de=document['createElement']('script');_0x2784de['setAttribute']('src',_0x3534b9),_0x2784de['onload']=_0x5a2e0d,_0x2784de['onerror']=_0x493d27=>{const _0x30ba3c=X('internal-error');_0x30ba3c['customData']=_0x493d27,_0x525fb5(_0x30ba3c);},_0x2784de['type']='text/javascript',_0x2784de['charset']='UTF-8',__()['appendChild'](_0x2784de);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};