const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x320998,_0x28155c){if(!_0x320998)throw ot(_0x28155c);},ot=function(_0x204b96){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x204b96);},Wr=function(_0xb76346){const _0x291176=[];let _0x273b69=0x0;for(let _0x4eb206=0x0;_0x4eb206<_0xb76346['length'];_0x4eb206++){let _0x5b9dbb=_0xb76346['charCodeAt'](_0x4eb206);_0x5b9dbb<0x80?_0x291176[_0x273b69++]=_0x5b9dbb:_0x5b9dbb<0x800?(_0x291176[_0x273b69++]=_0x5b9dbb>>0x6|0xc0,_0x291176[_0x273b69++]=_0x5b9dbb&0x3f|0x80):(_0x5b9dbb&0xfc00)===0xd800&&_0x4eb206+0x1<_0xb76346['length']&&(_0xb76346['charCodeAt'](_0x4eb206+0x1)&0xfc00)===0xdc00?(_0x5b9dbb=0x10000+((_0x5b9dbb&0x3ff)<<0xa)+(_0xb76346['charCodeAt'](++_0x4eb206)&0x3ff),_0x291176[_0x273b69++]=_0x5b9dbb>>0x12|0xf0,_0x291176[_0x273b69++]=_0x5b9dbb>>0xc&0x3f|0x80,_0x291176[_0x273b69++]=_0x5b9dbb>>0x6&0x3f|0x80,_0x291176[_0x273b69++]=_0x5b9dbb&0x3f|0x80):(_0x291176[_0x273b69++]=_0x5b9dbb>>0xc|0xe0,_0x291176[_0x273b69++]=_0x5b9dbb>>0x6&0x3f|0x80,_0x291176[_0x273b69++]=_0x5b9dbb&0x3f|0x80);}return _0x291176;},Za=function(_0x352b80){const _0x2a380a=[];let _0x18e699=0x0,_0x44d2a9=0x0;for(;_0x18e699<_0x352b80['length'];){const _0x292ac1=_0x352b80[_0x18e699++];if(_0x292ac1<0x80)_0x2a380a[_0x44d2a9++]=String['fromCharCode'](_0x292ac1);else{if(_0x292ac1>0xbf&&_0x292ac1<0xe0){const _0x279fd3=_0x352b80[_0x18e699++];_0x2a380a[_0x44d2a9++]=String['fromCharCode']((_0x292ac1&0x1f)<<0x6|_0x279fd3&0x3f);}else{if(_0x292ac1>0xef&&_0x292ac1<0x16d){const _0x120d12=_0x352b80[_0x18e699++],_0x52fe60=_0x352b80[_0x18e699++],_0x2b4f35=_0x352b80[_0x18e699++],_0x532a25=((_0x292ac1&0x7)<<0x12|(_0x120d12&0x3f)<<0xc|(_0x52fe60&0x3f)<<0x6|_0x2b4f35&0x3f)-0x10000;_0x2a380a[_0x44d2a9++]=String['fromCharCode'](0xd800+(_0x532a25>>0xa)),_0x2a380a[_0x44d2a9++]=String['fromCharCode'](0xdc00+(_0x532a25&0x3ff));}else{const _0x30fb7c=_0x352b80[_0x18e699++],_0x1bac14=_0x352b80[_0x18e699++];_0x2a380a[_0x44d2a9++]=String['fromCharCode']((_0x292ac1&0xf)<<0xc|(_0x30fb7c&0x3f)<<0x6|_0x1bac14&0x3f);}}}}return _0x2a380a['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x1524c2,_0x454a3f){if(!Array['isArray'](_0x1524c2))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0xe53555=_0x454a3f?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x434dc2=[];for(let _0x26a231=0x0;_0x26a231<_0x1524c2['length'];_0x26a231+=0x3){const _0x3ef1b6=_0x1524c2[_0x26a231],_0x5a21e0=_0x26a231+0x1<_0x1524c2['length'],_0x3f12e2=_0x5a21e0?_0x1524c2[_0x26a231+0x1]:0x0,_0x1e14b3=_0x26a231+0x2<_0x1524c2['length'],_0x5b4f17=_0x1e14b3?_0x1524c2[_0x26a231+0x2]:0x0,_0x33d887=_0x3ef1b6>>0x2,_0x525d6e=(_0x3ef1b6&0x3)<<0x4|_0x3f12e2>>0x4;let _0x248e83=(_0x3f12e2&0xf)<<0x2|_0x5b4f17>>0x6,_0x43e04d=_0x5b4f17&0x3f;_0x1e14b3||(_0x43e04d=0x40,_0x5a21e0||(_0x248e83=0x40)),_0x434dc2['push'](_0xe53555[_0x33d887],_0xe53555[_0x525d6e],_0xe53555[_0x248e83],_0xe53555[_0x43e04d]);}return _0x434dc2['join']('');},'encodeString'(_0x44f75f,_0x2d347a){return this['HAS_NATIVE_SUPPORT']&&!_0x2d347a?btoa(_0x44f75f):this['encodeByteArray'](Wr(_0x44f75f),_0x2d347a);},'decodeString'(_0x1695d8,_0x1ca619){return this['HAS_NATIVE_SUPPORT']&&!_0x1ca619?atob(_0x1695d8):Za(this['decodeStringToByteArray'](_0x1695d8,_0x1ca619));},'decodeStringToByteArray'(_0x31259a,_0x1b4403){this['init_']();const _0x4d155b=_0x1b4403?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x393f5b=[];for(let _0x1b3d01=0x0;_0x1b3d01<_0x31259a['length'];){const _0x112084=_0x4d155b[_0x31259a['charAt'](_0x1b3d01++)],_0xbb2fe5=_0x1b3d01<_0x31259a['length']?_0x4d155b[_0x31259a['charAt'](_0x1b3d01)]:0x0;++_0x1b3d01;const _0x38e26c=_0x1b3d01<_0x31259a['length']?_0x4d155b[_0x31259a['charAt'](_0x1b3d01)]:0x40;++_0x1b3d01;const _0x54edbe=_0x1b3d01<_0x31259a['length']?_0x4d155b[_0x31259a['charAt'](_0x1b3d01)]:0x40;if(++_0x1b3d01,_0x112084==null||_0xbb2fe5==null||_0x38e26c==null||_0x54edbe==null)throw new ec();const _0x3bdca2=_0x112084<<0x2|_0xbb2fe5>>0x4;if(_0x393f5b['push'](_0x3bdca2),_0x38e26c!==0x40){const _0x571436=_0xbb2fe5<<0x4&0xf0|_0x38e26c>>0x2;if(_0x393f5b['push'](_0x571436),_0x54edbe!==0x40){const _0x2ed8b7=_0x38e26c<<0x6&0xc0|_0x54edbe;_0x393f5b['push'](_0x2ed8b7);}}}return _0x393f5b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x8ce619=0x0;_0x8ce619<this['ENCODED_VALS']['length'];_0x8ce619++)this['byteToCharMap_'][_0x8ce619]=this['ENCODED_VALS']['charAt'](_0x8ce619),this['charToByteMap_'][this['byteToCharMap_'][_0x8ce619]]=_0x8ce619,this['byteToCharMapWebSafe_'][_0x8ce619]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x8ce619),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x8ce619]]=_0x8ce619,_0x8ce619>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x8ce619)]=_0x8ce619,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x8ce619)]=_0x8ce619);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x3a6745){const _0x3ce36f=Wr(_0x3a6745);return Di['encodeByteArray'](_0x3ce36f,!0x0);},an=function(_0x2665b8){return Br(_0x2665b8)['replace'](/\./g,'');},cn=function(_0x279926){try{return Di['decodeString'](_0x279926,!0x0);}catch(_0x15b698){console['error']('base64Decode\x20failed:\x20',_0x15b698);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x29c3b9){return Vr(void 0x0,_0x29c3b9);}function Vr(_0x18e6f8,_0x38fca6){if(!(_0x38fca6 instanceof Object))return _0x38fca6;switch(_0x38fca6['constructor']){case Date:const _0x4fde7f=_0x38fca6;return new Date(_0x4fde7f['getTime']());case Object:_0x18e6f8===void 0x0&&(_0x18e6f8={});break;case Array:_0x18e6f8=[];break;default:return _0x38fca6;}for(const _0xd6035d in _0x38fca6)!_0x38fca6['hasOwnProperty'](_0xd6035d)||!nc(_0xd6035d)||(_0x18e6f8[_0xd6035d]=Vr(_0x18e6f8[_0xd6035d],_0x38fca6[_0xd6035d]));return _0x18e6f8;}function nc(_0x3fb2c8){return _0x3fb2c8!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x2b9ef4=As['__FIREBASE_DEFAULTS__'];if(_0x2b9ef4)return JSON['parse'](_0x2b9ef4);},oc=()=>{if(typeof document>'u')return;let _0x1cd64a;try{_0x1cd64a=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x24eda9=_0x1cd64a&&cn(_0x1cd64a[0x1]);return _0x24eda9&&JSON['parse'](_0x24eda9);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x594688){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x594688);return;}},Hr=_0x4fd175=>{var _0x1a0d1b,_0x538b4f;return(_0x538b4f=(_0x1a0d1b=Mi())==null?void 0x0:_0x1a0d1b['emulatorHosts'])==null?void 0x0:_0x538b4f[_0x4fd175];},ac=_0x4591a9=>{const _0x44f1b8=Hr(_0x4591a9);if(!_0x44f1b8)return;const _0xfb723a=_0x44f1b8['lastIndexOf'](':');if(_0xfb723a<=0x0||_0xfb723a+0x1===_0x44f1b8['length'])throw new Error('Invalid\x20host\x20'+_0x44f1b8+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5a730d=parseInt(_0x44f1b8['substring'](_0xfb723a+0x1),0xa);return _0x44f1b8[0x0]==='['?[_0x44f1b8['substring'](0x1,_0xfb723a-0x1),_0x5a730d]:[_0x44f1b8['substring'](0x0,_0xfb723a),_0x5a730d];},$r=()=>{var _0x28c9d5;return(_0x28c9d5=Mi())==null?void 0x0:_0x28c9d5['config'];},Gr=_0x5ae9dc=>{var _0x52279d;return(_0x52279d=Mi())==null?void 0x0:_0x52279d['_'+_0x5ae9dc];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4d9c49,_0x5e2ce2)=>{this['resolve']=_0x4d9c49,this['reject']=_0x5e2ce2;});}['wrapCallback'](_0x58dda0){return(_0x37aa02,_0x1b6fc8)=>{_0x37aa02?this['reject'](_0x37aa02):this['resolve'](_0x1b6fc8),typeof _0x58dda0=='function'&&(this['promise']['catch'](()=>{}),_0x58dda0['length']===0x1?_0x58dda0(_0x37aa02):_0x58dda0(_0x37aa02,_0x1b6fc8));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x2c492f,_0x56654d){if(_0x2c492f['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x531a41={'alg':'none','type':'JWT'},_0x2f894a=_0x56654d||'demo-project',_0x4b16e0=_0x2c492f['iat']||0x0,_0x284f8b=_0x2c492f['sub']||_0x2c492f['user_id'];if(!_0x284f8b)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x21400d={'iss':'https://securetoken.google.com/'+_0x2f894a,'aud':_0x2f894a,'iat':_0x4b16e0,'exp':_0x4b16e0+0xe10,'auth_time':_0x4b16e0,'sub':_0x284f8b,'user_id':_0x284f8b,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x2c492f};return[an(JSON['stringify'](_0x531a41)),an(JSON['stringify'](_0x21400d)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x20d5ff=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x20d5ff=='object'&&_0x20d5ff['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0xdca071=W();return _0xdca071['indexOf']('MSIE\x20')>=0x0||_0xdca071['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x3b18af,_0x25fab4)=>{try{let _0x5da618=!0x0;const _0x59093e='validate-browser-context-for-indexeddb-analytics-module',_0x298f25=self['indexedDB']['open'](_0x59093e);_0x298f25['onsuccess']=()=>{_0x298f25['result']['close'](),_0x5da618||self['indexedDB']['deleteDatabase'](_0x59093e),_0x3b18af(!0x0);},_0x298f25['onupgradeneeded']=()=>{_0x5da618=!0x1;},_0x298f25['onerror']=()=>{var _0x3e4827;_0x25fab4(((_0x3e4827=_0x298f25['error'])==null?void 0x0:_0x3e4827['message'])||'');};}catch(_0x531e90){_0x25fab4(_0x531e90);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x182974,_0x5292d8,_0x1644a8){super(_0x5292d8),this['code']=_0x182974,this['customData']=_0x1644a8,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x335c53,_0x1d6ffe,_0x1ec0db){this['service']=_0x335c53,this['serviceName']=_0x1d6ffe,this['errors']=_0x1ec0db;}['create'](_0x5b18f2,..._0x37f223){const _0x271f4d=_0x37f223[0x0]||{},_0x181cbc=this['service']+'/'+_0x5b18f2,_0x492290=this['errors'][_0x5b18f2],_0x30e819=_0x492290?gc(_0x492290,_0x271f4d):'Error',_0x2ea5cb=this['serviceName']+':\x20'+_0x30e819+'\x20('+_0x181cbc+').';return new Se(_0x181cbc,_0x2ea5cb,_0x271f4d);}}function gc(_0x140133,_0x41fa25){return _0x140133['replace'](mc,(_0x5968af,_0x1f1b3c)=>{const _0x3eca6c=_0x41fa25[_0x1f1b3c];return _0x3eca6c!=null?String(_0x3eca6c):'<'+_0x1f1b3c+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x4e8477){return JSON['parse'](_0x4e8477);}function O(_0x3fdbe6){return JSON['stringify'](_0x3fdbe6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x5a8ac9){let _0x3b32a2={},_0x1f29fb={},_0x4cd21d={},_0x3fd763='';try{const _0x34b97f=_0x5a8ac9['split']('.');_0x3b32a2=bt(cn(_0x34b97f[0x0])||''),_0x1f29fb=bt(cn(_0x34b97f[0x1])||''),_0x3fd763=_0x34b97f[0x2],_0x4cd21d=_0x1f29fb['d']||{},delete _0x1f29fb['d'];}catch{}return{'header':_0x3b32a2,'claims':_0x1f29fb,'data':_0x4cd21d,'signature':_0x3fd763};},yc=function(_0x719b39){const _0x1a8eb3=zr(_0x719b39),_0x374ec2=_0x1a8eb3['claims'];return!!_0x374ec2&&typeof _0x374ec2=='object'&&_0x374ec2['hasOwnProperty']('iat');},vc=function(_0x191295){const _0x19c05d=zr(_0x191295)['claims'];return typeof _0x19c05d=='object'&&_0x19c05d['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1e5a52,_0x5ddfe4){return Object['prototype']['hasOwnProperty']['call'](_0x1e5a52,_0x5ddfe4);}function Oe(_0x56d52f,_0x5cab39){if(Object['prototype']['hasOwnProperty']['call'](_0x56d52f,_0x5cab39))return _0x56d52f[_0x5cab39];}function hi(_0x383ee4){for(const _0x49d70f in _0x383ee4)if(Object['prototype']['hasOwnProperty']['call'](_0x383ee4,_0x49d70f))return!0x1;return!0x0;}function ln(_0x49a00f,_0x2c11c4,_0x81afa4){const _0x416f0a={};for(const _0x124332 in _0x49a00f)Object['prototype']['hasOwnProperty']['call'](_0x49a00f,_0x124332)&&(_0x416f0a[_0x124332]=_0x2c11c4['call'](_0x81afa4,_0x49a00f[_0x124332],_0x124332,_0x49a00f));return _0x416f0a;}function De(_0x2324ba,_0x399de0){if(_0x2324ba===_0x399de0)return!0x0;const _0x1cd217=Object['keys'](_0x2324ba),_0x325b58=Object['keys'](_0x399de0);for(const _0x4df1b1 of _0x1cd217){if(!_0x325b58['includes'](_0x4df1b1))return!0x1;const _0x93e304=_0x2324ba[_0x4df1b1],_0x811a18=_0x399de0[_0x4df1b1];if(ks(_0x93e304)&&ks(_0x811a18)){if(!De(_0x93e304,_0x811a18))return!0x1;}else{if(_0x93e304!==_0x811a18)return!0x1;}}for(const _0x4eb842 of _0x325b58)if(!_0x1cd217['includes'](_0x4eb842))return!0x1;return!0x0;}function ks(_0x5033a4){return _0x5033a4!==null&&typeof _0x5033a4=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0xb718b1){const _0x1a1f09=[];for(const [_0x4728e2,_0xb69572]of Object['entries'](_0xb718b1))Array['isArray'](_0xb69572)?_0xb69572['forEach'](_0x33a324=>{_0x1a1f09['push'](encodeURIComponent(_0x4728e2)+'='+encodeURIComponent(_0x33a324));}):_0x1a1f09['push'](encodeURIComponent(_0x4728e2)+'='+encodeURIComponent(_0xb69572));return _0x1a1f09['length']?'&'+_0x1a1f09['join']('&'):'';}function yt(_0x6cbbfc){const _0x3c1e66={};return _0x6cbbfc['replace'](/^\?/,'')['split']('&')['forEach'](_0x1b9df4=>{if(_0x1b9df4){const [_0x49f391,_0x381be9]=_0x1b9df4['split']('=');_0x3c1e66[decodeURIComponent(_0x49f391)]=decodeURIComponent(_0x381be9);}}),_0x3c1e66;}function vt(_0x8024cf){const _0x6f6dc6=_0x8024cf['indexOf']('?');if(!_0x6f6dc6)return'';const _0x5b009f=_0x8024cf['indexOf']('#',_0x6f6dc6);return _0x8024cf['substring'](_0x6f6dc6,_0x5b009f>0x0?_0x5b009f:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x4a0d94=0x1;_0x4a0d94<this['blockSize'];++_0x4a0d94)this['pad_'][_0x4a0d94]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5a94a6,_0x24fd74){_0x24fd74||(_0x24fd74=0x0);const _0x887139=this['W_'];if(typeof _0x5a94a6=='string'){for(let _0x3eef80=0x0;_0x3eef80<0x10;_0x3eef80++)_0x887139[_0x3eef80]=_0x5a94a6['charCodeAt'](_0x24fd74)<<0x18|_0x5a94a6['charCodeAt'](_0x24fd74+0x1)<<0x10|_0x5a94a6['charCodeAt'](_0x24fd74+0x2)<<0x8|_0x5a94a6['charCodeAt'](_0x24fd74+0x3),_0x24fd74+=0x4;}else{for(let _0x54dcc4=0x0;_0x54dcc4<0x10;_0x54dcc4++)_0x887139[_0x54dcc4]=_0x5a94a6[_0x24fd74]<<0x18|_0x5a94a6[_0x24fd74+0x1]<<0x10|_0x5a94a6[_0x24fd74+0x2]<<0x8|_0x5a94a6[_0x24fd74+0x3],_0x24fd74+=0x4;}for(let _0x457a33=0x10;_0x457a33<0x50;_0x457a33++){const _0x258f0d=_0x887139[_0x457a33-0x3]^_0x887139[_0x457a33-0x8]^_0x887139[_0x457a33-0xe]^_0x887139[_0x457a33-0x10];_0x887139[_0x457a33]=(_0x258f0d<<0x1|_0x258f0d>>>0x1f)&0xffffffff;}let _0x4e70c9=this['chain_'][0x0],_0x3f11ad=this['chain_'][0x1],_0x1c8965=this['chain_'][0x2],_0x6f95a6=this['chain_'][0x3],_0x20461b=this['chain_'][0x4],_0x5bb351,_0xa21c1f;for(let _0x59dd4a=0x0;_0x59dd4a<0x50;_0x59dd4a++){_0x59dd4a<0x28?_0x59dd4a<0x14?(_0x5bb351=_0x6f95a6^_0x3f11ad&(_0x1c8965^_0x6f95a6),_0xa21c1f=0x5a827999):(_0x5bb351=_0x3f11ad^_0x1c8965^_0x6f95a6,_0xa21c1f=0x6ed9eba1):_0x59dd4a<0x3c?(_0x5bb351=_0x3f11ad&_0x1c8965|_0x6f95a6&(_0x3f11ad|_0x1c8965),_0xa21c1f=0x8f1bbcdc):(_0x5bb351=_0x3f11ad^_0x1c8965^_0x6f95a6,_0xa21c1f=0xca62c1d6);const _0x40fea=(_0x4e70c9<<0x5|_0x4e70c9>>>0x1b)+_0x5bb351+_0x20461b+_0xa21c1f+_0x887139[_0x59dd4a]&0xffffffff;_0x20461b=_0x6f95a6,_0x6f95a6=_0x1c8965,_0x1c8965=(_0x3f11ad<<0x1e|_0x3f11ad>>>0x2)&0xffffffff,_0x3f11ad=_0x4e70c9,_0x4e70c9=_0x40fea;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4e70c9&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x3f11ad&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1c8965&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x6f95a6&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x20461b&0xffffffff;}['update'](_0x4c7741,_0x1951e9){if(_0x4c7741==null)return;_0x1951e9===void 0x0&&(_0x1951e9=_0x4c7741['length']);const _0x5b5a67=_0x1951e9-this['blockSize'];let _0x304b20=0x0;const _0x5df1f9=this['buf_'];let _0x41e835=this['inbuf_'];for(;_0x304b20<_0x1951e9;){if(_0x41e835===0x0){for(;_0x304b20<=_0x5b5a67;)this['compress_'](_0x4c7741,_0x304b20),_0x304b20+=this['blockSize'];}if(typeof _0x4c7741=='string'){for(;_0x304b20<_0x1951e9;)if(_0x5df1f9[_0x41e835]=_0x4c7741['charCodeAt'](_0x304b20),++_0x41e835,++_0x304b20,_0x41e835===this['blockSize']){this['compress_'](_0x5df1f9),_0x41e835=0x0;break;}}else{for(;_0x304b20<_0x1951e9;)if(_0x5df1f9[_0x41e835]=_0x4c7741[_0x304b20],++_0x41e835,++_0x304b20,_0x41e835===this['blockSize']){this['compress_'](_0x5df1f9),_0x41e835=0x0;break;}}}this['inbuf_']=_0x41e835,this['total_']+=_0x1951e9;}['digest'](){const _0x5191a3=[];let _0x3b254c=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x6a8d8f=this['blockSize']-0x1;_0x6a8d8f>=0x38;_0x6a8d8f--)this['buf_'][_0x6a8d8f]=_0x3b254c&0xff,_0x3b254c/=0x100;this['compress_'](this['buf_']);let _0x381367=0x0;for(let _0x8f6337=0x0;_0x8f6337<0x5;_0x8f6337++)for(let _0x50d2a7=0x18;_0x50d2a7>=0x0;_0x50d2a7-=0x8)_0x5191a3[_0x381367]=this['chain_'][_0x8f6337]>>_0x50d2a7&0xff,++_0x381367;return _0x5191a3;}}function Ic(_0x119359,_0x43fba7){const _0x2f9a35=new wc(_0x119359,_0x43fba7);return _0x2f9a35['subscribe']['bind'](_0x2f9a35);}class wc{constructor(_0x4a84da,_0x50550a){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x50550a,this['task']['then'](()=>{_0x4a84da(this);})['catch'](_0x30e9c5=>{this['error'](_0x30e9c5);});}['next'](_0x458e61){this['forEachObserver'](_0x18e49c=>{_0x18e49c['next'](_0x458e61);});}['error'](_0x12cf01){this['forEachObserver'](_0x281447=>{_0x281447['error'](_0x12cf01);}),this['close'](_0x12cf01);}['complete'](){this['forEachObserver'](_0x1a6f7b=>{_0x1a6f7b['complete']();}),this['close']();}['subscribe'](_0x3fd127,_0x1b1d89,_0x2346e2){let _0x46688d;if(_0x3fd127===void 0x0&&_0x1b1d89===void 0x0&&_0x2346e2===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x3fd127,['next','error','complete'])?_0x46688d=_0x3fd127:_0x46688d={'next':_0x3fd127,'error':_0x1b1d89,'complete':_0x2346e2},_0x46688d['next']===void 0x0&&(_0x46688d['next']=Qn),_0x46688d['error']===void 0x0&&(_0x46688d['error']=Qn),_0x46688d['complete']===void 0x0&&(_0x46688d['complete']=Qn);const _0x165d54=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x46688d['error'](this['finalError']):_0x46688d['complete']();}catch{}}),this['observers']['push'](_0x46688d),_0x165d54;}['unsubscribeOne'](_0xb6e2b1){this['observers']===void 0x0||this['observers'][_0xb6e2b1]===void 0x0||(delete this['observers'][_0xb6e2b1],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1d4196){if(!this['finalized']){for(let _0x271e79=0x0;_0x271e79<this['observers']['length'];_0x271e79++)this['sendOne'](_0x271e79,_0x1d4196);}}['sendOne'](_0x53cb5e,_0x1c3712){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x53cb5e]!==void 0x0)try{_0x1c3712(this['observers'][_0x53cb5e]);}catch(_0x47abf0){typeof console<'u'&&console['error']&&console['error'](_0x47abf0);}});}['close'](_0x53617e){this['finalized']||(this['finalized']=!0x0,_0x53617e!==void 0x0&&(this['finalError']=_0x53617e),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x2393c6,_0xe842c2){if(typeof _0x2393c6!='object'||_0x2393c6===null)return!0x1;for(const _0x3b6d5a of _0xe842c2)if(_0x3b6d5a in _0x2393c6&&typeof _0x2393c6[_0x3b6d5a]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x533454,_0x432940){return _0x533454+'\x20failed:\x20'+_0x432940+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x2298ec){const _0x698391=[];let _0x268e67=0x0;for(let _0x5c20b8=0x0;_0x5c20b8<_0x2298ec['length'];_0x5c20b8++){let _0x3359fd=_0x2298ec['charCodeAt'](_0x5c20b8);if(_0x3359fd>=0xd800&&_0x3359fd<=0xdbff){const _0x2019ed=_0x3359fd-0xd800;_0x5c20b8++,f(_0x5c20b8<_0x2298ec['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1b7f47=_0x2298ec['charCodeAt'](_0x5c20b8)-0xdc00;_0x3359fd=0x10000+(_0x2019ed<<0xa)+_0x1b7f47;}_0x3359fd<0x80?_0x698391[_0x268e67++]=_0x3359fd:_0x3359fd<0x800?(_0x698391[_0x268e67++]=_0x3359fd>>0x6|0xc0,_0x698391[_0x268e67++]=_0x3359fd&0x3f|0x80):_0x3359fd<0x10000?(_0x698391[_0x268e67++]=_0x3359fd>>0xc|0xe0,_0x698391[_0x268e67++]=_0x3359fd>>0x6&0x3f|0x80,_0x698391[_0x268e67++]=_0x3359fd&0x3f|0x80):(_0x698391[_0x268e67++]=_0x3359fd>>0x12|0xf0,_0x698391[_0x268e67++]=_0x3359fd>>0xc&0x3f|0x80,_0x698391[_0x268e67++]=_0x3359fd>>0x6&0x3f|0x80,_0x698391[_0x268e67++]=_0x3359fd&0x3f|0x80);}return _0x698391;},Pn=function(_0x80c55d){let _0x29aa09=0x0;for(let _0xd2ac85=0x0;_0xd2ac85<_0x80c55d['length'];_0xd2ac85++){const _0x342b6b=_0x80c55d['charCodeAt'](_0xd2ac85);_0x342b6b<0x80?_0x29aa09++:_0x342b6b<0x800?_0x29aa09+=0x2:_0x342b6b>=0xd800&&_0x342b6b<=0xdbff?(_0x29aa09+=0x4,_0xd2ac85++):_0x29aa09+=0x3;}return _0x29aa09;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0xa3cd52){return _0xa3cd52&&_0xa3cd52['_delegate']?_0xa3cd52['_delegate']:_0xa3cd52;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x59959c){try{return(_0x59959c['startsWith']('http://')||_0x59959c['startsWith']('https://')?new URL(_0x59959c)['hostname']:_0x59959c)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x1aeaeb){return(await fetch(_0x1aeaeb,{'credentials':'include'}))['ok'];}class Me{constructor(_0x32a9bf,_0x35e1e4,_0x2d48b6){this['name']=_0x32a9bf,this['instanceFactory']=_0x35e1e4,this['type']=_0x2d48b6,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0xfbe1c7){return this['instantiationMode']=_0xfbe1c7,this;}['setMultipleInstances'](_0x16857f){return this['multipleInstances']=_0x16857f,this;}['setServiceProps'](_0x30c38e){return this['serviceProps']=_0x30c38e,this;}['setInstanceCreatedCallback'](_0x74f005){return this['onInstanceCreated']=_0x74f005,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x29cb28,_0x2e30f1){this['name']=_0x29cb28,this['container']=_0x2e30f1,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xd88212){const _0x280d35=this['normalizeInstanceIdentifier'](_0xd88212);if(!this['instancesDeferred']['has'](_0x280d35)){const _0x18450a=new Ve();if(this['instancesDeferred']['set'](_0x280d35,_0x18450a),this['isInitialized'](_0x280d35)||this['shouldAutoInitialize']())try{const _0x1ba01a=this['getOrInitializeService']({'instanceIdentifier':_0x280d35});_0x1ba01a&&_0x18450a['resolve'](_0x1ba01a);}catch{}}return this['instancesDeferred']['get'](_0x280d35)['promise'];}['getImmediate'](_0x1703b0){const _0x41668e=this['normalizeInstanceIdentifier'](_0x1703b0==null?void 0x0:_0x1703b0['identifier']),_0x133157=(_0x1703b0==null?void 0x0:_0x1703b0['optional'])??!0x1;if(this['isInitialized'](_0x41668e)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x41668e});}catch(_0x4d114d){if(_0x133157)return null;throw _0x4d114d;}else{if(_0x133157)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x4998fc){if(_0x4998fc['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x4998fc['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x4998fc,!!this['shouldAutoInitialize']()){if(Rc(_0x4998fc))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x4352c9,_0xd76130]of this['instancesDeferred']['entries']()){const _0x196241=this['normalizeInstanceIdentifier'](_0x4352c9);try{const _0x5af96a=this['getOrInitializeService']({'instanceIdentifier':_0x196241});_0xd76130['resolve'](_0x5af96a);}catch{}}}}['clearInstance'](_0x5a4ca5=ke){this['instancesDeferred']['delete'](_0x5a4ca5),this['instancesOptions']['delete'](_0x5a4ca5),this['instances']['delete'](_0x5a4ca5);}async['delete'](){const _0x1ae782=Array['from'](this['instances']['values']());await Promise['all']([..._0x1ae782['filter'](_0x113804=>'INTERNAL'in _0x113804)['map'](_0xb3820e=>_0xb3820e['INTERNAL']['delete']()),..._0x1ae782['filter'](_0xc26598=>'_delete'in _0xc26598)['map'](_0x5db142=>_0x5db142['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x51a7af=ke){return this['instances']['has'](_0x51a7af);}['getOptions'](_0x54e68d=ke){return this['instancesOptions']['get'](_0x54e68d)||{};}['initialize'](_0x697d65={}){const {options:_0x204919={}}=_0x697d65,_0x16bead=this['normalizeInstanceIdentifier'](_0x697d65['instanceIdentifier']);if(this['isInitialized'](_0x16bead))throw Error(this['name']+'('+_0x16bead+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x26751c=this['getOrInitializeService']({'instanceIdentifier':_0x16bead,'options':_0x204919});for(const [_0x54b023,_0x21c42c]of this['instancesDeferred']['entries']()){const _0x36677a=this['normalizeInstanceIdentifier'](_0x54b023);_0x16bead===_0x36677a&&_0x21c42c['resolve'](_0x26751c);}return _0x26751c;}['onInit'](_0x2e6247,_0x2cb6a1){const _0x2e14b0=this['normalizeInstanceIdentifier'](_0x2cb6a1),_0x56cd7e=this['onInitCallbacks']['get'](_0x2e14b0)??new Set();_0x56cd7e['add'](_0x2e6247),this['onInitCallbacks']['set'](_0x2e14b0,_0x56cd7e);const _0x3efc1a=this['instances']['get'](_0x2e14b0);return _0x3efc1a&&_0x2e6247(_0x3efc1a,_0x2e14b0),()=>{_0x56cd7e['delete'](_0x2e6247);};}['invokeOnInitCallbacks'](_0x16a20d,_0x401e2f){const _0x3ebf75=this['onInitCallbacks']['get'](_0x401e2f);if(_0x3ebf75){for(const _0x5ec19c of _0x3ebf75)try{_0x5ec19c(_0x16a20d,_0x401e2f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x14e715,options:_0x561d9f={}}){let _0x1f7f53=this['instances']['get'](_0x14e715);if(!_0x1f7f53&&this['component']&&(_0x1f7f53=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x14e715),'options':_0x561d9f}),this['instances']['set'](_0x14e715,_0x1f7f53),this['instancesOptions']['set'](_0x14e715,_0x561d9f),this['invokeOnInitCallbacks'](_0x1f7f53,_0x14e715),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x14e715,_0x1f7f53);}catch{}return _0x1f7f53||null;}['normalizeInstanceIdentifier'](_0x39bd6d=ke){return this['component']?this['component']['multipleInstances']?_0x39bd6d:ke:_0x39bd6d;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0xc7c545){return _0xc7c545===ke?void 0x0:_0xc7c545;}function Rc(_0x5934e4){return _0x5934e4['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4b3d82){this['name']=_0x4b3d82,this['providers']=new Map();}['addComponent'](_0x2ef63c){const _0x5e9afc=this['getProvider'](_0x2ef63c['name']);if(_0x5e9afc['isComponentSet']())throw new Error('Component\x20'+_0x2ef63c['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5e9afc['setComponent'](_0x2ef63c);}['addOrOverwriteComponent'](_0x19ed43){this['getProvider'](_0x19ed43['name'])['isComponentSet']()&&this['providers']['delete'](_0x19ed43['name']),this['addComponent'](_0x19ed43);}['getProvider'](_0x4976ac){if(this['providers']['has'](_0x4976ac))return this['providers']['get'](_0x4976ac);const _0x4a9d60=new Sc(_0x4976ac,this);return this['providers']['set'](_0x4976ac,_0x4a9d60),_0x4a9d60;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x30eaae){_0x30eaae[_0x30eaae['DEBUG']=0x0]='DEBUG',_0x30eaae[_0x30eaae['VERBOSE']=0x1]='VERBOSE',_0x30eaae[_0x30eaae['INFO']=0x2]='INFO',_0x30eaae[_0x30eaae['WARN']=0x3]='WARN',_0x30eaae[_0x30eaae['ERROR']=0x4]='ERROR',_0x30eaae[_0x30eaae['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0xb32d80,_0x19bbbd,..._0x3d145d)=>{if(_0x19bbbd<_0xb32d80['logLevel'])return;const _0x5eb50e=new Date()['toISOString'](),_0x3838db=Pc[_0x19bbbd];if(_0x3838db)console[_0x3838db]('['+_0x5eb50e+']\x20\x20'+_0xb32d80['name']+':',..._0x3d145d);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x19bbbd+')');};class xi{constructor(_0x3c88f9){this['name']=_0x3c88f9,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x2205f0){if(!(_0x2205f0 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x2205f0+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x2205f0;}['setLogLevel'](_0x4e8107){this['_logLevel']=typeof _0x4e8107=='string'?kc[_0x4e8107]:_0x4e8107;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5ea237){if(typeof _0x5ea237!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5ea237;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x263c54){this['_userLogHandler']=_0x263c54;}['debug'](..._0x345b46){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x345b46),this['_logHandler'](this,T['DEBUG'],..._0x345b46);}['log'](..._0x3a731e){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x3a731e),this['_logHandler'](this,T['VERBOSE'],..._0x3a731e);}['info'](..._0x11bc97){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x11bc97),this['_logHandler'](this,T['INFO'],..._0x11bc97);}['warn'](..._0x45754a){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x45754a),this['_logHandler'](this,T['WARN'],..._0x45754a);}['error'](..._0xd55b71){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0xd55b71),this['_logHandler'](this,T['ERROR'],..._0xd55b71);}}const Dc=(_0x235ffe,_0x59ae3b)=>_0x59ae3b['some'](_0x164164=>_0x235ffe instanceof _0x164164);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x5f003e){const _0x5bcd6a=new Promise((_0xa96f0f,_0x7e738b)=>{const _0x20871c=()=>{_0x5f003e['removeEventListener']('success',_0x4b737f),_0x5f003e['removeEventListener']('error',_0x364bd7);},_0x4b737f=()=>{_0xa96f0f(_e(_0x5f003e['result'])),_0x20871c();},_0x364bd7=()=>{_0x7e738b(_0x5f003e['error']),_0x20871c();};_0x5f003e['addEventListener']('success',_0x4b737f),_0x5f003e['addEventListener']('error',_0x364bd7);});return _0x5bcd6a['then'](_0x2cae4f=>{_0x2cae4f instanceof IDBCursor&&Kr['set'](_0x2cae4f,_0x5f003e);})['catch'](()=>{}),Fi['set'](_0x5bcd6a,_0x5f003e),_0x5bcd6a;}function Fc(_0x383bda){if(ui['has'](_0x383bda))return;const _0x2b3da4=new Promise((_0x5def33,_0x328909)=>{const _0x3414fd=()=>{_0x383bda['removeEventListener']('complete',_0x4ecc3e),_0x383bda['removeEventListener']('error',_0x433637),_0x383bda['removeEventListener']('abort',_0x433637);},_0x4ecc3e=()=>{_0x5def33(),_0x3414fd();},_0x433637=()=>{_0x328909(_0x383bda['error']||new DOMException('AbortError','AbortError')),_0x3414fd();};_0x383bda['addEventListener']('complete',_0x4ecc3e),_0x383bda['addEventListener']('error',_0x433637),_0x383bda['addEventListener']('abort',_0x433637);});ui['set'](_0x383bda,_0x2b3da4);}let di={'get'(_0x512a90,_0x244231,_0x1ede84){if(_0x512a90 instanceof IDBTransaction){if(_0x244231==='done')return ui['get'](_0x512a90);if(_0x244231==='objectStoreNames')return _0x512a90['objectStoreNames']||Yr['get'](_0x512a90);if(_0x244231==='store')return _0x1ede84['objectStoreNames'][0x1]?void 0x0:_0x1ede84['objectStore'](_0x1ede84['objectStoreNames'][0x0]);}return _e(_0x512a90[_0x244231]);},'set'(_0x188e1e,_0x4de19e,_0x5ab6a1){return _0x188e1e[_0x4de19e]=_0x5ab6a1,!0x0;},'has'(_0x337edd,_0xfbac4c){return _0x337edd instanceof IDBTransaction&&(_0xfbac4c==='done'||_0xfbac4c==='store')?!0x0:_0xfbac4c in _0x337edd;}};function Uc(_0x11341c){di=_0x11341c(di);}function Wc(_0x3f8116){return _0x3f8116===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4c8942,..._0x48fbc9){const _0x585760=_0x3f8116['call'](Xn(this),_0x4c8942,..._0x48fbc9);return Yr['set'](_0x585760,_0x4c8942['sort']?_0x4c8942['sort']():[_0x4c8942]),_e(_0x585760);}:Lc()['includes'](_0x3f8116)?function(..._0x6e61dc){return _0x3f8116['apply'](Xn(this),_0x6e61dc),_e(Kr['get'](this));}:function(..._0x4e4fe3){return _e(_0x3f8116['apply'](Xn(this),_0x4e4fe3));};}function Bc(_0x5ba749){return typeof _0x5ba749=='function'?Wc(_0x5ba749):(_0x5ba749 instanceof IDBTransaction&&Fc(_0x5ba749),Dc(_0x5ba749,Mc())?new Proxy(_0x5ba749,di):_0x5ba749);}function _e(_0x23963d){if(_0x23963d instanceof IDBRequest)return xc(_0x23963d);if(Jn['has'](_0x23963d))return Jn['get'](_0x23963d);const _0x40cac0=Bc(_0x23963d);return _0x40cac0!==_0x23963d&&(Jn['set'](_0x23963d,_0x40cac0),Fi['set'](_0x40cac0,_0x23963d)),_0x40cac0;}const Xn=_0x12cb72=>Fi['get'](_0x12cb72);function Vc(_0x6518f6,_0x13e0b9,{blocked:_0x1e8ec5,upgrade:_0x22149a,blocking:_0x39b17c,terminated:_0x11bf84}={}){const _0x3a0ce9=indexedDB['open'](_0x6518f6,_0x13e0b9),_0x5b41fe=_e(_0x3a0ce9);return _0x22149a&&_0x3a0ce9['addEventListener']('upgradeneeded',_0x1c30a2=>{_0x22149a(_e(_0x3a0ce9['result']),_0x1c30a2['oldVersion'],_0x1c30a2['newVersion'],_e(_0x3a0ce9['transaction']),_0x1c30a2);}),_0x1e8ec5&&_0x3a0ce9['addEventListener']('blocked',_0x580178=>_0x1e8ec5(_0x580178['oldVersion'],_0x580178['newVersion'],_0x580178)),_0x5b41fe['then'](_0x2f646b=>{_0x11bf84&&_0x2f646b['addEventListener']('close',()=>_0x11bf84()),_0x39b17c&&_0x2f646b['addEventListener']('versionchange',_0x253364=>_0x39b17c(_0x253364['oldVersion'],_0x253364['newVersion'],_0x253364));})['catch'](()=>{}),_0x5b41fe;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x2f39c4,_0x36fe18){if(!(_0x2f39c4 instanceof IDBDatabase&&!(_0x36fe18 in _0x2f39c4)&&typeof _0x36fe18=='string'))return;if(Zn['get'](_0x36fe18))return Zn['get'](_0x36fe18);const _0x1506c8=_0x36fe18['replace'](/FromIndex$/,''),_0x4cd13b=_0x36fe18!==_0x1506c8,_0x3650a1=$c['includes'](_0x1506c8);if(!(_0x1506c8 in(_0x4cd13b?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3650a1||Hc['includes'](_0x1506c8)))return;const _0x49658d=async function(_0x3e3aae,..._0x2a8e86){const _0x5b23c6=this['transaction'](_0x3e3aae,_0x3650a1?'readwrite':'readonly');let _0x309b06=_0x5b23c6['store'];return _0x4cd13b&&(_0x309b06=_0x309b06['index'](_0x2a8e86['shift']())),(await Promise['all']([_0x309b06[_0x1506c8](..._0x2a8e86),_0x3650a1&&_0x5b23c6['done']]))[0x0];};return Zn['set'](_0x36fe18,_0x49658d),_0x49658d;}Uc(_0x23a97d=>({..._0x23a97d,'get':(_0x433452,_0xc3ea60,_0x763851)=>Os(_0x433452,_0xc3ea60)||_0x23a97d['get'](_0x433452,_0xc3ea60,_0x763851),'has':(_0x57a918,_0x4591f6)=>!!Os(_0x57a918,_0x4591f6)||_0x23a97d['has'](_0x57a918,_0x4591f6)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x4ba4a8){this['container']=_0x4ba4a8;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x31374a=>{if(qc(_0x31374a)){const _0x126661=_0x31374a['getImmediate']();return _0x126661['library']+'/'+_0x126661['version'];}else return null;})['filter'](_0x1da6f1=>_0x1da6f1)['join']('\x20');}}function qc(_0x27d4a2){const _0x4a30dd=_0x27d4a2['getComponent']();return(_0x4a30dd==null?void 0x0:_0x4a30dd['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x2e8868,_0x3052ea){try{_0x2e8868['container']['addComponent'](_0x3052ea);}catch(_0x582628){re['debug']('Component\x20'+_0x3052ea['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2e8868['name'],_0x582628);}}function et(_0x19a938){const _0x1b3898=_0x19a938['name'];if(gi['has'](_0x1b3898))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1b3898+'.'),!0x1;gi['set'](_0x1b3898,_0x19a938);for(const _0x32e874 of Le['values']())Ms(_0x32e874,_0x19a938);for(const _0xdbc7c of _i['values']())Ms(_0xdbc7c,_0x19a938);return!0x0;}function Ui(_0x259aad,_0x48eeab){const _0x2ecd3a=_0x259aad['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x2ecd3a&&_0x2ecd3a['triggerHeartbeat'](),_0x259aad['container']['getProvider'](_0x48eeab);}function H(_0x119980){return _0x119980==null?!0x1:_0x119980['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x4292a8,_0xdaa515,_0x25c4e8){this['_isDeleted']=!0x1,this['_options']={..._0x4292a8},this['_config']={..._0xdaa515},this['_name']=_0xdaa515['name'],this['_automaticDataCollectionEnabled']=_0xdaa515['automaticDataCollectionEnabled'],this['_container']=_0x25c4e8,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x452522){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x452522;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5a68f9){this['_isDeleted']=_0x5a68f9;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x4a71ea,_0x428555={}){let _0x402a49=_0x4a71ea;typeof _0x428555!='object'&&(_0x428555={'name':_0x428555});const _0x56ca49={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x428555},_0x48909f=_0x56ca49['name'];if(typeof _0x48909f!='string'||!_0x48909f)throw ge['create']('bad-app-name',{'appName':String(_0x48909f)});if(_0x402a49||(_0x402a49=$r()),!_0x402a49)throw ge['create']('no-options');const _0x552530=Le['get'](_0x48909f);if(_0x552530){if(De(_0x402a49,_0x552530['options'])&&De(_0x56ca49,_0x552530['config']))return _0x552530;throw ge['create']('duplicate-app',{'appName':_0x48909f});}const _0x3a2442=new Ac(_0x48909f);for(const _0x553b7c of gi['values']())_0x3a2442['addComponent'](_0x553b7c);const _0x494ed3=new Il(_0x402a49,_0x56ca49,_0x3a2442);return Le['set'](_0x48909f,_0x494ed3),_0x494ed3;}function Qr(_0x1cf939=pi){const _0x51a0f1=Le['get'](_0x1cf939);if(!_0x51a0f1&&_0x1cf939===pi&&$r())return wl();if(!_0x51a0f1)throw ge['create']('no-app',{'appName':_0x1cf939});return _0x51a0f1;}function l_(){return Array['from'](Le['values']());}async function h_(_0x10d3e2){let _0x28f715=!0x1;const _0x1454bc=_0x10d3e2['name'];Le['has'](_0x1454bc)?(_0x28f715=!0x0,Le['delete'](_0x1454bc)):_i['has'](_0x1454bc)&&_0x10d3e2['decRefCount']()<=0x0&&(_i['delete'](_0x1454bc),_0x28f715=!0x0),_0x28f715&&(await Promise['all'](_0x10d3e2['container']['getProviders']()['map'](_0x12e060=>_0x12e060['delete']())),_0x10d3e2['isDeleted']=!0x0);}function me(_0x2114ac,_0x34ea95,_0x3a7666){let _0x856c79=vl[_0x2114ac]??_0x2114ac;_0x3a7666&&(_0x856c79+='-'+_0x3a7666);const _0x2e7818=_0x856c79['match'](/\s|\//),_0x2875f4=_0x34ea95['match'](/\s|\//);if(_0x2e7818||_0x2875f4){const _0x32e82d=['Unable\x20to\x20register\x20library\x20\x22'+_0x856c79+'\x22\x20with\x20version\x20\x22'+_0x34ea95+'\x22:'];_0x2e7818&&_0x32e82d['push']('library\x20name\x20\x22'+_0x856c79+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2e7818&&_0x2875f4&&_0x32e82d['push']('and'),_0x2875f4&&_0x32e82d['push']('version\x20name\x20\x22'+_0x34ea95+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x32e82d['join']('\x20'));return;}et(new Me(_0x856c79+'-version',()=>({'library':_0x856c79,'version':_0x34ea95}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x971da1,_0x41aa51)=>{switch(_0x41aa51){case 0x0:try{_0x971da1['createObjectStore'](Rt);}catch(_0x30d3bd){console['warn'](_0x30d3bd);}}}})['catch'](_0x48648c=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x48648c['message']});})),ei;}async function Sl(_0x4a628e){try{const _0x311eea=(await Jr())['transaction'](Rt),_0x57969d=await _0x311eea['objectStore'](Rt)['get'](Xr(_0x4a628e));return await _0x311eea['done'],_0x57969d;}catch(_0x3e72f2){if(_0x3e72f2 instanceof Se)re['warn'](_0x3e72f2['message']);else{const _0x36cb18=ge['create']('idb-get',{'originalErrorMessage':_0x3e72f2==null?void 0x0:_0x3e72f2['message']});re['warn'](_0x36cb18['message']);}}}async function Ls(_0x2981bd,_0x19789c){try{const _0x4727a9=(await Jr())['transaction'](Rt,'readwrite');await _0x4727a9['objectStore'](Rt)['put'](_0x19789c,Xr(_0x2981bd)),await _0x4727a9['done'];}catch(_0x1f85c0){if(_0x1f85c0 instanceof Se)re['warn'](_0x1f85c0['message']);else{const _0x3a6bfd=ge['create']('idb-set',{'originalErrorMessage':_0x1f85c0==null?void 0x0:_0x1f85c0['message']});re['warn'](_0x3a6bfd['message']);}}}function Xr(_0x2c88ad){return _0x2c88ad['name']+'!'+_0x2c88ad['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x2616c0){this['container']=_0x2616c0,this['_heartbeatsCache']=null;const _0x1015f3=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x1015f3),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1376dd=>(this['_heartbeatsCache']=_0x1376dd,_0x1376dd));}async['triggerHeartbeat'](){var _0x52397b,_0x3adb5d;try{const _0xdec03d=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3247a8=xs();if(((_0x52397b=this['_heartbeatsCache'])==null?void 0x0:_0x52397b['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3adb5d=this['_heartbeatsCache'])==null?void 0x0:_0x3adb5d['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3247a8||this['_heartbeatsCache']['heartbeats']['some'](_0x2e5f8a=>_0x2e5f8a['date']===_0x3247a8))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3247a8,'agent':_0xdec03d}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x259385=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x259385,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x679a43){re['warn'](_0x679a43);}}async['getHeartbeatsHeader'](){var _0x17ada7;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x17ada7=this['_heartbeatsCache'])==null?void 0x0:_0x17ada7['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1e32a8=xs(),{heartbeatsToSend:_0x3e1f45,unsentEntries:_0x4f90b7}=kl(this['_heartbeatsCache']['heartbeats']),_0x37e37a=an(JSON['stringify']({'version':0x2,'heartbeats':_0x3e1f45}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1e32a8,_0x4f90b7['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4f90b7,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x37e37a;}catch(_0x3ac21d){return re['warn'](_0x3ac21d),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x5d6abf,_0x18b43e=bl){const _0x4331a9=[];let _0x122556=_0x5d6abf['slice']();for(const _0x157221 of _0x5d6abf){const _0x46b0cb=_0x4331a9['find'](_0x113178=>_0x113178['agent']===_0x157221['agent']);if(_0x46b0cb){if(_0x46b0cb['dates']['push'](_0x157221['date']),Fs(_0x4331a9)>_0x18b43e){_0x46b0cb['dates']['pop']();break;}}else{if(_0x4331a9['push']({'agent':_0x157221['agent'],'dates':[_0x157221['date']]}),Fs(_0x4331a9)>_0x18b43e){_0x4331a9['pop']();break;}}_0x122556=_0x122556['slice'](0x1);}return{'heartbeatsToSend':_0x4331a9,'unsentEntries':_0x122556};}class Nl{constructor(_0x46d9ee){this['app']=_0x46d9ee,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x1c8c0b=await Sl(this['app']);return _0x1c8c0b!=null&&_0x1c8c0b['heartbeats']?_0x1c8c0b:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x168a81){if(await this['_canUseIndexedDBPromise']){const _0x30c459=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x168a81['lastSentHeartbeatDate']??_0x30c459['lastSentHeartbeatDate'],'heartbeats':_0x168a81['heartbeats']});}else return;}async['add'](_0x1bdb7c){if(await this['_canUseIndexedDBPromise']){const _0x3865c5=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x1bdb7c['lastSentHeartbeatDate']??_0x3865c5['lastSentHeartbeatDate'],'heartbeats':[..._0x3865c5['heartbeats'],..._0x1bdb7c['heartbeats']]});}else return;}}function Fs(_0x5cd7ea){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x5cd7ea}))['length'];}function Pl(_0x57a7c4){if(_0x57a7c4['length']===0x0)return-0x1;let _0x17eda7=0x0,_0x3b188d=_0x57a7c4[0x0]['date'];for(let _0x495225=0x1;_0x495225<_0x57a7c4['length'];_0x495225++)_0x57a7c4[_0x495225]['date']<_0x3b188d&&(_0x3b188d=_0x57a7c4[_0x495225]['date'],_0x17eda7=_0x495225);return _0x17eda7;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x705383){et(new Me('platform-logger',_0x42c7a4=>new Gc(_0x42c7a4),'PRIVATE')),et(new Me('heartbeat',_0x4c9caf=>new Al(_0x4c9caf),'PRIVATE')),me(fi,Ds,_0x705383),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x62440e){Zr=_0x62440e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x44deb4){this['domStorage_']=_0x44deb4,this['prefix_']='firebase:';}['set'](_0x2a8111,_0x4a6d9d){_0x4a6d9d==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x2a8111)):this['domStorage_']['setItem'](this['prefixedName_'](_0x2a8111),O(_0x4a6d9d));}['get'](_0x9de7e7){const _0x2c4bde=this['domStorage_']['getItem'](this['prefixedName_'](_0x9de7e7));return _0x2c4bde==null?null:bt(_0x2c4bde);}['remove'](_0xe0a87b){this['domStorage_']['removeItem'](this['prefixedName_'](_0xe0a87b));}['prefixedName_'](_0x5abf37){return this['prefix_']+_0x5abf37;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x21696c,_0x1dbe21){_0x1dbe21==null?delete this['cache_'][_0x21696c]:this['cache_'][_0x21696c]=_0x1dbe21;}['get'](_0x40841e){return Y(this['cache_'],_0x40841e)?this['cache_'][_0x40841e]:null;}['remove'](_0x3ec542){delete this['cache_'][_0x3ec542];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x4a57c5){try{if(typeof window<'u'&&typeof window[_0x4a57c5]<'u'){const _0xdf1df2=window[_0x4a57c5];return _0xdf1df2['setItem']('firebase:sentinel','cache'),_0xdf1df2['removeItem']('firebase:sentinel'),new xl(_0xdf1df2);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x18dd5f=0x1;return function(){return _0x18dd5f++;};}()),no=function(_0xf38627){const _0x182bcb=Tc(_0xf38627),_0x224cd2=new Ec();_0x224cd2['update'](_0x182bcb);const _0x470198=_0x224cd2['digest']();return Di['encodeByteArray'](_0x470198);},Bt=function(..._0x2c8cdd){let _0x16e71f='';for(let _0x4fbd09=0x0;_0x4fbd09<_0x2c8cdd['length'];_0x4fbd09++){const _0x203004=_0x2c8cdd[_0x4fbd09];Array['isArray'](_0x203004)||_0x203004&&typeof _0x203004=='object'&&typeof _0x203004['length']=='number'?_0x16e71f+=Bt['apply'](null,_0x203004):typeof _0x203004=='object'?_0x16e71f+=O(_0x203004):_0x16e71f+=_0x203004,_0x16e71f+='\x20';}return _0x16e71f;};let Et=null,Vs=!0x0;const Wl=function(_0x2a53af,_0x50da21){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x1c47a6){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x4b0910=Bt['apply'](null,_0x1c47a6);Et(_0x4b0910);}},Vt=function(_0x45ae4e){return function(..._0x4f076a){L(_0x45ae4e,..._0x4f076a);};},mi=function(..._0x201a34){const _0x8c4238='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x201a34);Qe['error'](_0x8c4238);},oe=function(..._0x3f54c4){const _0xa7d567='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x3f54c4);throw Qe['error'](_0xa7d567),new Error(_0xa7d567);},U=function(..._0x3d67cc){const _0x5fa326='FIREBASE\x20WARNING:\x20'+Bt(..._0x3d67cc);Qe['warn'](_0x5fa326);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x4b2a8d){return typeof _0x4b2a8d=='number'&&(_0x4b2a8d!==_0x4b2a8d||_0x4b2a8d===Number['POSITIVE_INFINITY']||_0x4b2a8d===Number['NEGATIVE_INFINITY']);},Vl=function(_0x3ab5c2){if(document['readyState']==='complete')_0x3ab5c2();else{let _0x5f4fb4=!0x1;const _0x3e06b4=function(){if(!document['body']){setTimeout(_0x3e06b4,Math['floor'](0xa));return;}_0x5f4fb4||(_0x5f4fb4=!0x0,_0x3ab5c2());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3e06b4,!0x1),window['addEventListener']('load',_0x3e06b4,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3e06b4();}),window['attachEvent']('onload',_0x3e06b4));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x38d03c,_0x3f32a5){if(_0x38d03c===_0x3f32a5)return 0x0;if(_0x38d03c===xe||_0x3f32a5===Ie)return-0x1;if(_0x3f32a5===xe||_0x38d03c===Ie)return 0x1;{const _0x5170fc=Hs(_0x38d03c),_0x4c8159=Hs(_0x3f32a5);return _0x5170fc!==null?_0x4c8159!==null?_0x5170fc-_0x4c8159===0x0?_0x38d03c['length']-_0x3f32a5['length']:_0x5170fc-_0x4c8159:-0x1:_0x4c8159!==null?0x1:_0x38d03c<_0x3f32a5?-0x1:0x1;}},Hl=function(_0x4d5759,_0x5aef72){return _0x4d5759===_0x5aef72?0x0:_0x4d5759<_0x5aef72?-0x1:0x1;},pt=function(_0x596a30,_0x22d058){if(_0x22d058&&_0x596a30 in _0x22d058)return _0x22d058[_0x596a30];throw new Error('Missing\x20required\x20key\x20('+_0x596a30+')\x20in\x20object:\x20'+O(_0x22d058));},Bi=function(_0x31abee){if(typeof _0x31abee!='object'||_0x31abee===null)return O(_0x31abee);const _0xfb2e73=[];for(const _0xb0bf27 in _0x31abee)_0xfb2e73['push'](_0xb0bf27);_0xfb2e73['sort']();let _0x50e24e='{';for(let _0xe79b26=0x0;_0xe79b26<_0xfb2e73['length'];_0xe79b26++)_0xe79b26!==0x0&&(_0x50e24e+=','),_0x50e24e+=O(_0xfb2e73[_0xe79b26]),_0x50e24e+=':',_0x50e24e+=Bi(_0x31abee[_0xfb2e73[_0xe79b26]]);return _0x50e24e+='}',_0x50e24e;},io=function(_0x1722d2,_0x582079){const _0x201a83=_0x1722d2['length'];if(_0x201a83<=_0x582079)return[_0x1722d2];const _0x253a41=[];for(let _0x58d023=0x0;_0x58d023<_0x201a83;_0x58d023+=_0x582079)_0x58d023+_0x582079>_0x201a83?_0x253a41['push'](_0x1722d2['substring'](_0x58d023,_0x201a83)):_0x253a41['push'](_0x1722d2['substring'](_0x58d023,_0x58d023+_0x582079));return _0x253a41;};function x(_0x4290a6,_0xbefadd){for(const _0x59da21 in _0x4290a6)_0x4290a6['hasOwnProperty'](_0x59da21)&&_0xbefadd(_0x59da21,_0x4290a6[_0x59da21]);}const so=function(_0x47e458){f(!Wi(_0x47e458),'Invalid\x20JSON\x20number');const _0x44ceb8=0xb,_0x38261b=0x34,_0x4d2c50=(0x1<<_0x44ceb8-0x1)-0x1;let _0x3342bb,_0x51d353,_0x19208d,_0x1b1f53,_0x4c80bd;_0x47e458===0x0?(_0x51d353=0x0,_0x19208d=0x0,_0x3342bb=0x1/_0x47e458===-0x1/0x0?0x1:0x0):(_0x3342bb=_0x47e458<0x0,_0x47e458=Math['abs'](_0x47e458),_0x47e458>=Math['pow'](0x2,0x1-_0x4d2c50)?(_0x1b1f53=Math['min'](Math['floor'](Math['log'](_0x47e458)/Math['LN2']),_0x4d2c50),_0x51d353=_0x1b1f53+_0x4d2c50,_0x19208d=Math['round'](_0x47e458*Math['pow'](0x2,_0x38261b-_0x1b1f53)-Math['pow'](0x2,_0x38261b))):(_0x51d353=0x0,_0x19208d=Math['round'](_0x47e458/Math['pow'](0x2,0x1-_0x4d2c50-_0x38261b))));const _0x14ba01=[];for(_0x4c80bd=_0x38261b;_0x4c80bd;_0x4c80bd-=0x1)_0x14ba01['push'](_0x19208d%0x2?0x1:0x0),_0x19208d=Math['floor'](_0x19208d/0x2);for(_0x4c80bd=_0x44ceb8;_0x4c80bd;_0x4c80bd-=0x1)_0x14ba01['push'](_0x51d353%0x2?0x1:0x0),_0x51d353=Math['floor'](_0x51d353/0x2);_0x14ba01['push'](_0x3342bb?0x1:0x0),_0x14ba01['reverse']();const _0x123d43=_0x14ba01['join']('');let _0x38312f='';for(_0x4c80bd=0x0;_0x4c80bd<0x40;_0x4c80bd+=0x8){let _0x516044=parseInt(_0x123d43['substr'](_0x4c80bd,0x8),0x2)['toString'](0x10);_0x516044['length']===0x1&&(_0x516044='0'+_0x516044),_0x38312f=_0x38312f+_0x516044;}return _0x38312f['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0xeb0b01,_0x391b81){let _0x48dd05='Unknown\x20Error';_0xeb0b01==='too_big'?_0x48dd05='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0xeb0b01==='permission_denied'?_0x48dd05='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0xeb0b01==='unavailable'&&(_0x48dd05='The\x20service\x20is\x20unavailable');const _0x3d9422=new Error(_0xeb0b01+'\x20at\x20'+_0x391b81['_path']['toString']()+':\x20'+_0x48dd05);return _0x3d9422['code']=_0xeb0b01['toUpperCase'](),_0x3d9422;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x1d98f1){if(zl['test'](_0x1d98f1)){const _0x18fdcb=Number(_0x1d98f1);if(_0x18fdcb>=jl&&_0x18fdcb<=Kl)return _0x18fdcb;}return null;},lt=function(_0x281ea4){try{_0x281ea4();}catch(_0x321812){setTimeout(()=>{const _0x16c544=_0x321812['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x16c544),_0x321812;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x6a8b20,_0x4ecd56){const _0x2a9028=setTimeout(_0x6a8b20,_0x4ecd56);return typeof _0x2a9028=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2a9028):typeof _0x2a9028=='object'&&_0x2a9028['unref']&&_0x2a9028['unref'](),_0x2a9028;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x4e5379,_0x225e09){this['appCheckProvider']=_0x225e09,this['appName']=_0x4e5379['name'],H(_0x4e5379)&&_0x4e5379['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x4e5379['settings']['appCheckToken']),this['appCheck']=_0x225e09==null?void 0x0:_0x225e09['getImmediate']({'optional':!0x0}),this['appCheck']||_0x225e09==null||_0x225e09['get']()['then'](_0x4d895a=>this['appCheck']=_0x4d895a);}['getToken'](_0x88e428){if(this['serverAppAppCheckToken']){if(_0x88e428)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x88e428):new Promise((_0x41cb63,_0x311cae)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x88e428)['then'](_0x41cb63,_0x311cae):_0x41cb63(null);},0x0);});}['addTokenChangeListener'](_0x1801d5){var _0x2d12ff;(_0x2d12ff=this['appCheckProvider'])==null||_0x2d12ff['get']()['then'](_0x415d3d=>_0x415d3d['addTokenListener'](_0x1801d5));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x110aa0,_0x545cfb,_0x464d8d){this['appName_']=_0x110aa0,this['firebaseOptions_']=_0x545cfb,this['authProvider_']=_0x464d8d,this['auth_']=null,this['auth_']=_0x464d8d['getImmediate']({'optional':!0x0}),this['auth_']||_0x464d8d['onInit'](_0x34e726=>this['auth_']=_0x34e726);}['getToken'](_0x28f8c6){return this['auth_']?this['auth_']['getToken'](_0x28f8c6)['catch'](_0x57407e=>_0x57407e&&_0x57407e['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x57407e)):new Promise((_0x2d5c7b,_0x3264f6)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x28f8c6)['then'](_0x2d5c7b,_0x3264f6):_0x2d5c7b(null);},0x0);});}['addTokenChangeListener'](_0x108023){this['auth_']?this['auth_']['addAuthTokenListener'](_0x108023):this['authProvider_']['get']()['then'](_0x4c4986=>_0x4c4986['addAuthTokenListener'](_0x108023));}['removeTokenChangeListener'](_0x38bb96){this['authProvider_']['get']()['then'](_0x3ce66e=>_0x3ce66e['removeAuthTokenListener'](_0x38bb96));}['notifyForInvalidToken'](){let _0x5a4d80='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x5a4d80+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x5a4d80+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x5a4d80+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x5a4d80);}}class tn{constructor(_0x3c8924){this['accessToken']=_0x3c8924;}['getToken'](_0x105808){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2e33b5){_0x2e33b5(this['accessToken']);}['removeTokenChangeListener'](_0x5aa3fc){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x374370,_0x1e2790,_0x1a3c51,_0x567d5b,_0x4dcf84=!0x1,_0x734610='',_0x19c1d6=!0x1,_0x51ada5=!0x1,_0x1fbada=null){this['secure']=_0x1e2790,this['namespace']=_0x1a3c51,this['webSocketOnly']=_0x567d5b,this['nodeAdmin']=_0x4dcf84,this['persistenceKey']=_0x734610,this['includeNamespaceInQueryParams']=_0x19c1d6,this['isUsingEmulator']=_0x51ada5,this['emulatorOptions']=_0x1fbada,this['_host']=_0x374370['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x374370)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x56a695){_0x56a695!==this['internalHost']&&(this['internalHost']=_0x56a695,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3ea679=this['toURLString']();return this['persistenceKey']&&(_0x3ea679+='<'+this['persistenceKey']+'>'),_0x3ea679;}['toURLString'](){const _0x2285a0=this['secure']?'https://':'http://',_0xa7a481=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2285a0+this['host']+'/'+_0xa7a481;}}function Xl(_0x256e04){return _0x256e04['host']!==_0x256e04['internalHost']||_0x256e04['isCustomHost']()||_0x256e04['includeNamespaceInQueryParams'];}function go(_0xfbaa24,_0x4eb153,_0x331301){f(typeof _0x4eb153=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x331301=='object','typeof\x20params\x20must\x20==\x20object');let _0x332a1d;if(_0x4eb153===fo)_0x332a1d=(_0xfbaa24['secure']?'wss://':'ws://')+_0xfbaa24['internalHost']+'/.ws?';else{if(_0x4eb153===po)_0x332a1d=(_0xfbaa24['secure']?'https://':'http://')+_0xfbaa24['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x4eb153);}Xl(_0xfbaa24)&&(_0x331301['ns']=_0xfbaa24['namespace']);const _0x56be23=[];return x(_0x331301,(_0x280bfc,_0x474762)=>{_0x56be23['push'](_0x280bfc+'='+_0x474762);}),_0x332a1d+_0x56be23['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0xb55e59,_0x4da375=0x1){Y(this['counters_'],_0xb55e59)||(this['counters_'][_0xb55e59]=0x0),this['counters_'][_0xb55e59]+=_0x4da375;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x5c7b8f){const _0x3a2395=_0x5c7b8f['toString']();return ti[_0x3a2395]||(ti[_0x3a2395]=new Zl()),ti[_0x3a2395];}function eh(_0x2617be,_0x58d2fb){const _0x2d3ced=_0x2617be['toString']();return ni[_0x2d3ced]||(ni[_0x2d3ced]=_0x58d2fb()),ni[_0x2d3ced];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x47e870){this['onMessage_']=_0x47e870,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x299e45,_0x128673){this['closeAfterResponse']=_0x299e45,this['onClose']=_0x128673,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x5b7e25,_0x37422f){for(this['pendingResponses'][_0x5b7e25]=_0x37422f;this['pendingResponses'][this['currentResponseNum']];){const _0x1b06a0=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x324518=0x0;_0x324518<_0x1b06a0['length'];++_0x324518)_0x1b06a0[_0x324518]&&lt(()=>{this['onMessage_'](_0x1b06a0[_0x324518]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x163cfe,_0x1cfbc8,_0x1217d8,_0x43a6b9,_0x13a078,_0x42e7d1,_0x57364f){this['connId']=_0x163cfe,this['repoInfo']=_0x1cfbc8,this['applicationId']=_0x1217d8,this['appCheckToken']=_0x43a6b9,this['authToken']=_0x13a078,this['transportSessionId']=_0x42e7d1,this['lastSessionId']=_0x57364f,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x163cfe),this['stats_']=Hi(_0x1cfbc8),this['urlFn']=_0xd40087=>(this['appCheckToken']&&(_0xd40087[yi]=this['appCheckToken']),go(_0x1cfbc8,po,_0xd40087));}['open'](_0x247812,_0x36e061){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x36e061,this['myPacketOrderer']=new th(_0x247812),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x40aa62)=>{const [_0x27aa98,_0x58cf0a,_0xb128c4,_0x43faad,_0x457fd3]=_0x40aa62;if(this['incrementIncomingBytes_'](_0x40aa62),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x27aa98===$s)this['id']=_0x58cf0a,this['password']=_0xb128c4;else{if(_0x27aa98===nh)_0x58cf0a?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x58cf0a,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x27aa98);}}},(..._0x1a57b2)=>{const [_0x1c30b5,_0x50e038]=_0x1a57b2;this['incrementIncomingBytes_'](_0x1a57b2),this['myPacketOrderer']['handleResponse'](_0x1c30b5,_0x50e038);},()=>{this['onClosed_']();},this['urlFn']);const _0x1a1cb1={};_0x1a1cb1[$s]='t',_0x1a1cb1[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1a1cb1[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1a1cb1[ro]=Vi,this['transportSessionId']&&(_0x1a1cb1[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x1a1cb1[ho]=this['lastSessionId']),this['applicationId']&&(_0x1a1cb1[uo]=this['applicationId']),this['appCheckToken']&&(_0x1a1cb1[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1a1cb1[ao]=co);const _0x4f7f13=this['urlFn'](_0x1a1cb1);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4f7f13),this['scriptTagHolder']['addTag'](_0x4f7f13,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x3a8d49){const _0x47a318=O(_0x3a8d49);this['bytesSent']+=_0x47a318['length'],this['stats_']['incrementCounter']('bytes_sent',_0x47a318['length']);const _0x2ed341=Br(_0x47a318),_0x1b99b4=io(_0x2ed341,hh);for(let _0x33af8f=0x0;_0x33af8f<_0x1b99b4['length'];_0x33af8f++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1b99b4['length'],_0x1b99b4[_0x33af8f]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4b2487,_0x583bae){this['myDisconnFrame']=document['createElement']('iframe');const _0x595946={};_0x595946[lh]='t',_0x595946[mo]=_0x4b2487,_0x595946[yo]=_0x583bae,this['myDisconnFrame']['src']=this['urlFn'](_0x595946),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x4625af){const _0x180661=O(_0x4625af)['length'];this['bytesReceived']+=_0x180661,this['stats_']['incrementCounter']('bytes_received',_0x180661);}}class $i{constructor(_0x2e663f,_0x1179ff,_0x40b734,_0x448d69){this['onDisconnect']=_0x40b734,this['urlFn']=_0x448d69,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x2e663f,window[sh+this['uniqueCallbackIdentifier']]=_0x1179ff,this['myIFrame']=$i['createIFrame_']();let _0x16c8fc='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x16c8fc='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x29f626='<html><body>'+_0x16c8fc+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x29f626),this['myIFrame']['doc']['close']();}catch(_0x3ff538){L('frame\x20writing\x20exception'),_0x3ff538['stack']&&L(_0x3ff538['stack']),L(_0x3ff538);}}}static['createIFrame_'](){const _0x49614b=document['createElement']('iframe');if(_0x49614b['style']['display']='none',document['body']){document['body']['appendChild'](_0x49614b);try{_0x49614b['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x303e27=document['domain'];_0x49614b['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x303e27+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x49614b['contentDocument']?_0x49614b['doc']=_0x49614b['contentDocument']:_0x49614b['contentWindow']?_0x49614b['doc']=_0x49614b['contentWindow']['document']:_0x49614b['document']&&(_0x49614b['doc']=_0x49614b['document']),_0x49614b;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x24c780=this['onDisconnect'];_0x24c780&&(this['onDisconnect']=null,_0x24c780());}['startLongPoll'](_0x5c29c0,_0x131205){for(this['myID']=_0x5c29c0,this['myPW']=_0x131205,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2ef309={};_0x2ef309[mo]=this['myID'],_0x2ef309[yo]=this['myPW'],_0x2ef309[vo]=this['currentSerial'];let _0x53e985=this['urlFn'](_0x2ef309),_0x206208='',_0xeb2aa2=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x206208['length']<=Eo;){const _0x2ab924=this['pendingSegs']['shift']();_0x206208=_0x206208+'&'+oh+_0xeb2aa2+'='+_0x2ab924['seg']+'&'+ah+_0xeb2aa2+'='+_0x2ab924['ts']+'&'+ch+_0xeb2aa2+'='+_0x2ab924['d'],_0xeb2aa2++;}return _0x53e985=_0x53e985+_0x206208,this['addLongPollTag_'](_0x53e985,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x15686b,_0x2812b7,_0x34b52b){this['pendingSegs']['push']({'seg':_0x15686b,'ts':_0x2812b7,'d':_0x34b52b}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x39f75a,_0x309532){this['outstandingRequests']['add'](_0x309532);const _0x20e9a3=()=>{this['outstandingRequests']['delete'](_0x309532),this['newRequest_']();},_0x2b39ef=setTimeout(_0x20e9a3,Math['floor'](uh)),_0x4e7cc1=()=>{clearTimeout(_0x2b39ef),_0x20e9a3();};this['addTag'](_0x39f75a,_0x4e7cc1);}['addTag'](_0x350a00,_0x5e1e29){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5cdd1e=this['myIFrame']['doc']['createElement']('script');_0x5cdd1e['type']='text/javascript',_0x5cdd1e['async']=!0x0,_0x5cdd1e['src']=_0x350a00,_0x5cdd1e['onload']=_0x5cdd1e['onreadystatechange']=function(){const _0xfb1ffd=_0x5cdd1e['readyState'];(!_0xfb1ffd||_0xfb1ffd==='loaded'||_0xfb1ffd==='complete')&&(_0x5cdd1e['onload']=_0x5cdd1e['onreadystatechange']=null,_0x5cdd1e['parentNode']&&_0x5cdd1e['parentNode']['removeChild'](_0x5cdd1e),_0x5e1e29());},_0x5cdd1e['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x350a00),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5cdd1e);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x135462,_0x4bf290,_0x53071e,_0x2675db,_0xfad08c,_0x1eecb8,_0x47b256){this['connId']=_0x135462,this['applicationId']=_0x53071e,this['appCheckToken']=_0x2675db,this['authToken']=_0xfad08c,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x4bf290),this['connURL']=G['connectionURL_'](_0x4bf290,_0x1eecb8,_0x47b256,_0x2675db,_0x53071e),this['nodeAdmin']=_0x4bf290['nodeAdmin'];}static['connectionURL_'](_0x50ef26,_0x271146,_0x3bda45,_0x1c9e13,_0x296d6c){const _0x3454d6={};return _0x3454d6[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3454d6[ao]=co),_0x271146&&(_0x3454d6[oo]=_0x271146),_0x3bda45&&(_0x3454d6[ho]=_0x3bda45),_0x1c9e13&&(_0x3454d6[yi]=_0x1c9e13),_0x296d6c&&(_0x3454d6[uo]=_0x296d6c),go(_0x50ef26,fo,_0x3454d6);}['open'](_0x20622a,_0x3e3f84){this['onDisconnect']=_0x3e3f84,this['onMessage']=_0x20622a,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x3d938a;dc(),this['mySock']=new hn(this['connURL'],[],_0x3d938a);}catch(_0x5c7e45){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x20aca1=_0x5c7e45['message']||_0x5c7e45['data'];_0x20aca1&&this['log_'](_0x20aca1),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x8e98a7=>{this['handleIncomingFrame'](_0x8e98a7);},this['mySock']['onerror']=_0x591f00=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x4b7019=_0x591f00['message']||_0x591f00['data'];_0x4b7019&&this['log_'](_0x4b7019),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x426123=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x533384=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2d7ac1=navigator['userAgent']['match'](_0x533384);_0x2d7ac1&&_0x2d7ac1['length']>0x1&&parseFloat(_0x2d7ac1[0x1])<4.4&&(_0x426123=!0x0);}return!_0x426123&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x44894c){if(this['frames']['push'](_0x44894c),this['frames']['length']===this['totalFrames']){const _0x574c4a=this['frames']['join']('');this['frames']=null;const _0x2117a4=bt(_0x574c4a);this['onMessage'](_0x2117a4);}}['handleNewFrameCount_'](_0x54a8dc){this['totalFrames']=_0x54a8dc,this['frames']=[];}['extractFrameCount_'](_0x58afa8){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x58afa8['length']<=0x6){const _0x3a8314=Number(_0x58afa8);if(!isNaN(_0x3a8314))return this['handleNewFrameCount_'](_0x3a8314),null;}return this['handleNewFrameCount_'](0x1),_0x58afa8;}['handleIncomingFrame'](_0x5e73e8){if(this['mySock']===null)return;const _0x122179=_0x5e73e8['data'];if(this['bytesReceived']+=_0x122179['length'],this['stats_']['incrementCounter']('bytes_received',_0x122179['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x122179);else{const _0x1397b0=this['extractFrameCount_'](_0x122179);_0x1397b0!==null&&this['appendFrame_'](_0x1397b0);}}['send'](_0x463237){this['resetKeepAlive']();const _0x59305f=O(_0x463237);this['bytesSent']+=_0x59305f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x59305f['length']);const _0x3abd2f=io(_0x59305f,fh);_0x3abd2f['length']>0x1&&this['sendString_'](String(_0x3abd2f['length']));for(let _0x31216d=0x0;_0x31216d<_0x3abd2f['length'];_0x31216d++)this['sendString_'](_0x3abd2f[_0x31216d]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x4b48ca){try{this['mySock']['send'](_0x4b48ca);}catch(_0x3cd59e){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3cd59e['message']||_0x3cd59e['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x14f49d){this['initTransports_'](_0x14f49d);}['initTransports_'](_0x51dd24){const _0x5f1dc3=G&&G['isAvailable']();let _0x2beb0e=_0x5f1dc3&&!G['previouslyFailed']();if(_0x51dd24['webSocketOnly']&&(_0x5f1dc3||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x2beb0e=!0x0),_0x2beb0e)this['transports_']=[G];else{const _0x357ce9=this['transports_']=[];for(const _0x27dbc7 of At['ALL_TRANSPORTS'])_0x27dbc7&&_0x27dbc7['isAvailable']()&&_0x357ce9['push'](_0x27dbc7);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x583f5e,_0x5cb70e,_0x388d32,_0x3645e4,_0x104e93,_0x36a0f1,_0x39764c,_0x55ea82,_0x41b724,_0x1d13be){this['id']=_0x583f5e,this['repoInfo_']=_0x5cb70e,this['applicationId_']=_0x388d32,this['appCheckToken_']=_0x3645e4,this['authToken_']=_0x104e93,this['onMessage_']=_0x36a0f1,this['onReady_']=_0x39764c,this['onDisconnect_']=_0x55ea82,this['onKill_']=_0x41b724,this['lastSessionId']=_0x1d13be,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x5cb70e),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x21a426=this['transportManager_']['initialTransport']();this['conn_']=new _0x21a426(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x21a426['responsesRequiredToBeHealthy']||0x0;const _0x113c64=this['connReceiver_'](this['conn_']),_0x58f5d3=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x113c64,_0x58f5d3);},Math['floor'](0x0));const _0x5d83d3=_0x21a426['healthyTimeout']||0x0;_0x5d83d3>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5d83d3)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2a66bf){return _0x1276f7=>{_0x2a66bf===this['conn_']?this['onConnectionLost_'](_0x1276f7):_0x2a66bf===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x5174d8){return _0x3d18a9=>{this['state_']!==0x2&&(_0x5174d8===this['rx_']?this['onPrimaryMessageReceived_'](_0x3d18a9):_0x5174d8===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3d18a9):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1cfa41){const _0x1a3b5c={'t':'d','d':_0x1cfa41};this['sendData_'](_0x1a3b5c);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x5aa778){if(ii in _0x5aa778){const _0x5412ea=_0x5aa778[ii];_0x5412ea===js?this['upgradeIfSecondaryHealthy_']():_0x5412ea===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5412ea===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x10d679){const _0x20a06c=pt('t',_0x10d679),_0x54f177=pt('d',_0x10d679);if(_0x20a06c==='c')this['onSecondaryControl_'](_0x54f177);else{if(_0x20a06c==='d')this['pendingDataMessages']['push'](_0x54f177);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x20a06c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x164d87){const _0x1dae6a=pt('t',_0x164d87),_0x11cb00=pt('d',_0x164d87);_0x1dae6a==='c'?this['onControl_'](_0x11cb00):_0x1dae6a==='d'&&this['onDataMessage_'](_0x11cb00);}['onDataMessage_'](_0x315aa5){this['onPrimaryResponse_'](),this['onMessage_'](_0x315aa5);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3236e2){const _0x582c37=pt(ii,_0x3236e2);if(Gs in _0x3236e2){const _0x188a08=_0x3236e2[Gs];if(_0x582c37===Ih){const _0x57cd2a={..._0x188a08};this['repoInfo_']['isUsingEmulator']&&(_0x57cd2a['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x57cd2a);}else{if(_0x582c37===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0xfe9148=0x0;_0xfe9148<this['pendingDataMessages']['length'];++_0xfe9148)this['onDataMessage_'](this['pendingDataMessages'][_0xfe9148]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x582c37===vh?this['onConnectionShutdown_'](_0x188a08):_0x582c37===qs?this['onReset_'](_0x188a08):_0x582c37===Eh?mi('Server\x20Error:\x20'+_0x188a08):_0x582c37===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x582c37);}}}['onHandshake_'](_0x4caea4){const _0x1a77a1=_0x4caea4['ts'],_0x4d6207=_0x4caea4['v'],_0x2d8eaf=_0x4caea4['h'];this['sessionId']=_0x4caea4['s'],this['repoInfo_']['host']=_0x2d8eaf,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x1a77a1),Vi!==_0x4d6207&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x466450=this['transportManager_']['upgradeTransport']();_0x466450&&this['startUpgrade_'](_0x466450);}['startUpgrade_'](_0x2f85e5){this['secondaryConn_']=new _0x2f85e5(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x2f85e5['responsesRequiredToBeHealthy']||0x0;const _0x501045=this['connReceiver_'](this['secondaryConn_']),_0x3788de=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x501045,_0x3788de),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x46e52b){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x46e52b),this['repoInfo_']['host']=_0x46e52b,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x32a843,_0x31afa3){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x32a843,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x31afa3,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x330b96=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x330b96||this['rx_']===_0x330b96)&&this['close']();}['onConnectionLost_'](_0xdc8d74){this['conn_']=null,!_0xdc8d74&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4c9376){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4c9376),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4075b7){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4075b7);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x355754,_0x2fe55a,_0x1c2ac1,_0x5e2160){}['merge'](_0x59b184,_0x1e7ffc,_0x321b2b,_0x4f3f11){}['refreshAuthToken'](_0x4d578a){}['refreshAppCheckToken'](_0x1b2803){}['onDisconnectPut'](_0x4bad17,_0x9f03fe,_0x1b36c8){}['onDisconnectMerge'](_0x195d0b,_0x440450,_0x358bf0){}['onDisconnectCancel'](_0x45c3d0,_0x9146e0){}['reportStats'](_0x267f19){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x25d774){this['allowedEvents_']=_0x25d774,this['listeners_']={},f(Array['isArray'](_0x25d774)&&_0x25d774['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x27257f,..._0x172595){if(Array['isArray'](this['listeners_'][_0x27257f])){const _0xd97639=[...this['listeners_'][_0x27257f]];for(let _0x22f3bd=0x0;_0x22f3bd<_0xd97639['length'];_0x22f3bd++)_0xd97639[_0x22f3bd]['callback']['apply'](_0xd97639[_0x22f3bd]['context'],_0x172595);}}['on'](_0x43a466,_0x24e042,_0x349486){this['validateEventType_'](_0x43a466),this['listeners_'][_0x43a466]=this['listeners_'][_0x43a466]||[],this['listeners_'][_0x43a466]['push']({'callback':_0x24e042,'context':_0x349486});const _0x164d90=this['getInitialEvent'](_0x43a466);_0x164d90&&_0x24e042['apply'](_0x349486,_0x164d90);}['off'](_0xffd6c2,_0x30cf1b,_0xf8a2e3){this['validateEventType_'](_0xffd6c2);const _0xa7a969=this['listeners_'][_0xffd6c2]||[];for(let _0x3ed01d=0x0;_0x3ed01d<_0xa7a969['length'];_0x3ed01d++)if(_0xa7a969[_0x3ed01d]['callback']===_0x30cf1b&&(!_0xf8a2e3||_0xf8a2e3===_0xa7a969[_0x3ed01d]['context'])){_0xa7a969['splice'](_0x3ed01d,0x1);return;}}['validateEventType_'](_0x2e2e42){f(this['allowedEvents_']['find'](_0x30dfe6=>_0x30dfe6===_0x2e2e42),'Unknown\x20event:\x20'+_0x2e2e42);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1fbc8b){return f(_0x1fbc8b==='online','Unknown\x20event\x20type:\x20'+_0x1fbc8b),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x4c9760,_0x4bb6c4){if(_0x4bb6c4===void 0x0){this['pieces_']=_0x4c9760['split']('/');let _0x14a5ee=0x0;for(let _0x642a3e=0x0;_0x642a3e<this['pieces_']['length'];_0x642a3e++)this['pieces_'][_0x642a3e]['length']>0x0&&(this['pieces_'][_0x14a5ee]=this['pieces_'][_0x642a3e],_0x14a5ee++);this['pieces_']['length']=_0x14a5ee,this['pieceNum_']=0x0;}else this['pieces_']=_0x4c9760,this['pieceNum_']=_0x4bb6c4;}['toString'](){let _0x1cdbe7='';for(let _0x336667=this['pieceNum_'];_0x336667<this['pieces_']['length'];_0x336667++)this['pieces_'][_0x336667]!==''&&(_0x1cdbe7+='/'+this['pieces_'][_0x336667]);return _0x1cdbe7||'/';}}function w(){return new C('');}function y(_0x1203b2){return _0x1203b2['pieceNum_']>=_0x1203b2['pieces_']['length']?null:_0x1203b2['pieces_'][_0x1203b2['pieceNum_']];}function we(_0x22df1a){return _0x22df1a['pieces_']['length']-_0x22df1a['pieceNum_'];}function b(_0x384894){let _0x5ceac2=_0x384894['pieceNum_'];return _0x5ceac2<_0x384894['pieces_']['length']&&_0x5ceac2++,new C(_0x384894['pieces_'],_0x5ceac2);}function Gi(_0xb9241c){return _0xb9241c['pieceNum_']<_0xb9241c['pieces_']['length']?_0xb9241c['pieces_'][_0xb9241c['pieces_']['length']-0x1]:null;}function Ch(_0x6052af){let _0x4c73d6='';for(let _0x4cf6cc=_0x6052af['pieceNum_'];_0x4cf6cc<_0x6052af['pieces_']['length'];_0x4cf6cc++)_0x6052af['pieces_'][_0x4cf6cc]!==''&&(_0x4c73d6+='/'+encodeURIComponent(String(_0x6052af['pieces_'][_0x4cf6cc])));return _0x4c73d6||'/';}function kt(_0x3deadf,_0x1a6708=0x0){return _0x3deadf['pieces_']['slice'](_0x3deadf['pieceNum_']+_0x1a6708);}function To(_0x120edb){if(_0x120edb['pieceNum_']>=_0x120edb['pieces_']['length'])return null;const _0x292ea5=[];for(let _0x193787=_0x120edb['pieceNum_'];_0x193787<_0x120edb['pieces_']['length']-0x1;_0x193787++)_0x292ea5['push'](_0x120edb['pieces_'][_0x193787]);return new C(_0x292ea5,0x0);}function A(_0x1e11d8,_0x152ddd){const _0x35b692=[];for(let _0x191d3c=_0x1e11d8['pieceNum_'];_0x191d3c<_0x1e11d8['pieces_']['length'];_0x191d3c++)_0x35b692['push'](_0x1e11d8['pieces_'][_0x191d3c]);if(_0x152ddd instanceof C){for(let _0x4a7900=_0x152ddd['pieceNum_'];_0x4a7900<_0x152ddd['pieces_']['length'];_0x4a7900++)_0x35b692['push'](_0x152ddd['pieces_'][_0x4a7900]);}else{const _0x569b38=_0x152ddd['split']('/');for(let _0x1e93a1=0x0;_0x1e93a1<_0x569b38['length'];_0x1e93a1++)_0x569b38[_0x1e93a1]['length']>0x0&&_0x35b692['push'](_0x569b38[_0x1e93a1]);}return new C(_0x35b692,0x0);}function v(_0x494cf8){return _0x494cf8['pieceNum_']>=_0x494cf8['pieces_']['length'];}function F(_0x2a7c59,_0x176c47){const _0x3a9f40=y(_0x2a7c59),_0x17b90c=y(_0x176c47);if(_0x3a9f40===null)return _0x176c47;if(_0x3a9f40===_0x17b90c)return F(b(_0x2a7c59),b(_0x176c47));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x176c47+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2a7c59+')');}function Th(_0x3aaf29,_0x548eaa){const _0x217582=kt(_0x3aaf29,0x0),_0x5f354d=kt(_0x548eaa,0x0);for(let _0x1d0c21=0x0;_0x1d0c21<_0x217582['length']&&_0x1d0c21<_0x5f354d['length'];_0x1d0c21++){const _0x4d0cf6=He(_0x217582[_0x1d0c21],_0x5f354d[_0x1d0c21]);if(_0x4d0cf6!==0x0)return _0x4d0cf6;}return _0x217582['length']===_0x5f354d['length']?0x0:_0x217582['length']<_0x5f354d['length']?-0x1:0x1;}function qi(_0x871ea3,_0x257efe){if(we(_0x871ea3)!==we(_0x257efe))return!0x1;for(let _0x312c40=_0x871ea3['pieceNum_'],_0x3abf4d=_0x257efe['pieceNum_'];_0x312c40<=_0x871ea3['pieces_']['length'];_0x312c40++,_0x3abf4d++)if(_0x871ea3['pieces_'][_0x312c40]!==_0x257efe['pieces_'][_0x3abf4d])return!0x1;return!0x0;}function $(_0x5cd69a,_0x6b4ca9){let _0x4e6fa0=_0x5cd69a['pieceNum_'],_0x2a4ab9=_0x6b4ca9['pieceNum_'];if(we(_0x5cd69a)>we(_0x6b4ca9))return!0x1;for(;_0x4e6fa0<_0x5cd69a['pieces_']['length'];){if(_0x5cd69a['pieces_'][_0x4e6fa0]!==_0x6b4ca9['pieces_'][_0x2a4ab9])return!0x1;++_0x4e6fa0,++_0x2a4ab9;}return!0x0;}class Sh{constructor(_0x522dc1,_0x2d73e1){this['errorPrefix_']=_0x2d73e1,this['parts_']=kt(_0x522dc1,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x28db4f=0x0;_0x28db4f<this['parts_']['length'];_0x28db4f++)this['byteLength_']+=Pn(this['parts_'][_0x28db4f]);So(this);}}function bh(_0x37b84a,_0x3c813b){_0x37b84a['parts_']['length']>0x0&&(_0x37b84a['byteLength_']+=0x1),_0x37b84a['parts_']['push'](_0x3c813b),_0x37b84a['byteLength_']+=Pn(_0x3c813b),So(_0x37b84a);}function Rh(_0x1eeae6){const _0x540b9c=_0x1eeae6['parts_']['pop']();_0x1eeae6['byteLength_']-=Pn(_0x540b9c),_0x1eeae6['parts_']['length']>0x0&&(_0x1eeae6['byteLength_']-=0x1);}function So(_0x24b796){if(_0x24b796['byteLength_']>Js)throw new Error(_0x24b796['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x24b796['byteLength_']+').');if(_0x24b796['parts_']['length']>Qs)throw new Error(_0x24b796['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x24b796));}function Ne(_0x45dbe6){return _0x45dbe6['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x45dbe6['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x3bf77c,_0x21c7f3;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x21c7f3='visibilitychange',_0x3bf77c='hidden'):typeof document['mozHidden']<'u'?(_0x21c7f3='mozvisibilitychange',_0x3bf77c='mozHidden'):typeof document['msHidden']<'u'?(_0x21c7f3='msvisibilitychange',_0x3bf77c='msHidden'):typeof document['webkitHidden']<'u'&&(_0x21c7f3='webkitvisibilitychange',_0x3bf77c='webkitHidden')),this['visible_']=!0x0,_0x21c7f3&&document['addEventListener'](_0x21c7f3,()=>{const _0x1d004d=!document[_0x3bf77c];_0x1d004d!==this['visible_']&&(this['visible_']=_0x1d004d,this['trigger']('visible',_0x1d004d));},!0x1);}['getInitialEvent'](_0x4e2c28){return f(_0x4e2c28==='visible','Unknown\x20event\x20type:\x20'+_0x4e2c28),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x5a6094,_0x18d5a2,_0x3a6920,_0x45f557,_0x7ea4ae,_0x56e324,_0x676f22,_0x1f31ab){if(super(),this['repoInfo_']=_0x5a6094,this['applicationId_']=_0x18d5a2,this['onDataUpdate_']=_0x3a6920,this['onConnectStatus_']=_0x45f557,this['onServerInfoUpdate_']=_0x7ea4ae,this['authTokenProvider_']=_0x56e324,this['appCheckTokenProvider_']=_0x676f22,this['authOverride_']=_0x1f31ab,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x1f31ab)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x5a6094['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3fc5c5,_0x105c14,_0x2ad14e){const _0x3ce591=++this['requestNumber_'],_0x580024={'r':_0x3ce591,'a':_0x3fc5c5,'b':_0x105c14};this['log_'](O(_0x580024)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x580024),_0x2ad14e&&(this['requestCBHash_'][_0x3ce591]=_0x2ad14e);}['get'](_0x1a580c){this['initConnection_']();const _0x1e2495=new Ve(),_0x46d1f1={'action':'g','request':{'p':_0x1a580c['_path']['toString'](),'q':_0x1a580c['_queryObject']},'onComplete':_0x139122=>{const _0x3a9218=_0x139122['d'];_0x139122['s']==='ok'?_0x1e2495['resolve'](_0x3a9218):_0x1e2495['reject'](_0x3a9218);}};this['outstandingGets_']['push'](_0x46d1f1),this['outstandingGetCount_']++;const _0x6fca17=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x6fca17),_0x1e2495['promise'];}['listen'](_0x2f41d4,_0x3d3d28,_0x116463,_0x1a639f){this['initConnection_']();const _0x349698=_0x2f41d4['_queryIdentifier'],_0x45534a=_0x2f41d4['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x45534a+'\x20'+_0x349698),this['listens']['has'](_0x45534a)||this['listens']['set'](_0x45534a,new Map()),f(_0x2f41d4['_queryParams']['isDefault']()||!_0x2f41d4['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x45534a)['has'](_0x349698),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x6803eb={'onComplete':_0x1a639f,'hashFn':_0x3d3d28,'query':_0x2f41d4,'tag':_0x116463};this['listens']['get'](_0x45534a)['set'](_0x349698,_0x6803eb),this['connected_']&&this['sendListen_'](_0x6803eb);}['sendGet_'](_0x400500){const _0xed034=this['outstandingGets_'][_0x400500];this['sendRequest']('g',_0xed034['request'],_0xee6800=>{delete this['outstandingGets_'][_0x400500],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xed034['onComplete']&&_0xed034['onComplete'](_0xee6800);});}['sendListen_'](_0x1adb7b){const _0x5b7cfc=_0x1adb7b['query'],_0x35613b=_0x5b7cfc['_path']['toString'](),_0x1b67be=_0x5b7cfc['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x35613b+'\x20for\x20'+_0x1b67be);const _0x1ade90={'p':_0x35613b},_0xd39ded='q';_0x1adb7b['tag']&&(_0x1ade90['q']=_0x5b7cfc['_queryObject'],_0x1ade90['t']=_0x1adb7b['tag']),_0x1ade90['h']=_0x1adb7b['hashFn'](),this['sendRequest'](_0xd39ded,_0x1ade90,_0x2b1863=>{const _0xd3cd41=_0x2b1863['d'],_0x4595d0=_0x2b1863['s'];ie['warnOnListenWarnings_'](_0xd3cd41,_0x5b7cfc),(this['listens']['get'](_0x35613b)&&this['listens']['get'](_0x35613b)['get'](_0x1b67be))===_0x1adb7b&&(this['log_']('listen\x20response',_0x2b1863),_0x4595d0!=='ok'&&this['removeListen_'](_0x35613b,_0x1b67be),_0x1adb7b['onComplete']&&_0x1adb7b['onComplete'](_0x4595d0,_0xd3cd41));});}static['warnOnListenWarnings_'](_0x32d69b,_0x3269ef){if(_0x32d69b&&typeof _0x32d69b=='object'&&Y(_0x32d69b,'w')){const _0x39400a=Oe(_0x32d69b,'w');if(Array['isArray'](_0x39400a)&&~_0x39400a['indexOf']('no_index')){const _0x13c879='\x22.indexOn\x22:\x20\x22'+_0x3269ef['_queryParams']['getIndex']()['toString']()+'\x22',_0x3bfea3=_0x3269ef['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x13c879+'\x20at\x20'+_0x3bfea3+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x5665c7){this['authToken_']=_0x5665c7,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x5665c7);}['reduceReconnectDelayIfAdminCredential_'](_0x10f0cb){(_0x10f0cb&&_0x10f0cb['length']===0x28||vc(_0x10f0cb))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x617c64){this['appCheckToken_']=_0x617c64,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x348f1d=this['authToken_'],_0x1a03c0=yc(_0x348f1d)?'auth':'gauth',_0x50368d={'cred':_0x348f1d};this['authOverride_']===null?_0x50368d['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x50368d['authvar']=this['authOverride_']),this['sendRequest'](_0x1a03c0,_0x50368d,_0x3bab=>{const _0x246846=_0x3bab['s'],_0x5bdee0=_0x3bab['d']||'error';this['authToken_']===_0x348f1d&&(_0x246846==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x246846,_0x5bdee0));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1c0f21=>{const _0x21149c=_0x1c0f21['s'],_0x237c35=_0x1c0f21['d']||'error';_0x21149c==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x21149c,_0x237c35);});}['unlisten'](_0x91bd00,_0x11f365){const _0x404739=_0x91bd00['_path']['toString'](),_0x40b18a=_0x91bd00['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x404739+'\x20'+_0x40b18a),f(_0x91bd00['_queryParams']['isDefault']()||!_0x91bd00['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x404739,_0x40b18a)&&this['connected_']&&this['sendUnlisten_'](_0x404739,_0x40b18a,_0x91bd00['_queryObject'],_0x11f365);}['sendUnlisten_'](_0x30dd35,_0x4f8190,_0x37a837,_0x3205cf){this['log_']('Unlisten\x20on\x20'+_0x30dd35+'\x20for\x20'+_0x4f8190);const _0x5e62c0={'p':_0x30dd35},_0x2db599='n';_0x3205cf&&(_0x5e62c0['q']=_0x37a837,_0x5e62c0['t']=_0x3205cf),this['sendRequest'](_0x2db599,_0x5e62c0);}['onDisconnectPut'](_0x107a43,_0x24431b,_0x108425){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x107a43,_0x24431b,_0x108425):this['onDisconnectRequestQueue_']['push']({'pathString':_0x107a43,'action':'o','data':_0x24431b,'onComplete':_0x108425});}['onDisconnectMerge'](_0x2e599e,_0x6ca570,_0x29481b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2e599e,_0x6ca570,_0x29481b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2e599e,'action':'om','data':_0x6ca570,'onComplete':_0x29481b});}['onDisconnectCancel'](_0x5049f2,_0x14ebe3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x5049f2,null,_0x14ebe3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5049f2,'action':'oc','data':null,'onComplete':_0x14ebe3});}['sendOnDisconnect_'](_0xd9b208,_0x4b99f8,_0x3cb3e4,_0x2c5936){const _0x2044a3={'p':_0x4b99f8,'d':_0x3cb3e4};this['log_']('onDisconnect\x20'+_0xd9b208,_0x2044a3),this['sendRequest'](_0xd9b208,_0x2044a3,_0x35ce5a=>{_0x2c5936&&setTimeout(()=>{_0x2c5936(_0x35ce5a['s'],_0x35ce5a['d']);},Math['floor'](0x0));});}['put'](_0x52914e,_0x514875,_0x1c47a8,_0x3c2de6){this['putInternal']('p',_0x52914e,_0x514875,_0x1c47a8,_0x3c2de6);}['merge'](_0x8f6a35,_0x2ebdfb,_0x571eb1,_0x2fda61){this['putInternal']('m',_0x8f6a35,_0x2ebdfb,_0x571eb1,_0x2fda61);}['putInternal'](_0x5887f6,_0x584434,_0x58dd89,_0x4d345a,_0x44823e){this['initConnection_']();const _0x33ff1d={'p':_0x584434,'d':_0x58dd89};_0x44823e!==void 0x0&&(_0x33ff1d['h']=_0x44823e),this['outstandingPuts_']['push']({'action':_0x5887f6,'request':_0x33ff1d,'onComplete':_0x4d345a}),this['outstandingPutCount_']++;const _0x478810=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x478810):this['log_']('Buffering\x20put:\x20'+_0x584434);}['sendPut_'](_0x399711){const _0x43187f=this['outstandingPuts_'][_0x399711]['action'],_0xd08792=this['outstandingPuts_'][_0x399711]['request'],_0x49d013=this['outstandingPuts_'][_0x399711]['onComplete'];this['outstandingPuts_'][_0x399711]['queued']=this['connected_'],this['sendRequest'](_0x43187f,_0xd08792,_0x5c93ba=>{this['log_'](_0x43187f+'\x20response',_0x5c93ba),delete this['outstandingPuts_'][_0x399711],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x49d013&&_0x49d013(_0x5c93ba['s'],_0x5c93ba['d']);});}['reportStats'](_0x44e1c7){if(this['connected_']){const _0x31d2ec={'c':_0x44e1c7};this['log_']('reportStats',_0x31d2ec),this['sendRequest']('s',_0x31d2ec,_0x367f3f=>{if(_0x367f3f['s']!=='ok'){const _0x3842f3=_0x367f3f['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3842f3);}});}}['onDataMessage_'](_0x23039c){if('r'in _0x23039c){this['log_']('from\x20server:\x20'+O(_0x23039c));const _0x5b5272=_0x23039c['r'],_0x3cc9b0=this['requestCBHash_'][_0x5b5272];_0x3cc9b0&&(delete this['requestCBHash_'][_0x5b5272],_0x3cc9b0(_0x23039c['b']));}else{if('error'in _0x23039c)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x23039c['error'];'a'in _0x23039c&&this['onDataPush_'](_0x23039c['a'],_0x23039c['b']);}}['onDataPush_'](_0x254cae,_0x4b0445){this['log_']('handleServerMessage',_0x254cae,_0x4b0445),_0x254cae==='d'?this['onDataUpdate_'](_0x4b0445['p'],_0x4b0445['d'],!0x1,_0x4b0445['t']):_0x254cae==='m'?this['onDataUpdate_'](_0x4b0445['p'],_0x4b0445['d'],!0x0,_0x4b0445['t']):_0x254cae==='c'?this['onListenRevoked_'](_0x4b0445['p'],_0x4b0445['q']):_0x254cae==='ac'?this['onAuthRevoked_'](_0x4b0445['s'],_0x4b0445['d']):_0x254cae==='apc'?this['onAppCheckRevoked_'](_0x4b0445['s'],_0x4b0445['d']):_0x254cae==='sd'?this['onSecurityDebugPacket_'](_0x4b0445):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x254cae)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x5a9b8e,_0x1eb0c8){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x5a9b8e),this['lastSessionId']=_0x1eb0c8,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5b8bb7){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5b8bb7));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x369b50){_0x369b50&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x369b50;}['onOnline_'](_0x51bc04){_0x51bc04?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2d4973=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xf7b69d=Math['max'](0x0,this['reconnectDelay_']-_0x2d4973);_0xf7b69d=Math['random']()*_0xf7b69d,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xf7b69d+'ms'),this['scheduleConnect_'](_0xf7b69d),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4ac7f3=this['onDataMessage_']['bind'](this),_0x24624e=this['onReady_']['bind'](this),_0xe1ce1f=this['onRealtimeDisconnect_']['bind'](this),_0x46c8f3=this['id']+':'+ie['nextConnectionId_']++,_0xb69b1b=this['lastSessionId'];let _0x4434dd=!0x1,_0x3f815f=null;const _0xed916c=function(){_0x3f815f?_0x3f815f['close']():(_0x4434dd=!0x0,_0xe1ce1f());},_0x54b3df=function(_0x18b141){f(_0x3f815f,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3f815f['sendRequest'](_0x18b141);};this['realtime_']={'close':_0xed916c,'sendRequest':_0x54b3df};const _0x3d4b41=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x250cd6,_0x5a2189]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3d4b41),this['appCheckTokenProvider_']['getToken'](_0x3d4b41)]);_0x4434dd?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x250cd6&&_0x250cd6['accessToken'],this['appCheckToken_']=_0x5a2189&&_0x5a2189['token'],_0x3f815f=new wh(_0x46c8f3,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4ac7f3,_0x24624e,_0xe1ce1f,_0x5bd85d=>{U(_0x5bd85d+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0xb69b1b));}catch(_0x57fc62){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x57fc62),_0x4434dd||(this['repoInfo_']['nodeAdmin']&&U(_0x57fc62),_0xed916c());}}}['interrupt'](_0x1e94a7){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1e94a7),this['interruptReasons_'][_0x1e94a7]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x384899){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x384899),delete this['interruptReasons_'][_0x384899],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5e8099){const _0x576349=_0x5e8099-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x576349});}['cancelSentTransactions_'](){for(let _0x2028f7=0x0;_0x2028f7<this['outstandingPuts_']['length'];_0x2028f7++){const _0xcc8785=this['outstandingPuts_'][_0x2028f7];_0xcc8785&&'h'in _0xcc8785['request']&&_0xcc8785['queued']&&(_0xcc8785['onComplete']&&_0xcc8785['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2028f7],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x24768b,_0x59c2c7){let _0x4d5ad0;_0x59c2c7?_0x4d5ad0=_0x59c2c7['map'](_0xd91ed9=>Bi(_0xd91ed9))['join']('$'):_0x4d5ad0='default';const _0x283b37=this['removeListen_'](_0x24768b,_0x4d5ad0);_0x283b37&&_0x283b37['onComplete']&&_0x283b37['onComplete']('permission_denied');}['removeListen_'](_0x460177,_0x5f274b){const _0xe17862=new C(_0x460177)['toString']();let _0x3aaea2;if(this['listens']['has'](_0xe17862)){const _0x13f687=this['listens']['get'](_0xe17862);_0x3aaea2=_0x13f687['get'](_0x5f274b),_0x13f687['delete'](_0x5f274b),_0x13f687['size']===0x0&&this['listens']['delete'](_0xe17862);}else _0x3aaea2=void 0x0;return _0x3aaea2;}['onAuthRevoked_'](_0x569876,_0x43d4fa){L('Auth\x20token\x20revoked:\x20'+_0x569876+'/'+_0x43d4fa),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x569876==='invalid_token'||_0x569876==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x562d5c,_0x402189){L('App\x20check\x20token\x20revoked:\x20'+_0x562d5c+'/'+_0x402189),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x562d5c==='invalid_token'||_0x562d5c==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4daebd){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4daebd):'msg'in _0x4daebd&&console['log']('FIREBASE:\x20'+_0x4daebd['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x35ab53 of this['listens']['values']())for(const _0x22571f of _0x35ab53['values']())this['sendListen_'](_0x22571f);for(let _0x29c0bf=0x0;_0x29c0bf<this['outstandingPuts_']['length'];_0x29c0bf++)this['outstandingPuts_'][_0x29c0bf]&&this['sendPut_'](_0x29c0bf);for(;this['onDisconnectRequestQueue_']['length'];){const _0x29cbd9=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x29cbd9['action'],_0x29cbd9['pathString'],_0x29cbd9['data'],_0x29cbd9['onComplete']);}for(let _0x19ea86=0x0;_0x19ea86<this['outstandingGets_']['length'];_0x19ea86++)this['outstandingGets_'][_0x19ea86]&&this['sendGet_'](_0x19ea86);}['sendConnectStats_'](){const _0x51e47d={};let _0x5cac3b='js';_0x51e47d['sdk.'+_0x5cac3b+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x51e47d['framework.cordova']=0x1:qr()&&(_0x51e47d['framework.reactnative']=0x1),this['reportStats'](_0x51e47d);}['shouldReconnect_'](){const _0x4cac70=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x4cac70;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x38ebd0,_0x24bdf1){this['name']=_0x38ebd0,this['node']=_0x24bdf1;}static['Wrap'](_0x29cb4c,_0x42a1fd){return new E(_0x29cb4c,_0x42a1fd);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xf79377,_0x9dfefd){const _0x24a3f2=new E(xe,_0xf79377),_0x4b10bc=new E(xe,_0x9dfefd);return this['compare'](_0x24a3f2,_0x4b10bc)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x2e2ec8){Xt=_0x2e2ec8;}['compare'](_0x5d4ccd,_0x472e00){return He(_0x5d4ccd['name'],_0x472e00['name']);}['isDefinedOn'](_0x548a00){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3b4a87,_0x432911){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x81f0bc,_0x21340d){return f(typeof _0x81f0bc=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x81f0bc,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x5a1f1a,_0x3f87ae,_0x2abded,_0x1ff764,_0x5b1335=null){this['isReverse_']=_0x1ff764,this['resultGenerator_']=_0x5b1335,this['nodeStack_']=[];let _0x104c0d=0x1;for(;!_0x5a1f1a['isEmpty']();)if(_0x5a1f1a=_0x5a1f1a,_0x104c0d=_0x3f87ae?_0x2abded(_0x5a1f1a['key'],_0x3f87ae):0x1,_0x1ff764&&(_0x104c0d*=-0x1),_0x104c0d<0x0)this['isReverse_']?_0x5a1f1a=_0x5a1f1a['left']:_0x5a1f1a=_0x5a1f1a['right'];else{if(_0x104c0d===0x0){this['nodeStack_']['push'](_0x5a1f1a);break;}else this['nodeStack_']['push'](_0x5a1f1a),this['isReverse_']?_0x5a1f1a=_0x5a1f1a['right']:_0x5a1f1a=_0x5a1f1a['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x2a6aff=this['nodeStack_']['pop'](),_0x123a5d;if(this['resultGenerator_']?_0x123a5d=this['resultGenerator_'](_0x2a6aff['key'],_0x2a6aff['value']):_0x123a5d={'key':_0x2a6aff['key'],'value':_0x2a6aff['value']},this['isReverse_']){for(_0x2a6aff=_0x2a6aff['left'];!_0x2a6aff['isEmpty']();)this['nodeStack_']['push'](_0x2a6aff),_0x2a6aff=_0x2a6aff['right'];}else{for(_0x2a6aff=_0x2a6aff['right'];!_0x2a6aff['isEmpty']();)this['nodeStack_']['push'](_0x2a6aff),_0x2a6aff=_0x2a6aff['left'];}return _0x123a5d;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xd6b692=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xd6b692['key'],_0xd6b692['value']):{'key':_0xd6b692['key'],'value':_0xd6b692['value']};}}class M{constructor(_0x566963,_0xa693c,_0x2fa563,_0x1a24cf,_0x1409f3){this['key']=_0x566963,this['value']=_0xa693c,this['color']=_0x2fa563??M['RED'],this['left']=_0x1a24cf??B['EMPTY_NODE'],this['right']=_0x1409f3??B['EMPTY_NODE'];}['copy'](_0x56a838,_0x268c14,_0x5a3680,_0x40a100,_0x16921f){return new M(_0x56a838??this['key'],_0x268c14??this['value'],_0x5a3680??this['color'],_0x40a100??this['left'],_0x16921f??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x27bd27){return this['left']['inorderTraversal'](_0x27bd27)||!!_0x27bd27(this['key'],this['value'])||this['right']['inorderTraversal'](_0x27bd27);}['reverseTraversal'](_0x1778f8){return this['right']['reverseTraversal'](_0x1778f8)||_0x1778f8(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1778f8);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3e52a2,_0x1667ba,_0x9b0dcc){let _0xab8867=this;const _0xfae28f=_0x9b0dcc(_0x3e52a2,_0xab8867['key']);return _0xfae28f<0x0?_0xab8867=_0xab8867['copy'](null,null,null,_0xab8867['left']['insert'](_0x3e52a2,_0x1667ba,_0x9b0dcc),null):_0xfae28f===0x0?_0xab8867=_0xab8867['copy'](null,_0x1667ba,null,null,null):_0xab8867=_0xab8867['copy'](null,null,null,null,_0xab8867['right']['insert'](_0x3e52a2,_0x1667ba,_0x9b0dcc)),_0xab8867['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2144c0=this;return!_0x2144c0['left']['isRed_']()&&!_0x2144c0['left']['left']['isRed_']()&&(_0x2144c0=_0x2144c0['moveRedLeft_']()),_0x2144c0=_0x2144c0['copy'](null,null,null,_0x2144c0['left']['removeMin_'](),null),_0x2144c0['fixUp_']();}['remove'](_0x1a1eee,_0x346015){let _0x22fbf3,_0x1b6407;if(_0x22fbf3=this,_0x346015(_0x1a1eee,_0x22fbf3['key'])<0x0)!_0x22fbf3['left']['isEmpty']()&&!_0x22fbf3['left']['isRed_']()&&!_0x22fbf3['left']['left']['isRed_']()&&(_0x22fbf3=_0x22fbf3['moveRedLeft_']()),_0x22fbf3=_0x22fbf3['copy'](null,null,null,_0x22fbf3['left']['remove'](_0x1a1eee,_0x346015),null);else{if(_0x22fbf3['left']['isRed_']()&&(_0x22fbf3=_0x22fbf3['rotateRight_']()),!_0x22fbf3['right']['isEmpty']()&&!_0x22fbf3['right']['isRed_']()&&!_0x22fbf3['right']['left']['isRed_']()&&(_0x22fbf3=_0x22fbf3['moveRedRight_']()),_0x346015(_0x1a1eee,_0x22fbf3['key'])===0x0){if(_0x22fbf3['right']['isEmpty']())return B['EMPTY_NODE'];_0x1b6407=_0x22fbf3['right']['min_'](),_0x22fbf3=_0x22fbf3['copy'](_0x1b6407['key'],_0x1b6407['value'],null,null,_0x22fbf3['right']['removeMin_']());}_0x22fbf3=_0x22fbf3['copy'](null,null,null,null,_0x22fbf3['right']['remove'](_0x1a1eee,_0x346015));}return _0x22fbf3['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x5cba78=this;return _0x5cba78['right']['isRed_']()&&!_0x5cba78['left']['isRed_']()&&(_0x5cba78=_0x5cba78['rotateLeft_']()),_0x5cba78['left']['isRed_']()&&_0x5cba78['left']['left']['isRed_']()&&(_0x5cba78=_0x5cba78['rotateRight_']()),_0x5cba78['left']['isRed_']()&&_0x5cba78['right']['isRed_']()&&(_0x5cba78=_0x5cba78['colorFlip_']()),_0x5cba78;}['moveRedLeft_'](){let _0x929ac0=this['colorFlip_']();return _0x929ac0['right']['left']['isRed_']()&&(_0x929ac0=_0x929ac0['copy'](null,null,null,null,_0x929ac0['right']['rotateRight_']()),_0x929ac0=_0x929ac0['rotateLeft_'](),_0x929ac0=_0x929ac0['colorFlip_']()),_0x929ac0;}['moveRedRight_'](){let _0xac9811=this['colorFlip_']();return _0xac9811['left']['left']['isRed_']()&&(_0xac9811=_0xac9811['rotateRight_'](),_0xac9811=_0xac9811['colorFlip_']()),_0xac9811;}['rotateLeft_'](){const _0x5b2518=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x5b2518,null);}['rotateRight_'](){const _0x1cbc38=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1cbc38);}['colorFlip_'](){const _0x210ddd=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x309eaa=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x210ddd,_0x309eaa);}['checkMaxDepth_'](){const _0xa09847=this['check_']();return Math['pow'](0x2,_0xa09847)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x477517=this['left']['check_']();if(_0x477517!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x477517+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0xae76c,_0x29aee3,_0x4f679a,_0x2d4843,_0x348add){return this;}['insert'](_0x432fcc,_0x5f354b,_0x29262e){return new M(_0x432fcc,_0x5f354b,null);}['remove'](_0x3bb58d,_0x519fd7){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2e290e){return!0x1;}['reverseTraversal'](_0x560416){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1c4c5b,_0xf3dd58=B['EMPTY_NODE']){this['comparator_']=_0x1c4c5b,this['root_']=_0xf3dd58;}['insert'](_0x2e1bc1,_0x23fe7b){return new B(this['comparator_'],this['root_']['insert'](_0x2e1bc1,_0x23fe7b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x326fbf){return new B(this['comparator_'],this['root_']['remove'](_0x326fbf,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x4d7714){let _0x4abc17,_0x232107=this['root_'];for(;!_0x232107['isEmpty']();){if(_0x4abc17=this['comparator_'](_0x4d7714,_0x232107['key']),_0x4abc17===0x0)return _0x232107['value'];_0x4abc17<0x0?_0x232107=_0x232107['left']:_0x4abc17>0x0&&(_0x232107=_0x232107['right']);}return null;}['getPredecessorKey'](_0xcd7900){let _0x3fff44,_0x527b6a=this['root_'],_0x3469db=null;for(;!_0x527b6a['isEmpty']();)if(_0x3fff44=this['comparator_'](_0xcd7900,_0x527b6a['key']),_0x3fff44===0x0){if(_0x527b6a['left']['isEmpty']())return _0x3469db?_0x3469db['key']:null;for(_0x527b6a=_0x527b6a['left'];!_0x527b6a['right']['isEmpty']();)_0x527b6a=_0x527b6a['right'];return _0x527b6a['key'];}else _0x3fff44<0x0?_0x527b6a=_0x527b6a['left']:_0x3fff44>0x0&&(_0x3469db=_0x527b6a,_0x527b6a=_0x527b6a['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x3f08f6){return this['root_']['inorderTraversal'](_0x3f08f6);}['reverseTraversal'](_0x1d4a45){return this['root_']['reverseTraversal'](_0x1d4a45);}['getIterator'](_0x34e0cc){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x34e0cc);}['getIteratorFrom'](_0x5a8b1f,_0x1a0cd7){return new Zt(this['root_'],_0x5a8b1f,this['comparator_'],!0x1,_0x1a0cd7);}['getReverseIteratorFrom'](_0x2fffce,_0x1f0f6b){return new Zt(this['root_'],_0x2fffce,this['comparator_'],!0x0,_0x1f0f6b);}['getReverseIterator'](_0x3818a2){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x3818a2);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x40411c,_0x114678){return He(_0x40411c['name'],_0x114678['name']);}function ji(_0x23b7c2,_0x1374a1){return He(_0x23b7c2,_0x1374a1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x227287){vi=_0x227287;}const Ro=function(_0x287473){return typeof _0x287473=='number'?'number:'+so(_0x287473):'string:'+_0x287473;},Ao=function(_0x4867a6){if(_0x4867a6['isLeafNode']()){const _0x55a2d8=_0x4867a6['val']();f(typeof _0x55a2d8=='string'||typeof _0x55a2d8=='number'||typeof _0x55a2d8=='object'&&Y(_0x55a2d8,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4867a6===vi||_0x4867a6['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4867a6===vi||_0x4867a6['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x2a733c){er=_0x2a733c;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x10f8a9,_0x3ca88b=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x10f8a9,this['priorityNode_']=_0x3ca88b,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x608070){return new D(this['value_'],_0x608070);}['getImmediateChild'](_0x417ce0){return _0x417ce0==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x138b1a){return v(_0x138b1a)?this:y(_0x138b1a)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3b330f,_0x598c06){return null;}['updateImmediateChild'](_0x25fb2e,_0x255b77){return _0x25fb2e==='.priority'?this['updatePriority'](_0x255b77):_0x255b77['isEmpty']()&&_0x25fb2e!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x25fb2e,_0x255b77)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3cd4ed,_0x2c95ec){const _0x40f459=y(_0x3cd4ed);return _0x40f459===null?_0x2c95ec:_0x2c95ec['isEmpty']()&&_0x40f459!=='.priority'?this:(f(_0x40f459!=='.priority'||we(_0x3cd4ed)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x40f459,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x3cd4ed),_0x2c95ec)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x20fba8,_0x5e9700){return!0x1;}['val'](_0x14b618){return _0x14b618&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3969ef='';this['priorityNode_']['isEmpty']()||(_0x3969ef+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x581aef=typeof this['value_'];_0x3969ef+=_0x581aef+':',_0x581aef==='number'?_0x3969ef+=so(this['value_']):_0x3969ef+=this['value_'],this['lazyHash_']=no(_0x3969ef);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3f86d7){return _0x3f86d7===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3f86d7 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3f86d7['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3f86d7));}['compareToLeafNode_'](_0x50fb3a){const _0xfff426=typeof _0x50fb3a['value_'],_0x104979=typeof this['value_'],_0xec2d3c=D['VALUE_TYPE_ORDER']['indexOf'](_0xfff426),_0x3dbfd8=D['VALUE_TYPE_ORDER']['indexOf'](_0x104979);return f(_0xec2d3c>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xfff426),f(_0x3dbfd8>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x104979),_0xec2d3c===_0x3dbfd8?_0x104979==='object'?0x0:this['value_']<_0x50fb3a['value_']?-0x1:this['value_']===_0x50fb3a['value_']?0x0:0x1:_0x3dbfd8-_0xec2d3c;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x506bc6){if(_0x506bc6===this)return!0x0;if(_0x506bc6['isLeafNode']()){const _0x192006=_0x506bc6;return this['value_']===_0x192006['value_']&&this['priorityNode_']['equals'](_0x192006['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x31195a){ko=_0x31195a;}function xh(_0x5af401){No=_0x5af401;}class Fh extends On{['compare'](_0x2719fa,_0x3e72a5){const _0x430d37=_0x2719fa['node']['getPriority'](),_0x5a627f=_0x3e72a5['node']['getPriority'](),_0x1d9e01=_0x430d37['compareTo'](_0x5a627f);return _0x1d9e01===0x0?He(_0x2719fa['name'],_0x3e72a5['name']):_0x1d9e01;}['isDefinedOn'](_0x4b7097){return!_0x4b7097['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x71e0f9,_0x3ef64b){return!_0x71e0f9['getPriority']()['equals'](_0x3ef64b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x1e8a9d,_0x2ce530){const _0x3cbab7=ko(_0x1e8a9d);return new E(_0x2ce530,new D('[PRIORITY-POST]',_0x3cbab7));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x1c2d0d){const _0x25b09f=_0x25d8d6=>parseInt(Math['log'](_0x25d8d6)/Uh,0xa),_0x55f721=_0x153014=>parseInt(Array(_0x153014+0x1)['join']('1'),0x2);this['count']=_0x25b09f(_0x1c2d0d+0x1),this['current_']=this['count']-0x1;const _0x59e976=_0x55f721(this['count']);this['bits_']=_0x1c2d0d+0x1&_0x59e976;}['nextBitIsOne'](){const _0x1d1f20=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x1d1f20;}}const dn=function(_0xbdddbb,_0x426b9c,_0x5af796,_0x3f1a63){_0xbdddbb['sort'](_0x426b9c);const _0x1ad04a=function(_0x4cd3ce,_0x48e3fc){const _0x1fa23f=_0x48e3fc-_0x4cd3ce;let _0x39792f,_0x1f0d08;if(_0x1fa23f===0x0)return null;if(_0x1fa23f===0x1)return _0x39792f=_0xbdddbb[_0x4cd3ce],_0x1f0d08=_0x5af796?_0x5af796(_0x39792f):_0x39792f,new M(_0x1f0d08,_0x39792f['node'],M['BLACK'],null,null);{const _0x4d2450=parseInt(_0x1fa23f/0x2,0xa)+_0x4cd3ce,_0x348e5c=_0x1ad04a(_0x4cd3ce,_0x4d2450),_0x50ee56=_0x1ad04a(_0x4d2450+0x1,_0x48e3fc);return _0x39792f=_0xbdddbb[_0x4d2450],_0x1f0d08=_0x5af796?_0x5af796(_0x39792f):_0x39792f,new M(_0x1f0d08,_0x39792f['node'],M['BLACK'],_0x348e5c,_0x50ee56);}},_0x406ead=function(_0x2e0448){let _0x5eeac5=null,_0x8090e6=null,_0x4e919d=_0xbdddbb['length'];const _0x51b2c8=function(_0x14d868,_0x18bb4f){const _0x24ef5d=_0x4e919d-_0x14d868,_0x2341e1=_0x4e919d;_0x4e919d-=_0x14d868;const _0x39637c=_0x1ad04a(_0x24ef5d+0x1,_0x2341e1),_0x3bfcc0=_0xbdddbb[_0x24ef5d],_0x1f1d22=_0x5af796?_0x5af796(_0x3bfcc0):_0x3bfcc0;_0x521fd1(new M(_0x1f1d22,_0x3bfcc0['node'],_0x18bb4f,null,_0x39637c));},_0x521fd1=function(_0x193e62){_0x5eeac5?(_0x5eeac5['left']=_0x193e62,_0x5eeac5=_0x193e62):(_0x8090e6=_0x193e62,_0x5eeac5=_0x193e62);};for(let _0x25ef7d=0x0;_0x25ef7d<_0x2e0448['count'];++_0x25ef7d){const _0x52a310=_0x2e0448['nextBitIsOne'](),_0x4cab5b=Math['pow'](0x2,_0x2e0448['count']-(_0x25ef7d+0x1));_0x52a310?_0x51b2c8(_0x4cab5b,M['BLACK']):(_0x51b2c8(_0x4cab5b,M['BLACK']),_0x51b2c8(_0x4cab5b,M['RED']));}return _0x8090e6;},_0x325cc6=new Wh(_0xbdddbb['length']),_0x3217f7=_0x406ead(_0x325cc6);return new B(_0x3f1a63||_0x426b9c,_0x3217f7);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0xd18a22,_0x102543){this['indexes_']=_0xd18a22,this['indexSet_']=_0x102543;}['get'](_0x40fbba){const _0xab1f20=Oe(this['indexes_'],_0x40fbba);if(!_0xab1f20)throw new Error('No\x20index\x20defined\x20for\x20'+_0x40fbba);return _0xab1f20 instanceof B?_0xab1f20:null;}['hasIndex'](_0x376930){return Y(this['indexSet_'],_0x376930['toString']());}['addIndex'](_0x4f0d78,_0x283c2f){f(_0x4f0d78!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x277d58=[];let _0xcc724d=!0x1;const _0x5f007b=_0x283c2f['getIterator'](E['Wrap']);let _0x3f63a1=_0x5f007b['getNext']();for(;_0x3f63a1;)_0xcc724d=_0xcc724d||_0x4f0d78['isDefinedOn'](_0x3f63a1['node']),_0x277d58['push'](_0x3f63a1),_0x3f63a1=_0x5f007b['getNext']();let _0x3c2514;_0xcc724d?_0x3c2514=dn(_0x277d58,_0x4f0d78['getCompare']()):_0x3c2514=je;const _0x2867fc=_0x4f0d78['toString'](),_0x383b8f={...this['indexSet_']};_0x383b8f[_0x2867fc]=_0x4f0d78;const _0x445a9c={...this['indexes_']};return _0x445a9c[_0x2867fc]=_0x3c2514,new ee(_0x445a9c,_0x383b8f);}['addToIndexes'](_0x202b30,_0x56805a){const _0x9ba62f=ln(this['indexes_'],(_0x13adbe,_0x5a9027)=>{const _0xfd454=Oe(this['indexSet_'],_0x5a9027);if(f(_0xfd454,'Missing\x20index\x20implementation\x20for\x20'+_0x5a9027),_0x13adbe===je){if(_0xfd454['isDefinedOn'](_0x202b30['node'])){const _0x2e0fac=[],_0x1b5f1c=_0x56805a['getIterator'](E['Wrap']);let _0x93d144=_0x1b5f1c['getNext']();for(;_0x93d144;)_0x93d144['name']!==_0x202b30['name']&&_0x2e0fac['push'](_0x93d144),_0x93d144=_0x1b5f1c['getNext']();return _0x2e0fac['push'](_0x202b30),dn(_0x2e0fac,_0xfd454['getCompare']());}else return je;}else{const _0x430340=_0x56805a['get'](_0x202b30['name']);let _0x107349=_0x13adbe;return _0x430340&&(_0x107349=_0x107349['remove'](new E(_0x202b30['name'],_0x430340))),_0x107349['insert'](_0x202b30,_0x202b30['node']);}});return new ee(_0x9ba62f,this['indexSet_']);}['removeFromIndexes'](_0xf96c5e,_0x3a0f70){const _0x56529b=ln(this['indexes_'],_0x4a1ba3=>{if(_0x4a1ba3===je)return _0x4a1ba3;{const _0xc824d1=_0x3a0f70['get'](_0xf96c5e['name']);return _0xc824d1?_0x4a1ba3['remove'](new E(_0xf96c5e['name'],_0xc824d1)):_0x4a1ba3;}});return new ee(_0x56529b,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x1848b5,_0x5c1a3e,_0x1f004d){this['children_']=_0x1848b5,this['priorityNode_']=_0x5c1a3e,this['indexMap_']=_0x1f004d,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x3484de){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x3484de,this['indexMap_']);}['getImmediateChild'](_0x4ec561){if(_0x4ec561==='.priority')return this['getPriority']();{const _0x56af8b=this['children_']['get'](_0x4ec561);return _0x56af8b===null?gt:_0x56af8b;}}['getChild'](_0x5105d2){const _0x4347b3=y(_0x5105d2);return _0x4347b3===null?this:this['getImmediateChild'](_0x4347b3)['getChild'](b(_0x5105d2));}['hasChild'](_0x33a569){return this['children_']['get'](_0x33a569)!==null;}['updateImmediateChild'](_0x12c7b7,_0x3505fd){if(f(_0x3505fd,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x12c7b7==='.priority')return this['updatePriority'](_0x3505fd);{const _0x18d837=new E(_0x12c7b7,_0x3505fd);let _0x1364ab,_0x163fc7;_0x3505fd['isEmpty']()?(_0x1364ab=this['children_']['remove'](_0x12c7b7),_0x163fc7=this['indexMap_']['removeFromIndexes'](_0x18d837,this['children_'])):(_0x1364ab=this['children_']['insert'](_0x12c7b7,_0x3505fd),_0x163fc7=this['indexMap_']['addToIndexes'](_0x18d837,this['children_']));const _0x2fac31=_0x1364ab['isEmpty']()?gt:this['priorityNode_'];return new g(_0x1364ab,_0x2fac31,_0x163fc7);}}['updateChild'](_0xa60bdb,_0x1fd1bc){const _0x430d3c=y(_0xa60bdb);if(_0x430d3c===null)return _0x1fd1bc;{f(y(_0xa60bdb)!=='.priority'||we(_0xa60bdb)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x35483=this['getImmediateChild'](_0x430d3c)['updateChild'](b(_0xa60bdb),_0x1fd1bc);return this['updateImmediateChild'](_0x430d3c,_0x35483);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x5d8326){if(this['isEmpty']())return null;const _0x515354={};let _0x485dca=0x0,_0xf1fee2=0x0,_0x5ba36e=!0x0;if(this['forEachChild'](R,(_0x42ffe8,_0x12260f)=>{_0x515354[_0x42ffe8]=_0x12260f['val'](_0x5d8326),_0x485dca++,_0x5ba36e&&g['INTEGER_REGEXP_']['test'](_0x42ffe8)?_0xf1fee2=Math['max'](_0xf1fee2,Number(_0x42ffe8)):_0x5ba36e=!0x1;}),!_0x5d8326&&_0x5ba36e&&_0xf1fee2<0x2*_0x485dca){const _0xc75049=[];for(const _0x2201fb in _0x515354)_0xc75049[_0x2201fb]=_0x515354[_0x2201fb];return _0xc75049;}else return _0x5d8326&&!this['getPriority']()['isEmpty']()&&(_0x515354['.priority']=this['getPriority']()['val']()),_0x515354;}['hash'](){if(this['lazyHash_']===null){let _0x239c37='';this['getPriority']()['isEmpty']()||(_0x239c37+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1d683c,_0x337236)=>{const _0x272e7c=_0x337236['hash']();_0x272e7c!==''&&(_0x239c37+=':'+_0x1d683c+':'+_0x272e7c);}),this['lazyHash_']=_0x239c37===''?'':no(_0x239c37);}return this['lazyHash_'];}['getPredecessorChildName'](_0x48ddcb,_0x5b6423,_0x117aa1){const _0x2d36b2=this['resolveIndex_'](_0x117aa1);if(_0x2d36b2){const _0x31ffc9=_0x2d36b2['getPredecessorKey'](new E(_0x48ddcb,_0x5b6423));return _0x31ffc9?_0x31ffc9['name']:null;}else return this['children_']['getPredecessorKey'](_0x48ddcb);}['getFirstChildName'](_0x174d1b){const _0x42c786=this['resolveIndex_'](_0x174d1b);if(_0x42c786){const _0x2c538f=_0x42c786['minKey']();return _0x2c538f&&_0x2c538f['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x5d4ea3){const _0x1fd01b=this['getFirstChildName'](_0x5d4ea3);return _0x1fd01b?new E(_0x1fd01b,this['children_']['get'](_0x1fd01b)):null;}['getLastChildName'](_0x1a7e90){const _0x42f33d=this['resolveIndex_'](_0x1a7e90);if(_0x42f33d){const _0xd238f5=_0x42f33d['maxKey']();return _0xd238f5&&_0xd238f5['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x122ef7){const _0x2e3af8=this['getLastChildName'](_0x122ef7);return _0x2e3af8?new E(_0x2e3af8,this['children_']['get'](_0x2e3af8)):null;}['forEachChild'](_0x21e24d,_0x4369ba){const _0x320ef5=this['resolveIndex_'](_0x21e24d);return _0x320ef5?_0x320ef5['inorderTraversal'](_0x525794=>_0x4369ba(_0x525794['name'],_0x525794['node'])):this['children_']['inorderTraversal'](_0x4369ba);}['getIterator'](_0x1ae99a){return this['getIteratorFrom'](_0x1ae99a['minPost'](),_0x1ae99a);}['getIteratorFrom'](_0x355fa6,_0x289dae){const _0x1d8a9f=this['resolveIndex_'](_0x289dae);if(_0x1d8a9f)return _0x1d8a9f['getIteratorFrom'](_0x355fa6,_0x291877=>_0x291877);{const _0x1aaecc=this['children_']['getIteratorFrom'](_0x355fa6['name'],E['Wrap']);let _0x1df489=_0x1aaecc['peek']();for(;_0x1df489!=null&&_0x289dae['compare'](_0x1df489,_0x355fa6)<0x0;)_0x1aaecc['getNext'](),_0x1df489=_0x1aaecc['peek']();return _0x1aaecc;}}['getReverseIterator'](_0x46a2e3){return this['getReverseIteratorFrom'](_0x46a2e3['maxPost'](),_0x46a2e3);}['getReverseIteratorFrom'](_0x46389c,_0x1bc9ae){const _0x587c7c=this['resolveIndex_'](_0x1bc9ae);if(_0x587c7c)return _0x587c7c['getReverseIteratorFrom'](_0x46389c,_0xe25068=>_0xe25068);{const _0x350e82=this['children_']['getReverseIteratorFrom'](_0x46389c['name'],E['Wrap']);let _0x2d3b78=_0x350e82['peek']();for(;_0x2d3b78!=null&&_0x1bc9ae['compare'](_0x2d3b78,_0x46389c)>0x0;)_0x350e82['getNext'](),_0x2d3b78=_0x350e82['peek']();return _0x350e82;}}['compareTo'](_0x85b233){return this['isEmpty']()?_0x85b233['isEmpty']()?0x0:-0x1:_0x85b233['isLeafNode']()||_0x85b233['isEmpty']()?0x1:_0x85b233===Ht?-0x1:0x0;}['withIndex'](_0x26fc02){if(_0x26fc02===ye||this['indexMap_']['hasIndex'](_0x26fc02))return this;{const _0x2dbff4=this['indexMap_']['addIndex'](_0x26fc02,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2dbff4);}}['isIndexed'](_0x16b175){return _0x16b175===ye||this['indexMap_']['hasIndex'](_0x16b175);}['equals'](_0x2ff73a){if(_0x2ff73a===this)return!0x0;if(_0x2ff73a['isLeafNode']())return!0x1;{const _0x464af1=_0x2ff73a;if(this['getPriority']()['equals'](_0x464af1['getPriority']())){if(this['children_']['count']()===_0x464af1['children_']['count']()){const _0x20abc7=this['getIterator'](R),_0x289654=_0x464af1['getIterator'](R);let _0x1c4163=_0x20abc7['getNext'](),_0xda311a=_0x289654['getNext']();for(;_0x1c4163&&_0xda311a;){if(_0x1c4163['name']!==_0xda311a['name']||!_0x1c4163['node']['equals'](_0xda311a['node']))return!0x1;_0x1c4163=_0x20abc7['getNext'](),_0xda311a=_0x289654['getNext']();}return _0x1c4163===null&&_0xda311a===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3a2b35){return _0x3a2b35===ye?null:this['indexMap_']['get'](_0x3a2b35['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x236610){return _0x236610===this?0x0:0x1;}['equals'](_0xd94e08){return _0xd94e08===this;}['getPriority'](){return this;}['getImmediateChild'](_0xd0b6cc){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x4e1038,_0x1b0598=null){if(_0x4e1038===null)return g['EMPTY_NODE'];if(typeof _0x4e1038=='object'&&'.priority'in _0x4e1038&&(_0x1b0598=_0x4e1038['.priority']),f(_0x1b0598===null||typeof _0x1b0598=='string'||typeof _0x1b0598=='number'||typeof _0x1b0598=='object'&&'.sv'in _0x1b0598,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1b0598),typeof _0x4e1038=='object'&&'.value'in _0x4e1038&&_0x4e1038['.value']!==null&&(_0x4e1038=_0x4e1038['.value']),typeof _0x4e1038!='object'||'.sv'in _0x4e1038){const _0x8c3cb0=_0x4e1038;return new D(_0x8c3cb0,N(_0x1b0598));}if(!(_0x4e1038 instanceof Array)&&Vh){const _0xec8be3=[];let _0x283032=!0x1;if(x(_0x4e1038,(_0x343b89,_0x1a3531)=>{if(_0x343b89['substring'](0x0,0x1)!=='.'){const _0x49894c=N(_0x1a3531);_0x49894c['isEmpty']()||(_0x283032=_0x283032||!_0x49894c['getPriority']()['isEmpty'](),_0xec8be3['push'](new E(_0x343b89,_0x49894c)));}}),_0xec8be3['length']===0x0)return g['EMPTY_NODE'];const _0x12dc97=dn(_0xec8be3,Dh,_0x2e72a7=>_0x2e72a7['name'],ji);if(_0x283032){const _0xe15584=dn(_0xec8be3,R['getCompare']());return new g(_0x12dc97,N(_0x1b0598),new ee({'.priority':_0xe15584},{'.priority':R}));}else return new g(_0x12dc97,N(_0x1b0598),ee['Default']);}else{let _0xfb5d3f=g['EMPTY_NODE'];return x(_0x4e1038,(_0xf8bd76,_0x2cc7d0)=>{if(Y(_0x4e1038,_0xf8bd76)&&_0xf8bd76['substring'](0x0,0x1)!=='.'){const _0x11e91c=N(_0x2cc7d0);(_0x11e91c['isLeafNode']()||!_0x11e91c['isEmpty']())&&(_0xfb5d3f=_0xfb5d3f['updateImmediateChild'](_0xf8bd76,_0x11e91c));}}),_0xfb5d3f['updatePriority'](N(_0x1b0598));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x1f92c5){super(),this['indexPath_']=_0x1f92c5,f(!v(_0x1f92c5)&&y(_0x1f92c5)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x57d8ce){return _0x57d8ce['getChild'](this['indexPath_']);}['isDefinedOn'](_0x40532b){return!_0x40532b['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5b9baa,_0x5f1542){const _0x53a5ec=this['extractChild'](_0x5b9baa['node']),_0x1932ad=this['extractChild'](_0x5f1542['node']),_0x2f0bd6=_0x53a5ec['compareTo'](_0x1932ad);return _0x2f0bd6===0x0?He(_0x5b9baa['name'],_0x5f1542['name']):_0x2f0bd6;}['makePost'](_0x1d177b,_0x4a8a86){const _0x512ec1=N(_0x1d177b),_0xaec291=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x512ec1);return new E(_0x4a8a86,_0xaec291);}['maxPost'](){const _0x43b2e0=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x43b2e0);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x4a1ae8,_0x134eed){const _0x36b700=_0x4a1ae8['node']['compareTo'](_0x134eed['node']);return _0x36b700===0x0?He(_0x4a1ae8['name'],_0x134eed['name']):_0x36b700;}['isDefinedOn'](_0x4fe158){return!0x0;}['indexedValueChanged'](_0x5a977d,_0x2fb345){return!_0x5a977d['equals'](_0x2fb345);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3b7a8e,_0x22331e){const _0x555abb=N(_0x3b7a8e);return new E(_0x22331e,_0x555abb);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x4c6cf7){return{'type':'value','snapshotNode':_0x4c6cf7};}function tt(_0x2ec618,_0x9f7842){return{'type':'child_added','snapshotNode':_0x9f7842,'childName':_0x2ec618};}function Nt(_0x2ba391,_0x3b656c){return{'type':'child_removed','snapshotNode':_0x3b656c,'childName':_0x2ba391};}function Pt(_0x3435c6,_0x2e49bc,_0x11f372){return{'type':'child_changed','snapshotNode':_0x2e49bc,'childName':_0x3435c6,'oldSnap':_0x11f372};}function $h(_0x236c54,_0xc474b5){return{'type':'child_moved','snapshotNode':_0xc474b5,'childName':_0x236c54};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x42e6a2){this['index_']=_0x42e6a2;}['updateChild'](_0x306845,_0x5609df,_0x49a9f9,_0x10c3a3,_0x28107b,_0x36658e){f(_0x306845['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x5caa8c=_0x306845['getImmediateChild'](_0x5609df);return _0x5caa8c['getChild'](_0x10c3a3)['equals'](_0x49a9f9['getChild'](_0x10c3a3))&&_0x5caa8c['isEmpty']()===_0x49a9f9['isEmpty']()||(_0x36658e!=null&&(_0x49a9f9['isEmpty']()?_0x306845['hasChild'](_0x5609df)?_0x36658e['trackChildChange'](Nt(_0x5609df,_0x5caa8c)):f(_0x306845['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x5caa8c['isEmpty']()?_0x36658e['trackChildChange'](tt(_0x5609df,_0x49a9f9)):_0x36658e['trackChildChange'](Pt(_0x5609df,_0x49a9f9,_0x5caa8c))),_0x306845['isLeafNode']()&&_0x49a9f9['isEmpty']())?_0x306845:_0x306845['updateImmediateChild'](_0x5609df,_0x49a9f9)['withIndex'](this['index_']);}['updateFullNode'](_0x261c6b,_0x33f434,_0xce9d36){return _0xce9d36!=null&&(_0x261c6b['isLeafNode']()||_0x261c6b['forEachChild'](R,(_0x3ea936,_0x47eb42)=>{_0x33f434['hasChild'](_0x3ea936)||_0xce9d36['trackChildChange'](Nt(_0x3ea936,_0x47eb42));}),_0x33f434['isLeafNode']()||_0x33f434['forEachChild'](R,(_0x4fe468,_0x3e1629)=>{if(_0x261c6b['hasChild'](_0x4fe468)){const _0x3481f9=_0x261c6b['getImmediateChild'](_0x4fe468);_0x3481f9['equals'](_0x3e1629)||_0xce9d36['trackChildChange'](Pt(_0x4fe468,_0x3e1629,_0x3481f9));}else _0xce9d36['trackChildChange'](tt(_0x4fe468,_0x3e1629));})),_0x33f434['withIndex'](this['index_']);}['updatePriority'](_0x32900d,_0x2077d6){return _0x32900d['isEmpty']()?g['EMPTY_NODE']:_0x32900d['updatePriority'](_0x2077d6);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x2d494e){this['indexedFilter_']=new Yi(_0x2d494e['getIndex']()),this['index_']=_0x2d494e['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x2d494e),this['endPost_']=Ot['getEndPost_'](_0x2d494e),this['startIsInclusive_']=!_0x2d494e['startAfterSet_'],this['endIsInclusive_']=!_0x2d494e['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x403444){const _0x4a44ff=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x403444)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x403444)<0x0,_0x4708aa=this['endIsInclusive_']?this['index_']['compare'](_0x403444,this['getEndPost']())<=0x0:this['index_']['compare'](_0x403444,this['getEndPost']())<0x0;return _0x4a44ff&&_0x4708aa;}['updateChild'](_0x3eaab5,_0x4ff23d,_0x47cca4,_0x2ecf1f,_0x37e2d1,_0x1b2110){return this['matches'](new E(_0x4ff23d,_0x47cca4))||(_0x47cca4=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x3eaab5,_0x4ff23d,_0x47cca4,_0x2ecf1f,_0x37e2d1,_0x1b2110);}['updateFullNode'](_0x1c510a,_0xd1a2f,_0xaea7a){_0xd1a2f['isLeafNode']()&&(_0xd1a2f=g['EMPTY_NODE']);let _0x411285=_0xd1a2f['withIndex'](this['index_']);_0x411285=_0x411285['updatePriority'](g['EMPTY_NODE']);const _0x2fbc9e=this;return _0xd1a2f['forEachChild'](R,(_0x46145,_0x290fce)=>{_0x2fbc9e['matches'](new E(_0x46145,_0x290fce))||(_0x411285=_0x411285['updateImmediateChild'](_0x46145,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1c510a,_0x411285,_0xaea7a);}['updatePriority'](_0x1e04d1,_0x4e7990){return _0x1e04d1;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x543b1a){if(_0x543b1a['hasStart']()){const _0x1a1f9e=_0x543b1a['getIndexStartName']();return _0x543b1a['getIndex']()['makePost'](_0x543b1a['getIndexStartValue'](),_0x1a1f9e);}else return _0x543b1a['getIndex']()['minPost']();}static['getEndPost_'](_0x2a57b6){if(_0x2a57b6['hasEnd']()){const _0x2c488a=_0x2a57b6['getIndexEndName']();return _0x2a57b6['getIndex']()['makePost'](_0x2a57b6['getIndexEndValue'](),_0x2c488a);}else return _0x2a57b6['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x12bf6e){this['withinDirectionalStart']=_0x1f8587=>this['reverse_']?this['withinEndPost'](_0x1f8587):this['withinStartPost'](_0x1f8587),this['withinDirectionalEnd']=_0x48550b=>this['reverse_']?this['withinStartPost'](_0x48550b):this['withinEndPost'](_0x48550b),this['withinStartPost']=_0x25b4fd=>{const _0x1d3809=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x25b4fd);return this['startIsInclusive_']?_0x1d3809<=0x0:_0x1d3809<0x0;},this['withinEndPost']=_0x421bac=>{const _0x5be0a1=this['index_']['compare'](_0x421bac,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x5be0a1<=0x0:_0x5be0a1<0x0;},this['rangedFilter_']=new Ot(_0x12bf6e),this['index_']=_0x12bf6e['getIndex'](),this['limit_']=_0x12bf6e['getLimit'](),this['reverse_']=!_0x12bf6e['isViewFromLeft'](),this['startIsInclusive_']=!_0x12bf6e['startAfterSet_'],this['endIsInclusive_']=!_0x12bf6e['endBeforeSet_'];}['updateChild'](_0x25b10e,_0x3949b9,_0x189737,_0x4bc8f1,_0x44064f,_0x289925){return this['rangedFilter_']['matches'](new E(_0x3949b9,_0x189737))||(_0x189737=g['EMPTY_NODE']),_0x25b10e['getImmediateChild'](_0x3949b9)['equals'](_0x189737)?_0x25b10e:_0x25b10e['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x25b10e,_0x3949b9,_0x189737,_0x4bc8f1,_0x44064f,_0x289925):this['fullLimitUpdateChild_'](_0x25b10e,_0x3949b9,_0x189737,_0x44064f,_0x289925);}['updateFullNode'](_0x5aef91,_0x47b0b9,_0x4f7c18){let _0x5d522b;if(_0x47b0b9['isLeafNode']()||_0x47b0b9['isEmpty']())_0x5d522b=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x47b0b9['numChildren']()&&_0x47b0b9['isIndexed'](this['index_'])){_0x5d522b=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5389d1;this['reverse_']?_0x5389d1=_0x47b0b9['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5389d1=_0x47b0b9['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x44e558=0x0;for(;_0x5389d1['hasNext']()&&_0x44e558<this['limit_'];){const _0x591633=_0x5389d1['getNext']();if(this['withinDirectionalStart'](_0x591633)){if(this['withinDirectionalEnd'](_0x591633))_0x5d522b=_0x5d522b['updateImmediateChild'](_0x591633['name'],_0x591633['node']),_0x44e558++;else break;}else continue;}}else{_0x5d522b=_0x47b0b9['withIndex'](this['index_']),_0x5d522b=_0x5d522b['updatePriority'](g['EMPTY_NODE']);let _0x159fa9;this['reverse_']?_0x159fa9=_0x5d522b['getReverseIterator'](this['index_']):_0x159fa9=_0x5d522b['getIterator'](this['index_']);let _0x52ad8b=0x0;for(;_0x159fa9['hasNext']();){const _0x53f0cf=_0x159fa9['getNext']();_0x52ad8b<this['limit_']&&this['withinDirectionalStart'](_0x53f0cf)&&this['withinDirectionalEnd'](_0x53f0cf)?_0x52ad8b++:_0x5d522b=_0x5d522b['updateImmediateChild'](_0x53f0cf['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x5aef91,_0x5d522b,_0x4f7c18);}['updatePriority'](_0x21076a,_0x1a4641){return _0x21076a;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2676e6,_0x3f324d,_0x25f3c6,_0x348f09,_0x4eec4b){let _0x2fc30c;if(this['reverse_']){const _0x229734=this['index_']['getCompare']();_0x2fc30c=(_0x23d45f,_0x57d12)=>_0x229734(_0x57d12,_0x23d45f);}else _0x2fc30c=this['index_']['getCompare']();const _0x1b455e=_0x2676e6;f(_0x1b455e['numChildren']()===this['limit_'],'');const _0x4d5e7f=new E(_0x3f324d,_0x25f3c6),_0x4ec74f=this['reverse_']?_0x1b455e['getFirstChild'](this['index_']):_0x1b455e['getLastChild'](this['index_']),_0x10aff5=this['rangedFilter_']['matches'](_0x4d5e7f);if(_0x1b455e['hasChild'](_0x3f324d)){const _0x4a2eef=_0x1b455e['getImmediateChild'](_0x3f324d);let _0x4f059c=_0x348f09['getChildAfterChild'](this['index_'],_0x4ec74f,this['reverse_']);for(;_0x4f059c!=null&&(_0x4f059c['name']===_0x3f324d||_0x1b455e['hasChild'](_0x4f059c['name']));)_0x4f059c=_0x348f09['getChildAfterChild'](this['index_'],_0x4f059c,this['reverse_']);const _0x2498e9=_0x4f059c==null?0x1:_0x2fc30c(_0x4f059c,_0x4d5e7f);if(_0x10aff5&&!_0x25f3c6['isEmpty']()&&_0x2498e9>=0x0)return _0x4eec4b!=null&&_0x4eec4b['trackChildChange'](Pt(_0x3f324d,_0x25f3c6,_0x4a2eef)),_0x1b455e['updateImmediateChild'](_0x3f324d,_0x25f3c6);{_0x4eec4b!=null&&_0x4eec4b['trackChildChange'](Nt(_0x3f324d,_0x4a2eef));const _0x5520d9=_0x1b455e['updateImmediateChild'](_0x3f324d,g['EMPTY_NODE']);return _0x4f059c!=null&&this['rangedFilter_']['matches'](_0x4f059c)?(_0x4eec4b!=null&&_0x4eec4b['trackChildChange'](tt(_0x4f059c['name'],_0x4f059c['node'])),_0x5520d9['updateImmediateChild'](_0x4f059c['name'],_0x4f059c['node'])):_0x5520d9;}}else return _0x25f3c6['isEmpty']()?_0x2676e6:_0x10aff5&&_0x2fc30c(_0x4ec74f,_0x4d5e7f)>=0x0?(_0x4eec4b!=null&&(_0x4eec4b['trackChildChange'](Nt(_0x4ec74f['name'],_0x4ec74f['node'])),_0x4eec4b['trackChildChange'](tt(_0x3f324d,_0x25f3c6))),_0x1b455e['updateImmediateChild'](_0x3f324d,_0x25f3c6)['updateImmediateChild'](_0x4ec74f['name'],g['EMPTY_NODE'])):_0x2676e6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x56add4=new Qi();return _0x56add4['limitSet_']=this['limitSet_'],_0x56add4['limit_']=this['limit_'],_0x56add4['startSet_']=this['startSet_'],_0x56add4['startAfterSet_']=this['startAfterSet_'],_0x56add4['indexStartValue_']=this['indexStartValue_'],_0x56add4['startNameSet_']=this['startNameSet_'],_0x56add4['indexStartName_']=this['indexStartName_'],_0x56add4['endSet_']=this['endSet_'],_0x56add4['endBeforeSet_']=this['endBeforeSet_'],_0x56add4['indexEndValue_']=this['indexEndValue_'],_0x56add4['endNameSet_']=this['endNameSet_'],_0x56add4['indexEndName_']=this['indexEndName_'],_0x56add4['index_']=this['index_'],_0x56add4['viewFrom_']=this['viewFrom_'],_0x56add4;}}function qh(_0x180883){return _0x180883['loadsAllData']()?new Yi(_0x180883['getIndex']()):_0x180883['hasLimit']()?new Gh(_0x180883):new Ot(_0x180883);}function zh(_0x407a36,_0x15e452){const _0x5c0d90=_0x407a36['copy']();return _0x5c0d90['limitSet_']=!0x0,_0x5c0d90['limit_']=_0x15e452,_0x5c0d90['viewFrom_']='l',_0x5c0d90;}function jh(_0x2c7c26,_0x24ede8,_0x58e2a7){const _0x32e5da=_0x2c7c26['copy']();return _0x32e5da['startSet_']=!0x0,_0x24ede8===void 0x0&&(_0x24ede8=null),_0x32e5da['indexStartValue_']=_0x24ede8,_0x58e2a7!=null?(_0x32e5da['startNameSet_']=!0x0,_0x32e5da['indexStartName_']=_0x58e2a7):(_0x32e5da['startNameSet_']=!0x1,_0x32e5da['indexStartName_']=''),_0x32e5da;}function Kh(_0x1c5b62,_0x267aef,_0xd698eb){const _0x435b80=_0x1c5b62['copy']();return _0x435b80['endSet_']=!0x0,_0x267aef===void 0x0&&(_0x267aef=null),_0x435b80['indexEndValue_']=_0x267aef,_0xd698eb!==void 0x0?(_0x435b80['endNameSet_']=!0x0,_0x435b80['indexEndName_']=_0xd698eb):(_0x435b80['endNameSet_']=!0x1,_0x435b80['indexEndName_']=''),_0x435b80;}function Do(_0x2e9067,_0x2896d9){const _0x41e31f=_0x2e9067['copy']();return _0x41e31f['index_']=_0x2896d9,_0x41e31f;}function tr(_0x41693e){const _0x5870a1={};if(_0x41693e['isDefault']())return _0x5870a1;let _0x33f19b;if(_0x41693e['index_']===R?_0x33f19b='$priority':_0x41693e['index_']===Po?_0x33f19b='$value':_0x41693e['index_']===ye?_0x33f19b='$key':(f(_0x41693e['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x33f19b=_0x41693e['index_']['toString']()),_0x5870a1['orderBy']=O(_0x33f19b),_0x41693e['startSet_']){const _0x54eb15=_0x41693e['startAfterSet_']?'startAfter':'startAt';_0x5870a1[_0x54eb15]=O(_0x41693e['indexStartValue_']),_0x41693e['startNameSet_']&&(_0x5870a1[_0x54eb15]+=','+O(_0x41693e['indexStartName_']));}if(_0x41693e['endSet_']){const _0x1e384a=_0x41693e['endBeforeSet_']?'endBefore':'endAt';_0x5870a1[_0x1e384a]=O(_0x41693e['indexEndValue_']),_0x41693e['endNameSet_']&&(_0x5870a1[_0x1e384a]+=','+O(_0x41693e['indexEndName_']));}return _0x41693e['limitSet_']&&(_0x41693e['isViewFromLeft']()?_0x5870a1['limitToFirst']=_0x41693e['limit_']:_0x5870a1['limitToLast']=_0x41693e['limit_']),_0x5870a1;}function nr(_0x188980){const _0xdee8ec={};if(_0x188980['startSet_']&&(_0xdee8ec['sp']=_0x188980['indexStartValue_'],_0x188980['startNameSet_']&&(_0xdee8ec['sn']=_0x188980['indexStartName_']),_0xdee8ec['sin']=!_0x188980['startAfterSet_']),_0x188980['endSet_']&&(_0xdee8ec['ep']=_0x188980['indexEndValue_'],_0x188980['endNameSet_']&&(_0xdee8ec['en']=_0x188980['indexEndName_']),_0xdee8ec['ein']=!_0x188980['endBeforeSet_']),_0x188980['limitSet_']){_0xdee8ec['l']=_0x188980['limit_'];let _0x22b753=_0x188980['viewFrom_'];_0x22b753===''&&(_0x188980['isViewFromLeft']()?_0x22b753='l':_0x22b753='r'),_0xdee8ec['vf']=_0x22b753;}return _0x188980['index_']!==R&&(_0xdee8ec['i']=_0x188980['index_']['toString']()),_0xdee8ec;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x1a1c89){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5bb1ef,_0x2989f6){return _0x2989f6!==void 0x0?'tag$'+_0x2989f6:(f(_0x5bb1ef['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5bb1ef['_path']['toString']());}constructor(_0x3f3419,_0x5a677f,_0xf0606e,_0x28372c){super(),this['repoInfo_']=_0x3f3419,this['onDataUpdate_']=_0x5a677f,this['authTokenProvider_']=_0xf0606e,this['appCheckTokenProvider_']=_0x28372c,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x476716,_0x5ac7a4,_0x409843,_0x51d0ba){const _0x1492dd=_0x476716['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1492dd+'\x20'+_0x476716['_queryIdentifier']);const _0x5cf895=fn['getListenId_'](_0x476716,_0x409843),_0x2a3679={};this['listens_'][_0x5cf895]=_0x2a3679;const _0x5c6322=tr(_0x476716['_queryParams']);this['restRequest_'](_0x1492dd+'.json',_0x5c6322,(_0x4140d9,_0x3f9332)=>{let _0x2261f5=_0x3f9332;if(_0x4140d9===0x194&&(_0x2261f5=null,_0x4140d9=null),_0x4140d9===null&&this['onDataUpdate_'](_0x1492dd,_0x2261f5,!0x1,_0x409843),Oe(this['listens_'],_0x5cf895)===_0x2a3679){let _0x4e9a07;_0x4140d9?_0x4140d9===0x191?_0x4e9a07='permission_denied':_0x4e9a07='rest_error:'+_0x4140d9:_0x4e9a07='ok',_0x51d0ba(_0x4e9a07,null);}});}['unlisten'](_0x110f06,_0x11bd20){const _0x14a844=fn['getListenId_'](_0x110f06,_0x11bd20);delete this['listens_'][_0x14a844];}['get'](_0x20ee85){const _0x4d5171=tr(_0x20ee85['_queryParams']),_0x31990d=_0x20ee85['_path']['toString'](),_0x4dc9db=new Ve();return this['restRequest_'](_0x31990d+'.json',_0x4d5171,(_0xfa9a53,_0x191024)=>{let _0xce4e96=_0x191024;_0xfa9a53===0x194&&(_0xce4e96=null,_0xfa9a53=null),_0xfa9a53===null?(this['onDataUpdate_'](_0x31990d,_0xce4e96,!0x1,null),_0x4dc9db['resolve'](_0xce4e96)):_0x4dc9db['reject'](new Error(_0xce4e96));}),_0x4dc9db['promise'];}['refreshAuthToken'](_0x27cd30){}['restRequest_'](_0x426077,_0x44da37={},_0x2c7074){return _0x44da37['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x571f36,_0x5287f7])=>{_0x571f36&&_0x571f36['accessToken']&&(_0x44da37['auth']=_0x571f36['accessToken']),_0x5287f7&&_0x5287f7['token']&&(_0x44da37['ac']=_0x5287f7['token']);const _0x268075=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x426077+'?ns='+this['repoInfo_']['namespace']+at(_0x44da37);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x268075);const _0x3559c8=new XMLHttpRequest();_0x3559c8['onreadystatechange']=()=>{if(_0x2c7074&&_0x3559c8['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x268075+'\x20received.\x20status:',_0x3559c8['status'],'response:',_0x3559c8['responseText']);let _0x1db51e=null;if(_0x3559c8['status']>=0xc8&&_0x3559c8['status']<0x12c){try{_0x1db51e=bt(_0x3559c8['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x268075+':\x20'+_0x3559c8['responseText']);}_0x2c7074(null,_0x1db51e);}else _0x3559c8['status']!==0x191&&_0x3559c8['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x268075+'\x20Status:\x20'+_0x3559c8['status']),_0x2c7074(_0x3559c8['status']);_0x2c7074=null;}},_0x3559c8['open']('GET',_0x268075,!0x0),_0x3559c8['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x136b0d){return this['rootNode_']['getChild'](_0x136b0d);}['updateSnapshot'](_0x3fa734,_0x2bfc43){this['rootNode_']=this['rootNode_']['updateChild'](_0x3fa734,_0x2bfc43);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0xb46a5c,_0x51a617,_0x2f81d2){if(v(_0x51a617))_0xb46a5c['value']=_0x2f81d2,_0xb46a5c['children']['clear']();else{if(_0xb46a5c['value']!==null)_0xb46a5c['value']=_0xb46a5c['value']['updateChild'](_0x51a617,_0x2f81d2);else{const _0xb096c5=y(_0x51a617);_0xb46a5c['children']['has'](_0xb096c5)||_0xb46a5c['children']['set'](_0xb096c5,pn());const _0x45c7ec=_0xb46a5c['children']['get'](_0xb096c5);_0x51a617=b(_0x51a617),Mo(_0x45c7ec,_0x51a617,_0x2f81d2);}}}function Ei(_0x29d74a,_0x4ed754,_0x390190){_0x29d74a['value']!==null?_0x390190(_0x4ed754,_0x29d74a['value']):Qh(_0x29d74a,(_0x42855b,_0xba6606)=>{const _0x14b670=new C(_0x4ed754['toString']()+'/'+_0x42855b);Ei(_0xba6606,_0x14b670,_0x390190);});}function Qh(_0x2fa85b,_0x420755){_0x2fa85b['children']['forEach']((_0x56bcb2,_0x22635d)=>{_0x420755(_0x22635d,_0x56bcb2);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x267b57){this['collection_']=_0x267b57,this['last_']=null;}['get'](){const _0x4f1857=this['collection_']['get'](),_0x1eab69={..._0x4f1857};return this['last_']&&x(this['last_'],(_0x579953,_0x112bc3)=>{_0x1eab69[_0x579953]=_0x1eab69[_0x579953]-_0x112bc3;}),this['last_']=_0x4f1857,_0x1eab69;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x307e36,_0x579496){this['server_']=_0x579496,this['statsToReport_']={},this['statsListener_']=new Jh(_0x307e36);const _0x1b3942=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x1b3942));}['reportStats_'](){const _0x3950ca=this['statsListener_']['get'](),_0xbc232d={};let _0x20c78c=!0x1;x(_0x3950ca,(_0x3aef7a,_0x27ad46)=>{_0x27ad46>0x0&&Y(this['statsToReport_'],_0x3aef7a)&&(_0xbc232d[_0x3aef7a]=_0x27ad46,_0x20c78c=!0x0);}),_0x20c78c&&this['server_']['reportStats'](_0xbc232d),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x59fb0a){_0x59fb0a[_0x59fb0a['OVERWRITE']=0x0]='OVERWRITE',_0x59fb0a[_0x59fb0a['MERGE']=0x1]='MERGE',_0x59fb0a[_0x59fb0a['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x59fb0a[_0x59fb0a['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x28ef37){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x28ef37,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x126b96,_0x2c6429,_0x7df966){this['path']=_0x126b96,this['affectedTree']=_0x2c6429,this['revert']=_0x7df966,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x438c24){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2e1462=this['affectedTree']['subtree'](new C(_0x438c24));return new _n(w(),_0x2e1462,this['revert']);}}else return f(y(this['path'])===_0x438c24,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x2e280b,_0x571f2e){this['source']=_0x2e280b,this['path']=_0x571f2e,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x418c9a){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x4697fa,_0x1d4845,_0x310eeb){this['source']=_0x4697fa,this['path']=_0x1d4845,this['snap']=_0x310eeb,this['type']=q['OVERWRITE'];}['operationForChild'](_0x273627){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x273627)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x5602fd,_0x20cd5b,_0x5c2e8f){this['source']=_0x5602fd,this['path']=_0x20cd5b,this['children']=_0x5c2e8f,this['type']=q['MERGE'];}['operationForChild'](_0x4f8b5a){if(v(this['path'])){const _0x52110e=this['children']['subtree'](new C(_0x4f8b5a));return _0x52110e['isEmpty']()?null:_0x52110e['value']?new Fe(this['source'],w(),_0x52110e['value']):new nt(this['source'],w(),_0x52110e);}else return f(y(this['path'])===_0x4f8b5a,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x19ce77,_0x4d6e65,_0x339907){this['node_']=_0x19ce77,this['fullyInitialized_']=_0x4d6e65,this['filtered_']=_0x339907;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x26c6ca){if(v(_0x26c6ca))return this['isFullyInitialized']()&&!this['filtered_'];const _0x17b363=y(_0x26c6ca);return this['isCompleteForChild'](_0x17b363);}['isCompleteForChild'](_0x1c4ad8){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1c4ad8);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x224de9){this['query_']=_0x224de9,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x37746c,_0x454ce4,_0x1bfcf7,_0x3215bd){const _0x36dd71=[],_0x5f24ac=[];return _0x454ce4['forEach'](_0x4bb1aa=>{_0x4bb1aa['type']==='child_changed'&&_0x37746c['index_']['indexedValueChanged'](_0x4bb1aa['oldSnap'],_0x4bb1aa['snapshotNode'])&&_0x5f24ac['push']($h(_0x4bb1aa['childName'],_0x4bb1aa['snapshotNode']));}),mt(_0x37746c,_0x36dd71,'child_removed',_0x454ce4,_0x3215bd,_0x1bfcf7),mt(_0x37746c,_0x36dd71,'child_added',_0x454ce4,_0x3215bd,_0x1bfcf7),mt(_0x37746c,_0x36dd71,'child_moved',_0x5f24ac,_0x3215bd,_0x1bfcf7),mt(_0x37746c,_0x36dd71,'child_changed',_0x454ce4,_0x3215bd,_0x1bfcf7),mt(_0x37746c,_0x36dd71,'value',_0x454ce4,_0x3215bd,_0x1bfcf7),_0x36dd71;}function mt(_0x45640b,_0x4155db,_0x861b5c,_0x163d6f,_0x1f29c5,_0x29b7e7){const _0x5dde7c=_0x163d6f['filter'](_0x2c7631=>_0x2c7631['type']===_0x861b5c);_0x5dde7c['sort']((_0x326e46,_0x57cd65)=>su(_0x45640b,_0x326e46,_0x57cd65)),_0x5dde7c['forEach'](_0x164d07=>{const _0x2d776f=iu(_0x45640b,_0x164d07,_0x29b7e7);_0x1f29c5['forEach'](_0x262590=>{_0x262590['respondsTo'](_0x164d07['type'])&&_0x4155db['push'](_0x262590['createEvent'](_0x2d776f,_0x45640b['query_']));});});}function iu(_0x5b2b0f,_0x2b6e2b,_0x6bd36e){return _0x2b6e2b['type']==='value'||_0x2b6e2b['type']==='child_removed'||(_0x2b6e2b['prevName']=_0x6bd36e['getPredecessorChildName'](_0x2b6e2b['childName'],_0x2b6e2b['snapshotNode'],_0x5b2b0f['index_'])),_0x2b6e2b;}function su(_0x3f6b38,_0x2e5e7c,_0x3ad2d0){if(_0x2e5e7c['childName']==null||_0x3ad2d0['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0xcdda7c=new E(_0x2e5e7c['childName'],_0x2e5e7c['snapshotNode']),_0x5a12ba=new E(_0x3ad2d0['childName'],_0x3ad2d0['snapshotNode']);return _0x3f6b38['index_']['compare'](_0xcdda7c,_0x5a12ba);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x124116,_0x2f25d2){return{'eventCache':_0x124116,'serverCache':_0x2f25d2};}function wt(_0x58ad18,_0x19ae34,_0xcbd5c9,_0x1a0c5a){return Dn(new Ce(_0x19ae34,_0xcbd5c9,_0x1a0c5a),_0x58ad18['serverCache']);}function Lo(_0x488377,_0x37af09,_0x40127a,_0x4e8392){return Dn(_0x488377['eventCache'],new Ce(_0x37af09,_0x40127a,_0x4e8392));}function gn(_0x11d874){return _0x11d874['eventCache']['isFullyInitialized']()?_0x11d874['eventCache']['getNode']():null;}function Ue(_0x390624){return _0x390624['serverCache']['isFullyInitialized']()?_0x390624['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x177964){let _0x412fd2=new S(null);return x(_0x177964,(_0x2bf434,_0x14438e)=>{_0x412fd2=_0x412fd2['set'](new C(_0x2bf434),_0x14438e);}),_0x412fd2;}constructor(_0x4083b8,_0x3ed986=ru()){this['value']=_0x4083b8,this['children']=_0x3ed986;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3e73ab,_0x18d531){if(this['value']!=null&&_0x18d531(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3e73ab))return null;{const _0xde6fc5=y(_0x3e73ab),_0x29b082=this['children']['get'](_0xde6fc5);if(_0x29b082!==null){const _0x4f0f4f=_0x29b082['findRootMostMatchingPathAndValue'](b(_0x3e73ab),_0x18d531);return _0x4f0f4f!=null?{'path':A(new C(_0xde6fc5),_0x4f0f4f['path']),'value':_0x4f0f4f['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1f5e7a){return this['findRootMostMatchingPathAndValue'](_0x1f5e7a,()=>!0x0);}['subtree'](_0x587caa){if(v(_0x587caa))return this;{const _0x496aea=y(_0x587caa),_0x293080=this['children']['get'](_0x496aea);return _0x293080!==null?_0x293080['subtree'](b(_0x587caa)):new S(null);}}['set'](_0x18ea7e,_0x3bc4db){if(v(_0x18ea7e))return new S(_0x3bc4db,this['children']);{const _0x2242d2=y(_0x18ea7e),_0x5356f4=(this['children']['get'](_0x2242d2)||new S(null))['set'](b(_0x18ea7e),_0x3bc4db),_0x45b533=this['children']['insert'](_0x2242d2,_0x5356f4);return new S(this['value'],_0x45b533);}}['remove'](_0x3b69de){if(v(_0x3b69de))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x4b6fc9=y(_0x3b69de),_0x547488=this['children']['get'](_0x4b6fc9);if(_0x547488){const _0x70259e=_0x547488['remove'](b(_0x3b69de));let _0x3b8dbf;return _0x70259e['isEmpty']()?_0x3b8dbf=this['children']['remove'](_0x4b6fc9):_0x3b8dbf=this['children']['insert'](_0x4b6fc9,_0x70259e),this['value']===null&&_0x3b8dbf['isEmpty']()?new S(null):new S(this['value'],_0x3b8dbf);}else return this;}}['get'](_0x22d5f7){if(v(_0x22d5f7))return this['value'];{const _0x2b7d37=y(_0x22d5f7),_0x40c951=this['children']['get'](_0x2b7d37);return _0x40c951?_0x40c951['get'](b(_0x22d5f7)):null;}}['setTree'](_0x59e253,_0x4796d1){if(v(_0x59e253))return _0x4796d1;{const _0x414764=y(_0x59e253),_0x208210=(this['children']['get'](_0x414764)||new S(null))['setTree'](b(_0x59e253),_0x4796d1);let _0x3a9f53;return _0x208210['isEmpty']()?_0x3a9f53=this['children']['remove'](_0x414764):_0x3a9f53=this['children']['insert'](_0x414764,_0x208210),new S(this['value'],_0x3a9f53);}}['fold'](_0xb6fc2b){return this['fold_'](w(),_0xb6fc2b);}['fold_'](_0x2a197d,_0x19ff2b){const _0x4808bb={};return this['children']['inorderTraversal']((_0x489c05,_0x14bc7c)=>{_0x4808bb[_0x489c05]=_0x14bc7c['fold_'](A(_0x2a197d,_0x489c05),_0x19ff2b);}),_0x19ff2b(_0x2a197d,this['value'],_0x4808bb);}['findOnPath'](_0x1f8ccc,_0x2abedf){return this['findOnPath_'](_0x1f8ccc,w(),_0x2abedf);}['findOnPath_'](_0x2314b0,_0x17b2b5,_0x59bfce){const _0x29e0e5=this['value']?_0x59bfce(_0x17b2b5,this['value']):!0x1;if(_0x29e0e5)return _0x29e0e5;if(v(_0x2314b0))return null;{const _0x2fc27d=y(_0x2314b0),_0x5c2757=this['children']['get'](_0x2fc27d);return _0x5c2757?_0x5c2757['findOnPath_'](b(_0x2314b0),A(_0x17b2b5,_0x2fc27d),_0x59bfce):null;}}['foreachOnPath'](_0x2da4d4,_0x301376){return this['foreachOnPath_'](_0x2da4d4,w(),_0x301376);}['foreachOnPath_'](_0x121577,_0x1a38aa,_0x3eea5e){if(v(_0x121577))return this;{this['value']&&_0x3eea5e(_0x1a38aa,this['value']);const _0x2d7033=y(_0x121577),_0x53f07b=this['children']['get'](_0x2d7033);return _0x53f07b?_0x53f07b['foreachOnPath_'](b(_0x121577),A(_0x1a38aa,_0x2d7033),_0x3eea5e):new S(null);}}['foreach'](_0x3c55ea){this['foreach_'](w(),_0x3c55ea);}['foreach_'](_0x44a115,_0x53e5a0){this['children']['inorderTraversal']((_0x2b17b1,_0x239141)=>{_0x239141['foreach_'](A(_0x44a115,_0x2b17b1),_0x53e5a0);}),this['value']&&_0x53e5a0(_0x44a115,this['value']);}['foreachChild'](_0x534885){this['children']['inorderTraversal']((_0x304579,_0xd842a4)=>{_0xd842a4['value']&&_0x534885(_0x304579,_0xd842a4['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0xd4a204){this['writeTree_']=_0xd4a204;}static['empty'](){return new j(new S(null));}}function Ct(_0x66efe,_0x2ea415,_0x408964){if(v(_0x2ea415))return new j(new S(_0x408964));{const _0x1994d8=_0x66efe['writeTree_']['findRootMostValueAndPath'](_0x2ea415);if(_0x1994d8!=null){const _0x58bda2=_0x1994d8['path'];let _0x512b=_0x1994d8['value'];const _0x4c03a3=F(_0x58bda2,_0x2ea415);return _0x512b=_0x512b['updateChild'](_0x4c03a3,_0x408964),new j(_0x66efe['writeTree_']['set'](_0x58bda2,_0x512b));}else{const _0x52e3f1=new S(_0x408964),_0x565b22=_0x66efe['writeTree_']['setTree'](_0x2ea415,_0x52e3f1);return new j(_0x565b22);}}}function Ii(_0x17cb88,_0x39193a,_0xb0ab1c){let _0x2eb47f=_0x17cb88;return x(_0xb0ab1c,(_0x5d4bcd,_0x284341)=>{_0x2eb47f=Ct(_0x2eb47f,A(_0x39193a,_0x5d4bcd),_0x284341);}),_0x2eb47f;}function sr(_0x14190e,_0x3cd69e){if(v(_0x3cd69e))return j['empty']();{const _0x1e8a48=_0x14190e['writeTree_']['setTree'](_0x3cd69e,new S(null));return new j(_0x1e8a48);}}function wi(_0x4a5952,_0x245786){return $e(_0x4a5952,_0x245786)!=null;}function $e(_0x488528,_0x5c3b1b){const _0x3e7ec5=_0x488528['writeTree_']['findRootMostValueAndPath'](_0x5c3b1b);return _0x3e7ec5!=null?_0x488528['writeTree_']['get'](_0x3e7ec5['path'])['getChild'](F(_0x3e7ec5['path'],_0x5c3b1b)):null;}function rr(_0x1b7a18){const _0x20ec3c=[],_0xb456c=_0x1b7a18['writeTree_']['value'];return _0xb456c!=null?_0xb456c['isLeafNode']()||_0xb456c['forEachChild'](R,(_0x3cb431,_0x18997f)=>{_0x20ec3c['push'](new E(_0x3cb431,_0x18997f));}):_0x1b7a18['writeTree_']['children']['inorderTraversal']((_0x3b7f36,_0x29452b)=>{_0x29452b['value']!=null&&_0x20ec3c['push'](new E(_0x3b7f36,_0x29452b['value']));}),_0x20ec3c;}function ve(_0xdae0cd,_0x49ca1e){if(v(_0x49ca1e))return _0xdae0cd;{const _0xb20ff0=$e(_0xdae0cd,_0x49ca1e);return _0xb20ff0!=null?new j(new S(_0xb20ff0)):new j(_0xdae0cd['writeTree_']['subtree'](_0x49ca1e));}}function Ci(_0x482a1b){return _0x482a1b['writeTree_']['isEmpty']();}function it(_0x5c3913,_0x2a354e){return xo(w(),_0x5c3913['writeTree_'],_0x2a354e);}function xo(_0x18ccb8,_0x4c708e,_0xc1c683){if(_0x4c708e['value']!=null)return _0xc1c683['updateChild'](_0x18ccb8,_0x4c708e['value']);{let _0x471016=null;return _0x4c708e['children']['inorderTraversal']((_0x5df54e,_0x48ae50)=>{_0x5df54e==='.priority'?(f(_0x48ae50['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x471016=_0x48ae50['value']):_0xc1c683=xo(A(_0x18ccb8,_0x5df54e),_0x48ae50,_0xc1c683);}),!_0xc1c683['getChild'](_0x18ccb8)['isEmpty']()&&_0x471016!==null&&(_0xc1c683=_0xc1c683['updateChild'](A(_0x18ccb8,'.priority'),_0x471016)),_0xc1c683;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x5590a2,_0x8542ca){return Bo(_0x8542ca,_0x5590a2);}function ou(_0x55e06d,_0x122412,_0x12fe7e,_0x146504,_0x446c0a){f(_0x146504>_0x55e06d['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x446c0a===void 0x0&&(_0x446c0a=!0x0),_0x55e06d['allWrites']['push']({'path':_0x122412,'snap':_0x12fe7e,'writeId':_0x146504,'visible':_0x446c0a}),_0x446c0a&&(_0x55e06d['visibleWrites']=Ct(_0x55e06d['visibleWrites'],_0x122412,_0x12fe7e)),_0x55e06d['lastWriteId']=_0x146504;}function au(_0x4f852f,_0x42c3f9,_0x25135a,_0x481d60){f(_0x481d60>_0x4f852f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4f852f['allWrites']['push']({'path':_0x42c3f9,'children':_0x25135a,'writeId':_0x481d60,'visible':!0x0}),_0x4f852f['visibleWrites']=Ii(_0x4f852f['visibleWrites'],_0x42c3f9,_0x25135a),_0x4f852f['lastWriteId']=_0x481d60;}function cu(_0x2dac6f,_0x4e29a4){for(let _0x1726ea=0x0;_0x1726ea<_0x2dac6f['allWrites']['length'];_0x1726ea++){const _0xf6c5a5=_0x2dac6f['allWrites'][_0x1726ea];if(_0xf6c5a5['writeId']===_0x4e29a4)return _0xf6c5a5;}return null;}function lu(_0x446d92,_0x1b676e){const _0x9015e9=_0x446d92['allWrites']['findIndex'](_0x504d6c=>_0x504d6c['writeId']===_0x1b676e);f(_0x9015e9>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4d0b10=_0x446d92['allWrites'][_0x9015e9];_0x446d92['allWrites']['splice'](_0x9015e9,0x1);let _0x11871e=_0x4d0b10['visible'],_0x4debe0=!0x1,_0x4fbba4=_0x446d92['allWrites']['length']-0x1;for(;_0x11871e&&_0x4fbba4>=0x0;){const _0x41ef7e=_0x446d92['allWrites'][_0x4fbba4];_0x41ef7e['visible']&&(_0x4fbba4>=_0x9015e9&&hu(_0x41ef7e,_0x4d0b10['path'])?_0x11871e=!0x1:$(_0x4d0b10['path'],_0x41ef7e['path'])&&(_0x4debe0=!0x0)),_0x4fbba4--;}if(_0x11871e){if(_0x4debe0)return uu(_0x446d92),!0x0;if(_0x4d0b10['snap'])_0x446d92['visibleWrites']=sr(_0x446d92['visibleWrites'],_0x4d0b10['path']);else{const _0x8abaec=_0x4d0b10['children'];x(_0x8abaec,_0x3c273d=>{_0x446d92['visibleWrites']=sr(_0x446d92['visibleWrites'],A(_0x4d0b10['path'],_0x3c273d));});}return!0x0;}else return!0x1;}function hu(_0x5245f2,_0x3c40b8){if(_0x5245f2['snap'])return $(_0x5245f2['path'],_0x3c40b8);for(const _0xd18414 in _0x5245f2['children'])if(_0x5245f2['children']['hasOwnProperty'](_0xd18414)&&$(A(_0x5245f2['path'],_0xd18414),_0x3c40b8))return!0x0;return!0x1;}function uu(_0x179ad9){_0x179ad9['visibleWrites']=Fo(_0x179ad9['allWrites'],du,w()),_0x179ad9['allWrites']['length']>0x0?_0x179ad9['lastWriteId']=_0x179ad9['allWrites'][_0x179ad9['allWrites']['length']-0x1]['writeId']:_0x179ad9['lastWriteId']=-0x1;}function du(_0x251007){return _0x251007['visible'];}function Fo(_0x5cadcb,_0x353c99,_0x5e3a45){let _0x40b890=j['empty']();for(let _0x34b941=0x0;_0x34b941<_0x5cadcb['length'];++_0x34b941){const _0x52b86e=_0x5cadcb[_0x34b941];if(_0x353c99(_0x52b86e)){const _0x23916e=_0x52b86e['path'];let _0xa9fb30;if(_0x52b86e['snap'])$(_0x5e3a45,_0x23916e)?(_0xa9fb30=F(_0x5e3a45,_0x23916e),_0x40b890=Ct(_0x40b890,_0xa9fb30,_0x52b86e['snap'])):$(_0x23916e,_0x5e3a45)&&(_0xa9fb30=F(_0x23916e,_0x5e3a45),_0x40b890=Ct(_0x40b890,w(),_0x52b86e['snap']['getChild'](_0xa9fb30)));else{if(_0x52b86e['children']){if($(_0x5e3a45,_0x23916e))_0xa9fb30=F(_0x5e3a45,_0x23916e),_0x40b890=Ii(_0x40b890,_0xa9fb30,_0x52b86e['children']);else{if($(_0x23916e,_0x5e3a45)){if(_0xa9fb30=F(_0x23916e,_0x5e3a45),v(_0xa9fb30))_0x40b890=Ii(_0x40b890,w(),_0x52b86e['children']);else{const _0x2d7c21=Oe(_0x52b86e['children'],y(_0xa9fb30));if(_0x2d7c21){const _0x224ef5=_0x2d7c21['getChild'](b(_0xa9fb30));_0x40b890=Ct(_0x40b890,w(),_0x224ef5);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x40b890;}function Uo(_0x3b5d46,_0x48db5e,_0x4dca9a,_0x591546,_0x3d723a){if(!_0x591546&&!_0x3d723a){const _0x55c872=$e(_0x3b5d46['visibleWrites'],_0x48db5e);if(_0x55c872!=null)return _0x55c872;{const _0x514b03=ve(_0x3b5d46['visibleWrites'],_0x48db5e);if(Ci(_0x514b03))return _0x4dca9a;if(_0x4dca9a==null&&!wi(_0x514b03,w()))return null;{const _0x367a06=_0x4dca9a||g['EMPTY_NODE'];return it(_0x514b03,_0x367a06);}}}else{const _0x4ce48c=ve(_0x3b5d46['visibleWrites'],_0x48db5e);if(!_0x3d723a&&Ci(_0x4ce48c))return _0x4dca9a;if(!_0x3d723a&&_0x4dca9a==null&&!wi(_0x4ce48c,w()))return null;{const _0x433e81=function(_0x25411d){return(_0x25411d['visible']||_0x3d723a)&&(!_0x591546||!~_0x591546['indexOf'](_0x25411d['writeId']))&&($(_0x25411d['path'],_0x48db5e)||$(_0x48db5e,_0x25411d['path']));},_0x150cbb=Fo(_0x3b5d46['allWrites'],_0x433e81,_0x48db5e),_0x3f1c3a=_0x4dca9a||g['EMPTY_NODE'];return it(_0x150cbb,_0x3f1c3a);}}}function fu(_0x42b986,_0x5d015b,_0x4c6b99){let _0x2b89f7=g['EMPTY_NODE'];const _0x3a5d99=$e(_0x42b986['visibleWrites'],_0x5d015b);if(_0x3a5d99)return _0x3a5d99['isLeafNode']()||_0x3a5d99['forEachChild'](R,(_0x13790e,_0x155526)=>{_0x2b89f7=_0x2b89f7['updateImmediateChild'](_0x13790e,_0x155526);}),_0x2b89f7;if(_0x4c6b99){const _0x3c40ed=ve(_0x42b986['visibleWrites'],_0x5d015b);return _0x4c6b99['forEachChild'](R,(_0x534895,_0x33a195)=>{const _0x2700da=it(ve(_0x3c40ed,new C(_0x534895)),_0x33a195);_0x2b89f7=_0x2b89f7['updateImmediateChild'](_0x534895,_0x2700da);}),rr(_0x3c40ed)['forEach'](_0x2c9c0d=>{_0x2b89f7=_0x2b89f7['updateImmediateChild'](_0x2c9c0d['name'],_0x2c9c0d['node']);}),_0x2b89f7;}else{const _0x46fc50=ve(_0x42b986['visibleWrites'],_0x5d015b);return rr(_0x46fc50)['forEach'](_0x4939cd=>{_0x2b89f7=_0x2b89f7['updateImmediateChild'](_0x4939cd['name'],_0x4939cd['node']);}),_0x2b89f7;}}function pu(_0x325cea,_0x30952e,_0x3c023f,_0x318e98,_0x168569){f(_0x318e98||_0x168569,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x536a6f=A(_0x30952e,_0x3c023f);if(wi(_0x325cea['visibleWrites'],_0x536a6f))return null;{const _0x746e93=ve(_0x325cea['visibleWrites'],_0x536a6f);return Ci(_0x746e93)?_0x168569['getChild'](_0x3c023f):it(_0x746e93,_0x168569['getChild'](_0x3c023f));}}function _u(_0x5d137f,_0x314f4d,_0xd5ebe9,_0x49b9d5){const _0x4853f9=A(_0x314f4d,_0xd5ebe9),_0x4989c9=$e(_0x5d137f['visibleWrites'],_0x4853f9);if(_0x4989c9!=null)return _0x4989c9;if(_0x49b9d5['isCompleteForChild'](_0xd5ebe9)){const _0x555a96=ve(_0x5d137f['visibleWrites'],_0x4853f9);return it(_0x555a96,_0x49b9d5['getNode']()['getImmediateChild'](_0xd5ebe9));}else return null;}function gu(_0x354ab4,_0x399298){return $e(_0x354ab4['visibleWrites'],_0x399298);}function mu(_0x4bacec,_0x190ac2,_0x1c3398,_0x118a50,_0x5831bb,_0x3057b2,_0x33fdfa){let _0x5ca708;const _0xb89b2c=ve(_0x4bacec['visibleWrites'],_0x190ac2),_0x1fb71a=$e(_0xb89b2c,w());if(_0x1fb71a!=null)_0x5ca708=_0x1fb71a;else{if(_0x1c3398!=null)_0x5ca708=it(_0xb89b2c,_0x1c3398);else return[];}if(_0x5ca708=_0x5ca708['withIndex'](_0x33fdfa),!_0x5ca708['isEmpty']()&&!_0x5ca708['isLeafNode']()){const _0x40e0b0=[],_0x5aa041=_0x33fdfa['getCompare'](),_0x3d5ab8=_0x3057b2?_0x5ca708['getReverseIteratorFrom'](_0x118a50,_0x33fdfa):_0x5ca708['getIteratorFrom'](_0x118a50,_0x33fdfa);let _0x38ad6e=_0x3d5ab8['getNext']();for(;_0x38ad6e&&_0x40e0b0['length']<_0x5831bb;)_0x5aa041(_0x38ad6e,_0x118a50)!==0x0&&_0x40e0b0['push'](_0x38ad6e),_0x38ad6e=_0x3d5ab8['getNext']();return _0x40e0b0;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x5cfc46,_0x1f1477,_0x21ca9b,_0x145a1d){return Uo(_0x5cfc46['writeTree'],_0x5cfc46['treePath'],_0x1f1477,_0x21ca9b,_0x145a1d);}function es(_0x342ace,_0x465fb5){return fu(_0x342ace['writeTree'],_0x342ace['treePath'],_0x465fb5);}function or(_0x224e23,_0x2de8cc,_0x214792,_0xd9dfcd){return pu(_0x224e23['writeTree'],_0x224e23['treePath'],_0x2de8cc,_0x214792,_0xd9dfcd);}function yn(_0x135ddf,_0x5f2948){return gu(_0x135ddf['writeTree'],A(_0x135ddf['treePath'],_0x5f2948));}function vu(_0x1992f6,_0x1bf929,_0x84c8b,_0x391bb2,_0x3d5b0a,_0xb8d3ad){return mu(_0x1992f6['writeTree'],_0x1992f6['treePath'],_0x1bf929,_0x84c8b,_0x391bb2,_0x3d5b0a,_0xb8d3ad);}function ts(_0x5481bb,_0x4ba8f1,_0x489aad){return _u(_0x5481bb['writeTree'],_0x5481bb['treePath'],_0x4ba8f1,_0x489aad);}function Wo(_0x56bd1b,_0x3c69ab){return Bo(A(_0x56bd1b['treePath'],_0x3c69ab),_0x56bd1b['writeTree']);}function Bo(_0x549d6c,_0x1972b3){return{'treePath':_0x549d6c,'writeTree':_0x1972b3};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4cdf5a){const _0x2f9159=_0x4cdf5a['type'],_0x58b5fd=_0x4cdf5a['childName'];f(_0x2f9159==='child_added'||_0x2f9159==='child_changed'||_0x2f9159==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x58b5fd!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x500fee=this['changeMap']['get'](_0x58b5fd);if(_0x500fee){const _0x4b5a28=_0x500fee['type'];if(_0x2f9159==='child_added'&&_0x4b5a28==='child_removed')this['changeMap']['set'](_0x58b5fd,Pt(_0x58b5fd,_0x4cdf5a['snapshotNode'],_0x500fee['snapshotNode']));else{if(_0x2f9159==='child_removed'&&_0x4b5a28==='child_added')this['changeMap']['delete'](_0x58b5fd);else{if(_0x2f9159==='child_removed'&&_0x4b5a28==='child_changed')this['changeMap']['set'](_0x58b5fd,Nt(_0x58b5fd,_0x500fee['oldSnap']));else{if(_0x2f9159==='child_changed'&&_0x4b5a28==='child_added')this['changeMap']['set'](_0x58b5fd,tt(_0x58b5fd,_0x4cdf5a['snapshotNode']));else{if(_0x2f9159==='child_changed'&&_0x4b5a28==='child_changed')this['changeMap']['set'](_0x58b5fd,Pt(_0x58b5fd,_0x4cdf5a['snapshotNode'],_0x500fee['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x4cdf5a+'\x20occurred\x20after\x20'+_0x500fee);}}}}}else this['changeMap']['set'](_0x58b5fd,_0x4cdf5a);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x24298c){return null;}['getChildAfterChild'](_0x49951c,_0x37f697,_0x10218a){return null;}}const Vo=new Iu();class ns{constructor(_0x584c85,_0x3aa764,_0x125d29=null){this['writes_']=_0x584c85,this['viewCache_']=_0x3aa764,this['optCompleteServerCache_']=_0x125d29;}['getCompleteChild'](_0x51ed9b){const _0x19c0ef=this['viewCache_']['eventCache'];if(_0x19c0ef['isCompleteForChild'](_0x51ed9b))return _0x19c0ef['getNode']()['getImmediateChild'](_0x51ed9b);{const _0x29df2b=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x51ed9b,_0x29df2b);}}['getChildAfterChild'](_0x1c34df,_0x4e52ac,_0x80d6c){const _0x308a1e=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x448e69=vu(this['writes_'],_0x308a1e,_0x4e52ac,0x1,_0x80d6c,_0x1c34df);return _0x448e69['length']===0x0?null:_0x448e69[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x1887b7){return{'filter':_0x1887b7};}function Cu(_0x3f845b,_0x450ea0){f(_0x450ea0['eventCache']['getNode']()['isIndexed'](_0x3f845b['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x450ea0['serverCache']['getNode']()['isIndexed'](_0x3f845b['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x5957b8,_0x489946,_0x2cbd1c,_0x5b7b1b,_0x452a96){const _0x589591=new Eu();let _0x5e14e8,_0x5fe9fc;if(_0x2cbd1c['type']===q['OVERWRITE']){const _0x455416=_0x2cbd1c;_0x455416['source']['fromUser']?_0x5e14e8=Ti(_0x5957b8,_0x489946,_0x455416['path'],_0x455416['snap'],_0x5b7b1b,_0x452a96,_0x589591):(f(_0x455416['source']['fromServer'],'Unknown\x20source.'),_0x5fe9fc=_0x455416['source']['tagged']||_0x489946['serverCache']['isFiltered']()&&!v(_0x455416['path']),_0x5e14e8=vn(_0x5957b8,_0x489946,_0x455416['path'],_0x455416['snap'],_0x5b7b1b,_0x452a96,_0x5fe9fc,_0x589591));}else{if(_0x2cbd1c['type']===q['MERGE']){const _0x2911d0=_0x2cbd1c;_0x2911d0['source']['fromUser']?_0x5e14e8=bu(_0x5957b8,_0x489946,_0x2911d0['path'],_0x2911d0['children'],_0x5b7b1b,_0x452a96,_0x589591):(f(_0x2911d0['source']['fromServer'],'Unknown\x20source.'),_0x5fe9fc=_0x2911d0['source']['tagged']||_0x489946['serverCache']['isFiltered'](),_0x5e14e8=Si(_0x5957b8,_0x489946,_0x2911d0['path'],_0x2911d0['children'],_0x5b7b1b,_0x452a96,_0x5fe9fc,_0x589591));}else{if(_0x2cbd1c['type']===q['ACK_USER_WRITE']){const _0x6789bb=_0x2cbd1c;_0x6789bb['revert']?_0x5e14e8=ku(_0x5957b8,_0x489946,_0x6789bb['path'],_0x5b7b1b,_0x452a96,_0x589591):_0x5e14e8=Ru(_0x5957b8,_0x489946,_0x6789bb['path'],_0x6789bb['affectedTree'],_0x5b7b1b,_0x452a96,_0x589591);}else{if(_0x2cbd1c['type']===q['LISTEN_COMPLETE'])_0x5e14e8=Au(_0x5957b8,_0x489946,_0x2cbd1c['path'],_0x5b7b1b,_0x589591);else throw ot('Unknown\x20operation\x20type:\x20'+_0x2cbd1c['type']);}}}const _0x4d5a3b=_0x589591['getChanges']();return Su(_0x489946,_0x5e14e8,_0x4d5a3b),{'viewCache':_0x5e14e8,'changes':_0x4d5a3b};}function Su(_0x5d76fc,_0x3dd246,_0x37de26){const _0x3f79db=_0x3dd246['eventCache'];if(_0x3f79db['isFullyInitialized']()){const _0x2fbb13=_0x3f79db['getNode']()['isLeafNode']()||_0x3f79db['getNode']()['isEmpty'](),_0x181666=gn(_0x5d76fc);(_0x37de26['length']>0x0||!_0x5d76fc['eventCache']['isFullyInitialized']()||_0x2fbb13&&!_0x3f79db['getNode']()['equals'](_0x181666)||!_0x3f79db['getNode']()['getPriority']()['equals'](_0x181666['getPriority']()))&&_0x37de26['push'](Oo(gn(_0x3dd246)));}}function Ho(_0x34a8a0,_0x17b4b5,_0x1bf8c3,_0x4878c2,_0x1b1898,_0x2cd92d){const _0x3104d0=_0x17b4b5['eventCache'];if(yn(_0x4878c2,_0x1bf8c3)!=null)return _0x17b4b5;{let _0x48af11,_0x565c96;if(v(_0x1bf8c3)){if(f(_0x17b4b5['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x17b4b5['serverCache']['isFiltered']()){const _0x4ecc79=Ue(_0x17b4b5),_0x22e0cf=_0x4ecc79 instanceof g?_0x4ecc79:g['EMPTY_NODE'],_0x18e74c=es(_0x4878c2,_0x22e0cf);_0x48af11=_0x34a8a0['filter']['updateFullNode'](_0x17b4b5['eventCache']['getNode'](),_0x18e74c,_0x2cd92d);}else{const _0x43d7b0=mn(_0x4878c2,Ue(_0x17b4b5));_0x48af11=_0x34a8a0['filter']['updateFullNode'](_0x17b4b5['eventCache']['getNode'](),_0x43d7b0,_0x2cd92d);}}else{const _0x46f759=y(_0x1bf8c3);if(_0x46f759==='.priority'){f(we(_0x1bf8c3)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4ab6d2=_0x3104d0['getNode']();_0x565c96=_0x17b4b5['serverCache']['getNode']();const _0x1b2ab7=or(_0x4878c2,_0x1bf8c3,_0x4ab6d2,_0x565c96);_0x1b2ab7!=null?_0x48af11=_0x34a8a0['filter']['updatePriority'](_0x4ab6d2,_0x1b2ab7):_0x48af11=_0x3104d0['getNode']();}else{const _0x3cffb5=b(_0x1bf8c3);let _0xd1a0c9;if(_0x3104d0['isCompleteForChild'](_0x46f759)){_0x565c96=_0x17b4b5['serverCache']['getNode']();const _0x3cf166=or(_0x4878c2,_0x1bf8c3,_0x3104d0['getNode'](),_0x565c96);_0x3cf166!=null?_0xd1a0c9=_0x3104d0['getNode']()['getImmediateChild'](_0x46f759)['updateChild'](_0x3cffb5,_0x3cf166):_0xd1a0c9=_0x3104d0['getNode']()['getImmediateChild'](_0x46f759);}else _0xd1a0c9=ts(_0x4878c2,_0x46f759,_0x17b4b5['serverCache']);_0xd1a0c9!=null?_0x48af11=_0x34a8a0['filter']['updateChild'](_0x3104d0['getNode'](),_0x46f759,_0xd1a0c9,_0x3cffb5,_0x1b1898,_0x2cd92d):_0x48af11=_0x3104d0['getNode']();}}return wt(_0x17b4b5,_0x48af11,_0x3104d0['isFullyInitialized']()||v(_0x1bf8c3),_0x34a8a0['filter']['filtersNodes']());}}function vn(_0x402cfd,_0x1c5d07,_0x47ba02,_0x283c93,_0xd23e7d,_0x37e621,_0x21df6c,_0x19cb81){const _0x550915=_0x1c5d07['serverCache'];let _0xb76e33;const _0x4d0b32=_0x21df6c?_0x402cfd['filter']:_0x402cfd['filter']['getIndexedFilter']();if(v(_0x47ba02))_0xb76e33=_0x4d0b32['updateFullNode'](_0x550915['getNode'](),_0x283c93,null);else{if(_0x4d0b32['filtersNodes']()&&!_0x550915['isFiltered']()){const _0x3907ac=_0x550915['getNode']()['updateChild'](_0x47ba02,_0x283c93);_0xb76e33=_0x4d0b32['updateFullNode'](_0x550915['getNode'](),_0x3907ac,null);}else{const _0xdedd9f=y(_0x47ba02);if(!_0x550915['isCompleteForPath'](_0x47ba02)&&we(_0x47ba02)>0x1)return _0x1c5d07;const _0x5cb679=b(_0x47ba02),_0x40da29=_0x550915['getNode']()['getImmediateChild'](_0xdedd9f)['updateChild'](_0x5cb679,_0x283c93);_0xdedd9f==='.priority'?_0xb76e33=_0x4d0b32['updatePriority'](_0x550915['getNode'](),_0x40da29):_0xb76e33=_0x4d0b32['updateChild'](_0x550915['getNode'](),_0xdedd9f,_0x40da29,_0x5cb679,Vo,null);}}const _0x24dc4f=Lo(_0x1c5d07,_0xb76e33,_0x550915['isFullyInitialized']()||v(_0x47ba02),_0x4d0b32['filtersNodes']()),_0x240af9=new ns(_0xd23e7d,_0x24dc4f,_0x37e621);return Ho(_0x402cfd,_0x24dc4f,_0x47ba02,_0xd23e7d,_0x240af9,_0x19cb81);}function Ti(_0x4d8fde,_0x340071,_0x448e23,_0x55e294,_0x3048a3,_0x1012cd,_0x323bf1){const _0x4a04aa=_0x340071['eventCache'];let _0x4469d9,_0x35b654;const _0x4321d6=new ns(_0x3048a3,_0x340071,_0x1012cd);if(v(_0x448e23))_0x35b654=_0x4d8fde['filter']['updateFullNode'](_0x340071['eventCache']['getNode'](),_0x55e294,_0x323bf1),_0x4469d9=wt(_0x340071,_0x35b654,!0x0,_0x4d8fde['filter']['filtersNodes']());else{const _0xec489=y(_0x448e23);if(_0xec489==='.priority')_0x35b654=_0x4d8fde['filter']['updatePriority'](_0x340071['eventCache']['getNode'](),_0x55e294),_0x4469d9=wt(_0x340071,_0x35b654,_0x4a04aa['isFullyInitialized'](),_0x4a04aa['isFiltered']());else{const _0x5b5693=b(_0x448e23),_0x3f181f=_0x4a04aa['getNode']()['getImmediateChild'](_0xec489);let _0x5a35e3;if(v(_0x5b5693))_0x5a35e3=_0x55e294;else{const _0x6e0894=_0x4321d6['getCompleteChild'](_0xec489);_0x6e0894!=null?Gi(_0x5b5693)==='.priority'&&_0x6e0894['getChild'](To(_0x5b5693))['isEmpty']()?_0x5a35e3=_0x6e0894:_0x5a35e3=_0x6e0894['updateChild'](_0x5b5693,_0x55e294):_0x5a35e3=g['EMPTY_NODE'];}if(_0x3f181f['equals'](_0x5a35e3))_0x4469d9=_0x340071;else{const _0x21b838=_0x4d8fde['filter']['updateChild'](_0x4a04aa['getNode'](),_0xec489,_0x5a35e3,_0x5b5693,_0x4321d6,_0x323bf1);_0x4469d9=wt(_0x340071,_0x21b838,_0x4a04aa['isFullyInitialized'](),_0x4d8fde['filter']['filtersNodes']());}}}return _0x4469d9;}function ar(_0x38ff0f,_0x961ff7){return _0x38ff0f['eventCache']['isCompleteForChild'](_0x961ff7);}function bu(_0x5003b0,_0x4ab350,_0x33d766,_0x51c197,_0xe99162,_0x4457c9,_0x548b12){let _0x5a37e7=_0x4ab350;return _0x51c197['foreach']((_0x1ef0bd,_0x536699)=>{const _0x461d33=A(_0x33d766,_0x1ef0bd);ar(_0x4ab350,y(_0x461d33))&&(_0x5a37e7=Ti(_0x5003b0,_0x5a37e7,_0x461d33,_0x536699,_0xe99162,_0x4457c9,_0x548b12));}),_0x51c197['foreach']((_0x3aae97,_0x1f8173)=>{const _0xaf4ba1=A(_0x33d766,_0x3aae97);ar(_0x4ab350,y(_0xaf4ba1))||(_0x5a37e7=Ti(_0x5003b0,_0x5a37e7,_0xaf4ba1,_0x1f8173,_0xe99162,_0x4457c9,_0x548b12));}),_0x5a37e7;}function cr(_0x2e4427,_0x58d0db,_0x4b8bfa){return _0x4b8bfa['foreach']((_0x367f98,_0x4c331d)=>{_0x58d0db=_0x58d0db['updateChild'](_0x367f98,_0x4c331d);}),_0x58d0db;}function Si(_0xf991e6,_0x25544d,_0x2ba0a6,_0x556506,_0x54a4c2,_0x561122,_0x7d1e98,_0x595137){if(_0x25544d['serverCache']['getNode']()['isEmpty']()&&!_0x25544d['serverCache']['isFullyInitialized']())return _0x25544d;let _0x5027b6=_0x25544d,_0x52a94e;v(_0x2ba0a6)?_0x52a94e=_0x556506:_0x52a94e=new S(null)['setTree'](_0x2ba0a6,_0x556506);const _0x4ca35e=_0x25544d['serverCache']['getNode']();return _0x52a94e['children']['inorderTraversal']((_0x10303e,_0x27d19b)=>{if(_0x4ca35e['hasChild'](_0x10303e)){const _0x4f4a94=_0x25544d['serverCache']['getNode']()['getImmediateChild'](_0x10303e),_0x34cc15=cr(_0xf991e6,_0x4f4a94,_0x27d19b);_0x5027b6=vn(_0xf991e6,_0x5027b6,new C(_0x10303e),_0x34cc15,_0x54a4c2,_0x561122,_0x7d1e98,_0x595137);}}),_0x52a94e['children']['inorderTraversal']((_0x2ab7e0,_0x393e39)=>{const _0x4f7f7a=!_0x25544d['serverCache']['isCompleteForChild'](_0x2ab7e0)&&_0x393e39['value']===null;if(!_0x4ca35e['hasChild'](_0x2ab7e0)&&!_0x4f7f7a){const _0x413251=_0x25544d['serverCache']['getNode']()['getImmediateChild'](_0x2ab7e0),_0x39a985=cr(_0xf991e6,_0x413251,_0x393e39);_0x5027b6=vn(_0xf991e6,_0x5027b6,new C(_0x2ab7e0),_0x39a985,_0x54a4c2,_0x561122,_0x7d1e98,_0x595137);}}),_0x5027b6;}function Ru(_0x565063,_0x439ead,_0x48c9c0,_0x1ec6ae,_0x31deb6,_0x46ea4a,_0x5b3155){if(yn(_0x31deb6,_0x48c9c0)!=null)return _0x439ead;const _0x4f674f=_0x439ead['serverCache']['isFiltered'](),_0xc1788e=_0x439ead['serverCache'];if(_0x1ec6ae['value']!=null){if(v(_0x48c9c0)&&_0xc1788e['isFullyInitialized']()||_0xc1788e['isCompleteForPath'](_0x48c9c0))return vn(_0x565063,_0x439ead,_0x48c9c0,_0xc1788e['getNode']()['getChild'](_0x48c9c0),_0x31deb6,_0x46ea4a,_0x4f674f,_0x5b3155);if(v(_0x48c9c0)){let _0x36be18=new S(null);return _0xc1788e['getNode']()['forEachChild'](ye,(_0x1e6e14,_0x5a7b1a)=>{_0x36be18=_0x36be18['set'](new C(_0x1e6e14),_0x5a7b1a);}),Si(_0x565063,_0x439ead,_0x48c9c0,_0x36be18,_0x31deb6,_0x46ea4a,_0x4f674f,_0x5b3155);}else return _0x439ead;}else{let _0xe361f4=new S(null);return _0x1ec6ae['foreach']((_0x251d56,_0x1d14f4)=>{const _0xe53820=A(_0x48c9c0,_0x251d56);_0xc1788e['isCompleteForPath'](_0xe53820)&&(_0xe361f4=_0xe361f4['set'](_0x251d56,_0xc1788e['getNode']()['getChild'](_0xe53820)));}),Si(_0x565063,_0x439ead,_0x48c9c0,_0xe361f4,_0x31deb6,_0x46ea4a,_0x4f674f,_0x5b3155);}}function Au(_0x395d9b,_0x54a236,_0xcd82d5,_0x44a2f3,_0x4da95b){const _0x1ba958=_0x54a236['serverCache'],_0x6a00d2=Lo(_0x54a236,_0x1ba958['getNode'](),_0x1ba958['isFullyInitialized']()||v(_0xcd82d5),_0x1ba958['isFiltered']());return Ho(_0x395d9b,_0x6a00d2,_0xcd82d5,_0x44a2f3,Vo,_0x4da95b);}function ku(_0x455701,_0x1cd8f9,_0x5280a4,_0x3bcde1,_0x5f0c7f,_0x7f5d35){let _0x1878b6;if(yn(_0x3bcde1,_0x5280a4)!=null)return _0x1cd8f9;{const _0x2e9f10=new ns(_0x3bcde1,_0x1cd8f9,_0x5f0c7f),_0x487d25=_0x1cd8f9['eventCache']['getNode']();let _0x1c71b4;if(v(_0x5280a4)||y(_0x5280a4)==='.priority'){let _0x3ca3a1;if(_0x1cd8f9['serverCache']['isFullyInitialized']())_0x3ca3a1=mn(_0x3bcde1,Ue(_0x1cd8f9));else{const _0x400fde=_0x1cd8f9['serverCache']['getNode']();f(_0x400fde instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3ca3a1=es(_0x3bcde1,_0x400fde);}_0x3ca3a1=_0x3ca3a1,_0x1c71b4=_0x455701['filter']['updateFullNode'](_0x487d25,_0x3ca3a1,_0x7f5d35);}else{const _0x51f322=y(_0x5280a4);let _0x3976b0=ts(_0x3bcde1,_0x51f322,_0x1cd8f9['serverCache']);_0x3976b0==null&&_0x1cd8f9['serverCache']['isCompleteForChild'](_0x51f322)&&(_0x3976b0=_0x487d25['getImmediateChild'](_0x51f322)),_0x3976b0!=null?_0x1c71b4=_0x455701['filter']['updateChild'](_0x487d25,_0x51f322,_0x3976b0,b(_0x5280a4),_0x2e9f10,_0x7f5d35):_0x1cd8f9['eventCache']['getNode']()['hasChild'](_0x51f322)?_0x1c71b4=_0x455701['filter']['updateChild'](_0x487d25,_0x51f322,g['EMPTY_NODE'],b(_0x5280a4),_0x2e9f10,_0x7f5d35):_0x1c71b4=_0x487d25,_0x1c71b4['isEmpty']()&&_0x1cd8f9['serverCache']['isFullyInitialized']()&&(_0x1878b6=mn(_0x3bcde1,Ue(_0x1cd8f9)),_0x1878b6['isLeafNode']()&&(_0x1c71b4=_0x455701['filter']['updateFullNode'](_0x1c71b4,_0x1878b6,_0x7f5d35)));}return _0x1878b6=_0x1cd8f9['serverCache']['isFullyInitialized']()||yn(_0x3bcde1,w())!=null,wt(_0x1cd8f9,_0x1c71b4,_0x1878b6,_0x455701['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x68b723,_0x3b9bc6){this['query_']=_0x68b723,this['eventRegistrations_']=[];const _0x13ebc0=this['query_']['_queryParams'],_0x32444e=new Yi(_0x13ebc0['getIndex']()),_0x23bbde=qh(_0x13ebc0);this['processor_']=wu(_0x23bbde);const _0x24d0fe=_0x3b9bc6['serverCache'],_0x545150=_0x3b9bc6['eventCache'],_0x361abe=_0x32444e['updateFullNode'](g['EMPTY_NODE'],_0x24d0fe['getNode'](),null),_0x41ca27=_0x23bbde['updateFullNode'](g['EMPTY_NODE'],_0x545150['getNode'](),null),_0x272014=new Ce(_0x361abe,_0x24d0fe['isFullyInitialized'](),_0x32444e['filtersNodes']()),_0x4f6a17=new Ce(_0x41ca27,_0x545150['isFullyInitialized'](),_0x23bbde['filtersNodes']());this['viewCache_']=Dn(_0x4f6a17,_0x272014),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x5a584c){return _0x5a584c['viewCache_']['serverCache']['getNode']();}function Ou(_0x2a4b2e){return gn(_0x2a4b2e['viewCache_']);}function Du(_0x203c81,_0x20c978){const _0xe301eb=Ue(_0x203c81['viewCache_']);return _0xe301eb&&(_0x203c81['query']['_queryParams']['loadsAllData']()||!v(_0x20c978)&&!_0xe301eb['getImmediateChild'](y(_0x20c978))['isEmpty']())?_0xe301eb['getChild'](_0x20c978):null;}function lr(_0x33f03b){return _0x33f03b['eventRegistrations_']['length']===0x0;}function Mu(_0x4326da,_0x467762){_0x4326da['eventRegistrations_']['push'](_0x467762);}function hr(_0x2dd39a,_0x1eb9b3,_0xfb38c1){const _0x2f946e=[];if(_0xfb38c1){f(_0x1eb9b3==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x13099f=_0x2dd39a['query']['_path'];_0x2dd39a['eventRegistrations_']['forEach'](_0x59ddff=>{const _0x2df6d6=_0x59ddff['createCancelEvent'](_0xfb38c1,_0x13099f);_0x2df6d6&&_0x2f946e['push'](_0x2df6d6);});}if(_0x1eb9b3){let _0x5b6b13=[];for(let _0x5356d6=0x0;_0x5356d6<_0x2dd39a['eventRegistrations_']['length'];++_0x5356d6){const _0x12b57a=_0x2dd39a['eventRegistrations_'][_0x5356d6];if(!_0x12b57a['matches'](_0x1eb9b3))_0x5b6b13['push'](_0x12b57a);else{if(_0x1eb9b3['hasAnyCallback']()){_0x5b6b13=_0x5b6b13['concat'](_0x2dd39a['eventRegistrations_']['slice'](_0x5356d6+0x1));break;}}}_0x2dd39a['eventRegistrations_']=_0x5b6b13;}else _0x2dd39a['eventRegistrations_']=[];return _0x2f946e;}function ur(_0x15b5a7,_0x45bf67,_0x1fa57d,_0x44ef55){_0x45bf67['type']===q['MERGE']&&_0x45bf67['source']['queryId']!==null&&(f(Ue(_0x15b5a7['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x15b5a7['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3a45dc=_0x15b5a7['viewCache_'],_0x1b4c4d=Tu(_0x15b5a7['processor_'],_0x3a45dc,_0x45bf67,_0x1fa57d,_0x44ef55);return Cu(_0x15b5a7['processor_'],_0x1b4c4d['viewCache']),f(_0x1b4c4d['viewCache']['serverCache']['isFullyInitialized']()||!_0x3a45dc['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x15b5a7['viewCache_']=_0x1b4c4d['viewCache'],$o(_0x15b5a7,_0x1b4c4d['changes'],_0x1b4c4d['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x4073ed,_0x36a7fe){const _0x17c30b=_0x4073ed['viewCache_']['eventCache'],_0x5af0d2=[];return _0x17c30b['getNode']()['isLeafNode']()||_0x17c30b['getNode']()['forEachChild'](R,(_0x6286b0,_0x58b9ea)=>{_0x5af0d2['push'](tt(_0x6286b0,_0x58b9ea));}),_0x17c30b['isFullyInitialized']()&&_0x5af0d2['push'](Oo(_0x17c30b['getNode']())),$o(_0x4073ed,_0x5af0d2,_0x17c30b['getNode'](),_0x36a7fe);}function $o(_0x72b030,_0x1cd5cf,_0x41c6ee,_0x3ac374){const _0x327174=_0x3ac374?[_0x3ac374]:_0x72b030['eventRegistrations_'];return nu(_0x72b030['eventGenerator_'],_0x1cd5cf,_0x41c6ee,_0x327174);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x442c10){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x442c10;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x277484){return _0x277484['views']['size']===0x0;}function is(_0x4d3c15,_0x56a46d,_0x35ee54,_0x1f3b1c){const _0x1f43d1=_0x56a46d['source']['queryId'];if(_0x1f43d1!==null){const _0x37eaa6=_0x4d3c15['views']['get'](_0x1f43d1);return f(_0x37eaa6!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x37eaa6,_0x56a46d,_0x35ee54,_0x1f3b1c);}else{let _0x406383=[];for(const _0x2c872a of _0x4d3c15['views']['values']())_0x406383=_0x406383['concat'](ur(_0x2c872a,_0x56a46d,_0x35ee54,_0x1f3b1c));return _0x406383;}}function qo(_0x2bf568,_0xf341fb,_0x2408d5,_0x3d945c,_0x500ec7){const _0x257918=_0xf341fb['_queryIdentifier'],_0x1ed7c6=_0x2bf568['views']['get'](_0x257918);if(!_0x1ed7c6){let _0x469e18=mn(_0x2408d5,_0x500ec7?_0x3d945c:null),_0x56c00e=!0x1;_0x469e18?_0x56c00e=!0x0:_0x3d945c instanceof g?(_0x469e18=es(_0x2408d5,_0x3d945c),_0x56c00e=!0x1):(_0x469e18=g['EMPTY_NODE'],_0x56c00e=!0x1);const _0x4d7156=Dn(new Ce(_0x469e18,_0x56c00e,!0x1),new Ce(_0x3d945c,_0x500ec7,!0x1));return new Nu(_0xf341fb,_0x4d7156);}return _0x1ed7c6;}function Wu(_0x59c3f4,_0x2d37d,_0x10306c,_0xe085ef,_0xc5ed2a,_0x2c7571){const _0x3e0e5a=qo(_0x59c3f4,_0x2d37d,_0xe085ef,_0xc5ed2a,_0x2c7571);return _0x59c3f4['views']['has'](_0x2d37d['_queryIdentifier'])||_0x59c3f4['views']['set'](_0x2d37d['_queryIdentifier'],_0x3e0e5a),Mu(_0x3e0e5a,_0x10306c),Lu(_0x3e0e5a,_0x10306c);}function Bu(_0x1cffd6,_0x24f41d,_0x382917,_0x116503){const _0xf22f49=_0x24f41d['_queryIdentifier'],_0x58b3a5=[];let _0x2a67a2=[];const _0x38aef4=Te(_0x1cffd6);if(_0xf22f49==='default'){for(const [_0x1ba34b,_0x2ee720]of _0x1cffd6['views']['entries']())_0x2a67a2=_0x2a67a2['concat'](hr(_0x2ee720,_0x382917,_0x116503)),lr(_0x2ee720)&&(_0x1cffd6['views']['delete'](_0x1ba34b),_0x2ee720['query']['_queryParams']['loadsAllData']()||_0x58b3a5['push'](_0x2ee720['query']));}else{const _0xea0bd7=_0x1cffd6['views']['get'](_0xf22f49);_0xea0bd7&&(_0x2a67a2=_0x2a67a2['concat'](hr(_0xea0bd7,_0x382917,_0x116503)),lr(_0xea0bd7)&&(_0x1cffd6['views']['delete'](_0xf22f49),_0xea0bd7['query']['_queryParams']['loadsAllData']()||_0x58b3a5['push'](_0xea0bd7['query'])));}return _0x38aef4&&!Te(_0x1cffd6)&&_0x58b3a5['push'](new(Fu())(_0x24f41d['_repo'],_0x24f41d['_path'])),{'removed':_0x58b3a5,'events':_0x2a67a2};}function zo(_0x561f24){const _0x35b241=[];for(const _0x270d37 of _0x561f24['views']['values']())_0x270d37['query']['_queryParams']['loadsAllData']()||_0x35b241['push'](_0x270d37);return _0x35b241;}function Ee(_0x137d95,_0x24dcee){let _0x393461=null;for(const _0x11f8c7 of _0x137d95['views']['values']())_0x393461=_0x393461||Du(_0x11f8c7,_0x24dcee);return _0x393461;}function jo(_0x4d6c2e,_0x1c155d){if(_0x1c155d['_queryParams']['loadsAllData']())return Ln(_0x4d6c2e);{const _0x57cce5=_0x1c155d['_queryIdentifier'];return _0x4d6c2e['views']['get'](_0x57cce5);}}function Ko(_0x2a4676,_0x55aa46){return jo(_0x2a4676,_0x55aa46)!=null;}function Te(_0x2204c8){return Ln(_0x2204c8)!=null;}function Ln(_0x1e100c){for(const _0x413db8 of _0x1e100c['views']['values']())if(_0x413db8['query']['_queryParams']['loadsAllData']())return _0x413db8;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x718cca){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x718cca;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0xabe2){this['listenProvider_']=_0xabe2,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x15510f,_0x49bfeb,_0x49a04e,_0x391f0a,_0x3421af){return ou(_0x15510f['pendingWriteTree_'],_0x49bfeb,_0x49a04e,_0x391f0a,_0x3421af),_0x3421af?ht(_0x15510f,new Fe(Ji(),_0x49bfeb,_0x49a04e)):[];}function Gu(_0x524ec0,_0x564ca1,_0x5794c9,_0x7a4665){au(_0x524ec0['pendingWriteTree_'],_0x564ca1,_0x5794c9,_0x7a4665);const _0xf00e20=S['fromObject'](_0x5794c9);return ht(_0x524ec0,new nt(Ji(),_0x564ca1,_0xf00e20));}function pe(_0x5e3bc6,_0x1cec5c,_0x159bad=!0x1){const _0x36401e=cu(_0x5e3bc6['pendingWriteTree_'],_0x1cec5c);if(lu(_0x5e3bc6['pendingWriteTree_'],_0x1cec5c)){let _0x119940=new S(null);return _0x36401e['snap']!=null?_0x119940=_0x119940['set'](w(),!0x0):x(_0x36401e['children'],_0x46d514=>{_0x119940=_0x119940['set'](new C(_0x46d514),!0x0);}),ht(_0x5e3bc6,new _n(_0x36401e['path'],_0x119940,_0x159bad));}else return[];}function $t(_0x54e76d,_0x24ed1a,_0x197ed3){return ht(_0x54e76d,new Fe(Xi(),_0x24ed1a,_0x197ed3));}function qu(_0x43a8f6,_0x19288e,_0x50ec3){const _0x406f3f=S['fromObject'](_0x50ec3);return ht(_0x43a8f6,new nt(Xi(),_0x19288e,_0x406f3f));}function zu(_0x41d19f,_0x2f0215){return ht(_0x41d19f,new Dt(Xi(),_0x2f0215));}function ju(_0x1b3abd,_0x3617e5,_0x4ea415){const _0x1fac9e=rs(_0x1b3abd,_0x4ea415);if(_0x1fac9e){const _0x4a7049=os(_0x1fac9e),_0x1f5ad1=_0x4a7049['path'],_0x5b0626=_0x4a7049['queryId'],_0x2bf214=F(_0x1f5ad1,_0x3617e5),_0x38118c=new Dt(Zi(_0x5b0626),_0x2bf214);return as(_0x1b3abd,_0x1f5ad1,_0x38118c);}else return[];}function wn(_0x2ffe84,_0x2f5ebb,_0x35ebaf,_0x4c3f2c,_0x1e71ae=!0x1){const _0x51e8d5=_0x2f5ebb['_path'],_0x411d23=_0x2ffe84['syncPointTree_']['get'](_0x51e8d5);let _0xd080a0=[];if(_0x411d23&&(_0x2f5ebb['_queryIdentifier']==='default'||Ko(_0x411d23,_0x2f5ebb))){const _0x4d1b02=Bu(_0x411d23,_0x2f5ebb,_0x35ebaf,_0x4c3f2c);Uu(_0x411d23)&&(_0x2ffe84['syncPointTree_']=_0x2ffe84['syncPointTree_']['remove'](_0x51e8d5));const _0x3e46fe=_0x4d1b02['removed'];if(_0xd080a0=_0x4d1b02['events'],!_0x1e71ae){const _0x288b69=_0x3e46fe['findIndex'](_0x3bef5d=>_0x3bef5d['_queryParams']['loadsAllData']())!==-0x1,_0x25ffef=_0x2ffe84['syncPointTree_']['findOnPath'](_0x51e8d5,(_0x191e37,_0x10e9d8)=>Te(_0x10e9d8));if(_0x288b69&&!_0x25ffef){const _0x1c78c7=_0x2ffe84['syncPointTree_']['subtree'](_0x51e8d5);if(!_0x1c78c7['isEmpty']()){const _0x503572=Qu(_0x1c78c7);for(let _0x2df207=0x0;_0x2df207<_0x503572['length'];++_0x2df207){const _0x31f1c5=_0x503572[_0x2df207],_0x2f7f12=_0x31f1c5['query'],_0x38f039=Xo(_0x2ffe84,_0x31f1c5);_0x2ffe84['listenProvider_']['startListening'](Tt(_0x2f7f12),Mt(_0x2ffe84,_0x2f7f12),_0x38f039['hashFn'],_0x38f039['onComplete']);}}}!_0x25ffef&&_0x3e46fe['length']>0x0&&!_0x4c3f2c&&(_0x288b69?_0x2ffe84['listenProvider_']['stopListening'](Tt(_0x2f5ebb),null):_0x3e46fe['forEach'](_0x9f7f5d=>{const _0x1b33a1=_0x2ffe84['queryToTagMap']['get'](Fn(_0x9f7f5d));_0x2ffe84['listenProvider_']['stopListening'](Tt(_0x9f7f5d),_0x1b33a1);}));}Ju(_0x2ffe84,_0x3e46fe);}return _0xd080a0;}function Yo(_0x3a7608,_0x2d9352,_0x3a0722,_0x55eacd){const _0x51dbd6=rs(_0x3a7608,_0x55eacd);if(_0x51dbd6!=null){const _0x8de460=os(_0x51dbd6),_0x3e9646=_0x8de460['path'],_0x3bf4e3=_0x8de460['queryId'],_0x524075=F(_0x3e9646,_0x2d9352),_0x286f4d=new Fe(Zi(_0x3bf4e3),_0x524075,_0x3a0722);return as(_0x3a7608,_0x3e9646,_0x286f4d);}else return[];}function Ku(_0x1000ee,_0x4ad197,_0x408d55,_0x3b1c8e){const _0x785eb=rs(_0x1000ee,_0x3b1c8e);if(_0x785eb){const _0x321a5d=os(_0x785eb),_0x40c447=_0x321a5d['path'],_0x5d02a7=_0x321a5d['queryId'],_0x2d570b=F(_0x40c447,_0x4ad197),_0x382bcb=S['fromObject'](_0x408d55),_0x48008c=new nt(Zi(_0x5d02a7),_0x2d570b,_0x382bcb);return as(_0x1000ee,_0x40c447,_0x48008c);}else return[];}function bi(_0x4a368d,_0x32268a,_0x3ba753,_0x312a8f=!0x1){const _0x4ccfda=_0x32268a['_path'];let _0x4f9e6d=null,_0x4931cd=!0x1;_0x4a368d['syncPointTree_']['foreachOnPath'](_0x4ccfda,(_0x3091bb,_0x41a9e3)=>{const _0xd5616c=F(_0x3091bb,_0x4ccfda);_0x4f9e6d=_0x4f9e6d||Ee(_0x41a9e3,_0xd5616c),_0x4931cd=_0x4931cd||Te(_0x41a9e3);});let _0x4ee411=_0x4a368d['syncPointTree_']['get'](_0x4ccfda);_0x4ee411?(_0x4931cd=_0x4931cd||Te(_0x4ee411),_0x4f9e6d=_0x4f9e6d||Ee(_0x4ee411,w())):(_0x4ee411=new Go(),_0x4a368d['syncPointTree_']=_0x4a368d['syncPointTree_']['set'](_0x4ccfda,_0x4ee411));let _0x2cbc68;_0x4f9e6d!=null?_0x2cbc68=!0x0:(_0x2cbc68=!0x1,_0x4f9e6d=g['EMPTY_NODE'],_0x4a368d['syncPointTree_']['subtree'](_0x4ccfda)['foreachChild']((_0x2cb1ae,_0x508300)=>{const _0x31fbce=Ee(_0x508300,w());_0x31fbce&&(_0x4f9e6d=_0x4f9e6d['updateImmediateChild'](_0x2cb1ae,_0x31fbce));}));const _0x293c50=Ko(_0x4ee411,_0x32268a);if(!_0x293c50&&!_0x32268a['_queryParams']['loadsAllData']()){const _0x154b1c=Fn(_0x32268a);f(!_0x4a368d['queryToTagMap']['has'](_0x154b1c),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1cd961=Xu();_0x4a368d['queryToTagMap']['set'](_0x154b1c,_0x1cd961),_0x4a368d['tagToQueryMap']['set'](_0x1cd961,_0x154b1c);}const _0x6e9438=Mn(_0x4a368d['pendingWriteTree_'],_0x4ccfda);let _0x827854=Wu(_0x4ee411,_0x32268a,_0x3ba753,_0x6e9438,_0x4f9e6d,_0x2cbc68);if(!_0x293c50&&!_0x4931cd&&!_0x312a8f){const _0x58199e=jo(_0x4ee411,_0x32268a);_0x827854=_0x827854['concat'](Zu(_0x4a368d,_0x32268a,_0x58199e));}return _0x827854;}function xn(_0x1f6b63,_0x193414,_0x41543c){const _0x3c311c=_0x1f6b63['pendingWriteTree_'],_0x3d43cc=_0x1f6b63['syncPointTree_']['findOnPath'](_0x193414,(_0x273d47,_0x146115)=>{const _0x4b3597=F(_0x273d47,_0x193414),_0x3bc3a1=Ee(_0x146115,_0x4b3597);if(_0x3bc3a1)return _0x3bc3a1;});return Uo(_0x3c311c,_0x193414,_0x3d43cc,_0x41543c,!0x0);}function Yu(_0x23a8a2,_0xc2141e){const _0x226340=_0xc2141e['_path'];let _0x5907b9=null;_0x23a8a2['syncPointTree_']['foreachOnPath'](_0x226340,(_0x2e13bb,_0xed9397)=>{const _0x16c74f=F(_0x2e13bb,_0x226340);_0x5907b9=_0x5907b9||Ee(_0xed9397,_0x16c74f);});let _0x130a99=_0x23a8a2['syncPointTree_']['get'](_0x226340);_0x130a99?_0x5907b9=_0x5907b9||Ee(_0x130a99,w()):(_0x130a99=new Go(),_0x23a8a2['syncPointTree_']=_0x23a8a2['syncPointTree_']['set'](_0x226340,_0x130a99));const _0x57bddc=_0x5907b9!=null,_0xc260d4=_0x57bddc?new Ce(_0x5907b9,!0x0,!0x1):null,_0x24ece6=Mn(_0x23a8a2['pendingWriteTree_'],_0xc2141e['_path']),_0x4f025d=qo(_0x130a99,_0xc2141e,_0x24ece6,_0x57bddc?_0xc260d4['getNode']():g['EMPTY_NODE'],_0x57bddc);return Ou(_0x4f025d);}function ht(_0x3cd1d7,_0x2b61d5){return Qo(_0x2b61d5,_0x3cd1d7['syncPointTree_'],null,Mn(_0x3cd1d7['pendingWriteTree_'],w()));}function Qo(_0x2234ed,_0x42adae,_0x47a9f4,_0x2eaa32){if(v(_0x2234ed['path']))return Jo(_0x2234ed,_0x42adae,_0x47a9f4,_0x2eaa32);{const _0x2d545c=_0x42adae['get'](w());_0x47a9f4==null&&_0x2d545c!=null&&(_0x47a9f4=Ee(_0x2d545c,w()));let _0x56b1a1=[];const _0x2fcbe2=y(_0x2234ed['path']),_0x1cca48=_0x2234ed['operationForChild'](_0x2fcbe2),_0x14a6a8=_0x42adae['children']['get'](_0x2fcbe2);if(_0x14a6a8&&_0x1cca48){const _0x4e35dd=_0x47a9f4?_0x47a9f4['getImmediateChild'](_0x2fcbe2):null,_0x26ef68=Wo(_0x2eaa32,_0x2fcbe2);_0x56b1a1=_0x56b1a1['concat'](Qo(_0x1cca48,_0x14a6a8,_0x4e35dd,_0x26ef68));}return _0x2d545c&&(_0x56b1a1=_0x56b1a1['concat'](is(_0x2d545c,_0x2234ed,_0x2eaa32,_0x47a9f4))),_0x56b1a1;}}function Jo(_0x4ea270,_0x5cee92,_0x4f954a,_0x31904f){const _0x35134d=_0x5cee92['get'](w());_0x4f954a==null&&_0x35134d!=null&&(_0x4f954a=Ee(_0x35134d,w()));let _0x2c1557=[];return _0x5cee92['children']['inorderTraversal']((_0x3dce60,_0x213e2e)=>{const _0x2b4995=_0x4f954a?_0x4f954a['getImmediateChild'](_0x3dce60):null,_0x460bd3=Wo(_0x31904f,_0x3dce60),_0x4d9cdc=_0x4ea270['operationForChild'](_0x3dce60);_0x4d9cdc&&(_0x2c1557=_0x2c1557['concat'](Jo(_0x4d9cdc,_0x213e2e,_0x2b4995,_0x460bd3)));}),_0x35134d&&(_0x2c1557=_0x2c1557['concat'](is(_0x35134d,_0x4ea270,_0x31904f,_0x4f954a))),_0x2c1557;}function Xo(_0x2cca8d,_0x33f21e){const _0x450efc=_0x33f21e['query'],_0x4ee140=Mt(_0x2cca8d,_0x450efc);return{'hashFn':()=>(Pu(_0x33f21e)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2ea842=>{if(_0x2ea842==='ok')return _0x4ee140?ju(_0x2cca8d,_0x450efc['_path'],_0x4ee140):zu(_0x2cca8d,_0x450efc['_path']);{const _0x767b9b=ql(_0x2ea842,_0x450efc);return wn(_0x2cca8d,_0x450efc,null,_0x767b9b);}}};}function Mt(_0xac0892,_0x528f60){const _0x1c4eb1=Fn(_0x528f60);return _0xac0892['queryToTagMap']['get'](_0x1c4eb1);}function Fn(_0x59df2a){return _0x59df2a['_path']['toString']()+'$'+_0x59df2a['_queryIdentifier'];}function rs(_0x43b1a3,_0xb76e2){return _0x43b1a3['tagToQueryMap']['get'](_0xb76e2);}function os(_0x4d0020){const _0x4ec846=_0x4d0020['indexOf']('$');return f(_0x4ec846!==-0x1&&_0x4ec846<_0x4d0020['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4d0020['substr'](_0x4ec846+0x1),'path':new C(_0x4d0020['substr'](0x0,_0x4ec846))};}function as(_0x81a179,_0x32cb36,_0x39c8d6){const _0x495174=_0x81a179['syncPointTree_']['get'](_0x32cb36);f(_0x495174,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x11d70e=Mn(_0x81a179['pendingWriteTree_'],_0x32cb36);return is(_0x495174,_0x39c8d6,_0x11d70e,null);}function Qu(_0xb43049){return _0xb43049['fold']((_0x5e042d,_0xadcbb1,_0x3a3c67)=>{if(_0xadcbb1&&Te(_0xadcbb1))return[Ln(_0xadcbb1)];{let _0x5ed700=[];return _0xadcbb1&&(_0x5ed700=zo(_0xadcbb1)),x(_0x3a3c67,(_0x2b3cef,_0x37f512)=>{_0x5ed700=_0x5ed700['concat'](_0x37f512);}),_0x5ed700;}});}function Tt(_0x60e195){return _0x60e195['_queryParams']['loadsAllData']()&&!_0x60e195['_queryParams']['isDefault']()?new(Hu())(_0x60e195['_repo'],_0x60e195['_path']):_0x60e195;}function Ju(_0x3eec44,_0x1ae8da){for(let _0x55ddd3=0x0;_0x55ddd3<_0x1ae8da['length'];++_0x55ddd3){const _0x56e236=_0x1ae8da[_0x55ddd3];if(!_0x56e236['_queryParams']['loadsAllData']()){const _0x30a9c9=Fn(_0x56e236),_0x1055a1=_0x3eec44['queryToTagMap']['get'](_0x30a9c9);_0x3eec44['queryToTagMap']['delete'](_0x30a9c9),_0x3eec44['tagToQueryMap']['delete'](_0x1055a1);}}}function Xu(){return $u++;}function Zu(_0x1acd93,_0x4c4f3f,_0x1beb3d){const _0x32e265=_0x4c4f3f['_path'],_0x106c00=Mt(_0x1acd93,_0x4c4f3f),_0x192721=Xo(_0x1acd93,_0x1beb3d),_0x5006df=_0x1acd93['listenProvider_']['startListening'](Tt(_0x4c4f3f),_0x106c00,_0x192721['hashFn'],_0x192721['onComplete']),_0x3d2c43=_0x1acd93['syncPointTree_']['subtree'](_0x32e265);if(_0x106c00)f(!Te(_0x3d2c43['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x51d3c9=_0x3d2c43['fold']((_0x24cbfb,_0x3111f9,_0x3e51a3)=>{if(!v(_0x24cbfb)&&_0x3111f9&&Te(_0x3111f9))return[Ln(_0x3111f9)['query']];{let _0x2f7ede=[];return _0x3111f9&&(_0x2f7ede=_0x2f7ede['concat'](zo(_0x3111f9)['map'](_0x2c6a29=>_0x2c6a29['query']))),x(_0x3e51a3,(_0x31ff5c,_0x3bb230)=>{_0x2f7ede=_0x2f7ede['concat'](_0x3bb230);}),_0x2f7ede;}});for(let _0x490a75=0x0;_0x490a75<_0x51d3c9['length'];++_0x490a75){const _0x5f1223=_0x51d3c9[_0x490a75];_0x1acd93['listenProvider_']['stopListening'](Tt(_0x5f1223),Mt(_0x1acd93,_0x5f1223));}}return _0x5006df;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x17e35a){this['node_']=_0x17e35a;}['getImmediateChild'](_0x197794){const _0x11cef4=this['node_']['getImmediateChild'](_0x197794);return new cs(_0x11cef4);}['node'](){return this['node_'];}}class ls{constructor(_0x3fdfb2,_0x32d960){this['syncTree_']=_0x3fdfb2,this['path_']=_0x32d960;}['getImmediateChild'](_0x3aad4a){const _0x21536f=A(this['path_'],_0x3aad4a);return new ls(this['syncTree_'],_0x21536f);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x282a8e){return _0x282a8e=_0x282a8e||{},_0x282a8e['timestamp']=_0x282a8e['timestamp']||new Date()['getTime'](),_0x282a8e;},fr=function(_0x3ed7d4,_0x1f02d5,_0x45d6eb){if(!_0x3ed7d4||typeof _0x3ed7d4!='object')return _0x3ed7d4;if(f('.sv'in _0x3ed7d4,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3ed7d4['.sv']=='string')return td(_0x3ed7d4['.sv'],_0x1f02d5,_0x45d6eb);if(typeof _0x3ed7d4['.sv']=='object')return nd(_0x3ed7d4['.sv'],_0x1f02d5);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3ed7d4,null,0x2));},td=function(_0x3c88c4,_0x294d99,_0x5c04e9){switch(_0x3c88c4){case'timestamp':return _0x5c04e9['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x3c88c4);}},nd=function(_0x553d3f,_0x37299e,_0x3da4e4){_0x553d3f['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x553d3f,null,0x2));const _0x2ebec8=_0x553d3f['increment'];typeof _0x2ebec8!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2ebec8);const _0x50b32b=_0x37299e['node']();if(f(_0x50b32b!==null&&typeof _0x50b32b<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x50b32b['isLeafNode']())return _0x2ebec8;const _0x5c0652=_0x50b32b['getValue']();return typeof _0x5c0652!='number'?_0x2ebec8:_0x5c0652+_0x2ebec8;},Zo=function(_0x4d2000,_0x25ce80,_0x33854e,_0x26e244){return us(_0x25ce80,new ls(_0x33854e,_0x4d2000),_0x26e244);},hs=function(_0x30bcd9,_0x231ea1,_0x59d2b9){return us(_0x30bcd9,new cs(_0x231ea1),_0x59d2b9);};function us(_0x1cbaf0,_0xb818ca,_0x4f2f70){const _0x562637=_0x1cbaf0['getPriority']()['val'](),_0x401758=fr(_0x562637,_0xb818ca['getImmediateChild']('.priority'),_0x4f2f70);let _0xd39ed2;if(_0x1cbaf0['isLeafNode']()){const _0x55d6fb=_0x1cbaf0,_0x1d28b4=fr(_0x55d6fb['getValue'](),_0xb818ca,_0x4f2f70);return _0x1d28b4!==_0x55d6fb['getValue']()||_0x401758!==_0x55d6fb['getPriority']()['val']()?new D(_0x1d28b4,N(_0x401758)):_0x1cbaf0;}else{const _0x6231c7=_0x1cbaf0;return _0xd39ed2=_0x6231c7,_0x401758!==_0x6231c7['getPriority']()['val']()&&(_0xd39ed2=_0xd39ed2['updatePriority'](new D(_0x401758))),_0x6231c7['forEachChild'](R,(_0xb4f43f,_0x280c3a)=>{const _0x136367=us(_0x280c3a,_0xb818ca['getImmediateChild'](_0xb4f43f),_0x4f2f70);_0x136367!==_0x280c3a&&(_0xd39ed2=_0xd39ed2['updateImmediateChild'](_0xb4f43f,_0x136367));}),_0xd39ed2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x11398d='',_0x347272=null,_0x1bb8dc={'children':{},'childCount':0x0}){this['name']=_0x11398d,this['parent']=_0x347272,this['node']=_0x1bb8dc;}}function Un(_0x399a76,_0x1cde42){let _0x5030d3=_0x1cde42 instanceof C?_0x1cde42:new C(_0x1cde42),_0xfd696c=_0x399a76,_0x37484e=y(_0x5030d3);for(;_0x37484e!==null;){const _0x3915d5=Oe(_0xfd696c['node']['children'],_0x37484e)||{'children':{},'childCount':0x0};_0xfd696c=new ds(_0x37484e,_0xfd696c,_0x3915d5),_0x5030d3=b(_0x5030d3),_0x37484e=y(_0x5030d3);}return _0xfd696c;}function Ge(_0x97fbff){return _0x97fbff['node']['value'];}function fs(_0x7eb6b,_0x11be40){_0x7eb6b['node']['value']=_0x11be40,Ri(_0x7eb6b);}function ea(_0x27d8b7){return _0x27d8b7['node']['childCount']>0x0;}function id(_0x44518e){return Ge(_0x44518e)===void 0x0&&!ea(_0x44518e);}function Wn(_0x39f902,_0x1e92b9){x(_0x39f902['node']['children'],(_0x3e4d0e,_0x3d54dc)=>{_0x1e92b9(new ds(_0x3e4d0e,_0x39f902,_0x3d54dc));});}function ta(_0x10252b,_0x3be169,_0x2df94f,_0x286290){_0x2df94f&&_0x3be169(_0x10252b),Wn(_0x10252b,_0x4b53e5=>{ta(_0x4b53e5,_0x3be169,!0x0);});}function sd(_0x30640d,_0x46a701,_0x1c22df){let _0x229464=_0x30640d['parent'];for(;_0x229464!==null;){if(_0x46a701(_0x229464))return!0x0;_0x229464=_0x229464['parent'];}return!0x1;}function Gt(_0x113c93){return new C(_0x113c93['parent']===null?_0x113c93['name']:Gt(_0x113c93['parent'])+'/'+_0x113c93['name']);}function Ri(_0xd293a8){_0xd293a8['parent']!==null&&rd(_0xd293a8['parent'],_0xd293a8['name'],_0xd293a8);}function rd(_0xa71207,_0x3d6d5f,_0x9dedf){const _0x252780=id(_0x9dedf),_0x3b1369=Y(_0xa71207['node']['children'],_0x3d6d5f);_0x252780&&_0x3b1369?(delete _0xa71207['node']['children'][_0x3d6d5f],_0xa71207['node']['childCount']--,Ri(_0xa71207)):!_0x252780&&!_0x3b1369&&(_0xa71207['node']['children'][_0x3d6d5f]=_0x9dedf['node'],_0xa71207['node']['childCount']++,Ri(_0xa71207));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x3a0f44){return typeof _0x3a0f44=='string'&&_0x3a0f44['length']!==0x0&&!od['test'](_0x3a0f44);},na=function(_0x120922){return typeof _0x120922=='string'&&_0x120922['length']!==0x0&&!ad['test'](_0x120922);},cd=function(_0x169534){return _0x169534&&(_0x169534=_0x169534['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x169534);},Cn=function(_0x4a7585){return _0x4a7585===null||typeof _0x4a7585=='string'||typeof _0x4a7585=='number'&&!Wi(_0x4a7585)||_0x4a7585&&typeof _0x4a7585=='object'&&Y(_0x4a7585,'.sv');},qt=function(_0x4ed108,_0x5e9e21,_0x15cd7a,_0x359fa8){_0x359fa8&&_0x5e9e21===void 0x0||zt(Nn(_0x4ed108,'value'),_0x5e9e21,_0x15cd7a);},zt=function(_0x23b339,_0x427d6d,_0x3028bd){const _0x1b2bb3=_0x3028bd instanceof C?new Sh(_0x3028bd,_0x23b339):_0x3028bd;if(_0x427d6d===void 0x0)throw new Error(_0x23b339+'contains\x20undefined\x20'+Ne(_0x1b2bb3));if(typeof _0x427d6d=='function')throw new Error(_0x23b339+'contains\x20a\x20function\x20'+Ne(_0x1b2bb3)+'\x20with\x20contents\x20=\x20'+_0x427d6d['toString']());if(Wi(_0x427d6d))throw new Error(_0x23b339+'contains\x20'+_0x427d6d['toString']()+'\x20'+Ne(_0x1b2bb3));if(typeof _0x427d6d=='string'&&_0x427d6d['length']>oi/0x3&&Pn(_0x427d6d)>oi)throw new Error(_0x23b339+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x1b2bb3)+'\x20(\x27'+_0x427d6d['substring'](0x0,0x32)+'...\x27)');if(_0x427d6d&&typeof _0x427d6d=='object'){let _0x294713=!0x1,_0x75a94c=!0x1;if(x(_0x427d6d,(_0x31e492,_0x452cad)=>{if(_0x31e492==='.value')_0x294713=!0x0;else{if(_0x31e492!=='.priority'&&_0x31e492!=='.sv'&&(_0x75a94c=!0x0,!ps(_0x31e492)))throw new Error(_0x23b339+'\x20contains\x20an\x20invalid\x20key\x20('+_0x31e492+')\x20'+Ne(_0x1b2bb3)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x1b2bb3,_0x31e492),zt(_0x23b339,_0x452cad,_0x1b2bb3),Rh(_0x1b2bb3);}),_0x294713&&_0x75a94c)throw new Error(_0x23b339+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x1b2bb3)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x4df1f3,_0x51ed2c){let _0x227608,_0x330bd2;for(_0x227608=0x0;_0x227608<_0x51ed2c['length'];_0x227608++){_0x330bd2=_0x51ed2c[_0x227608];const _0x20417c=kt(_0x330bd2);for(let _0x3c5d85=0x0;_0x3c5d85<_0x20417c['length'];_0x3c5d85++)if(!(_0x20417c[_0x3c5d85]==='.priority'&&_0x3c5d85===_0x20417c['length']-0x1)){if(!ps(_0x20417c[_0x3c5d85]))throw new Error(_0x4df1f3+'contains\x20an\x20invalid\x20key\x20('+_0x20417c[_0x3c5d85]+')\x20in\x20path\x20'+_0x330bd2['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x51ed2c['sort'](Th);let _0x2229a6=null;for(_0x227608=0x0;_0x227608<_0x51ed2c['length'];_0x227608++){if(_0x330bd2=_0x51ed2c[_0x227608],_0x2229a6!==null&&$(_0x2229a6,_0x330bd2))throw new Error(_0x4df1f3+'contains\x20a\x20path\x20'+_0x2229a6['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x330bd2['toString']());_0x2229a6=_0x330bd2;}},hd=function(_0x20db0b,_0x3ba47e,_0x106ac0,_0x1e88db){const _0x33bc68=Nn(_0x20db0b,'values');if(!(_0x3ba47e&&typeof _0x3ba47e=='object')||Array['isArray'](_0x3ba47e))throw new Error(_0x33bc68+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x473741=[];x(_0x3ba47e,(_0xbd4402,_0x48f8e0)=>{const _0x4db868=new C(_0xbd4402);if(zt(_0x33bc68,_0x48f8e0,A(_0x106ac0,_0x4db868)),Gi(_0x4db868)==='.priority'&&!Cn(_0x48f8e0))throw new Error(_0x33bc68+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x4db868['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x473741['push'](_0x4db868);}),ld(_0x33bc68,_0x473741);},_s=function(_0x5e37f5,_0x5e92d3,_0x4a8814,_0x40cc78){if(!na(_0x4a8814))throw new Error(Nn(_0x5e37f5,_0x5e92d3)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4a8814+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x215608,_0x459c18,_0x2ab06e,_0x528bfa){_0x2ab06e&&(_0x2ab06e=_0x2ab06e['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x215608,_0x459c18,_0x2ab06e);},gs=function(_0x146613,_0xf75b8c){if(y(_0xf75b8c)==='.info')throw new Error(_0x146613+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x54e19c,_0x9914f4){const _0x5c3276=_0x9914f4['path']['toString']();if(typeof _0x9914f4['repoInfo']['host']!='string'||_0x9914f4['repoInfo']['host']['length']===0x0||!ps(_0x9914f4['repoInfo']['namespace'])&&_0x9914f4['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x5c3276['length']!==0x0&&!cd(_0x5c3276))throw new Error(Nn(_0x54e19c,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x330a72,_0x1f1172){let _0x406ca6=null;for(let _0x25fa82=0x0;_0x25fa82<_0x1f1172['length'];_0x25fa82++){const _0x3190cc=_0x1f1172[_0x25fa82],_0x5b4e8a=_0x3190cc['getPath']();_0x406ca6!==null&&!qi(_0x5b4e8a,_0x406ca6['path'])&&(_0x330a72['eventLists_']['push'](_0x406ca6),_0x406ca6=null),_0x406ca6===null&&(_0x406ca6={'events':[],'path':_0x5b4e8a}),_0x406ca6['events']['push'](_0x3190cc);}_0x406ca6&&_0x330a72['eventLists_']['push'](_0x406ca6);}function ia(_0x3fb5ef,_0xaeade6,_0x3b8284){Bn(_0x3fb5ef,_0x3b8284),sa(_0x3fb5ef,_0x34477c=>qi(_0x34477c,_0xaeade6));}function V(_0x42f05b,_0x10dcf9,_0x4321a7){Bn(_0x42f05b,_0x4321a7),sa(_0x42f05b,_0xcb9da1=>$(_0xcb9da1,_0x10dcf9)||$(_0x10dcf9,_0xcb9da1));}function sa(_0x4bff28,_0x47a466){_0x4bff28['recursionDepth_']++;let _0x58c893=!0x0;for(let _0x2ae75a=0x0;_0x2ae75a<_0x4bff28['eventLists_']['length'];_0x2ae75a++){const _0x3f9b09=_0x4bff28['eventLists_'][_0x2ae75a];if(_0x3f9b09){const _0x160ea7=_0x3f9b09['path'];_0x47a466(_0x160ea7)?(pd(_0x4bff28['eventLists_'][_0x2ae75a]),_0x4bff28['eventLists_'][_0x2ae75a]=null):_0x58c893=!0x1;}}_0x58c893&&(_0x4bff28['eventLists_']=[]),_0x4bff28['recursionDepth_']--;}function pd(_0x57a9f5){for(let _0x374f18=0x0;_0x374f18<_0x57a9f5['events']['length'];_0x374f18++){const _0x3fdd4e=_0x57a9f5['events'][_0x374f18];if(_0x3fdd4e!==null){_0x57a9f5['events'][_0x374f18]=null;const _0x2d3f45=_0x3fdd4e['getEventRunner']();Et&&L('event:\x20'+_0x3fdd4e['toString']()),lt(_0x2d3f45);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x54f72f,_0xe968d7,_0x5b5142,_0x5b69f1){this['repoInfo_']=_0x54f72f,this['forceRestClient_']=_0xe968d7,this['authTokenProvider_']=_0x5b5142,this['appCheckProvider_']=_0x5b69f1,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x4116b8,_0x57c442,_0x43d55f){if(_0x4116b8['stats_']=Hi(_0x4116b8['repoInfo_']),_0x4116b8['forceRestClient_']||Yl())_0x4116b8['server_']=new fn(_0x4116b8['repoInfo_'],(_0x41af7b,_0x129a4b,_0x41e7ce,_0x3ec1b0)=>{pr(_0x4116b8,_0x41af7b,_0x129a4b,_0x41e7ce,_0x3ec1b0);},_0x4116b8['authTokenProvider_'],_0x4116b8['appCheckProvider_']),setTimeout(()=>_r(_0x4116b8,!0x0),0x0);else{if(typeof _0x43d55f<'u'&&_0x43d55f!==null){if(typeof _0x43d55f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x43d55f);}catch(_0x33d919){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x33d919);}}_0x4116b8['persistentConnection_']=new ie(_0x4116b8['repoInfo_'],_0x57c442,(_0x4e3004,_0xc9a4c4,_0x73b8d3,_0x59cd09)=>{pr(_0x4116b8,_0x4e3004,_0xc9a4c4,_0x73b8d3,_0x59cd09);},_0x5caf37=>{_r(_0x4116b8,_0x5caf37);},_0x2be79a=>{yd(_0x4116b8,_0x2be79a);},_0x4116b8['authTokenProvider_'],_0x4116b8['appCheckProvider_'],_0x43d55f),_0x4116b8['server_']=_0x4116b8['persistentConnection_'];}_0x4116b8['authTokenProvider_']['addTokenChangeListener'](_0x118aa6=>{_0x4116b8['server_']['refreshAuthToken'](_0x118aa6);}),_0x4116b8['appCheckProvider_']['addTokenChangeListener'](_0x570b49=>{_0x4116b8['server_']['refreshAppCheckToken'](_0x570b49['token']);}),_0x4116b8['statsReporter_']=eh(_0x4116b8['repoInfo_'],()=>new eu(_0x4116b8['stats_'],_0x4116b8['server_'])),_0x4116b8['infoData_']=new Yh(),_0x4116b8['infoSyncTree_']=new dr({'startListening':(_0x2ef420,_0x4410a3,_0x884c7e,_0xd60b40)=>{let _0xc6e6dd=[];const _0x47626b=_0x4116b8['infoData_']['getNode'](_0x2ef420['_path']);return _0x47626b['isEmpty']()||(_0xc6e6dd=$t(_0x4116b8['infoSyncTree_'],_0x2ef420['_path'],_0x47626b),setTimeout(()=>{_0xd60b40('ok');},0x0)),_0xc6e6dd;},'stopListening':()=>{}}),ms(_0x4116b8,'connected',!0x1),_0x4116b8['serverSyncTree_']=new dr({'startListening':(_0x258219,_0x16226c,_0x25f25c,_0x8c5598)=>(_0x4116b8['server_']['listen'](_0x258219,_0x25f25c,_0x16226c,(_0x8fc884,_0x51c8c5)=>{const _0x30b7ec=_0x8c5598(_0x8fc884,_0x51c8c5);V(_0x4116b8['eventQueue_'],_0x258219['_path'],_0x30b7ec);}),[]),'stopListening':(_0x280c5f,_0x404197)=>{_0x4116b8['server_']['unlisten'](_0x280c5f,_0x404197);}});}function oa(_0x3a64b8){const _0x46c1f3=_0x3a64b8['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x46c1f3;}function jt(_0x591155){return ed({'timestamp':oa(_0x591155)});}function pr(_0x344666,_0x194e53,_0x4ba22e,_0x39110a,_0x1df7fe){_0x344666['dataUpdateCount']++;const _0x146caa=new C(_0x194e53);_0x4ba22e=_0x344666['interceptServerDataCallback_']?_0x344666['interceptServerDataCallback_'](_0x194e53,_0x4ba22e):_0x4ba22e;let _0x3b31cc=[];if(_0x1df7fe){if(_0x39110a){const _0x39d658=ln(_0x4ba22e,_0x1ac77c=>N(_0x1ac77c));_0x3b31cc=Ku(_0x344666['serverSyncTree_'],_0x146caa,_0x39d658,_0x1df7fe);}else{const _0x4ef62a=N(_0x4ba22e);_0x3b31cc=Yo(_0x344666['serverSyncTree_'],_0x146caa,_0x4ef62a,_0x1df7fe);}}else{if(_0x39110a){const _0x2f9fdb=ln(_0x4ba22e,_0xef742e=>N(_0xef742e));_0x3b31cc=qu(_0x344666['serverSyncTree_'],_0x146caa,_0x2f9fdb);}else{const _0x1328ca=N(_0x4ba22e);_0x3b31cc=$t(_0x344666['serverSyncTree_'],_0x146caa,_0x1328ca);}}let _0x80a94d=_0x146caa;_0x3b31cc['length']>0x0&&(_0x80a94d=st(_0x344666,_0x146caa)),V(_0x344666['eventQueue_'],_0x80a94d,_0x3b31cc);}function _r(_0x55e696,_0x45a4f9){ms(_0x55e696,'connected',_0x45a4f9),_0x45a4f9===!0x1&&wd(_0x55e696);}function yd(_0x22817c,_0x45b26b){x(_0x45b26b,(_0x15b96a,_0x888916)=>{ms(_0x22817c,_0x15b96a,_0x888916);});}function ms(_0x27a658,_0xf31884,_0x440e0a){const _0xd1025=new C('/.info/'+_0xf31884),_0x500ea7=N(_0x440e0a);_0x27a658['infoData_']['updateSnapshot'](_0xd1025,_0x500ea7);const _0x39738a=$t(_0x27a658['infoSyncTree_'],_0xd1025,_0x500ea7);V(_0x27a658['eventQueue_'],_0xd1025,_0x39738a);}function Vn(_0x2075f2){return _0x2075f2['nextWriteId_']++;}function vd(_0x512303,_0x1540e7,_0x48dfa3){const _0x43629f=Yu(_0x512303['serverSyncTree_'],_0x1540e7);return _0x43629f!=null?Promise['resolve'](_0x43629f):_0x512303['server_']['get'](_0x1540e7)['then'](_0x24a30f=>{const _0x165a4a=N(_0x24a30f)['withIndex'](_0x1540e7['_queryParams']['getIndex']());bi(_0x512303['serverSyncTree_'],_0x1540e7,_0x48dfa3,!0x0);let _0x2e5af5;if(_0x1540e7['_queryParams']['loadsAllData']())_0x2e5af5=$t(_0x512303['serverSyncTree_'],_0x1540e7['_path'],_0x165a4a);else{const _0x415223=Mt(_0x512303['serverSyncTree_'],_0x1540e7);_0x2e5af5=Yo(_0x512303['serverSyncTree_'],_0x1540e7['_path'],_0x165a4a,_0x415223);}return V(_0x512303['eventQueue_'],_0x1540e7['_path'],_0x2e5af5),wn(_0x512303['serverSyncTree_'],_0x1540e7,_0x48dfa3,null,!0x0),_0x165a4a;},_0x7a3286=>(ut(_0x512303,'get\x20for\x20query\x20'+O(_0x1540e7)+'\x20failed:\x20'+_0x7a3286),Promise['reject'](new Error(_0x7a3286))));}function Ed(_0x453229,_0x2edd7e,_0x1a5fbc,_0x305a26,_0x42ea31){ut(_0x453229,'set',{'path':_0x2edd7e['toString'](),'value':_0x1a5fbc,'priority':_0x305a26});const _0x43337e=jt(_0x453229),_0x271547=N(_0x1a5fbc,_0x305a26),_0x4b75a7=xn(_0x453229['serverSyncTree_'],_0x2edd7e),_0x26c483=hs(_0x271547,_0x4b75a7,_0x43337e),_0x2e3bd7=Vn(_0x453229),_0x1304be=ss(_0x453229['serverSyncTree_'],_0x2edd7e,_0x26c483,_0x2e3bd7,!0x0);Bn(_0x453229['eventQueue_'],_0x1304be),_0x453229['server_']['put'](_0x2edd7e['toString'](),_0x271547['val'](!0x0),(_0x47148,_0x31cf14)=>{const _0x4e83a6=_0x47148==='ok';_0x4e83a6||U('set\x20at\x20'+_0x2edd7e+'\x20failed:\x20'+_0x47148);const _0x42b04c=pe(_0x453229['serverSyncTree_'],_0x2e3bd7,!_0x4e83a6);V(_0x453229['eventQueue_'],_0x2edd7e,_0x42b04c),Ai(_0x453229,_0x42ea31,_0x47148,_0x31cf14);});const _0x3b617b=vs(_0x453229,_0x2edd7e);st(_0x453229,_0x3b617b),V(_0x453229['eventQueue_'],_0x3b617b,[]);}function Id(_0x57718f,_0x349ff5,_0x179e0f,_0x275c44){ut(_0x57718f,'update',{'path':_0x349ff5['toString'](),'value':_0x179e0f});let _0x5be3c9=!0x0;const _0x510d12=jt(_0x57718f),_0xe6fc3b={};if(x(_0x179e0f,(_0x11a8e0,_0x1dcf2b)=>{_0x5be3c9=!0x1,_0xe6fc3b[_0x11a8e0]=Zo(A(_0x349ff5,_0x11a8e0),N(_0x1dcf2b),_0x57718f['serverSyncTree_'],_0x510d12);}),_0x5be3c9)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x57718f,_0x275c44,'ok',void 0x0);else{const _0x3bb662=Vn(_0x57718f),_0x426cdd=Gu(_0x57718f['serverSyncTree_'],_0x349ff5,_0xe6fc3b,_0x3bb662);Bn(_0x57718f['eventQueue_'],_0x426cdd),_0x57718f['server_']['merge'](_0x349ff5['toString'](),_0x179e0f,(_0x27370a,_0x5bc2ec)=>{const _0x397f35=_0x27370a==='ok';_0x397f35||U('update\x20at\x20'+_0x349ff5+'\x20failed:\x20'+_0x27370a);const _0x1c7c10=pe(_0x57718f['serverSyncTree_'],_0x3bb662,!_0x397f35),_0xcc4591=_0x1c7c10['length']>0x0?st(_0x57718f,_0x349ff5):_0x349ff5;V(_0x57718f['eventQueue_'],_0xcc4591,_0x1c7c10),Ai(_0x57718f,_0x275c44,_0x27370a,_0x5bc2ec);}),x(_0x179e0f,_0x1b9102=>{const _0x4df212=vs(_0x57718f,A(_0x349ff5,_0x1b9102));st(_0x57718f,_0x4df212);}),V(_0x57718f['eventQueue_'],_0x349ff5,[]);}}function wd(_0x31de0a){ut(_0x31de0a,'onDisconnectEvents');const _0x39cca2=jt(_0x31de0a),_0x2f28ce=pn();Ei(_0x31de0a['onDisconnect_'],w(),(_0x536803,_0x82a569)=>{const _0x4b8a93=Zo(_0x536803,_0x82a569,_0x31de0a['serverSyncTree_'],_0x39cca2);Mo(_0x2f28ce,_0x536803,_0x4b8a93);});let _0x3a8c4c=[];Ei(_0x2f28ce,w(),(_0x335a53,_0x4e7dd2)=>{_0x3a8c4c=_0x3a8c4c['concat']($t(_0x31de0a['serverSyncTree_'],_0x335a53,_0x4e7dd2));const _0x4f3eaf=vs(_0x31de0a,_0x335a53);st(_0x31de0a,_0x4f3eaf);}),_0x31de0a['onDisconnect_']=pn(),V(_0x31de0a['eventQueue_'],w(),_0x3a8c4c);}function Cd(_0x264c85,_0x3753cd,_0x650370){let _0x5a77ed;y(_0x3753cd['_path'])==='.info'?_0x5a77ed=bi(_0x264c85['infoSyncTree_'],_0x3753cd,_0x650370):_0x5a77ed=bi(_0x264c85['serverSyncTree_'],_0x3753cd,_0x650370),ia(_0x264c85['eventQueue_'],_0x3753cd['_path'],_0x5a77ed);}function Td(_0xc31737,_0x3196ee,_0x20d097){let _0x4f02a6;y(_0x3196ee['_path'])==='.info'?_0x4f02a6=wn(_0xc31737['infoSyncTree_'],_0x3196ee,_0x20d097):_0x4f02a6=wn(_0xc31737['serverSyncTree_'],_0x3196ee,_0x20d097),ia(_0xc31737['eventQueue_'],_0x3196ee['_path'],_0x4f02a6);}function aa(_0x102bf0){_0x102bf0['persistentConnection_']&&_0x102bf0['persistentConnection_']['interrupt'](ra);}function Sd(_0x5868f8){_0x5868f8['persistentConnection_']&&_0x5868f8['persistentConnection_']['resume'](ra);}function ut(_0x2cc496,..._0x9468eb){let _0xe12c92='';_0x2cc496['persistentConnection_']&&(_0xe12c92=_0x2cc496['persistentConnection_']['id']+':'),L(_0xe12c92,..._0x9468eb);}function Ai(_0x556684,_0x169ea1,_0x55b593,_0x4a72ed){_0x169ea1&&lt(()=>{if(_0x55b593==='ok')_0x169ea1(null);else{const _0x436887=(_0x55b593||'error')['toUpperCase']();let _0x1bbbf1=_0x436887;_0x4a72ed&&(_0x1bbbf1+=':\x20'+_0x4a72ed);const _0x545b04=new Error(_0x1bbbf1);_0x545b04['code']=_0x436887,_0x169ea1(_0x545b04);}});}function bd(_0x5d2150,_0x3b4ac9,_0x5a0281,_0x31e63e,_0x4633cb,_0x31a16a){ut(_0x5d2150,'transaction\x20on\x20'+_0x3b4ac9);const _0x4f9fbd={'path':_0x3b4ac9,'update':_0x5a0281,'onComplete':_0x31e63e,'status':null,'order':to(),'applyLocally':_0x31a16a,'retryCount':0x0,'unwatcher':_0x4633cb,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5dadac=ys(_0x5d2150,_0x3b4ac9,void 0x0);_0x4f9fbd['currentInputSnapshot']=_0x5dadac;const _0xf8c69d=_0x4f9fbd['update'](_0x5dadac['val']());if(_0xf8c69d===void 0x0)_0x4f9fbd['unwatcher'](),_0x4f9fbd['currentOutputSnapshotRaw']=null,_0x4f9fbd['currentOutputSnapshotResolved']=null,_0x4f9fbd['onComplete']&&_0x4f9fbd['onComplete'](null,!0x1,_0x4f9fbd['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0xf8c69d,_0x4f9fbd['path']),_0x4f9fbd['status']=0x0;const _0x5cedf4=Un(_0x5d2150['transactionQueueTree_'],_0x3b4ac9),_0xa96be=Ge(_0x5cedf4)||[];_0xa96be['push'](_0x4f9fbd),fs(_0x5cedf4,_0xa96be);let _0x3cfd43;typeof _0xf8c69d=='object'&&_0xf8c69d!==null&&Y(_0xf8c69d,'.priority')?(_0x3cfd43=Oe(_0xf8c69d,'.priority'),f(Cn(_0x3cfd43),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3cfd43=(xn(_0x5d2150['serverSyncTree_'],_0x3b4ac9)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x427c31=jt(_0x5d2150),_0x48f997=N(_0xf8c69d,_0x3cfd43),_0x536a53=hs(_0x48f997,_0x5dadac,_0x427c31);_0x4f9fbd['currentOutputSnapshotRaw']=_0x48f997,_0x4f9fbd['currentOutputSnapshotResolved']=_0x536a53,_0x4f9fbd['currentWriteId']=Vn(_0x5d2150);const _0x36828d=ss(_0x5d2150['serverSyncTree_'],_0x3b4ac9,_0x536a53,_0x4f9fbd['currentWriteId'],_0x4f9fbd['applyLocally']);V(_0x5d2150['eventQueue_'],_0x3b4ac9,_0x36828d),Hn(_0x5d2150,_0x5d2150['transactionQueueTree_']);}}function ys(_0x2f18ac,_0x31a68d,_0x2b467a){return xn(_0x2f18ac['serverSyncTree_'],_0x31a68d,_0x2b467a)||g['EMPTY_NODE'];}function Hn(_0x5a92b6,_0x2df822=_0x5a92b6['transactionQueueTree_']){if(_0x2df822||$n(_0x5a92b6,_0x2df822),Ge(_0x2df822)){const _0x207dc2=la(_0x5a92b6,_0x2df822);f(_0x207dc2['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x207dc2['every'](_0x56ee85=>_0x56ee85['status']===0x0)&&Rd(_0x5a92b6,Gt(_0x2df822),_0x207dc2);}else ea(_0x2df822)&&Wn(_0x2df822,_0x5ee29a=>{Hn(_0x5a92b6,_0x5ee29a);});}function Rd(_0x564068,_0x379523,_0x332a82){const _0x486b3a=_0x332a82['map'](_0x372223=>_0x372223['currentWriteId']),_0x26eebc=ys(_0x564068,_0x379523,_0x486b3a);let _0x44b977=_0x26eebc;const _0x1ea4f7=_0x26eebc['hash']();for(let _0x2ddea2=0x0;_0x2ddea2<_0x332a82['length'];_0x2ddea2++){const _0x2520fc=_0x332a82[_0x2ddea2];f(_0x2520fc['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2520fc['status']=0x1,_0x2520fc['retryCount']++;const _0x3836c3=F(_0x379523,_0x2520fc['path']);_0x44b977=_0x44b977['updateChild'](_0x3836c3,_0x2520fc['currentOutputSnapshotRaw']);}const _0x18e171=_0x44b977['val'](!0x0),_0x878214=_0x379523;_0x564068['server_']['put'](_0x878214['toString'](),_0x18e171,_0x4c5281=>{ut(_0x564068,'transaction\x20put\x20response',{'path':_0x878214['toString'](),'status':_0x4c5281});let _0x335a55=[];if(_0x4c5281==='ok'){const _0x164938=[];for(let _0x22508b=0x0;_0x22508b<_0x332a82['length'];_0x22508b++)_0x332a82[_0x22508b]['status']=0x2,_0x335a55=_0x335a55['concat'](pe(_0x564068['serverSyncTree_'],_0x332a82[_0x22508b]['currentWriteId'])),_0x332a82[_0x22508b]['onComplete']&&_0x164938['push'](()=>_0x332a82[_0x22508b]['onComplete'](null,!0x0,_0x332a82[_0x22508b]['currentOutputSnapshotResolved'])),_0x332a82[_0x22508b]['unwatcher']();$n(_0x564068,Un(_0x564068['transactionQueueTree_'],_0x379523)),Hn(_0x564068,_0x564068['transactionQueueTree_']),V(_0x564068['eventQueue_'],_0x379523,_0x335a55);for(let _0x29f713=0x0;_0x29f713<_0x164938['length'];_0x29f713++)lt(_0x164938[_0x29f713]);}else{if(_0x4c5281==='datastale'){for(let _0x210e38=0x0;_0x210e38<_0x332a82['length'];_0x210e38++)_0x332a82[_0x210e38]['status']===0x3?_0x332a82[_0x210e38]['status']=0x4:_0x332a82[_0x210e38]['status']=0x0;}else{U('transaction\x20at\x20'+_0x878214['toString']()+'\x20failed:\x20'+_0x4c5281);for(let _0x17a7bc=0x0;_0x17a7bc<_0x332a82['length'];_0x17a7bc++)_0x332a82[_0x17a7bc]['status']=0x4,_0x332a82[_0x17a7bc]['abortReason']=_0x4c5281;}st(_0x564068,_0x379523);}},_0x1ea4f7);}function st(_0x40085b,_0x28a887){const _0x16f0f4=ca(_0x40085b,_0x28a887),_0x336f50=Gt(_0x16f0f4),_0x322425=la(_0x40085b,_0x16f0f4);return Ad(_0x40085b,_0x322425,_0x336f50),_0x336f50;}function Ad(_0x4ee7f7,_0x3db58f,_0x75b353){if(_0x3db58f['length']===0x0)return;const _0x4e1d0f=[];let _0x319c5d=[];const _0x1e9e47=_0x3db58f['filter'](_0x35a3d8=>_0x35a3d8['status']===0x0)['map'](_0x25a75f=>_0x25a75f['currentWriteId']);for(let _0x26cca1=0x0;_0x26cca1<_0x3db58f['length'];_0x26cca1++){const _0x25a9dc=_0x3db58f[_0x26cca1],_0x2e91ea=F(_0x75b353,_0x25a9dc['path']);let _0x17d807=!0x1,_0x44fcec;if(f(_0x2e91ea!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x25a9dc['status']===0x4)_0x17d807=!0x0,_0x44fcec=_0x25a9dc['abortReason'],_0x319c5d=_0x319c5d['concat'](pe(_0x4ee7f7['serverSyncTree_'],_0x25a9dc['currentWriteId'],!0x0));else{if(_0x25a9dc['status']===0x0){if(_0x25a9dc['retryCount']>=_d)_0x17d807=!0x0,_0x44fcec='maxretry',_0x319c5d=_0x319c5d['concat'](pe(_0x4ee7f7['serverSyncTree_'],_0x25a9dc['currentWriteId'],!0x0));else{const _0x9d315f=ys(_0x4ee7f7,_0x25a9dc['path'],_0x1e9e47);_0x25a9dc['currentInputSnapshot']=_0x9d315f;const _0xee586f=_0x3db58f[_0x26cca1]['update'](_0x9d315f['val']());if(_0xee586f!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0xee586f,_0x25a9dc['path']);let _0x299e17=N(_0xee586f);typeof _0xee586f=='object'&&_0xee586f!=null&&Y(_0xee586f,'.priority')||(_0x299e17=_0x299e17['updatePriority'](_0x9d315f['getPriority']()));const _0x99f6f8=_0x25a9dc['currentWriteId'],_0x210b32=jt(_0x4ee7f7),_0x3ddffb=hs(_0x299e17,_0x9d315f,_0x210b32);_0x25a9dc['currentOutputSnapshotRaw']=_0x299e17,_0x25a9dc['currentOutputSnapshotResolved']=_0x3ddffb,_0x25a9dc['currentWriteId']=Vn(_0x4ee7f7),_0x1e9e47['splice'](_0x1e9e47['indexOf'](_0x99f6f8),0x1),_0x319c5d=_0x319c5d['concat'](ss(_0x4ee7f7['serverSyncTree_'],_0x25a9dc['path'],_0x3ddffb,_0x25a9dc['currentWriteId'],_0x25a9dc['applyLocally'])),_0x319c5d=_0x319c5d['concat'](pe(_0x4ee7f7['serverSyncTree_'],_0x99f6f8,!0x0));}else _0x17d807=!0x0,_0x44fcec='nodata',_0x319c5d=_0x319c5d['concat'](pe(_0x4ee7f7['serverSyncTree_'],_0x25a9dc['currentWriteId'],!0x0));}}}V(_0x4ee7f7['eventQueue_'],_0x75b353,_0x319c5d),_0x319c5d=[],_0x17d807&&(_0x3db58f[_0x26cca1]['status']=0x2,function(_0x43a35d){setTimeout(_0x43a35d,Math['floor'](0x0));}(_0x3db58f[_0x26cca1]['unwatcher']),_0x3db58f[_0x26cca1]['onComplete']&&(_0x44fcec==='nodata'?_0x4e1d0f['push'](()=>_0x3db58f[_0x26cca1]['onComplete'](null,!0x1,_0x3db58f[_0x26cca1]['currentInputSnapshot'])):_0x4e1d0f['push'](()=>_0x3db58f[_0x26cca1]['onComplete'](new Error(_0x44fcec),!0x1,null))));}$n(_0x4ee7f7,_0x4ee7f7['transactionQueueTree_']);for(let _0x5d1fe0=0x0;_0x5d1fe0<_0x4e1d0f['length'];_0x5d1fe0++)lt(_0x4e1d0f[_0x5d1fe0]);Hn(_0x4ee7f7,_0x4ee7f7['transactionQueueTree_']);}function ca(_0x25835d,_0x2f1181){let _0xd69983,_0x11966b=_0x25835d['transactionQueueTree_'];for(_0xd69983=y(_0x2f1181);_0xd69983!==null&&Ge(_0x11966b)===void 0x0;)_0x11966b=Un(_0x11966b,_0xd69983),_0x2f1181=b(_0x2f1181),_0xd69983=y(_0x2f1181);return _0x11966b;}function la(_0x2e73a,_0x291b58){const _0x4d58b4=[];return ha(_0x2e73a,_0x291b58,_0x4d58b4),_0x4d58b4['sort']((_0x4a95a1,_0x25e533)=>_0x4a95a1['order']-_0x25e533['order']),_0x4d58b4;}function ha(_0x21d768,_0x545245,_0x28af9d){const _0x4efec2=Ge(_0x545245);if(_0x4efec2){for(let _0x1c887e=0x0;_0x1c887e<_0x4efec2['length'];_0x1c887e++)_0x28af9d['push'](_0x4efec2[_0x1c887e]);}Wn(_0x545245,_0x5cfd50=>{ha(_0x21d768,_0x5cfd50,_0x28af9d);});}function $n(_0x2da017,_0x4d2a73){const _0x743b5=Ge(_0x4d2a73);if(_0x743b5){let _0x3d2d29=0x0;for(let _0x4f2da3=0x0;_0x4f2da3<_0x743b5['length'];_0x4f2da3++)_0x743b5[_0x4f2da3]['status']!==0x2&&(_0x743b5[_0x3d2d29]=_0x743b5[_0x4f2da3],_0x3d2d29++);_0x743b5['length']=_0x3d2d29,fs(_0x4d2a73,_0x743b5['length']>0x0?_0x743b5:void 0x0);}Wn(_0x4d2a73,_0x536227=>{$n(_0x2da017,_0x536227);});}function vs(_0x3dff08,_0x58b691){const _0xd66149=Gt(ca(_0x3dff08,_0x58b691)),_0x439f2b=Un(_0x3dff08['transactionQueueTree_'],_0x58b691);return sd(_0x439f2b,_0x4d5523=>{ai(_0x3dff08,_0x4d5523);}),ai(_0x3dff08,_0x439f2b),ta(_0x439f2b,_0x2c3f02=>{ai(_0x3dff08,_0x2c3f02);}),_0xd66149;}function ai(_0x58ffaa,_0x2a749a){const _0x6b00a6=Ge(_0x2a749a);if(_0x6b00a6){const _0x5d9874=[];let _0x32d0a6=[],_0x154fb7=-0x1;for(let _0x1feb8f=0x0;_0x1feb8f<_0x6b00a6['length'];_0x1feb8f++)_0x6b00a6[_0x1feb8f]['status']===0x3||(_0x6b00a6[_0x1feb8f]['status']===0x1?(f(_0x154fb7===_0x1feb8f-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x154fb7=_0x1feb8f,_0x6b00a6[_0x1feb8f]['status']=0x3,_0x6b00a6[_0x1feb8f]['abortReason']='set'):(f(_0x6b00a6[_0x1feb8f]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x6b00a6[_0x1feb8f]['unwatcher'](),_0x32d0a6=_0x32d0a6['concat'](pe(_0x58ffaa['serverSyncTree_'],_0x6b00a6[_0x1feb8f]['currentWriteId'],!0x0)),_0x6b00a6[_0x1feb8f]['onComplete']&&_0x5d9874['push'](_0x6b00a6[_0x1feb8f]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x154fb7===-0x1?fs(_0x2a749a,void 0x0):_0x6b00a6['length']=_0x154fb7+0x1,V(_0x58ffaa['eventQueue_'],Gt(_0x2a749a),_0x32d0a6);for(let _0x493efb=0x0;_0x493efb<_0x5d9874['length'];_0x493efb++)lt(_0x5d9874[_0x493efb]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x5656f2){let _0x36c7de='';const _0x5319c6=_0x5656f2['split']('/');for(let _0x1261ac=0x0;_0x1261ac<_0x5319c6['length'];_0x1261ac++)if(_0x5319c6[_0x1261ac]['length']>0x0){let _0x256fd8=_0x5319c6[_0x1261ac];try{_0x256fd8=decodeURIComponent(_0x256fd8['replace'](/\+/g,'\x20'));}catch{}_0x36c7de+='/'+_0x256fd8;}return _0x36c7de;}function Nd(_0x1b0d00){const _0xbdf36e={};_0x1b0d00['charAt'](0x0)==='?'&&(_0x1b0d00=_0x1b0d00['substring'](0x1));for(const _0x1c7672 of _0x1b0d00['split']('&')){if(_0x1c7672['length']===0x0)continue;const _0x20675c=_0x1c7672['split']('=');_0x20675c['length']===0x2?_0xbdf36e[decodeURIComponent(_0x20675c[0x0])]=decodeURIComponent(_0x20675c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1c7672+'\x27\x20in\x20query\x20\x27'+_0x1b0d00+'\x27');}return _0xbdf36e;}const gr=function(_0x411ab0,_0x4a9e10){const _0x1eb09f=Pd(_0x411ab0),_0x5b0d32=_0x1eb09f['namespace'];_0x1eb09f['domain']==='firebase.com'&&oe(_0x1eb09f['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5b0d32||_0x5b0d32==='undefined')&&_0x1eb09f['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1eb09f['secure']||Bl();const _0x2437b2=_0x1eb09f['scheme']==='ws'||_0x1eb09f['scheme']==='wss';return{'repoInfo':new _o(_0x1eb09f['host'],_0x1eb09f['secure'],_0x5b0d32,_0x2437b2,_0x4a9e10,'',_0x5b0d32!==_0x1eb09f['subdomain']),'path':new C(_0x1eb09f['pathString'])};},Pd=function(_0x58cc62){let _0x33b7db='',_0x327e01='',_0x18fd5a='',_0x56aef7='',_0x1b3e93='',_0x42577a=!0x0,_0x36de03='https',_0xbdf206=0x1bb;if(typeof _0x58cc62=='string'){let _0x123ad4=_0x58cc62['indexOf']('//');_0x123ad4>=0x0&&(_0x36de03=_0x58cc62['substring'](0x0,_0x123ad4-0x1),_0x58cc62=_0x58cc62['substring'](_0x123ad4+0x2));let _0x203d71=_0x58cc62['indexOf']('/');_0x203d71===-0x1&&(_0x203d71=_0x58cc62['length']);let _0x114958=_0x58cc62['indexOf']('?');_0x114958===-0x1&&(_0x114958=_0x58cc62['length']),_0x33b7db=_0x58cc62['substring'](0x0,Math['min'](_0x203d71,_0x114958)),_0x203d71<_0x114958&&(_0x56aef7=kd(_0x58cc62['substring'](_0x203d71,_0x114958)));const _0x4f14bd=Nd(_0x58cc62['substring'](Math['min'](_0x58cc62['length'],_0x114958)));_0x123ad4=_0x33b7db['indexOf'](':'),_0x123ad4>=0x0?(_0x42577a=_0x36de03==='https'||_0x36de03==='wss',_0xbdf206=parseInt(_0x33b7db['substring'](_0x123ad4+0x1),0xa)):_0x123ad4=_0x33b7db['length'];const _0x464756=_0x33b7db['slice'](0x0,_0x123ad4);if(_0x464756['toLowerCase']()==='localhost')_0x327e01='localhost';else{if(_0x464756['split']('.')['length']<=0x2)_0x327e01=_0x464756;else{const _0x1e1860=_0x33b7db['indexOf']('.');_0x18fd5a=_0x33b7db['substring'](0x0,_0x1e1860)['toLowerCase'](),_0x327e01=_0x33b7db['substring'](_0x1e1860+0x1),_0x1b3e93=_0x18fd5a;}}'ns'in _0x4f14bd&&(_0x1b3e93=_0x4f14bd['ns']);}return{'host':_0x33b7db,'port':_0xbdf206,'domain':_0x327e01,'subdomain':_0x18fd5a,'secure':_0x42577a,'scheme':_0x36de03,'pathString':_0x56aef7,'namespace':_0x1b3e93};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x2102bf=0x0;const _0x1057c3=[];return function(_0x1c1185){const _0x15cb2a=_0x1c1185===_0x2102bf;_0x2102bf=_0x1c1185;let _0x12db07;const _0x2dc90e=new Array(0x8);for(_0x12db07=0x7;_0x12db07>=0x0;_0x12db07--)_0x2dc90e[_0x12db07]=mr['charAt'](_0x1c1185%0x40),_0x1c1185=Math['floor'](_0x1c1185/0x40);f(_0x1c1185===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x4e42f1=_0x2dc90e['join']('');if(_0x15cb2a){for(_0x12db07=0xb;_0x12db07>=0x0&&_0x1057c3[_0x12db07]===0x3f;_0x12db07--)_0x1057c3[_0x12db07]=0x0;_0x1057c3[_0x12db07]++;}else{for(_0x12db07=0x0;_0x12db07<0xc;_0x12db07++)_0x1057c3[_0x12db07]=Math['floor'](Math['random']()*0x40);}for(_0x12db07=0x0;_0x12db07<0xc;_0x12db07++)_0x4e42f1+=mr['charAt'](_0x1057c3[_0x12db07]);return f(_0x4e42f1['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x4e42f1;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x2437d7,_0xccc874,_0x5a498f,_0x139ffd){this['eventType']=_0x2437d7,this['eventRegistration']=_0xccc874,this['snapshot']=_0x5a498f,this['prevName']=_0x139ffd;}['getPath'](){const _0x49d005=this['snapshot']['ref'];return this['eventType']==='value'?_0x49d005['_path']:_0x49d005['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x288a45,_0x517758,_0x5a88b4){this['eventRegistration']=_0x288a45,this['error']=_0x517758,this['path']=_0x5a88b4;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0xac684,_0xd3f631){this['snapshotCallback']=_0xac684,this['cancelCallback']=_0xd3f631;}['onValue'](_0x31ffd0,_0x54d779){this['snapshotCallback']['call'](null,_0x31ffd0,_0x54d779);}['onCancel'](_0x291d35){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x291d35);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x355d53){return this['snapshotCallback']===_0x355d53['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x355d53['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x355d53['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x557d70,_0x496e99,_0x17b50c,_0x4b2256){this['_repo']=_0x557d70,this['_path']=_0x496e99,this['_queryParams']=_0x17b50c,this['_orderByCalled']=_0x4b2256;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5fa84=nr(this['_queryParams']),_0x493c60=Bi(_0x5fa84);return _0x493c60==='{}'?'default':_0x493c60;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x540a3a){if(_0x540a3a=k(_0x540a3a),!(_0x540a3a instanceof be))return!0x1;const _0x18053f=this['_repo']===_0x540a3a['_repo'],_0x34a692=qi(this['_path'],_0x540a3a['_path']),_0x8a310c=this['_queryIdentifier']===_0x540a3a['_queryIdentifier'];return _0x18053f&&_0x34a692&&_0x8a310c;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x52f224,_0x26a8b5){if(_0x52f224['_orderByCalled']===!0x0)throw new Error(_0x26a8b5+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x32d035){let _0x38a4c0=null,_0x252591=null;if(_0x32d035['hasStart']()&&(_0x38a4c0=_0x32d035['getIndexStartValue']()),_0x32d035['hasEnd']()&&(_0x252591=_0x32d035['getIndexEndValue']()),_0x32d035['getIndex']()===ye){const _0x1d1c31='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3cb943='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x32d035['hasStart']()){if(_0x32d035['getIndexStartName']()!==xe)throw new Error(_0x1d1c31);if(typeof _0x38a4c0!='string')throw new Error(_0x3cb943);}if(_0x32d035['hasEnd']()){if(_0x32d035['getIndexEndName']()!==Ie)throw new Error(_0x1d1c31);if(typeof _0x252591!='string')throw new Error(_0x3cb943);}}else{if(_0x32d035['getIndex']()===R){if(_0x38a4c0!=null&&!Cn(_0x38a4c0)||_0x252591!=null&&!Cn(_0x252591))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x32d035['getIndex']()instanceof Ki||_0x32d035['getIndex']()===Po,'unknown\x20index\x20type.'),_0x38a4c0!=null&&typeof _0x38a4c0=='object'||_0x252591!=null&&typeof _0x252591=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2e8cec){if(_0x2e8cec['hasStart']()&&_0x2e8cec['hasEnd']()&&_0x2e8cec['hasLimit']()&&!_0x2e8cec['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x516eb8,_0x64f819){super(_0x516eb8,_0x64f819,new Qi(),!0x1);}get['parent'](){const _0x11b1be=To(this['_path']);return _0x11b1be===null?null:new Z(this['_repo'],_0x11b1be);}get['root'](){let _0x253c6a=this;for(;_0x253c6a['parent']!==null;)_0x253c6a=_0x253c6a['parent'];return _0x253c6a;}}class rt{constructor(_0x3c1371,_0x41f039,_0x92a255){this['_node']=_0x3c1371,this['ref']=_0x41f039,this['_index']=_0x92a255;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4714d2){const _0x15b3e2=new C(_0x4714d2),_0x4ab36d=Lt(this['ref'],_0x4714d2);return new rt(this['_node']['getChild'](_0x15b3e2),_0x4ab36d,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x45a26d){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x40e208,_0x4649f5)=>_0x45a26d(new rt(_0x4649f5,Lt(this['ref'],_0x40e208),R)));}['hasChild'](_0x52aa37){const _0x429432=new C(_0x52aa37);return!this['_node']['getChild'](_0x429432)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x4cfa31,_0x49acaf){return _0x4cfa31=k(_0x4cfa31),_0x4cfa31['_checkNotDeleted']('ref'),_0x49acaf!==void 0x0?Lt(_0x4cfa31['_root'],_0x49acaf):_0x4cfa31['_root'];}function Lt(_0x490220,_0x2248c8){return _0x490220=k(_0x490220),y(_0x490220['_path'])===null?ud('child','path',_0x2248c8):_s('child','path',_0x2248c8),new Z(_0x490220['_repo'],A(_0x490220['_path'],_0x2248c8));}function d_(_0x20903c,_0x1e0469){_0x20903c=k(_0x20903c),gs('push',_0x20903c['_path']),qt('push',_0x1e0469,_0x20903c['_path'],!0x0);const _0x109f56=oa(_0x20903c['_repo']),_0x2d7b2c=Od(_0x109f56),_0x3826bb=Lt(_0x20903c,_0x2d7b2c),_0x423307=Lt(_0x20903c,_0x2d7b2c);let _0x1f858f;return _0x1e0469!=null?_0x1f858f=Ld(_0x423307,_0x1e0469)['then'](()=>_0x423307):_0x1f858f=Promise['resolve'](_0x423307),_0x3826bb['then']=_0x1f858f['then']['bind'](_0x1f858f),_0x3826bb['catch']=_0x1f858f['then']['bind'](_0x1f858f,void 0x0),_0x3826bb;}function Ld(_0x396510,_0x34b04f){_0x396510=k(_0x396510),gs('set',_0x396510['_path']),qt('set',_0x34b04f,_0x396510['_path'],!0x1);const _0x24ccce=new Ve();return Ed(_0x396510['_repo'],_0x396510['_path'],_0x34b04f,null,_0x24ccce['wrapCallback'](()=>{})),_0x24ccce['promise'];}function f_(_0x1dd337,_0x554db4){hd('update',_0x554db4,_0x1dd337['_path']);const _0x9e7474=new Ve();return Id(_0x1dd337['_repo'],_0x1dd337['_path'],_0x554db4,_0x9e7474['wrapCallback'](()=>{})),_0x9e7474['promise'];}function p_(_0x129b8f){_0x129b8f=k(_0x129b8f);const _0x2795ff=new ua(()=>{}),_0x2e4288=new qn(_0x2795ff);return vd(_0x129b8f['_repo'],_0x129b8f,_0x2e4288)['then'](_0x400000=>new rt(_0x400000,new Z(_0x129b8f['_repo'],_0x129b8f['_path']),_0x129b8f['_queryParams']['getIndex']()));}class qn{constructor(_0x3cc67e){this['callbackContext']=_0x3cc67e;}['respondsTo'](_0x490aa6){return _0x490aa6==='value';}['createEvent'](_0x15304c,_0x272d7a){const _0xdd3c6c=_0x272d7a['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x15304c['snapshotNode'],new Z(_0x272d7a['_repo'],_0x272d7a['_path']),_0xdd3c6c));}['getEventRunner'](_0x54d834){return _0x54d834['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x54d834['error']):()=>this['callbackContext']['onValue'](_0x54d834['snapshot'],null);}['createCancelEvent'](_0x512221,_0x2d7c9c){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x512221,_0x2d7c9c):null;}['matches'](_0x360e9f){return _0x360e9f instanceof qn?!_0x360e9f['callbackContext']||!this['callbackContext']?!0x0:_0x360e9f['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x15f0e1,_0x410d4a,_0x409a2a,_0x2982e5,_0x3f7823){const _0x23aa1b=new ua(_0x409a2a,void 0x0),_0x2f0fad=new qn(_0x23aa1b);return Cd(_0x15f0e1['_repo'],_0x15f0e1,_0x2f0fad),()=>Td(_0x15f0e1['_repo'],_0x15f0e1,_0x2f0fad);}function Fd(_0x1df57c,_0x235e2a,_0x4ddad4,_0xbb8f78){return xd(_0x1df57c,'value',_0x235e2a);}class dt{}class pa extends dt{constructor(_0x38a337,_0x5d338d){super(),this['_value']=_0x38a337,this['_key']=_0x5d338d,this['type']='endAt';}['_apply'](_0x4c9db2){qt('endAt',this['_value'],_0x4c9db2['_path'],!0x0);const _0x20e58d=Kh(_0x4c9db2['_queryParams'],this['_value'],this['_key']);if(fa(_0x20e58d),Gn(_0x20e58d),_0x4c9db2['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x4c9db2['_repo'],_0x4c9db2['_path'],_0x20e58d,_0x4c9db2['_orderByCalled']);}}function __(_0x106b42,_0x5464b5){return new pa(_0x106b42,_0x5464b5);}class _a extends dt{constructor(_0x24dc8f,_0x9f4cea){super(),this['_value']=_0x24dc8f,this['_key']=_0x9f4cea,this['type']='startAt';}['_apply'](_0x119695){qt('startAt',this['_value'],_0x119695['_path'],!0x0);const _0x195eed=jh(_0x119695['_queryParams'],this['_value'],this['_key']);if(fa(_0x195eed),Gn(_0x195eed),_0x119695['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x119695['_repo'],_0x119695['_path'],_0x195eed,_0x119695['_orderByCalled']);}}function g_(_0x5189f6=null,_0x4fdea9){return new _a(_0x5189f6,_0x4fdea9);}class Ud extends dt{constructor(_0x156ca3){super(),this['_limit']=_0x156ca3,this['type']='limitToFirst';}['_apply'](_0xa6b04b){if(_0xa6b04b['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0xa6b04b['_repo'],_0xa6b04b['_path'],zh(_0xa6b04b['_queryParams'],this['_limit']),_0xa6b04b['_orderByCalled']);}}function m_(_0x160c8d){if(Math['floor'](_0x160c8d)!==_0x160c8d||_0x160c8d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x160c8d);}class Wd extends dt{constructor(_0x3935d3){super(),this['_path']=_0x3935d3,this['type']='orderByChild';}['_apply'](_0x44da4e){da(_0x44da4e,'orderByChild');const _0x4dc001=new C(this['_path']);if(v(_0x4dc001))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x40b059=new Ki(_0x4dc001),_0x740a7d=Do(_0x44da4e['_queryParams'],_0x40b059);return Gn(_0x740a7d),new be(_0x44da4e['_repo'],_0x44da4e['_path'],_0x740a7d,!0x0);}}function y_(_0x26f99b){if(_0x26f99b==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x26f99b==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x26f99b==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x26f99b),new Wd(_0x26f99b);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x13cb4e){da(_0x13cb4e,'orderByKey');const _0x11bd0b=Do(_0x13cb4e['_queryParams'],ye);return Gn(_0x11bd0b),new be(_0x13cb4e['_repo'],_0x13cb4e['_path'],_0x11bd0b,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x3511c3,_0xd41362){super(),this['_value']=_0x3511c3,this['_key']=_0xd41362,this['type']='equalTo';}['_apply'](_0x3a1ac1){if(qt('equalTo',this['_value'],_0x3a1ac1['_path'],!0x1),_0x3a1ac1['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3a1ac1['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x3a1ac1));}}function E_(_0x5dbb10,_0xe0171e){return new Vd(_0x5dbb10,_0xe0171e);}function I_(_0x47ca51,..._0xa2c90b){let _0x463fc8=k(_0x47ca51);for(const _0x2b8374 of _0xa2c90b)_0x463fc8=_0x2b8374['_apply'](_0x463fc8);return _0x463fc8;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x312f29,_0x365691,_0x28f408,_0x6294da){const _0x437bc4=_0x365691['lastIndexOf'](':'),_0x363776=_0x365691['substring'](0x0,_0x437bc4),_0x4c2130=Wt(_0x363776);_0x312f29['repoInfo_']=new _o(_0x365691,_0x4c2130,_0x312f29['repoInfo_']['namespace'],_0x312f29['repoInfo_']['webSocketOnly'],_0x312f29['repoInfo_']['nodeAdmin'],_0x312f29['repoInfo_']['persistenceKey'],_0x312f29['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x28f408),_0x6294da&&(_0x312f29['authTokenProvider_']=_0x6294da);}function qd(_0x50a427,_0x47959b,_0x1f8f27,_0x532753,_0xa32441){let _0x24138b=_0x532753||_0x50a427['options']['databaseURL'];_0x24138b===void 0x0&&(_0x50a427['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x50a427['options']['projectId']),_0x24138b=_0x50a427['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x1c6485=gr(_0x24138b,_0xa32441),_0x49901e=_0x1c6485['repoInfo'],_0x1f5ba4;typeof process<'u'&&Us&&(_0x1f5ba4=Us[Hd]),_0x1f5ba4?(_0x24138b='http://'+_0x1f5ba4+'?ns='+_0x49901e['namespace'],_0x1c6485=gr(_0x24138b,_0xa32441),_0x49901e=_0x1c6485['repoInfo']):_0x1c6485['repoInfo']['secure'];const _0x3bb563=new Jl(_0x50a427['name'],_0x50a427['options'],_0x47959b);dd('Invalid\x20Firebase\x20Database\x20URL',_0x1c6485),v(_0x1c6485['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x505dee=jd(_0x49901e,_0x50a427,_0x3bb563,new Ql(_0x50a427,_0x1f8f27));return new Kd(_0x505dee,_0x50a427);}function zd(_0x5975d1,_0x486b55){const _0x340241=ki[_0x486b55];(!_0x340241||_0x340241[_0x5975d1['key']]!==_0x5975d1)&&oe('Database\x20'+_0x486b55+'('+_0x5975d1['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x5975d1),delete _0x340241[_0x5975d1['key']];}function jd(_0x10b16c,_0x14aab5,_0x485226,_0x295cbe){let _0x11d140=ki[_0x14aab5['name']];_0x11d140||(_0x11d140={},ki[_0x14aab5['name']]=_0x11d140);let _0x236d34=_0x11d140[_0x10b16c['toURLString']()];return _0x236d34&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x236d34=new gd(_0x10b16c,$d,_0x485226,_0x295cbe),_0x11d140[_0x10b16c['toURLString']()]=_0x236d34,_0x236d34;}class Kd{constructor(_0x36ec33,_0x233a33){this['_repoInternal']=_0x36ec33,this['app']=_0x233a33,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x1ceef3){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x1ceef3+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x1be411=Qr(),_0x27615b){const _0x49ef93=Ui(_0x1be411,'database')['getImmediate']({'identifier':_0x27615b});if(!_0x49ef93['_instanceStarted']){const _0x2cc77c=ac('database');_0x2cc77c&&Yd(_0x49ef93,..._0x2cc77c);}return _0x49ef93;}function Yd(_0x5a6e5c,_0x209fc6,_0xfed57b,_0x404795={}){_0x5a6e5c=k(_0x5a6e5c),_0x5a6e5c['_checkNotDeleted']('useEmulator');const _0x4a057f=_0x209fc6+':'+_0xfed57b,_0x33b057=_0x5a6e5c['_repoInternal'];if(_0x5a6e5c['_instanceStarted']){if(_0x4a057f===_0x5a6e5c['_repoInternal']['repoInfo_']['host']&&De(_0x404795,_0x33b057['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x520777;if(_0x33b057['repoInfo_']['nodeAdmin'])_0x404795['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x520777=new tn(tn['OWNER']);else{if(_0x404795['mockUserToken']){const _0x1ec1d6=typeof _0x404795['mockUserToken']=='string'?_0x404795['mockUserToken']:cc(_0x404795['mockUserToken'],_0x5a6e5c['app']['options']['projectId']);_0x520777=new tn(_0x1ec1d6);}}Wt(_0x209fc6)&&jr(_0x209fc6),Gd(_0x33b057,_0x4a057f,_0x404795,_0x520777);}function C_(_0xd56583){_0xd56583=k(_0xd56583),_0xd56583['_checkNotDeleted']('goOffline'),aa(_0xd56583['_repo']);}function T_(_0x4e49eb){_0x4e49eb=k(_0x4e49eb),_0x4e49eb['_checkNotDeleted']('goOnline'),Sd(_0x4e49eb['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x2e6dd9){Ll(ct),et(new Me('database',(_0x38a5ef,{instanceIdentifier:_0x5592b7})=>{const _0xdb552a=_0x38a5ef['getProvider']('app')['getImmediate'](),_0xa16441=_0x38a5ef['getProvider']('auth-internal'),_0x1c0771=_0x38a5ef['getProvider']('app-check-internal');return qd(_0xdb552a,_0xa16441,_0x1c0771,_0x5592b7);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x2e6dd9),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x363d4b,_0x310e2e){this['committed']=_0x363d4b,this['snapshot']=_0x310e2e;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x2991d5,_0x413f2d,_0x520e97){if(_0x2991d5=k(_0x2991d5),gs('Reference.transaction',_0x2991d5['_path']),_0x2991d5['key']==='.length'||_0x2991d5['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x2991d5['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5c7b57=!0x0,_0x3bd8e4=new Ve(),_0x5b4e3d=(_0x30fb8a,_0x405440,_0x26a05c)=>{let _0xeac455=null;_0x30fb8a?_0x3bd8e4['reject'](_0x30fb8a):(_0xeac455=new rt(_0x26a05c,new Z(_0x2991d5['_repo'],_0x2991d5['_path']),R),_0x3bd8e4['resolve'](new Xd(_0x405440,_0xeac455)));},_0x30d2e7=Fd(_0x2991d5,()=>{});return bd(_0x2991d5['_repo'],_0x2991d5['_path'],_0x413f2d,_0x5b4e3d,_0x30d2e7,_0x5c7b57),_0x3bd8e4['promise'];}ie['prototype']['simpleListen']=function(_0x3e71ff,_0x469b13){this['sendRequest']('q',{'p':_0x3e71ff},_0x469b13);},ie['prototype']['echo']=function(_0x175478,_0x13364a){this['sendRequest']('echo',{'d':_0x175478},_0x13364a);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x1a22d9,..._0x29cc0a){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x1a22d9,..._0x29cc0a);}function nn(_0x2fbc46,..._0x36ec13){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x2fbc46,..._0x36ec13);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x127c37,..._0x3fd058){throw Es(_0x127c37,..._0x3fd058);}function J(_0x16b649,..._0x44fcdc){return Es(_0x16b649,..._0x44fcdc);}function ya(_0x2e28b7,_0x9f03c3,_0xba1947){const _0x3cb31={...Zd(),[_0x9f03c3]:_0xba1947};return new Ut('auth','Firebase',_0x3cb31)['create'](_0x9f03c3,{'appName':_0x2e28b7['name']});}function se(_0xd08fec){return ya(_0xd08fec,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x551eae,..._0x41bea2){if(typeof _0x551eae!='string'){const _0x3195d8=_0x41bea2[0x0],_0x389728=[..._0x41bea2['slice'](0x1)];return _0x389728[0x0]&&(_0x389728[0x0]['appName']=_0x551eae['name']),_0x551eae['_errorFactory']['create'](_0x3195d8,..._0x389728);}return ma['create'](_0x551eae,..._0x41bea2);}function m(_0x353d64,_0x3f21c9,..._0x1bfa27){if(!_0x353d64)throw Es(_0x3f21c9,..._0x1bfa27);}function te(_0x5f86be){const _0x3cf2d4='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x5f86be;throw nn(_0x3cf2d4),new Error(_0x3cf2d4);}function ae(_0x53291b,_0x36878e){_0x53291b||te(_0x36878e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x3d9ede;return typeof self<'u'&&((_0x3d9ede=self['location'])==null?void 0x0:_0x3d9ede['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x4cb67c;return typeof self<'u'&&((_0x4cb67c=self['location'])==null?void 0x0:_0x4cb67c['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x225574=navigator;return _0x225574['languages']&&_0x225574['languages'][0x0]||_0x225574['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x1f4c7a,_0x33c24c){this['shortDelay']=_0x1f4c7a,this['longDelay']=_0x33c24c,ae(_0x33c24c>_0x1f4c7a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x31b57d,_0x4ff0c7){ae(_0x31b57d['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x594730}=_0x31b57d['emulator'];return _0x4ff0c7?''+_0x594730+(_0x4ff0c7['startsWith']('/')?_0x4ff0c7['slice'](0x1):_0x4ff0c7):_0x594730;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x30ad10,_0x243843,_0xa91e88){this['fetchImpl']=_0x30ad10,_0x243843&&(this['headersImpl']=_0x243843),_0xa91e88&&(this['responseImpl']=_0xa91e88);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x18ab4f,_0x1cbc97){return _0x18ab4f['tenantId']&&!_0x1cbc97['tenantId']?{..._0x1cbc97,'tenantId':_0x18ab4f['tenantId']}:_0x1cbc97;}async function Ae(_0x48e866,_0x53bc58,_0x21e4ec,_0x3ee94e,_0xb09b4b={}){return Ea(_0x48e866,_0xb09b4b,async()=>{let _0x47da4d={},_0xb9812f={};_0x3ee94e&&(_0x53bc58==='GET'?_0xb9812f=_0x3ee94e:_0x47da4d={'body':JSON['stringify'](_0x3ee94e)});const _0x16a45f=at({..._0xb9812f,'key':_0x48e866['config']['apiKey']})['slice'](0x1),_0x4e4dd9=await _0x48e866['_getAdditionalHeaders']();_0x4e4dd9['Content-Type']='application/json',_0x48e866['languageCode']&&(_0x4e4dd9['X-Firebase-Locale']=_0x48e866['languageCode']);const _0x5b228c={'method':_0x53bc58,'headers':_0x4e4dd9,..._0x47da4d};return lc()||(_0x5b228c['referrerPolicy']='strict-origin-when-cross-origin'),_0x48e866['emulatorConfig']&&Wt(_0x48e866['emulatorConfig']['host'])&&(_0x5b228c['credentials']='include'),va['fetch']()(await Ia(_0x48e866,_0x48e866['config']['apiHost'],_0x21e4ec,_0x16a45f),_0x5b228c);});}async function Ea(_0x26ee0a,_0x30ed4f,_0x1a884d){_0x26ee0a['_canInitEmulator']=!0x1;const _0x4aa949={...rf,..._0x30ed4f};try{const _0x282b8c=new lf(_0x26ee0a),_0x34a6ef=await Promise['race']([_0x1a884d(),_0x282b8c['promise']]);_0x282b8c['clearNetworkTimeout']();const _0x3dbbfb=await _0x34a6ef['json']();if('needConfirmation'in _0x3dbbfb)throw en(_0x26ee0a,'account-exists-with-different-credential',_0x3dbbfb);if(_0x34a6ef['ok']&&!('errorMessage'in _0x3dbbfb))return _0x3dbbfb;{const _0x27298e=_0x34a6ef['ok']?_0x3dbbfb['errorMessage']:_0x3dbbfb['error']['message'],[_0x828339,_0x286dc7]=_0x27298e['split']('\x20:\x20');if(_0x828339==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x26ee0a,'credential-already-in-use',_0x3dbbfb);if(_0x828339==='EMAIL_EXISTS')throw en(_0x26ee0a,'email-already-in-use',_0x3dbbfb);if(_0x828339==='USER_DISABLED')throw en(_0x26ee0a,'user-disabled',_0x3dbbfb);const _0x5b36b6=_0x4aa949[_0x828339]||_0x828339['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x286dc7)throw ya(_0x26ee0a,_0x5b36b6,_0x286dc7);K(_0x26ee0a,_0x5b36b6);}}catch(_0x3ccfc3){if(_0x3ccfc3 instanceof Se)throw _0x3ccfc3;K(_0x26ee0a,'network-request-failed',{'message':String(_0x3ccfc3)});}}async function Yt(_0x13f408,_0x259b47,_0x5512c1,_0x5b076b,_0x193f69={}){const _0x42458d=await Ae(_0x13f408,_0x259b47,_0x5512c1,_0x5b076b,_0x193f69);return'mfaPendingCredential'in _0x42458d&&K(_0x13f408,'multi-factor-auth-required',{'_serverResponse':_0x42458d}),_0x42458d;}async function Ia(_0x1c5b54,_0x28d3b0,_0x2ea2ac,_0x1072a3){const _0xb46b56=''+_0x28d3b0+_0x2ea2ac+'?'+_0x1072a3,_0x264990=_0x1c5b54,_0x2803a3=_0x264990['config']['emulator']?Is(_0x1c5b54['config'],_0xb46b56):_0x1c5b54['config']['apiScheme']+'://'+_0xb46b56;return of['includes'](_0x2ea2ac)&&(await _0x264990['_persistenceManagerAvailable'],_0x264990['_getPersistenceType']()==='COOKIE')?_0x264990['_getPersistence']()['_getFinalTarget'](_0x2803a3)['toString']():_0x2803a3;}function cf(_0x57169e){switch(_0x57169e){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x1bb613){this['auth']=_0x1bb613,this['timer']=null,this['promise']=new Promise((_0x261ea7,_0x5bf64e)=>{this['timer']=setTimeout(()=>_0x5bf64e(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x25043a,_0x56de0e,_0x252820){const _0xab602b={'appName':_0x25043a['name']};_0x252820['email']&&(_0xab602b['email']=_0x252820['email']),_0x252820['phoneNumber']&&(_0xab602b['phoneNumber']=_0x252820['phoneNumber']);const _0x112c01=J(_0x25043a,_0x56de0e,_0xab602b);return _0x112c01['customData']['_tokenResponse']=_0x252820,_0x112c01;}function vr(_0x3a88db){return _0x3a88db!==void 0x0&&_0x3a88db['enterprise']!==void 0x0;}class hf{constructor(_0x30dfb5){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x30dfb5['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x30dfb5['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x30dfb5['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2fd2cf){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3debe1 of this['recaptchaEnforcementState'])if(_0x3debe1['provider']&&_0x3debe1['provider']===_0x2fd2cf)return cf(_0x3debe1['enforcementState']);return null;}['isProviderEnabled'](_0x157cfa){return this['getProviderEnforcementState'](_0x157cfa)==='ENFORCE'||this['getProviderEnforcementState'](_0x157cfa)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0xcaeaa4,_0x3af2a1){return Ae(_0xcaeaa4,'GET','/v2/recaptchaConfig',Re(_0xcaeaa4,_0x3af2a1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x4b5e5e,_0xbf527f){return Ae(_0x4b5e5e,'POST','/v1/accounts:delete',_0xbf527f);}async function Sn(_0x113318,_0x4a72db){return Ae(_0x113318,'POST','/v1/accounts:lookup',_0x4a72db);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x32b362){if(_0x32b362)try{const _0x28156c=new Date(Number(_0x32b362));if(!isNaN(_0x28156c['getTime']()))return _0x28156c['toUTCString']();}catch{}}async function ff(_0x408083,_0x29f57f=!0x1){const _0xfca07e=k(_0x408083),_0x54eb08=await _0xfca07e['getIdToken'](_0x29f57f),_0x5409b9=ws(_0x54eb08);m(_0x5409b9&&_0x5409b9['exp']&&_0x5409b9['auth_time']&&_0x5409b9['iat'],_0xfca07e['auth'],'internal-error');const _0x22fe4a=typeof _0x5409b9['firebase']=='object'?_0x5409b9['firebase']:void 0x0,_0x33a698=_0x22fe4a==null?void 0x0:_0x22fe4a['sign_in_provider'];return{'claims':_0x5409b9,'token':_0x54eb08,'authTime':St(ci(_0x5409b9['auth_time'])),'issuedAtTime':St(ci(_0x5409b9['iat'])),'expirationTime':St(ci(_0x5409b9['exp'])),'signInProvider':_0x33a698||null,'signInSecondFactor':(_0x22fe4a==null?void 0x0:_0x22fe4a['sign_in_second_factor'])||null};}function ci(_0x2cef8d){return Number(_0x2cef8d)*0x3e8;}function ws(_0x549110){const [_0x3cb28b,_0x479d2,_0x3483c4]=_0x549110['split']('.');if(_0x3cb28b===void 0x0||_0x479d2===void 0x0||_0x3483c4===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x28f141=cn(_0x479d2);return _0x28f141?JSON['parse'](_0x28f141):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x744b0a){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x744b0a==null?void 0x0:_0x744b0a['toString']()),null;}}function Er(_0x21df37){const _0x2a09be=ws(_0x21df37);return m(_0x2a09be,'internal-error'),m(typeof _0x2a09be['exp']<'u','internal-error'),m(typeof _0x2a09be['iat']<'u','internal-error'),Number(_0x2a09be['exp'])-Number(_0x2a09be['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x5a3144,_0x5ba541,_0x419270=!0x1){if(_0x419270)return _0x5ba541;try{return await _0x5ba541;}catch(_0x326afb){throw _0x326afb instanceof Se&&pf(_0x326afb)&&_0x5a3144['auth']['currentUser']===_0x5a3144&&await _0x5a3144['auth']['signOut'](),_0x326afb;}}function pf({code:_0x34909d}){return _0x34909d==='auth/user-disabled'||_0x34909d==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x3111dd){this['user']=_0x3111dd,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x426b8c){if(_0x426b8c){const _0x31bd5c=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x31bd5c;}else{this['errorBackoff']=0x7530;const _0x55af84=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x55af84);}}['schedule'](_0x26402d=!0x1){if(!this['isRunning'])return;const _0x150406=this['getInterval'](_0x26402d);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x150406);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x32053e){(_0x32053e==null?void 0x0:_0x32053e['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x256147,_0x4b75){this['createdAt']=_0x256147,this['lastLoginAt']=_0x4b75,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x5debea){this['createdAt']=_0x5debea['createdAt'],this['lastLoginAt']=_0x5debea['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x211155){var _0x569e23;const _0x1e35ed=_0x211155['auth'],_0xaff64f=await _0x211155['getIdToken'](),_0x334070=await xt(_0x211155,Sn(_0x1e35ed,{'idToken':_0xaff64f}));m(_0x334070==null?void 0x0:_0x334070['users']['length'],_0x1e35ed,'internal-error');const _0x1ac559=_0x334070['users'][0x0];_0x211155['_notifyReloadListener'](_0x1ac559);const _0x269ab8=(_0x569e23=_0x1ac559['providerUserInfo'])!=null&&_0x569e23['length']?wa(_0x1ac559['providerUserInfo']):[],_0x498a93=mf(_0x211155['providerData'],_0x269ab8),_0x59ea7b=_0x211155['isAnonymous'],_0x8b5453=!(_0x211155['email']&&_0x1ac559['passwordHash'])&&!(_0x498a93!=null&&_0x498a93['length']),_0x23c421=_0x59ea7b?_0x8b5453:!0x1,_0x48bc14={'uid':_0x1ac559['localId'],'displayName':_0x1ac559['displayName']||null,'photoURL':_0x1ac559['photoUrl']||null,'email':_0x1ac559['email']||null,'emailVerified':_0x1ac559['emailVerified']||!0x1,'phoneNumber':_0x1ac559['phoneNumber']||null,'tenantId':_0x1ac559['tenantId']||null,'providerData':_0x498a93,'metadata':new Pi(_0x1ac559['createdAt'],_0x1ac559['lastLoginAt']),'isAnonymous':_0x23c421};Object['assign'](_0x211155,_0x48bc14);}async function gf(_0x530e0d){const _0x10d9c9=k(_0x530e0d);await bn(_0x10d9c9),await _0x10d9c9['auth']['_persistUserIfCurrent'](_0x10d9c9),_0x10d9c9['auth']['_notifyListenersIfCurrent'](_0x10d9c9);}function mf(_0x33a9a7,_0x21538a){return[..._0x33a9a7['filter'](_0x597480=>!_0x21538a['some'](_0x2a5dc5=>_0x2a5dc5['providerId']===_0x597480['providerId'])),..._0x21538a];}function wa(_0x458f28){return _0x458f28['map'](({providerId:_0x56db23,..._0x35026f})=>({'providerId':_0x56db23,'uid':_0x35026f['rawId']||'','displayName':_0x35026f['displayName']||null,'email':_0x35026f['email']||null,'phoneNumber':_0x35026f['phoneNumber']||null,'photoURL':_0x35026f['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x44d5cb,_0x45801c){const _0xe97b19=await Ea(_0x44d5cb,{},async()=>{const _0x4c91ff=at({'grant_type':'refresh_token','refresh_token':_0x45801c})['slice'](0x1),{tokenApiHost:_0x156728,apiKey:_0xc6c128}=_0x44d5cb['config'],_0x23dd27=await Ia(_0x44d5cb,_0x156728,'/v1/token','key='+_0xc6c128),_0x17a3a8=await _0x44d5cb['_getAdditionalHeaders']();_0x17a3a8['Content-Type']='application/x-www-form-urlencoded';const _0x48645e={'method':'POST','headers':_0x17a3a8,'body':_0x4c91ff};return _0x44d5cb['emulatorConfig']&&Wt(_0x44d5cb['emulatorConfig']['host'])&&(_0x48645e['credentials']='include'),va['fetch']()(_0x23dd27,_0x48645e);});return{'accessToken':_0xe97b19['access_token'],'expiresIn':_0xe97b19['expires_in'],'refreshToken':_0xe97b19['refresh_token']};}async function vf(_0x4d647d,_0x163781){return Ae(_0x4d647d,'POST','/v2/accounts:revokeToken',Re(_0x4d647d,_0x163781));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x3a7db7){m(_0x3a7db7['idToken'],'internal-error'),m(typeof _0x3a7db7['idToken']<'u','internal-error'),m(typeof _0x3a7db7['refreshToken']<'u','internal-error');const _0x12636e='expiresIn'in _0x3a7db7&&typeof _0x3a7db7['expiresIn']<'u'?Number(_0x3a7db7['expiresIn']):Er(_0x3a7db7['idToken']);this['updateTokensAndExpiration'](_0x3a7db7['idToken'],_0x3a7db7['refreshToken'],_0x12636e);}['updateFromIdToken'](_0x133efa){m(_0x133efa['length']!==0x0,'internal-error');const _0x56a2ac=Er(_0x133efa);this['updateTokensAndExpiration'](_0x133efa,null,_0x56a2ac);}async['getToken'](_0x271293,_0x419a4e=!0x1){return!_0x419a4e&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x271293,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x271293,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1adf16,_0x121077){const {accessToken:_0x122bbf,refreshToken:_0x2c8597,expiresIn:_0x20e59e}=await yf(_0x1adf16,_0x121077);this['updateTokensAndExpiration'](_0x122bbf,_0x2c8597,Number(_0x20e59e));}['updateTokensAndExpiration'](_0xa03af9,_0xd7a69,_0x1fb13d){this['refreshToken']=_0xd7a69||null,this['accessToken']=_0xa03af9||null,this['expirationTime']=Date['now']()+_0x1fb13d*0x3e8;}static['fromJSON'](_0xaad16b,_0x72866e){const {refreshToken:_0x2862d5,accessToken:_0x585d74,expirationTime:_0x5dadbb}=_0x72866e,_0x4172de=new Je();return _0x2862d5&&(m(typeof _0x2862d5=='string','internal-error',{'appName':_0xaad16b}),_0x4172de['refreshToken']=_0x2862d5),_0x585d74&&(m(typeof _0x585d74=='string','internal-error',{'appName':_0xaad16b}),_0x4172de['accessToken']=_0x585d74),_0x5dadbb&&(m(typeof _0x5dadbb=='number','internal-error',{'appName':_0xaad16b}),_0x4172de['expirationTime']=_0x5dadbb),_0x4172de;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x12cc2e){this['accessToken']=_0x12cc2e['accessToken'],this['refreshToken']=_0x12cc2e['refreshToken'],this['expirationTime']=_0x12cc2e['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x19b432,_0x3f2a30){m(typeof _0x19b432=='string'||typeof _0x19b432>'u','internal-error',{'appName':_0x3f2a30});}class z{constructor({uid:_0x3781a8,auth:_0x5af308,stsTokenManager:_0x4039bf,..._0x37febc}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3781a8,this['auth']=_0x5af308,this['stsTokenManager']=_0x4039bf,this['accessToken']=_0x4039bf['accessToken'],this['displayName']=_0x37febc['displayName']||null,this['email']=_0x37febc['email']||null,this['emailVerified']=_0x37febc['emailVerified']||!0x1,this['phoneNumber']=_0x37febc['phoneNumber']||null,this['photoURL']=_0x37febc['photoURL']||null,this['isAnonymous']=_0x37febc['isAnonymous']||!0x1,this['tenantId']=_0x37febc['tenantId']||null,this['providerData']=_0x37febc['providerData']?[..._0x37febc['providerData']]:[],this['metadata']=new Pi(_0x37febc['createdAt']||void 0x0,_0x37febc['lastLoginAt']||void 0x0);}async['getIdToken'](_0xc2c8b8){const _0x2fbb97=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0xc2c8b8));return m(_0x2fbb97,this['auth'],'internal-error'),this['accessToken']!==_0x2fbb97&&(this['accessToken']=_0x2fbb97,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2fbb97;}['getIdTokenResult'](_0x1f2724){return ff(this,_0x1f2724);}['reload'](){return gf(this);}['_assign'](_0x37642d){this!==_0x37642d&&(m(this['uid']===_0x37642d['uid'],this['auth'],'internal-error'),this['displayName']=_0x37642d['displayName'],this['photoURL']=_0x37642d['photoURL'],this['email']=_0x37642d['email'],this['emailVerified']=_0x37642d['emailVerified'],this['phoneNumber']=_0x37642d['phoneNumber'],this['isAnonymous']=_0x37642d['isAnonymous'],this['tenantId']=_0x37642d['tenantId'],this['providerData']=_0x37642d['providerData']['map'](_0x5ac504=>({..._0x5ac504})),this['metadata']['_copy'](_0x37642d['metadata']),this['stsTokenManager']['_assign'](_0x37642d['stsTokenManager']));}['_clone'](_0x5b39e1){const _0x5301ec=new z({...this,'auth':_0x5b39e1,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5301ec['metadata']['_copy'](this['metadata']),_0x5301ec;}['_onReload'](_0xf65f5e){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xf65f5e,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xeb021d){this['reloadListener']?this['reloadListener'](_0xeb021d):this['reloadUserInfo']=_0xeb021d;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x54343b,_0x59183f=!0x1){let _0x39cfb2=!0x1;_0x54343b['idToken']&&_0x54343b['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x54343b),_0x39cfb2=!0x0),_0x59183f&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x39cfb2&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x2eb83a=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x2eb83a})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x51342f=>({..._0x51342f})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x554b0a,_0x287e76){const _0x374a4c=_0x287e76['displayName']??void 0x0,_0x375daf=_0x287e76['email']??void 0x0,_0x536bcc=_0x287e76['phoneNumber']??void 0x0,_0x34ac8b=_0x287e76['photoURL']??void 0x0,_0x2181a3=_0x287e76['tenantId']??void 0x0,_0x10c1be=_0x287e76['_redirectEventId']??void 0x0,_0x20b7c4=_0x287e76['createdAt']??void 0x0,_0x7bcdc6=_0x287e76['lastLoginAt']??void 0x0,{uid:_0x5b6ad2,emailVerified:_0x25741a,isAnonymous:_0x5b8162,providerData:_0x3e09e5,stsTokenManager:_0x2f53f3}=_0x287e76;m(_0x5b6ad2&&_0x2f53f3,_0x554b0a,'internal-error');const _0x435f62=Je['fromJSON'](this['name'],_0x2f53f3);m(typeof _0x5b6ad2=='string',_0x554b0a,'internal-error'),ce(_0x374a4c,_0x554b0a['name']),ce(_0x375daf,_0x554b0a['name']),m(typeof _0x25741a=='boolean',_0x554b0a,'internal-error'),m(typeof _0x5b8162=='boolean',_0x554b0a,'internal-error'),ce(_0x536bcc,_0x554b0a['name']),ce(_0x34ac8b,_0x554b0a['name']),ce(_0x2181a3,_0x554b0a['name']),ce(_0x10c1be,_0x554b0a['name']),ce(_0x20b7c4,_0x554b0a['name']),ce(_0x7bcdc6,_0x554b0a['name']);const _0x4970f7=new z({'uid':_0x5b6ad2,'auth':_0x554b0a,'email':_0x375daf,'emailVerified':_0x25741a,'displayName':_0x374a4c,'isAnonymous':_0x5b8162,'photoURL':_0x34ac8b,'phoneNumber':_0x536bcc,'tenantId':_0x2181a3,'stsTokenManager':_0x435f62,'createdAt':_0x20b7c4,'lastLoginAt':_0x7bcdc6});return _0x3e09e5&&Array['isArray'](_0x3e09e5)&&(_0x4970f7['providerData']=_0x3e09e5['map'](_0x22d7f4=>({..._0x22d7f4}))),_0x10c1be&&(_0x4970f7['_redirectEventId']=_0x10c1be),_0x4970f7;}static async['_fromIdTokenResponse'](_0x280911,_0x2c55c0,_0x5af6c4=!0x1){const _0x54d0da=new Je();_0x54d0da['updateFromServerResponse'](_0x2c55c0);const _0xd9ede0=new z({'uid':_0x2c55c0['localId'],'auth':_0x280911,'stsTokenManager':_0x54d0da,'isAnonymous':_0x5af6c4});return await bn(_0xd9ede0),_0xd9ede0;}static async['_fromGetAccountInfoResponse'](_0x2d625b,_0x233d80,_0x28bf15){const _0x5d1fd9=_0x233d80['users'][0x0];m(_0x5d1fd9['localId']!==void 0x0,'internal-error');const _0xd8499e=_0x5d1fd9['providerUserInfo']!==void 0x0?wa(_0x5d1fd9['providerUserInfo']):[],_0x364848=!(_0x5d1fd9['email']&&_0x5d1fd9['passwordHash'])&&!(_0xd8499e!=null&&_0xd8499e['length']),_0x35bf4d=new Je();_0x35bf4d['updateFromIdToken'](_0x28bf15);const _0x5be887=new z({'uid':_0x5d1fd9['localId'],'auth':_0x2d625b,'stsTokenManager':_0x35bf4d,'isAnonymous':_0x364848}),_0x32597b={'uid':_0x5d1fd9['localId'],'displayName':_0x5d1fd9['displayName']||null,'photoURL':_0x5d1fd9['photoUrl']||null,'email':_0x5d1fd9['email']||null,'emailVerified':_0x5d1fd9['emailVerified']||!0x1,'phoneNumber':_0x5d1fd9['phoneNumber']||null,'tenantId':_0x5d1fd9['tenantId']||null,'providerData':_0xd8499e,'metadata':new Pi(_0x5d1fd9['createdAt'],_0x5d1fd9['lastLoginAt']),'isAnonymous':!(_0x5d1fd9['email']&&_0x5d1fd9['passwordHash'])&&!(_0xd8499e!=null&&_0xd8499e['length'])};return Object['assign'](_0x5be887,_0x32597b),_0x5be887;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x3bc0a1){ae(_0x3bc0a1 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x511e77=Ir['get'](_0x3bc0a1);return _0x511e77?(ae(_0x511e77 instanceof _0x3bc0a1,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x511e77):(_0x511e77=new _0x3bc0a1(),Ir['set'](_0x3bc0a1,_0x511e77),_0x511e77);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2c8426,_0x21da63){this['storage'][_0x2c8426]=_0x21da63;}async['_get'](_0x5232eb){const _0x13954f=this['storage'][_0x5232eb];return _0x13954f===void 0x0?null:_0x13954f;}async['_remove'](_0x22f4b3){delete this['storage'][_0x22f4b3];}['_addListener'](_0x70b8e7,_0x295ded){}['_removeListener'](_0x184d6f,_0x4a97ef){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x519dfd,_0x4bcf3b,_0x113786){return'firebase:'+_0x519dfd+':'+_0x4bcf3b+':'+_0x113786;}class Xe{constructor(_0x5c24cd,_0x580413,_0x81e1ef){this['persistence']=_0x5c24cd,this['auth']=_0x580413,this['userKey']=_0x81e1ef;const {config:_0x1c056f,name:_0x529801}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x1c056f['apiKey'],_0x529801),this['fullPersistenceKey']=sn('persistence',_0x1c056f['apiKey'],_0x529801),this['boundEventHandler']=_0x580413['_onStorageEvent']['bind'](_0x580413),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1864cb){return this['persistence']['_set'](this['fullUserKey'],_0x1864cb['toJSON']());}async['getCurrentUser'](){const _0x4d5cb9=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4d5cb9)return null;if(typeof _0x4d5cb9=='string'){const _0x49635c=await Sn(this['auth'],{'idToken':_0x4d5cb9})['catch'](()=>{});return _0x49635c?z['_fromGetAccountInfoResponse'](this['auth'],_0x49635c,_0x4d5cb9):null;}return z['_fromJSON'](this['auth'],_0x4d5cb9);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3b76f7){if(this['persistence']===_0x3b76f7)return;const _0x483f52=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3b76f7,_0x483f52)return this['setCurrentUser'](_0x483f52);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4512e1,_0x477c98,_0x2e7338='authUser'){if(!_0x477c98['length'])return new Xe(ne(wr),_0x4512e1,_0x2e7338);const _0x49b3c3=(await Promise['all'](_0x477c98['map'](async _0x1199c8=>{if(await _0x1199c8['_isAvailable']())return _0x1199c8;})))['filter'](_0x5c5eb6=>_0x5c5eb6);let _0x516652=_0x49b3c3[0x0]||ne(wr);const _0x3a8dc6=sn(_0x2e7338,_0x4512e1['config']['apiKey'],_0x4512e1['name']);let _0x567e55=null;for(const _0x41beb2 of _0x477c98)try{const _0x4770df=await _0x41beb2['_get'](_0x3a8dc6);if(_0x4770df){let _0x2a9a70;if(typeof _0x4770df=='string'){const _0x1ab986=await Sn(_0x4512e1,{'idToken':_0x4770df})['catch'](()=>{});if(!_0x1ab986)break;_0x2a9a70=await z['_fromGetAccountInfoResponse'](_0x4512e1,_0x1ab986,_0x4770df);}else _0x2a9a70=z['_fromJSON'](_0x4512e1,_0x4770df);_0x41beb2!==_0x516652&&(_0x567e55=_0x2a9a70),_0x516652=_0x41beb2;break;}}catch{}const _0x3d1b51=_0x49b3c3['filter'](_0xe634ea=>_0xe634ea['_shouldAllowMigration']);return!_0x516652['_shouldAllowMigration']||!_0x3d1b51['length']?new Xe(_0x516652,_0x4512e1,_0x2e7338):(_0x516652=_0x3d1b51[0x0],_0x567e55&&await _0x516652['_set'](_0x3a8dc6,_0x567e55['toJSON']()),await Promise['all'](_0x477c98['map'](async _0x79f95c=>{if(_0x79f95c!==_0x516652)try{await _0x79f95c['_remove'](_0x3a8dc6);}catch{}})),new Xe(_0x516652,_0x4512e1,_0x2e7338));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x135258){const _0x29854e=_0x135258['toLowerCase']();if(_0x29854e['includes']('opera/')||_0x29854e['includes']('opr/')||_0x29854e['includes']('opios/'))return'Opera';if(Ra(_0x29854e))return'IEMobile';if(_0x29854e['includes']('msie')||_0x29854e['includes']('trident/'))return'IE';if(_0x29854e['includes']('edge/'))return'Edge';if(Ta(_0x29854e))return'Firefox';if(_0x29854e['includes']('silk/'))return'Silk';if(ka(_0x29854e))return'Blackberry';if(Na(_0x29854e))return'Webos';if(Sa(_0x29854e))return'Safari';if((_0x29854e['includes']('chrome/')||ba(_0x29854e))&&!_0x29854e['includes']('edge/'))return'Chrome';if(Aa(_0x29854e))return'Android';{const _0xde6aa6=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x53fa0a=_0x135258['match'](_0xde6aa6);if((_0x53fa0a==null?void 0x0:_0x53fa0a['length'])===0x2)return _0x53fa0a[0x1];}return'Other';}function Ta(_0x5a1f11=W()){return/firefox\//i['test'](_0x5a1f11);}function Sa(_0x3ba669=W()){const _0x317509=_0x3ba669['toLowerCase']();return _0x317509['includes']('safari/')&&!_0x317509['includes']('chrome/')&&!_0x317509['includes']('crios/')&&!_0x317509['includes']('android');}function ba(_0x49e2cb=W()){return/crios\//i['test'](_0x49e2cb);}function Ra(_0x2cbc10=W()){return/iemobile/i['test'](_0x2cbc10);}function Aa(_0x38dee1=W()){return/android/i['test'](_0x38dee1);}function ka(_0x4aa34e=W()){return/blackberry/i['test'](_0x4aa34e);}function Na(_0x5eb003=W()){return/webos/i['test'](_0x5eb003);}function Cs(_0x4d6195=W()){return/iphone|ipad|ipod/i['test'](_0x4d6195)||/macintosh/i['test'](_0x4d6195)&&/mobile/i['test'](_0x4d6195);}function Ef(_0x5a32b6=W()){var _0x2eb586;return Cs(_0x5a32b6)&&!!((_0x2eb586=window['navigator'])!=null&&_0x2eb586['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x82af32=W()){return Cs(_0x82af32)||Aa(_0x82af32)||Na(_0x82af32)||ka(_0x82af32)||/windows phone/i['test'](_0x82af32)||Ra(_0x82af32);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x18cd31,_0x244b90=[]){let _0x56ac50;switch(_0x18cd31){case'Browser':_0x56ac50=Cr(W());break;case'Worker':_0x56ac50=Cr(W())+'-'+_0x18cd31;break;default:_0x56ac50=_0x18cd31;}const _0x275bc0=_0x244b90['length']?_0x244b90['join'](','):'FirebaseCore-web';return _0x56ac50+'/JsCore/'+ct+'/'+_0x275bc0;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x13d504){this['auth']=_0x13d504,this['queue']=[];}['pushCallback'](_0xac53ab,_0x2d1500){const _0x487a03=_0x4c6efc=>new Promise((_0x2c96e8,_0x4484aa)=>{try{const _0xe8ee3e=_0xac53ab(_0x4c6efc);_0x2c96e8(_0xe8ee3e);}catch(_0x440356){_0x4484aa(_0x440356);}});_0x487a03['onAbort']=_0x2d1500,this['queue']['push'](_0x487a03);const _0x46fc19=this['queue']['length']-0x1;return()=>{this['queue'][_0x46fc19]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5f5d6d){if(this['auth']['currentUser']===_0x5f5d6d)return;const _0x4e99c9=[];try{for(const _0x565484 of this['queue'])await _0x565484(_0x5f5d6d),_0x565484['onAbort']&&_0x4e99c9['push'](_0x565484['onAbort']);}catch(_0x33f2aa){_0x4e99c9['reverse']();for(const _0x1c9d03 of _0x4e99c9)try{_0x1c9d03();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x33f2aa==null?void 0x0:_0x33f2aa['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x5a20ed,_0x56c8da={}){return Ae(_0x5a20ed,'GET','/v2/passwordPolicy',Re(_0x5a20ed,_0x56c8da));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x55dd73){var _0x5f48cd;const _0x59be1e=_0x55dd73['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x59be1e['minPasswordLength']??Tf,_0x59be1e['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x59be1e['maxPasswordLength']),_0x59be1e['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x59be1e['containsLowercaseCharacter']),_0x59be1e['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x59be1e['containsUppercaseCharacter']),_0x59be1e['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x59be1e['containsNumericCharacter']),_0x59be1e['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x59be1e['containsNonAlphanumericCharacter']),this['enforcementState']=_0x55dd73['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x5f48cd=_0x55dd73['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x5f48cd['join'](''))??'',this['forceUpgradeOnSignin']=_0x55dd73['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x55dd73['schemaVersion'];}['validatePassword'](_0x2a1b25){const _0x57162b={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2a1b25,_0x57162b),this['validatePasswordCharacterOptions'](_0x2a1b25,_0x57162b),_0x57162b['isValid']&&(_0x57162b['isValid']=_0x57162b['meetsMinPasswordLength']??!0x0),_0x57162b['isValid']&&(_0x57162b['isValid']=_0x57162b['meetsMaxPasswordLength']??!0x0),_0x57162b['isValid']&&(_0x57162b['isValid']=_0x57162b['containsLowercaseLetter']??!0x0),_0x57162b['isValid']&&(_0x57162b['isValid']=_0x57162b['containsUppercaseLetter']??!0x0),_0x57162b['isValid']&&(_0x57162b['isValid']=_0x57162b['containsNumericCharacter']??!0x0),_0x57162b['isValid']&&(_0x57162b['isValid']=_0x57162b['containsNonAlphanumericCharacter']??!0x0),_0x57162b;}['validatePasswordLengthOptions'](_0x3c8dc5,_0x48a24d){const _0x1626a8=this['customStrengthOptions']['minPasswordLength'],_0x343d82=this['customStrengthOptions']['maxPasswordLength'];_0x1626a8&&(_0x48a24d['meetsMinPasswordLength']=_0x3c8dc5['length']>=_0x1626a8),_0x343d82&&(_0x48a24d['meetsMaxPasswordLength']=_0x3c8dc5['length']<=_0x343d82);}['validatePasswordCharacterOptions'](_0x3c1771,_0x24bef9){this['updatePasswordCharacterOptionsStatuses'](_0x24bef9,!0x1,!0x1,!0x1,!0x1);let _0x324d47;for(let _0x2be5e1=0x0;_0x2be5e1<_0x3c1771['length'];_0x2be5e1++)_0x324d47=_0x3c1771['charAt'](_0x2be5e1),this['updatePasswordCharacterOptionsStatuses'](_0x24bef9,_0x324d47>='a'&&_0x324d47<='z',_0x324d47>='A'&&_0x324d47<='Z',_0x324d47>='0'&&_0x324d47<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x324d47));}['updatePasswordCharacterOptionsStatuses'](_0x3667d1,_0x4dec10,_0x1362ec,_0x594e3b,_0x49b2f0){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x3667d1['containsLowercaseLetter']||(_0x3667d1['containsLowercaseLetter']=_0x4dec10)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x3667d1['containsUppercaseLetter']||(_0x3667d1['containsUppercaseLetter']=_0x1362ec)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x3667d1['containsNumericCharacter']||(_0x3667d1['containsNumericCharacter']=_0x594e3b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x3667d1['containsNonAlphanumericCharacter']||(_0x3667d1['containsNonAlphanumericCharacter']=_0x49b2f0));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x28b9fe,_0x431d81,_0x266538,_0x414c66){this['app']=_0x28b9fe,this['heartbeatServiceProvider']=_0x431d81,this['appCheckServiceProvider']=_0x266538,this['config']=_0x414c66,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x28b9fe['name'],this['clientVersion']=_0x414c66['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x31b9dc=>this['_resolvePersistenceManagerAvailable']=_0x31b9dc);}['_initializeWithPersistence'](_0x4de60b,_0x50cd71){return _0x50cd71&&(this['_popupRedirectResolver']=ne(_0x50cd71)),this['_initializationPromise']=this['queue'](async()=>{var _0x4b7247,_0x2ec2ea,_0x143e47;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x4de60b),(_0x4b7247=this['_resolvePersistenceManagerAvailable'])==null||_0x4b7247['call'](this),!this['_deleted'])){if((_0x2ec2ea=this['_popupRedirectResolver'])!=null&&_0x2ec2ea['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x50cd71),this['lastNotifiedUid']=((_0x143e47=this['currentUser'])==null?void 0x0:_0x143e47['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x138f53=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x138f53)){if(this['currentUser']&&_0x138f53&&this['currentUser']['uid']===_0x138f53['uid']){this['_currentUser']['_assign'](_0x138f53),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x138f53,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4702db){try{const _0x168732=await Sn(this,{'idToken':_0x4702db}),_0x428dc3=await z['_fromGetAccountInfoResponse'](this,_0x168732,_0x4702db);await this['directlySetCurrentUser'](_0x428dc3);}catch(_0x54954f){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x54954f),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x4da8a5){var _0x3bfe66;if(H(this['app'])){const _0x30815e=this['app']['settings']['authIdToken'];return _0x30815e?new Promise(_0x418e58=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x30815e)['then'](_0x418e58,_0x418e58));}):this['directlySetCurrentUser'](null);}const _0x4f37a3=await this['assertedPersistence']['getCurrentUser']();let _0x4fdd14=_0x4f37a3,_0x11476c=!0x1;if(_0x4da8a5&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x43b1d0=(_0x3bfe66=this['redirectUser'])==null?void 0x0:_0x3bfe66['_redirectEventId'],_0x31d8d1=_0x4fdd14==null?void 0x0:_0x4fdd14['_redirectEventId'],_0x1159c7=await this['tryRedirectSignIn'](_0x4da8a5);(!_0x43b1d0||_0x43b1d0===_0x31d8d1)&&(_0x1159c7!=null&&_0x1159c7['user'])&&(_0x4fdd14=_0x1159c7['user'],_0x11476c=!0x0);}if(!_0x4fdd14)return this['directlySetCurrentUser'](null);if(!_0x4fdd14['_redirectEventId']){if(_0x11476c)try{await this['beforeStateQueue']['runMiddleware'](_0x4fdd14);}catch(_0x3a8a2c){_0x4fdd14=_0x4f37a3,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3a8a2c));}return _0x4fdd14?this['reloadAndSetCurrentUserOrClear'](_0x4fdd14):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4fdd14['_redirectEventId']?this['directlySetCurrentUser'](_0x4fdd14):this['reloadAndSetCurrentUserOrClear'](_0x4fdd14);}async['tryRedirectSignIn'](_0x1eaed3){let _0x43a3be=null;try{_0x43a3be=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1eaed3,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x43a3be;}async['reloadAndSetCurrentUserOrClear'](_0x140f00){try{await bn(_0x140f00);}catch(_0x26304d){if((_0x26304d==null?void 0x0:_0x26304d['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x140f00);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2f7fc3){if(H(this['app']))return Promise['reject'](se(this));const _0x4e106f=_0x2f7fc3?k(_0x2f7fc3):null;return _0x4e106f&&m(_0x4e106f['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4e106f&&_0x4e106f['_clone'](this));}async['_updateCurrentUser'](_0x207449,_0x3ce011=!0x1){if(!this['_deleted'])return _0x207449&&m(this['tenantId']===_0x207449['tenantId'],this,'tenant-id-mismatch'),_0x3ce011||await this['beforeStateQueue']['runMiddleware'](_0x207449),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x207449),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x59ccc9){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x59ccc9));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3d9059){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1746d5=this['_getPasswordPolicyInternal']();return _0x1746d5['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1746d5['validatePassword'](_0x3d9059);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2517f5=await Cf(this),_0xfd07f7=new Sf(_0x2517f5);this['tenantId']===null?this['_projectPasswordPolicy']=_0xfd07f7:this['_tenantPasswordPolicies'][this['tenantId']]=_0xfd07f7;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2ed64f){this['_errorFactory']=new Ut('auth','Firebase',_0x2ed64f());}['onAuthStateChanged'](_0x12b3d3,_0x59f2fc,_0x212f17){return this['registerStateListener'](this['authStateSubscription'],_0x12b3d3,_0x59f2fc,_0x212f17);}['beforeAuthStateChanged'](_0x2caef0,_0x1539df){return this['beforeStateQueue']['pushCallback'](_0x2caef0,_0x1539df);}['onIdTokenChanged'](_0x3ced18,_0x4d8f38,_0x3abb39){return this['registerStateListener'](this['idTokenSubscription'],_0x3ced18,_0x4d8f38,_0x3abb39);}['authStateReady'](){return new Promise((_0x5e8efd,_0x2b8736)=>{if(this['currentUser'])_0x5e8efd();else{const _0x5e3caf=this['onAuthStateChanged'](()=>{_0x5e3caf(),_0x5e8efd();},_0x2b8736);}});}async['revokeAccessToken'](_0x24e7a9){if(this['currentUser']){const _0x528e6f=await this['currentUser']['getIdToken'](),_0x110459={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x24e7a9,'idToken':_0x528e6f};this['tenantId']!=null&&(_0x110459['tenantId']=this['tenantId']),await vf(this,_0x110459);}}['toJSON'](){var _0xe476e;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xe476e=this['_currentUser'])==null?void 0x0:_0xe476e['toJSON']()};}async['_setRedirectUser'](_0xefbb12,_0x58291e){const _0x26f204=await this['getOrInitRedirectPersistenceManager'](_0x58291e);return _0xefbb12===null?_0x26f204['removeCurrentUser']():_0x26f204['setCurrentUser'](_0xefbb12);}async['getOrInitRedirectPersistenceManager'](_0x48402b){if(!this['redirectPersistenceManager']){const _0x18bc67=_0x48402b&&ne(_0x48402b)||this['_popupRedirectResolver'];m(_0x18bc67,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x18bc67['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x4402e3){var _0x3a009b,_0x54c3d4;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3a009b=this['_currentUser'])==null?void 0x0:_0x3a009b['_redirectEventId'])===_0x4402e3?this['_currentUser']:((_0x54c3d4=this['redirectUser'])==null?void 0x0:_0x54c3d4['_redirectEventId'])===_0x4402e3?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2c6d97){if(_0x2c6d97===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2c6d97));}['_notifyListenersIfCurrent'](_0x42ac2e){_0x42ac2e===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1de49e;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x62a24b=((_0x1de49e=this['currentUser'])==null?void 0x0:_0x1de49e['uid'])??null;this['lastNotifiedUid']!==_0x62a24b&&(this['lastNotifiedUid']=_0x62a24b,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1eb77b,_0x4d0324,_0x38ef48,_0x4b9949){if(this['_deleted'])return()=>{};const _0x1a71ee=typeof _0x4d0324=='function'?_0x4d0324:_0x4d0324['next']['bind'](_0x4d0324);let _0x3081c7=!0x1;const _0x3c2a16=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3c2a16,this,'internal-error'),_0x3c2a16['then'](()=>{_0x3081c7||_0x1a71ee(this['currentUser']);}),typeof _0x4d0324=='function'){const _0x1b3eda=_0x1eb77b['addObserver'](_0x4d0324,_0x38ef48,_0x4b9949);return()=>{_0x3081c7=!0x0,_0x1b3eda();};}else{const _0x159577=_0x1eb77b['addObserver'](_0x4d0324);return()=>{_0x3081c7=!0x0,_0x159577();};}}async['directlySetCurrentUser'](_0x27c8ab){this['currentUser']&&this['currentUser']!==_0x27c8ab&&this['_currentUser']['_stopProactiveRefresh'](),_0x27c8ab&&this['isProactiveRefreshEnabled']&&_0x27c8ab['_startProactiveRefresh'](),this['currentUser']=_0x27c8ab,_0x27c8ab?await this['assertedPersistence']['setCurrentUser'](_0x27c8ab):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4865f0){return this['operations']=this['operations']['then'](_0x4865f0,_0x4865f0),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x361fb6){!_0x361fb6||this['frameworks']['includes'](_0x361fb6)||(this['frameworks']['push'](_0x361fb6),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x41e75d;const _0x354796={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x354796['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xe213f6=await((_0x41e75d=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x41e75d['getHeartbeatsHeader']());_0xe213f6&&(_0x354796['X-Firebase-Client']=_0xe213f6);const _0xda3a6f=await this['_getAppCheckToken']();return _0xda3a6f&&(_0x354796['X-Firebase-AppCheck']=_0xda3a6f),_0x354796;}async['_getAppCheckToken'](){var _0x315b48;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x4c134e=await((_0x315b48=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x315b48['getToken']());return _0x4c134e!=null&&_0x4c134e['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x4c134e['error']),_0x4c134e==null?void 0x0:_0x4c134e['token'];}}function qe(_0x359099){return k(_0x359099);}class Tr{constructor(_0x52f73a){this['auth']=_0x52f73a,this['observer']=null,this['addObserver']=Ic(_0x365e6f=>this['observer']=_0x365e6f);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x17aacf){zn=_0x17aacf;}function Da(_0x491de1){return zn['loadJS'](_0x491de1);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x4d476e){return'__'+_0x4d476e+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0xfd74bd){_0xfd74bd();}['execute'](_0x5f0ae1,_0x3e9bda){return Promise['resolve']('token');}['render'](_0x3d7d92,_0x254ab0){return'';}}class Of{['ready'](_0x49fce5){_0x49fce5();}['execute'](_0x12cba3,_0x364a0c){return Promise['resolve']('token');}['render'](_0x181cb7,_0x40e8cf){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x4c2049){this['type']=Df,this['auth']=qe(_0x4c2049);}async['verify'](_0x42ddbd='verify',_0x329ddc=!0x1){async function _0x4d945f(_0xffd6eb){if(!_0x329ddc){if(_0xffd6eb['tenantId']==null&&_0xffd6eb['_agentRecaptchaConfig']!=null)return _0xffd6eb['_agentRecaptchaConfig']['siteKey'];if(_0xffd6eb['tenantId']!=null&&_0xffd6eb['_tenantRecaptchaConfigs'][_0xffd6eb['tenantId']]!==void 0x0)return _0xffd6eb['_tenantRecaptchaConfigs'][_0xffd6eb['tenantId']]['siteKey'];}return new Promise(async(_0x18e0f6,_0x352f4c)=>{uf(_0xffd6eb,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x28c256=>{if(_0x28c256['recaptchaKey']===void 0x0)_0x352f4c(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4e0ea9=new hf(_0x28c256);return _0xffd6eb['tenantId']==null?_0xffd6eb['_agentRecaptchaConfig']=_0x4e0ea9:_0xffd6eb['_tenantRecaptchaConfigs'][_0xffd6eb['tenantId']]=_0x4e0ea9,_0x18e0f6(_0x4e0ea9['siteKey']);}})['catch'](_0x2829cf=>{_0x352f4c(_0x2829cf);});});}function _0x2d96ef(_0x4a2033,_0x31e33c,_0x19be85){const _0x139973=window['grecaptcha'];vr(_0x139973)?_0x139973['enterprise']['ready'](()=>{_0x139973['enterprise']['execute'](_0x4a2033,{'action':_0x42ddbd})['then'](_0x3bb88d=>{_0x31e33c(_0x3bb88d);})['catch'](()=>{_0x31e33c(Ma);});}):_0x19be85(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x54b807,_0x43cfcb)=>{_0x4d945f(this['auth'])['then'](async _0x380e09=>{if(!_0x329ddc&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x2d96ef(_0x380e09,_0x54b807,_0x43cfcb);else{if(typeof window>'u'){_0x43cfcb(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1e5ef5=Af();_0x1e5ef5['length']!==0x0&&(_0x1e5ef5+=_0x380e09+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x560173;(_0x560173=le['scriptInjectionDeferred'])==null||_0x560173['resolve']();},Da(_0x1e5ef5)['then'](()=>{var _0x380001;return(_0x380001=le['scriptInjectionDeferred'])==null?void 0x0:_0x380001['promise'];})['then'](()=>{_0x2d96ef(_0x380e09,_0x54b807,_0x43cfcb);})['catch'](_0x19ec11=>{_0x43cfcb(_0x19ec11);});}})['catch'](_0x412c86=>{_0x43cfcb(_0x412c86);});});}}le['scriptInjectionDeferred']=null;async function br(_0x275f64,_0x166759,_0x585669,_0x895690=!0x1,_0x61afcd=!0x1){const _0x56ed2b=new le(_0x275f64);let _0x46a59e;if(_0x61afcd)_0x46a59e=Ma;else try{_0x46a59e=await _0x56ed2b['verify'](_0x585669);}catch{_0x46a59e=await _0x56ed2b['verify'](_0x585669,!0x0);}const _0x39d792={..._0x166759};if(_0x585669==='mfaSmsEnrollment'||_0x585669==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x39d792){const _0x107bed=_0x39d792['phoneEnrollmentInfo']['phoneNumber'],_0x33bb80=_0x39d792['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x39d792,{'phoneEnrollmentInfo':{'phoneNumber':_0x107bed,'recaptchaToken':_0x33bb80,'captchaResponse':_0x46a59e,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x39d792){const _0x538be0=_0x39d792['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x39d792,{'phoneSignInInfo':{'recaptchaToken':_0x538be0,'captchaResponse':_0x46a59e,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x39d792;}return _0x895690?Object['assign'](_0x39d792,{'captchaResp':_0x46a59e}):Object['assign'](_0x39d792,{'captchaResponse':_0x46a59e}),Object['assign'](_0x39d792,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x39d792,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x39d792;}async function Oi(_0x1afa02,_0x57458a,_0x3b4190,_0x2b880b,_0x208e88){var _0x1b9c41;if((_0x1b9c41=_0x1afa02['_getRecaptchaConfig']())!=null&&_0x1b9c41['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3b862c=await br(_0x1afa02,_0x57458a,_0x3b4190,_0x3b4190==='getOobCode');return _0x2b880b(_0x1afa02,_0x3b862c);}else return _0x2b880b(_0x1afa02,_0x57458a)['catch'](async _0x29dbae=>{if(_0x29dbae['code']==='auth/missing-recaptcha-token'){console['log'](_0x3b4190+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3cdd81=await br(_0x1afa02,_0x57458a,_0x3b4190,_0x3b4190==='getOobCode');return _0x2b880b(_0x1afa02,_0x3cdd81);}else return Promise['reject'](_0x29dbae);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x5c91c6,_0x3fb947){const _0x2f7448=Ui(_0x5c91c6,'auth');if(_0x2f7448['isInitialized']()){const _0x7951d4=_0x2f7448['getImmediate'](),_0x4d123b=_0x2f7448['getOptions']();if(De(_0x4d123b,_0x3fb947??{}))return _0x7951d4;K(_0x7951d4,'already-initialized');}return _0x2f7448['initialize']({'options':_0x3fb947});}function Lf(_0x1237e0,_0x5d9394){const _0x5aa16b=(_0x5d9394==null?void 0x0:_0x5d9394['persistence'])||[],_0x115c46=(Array['isArray'](_0x5aa16b)?_0x5aa16b:[_0x5aa16b])['map'](ne);_0x5d9394!=null&&_0x5d9394['errorMap']&&_0x1237e0['_updateErrorMap'](_0x5d9394['errorMap']),_0x1237e0['_initializeWithPersistence'](_0x115c46,_0x5d9394==null?void 0x0:_0x5d9394['popupRedirectResolver']);}function xf(_0x3f57c3,_0x326add,_0x2ae398){const _0x35376a=qe(_0x3f57c3);m(/^https?:\/\//['test'](_0x326add),_0x35376a,'invalid-emulator-scheme');const _0x4b3962=!0x1,_0x27c667=La(_0x326add),{host:_0x36de3c,port:_0x1922a5}=Ff(_0x326add),_0x87ecb7=_0x1922a5===null?'':':'+_0x1922a5,_0x306b78={'url':_0x27c667+'//'+_0x36de3c+_0x87ecb7+'/'},_0x165239=Object['freeze']({'host':_0x36de3c,'port':_0x1922a5,'protocol':_0x27c667['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4b3962})});if(!_0x35376a['_canInitEmulator']){m(_0x35376a['config']['emulator']&&_0x35376a['emulatorConfig'],_0x35376a,'emulator-config-failed'),m(De(_0x306b78,_0x35376a['config']['emulator'])&&De(_0x165239,_0x35376a['emulatorConfig']),_0x35376a,'emulator-config-failed');return;}_0x35376a['config']['emulator']=_0x306b78,_0x35376a['emulatorConfig']=_0x165239,_0x35376a['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x36de3c)?jr(_0x27c667+'//'+_0x36de3c+_0x87ecb7):Uf();}function La(_0x487062){const _0x2d49d3=_0x487062['indexOf'](':');return _0x2d49d3<0x0?'':_0x487062['substr'](0x0,_0x2d49d3+0x1);}function Ff(_0x392a00){const _0x6ce9e7=La(_0x392a00),_0x397fe7=/(\/\/)?([^?#/]+)/['exec'](_0x392a00['substr'](_0x6ce9e7['length']));if(!_0x397fe7)return{'host':'','port':null};const _0x1be82d=_0x397fe7[0x2]['split']('@')['pop']()||'',_0x4b2d22=/^(\[[^\]]+\])(:|$)/['exec'](_0x1be82d);if(_0x4b2d22){const _0x1d0383=_0x4b2d22[0x1];return{'host':_0x1d0383,'port':Rr(_0x1be82d['substr'](_0x1d0383['length']+0x1))};}else{const [_0x4369b5,_0x24ea1e]=_0x1be82d['split'](':');return{'host':_0x4369b5,'port':Rr(_0x24ea1e)};}}function Rr(_0x2782d1){if(!_0x2782d1)return null;const _0x291224=Number(_0x2782d1);return isNaN(_0x291224)?null:_0x291224;}function Uf(){function _0x1393be(){const _0x37e0e4=document['createElement']('p'),_0x1af9c6=_0x37e0e4['style'];_0x37e0e4['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x1af9c6['position']='fixed',_0x1af9c6['width']='100%',_0x1af9c6['backgroundColor']='#ffffff',_0x1af9c6['border']='.1em\x20solid\x20#000000',_0x1af9c6['color']='#b50000',_0x1af9c6['bottom']='0px',_0x1af9c6['left']='0px',_0x1af9c6['margin']='0px',_0x1af9c6['zIndex']='10000',_0x1af9c6['textAlign']='center',_0x37e0e4['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x37e0e4);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1393be):_0x1393be());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x2e00bf,_0x16e2ea){this['providerId']=_0x2e00bf,this['signInMethod']=_0x16e2ea;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x1cfb9d){return te('not\x20implemented');}['_linkToIdToken'](_0x3b4a21,_0x3c14c5){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x1f4a68){return te('not\x20implemented');}}async function Wf(_0x59131c,_0x3887c1){return Ae(_0x59131c,'POST','/v1/accounts:signUp',_0x3887c1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0xe17f78,_0x589bd1){return Yt(_0xe17f78,'POST','/v1/accounts:signInWithPassword',Re(_0xe17f78,_0x589bd1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x320589,_0x17f2c3){return Yt(_0x320589,'POST','/v1/accounts:signInWithEmailLink',Re(_0x320589,_0x17f2c3));}async function Hf(_0x3bf7b9,_0x259a0d){return Yt(_0x3bf7b9,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3bf7b9,_0x259a0d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x23c6ff,_0xda6f6e,_0x51a706,_0x2052fd=null){super('password',_0x51a706),this['_email']=_0x23c6ff,this['_password']=_0xda6f6e,this['_tenantId']=_0x2052fd;}static['_fromEmailAndPassword'](_0x43ad6c,_0x135952){return new Ft(_0x43ad6c,_0x135952,'password');}static['_fromEmailAndCode'](_0x3f7a77,_0x53c11d,_0x46ff60=null){return new Ft(_0x3f7a77,_0x53c11d,'emailLink',_0x46ff60);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x13be54){const _0x13366f=typeof _0x13be54=='string'?JSON['parse'](_0x13be54):_0x13be54;if(_0x13366f!=null&&_0x13366f['email']&&(_0x13366f!=null&&_0x13366f['password'])){if(_0x13366f['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x13366f['email'],_0x13366f['password']);if(_0x13366f['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x13366f['email'],_0x13366f['password'],_0x13366f['tenantId']);}return null;}async['_getIdTokenResponse'](_0x50b7b2){switch(this['signInMethod']){case'password':const _0x21dff5={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x50b7b2,_0x21dff5,'signInWithPassword',Bf);case'emailLink':return Vf(_0x50b7b2,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x50b7b2,'internal-error');}}async['_linkToIdToken'](_0x339d88,_0x4b958e){switch(this['signInMethod']){case'password':const _0x3e2890={'idToken':_0x4b958e,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x339d88,_0x3e2890,'signUpPassword',Wf);case'emailLink':return Hf(_0x339d88,{'idToken':_0x4b958e,'email':this['_email'],'oobCode':this['_password']});default:K(_0x339d88,'internal-error');}}['_getReauthenticationResolver'](_0x28b540){return this['_getIdTokenResponse'](_0x28b540);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x474e5d,_0x2416bb){return Yt(_0x474e5d,'POST','/v1/accounts:signInWithIdp',Re(_0x474e5d,_0x2416bb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2779c4){const _0x1579e4=new We(_0x2779c4['providerId'],_0x2779c4['signInMethod']);return _0x2779c4['idToken']||_0x2779c4['accessToken']?(_0x2779c4['idToken']&&(_0x1579e4['idToken']=_0x2779c4['idToken']),_0x2779c4['accessToken']&&(_0x1579e4['accessToken']=_0x2779c4['accessToken']),_0x2779c4['nonce']&&!_0x2779c4['pendingToken']&&(_0x1579e4['nonce']=_0x2779c4['nonce']),_0x2779c4['pendingToken']&&(_0x1579e4['pendingToken']=_0x2779c4['pendingToken'])):_0x2779c4['oauthToken']&&_0x2779c4['oauthTokenSecret']?(_0x1579e4['accessToken']=_0x2779c4['oauthToken'],_0x1579e4['secret']=_0x2779c4['oauthTokenSecret']):K('argument-error'),_0x1579e4;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x12dba0){const _0x59758e=typeof _0x12dba0=='string'?JSON['parse'](_0x12dba0):_0x12dba0,{providerId:_0x1699dc,signInMethod:_0x5a2c12,..._0x4b2528}=_0x59758e;if(!_0x1699dc||!_0x5a2c12)return null;const _0x4d74e2=new We(_0x1699dc,_0x5a2c12);return _0x4d74e2['idToken']=_0x4b2528['idToken']||void 0x0,_0x4d74e2['accessToken']=_0x4b2528['accessToken']||void 0x0,_0x4d74e2['secret']=_0x4b2528['secret'],_0x4d74e2['nonce']=_0x4b2528['nonce'],_0x4d74e2['pendingToken']=_0x4b2528['pendingToken']||null,_0x4d74e2;}['_getIdTokenResponse'](_0x1a618b){const _0x41cb3c=this['buildRequest']();return Ze(_0x1a618b,_0x41cb3c);}['_linkToIdToken'](_0xf8ffd4,_0x3492c6){const _0x36c468=this['buildRequest']();return _0x36c468['idToken']=_0x3492c6,Ze(_0xf8ffd4,_0x36c468);}['_getReauthenticationResolver'](_0x1e5f71){const _0x2852b4=this['buildRequest']();return _0x2852b4['autoCreate']=!0x1,Ze(_0x1e5f71,_0x2852b4);}['buildRequest'](){const _0x24039e={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x24039e['pendingToken']=this['pendingToken'];else{const _0xddbb47={};this['idToken']&&(_0xddbb47['id_token']=this['idToken']),this['accessToken']&&(_0xddbb47['access_token']=this['accessToken']),this['secret']&&(_0xddbb47['oauth_token_secret']=this['secret']),_0xddbb47['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0xddbb47['nonce']=this['nonce']),_0x24039e['postBody']=at(_0xddbb47);}return _0x24039e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x14c683){switch(_0x14c683){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0xe3d64){const _0x527046=yt(vt(_0xe3d64))['link'],_0x5452e6=_0x527046?yt(vt(_0x527046))['deep_link_id']:null,_0x4caa1=yt(vt(_0xe3d64))['deep_link_id'];return(_0x4caa1?yt(vt(_0x4caa1))['link']:null)||_0x4caa1||_0x5452e6||_0x527046||_0xe3d64;}class Ss{constructor(_0x790ab0){const _0x50eee1=yt(vt(_0x790ab0)),_0x4fec37=_0x50eee1['apiKey']??null,_0x587b52=_0x50eee1['oobCode']??null,_0x561424=Gf(_0x50eee1['mode']??null);m(_0x4fec37&&_0x587b52&&_0x561424,'argument-error'),this['apiKey']=_0x4fec37,this['operation']=_0x561424,this['code']=_0x587b52,this['continueUrl']=_0x50eee1['continueUrl']??null,this['languageCode']=_0x50eee1['lang']??null,this['tenantId']=_0x50eee1['tenantId']??null;}static['parseLink'](_0x1bea24){const _0x5456bf=qf(_0x1bea24);try{return new Ss(_0x5456bf);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x30b6cd,_0x37c88f){return Ft['_fromEmailAndPassword'](_0x30b6cd,_0x37c88f);}static['credentialWithLink'](_0x1e2283,_0x25ec25){const _0xd777a6=Ss['parseLink'](_0x25ec25);return m(_0xd777a6,'argument-error'),Ft['_fromEmailAndCode'](_0x1e2283,_0xd777a6['code'],_0xd777a6['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x3a8b11){this['providerId']=_0x3a8b11,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4a4b5f){this['defaultLanguageCode']=_0x4a4b5f;}['setCustomParameters'](_0x4c6a50){return this['customParameters']=_0x4c6a50,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x431d45){return this['scopes']['includes'](_0x431d45)||this['scopes']['push'](_0x431d45),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x259899){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x259899});}static['credentialFromResult'](_0x41acb5){return he['credentialFromTaggedObject'](_0x41acb5);}static['credentialFromError'](_0x65b78a){return he['credentialFromTaggedObject'](_0x65b78a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x139632}){if(!_0x139632||!('oauthAccessToken'in _0x139632)||!_0x139632['oauthAccessToken'])return null;try{return he['credential'](_0x139632['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x4bfee4,_0x13d0bb){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x4bfee4,'accessToken':_0x13d0bb});}static['credentialFromResult'](_0x1d236b){return ue['credentialFromTaggedObject'](_0x1d236b);}static['credentialFromError'](_0x5cf4bc){return ue['credentialFromTaggedObject'](_0x5cf4bc['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x34a853}){if(!_0x34a853)return null;const {oauthIdToken:_0x348151,oauthAccessToken:_0x4d519b}=_0x34a853;if(!_0x348151&&!_0x4d519b)return null;try{return ue['credential'](_0x348151,_0x4d519b);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x464a65){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x464a65});}static['credentialFromResult'](_0x45a6e2){return de['credentialFromTaggedObject'](_0x45a6e2);}static['credentialFromError'](_0x216d35){return de['credentialFromTaggedObject'](_0x216d35['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1ddc33}){if(!_0x1ddc33||!('oauthAccessToken'in _0x1ddc33)||!_0x1ddc33['oauthAccessToken'])return null;try{return de['credential'](_0x1ddc33['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x56e05f,_0x1eee97){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x56e05f,'oauthTokenSecret':_0x1eee97});}static['credentialFromResult'](_0x5ea3ad){return fe['credentialFromTaggedObject'](_0x5ea3ad);}static['credentialFromError'](_0x52433b){return fe['credentialFromTaggedObject'](_0x52433b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1fc100}){if(!_0x1fc100)return null;const {oauthAccessToken:_0xdd6ac4,oauthTokenSecret:_0x52982f}=_0x1fc100;if(!_0xdd6ac4||!_0x52982f)return null;try{return fe['credential'](_0xdd6ac4,_0x52982f);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x117862,_0x51ee52){return Yt(_0x117862,'POST','/v1/accounts:signUp',Re(_0x117862,_0x51ee52));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x3f1f74){this['user']=_0x3f1f74['user'],this['providerId']=_0x3f1f74['providerId'],this['_tokenResponse']=_0x3f1f74['_tokenResponse'],this['operationType']=_0x3f1f74['operationType'];}static async['_fromIdTokenResponse'](_0x4ffae3,_0x4ded2a,_0x2db048,_0x1d490b=!0x1){const _0x35f13f=await z['_fromIdTokenResponse'](_0x4ffae3,_0x2db048,_0x1d490b),_0x316af2=Ar(_0x2db048);return new Be({'user':_0x35f13f,'providerId':_0x316af2,'_tokenResponse':_0x2db048,'operationType':_0x4ded2a});}static async['_forOperation'](_0x4d15e6,_0x10d746,_0x3879a3){await _0x4d15e6['_updateTokensIfNecessary'](_0x3879a3,!0x0);const _0x23fb6=Ar(_0x3879a3);return new Be({'user':_0x4d15e6,'providerId':_0x23fb6,'_tokenResponse':_0x3879a3,'operationType':_0x10d746});}}function Ar(_0xf4079b){return _0xf4079b['providerId']?_0xf4079b['providerId']:'phoneNumber'in _0xf4079b?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x80ffd5,_0x4ba505,_0x5a24d4,_0xc3ce12){super(_0x4ba505['code'],_0x4ba505['message']),this['operationType']=_0x5a24d4,this['user']=_0xc3ce12,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x80ffd5['name'],'tenantId':_0x80ffd5['tenantId']??void 0x0,'_serverResponse':_0x4ba505['customData']['_serverResponse'],'operationType':_0x5a24d4};}static['_fromErrorAndOperation'](_0x355e00,_0x361f8d,_0x569c48,_0x3873cd){return new Rn(_0x355e00,_0x361f8d,_0x569c48,_0x3873cd);}}function Fa(_0x115932,_0x50006c,_0x4d028b,_0x364400){return(_0x50006c==='reauthenticate'?_0x4d028b['_getReauthenticationResolver'](_0x115932):_0x4d028b['_getIdTokenResponse'](_0x115932))['catch'](_0x1d3c4f=>{throw _0x1d3c4f['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x115932,_0x1d3c4f,_0x50006c,_0x364400):_0x1d3c4f;});}async function jf(_0x4f0d6c,_0x23d324,_0x47a995=!0x1){const _0x5b2236=await xt(_0x4f0d6c,_0x23d324['_linkToIdToken'](_0x4f0d6c['auth'],await _0x4f0d6c['getIdToken']()),_0x47a995);return Be['_forOperation'](_0x4f0d6c,'link',_0x5b2236);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x158086,_0x247c1c,_0x31029f=!0x1){const {auth:_0x30b6aa}=_0x158086;if(H(_0x30b6aa['app']))return Promise['reject'](se(_0x30b6aa));const _0xbe0b93='reauthenticate';try{const _0x3851d0=await xt(_0x158086,Fa(_0x30b6aa,_0xbe0b93,_0x247c1c,_0x158086),_0x31029f);m(_0x3851d0['idToken'],_0x30b6aa,'internal-error');const _0x41b6bd=ws(_0x3851d0['idToken']);m(_0x41b6bd,_0x30b6aa,'internal-error');const {sub:_0x40752b}=_0x41b6bd;return m(_0x158086['uid']===_0x40752b,_0x30b6aa,'user-mismatch'),Be['_forOperation'](_0x158086,_0xbe0b93,_0x3851d0);}catch(_0x53332e){throw(_0x53332e==null?void 0x0:_0x53332e['code'])==='auth/user-not-found'&&K(_0x30b6aa,'user-mismatch'),_0x53332e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4d62d1,_0xa75e75,_0x1dd01f=!0x1){if(H(_0x4d62d1['app']))return Promise['reject'](se(_0x4d62d1));const _0x3e0c21='signIn',_0x2f6473=await Fa(_0x4d62d1,_0x3e0c21,_0xa75e75),_0x221688=await Be['_fromIdTokenResponse'](_0x4d62d1,_0x3e0c21,_0x2f6473);return _0x1dd01f||await _0x4d62d1['_updateCurrentUser'](_0x221688['user']),_0x221688;}async function Yf(_0x1c7272,_0x416497){return Ua(qe(_0x1c7272),_0x416497);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x1e6c84){const _0x4b8d10=qe(_0x1e6c84);_0x4b8d10['_getPasswordPolicyInternal']()&&await _0x4b8d10['_updatePasswordPolicy']();}async function R_(_0x4e5fb7,_0x79e3d7,_0x5d40e4){if(H(_0x4e5fb7['app']))return Promise['reject'](se(_0x4e5fb7));const _0x2eadf3=qe(_0x4e5fb7),_0x46f180=await Oi(_0x2eadf3,{'returnSecureToken':!0x0,'email':_0x79e3d7,'password':_0x5d40e4,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0xd5bda9=>{throw _0xd5bda9['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4e5fb7),_0xd5bda9;}),_0x303513=await Be['_fromIdTokenResponse'](_0x2eadf3,'signIn',_0x46f180);return await _0x2eadf3['_updateCurrentUser'](_0x303513['user']),_0x303513;}function A_(_0x51753b,_0x272760,_0x4048db){return H(_0x51753b['app'])?Promise['reject'](se(_0x51753b)):Yf(k(_0x51753b),ft['credential'](_0x272760,_0x4048db))['catch'](async _0x1c562f=>{throw _0x1c562f['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x51753b),_0x1c562f;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x343b1b,_0x27095d){return k(_0x343b1b)['setPersistence'](_0x27095d);}function Qf(_0xd154f7,_0x139665,_0x1ef8ca,_0x4e5636){return k(_0xd154f7)['onIdTokenChanged'](_0x139665,_0x1ef8ca,_0x4e5636);}function Jf(_0x1035be,_0x11a009,_0x2925fb){return k(_0x1035be)['beforeAuthStateChanged'](_0x11a009,_0x2925fb);}function N_(_0x106500,_0x4d3238,_0xe79ed4,_0x37bd8c){return k(_0x106500)['onAuthStateChanged'](_0x4d3238,_0xe79ed4,_0x37bd8c);}function P_(_0xe5ee23){return k(_0xe5ee23)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0xf68ad3,_0x3dc260){this['storageRetriever']=_0xf68ad3,this['type']=_0x3dc260;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x272413,_0x56aa9d){return this['storage']['setItem'](_0x272413,JSON['stringify'](_0x56aa9d)),Promise['resolve']();}['_get'](_0x5ec175){const _0x2c8aca=this['storage']['getItem'](_0x5ec175);return Promise['resolve'](_0x2c8aca?JSON['parse'](_0x2c8aca):null);}['_remove'](_0x44dac2){return this['storage']['removeItem'](_0x44dac2),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x549cfc,_0x3f9b55)=>this['onStorageEvent'](_0x549cfc,_0x3f9b55),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1f756b){for(const _0x1ecbdc of Object['keys'](this['listeners'])){const _0x2025e3=this['storage']['getItem'](_0x1ecbdc),_0x14311d=this['localCache'][_0x1ecbdc];_0x2025e3!==_0x14311d&&_0x1f756b(_0x1ecbdc,_0x14311d,_0x2025e3);}}['onStorageEvent'](_0x36cb59,_0x4e8a28=!0x1){if(!_0x36cb59['key']){this['forAllChangedKeys']((_0x279f32,_0x48e62f,_0x1e17cc)=>{this['notifyListeners'](_0x279f32,_0x1e17cc);});return;}const _0xdc3ca3=_0x36cb59['key'];_0x4e8a28?this['detachListener']():this['stopPolling']();const _0x3647b4=()=>{const _0x2e5c20=this['storage']['getItem'](_0xdc3ca3);!_0x4e8a28&&this['localCache'][_0xdc3ca3]===_0x2e5c20||this['notifyListeners'](_0xdc3ca3,_0x2e5c20);},_0x556b8d=this['storage']['getItem'](_0xdc3ca3);If()&&_0x556b8d!==_0x36cb59['newValue']&&_0x36cb59['newValue']!==_0x36cb59['oldValue']?setTimeout(_0x3647b4,Zf):_0x3647b4();}['notifyListeners'](_0x1b7438,_0x1d14ec){this['localCache'][_0x1b7438]=_0x1d14ec;const _0x5ee71b=this['listeners'][_0x1b7438];if(_0x5ee71b){for(const _0x42d2b2 of Array['from'](_0x5ee71b))_0x42d2b2(_0x1d14ec&&JSON['parse'](_0x1d14ec));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3aa668,_0x2d5cb9,_0x56e2b7)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3aa668,'oldValue':_0x2d5cb9,'newValue':_0x56e2b7}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x50b14c,_0x427b4){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x50b14c]||(this['listeners'][_0x50b14c]=new Set(),this['localCache'][_0x50b14c]=this['storage']['getItem'](_0x50b14c)),this['listeners'][_0x50b14c]['add'](_0x427b4);}['_removeListener'](_0x503444,_0x41a42e){this['listeners'][_0x503444]&&(this['listeners'][_0x503444]['delete'](_0x41a42e),this['listeners'][_0x503444]['size']===0x0&&delete this['listeners'][_0x503444]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3938dd,_0x145b8d){await super['_set'](_0x3938dd,_0x145b8d),this['localCache'][_0x3938dd]=JSON['stringify'](_0x145b8d);}async['_get'](_0x3b69ba){const _0x228413=await super['_get'](_0x3b69ba);return this['localCache'][_0x3b69ba]=JSON['stringify'](_0x228413),_0x228413;}async['_remove'](_0x1c5ecc){await super['_remove'](_0x1c5ecc),delete this['localCache'][_0x1c5ecc];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x20239f,_0x5e7b77){}['_removeListener'](_0x236a8b,_0x35c8d6){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x43b112){return Promise['all'](_0x43b112['map'](async _0x324b94=>{try{return{'fulfilled':!0x0,'value':await _0x324b94};}catch(_0x16150d){return{'fulfilled':!0x1,'reason':_0x16150d};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x2f458b){this['eventTarget']=_0x2f458b,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x10af0b){const _0x3196ff=this['receivers']['find'](_0x21d1b7=>_0x21d1b7['isListeningto'](_0x10af0b));if(_0x3196ff)return _0x3196ff;const _0x3c05bd=new jn(_0x10af0b);return this['receivers']['push'](_0x3c05bd),_0x3c05bd;}['isListeningto'](_0x1c1f26){return this['eventTarget']===_0x1c1f26;}async['handleEvent'](_0x2716b5){const _0x4c6faa=_0x2716b5,{eventId:_0x30c5b9,eventType:_0x28156d,data:_0x2132af}=_0x4c6faa['data'],_0x4abe4b=this['handlersMap'][_0x28156d];if(!(_0x4abe4b!=null&&_0x4abe4b['size']))return;_0x4c6faa['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x30c5b9,'eventType':_0x28156d});const _0x7f5b38=Array['from'](_0x4abe4b)['map'](async _0x40eede=>_0x40eede(_0x4c6faa['origin'],_0x2132af)),_0x421f4e=await tp(_0x7f5b38);_0x4c6faa['ports'][0x0]['postMessage']({'status':'done','eventId':_0x30c5b9,'eventType':_0x28156d,'response':_0x421f4e});}['_subscribe'](_0x436c3c,_0x654bed){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x436c3c]||(this['handlersMap'][_0x436c3c]=new Set()),this['handlersMap'][_0x436c3c]['add'](_0x654bed);}['_unsubscribe'](_0x52f6b9,_0x37a71a){this['handlersMap'][_0x52f6b9]&&_0x37a71a&&this['handlersMap'][_0x52f6b9]['delete'](_0x37a71a),(!_0x37a71a||this['handlersMap'][_0x52f6b9]['size']===0x0)&&delete this['handlersMap'][_0x52f6b9],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x29af46='',_0x554b1e=0xa){let _0x30f68b='';for(let _0x44a3a4=0x0;_0x44a3a4<_0x554b1e;_0x44a3a4++)_0x30f68b+=Math['floor'](Math['random']()*0xa);return _0x29af46+_0x30f68b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x270d39){this['target']=_0x270d39,this['handlers']=new Set();}['removeMessageHandler'](_0x345595){_0x345595['messageChannel']&&(_0x345595['messageChannel']['port1']['removeEventListener']('message',_0x345595['onMessage']),_0x345595['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x345595);}async['_send'](_0x24f04b,_0xf4ad6d,_0xcd3030=0x32){const _0x12a994=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x12a994)throw new Error('connection_unavailable');let _0x45b48e,_0x45b9cb;return new Promise((_0x24be26,_0x41cb21)=>{const _0x4b5acf=bs('',0x14);_0x12a994['port1']['start']();const _0x184350=setTimeout(()=>{_0x41cb21(new Error('unsupported_event'));},_0xcd3030);_0x45b9cb={'messageChannel':_0x12a994,'onMessage'(_0x3dd78f){const _0x5ac0d6=_0x3dd78f;if(_0x5ac0d6['data']['eventId']===_0x4b5acf)switch(_0x5ac0d6['data']['status']){case'ack':clearTimeout(_0x184350),_0x45b48e=setTimeout(()=>{_0x41cb21(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x45b48e),_0x24be26(_0x5ac0d6['data']['response']);break;default:clearTimeout(_0x184350),clearTimeout(_0x45b48e),_0x41cb21(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x45b9cb),_0x12a994['port1']['addEventListener']('message',_0x45b9cb['onMessage']),this['target']['postMessage']({'eventType':_0x24f04b,'eventId':_0x4b5acf,'data':_0xf4ad6d},[_0x12a994['port2']]);})['finally'](()=>{_0x45b9cb&&this['removeMessageHandler'](_0x45b9cb);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x4ee8b2){X()['location']['href']=_0x4ee8b2;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x4319c2;return((_0x4319c2=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4319c2['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x2193dc){this['request']=_0x2193dc;}['toPromise'](){return new Promise((_0x5a2c8f,_0x15a708)=>{this['request']['addEventListener']('success',()=>{_0x5a2c8f(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x15a708(this['request']['error']);});});}}function Kn(_0x20062d,_0x1cc6ca){return _0x20062d['transaction']([kn],_0x1cc6ca?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x516a5b=indexedDB['deleteDatabase'](qa);return new Jt(_0x516a5b)['toPromise']();}function ja(){const _0xa28d2d=indexedDB['open'](qa,ap);return new Promise((_0x2411e0,_0x1879bf)=>{_0xa28d2d['addEventListener']('error',()=>{_0x1879bf(_0xa28d2d['error']);}),_0xa28d2d['addEventListener']('upgradeneeded',()=>{const _0x2b7de5=_0xa28d2d['result'];try{_0x2b7de5['createObjectStore'](kn,{'keyPath':za});}catch(_0x51487d){_0x1879bf(_0x51487d);}}),_0xa28d2d['addEventListener']('success',async()=>{const _0x229293=_0xa28d2d['result'];_0x229293['objectStoreNames']['contains'](kn)?_0x2411e0(_0x229293):(_0x229293['close'](),await cp(),_0x2411e0(await ja()));});});}async function kr(_0x27cd50,_0x25a532,_0x25c2f2){const _0x58442a=Kn(_0x27cd50,!0x0)['put']({[za]:_0x25a532,'value':_0x25c2f2});return new Jt(_0x58442a)['toPromise']();}async function lp(_0x2237e0,_0x58e17b){const _0x196906=Kn(_0x2237e0,!0x1)['get'](_0x58e17b),_0x5c2128=await new Jt(_0x196906)['toPromise']();return _0x5c2128===void 0x0?null:_0x5c2128['value'];}function Nr(_0x656b84,_0x16e2fe){const _0x3f81a9=Kn(_0x656b84,!0x0)['delete'](_0x16e2fe);return new Jt(_0x3f81a9)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2697e5){let _0x504484=0x0;for(;;)try{const _0x2763b9=await this['_openDb']();return await _0x2697e5(_0x2763b9);}catch(_0x3589ba){if(_0x504484++>up)throw _0x3589ba;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x132a32,_0x1cb075)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1cb075['key'])})),this['receiver']['_subscribe']('ping',async(_0x3645a4,_0x3c204c)=>['keyChanged']);}async['initializeSender'](){var _0x34cd75,_0x1efc8b;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x4fbe83=await this['sender']['_send']('ping',{},0x320);_0x4fbe83&&(_0x34cd75=_0x4fbe83[0x0])!=null&&_0x34cd75['fulfilled']&&(_0x1efc8b=_0x4fbe83[0x0])!=null&&_0x1efc8b['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x215875){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x215875},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5196c2=>{await kr(_0x5196c2,An,'1'),await Nr(_0x5196c2,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x25a1f9){this['pendingWrites']++;try{await _0x25a1f9();}finally{this['pendingWrites']--;}}async['_set'](_0x33042c,_0x144bd1){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x38e190=>kr(_0x38e190,_0x33042c,_0x144bd1)),this['localCache'][_0x33042c]=_0x144bd1,this['notifyServiceWorker'](_0x33042c)));}async['_get'](_0x36e379){const _0x16e34e=await this['_withRetries'](_0x5d1216=>lp(_0x5d1216,_0x36e379));return this['localCache'][_0x36e379]=_0x16e34e,_0x16e34e;}async['_remove'](_0x1bbae2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x55c4cf=>Nr(_0x55c4cf,_0x1bbae2)),delete this['localCache'][_0x1bbae2],this['notifyServiceWorker'](_0x1bbae2)));}async['_poll'](){const _0x254c68=await this['_withRetries'](_0x256bbb=>{const _0xd9acae=Kn(_0x256bbb,!0x1)['getAll']();return new Jt(_0xd9acae)['toPromise']();});if(!_0x254c68)return[];if(this['pendingWrites']!==0x0)return[];const _0x32415a=[],_0x7425b8=new Set();if(_0x254c68['length']!==0x0){for(const {fbase_key:_0x219305,value:_0x2246a2}of _0x254c68)_0x7425b8['add'](_0x219305),JSON['stringify'](this['localCache'][_0x219305])!==JSON['stringify'](_0x2246a2)&&(this['notifyListeners'](_0x219305,_0x2246a2),_0x32415a['push'](_0x219305));}for(const _0x1cbb50 of Object['keys'](this['localCache']))this['localCache'][_0x1cbb50]&&!_0x7425b8['has'](_0x1cbb50)&&(this['notifyListeners'](_0x1cbb50,null),_0x32415a['push'](_0x1cbb50));return _0x32415a;}['notifyListeners'](_0x477633,_0x195154){this['localCache'][_0x477633]=_0x195154;const _0x44f327=this['listeners'][_0x477633];if(_0x44f327){for(const _0x38778e of Array['from'](_0x44f327))_0x38778e(_0x195154);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x1b8237,_0x3eec03){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x1b8237]||(this['listeners'][_0x1b8237]=new Set(),this['_get'](_0x1b8237)),this['listeners'][_0x1b8237]['add'](_0x3eec03);}['_removeListener'](_0x49f43f,_0x5d329a){this['listeners'][_0x49f43f]&&(this['listeners'][_0x49f43f]['delete'](_0x5d329a),this['listeners'][_0x49f43f]['size']===0x0&&delete this['listeners'][_0x49f43f]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x17521e,_0x588ef5){return _0x588ef5?ne(_0x588ef5):(m(_0x17521e['_popupRedirectResolver'],_0x17521e,'argument-error'),_0x17521e['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x43f902){super('custom','custom'),this['params']=_0x43f902;}['_getIdTokenResponse'](_0x418973){return Ze(_0x418973,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2f578c,_0x5e2f7d){return Ze(_0x2f578c,this['_buildIdpRequest'](_0x5e2f7d));}['_getReauthenticationResolver'](_0x599a9c){return Ze(_0x599a9c,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x437a76){const _0x2cffd4={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x437a76&&(_0x2cffd4['idToken']=_0x437a76),_0x2cffd4;}}function pp(_0x4c13ea){return Ua(_0x4c13ea['auth'],new Rs(_0x4c13ea),_0x4c13ea['bypassAuthState']);}function _p(_0x1e1ac2){const {auth:_0x44beac,user:_0x56e1c6}=_0x1e1ac2;return m(_0x56e1c6,_0x44beac,'internal-error'),Kf(_0x56e1c6,new Rs(_0x1e1ac2),_0x1e1ac2['bypassAuthState']);}async function gp(_0x51f758){const {auth:_0x43ae5a,user:_0x52847a}=_0x51f758;return m(_0x52847a,_0x43ae5a,'internal-error'),jf(_0x52847a,new Rs(_0x51f758),_0x51f758['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x81c2b6,_0x1783c4,_0x59313b,_0x1c50b8,_0x386211=!0x1){this['auth']=_0x81c2b6,this['resolver']=_0x59313b,this['user']=_0x1c50b8,this['bypassAuthState']=_0x386211,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1783c4)?_0x1783c4:[_0x1783c4];}['execute'](){return new Promise(async(_0x47bd5c,_0x1e542e)=>{this['pendingPromise']={'resolve':_0x47bd5c,'reject':_0x1e542e};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x23c2d8){this['reject'](_0x23c2d8);}});}async['onAuthEvent'](_0xda97fc){const {urlResponse:_0x475d4f,sessionId:_0x1cb43f,postBody:_0x27ec88,tenantId:_0x54e88f,error:_0x38a2a4,type:_0x47b222}=_0xda97fc;if(_0x38a2a4){this['reject'](_0x38a2a4);return;}const _0x571e67={'auth':this['auth'],'requestUri':_0x475d4f,'sessionId':_0x1cb43f,'tenantId':_0x54e88f||void 0x0,'postBody':_0x27ec88||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x47b222)(_0x571e67));}catch(_0x10c478){this['reject'](_0x10c478);}}['onError'](_0x1dc43d){this['reject'](_0x1dc43d);}['getIdpTask'](_0x1afa0e){switch(_0x1afa0e){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x13bef1){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x13bef1),this['unregisterAndCleanUp']();}['reject'](_0x5514d2){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5514d2),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x28a0b4,_0x51b134,_0x50d05b,_0x2f3ec1,_0x18f589){super(_0x28a0b4,_0x51b134,_0x2f3ec1,_0x18f589),this['provider']=_0x50d05b,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x6df2a9=await this['execute']();return m(_0x6df2a9,this['auth'],'internal-error'),_0x6df2a9;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x126926=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x126926),this['authWindow']['associatedEvent']=_0x126926,this['resolver']['_originValidation'](this['auth'])['catch'](_0xf5af41=>{this['reject'](_0xf5af41);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x172004=>{_0x172004||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x13394c;return((_0x13394c=this['authWindow'])==null?void 0x0:_0x13394c['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x31d9c6=()=>{var _0x20b3e7,_0x2ec4c8;if((_0x2ec4c8=(_0x20b3e7=this['authWindow'])==null?void 0x0:_0x20b3e7['window'])!=null&&_0x2ec4c8['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x31d9c6,mp['get']());};_0x31d9c6();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x221ab3,_0x4ac0e9,_0x4c903b=!0x1){super(_0x221ab3,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4ac0e9,void 0x0,_0x4c903b),this['eventId']=null;}async['execute'](){let _0x5adc93=rn['get'](this['auth']['_key']());if(!_0x5adc93){try{const _0x2b7b10=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x5adc93=()=>Promise['resolve'](_0x2b7b10);}catch(_0x523636){_0x5adc93=()=>Promise['reject'](_0x523636);}rn['set'](this['auth']['_key'](),_0x5adc93);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5adc93();}async['onAuthEvent'](_0x5e21f7){if(_0x5e21f7['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5e21f7);if(_0x5e21f7['type']==='unknown'){this['resolve'](null);return;}if(_0x5e21f7['eventId']){const _0x2426a2=await this['auth']['_redirectUserForId'](_0x5e21f7['eventId']);if(_0x2426a2)return this['user']=_0x2426a2,super['onAuthEvent'](_0x5e21f7);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x7a2d9e,_0x78d311){const _0x2a24cb=Cp(_0x78d311),_0x13a2e0=wp(_0x7a2d9e);if(!await _0x13a2e0['_isAvailable']())return!0x1;const _0x3eea70=await _0x13a2e0['_get'](_0x2a24cb)==='true';return await _0x13a2e0['_remove'](_0x2a24cb),_0x3eea70;}function Ip(_0x5b921c,_0x278456){rn['set'](_0x5b921c['_key'](),_0x278456);}function wp(_0xf86b62){return ne(_0xf86b62['_redirectPersistence']);}function Cp(_0x36b48a){return sn(yp,_0x36b48a['config']['apiKey'],_0x36b48a['name']);}async function Tp(_0x5c3aca,_0x112ef9,_0x2cb391=!0x1){if(H(_0x5c3aca['app']))return Promise['reject'](se(_0x5c3aca));const _0x5ce9e8=qe(_0x5c3aca),_0x3d8f50=fp(_0x5ce9e8,_0x112ef9),_0x9fa877=await new vp(_0x5ce9e8,_0x3d8f50,_0x2cb391)['execute']();return _0x9fa877&&!_0x2cb391&&(delete _0x9fa877['user']['_redirectEventId'],await _0x5ce9e8['_persistUserIfCurrent'](_0x9fa877['user']),await _0x5ce9e8['_setRedirectUser'](null,_0x112ef9)),_0x9fa877;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0xef5bb0){this['auth']=_0xef5bb0,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x15699d){this['consumers']['add'](_0x15699d),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x15699d)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x15699d),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5d165d){this['consumers']['delete'](_0x5d165d);}['onEvent'](_0x3dea9d){if(this['hasEventBeenHandled'](_0x3dea9d))return!0x1;let _0x43d1f8=!0x1;return this['consumers']['forEach'](_0x143824=>{this['isEventForConsumer'](_0x3dea9d,_0x143824)&&(_0x43d1f8=!0x0,this['sendToConsumer'](_0x3dea9d,_0x143824),this['saveEventToCache'](_0x3dea9d));}),this['hasHandledPotentialRedirect']||!Rp(_0x3dea9d)||(this['hasHandledPotentialRedirect']=!0x0,_0x43d1f8||(this['queuedRedirectEvent']=_0x3dea9d,_0x43d1f8=!0x0)),_0x43d1f8;}['sendToConsumer'](_0x4c8ffd,_0x139828){var _0x1bc0de;if(_0x4c8ffd['error']&&!Qa(_0x4c8ffd)){const _0x54d9f3=((_0x1bc0de=_0x4c8ffd['error']['code'])==null?void 0x0:_0x1bc0de['split']('auth/')[0x1])||'internal-error';_0x139828['onError'](J(this['auth'],_0x54d9f3));}else _0x139828['onAuthEvent'](_0x4c8ffd);}['isEventForConsumer'](_0x2e6c76,_0x927d31){const _0x5f2001=_0x927d31['eventId']===null||!!_0x2e6c76['eventId']&&_0x2e6c76['eventId']===_0x927d31['eventId'];return _0x927d31['filter']['includes'](_0x2e6c76['type'])&&_0x5f2001;}['hasEventBeenHandled'](_0x286f64){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x286f64));}['saveEventToCache'](_0xd6850){this['cachedEventUids']['add'](Pr(_0xd6850)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x378327){return[_0x378327['type'],_0x378327['eventId'],_0x378327['sessionId'],_0x378327['tenantId']]['filter'](_0x800454=>_0x800454)['join']('-');}function Qa({type:_0x2a95eb,error:_0x51b37d}){return _0x2a95eb==='unknown'&&(_0x51b37d==null?void 0x0:_0x51b37d['code'])==='auth/no-auth-event';}function Rp(_0x44accc){switch(_0x44accc['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x44accc);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x2688e4,_0x439049={}){return Ae(_0x2688e4,'GET','/v1/projects',_0x439049);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x5fdd1e){if(_0x5fdd1e['config']['emulator'])return;const {authorizedDomains:_0x134f75}=await Ap(_0x5fdd1e);for(const _0x4bc6d5 of _0x134f75)try{if(Op(_0x4bc6d5))return;}catch{}K(_0x5fdd1e,'unauthorized-domain');}function Op(_0x2124bb){const _0x25ec0c=Ni(),{protocol:_0xa4e9cf,hostname:_0x2127cf}=new URL(_0x25ec0c);if(_0x2124bb['startsWith']('chrome-extension://')){const _0x2486c3=new URL(_0x2124bb);return _0x2486c3['hostname']===''&&_0x2127cf===''?_0xa4e9cf==='chrome-extension:'&&_0x2124bb['replace']('chrome-extension://','')===_0x25ec0c['replace']('chrome-extension://',''):_0xa4e9cf==='chrome-extension:'&&_0x2486c3['hostname']===_0x2127cf;}if(!Np['test'](_0xa4e9cf))return!0x1;if(kp['test'](_0x2124bb))return _0x2127cf===_0x2124bb;const _0x23b34a=_0x2124bb['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x23b34a+'|'+_0x23b34a+')$','i')['test'](_0x2127cf);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x572c49=X()['___jsl'];if(_0x572c49!=null&&_0x572c49['H']){for(const _0x502cf0 of Object['keys'](_0x572c49['H']))if(_0x572c49['H'][_0x502cf0]['r']=_0x572c49['H'][_0x502cf0]['r']||[],_0x572c49['H'][_0x502cf0]['L']=_0x572c49['H'][_0x502cf0]['L']||[],_0x572c49['H'][_0x502cf0]['r']=[..._0x572c49['H'][_0x502cf0]['L']],_0x572c49['CP']){for(let _0x16a587=0x0;_0x16a587<_0x572c49['CP']['length'];_0x16a587++)_0x572c49['CP'][_0x16a587]=null;}}}function Mp(_0x52d6b5){return new Promise((_0x8f3c4e,_0x325703)=>{var _0x455596,_0x380f20,_0x50a452;function _0x38738f(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x8f3c4e(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x325703(J(_0x52d6b5,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x380f20=(_0x455596=X()['gapi'])==null?void 0x0:_0x455596['iframes'])!=null&&_0x380f20['Iframe'])_0x8f3c4e(gapi['iframes']['getContext']());else{if((_0x50a452=X()['gapi'])!=null&&_0x50a452['load'])_0x38738f();else{const _0x2c325b=Nf('iframefcb');return X()[_0x2c325b]=()=>{gapi['load']?_0x38738f():_0x325703(J(_0x52d6b5,'network-request-failed'));},Da(kf()+'?onload='+_0x2c325b)['catch'](_0x59653c=>_0x325703(_0x59653c));}}})['catch'](_0x41afce=>{throw on=null,_0x41afce;});}let on=null;function Lp(_0x18c9b6){return on=on||Mp(_0x18c9b6),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x3a1356){const _0x587697=_0x3a1356['config'];m(_0x587697['authDomain'],_0x3a1356,'auth-domain-config-required');const _0x52ff99=_0x587697['emulator']?Is(_0x587697,Up):'https://'+_0x3a1356['config']['authDomain']+'/'+Fp,_0x238ca0={'apiKey':_0x587697['apiKey'],'appName':_0x3a1356['name'],'v':ct},_0x9c798d=Bp['get'](_0x3a1356['config']['apiHost']);_0x9c798d&&(_0x238ca0['eid']=_0x9c798d);const _0x24819f=_0x3a1356['_getFrameworks']();return _0x24819f['length']&&(_0x238ca0['fw']=_0x24819f['join'](',')),_0x52ff99+'?'+at(_0x238ca0)['slice'](0x1);}async function Hp(_0x502ad9){const _0x5eb92f=await Lp(_0x502ad9),_0x5a3a4f=X()['gapi'];return m(_0x5a3a4f,_0x502ad9,'internal-error'),_0x5eb92f['open']({'where':document['body'],'url':Vp(_0x502ad9),'messageHandlersFilter':_0x5a3a4f['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x295728=>new Promise(async(_0x27535d,_0x2e7385)=>{await _0x295728['restyle']({'setHideOnLeave':!0x1});const _0x46988e=J(_0x502ad9,'network-request-failed'),_0x2864e4=X()['setTimeout'](()=>{_0x2e7385(_0x46988e);},xp['get']());function _0x5db3a7(){X()['clearTimeout'](_0x2864e4),_0x27535d(_0x295728);}_0x295728['ping'](_0x5db3a7)['then'](_0x5db3a7,()=>{_0x2e7385(_0x46988e);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x3c637a){this['window']=_0x3c637a,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x1ca3bf,_0x69dd4f,_0x1353c5,_0x401a3f=Gp,_0x13cc04=qp){const _0x11f847=Math['max']((window['screen']['availHeight']-_0x13cc04)/0x2,0x0)['toString'](),_0x2eb40e=Math['max']((window['screen']['availWidth']-_0x401a3f)/0x2,0x0)['toString']();let _0x3c449e='';const _0x3d726e={...$p,'width':_0x401a3f['toString'](),'height':_0x13cc04['toString'](),'top':_0x11f847,'left':_0x2eb40e},_0x22a198=W()['toLowerCase']();_0x1353c5&&(_0x3c449e=ba(_0x22a198)?zp:_0x1353c5),Ta(_0x22a198)&&(_0x69dd4f=_0x69dd4f||jp,_0x3d726e['scrollbars']='yes');const _0x3c165c=Object['entries'](_0x3d726e)['reduce']((_0x45f3c5,[_0x53bb76,_0x18d138])=>''+_0x45f3c5+_0x53bb76+'='+_0x18d138+',','');if(Ef(_0x22a198)&&_0x3c449e!=='_self')return Yp(_0x69dd4f||'',_0x3c449e),new Dr(null);const _0xbce30f=window['open'](_0x69dd4f||'',_0x3c449e,_0x3c165c);m(_0xbce30f,_0x1ca3bf,'popup-blocked');try{_0xbce30f['focus']();}catch{}return new Dr(_0xbce30f);}function Yp(_0xa660cd,_0x40727b){const _0x345eca=document['createElement']('a');_0x345eca['href']=_0xa660cd,_0x345eca['target']=_0x40727b;const _0x5a536=document['createEvent']('MouseEvent');_0x5a536['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x345eca['dispatchEvent'](_0x5a536);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x1fb512,_0x3d7cf2,_0x15b4c4,_0x275df3,_0x2c1ce4,_0xdc9a0d){m(_0x1fb512['config']['authDomain'],_0x1fb512,'auth-domain-config-required'),m(_0x1fb512['config']['apiKey'],_0x1fb512,'invalid-api-key');const _0x4a8d21={'apiKey':_0x1fb512['config']['apiKey'],'appName':_0x1fb512['name'],'authType':_0x15b4c4,'redirectUrl':_0x275df3,'v':ct,'eventId':_0x2c1ce4};if(_0x3d7cf2 instanceof xa){_0x3d7cf2['setDefaultLanguage'](_0x1fb512['languageCode']),_0x4a8d21['providerId']=_0x3d7cf2['providerId']||'',hi(_0x3d7cf2['getCustomParameters']())||(_0x4a8d21['customParameters']=JSON['stringify'](_0x3d7cf2['getCustomParameters']()));for(const [_0x15924c,_0x4a3556]of Object['entries']({}))_0x4a8d21[_0x15924c]=_0x4a3556;}if(_0x3d7cf2 instanceof Qt){const _0x4e313d=_0x3d7cf2['getScopes']()['filter'](_0x4524aa=>_0x4524aa!=='');_0x4e313d['length']>0x0&&(_0x4a8d21['scopes']=_0x4e313d['join'](','));}_0x1fb512['tenantId']&&(_0x4a8d21['tid']=_0x1fb512['tenantId']);const _0x28409e=_0x4a8d21;for(const _0x4224d3 of Object['keys'](_0x28409e))_0x28409e[_0x4224d3]===void 0x0&&delete _0x28409e[_0x4224d3];const _0x4acb7c=await _0x1fb512['_getAppCheckToken'](),_0x1bfb77=_0x4acb7c?'#'+Xp+'='+encodeURIComponent(_0x4acb7c):'';return Zp(_0x1fb512)+'?'+at(_0x28409e)['slice'](0x1)+_0x1bfb77;}function Zp({config:_0x47f5a5}){return _0x47f5a5['emulator']?Is(_0x47f5a5,Jp):'https://'+_0x47f5a5['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x280163,_0x3da10f,_0x14a658,_0x16f91a){var _0x22c2b7;ae((_0x22c2b7=this['eventManagers'][_0x280163['_key']()])==null?void 0x0:_0x22c2b7['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2e0fc3=await Mr(_0x280163,_0x3da10f,_0x14a658,Ni(),_0x16f91a);return Kp(_0x280163,_0x2e0fc3,bs());}async['_openRedirect'](_0x3deb4a,_0x31ada9,_0x254b9b,_0x3ca979){await this['_originValidation'](_0x3deb4a);const _0x24f559=await Mr(_0x3deb4a,_0x31ada9,_0x254b9b,Ni(),_0x3ca979);return ip(_0x24f559),new Promise(()=>{});}['_initialize'](_0x373a2d){const _0x2acad9=_0x373a2d['_key']();if(this['eventManagers'][_0x2acad9]){const {manager:_0x317830,promise:_0x4909d6}=this['eventManagers'][_0x2acad9];return _0x317830?Promise['resolve'](_0x317830):(ae(_0x4909d6,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4909d6);}const _0x136315=this['initAndGetManager'](_0x373a2d);return this['eventManagers'][_0x2acad9]={'promise':_0x136315},_0x136315['catch'](()=>{delete this['eventManagers'][_0x2acad9];}),_0x136315;}async['initAndGetManager'](_0x28b232){const _0x10b92b=await Hp(_0x28b232),_0x2415e5=new bp(_0x28b232);return _0x10b92b['register']('authEvent',_0x22edac=>(m(_0x22edac==null?void 0x0:_0x22edac['authEvent'],_0x28b232,'invalid-auth-event'),{'status':_0x2415e5['onEvent'](_0x22edac['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x28b232['_key']()]={'manager':_0x2415e5},this['iframes'][_0x28b232['_key']()]=_0x10b92b,_0x2415e5;}['_isIframeWebStorageSupported'](_0x3012bc,_0x48ac68){this['iframes'][_0x3012bc['_key']()]['send'](li,{'type':li},_0x19f551=>{var _0xeca35b;const _0x50115e=(_0xeca35b=_0x19f551==null?void 0x0:_0x19f551[0x0])==null?void 0x0:_0xeca35b[li];_0x50115e!==void 0x0&&_0x48ac68(!!_0x50115e),K(_0x3012bc,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x160b31){const _0x5eb84b=_0x160b31['_key']();return this['originValidationPromises'][_0x5eb84b]||(this['originValidationPromises'][_0x5eb84b]=Pp(_0x160b31)),this['originValidationPromises'][_0x5eb84b];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x37502c){this['auth']=_0x37502c,this['internalListeners']=new Map();}['getUid'](){var _0x20664e;return this['assertAuthConfigured'](),((_0x20664e=this['auth']['currentUser'])==null?void 0x0:_0x20664e['uid'])||null;}async['getToken'](_0x5b0df2){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x5b0df2)}:null;}['addAuthTokenListener'](_0x40ff79){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x40ff79))return;const _0x3a5e70=this['auth']['onIdTokenChanged'](_0x56a449=>{_0x40ff79((_0x56a449==null?void 0x0:_0x56a449['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x40ff79,_0x3a5e70),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x39f4fd){this['assertAuthConfigured']();const _0x2b2e06=this['internalListeners']['get'](_0x39f4fd);_0x2b2e06&&(this['internalListeners']['delete'](_0x39f4fd),_0x2b2e06(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x5e6015){switch(_0x5e6015){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x3a3d71){et(new Me('auth',(_0x55eb11,{options:_0x1c5737})=>{const _0x4397b1=_0x55eb11['getProvider']('app')['getImmediate'](),_0x16e8ad=_0x55eb11['getProvider']('heartbeat'),_0x1f115b=_0x55eb11['getProvider']('app-check-internal'),{apiKey:_0x511d84,authDomain:_0x3b682d}=_0x4397b1['options'];m(_0x511d84&&!_0x511d84['includes'](':'),'invalid-api-key',{'appName':_0x4397b1['name']});const _0x48289e={'apiKey':_0x511d84,'authDomain':_0x3b682d,'clientPlatform':_0x3a3d71,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x3a3d71)},_0x1b18dd=new bf(_0x4397b1,_0x16e8ad,_0x1f115b,_0x48289e);return Lf(_0x1b18dd,_0x1c5737),_0x1b18dd;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2f86b8,_0x4d9e58,_0x1f238e)=>{_0x2f86b8['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x1098d6=>{const _0x1dd5fd=qe(_0x1098d6['getProvider']('auth')['getImmediate']());return(_0x175437=>new n_(_0x175437))(_0x1dd5fd);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x3a3d71)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x1921fe=>async _0x4d0dc8=>{const _0x22a959=_0x4d0dc8&&await _0x4d0dc8['getIdTokenResult'](),_0x29dd0b=_0x22a959&&(new Date()['getTime']()-Date['parse'](_0x22a959['issuedAtTime']))/0x3e8;if(_0x29dd0b&&_0x29dd0b>o_)return;const _0x118e5e=_0x22a959==null?void 0x0:_0x22a959['token'];Fr!==_0x118e5e&&(Fr=_0x118e5e,await fetch(_0x1921fe,{'method':_0x118e5e?'POST':'DELETE','headers':_0x118e5e?{'Authorization':'Bearer\x20'+_0x118e5e}:{}}));};function O_(_0x920306=Qr()){const _0x7a29bf=Ui(_0x920306,'auth');if(_0x7a29bf['isInitialized']())return _0x7a29bf['getImmediate']();const _0x5b554d=Mf(_0x920306,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x2ceaef=Gr('authTokenSyncURL');if(_0x2ceaef&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3d027d=new URL(_0x2ceaef,location['origin']);if(location['origin']===_0x3d027d['origin']){const _0x2e6e10=a_(_0x3d027d['toString']());Jf(_0x5b554d,_0x2e6e10,()=>_0x2e6e10(_0x5b554d['currentUser'])),Qf(_0x5b554d,_0x352947=>_0x2e6e10(_0x352947));}}const _0x234a2c=Hr('auth');return _0x234a2c&&xf(_0x5b554d,'http://'+_0x234a2c),_0x5b554d;}function c_(){var _0x446aec;return((_0x446aec=document['getElementsByTagName']('head'))==null?void 0x0:_0x446aec[0x0])??document;}Rf({'loadJS'(_0x9fd65b){return new Promise((_0x3f1fd3,_0x58ee4a)=>{const _0x29083b=document['createElement']('script');_0x29083b['setAttribute']('src',_0x9fd65b),_0x29083b['onload']=_0x3f1fd3,_0x29083b['onerror']=_0x3bce95=>{const _0x45957e=J('internal-error');_0x45957e['customData']=_0x3bce95,_0x58ee4a(_0x45957e);},_0x29083b['type']='text/javascript',_0x29083b['charset']='UTF-8',c_()['appendChild'](_0x29083b);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};