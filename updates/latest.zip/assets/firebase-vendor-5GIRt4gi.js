const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1c5c8c,_0x1b2195){if(!_0x1c5c8c)throw ot(_0x1b2195);},ot=function(_0x5d36c0){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5d36c0);},Wr=function(_0x4c9b55){const _0x3fe1ac=[];let _0x67a26b=0x0;for(let _0x4e736b=0x0;_0x4e736b<_0x4c9b55['length'];_0x4e736b++){let _0x103679=_0x4c9b55['charCodeAt'](_0x4e736b);_0x103679<0x80?_0x3fe1ac[_0x67a26b++]=_0x103679:_0x103679<0x800?(_0x3fe1ac[_0x67a26b++]=_0x103679>>0x6|0xc0,_0x3fe1ac[_0x67a26b++]=_0x103679&0x3f|0x80):(_0x103679&0xfc00)===0xd800&&_0x4e736b+0x1<_0x4c9b55['length']&&(_0x4c9b55['charCodeAt'](_0x4e736b+0x1)&0xfc00)===0xdc00?(_0x103679=0x10000+((_0x103679&0x3ff)<<0xa)+(_0x4c9b55['charCodeAt'](++_0x4e736b)&0x3ff),_0x3fe1ac[_0x67a26b++]=_0x103679>>0x12|0xf0,_0x3fe1ac[_0x67a26b++]=_0x103679>>0xc&0x3f|0x80,_0x3fe1ac[_0x67a26b++]=_0x103679>>0x6&0x3f|0x80,_0x3fe1ac[_0x67a26b++]=_0x103679&0x3f|0x80):(_0x3fe1ac[_0x67a26b++]=_0x103679>>0xc|0xe0,_0x3fe1ac[_0x67a26b++]=_0x103679>>0x6&0x3f|0x80,_0x3fe1ac[_0x67a26b++]=_0x103679&0x3f|0x80);}return _0x3fe1ac;},Za=function(_0x19c950){const _0x5993ca=[];let _0x361905=0x0,_0x47737c=0x0;for(;_0x361905<_0x19c950['length'];){const _0x5a745d=_0x19c950[_0x361905++];if(_0x5a745d<0x80)_0x5993ca[_0x47737c++]=String['fromCharCode'](_0x5a745d);else{if(_0x5a745d>0xbf&&_0x5a745d<0xe0){const _0x1a1ca3=_0x19c950[_0x361905++];_0x5993ca[_0x47737c++]=String['fromCharCode']((_0x5a745d&0x1f)<<0x6|_0x1a1ca3&0x3f);}else{if(_0x5a745d>0xef&&_0x5a745d<0x16d){const _0x119376=_0x19c950[_0x361905++],_0x30b231=_0x19c950[_0x361905++],_0xed57c=_0x19c950[_0x361905++],_0x4ca809=((_0x5a745d&0x7)<<0x12|(_0x119376&0x3f)<<0xc|(_0x30b231&0x3f)<<0x6|_0xed57c&0x3f)-0x10000;_0x5993ca[_0x47737c++]=String['fromCharCode'](0xd800+(_0x4ca809>>0xa)),_0x5993ca[_0x47737c++]=String['fromCharCode'](0xdc00+(_0x4ca809&0x3ff));}else{const _0x159733=_0x19c950[_0x361905++],_0x35f505=_0x19c950[_0x361905++];_0x5993ca[_0x47737c++]=String['fromCharCode']((_0x5a745d&0xf)<<0xc|(_0x159733&0x3f)<<0x6|_0x35f505&0x3f);}}}}return _0x5993ca['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x1f35ff,_0x3ee3ee){if(!Array['isArray'](_0x1f35ff))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3f9266=_0x3ee3ee?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x1e4f2f=[];for(let _0x4581da=0x0;_0x4581da<_0x1f35ff['length'];_0x4581da+=0x3){const _0x45c3eb=_0x1f35ff[_0x4581da],_0x1b8b52=_0x4581da+0x1<_0x1f35ff['length'],_0x2eef6f=_0x1b8b52?_0x1f35ff[_0x4581da+0x1]:0x0,_0x132cec=_0x4581da+0x2<_0x1f35ff['length'],_0x234d84=_0x132cec?_0x1f35ff[_0x4581da+0x2]:0x0,_0x1461b1=_0x45c3eb>>0x2,_0xc696ab=(_0x45c3eb&0x3)<<0x4|_0x2eef6f>>0x4;let _0x410b32=(_0x2eef6f&0xf)<<0x2|_0x234d84>>0x6,_0x5f5d51=_0x234d84&0x3f;_0x132cec||(_0x5f5d51=0x40,_0x1b8b52||(_0x410b32=0x40)),_0x1e4f2f['push'](_0x3f9266[_0x1461b1],_0x3f9266[_0xc696ab],_0x3f9266[_0x410b32],_0x3f9266[_0x5f5d51]);}return _0x1e4f2f['join']('');},'encodeString'(_0x3895a1,_0x496ce2){return this['HAS_NATIVE_SUPPORT']&&!_0x496ce2?btoa(_0x3895a1):this['encodeByteArray'](Wr(_0x3895a1),_0x496ce2);},'decodeString'(_0x45b012,_0x4a3859){return this['HAS_NATIVE_SUPPORT']&&!_0x4a3859?atob(_0x45b012):Za(this['decodeStringToByteArray'](_0x45b012,_0x4a3859));},'decodeStringToByteArray'(_0x28a42f,_0x450472){this['init_']();const _0x5a5165=_0x450472?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x404fe1=[];for(let _0x2c6a64=0x0;_0x2c6a64<_0x28a42f['length'];){const _0xdf2079=_0x5a5165[_0x28a42f['charAt'](_0x2c6a64++)],_0x4c9b96=_0x2c6a64<_0x28a42f['length']?_0x5a5165[_0x28a42f['charAt'](_0x2c6a64)]:0x0;++_0x2c6a64;const _0x2e4ae0=_0x2c6a64<_0x28a42f['length']?_0x5a5165[_0x28a42f['charAt'](_0x2c6a64)]:0x40;++_0x2c6a64;const _0x8799aa=_0x2c6a64<_0x28a42f['length']?_0x5a5165[_0x28a42f['charAt'](_0x2c6a64)]:0x40;if(++_0x2c6a64,_0xdf2079==null||_0x4c9b96==null||_0x2e4ae0==null||_0x8799aa==null)throw new ec();const _0x25a6c6=_0xdf2079<<0x2|_0x4c9b96>>0x4;if(_0x404fe1['push'](_0x25a6c6),_0x2e4ae0!==0x40){const _0x4916d0=_0x4c9b96<<0x4&0xf0|_0x2e4ae0>>0x2;if(_0x404fe1['push'](_0x4916d0),_0x8799aa!==0x40){const _0x58ef7c=_0x2e4ae0<<0x6&0xc0|_0x8799aa;_0x404fe1['push'](_0x58ef7c);}}}return _0x404fe1;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x14e16c=0x0;_0x14e16c<this['ENCODED_VALS']['length'];_0x14e16c++)this['byteToCharMap_'][_0x14e16c]=this['ENCODED_VALS']['charAt'](_0x14e16c),this['charToByteMap_'][this['byteToCharMap_'][_0x14e16c]]=_0x14e16c,this['byteToCharMapWebSafe_'][_0x14e16c]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x14e16c),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x14e16c]]=_0x14e16c,_0x14e16c>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x14e16c)]=_0x14e16c,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x14e16c)]=_0x14e16c);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x3a608e){const _0x25fe76=Wr(_0x3a608e);return Di['encodeByteArray'](_0x25fe76,!0x0);},an=function(_0x1f9e28){return Br(_0x1f9e28)['replace'](/\./g,'');},cn=function(_0x4c84c7){try{return Di['decodeString'](_0x4c84c7,!0x0);}catch(_0xbddf20){console['error']('base64Decode\x20failed:\x20',_0xbddf20);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x173637){return Vr(void 0x0,_0x173637);}function Vr(_0xe12ee5,_0x4340c3){if(!(_0x4340c3 instanceof Object))return _0x4340c3;switch(_0x4340c3['constructor']){case Date:const _0x4b400c=_0x4340c3;return new Date(_0x4b400c['getTime']());case Object:_0xe12ee5===void 0x0&&(_0xe12ee5={});break;case Array:_0xe12ee5=[];break;default:return _0x4340c3;}for(const _0x509896 in _0x4340c3)!_0x4340c3['hasOwnProperty'](_0x509896)||!nc(_0x509896)||(_0xe12ee5[_0x509896]=Vr(_0xe12ee5[_0x509896],_0x4340c3[_0x509896]));return _0xe12ee5;}function nc(_0x272138){return _0x272138!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x204504=As['__FIREBASE_DEFAULTS__'];if(_0x204504)return JSON['parse'](_0x204504);},oc=()=>{if(typeof document>'u')return;let _0x460e59;try{_0x460e59=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x1ef90f=_0x460e59&&cn(_0x460e59[0x1]);return _0x1ef90f&&JSON['parse'](_0x1ef90f);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x50aa86){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x50aa86);return;}},Hr=_0xa358eb=>{var _0x552b5a,_0x24f31c;return(_0x24f31c=(_0x552b5a=Mi())==null?void 0x0:_0x552b5a['emulatorHosts'])==null?void 0x0:_0x24f31c[_0xa358eb];},ac=_0x1bbfa4=>{const _0x1bda53=Hr(_0x1bbfa4);if(!_0x1bda53)return;const _0x18d021=_0x1bda53['lastIndexOf'](':');if(_0x18d021<=0x0||_0x18d021+0x1===_0x1bda53['length'])throw new Error('Invalid\x20host\x20'+_0x1bda53+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x32492e=parseInt(_0x1bda53['substring'](_0x18d021+0x1),0xa);return _0x1bda53[0x0]==='['?[_0x1bda53['substring'](0x1,_0x18d021-0x1),_0x32492e]:[_0x1bda53['substring'](0x0,_0x18d021),_0x32492e];},$r=()=>{var _0x200de5;return(_0x200de5=Mi())==null?void 0x0:_0x200de5['config'];},Gr=_0x483908=>{var _0x2aa9a5;return(_0x2aa9a5=Mi())==null?void 0x0:_0x2aa9a5['_'+_0x483908];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x5634ea,_0x49a6a1)=>{this['resolve']=_0x5634ea,this['reject']=_0x49a6a1;});}['wrapCallback'](_0x41917e){return(_0x2c113e,_0x351e4a)=>{_0x2c113e?this['reject'](_0x2c113e):this['resolve'](_0x351e4a),typeof _0x41917e=='function'&&(this['promise']['catch'](()=>{}),_0x41917e['length']===0x1?_0x41917e(_0x2c113e):_0x41917e(_0x2c113e,_0x351e4a));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x371c23,_0x39e460){if(_0x371c23['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3e719d={'alg':'none','type':'JWT'},_0x14bd5d=_0x39e460||'demo-project',_0x328842=_0x371c23['iat']||0x0,_0x44398b=_0x371c23['sub']||_0x371c23['user_id'];if(!_0x44398b)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1934d6={'iss':'https://securetoken.google.com/'+_0x14bd5d,'aud':_0x14bd5d,'iat':_0x328842,'exp':_0x328842+0xe10,'auth_time':_0x328842,'sub':_0x44398b,'user_id':_0x44398b,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x371c23};return[an(JSON['stringify'](_0x3e719d)),an(JSON['stringify'](_0x1934d6)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x4bb06b=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4bb06b=='object'&&_0x4bb06b['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x16b9ab=W();return _0x16b9ab['indexOf']('MSIE\x20')>=0x0||_0x16b9ab['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x322d8b,_0x5285ca)=>{try{let _0x237721=!0x0;const _0x4e3f1c='validate-browser-context-for-indexeddb-analytics-module',_0x59accc=self['indexedDB']['open'](_0x4e3f1c);_0x59accc['onsuccess']=()=>{_0x59accc['result']['close'](),_0x237721||self['indexedDB']['deleteDatabase'](_0x4e3f1c),_0x322d8b(!0x0);},_0x59accc['onupgradeneeded']=()=>{_0x237721=!0x1;},_0x59accc['onerror']=()=>{var _0x3f331b;_0x5285ca(((_0x3f331b=_0x59accc['error'])==null?void 0x0:_0x3f331b['message'])||'');};}catch(_0xd6b0be){_0x5285ca(_0xd6b0be);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x1df67b,_0x34fcab,_0x3f0ed8){super(_0x34fcab),this['code']=_0x1df67b,this['customData']=_0x3f0ed8,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x4b4a5b,_0x4af83b,_0xcb4971){this['service']=_0x4b4a5b,this['serviceName']=_0x4af83b,this['errors']=_0xcb4971;}['create'](_0x40aa2b,..._0xab8965){const _0x35c0df=_0xab8965[0x0]||{},_0xe935d1=this['service']+'/'+_0x40aa2b,_0x971798=this['errors'][_0x40aa2b],_0x12c5ba=_0x971798?gc(_0x971798,_0x35c0df):'Error',_0x5aff44=this['serviceName']+':\x20'+_0x12c5ba+'\x20('+_0xe935d1+').';return new Se(_0xe935d1,_0x5aff44,_0x35c0df);}}function gc(_0x25bade,_0x1b2310){return _0x25bade['replace'](mc,(_0x15e1d3,_0x5550ec)=>{const _0x12b4c7=_0x1b2310[_0x5550ec];return _0x12b4c7!=null?String(_0x12b4c7):'<'+_0x5550ec+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x414842){return JSON['parse'](_0x414842);}function O(_0x505cf4){return JSON['stringify'](_0x505cf4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x5abcd4){let _0x209b34={},_0x16eac2={},_0xb7d088={},_0x4b01d0='';try{const _0x1b2d40=_0x5abcd4['split']('.');_0x209b34=bt(cn(_0x1b2d40[0x0])||''),_0x16eac2=bt(cn(_0x1b2d40[0x1])||''),_0x4b01d0=_0x1b2d40[0x2],_0xb7d088=_0x16eac2['d']||{},delete _0x16eac2['d'];}catch{}return{'header':_0x209b34,'claims':_0x16eac2,'data':_0xb7d088,'signature':_0x4b01d0};},yc=function(_0x4df0d){const _0x38c028=zr(_0x4df0d),_0x509b61=_0x38c028['claims'];return!!_0x509b61&&typeof _0x509b61=='object'&&_0x509b61['hasOwnProperty']('iat');},vc=function(_0x4ee4e8){const _0x3ea6b2=zr(_0x4ee4e8)['claims'];return typeof _0x3ea6b2=='object'&&_0x3ea6b2['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x58e293,_0x369305){return Object['prototype']['hasOwnProperty']['call'](_0x58e293,_0x369305);}function Oe(_0x25efef,_0x386ff2){if(Object['prototype']['hasOwnProperty']['call'](_0x25efef,_0x386ff2))return _0x25efef[_0x386ff2];}function hi(_0x1299bd){for(const _0x1a86f9 in _0x1299bd)if(Object['prototype']['hasOwnProperty']['call'](_0x1299bd,_0x1a86f9))return!0x1;return!0x0;}function ln(_0x1846fe,_0x4d2774,_0x1dfc91){const _0x576860={};for(const _0x2bc393 in _0x1846fe)Object['prototype']['hasOwnProperty']['call'](_0x1846fe,_0x2bc393)&&(_0x576860[_0x2bc393]=_0x4d2774['call'](_0x1dfc91,_0x1846fe[_0x2bc393],_0x2bc393,_0x1846fe));return _0x576860;}function De(_0x21d8b8,_0x5caba9){if(_0x21d8b8===_0x5caba9)return!0x0;const _0x324bb2=Object['keys'](_0x21d8b8),_0x332e68=Object['keys'](_0x5caba9);for(const _0x4e5bfb of _0x324bb2){if(!_0x332e68['includes'](_0x4e5bfb))return!0x1;const _0x6f8a28=_0x21d8b8[_0x4e5bfb],_0x49a62a=_0x5caba9[_0x4e5bfb];if(ks(_0x6f8a28)&&ks(_0x49a62a)){if(!De(_0x6f8a28,_0x49a62a))return!0x1;}else{if(_0x6f8a28!==_0x49a62a)return!0x1;}}for(const _0xc12d69 of _0x332e68)if(!_0x324bb2['includes'](_0xc12d69))return!0x1;return!0x0;}function ks(_0x307ebd){return _0x307ebd!==null&&typeof _0x307ebd=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x25a9eb){const _0x5dff7d=[];for(const [_0x3e4549,_0x6e0dfc]of Object['entries'](_0x25a9eb))Array['isArray'](_0x6e0dfc)?_0x6e0dfc['forEach'](_0x569b1e=>{_0x5dff7d['push'](encodeURIComponent(_0x3e4549)+'='+encodeURIComponent(_0x569b1e));}):_0x5dff7d['push'](encodeURIComponent(_0x3e4549)+'='+encodeURIComponent(_0x6e0dfc));return _0x5dff7d['length']?'&'+_0x5dff7d['join']('&'):'';}function yt(_0x2cc8de){const _0x1f8a7a={};return _0x2cc8de['replace'](/^\?/,'')['split']('&')['forEach'](_0x119d69=>{if(_0x119d69){const [_0x53a1fb,_0x569a14]=_0x119d69['split']('=');_0x1f8a7a[decodeURIComponent(_0x53a1fb)]=decodeURIComponent(_0x569a14);}}),_0x1f8a7a;}function vt(_0x177a9d){const _0x1b6ede=_0x177a9d['indexOf']('?');if(!_0x1b6ede)return'';const _0x2ccba2=_0x177a9d['indexOf']('#',_0x1b6ede);return _0x177a9d['substring'](_0x1b6ede,_0x2ccba2>0x0?_0x2ccba2:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x1efe76=0x1;_0x1efe76<this['blockSize'];++_0x1efe76)this['pad_'][_0x1efe76]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x10f9cf,_0x294e66){_0x294e66||(_0x294e66=0x0);const _0x3f554b=this['W_'];if(typeof _0x10f9cf=='string'){for(let _0x1b9863=0x0;_0x1b9863<0x10;_0x1b9863++)_0x3f554b[_0x1b9863]=_0x10f9cf['charCodeAt'](_0x294e66)<<0x18|_0x10f9cf['charCodeAt'](_0x294e66+0x1)<<0x10|_0x10f9cf['charCodeAt'](_0x294e66+0x2)<<0x8|_0x10f9cf['charCodeAt'](_0x294e66+0x3),_0x294e66+=0x4;}else{for(let _0x5b302e=0x0;_0x5b302e<0x10;_0x5b302e++)_0x3f554b[_0x5b302e]=_0x10f9cf[_0x294e66]<<0x18|_0x10f9cf[_0x294e66+0x1]<<0x10|_0x10f9cf[_0x294e66+0x2]<<0x8|_0x10f9cf[_0x294e66+0x3],_0x294e66+=0x4;}for(let _0x259681=0x10;_0x259681<0x50;_0x259681++){const _0x2ba3b2=_0x3f554b[_0x259681-0x3]^_0x3f554b[_0x259681-0x8]^_0x3f554b[_0x259681-0xe]^_0x3f554b[_0x259681-0x10];_0x3f554b[_0x259681]=(_0x2ba3b2<<0x1|_0x2ba3b2>>>0x1f)&0xffffffff;}let _0x4f74e8=this['chain_'][0x0],_0xfd9803=this['chain_'][0x1],_0x4bb61f=this['chain_'][0x2],_0x1ec04a=this['chain_'][0x3],_0x249040=this['chain_'][0x4],_0x1acdc3,_0xd2b154;for(let _0x16786b=0x0;_0x16786b<0x50;_0x16786b++){_0x16786b<0x28?_0x16786b<0x14?(_0x1acdc3=_0x1ec04a^_0xfd9803&(_0x4bb61f^_0x1ec04a),_0xd2b154=0x5a827999):(_0x1acdc3=_0xfd9803^_0x4bb61f^_0x1ec04a,_0xd2b154=0x6ed9eba1):_0x16786b<0x3c?(_0x1acdc3=_0xfd9803&_0x4bb61f|_0x1ec04a&(_0xfd9803|_0x4bb61f),_0xd2b154=0x8f1bbcdc):(_0x1acdc3=_0xfd9803^_0x4bb61f^_0x1ec04a,_0xd2b154=0xca62c1d6);const _0x3e75b5=(_0x4f74e8<<0x5|_0x4f74e8>>>0x1b)+_0x1acdc3+_0x249040+_0xd2b154+_0x3f554b[_0x16786b]&0xffffffff;_0x249040=_0x1ec04a,_0x1ec04a=_0x4bb61f,_0x4bb61f=(_0xfd9803<<0x1e|_0xfd9803>>>0x2)&0xffffffff,_0xfd9803=_0x4f74e8,_0x4f74e8=_0x3e75b5;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4f74e8&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xfd9803&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4bb61f&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1ec04a&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x249040&0xffffffff;}['update'](_0x51d030,_0x4d768b){if(_0x51d030==null)return;_0x4d768b===void 0x0&&(_0x4d768b=_0x51d030['length']);const _0x54d930=_0x4d768b-this['blockSize'];let _0x9cca11=0x0;const _0x26e90b=this['buf_'];let _0x167d0c=this['inbuf_'];for(;_0x9cca11<_0x4d768b;){if(_0x167d0c===0x0){for(;_0x9cca11<=_0x54d930;)this['compress_'](_0x51d030,_0x9cca11),_0x9cca11+=this['blockSize'];}if(typeof _0x51d030=='string'){for(;_0x9cca11<_0x4d768b;)if(_0x26e90b[_0x167d0c]=_0x51d030['charCodeAt'](_0x9cca11),++_0x167d0c,++_0x9cca11,_0x167d0c===this['blockSize']){this['compress_'](_0x26e90b),_0x167d0c=0x0;break;}}else{for(;_0x9cca11<_0x4d768b;)if(_0x26e90b[_0x167d0c]=_0x51d030[_0x9cca11],++_0x167d0c,++_0x9cca11,_0x167d0c===this['blockSize']){this['compress_'](_0x26e90b),_0x167d0c=0x0;break;}}}this['inbuf_']=_0x167d0c,this['total_']+=_0x4d768b;}['digest'](){const _0x492e09=[];let _0x53e968=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0xbb5d09=this['blockSize']-0x1;_0xbb5d09>=0x38;_0xbb5d09--)this['buf_'][_0xbb5d09]=_0x53e968&0xff,_0x53e968/=0x100;this['compress_'](this['buf_']);let _0x8fad9=0x0;for(let _0x475209=0x0;_0x475209<0x5;_0x475209++)for(let _0x2f4ebc=0x18;_0x2f4ebc>=0x0;_0x2f4ebc-=0x8)_0x492e09[_0x8fad9]=this['chain_'][_0x475209]>>_0x2f4ebc&0xff,++_0x8fad9;return _0x492e09;}}function Ic(_0x5bc1aa,_0x5f05d2){const _0xa70241=new wc(_0x5bc1aa,_0x5f05d2);return _0xa70241['subscribe']['bind'](_0xa70241);}class wc{constructor(_0x146460,_0x5db0eb){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x5db0eb,this['task']['then'](()=>{_0x146460(this);})['catch'](_0x2468a1=>{this['error'](_0x2468a1);});}['next'](_0x461134){this['forEachObserver'](_0x2efc32=>{_0x2efc32['next'](_0x461134);});}['error'](_0xf56054){this['forEachObserver'](_0x4071e6=>{_0x4071e6['error'](_0xf56054);}),this['close'](_0xf56054);}['complete'](){this['forEachObserver'](_0x23ae16=>{_0x23ae16['complete']();}),this['close']();}['subscribe'](_0x57bb2e,_0x18dd0c,_0x41f47e){let _0x45b7ff;if(_0x57bb2e===void 0x0&&_0x18dd0c===void 0x0&&_0x41f47e===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x57bb2e,['next','error','complete'])?_0x45b7ff=_0x57bb2e:_0x45b7ff={'next':_0x57bb2e,'error':_0x18dd0c,'complete':_0x41f47e},_0x45b7ff['next']===void 0x0&&(_0x45b7ff['next']=Qn),_0x45b7ff['error']===void 0x0&&(_0x45b7ff['error']=Qn),_0x45b7ff['complete']===void 0x0&&(_0x45b7ff['complete']=Qn);const _0x283a25=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x45b7ff['error'](this['finalError']):_0x45b7ff['complete']();}catch{}}),this['observers']['push'](_0x45b7ff),_0x283a25;}['unsubscribeOne'](_0x1ee900){this['observers']===void 0x0||this['observers'][_0x1ee900]===void 0x0||(delete this['observers'][_0x1ee900],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x36c9f1){if(!this['finalized']){for(let _0x42f3a8=0x0;_0x42f3a8<this['observers']['length'];_0x42f3a8++)this['sendOne'](_0x42f3a8,_0x36c9f1);}}['sendOne'](_0x3b9d28,_0x47a9fc){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3b9d28]!==void 0x0)try{_0x47a9fc(this['observers'][_0x3b9d28]);}catch(_0x5284b9){typeof console<'u'&&console['error']&&console['error'](_0x5284b9);}});}['close'](_0x3ec579){this['finalized']||(this['finalized']=!0x0,_0x3ec579!==void 0x0&&(this['finalError']=_0x3ec579),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x346c7f,_0x19911e){if(typeof _0x346c7f!='object'||_0x346c7f===null)return!0x1;for(const _0x4a18ce of _0x19911e)if(_0x4a18ce in _0x346c7f&&typeof _0x346c7f[_0x4a18ce]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x194d19,_0x49f788){return _0x194d19+'\x20failed:\x20'+_0x49f788+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x467829){const _0x32dc5b=[];let _0x3edec6=0x0;for(let _0x22ab5d=0x0;_0x22ab5d<_0x467829['length'];_0x22ab5d++){let _0x48c171=_0x467829['charCodeAt'](_0x22ab5d);if(_0x48c171>=0xd800&&_0x48c171<=0xdbff){const _0x5d8c5c=_0x48c171-0xd800;_0x22ab5d++,f(_0x22ab5d<_0x467829['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x371b93=_0x467829['charCodeAt'](_0x22ab5d)-0xdc00;_0x48c171=0x10000+(_0x5d8c5c<<0xa)+_0x371b93;}_0x48c171<0x80?_0x32dc5b[_0x3edec6++]=_0x48c171:_0x48c171<0x800?(_0x32dc5b[_0x3edec6++]=_0x48c171>>0x6|0xc0,_0x32dc5b[_0x3edec6++]=_0x48c171&0x3f|0x80):_0x48c171<0x10000?(_0x32dc5b[_0x3edec6++]=_0x48c171>>0xc|0xe0,_0x32dc5b[_0x3edec6++]=_0x48c171>>0x6&0x3f|0x80,_0x32dc5b[_0x3edec6++]=_0x48c171&0x3f|0x80):(_0x32dc5b[_0x3edec6++]=_0x48c171>>0x12|0xf0,_0x32dc5b[_0x3edec6++]=_0x48c171>>0xc&0x3f|0x80,_0x32dc5b[_0x3edec6++]=_0x48c171>>0x6&0x3f|0x80,_0x32dc5b[_0x3edec6++]=_0x48c171&0x3f|0x80);}return _0x32dc5b;},Pn=function(_0x1e5979){let _0x43b9d6=0x0;for(let _0x102e1e=0x0;_0x102e1e<_0x1e5979['length'];_0x102e1e++){const _0x717cb=_0x1e5979['charCodeAt'](_0x102e1e);_0x717cb<0x80?_0x43b9d6++:_0x717cb<0x800?_0x43b9d6+=0x2:_0x717cb>=0xd800&&_0x717cb<=0xdbff?(_0x43b9d6+=0x4,_0x102e1e++):_0x43b9d6+=0x3;}return _0x43b9d6;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x4c7576){return _0x4c7576&&_0x4c7576['_delegate']?_0x4c7576['_delegate']:_0x4c7576;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x4db2ea){try{return(_0x4db2ea['startsWith']('http://')||_0x4db2ea['startsWith']('https://')?new URL(_0x4db2ea)['hostname']:_0x4db2ea)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x3d683f){return(await fetch(_0x3d683f,{'credentials':'include'}))['ok'];}class Me{constructor(_0x4ae29f,_0x46db9f,_0x298898){this['name']=_0x4ae29f,this['instanceFactory']=_0x46db9f,this['type']=_0x298898,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x582632){return this['instantiationMode']=_0x582632,this;}['setMultipleInstances'](_0x1eae01){return this['multipleInstances']=_0x1eae01,this;}['setServiceProps'](_0x23487a){return this['serviceProps']=_0x23487a,this;}['setInstanceCreatedCallback'](_0x5e0eb0){return this['onInstanceCreated']=_0x5e0eb0,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x3b5cf5,_0x4cc17d){this['name']=_0x3b5cf5,this['container']=_0x4cc17d,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x4c8c80){const _0xc6defe=this['normalizeInstanceIdentifier'](_0x4c8c80);if(!this['instancesDeferred']['has'](_0xc6defe)){const _0x3f5706=new Ve();if(this['instancesDeferred']['set'](_0xc6defe,_0x3f5706),this['isInitialized'](_0xc6defe)||this['shouldAutoInitialize']())try{const _0x35589e=this['getOrInitializeService']({'instanceIdentifier':_0xc6defe});_0x35589e&&_0x3f5706['resolve'](_0x35589e);}catch{}}return this['instancesDeferred']['get'](_0xc6defe)['promise'];}['getImmediate'](_0x13e4c6){const _0x2b597e=this['normalizeInstanceIdentifier'](_0x13e4c6==null?void 0x0:_0x13e4c6['identifier']),_0x145c4c=(_0x13e4c6==null?void 0x0:_0x13e4c6['optional'])??!0x1;if(this['isInitialized'](_0x2b597e)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2b597e});}catch(_0x400bd4){if(_0x145c4c)return null;throw _0x400bd4;}else{if(_0x145c4c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x34b7fc){if(_0x34b7fc['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x34b7fc['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x34b7fc,!!this['shouldAutoInitialize']()){if(Rc(_0x34b7fc))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x173b3b,_0x43e05f]of this['instancesDeferred']['entries']()){const _0x4b24cf=this['normalizeInstanceIdentifier'](_0x173b3b);try{const _0x16eb33=this['getOrInitializeService']({'instanceIdentifier':_0x4b24cf});_0x43e05f['resolve'](_0x16eb33);}catch{}}}}['clearInstance'](_0xd4f4b1=ke){this['instancesDeferred']['delete'](_0xd4f4b1),this['instancesOptions']['delete'](_0xd4f4b1),this['instances']['delete'](_0xd4f4b1);}async['delete'](){const _0x299e0e=Array['from'](this['instances']['values']());await Promise['all']([..._0x299e0e['filter'](_0x132939=>'INTERNAL'in _0x132939)['map'](_0x455538=>_0x455538['INTERNAL']['delete']()),..._0x299e0e['filter'](_0x3e803d=>'_delete'in _0x3e803d)['map'](_0x14ae41=>_0x14ae41['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1348e1=ke){return this['instances']['has'](_0x1348e1);}['getOptions'](_0x131323=ke){return this['instancesOptions']['get'](_0x131323)||{};}['initialize'](_0x441d3b={}){const {options:_0x48d81b={}}=_0x441d3b,_0x44d5d1=this['normalizeInstanceIdentifier'](_0x441d3b['instanceIdentifier']);if(this['isInitialized'](_0x44d5d1))throw Error(this['name']+'('+_0x44d5d1+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x32f81f=this['getOrInitializeService']({'instanceIdentifier':_0x44d5d1,'options':_0x48d81b});for(const [_0x3083e6,_0xdeca69]of this['instancesDeferred']['entries']()){const _0x51067e=this['normalizeInstanceIdentifier'](_0x3083e6);_0x44d5d1===_0x51067e&&_0xdeca69['resolve'](_0x32f81f);}return _0x32f81f;}['onInit'](_0x8447ac,_0x290a17){const _0x4db795=this['normalizeInstanceIdentifier'](_0x290a17),_0x3ea238=this['onInitCallbacks']['get'](_0x4db795)??new Set();_0x3ea238['add'](_0x8447ac),this['onInitCallbacks']['set'](_0x4db795,_0x3ea238);const _0x548b80=this['instances']['get'](_0x4db795);return _0x548b80&&_0x8447ac(_0x548b80,_0x4db795),()=>{_0x3ea238['delete'](_0x8447ac);};}['invokeOnInitCallbacks'](_0x4c2eca,_0x2c402a){const _0x405c79=this['onInitCallbacks']['get'](_0x2c402a);if(_0x405c79){for(const _0x238ad3 of _0x405c79)try{_0x238ad3(_0x4c2eca,_0x2c402a);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x25e879,options:_0x4cb2f0={}}){let _0x9ab8d9=this['instances']['get'](_0x25e879);if(!_0x9ab8d9&&this['component']&&(_0x9ab8d9=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x25e879),'options':_0x4cb2f0}),this['instances']['set'](_0x25e879,_0x9ab8d9),this['instancesOptions']['set'](_0x25e879,_0x4cb2f0),this['invokeOnInitCallbacks'](_0x9ab8d9,_0x25e879),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x25e879,_0x9ab8d9);}catch{}return _0x9ab8d9||null;}['normalizeInstanceIdentifier'](_0x16a3d9=ke){return this['component']?this['component']['multipleInstances']?_0x16a3d9:ke:_0x16a3d9;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x3be4f0){return _0x3be4f0===ke?void 0x0:_0x3be4f0;}function Rc(_0x40edf7){return _0x40edf7['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x47cc3e){this['name']=_0x47cc3e,this['providers']=new Map();}['addComponent'](_0x230a1e){const _0x5eeb56=this['getProvider'](_0x230a1e['name']);if(_0x5eeb56['isComponentSet']())throw new Error('Component\x20'+_0x230a1e['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5eeb56['setComponent'](_0x230a1e);}['addOrOverwriteComponent'](_0x563810){this['getProvider'](_0x563810['name'])['isComponentSet']()&&this['providers']['delete'](_0x563810['name']),this['addComponent'](_0x563810);}['getProvider'](_0xc4c37){if(this['providers']['has'](_0xc4c37))return this['providers']['get'](_0xc4c37);const _0x49a72d=new Sc(_0xc4c37,this);return this['providers']['set'](_0xc4c37,_0x49a72d),_0x49a72d;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x15c5fe){_0x15c5fe[_0x15c5fe['DEBUG']=0x0]='DEBUG',_0x15c5fe[_0x15c5fe['VERBOSE']=0x1]='VERBOSE',_0x15c5fe[_0x15c5fe['INFO']=0x2]='INFO',_0x15c5fe[_0x15c5fe['WARN']=0x3]='WARN',_0x15c5fe[_0x15c5fe['ERROR']=0x4]='ERROR',_0x15c5fe[_0x15c5fe['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x57f413,_0x2f4faa,..._0x86b42c)=>{if(_0x2f4faa<_0x57f413['logLevel'])return;const _0xc67351=new Date()['toISOString'](),_0x22ef6f=Pc[_0x2f4faa];if(_0x22ef6f)console[_0x22ef6f]('['+_0xc67351+']\x20\x20'+_0x57f413['name']+':',..._0x86b42c);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2f4faa+')');};class xi{constructor(_0x58e13d){this['name']=_0x58e13d,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5d2f72){if(!(_0x5d2f72 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5d2f72+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5d2f72;}['setLogLevel'](_0x11acea){this['_logLevel']=typeof _0x11acea=='string'?kc[_0x11acea]:_0x11acea;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x224043){if(typeof _0x224043!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x224043;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x472d80){this['_userLogHandler']=_0x472d80;}['debug'](..._0x1c63bd){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1c63bd),this['_logHandler'](this,T['DEBUG'],..._0x1c63bd);}['log'](..._0x3900c6){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x3900c6),this['_logHandler'](this,T['VERBOSE'],..._0x3900c6);}['info'](..._0x16dc92){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x16dc92),this['_logHandler'](this,T['INFO'],..._0x16dc92);}['warn'](..._0x2a71b5){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2a71b5),this['_logHandler'](this,T['WARN'],..._0x2a71b5);}['error'](..._0x7af7b9){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x7af7b9),this['_logHandler'](this,T['ERROR'],..._0x7af7b9);}}const Dc=(_0x36c8f5,_0x19d7dc)=>_0x19d7dc['some'](_0x3c7054=>_0x36c8f5 instanceof _0x3c7054);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x427879){const _0x2c7d2b=new Promise((_0xa48933,_0x3a99cb)=>{const _0x350745=()=>{_0x427879['removeEventListener']('success',_0x1a37b5),_0x427879['removeEventListener']('error',_0x32a243);},_0x1a37b5=()=>{_0xa48933(_e(_0x427879['result'])),_0x350745();},_0x32a243=()=>{_0x3a99cb(_0x427879['error']),_0x350745();};_0x427879['addEventListener']('success',_0x1a37b5),_0x427879['addEventListener']('error',_0x32a243);});return _0x2c7d2b['then'](_0x1030de=>{_0x1030de instanceof IDBCursor&&Kr['set'](_0x1030de,_0x427879);})['catch'](()=>{}),Fi['set'](_0x2c7d2b,_0x427879),_0x2c7d2b;}function Fc(_0x4f9474){if(ui['has'](_0x4f9474))return;const _0x2c58a2=new Promise((_0x4aed55,_0x215e8b)=>{const _0x23de65=()=>{_0x4f9474['removeEventListener']('complete',_0x397176),_0x4f9474['removeEventListener']('error',_0x194a5c),_0x4f9474['removeEventListener']('abort',_0x194a5c);},_0x397176=()=>{_0x4aed55(),_0x23de65();},_0x194a5c=()=>{_0x215e8b(_0x4f9474['error']||new DOMException('AbortError','AbortError')),_0x23de65();};_0x4f9474['addEventListener']('complete',_0x397176),_0x4f9474['addEventListener']('error',_0x194a5c),_0x4f9474['addEventListener']('abort',_0x194a5c);});ui['set'](_0x4f9474,_0x2c58a2);}let di={'get'(_0x492ce1,_0x4240b9,_0x3a6e26){if(_0x492ce1 instanceof IDBTransaction){if(_0x4240b9==='done')return ui['get'](_0x492ce1);if(_0x4240b9==='objectStoreNames')return _0x492ce1['objectStoreNames']||Yr['get'](_0x492ce1);if(_0x4240b9==='store')return _0x3a6e26['objectStoreNames'][0x1]?void 0x0:_0x3a6e26['objectStore'](_0x3a6e26['objectStoreNames'][0x0]);}return _e(_0x492ce1[_0x4240b9]);},'set'(_0xb31ebf,_0x112e22,_0x172910){return _0xb31ebf[_0x112e22]=_0x172910,!0x0;},'has'(_0x5dc633,_0x1dcf9a){return _0x5dc633 instanceof IDBTransaction&&(_0x1dcf9a==='done'||_0x1dcf9a==='store')?!0x0:_0x1dcf9a in _0x5dc633;}};function Uc(_0xcaa077){di=_0xcaa077(di);}function Wc(_0x347f89){return _0x347f89===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x117c39,..._0x42610c){const _0x3d4b21=_0x347f89['call'](Xn(this),_0x117c39,..._0x42610c);return Yr['set'](_0x3d4b21,_0x117c39['sort']?_0x117c39['sort']():[_0x117c39]),_e(_0x3d4b21);}:Lc()['includes'](_0x347f89)?function(..._0x5d36d4){return _0x347f89['apply'](Xn(this),_0x5d36d4),_e(Kr['get'](this));}:function(..._0xc4b0e1){return _e(_0x347f89['apply'](Xn(this),_0xc4b0e1));};}function Bc(_0x5e6e71){return typeof _0x5e6e71=='function'?Wc(_0x5e6e71):(_0x5e6e71 instanceof IDBTransaction&&Fc(_0x5e6e71),Dc(_0x5e6e71,Mc())?new Proxy(_0x5e6e71,di):_0x5e6e71);}function _e(_0x223ca2){if(_0x223ca2 instanceof IDBRequest)return xc(_0x223ca2);if(Jn['has'](_0x223ca2))return Jn['get'](_0x223ca2);const _0x2227d3=Bc(_0x223ca2);return _0x2227d3!==_0x223ca2&&(Jn['set'](_0x223ca2,_0x2227d3),Fi['set'](_0x2227d3,_0x223ca2)),_0x2227d3;}const Xn=_0x27c764=>Fi['get'](_0x27c764);function Vc(_0x3c1639,_0x52b26a,{blocked:_0x499bf5,upgrade:_0xccc05f,blocking:_0x149912,terminated:_0x34e82e}={}){const _0x4b3f01=indexedDB['open'](_0x3c1639,_0x52b26a),_0x58e0d6=_e(_0x4b3f01);return _0xccc05f&&_0x4b3f01['addEventListener']('upgradeneeded',_0x3715e8=>{_0xccc05f(_e(_0x4b3f01['result']),_0x3715e8['oldVersion'],_0x3715e8['newVersion'],_e(_0x4b3f01['transaction']),_0x3715e8);}),_0x499bf5&&_0x4b3f01['addEventListener']('blocked',_0x2d5213=>_0x499bf5(_0x2d5213['oldVersion'],_0x2d5213['newVersion'],_0x2d5213)),_0x58e0d6['then'](_0x13786b=>{_0x34e82e&&_0x13786b['addEventListener']('close',()=>_0x34e82e()),_0x149912&&_0x13786b['addEventListener']('versionchange',_0x879c76=>_0x149912(_0x879c76['oldVersion'],_0x879c76['newVersion'],_0x879c76));})['catch'](()=>{}),_0x58e0d6;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x1d30d8,_0x594168){if(!(_0x1d30d8 instanceof IDBDatabase&&!(_0x594168 in _0x1d30d8)&&typeof _0x594168=='string'))return;if(Zn['get'](_0x594168))return Zn['get'](_0x594168);const _0x10773b=_0x594168['replace'](/FromIndex$/,''),_0xf02668=_0x594168!==_0x10773b,_0x4ed6a4=$c['includes'](_0x10773b);if(!(_0x10773b in(_0xf02668?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4ed6a4||Hc['includes'](_0x10773b)))return;const _0x31ca9c=async function(_0xc635c6,..._0x40a93b){const _0x10d415=this['transaction'](_0xc635c6,_0x4ed6a4?'readwrite':'readonly');let _0x2a5684=_0x10d415['store'];return _0xf02668&&(_0x2a5684=_0x2a5684['index'](_0x40a93b['shift']())),(await Promise['all']([_0x2a5684[_0x10773b](..._0x40a93b),_0x4ed6a4&&_0x10d415['done']]))[0x0];};return Zn['set'](_0x594168,_0x31ca9c),_0x31ca9c;}Uc(_0x565926=>({..._0x565926,'get':(_0x56a003,_0x153719,_0x212354)=>Os(_0x56a003,_0x153719)||_0x565926['get'](_0x56a003,_0x153719,_0x212354),'has':(_0xfe4ff8,_0x5a437b)=>!!Os(_0xfe4ff8,_0x5a437b)||_0x565926['has'](_0xfe4ff8,_0x5a437b)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x383db1){this['container']=_0x383db1;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xe941f4=>{if(qc(_0xe941f4)){const _0x2dbe93=_0xe941f4['getImmediate']();return _0x2dbe93['library']+'/'+_0x2dbe93['version'];}else return null;})['filter'](_0x55023e=>_0x55023e)['join']('\x20');}}function qc(_0x85a982){const _0x13c760=_0x85a982['getComponent']();return(_0x13c760==null?void 0x0:_0x13c760['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x3f67ae,_0x31fe3c){try{_0x3f67ae['container']['addComponent'](_0x31fe3c);}catch(_0x2e04fa){re['debug']('Component\x20'+_0x31fe3c['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3f67ae['name'],_0x2e04fa);}}function et(_0x2de92b){const _0xd54118=_0x2de92b['name'];if(gi['has'](_0xd54118))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0xd54118+'.'),!0x1;gi['set'](_0xd54118,_0x2de92b);for(const _0x18e503 of Le['values']())Ms(_0x18e503,_0x2de92b);for(const _0xcf1079 of _i['values']())Ms(_0xcf1079,_0x2de92b);return!0x0;}function Ui(_0x49323a,_0x55cffc){const _0xbef556=_0x49323a['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xbef556&&_0xbef556['triggerHeartbeat'](),_0x49323a['container']['getProvider'](_0x55cffc);}function H(_0x526d64){return _0x526d64==null?!0x1:_0x526d64['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x498997,_0x300f43,_0x343a8b){this['_isDeleted']=!0x1,this['_options']={..._0x498997},this['_config']={..._0x300f43},this['_name']=_0x300f43['name'],this['_automaticDataCollectionEnabled']=_0x300f43['automaticDataCollectionEnabled'],this['_container']=_0x343a8b,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x1fb37e){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x1fb37e;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x1bf408){this['_isDeleted']=_0x1bf408;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x4c8148,_0x2854cb={}){let _0x3c979b=_0x4c8148;typeof _0x2854cb!='object'&&(_0x2854cb={'name':_0x2854cb});const _0x27c6c6={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x2854cb},_0x1630ab=_0x27c6c6['name'];if(typeof _0x1630ab!='string'||!_0x1630ab)throw ge['create']('bad-app-name',{'appName':String(_0x1630ab)});if(_0x3c979b||(_0x3c979b=$r()),!_0x3c979b)throw ge['create']('no-options');const _0x24d4f3=Le['get'](_0x1630ab);if(_0x24d4f3){if(De(_0x3c979b,_0x24d4f3['options'])&&De(_0x27c6c6,_0x24d4f3['config']))return _0x24d4f3;throw ge['create']('duplicate-app',{'appName':_0x1630ab});}const _0x47fee4=new Ac(_0x1630ab);for(const _0x165555 of gi['values']())_0x47fee4['addComponent'](_0x165555);const _0x43b0e6=new Il(_0x3c979b,_0x27c6c6,_0x47fee4);return Le['set'](_0x1630ab,_0x43b0e6),_0x43b0e6;}function Qr(_0x432f22=pi){const _0x10102a=Le['get'](_0x432f22);if(!_0x10102a&&_0x432f22===pi&&$r())return wl();if(!_0x10102a)throw ge['create']('no-app',{'appName':_0x432f22});return _0x10102a;}function l_(){return Array['from'](Le['values']());}async function h_(_0x48e61d){let _0x652d9a=!0x1;const _0x36494f=_0x48e61d['name'];Le['has'](_0x36494f)?(_0x652d9a=!0x0,Le['delete'](_0x36494f)):_i['has'](_0x36494f)&&_0x48e61d['decRefCount']()<=0x0&&(_i['delete'](_0x36494f),_0x652d9a=!0x0),_0x652d9a&&(await Promise['all'](_0x48e61d['container']['getProviders']()['map'](_0x3f3967=>_0x3f3967['delete']())),_0x48e61d['isDeleted']=!0x0);}function me(_0x3bddf2,_0x2cc79e,_0x957663){let _0x133e06=vl[_0x3bddf2]??_0x3bddf2;_0x957663&&(_0x133e06+='-'+_0x957663);const _0x2b6f4c=_0x133e06['match'](/\s|\//),_0x1ccf27=_0x2cc79e['match'](/\s|\//);if(_0x2b6f4c||_0x1ccf27){const _0x19ee2e=['Unable\x20to\x20register\x20library\x20\x22'+_0x133e06+'\x22\x20with\x20version\x20\x22'+_0x2cc79e+'\x22:'];_0x2b6f4c&&_0x19ee2e['push']('library\x20name\x20\x22'+_0x133e06+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2b6f4c&&_0x1ccf27&&_0x19ee2e['push']('and'),_0x1ccf27&&_0x19ee2e['push']('version\x20name\x20\x22'+_0x2cc79e+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x19ee2e['join']('\x20'));return;}et(new Me(_0x133e06+'-version',()=>({'library':_0x133e06,'version':_0x2cc79e}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x149396,_0x30612b)=>{switch(_0x30612b){case 0x0:try{_0x149396['createObjectStore'](Rt);}catch(_0x44ac95){console['warn'](_0x44ac95);}}}})['catch'](_0x48f471=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x48f471['message']});})),ei;}async function Sl(_0x41053b){try{const _0x1db9f1=(await Jr())['transaction'](Rt),_0x2452af=await _0x1db9f1['objectStore'](Rt)['get'](Xr(_0x41053b));return await _0x1db9f1['done'],_0x2452af;}catch(_0x3a58dc){if(_0x3a58dc instanceof Se)re['warn'](_0x3a58dc['message']);else{const _0x2afb8b=ge['create']('idb-get',{'originalErrorMessage':_0x3a58dc==null?void 0x0:_0x3a58dc['message']});re['warn'](_0x2afb8b['message']);}}}async function Ls(_0x1925ca,_0x3045a5){try{const _0x509534=(await Jr())['transaction'](Rt,'readwrite');await _0x509534['objectStore'](Rt)['put'](_0x3045a5,Xr(_0x1925ca)),await _0x509534['done'];}catch(_0x208ef8){if(_0x208ef8 instanceof Se)re['warn'](_0x208ef8['message']);else{const _0x15f6f0=ge['create']('idb-set',{'originalErrorMessage':_0x208ef8==null?void 0x0:_0x208ef8['message']});re['warn'](_0x15f6f0['message']);}}}function Xr(_0x1a3483){return _0x1a3483['name']+'!'+_0x1a3483['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x839730){this['container']=_0x839730,this['_heartbeatsCache']=null;const _0x141589=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x141589),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0xff63ad=>(this['_heartbeatsCache']=_0xff63ad,_0xff63ad));}async['triggerHeartbeat'](){var _0x305551,_0x1ba0fd;try{const _0x267a63=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x222515=xs();if(((_0x305551=this['_heartbeatsCache'])==null?void 0x0:_0x305551['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x1ba0fd=this['_heartbeatsCache'])==null?void 0x0:_0x1ba0fd['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x222515||this['_heartbeatsCache']['heartbeats']['some'](_0x41f0e4=>_0x41f0e4['date']===_0x222515))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x222515,'agent':_0x267a63}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x18ce32=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x18ce32,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x37a4d1){re['warn'](_0x37a4d1);}}async['getHeartbeatsHeader'](){var _0x171961;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x171961=this['_heartbeatsCache'])==null?void 0x0:_0x171961['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4c0e07=xs(),{heartbeatsToSend:_0x259321,unsentEntries:_0x5b2d87}=kl(this['_heartbeatsCache']['heartbeats']),_0xfc4eb0=an(JSON['stringify']({'version':0x2,'heartbeats':_0x259321}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4c0e07,_0x5b2d87['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x5b2d87,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xfc4eb0;}catch(_0x4c6f81){return re['warn'](_0x4c6f81),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x1e5728,_0x26fff1=bl){const _0x2f7cc4=[];let _0x452248=_0x1e5728['slice']();for(const _0x33b9a5 of _0x1e5728){const _0x39c44e=_0x2f7cc4['find'](_0x9735ac=>_0x9735ac['agent']===_0x33b9a5['agent']);if(_0x39c44e){if(_0x39c44e['dates']['push'](_0x33b9a5['date']),Fs(_0x2f7cc4)>_0x26fff1){_0x39c44e['dates']['pop']();break;}}else{if(_0x2f7cc4['push']({'agent':_0x33b9a5['agent'],'dates':[_0x33b9a5['date']]}),Fs(_0x2f7cc4)>_0x26fff1){_0x2f7cc4['pop']();break;}}_0x452248=_0x452248['slice'](0x1);}return{'heartbeatsToSend':_0x2f7cc4,'unsentEntries':_0x452248};}class Nl{constructor(_0x280456){this['app']=_0x280456,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4ac105=await Sl(this['app']);return _0x4ac105!=null&&_0x4ac105['heartbeats']?_0x4ac105:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5740a3){if(await this['_canUseIndexedDBPromise']){const _0x117005=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x5740a3['lastSentHeartbeatDate']??_0x117005['lastSentHeartbeatDate'],'heartbeats':_0x5740a3['heartbeats']});}else return;}async['add'](_0xade55d){if(await this['_canUseIndexedDBPromise']){const _0x3507c6=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0xade55d['lastSentHeartbeatDate']??_0x3507c6['lastSentHeartbeatDate'],'heartbeats':[..._0x3507c6['heartbeats'],..._0xade55d['heartbeats']]});}else return;}}function Fs(_0x112188){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x112188}))['length'];}function Pl(_0x232998){if(_0x232998['length']===0x0)return-0x1;let _0x4c9fe8=0x0,_0xdb7a59=_0x232998[0x0]['date'];for(let _0x2bb2a2=0x1;_0x2bb2a2<_0x232998['length'];_0x2bb2a2++)_0x232998[_0x2bb2a2]['date']<_0xdb7a59&&(_0xdb7a59=_0x232998[_0x2bb2a2]['date'],_0x4c9fe8=_0x2bb2a2);return _0x4c9fe8;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x1dcf8a){et(new Me('platform-logger',_0x2eff2e=>new Gc(_0x2eff2e),'PRIVATE')),et(new Me('heartbeat',_0x80528c=>new Al(_0x80528c),'PRIVATE')),me(fi,Ds,_0x1dcf8a),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0xae5390){Zr=_0xae5390;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x12de4c){this['domStorage_']=_0x12de4c,this['prefix_']='firebase:';}['set'](_0x2bb4f0,_0x51db9f){_0x51db9f==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x2bb4f0)):this['domStorage_']['setItem'](this['prefixedName_'](_0x2bb4f0),O(_0x51db9f));}['get'](_0x5a94f6){const _0x560ce2=this['domStorage_']['getItem'](this['prefixedName_'](_0x5a94f6));return _0x560ce2==null?null:bt(_0x560ce2);}['remove'](_0xf600b0){this['domStorage_']['removeItem'](this['prefixedName_'](_0xf600b0));}['prefixedName_'](_0x3e70af){return this['prefix_']+_0x3e70af;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x45122e,_0x4179b7){_0x4179b7==null?delete this['cache_'][_0x45122e]:this['cache_'][_0x45122e]=_0x4179b7;}['get'](_0x5a2904){return Y(this['cache_'],_0x5a2904)?this['cache_'][_0x5a2904]:null;}['remove'](_0x1a375f){delete this['cache_'][_0x1a375f];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x515eaf){try{if(typeof window<'u'&&typeof window[_0x515eaf]<'u'){const _0x3841c0=window[_0x515eaf];return _0x3841c0['setItem']('firebase:sentinel','cache'),_0x3841c0['removeItem']('firebase:sentinel'),new xl(_0x3841c0);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x5b1cb0=0x1;return function(){return _0x5b1cb0++;};}()),no=function(_0x524fe3){const _0x53cfc6=Tc(_0x524fe3),_0x18471e=new Ec();_0x18471e['update'](_0x53cfc6);const _0x1e4c8e=_0x18471e['digest']();return Di['encodeByteArray'](_0x1e4c8e);},Bt=function(..._0x4efe10){let _0x5de26e='';for(let _0xa0b619=0x0;_0xa0b619<_0x4efe10['length'];_0xa0b619++){const _0xffc706=_0x4efe10[_0xa0b619];Array['isArray'](_0xffc706)||_0xffc706&&typeof _0xffc706=='object'&&typeof _0xffc706['length']=='number'?_0x5de26e+=Bt['apply'](null,_0xffc706):typeof _0xffc706=='object'?_0x5de26e+=O(_0xffc706):_0x5de26e+=_0xffc706,_0x5de26e+='\x20';}return _0x5de26e;};let Et=null,Vs=!0x0;const Wl=function(_0x4ecd4c,_0x256c51){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x3c8483){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x4391e2=Bt['apply'](null,_0x3c8483);Et(_0x4391e2);}},Vt=function(_0x1c55cb){return function(..._0x504036){L(_0x1c55cb,..._0x504036);};},mi=function(..._0x191b79){const _0x16a885='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x191b79);Qe['error'](_0x16a885);},oe=function(..._0x4781c1){const _0x133436='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x4781c1);throw Qe['error'](_0x133436),new Error(_0x133436);},U=function(..._0x5b2c53){const _0xf4b9f2='FIREBASE\x20WARNING:\x20'+Bt(..._0x5b2c53);Qe['warn'](_0xf4b9f2);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x44efdf){return typeof _0x44efdf=='number'&&(_0x44efdf!==_0x44efdf||_0x44efdf===Number['POSITIVE_INFINITY']||_0x44efdf===Number['NEGATIVE_INFINITY']);},Vl=function(_0x5c9db7){if(document['readyState']==='complete')_0x5c9db7();else{let _0xceadd2=!0x1;const _0xebcf5c=function(){if(!document['body']){setTimeout(_0xebcf5c,Math['floor'](0xa));return;}_0xceadd2||(_0xceadd2=!0x0,_0x5c9db7());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0xebcf5c,!0x1),window['addEventListener']('load',_0xebcf5c,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0xebcf5c();}),window['attachEvent']('onload',_0xebcf5c));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x34ae5d,_0x32c757){if(_0x34ae5d===_0x32c757)return 0x0;if(_0x34ae5d===xe||_0x32c757===Ie)return-0x1;if(_0x32c757===xe||_0x34ae5d===Ie)return 0x1;{const _0x5d4e0e=Hs(_0x34ae5d),_0x1be58d=Hs(_0x32c757);return _0x5d4e0e!==null?_0x1be58d!==null?_0x5d4e0e-_0x1be58d===0x0?_0x34ae5d['length']-_0x32c757['length']:_0x5d4e0e-_0x1be58d:-0x1:_0x1be58d!==null?0x1:_0x34ae5d<_0x32c757?-0x1:0x1;}},Hl=function(_0xdbc3b,_0xfe5cd9){return _0xdbc3b===_0xfe5cd9?0x0:_0xdbc3b<_0xfe5cd9?-0x1:0x1;},pt=function(_0x5516c8,_0x30de2f){if(_0x30de2f&&_0x5516c8 in _0x30de2f)return _0x30de2f[_0x5516c8];throw new Error('Missing\x20required\x20key\x20('+_0x5516c8+')\x20in\x20object:\x20'+O(_0x30de2f));},Bi=function(_0x756609){if(typeof _0x756609!='object'||_0x756609===null)return O(_0x756609);const _0x59188d=[];for(const _0x579835 in _0x756609)_0x59188d['push'](_0x579835);_0x59188d['sort']();let _0x9e02eb='{';for(let _0x59be72=0x0;_0x59be72<_0x59188d['length'];_0x59be72++)_0x59be72!==0x0&&(_0x9e02eb+=','),_0x9e02eb+=O(_0x59188d[_0x59be72]),_0x9e02eb+=':',_0x9e02eb+=Bi(_0x756609[_0x59188d[_0x59be72]]);return _0x9e02eb+='}',_0x9e02eb;},io=function(_0xba0026,_0x4c5131){const _0x2239ef=_0xba0026['length'];if(_0x2239ef<=_0x4c5131)return[_0xba0026];const _0x40bd08=[];for(let _0x14dd2b=0x0;_0x14dd2b<_0x2239ef;_0x14dd2b+=_0x4c5131)_0x14dd2b+_0x4c5131>_0x2239ef?_0x40bd08['push'](_0xba0026['substring'](_0x14dd2b,_0x2239ef)):_0x40bd08['push'](_0xba0026['substring'](_0x14dd2b,_0x14dd2b+_0x4c5131));return _0x40bd08;};function x(_0x270bb1,_0x59238f){for(const _0x4b2718 in _0x270bb1)_0x270bb1['hasOwnProperty'](_0x4b2718)&&_0x59238f(_0x4b2718,_0x270bb1[_0x4b2718]);}const so=function(_0x108774){f(!Wi(_0x108774),'Invalid\x20JSON\x20number');const _0x3140ab=0xb,_0x319296=0x34,_0x52577f=(0x1<<_0x3140ab-0x1)-0x1;let _0x3f5ed1,_0x5314bd,_0x384955,_0x56968b,_0x43b234;_0x108774===0x0?(_0x5314bd=0x0,_0x384955=0x0,_0x3f5ed1=0x1/_0x108774===-0x1/0x0?0x1:0x0):(_0x3f5ed1=_0x108774<0x0,_0x108774=Math['abs'](_0x108774),_0x108774>=Math['pow'](0x2,0x1-_0x52577f)?(_0x56968b=Math['min'](Math['floor'](Math['log'](_0x108774)/Math['LN2']),_0x52577f),_0x5314bd=_0x56968b+_0x52577f,_0x384955=Math['round'](_0x108774*Math['pow'](0x2,_0x319296-_0x56968b)-Math['pow'](0x2,_0x319296))):(_0x5314bd=0x0,_0x384955=Math['round'](_0x108774/Math['pow'](0x2,0x1-_0x52577f-_0x319296))));const _0x1890b7=[];for(_0x43b234=_0x319296;_0x43b234;_0x43b234-=0x1)_0x1890b7['push'](_0x384955%0x2?0x1:0x0),_0x384955=Math['floor'](_0x384955/0x2);for(_0x43b234=_0x3140ab;_0x43b234;_0x43b234-=0x1)_0x1890b7['push'](_0x5314bd%0x2?0x1:0x0),_0x5314bd=Math['floor'](_0x5314bd/0x2);_0x1890b7['push'](_0x3f5ed1?0x1:0x0),_0x1890b7['reverse']();const _0x35e239=_0x1890b7['join']('');let _0x3ca8df='';for(_0x43b234=0x0;_0x43b234<0x40;_0x43b234+=0x8){let _0x548506=parseInt(_0x35e239['substr'](_0x43b234,0x8),0x2)['toString'](0x10);_0x548506['length']===0x1&&(_0x548506='0'+_0x548506),_0x3ca8df=_0x3ca8df+_0x548506;}return _0x3ca8df['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x2d7ab3,_0xfc2846){let _0x22fffd='Unknown\x20Error';_0x2d7ab3==='too_big'?_0x22fffd='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2d7ab3==='permission_denied'?_0x22fffd='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2d7ab3==='unavailable'&&(_0x22fffd='The\x20service\x20is\x20unavailable');const _0xd4edb6=new Error(_0x2d7ab3+'\x20at\x20'+_0xfc2846['_path']['toString']()+':\x20'+_0x22fffd);return _0xd4edb6['code']=_0x2d7ab3['toUpperCase'](),_0xd4edb6;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x59e3f8){if(zl['test'](_0x59e3f8)){const _0x4aa4d7=Number(_0x59e3f8);if(_0x4aa4d7>=jl&&_0x4aa4d7<=Kl)return _0x4aa4d7;}return null;},lt=function(_0x4852b8){try{_0x4852b8();}catch(_0x5ced5e){setTimeout(()=>{const _0x317c75=_0x5ced5e['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x317c75),_0x5ced5e;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x4a162c,_0x50a219){const _0x209ddc=setTimeout(_0x4a162c,_0x50a219);return typeof _0x209ddc=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x209ddc):typeof _0x209ddc=='object'&&_0x209ddc['unref']&&_0x209ddc['unref'](),_0x209ddc;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x1f81f3,_0x1245b9){this['appCheckProvider']=_0x1245b9,this['appName']=_0x1f81f3['name'],H(_0x1f81f3)&&_0x1f81f3['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x1f81f3['settings']['appCheckToken']),this['appCheck']=_0x1245b9==null?void 0x0:_0x1245b9['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1245b9==null||_0x1245b9['get']()['then'](_0x395b95=>this['appCheck']=_0x395b95);}['getToken'](_0x9d8d01){if(this['serverAppAppCheckToken']){if(_0x9d8d01)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x9d8d01):new Promise((_0x1b4faa,_0x3e0153)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x9d8d01)['then'](_0x1b4faa,_0x3e0153):_0x1b4faa(null);},0x0);});}['addTokenChangeListener'](_0x48f0dd){var _0x1eb80f;(_0x1eb80f=this['appCheckProvider'])==null||_0x1eb80f['get']()['then'](_0x279c0b=>_0x279c0b['addTokenListener'](_0x48f0dd));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x1085fe,_0x2eb3af,_0x49612d){this['appName_']=_0x1085fe,this['firebaseOptions_']=_0x2eb3af,this['authProvider_']=_0x49612d,this['auth_']=null,this['auth_']=_0x49612d['getImmediate']({'optional':!0x0}),this['auth_']||_0x49612d['onInit'](_0x4c3a0e=>this['auth_']=_0x4c3a0e);}['getToken'](_0xac2b79){return this['auth_']?this['auth_']['getToken'](_0xac2b79)['catch'](_0x7de528=>_0x7de528&&_0x7de528['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x7de528)):new Promise((_0x1cb402,_0x506b05)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0xac2b79)['then'](_0x1cb402,_0x506b05):_0x1cb402(null);},0x0);});}['addTokenChangeListener'](_0x466117){this['auth_']?this['auth_']['addAuthTokenListener'](_0x466117):this['authProvider_']['get']()['then'](_0xf3d20e=>_0xf3d20e['addAuthTokenListener'](_0x466117));}['removeTokenChangeListener'](_0x5c25d6){this['authProvider_']['get']()['then'](_0x5a203f=>_0x5a203f['removeAuthTokenListener'](_0x5c25d6));}['notifyForInvalidToken'](){let _0x25b544='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x25b544+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x25b544+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x25b544+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x25b544);}}class tn{constructor(_0x1f12e1){this['accessToken']=_0x1f12e1;}['getToken'](_0xceaa2a){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x6005d6){_0x6005d6(this['accessToken']);}['removeTokenChangeListener'](_0xa84c43){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x1ae7f3,_0x2377b3,_0x30ff22,_0x15e715,_0xf0f4f5=!0x1,_0x4cd192='',_0x576505=!0x1,_0x414f67=!0x1,_0x48144f=null){this['secure']=_0x2377b3,this['namespace']=_0x30ff22,this['webSocketOnly']=_0x15e715,this['nodeAdmin']=_0xf0f4f5,this['persistenceKey']=_0x4cd192,this['includeNamespaceInQueryParams']=_0x576505,this['isUsingEmulator']=_0x414f67,this['emulatorOptions']=_0x48144f,this['_host']=_0x1ae7f3['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x1ae7f3)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4317ff){_0x4317ff!==this['internalHost']&&(this['internalHost']=_0x4317ff,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x10ae0b=this['toURLString']();return this['persistenceKey']&&(_0x10ae0b+='<'+this['persistenceKey']+'>'),_0x10ae0b;}['toURLString'](){const _0x5265dd=this['secure']?'https://':'http://',_0x4ebacb=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5265dd+this['host']+'/'+_0x4ebacb;}}function Xl(_0x428b46){return _0x428b46['host']!==_0x428b46['internalHost']||_0x428b46['isCustomHost']()||_0x428b46['includeNamespaceInQueryParams'];}function go(_0x441398,_0x18bec7,_0x53477b){f(typeof _0x18bec7=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x53477b=='object','typeof\x20params\x20must\x20==\x20object');let _0x386152;if(_0x18bec7===fo)_0x386152=(_0x441398['secure']?'wss://':'ws://')+_0x441398['internalHost']+'/.ws?';else{if(_0x18bec7===po)_0x386152=(_0x441398['secure']?'https://':'http://')+_0x441398['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x18bec7);}Xl(_0x441398)&&(_0x53477b['ns']=_0x441398['namespace']);const _0x1f8e19=[];return x(_0x53477b,(_0x5de1af,_0x4ed02f)=>{_0x1f8e19['push'](_0x5de1af+'='+_0x4ed02f);}),_0x386152+_0x1f8e19['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x46f600,_0x130d9e=0x1){Y(this['counters_'],_0x46f600)||(this['counters_'][_0x46f600]=0x0),this['counters_'][_0x46f600]+=_0x130d9e;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0xe46283){const _0x178b5a=_0xe46283['toString']();return ti[_0x178b5a]||(ti[_0x178b5a]=new Zl()),ti[_0x178b5a];}function eh(_0x4c39b6,_0x4587ee){const _0x10d698=_0x4c39b6['toString']();return ni[_0x10d698]||(ni[_0x10d698]=_0x4587ee()),ni[_0x10d698];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x4c7b63){this['onMessage_']=_0x4c7b63,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3fff57,_0x25450c){this['closeAfterResponse']=_0x3fff57,this['onClose']=_0x25450c,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x421019,_0x2d8d9c){for(this['pendingResponses'][_0x421019]=_0x2d8d9c;this['pendingResponses'][this['currentResponseNum']];){const _0x56f491=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3ca1c1=0x0;_0x3ca1c1<_0x56f491['length'];++_0x3ca1c1)_0x56f491[_0x3ca1c1]&&lt(()=>{this['onMessage_'](_0x56f491[_0x3ca1c1]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0xceae09,_0x418834,_0x1e8d2b,_0x3040de,_0x2213b5,_0x2dc4f3,_0x4a3422){this['connId']=_0xceae09,this['repoInfo']=_0x418834,this['applicationId']=_0x1e8d2b,this['appCheckToken']=_0x3040de,this['authToken']=_0x2213b5,this['transportSessionId']=_0x2dc4f3,this['lastSessionId']=_0x4a3422,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0xceae09),this['stats_']=Hi(_0x418834),this['urlFn']=_0x3782a4=>(this['appCheckToken']&&(_0x3782a4[yi]=this['appCheckToken']),go(_0x418834,po,_0x3782a4));}['open'](_0x536455,_0x5c0783){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5c0783,this['myPacketOrderer']=new th(_0x536455),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x1ca446)=>{const [_0x4330e7,_0x16d931,_0x2857f0,_0x12c444,_0x4abfcd]=_0x1ca446;if(this['incrementIncomingBytes_'](_0x1ca446),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4330e7===$s)this['id']=_0x16d931,this['password']=_0x2857f0;else{if(_0x4330e7===nh)_0x16d931?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x16d931,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4330e7);}}},(..._0x36e319)=>{const [_0x40636a,_0x293c02]=_0x36e319;this['incrementIncomingBytes_'](_0x36e319),this['myPacketOrderer']['handleResponse'](_0x40636a,_0x293c02);},()=>{this['onClosed_']();},this['urlFn']);const _0xf53ac7={};_0xf53ac7[$s]='t',_0xf53ac7[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0xf53ac7[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0xf53ac7[ro]=Vi,this['transportSessionId']&&(_0xf53ac7[oo]=this['transportSessionId']),this['lastSessionId']&&(_0xf53ac7[ho]=this['lastSessionId']),this['applicationId']&&(_0xf53ac7[uo]=this['applicationId']),this['appCheckToken']&&(_0xf53ac7[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0xf53ac7[ao]=co);const _0x4f4d97=this['urlFn'](_0xf53ac7);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4f4d97),this['scriptTagHolder']['addTag'](_0x4f4d97,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x268b97){const _0x3d104c=O(_0x268b97);this['bytesSent']+=_0x3d104c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3d104c['length']);const _0x5813b9=Br(_0x3d104c),_0x3b404b=io(_0x5813b9,hh);for(let _0x15cabd=0x0;_0x15cabd<_0x3b404b['length'];_0x15cabd++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3b404b['length'],_0x3b404b[_0x15cabd]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x3790cd,_0x3d192a){this['myDisconnFrame']=document['createElement']('iframe');const _0x79f680={};_0x79f680[lh]='t',_0x79f680[mo]=_0x3790cd,_0x79f680[yo]=_0x3d192a,this['myDisconnFrame']['src']=this['urlFn'](_0x79f680),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x348c9f){const _0x3fcfba=O(_0x348c9f)['length'];this['bytesReceived']+=_0x3fcfba,this['stats_']['incrementCounter']('bytes_received',_0x3fcfba);}}class $i{constructor(_0x5d13ed,_0x40b592,_0x4acca3,_0x54a0ef){this['onDisconnect']=_0x4acca3,this['urlFn']=_0x54a0ef,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x5d13ed,window[sh+this['uniqueCallbackIdentifier']]=_0x40b592,this['myIFrame']=$i['createIFrame_']();let _0x29182b='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x29182b='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4bd792='<html><body>'+_0x29182b+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4bd792),this['myIFrame']['doc']['close']();}catch(_0x45c3f4){L('frame\x20writing\x20exception'),_0x45c3f4['stack']&&L(_0x45c3f4['stack']),L(_0x45c3f4);}}}static['createIFrame_'](){const _0x50f835=document['createElement']('iframe');if(_0x50f835['style']['display']='none',document['body']){document['body']['appendChild'](_0x50f835);try{_0x50f835['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0xf2c5b5=document['domain'];_0x50f835['src']='javascript:void((function(){document.open();document.domain=\x27'+_0xf2c5b5+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x50f835['contentDocument']?_0x50f835['doc']=_0x50f835['contentDocument']:_0x50f835['contentWindow']?_0x50f835['doc']=_0x50f835['contentWindow']['document']:_0x50f835['document']&&(_0x50f835['doc']=_0x50f835['document']),_0x50f835;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x5e1082=this['onDisconnect'];_0x5e1082&&(this['onDisconnect']=null,_0x5e1082());}['startLongPoll'](_0x337054,_0x2ea17f){for(this['myID']=_0x337054,this['myPW']=_0x2ea17f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3afa32={};_0x3afa32[mo]=this['myID'],_0x3afa32[yo]=this['myPW'],_0x3afa32[vo]=this['currentSerial'];let _0x1f3aa5=this['urlFn'](_0x3afa32),_0x5b88d3='',_0x24d1c0=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x5b88d3['length']<=Eo;){const _0x41a8c6=this['pendingSegs']['shift']();_0x5b88d3=_0x5b88d3+'&'+oh+_0x24d1c0+'='+_0x41a8c6['seg']+'&'+ah+_0x24d1c0+'='+_0x41a8c6['ts']+'&'+ch+_0x24d1c0+'='+_0x41a8c6['d'],_0x24d1c0++;}return _0x1f3aa5=_0x1f3aa5+_0x5b88d3,this['addLongPollTag_'](_0x1f3aa5,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x5edfa7,_0x1e9d16,_0x1ae078){this['pendingSegs']['push']({'seg':_0x5edfa7,'ts':_0x1e9d16,'d':_0x1ae078}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x3ff7f4,_0x33d934){this['outstandingRequests']['add'](_0x33d934);const _0x58c42c=()=>{this['outstandingRequests']['delete'](_0x33d934),this['newRequest_']();},_0x32233a=setTimeout(_0x58c42c,Math['floor'](uh)),_0x4fe36d=()=>{clearTimeout(_0x32233a),_0x58c42c();};this['addTag'](_0x3ff7f4,_0x4fe36d);}['addTag'](_0x233a25,_0x2c4639){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x508a2d=this['myIFrame']['doc']['createElement']('script');_0x508a2d['type']='text/javascript',_0x508a2d['async']=!0x0,_0x508a2d['src']=_0x233a25,_0x508a2d['onload']=_0x508a2d['onreadystatechange']=function(){const _0x48217e=_0x508a2d['readyState'];(!_0x48217e||_0x48217e==='loaded'||_0x48217e==='complete')&&(_0x508a2d['onload']=_0x508a2d['onreadystatechange']=null,_0x508a2d['parentNode']&&_0x508a2d['parentNode']['removeChild'](_0x508a2d),_0x2c4639());},_0x508a2d['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x233a25),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x508a2d);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x3e307d,_0x456fe1,_0x3bca84,_0x180e15,_0x5b10d7,_0x203eeb,_0x144440){this['connId']=_0x3e307d,this['applicationId']=_0x3bca84,this['appCheckToken']=_0x180e15,this['authToken']=_0x5b10d7,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x456fe1),this['connURL']=G['connectionURL_'](_0x456fe1,_0x203eeb,_0x144440,_0x180e15,_0x3bca84),this['nodeAdmin']=_0x456fe1['nodeAdmin'];}static['connectionURL_'](_0x134de7,_0x19f5dc,_0x26c2b3,_0x206c1a,_0x4fec8f){const _0x43eb1e={};return _0x43eb1e[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x43eb1e[ao]=co),_0x19f5dc&&(_0x43eb1e[oo]=_0x19f5dc),_0x26c2b3&&(_0x43eb1e[ho]=_0x26c2b3),_0x206c1a&&(_0x43eb1e[yi]=_0x206c1a),_0x4fec8f&&(_0x43eb1e[uo]=_0x4fec8f),go(_0x134de7,fo,_0x43eb1e);}['open'](_0x2b69cb,_0x352064){this['onDisconnect']=_0x352064,this['onMessage']=_0x2b69cb,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x394499;dc(),this['mySock']=new hn(this['connURL'],[],_0x394499);}catch(_0x1f97b3){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x5b9c8f=_0x1f97b3['message']||_0x1f97b3['data'];_0x5b9c8f&&this['log_'](_0x5b9c8f),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x4e82d7=>{this['handleIncomingFrame'](_0x4e82d7);},this['mySock']['onerror']=_0x2bcd14=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x4069b4=_0x2bcd14['message']||_0x2bcd14['data'];_0x4069b4&&this['log_'](_0x4069b4),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x213d54=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x45673b=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5e91aa=navigator['userAgent']['match'](_0x45673b);_0x5e91aa&&_0x5e91aa['length']>0x1&&parseFloat(_0x5e91aa[0x1])<4.4&&(_0x213d54=!0x0);}return!_0x213d54&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x10f4b4){if(this['frames']['push'](_0x10f4b4),this['frames']['length']===this['totalFrames']){const _0x15a1e8=this['frames']['join']('');this['frames']=null;const _0x35a74c=bt(_0x15a1e8);this['onMessage'](_0x35a74c);}}['handleNewFrameCount_'](_0x5c755c){this['totalFrames']=_0x5c755c,this['frames']=[];}['extractFrameCount_'](_0xfeec24){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0xfeec24['length']<=0x6){const _0x1ca38c=Number(_0xfeec24);if(!isNaN(_0x1ca38c))return this['handleNewFrameCount_'](_0x1ca38c),null;}return this['handleNewFrameCount_'](0x1),_0xfeec24;}['handleIncomingFrame'](_0x2d32e){if(this['mySock']===null)return;const _0x2c933d=_0x2d32e['data'];if(this['bytesReceived']+=_0x2c933d['length'],this['stats_']['incrementCounter']('bytes_received',_0x2c933d['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2c933d);else{const _0x118c99=this['extractFrameCount_'](_0x2c933d);_0x118c99!==null&&this['appendFrame_'](_0x118c99);}}['send'](_0x5f37a5){this['resetKeepAlive']();const _0x13ab0d=O(_0x5f37a5);this['bytesSent']+=_0x13ab0d['length'],this['stats_']['incrementCounter']('bytes_sent',_0x13ab0d['length']);const _0x424936=io(_0x13ab0d,fh);_0x424936['length']>0x1&&this['sendString_'](String(_0x424936['length']));for(let _0x2c9950=0x0;_0x2c9950<_0x424936['length'];_0x2c9950++)this['sendString_'](_0x424936[_0x2c9950]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x2c9897){try{this['mySock']['send'](_0x2c9897);}catch(_0x154d5f){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x154d5f['message']||_0x154d5f['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x28b7ed){this['initTransports_'](_0x28b7ed);}['initTransports_'](_0x45de96){const _0x31716f=G&&G['isAvailable']();let _0x4c77ba=_0x31716f&&!G['previouslyFailed']();if(_0x45de96['webSocketOnly']&&(_0x31716f||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4c77ba=!0x0),_0x4c77ba)this['transports_']=[G];else{const _0x23f8e0=this['transports_']=[];for(const _0x2030bc of At['ALL_TRANSPORTS'])_0x2030bc&&_0x2030bc['isAvailable']()&&_0x23f8e0['push'](_0x2030bc);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x2747b7,_0x27aba3,_0x51b598,_0x2a3c85,_0x4b2024,_0x3000b5,_0x34a733,_0x33d58d,_0x5be969,_0x70097b){this['id']=_0x2747b7,this['repoInfo_']=_0x27aba3,this['applicationId_']=_0x51b598,this['appCheckToken_']=_0x2a3c85,this['authToken_']=_0x4b2024,this['onMessage_']=_0x3000b5,this['onReady_']=_0x34a733,this['onDisconnect_']=_0x33d58d,this['onKill_']=_0x5be969,this['lastSessionId']=_0x70097b,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x27aba3),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1cb0df=this['transportManager_']['initialTransport']();this['conn_']=new _0x1cb0df(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1cb0df['responsesRequiredToBeHealthy']||0x0;const _0x5e8b7a=this['connReceiver_'](this['conn_']),_0x3336f8=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x5e8b7a,_0x3336f8);},Math['floor'](0x0));const _0x1d67c3=_0x1cb0df['healthyTimeout']||0x0;_0x1d67c3>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x1d67c3)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5f1e39){return _0x3f1031=>{_0x5f1e39===this['conn_']?this['onConnectionLost_'](_0x3f1031):_0x5f1e39===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3e3274){return _0x14d475=>{this['state_']!==0x2&&(_0x3e3274===this['rx_']?this['onPrimaryMessageReceived_'](_0x14d475):_0x3e3274===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x14d475):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1fcafb){const _0x11c123={'t':'d','d':_0x1fcafb};this['sendData_'](_0x11c123);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1744b4){if(ii in _0x1744b4){const _0x43c044=_0x1744b4[ii];_0x43c044===js?this['upgradeIfSecondaryHealthy_']():_0x43c044===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x43c044===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x435aeb){const _0x8457d=pt('t',_0x435aeb),_0x2c5d41=pt('d',_0x435aeb);if(_0x8457d==='c')this['onSecondaryControl_'](_0x2c5d41);else{if(_0x8457d==='d')this['pendingDataMessages']['push'](_0x2c5d41);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x8457d);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x6e78f4){const _0x161d04=pt('t',_0x6e78f4),_0x39ee7a=pt('d',_0x6e78f4);_0x161d04==='c'?this['onControl_'](_0x39ee7a):_0x161d04==='d'&&this['onDataMessage_'](_0x39ee7a);}['onDataMessage_'](_0x32510f){this['onPrimaryResponse_'](),this['onMessage_'](_0x32510f);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x71c1bb){const _0x2ac9eb=pt(ii,_0x71c1bb);if(Gs in _0x71c1bb){const _0x3d9614=_0x71c1bb[Gs];if(_0x2ac9eb===Ih){const _0x19b159={..._0x3d9614};this['repoInfo_']['isUsingEmulator']&&(_0x19b159['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x19b159);}else{if(_0x2ac9eb===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x5d86b7=0x0;_0x5d86b7<this['pendingDataMessages']['length'];++_0x5d86b7)this['onDataMessage_'](this['pendingDataMessages'][_0x5d86b7]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2ac9eb===vh?this['onConnectionShutdown_'](_0x3d9614):_0x2ac9eb===qs?this['onReset_'](_0x3d9614):_0x2ac9eb===Eh?mi('Server\x20Error:\x20'+_0x3d9614):_0x2ac9eb===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x2ac9eb);}}}['onHandshake_'](_0x34d3d6){const _0x24ff07=_0x34d3d6['ts'],_0x12ee54=_0x34d3d6['v'],_0x177d84=_0x34d3d6['h'];this['sessionId']=_0x34d3d6['s'],this['repoInfo_']['host']=_0x177d84,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x24ff07),Vi!==_0x12ee54&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1693f4=this['transportManager_']['upgradeTransport']();_0x1693f4&&this['startUpgrade_'](_0x1693f4);}['startUpgrade_'](_0x28e2a8){this['secondaryConn_']=new _0x28e2a8(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x28e2a8['responsesRequiredToBeHealthy']||0x0;const _0x7297c3=this['connReceiver_'](this['secondaryConn_']),_0x3933d0=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x7297c3,_0x3933d0),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x459004){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x459004),this['repoInfo_']['host']=_0x459004,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4a87af,_0x32ed90){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4a87af,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x32ed90,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x351419=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x351419||this['rx_']===_0x351419)&&this['close']();}['onConnectionLost_'](_0x225b9e){this['conn_']=null,!_0x225b9e&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3fcb3b){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3fcb3b),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x778880){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x778880);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x2ae65f,_0x295f8b,_0x3e690a,_0x445dc3){}['merge'](_0x192652,_0x21387e,_0x152ed0,_0x4e1d2b){}['refreshAuthToken'](_0x1a7331){}['refreshAppCheckToken'](_0x2d33f8){}['onDisconnectPut'](_0x33b0eb,_0x4c4f9d,_0x2d9826){}['onDisconnectMerge'](_0x2cd238,_0x13afc7,_0x27bd45){}['onDisconnectCancel'](_0x131abc,_0x48ea1f){}['reportStats'](_0x100c30){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x2fec55){this['allowedEvents_']=_0x2fec55,this['listeners_']={},f(Array['isArray'](_0x2fec55)&&_0x2fec55['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x2bdd0a,..._0x738fed){if(Array['isArray'](this['listeners_'][_0x2bdd0a])){const _0x39e5a9=[...this['listeners_'][_0x2bdd0a]];for(let _0x2cda18=0x0;_0x2cda18<_0x39e5a9['length'];_0x2cda18++)_0x39e5a9[_0x2cda18]['callback']['apply'](_0x39e5a9[_0x2cda18]['context'],_0x738fed);}}['on'](_0x257b3f,_0x16889d,_0x2ca55b){this['validateEventType_'](_0x257b3f),this['listeners_'][_0x257b3f]=this['listeners_'][_0x257b3f]||[],this['listeners_'][_0x257b3f]['push']({'callback':_0x16889d,'context':_0x2ca55b});const _0x5418ca=this['getInitialEvent'](_0x257b3f);_0x5418ca&&_0x16889d['apply'](_0x2ca55b,_0x5418ca);}['off'](_0x281d7c,_0x56fd0d,_0x54cc6c){this['validateEventType_'](_0x281d7c);const _0x541c52=this['listeners_'][_0x281d7c]||[];for(let _0x2566e4=0x0;_0x2566e4<_0x541c52['length'];_0x2566e4++)if(_0x541c52[_0x2566e4]['callback']===_0x56fd0d&&(!_0x54cc6c||_0x54cc6c===_0x541c52[_0x2566e4]['context'])){_0x541c52['splice'](_0x2566e4,0x1);return;}}['validateEventType_'](_0x421b42){f(this['allowedEvents_']['find'](_0x1cce03=>_0x1cce03===_0x421b42),'Unknown\x20event:\x20'+_0x421b42);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x3bfc9a){return f(_0x3bfc9a==='online','Unknown\x20event\x20type:\x20'+_0x3bfc9a),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x515630,_0x5a9c03){if(_0x5a9c03===void 0x0){this['pieces_']=_0x515630['split']('/');let _0x3d4764=0x0;for(let _0x395872=0x0;_0x395872<this['pieces_']['length'];_0x395872++)this['pieces_'][_0x395872]['length']>0x0&&(this['pieces_'][_0x3d4764]=this['pieces_'][_0x395872],_0x3d4764++);this['pieces_']['length']=_0x3d4764,this['pieceNum_']=0x0;}else this['pieces_']=_0x515630,this['pieceNum_']=_0x5a9c03;}['toString'](){let _0x17986e='';for(let _0x1dd361=this['pieceNum_'];_0x1dd361<this['pieces_']['length'];_0x1dd361++)this['pieces_'][_0x1dd361]!==''&&(_0x17986e+='/'+this['pieces_'][_0x1dd361]);return _0x17986e||'/';}}function w(){return new C('');}function y(_0x39470b){return _0x39470b['pieceNum_']>=_0x39470b['pieces_']['length']?null:_0x39470b['pieces_'][_0x39470b['pieceNum_']];}function we(_0x587a3a){return _0x587a3a['pieces_']['length']-_0x587a3a['pieceNum_'];}function b(_0x4a1d01){let _0x22d6f0=_0x4a1d01['pieceNum_'];return _0x22d6f0<_0x4a1d01['pieces_']['length']&&_0x22d6f0++,new C(_0x4a1d01['pieces_'],_0x22d6f0);}function Gi(_0x3070eb){return _0x3070eb['pieceNum_']<_0x3070eb['pieces_']['length']?_0x3070eb['pieces_'][_0x3070eb['pieces_']['length']-0x1]:null;}function Ch(_0x140f53){let _0x321d3f='';for(let _0x2e7b54=_0x140f53['pieceNum_'];_0x2e7b54<_0x140f53['pieces_']['length'];_0x2e7b54++)_0x140f53['pieces_'][_0x2e7b54]!==''&&(_0x321d3f+='/'+encodeURIComponent(String(_0x140f53['pieces_'][_0x2e7b54])));return _0x321d3f||'/';}function kt(_0x31f0db,_0x40a220=0x0){return _0x31f0db['pieces_']['slice'](_0x31f0db['pieceNum_']+_0x40a220);}function To(_0x57e184){if(_0x57e184['pieceNum_']>=_0x57e184['pieces_']['length'])return null;const _0x5316ea=[];for(let _0x5ac930=_0x57e184['pieceNum_'];_0x5ac930<_0x57e184['pieces_']['length']-0x1;_0x5ac930++)_0x5316ea['push'](_0x57e184['pieces_'][_0x5ac930]);return new C(_0x5316ea,0x0);}function A(_0xb7b233,_0x3d625b){const _0x4f46dd=[];for(let _0xc852b3=_0xb7b233['pieceNum_'];_0xc852b3<_0xb7b233['pieces_']['length'];_0xc852b3++)_0x4f46dd['push'](_0xb7b233['pieces_'][_0xc852b3]);if(_0x3d625b instanceof C){for(let _0x1dc97b=_0x3d625b['pieceNum_'];_0x1dc97b<_0x3d625b['pieces_']['length'];_0x1dc97b++)_0x4f46dd['push'](_0x3d625b['pieces_'][_0x1dc97b]);}else{const _0x57147a=_0x3d625b['split']('/');for(let _0x19befd=0x0;_0x19befd<_0x57147a['length'];_0x19befd++)_0x57147a[_0x19befd]['length']>0x0&&_0x4f46dd['push'](_0x57147a[_0x19befd]);}return new C(_0x4f46dd,0x0);}function v(_0x414dd2){return _0x414dd2['pieceNum_']>=_0x414dd2['pieces_']['length'];}function F(_0x387f60,_0x1d7a88){const _0xba6b7b=y(_0x387f60),_0x537bbd=y(_0x1d7a88);if(_0xba6b7b===null)return _0x1d7a88;if(_0xba6b7b===_0x537bbd)return F(b(_0x387f60),b(_0x1d7a88));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x1d7a88+')\x20is\x20not\x20within\x20outerPath\x20('+_0x387f60+')');}function Th(_0x4f6599,_0x17eb41){const _0x2fe065=kt(_0x4f6599,0x0),_0x566a09=kt(_0x17eb41,0x0);for(let _0x271ace=0x0;_0x271ace<_0x2fe065['length']&&_0x271ace<_0x566a09['length'];_0x271ace++){const _0xc4c0e8=He(_0x2fe065[_0x271ace],_0x566a09[_0x271ace]);if(_0xc4c0e8!==0x0)return _0xc4c0e8;}return _0x2fe065['length']===_0x566a09['length']?0x0:_0x2fe065['length']<_0x566a09['length']?-0x1:0x1;}function qi(_0x13f09b,_0x1305e2){if(we(_0x13f09b)!==we(_0x1305e2))return!0x1;for(let _0x1658f9=_0x13f09b['pieceNum_'],_0x1b4fac=_0x1305e2['pieceNum_'];_0x1658f9<=_0x13f09b['pieces_']['length'];_0x1658f9++,_0x1b4fac++)if(_0x13f09b['pieces_'][_0x1658f9]!==_0x1305e2['pieces_'][_0x1b4fac])return!0x1;return!0x0;}function $(_0x297426,_0xe61013){let _0x43cf44=_0x297426['pieceNum_'],_0x4485dc=_0xe61013['pieceNum_'];if(we(_0x297426)>we(_0xe61013))return!0x1;for(;_0x43cf44<_0x297426['pieces_']['length'];){if(_0x297426['pieces_'][_0x43cf44]!==_0xe61013['pieces_'][_0x4485dc])return!0x1;++_0x43cf44,++_0x4485dc;}return!0x0;}class Sh{constructor(_0x4ab2b2,_0x8075cd){this['errorPrefix_']=_0x8075cd,this['parts_']=kt(_0x4ab2b2,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x30f592=0x0;_0x30f592<this['parts_']['length'];_0x30f592++)this['byteLength_']+=Pn(this['parts_'][_0x30f592]);So(this);}}function bh(_0x23327d,_0x348397){_0x23327d['parts_']['length']>0x0&&(_0x23327d['byteLength_']+=0x1),_0x23327d['parts_']['push'](_0x348397),_0x23327d['byteLength_']+=Pn(_0x348397),So(_0x23327d);}function Rh(_0x4891a2){const _0x579c6c=_0x4891a2['parts_']['pop']();_0x4891a2['byteLength_']-=Pn(_0x579c6c),_0x4891a2['parts_']['length']>0x0&&(_0x4891a2['byteLength_']-=0x1);}function So(_0x20287b){if(_0x20287b['byteLength_']>Js)throw new Error(_0x20287b['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x20287b['byteLength_']+').');if(_0x20287b['parts_']['length']>Qs)throw new Error(_0x20287b['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x20287b));}function Ne(_0x1b7aac){return _0x1b7aac['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1b7aac['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x3a22a4,_0x35594b;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x35594b='visibilitychange',_0x3a22a4='hidden'):typeof document['mozHidden']<'u'?(_0x35594b='mozvisibilitychange',_0x3a22a4='mozHidden'):typeof document['msHidden']<'u'?(_0x35594b='msvisibilitychange',_0x3a22a4='msHidden'):typeof document['webkitHidden']<'u'&&(_0x35594b='webkitvisibilitychange',_0x3a22a4='webkitHidden')),this['visible_']=!0x0,_0x35594b&&document['addEventListener'](_0x35594b,()=>{const _0x59dfa5=!document[_0x3a22a4];_0x59dfa5!==this['visible_']&&(this['visible_']=_0x59dfa5,this['trigger']('visible',_0x59dfa5));},!0x1);}['getInitialEvent'](_0x3f9e4d){return f(_0x3f9e4d==='visible','Unknown\x20event\x20type:\x20'+_0x3f9e4d),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x5caf0b,_0x4ce4b7,_0x1b58cf,_0x24ee07,_0xf3d555,_0x3bdc26,_0x1f3cb1,_0x3941d8){if(super(),this['repoInfo_']=_0x5caf0b,this['applicationId_']=_0x4ce4b7,this['onDataUpdate_']=_0x1b58cf,this['onConnectStatus_']=_0x24ee07,this['onServerInfoUpdate_']=_0xf3d555,this['authTokenProvider_']=_0x3bdc26,this['appCheckTokenProvider_']=_0x1f3cb1,this['authOverride_']=_0x3941d8,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x3941d8)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x5caf0b['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x49a7ae,_0x593b33,_0x1da3e7){const _0xdf4f40=++this['requestNumber_'],_0x348b7c={'r':_0xdf4f40,'a':_0x49a7ae,'b':_0x593b33};this['log_'](O(_0x348b7c)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x348b7c),_0x1da3e7&&(this['requestCBHash_'][_0xdf4f40]=_0x1da3e7);}['get'](_0x4da77a){this['initConnection_']();const _0x18689c=new Ve(),_0x92df73={'action':'g','request':{'p':_0x4da77a['_path']['toString'](),'q':_0x4da77a['_queryObject']},'onComplete':_0x71e8fa=>{const _0x434e4e=_0x71e8fa['d'];_0x71e8fa['s']==='ok'?_0x18689c['resolve'](_0x434e4e):_0x18689c['reject'](_0x434e4e);}};this['outstandingGets_']['push'](_0x92df73),this['outstandingGetCount_']++;const _0x1d8df0=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1d8df0),_0x18689c['promise'];}['listen'](_0x1b2328,_0x3bfbae,_0x4e4f6c,_0x12dd3e){this['initConnection_']();const _0x5cc67d=_0x1b2328['_queryIdentifier'],_0x47071b=_0x1b2328['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x47071b+'\x20'+_0x5cc67d),this['listens']['has'](_0x47071b)||this['listens']['set'](_0x47071b,new Map()),f(_0x1b2328['_queryParams']['isDefault']()||!_0x1b2328['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x47071b)['has'](_0x5cc67d),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4e5eb6={'onComplete':_0x12dd3e,'hashFn':_0x3bfbae,'query':_0x1b2328,'tag':_0x4e4f6c};this['listens']['get'](_0x47071b)['set'](_0x5cc67d,_0x4e5eb6),this['connected_']&&this['sendListen_'](_0x4e5eb6);}['sendGet_'](_0x451383){const _0x420dd0=this['outstandingGets_'][_0x451383];this['sendRequest']('g',_0x420dd0['request'],_0x534d2e=>{delete this['outstandingGets_'][_0x451383],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x420dd0['onComplete']&&_0x420dd0['onComplete'](_0x534d2e);});}['sendListen_'](_0xe2ad6a){const _0x476e85=_0xe2ad6a['query'],_0x173426=_0x476e85['_path']['toString'](),_0x1e2c61=_0x476e85['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x173426+'\x20for\x20'+_0x1e2c61);const _0x42ff2e={'p':_0x173426},_0x5adfd7='q';_0xe2ad6a['tag']&&(_0x42ff2e['q']=_0x476e85['_queryObject'],_0x42ff2e['t']=_0xe2ad6a['tag']),_0x42ff2e['h']=_0xe2ad6a['hashFn'](),this['sendRequest'](_0x5adfd7,_0x42ff2e,_0x3b5176=>{const _0x3f4d45=_0x3b5176['d'],_0x463609=_0x3b5176['s'];ie['warnOnListenWarnings_'](_0x3f4d45,_0x476e85),(this['listens']['get'](_0x173426)&&this['listens']['get'](_0x173426)['get'](_0x1e2c61))===_0xe2ad6a&&(this['log_']('listen\x20response',_0x3b5176),_0x463609!=='ok'&&this['removeListen_'](_0x173426,_0x1e2c61),_0xe2ad6a['onComplete']&&_0xe2ad6a['onComplete'](_0x463609,_0x3f4d45));});}static['warnOnListenWarnings_'](_0x4e43d1,_0x5ccead){if(_0x4e43d1&&typeof _0x4e43d1=='object'&&Y(_0x4e43d1,'w')){const _0x516bde=Oe(_0x4e43d1,'w');if(Array['isArray'](_0x516bde)&&~_0x516bde['indexOf']('no_index')){const _0x3dd94d='\x22.indexOn\x22:\x20\x22'+_0x5ccead['_queryParams']['getIndex']()['toString']()+'\x22',_0x29af28=_0x5ccead['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3dd94d+'\x20at\x20'+_0x29af28+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x397b9f){this['authToken_']=_0x397b9f,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x397b9f);}['reduceReconnectDelayIfAdminCredential_'](_0x484fff){(_0x484fff&&_0x484fff['length']===0x28||vc(_0x484fff))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x3d680a){this['appCheckToken_']=_0x3d680a,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x39f310=this['authToken_'],_0x130082=yc(_0x39f310)?'auth':'gauth',_0x814824={'cred':_0x39f310};this['authOverride_']===null?_0x814824['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x814824['authvar']=this['authOverride_']),this['sendRequest'](_0x130082,_0x814824,_0x27e33f=>{const _0x23d977=_0x27e33f['s'],_0x3d6a57=_0x27e33f['d']||'error';this['authToken_']===_0x39f310&&(_0x23d977==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x23d977,_0x3d6a57));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3df698=>{const _0x5c46ea=_0x3df698['s'],_0x57f9e9=_0x3df698['d']||'error';_0x5c46ea==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x5c46ea,_0x57f9e9);});}['unlisten'](_0x580457,_0x5daff3){const _0x24ac4a=_0x580457['_path']['toString'](),_0x513ca0=_0x580457['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x24ac4a+'\x20'+_0x513ca0),f(_0x580457['_queryParams']['isDefault']()||!_0x580457['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x24ac4a,_0x513ca0)&&this['connected_']&&this['sendUnlisten_'](_0x24ac4a,_0x513ca0,_0x580457['_queryObject'],_0x5daff3);}['sendUnlisten_'](_0x47efb2,_0x391441,_0x2a0677,_0x562b47){this['log_']('Unlisten\x20on\x20'+_0x47efb2+'\x20for\x20'+_0x391441);const _0x310a09={'p':_0x47efb2},_0xb16fe5='n';_0x562b47&&(_0x310a09['q']=_0x2a0677,_0x310a09['t']=_0x562b47),this['sendRequest'](_0xb16fe5,_0x310a09);}['onDisconnectPut'](_0x332354,_0x5c45b1,_0x1c061a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x332354,_0x5c45b1,_0x1c061a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x332354,'action':'o','data':_0x5c45b1,'onComplete':_0x1c061a});}['onDisconnectMerge'](_0x58a2c3,_0x481993,_0x4554c7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x58a2c3,_0x481993,_0x4554c7):this['onDisconnectRequestQueue_']['push']({'pathString':_0x58a2c3,'action':'om','data':_0x481993,'onComplete':_0x4554c7});}['onDisconnectCancel'](_0x1cab4b,_0x19120a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1cab4b,null,_0x19120a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1cab4b,'action':'oc','data':null,'onComplete':_0x19120a});}['sendOnDisconnect_'](_0x3dfe86,_0x8a1a1b,_0x1ef29b,_0x199850){const _0x4dbbf6={'p':_0x8a1a1b,'d':_0x1ef29b};this['log_']('onDisconnect\x20'+_0x3dfe86,_0x4dbbf6),this['sendRequest'](_0x3dfe86,_0x4dbbf6,_0x1d76f1=>{_0x199850&&setTimeout(()=>{_0x199850(_0x1d76f1['s'],_0x1d76f1['d']);},Math['floor'](0x0));});}['put'](_0xa711f0,_0x2328d2,_0x339e33,_0x8eac60){this['putInternal']('p',_0xa711f0,_0x2328d2,_0x339e33,_0x8eac60);}['merge'](_0x27e7b5,_0x89095b,_0x3c031f,_0xbcc972){this['putInternal']('m',_0x27e7b5,_0x89095b,_0x3c031f,_0xbcc972);}['putInternal'](_0x14d77c,_0x220c9e,_0x50e26d,_0x37636a,_0x181da0){this['initConnection_']();const _0x493874={'p':_0x220c9e,'d':_0x50e26d};_0x181da0!==void 0x0&&(_0x493874['h']=_0x181da0),this['outstandingPuts_']['push']({'action':_0x14d77c,'request':_0x493874,'onComplete':_0x37636a}),this['outstandingPutCount_']++;const _0x51302b=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x51302b):this['log_']('Buffering\x20put:\x20'+_0x220c9e);}['sendPut_'](_0x2b6a8e){const _0x14c2a5=this['outstandingPuts_'][_0x2b6a8e]['action'],_0x139478=this['outstandingPuts_'][_0x2b6a8e]['request'],_0x36b351=this['outstandingPuts_'][_0x2b6a8e]['onComplete'];this['outstandingPuts_'][_0x2b6a8e]['queued']=this['connected_'],this['sendRequest'](_0x14c2a5,_0x139478,_0x4efe87=>{this['log_'](_0x14c2a5+'\x20response',_0x4efe87),delete this['outstandingPuts_'][_0x2b6a8e],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x36b351&&_0x36b351(_0x4efe87['s'],_0x4efe87['d']);});}['reportStats'](_0xa8a05d){if(this['connected_']){const _0x3b14d5={'c':_0xa8a05d};this['log_']('reportStats',_0x3b14d5),this['sendRequest']('s',_0x3b14d5,_0x1feff6=>{if(_0x1feff6['s']!=='ok'){const _0x5679d0=_0x1feff6['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5679d0);}});}}['onDataMessage_'](_0x5e9469){if('r'in _0x5e9469){this['log_']('from\x20server:\x20'+O(_0x5e9469));const _0x391b61=_0x5e9469['r'],_0x24e8e8=this['requestCBHash_'][_0x391b61];_0x24e8e8&&(delete this['requestCBHash_'][_0x391b61],_0x24e8e8(_0x5e9469['b']));}else{if('error'in _0x5e9469)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5e9469['error'];'a'in _0x5e9469&&this['onDataPush_'](_0x5e9469['a'],_0x5e9469['b']);}}['onDataPush_'](_0x17800b,_0x1ae84d){this['log_']('handleServerMessage',_0x17800b,_0x1ae84d),_0x17800b==='d'?this['onDataUpdate_'](_0x1ae84d['p'],_0x1ae84d['d'],!0x1,_0x1ae84d['t']):_0x17800b==='m'?this['onDataUpdate_'](_0x1ae84d['p'],_0x1ae84d['d'],!0x0,_0x1ae84d['t']):_0x17800b==='c'?this['onListenRevoked_'](_0x1ae84d['p'],_0x1ae84d['q']):_0x17800b==='ac'?this['onAuthRevoked_'](_0x1ae84d['s'],_0x1ae84d['d']):_0x17800b==='apc'?this['onAppCheckRevoked_'](_0x1ae84d['s'],_0x1ae84d['d']):_0x17800b==='sd'?this['onSecurityDebugPacket_'](_0x1ae84d):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x17800b)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0xe5bf1d,_0x3573d5){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0xe5bf1d),this['lastSessionId']=_0x3573d5,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3033ad){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3033ad));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x362819){_0x362819&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x362819;}['onOnline_'](_0x5c66a4){_0x5c66a4?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3935aa=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x36254d=Math['max'](0x0,this['reconnectDelay_']-_0x3935aa);_0x36254d=Math['random']()*_0x36254d,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x36254d+'ms'),this['scheduleConnect_'](_0x36254d),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4a5a4e=this['onDataMessage_']['bind'](this),_0x533885=this['onReady_']['bind'](this),_0x827500=this['onRealtimeDisconnect_']['bind'](this),_0x5b82a0=this['id']+':'+ie['nextConnectionId_']++,_0x9b0be=this['lastSessionId'];let _0x1e2bea=!0x1,_0x1a6d20=null;const _0x4d5b0c=function(){_0x1a6d20?_0x1a6d20['close']():(_0x1e2bea=!0x0,_0x827500());},_0x13fad5=function(_0x282a92){f(_0x1a6d20,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1a6d20['sendRequest'](_0x282a92);};this['realtime_']={'close':_0x4d5b0c,'sendRequest':_0x13fad5};const _0x1c3bf7=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1e1e3c,_0x45f098]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x1c3bf7),this['appCheckTokenProvider_']['getToken'](_0x1c3bf7)]);_0x1e2bea?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1e1e3c&&_0x1e1e3c['accessToken'],this['appCheckToken_']=_0x45f098&&_0x45f098['token'],_0x1a6d20=new wh(_0x5b82a0,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4a5a4e,_0x533885,_0x827500,_0x11d585=>{U(_0x11d585+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x9b0be));}catch(_0x5ac7c7){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x5ac7c7),_0x1e2bea||(this['repoInfo_']['nodeAdmin']&&U(_0x5ac7c7),_0x4d5b0c());}}}['interrupt'](_0x1d84b0){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1d84b0),this['interruptReasons_'][_0x1d84b0]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x39f1dc){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x39f1dc),delete this['interruptReasons_'][_0x39f1dc],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1d0574){const _0x446453=_0x1d0574-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x446453});}['cancelSentTransactions_'](){for(let _0x213c06=0x0;_0x213c06<this['outstandingPuts_']['length'];_0x213c06++){const _0x257290=this['outstandingPuts_'][_0x213c06];_0x257290&&'h'in _0x257290['request']&&_0x257290['queued']&&(_0x257290['onComplete']&&_0x257290['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x213c06],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5c67e4,_0x15e8cb){let _0x72df9a;_0x15e8cb?_0x72df9a=_0x15e8cb['map'](_0x45d34c=>Bi(_0x45d34c))['join']('$'):_0x72df9a='default';const _0x2df9ae=this['removeListen_'](_0x5c67e4,_0x72df9a);_0x2df9ae&&_0x2df9ae['onComplete']&&_0x2df9ae['onComplete']('permission_denied');}['removeListen_'](_0x4ba225,_0x503275){const _0x577b1f=new C(_0x4ba225)['toString']();let _0x2a92b7;if(this['listens']['has'](_0x577b1f)){const _0x49307d=this['listens']['get'](_0x577b1f);_0x2a92b7=_0x49307d['get'](_0x503275),_0x49307d['delete'](_0x503275),_0x49307d['size']===0x0&&this['listens']['delete'](_0x577b1f);}else _0x2a92b7=void 0x0;return _0x2a92b7;}['onAuthRevoked_'](_0x4ef1d3,_0x2d125a){L('Auth\x20token\x20revoked:\x20'+_0x4ef1d3+'/'+_0x2d125a),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x4ef1d3==='invalid_token'||_0x4ef1d3==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5e799e,_0xa1d349){L('App\x20check\x20token\x20revoked:\x20'+_0x5e799e+'/'+_0xa1d349),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5e799e==='invalid_token'||_0x5e799e==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x32da17){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x32da17):'msg'in _0x32da17&&console['log']('FIREBASE:\x20'+_0x32da17['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x11cc13 of this['listens']['values']())for(const _0x3da89c of _0x11cc13['values']())this['sendListen_'](_0x3da89c);for(let _0x3d6876=0x0;_0x3d6876<this['outstandingPuts_']['length'];_0x3d6876++)this['outstandingPuts_'][_0x3d6876]&&this['sendPut_'](_0x3d6876);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4cb205=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4cb205['action'],_0x4cb205['pathString'],_0x4cb205['data'],_0x4cb205['onComplete']);}for(let _0x688c7c=0x0;_0x688c7c<this['outstandingGets_']['length'];_0x688c7c++)this['outstandingGets_'][_0x688c7c]&&this['sendGet_'](_0x688c7c);}['sendConnectStats_'](){const _0x343830={};let _0x84d996='js';_0x343830['sdk.'+_0x84d996+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x343830['framework.cordova']=0x1:qr()&&(_0x343830['framework.reactnative']=0x1),this['reportStats'](_0x343830);}['shouldReconnect_'](){const _0x357ecf=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x357ecf;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x57fe8b,_0x1a9b7d){this['name']=_0x57fe8b,this['node']=_0x1a9b7d;}static['Wrap'](_0x2c285a,_0x9e83c6){return new E(_0x2c285a,_0x9e83c6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3ed428,_0x338772){const _0x56010b=new E(xe,_0x3ed428),_0x3291fe=new E(xe,_0x338772);return this['compare'](_0x56010b,_0x3291fe)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x881f67){Xt=_0x881f67;}['compare'](_0x4065c6,_0x327940){return He(_0x4065c6['name'],_0x327940['name']);}['isDefinedOn'](_0x4b3ba1){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x27f958,_0x1b0a23){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x15922b,_0x3a7994){return f(typeof _0x15922b=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x15922b,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x47526f,_0x209774,_0x345426,_0x1e7904,_0x23f03c=null){this['isReverse_']=_0x1e7904,this['resultGenerator_']=_0x23f03c,this['nodeStack_']=[];let _0x17b792=0x1;for(;!_0x47526f['isEmpty']();)if(_0x47526f=_0x47526f,_0x17b792=_0x209774?_0x345426(_0x47526f['key'],_0x209774):0x1,_0x1e7904&&(_0x17b792*=-0x1),_0x17b792<0x0)this['isReverse_']?_0x47526f=_0x47526f['left']:_0x47526f=_0x47526f['right'];else{if(_0x17b792===0x0){this['nodeStack_']['push'](_0x47526f);break;}else this['nodeStack_']['push'](_0x47526f),this['isReverse_']?_0x47526f=_0x47526f['right']:_0x47526f=_0x47526f['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x521b24=this['nodeStack_']['pop'](),_0x11943b;if(this['resultGenerator_']?_0x11943b=this['resultGenerator_'](_0x521b24['key'],_0x521b24['value']):_0x11943b={'key':_0x521b24['key'],'value':_0x521b24['value']},this['isReverse_']){for(_0x521b24=_0x521b24['left'];!_0x521b24['isEmpty']();)this['nodeStack_']['push'](_0x521b24),_0x521b24=_0x521b24['right'];}else{for(_0x521b24=_0x521b24['right'];!_0x521b24['isEmpty']();)this['nodeStack_']['push'](_0x521b24),_0x521b24=_0x521b24['left'];}return _0x11943b;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2b4aa3=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2b4aa3['key'],_0x2b4aa3['value']):{'key':_0x2b4aa3['key'],'value':_0x2b4aa3['value']};}}class M{constructor(_0x13ed78,_0x49b8be,_0x122106,_0x21c2c9,_0x4a5947){this['key']=_0x13ed78,this['value']=_0x49b8be,this['color']=_0x122106??M['RED'],this['left']=_0x21c2c9??B['EMPTY_NODE'],this['right']=_0x4a5947??B['EMPTY_NODE'];}['copy'](_0x380ede,_0x5e3d94,_0x5c7914,_0x1b5251,_0x597bbf){return new M(_0x380ede??this['key'],_0x5e3d94??this['value'],_0x5c7914??this['color'],_0x1b5251??this['left'],_0x597bbf??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0xb2ee6c){return this['left']['inorderTraversal'](_0xb2ee6c)||!!_0xb2ee6c(this['key'],this['value'])||this['right']['inorderTraversal'](_0xb2ee6c);}['reverseTraversal'](_0x43becb){return this['right']['reverseTraversal'](_0x43becb)||_0x43becb(this['key'],this['value'])||this['left']['reverseTraversal'](_0x43becb);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5858f3,_0x4ee209,_0x26ac2e){let _0x48b6df=this;const _0x349bfe=_0x26ac2e(_0x5858f3,_0x48b6df['key']);return _0x349bfe<0x0?_0x48b6df=_0x48b6df['copy'](null,null,null,_0x48b6df['left']['insert'](_0x5858f3,_0x4ee209,_0x26ac2e),null):_0x349bfe===0x0?_0x48b6df=_0x48b6df['copy'](null,_0x4ee209,null,null,null):_0x48b6df=_0x48b6df['copy'](null,null,null,null,_0x48b6df['right']['insert'](_0x5858f3,_0x4ee209,_0x26ac2e)),_0x48b6df['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x32e842=this;return!_0x32e842['left']['isRed_']()&&!_0x32e842['left']['left']['isRed_']()&&(_0x32e842=_0x32e842['moveRedLeft_']()),_0x32e842=_0x32e842['copy'](null,null,null,_0x32e842['left']['removeMin_'](),null),_0x32e842['fixUp_']();}['remove'](_0x50c999,_0x428eab){let _0x436275,_0x340d98;if(_0x436275=this,_0x428eab(_0x50c999,_0x436275['key'])<0x0)!_0x436275['left']['isEmpty']()&&!_0x436275['left']['isRed_']()&&!_0x436275['left']['left']['isRed_']()&&(_0x436275=_0x436275['moveRedLeft_']()),_0x436275=_0x436275['copy'](null,null,null,_0x436275['left']['remove'](_0x50c999,_0x428eab),null);else{if(_0x436275['left']['isRed_']()&&(_0x436275=_0x436275['rotateRight_']()),!_0x436275['right']['isEmpty']()&&!_0x436275['right']['isRed_']()&&!_0x436275['right']['left']['isRed_']()&&(_0x436275=_0x436275['moveRedRight_']()),_0x428eab(_0x50c999,_0x436275['key'])===0x0){if(_0x436275['right']['isEmpty']())return B['EMPTY_NODE'];_0x340d98=_0x436275['right']['min_'](),_0x436275=_0x436275['copy'](_0x340d98['key'],_0x340d98['value'],null,null,_0x436275['right']['removeMin_']());}_0x436275=_0x436275['copy'](null,null,null,null,_0x436275['right']['remove'](_0x50c999,_0x428eab));}return _0x436275['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1dcb08=this;return _0x1dcb08['right']['isRed_']()&&!_0x1dcb08['left']['isRed_']()&&(_0x1dcb08=_0x1dcb08['rotateLeft_']()),_0x1dcb08['left']['isRed_']()&&_0x1dcb08['left']['left']['isRed_']()&&(_0x1dcb08=_0x1dcb08['rotateRight_']()),_0x1dcb08['left']['isRed_']()&&_0x1dcb08['right']['isRed_']()&&(_0x1dcb08=_0x1dcb08['colorFlip_']()),_0x1dcb08;}['moveRedLeft_'](){let _0x344465=this['colorFlip_']();return _0x344465['right']['left']['isRed_']()&&(_0x344465=_0x344465['copy'](null,null,null,null,_0x344465['right']['rotateRight_']()),_0x344465=_0x344465['rotateLeft_'](),_0x344465=_0x344465['colorFlip_']()),_0x344465;}['moveRedRight_'](){let _0x191d9e=this['colorFlip_']();return _0x191d9e['left']['left']['isRed_']()&&(_0x191d9e=_0x191d9e['rotateRight_'](),_0x191d9e=_0x191d9e['colorFlip_']()),_0x191d9e;}['rotateLeft_'](){const _0x510a13=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x510a13,null);}['rotateRight_'](){const _0x506639=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x506639);}['colorFlip_'](){const _0x513cd2=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x575e4b=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x513cd2,_0x575e4b);}['checkMaxDepth_'](){const _0x1875bb=this['check_']();return Math['pow'](0x2,_0x1875bb)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x7f4058=this['left']['check_']();if(_0x7f4058!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x7f4058+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x2c0d13,_0x5370d6,_0x3930a1,_0x301545,_0x43e85e){return this;}['insert'](_0xb744dd,_0x335e6c,_0x2216a6){return new M(_0xb744dd,_0x335e6c,null);}['remove'](_0x3c1f7c,_0x4fa65f){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x285e4c){return!0x1;}['reverseTraversal'](_0x5d4e56){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x435c38,_0x5eaa35=B['EMPTY_NODE']){this['comparator_']=_0x435c38,this['root_']=_0x5eaa35;}['insert'](_0x58d20d,_0x1f494f){return new B(this['comparator_'],this['root_']['insert'](_0x58d20d,_0x1f494f,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x28a15b){return new B(this['comparator_'],this['root_']['remove'](_0x28a15b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x34ae4b){let _0x22d3bd,_0x24b3ca=this['root_'];for(;!_0x24b3ca['isEmpty']();){if(_0x22d3bd=this['comparator_'](_0x34ae4b,_0x24b3ca['key']),_0x22d3bd===0x0)return _0x24b3ca['value'];_0x22d3bd<0x0?_0x24b3ca=_0x24b3ca['left']:_0x22d3bd>0x0&&(_0x24b3ca=_0x24b3ca['right']);}return null;}['getPredecessorKey'](_0x237500){let _0x21e4e0,_0x527435=this['root_'],_0x3b4875=null;for(;!_0x527435['isEmpty']();)if(_0x21e4e0=this['comparator_'](_0x237500,_0x527435['key']),_0x21e4e0===0x0){if(_0x527435['left']['isEmpty']())return _0x3b4875?_0x3b4875['key']:null;for(_0x527435=_0x527435['left'];!_0x527435['right']['isEmpty']();)_0x527435=_0x527435['right'];return _0x527435['key'];}else _0x21e4e0<0x0?_0x527435=_0x527435['left']:_0x21e4e0>0x0&&(_0x3b4875=_0x527435,_0x527435=_0x527435['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x479f1a){return this['root_']['inorderTraversal'](_0x479f1a);}['reverseTraversal'](_0xd1fea2){return this['root_']['reverseTraversal'](_0xd1fea2);}['getIterator'](_0x55a50b){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x55a50b);}['getIteratorFrom'](_0x1f50f9,_0x617982){return new Zt(this['root_'],_0x1f50f9,this['comparator_'],!0x1,_0x617982);}['getReverseIteratorFrom'](_0x4e20b7,_0x251743){return new Zt(this['root_'],_0x4e20b7,this['comparator_'],!0x0,_0x251743);}['getReverseIterator'](_0x314840){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x314840);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x1a3a86,_0x408630){return He(_0x1a3a86['name'],_0x408630['name']);}function ji(_0x4bf04e,_0xf4dfd3){return He(_0x4bf04e,_0xf4dfd3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x295189){vi=_0x295189;}const Ro=function(_0x1d483c){return typeof _0x1d483c=='number'?'number:'+so(_0x1d483c):'string:'+_0x1d483c;},Ao=function(_0x1701de){if(_0x1701de['isLeafNode']()){const _0x55a91c=_0x1701de['val']();f(typeof _0x55a91c=='string'||typeof _0x55a91c=='number'||typeof _0x55a91c=='object'&&Y(_0x55a91c,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x1701de===vi||_0x1701de['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x1701de===vi||_0x1701de['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x2b612c){er=_0x2b612c;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x1c1ae6,_0x5e4eec=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x1c1ae6,this['priorityNode_']=_0x5e4eec,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5e68ae){return new D(this['value_'],_0x5e68ae);}['getImmediateChild'](_0xb92b20){return _0xb92b20==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x16b546){return v(_0x16b546)?this:y(_0x16b546)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x29867f,_0x64773e){return null;}['updateImmediateChild'](_0x5d6d83,_0x42e813){return _0x5d6d83==='.priority'?this['updatePriority'](_0x42e813):_0x42e813['isEmpty']()&&_0x5d6d83!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5d6d83,_0x42e813)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2036ca,_0x275d9d){const _0x586b48=y(_0x2036ca);return _0x586b48===null?_0x275d9d:_0x275d9d['isEmpty']()&&_0x586b48!=='.priority'?this:(f(_0x586b48!=='.priority'||we(_0x2036ca)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x586b48,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x2036ca),_0x275d9d)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3bea96,_0x36c2b1){return!0x1;}['val'](_0x205e0e){return _0x205e0e&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1397fe='';this['priorityNode_']['isEmpty']()||(_0x1397fe+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x462455=typeof this['value_'];_0x1397fe+=_0x462455+':',_0x462455==='number'?_0x1397fe+=so(this['value_']):_0x1397fe+=this['value_'],this['lazyHash_']=no(_0x1397fe);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x5800f2){return _0x5800f2===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x5800f2 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x5800f2['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x5800f2));}['compareToLeafNode_'](_0x1d2b5b){const _0x55aba7=typeof _0x1d2b5b['value_'],_0x47ac79=typeof this['value_'],_0x3ead09=D['VALUE_TYPE_ORDER']['indexOf'](_0x55aba7),_0x1e193f=D['VALUE_TYPE_ORDER']['indexOf'](_0x47ac79);return f(_0x3ead09>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x55aba7),f(_0x1e193f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x47ac79),_0x3ead09===_0x1e193f?_0x47ac79==='object'?0x0:this['value_']<_0x1d2b5b['value_']?-0x1:this['value_']===_0x1d2b5b['value_']?0x0:0x1:_0x1e193f-_0x3ead09;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x102840){if(_0x102840===this)return!0x0;if(_0x102840['isLeafNode']()){const _0x1d82ec=_0x102840;return this['value_']===_0x1d82ec['value_']&&this['priorityNode_']['equals'](_0x1d82ec['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x55fd3a){ko=_0x55fd3a;}function xh(_0x228f97){No=_0x228f97;}class Fh extends On{['compare'](_0x4322e9,_0x5be585){const _0x27d34e=_0x4322e9['node']['getPriority'](),_0x5752c9=_0x5be585['node']['getPriority'](),_0x5cb761=_0x27d34e['compareTo'](_0x5752c9);return _0x5cb761===0x0?He(_0x4322e9['name'],_0x5be585['name']):_0x5cb761;}['isDefinedOn'](_0x283319){return!_0x283319['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x422102,_0x21f0a2){return!_0x422102['getPriority']()['equals'](_0x21f0a2['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x753d9a,_0x2df6f4){const _0x529995=ko(_0x753d9a);return new E(_0x2df6f4,new D('[PRIORITY-POST]',_0x529995));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x7830a9){const _0x12f774=_0x3a59a0=>parseInt(Math['log'](_0x3a59a0)/Uh,0xa),_0x5145e4=_0x17d32c=>parseInt(Array(_0x17d32c+0x1)['join']('1'),0x2);this['count']=_0x12f774(_0x7830a9+0x1),this['current_']=this['count']-0x1;const _0x4aae04=_0x5145e4(this['count']);this['bits_']=_0x7830a9+0x1&_0x4aae04;}['nextBitIsOne'](){const _0x26e085=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x26e085;}}const dn=function(_0x592a8b,_0x1e8c31,_0x17a858,_0x428550){_0x592a8b['sort'](_0x1e8c31);const _0x412ed9=function(_0x46980e,_0x25bc5b){const _0x3cdeee=_0x25bc5b-_0x46980e;let _0x4e36b8,_0x300da1;if(_0x3cdeee===0x0)return null;if(_0x3cdeee===0x1)return _0x4e36b8=_0x592a8b[_0x46980e],_0x300da1=_0x17a858?_0x17a858(_0x4e36b8):_0x4e36b8,new M(_0x300da1,_0x4e36b8['node'],M['BLACK'],null,null);{const _0x3095ea=parseInt(_0x3cdeee/0x2,0xa)+_0x46980e,_0x5709f3=_0x412ed9(_0x46980e,_0x3095ea),_0x23f1a0=_0x412ed9(_0x3095ea+0x1,_0x25bc5b);return _0x4e36b8=_0x592a8b[_0x3095ea],_0x300da1=_0x17a858?_0x17a858(_0x4e36b8):_0x4e36b8,new M(_0x300da1,_0x4e36b8['node'],M['BLACK'],_0x5709f3,_0x23f1a0);}},_0x202f1b=function(_0x3556b2){let _0x13f1ad=null,_0x5d7772=null,_0x529220=_0x592a8b['length'];const _0xe30acb=function(_0x462e37,_0x2aac23){const _0xeacd7b=_0x529220-_0x462e37,_0xd0be49=_0x529220;_0x529220-=_0x462e37;const _0x26afd6=_0x412ed9(_0xeacd7b+0x1,_0xd0be49),_0x5b8fcd=_0x592a8b[_0xeacd7b],_0x4fdd51=_0x17a858?_0x17a858(_0x5b8fcd):_0x5b8fcd;_0x1cf521(new M(_0x4fdd51,_0x5b8fcd['node'],_0x2aac23,null,_0x26afd6));},_0x1cf521=function(_0x5a1455){_0x13f1ad?(_0x13f1ad['left']=_0x5a1455,_0x13f1ad=_0x5a1455):(_0x5d7772=_0x5a1455,_0x13f1ad=_0x5a1455);};for(let _0x1480ea=0x0;_0x1480ea<_0x3556b2['count'];++_0x1480ea){const _0x5d25d7=_0x3556b2['nextBitIsOne'](),_0x484692=Math['pow'](0x2,_0x3556b2['count']-(_0x1480ea+0x1));_0x5d25d7?_0xe30acb(_0x484692,M['BLACK']):(_0xe30acb(_0x484692,M['BLACK']),_0xe30acb(_0x484692,M['RED']));}return _0x5d7772;},_0x142c64=new Wh(_0x592a8b['length']),_0x12e25e=_0x202f1b(_0x142c64);return new B(_0x428550||_0x1e8c31,_0x12e25e);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x9140fc,_0x311d0d){this['indexes_']=_0x9140fc,this['indexSet_']=_0x311d0d;}['get'](_0x5d0f45){const _0x4f0e0b=Oe(this['indexes_'],_0x5d0f45);if(!_0x4f0e0b)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5d0f45);return _0x4f0e0b instanceof B?_0x4f0e0b:null;}['hasIndex'](_0x3c0ebb){return Y(this['indexSet_'],_0x3c0ebb['toString']());}['addIndex'](_0x321024,_0x237939){f(_0x321024!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2b8fbf=[];let _0x5273f9=!0x1;const _0x2c6ee8=_0x237939['getIterator'](E['Wrap']);let _0x1f5c88=_0x2c6ee8['getNext']();for(;_0x1f5c88;)_0x5273f9=_0x5273f9||_0x321024['isDefinedOn'](_0x1f5c88['node']),_0x2b8fbf['push'](_0x1f5c88),_0x1f5c88=_0x2c6ee8['getNext']();let _0x37236c;_0x5273f9?_0x37236c=dn(_0x2b8fbf,_0x321024['getCompare']()):_0x37236c=je;const _0x1e6b44=_0x321024['toString'](),_0xbe1b6b={...this['indexSet_']};_0xbe1b6b[_0x1e6b44]=_0x321024;const _0x421a36={...this['indexes_']};return _0x421a36[_0x1e6b44]=_0x37236c,new ee(_0x421a36,_0xbe1b6b);}['addToIndexes'](_0x3f268d,_0x1b5132){const _0x44706f=ln(this['indexes_'],(_0x5354e9,_0xcfb8cf)=>{const _0x822328=Oe(this['indexSet_'],_0xcfb8cf);if(f(_0x822328,'Missing\x20index\x20implementation\x20for\x20'+_0xcfb8cf),_0x5354e9===je){if(_0x822328['isDefinedOn'](_0x3f268d['node'])){const _0x4da925=[],_0x4b526c=_0x1b5132['getIterator'](E['Wrap']);let _0x1a6e5b=_0x4b526c['getNext']();for(;_0x1a6e5b;)_0x1a6e5b['name']!==_0x3f268d['name']&&_0x4da925['push'](_0x1a6e5b),_0x1a6e5b=_0x4b526c['getNext']();return _0x4da925['push'](_0x3f268d),dn(_0x4da925,_0x822328['getCompare']());}else return je;}else{const _0x2d72fa=_0x1b5132['get'](_0x3f268d['name']);let _0x12b2bc=_0x5354e9;return _0x2d72fa&&(_0x12b2bc=_0x12b2bc['remove'](new E(_0x3f268d['name'],_0x2d72fa))),_0x12b2bc['insert'](_0x3f268d,_0x3f268d['node']);}});return new ee(_0x44706f,this['indexSet_']);}['removeFromIndexes'](_0x29aa38,_0x197bee){const _0x359d86=ln(this['indexes_'],_0x3858c1=>{if(_0x3858c1===je)return _0x3858c1;{const _0x5738c1=_0x197bee['get'](_0x29aa38['name']);return _0x5738c1?_0x3858c1['remove'](new E(_0x29aa38['name'],_0x5738c1)):_0x3858c1;}});return new ee(_0x359d86,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x588249,_0x51e7ef,_0x24e2b8){this['children_']=_0x588249,this['priorityNode_']=_0x51e7ef,this['indexMap_']=_0x24e2b8,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x68e41){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x68e41,this['indexMap_']);}['getImmediateChild'](_0x53d339){if(_0x53d339==='.priority')return this['getPriority']();{const _0x5d4061=this['children_']['get'](_0x53d339);return _0x5d4061===null?gt:_0x5d4061;}}['getChild'](_0x315bb6){const _0x19c7da=y(_0x315bb6);return _0x19c7da===null?this:this['getImmediateChild'](_0x19c7da)['getChild'](b(_0x315bb6));}['hasChild'](_0x272821){return this['children_']['get'](_0x272821)!==null;}['updateImmediateChild'](_0x342102,_0x459e7d){if(f(_0x459e7d,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x342102==='.priority')return this['updatePriority'](_0x459e7d);{const _0x26a1b1=new E(_0x342102,_0x459e7d);let _0x458307,_0x166ab5;_0x459e7d['isEmpty']()?(_0x458307=this['children_']['remove'](_0x342102),_0x166ab5=this['indexMap_']['removeFromIndexes'](_0x26a1b1,this['children_'])):(_0x458307=this['children_']['insert'](_0x342102,_0x459e7d),_0x166ab5=this['indexMap_']['addToIndexes'](_0x26a1b1,this['children_']));const _0x364fee=_0x458307['isEmpty']()?gt:this['priorityNode_'];return new g(_0x458307,_0x364fee,_0x166ab5);}}['updateChild'](_0x411e0a,_0x58303d){const _0x2c10a0=y(_0x411e0a);if(_0x2c10a0===null)return _0x58303d;{f(y(_0x411e0a)!=='.priority'||we(_0x411e0a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5eabe0=this['getImmediateChild'](_0x2c10a0)['updateChild'](b(_0x411e0a),_0x58303d);return this['updateImmediateChild'](_0x2c10a0,_0x5eabe0);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x723fed){if(this['isEmpty']())return null;const _0x194862={};let _0x5aee35=0x0,_0x4e5f31=0x0,_0x3923e2=!0x0;if(this['forEachChild'](R,(_0x4e3267,_0x1f5b42)=>{_0x194862[_0x4e3267]=_0x1f5b42['val'](_0x723fed),_0x5aee35++,_0x3923e2&&g['INTEGER_REGEXP_']['test'](_0x4e3267)?_0x4e5f31=Math['max'](_0x4e5f31,Number(_0x4e3267)):_0x3923e2=!0x1;}),!_0x723fed&&_0x3923e2&&_0x4e5f31<0x2*_0x5aee35){const _0x58d148=[];for(const _0x441400 in _0x194862)_0x58d148[_0x441400]=_0x194862[_0x441400];return _0x58d148;}else return _0x723fed&&!this['getPriority']()['isEmpty']()&&(_0x194862['.priority']=this['getPriority']()['val']()),_0x194862;}['hash'](){if(this['lazyHash_']===null){let _0x2cd6f3='';this['getPriority']()['isEmpty']()||(_0x2cd6f3+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x3fd7c2,_0x353428)=>{const _0x31de8a=_0x353428['hash']();_0x31de8a!==''&&(_0x2cd6f3+=':'+_0x3fd7c2+':'+_0x31de8a);}),this['lazyHash_']=_0x2cd6f3===''?'':no(_0x2cd6f3);}return this['lazyHash_'];}['getPredecessorChildName'](_0x43e1f8,_0x47e05f,_0x564ca1){const _0xf15bb1=this['resolveIndex_'](_0x564ca1);if(_0xf15bb1){const _0x43e880=_0xf15bb1['getPredecessorKey'](new E(_0x43e1f8,_0x47e05f));return _0x43e880?_0x43e880['name']:null;}else return this['children_']['getPredecessorKey'](_0x43e1f8);}['getFirstChildName'](_0x75f907){const _0x108f6b=this['resolveIndex_'](_0x75f907);if(_0x108f6b){const _0x11cc02=_0x108f6b['minKey']();return _0x11cc02&&_0x11cc02['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x9b7942){const _0x2aad63=this['getFirstChildName'](_0x9b7942);return _0x2aad63?new E(_0x2aad63,this['children_']['get'](_0x2aad63)):null;}['getLastChildName'](_0x752a53){const _0x326f86=this['resolveIndex_'](_0x752a53);if(_0x326f86){const _0x1eb13a=_0x326f86['maxKey']();return _0x1eb13a&&_0x1eb13a['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x10dfe6){const _0x14d718=this['getLastChildName'](_0x10dfe6);return _0x14d718?new E(_0x14d718,this['children_']['get'](_0x14d718)):null;}['forEachChild'](_0x4aa123,_0x12b5d6){const _0x4495bf=this['resolveIndex_'](_0x4aa123);return _0x4495bf?_0x4495bf['inorderTraversal'](_0x2e4d41=>_0x12b5d6(_0x2e4d41['name'],_0x2e4d41['node'])):this['children_']['inorderTraversal'](_0x12b5d6);}['getIterator'](_0x2812f2){return this['getIteratorFrom'](_0x2812f2['minPost'](),_0x2812f2);}['getIteratorFrom'](_0x3e3bbc,_0x2303cc){const _0xa4e28a=this['resolveIndex_'](_0x2303cc);if(_0xa4e28a)return _0xa4e28a['getIteratorFrom'](_0x3e3bbc,_0x1b9fa9=>_0x1b9fa9);{const _0x5832e7=this['children_']['getIteratorFrom'](_0x3e3bbc['name'],E['Wrap']);let _0x4c1100=_0x5832e7['peek']();for(;_0x4c1100!=null&&_0x2303cc['compare'](_0x4c1100,_0x3e3bbc)<0x0;)_0x5832e7['getNext'](),_0x4c1100=_0x5832e7['peek']();return _0x5832e7;}}['getReverseIterator'](_0x21c9ea){return this['getReverseIteratorFrom'](_0x21c9ea['maxPost'](),_0x21c9ea);}['getReverseIteratorFrom'](_0x213374,_0x199625){const _0x3e68e3=this['resolveIndex_'](_0x199625);if(_0x3e68e3)return _0x3e68e3['getReverseIteratorFrom'](_0x213374,_0x2bedcc=>_0x2bedcc);{const _0x351e96=this['children_']['getReverseIteratorFrom'](_0x213374['name'],E['Wrap']);let _0x2f5727=_0x351e96['peek']();for(;_0x2f5727!=null&&_0x199625['compare'](_0x2f5727,_0x213374)>0x0;)_0x351e96['getNext'](),_0x2f5727=_0x351e96['peek']();return _0x351e96;}}['compareTo'](_0x15c8bc){return this['isEmpty']()?_0x15c8bc['isEmpty']()?0x0:-0x1:_0x15c8bc['isLeafNode']()||_0x15c8bc['isEmpty']()?0x1:_0x15c8bc===Ht?-0x1:0x0;}['withIndex'](_0xca2b70){if(_0xca2b70===ye||this['indexMap_']['hasIndex'](_0xca2b70))return this;{const _0x4e9cf9=this['indexMap_']['addIndex'](_0xca2b70,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x4e9cf9);}}['isIndexed'](_0x123fc3){return _0x123fc3===ye||this['indexMap_']['hasIndex'](_0x123fc3);}['equals'](_0x5e6661){if(_0x5e6661===this)return!0x0;if(_0x5e6661['isLeafNode']())return!0x1;{const _0x5b9501=_0x5e6661;if(this['getPriority']()['equals'](_0x5b9501['getPriority']())){if(this['children_']['count']()===_0x5b9501['children_']['count']()){const _0x2f6310=this['getIterator'](R),_0x12956e=_0x5b9501['getIterator'](R);let _0x4d0134=_0x2f6310['getNext'](),_0x325c82=_0x12956e['getNext']();for(;_0x4d0134&&_0x325c82;){if(_0x4d0134['name']!==_0x325c82['name']||!_0x4d0134['node']['equals'](_0x325c82['node']))return!0x1;_0x4d0134=_0x2f6310['getNext'](),_0x325c82=_0x12956e['getNext']();}return _0x4d0134===null&&_0x325c82===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x549876){return _0x549876===ye?null:this['indexMap_']['get'](_0x549876['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x40dfdd){return _0x40dfdd===this?0x0:0x1;}['equals'](_0x243200){return _0x243200===this;}['getPriority'](){return this;}['getImmediateChild'](_0x31b2a8){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x26d1bf,_0x1aad70=null){if(_0x26d1bf===null)return g['EMPTY_NODE'];if(typeof _0x26d1bf=='object'&&'.priority'in _0x26d1bf&&(_0x1aad70=_0x26d1bf['.priority']),f(_0x1aad70===null||typeof _0x1aad70=='string'||typeof _0x1aad70=='number'||typeof _0x1aad70=='object'&&'.sv'in _0x1aad70,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1aad70),typeof _0x26d1bf=='object'&&'.value'in _0x26d1bf&&_0x26d1bf['.value']!==null&&(_0x26d1bf=_0x26d1bf['.value']),typeof _0x26d1bf!='object'||'.sv'in _0x26d1bf){const _0x2e43cb=_0x26d1bf;return new D(_0x2e43cb,N(_0x1aad70));}if(!(_0x26d1bf instanceof Array)&&Vh){const _0x2b3e51=[];let _0x1719a0=!0x1;if(x(_0x26d1bf,(_0x597831,_0x1abbf4)=>{if(_0x597831['substring'](0x0,0x1)!=='.'){const _0x5e1b64=N(_0x1abbf4);_0x5e1b64['isEmpty']()||(_0x1719a0=_0x1719a0||!_0x5e1b64['getPriority']()['isEmpty'](),_0x2b3e51['push'](new E(_0x597831,_0x5e1b64)));}}),_0x2b3e51['length']===0x0)return g['EMPTY_NODE'];const _0x4fa77c=dn(_0x2b3e51,Dh,_0x5d7993=>_0x5d7993['name'],ji);if(_0x1719a0){const _0x58b7f7=dn(_0x2b3e51,R['getCompare']());return new g(_0x4fa77c,N(_0x1aad70),new ee({'.priority':_0x58b7f7},{'.priority':R}));}else return new g(_0x4fa77c,N(_0x1aad70),ee['Default']);}else{let _0x43fd28=g['EMPTY_NODE'];return x(_0x26d1bf,(_0x57188c,_0x6e4ebe)=>{if(Y(_0x26d1bf,_0x57188c)&&_0x57188c['substring'](0x0,0x1)!=='.'){const _0x12f2c=N(_0x6e4ebe);(_0x12f2c['isLeafNode']()||!_0x12f2c['isEmpty']())&&(_0x43fd28=_0x43fd28['updateImmediateChild'](_0x57188c,_0x12f2c));}}),_0x43fd28['updatePriority'](N(_0x1aad70));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x25b016){super(),this['indexPath_']=_0x25b016,f(!v(_0x25b016)&&y(_0x25b016)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2f3d2b){return _0x2f3d2b['getChild'](this['indexPath_']);}['isDefinedOn'](_0x47d51f){return!_0x47d51f['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2b814c,_0x21fda2){const _0x5774b9=this['extractChild'](_0x2b814c['node']),_0x4dc058=this['extractChild'](_0x21fda2['node']),_0x13c989=_0x5774b9['compareTo'](_0x4dc058);return _0x13c989===0x0?He(_0x2b814c['name'],_0x21fda2['name']):_0x13c989;}['makePost'](_0xdd4571,_0x6c9987){const _0x588c07=N(_0xdd4571),_0xb08960=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x588c07);return new E(_0x6c9987,_0xb08960);}['maxPost'](){const _0x12f9b0=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x12f9b0);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x4362a0,_0x245328){const _0x5a549b=_0x4362a0['node']['compareTo'](_0x245328['node']);return _0x5a549b===0x0?He(_0x4362a0['name'],_0x245328['name']):_0x5a549b;}['isDefinedOn'](_0x13812d){return!0x0;}['indexedValueChanged'](_0x17046f,_0x144acd){return!_0x17046f['equals'](_0x144acd);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x9063bd,_0x4031e9){const _0x28ff16=N(_0x9063bd);return new E(_0x4031e9,_0x28ff16);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x346aeb){return{'type':'value','snapshotNode':_0x346aeb};}function tt(_0x5c206e,_0x1926c4){return{'type':'child_added','snapshotNode':_0x1926c4,'childName':_0x5c206e};}function Nt(_0x53ab82,_0x53f5a6){return{'type':'child_removed','snapshotNode':_0x53f5a6,'childName':_0x53ab82};}function Pt(_0x46b8c1,_0x2df474,_0x485709){return{'type':'child_changed','snapshotNode':_0x2df474,'childName':_0x46b8c1,'oldSnap':_0x485709};}function $h(_0x508f4e,_0x398654){return{'type':'child_moved','snapshotNode':_0x398654,'childName':_0x508f4e};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x46e585){this['index_']=_0x46e585;}['updateChild'](_0x39dc79,_0x1a2482,_0x1ff183,_0x20ac2d,_0x4ea96e,_0x3e684a){f(_0x39dc79['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x559a6e=_0x39dc79['getImmediateChild'](_0x1a2482);return _0x559a6e['getChild'](_0x20ac2d)['equals'](_0x1ff183['getChild'](_0x20ac2d))&&_0x559a6e['isEmpty']()===_0x1ff183['isEmpty']()||(_0x3e684a!=null&&(_0x1ff183['isEmpty']()?_0x39dc79['hasChild'](_0x1a2482)?_0x3e684a['trackChildChange'](Nt(_0x1a2482,_0x559a6e)):f(_0x39dc79['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x559a6e['isEmpty']()?_0x3e684a['trackChildChange'](tt(_0x1a2482,_0x1ff183)):_0x3e684a['trackChildChange'](Pt(_0x1a2482,_0x1ff183,_0x559a6e))),_0x39dc79['isLeafNode']()&&_0x1ff183['isEmpty']())?_0x39dc79:_0x39dc79['updateImmediateChild'](_0x1a2482,_0x1ff183)['withIndex'](this['index_']);}['updateFullNode'](_0x15d7da,_0x505a7d,_0x20e718){return _0x20e718!=null&&(_0x15d7da['isLeafNode']()||_0x15d7da['forEachChild'](R,(_0x15b607,_0x2d9465)=>{_0x505a7d['hasChild'](_0x15b607)||_0x20e718['trackChildChange'](Nt(_0x15b607,_0x2d9465));}),_0x505a7d['isLeafNode']()||_0x505a7d['forEachChild'](R,(_0x500ae9,_0x41fa21)=>{if(_0x15d7da['hasChild'](_0x500ae9)){const _0x3fc755=_0x15d7da['getImmediateChild'](_0x500ae9);_0x3fc755['equals'](_0x41fa21)||_0x20e718['trackChildChange'](Pt(_0x500ae9,_0x41fa21,_0x3fc755));}else _0x20e718['trackChildChange'](tt(_0x500ae9,_0x41fa21));})),_0x505a7d['withIndex'](this['index_']);}['updatePriority'](_0x2d1823,_0x268349){return _0x2d1823['isEmpty']()?g['EMPTY_NODE']:_0x2d1823['updatePriority'](_0x268349);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x484685){this['indexedFilter_']=new Yi(_0x484685['getIndex']()),this['index_']=_0x484685['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x484685),this['endPost_']=Ot['getEndPost_'](_0x484685),this['startIsInclusive_']=!_0x484685['startAfterSet_'],this['endIsInclusive_']=!_0x484685['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x23d1ae){const _0x411acc=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x23d1ae)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x23d1ae)<0x0,_0x28725d=this['endIsInclusive_']?this['index_']['compare'](_0x23d1ae,this['getEndPost']())<=0x0:this['index_']['compare'](_0x23d1ae,this['getEndPost']())<0x0;return _0x411acc&&_0x28725d;}['updateChild'](_0x4ce2dd,_0x2d2288,_0x3ca512,_0x576bdf,_0x4968e4,_0xd75949){return this['matches'](new E(_0x2d2288,_0x3ca512))||(_0x3ca512=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4ce2dd,_0x2d2288,_0x3ca512,_0x576bdf,_0x4968e4,_0xd75949);}['updateFullNode'](_0x1279a5,_0x16c751,_0x46644c){_0x16c751['isLeafNode']()&&(_0x16c751=g['EMPTY_NODE']);let _0x27b3f1=_0x16c751['withIndex'](this['index_']);_0x27b3f1=_0x27b3f1['updatePriority'](g['EMPTY_NODE']);const _0x28b1ac=this;return _0x16c751['forEachChild'](R,(_0x20085c,_0x346187)=>{_0x28b1ac['matches'](new E(_0x20085c,_0x346187))||(_0x27b3f1=_0x27b3f1['updateImmediateChild'](_0x20085c,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1279a5,_0x27b3f1,_0x46644c);}['updatePriority'](_0x4eff39,_0x563949){return _0x4eff39;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x1bbeb9){if(_0x1bbeb9['hasStart']()){const _0x395e27=_0x1bbeb9['getIndexStartName']();return _0x1bbeb9['getIndex']()['makePost'](_0x1bbeb9['getIndexStartValue'](),_0x395e27);}else return _0x1bbeb9['getIndex']()['minPost']();}static['getEndPost_'](_0x3f9bb2){if(_0x3f9bb2['hasEnd']()){const _0x14228e=_0x3f9bb2['getIndexEndName']();return _0x3f9bb2['getIndex']()['makePost'](_0x3f9bb2['getIndexEndValue'](),_0x14228e);}else return _0x3f9bb2['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x373f1d){this['withinDirectionalStart']=_0x87bb7b=>this['reverse_']?this['withinEndPost'](_0x87bb7b):this['withinStartPost'](_0x87bb7b),this['withinDirectionalEnd']=_0x5b7806=>this['reverse_']?this['withinStartPost'](_0x5b7806):this['withinEndPost'](_0x5b7806),this['withinStartPost']=_0x4e5431=>{const _0x48393c=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x4e5431);return this['startIsInclusive_']?_0x48393c<=0x0:_0x48393c<0x0;},this['withinEndPost']=_0x21fee2=>{const _0x27f822=this['index_']['compare'](_0x21fee2,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x27f822<=0x0:_0x27f822<0x0;},this['rangedFilter_']=new Ot(_0x373f1d),this['index_']=_0x373f1d['getIndex'](),this['limit_']=_0x373f1d['getLimit'](),this['reverse_']=!_0x373f1d['isViewFromLeft'](),this['startIsInclusive_']=!_0x373f1d['startAfterSet_'],this['endIsInclusive_']=!_0x373f1d['endBeforeSet_'];}['updateChild'](_0x4f5bab,_0x239830,_0x5f2c40,_0x2d5d42,_0x162852,_0x5792e7){return this['rangedFilter_']['matches'](new E(_0x239830,_0x5f2c40))||(_0x5f2c40=g['EMPTY_NODE']),_0x4f5bab['getImmediateChild'](_0x239830)['equals'](_0x5f2c40)?_0x4f5bab:_0x4f5bab['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x4f5bab,_0x239830,_0x5f2c40,_0x2d5d42,_0x162852,_0x5792e7):this['fullLimitUpdateChild_'](_0x4f5bab,_0x239830,_0x5f2c40,_0x162852,_0x5792e7);}['updateFullNode'](_0x53a7dc,_0x2c4ab8,_0x240932){let _0x39a4cf;if(_0x2c4ab8['isLeafNode']()||_0x2c4ab8['isEmpty']())_0x39a4cf=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2c4ab8['numChildren']()&&_0x2c4ab8['isIndexed'](this['index_'])){_0x39a4cf=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x598e63;this['reverse_']?_0x598e63=_0x2c4ab8['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x598e63=_0x2c4ab8['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xda034a=0x0;for(;_0x598e63['hasNext']()&&_0xda034a<this['limit_'];){const _0x129a92=_0x598e63['getNext']();if(this['withinDirectionalStart'](_0x129a92)){if(this['withinDirectionalEnd'](_0x129a92))_0x39a4cf=_0x39a4cf['updateImmediateChild'](_0x129a92['name'],_0x129a92['node']),_0xda034a++;else break;}else continue;}}else{_0x39a4cf=_0x2c4ab8['withIndex'](this['index_']),_0x39a4cf=_0x39a4cf['updatePriority'](g['EMPTY_NODE']);let _0x4688f7;this['reverse_']?_0x4688f7=_0x39a4cf['getReverseIterator'](this['index_']):_0x4688f7=_0x39a4cf['getIterator'](this['index_']);let _0x40ea9e=0x0;for(;_0x4688f7['hasNext']();){const _0x4aaaea=_0x4688f7['getNext']();_0x40ea9e<this['limit_']&&this['withinDirectionalStart'](_0x4aaaea)&&this['withinDirectionalEnd'](_0x4aaaea)?_0x40ea9e++:_0x39a4cf=_0x39a4cf['updateImmediateChild'](_0x4aaaea['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x53a7dc,_0x39a4cf,_0x240932);}['updatePriority'](_0x8ec19a,_0x11ac14){return _0x8ec19a;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x57349a,_0x3f5b44,_0x1f0b11,_0x41571e,_0x38e8d0){let _0x397594;if(this['reverse_']){const _0x136413=this['index_']['getCompare']();_0x397594=(_0x1493b5,_0x1f4398)=>_0x136413(_0x1f4398,_0x1493b5);}else _0x397594=this['index_']['getCompare']();const _0x3a078d=_0x57349a;f(_0x3a078d['numChildren']()===this['limit_'],'');const _0x4bbe56=new E(_0x3f5b44,_0x1f0b11),_0x1fa8e5=this['reverse_']?_0x3a078d['getFirstChild'](this['index_']):_0x3a078d['getLastChild'](this['index_']),_0x109204=this['rangedFilter_']['matches'](_0x4bbe56);if(_0x3a078d['hasChild'](_0x3f5b44)){const _0x144138=_0x3a078d['getImmediateChild'](_0x3f5b44);let _0xfd33a0=_0x41571e['getChildAfterChild'](this['index_'],_0x1fa8e5,this['reverse_']);for(;_0xfd33a0!=null&&(_0xfd33a0['name']===_0x3f5b44||_0x3a078d['hasChild'](_0xfd33a0['name']));)_0xfd33a0=_0x41571e['getChildAfterChild'](this['index_'],_0xfd33a0,this['reverse_']);const _0x2d938e=_0xfd33a0==null?0x1:_0x397594(_0xfd33a0,_0x4bbe56);if(_0x109204&&!_0x1f0b11['isEmpty']()&&_0x2d938e>=0x0)return _0x38e8d0!=null&&_0x38e8d0['trackChildChange'](Pt(_0x3f5b44,_0x1f0b11,_0x144138)),_0x3a078d['updateImmediateChild'](_0x3f5b44,_0x1f0b11);{_0x38e8d0!=null&&_0x38e8d0['trackChildChange'](Nt(_0x3f5b44,_0x144138));const _0x5e479a=_0x3a078d['updateImmediateChild'](_0x3f5b44,g['EMPTY_NODE']);return _0xfd33a0!=null&&this['rangedFilter_']['matches'](_0xfd33a0)?(_0x38e8d0!=null&&_0x38e8d0['trackChildChange'](tt(_0xfd33a0['name'],_0xfd33a0['node'])),_0x5e479a['updateImmediateChild'](_0xfd33a0['name'],_0xfd33a0['node'])):_0x5e479a;}}else return _0x1f0b11['isEmpty']()?_0x57349a:_0x109204&&_0x397594(_0x1fa8e5,_0x4bbe56)>=0x0?(_0x38e8d0!=null&&(_0x38e8d0['trackChildChange'](Nt(_0x1fa8e5['name'],_0x1fa8e5['node'])),_0x38e8d0['trackChildChange'](tt(_0x3f5b44,_0x1f0b11))),_0x3a078d['updateImmediateChild'](_0x3f5b44,_0x1f0b11)['updateImmediateChild'](_0x1fa8e5['name'],g['EMPTY_NODE'])):_0x57349a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x2723e8=new Qi();return _0x2723e8['limitSet_']=this['limitSet_'],_0x2723e8['limit_']=this['limit_'],_0x2723e8['startSet_']=this['startSet_'],_0x2723e8['startAfterSet_']=this['startAfterSet_'],_0x2723e8['indexStartValue_']=this['indexStartValue_'],_0x2723e8['startNameSet_']=this['startNameSet_'],_0x2723e8['indexStartName_']=this['indexStartName_'],_0x2723e8['endSet_']=this['endSet_'],_0x2723e8['endBeforeSet_']=this['endBeforeSet_'],_0x2723e8['indexEndValue_']=this['indexEndValue_'],_0x2723e8['endNameSet_']=this['endNameSet_'],_0x2723e8['indexEndName_']=this['indexEndName_'],_0x2723e8['index_']=this['index_'],_0x2723e8['viewFrom_']=this['viewFrom_'],_0x2723e8;}}function qh(_0x402967){return _0x402967['loadsAllData']()?new Yi(_0x402967['getIndex']()):_0x402967['hasLimit']()?new Gh(_0x402967):new Ot(_0x402967);}function zh(_0x1d50be,_0xb4ff5b){const _0x3bfd3c=_0x1d50be['copy']();return _0x3bfd3c['limitSet_']=!0x0,_0x3bfd3c['limit_']=_0xb4ff5b,_0x3bfd3c['viewFrom_']='l',_0x3bfd3c;}function jh(_0x1fc034,_0x4b3505,_0x130034){const _0x11f687=_0x1fc034['copy']();return _0x11f687['startSet_']=!0x0,_0x4b3505===void 0x0&&(_0x4b3505=null),_0x11f687['indexStartValue_']=_0x4b3505,_0x130034!=null?(_0x11f687['startNameSet_']=!0x0,_0x11f687['indexStartName_']=_0x130034):(_0x11f687['startNameSet_']=!0x1,_0x11f687['indexStartName_']=''),_0x11f687;}function Kh(_0x31f625,_0x119c2f,_0x5b0b53){const _0x8f5c3d=_0x31f625['copy']();return _0x8f5c3d['endSet_']=!0x0,_0x119c2f===void 0x0&&(_0x119c2f=null),_0x8f5c3d['indexEndValue_']=_0x119c2f,_0x5b0b53!==void 0x0?(_0x8f5c3d['endNameSet_']=!0x0,_0x8f5c3d['indexEndName_']=_0x5b0b53):(_0x8f5c3d['endNameSet_']=!0x1,_0x8f5c3d['indexEndName_']=''),_0x8f5c3d;}function Do(_0x11c6a4,_0x52ff6b){const _0x46f3a8=_0x11c6a4['copy']();return _0x46f3a8['index_']=_0x52ff6b,_0x46f3a8;}function tr(_0xeaa4ca){const _0x530a16={};if(_0xeaa4ca['isDefault']())return _0x530a16;let _0x4f0aa7;if(_0xeaa4ca['index_']===R?_0x4f0aa7='$priority':_0xeaa4ca['index_']===Po?_0x4f0aa7='$value':_0xeaa4ca['index_']===ye?_0x4f0aa7='$key':(f(_0xeaa4ca['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x4f0aa7=_0xeaa4ca['index_']['toString']()),_0x530a16['orderBy']=O(_0x4f0aa7),_0xeaa4ca['startSet_']){const _0x31f912=_0xeaa4ca['startAfterSet_']?'startAfter':'startAt';_0x530a16[_0x31f912]=O(_0xeaa4ca['indexStartValue_']),_0xeaa4ca['startNameSet_']&&(_0x530a16[_0x31f912]+=','+O(_0xeaa4ca['indexStartName_']));}if(_0xeaa4ca['endSet_']){const _0x34c6cc=_0xeaa4ca['endBeforeSet_']?'endBefore':'endAt';_0x530a16[_0x34c6cc]=O(_0xeaa4ca['indexEndValue_']),_0xeaa4ca['endNameSet_']&&(_0x530a16[_0x34c6cc]+=','+O(_0xeaa4ca['indexEndName_']));}return _0xeaa4ca['limitSet_']&&(_0xeaa4ca['isViewFromLeft']()?_0x530a16['limitToFirst']=_0xeaa4ca['limit_']:_0x530a16['limitToLast']=_0xeaa4ca['limit_']),_0x530a16;}function nr(_0x24fb4b){const _0x3c65fb={};if(_0x24fb4b['startSet_']&&(_0x3c65fb['sp']=_0x24fb4b['indexStartValue_'],_0x24fb4b['startNameSet_']&&(_0x3c65fb['sn']=_0x24fb4b['indexStartName_']),_0x3c65fb['sin']=!_0x24fb4b['startAfterSet_']),_0x24fb4b['endSet_']&&(_0x3c65fb['ep']=_0x24fb4b['indexEndValue_'],_0x24fb4b['endNameSet_']&&(_0x3c65fb['en']=_0x24fb4b['indexEndName_']),_0x3c65fb['ein']=!_0x24fb4b['endBeforeSet_']),_0x24fb4b['limitSet_']){_0x3c65fb['l']=_0x24fb4b['limit_'];let _0x369a2a=_0x24fb4b['viewFrom_'];_0x369a2a===''&&(_0x24fb4b['isViewFromLeft']()?_0x369a2a='l':_0x369a2a='r'),_0x3c65fb['vf']=_0x369a2a;}return _0x24fb4b['index_']!==R&&(_0x3c65fb['i']=_0x24fb4b['index_']['toString']()),_0x3c65fb;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x5bcfa8){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4f7693,_0x36bd56){return _0x36bd56!==void 0x0?'tag$'+_0x36bd56:(f(_0x4f7693['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4f7693['_path']['toString']());}constructor(_0x198bfd,_0x489e72,_0x1fd592,_0x20d1ec){super(),this['repoInfo_']=_0x198bfd,this['onDataUpdate_']=_0x489e72,this['authTokenProvider_']=_0x1fd592,this['appCheckTokenProvider_']=_0x20d1ec,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x22c2a9,_0x16bbff,_0x2b7ee1,_0xef13c9){const _0x40502a=_0x22c2a9['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x40502a+'\x20'+_0x22c2a9['_queryIdentifier']);const _0x5c2266=fn['getListenId_'](_0x22c2a9,_0x2b7ee1),_0x1cc92f={};this['listens_'][_0x5c2266]=_0x1cc92f;const _0x29b62d=tr(_0x22c2a9['_queryParams']);this['restRequest_'](_0x40502a+'.json',_0x29b62d,(_0xd8a84c,_0x2efb14)=>{let _0x406b85=_0x2efb14;if(_0xd8a84c===0x194&&(_0x406b85=null,_0xd8a84c=null),_0xd8a84c===null&&this['onDataUpdate_'](_0x40502a,_0x406b85,!0x1,_0x2b7ee1),Oe(this['listens_'],_0x5c2266)===_0x1cc92f){let _0x17947f;_0xd8a84c?_0xd8a84c===0x191?_0x17947f='permission_denied':_0x17947f='rest_error:'+_0xd8a84c:_0x17947f='ok',_0xef13c9(_0x17947f,null);}});}['unlisten'](_0x2ad8,_0x1d0050){const _0x973678=fn['getListenId_'](_0x2ad8,_0x1d0050);delete this['listens_'][_0x973678];}['get'](_0x1259a9){const _0x57b625=tr(_0x1259a9['_queryParams']),_0xb46f93=_0x1259a9['_path']['toString'](),_0x593395=new Ve();return this['restRequest_'](_0xb46f93+'.json',_0x57b625,(_0x3d36f9,_0x3014d9)=>{let _0x3c13ca=_0x3014d9;_0x3d36f9===0x194&&(_0x3c13ca=null,_0x3d36f9=null),_0x3d36f9===null?(this['onDataUpdate_'](_0xb46f93,_0x3c13ca,!0x1,null),_0x593395['resolve'](_0x3c13ca)):_0x593395['reject'](new Error(_0x3c13ca));}),_0x593395['promise'];}['refreshAuthToken'](_0x436220){}['restRequest_'](_0x810d4e,_0x4ddf78={},_0x277fc0){return _0x4ddf78['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x105a7a,_0x58ef89])=>{_0x105a7a&&_0x105a7a['accessToken']&&(_0x4ddf78['auth']=_0x105a7a['accessToken']),_0x58ef89&&_0x58ef89['token']&&(_0x4ddf78['ac']=_0x58ef89['token']);const _0x13a4ea=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x810d4e+'?ns='+this['repoInfo_']['namespace']+at(_0x4ddf78);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x13a4ea);const _0x393996=new XMLHttpRequest();_0x393996['onreadystatechange']=()=>{if(_0x277fc0&&_0x393996['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x13a4ea+'\x20received.\x20status:',_0x393996['status'],'response:',_0x393996['responseText']);let _0x53bb4c=null;if(_0x393996['status']>=0xc8&&_0x393996['status']<0x12c){try{_0x53bb4c=bt(_0x393996['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x13a4ea+':\x20'+_0x393996['responseText']);}_0x277fc0(null,_0x53bb4c);}else _0x393996['status']!==0x191&&_0x393996['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x13a4ea+'\x20Status:\x20'+_0x393996['status']),_0x277fc0(_0x393996['status']);_0x277fc0=null;}},_0x393996['open']('GET',_0x13a4ea,!0x0),_0x393996['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x57b1db){return this['rootNode_']['getChild'](_0x57b1db);}['updateSnapshot'](_0x419f4a,_0x265ba3){this['rootNode_']=this['rootNode_']['updateChild'](_0x419f4a,_0x265ba3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x33b218,_0x581b78,_0xfc62d9){if(v(_0x581b78))_0x33b218['value']=_0xfc62d9,_0x33b218['children']['clear']();else{if(_0x33b218['value']!==null)_0x33b218['value']=_0x33b218['value']['updateChild'](_0x581b78,_0xfc62d9);else{const _0x34feff=y(_0x581b78);_0x33b218['children']['has'](_0x34feff)||_0x33b218['children']['set'](_0x34feff,pn());const _0x472b6a=_0x33b218['children']['get'](_0x34feff);_0x581b78=b(_0x581b78),Mo(_0x472b6a,_0x581b78,_0xfc62d9);}}}function Ei(_0x1a952f,_0x1a28a9,_0x2b10bb){_0x1a952f['value']!==null?_0x2b10bb(_0x1a28a9,_0x1a952f['value']):Qh(_0x1a952f,(_0x2c7052,_0x5b1c74)=>{const _0x411bf2=new C(_0x1a28a9['toString']()+'/'+_0x2c7052);Ei(_0x5b1c74,_0x411bf2,_0x2b10bb);});}function Qh(_0x4abef0,_0x1c221c){_0x4abef0['children']['forEach']((_0x199692,_0x23d1ad)=>{_0x1c221c(_0x23d1ad,_0x199692);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x23e96f){this['collection_']=_0x23e96f,this['last_']=null;}['get'](){const _0x24d084=this['collection_']['get'](),_0x365f6e={..._0x24d084};return this['last_']&&x(this['last_'],(_0x3a2ff6,_0x35c3bd)=>{_0x365f6e[_0x3a2ff6]=_0x365f6e[_0x3a2ff6]-_0x35c3bd;}),this['last_']=_0x24d084,_0x365f6e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x452c38,_0x1c03b6){this['server_']=_0x1c03b6,this['statsToReport_']={},this['statsListener_']=new Jh(_0x452c38);const _0x179861=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x179861));}['reportStats_'](){const _0x5af35f=this['statsListener_']['get'](),_0x326eaf={};let _0x1237e5=!0x1;x(_0x5af35f,(_0x42bbcd,_0x37d283)=>{_0x37d283>0x0&&Y(this['statsToReport_'],_0x42bbcd)&&(_0x326eaf[_0x42bbcd]=_0x37d283,_0x1237e5=!0x0);}),_0x1237e5&&this['server_']['reportStats'](_0x326eaf),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x253a75){_0x253a75[_0x253a75['OVERWRITE']=0x0]='OVERWRITE',_0x253a75[_0x253a75['MERGE']=0x1]='MERGE',_0x253a75[_0x253a75['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x253a75[_0x253a75['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x20e6f3){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x20e6f3,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x552e30,_0x420239,_0x496a71){this['path']=_0x552e30,this['affectedTree']=_0x420239,this['revert']=_0x496a71,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x21050e){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3edd21=this['affectedTree']['subtree'](new C(_0x21050e));return new _n(w(),_0x3edd21,this['revert']);}}else return f(y(this['path'])===_0x21050e,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x127744,_0x4e7e46){this['source']=_0x127744,this['path']=_0x4e7e46,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x479261){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x6658fe,_0x1595b2,_0x1b7536){this['source']=_0x6658fe,this['path']=_0x1595b2,this['snap']=_0x1b7536,this['type']=q['OVERWRITE'];}['operationForChild'](_0x33686d){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x33686d)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x22a84f,_0xa8b91b,_0xaad8e6){this['source']=_0x22a84f,this['path']=_0xa8b91b,this['children']=_0xaad8e6,this['type']=q['MERGE'];}['operationForChild'](_0x1b1b28){if(v(this['path'])){const _0x1e8a29=this['children']['subtree'](new C(_0x1b1b28));return _0x1e8a29['isEmpty']()?null:_0x1e8a29['value']?new Fe(this['source'],w(),_0x1e8a29['value']):new nt(this['source'],w(),_0x1e8a29);}else return f(y(this['path'])===_0x1b1b28,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x3d0cd0,_0x409910,_0x353929){this['node_']=_0x3d0cd0,this['fullyInitialized_']=_0x409910,this['filtered_']=_0x353929;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1ed8aa){if(v(_0x1ed8aa))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3785c5=y(_0x1ed8aa);return this['isCompleteForChild'](_0x3785c5);}['isCompleteForChild'](_0x33e52d){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x33e52d);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x300216){this['query_']=_0x300216,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x3cbf3f,_0x110c84,_0x1bd8e4,_0xfa9634){const _0xd823d0=[],_0xd00ff1=[];return _0x110c84['forEach'](_0xbba170=>{_0xbba170['type']==='child_changed'&&_0x3cbf3f['index_']['indexedValueChanged'](_0xbba170['oldSnap'],_0xbba170['snapshotNode'])&&_0xd00ff1['push']($h(_0xbba170['childName'],_0xbba170['snapshotNode']));}),mt(_0x3cbf3f,_0xd823d0,'child_removed',_0x110c84,_0xfa9634,_0x1bd8e4),mt(_0x3cbf3f,_0xd823d0,'child_added',_0x110c84,_0xfa9634,_0x1bd8e4),mt(_0x3cbf3f,_0xd823d0,'child_moved',_0xd00ff1,_0xfa9634,_0x1bd8e4),mt(_0x3cbf3f,_0xd823d0,'child_changed',_0x110c84,_0xfa9634,_0x1bd8e4),mt(_0x3cbf3f,_0xd823d0,'value',_0x110c84,_0xfa9634,_0x1bd8e4),_0xd823d0;}function mt(_0x1c5299,_0x58001f,_0x3492a7,_0x27a558,_0x5292d3,_0x192fbb){const _0x16f1dd=_0x27a558['filter'](_0x3261b0=>_0x3261b0['type']===_0x3492a7);_0x16f1dd['sort']((_0x2a7a3d,_0x341714)=>su(_0x1c5299,_0x2a7a3d,_0x341714)),_0x16f1dd['forEach'](_0xc48a0f=>{const _0x15d133=iu(_0x1c5299,_0xc48a0f,_0x192fbb);_0x5292d3['forEach'](_0xf3a5ef=>{_0xf3a5ef['respondsTo'](_0xc48a0f['type'])&&_0x58001f['push'](_0xf3a5ef['createEvent'](_0x15d133,_0x1c5299['query_']));});});}function iu(_0x374a51,_0x2fc5bb,_0x524126){return _0x2fc5bb['type']==='value'||_0x2fc5bb['type']==='child_removed'||(_0x2fc5bb['prevName']=_0x524126['getPredecessorChildName'](_0x2fc5bb['childName'],_0x2fc5bb['snapshotNode'],_0x374a51['index_'])),_0x2fc5bb;}function su(_0x465d28,_0x35c679,_0x128262){if(_0x35c679['childName']==null||_0x128262['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x406396=new E(_0x35c679['childName'],_0x35c679['snapshotNode']),_0x57bfab=new E(_0x128262['childName'],_0x128262['snapshotNode']);return _0x465d28['index_']['compare'](_0x406396,_0x57bfab);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x5d12f4,_0x5ef9c9){return{'eventCache':_0x5d12f4,'serverCache':_0x5ef9c9};}function wt(_0x470361,_0x23e5d5,_0x37e1cd,_0x2b9814){return Dn(new Ce(_0x23e5d5,_0x37e1cd,_0x2b9814),_0x470361['serverCache']);}function Lo(_0x35ad8,_0x3f95c6,_0x2447ed,_0x5889e6){return Dn(_0x35ad8['eventCache'],new Ce(_0x3f95c6,_0x2447ed,_0x5889e6));}function gn(_0x28f4ed){return _0x28f4ed['eventCache']['isFullyInitialized']()?_0x28f4ed['eventCache']['getNode']():null;}function Ue(_0x246341){return _0x246341['serverCache']['isFullyInitialized']()?_0x246341['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x441739){let _0x1ddb93=new S(null);return x(_0x441739,(_0x16bccb,_0x310067)=>{_0x1ddb93=_0x1ddb93['set'](new C(_0x16bccb),_0x310067);}),_0x1ddb93;}constructor(_0x5aee51,_0x5618db=ru()){this['value']=_0x5aee51,this['children']=_0x5618db;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x242ab8,_0x1d468b){if(this['value']!=null&&_0x1d468b(this['value']))return{'path':w(),'value':this['value']};if(v(_0x242ab8))return null;{const _0x2d4307=y(_0x242ab8),_0x47b3f6=this['children']['get'](_0x2d4307);if(_0x47b3f6!==null){const _0xfa4bb2=_0x47b3f6['findRootMostMatchingPathAndValue'](b(_0x242ab8),_0x1d468b);return _0xfa4bb2!=null?{'path':A(new C(_0x2d4307),_0xfa4bb2['path']),'value':_0xfa4bb2['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x35a9bb){return this['findRootMostMatchingPathAndValue'](_0x35a9bb,()=>!0x0);}['subtree'](_0x3a2e58){if(v(_0x3a2e58))return this;{const _0x46798f=y(_0x3a2e58),_0x2a19d4=this['children']['get'](_0x46798f);return _0x2a19d4!==null?_0x2a19d4['subtree'](b(_0x3a2e58)):new S(null);}}['set'](_0x3df10e,_0x2318a7){if(v(_0x3df10e))return new S(_0x2318a7,this['children']);{const _0x24dd05=y(_0x3df10e),_0x5d280b=(this['children']['get'](_0x24dd05)||new S(null))['set'](b(_0x3df10e),_0x2318a7),_0x5d9bb0=this['children']['insert'](_0x24dd05,_0x5d280b);return new S(this['value'],_0x5d9bb0);}}['remove'](_0x39e746){if(v(_0x39e746))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x408145=y(_0x39e746),_0x50a0dd=this['children']['get'](_0x408145);if(_0x50a0dd){const _0x5f48eb=_0x50a0dd['remove'](b(_0x39e746));let _0x39fcc1;return _0x5f48eb['isEmpty']()?_0x39fcc1=this['children']['remove'](_0x408145):_0x39fcc1=this['children']['insert'](_0x408145,_0x5f48eb),this['value']===null&&_0x39fcc1['isEmpty']()?new S(null):new S(this['value'],_0x39fcc1);}else return this;}}['get'](_0x4046a4){if(v(_0x4046a4))return this['value'];{const _0x334ddc=y(_0x4046a4),_0x9c036d=this['children']['get'](_0x334ddc);return _0x9c036d?_0x9c036d['get'](b(_0x4046a4)):null;}}['setTree'](_0xab9778,_0x12845d){if(v(_0xab9778))return _0x12845d;{const _0x121ae4=y(_0xab9778),_0xbcee3e=(this['children']['get'](_0x121ae4)||new S(null))['setTree'](b(_0xab9778),_0x12845d);let _0x26197d;return _0xbcee3e['isEmpty']()?_0x26197d=this['children']['remove'](_0x121ae4):_0x26197d=this['children']['insert'](_0x121ae4,_0xbcee3e),new S(this['value'],_0x26197d);}}['fold'](_0x48dbd0){return this['fold_'](w(),_0x48dbd0);}['fold_'](_0xa42daf,_0x1f8f16){const _0x3652ef={};return this['children']['inorderTraversal']((_0x146c7b,_0x10a3f9)=>{_0x3652ef[_0x146c7b]=_0x10a3f9['fold_'](A(_0xa42daf,_0x146c7b),_0x1f8f16);}),_0x1f8f16(_0xa42daf,this['value'],_0x3652ef);}['findOnPath'](_0x297e7a,_0x4c26cb){return this['findOnPath_'](_0x297e7a,w(),_0x4c26cb);}['findOnPath_'](_0x23d009,_0x2e417a,_0x8af167){const _0x2c8c93=this['value']?_0x8af167(_0x2e417a,this['value']):!0x1;if(_0x2c8c93)return _0x2c8c93;if(v(_0x23d009))return null;{const _0x3e0452=y(_0x23d009),_0x3c16d6=this['children']['get'](_0x3e0452);return _0x3c16d6?_0x3c16d6['findOnPath_'](b(_0x23d009),A(_0x2e417a,_0x3e0452),_0x8af167):null;}}['foreachOnPath'](_0x312e21,_0x224e6a){return this['foreachOnPath_'](_0x312e21,w(),_0x224e6a);}['foreachOnPath_'](_0xee4564,_0x296d70,_0x41e396){if(v(_0xee4564))return this;{this['value']&&_0x41e396(_0x296d70,this['value']);const _0x275e5d=y(_0xee4564),_0x30dd46=this['children']['get'](_0x275e5d);return _0x30dd46?_0x30dd46['foreachOnPath_'](b(_0xee4564),A(_0x296d70,_0x275e5d),_0x41e396):new S(null);}}['foreach'](_0x406b79){this['foreach_'](w(),_0x406b79);}['foreach_'](_0x5bb24e,_0x3b977c){this['children']['inorderTraversal']((_0x3b30f2,_0x11c739)=>{_0x11c739['foreach_'](A(_0x5bb24e,_0x3b30f2),_0x3b977c);}),this['value']&&_0x3b977c(_0x5bb24e,this['value']);}['foreachChild'](_0x19d910){this['children']['inorderTraversal']((_0xe22621,_0x17835b)=>{_0x17835b['value']&&_0x19d910(_0xe22621,_0x17835b['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x29dcc1){this['writeTree_']=_0x29dcc1;}static['empty'](){return new j(new S(null));}}function Ct(_0x36def6,_0x178400,_0x495771){if(v(_0x178400))return new j(new S(_0x495771));{const _0x286dfc=_0x36def6['writeTree_']['findRootMostValueAndPath'](_0x178400);if(_0x286dfc!=null){const _0x70fc=_0x286dfc['path'];let _0x3a8f3b=_0x286dfc['value'];const _0x405ae7=F(_0x70fc,_0x178400);return _0x3a8f3b=_0x3a8f3b['updateChild'](_0x405ae7,_0x495771),new j(_0x36def6['writeTree_']['set'](_0x70fc,_0x3a8f3b));}else{const _0x18fbd5=new S(_0x495771),_0x24ca7e=_0x36def6['writeTree_']['setTree'](_0x178400,_0x18fbd5);return new j(_0x24ca7e);}}}function Ii(_0x4e4984,_0x36975f,_0x5b3b3c){let _0x5ba269=_0x4e4984;return x(_0x5b3b3c,(_0x5a3b06,_0x22fb7b)=>{_0x5ba269=Ct(_0x5ba269,A(_0x36975f,_0x5a3b06),_0x22fb7b);}),_0x5ba269;}function sr(_0x486250,_0x241edb){if(v(_0x241edb))return j['empty']();{const _0x98c3db=_0x486250['writeTree_']['setTree'](_0x241edb,new S(null));return new j(_0x98c3db);}}function wi(_0x57b6d4,_0x1e965f){return $e(_0x57b6d4,_0x1e965f)!=null;}function $e(_0x55777a,_0x5b4da6){const _0x4d0a5b=_0x55777a['writeTree_']['findRootMostValueAndPath'](_0x5b4da6);return _0x4d0a5b!=null?_0x55777a['writeTree_']['get'](_0x4d0a5b['path'])['getChild'](F(_0x4d0a5b['path'],_0x5b4da6)):null;}function rr(_0x2cc602){const _0x4f74b4=[],_0x450a8e=_0x2cc602['writeTree_']['value'];return _0x450a8e!=null?_0x450a8e['isLeafNode']()||_0x450a8e['forEachChild'](R,(_0x144f04,_0x5bc844)=>{_0x4f74b4['push'](new E(_0x144f04,_0x5bc844));}):_0x2cc602['writeTree_']['children']['inorderTraversal']((_0x11618c,_0x121dcb)=>{_0x121dcb['value']!=null&&_0x4f74b4['push'](new E(_0x11618c,_0x121dcb['value']));}),_0x4f74b4;}function ve(_0x3d5427,_0x18f6b2){if(v(_0x18f6b2))return _0x3d5427;{const _0xfa537e=$e(_0x3d5427,_0x18f6b2);return _0xfa537e!=null?new j(new S(_0xfa537e)):new j(_0x3d5427['writeTree_']['subtree'](_0x18f6b2));}}function Ci(_0x2f47b7){return _0x2f47b7['writeTree_']['isEmpty']();}function it(_0x4b31fb,_0x273cb1){return xo(w(),_0x4b31fb['writeTree_'],_0x273cb1);}function xo(_0x18f8bc,_0x57c0b2,_0x2f168b){if(_0x57c0b2['value']!=null)return _0x2f168b['updateChild'](_0x18f8bc,_0x57c0b2['value']);{let _0x15d678=null;return _0x57c0b2['children']['inorderTraversal']((_0x4f72fb,_0x52ed15)=>{_0x4f72fb==='.priority'?(f(_0x52ed15['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x15d678=_0x52ed15['value']):_0x2f168b=xo(A(_0x18f8bc,_0x4f72fb),_0x52ed15,_0x2f168b);}),!_0x2f168b['getChild'](_0x18f8bc)['isEmpty']()&&_0x15d678!==null&&(_0x2f168b=_0x2f168b['updateChild'](A(_0x18f8bc,'.priority'),_0x15d678)),_0x2f168b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x337207,_0x5eb71a){return Bo(_0x5eb71a,_0x337207);}function ou(_0x3f74f7,_0x2abf06,_0x3e6daa,_0x4ebd5d,_0x4f5321){f(_0x4ebd5d>_0x3f74f7['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x4f5321===void 0x0&&(_0x4f5321=!0x0),_0x3f74f7['allWrites']['push']({'path':_0x2abf06,'snap':_0x3e6daa,'writeId':_0x4ebd5d,'visible':_0x4f5321}),_0x4f5321&&(_0x3f74f7['visibleWrites']=Ct(_0x3f74f7['visibleWrites'],_0x2abf06,_0x3e6daa)),_0x3f74f7['lastWriteId']=_0x4ebd5d;}function au(_0x50799f,_0x4fea4a,_0x24127e,_0x4c665d){f(_0x4c665d>_0x50799f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x50799f['allWrites']['push']({'path':_0x4fea4a,'children':_0x24127e,'writeId':_0x4c665d,'visible':!0x0}),_0x50799f['visibleWrites']=Ii(_0x50799f['visibleWrites'],_0x4fea4a,_0x24127e),_0x50799f['lastWriteId']=_0x4c665d;}function cu(_0x321593,_0x488cc0){for(let _0x13145b=0x0;_0x13145b<_0x321593['allWrites']['length'];_0x13145b++){const _0x345240=_0x321593['allWrites'][_0x13145b];if(_0x345240['writeId']===_0x488cc0)return _0x345240;}return null;}function lu(_0x592095,_0x3e7808){const _0x2199c0=_0x592095['allWrites']['findIndex'](_0x1b6372=>_0x1b6372['writeId']===_0x3e7808);f(_0x2199c0>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4709e9=_0x592095['allWrites'][_0x2199c0];_0x592095['allWrites']['splice'](_0x2199c0,0x1);let _0x1313f6=_0x4709e9['visible'],_0x14c73c=!0x1,_0x196444=_0x592095['allWrites']['length']-0x1;for(;_0x1313f6&&_0x196444>=0x0;){const _0x474f9a=_0x592095['allWrites'][_0x196444];_0x474f9a['visible']&&(_0x196444>=_0x2199c0&&hu(_0x474f9a,_0x4709e9['path'])?_0x1313f6=!0x1:$(_0x4709e9['path'],_0x474f9a['path'])&&(_0x14c73c=!0x0)),_0x196444--;}if(_0x1313f6){if(_0x14c73c)return uu(_0x592095),!0x0;if(_0x4709e9['snap'])_0x592095['visibleWrites']=sr(_0x592095['visibleWrites'],_0x4709e9['path']);else{const _0x5c774e=_0x4709e9['children'];x(_0x5c774e,_0x479d62=>{_0x592095['visibleWrites']=sr(_0x592095['visibleWrites'],A(_0x4709e9['path'],_0x479d62));});}return!0x0;}else return!0x1;}function hu(_0x55d763,_0x50da4f){if(_0x55d763['snap'])return $(_0x55d763['path'],_0x50da4f);for(const _0x42eb73 in _0x55d763['children'])if(_0x55d763['children']['hasOwnProperty'](_0x42eb73)&&$(A(_0x55d763['path'],_0x42eb73),_0x50da4f))return!0x0;return!0x1;}function uu(_0x1bd806){_0x1bd806['visibleWrites']=Fo(_0x1bd806['allWrites'],du,w()),_0x1bd806['allWrites']['length']>0x0?_0x1bd806['lastWriteId']=_0x1bd806['allWrites'][_0x1bd806['allWrites']['length']-0x1]['writeId']:_0x1bd806['lastWriteId']=-0x1;}function du(_0x28a34b){return _0x28a34b['visible'];}function Fo(_0x5a229c,_0x120392,_0x30008e){let _0x573391=j['empty']();for(let _0xbf36f8=0x0;_0xbf36f8<_0x5a229c['length'];++_0xbf36f8){const _0x1d2902=_0x5a229c[_0xbf36f8];if(_0x120392(_0x1d2902)){const _0x40fd42=_0x1d2902['path'];let _0xc97cd0;if(_0x1d2902['snap'])$(_0x30008e,_0x40fd42)?(_0xc97cd0=F(_0x30008e,_0x40fd42),_0x573391=Ct(_0x573391,_0xc97cd0,_0x1d2902['snap'])):$(_0x40fd42,_0x30008e)&&(_0xc97cd0=F(_0x40fd42,_0x30008e),_0x573391=Ct(_0x573391,w(),_0x1d2902['snap']['getChild'](_0xc97cd0)));else{if(_0x1d2902['children']){if($(_0x30008e,_0x40fd42))_0xc97cd0=F(_0x30008e,_0x40fd42),_0x573391=Ii(_0x573391,_0xc97cd0,_0x1d2902['children']);else{if($(_0x40fd42,_0x30008e)){if(_0xc97cd0=F(_0x40fd42,_0x30008e),v(_0xc97cd0))_0x573391=Ii(_0x573391,w(),_0x1d2902['children']);else{const _0x17bba6=Oe(_0x1d2902['children'],y(_0xc97cd0));if(_0x17bba6){const _0x348440=_0x17bba6['getChild'](b(_0xc97cd0));_0x573391=Ct(_0x573391,w(),_0x348440);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x573391;}function Uo(_0x413bc6,_0xd18eff,_0x43b290,_0x4d6721,_0x1e2235){if(!_0x4d6721&&!_0x1e2235){const _0xea9fd7=$e(_0x413bc6['visibleWrites'],_0xd18eff);if(_0xea9fd7!=null)return _0xea9fd7;{const _0x407765=ve(_0x413bc6['visibleWrites'],_0xd18eff);if(Ci(_0x407765))return _0x43b290;if(_0x43b290==null&&!wi(_0x407765,w()))return null;{const _0x199e37=_0x43b290||g['EMPTY_NODE'];return it(_0x407765,_0x199e37);}}}else{const _0x498186=ve(_0x413bc6['visibleWrites'],_0xd18eff);if(!_0x1e2235&&Ci(_0x498186))return _0x43b290;if(!_0x1e2235&&_0x43b290==null&&!wi(_0x498186,w()))return null;{const _0x480e07=function(_0x3fb6bb){return(_0x3fb6bb['visible']||_0x1e2235)&&(!_0x4d6721||!~_0x4d6721['indexOf'](_0x3fb6bb['writeId']))&&($(_0x3fb6bb['path'],_0xd18eff)||$(_0xd18eff,_0x3fb6bb['path']));},_0x2c1003=Fo(_0x413bc6['allWrites'],_0x480e07,_0xd18eff),_0x4e856e=_0x43b290||g['EMPTY_NODE'];return it(_0x2c1003,_0x4e856e);}}}function fu(_0x223057,_0x29f9a7,_0x523621){let _0x346191=g['EMPTY_NODE'];const _0x2557ec=$e(_0x223057['visibleWrites'],_0x29f9a7);if(_0x2557ec)return _0x2557ec['isLeafNode']()||_0x2557ec['forEachChild'](R,(_0x4ee4ee,_0x41901e)=>{_0x346191=_0x346191['updateImmediateChild'](_0x4ee4ee,_0x41901e);}),_0x346191;if(_0x523621){const _0x496462=ve(_0x223057['visibleWrites'],_0x29f9a7);return _0x523621['forEachChild'](R,(_0x105339,_0x26f977)=>{const _0x1bd258=it(ve(_0x496462,new C(_0x105339)),_0x26f977);_0x346191=_0x346191['updateImmediateChild'](_0x105339,_0x1bd258);}),rr(_0x496462)['forEach'](_0x3f29d0=>{_0x346191=_0x346191['updateImmediateChild'](_0x3f29d0['name'],_0x3f29d0['node']);}),_0x346191;}else{const _0x4f7d72=ve(_0x223057['visibleWrites'],_0x29f9a7);return rr(_0x4f7d72)['forEach'](_0x35f7ba=>{_0x346191=_0x346191['updateImmediateChild'](_0x35f7ba['name'],_0x35f7ba['node']);}),_0x346191;}}function pu(_0x39c30e,_0x26572b,_0x2ac340,_0x26712a,_0x4140cb){f(_0x26712a||_0x4140cb,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1c2bc0=A(_0x26572b,_0x2ac340);if(wi(_0x39c30e['visibleWrites'],_0x1c2bc0))return null;{const _0x147744=ve(_0x39c30e['visibleWrites'],_0x1c2bc0);return Ci(_0x147744)?_0x4140cb['getChild'](_0x2ac340):it(_0x147744,_0x4140cb['getChild'](_0x2ac340));}}function _u(_0x2eeca3,_0x2fa8fa,_0x186dc8,_0x45fa43){const _0x287412=A(_0x2fa8fa,_0x186dc8),_0x3334ef=$e(_0x2eeca3['visibleWrites'],_0x287412);if(_0x3334ef!=null)return _0x3334ef;if(_0x45fa43['isCompleteForChild'](_0x186dc8)){const _0x43369d=ve(_0x2eeca3['visibleWrites'],_0x287412);return it(_0x43369d,_0x45fa43['getNode']()['getImmediateChild'](_0x186dc8));}else return null;}function gu(_0x30d563,_0x3a0041){return $e(_0x30d563['visibleWrites'],_0x3a0041);}function mu(_0xf98dbe,_0x29d8cd,_0x4f4bda,_0x21ea99,_0x5e9c4a,_0x13615b,_0x4ac834){let _0x45b00d;const _0x45871e=ve(_0xf98dbe['visibleWrites'],_0x29d8cd),_0x54e8b6=$e(_0x45871e,w());if(_0x54e8b6!=null)_0x45b00d=_0x54e8b6;else{if(_0x4f4bda!=null)_0x45b00d=it(_0x45871e,_0x4f4bda);else return[];}if(_0x45b00d=_0x45b00d['withIndex'](_0x4ac834),!_0x45b00d['isEmpty']()&&!_0x45b00d['isLeafNode']()){const _0xb5e1cd=[],_0x1c4f76=_0x4ac834['getCompare'](),_0x1651e8=_0x13615b?_0x45b00d['getReverseIteratorFrom'](_0x21ea99,_0x4ac834):_0x45b00d['getIteratorFrom'](_0x21ea99,_0x4ac834);let _0x292843=_0x1651e8['getNext']();for(;_0x292843&&_0xb5e1cd['length']<_0x5e9c4a;)_0x1c4f76(_0x292843,_0x21ea99)!==0x0&&_0xb5e1cd['push'](_0x292843),_0x292843=_0x1651e8['getNext']();return _0xb5e1cd;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x4402dc,_0x27c488,_0x1ff1ac,_0x234747){return Uo(_0x4402dc['writeTree'],_0x4402dc['treePath'],_0x27c488,_0x1ff1ac,_0x234747);}function es(_0x68a520,_0x599643){return fu(_0x68a520['writeTree'],_0x68a520['treePath'],_0x599643);}function or(_0x75fc42,_0x189ac4,_0x1d66e4,_0x5b0307){return pu(_0x75fc42['writeTree'],_0x75fc42['treePath'],_0x189ac4,_0x1d66e4,_0x5b0307);}function yn(_0x3c1866,_0x3ee4b4){return gu(_0x3c1866['writeTree'],A(_0x3c1866['treePath'],_0x3ee4b4));}function vu(_0x4fb5b0,_0x2980d7,_0xbe8786,_0x46e8a2,_0x4778d2,_0x444aca){return mu(_0x4fb5b0['writeTree'],_0x4fb5b0['treePath'],_0x2980d7,_0xbe8786,_0x46e8a2,_0x4778d2,_0x444aca);}function ts(_0x3969e9,_0x8346b6,_0x31fcac){return _u(_0x3969e9['writeTree'],_0x3969e9['treePath'],_0x8346b6,_0x31fcac);}function Wo(_0x520f67,_0x48db30){return Bo(A(_0x520f67['treePath'],_0x48db30),_0x520f67['writeTree']);}function Bo(_0x108747,_0x33c329){return{'treePath':_0x108747,'writeTree':_0x33c329};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x512483){const _0x28b76a=_0x512483['type'],_0x10270e=_0x512483['childName'];f(_0x28b76a==='child_added'||_0x28b76a==='child_changed'||_0x28b76a==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x10270e!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4c7e5d=this['changeMap']['get'](_0x10270e);if(_0x4c7e5d){const _0x27ad07=_0x4c7e5d['type'];if(_0x28b76a==='child_added'&&_0x27ad07==='child_removed')this['changeMap']['set'](_0x10270e,Pt(_0x10270e,_0x512483['snapshotNode'],_0x4c7e5d['snapshotNode']));else{if(_0x28b76a==='child_removed'&&_0x27ad07==='child_added')this['changeMap']['delete'](_0x10270e);else{if(_0x28b76a==='child_removed'&&_0x27ad07==='child_changed')this['changeMap']['set'](_0x10270e,Nt(_0x10270e,_0x4c7e5d['oldSnap']));else{if(_0x28b76a==='child_changed'&&_0x27ad07==='child_added')this['changeMap']['set'](_0x10270e,tt(_0x10270e,_0x512483['snapshotNode']));else{if(_0x28b76a==='child_changed'&&_0x27ad07==='child_changed')this['changeMap']['set'](_0x10270e,Pt(_0x10270e,_0x512483['snapshotNode'],_0x4c7e5d['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x512483+'\x20occurred\x20after\x20'+_0x4c7e5d);}}}}}else this['changeMap']['set'](_0x10270e,_0x512483);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x58988b){return null;}['getChildAfterChild'](_0x2bdecd,_0x85dc00,_0x2b7002){return null;}}const Vo=new Iu();class ns{constructor(_0x2cd012,_0x40f006,_0x263ea9=null){this['writes_']=_0x2cd012,this['viewCache_']=_0x40f006,this['optCompleteServerCache_']=_0x263ea9;}['getCompleteChild'](_0x1622e7){const _0x5277f7=this['viewCache_']['eventCache'];if(_0x5277f7['isCompleteForChild'](_0x1622e7))return _0x5277f7['getNode']()['getImmediateChild'](_0x1622e7);{const _0x152a72=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x1622e7,_0x152a72);}}['getChildAfterChild'](_0x5baf53,_0x2b53a8,_0x47bf44){const _0x2dbb43=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x5c1353=vu(this['writes_'],_0x2dbb43,_0x2b53a8,0x1,_0x47bf44,_0x5baf53);return _0x5c1353['length']===0x0?null:_0x5c1353[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x13bbbd){return{'filter':_0x13bbbd};}function Cu(_0x555f6d,_0x42a1b7){f(_0x42a1b7['eventCache']['getNode']()['isIndexed'](_0x555f6d['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x42a1b7['serverCache']['getNode']()['isIndexed'](_0x555f6d['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x173d3b,_0xae7c05,_0x458ecf,_0x5abdc4,_0x5345bb){const _0x44a8f3=new Eu();let _0x493574,_0x737580;if(_0x458ecf['type']===q['OVERWRITE']){const _0x29f2f0=_0x458ecf;_0x29f2f0['source']['fromUser']?_0x493574=Ti(_0x173d3b,_0xae7c05,_0x29f2f0['path'],_0x29f2f0['snap'],_0x5abdc4,_0x5345bb,_0x44a8f3):(f(_0x29f2f0['source']['fromServer'],'Unknown\x20source.'),_0x737580=_0x29f2f0['source']['tagged']||_0xae7c05['serverCache']['isFiltered']()&&!v(_0x29f2f0['path']),_0x493574=vn(_0x173d3b,_0xae7c05,_0x29f2f0['path'],_0x29f2f0['snap'],_0x5abdc4,_0x5345bb,_0x737580,_0x44a8f3));}else{if(_0x458ecf['type']===q['MERGE']){const _0x604a18=_0x458ecf;_0x604a18['source']['fromUser']?_0x493574=bu(_0x173d3b,_0xae7c05,_0x604a18['path'],_0x604a18['children'],_0x5abdc4,_0x5345bb,_0x44a8f3):(f(_0x604a18['source']['fromServer'],'Unknown\x20source.'),_0x737580=_0x604a18['source']['tagged']||_0xae7c05['serverCache']['isFiltered'](),_0x493574=Si(_0x173d3b,_0xae7c05,_0x604a18['path'],_0x604a18['children'],_0x5abdc4,_0x5345bb,_0x737580,_0x44a8f3));}else{if(_0x458ecf['type']===q['ACK_USER_WRITE']){const _0x52863e=_0x458ecf;_0x52863e['revert']?_0x493574=ku(_0x173d3b,_0xae7c05,_0x52863e['path'],_0x5abdc4,_0x5345bb,_0x44a8f3):_0x493574=Ru(_0x173d3b,_0xae7c05,_0x52863e['path'],_0x52863e['affectedTree'],_0x5abdc4,_0x5345bb,_0x44a8f3);}else{if(_0x458ecf['type']===q['LISTEN_COMPLETE'])_0x493574=Au(_0x173d3b,_0xae7c05,_0x458ecf['path'],_0x5abdc4,_0x44a8f3);else throw ot('Unknown\x20operation\x20type:\x20'+_0x458ecf['type']);}}}const _0x3b3056=_0x44a8f3['getChanges']();return Su(_0xae7c05,_0x493574,_0x3b3056),{'viewCache':_0x493574,'changes':_0x3b3056};}function Su(_0x34604b,_0x691cc9,_0x5752a9){const _0x4ea9ee=_0x691cc9['eventCache'];if(_0x4ea9ee['isFullyInitialized']()){const _0x133511=_0x4ea9ee['getNode']()['isLeafNode']()||_0x4ea9ee['getNode']()['isEmpty'](),_0x39b4b4=gn(_0x34604b);(_0x5752a9['length']>0x0||!_0x34604b['eventCache']['isFullyInitialized']()||_0x133511&&!_0x4ea9ee['getNode']()['equals'](_0x39b4b4)||!_0x4ea9ee['getNode']()['getPriority']()['equals'](_0x39b4b4['getPriority']()))&&_0x5752a9['push'](Oo(gn(_0x691cc9)));}}function Ho(_0x26ff16,_0x268793,_0x22ba32,_0x29f8d5,_0x5d8df6,_0xbd09aa){const _0x2f8c99=_0x268793['eventCache'];if(yn(_0x29f8d5,_0x22ba32)!=null)return _0x268793;{let _0x50d47a,_0x4d4cf7;if(v(_0x22ba32)){if(f(_0x268793['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x268793['serverCache']['isFiltered']()){const _0x566fa3=Ue(_0x268793),_0x2b43a7=_0x566fa3 instanceof g?_0x566fa3:g['EMPTY_NODE'],_0x55162d=es(_0x29f8d5,_0x2b43a7);_0x50d47a=_0x26ff16['filter']['updateFullNode'](_0x268793['eventCache']['getNode'](),_0x55162d,_0xbd09aa);}else{const _0x1a0838=mn(_0x29f8d5,Ue(_0x268793));_0x50d47a=_0x26ff16['filter']['updateFullNode'](_0x268793['eventCache']['getNode'](),_0x1a0838,_0xbd09aa);}}else{const _0x59976f=y(_0x22ba32);if(_0x59976f==='.priority'){f(we(_0x22ba32)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x39025e=_0x2f8c99['getNode']();_0x4d4cf7=_0x268793['serverCache']['getNode']();const _0x1dbedd=or(_0x29f8d5,_0x22ba32,_0x39025e,_0x4d4cf7);_0x1dbedd!=null?_0x50d47a=_0x26ff16['filter']['updatePriority'](_0x39025e,_0x1dbedd):_0x50d47a=_0x2f8c99['getNode']();}else{const _0x207e26=b(_0x22ba32);let _0x1e5f9d;if(_0x2f8c99['isCompleteForChild'](_0x59976f)){_0x4d4cf7=_0x268793['serverCache']['getNode']();const _0x20c50b=or(_0x29f8d5,_0x22ba32,_0x2f8c99['getNode'](),_0x4d4cf7);_0x20c50b!=null?_0x1e5f9d=_0x2f8c99['getNode']()['getImmediateChild'](_0x59976f)['updateChild'](_0x207e26,_0x20c50b):_0x1e5f9d=_0x2f8c99['getNode']()['getImmediateChild'](_0x59976f);}else _0x1e5f9d=ts(_0x29f8d5,_0x59976f,_0x268793['serverCache']);_0x1e5f9d!=null?_0x50d47a=_0x26ff16['filter']['updateChild'](_0x2f8c99['getNode'](),_0x59976f,_0x1e5f9d,_0x207e26,_0x5d8df6,_0xbd09aa):_0x50d47a=_0x2f8c99['getNode']();}}return wt(_0x268793,_0x50d47a,_0x2f8c99['isFullyInitialized']()||v(_0x22ba32),_0x26ff16['filter']['filtersNodes']());}}function vn(_0x44f617,_0x37da03,_0x31b446,_0x589b3c,_0x35cef8,_0x495df9,_0x5ca6c3,_0x4ac66e){const _0x5f1840=_0x37da03['serverCache'];let _0x4c554c;const _0xde20e3=_0x5ca6c3?_0x44f617['filter']:_0x44f617['filter']['getIndexedFilter']();if(v(_0x31b446))_0x4c554c=_0xde20e3['updateFullNode'](_0x5f1840['getNode'](),_0x589b3c,null);else{if(_0xde20e3['filtersNodes']()&&!_0x5f1840['isFiltered']()){const _0x47d0c8=_0x5f1840['getNode']()['updateChild'](_0x31b446,_0x589b3c);_0x4c554c=_0xde20e3['updateFullNode'](_0x5f1840['getNode'](),_0x47d0c8,null);}else{const _0x43f79d=y(_0x31b446);if(!_0x5f1840['isCompleteForPath'](_0x31b446)&&we(_0x31b446)>0x1)return _0x37da03;const _0x2dae36=b(_0x31b446),_0xc721d7=_0x5f1840['getNode']()['getImmediateChild'](_0x43f79d)['updateChild'](_0x2dae36,_0x589b3c);_0x43f79d==='.priority'?_0x4c554c=_0xde20e3['updatePriority'](_0x5f1840['getNode'](),_0xc721d7):_0x4c554c=_0xde20e3['updateChild'](_0x5f1840['getNode'](),_0x43f79d,_0xc721d7,_0x2dae36,Vo,null);}}const _0x2c14a2=Lo(_0x37da03,_0x4c554c,_0x5f1840['isFullyInitialized']()||v(_0x31b446),_0xde20e3['filtersNodes']()),_0x3a2c78=new ns(_0x35cef8,_0x2c14a2,_0x495df9);return Ho(_0x44f617,_0x2c14a2,_0x31b446,_0x35cef8,_0x3a2c78,_0x4ac66e);}function Ti(_0x5506ca,_0x4541fd,_0x16effb,_0x4a20bf,_0x4fd13a,_0x49a7f7,_0x5f59cd){const _0x146cc1=_0x4541fd['eventCache'];let _0x593479,_0x14f3bc;const _0xef3f63=new ns(_0x4fd13a,_0x4541fd,_0x49a7f7);if(v(_0x16effb))_0x14f3bc=_0x5506ca['filter']['updateFullNode'](_0x4541fd['eventCache']['getNode'](),_0x4a20bf,_0x5f59cd),_0x593479=wt(_0x4541fd,_0x14f3bc,!0x0,_0x5506ca['filter']['filtersNodes']());else{const _0x438906=y(_0x16effb);if(_0x438906==='.priority')_0x14f3bc=_0x5506ca['filter']['updatePriority'](_0x4541fd['eventCache']['getNode'](),_0x4a20bf),_0x593479=wt(_0x4541fd,_0x14f3bc,_0x146cc1['isFullyInitialized'](),_0x146cc1['isFiltered']());else{const _0x8419dd=b(_0x16effb),_0x373c7c=_0x146cc1['getNode']()['getImmediateChild'](_0x438906);let _0x11635b;if(v(_0x8419dd))_0x11635b=_0x4a20bf;else{const _0x46f3eb=_0xef3f63['getCompleteChild'](_0x438906);_0x46f3eb!=null?Gi(_0x8419dd)==='.priority'&&_0x46f3eb['getChild'](To(_0x8419dd))['isEmpty']()?_0x11635b=_0x46f3eb:_0x11635b=_0x46f3eb['updateChild'](_0x8419dd,_0x4a20bf):_0x11635b=g['EMPTY_NODE'];}if(_0x373c7c['equals'](_0x11635b))_0x593479=_0x4541fd;else{const _0x22411f=_0x5506ca['filter']['updateChild'](_0x146cc1['getNode'](),_0x438906,_0x11635b,_0x8419dd,_0xef3f63,_0x5f59cd);_0x593479=wt(_0x4541fd,_0x22411f,_0x146cc1['isFullyInitialized'](),_0x5506ca['filter']['filtersNodes']());}}}return _0x593479;}function ar(_0x21027d,_0x38b47c){return _0x21027d['eventCache']['isCompleteForChild'](_0x38b47c);}function bu(_0x51c7a2,_0x66ed79,_0x21d5ff,_0x118747,_0x4d0f44,_0x3c46b5,_0x12fb90){let _0x2c1910=_0x66ed79;return _0x118747['foreach']((_0x2e661e,_0x253449)=>{const _0x403051=A(_0x21d5ff,_0x2e661e);ar(_0x66ed79,y(_0x403051))&&(_0x2c1910=Ti(_0x51c7a2,_0x2c1910,_0x403051,_0x253449,_0x4d0f44,_0x3c46b5,_0x12fb90));}),_0x118747['foreach']((_0x39a3ff,_0x1faf3b)=>{const _0x2c4328=A(_0x21d5ff,_0x39a3ff);ar(_0x66ed79,y(_0x2c4328))||(_0x2c1910=Ti(_0x51c7a2,_0x2c1910,_0x2c4328,_0x1faf3b,_0x4d0f44,_0x3c46b5,_0x12fb90));}),_0x2c1910;}function cr(_0x57f45e,_0x132685,_0x48762a){return _0x48762a['foreach']((_0x38a9f4,_0x574af3)=>{_0x132685=_0x132685['updateChild'](_0x38a9f4,_0x574af3);}),_0x132685;}function Si(_0x91adab,_0x6bdb95,_0x1eac60,_0xc85cbf,_0x1960d7,_0x5537a3,_0x6a658b,_0x1baa1f){if(_0x6bdb95['serverCache']['getNode']()['isEmpty']()&&!_0x6bdb95['serverCache']['isFullyInitialized']())return _0x6bdb95;let _0x508a70=_0x6bdb95,_0x3967ee;v(_0x1eac60)?_0x3967ee=_0xc85cbf:_0x3967ee=new S(null)['setTree'](_0x1eac60,_0xc85cbf);const _0xaa0e6=_0x6bdb95['serverCache']['getNode']();return _0x3967ee['children']['inorderTraversal']((_0x2ab19c,_0x5e72db)=>{if(_0xaa0e6['hasChild'](_0x2ab19c)){const _0x2d8dd2=_0x6bdb95['serverCache']['getNode']()['getImmediateChild'](_0x2ab19c),_0x18a4a6=cr(_0x91adab,_0x2d8dd2,_0x5e72db);_0x508a70=vn(_0x91adab,_0x508a70,new C(_0x2ab19c),_0x18a4a6,_0x1960d7,_0x5537a3,_0x6a658b,_0x1baa1f);}}),_0x3967ee['children']['inorderTraversal']((_0x4af988,_0x50adf7)=>{const _0x117813=!_0x6bdb95['serverCache']['isCompleteForChild'](_0x4af988)&&_0x50adf7['value']===null;if(!_0xaa0e6['hasChild'](_0x4af988)&&!_0x117813){const _0x3ca1f9=_0x6bdb95['serverCache']['getNode']()['getImmediateChild'](_0x4af988),_0x53c412=cr(_0x91adab,_0x3ca1f9,_0x50adf7);_0x508a70=vn(_0x91adab,_0x508a70,new C(_0x4af988),_0x53c412,_0x1960d7,_0x5537a3,_0x6a658b,_0x1baa1f);}}),_0x508a70;}function Ru(_0xd16bc9,_0xd9c3d0,_0x41b168,_0x14894d,_0x20c358,_0x8a380d,_0x4b0baa){if(yn(_0x20c358,_0x41b168)!=null)return _0xd9c3d0;const _0x217b5b=_0xd9c3d0['serverCache']['isFiltered'](),_0x170858=_0xd9c3d0['serverCache'];if(_0x14894d['value']!=null){if(v(_0x41b168)&&_0x170858['isFullyInitialized']()||_0x170858['isCompleteForPath'](_0x41b168))return vn(_0xd16bc9,_0xd9c3d0,_0x41b168,_0x170858['getNode']()['getChild'](_0x41b168),_0x20c358,_0x8a380d,_0x217b5b,_0x4b0baa);if(v(_0x41b168)){let _0x1213fd=new S(null);return _0x170858['getNode']()['forEachChild'](ye,(_0x3db8bf,_0x3122ea)=>{_0x1213fd=_0x1213fd['set'](new C(_0x3db8bf),_0x3122ea);}),Si(_0xd16bc9,_0xd9c3d0,_0x41b168,_0x1213fd,_0x20c358,_0x8a380d,_0x217b5b,_0x4b0baa);}else return _0xd9c3d0;}else{let _0x9e7927=new S(null);return _0x14894d['foreach']((_0x3a65bc,_0x5ad5d9)=>{const _0x1757f4=A(_0x41b168,_0x3a65bc);_0x170858['isCompleteForPath'](_0x1757f4)&&(_0x9e7927=_0x9e7927['set'](_0x3a65bc,_0x170858['getNode']()['getChild'](_0x1757f4)));}),Si(_0xd16bc9,_0xd9c3d0,_0x41b168,_0x9e7927,_0x20c358,_0x8a380d,_0x217b5b,_0x4b0baa);}}function Au(_0x261074,_0x3065dc,_0x324415,_0x123ce1,_0x209809){const _0x40cce7=_0x3065dc['serverCache'],_0x3fdc42=Lo(_0x3065dc,_0x40cce7['getNode'](),_0x40cce7['isFullyInitialized']()||v(_0x324415),_0x40cce7['isFiltered']());return Ho(_0x261074,_0x3fdc42,_0x324415,_0x123ce1,Vo,_0x209809);}function ku(_0xe892d4,_0x3a439d,_0xf8859d,_0x99367f,_0x83c3a4,_0x25ff80){let _0x15300;if(yn(_0x99367f,_0xf8859d)!=null)return _0x3a439d;{const _0x47428d=new ns(_0x99367f,_0x3a439d,_0x83c3a4),_0x68b779=_0x3a439d['eventCache']['getNode']();let _0x5e9494;if(v(_0xf8859d)||y(_0xf8859d)==='.priority'){let _0x17e40a;if(_0x3a439d['serverCache']['isFullyInitialized']())_0x17e40a=mn(_0x99367f,Ue(_0x3a439d));else{const _0xfd72ce=_0x3a439d['serverCache']['getNode']();f(_0xfd72ce instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x17e40a=es(_0x99367f,_0xfd72ce);}_0x17e40a=_0x17e40a,_0x5e9494=_0xe892d4['filter']['updateFullNode'](_0x68b779,_0x17e40a,_0x25ff80);}else{const _0x386a28=y(_0xf8859d);let _0x193f44=ts(_0x99367f,_0x386a28,_0x3a439d['serverCache']);_0x193f44==null&&_0x3a439d['serverCache']['isCompleteForChild'](_0x386a28)&&(_0x193f44=_0x68b779['getImmediateChild'](_0x386a28)),_0x193f44!=null?_0x5e9494=_0xe892d4['filter']['updateChild'](_0x68b779,_0x386a28,_0x193f44,b(_0xf8859d),_0x47428d,_0x25ff80):_0x3a439d['eventCache']['getNode']()['hasChild'](_0x386a28)?_0x5e9494=_0xe892d4['filter']['updateChild'](_0x68b779,_0x386a28,g['EMPTY_NODE'],b(_0xf8859d),_0x47428d,_0x25ff80):_0x5e9494=_0x68b779,_0x5e9494['isEmpty']()&&_0x3a439d['serverCache']['isFullyInitialized']()&&(_0x15300=mn(_0x99367f,Ue(_0x3a439d)),_0x15300['isLeafNode']()&&(_0x5e9494=_0xe892d4['filter']['updateFullNode'](_0x5e9494,_0x15300,_0x25ff80)));}return _0x15300=_0x3a439d['serverCache']['isFullyInitialized']()||yn(_0x99367f,w())!=null,wt(_0x3a439d,_0x5e9494,_0x15300,_0xe892d4['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x40ed1a,_0x24a0f9){this['query_']=_0x40ed1a,this['eventRegistrations_']=[];const _0x4c5c64=this['query_']['_queryParams'],_0x393c2c=new Yi(_0x4c5c64['getIndex']()),_0x2508d8=qh(_0x4c5c64);this['processor_']=wu(_0x2508d8);const _0x59e734=_0x24a0f9['serverCache'],_0x524fc0=_0x24a0f9['eventCache'],_0x42a90f=_0x393c2c['updateFullNode'](g['EMPTY_NODE'],_0x59e734['getNode'](),null),_0x5eb6b7=_0x2508d8['updateFullNode'](g['EMPTY_NODE'],_0x524fc0['getNode'](),null),_0x205667=new Ce(_0x42a90f,_0x59e734['isFullyInitialized'](),_0x393c2c['filtersNodes']()),_0x23346a=new Ce(_0x5eb6b7,_0x524fc0['isFullyInitialized'](),_0x2508d8['filtersNodes']());this['viewCache_']=Dn(_0x23346a,_0x205667),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0xf9400f){return _0xf9400f['viewCache_']['serverCache']['getNode']();}function Ou(_0x29821b){return gn(_0x29821b['viewCache_']);}function Du(_0x592263,_0x5b3339){const _0x4cf148=Ue(_0x592263['viewCache_']);return _0x4cf148&&(_0x592263['query']['_queryParams']['loadsAllData']()||!v(_0x5b3339)&&!_0x4cf148['getImmediateChild'](y(_0x5b3339))['isEmpty']())?_0x4cf148['getChild'](_0x5b3339):null;}function lr(_0x447e59){return _0x447e59['eventRegistrations_']['length']===0x0;}function Mu(_0x45c6a7,_0x41840a){_0x45c6a7['eventRegistrations_']['push'](_0x41840a);}function hr(_0x41c97e,_0x3834fa,_0x332b84){const _0x11e31c=[];if(_0x332b84){f(_0x3834fa==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x450f1d=_0x41c97e['query']['_path'];_0x41c97e['eventRegistrations_']['forEach'](_0x583022=>{const _0x126250=_0x583022['createCancelEvent'](_0x332b84,_0x450f1d);_0x126250&&_0x11e31c['push'](_0x126250);});}if(_0x3834fa){let _0x4ae604=[];for(let _0x2e5a8f=0x0;_0x2e5a8f<_0x41c97e['eventRegistrations_']['length'];++_0x2e5a8f){const _0x5886a1=_0x41c97e['eventRegistrations_'][_0x2e5a8f];if(!_0x5886a1['matches'](_0x3834fa))_0x4ae604['push'](_0x5886a1);else{if(_0x3834fa['hasAnyCallback']()){_0x4ae604=_0x4ae604['concat'](_0x41c97e['eventRegistrations_']['slice'](_0x2e5a8f+0x1));break;}}}_0x41c97e['eventRegistrations_']=_0x4ae604;}else _0x41c97e['eventRegistrations_']=[];return _0x11e31c;}function ur(_0xfd323f,_0x31bb4f,_0x5ecc4a,_0x3c453f){_0x31bb4f['type']===q['MERGE']&&_0x31bb4f['source']['queryId']!==null&&(f(Ue(_0xfd323f['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0xfd323f['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x13979c=_0xfd323f['viewCache_'],_0x5d62ff=Tu(_0xfd323f['processor_'],_0x13979c,_0x31bb4f,_0x5ecc4a,_0x3c453f);return Cu(_0xfd323f['processor_'],_0x5d62ff['viewCache']),f(_0x5d62ff['viewCache']['serverCache']['isFullyInitialized']()||!_0x13979c['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xfd323f['viewCache_']=_0x5d62ff['viewCache'],$o(_0xfd323f,_0x5d62ff['changes'],_0x5d62ff['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x25fc43,_0x1adaad){const _0x1a39bc=_0x25fc43['viewCache_']['eventCache'],_0x522f29=[];return _0x1a39bc['getNode']()['isLeafNode']()||_0x1a39bc['getNode']()['forEachChild'](R,(_0x24a833,_0xe5e60d)=>{_0x522f29['push'](tt(_0x24a833,_0xe5e60d));}),_0x1a39bc['isFullyInitialized']()&&_0x522f29['push'](Oo(_0x1a39bc['getNode']())),$o(_0x25fc43,_0x522f29,_0x1a39bc['getNode'](),_0x1adaad);}function $o(_0x5dad81,_0x5ce01d,_0x248980,_0x3da5f2){const _0xcd2c0d=_0x3da5f2?[_0x3da5f2]:_0x5dad81['eventRegistrations_'];return nu(_0x5dad81['eventGenerator_'],_0x5ce01d,_0x248980,_0xcd2c0d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x5192be){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x5192be;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x5bed88){return _0x5bed88['views']['size']===0x0;}function is(_0x4c79fb,_0x3d3fd3,_0x15f686,_0x5ac79d){const _0x280837=_0x3d3fd3['source']['queryId'];if(_0x280837!==null){const _0x19bdda=_0x4c79fb['views']['get'](_0x280837);return f(_0x19bdda!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x19bdda,_0x3d3fd3,_0x15f686,_0x5ac79d);}else{let _0x17842a=[];for(const _0x205c49 of _0x4c79fb['views']['values']())_0x17842a=_0x17842a['concat'](ur(_0x205c49,_0x3d3fd3,_0x15f686,_0x5ac79d));return _0x17842a;}}function qo(_0x59d975,_0x104108,_0x55448c,_0x2ead39,_0x1de104){const _0x5c47c8=_0x104108['_queryIdentifier'],_0x30e99e=_0x59d975['views']['get'](_0x5c47c8);if(!_0x30e99e){let _0x27e13c=mn(_0x55448c,_0x1de104?_0x2ead39:null),_0x4304eb=!0x1;_0x27e13c?_0x4304eb=!0x0:_0x2ead39 instanceof g?(_0x27e13c=es(_0x55448c,_0x2ead39),_0x4304eb=!0x1):(_0x27e13c=g['EMPTY_NODE'],_0x4304eb=!0x1);const _0x2baab3=Dn(new Ce(_0x27e13c,_0x4304eb,!0x1),new Ce(_0x2ead39,_0x1de104,!0x1));return new Nu(_0x104108,_0x2baab3);}return _0x30e99e;}function Wu(_0xd7509d,_0xb0703e,_0x3d6794,_0x4c6dbb,_0x2f260c,_0x35f40c){const _0x224924=qo(_0xd7509d,_0xb0703e,_0x4c6dbb,_0x2f260c,_0x35f40c);return _0xd7509d['views']['has'](_0xb0703e['_queryIdentifier'])||_0xd7509d['views']['set'](_0xb0703e['_queryIdentifier'],_0x224924),Mu(_0x224924,_0x3d6794),Lu(_0x224924,_0x3d6794);}function Bu(_0xeea55f,_0x5342f9,_0x1e6831,_0x235fc3){const _0xdb2beb=_0x5342f9['_queryIdentifier'],_0x3a2f85=[];let _0x2c0a92=[];const _0x192661=Te(_0xeea55f);if(_0xdb2beb==='default'){for(const [_0x117d18,_0x3c2841]of _0xeea55f['views']['entries']())_0x2c0a92=_0x2c0a92['concat'](hr(_0x3c2841,_0x1e6831,_0x235fc3)),lr(_0x3c2841)&&(_0xeea55f['views']['delete'](_0x117d18),_0x3c2841['query']['_queryParams']['loadsAllData']()||_0x3a2f85['push'](_0x3c2841['query']));}else{const _0x5e6f0b=_0xeea55f['views']['get'](_0xdb2beb);_0x5e6f0b&&(_0x2c0a92=_0x2c0a92['concat'](hr(_0x5e6f0b,_0x1e6831,_0x235fc3)),lr(_0x5e6f0b)&&(_0xeea55f['views']['delete'](_0xdb2beb),_0x5e6f0b['query']['_queryParams']['loadsAllData']()||_0x3a2f85['push'](_0x5e6f0b['query'])));}return _0x192661&&!Te(_0xeea55f)&&_0x3a2f85['push'](new(Fu())(_0x5342f9['_repo'],_0x5342f9['_path'])),{'removed':_0x3a2f85,'events':_0x2c0a92};}function zo(_0xf0817c){const _0x2eba47=[];for(const _0x238fb6 of _0xf0817c['views']['values']())_0x238fb6['query']['_queryParams']['loadsAllData']()||_0x2eba47['push'](_0x238fb6);return _0x2eba47;}function Ee(_0x33a8d3,_0x4add31){let _0x20e161=null;for(const _0x2ddd55 of _0x33a8d3['views']['values']())_0x20e161=_0x20e161||Du(_0x2ddd55,_0x4add31);return _0x20e161;}function jo(_0x426e59,_0x41d01e){if(_0x41d01e['_queryParams']['loadsAllData']())return Ln(_0x426e59);{const _0xaa0e40=_0x41d01e['_queryIdentifier'];return _0x426e59['views']['get'](_0xaa0e40);}}function Ko(_0x4f7b20,_0x1ab2ad){return jo(_0x4f7b20,_0x1ab2ad)!=null;}function Te(_0x140c1d){return Ln(_0x140c1d)!=null;}function Ln(_0x5b57a5){for(const _0x27dadd of _0x5b57a5['views']['values']())if(_0x27dadd['query']['_queryParams']['loadsAllData']())return _0x27dadd;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x5093de){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x5093de;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x2e5423){this['listenProvider_']=_0x2e5423,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x1a6c39,_0x4da243,_0x4c5f39,_0x2f92d6,_0x6dfa15){return ou(_0x1a6c39['pendingWriteTree_'],_0x4da243,_0x4c5f39,_0x2f92d6,_0x6dfa15),_0x6dfa15?ht(_0x1a6c39,new Fe(Ji(),_0x4da243,_0x4c5f39)):[];}function Gu(_0x39af1b,_0x4a5e90,_0x474b82,_0x53b254){au(_0x39af1b['pendingWriteTree_'],_0x4a5e90,_0x474b82,_0x53b254);const _0x4d8405=S['fromObject'](_0x474b82);return ht(_0x39af1b,new nt(Ji(),_0x4a5e90,_0x4d8405));}function pe(_0x36e1bf,_0x49534e,_0x5ec360=!0x1){const _0x367121=cu(_0x36e1bf['pendingWriteTree_'],_0x49534e);if(lu(_0x36e1bf['pendingWriteTree_'],_0x49534e)){let _0x18129e=new S(null);return _0x367121['snap']!=null?_0x18129e=_0x18129e['set'](w(),!0x0):x(_0x367121['children'],_0x33dc10=>{_0x18129e=_0x18129e['set'](new C(_0x33dc10),!0x0);}),ht(_0x36e1bf,new _n(_0x367121['path'],_0x18129e,_0x5ec360));}else return[];}function $t(_0xf48fc5,_0x1d0049,_0x36da41){return ht(_0xf48fc5,new Fe(Xi(),_0x1d0049,_0x36da41));}function qu(_0x255907,_0x1c0b5b,_0x43eff4){const _0x45c4da=S['fromObject'](_0x43eff4);return ht(_0x255907,new nt(Xi(),_0x1c0b5b,_0x45c4da));}function zu(_0x24325d,_0xf0515){return ht(_0x24325d,new Dt(Xi(),_0xf0515));}function ju(_0x6e727f,_0x246c33,_0x23304f){const _0x1940a1=rs(_0x6e727f,_0x23304f);if(_0x1940a1){const _0x2d1b8e=os(_0x1940a1),_0x5f314e=_0x2d1b8e['path'],_0x2066b6=_0x2d1b8e['queryId'],_0x1495dc=F(_0x5f314e,_0x246c33),_0x1a1e2b=new Dt(Zi(_0x2066b6),_0x1495dc);return as(_0x6e727f,_0x5f314e,_0x1a1e2b);}else return[];}function wn(_0x2ab414,_0x5e9015,_0x29b8a9,_0x18c72b,_0x22f7c1=!0x1){const _0x2a3b63=_0x5e9015['_path'],_0x151325=_0x2ab414['syncPointTree_']['get'](_0x2a3b63);let _0x3894c1=[];if(_0x151325&&(_0x5e9015['_queryIdentifier']==='default'||Ko(_0x151325,_0x5e9015))){const _0x488328=Bu(_0x151325,_0x5e9015,_0x29b8a9,_0x18c72b);Uu(_0x151325)&&(_0x2ab414['syncPointTree_']=_0x2ab414['syncPointTree_']['remove'](_0x2a3b63));const _0x536db5=_0x488328['removed'];if(_0x3894c1=_0x488328['events'],!_0x22f7c1){const _0x3eb6cb=_0x536db5['findIndex'](_0x5c7193=>_0x5c7193['_queryParams']['loadsAllData']())!==-0x1,_0x145fcd=_0x2ab414['syncPointTree_']['findOnPath'](_0x2a3b63,(_0x5ce803,_0x3afa39)=>Te(_0x3afa39));if(_0x3eb6cb&&!_0x145fcd){const _0x24c51e=_0x2ab414['syncPointTree_']['subtree'](_0x2a3b63);if(!_0x24c51e['isEmpty']()){const _0x50b69b=Qu(_0x24c51e);for(let _0x427b46=0x0;_0x427b46<_0x50b69b['length'];++_0x427b46){const _0x161654=_0x50b69b[_0x427b46],_0x149078=_0x161654['query'],_0x5c6091=Xo(_0x2ab414,_0x161654);_0x2ab414['listenProvider_']['startListening'](Tt(_0x149078),Mt(_0x2ab414,_0x149078),_0x5c6091['hashFn'],_0x5c6091['onComplete']);}}}!_0x145fcd&&_0x536db5['length']>0x0&&!_0x18c72b&&(_0x3eb6cb?_0x2ab414['listenProvider_']['stopListening'](Tt(_0x5e9015),null):_0x536db5['forEach'](_0x4d56ad=>{const _0x19be9b=_0x2ab414['queryToTagMap']['get'](Fn(_0x4d56ad));_0x2ab414['listenProvider_']['stopListening'](Tt(_0x4d56ad),_0x19be9b);}));}Ju(_0x2ab414,_0x536db5);}return _0x3894c1;}function Yo(_0x1b01e0,_0x2eba3f,_0x2ce473,_0x2f5254){const _0x403e6b=rs(_0x1b01e0,_0x2f5254);if(_0x403e6b!=null){const _0x48f1a8=os(_0x403e6b),_0x2454ea=_0x48f1a8['path'],_0x411d13=_0x48f1a8['queryId'],_0x3cc855=F(_0x2454ea,_0x2eba3f),_0x583843=new Fe(Zi(_0x411d13),_0x3cc855,_0x2ce473);return as(_0x1b01e0,_0x2454ea,_0x583843);}else return[];}function Ku(_0x203288,_0x3ce4bc,_0x297011,_0x5c0e08){const _0x20745b=rs(_0x203288,_0x5c0e08);if(_0x20745b){const _0x313c41=os(_0x20745b),_0x273dc9=_0x313c41['path'],_0x332d4d=_0x313c41['queryId'],_0x2c74a4=F(_0x273dc9,_0x3ce4bc),_0x53a876=S['fromObject'](_0x297011),_0x1d3557=new nt(Zi(_0x332d4d),_0x2c74a4,_0x53a876);return as(_0x203288,_0x273dc9,_0x1d3557);}else return[];}function bi(_0x145bdf,_0x314f89,_0x1ad90e,_0x40138a=!0x1){const _0x12216a=_0x314f89['_path'];let _0x45c673=null,_0x39147d=!0x1;_0x145bdf['syncPointTree_']['foreachOnPath'](_0x12216a,(_0x3c03ec,_0x369c80)=>{const _0x523700=F(_0x3c03ec,_0x12216a);_0x45c673=_0x45c673||Ee(_0x369c80,_0x523700),_0x39147d=_0x39147d||Te(_0x369c80);});let _0x5917d4=_0x145bdf['syncPointTree_']['get'](_0x12216a);_0x5917d4?(_0x39147d=_0x39147d||Te(_0x5917d4),_0x45c673=_0x45c673||Ee(_0x5917d4,w())):(_0x5917d4=new Go(),_0x145bdf['syncPointTree_']=_0x145bdf['syncPointTree_']['set'](_0x12216a,_0x5917d4));let _0x46ad15;_0x45c673!=null?_0x46ad15=!0x0:(_0x46ad15=!0x1,_0x45c673=g['EMPTY_NODE'],_0x145bdf['syncPointTree_']['subtree'](_0x12216a)['foreachChild']((_0xeb09ac,_0x905d89)=>{const _0x480a4b=Ee(_0x905d89,w());_0x480a4b&&(_0x45c673=_0x45c673['updateImmediateChild'](_0xeb09ac,_0x480a4b));}));const _0x12d61b=Ko(_0x5917d4,_0x314f89);if(!_0x12d61b&&!_0x314f89['_queryParams']['loadsAllData']()){const _0x25ad74=Fn(_0x314f89);f(!_0x145bdf['queryToTagMap']['has'](_0x25ad74),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xe6449=Xu();_0x145bdf['queryToTagMap']['set'](_0x25ad74,_0xe6449),_0x145bdf['tagToQueryMap']['set'](_0xe6449,_0x25ad74);}const _0x157396=Mn(_0x145bdf['pendingWriteTree_'],_0x12216a);let _0x5c3d25=Wu(_0x5917d4,_0x314f89,_0x1ad90e,_0x157396,_0x45c673,_0x46ad15);if(!_0x12d61b&&!_0x39147d&&!_0x40138a){const _0x237e11=jo(_0x5917d4,_0x314f89);_0x5c3d25=_0x5c3d25['concat'](Zu(_0x145bdf,_0x314f89,_0x237e11));}return _0x5c3d25;}function xn(_0x32f914,_0xcdf470,_0xa7f6d2){const _0x516c0d=_0x32f914['pendingWriteTree_'],_0x4843be=_0x32f914['syncPointTree_']['findOnPath'](_0xcdf470,(_0x39e7a4,_0x1f4e35)=>{const _0x22893c=F(_0x39e7a4,_0xcdf470),_0x436914=Ee(_0x1f4e35,_0x22893c);if(_0x436914)return _0x436914;});return Uo(_0x516c0d,_0xcdf470,_0x4843be,_0xa7f6d2,!0x0);}function Yu(_0x1606fc,_0x139fc5){const _0x434c3f=_0x139fc5['_path'];let _0x3e4972=null;_0x1606fc['syncPointTree_']['foreachOnPath'](_0x434c3f,(_0x18c782,_0x4604fb)=>{const _0x215a87=F(_0x18c782,_0x434c3f);_0x3e4972=_0x3e4972||Ee(_0x4604fb,_0x215a87);});let _0xd74d1b=_0x1606fc['syncPointTree_']['get'](_0x434c3f);_0xd74d1b?_0x3e4972=_0x3e4972||Ee(_0xd74d1b,w()):(_0xd74d1b=new Go(),_0x1606fc['syncPointTree_']=_0x1606fc['syncPointTree_']['set'](_0x434c3f,_0xd74d1b));const _0x3a4e2a=_0x3e4972!=null,_0x544946=_0x3a4e2a?new Ce(_0x3e4972,!0x0,!0x1):null,_0x2aacdf=Mn(_0x1606fc['pendingWriteTree_'],_0x139fc5['_path']),_0x5a71f0=qo(_0xd74d1b,_0x139fc5,_0x2aacdf,_0x3a4e2a?_0x544946['getNode']():g['EMPTY_NODE'],_0x3a4e2a);return Ou(_0x5a71f0);}function ht(_0x1a4e37,_0x9461e3){return Qo(_0x9461e3,_0x1a4e37['syncPointTree_'],null,Mn(_0x1a4e37['pendingWriteTree_'],w()));}function Qo(_0xc93229,_0x5d3611,_0x174569,_0x13ef0e){if(v(_0xc93229['path']))return Jo(_0xc93229,_0x5d3611,_0x174569,_0x13ef0e);{const _0x4d74e6=_0x5d3611['get'](w());_0x174569==null&&_0x4d74e6!=null&&(_0x174569=Ee(_0x4d74e6,w()));let _0x23dec4=[];const _0x4995b5=y(_0xc93229['path']),_0x566f0d=_0xc93229['operationForChild'](_0x4995b5),_0x35250f=_0x5d3611['children']['get'](_0x4995b5);if(_0x35250f&&_0x566f0d){const _0x573637=_0x174569?_0x174569['getImmediateChild'](_0x4995b5):null,_0x4e8907=Wo(_0x13ef0e,_0x4995b5);_0x23dec4=_0x23dec4['concat'](Qo(_0x566f0d,_0x35250f,_0x573637,_0x4e8907));}return _0x4d74e6&&(_0x23dec4=_0x23dec4['concat'](is(_0x4d74e6,_0xc93229,_0x13ef0e,_0x174569))),_0x23dec4;}}function Jo(_0x1f81da,_0x13fea2,_0x2a0355,_0x5e4ef9){const _0x21be88=_0x13fea2['get'](w());_0x2a0355==null&&_0x21be88!=null&&(_0x2a0355=Ee(_0x21be88,w()));let _0x2bd91e=[];return _0x13fea2['children']['inorderTraversal']((_0x2609fe,_0x1ed5f8)=>{const _0x59014c=_0x2a0355?_0x2a0355['getImmediateChild'](_0x2609fe):null,_0x28e2e6=Wo(_0x5e4ef9,_0x2609fe),_0x56e922=_0x1f81da['operationForChild'](_0x2609fe);_0x56e922&&(_0x2bd91e=_0x2bd91e['concat'](Jo(_0x56e922,_0x1ed5f8,_0x59014c,_0x28e2e6)));}),_0x21be88&&(_0x2bd91e=_0x2bd91e['concat'](is(_0x21be88,_0x1f81da,_0x5e4ef9,_0x2a0355))),_0x2bd91e;}function Xo(_0x30f5d4,_0x466bfc){const _0x463af6=_0x466bfc['query'],_0x44419c=Mt(_0x30f5d4,_0x463af6);return{'hashFn':()=>(Pu(_0x466bfc)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x58c20e=>{if(_0x58c20e==='ok')return _0x44419c?ju(_0x30f5d4,_0x463af6['_path'],_0x44419c):zu(_0x30f5d4,_0x463af6['_path']);{const _0x1de3c4=ql(_0x58c20e,_0x463af6);return wn(_0x30f5d4,_0x463af6,null,_0x1de3c4);}}};}function Mt(_0x260da7,_0x34acae){const _0x59b42c=Fn(_0x34acae);return _0x260da7['queryToTagMap']['get'](_0x59b42c);}function Fn(_0x88cc94){return _0x88cc94['_path']['toString']()+'$'+_0x88cc94['_queryIdentifier'];}function rs(_0x1bca5b,_0x10cacb){return _0x1bca5b['tagToQueryMap']['get'](_0x10cacb);}function os(_0x1eaafa){const _0x1d9bcd=_0x1eaafa['indexOf']('$');return f(_0x1d9bcd!==-0x1&&_0x1d9bcd<_0x1eaafa['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1eaafa['substr'](_0x1d9bcd+0x1),'path':new C(_0x1eaafa['substr'](0x0,_0x1d9bcd))};}function as(_0x23d1d8,_0x24ac30,_0x5306a9){const _0x5b9ea0=_0x23d1d8['syncPointTree_']['get'](_0x24ac30);f(_0x5b9ea0,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x5ea23a=Mn(_0x23d1d8['pendingWriteTree_'],_0x24ac30);return is(_0x5b9ea0,_0x5306a9,_0x5ea23a,null);}function Qu(_0x4c8f4f){return _0x4c8f4f['fold']((_0xe58b02,_0xed2add,_0x1801a5)=>{if(_0xed2add&&Te(_0xed2add))return[Ln(_0xed2add)];{let _0x9ac8e4=[];return _0xed2add&&(_0x9ac8e4=zo(_0xed2add)),x(_0x1801a5,(_0x2168f1,_0x368ebf)=>{_0x9ac8e4=_0x9ac8e4['concat'](_0x368ebf);}),_0x9ac8e4;}});}function Tt(_0x5619ea){return _0x5619ea['_queryParams']['loadsAllData']()&&!_0x5619ea['_queryParams']['isDefault']()?new(Hu())(_0x5619ea['_repo'],_0x5619ea['_path']):_0x5619ea;}function Ju(_0x585f77,_0x464a5c){for(let _0x17b117=0x0;_0x17b117<_0x464a5c['length'];++_0x17b117){const _0x18ce83=_0x464a5c[_0x17b117];if(!_0x18ce83['_queryParams']['loadsAllData']()){const _0x104cd5=Fn(_0x18ce83),_0x4ce41b=_0x585f77['queryToTagMap']['get'](_0x104cd5);_0x585f77['queryToTagMap']['delete'](_0x104cd5),_0x585f77['tagToQueryMap']['delete'](_0x4ce41b);}}}function Xu(){return $u++;}function Zu(_0x59ff25,_0x238af2,_0x466aab){const _0x457fee=_0x238af2['_path'],_0x598bd1=Mt(_0x59ff25,_0x238af2),_0x36d071=Xo(_0x59ff25,_0x466aab),_0x2d2a6a=_0x59ff25['listenProvider_']['startListening'](Tt(_0x238af2),_0x598bd1,_0x36d071['hashFn'],_0x36d071['onComplete']),_0x20a381=_0x59ff25['syncPointTree_']['subtree'](_0x457fee);if(_0x598bd1)f(!Te(_0x20a381['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x124f56=_0x20a381['fold']((_0x258fef,_0x1190fb,_0x24b449)=>{if(!v(_0x258fef)&&_0x1190fb&&Te(_0x1190fb))return[Ln(_0x1190fb)['query']];{let _0x53ad66=[];return _0x1190fb&&(_0x53ad66=_0x53ad66['concat'](zo(_0x1190fb)['map'](_0x1edb17=>_0x1edb17['query']))),x(_0x24b449,(_0xeb356d,_0x5ecdca)=>{_0x53ad66=_0x53ad66['concat'](_0x5ecdca);}),_0x53ad66;}});for(let _0x257233=0x0;_0x257233<_0x124f56['length'];++_0x257233){const _0x4596bf=_0x124f56[_0x257233];_0x59ff25['listenProvider_']['stopListening'](Tt(_0x4596bf),Mt(_0x59ff25,_0x4596bf));}}return _0x2d2a6a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x5aca1d){this['node_']=_0x5aca1d;}['getImmediateChild'](_0x2c9f11){const _0x451c43=this['node_']['getImmediateChild'](_0x2c9f11);return new cs(_0x451c43);}['node'](){return this['node_'];}}class ls{constructor(_0x584fb3,_0x40892b){this['syncTree_']=_0x584fb3,this['path_']=_0x40892b;}['getImmediateChild'](_0x41ea03){const _0x5f05ee=A(this['path_'],_0x41ea03);return new ls(this['syncTree_'],_0x5f05ee);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x13f9cd){return _0x13f9cd=_0x13f9cd||{},_0x13f9cd['timestamp']=_0x13f9cd['timestamp']||new Date()['getTime'](),_0x13f9cd;},fr=function(_0x3c17bc,_0x5352e5,_0x5a76dc){if(!_0x3c17bc||typeof _0x3c17bc!='object')return _0x3c17bc;if(f('.sv'in _0x3c17bc,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3c17bc['.sv']=='string')return td(_0x3c17bc['.sv'],_0x5352e5,_0x5a76dc);if(typeof _0x3c17bc['.sv']=='object')return nd(_0x3c17bc['.sv'],_0x5352e5);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3c17bc,null,0x2));},td=function(_0x1e1ea6,_0x419548,_0x51d682){switch(_0x1e1ea6){case'timestamp':return _0x51d682['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1e1ea6);}},nd=function(_0x137049,_0x8ea4d5,_0x4d9df7){_0x137049['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x137049,null,0x2));const _0x735ca=_0x137049['increment'];typeof _0x735ca!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x735ca);const _0x4b5905=_0x8ea4d5['node']();if(f(_0x4b5905!==null&&typeof _0x4b5905<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4b5905['isLeafNode']())return _0x735ca;const _0x250e75=_0x4b5905['getValue']();return typeof _0x250e75!='number'?_0x735ca:_0x250e75+_0x735ca;},Zo=function(_0x232878,_0x3fd7,_0x71dc31,_0x41e378){return us(_0x3fd7,new ls(_0x71dc31,_0x232878),_0x41e378);},hs=function(_0x4febfd,_0xe5c9b,_0x58d15a){return us(_0x4febfd,new cs(_0xe5c9b),_0x58d15a);};function us(_0x4a804f,_0x255523,_0x219341){const _0x480fdc=_0x4a804f['getPriority']()['val'](),_0x3c5311=fr(_0x480fdc,_0x255523['getImmediateChild']('.priority'),_0x219341);let _0x41aa41;if(_0x4a804f['isLeafNode']()){const _0x5497d2=_0x4a804f,_0x166469=fr(_0x5497d2['getValue'](),_0x255523,_0x219341);return _0x166469!==_0x5497d2['getValue']()||_0x3c5311!==_0x5497d2['getPriority']()['val']()?new D(_0x166469,N(_0x3c5311)):_0x4a804f;}else{const _0x4031c3=_0x4a804f;return _0x41aa41=_0x4031c3,_0x3c5311!==_0x4031c3['getPriority']()['val']()&&(_0x41aa41=_0x41aa41['updatePriority'](new D(_0x3c5311))),_0x4031c3['forEachChild'](R,(_0x6c0aac,_0x2cc341)=>{const _0x4fc536=us(_0x2cc341,_0x255523['getImmediateChild'](_0x6c0aac),_0x219341);_0x4fc536!==_0x2cc341&&(_0x41aa41=_0x41aa41['updateImmediateChild'](_0x6c0aac,_0x4fc536));}),_0x41aa41;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x1dc9ee='',_0x3cc47f=null,_0x109ec8={'children':{},'childCount':0x0}){this['name']=_0x1dc9ee,this['parent']=_0x3cc47f,this['node']=_0x109ec8;}}function Un(_0x2b9374,_0x1a9cc9){let _0x1a5a3a=_0x1a9cc9 instanceof C?_0x1a9cc9:new C(_0x1a9cc9),_0x52a23e=_0x2b9374,_0x251ed1=y(_0x1a5a3a);for(;_0x251ed1!==null;){const _0xa8b64c=Oe(_0x52a23e['node']['children'],_0x251ed1)||{'children':{},'childCount':0x0};_0x52a23e=new ds(_0x251ed1,_0x52a23e,_0xa8b64c),_0x1a5a3a=b(_0x1a5a3a),_0x251ed1=y(_0x1a5a3a);}return _0x52a23e;}function Ge(_0x432969){return _0x432969['node']['value'];}function fs(_0x2517dc,_0xadde97){_0x2517dc['node']['value']=_0xadde97,Ri(_0x2517dc);}function ea(_0x20b6a3){return _0x20b6a3['node']['childCount']>0x0;}function id(_0x84cf9b){return Ge(_0x84cf9b)===void 0x0&&!ea(_0x84cf9b);}function Wn(_0xf59b8,_0x13463b){x(_0xf59b8['node']['children'],(_0x258773,_0x2dc5f9)=>{_0x13463b(new ds(_0x258773,_0xf59b8,_0x2dc5f9));});}function ta(_0x880865,_0x597e5e,_0x1371a0,_0x47065a){_0x1371a0&&_0x597e5e(_0x880865),Wn(_0x880865,_0x275f9b=>{ta(_0x275f9b,_0x597e5e,!0x0);});}function sd(_0x11461b,_0x105223,_0x10dced){let _0x2138f9=_0x11461b['parent'];for(;_0x2138f9!==null;){if(_0x105223(_0x2138f9))return!0x0;_0x2138f9=_0x2138f9['parent'];}return!0x1;}function Gt(_0x2c63ef){return new C(_0x2c63ef['parent']===null?_0x2c63ef['name']:Gt(_0x2c63ef['parent'])+'/'+_0x2c63ef['name']);}function Ri(_0x8b719c){_0x8b719c['parent']!==null&&rd(_0x8b719c['parent'],_0x8b719c['name'],_0x8b719c);}function rd(_0x4f604b,_0x4aee91,_0x2fb8af){const _0x2ddf81=id(_0x2fb8af),_0x49ec59=Y(_0x4f604b['node']['children'],_0x4aee91);_0x2ddf81&&_0x49ec59?(delete _0x4f604b['node']['children'][_0x4aee91],_0x4f604b['node']['childCount']--,Ri(_0x4f604b)):!_0x2ddf81&&!_0x49ec59&&(_0x4f604b['node']['children'][_0x4aee91]=_0x2fb8af['node'],_0x4f604b['node']['childCount']++,Ri(_0x4f604b));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x2cbd4d){return typeof _0x2cbd4d=='string'&&_0x2cbd4d['length']!==0x0&&!od['test'](_0x2cbd4d);},na=function(_0x1fb4e5){return typeof _0x1fb4e5=='string'&&_0x1fb4e5['length']!==0x0&&!ad['test'](_0x1fb4e5);},cd=function(_0x531f14){return _0x531f14&&(_0x531f14=_0x531f14['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x531f14);},Cn=function(_0x4262ab){return _0x4262ab===null||typeof _0x4262ab=='string'||typeof _0x4262ab=='number'&&!Wi(_0x4262ab)||_0x4262ab&&typeof _0x4262ab=='object'&&Y(_0x4262ab,'.sv');},qt=function(_0xd85da7,_0x368d0a,_0x8d966,_0x374ebc){_0x374ebc&&_0x368d0a===void 0x0||zt(Nn(_0xd85da7,'value'),_0x368d0a,_0x8d966);},zt=function(_0xe17002,_0x428df3,_0x2eb15f){const _0x2cebe5=_0x2eb15f instanceof C?new Sh(_0x2eb15f,_0xe17002):_0x2eb15f;if(_0x428df3===void 0x0)throw new Error(_0xe17002+'contains\x20undefined\x20'+Ne(_0x2cebe5));if(typeof _0x428df3=='function')throw new Error(_0xe17002+'contains\x20a\x20function\x20'+Ne(_0x2cebe5)+'\x20with\x20contents\x20=\x20'+_0x428df3['toString']());if(Wi(_0x428df3))throw new Error(_0xe17002+'contains\x20'+_0x428df3['toString']()+'\x20'+Ne(_0x2cebe5));if(typeof _0x428df3=='string'&&_0x428df3['length']>oi/0x3&&Pn(_0x428df3)>oi)throw new Error(_0xe17002+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x2cebe5)+'\x20(\x27'+_0x428df3['substring'](0x0,0x32)+'...\x27)');if(_0x428df3&&typeof _0x428df3=='object'){let _0x16501b=!0x1,_0x537f57=!0x1;if(x(_0x428df3,(_0x2b1dd8,_0x4a06b1)=>{if(_0x2b1dd8==='.value')_0x16501b=!0x0;else{if(_0x2b1dd8!=='.priority'&&_0x2b1dd8!=='.sv'&&(_0x537f57=!0x0,!ps(_0x2b1dd8)))throw new Error(_0xe17002+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2b1dd8+')\x20'+Ne(_0x2cebe5)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x2cebe5,_0x2b1dd8),zt(_0xe17002,_0x4a06b1,_0x2cebe5),Rh(_0x2cebe5);}),_0x16501b&&_0x537f57)throw new Error(_0xe17002+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x2cebe5)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0xa32a4c,_0x7e9e4d){let _0x5a2ba8,_0x185a46;for(_0x5a2ba8=0x0;_0x5a2ba8<_0x7e9e4d['length'];_0x5a2ba8++){_0x185a46=_0x7e9e4d[_0x5a2ba8];const _0x266e00=kt(_0x185a46);for(let _0xf0daf0=0x0;_0xf0daf0<_0x266e00['length'];_0xf0daf0++)if(!(_0x266e00[_0xf0daf0]==='.priority'&&_0xf0daf0===_0x266e00['length']-0x1)){if(!ps(_0x266e00[_0xf0daf0]))throw new Error(_0xa32a4c+'contains\x20an\x20invalid\x20key\x20('+_0x266e00[_0xf0daf0]+')\x20in\x20path\x20'+_0x185a46['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x7e9e4d['sort'](Th);let _0x5e0625=null;for(_0x5a2ba8=0x0;_0x5a2ba8<_0x7e9e4d['length'];_0x5a2ba8++){if(_0x185a46=_0x7e9e4d[_0x5a2ba8],_0x5e0625!==null&&$(_0x5e0625,_0x185a46))throw new Error(_0xa32a4c+'contains\x20a\x20path\x20'+_0x5e0625['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x185a46['toString']());_0x5e0625=_0x185a46;}},hd=function(_0x4ef16e,_0x481dbe,_0xf44e76,_0x42e65b){const _0x51f866=Nn(_0x4ef16e,'values');if(!(_0x481dbe&&typeof _0x481dbe=='object')||Array['isArray'](_0x481dbe))throw new Error(_0x51f866+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2fee5b=[];x(_0x481dbe,(_0x5975db,_0x21ae5a)=>{const _0x65b90e=new C(_0x5975db);if(zt(_0x51f866,_0x21ae5a,A(_0xf44e76,_0x65b90e)),Gi(_0x65b90e)==='.priority'&&!Cn(_0x21ae5a))throw new Error(_0x51f866+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x65b90e['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2fee5b['push'](_0x65b90e);}),ld(_0x51f866,_0x2fee5b);},_s=function(_0x4832ef,_0x667457,_0x151337,_0x1eff3b){if(!na(_0x151337))throw new Error(Nn(_0x4832ef,_0x667457)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x151337+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0xd0c59b,_0x1fa0ba,_0x39c35d,_0x153dde){_0x39c35d&&(_0x39c35d=_0x39c35d['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0xd0c59b,_0x1fa0ba,_0x39c35d);},gs=function(_0xc9acb7,_0x141a61){if(y(_0x141a61)==='.info')throw new Error(_0xc9acb7+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x374e7c,_0x3a26d8){const _0x4406e9=_0x3a26d8['path']['toString']();if(typeof _0x3a26d8['repoInfo']['host']!='string'||_0x3a26d8['repoInfo']['host']['length']===0x0||!ps(_0x3a26d8['repoInfo']['namespace'])&&_0x3a26d8['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4406e9['length']!==0x0&&!cd(_0x4406e9))throw new Error(Nn(_0x374e7c,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x5809a6,_0x207ec7){let _0x13c3e7=null;for(let _0x470c6f=0x0;_0x470c6f<_0x207ec7['length'];_0x470c6f++){const _0x257250=_0x207ec7[_0x470c6f],_0x5792db=_0x257250['getPath']();_0x13c3e7!==null&&!qi(_0x5792db,_0x13c3e7['path'])&&(_0x5809a6['eventLists_']['push'](_0x13c3e7),_0x13c3e7=null),_0x13c3e7===null&&(_0x13c3e7={'events':[],'path':_0x5792db}),_0x13c3e7['events']['push'](_0x257250);}_0x13c3e7&&_0x5809a6['eventLists_']['push'](_0x13c3e7);}function ia(_0x3ee48c,_0x5b3323,_0x2fc7c6){Bn(_0x3ee48c,_0x2fc7c6),sa(_0x3ee48c,_0x46e059=>qi(_0x46e059,_0x5b3323));}function V(_0x144443,_0x45b35e,_0xe38562){Bn(_0x144443,_0xe38562),sa(_0x144443,_0x573997=>$(_0x573997,_0x45b35e)||$(_0x45b35e,_0x573997));}function sa(_0x2c6b6a,_0x201625){_0x2c6b6a['recursionDepth_']++;let _0xe42220=!0x0;for(let _0x32d4ac=0x0;_0x32d4ac<_0x2c6b6a['eventLists_']['length'];_0x32d4ac++){const _0x3e3928=_0x2c6b6a['eventLists_'][_0x32d4ac];if(_0x3e3928){const _0x3a192e=_0x3e3928['path'];_0x201625(_0x3a192e)?(pd(_0x2c6b6a['eventLists_'][_0x32d4ac]),_0x2c6b6a['eventLists_'][_0x32d4ac]=null):_0xe42220=!0x1;}}_0xe42220&&(_0x2c6b6a['eventLists_']=[]),_0x2c6b6a['recursionDepth_']--;}function pd(_0x48a4c8){for(let _0x201c27=0x0;_0x201c27<_0x48a4c8['events']['length'];_0x201c27++){const _0x4c645c=_0x48a4c8['events'][_0x201c27];if(_0x4c645c!==null){_0x48a4c8['events'][_0x201c27]=null;const _0x2897e3=_0x4c645c['getEventRunner']();Et&&L('event:\x20'+_0x4c645c['toString']()),lt(_0x2897e3);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x163ac6,_0x8cfc55,_0x12ca4d,_0x5b85b9){this['repoInfo_']=_0x163ac6,this['forceRestClient_']=_0x8cfc55,this['authTokenProvider_']=_0x12ca4d,this['appCheckProvider_']=_0x5b85b9,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x4165b1,_0x500463,_0x26ac69){if(_0x4165b1['stats_']=Hi(_0x4165b1['repoInfo_']),_0x4165b1['forceRestClient_']||Yl())_0x4165b1['server_']=new fn(_0x4165b1['repoInfo_'],(_0x1e3fb0,_0x28623b,_0x59f177,_0x465a60)=>{pr(_0x4165b1,_0x1e3fb0,_0x28623b,_0x59f177,_0x465a60);},_0x4165b1['authTokenProvider_'],_0x4165b1['appCheckProvider_']),setTimeout(()=>_r(_0x4165b1,!0x0),0x0);else{if(typeof _0x26ac69<'u'&&_0x26ac69!==null){if(typeof _0x26ac69!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x26ac69);}catch(_0x2c1270){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x2c1270);}}_0x4165b1['persistentConnection_']=new ie(_0x4165b1['repoInfo_'],_0x500463,(_0x3900a0,_0x81ff95,_0x24ce47,_0x5e525c)=>{pr(_0x4165b1,_0x3900a0,_0x81ff95,_0x24ce47,_0x5e525c);},_0x114779=>{_r(_0x4165b1,_0x114779);},_0x3271cf=>{yd(_0x4165b1,_0x3271cf);},_0x4165b1['authTokenProvider_'],_0x4165b1['appCheckProvider_'],_0x26ac69),_0x4165b1['server_']=_0x4165b1['persistentConnection_'];}_0x4165b1['authTokenProvider_']['addTokenChangeListener'](_0x1350da=>{_0x4165b1['server_']['refreshAuthToken'](_0x1350da);}),_0x4165b1['appCheckProvider_']['addTokenChangeListener'](_0x58f191=>{_0x4165b1['server_']['refreshAppCheckToken'](_0x58f191['token']);}),_0x4165b1['statsReporter_']=eh(_0x4165b1['repoInfo_'],()=>new eu(_0x4165b1['stats_'],_0x4165b1['server_'])),_0x4165b1['infoData_']=new Yh(),_0x4165b1['infoSyncTree_']=new dr({'startListening':(_0x337659,_0x4c344b,_0x4fb1e8,_0x2992a5)=>{let _0x54bcad=[];const _0x3c0733=_0x4165b1['infoData_']['getNode'](_0x337659['_path']);return _0x3c0733['isEmpty']()||(_0x54bcad=$t(_0x4165b1['infoSyncTree_'],_0x337659['_path'],_0x3c0733),setTimeout(()=>{_0x2992a5('ok');},0x0)),_0x54bcad;},'stopListening':()=>{}}),ms(_0x4165b1,'connected',!0x1),_0x4165b1['serverSyncTree_']=new dr({'startListening':(_0x469e1d,_0x55b694,_0x5f5fc6,_0x328661)=>(_0x4165b1['server_']['listen'](_0x469e1d,_0x5f5fc6,_0x55b694,(_0xc298d,_0x3d986a)=>{const _0xc029ad=_0x328661(_0xc298d,_0x3d986a);V(_0x4165b1['eventQueue_'],_0x469e1d['_path'],_0xc029ad);}),[]),'stopListening':(_0x3c2e31,_0x34c63a)=>{_0x4165b1['server_']['unlisten'](_0x3c2e31,_0x34c63a);}});}function oa(_0xf3692){const _0x5c6238=_0xf3692['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x5c6238;}function jt(_0x29264e){return ed({'timestamp':oa(_0x29264e)});}function pr(_0x3c07f1,_0x14c857,_0x1d6692,_0x4c1922,_0x5b5fb1){_0x3c07f1['dataUpdateCount']++;const _0x30d734=new C(_0x14c857);_0x1d6692=_0x3c07f1['interceptServerDataCallback_']?_0x3c07f1['interceptServerDataCallback_'](_0x14c857,_0x1d6692):_0x1d6692;let _0x2dc662=[];if(_0x5b5fb1){if(_0x4c1922){const _0x2855f1=ln(_0x1d6692,_0x4e3164=>N(_0x4e3164));_0x2dc662=Ku(_0x3c07f1['serverSyncTree_'],_0x30d734,_0x2855f1,_0x5b5fb1);}else{const _0x3d14da=N(_0x1d6692);_0x2dc662=Yo(_0x3c07f1['serverSyncTree_'],_0x30d734,_0x3d14da,_0x5b5fb1);}}else{if(_0x4c1922){const _0x4e1f14=ln(_0x1d6692,_0x29bc33=>N(_0x29bc33));_0x2dc662=qu(_0x3c07f1['serverSyncTree_'],_0x30d734,_0x4e1f14);}else{const _0x1a5285=N(_0x1d6692);_0x2dc662=$t(_0x3c07f1['serverSyncTree_'],_0x30d734,_0x1a5285);}}let _0x5cccab=_0x30d734;_0x2dc662['length']>0x0&&(_0x5cccab=st(_0x3c07f1,_0x30d734)),V(_0x3c07f1['eventQueue_'],_0x5cccab,_0x2dc662);}function _r(_0x366ae8,_0x58a112){ms(_0x366ae8,'connected',_0x58a112),_0x58a112===!0x1&&wd(_0x366ae8);}function yd(_0x2a89ee,_0x29e464){x(_0x29e464,(_0x46a8db,_0x21ad79)=>{ms(_0x2a89ee,_0x46a8db,_0x21ad79);});}function ms(_0x16a209,_0x4a9a8b,_0x4dc2c5){const _0x4b669f=new C('/.info/'+_0x4a9a8b),_0xd879e9=N(_0x4dc2c5);_0x16a209['infoData_']['updateSnapshot'](_0x4b669f,_0xd879e9);const _0x149ad1=$t(_0x16a209['infoSyncTree_'],_0x4b669f,_0xd879e9);V(_0x16a209['eventQueue_'],_0x4b669f,_0x149ad1);}function Vn(_0x183755){return _0x183755['nextWriteId_']++;}function vd(_0x2e5370,_0x5e9e37,_0x50e243){const _0x5ce3ec=Yu(_0x2e5370['serverSyncTree_'],_0x5e9e37);return _0x5ce3ec!=null?Promise['resolve'](_0x5ce3ec):_0x2e5370['server_']['get'](_0x5e9e37)['then'](_0x236e61=>{const _0xdd3b9=N(_0x236e61)['withIndex'](_0x5e9e37['_queryParams']['getIndex']());bi(_0x2e5370['serverSyncTree_'],_0x5e9e37,_0x50e243,!0x0);let _0x330272;if(_0x5e9e37['_queryParams']['loadsAllData']())_0x330272=$t(_0x2e5370['serverSyncTree_'],_0x5e9e37['_path'],_0xdd3b9);else{const _0x3a690e=Mt(_0x2e5370['serverSyncTree_'],_0x5e9e37);_0x330272=Yo(_0x2e5370['serverSyncTree_'],_0x5e9e37['_path'],_0xdd3b9,_0x3a690e);}return V(_0x2e5370['eventQueue_'],_0x5e9e37['_path'],_0x330272),wn(_0x2e5370['serverSyncTree_'],_0x5e9e37,_0x50e243,null,!0x0),_0xdd3b9;},_0x587884=>(ut(_0x2e5370,'get\x20for\x20query\x20'+O(_0x5e9e37)+'\x20failed:\x20'+_0x587884),Promise['reject'](new Error(_0x587884))));}function Ed(_0x256246,_0x52ebb2,_0x5bcaf9,_0x38932a,_0x16820a){ut(_0x256246,'set',{'path':_0x52ebb2['toString'](),'value':_0x5bcaf9,'priority':_0x38932a});const _0x5ae83e=jt(_0x256246),_0x32c959=N(_0x5bcaf9,_0x38932a),_0x411606=xn(_0x256246['serverSyncTree_'],_0x52ebb2),_0x502e0e=hs(_0x32c959,_0x411606,_0x5ae83e),_0x5dfff6=Vn(_0x256246),_0x4cfaa3=ss(_0x256246['serverSyncTree_'],_0x52ebb2,_0x502e0e,_0x5dfff6,!0x0);Bn(_0x256246['eventQueue_'],_0x4cfaa3),_0x256246['server_']['put'](_0x52ebb2['toString'](),_0x32c959['val'](!0x0),(_0x58f80c,_0xc033d1)=>{const _0x1d2fa9=_0x58f80c==='ok';_0x1d2fa9||U('set\x20at\x20'+_0x52ebb2+'\x20failed:\x20'+_0x58f80c);const _0x23b6bb=pe(_0x256246['serverSyncTree_'],_0x5dfff6,!_0x1d2fa9);V(_0x256246['eventQueue_'],_0x52ebb2,_0x23b6bb),Ai(_0x256246,_0x16820a,_0x58f80c,_0xc033d1);});const _0x363d98=vs(_0x256246,_0x52ebb2);st(_0x256246,_0x363d98),V(_0x256246['eventQueue_'],_0x363d98,[]);}function Id(_0xd5f6a6,_0x1f3a65,_0xf79c72,_0x22fd5a){ut(_0xd5f6a6,'update',{'path':_0x1f3a65['toString'](),'value':_0xf79c72});let _0x543db4=!0x0;const _0x90426=jt(_0xd5f6a6),_0x19a26c={};if(x(_0xf79c72,(_0x12f448,_0x44a949)=>{_0x543db4=!0x1,_0x19a26c[_0x12f448]=Zo(A(_0x1f3a65,_0x12f448),N(_0x44a949),_0xd5f6a6['serverSyncTree_'],_0x90426);}),_0x543db4)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0xd5f6a6,_0x22fd5a,'ok',void 0x0);else{const _0x15bca3=Vn(_0xd5f6a6),_0x3f4746=Gu(_0xd5f6a6['serverSyncTree_'],_0x1f3a65,_0x19a26c,_0x15bca3);Bn(_0xd5f6a6['eventQueue_'],_0x3f4746),_0xd5f6a6['server_']['merge'](_0x1f3a65['toString'](),_0xf79c72,(_0x259ce8,_0x1945fb)=>{const _0x3f4e30=_0x259ce8==='ok';_0x3f4e30||U('update\x20at\x20'+_0x1f3a65+'\x20failed:\x20'+_0x259ce8);const _0x3b8835=pe(_0xd5f6a6['serverSyncTree_'],_0x15bca3,!_0x3f4e30),_0x13a764=_0x3b8835['length']>0x0?st(_0xd5f6a6,_0x1f3a65):_0x1f3a65;V(_0xd5f6a6['eventQueue_'],_0x13a764,_0x3b8835),Ai(_0xd5f6a6,_0x22fd5a,_0x259ce8,_0x1945fb);}),x(_0xf79c72,_0x2b11f7=>{const _0x21f872=vs(_0xd5f6a6,A(_0x1f3a65,_0x2b11f7));st(_0xd5f6a6,_0x21f872);}),V(_0xd5f6a6['eventQueue_'],_0x1f3a65,[]);}}function wd(_0x4956f1){ut(_0x4956f1,'onDisconnectEvents');const _0x3083d1=jt(_0x4956f1),_0x6e04b8=pn();Ei(_0x4956f1['onDisconnect_'],w(),(_0x4f9412,_0x539090)=>{const _0x3a3133=Zo(_0x4f9412,_0x539090,_0x4956f1['serverSyncTree_'],_0x3083d1);Mo(_0x6e04b8,_0x4f9412,_0x3a3133);});let _0x5aaa08=[];Ei(_0x6e04b8,w(),(_0x8c3ced,_0xc8390)=>{_0x5aaa08=_0x5aaa08['concat']($t(_0x4956f1['serverSyncTree_'],_0x8c3ced,_0xc8390));const _0x161526=vs(_0x4956f1,_0x8c3ced);st(_0x4956f1,_0x161526);}),_0x4956f1['onDisconnect_']=pn(),V(_0x4956f1['eventQueue_'],w(),_0x5aaa08);}function Cd(_0x5ecd9b,_0xaff54b,_0x483ad2){let _0x12c754;y(_0xaff54b['_path'])==='.info'?_0x12c754=bi(_0x5ecd9b['infoSyncTree_'],_0xaff54b,_0x483ad2):_0x12c754=bi(_0x5ecd9b['serverSyncTree_'],_0xaff54b,_0x483ad2),ia(_0x5ecd9b['eventQueue_'],_0xaff54b['_path'],_0x12c754);}function Td(_0x942d37,_0x4cfba2,_0xf92554){let _0x49578b;y(_0x4cfba2['_path'])==='.info'?_0x49578b=wn(_0x942d37['infoSyncTree_'],_0x4cfba2,_0xf92554):_0x49578b=wn(_0x942d37['serverSyncTree_'],_0x4cfba2,_0xf92554),ia(_0x942d37['eventQueue_'],_0x4cfba2['_path'],_0x49578b);}function aa(_0x15c2fe){_0x15c2fe['persistentConnection_']&&_0x15c2fe['persistentConnection_']['interrupt'](ra);}function Sd(_0x4864b6){_0x4864b6['persistentConnection_']&&_0x4864b6['persistentConnection_']['resume'](ra);}function ut(_0x621803,..._0x518571){let _0x1ea4c9='';_0x621803['persistentConnection_']&&(_0x1ea4c9=_0x621803['persistentConnection_']['id']+':'),L(_0x1ea4c9,..._0x518571);}function Ai(_0x4caeb0,_0x3e3814,_0x5f33d5,_0x39294a){_0x3e3814&&lt(()=>{if(_0x5f33d5==='ok')_0x3e3814(null);else{const _0x179ca7=(_0x5f33d5||'error')['toUpperCase']();let _0x34bb39=_0x179ca7;_0x39294a&&(_0x34bb39+=':\x20'+_0x39294a);const _0x4f960d=new Error(_0x34bb39);_0x4f960d['code']=_0x179ca7,_0x3e3814(_0x4f960d);}});}function bd(_0x29e822,_0x16728b,_0x2a1c74,_0x440937,_0x4dab44,_0x35e390){ut(_0x29e822,'transaction\x20on\x20'+_0x16728b);const _0x5f5499={'path':_0x16728b,'update':_0x2a1c74,'onComplete':_0x440937,'status':null,'order':to(),'applyLocally':_0x35e390,'retryCount':0x0,'unwatcher':_0x4dab44,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5b0ba6=ys(_0x29e822,_0x16728b,void 0x0);_0x5f5499['currentInputSnapshot']=_0x5b0ba6;const _0x29dae9=_0x5f5499['update'](_0x5b0ba6['val']());if(_0x29dae9===void 0x0)_0x5f5499['unwatcher'](),_0x5f5499['currentOutputSnapshotRaw']=null,_0x5f5499['currentOutputSnapshotResolved']=null,_0x5f5499['onComplete']&&_0x5f5499['onComplete'](null,!0x1,_0x5f5499['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x29dae9,_0x5f5499['path']),_0x5f5499['status']=0x0;const _0x1138d8=Un(_0x29e822['transactionQueueTree_'],_0x16728b),_0x21efe0=Ge(_0x1138d8)||[];_0x21efe0['push'](_0x5f5499),fs(_0x1138d8,_0x21efe0);let _0x43844c;typeof _0x29dae9=='object'&&_0x29dae9!==null&&Y(_0x29dae9,'.priority')?(_0x43844c=Oe(_0x29dae9,'.priority'),f(Cn(_0x43844c),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x43844c=(xn(_0x29e822['serverSyncTree_'],_0x16728b)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x47445f=jt(_0x29e822),_0x54e439=N(_0x29dae9,_0x43844c),_0x49251f=hs(_0x54e439,_0x5b0ba6,_0x47445f);_0x5f5499['currentOutputSnapshotRaw']=_0x54e439,_0x5f5499['currentOutputSnapshotResolved']=_0x49251f,_0x5f5499['currentWriteId']=Vn(_0x29e822);const _0x14084f=ss(_0x29e822['serverSyncTree_'],_0x16728b,_0x49251f,_0x5f5499['currentWriteId'],_0x5f5499['applyLocally']);V(_0x29e822['eventQueue_'],_0x16728b,_0x14084f),Hn(_0x29e822,_0x29e822['transactionQueueTree_']);}}function ys(_0x25da86,_0x39a99b,_0x5d17b1){return xn(_0x25da86['serverSyncTree_'],_0x39a99b,_0x5d17b1)||g['EMPTY_NODE'];}function Hn(_0x2e0a98,_0x8cd15f=_0x2e0a98['transactionQueueTree_']){if(_0x8cd15f||$n(_0x2e0a98,_0x8cd15f),Ge(_0x8cd15f)){const _0x3b59ba=la(_0x2e0a98,_0x8cd15f);f(_0x3b59ba['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3b59ba['every'](_0x5b9796=>_0x5b9796['status']===0x0)&&Rd(_0x2e0a98,Gt(_0x8cd15f),_0x3b59ba);}else ea(_0x8cd15f)&&Wn(_0x8cd15f,_0x1c23d4=>{Hn(_0x2e0a98,_0x1c23d4);});}function Rd(_0x596a5,_0x5c8b96,_0x17ec0e){const _0x2ef4e5=_0x17ec0e['map'](_0x10bf76=>_0x10bf76['currentWriteId']),_0x5dc8bf=ys(_0x596a5,_0x5c8b96,_0x2ef4e5);let _0x3676c1=_0x5dc8bf;const _0x1d9414=_0x5dc8bf['hash']();for(let _0x17fe44=0x0;_0x17fe44<_0x17ec0e['length'];_0x17fe44++){const _0xd54b12=_0x17ec0e[_0x17fe44];f(_0xd54b12['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0xd54b12['status']=0x1,_0xd54b12['retryCount']++;const _0x3c9e16=F(_0x5c8b96,_0xd54b12['path']);_0x3676c1=_0x3676c1['updateChild'](_0x3c9e16,_0xd54b12['currentOutputSnapshotRaw']);}const _0x20528f=_0x3676c1['val'](!0x0),_0x1019cd=_0x5c8b96;_0x596a5['server_']['put'](_0x1019cd['toString'](),_0x20528f,_0x527a07=>{ut(_0x596a5,'transaction\x20put\x20response',{'path':_0x1019cd['toString'](),'status':_0x527a07});let _0x4c8b17=[];if(_0x527a07==='ok'){const _0x38b7c3=[];for(let _0x54bc05=0x0;_0x54bc05<_0x17ec0e['length'];_0x54bc05++)_0x17ec0e[_0x54bc05]['status']=0x2,_0x4c8b17=_0x4c8b17['concat'](pe(_0x596a5['serverSyncTree_'],_0x17ec0e[_0x54bc05]['currentWriteId'])),_0x17ec0e[_0x54bc05]['onComplete']&&_0x38b7c3['push'](()=>_0x17ec0e[_0x54bc05]['onComplete'](null,!0x0,_0x17ec0e[_0x54bc05]['currentOutputSnapshotResolved'])),_0x17ec0e[_0x54bc05]['unwatcher']();$n(_0x596a5,Un(_0x596a5['transactionQueueTree_'],_0x5c8b96)),Hn(_0x596a5,_0x596a5['transactionQueueTree_']),V(_0x596a5['eventQueue_'],_0x5c8b96,_0x4c8b17);for(let _0x498ff9=0x0;_0x498ff9<_0x38b7c3['length'];_0x498ff9++)lt(_0x38b7c3[_0x498ff9]);}else{if(_0x527a07==='datastale'){for(let _0x56c5da=0x0;_0x56c5da<_0x17ec0e['length'];_0x56c5da++)_0x17ec0e[_0x56c5da]['status']===0x3?_0x17ec0e[_0x56c5da]['status']=0x4:_0x17ec0e[_0x56c5da]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1019cd['toString']()+'\x20failed:\x20'+_0x527a07);for(let _0x521989=0x0;_0x521989<_0x17ec0e['length'];_0x521989++)_0x17ec0e[_0x521989]['status']=0x4,_0x17ec0e[_0x521989]['abortReason']=_0x527a07;}st(_0x596a5,_0x5c8b96);}},_0x1d9414);}function st(_0x449d43,_0x29a9eb){const _0x1ba5fc=ca(_0x449d43,_0x29a9eb),_0x5a6706=Gt(_0x1ba5fc),_0x27bc1c=la(_0x449d43,_0x1ba5fc);return Ad(_0x449d43,_0x27bc1c,_0x5a6706),_0x5a6706;}function Ad(_0x260d85,_0x251bd9,_0x45a231){if(_0x251bd9['length']===0x0)return;const _0x43c081=[];let _0x4dc1ab=[];const _0x3e12d8=_0x251bd9['filter'](_0x14613e=>_0x14613e['status']===0x0)['map'](_0x5062a0=>_0x5062a0['currentWriteId']);for(let _0x4c7e09=0x0;_0x4c7e09<_0x251bd9['length'];_0x4c7e09++){const _0x1d01a8=_0x251bd9[_0x4c7e09],_0x4239ce=F(_0x45a231,_0x1d01a8['path']);let _0x24beae=!0x1,_0x717e9e;if(f(_0x4239ce!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x1d01a8['status']===0x4)_0x24beae=!0x0,_0x717e9e=_0x1d01a8['abortReason'],_0x4dc1ab=_0x4dc1ab['concat'](pe(_0x260d85['serverSyncTree_'],_0x1d01a8['currentWriteId'],!0x0));else{if(_0x1d01a8['status']===0x0){if(_0x1d01a8['retryCount']>=_d)_0x24beae=!0x0,_0x717e9e='maxretry',_0x4dc1ab=_0x4dc1ab['concat'](pe(_0x260d85['serverSyncTree_'],_0x1d01a8['currentWriteId'],!0x0));else{const _0x457344=ys(_0x260d85,_0x1d01a8['path'],_0x3e12d8);_0x1d01a8['currentInputSnapshot']=_0x457344;const _0x37a28a=_0x251bd9[_0x4c7e09]['update'](_0x457344['val']());if(_0x37a28a!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x37a28a,_0x1d01a8['path']);let _0x58af86=N(_0x37a28a);typeof _0x37a28a=='object'&&_0x37a28a!=null&&Y(_0x37a28a,'.priority')||(_0x58af86=_0x58af86['updatePriority'](_0x457344['getPriority']()));const _0x3757e4=_0x1d01a8['currentWriteId'],_0x8ac3bf=jt(_0x260d85),_0x2988f8=hs(_0x58af86,_0x457344,_0x8ac3bf);_0x1d01a8['currentOutputSnapshotRaw']=_0x58af86,_0x1d01a8['currentOutputSnapshotResolved']=_0x2988f8,_0x1d01a8['currentWriteId']=Vn(_0x260d85),_0x3e12d8['splice'](_0x3e12d8['indexOf'](_0x3757e4),0x1),_0x4dc1ab=_0x4dc1ab['concat'](ss(_0x260d85['serverSyncTree_'],_0x1d01a8['path'],_0x2988f8,_0x1d01a8['currentWriteId'],_0x1d01a8['applyLocally'])),_0x4dc1ab=_0x4dc1ab['concat'](pe(_0x260d85['serverSyncTree_'],_0x3757e4,!0x0));}else _0x24beae=!0x0,_0x717e9e='nodata',_0x4dc1ab=_0x4dc1ab['concat'](pe(_0x260d85['serverSyncTree_'],_0x1d01a8['currentWriteId'],!0x0));}}}V(_0x260d85['eventQueue_'],_0x45a231,_0x4dc1ab),_0x4dc1ab=[],_0x24beae&&(_0x251bd9[_0x4c7e09]['status']=0x2,function(_0x3bcedf){setTimeout(_0x3bcedf,Math['floor'](0x0));}(_0x251bd9[_0x4c7e09]['unwatcher']),_0x251bd9[_0x4c7e09]['onComplete']&&(_0x717e9e==='nodata'?_0x43c081['push'](()=>_0x251bd9[_0x4c7e09]['onComplete'](null,!0x1,_0x251bd9[_0x4c7e09]['currentInputSnapshot'])):_0x43c081['push'](()=>_0x251bd9[_0x4c7e09]['onComplete'](new Error(_0x717e9e),!0x1,null))));}$n(_0x260d85,_0x260d85['transactionQueueTree_']);for(let _0x53e9bd=0x0;_0x53e9bd<_0x43c081['length'];_0x53e9bd++)lt(_0x43c081[_0x53e9bd]);Hn(_0x260d85,_0x260d85['transactionQueueTree_']);}function ca(_0x6bf332,_0x1ebcd0){let _0x27fdd0,_0x48d568=_0x6bf332['transactionQueueTree_'];for(_0x27fdd0=y(_0x1ebcd0);_0x27fdd0!==null&&Ge(_0x48d568)===void 0x0;)_0x48d568=Un(_0x48d568,_0x27fdd0),_0x1ebcd0=b(_0x1ebcd0),_0x27fdd0=y(_0x1ebcd0);return _0x48d568;}function la(_0x4b48d8,_0x440daf){const _0x133f09=[];return ha(_0x4b48d8,_0x440daf,_0x133f09),_0x133f09['sort']((_0x11dcad,_0x128a46)=>_0x11dcad['order']-_0x128a46['order']),_0x133f09;}function ha(_0x5e950e,_0x3cf743,_0x1355b9){const _0x3b39bb=Ge(_0x3cf743);if(_0x3b39bb){for(let _0x1fc503=0x0;_0x1fc503<_0x3b39bb['length'];_0x1fc503++)_0x1355b9['push'](_0x3b39bb[_0x1fc503]);}Wn(_0x3cf743,_0x1e4121=>{ha(_0x5e950e,_0x1e4121,_0x1355b9);});}function $n(_0xd61e2b,_0x5f2210){const _0x13f629=Ge(_0x5f2210);if(_0x13f629){let _0x35eb98=0x0;for(let _0x362146=0x0;_0x362146<_0x13f629['length'];_0x362146++)_0x13f629[_0x362146]['status']!==0x2&&(_0x13f629[_0x35eb98]=_0x13f629[_0x362146],_0x35eb98++);_0x13f629['length']=_0x35eb98,fs(_0x5f2210,_0x13f629['length']>0x0?_0x13f629:void 0x0);}Wn(_0x5f2210,_0x5f2d9f=>{$n(_0xd61e2b,_0x5f2d9f);});}function vs(_0x3da2be,_0x40eb08){const _0x505aa8=Gt(ca(_0x3da2be,_0x40eb08)),_0x2677c2=Un(_0x3da2be['transactionQueueTree_'],_0x40eb08);return sd(_0x2677c2,_0x3b10fe=>{ai(_0x3da2be,_0x3b10fe);}),ai(_0x3da2be,_0x2677c2),ta(_0x2677c2,_0x5ab3f9=>{ai(_0x3da2be,_0x5ab3f9);}),_0x505aa8;}function ai(_0x4f9d1f,_0x46c180){const _0x39cfba=Ge(_0x46c180);if(_0x39cfba){const _0xd3f370=[];let _0x38be86=[],_0x1cc8a1=-0x1;for(let _0xa76659=0x0;_0xa76659<_0x39cfba['length'];_0xa76659++)_0x39cfba[_0xa76659]['status']===0x3||(_0x39cfba[_0xa76659]['status']===0x1?(f(_0x1cc8a1===_0xa76659-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1cc8a1=_0xa76659,_0x39cfba[_0xa76659]['status']=0x3,_0x39cfba[_0xa76659]['abortReason']='set'):(f(_0x39cfba[_0xa76659]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x39cfba[_0xa76659]['unwatcher'](),_0x38be86=_0x38be86['concat'](pe(_0x4f9d1f['serverSyncTree_'],_0x39cfba[_0xa76659]['currentWriteId'],!0x0)),_0x39cfba[_0xa76659]['onComplete']&&_0xd3f370['push'](_0x39cfba[_0xa76659]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1cc8a1===-0x1?fs(_0x46c180,void 0x0):_0x39cfba['length']=_0x1cc8a1+0x1,V(_0x4f9d1f['eventQueue_'],Gt(_0x46c180),_0x38be86);for(let _0x3b9d93=0x0;_0x3b9d93<_0xd3f370['length'];_0x3b9d93++)lt(_0xd3f370[_0x3b9d93]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x4eac1b){let _0x277b32='';const _0x1e7168=_0x4eac1b['split']('/');for(let _0x472378=0x0;_0x472378<_0x1e7168['length'];_0x472378++)if(_0x1e7168[_0x472378]['length']>0x0){let _0x5d0a00=_0x1e7168[_0x472378];try{_0x5d0a00=decodeURIComponent(_0x5d0a00['replace'](/\+/g,'\x20'));}catch{}_0x277b32+='/'+_0x5d0a00;}return _0x277b32;}function Nd(_0x1f217b){const _0x13f64a={};_0x1f217b['charAt'](0x0)==='?'&&(_0x1f217b=_0x1f217b['substring'](0x1));for(const _0x51ede7 of _0x1f217b['split']('&')){if(_0x51ede7['length']===0x0)continue;const _0x1a3f35=_0x51ede7['split']('=');_0x1a3f35['length']===0x2?_0x13f64a[decodeURIComponent(_0x1a3f35[0x0])]=decodeURIComponent(_0x1a3f35[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x51ede7+'\x27\x20in\x20query\x20\x27'+_0x1f217b+'\x27');}return _0x13f64a;}const gr=function(_0x92104c,_0x2e767c){const _0x40ae5a=Pd(_0x92104c),_0x4cee48=_0x40ae5a['namespace'];_0x40ae5a['domain']==='firebase.com'&&oe(_0x40ae5a['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4cee48||_0x4cee48==='undefined')&&_0x40ae5a['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x40ae5a['secure']||Bl();const _0x4a3baf=_0x40ae5a['scheme']==='ws'||_0x40ae5a['scheme']==='wss';return{'repoInfo':new _o(_0x40ae5a['host'],_0x40ae5a['secure'],_0x4cee48,_0x4a3baf,_0x2e767c,'',_0x4cee48!==_0x40ae5a['subdomain']),'path':new C(_0x40ae5a['pathString'])};},Pd=function(_0x2fceb9){let _0x3d307c='',_0x1edfc9='',_0x47cef8='',_0x104c2b='',_0x1df10d='',_0x29fef4=!0x0,_0x450e3e='https',_0x1c9b3d=0x1bb;if(typeof _0x2fceb9=='string'){let _0x6d716=_0x2fceb9['indexOf']('//');_0x6d716>=0x0&&(_0x450e3e=_0x2fceb9['substring'](0x0,_0x6d716-0x1),_0x2fceb9=_0x2fceb9['substring'](_0x6d716+0x2));let _0xd3c78c=_0x2fceb9['indexOf']('/');_0xd3c78c===-0x1&&(_0xd3c78c=_0x2fceb9['length']);let _0x4d1566=_0x2fceb9['indexOf']('?');_0x4d1566===-0x1&&(_0x4d1566=_0x2fceb9['length']),_0x3d307c=_0x2fceb9['substring'](0x0,Math['min'](_0xd3c78c,_0x4d1566)),_0xd3c78c<_0x4d1566&&(_0x104c2b=kd(_0x2fceb9['substring'](_0xd3c78c,_0x4d1566)));const _0x1c14ef=Nd(_0x2fceb9['substring'](Math['min'](_0x2fceb9['length'],_0x4d1566)));_0x6d716=_0x3d307c['indexOf'](':'),_0x6d716>=0x0?(_0x29fef4=_0x450e3e==='https'||_0x450e3e==='wss',_0x1c9b3d=parseInt(_0x3d307c['substring'](_0x6d716+0x1),0xa)):_0x6d716=_0x3d307c['length'];const _0x255bb7=_0x3d307c['slice'](0x0,_0x6d716);if(_0x255bb7['toLowerCase']()==='localhost')_0x1edfc9='localhost';else{if(_0x255bb7['split']('.')['length']<=0x2)_0x1edfc9=_0x255bb7;else{const _0x4fcf29=_0x3d307c['indexOf']('.');_0x47cef8=_0x3d307c['substring'](0x0,_0x4fcf29)['toLowerCase'](),_0x1edfc9=_0x3d307c['substring'](_0x4fcf29+0x1),_0x1df10d=_0x47cef8;}}'ns'in _0x1c14ef&&(_0x1df10d=_0x1c14ef['ns']);}return{'host':_0x3d307c,'port':_0x1c9b3d,'domain':_0x1edfc9,'subdomain':_0x47cef8,'secure':_0x29fef4,'scheme':_0x450e3e,'pathString':_0x104c2b,'namespace':_0x1df10d};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x427d57=0x0;const _0x23ce5a=[];return function(_0xbba5aa){const _0x1edaf7=_0xbba5aa===_0x427d57;_0x427d57=_0xbba5aa;let _0x5f3612;const _0x3c6808=new Array(0x8);for(_0x5f3612=0x7;_0x5f3612>=0x0;_0x5f3612--)_0x3c6808[_0x5f3612]=mr['charAt'](_0xbba5aa%0x40),_0xbba5aa=Math['floor'](_0xbba5aa/0x40);f(_0xbba5aa===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x4d2aee=_0x3c6808['join']('');if(_0x1edaf7){for(_0x5f3612=0xb;_0x5f3612>=0x0&&_0x23ce5a[_0x5f3612]===0x3f;_0x5f3612--)_0x23ce5a[_0x5f3612]=0x0;_0x23ce5a[_0x5f3612]++;}else{for(_0x5f3612=0x0;_0x5f3612<0xc;_0x5f3612++)_0x23ce5a[_0x5f3612]=Math['floor'](Math['random']()*0x40);}for(_0x5f3612=0x0;_0x5f3612<0xc;_0x5f3612++)_0x4d2aee+=mr['charAt'](_0x23ce5a[_0x5f3612]);return f(_0x4d2aee['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x4d2aee;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x455a41,_0x184fc8,_0x589dad,_0x35e8c6){this['eventType']=_0x455a41,this['eventRegistration']=_0x184fc8,this['snapshot']=_0x589dad,this['prevName']=_0x35e8c6;}['getPath'](){const _0xe19621=this['snapshot']['ref'];return this['eventType']==='value'?_0xe19621['_path']:_0xe19621['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x447f5d,_0x47ab18,_0x4a4419){this['eventRegistration']=_0x447f5d,this['error']=_0x47ab18,this['path']=_0x4a4419;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x106488,_0x12f57b){this['snapshotCallback']=_0x106488,this['cancelCallback']=_0x12f57b;}['onValue'](_0x209ed8,_0x28f6c1){this['snapshotCallback']['call'](null,_0x209ed8,_0x28f6c1);}['onCancel'](_0x31a859){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x31a859);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1ebe1f){return this['snapshotCallback']===_0x1ebe1f['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1ebe1f['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1ebe1f['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x303f47,_0x4c918e,_0x161b8b,_0x21fc8f){this['_repo']=_0x303f47,this['_path']=_0x4c918e,this['_queryParams']=_0x161b8b,this['_orderByCalled']=_0x21fc8f;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5f02b2=nr(this['_queryParams']),_0x599a45=Bi(_0x5f02b2);return _0x599a45==='{}'?'default':_0x599a45;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x3ebea8){if(_0x3ebea8=k(_0x3ebea8),!(_0x3ebea8 instanceof be))return!0x1;const _0x2ac11a=this['_repo']===_0x3ebea8['_repo'],_0x34180a=qi(this['_path'],_0x3ebea8['_path']),_0x2446d8=this['_queryIdentifier']===_0x3ebea8['_queryIdentifier'];return _0x2ac11a&&_0x34180a&&_0x2446d8;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x143f65,_0xec3d3b){if(_0x143f65['_orderByCalled']===!0x0)throw new Error(_0xec3d3b+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x52f41a){let _0x2236d6=null,_0x5b1d93=null;if(_0x52f41a['hasStart']()&&(_0x2236d6=_0x52f41a['getIndexStartValue']()),_0x52f41a['hasEnd']()&&(_0x5b1d93=_0x52f41a['getIndexEndValue']()),_0x52f41a['getIndex']()===ye){const _0x4254df='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x115abc='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x52f41a['hasStart']()){if(_0x52f41a['getIndexStartName']()!==xe)throw new Error(_0x4254df);if(typeof _0x2236d6!='string')throw new Error(_0x115abc);}if(_0x52f41a['hasEnd']()){if(_0x52f41a['getIndexEndName']()!==Ie)throw new Error(_0x4254df);if(typeof _0x5b1d93!='string')throw new Error(_0x115abc);}}else{if(_0x52f41a['getIndex']()===R){if(_0x2236d6!=null&&!Cn(_0x2236d6)||_0x5b1d93!=null&&!Cn(_0x5b1d93))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x52f41a['getIndex']()instanceof Ki||_0x52f41a['getIndex']()===Po,'unknown\x20index\x20type.'),_0x2236d6!=null&&typeof _0x2236d6=='object'||_0x5b1d93!=null&&typeof _0x5b1d93=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x14e27d){if(_0x14e27d['hasStart']()&&_0x14e27d['hasEnd']()&&_0x14e27d['hasLimit']()&&!_0x14e27d['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x202792,_0x1090ed){super(_0x202792,_0x1090ed,new Qi(),!0x1);}get['parent'](){const _0x31e6e3=To(this['_path']);return _0x31e6e3===null?null:new Z(this['_repo'],_0x31e6e3);}get['root'](){let _0x83cbe7=this;for(;_0x83cbe7['parent']!==null;)_0x83cbe7=_0x83cbe7['parent'];return _0x83cbe7;}}class rt{constructor(_0x13ae63,_0x442c7b,_0x44e76d){this['_node']=_0x13ae63,this['ref']=_0x442c7b,this['_index']=_0x44e76d;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x14aaf2){const _0x411e5f=new C(_0x14aaf2),_0x232e2f=Lt(this['ref'],_0x14aaf2);return new rt(this['_node']['getChild'](_0x411e5f),_0x232e2f,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1b187d){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x369a0b,_0x307c87)=>_0x1b187d(new rt(_0x307c87,Lt(this['ref'],_0x369a0b),R)));}['hasChild'](_0x55d084){const _0x2a97bd=new C(_0x55d084);return!this['_node']['getChild'](_0x2a97bd)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x29859a,_0x39f465){return _0x29859a=k(_0x29859a),_0x29859a['_checkNotDeleted']('ref'),_0x39f465!==void 0x0?Lt(_0x29859a['_root'],_0x39f465):_0x29859a['_root'];}function Lt(_0x14e728,_0x5716ca){return _0x14e728=k(_0x14e728),y(_0x14e728['_path'])===null?ud('child','path',_0x5716ca):_s('child','path',_0x5716ca),new Z(_0x14e728['_repo'],A(_0x14e728['_path'],_0x5716ca));}function d_(_0x29f6f3,_0x24c7f1){_0x29f6f3=k(_0x29f6f3),gs('push',_0x29f6f3['_path']),qt('push',_0x24c7f1,_0x29f6f3['_path'],!0x0);const _0x5a5065=oa(_0x29f6f3['_repo']),_0xf9b054=Od(_0x5a5065),_0x4a8bee=Lt(_0x29f6f3,_0xf9b054),_0x453393=Lt(_0x29f6f3,_0xf9b054);let _0x450d4;return _0x24c7f1!=null?_0x450d4=Ld(_0x453393,_0x24c7f1)['then'](()=>_0x453393):_0x450d4=Promise['resolve'](_0x453393),_0x4a8bee['then']=_0x450d4['then']['bind'](_0x450d4),_0x4a8bee['catch']=_0x450d4['then']['bind'](_0x450d4,void 0x0),_0x4a8bee;}function Ld(_0xe6e77b,_0x17ee93){_0xe6e77b=k(_0xe6e77b),gs('set',_0xe6e77b['_path']),qt('set',_0x17ee93,_0xe6e77b['_path'],!0x1);const _0x152e22=new Ve();return Ed(_0xe6e77b['_repo'],_0xe6e77b['_path'],_0x17ee93,null,_0x152e22['wrapCallback'](()=>{})),_0x152e22['promise'];}function f_(_0x46dc2a,_0x46b6ac){hd('update',_0x46b6ac,_0x46dc2a['_path']);const _0x377d45=new Ve();return Id(_0x46dc2a['_repo'],_0x46dc2a['_path'],_0x46b6ac,_0x377d45['wrapCallback'](()=>{})),_0x377d45['promise'];}function p_(_0x1a8d8a){_0x1a8d8a=k(_0x1a8d8a);const _0x54e1ec=new ua(()=>{}),_0x282eb8=new qn(_0x54e1ec);return vd(_0x1a8d8a['_repo'],_0x1a8d8a,_0x282eb8)['then'](_0x385d0c=>new rt(_0x385d0c,new Z(_0x1a8d8a['_repo'],_0x1a8d8a['_path']),_0x1a8d8a['_queryParams']['getIndex']()));}class qn{constructor(_0x40f75a){this['callbackContext']=_0x40f75a;}['respondsTo'](_0x552231){return _0x552231==='value';}['createEvent'](_0x3f8f86,_0x378310){const _0x2a291d=_0x378310['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x3f8f86['snapshotNode'],new Z(_0x378310['_repo'],_0x378310['_path']),_0x2a291d));}['getEventRunner'](_0x52ffc1){return _0x52ffc1['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x52ffc1['error']):()=>this['callbackContext']['onValue'](_0x52ffc1['snapshot'],null);}['createCancelEvent'](_0xec108c,_0x265e4d){return this['callbackContext']['hasCancelCallback']?new Md(this,_0xec108c,_0x265e4d):null;}['matches'](_0x1c98b1){return _0x1c98b1 instanceof qn?!_0x1c98b1['callbackContext']||!this['callbackContext']?!0x0:_0x1c98b1['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x3cf008,_0x2c72e9,_0x2e4a2c,_0x2aeeac,_0x510252){const _0x257836=new ua(_0x2e4a2c,void 0x0),_0x2837cf=new qn(_0x257836);return Cd(_0x3cf008['_repo'],_0x3cf008,_0x2837cf),()=>Td(_0x3cf008['_repo'],_0x3cf008,_0x2837cf);}function Fd(_0x2b9d02,_0x596d47,_0x2cbb8d,_0x12111a){return xd(_0x2b9d02,'value',_0x596d47);}class dt{}class pa extends dt{constructor(_0x5826eb,_0x8cb6bf){super(),this['_value']=_0x5826eb,this['_key']=_0x8cb6bf,this['type']='endAt';}['_apply'](_0x182d0f){qt('endAt',this['_value'],_0x182d0f['_path'],!0x0);const _0x55fe1b=Kh(_0x182d0f['_queryParams'],this['_value'],this['_key']);if(fa(_0x55fe1b),Gn(_0x55fe1b),_0x182d0f['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x182d0f['_repo'],_0x182d0f['_path'],_0x55fe1b,_0x182d0f['_orderByCalled']);}}function __(_0x5888e9,_0x235522){return new pa(_0x5888e9,_0x235522);}class _a extends dt{constructor(_0x327e06,_0x24e6a0){super(),this['_value']=_0x327e06,this['_key']=_0x24e6a0,this['type']='startAt';}['_apply'](_0x27ec60){qt('startAt',this['_value'],_0x27ec60['_path'],!0x0);const _0x1e9503=jh(_0x27ec60['_queryParams'],this['_value'],this['_key']);if(fa(_0x1e9503),Gn(_0x1e9503),_0x27ec60['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x27ec60['_repo'],_0x27ec60['_path'],_0x1e9503,_0x27ec60['_orderByCalled']);}}function g_(_0x362567=null,_0x2ad62b){return new _a(_0x362567,_0x2ad62b);}class Ud extends dt{constructor(_0x3dcab0){super(),this['_limit']=_0x3dcab0,this['type']='limitToFirst';}['_apply'](_0x3e9681){if(_0x3e9681['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x3e9681['_repo'],_0x3e9681['_path'],zh(_0x3e9681['_queryParams'],this['_limit']),_0x3e9681['_orderByCalled']);}}function m_(_0x2b7fee){if(Math['floor'](_0x2b7fee)!==_0x2b7fee||_0x2b7fee<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x2b7fee);}class Wd extends dt{constructor(_0x53874a){super(),this['_path']=_0x53874a,this['type']='orderByChild';}['_apply'](_0x2062a4){da(_0x2062a4,'orderByChild');const _0x2e8487=new C(this['_path']);if(v(_0x2e8487))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x587359=new Ki(_0x2e8487),_0x23308b=Do(_0x2062a4['_queryParams'],_0x587359);return Gn(_0x23308b),new be(_0x2062a4['_repo'],_0x2062a4['_path'],_0x23308b,!0x0);}}function y_(_0x1f8473){if(_0x1f8473==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1f8473==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1f8473==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x1f8473),new Wd(_0x1f8473);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3aedfe){da(_0x3aedfe,'orderByKey');const _0x1224f1=Do(_0x3aedfe['_queryParams'],ye);return Gn(_0x1224f1),new be(_0x3aedfe['_repo'],_0x3aedfe['_path'],_0x1224f1,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x3edb13,_0x1c57ac){super(),this['_value']=_0x3edb13,this['_key']=_0x1c57ac,this['type']='equalTo';}['_apply'](_0x232292){if(qt('equalTo',this['_value'],_0x232292['_path'],!0x1),_0x232292['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x232292['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x232292));}}function E_(_0x28858a,_0x3f61e3){return new Vd(_0x28858a,_0x3f61e3);}function I_(_0x3962c8,..._0x253f87){let _0x5b3cc4=k(_0x3962c8);for(const _0x363f3f of _0x253f87)_0x5b3cc4=_0x363f3f['_apply'](_0x5b3cc4);return _0x5b3cc4;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x30d29b,_0x10eb17,_0x13c813,_0x48e06e){const _0x4c86de=_0x10eb17['lastIndexOf'](':'),_0x2ee359=_0x10eb17['substring'](0x0,_0x4c86de),_0x492074=Wt(_0x2ee359);_0x30d29b['repoInfo_']=new _o(_0x10eb17,_0x492074,_0x30d29b['repoInfo_']['namespace'],_0x30d29b['repoInfo_']['webSocketOnly'],_0x30d29b['repoInfo_']['nodeAdmin'],_0x30d29b['repoInfo_']['persistenceKey'],_0x30d29b['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x13c813),_0x48e06e&&(_0x30d29b['authTokenProvider_']=_0x48e06e);}function qd(_0x11b6d3,_0xe3650a,_0x319322,_0x2fb6a6,_0x5210dd){let _0x1dda4b=_0x2fb6a6||_0x11b6d3['options']['databaseURL'];_0x1dda4b===void 0x0&&(_0x11b6d3['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x11b6d3['options']['projectId']),_0x1dda4b=_0x11b6d3['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x866eff=gr(_0x1dda4b,_0x5210dd),_0x50c141=_0x866eff['repoInfo'],_0x19e5a1;typeof process<'u'&&Us&&(_0x19e5a1=Us[Hd]),_0x19e5a1?(_0x1dda4b='http://'+_0x19e5a1+'?ns='+_0x50c141['namespace'],_0x866eff=gr(_0x1dda4b,_0x5210dd),_0x50c141=_0x866eff['repoInfo']):_0x866eff['repoInfo']['secure'];const _0x488cf3=new Jl(_0x11b6d3['name'],_0x11b6d3['options'],_0xe3650a);dd('Invalid\x20Firebase\x20Database\x20URL',_0x866eff),v(_0x866eff['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x1440aa=jd(_0x50c141,_0x11b6d3,_0x488cf3,new Ql(_0x11b6d3,_0x319322));return new Kd(_0x1440aa,_0x11b6d3);}function zd(_0x1aca8e,_0x34a1a1){const _0x399bac=ki[_0x34a1a1];(!_0x399bac||_0x399bac[_0x1aca8e['key']]!==_0x1aca8e)&&oe('Database\x20'+_0x34a1a1+'('+_0x1aca8e['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x1aca8e),delete _0x399bac[_0x1aca8e['key']];}function jd(_0x43c0b5,_0x3ee6c8,_0x27160e,_0x40f2da){let _0x29c20a=ki[_0x3ee6c8['name']];_0x29c20a||(_0x29c20a={},ki[_0x3ee6c8['name']]=_0x29c20a);let _0x4b69d=_0x29c20a[_0x43c0b5['toURLString']()];return _0x4b69d&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4b69d=new gd(_0x43c0b5,$d,_0x27160e,_0x40f2da),_0x29c20a[_0x43c0b5['toURLString']()]=_0x4b69d,_0x4b69d;}class Kd{constructor(_0x329919,_0x4910e7){this['_repoInternal']=_0x329919,this['app']=_0x4910e7,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x8fe48c){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x8fe48c+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x29bce7=Qr(),_0x1af402){const _0x44c29f=Ui(_0x29bce7,'database')['getImmediate']({'identifier':_0x1af402});if(!_0x44c29f['_instanceStarted']){const _0x409651=ac('database');_0x409651&&Yd(_0x44c29f,..._0x409651);}return _0x44c29f;}function Yd(_0xff0b2f,_0x42ccb5,_0x15806a,_0x324f74={}){_0xff0b2f=k(_0xff0b2f),_0xff0b2f['_checkNotDeleted']('useEmulator');const _0x755d2d=_0x42ccb5+':'+_0x15806a,_0xe22a16=_0xff0b2f['_repoInternal'];if(_0xff0b2f['_instanceStarted']){if(_0x755d2d===_0xff0b2f['_repoInternal']['repoInfo_']['host']&&De(_0x324f74,_0xe22a16['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x31dc97;if(_0xe22a16['repoInfo_']['nodeAdmin'])_0x324f74['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x31dc97=new tn(tn['OWNER']);else{if(_0x324f74['mockUserToken']){const _0x2591f4=typeof _0x324f74['mockUserToken']=='string'?_0x324f74['mockUserToken']:cc(_0x324f74['mockUserToken'],_0xff0b2f['app']['options']['projectId']);_0x31dc97=new tn(_0x2591f4);}}Wt(_0x42ccb5)&&jr(_0x42ccb5),Gd(_0xe22a16,_0x755d2d,_0x324f74,_0x31dc97);}function C_(_0x42c51f){_0x42c51f=k(_0x42c51f),_0x42c51f['_checkNotDeleted']('goOffline'),aa(_0x42c51f['_repo']);}function T_(_0x2957ac){_0x2957ac=k(_0x2957ac),_0x2957ac['_checkNotDeleted']('goOnline'),Sd(_0x2957ac['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x91c9){Ll(ct),et(new Me('database',(_0xf30532,{instanceIdentifier:_0x5e9e28})=>{const _0xd65d62=_0xf30532['getProvider']('app')['getImmediate'](),_0x5cb553=_0xf30532['getProvider']('auth-internal'),_0x201c9f=_0xf30532['getProvider']('app-check-internal');return qd(_0xd65d62,_0x5cb553,_0x201c9f,_0x5e9e28);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x91c9),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x307746,_0x5afe91){this['committed']=_0x307746,this['snapshot']=_0x5afe91;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x54acb5,_0xc44b33,_0x712ddd){if(_0x54acb5=k(_0x54acb5),gs('Reference.transaction',_0x54acb5['_path']),_0x54acb5['key']==='.length'||_0x54acb5['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x54acb5['key']+'\x20is\x20a\x20read-only\x20object.';const _0x390688=!0x0,_0x373423=new Ve(),_0x404e9d=(_0x46681a,_0x26f23d,_0x425839)=>{let _0x1c21e1=null;_0x46681a?_0x373423['reject'](_0x46681a):(_0x1c21e1=new rt(_0x425839,new Z(_0x54acb5['_repo'],_0x54acb5['_path']),R),_0x373423['resolve'](new Xd(_0x26f23d,_0x1c21e1)));},_0x4773f2=Fd(_0x54acb5,()=>{});return bd(_0x54acb5['_repo'],_0x54acb5['_path'],_0xc44b33,_0x404e9d,_0x4773f2,_0x390688),_0x373423['promise'];}ie['prototype']['simpleListen']=function(_0x2dd2a4,_0x29118d){this['sendRequest']('q',{'p':_0x2dd2a4},_0x29118d);},ie['prototype']['echo']=function(_0x293f54,_0x4e0237){this['sendRequest']('echo',{'d':_0x293f54},_0x4e0237);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x2758bc,..._0xda973c){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x2758bc,..._0xda973c);}function nn(_0x2968d3,..._0x37977a){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x2968d3,..._0x37977a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x1b0304,..._0x183029){throw Es(_0x1b0304,..._0x183029);}function J(_0x361622,..._0x562f3b){return Es(_0x361622,..._0x562f3b);}function ya(_0x194988,_0x2cbb53,_0x3ffc06){const _0x24ca41={...Zd(),[_0x2cbb53]:_0x3ffc06};return new Ut('auth','Firebase',_0x24ca41)['create'](_0x2cbb53,{'appName':_0x194988['name']});}function se(_0x14c590){return ya(_0x14c590,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x5259e4,..._0x99f188){if(typeof _0x5259e4!='string'){const _0x2708d1=_0x99f188[0x0],_0x3ee381=[..._0x99f188['slice'](0x1)];return _0x3ee381[0x0]&&(_0x3ee381[0x0]['appName']=_0x5259e4['name']),_0x5259e4['_errorFactory']['create'](_0x2708d1,..._0x3ee381);}return ma['create'](_0x5259e4,..._0x99f188);}function m(_0xc581c6,_0x54084b,..._0x4527b9){if(!_0xc581c6)throw Es(_0x54084b,..._0x4527b9);}function te(_0x278a4e){const _0x525524='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x278a4e;throw nn(_0x525524),new Error(_0x525524);}function ae(_0x15b967,_0x480518){_0x15b967||te(_0x480518);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x3b3532;return typeof self<'u'&&((_0x3b3532=self['location'])==null?void 0x0:_0x3b3532['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x38c574;return typeof self<'u'&&((_0x38c574=self['location'])==null?void 0x0:_0x38c574['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x2b72c1=navigator;return _0x2b72c1['languages']&&_0x2b72c1['languages'][0x0]||_0x2b72c1['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x40fa12,_0x545677){this['shortDelay']=_0x40fa12,this['longDelay']=_0x545677,ae(_0x545677>_0x40fa12,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x3c1260,_0x5a3ce8){ae(_0x3c1260['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2a4c7e}=_0x3c1260['emulator'];return _0x5a3ce8?''+_0x2a4c7e+(_0x5a3ce8['startsWith']('/')?_0x5a3ce8['slice'](0x1):_0x5a3ce8):_0x2a4c7e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x406832,_0x55a514,_0x14b075){this['fetchImpl']=_0x406832,_0x55a514&&(this['headersImpl']=_0x55a514),_0x14b075&&(this['responseImpl']=_0x14b075);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x1b8073,_0x1ffbfd){return _0x1b8073['tenantId']&&!_0x1ffbfd['tenantId']?{..._0x1ffbfd,'tenantId':_0x1b8073['tenantId']}:_0x1ffbfd;}async function Ae(_0x357ddb,_0x367929,_0x30f6e5,_0x368443,_0x3775b3={}){return Ea(_0x357ddb,_0x3775b3,async()=>{let _0x5ad56a={},_0x5bbfb2={};_0x368443&&(_0x367929==='GET'?_0x5bbfb2=_0x368443:_0x5ad56a={'body':JSON['stringify'](_0x368443)});const _0x3fbace=at({..._0x5bbfb2,'key':_0x357ddb['config']['apiKey']})['slice'](0x1),_0x37528a=await _0x357ddb['_getAdditionalHeaders']();_0x37528a['Content-Type']='application/json',_0x357ddb['languageCode']&&(_0x37528a['X-Firebase-Locale']=_0x357ddb['languageCode']);const _0x42fb7e={'method':_0x367929,'headers':_0x37528a,..._0x5ad56a};return lc()||(_0x42fb7e['referrerPolicy']='strict-origin-when-cross-origin'),_0x357ddb['emulatorConfig']&&Wt(_0x357ddb['emulatorConfig']['host'])&&(_0x42fb7e['credentials']='include'),va['fetch']()(await Ia(_0x357ddb,_0x357ddb['config']['apiHost'],_0x30f6e5,_0x3fbace),_0x42fb7e);});}async function Ea(_0x41eed5,_0x3aae87,_0x2ae7fe){_0x41eed5['_canInitEmulator']=!0x1;const _0x6e2b6c={...rf,..._0x3aae87};try{const _0xa389ba=new lf(_0x41eed5),_0x5c4888=await Promise['race']([_0x2ae7fe(),_0xa389ba['promise']]);_0xa389ba['clearNetworkTimeout']();const _0x56bfa8=await _0x5c4888['json']();if('needConfirmation'in _0x56bfa8)throw en(_0x41eed5,'account-exists-with-different-credential',_0x56bfa8);if(_0x5c4888['ok']&&!('errorMessage'in _0x56bfa8))return _0x56bfa8;{const _0x3b2194=_0x5c4888['ok']?_0x56bfa8['errorMessage']:_0x56bfa8['error']['message'],[_0x43891e,_0x53cd35]=_0x3b2194['split']('\x20:\x20');if(_0x43891e==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x41eed5,'credential-already-in-use',_0x56bfa8);if(_0x43891e==='EMAIL_EXISTS')throw en(_0x41eed5,'email-already-in-use',_0x56bfa8);if(_0x43891e==='USER_DISABLED')throw en(_0x41eed5,'user-disabled',_0x56bfa8);const _0xe4776d=_0x6e2b6c[_0x43891e]||_0x43891e['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x53cd35)throw ya(_0x41eed5,_0xe4776d,_0x53cd35);K(_0x41eed5,_0xe4776d);}}catch(_0x382c5f){if(_0x382c5f instanceof Se)throw _0x382c5f;K(_0x41eed5,'network-request-failed',{'message':String(_0x382c5f)});}}async function Yt(_0x4dfbdf,_0x379acf,_0xddac19,_0x5e28ce,_0x5e7eca={}){const _0x5ca70b=await Ae(_0x4dfbdf,_0x379acf,_0xddac19,_0x5e28ce,_0x5e7eca);return'mfaPendingCredential'in _0x5ca70b&&K(_0x4dfbdf,'multi-factor-auth-required',{'_serverResponse':_0x5ca70b}),_0x5ca70b;}async function Ia(_0x176ccb,_0x1917e2,_0x2f51fc,_0x273f0e){const _0x20ac20=''+_0x1917e2+_0x2f51fc+'?'+_0x273f0e,_0x136d9c=_0x176ccb,_0xa4ef9f=_0x136d9c['config']['emulator']?Is(_0x176ccb['config'],_0x20ac20):_0x176ccb['config']['apiScheme']+'://'+_0x20ac20;return of['includes'](_0x2f51fc)&&(await _0x136d9c['_persistenceManagerAvailable'],_0x136d9c['_getPersistenceType']()==='COOKIE')?_0x136d9c['_getPersistence']()['_getFinalTarget'](_0xa4ef9f)['toString']():_0xa4ef9f;}function cf(_0x173e64){switch(_0x173e64){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3b43a1){this['auth']=_0x3b43a1,this['timer']=null,this['promise']=new Promise((_0x350923,_0x569a4c)=>{this['timer']=setTimeout(()=>_0x569a4c(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x21ca78,_0x311160,_0x5746b5){const _0xbcc66a={'appName':_0x21ca78['name']};_0x5746b5['email']&&(_0xbcc66a['email']=_0x5746b5['email']),_0x5746b5['phoneNumber']&&(_0xbcc66a['phoneNumber']=_0x5746b5['phoneNumber']);const _0x2320cc=J(_0x21ca78,_0x311160,_0xbcc66a);return _0x2320cc['customData']['_tokenResponse']=_0x5746b5,_0x2320cc;}function vr(_0x51f1f4){return _0x51f1f4!==void 0x0&&_0x51f1f4['enterprise']!==void 0x0;}class hf{constructor(_0x502c3c){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x502c3c['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x502c3c['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x502c3c['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1847a){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x141203 of this['recaptchaEnforcementState'])if(_0x141203['provider']&&_0x141203['provider']===_0x1847a)return cf(_0x141203['enforcementState']);return null;}['isProviderEnabled'](_0x417796){return this['getProviderEnforcementState'](_0x417796)==='ENFORCE'||this['getProviderEnforcementState'](_0x417796)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0xd61e4c,_0x387174){return Ae(_0xd61e4c,'GET','/v2/recaptchaConfig',Re(_0xd61e4c,_0x387174));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0xe11f40,_0x281132){return Ae(_0xe11f40,'POST','/v1/accounts:delete',_0x281132);}async function Sn(_0x3b5cab,_0x559fc4){return Ae(_0x3b5cab,'POST','/v1/accounts:lookup',_0x559fc4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x4840a2){if(_0x4840a2)try{const _0x44a221=new Date(Number(_0x4840a2));if(!isNaN(_0x44a221['getTime']()))return _0x44a221['toUTCString']();}catch{}}async function ff(_0x43ad18,_0x38486f=!0x1){const _0x5c3c67=k(_0x43ad18),_0x5de80e=await _0x5c3c67['getIdToken'](_0x38486f),_0x56e954=ws(_0x5de80e);m(_0x56e954&&_0x56e954['exp']&&_0x56e954['auth_time']&&_0x56e954['iat'],_0x5c3c67['auth'],'internal-error');const _0x3de2d3=typeof _0x56e954['firebase']=='object'?_0x56e954['firebase']:void 0x0,_0x486d3c=_0x3de2d3==null?void 0x0:_0x3de2d3['sign_in_provider'];return{'claims':_0x56e954,'token':_0x5de80e,'authTime':St(ci(_0x56e954['auth_time'])),'issuedAtTime':St(ci(_0x56e954['iat'])),'expirationTime':St(ci(_0x56e954['exp'])),'signInProvider':_0x486d3c||null,'signInSecondFactor':(_0x3de2d3==null?void 0x0:_0x3de2d3['sign_in_second_factor'])||null};}function ci(_0xaa1efb){return Number(_0xaa1efb)*0x3e8;}function ws(_0x2d21c1){const [_0x2c5a75,_0x46faf2,_0x1fe0af]=_0x2d21c1['split']('.');if(_0x2c5a75===void 0x0||_0x46faf2===void 0x0||_0x1fe0af===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x196484=cn(_0x46faf2);return _0x196484?JSON['parse'](_0x196484):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x19e295){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x19e295==null?void 0x0:_0x19e295['toString']()),null;}}function Er(_0x3fe230){const _0x439001=ws(_0x3fe230);return m(_0x439001,'internal-error'),m(typeof _0x439001['exp']<'u','internal-error'),m(typeof _0x439001['iat']<'u','internal-error'),Number(_0x439001['exp'])-Number(_0x439001['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x28a9d4,_0x5749bd,_0x457806=!0x1){if(_0x457806)return _0x5749bd;try{return await _0x5749bd;}catch(_0x393f69){throw _0x393f69 instanceof Se&&pf(_0x393f69)&&_0x28a9d4['auth']['currentUser']===_0x28a9d4&&await _0x28a9d4['auth']['signOut'](),_0x393f69;}}function pf({code:_0x59ea15}){return _0x59ea15==='auth/user-disabled'||_0x59ea15==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x4a7191){this['user']=_0x4a7191,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x489fc1){if(_0x489fc1){const _0x19c985=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x19c985;}else{this['errorBackoff']=0x7530;const _0x1a860f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1a860f);}}['schedule'](_0x5c2dde=!0x1){if(!this['isRunning'])return;const _0x36f109=this['getInterval'](_0x5c2dde);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x36f109);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xace369){(_0xace369==null?void 0x0:_0xace369['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x2cacd9,_0x496fb0){this['createdAt']=_0x2cacd9,this['lastLoginAt']=_0x496fb0,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x24b172){this['createdAt']=_0x24b172['createdAt'],this['lastLoginAt']=_0x24b172['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x26a42c){var _0xc80fa7;const _0xc8be45=_0x26a42c['auth'],_0x55b645=await _0x26a42c['getIdToken'](),_0x274bc2=await xt(_0x26a42c,Sn(_0xc8be45,{'idToken':_0x55b645}));m(_0x274bc2==null?void 0x0:_0x274bc2['users']['length'],_0xc8be45,'internal-error');const _0x2397b6=_0x274bc2['users'][0x0];_0x26a42c['_notifyReloadListener'](_0x2397b6);const _0x12907a=(_0xc80fa7=_0x2397b6['providerUserInfo'])!=null&&_0xc80fa7['length']?wa(_0x2397b6['providerUserInfo']):[],_0x18236d=mf(_0x26a42c['providerData'],_0x12907a),_0x1f4195=_0x26a42c['isAnonymous'],_0x3a7db8=!(_0x26a42c['email']&&_0x2397b6['passwordHash'])&&!(_0x18236d!=null&&_0x18236d['length']),_0x45ab20=_0x1f4195?_0x3a7db8:!0x1,_0x54b3e4={'uid':_0x2397b6['localId'],'displayName':_0x2397b6['displayName']||null,'photoURL':_0x2397b6['photoUrl']||null,'email':_0x2397b6['email']||null,'emailVerified':_0x2397b6['emailVerified']||!0x1,'phoneNumber':_0x2397b6['phoneNumber']||null,'tenantId':_0x2397b6['tenantId']||null,'providerData':_0x18236d,'metadata':new Pi(_0x2397b6['createdAt'],_0x2397b6['lastLoginAt']),'isAnonymous':_0x45ab20};Object['assign'](_0x26a42c,_0x54b3e4);}async function gf(_0x33e320){const _0x59c867=k(_0x33e320);await bn(_0x59c867),await _0x59c867['auth']['_persistUserIfCurrent'](_0x59c867),_0x59c867['auth']['_notifyListenersIfCurrent'](_0x59c867);}function mf(_0x25d974,_0x58d66b){return[..._0x25d974['filter'](_0x1b25fe=>!_0x58d66b['some'](_0x4e99ff=>_0x4e99ff['providerId']===_0x1b25fe['providerId'])),..._0x58d66b];}function wa(_0x1a7a28){return _0x1a7a28['map'](({providerId:_0x578612,..._0x4b4f5b})=>({'providerId':_0x578612,'uid':_0x4b4f5b['rawId']||'','displayName':_0x4b4f5b['displayName']||null,'email':_0x4b4f5b['email']||null,'phoneNumber':_0x4b4f5b['phoneNumber']||null,'photoURL':_0x4b4f5b['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x5441d6,_0x366342){const _0x2346d6=await Ea(_0x5441d6,{},async()=>{const _0x13fb4e=at({'grant_type':'refresh_token','refresh_token':_0x366342})['slice'](0x1),{tokenApiHost:_0x4b4cf6,apiKey:_0x479025}=_0x5441d6['config'],_0x10d61b=await Ia(_0x5441d6,_0x4b4cf6,'/v1/token','key='+_0x479025),_0x1dad50=await _0x5441d6['_getAdditionalHeaders']();_0x1dad50['Content-Type']='application/x-www-form-urlencoded';const _0x15c525={'method':'POST','headers':_0x1dad50,'body':_0x13fb4e};return _0x5441d6['emulatorConfig']&&Wt(_0x5441d6['emulatorConfig']['host'])&&(_0x15c525['credentials']='include'),va['fetch']()(_0x10d61b,_0x15c525);});return{'accessToken':_0x2346d6['access_token'],'expiresIn':_0x2346d6['expires_in'],'refreshToken':_0x2346d6['refresh_token']};}async function vf(_0xf20711,_0x2ba442){return Ae(_0xf20711,'POST','/v2/accounts:revokeToken',Re(_0xf20711,_0x2ba442));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x51980d){m(_0x51980d['idToken'],'internal-error'),m(typeof _0x51980d['idToken']<'u','internal-error'),m(typeof _0x51980d['refreshToken']<'u','internal-error');const _0x339f0b='expiresIn'in _0x51980d&&typeof _0x51980d['expiresIn']<'u'?Number(_0x51980d['expiresIn']):Er(_0x51980d['idToken']);this['updateTokensAndExpiration'](_0x51980d['idToken'],_0x51980d['refreshToken'],_0x339f0b);}['updateFromIdToken'](_0x2e109e){m(_0x2e109e['length']!==0x0,'internal-error');const _0x46ccb8=Er(_0x2e109e);this['updateTokensAndExpiration'](_0x2e109e,null,_0x46ccb8);}async['getToken'](_0x1aadf4,_0x5a9fe7=!0x1){return!_0x5a9fe7&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1aadf4,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1aadf4,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1189d2,_0x425faf){const {accessToken:_0x2fe08d,refreshToken:_0x17c07e,expiresIn:_0xcfbb0}=await yf(_0x1189d2,_0x425faf);this['updateTokensAndExpiration'](_0x2fe08d,_0x17c07e,Number(_0xcfbb0));}['updateTokensAndExpiration'](_0x22de0d,_0x2a3a54,_0xdb02ec){this['refreshToken']=_0x2a3a54||null,this['accessToken']=_0x22de0d||null,this['expirationTime']=Date['now']()+_0xdb02ec*0x3e8;}static['fromJSON'](_0x4eb048,_0x51ba7a){const {refreshToken:_0x4e923b,accessToken:_0x53f3bc,expirationTime:_0x1e6522}=_0x51ba7a,_0x4cd288=new Je();return _0x4e923b&&(m(typeof _0x4e923b=='string','internal-error',{'appName':_0x4eb048}),_0x4cd288['refreshToken']=_0x4e923b),_0x53f3bc&&(m(typeof _0x53f3bc=='string','internal-error',{'appName':_0x4eb048}),_0x4cd288['accessToken']=_0x53f3bc),_0x1e6522&&(m(typeof _0x1e6522=='number','internal-error',{'appName':_0x4eb048}),_0x4cd288['expirationTime']=_0x1e6522),_0x4cd288;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1588f6){this['accessToken']=_0x1588f6['accessToken'],this['refreshToken']=_0x1588f6['refreshToken'],this['expirationTime']=_0x1588f6['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x25e01d,_0x39bcb3){m(typeof _0x25e01d=='string'||typeof _0x25e01d>'u','internal-error',{'appName':_0x39bcb3});}class z{constructor({uid:_0xbd1df4,auth:_0x48f3f0,stsTokenManager:_0x2bdb87,..._0x1d1bfa}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xbd1df4,this['auth']=_0x48f3f0,this['stsTokenManager']=_0x2bdb87,this['accessToken']=_0x2bdb87['accessToken'],this['displayName']=_0x1d1bfa['displayName']||null,this['email']=_0x1d1bfa['email']||null,this['emailVerified']=_0x1d1bfa['emailVerified']||!0x1,this['phoneNumber']=_0x1d1bfa['phoneNumber']||null,this['photoURL']=_0x1d1bfa['photoURL']||null,this['isAnonymous']=_0x1d1bfa['isAnonymous']||!0x1,this['tenantId']=_0x1d1bfa['tenantId']||null,this['providerData']=_0x1d1bfa['providerData']?[..._0x1d1bfa['providerData']]:[],this['metadata']=new Pi(_0x1d1bfa['createdAt']||void 0x0,_0x1d1bfa['lastLoginAt']||void 0x0);}async['getIdToken'](_0x222545){const _0x3a841c=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x222545));return m(_0x3a841c,this['auth'],'internal-error'),this['accessToken']!==_0x3a841c&&(this['accessToken']=_0x3a841c,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3a841c;}['getIdTokenResult'](_0x3b5f29){return ff(this,_0x3b5f29);}['reload'](){return gf(this);}['_assign'](_0x157399){this!==_0x157399&&(m(this['uid']===_0x157399['uid'],this['auth'],'internal-error'),this['displayName']=_0x157399['displayName'],this['photoURL']=_0x157399['photoURL'],this['email']=_0x157399['email'],this['emailVerified']=_0x157399['emailVerified'],this['phoneNumber']=_0x157399['phoneNumber'],this['isAnonymous']=_0x157399['isAnonymous'],this['tenantId']=_0x157399['tenantId'],this['providerData']=_0x157399['providerData']['map'](_0x59b070=>({..._0x59b070})),this['metadata']['_copy'](_0x157399['metadata']),this['stsTokenManager']['_assign'](_0x157399['stsTokenManager']));}['_clone'](_0x3192c5){const _0x1fdda6=new z({...this,'auth':_0x3192c5,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1fdda6['metadata']['_copy'](this['metadata']),_0x1fdda6;}['_onReload'](_0x384a03){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x384a03,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xda513f){this['reloadListener']?this['reloadListener'](_0xda513f):this['reloadUserInfo']=_0xda513f;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x272e84,_0x4b36f5=!0x1){let _0x27ee2e=!0x1;_0x272e84['idToken']&&_0x272e84['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x272e84),_0x27ee2e=!0x0),_0x4b36f5&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x27ee2e&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x5d2d1b=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x5d2d1b})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0xd08b62=>({..._0xd08b62})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x29a785,_0x51c491){const _0x168e78=_0x51c491['displayName']??void 0x0,_0x53763b=_0x51c491['email']??void 0x0,_0x3a76f7=_0x51c491['phoneNumber']??void 0x0,_0x47b138=_0x51c491['photoURL']??void 0x0,_0x2114cc=_0x51c491['tenantId']??void 0x0,_0xe0c741=_0x51c491['_redirectEventId']??void 0x0,_0x55a818=_0x51c491['createdAt']??void 0x0,_0x10e2e2=_0x51c491['lastLoginAt']??void 0x0,{uid:_0x224409,emailVerified:_0x1e8d90,isAnonymous:_0x5668fc,providerData:_0x4ac1da,stsTokenManager:_0x174fce}=_0x51c491;m(_0x224409&&_0x174fce,_0x29a785,'internal-error');const _0x3b3f78=Je['fromJSON'](this['name'],_0x174fce);m(typeof _0x224409=='string',_0x29a785,'internal-error'),ce(_0x168e78,_0x29a785['name']),ce(_0x53763b,_0x29a785['name']),m(typeof _0x1e8d90=='boolean',_0x29a785,'internal-error'),m(typeof _0x5668fc=='boolean',_0x29a785,'internal-error'),ce(_0x3a76f7,_0x29a785['name']),ce(_0x47b138,_0x29a785['name']),ce(_0x2114cc,_0x29a785['name']),ce(_0xe0c741,_0x29a785['name']),ce(_0x55a818,_0x29a785['name']),ce(_0x10e2e2,_0x29a785['name']);const _0x106cc0=new z({'uid':_0x224409,'auth':_0x29a785,'email':_0x53763b,'emailVerified':_0x1e8d90,'displayName':_0x168e78,'isAnonymous':_0x5668fc,'photoURL':_0x47b138,'phoneNumber':_0x3a76f7,'tenantId':_0x2114cc,'stsTokenManager':_0x3b3f78,'createdAt':_0x55a818,'lastLoginAt':_0x10e2e2});return _0x4ac1da&&Array['isArray'](_0x4ac1da)&&(_0x106cc0['providerData']=_0x4ac1da['map'](_0x4db97f=>({..._0x4db97f}))),_0xe0c741&&(_0x106cc0['_redirectEventId']=_0xe0c741),_0x106cc0;}static async['_fromIdTokenResponse'](_0x427456,_0x154654,_0x107592=!0x1){const _0x27a66d=new Je();_0x27a66d['updateFromServerResponse'](_0x154654);const _0x527508=new z({'uid':_0x154654['localId'],'auth':_0x427456,'stsTokenManager':_0x27a66d,'isAnonymous':_0x107592});return await bn(_0x527508),_0x527508;}static async['_fromGetAccountInfoResponse'](_0x445d17,_0x274010,_0x443337){const _0x546d9c=_0x274010['users'][0x0];m(_0x546d9c['localId']!==void 0x0,'internal-error');const _0x4412a0=_0x546d9c['providerUserInfo']!==void 0x0?wa(_0x546d9c['providerUserInfo']):[],_0x6c34e9=!(_0x546d9c['email']&&_0x546d9c['passwordHash'])&&!(_0x4412a0!=null&&_0x4412a0['length']),_0x583854=new Je();_0x583854['updateFromIdToken'](_0x443337);const _0x52ec85=new z({'uid':_0x546d9c['localId'],'auth':_0x445d17,'stsTokenManager':_0x583854,'isAnonymous':_0x6c34e9}),_0x4bd096={'uid':_0x546d9c['localId'],'displayName':_0x546d9c['displayName']||null,'photoURL':_0x546d9c['photoUrl']||null,'email':_0x546d9c['email']||null,'emailVerified':_0x546d9c['emailVerified']||!0x1,'phoneNumber':_0x546d9c['phoneNumber']||null,'tenantId':_0x546d9c['tenantId']||null,'providerData':_0x4412a0,'metadata':new Pi(_0x546d9c['createdAt'],_0x546d9c['lastLoginAt']),'isAnonymous':!(_0x546d9c['email']&&_0x546d9c['passwordHash'])&&!(_0x4412a0!=null&&_0x4412a0['length'])};return Object['assign'](_0x52ec85,_0x4bd096),_0x52ec85;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x24a27f){ae(_0x24a27f instanceof Function,'Expected\x20a\x20class\x20definition');let _0x44e7c6=Ir['get'](_0x24a27f);return _0x44e7c6?(ae(_0x44e7c6 instanceof _0x24a27f,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x44e7c6):(_0x44e7c6=new _0x24a27f(),Ir['set'](_0x24a27f,_0x44e7c6),_0x44e7c6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x606662,_0x2b75a5){this['storage'][_0x606662]=_0x2b75a5;}async['_get'](_0x564124){const _0x59797e=this['storage'][_0x564124];return _0x59797e===void 0x0?null:_0x59797e;}async['_remove'](_0x4840ef){delete this['storage'][_0x4840ef];}['_addListener'](_0x322fff,_0x56d80c){}['_removeListener'](_0x3fa3a3,_0xe10a8d){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x4bf74a,_0x5ca69b,_0x3cfe59){return'firebase:'+_0x4bf74a+':'+_0x5ca69b+':'+_0x3cfe59;}class Xe{constructor(_0x5a60d0,_0x1b26dc,_0x3ca5aa){this['persistence']=_0x5a60d0,this['auth']=_0x1b26dc,this['userKey']=_0x3ca5aa;const {config:_0x50e233,name:_0xae1104}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x50e233['apiKey'],_0xae1104),this['fullPersistenceKey']=sn('persistence',_0x50e233['apiKey'],_0xae1104),this['boundEventHandler']=_0x1b26dc['_onStorageEvent']['bind'](_0x1b26dc),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x14ec7d){return this['persistence']['_set'](this['fullUserKey'],_0x14ec7d['toJSON']());}async['getCurrentUser'](){const _0x4513e6=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4513e6)return null;if(typeof _0x4513e6=='string'){const _0x1f182b=await Sn(this['auth'],{'idToken':_0x4513e6})['catch'](()=>{});return _0x1f182b?z['_fromGetAccountInfoResponse'](this['auth'],_0x1f182b,_0x4513e6):null;}return z['_fromJSON'](this['auth'],_0x4513e6);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5d3724){if(this['persistence']===_0x5d3724)return;const _0x3519e7=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5d3724,_0x3519e7)return this['setCurrentUser'](_0x3519e7);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x19934d,_0x4dcdf2,_0x43280f='authUser'){if(!_0x4dcdf2['length'])return new Xe(ne(wr),_0x19934d,_0x43280f);const _0x1bebb6=(await Promise['all'](_0x4dcdf2['map'](async _0x309063=>{if(await _0x309063['_isAvailable']())return _0x309063;})))['filter'](_0x316078=>_0x316078);let _0x1fd8c7=_0x1bebb6[0x0]||ne(wr);const _0xe4a586=sn(_0x43280f,_0x19934d['config']['apiKey'],_0x19934d['name']);let _0x27bed0=null;for(const _0x59d8f6 of _0x4dcdf2)try{const _0x4f44ae=await _0x59d8f6['_get'](_0xe4a586);if(_0x4f44ae){let _0x2f240f;if(typeof _0x4f44ae=='string'){const _0x399c7e=await Sn(_0x19934d,{'idToken':_0x4f44ae})['catch'](()=>{});if(!_0x399c7e)break;_0x2f240f=await z['_fromGetAccountInfoResponse'](_0x19934d,_0x399c7e,_0x4f44ae);}else _0x2f240f=z['_fromJSON'](_0x19934d,_0x4f44ae);_0x59d8f6!==_0x1fd8c7&&(_0x27bed0=_0x2f240f),_0x1fd8c7=_0x59d8f6;break;}}catch{}const _0x3ba80f=_0x1bebb6['filter'](_0x37162c=>_0x37162c['_shouldAllowMigration']);return!_0x1fd8c7['_shouldAllowMigration']||!_0x3ba80f['length']?new Xe(_0x1fd8c7,_0x19934d,_0x43280f):(_0x1fd8c7=_0x3ba80f[0x0],_0x27bed0&&await _0x1fd8c7['_set'](_0xe4a586,_0x27bed0['toJSON']()),await Promise['all'](_0x4dcdf2['map'](async _0x21a33c=>{if(_0x21a33c!==_0x1fd8c7)try{await _0x21a33c['_remove'](_0xe4a586);}catch{}})),new Xe(_0x1fd8c7,_0x19934d,_0x43280f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x3f8965){const _0x657e7b=_0x3f8965['toLowerCase']();if(_0x657e7b['includes']('opera/')||_0x657e7b['includes']('opr/')||_0x657e7b['includes']('opios/'))return'Opera';if(Ra(_0x657e7b))return'IEMobile';if(_0x657e7b['includes']('msie')||_0x657e7b['includes']('trident/'))return'IE';if(_0x657e7b['includes']('edge/'))return'Edge';if(Ta(_0x657e7b))return'Firefox';if(_0x657e7b['includes']('silk/'))return'Silk';if(ka(_0x657e7b))return'Blackberry';if(Na(_0x657e7b))return'Webos';if(Sa(_0x657e7b))return'Safari';if((_0x657e7b['includes']('chrome/')||ba(_0x657e7b))&&!_0x657e7b['includes']('edge/'))return'Chrome';if(Aa(_0x657e7b))return'Android';{const _0x210ccd=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1a9ef8=_0x3f8965['match'](_0x210ccd);if((_0x1a9ef8==null?void 0x0:_0x1a9ef8['length'])===0x2)return _0x1a9ef8[0x1];}return'Other';}function Ta(_0x533faa=W()){return/firefox\//i['test'](_0x533faa);}function Sa(_0xbb71f8=W()){const _0x15e2e9=_0xbb71f8['toLowerCase']();return _0x15e2e9['includes']('safari/')&&!_0x15e2e9['includes']('chrome/')&&!_0x15e2e9['includes']('crios/')&&!_0x15e2e9['includes']('android');}function ba(_0xe53e8=W()){return/crios\//i['test'](_0xe53e8);}function Ra(_0x3c44b9=W()){return/iemobile/i['test'](_0x3c44b9);}function Aa(_0x37bb34=W()){return/android/i['test'](_0x37bb34);}function ka(_0x54da9a=W()){return/blackberry/i['test'](_0x54da9a);}function Na(_0x429a95=W()){return/webos/i['test'](_0x429a95);}function Cs(_0x558927=W()){return/iphone|ipad|ipod/i['test'](_0x558927)||/macintosh/i['test'](_0x558927)&&/mobile/i['test'](_0x558927);}function Ef(_0x514a01=W()){var _0x1eebda;return Cs(_0x514a01)&&!!((_0x1eebda=window['navigator'])!=null&&_0x1eebda['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x19c818=W()){return Cs(_0x19c818)||Aa(_0x19c818)||Na(_0x19c818)||ka(_0x19c818)||/windows phone/i['test'](_0x19c818)||Ra(_0x19c818);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x340299,_0x2e651a=[]){let _0x16a659;switch(_0x340299){case'Browser':_0x16a659=Cr(W());break;case'Worker':_0x16a659=Cr(W())+'-'+_0x340299;break;default:_0x16a659=_0x340299;}const _0x208fdb=_0x2e651a['length']?_0x2e651a['join'](','):'FirebaseCore-web';return _0x16a659+'/JsCore/'+ct+'/'+_0x208fdb;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x28734d){this['auth']=_0x28734d,this['queue']=[];}['pushCallback'](_0xfe60ef,_0x169c1f){const _0x3ffd82=_0x244f4a=>new Promise((_0x4eb041,_0x39bf37)=>{try{const _0x53058f=_0xfe60ef(_0x244f4a);_0x4eb041(_0x53058f);}catch(_0x202576){_0x39bf37(_0x202576);}});_0x3ffd82['onAbort']=_0x169c1f,this['queue']['push'](_0x3ffd82);const _0x131d19=this['queue']['length']-0x1;return()=>{this['queue'][_0x131d19]=()=>Promise['resolve']();};}async['runMiddleware'](_0x391701){if(this['auth']['currentUser']===_0x391701)return;const _0x54b02e=[];try{for(const _0x2b5326 of this['queue'])await _0x2b5326(_0x391701),_0x2b5326['onAbort']&&_0x54b02e['push'](_0x2b5326['onAbort']);}catch(_0x11347e){_0x54b02e['reverse']();for(const _0x8582b5 of _0x54b02e)try{_0x8582b5();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x11347e==null?void 0x0:_0x11347e['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x495604,_0x1a46d3={}){return Ae(_0x495604,'GET','/v2/passwordPolicy',Re(_0x495604,_0x1a46d3));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x480066){var _0x23b6e7;const _0x1a6923=_0x480066['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x1a6923['minPasswordLength']??Tf,_0x1a6923['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x1a6923['maxPasswordLength']),_0x1a6923['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x1a6923['containsLowercaseCharacter']),_0x1a6923['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x1a6923['containsUppercaseCharacter']),_0x1a6923['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x1a6923['containsNumericCharacter']),_0x1a6923['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x1a6923['containsNonAlphanumericCharacter']),this['enforcementState']=_0x480066['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x23b6e7=_0x480066['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x23b6e7['join'](''))??'',this['forceUpgradeOnSignin']=_0x480066['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x480066['schemaVersion'];}['validatePassword'](_0x1c7c56){const _0xd63d65={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1c7c56,_0xd63d65),this['validatePasswordCharacterOptions'](_0x1c7c56,_0xd63d65),_0xd63d65['isValid']&&(_0xd63d65['isValid']=_0xd63d65['meetsMinPasswordLength']??!0x0),_0xd63d65['isValid']&&(_0xd63d65['isValid']=_0xd63d65['meetsMaxPasswordLength']??!0x0),_0xd63d65['isValid']&&(_0xd63d65['isValid']=_0xd63d65['containsLowercaseLetter']??!0x0),_0xd63d65['isValid']&&(_0xd63d65['isValid']=_0xd63d65['containsUppercaseLetter']??!0x0),_0xd63d65['isValid']&&(_0xd63d65['isValid']=_0xd63d65['containsNumericCharacter']??!0x0),_0xd63d65['isValid']&&(_0xd63d65['isValid']=_0xd63d65['containsNonAlphanumericCharacter']??!0x0),_0xd63d65;}['validatePasswordLengthOptions'](_0x4b13d1,_0x184669){const _0x2bf531=this['customStrengthOptions']['minPasswordLength'],_0xdaf99b=this['customStrengthOptions']['maxPasswordLength'];_0x2bf531&&(_0x184669['meetsMinPasswordLength']=_0x4b13d1['length']>=_0x2bf531),_0xdaf99b&&(_0x184669['meetsMaxPasswordLength']=_0x4b13d1['length']<=_0xdaf99b);}['validatePasswordCharacterOptions'](_0x4eb8a2,_0x45f4a9){this['updatePasswordCharacterOptionsStatuses'](_0x45f4a9,!0x1,!0x1,!0x1,!0x1);let _0x51cc90;for(let _0x41f00c=0x0;_0x41f00c<_0x4eb8a2['length'];_0x41f00c++)_0x51cc90=_0x4eb8a2['charAt'](_0x41f00c),this['updatePasswordCharacterOptionsStatuses'](_0x45f4a9,_0x51cc90>='a'&&_0x51cc90<='z',_0x51cc90>='A'&&_0x51cc90<='Z',_0x51cc90>='0'&&_0x51cc90<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x51cc90));}['updatePasswordCharacterOptionsStatuses'](_0x5dd7b0,_0x5224f4,_0x61f14e,_0x5cdc20,_0x376d34){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5dd7b0['containsLowercaseLetter']||(_0x5dd7b0['containsLowercaseLetter']=_0x5224f4)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5dd7b0['containsUppercaseLetter']||(_0x5dd7b0['containsUppercaseLetter']=_0x61f14e)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5dd7b0['containsNumericCharacter']||(_0x5dd7b0['containsNumericCharacter']=_0x5cdc20)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5dd7b0['containsNonAlphanumericCharacter']||(_0x5dd7b0['containsNonAlphanumericCharacter']=_0x376d34));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x91ae05,_0x604824,_0xb01d88,_0x223d21){this['app']=_0x91ae05,this['heartbeatServiceProvider']=_0x604824,this['appCheckServiceProvider']=_0xb01d88,this['config']=_0x223d21,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x91ae05['name'],this['clientVersion']=_0x223d21['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x45a76a=>this['_resolvePersistenceManagerAvailable']=_0x45a76a);}['_initializeWithPersistence'](_0x5c8f53,_0xa60892){return _0xa60892&&(this['_popupRedirectResolver']=ne(_0xa60892)),this['_initializationPromise']=this['queue'](async()=>{var _0x5da775,_0x134fb8,_0x3073c3;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x5c8f53),(_0x5da775=this['_resolvePersistenceManagerAvailable'])==null||_0x5da775['call'](this),!this['_deleted'])){if((_0x134fb8=this['_popupRedirectResolver'])!=null&&_0x134fb8['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0xa60892),this['lastNotifiedUid']=((_0x3073c3=this['currentUser'])==null?void 0x0:_0x3073c3['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x5cfd7b=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x5cfd7b)){if(this['currentUser']&&_0x5cfd7b&&this['currentUser']['uid']===_0x5cfd7b['uid']){this['_currentUser']['_assign'](_0x5cfd7b),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x5cfd7b,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x343af2){try{const _0x2f46b6=await Sn(this,{'idToken':_0x343af2}),_0x4725bb=await z['_fromGetAccountInfoResponse'](this,_0x2f46b6,_0x343af2);await this['directlySetCurrentUser'](_0x4725bb);}catch(_0x4d363a){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4d363a),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2d5533){var _0x2c832d;if(H(this['app'])){const _0x486b05=this['app']['settings']['authIdToken'];return _0x486b05?new Promise(_0x2a084b=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x486b05)['then'](_0x2a084b,_0x2a084b));}):this['directlySetCurrentUser'](null);}const _0x5c36c0=await this['assertedPersistence']['getCurrentUser']();let _0x223579=_0x5c36c0,_0x40fe10=!0x1;if(_0x2d5533&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3c0afe=(_0x2c832d=this['redirectUser'])==null?void 0x0:_0x2c832d['_redirectEventId'],_0x3eb71c=_0x223579==null?void 0x0:_0x223579['_redirectEventId'],_0x1dce3f=await this['tryRedirectSignIn'](_0x2d5533);(!_0x3c0afe||_0x3c0afe===_0x3eb71c)&&(_0x1dce3f!=null&&_0x1dce3f['user'])&&(_0x223579=_0x1dce3f['user'],_0x40fe10=!0x0);}if(!_0x223579)return this['directlySetCurrentUser'](null);if(!_0x223579['_redirectEventId']){if(_0x40fe10)try{await this['beforeStateQueue']['runMiddleware'](_0x223579);}catch(_0x27bca6){_0x223579=_0x5c36c0,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x27bca6));}return _0x223579?this['reloadAndSetCurrentUserOrClear'](_0x223579):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x223579['_redirectEventId']?this['directlySetCurrentUser'](_0x223579):this['reloadAndSetCurrentUserOrClear'](_0x223579);}async['tryRedirectSignIn'](_0x31f06a){let _0x5849b6=null;try{_0x5849b6=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x31f06a,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5849b6;}async['reloadAndSetCurrentUserOrClear'](_0x4bd3e7){try{await bn(_0x4bd3e7);}catch(_0x4a279a){if((_0x4a279a==null?void 0x0:_0x4a279a['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4bd3e7);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0xf09670){if(H(this['app']))return Promise['reject'](se(this));const _0x58a6bd=_0xf09670?k(_0xf09670):null;return _0x58a6bd&&m(_0x58a6bd['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x58a6bd&&_0x58a6bd['_clone'](this));}async['_updateCurrentUser'](_0x2ed636,_0x4942f0=!0x1){if(!this['_deleted'])return _0x2ed636&&m(this['tenantId']===_0x2ed636['tenantId'],this,'tenant-id-mismatch'),_0x4942f0||await this['beforeStateQueue']['runMiddleware'](_0x2ed636),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2ed636),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xb2f25d){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0xb2f25d));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5a8d86){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x226c6a=this['_getPasswordPolicyInternal']();return _0x226c6a['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x226c6a['validatePassword'](_0x5a8d86);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x14a4ca=await Cf(this),_0x299b7e=new Sf(_0x14a4ca);this['tenantId']===null?this['_projectPasswordPolicy']=_0x299b7e:this['_tenantPasswordPolicies'][this['tenantId']]=_0x299b7e;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x103225){this['_errorFactory']=new Ut('auth','Firebase',_0x103225());}['onAuthStateChanged'](_0x335dc2,_0x4824dd,_0x3613a5){return this['registerStateListener'](this['authStateSubscription'],_0x335dc2,_0x4824dd,_0x3613a5);}['beforeAuthStateChanged'](_0x1487c5,_0x50dc1e){return this['beforeStateQueue']['pushCallback'](_0x1487c5,_0x50dc1e);}['onIdTokenChanged'](_0x1ba4e5,_0x296cbe,_0x1769e5){return this['registerStateListener'](this['idTokenSubscription'],_0x1ba4e5,_0x296cbe,_0x1769e5);}['authStateReady'](){return new Promise((_0x1b22d8,_0x111c96)=>{if(this['currentUser'])_0x1b22d8();else{const _0x36c789=this['onAuthStateChanged'](()=>{_0x36c789(),_0x1b22d8();},_0x111c96);}});}async['revokeAccessToken'](_0x11af18){if(this['currentUser']){const _0x5ea1eb=await this['currentUser']['getIdToken'](),_0x3ced56={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x11af18,'idToken':_0x5ea1eb};this['tenantId']!=null&&(_0x3ced56['tenantId']=this['tenantId']),await vf(this,_0x3ced56);}}['toJSON'](){var _0x22b154;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x22b154=this['_currentUser'])==null?void 0x0:_0x22b154['toJSON']()};}async['_setRedirectUser'](_0x56878b,_0x6b88ae){const _0x41ffdf=await this['getOrInitRedirectPersistenceManager'](_0x6b88ae);return _0x56878b===null?_0x41ffdf['removeCurrentUser']():_0x41ffdf['setCurrentUser'](_0x56878b);}async['getOrInitRedirectPersistenceManager'](_0x23f9f7){if(!this['redirectPersistenceManager']){const _0x4730c8=_0x23f9f7&&ne(_0x23f9f7)||this['_popupRedirectResolver'];m(_0x4730c8,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x4730c8['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x45fe5e){var _0x51e8ac,_0x5078bb;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x51e8ac=this['_currentUser'])==null?void 0x0:_0x51e8ac['_redirectEventId'])===_0x45fe5e?this['_currentUser']:((_0x5078bb=this['redirectUser'])==null?void 0x0:_0x5078bb['_redirectEventId'])===_0x45fe5e?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x570b69){if(_0x570b69===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x570b69));}['_notifyListenersIfCurrent'](_0x3b514c){_0x3b514c===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0xcb3efd;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x48fd98=((_0xcb3efd=this['currentUser'])==null?void 0x0:_0xcb3efd['uid'])??null;this['lastNotifiedUid']!==_0x48fd98&&(this['lastNotifiedUid']=_0x48fd98,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x59f533,_0x403a16,_0x4ee911,_0x2515c3){if(this['_deleted'])return()=>{};const _0x5bfa12=typeof _0x403a16=='function'?_0x403a16:_0x403a16['next']['bind'](_0x403a16);let _0x37085a=!0x1;const _0x368dba=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x368dba,this,'internal-error'),_0x368dba['then'](()=>{_0x37085a||_0x5bfa12(this['currentUser']);}),typeof _0x403a16=='function'){const _0x2161e2=_0x59f533['addObserver'](_0x403a16,_0x4ee911,_0x2515c3);return()=>{_0x37085a=!0x0,_0x2161e2();};}else{const _0x163bb6=_0x59f533['addObserver'](_0x403a16);return()=>{_0x37085a=!0x0,_0x163bb6();};}}async['directlySetCurrentUser'](_0x5d7496){this['currentUser']&&this['currentUser']!==_0x5d7496&&this['_currentUser']['_stopProactiveRefresh'](),_0x5d7496&&this['isProactiveRefreshEnabled']&&_0x5d7496['_startProactiveRefresh'](),this['currentUser']=_0x5d7496,_0x5d7496?await this['assertedPersistence']['setCurrentUser'](_0x5d7496):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x325f47){return this['operations']=this['operations']['then'](_0x325f47,_0x325f47),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x40ea1a){!_0x40ea1a||this['frameworks']['includes'](_0x40ea1a)||(this['frameworks']['push'](_0x40ea1a),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0xcc4331;const _0x22702f={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x22702f['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3e1466=await((_0xcc4331=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xcc4331['getHeartbeatsHeader']());_0x3e1466&&(_0x22702f['X-Firebase-Client']=_0x3e1466);const _0x2d707b=await this['_getAppCheckToken']();return _0x2d707b&&(_0x22702f['X-Firebase-AppCheck']=_0x2d707b),_0x22702f;}async['_getAppCheckToken'](){var _0x39d23e;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x48c0e5=await((_0x39d23e=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x39d23e['getToken']());return _0x48c0e5!=null&&_0x48c0e5['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x48c0e5['error']),_0x48c0e5==null?void 0x0:_0x48c0e5['token'];}}function qe(_0x407ee6){return k(_0x407ee6);}class Tr{constructor(_0x1ee15e){this['auth']=_0x1ee15e,this['observer']=null,this['addObserver']=Ic(_0x199eb1=>this['observer']=_0x199eb1);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0xa315c1){zn=_0xa315c1;}function Da(_0x4ee683){return zn['loadJS'](_0x4ee683);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x5e36c7){return'__'+_0x5e36c7+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x276322){_0x276322();}['execute'](_0x4ae8de,_0x27c58a){return Promise['resolve']('token');}['render'](_0x38be87,_0x2b4832){return'';}}class Of{['ready'](_0x1c9f6d){_0x1c9f6d();}['execute'](_0x98944c,_0x56e4ea){return Promise['resolve']('token');}['render'](_0x472a63,_0x49e57d){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x5cdb33){this['type']=Df,this['auth']=qe(_0x5cdb33);}async['verify'](_0x4d05c7='verify',_0xe8450f=!0x1){async function _0x4e6cfd(_0x5cea91){if(!_0xe8450f){if(_0x5cea91['tenantId']==null&&_0x5cea91['_agentRecaptchaConfig']!=null)return _0x5cea91['_agentRecaptchaConfig']['siteKey'];if(_0x5cea91['tenantId']!=null&&_0x5cea91['_tenantRecaptchaConfigs'][_0x5cea91['tenantId']]!==void 0x0)return _0x5cea91['_tenantRecaptchaConfigs'][_0x5cea91['tenantId']]['siteKey'];}return new Promise(async(_0x25e96b,_0x30a848)=>{uf(_0x5cea91,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4c2097=>{if(_0x4c2097['recaptchaKey']===void 0x0)_0x30a848(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x424910=new hf(_0x4c2097);return _0x5cea91['tenantId']==null?_0x5cea91['_agentRecaptchaConfig']=_0x424910:_0x5cea91['_tenantRecaptchaConfigs'][_0x5cea91['tenantId']]=_0x424910,_0x25e96b(_0x424910['siteKey']);}})['catch'](_0xa047a6=>{_0x30a848(_0xa047a6);});});}function _0x260f27(_0x3d67b3,_0x27c687,_0x8ba198){const _0x129c69=window['grecaptcha'];vr(_0x129c69)?_0x129c69['enterprise']['ready'](()=>{_0x129c69['enterprise']['execute'](_0x3d67b3,{'action':_0x4d05c7})['then'](_0x366af7=>{_0x27c687(_0x366af7);})['catch'](()=>{_0x27c687(Ma);});}):_0x8ba198(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1d4ca7,_0x2503e8)=>{_0x4e6cfd(this['auth'])['then'](async _0x1662ab=>{if(!_0xe8450f&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x260f27(_0x1662ab,_0x1d4ca7,_0x2503e8);else{if(typeof window>'u'){_0x2503e8(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x52f317=Af();_0x52f317['length']!==0x0&&(_0x52f317+=_0x1662ab+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x2a161f;(_0x2a161f=le['scriptInjectionDeferred'])==null||_0x2a161f['resolve']();},Da(_0x52f317)['then'](()=>{var _0x35566a;return(_0x35566a=le['scriptInjectionDeferred'])==null?void 0x0:_0x35566a['promise'];})['then'](()=>{_0x260f27(_0x1662ab,_0x1d4ca7,_0x2503e8);})['catch'](_0x56152e=>{_0x2503e8(_0x56152e);});}})['catch'](_0x1336d3=>{_0x2503e8(_0x1336d3);});});}}le['scriptInjectionDeferred']=null;async function br(_0x4d6d8d,_0x202d10,_0x11bbad,_0x254298=!0x1,_0x43f639=!0x1){const _0x4f1181=new le(_0x4d6d8d);let _0x5e680f;if(_0x43f639)_0x5e680f=Ma;else try{_0x5e680f=await _0x4f1181['verify'](_0x11bbad);}catch{_0x5e680f=await _0x4f1181['verify'](_0x11bbad,!0x0);}const _0x339101={..._0x202d10};if(_0x11bbad==='mfaSmsEnrollment'||_0x11bbad==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x339101){const _0x59277f=_0x339101['phoneEnrollmentInfo']['phoneNumber'],_0x4db2de=_0x339101['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x339101,{'phoneEnrollmentInfo':{'phoneNumber':_0x59277f,'recaptchaToken':_0x4db2de,'captchaResponse':_0x5e680f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x339101){const _0x316a4b=_0x339101['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x339101,{'phoneSignInInfo':{'recaptchaToken':_0x316a4b,'captchaResponse':_0x5e680f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x339101;}return _0x254298?Object['assign'](_0x339101,{'captchaResp':_0x5e680f}):Object['assign'](_0x339101,{'captchaResponse':_0x5e680f}),Object['assign'](_0x339101,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x339101,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x339101;}async function Oi(_0x14a262,_0x3719e9,_0x302450,_0x493c75,_0x7bf372){var _0x5c5c36;if((_0x5c5c36=_0x14a262['_getRecaptchaConfig']())!=null&&_0x5c5c36['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x133b1c=await br(_0x14a262,_0x3719e9,_0x302450,_0x302450==='getOobCode');return _0x493c75(_0x14a262,_0x133b1c);}else return _0x493c75(_0x14a262,_0x3719e9)['catch'](async _0x5685f0=>{if(_0x5685f0['code']==='auth/missing-recaptcha-token'){console['log'](_0x302450+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x2741ef=await br(_0x14a262,_0x3719e9,_0x302450,_0x302450==='getOobCode');return _0x493c75(_0x14a262,_0x2741ef);}else return Promise['reject'](_0x5685f0);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x4f9d92,_0x53ba18){const _0x8c6fa7=Ui(_0x4f9d92,'auth');if(_0x8c6fa7['isInitialized']()){const _0x563620=_0x8c6fa7['getImmediate'](),_0x493eb8=_0x8c6fa7['getOptions']();if(De(_0x493eb8,_0x53ba18??{}))return _0x563620;K(_0x563620,'already-initialized');}return _0x8c6fa7['initialize']({'options':_0x53ba18});}function Lf(_0x57dd19,_0x5bf557){const _0xa3b536=(_0x5bf557==null?void 0x0:_0x5bf557['persistence'])||[],_0x277ea6=(Array['isArray'](_0xa3b536)?_0xa3b536:[_0xa3b536])['map'](ne);_0x5bf557!=null&&_0x5bf557['errorMap']&&_0x57dd19['_updateErrorMap'](_0x5bf557['errorMap']),_0x57dd19['_initializeWithPersistence'](_0x277ea6,_0x5bf557==null?void 0x0:_0x5bf557['popupRedirectResolver']);}function xf(_0x2784b,_0x4dab33,_0x390052){const _0x3b19bf=qe(_0x2784b);m(/^https?:\/\//['test'](_0x4dab33),_0x3b19bf,'invalid-emulator-scheme');const _0x274a78=!0x1,_0x3b29bd=La(_0x4dab33),{host:_0x12e233,port:_0x572f6e}=Ff(_0x4dab33),_0x47e2f8=_0x572f6e===null?'':':'+_0x572f6e,_0x2195cb={'url':_0x3b29bd+'//'+_0x12e233+_0x47e2f8+'/'},_0x1891f4=Object['freeze']({'host':_0x12e233,'port':_0x572f6e,'protocol':_0x3b29bd['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x274a78})});if(!_0x3b19bf['_canInitEmulator']){m(_0x3b19bf['config']['emulator']&&_0x3b19bf['emulatorConfig'],_0x3b19bf,'emulator-config-failed'),m(De(_0x2195cb,_0x3b19bf['config']['emulator'])&&De(_0x1891f4,_0x3b19bf['emulatorConfig']),_0x3b19bf,'emulator-config-failed');return;}_0x3b19bf['config']['emulator']=_0x2195cb,_0x3b19bf['emulatorConfig']=_0x1891f4,_0x3b19bf['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x12e233)?jr(_0x3b29bd+'//'+_0x12e233+_0x47e2f8):Uf();}function La(_0x5be328){const _0x3f5f48=_0x5be328['indexOf'](':');return _0x3f5f48<0x0?'':_0x5be328['substr'](0x0,_0x3f5f48+0x1);}function Ff(_0x3cba4d){const _0x2a5605=La(_0x3cba4d),_0x590cc2=/(\/\/)?([^?#/]+)/['exec'](_0x3cba4d['substr'](_0x2a5605['length']));if(!_0x590cc2)return{'host':'','port':null};const _0x506428=_0x590cc2[0x2]['split']('@')['pop']()||'',_0x1120f1=/^(\[[^\]]+\])(:|$)/['exec'](_0x506428);if(_0x1120f1){const _0x14b5b2=_0x1120f1[0x1];return{'host':_0x14b5b2,'port':Rr(_0x506428['substr'](_0x14b5b2['length']+0x1))};}else{const [_0x4a3e6a,_0x15bf01]=_0x506428['split'](':');return{'host':_0x4a3e6a,'port':Rr(_0x15bf01)};}}function Rr(_0x45764d){if(!_0x45764d)return null;const _0x1ecd05=Number(_0x45764d);return isNaN(_0x1ecd05)?null:_0x1ecd05;}function Uf(){function _0x36b6ab(){const _0x4083f7=document['createElement']('p'),_0x5e6d80=_0x4083f7['style'];_0x4083f7['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5e6d80['position']='fixed',_0x5e6d80['width']='100%',_0x5e6d80['backgroundColor']='#ffffff',_0x5e6d80['border']='.1em\x20solid\x20#000000',_0x5e6d80['color']='#b50000',_0x5e6d80['bottom']='0px',_0x5e6d80['left']='0px',_0x5e6d80['margin']='0px',_0x5e6d80['zIndex']='10000',_0x5e6d80['textAlign']='center',_0x4083f7['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4083f7);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x36b6ab):_0x36b6ab());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x326bab,_0x54addb){this['providerId']=_0x326bab,this['signInMethod']=_0x54addb;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x522ac3){return te('not\x20implemented');}['_linkToIdToken'](_0x4b6b71,_0x3c6ce1){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x530a43){return te('not\x20implemented');}}async function Wf(_0x9e4d37,_0xd80272){return Ae(_0x9e4d37,'POST','/v1/accounts:signUp',_0xd80272);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x39aaef,_0x103d91){return Yt(_0x39aaef,'POST','/v1/accounts:signInWithPassword',Re(_0x39aaef,_0x103d91));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x49d089,_0x21b370){return Yt(_0x49d089,'POST','/v1/accounts:signInWithEmailLink',Re(_0x49d089,_0x21b370));}async function Hf(_0xe88668,_0xd96021){return Yt(_0xe88668,'POST','/v1/accounts:signInWithEmailLink',Re(_0xe88668,_0xd96021));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x371e92,_0x5a2430,_0x5b9e17,_0x11d6c2=null){super('password',_0x5b9e17),this['_email']=_0x371e92,this['_password']=_0x5a2430,this['_tenantId']=_0x11d6c2;}static['_fromEmailAndPassword'](_0x594aa2,_0x4407a4){return new Ft(_0x594aa2,_0x4407a4,'password');}static['_fromEmailAndCode'](_0x3df103,_0x233e9e,_0x3b3a9a=null){return new Ft(_0x3df103,_0x233e9e,'emailLink',_0x3b3a9a);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x307971){const _0x2fa699=typeof _0x307971=='string'?JSON['parse'](_0x307971):_0x307971;if(_0x2fa699!=null&&_0x2fa699['email']&&(_0x2fa699!=null&&_0x2fa699['password'])){if(_0x2fa699['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2fa699['email'],_0x2fa699['password']);if(_0x2fa699['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2fa699['email'],_0x2fa699['password'],_0x2fa699['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5a0e2b){switch(this['signInMethod']){case'password':const _0x38a7f4={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5a0e2b,_0x38a7f4,'signInWithPassword',Bf);case'emailLink':return Vf(_0x5a0e2b,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x5a0e2b,'internal-error');}}async['_linkToIdToken'](_0x5141ee,_0x1ca4cb){switch(this['signInMethod']){case'password':const _0x19b075={'idToken':_0x1ca4cb,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5141ee,_0x19b075,'signUpPassword',Wf);case'emailLink':return Hf(_0x5141ee,{'idToken':_0x1ca4cb,'email':this['_email'],'oobCode':this['_password']});default:K(_0x5141ee,'internal-error');}}['_getReauthenticationResolver'](_0x143059){return this['_getIdTokenResponse'](_0x143059);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x355e63,_0x3dbc2c){return Yt(_0x355e63,'POST','/v1/accounts:signInWithIdp',Re(_0x355e63,_0x3dbc2c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x37203e){const _0x1baf34=new We(_0x37203e['providerId'],_0x37203e['signInMethod']);return _0x37203e['idToken']||_0x37203e['accessToken']?(_0x37203e['idToken']&&(_0x1baf34['idToken']=_0x37203e['idToken']),_0x37203e['accessToken']&&(_0x1baf34['accessToken']=_0x37203e['accessToken']),_0x37203e['nonce']&&!_0x37203e['pendingToken']&&(_0x1baf34['nonce']=_0x37203e['nonce']),_0x37203e['pendingToken']&&(_0x1baf34['pendingToken']=_0x37203e['pendingToken'])):_0x37203e['oauthToken']&&_0x37203e['oauthTokenSecret']?(_0x1baf34['accessToken']=_0x37203e['oauthToken'],_0x1baf34['secret']=_0x37203e['oauthTokenSecret']):K('argument-error'),_0x1baf34;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0xd91562){const _0x4bb7db=typeof _0xd91562=='string'?JSON['parse'](_0xd91562):_0xd91562,{providerId:_0x9274fc,signInMethod:_0xc73045,..._0x42ef09}=_0x4bb7db;if(!_0x9274fc||!_0xc73045)return null;const _0x947fba=new We(_0x9274fc,_0xc73045);return _0x947fba['idToken']=_0x42ef09['idToken']||void 0x0,_0x947fba['accessToken']=_0x42ef09['accessToken']||void 0x0,_0x947fba['secret']=_0x42ef09['secret'],_0x947fba['nonce']=_0x42ef09['nonce'],_0x947fba['pendingToken']=_0x42ef09['pendingToken']||null,_0x947fba;}['_getIdTokenResponse'](_0x2669d0){const _0x43e6dc=this['buildRequest']();return Ze(_0x2669d0,_0x43e6dc);}['_linkToIdToken'](_0x3ba142,_0x37e1f5){const _0x126ae9=this['buildRequest']();return _0x126ae9['idToken']=_0x37e1f5,Ze(_0x3ba142,_0x126ae9);}['_getReauthenticationResolver'](_0x2d74d6){const _0x3ac052=this['buildRequest']();return _0x3ac052['autoCreate']=!0x1,Ze(_0x2d74d6,_0x3ac052);}['buildRequest'](){const _0x5bbee0={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x5bbee0['pendingToken']=this['pendingToken'];else{const _0x29b114={};this['idToken']&&(_0x29b114['id_token']=this['idToken']),this['accessToken']&&(_0x29b114['access_token']=this['accessToken']),this['secret']&&(_0x29b114['oauth_token_secret']=this['secret']),_0x29b114['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x29b114['nonce']=this['nonce']),_0x5bbee0['postBody']=at(_0x29b114);}return _0x5bbee0;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x33d082){switch(_0x33d082){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x3d20a3){const _0x521cfb=yt(vt(_0x3d20a3))['link'],_0x385cdb=_0x521cfb?yt(vt(_0x521cfb))['deep_link_id']:null,_0x33aa14=yt(vt(_0x3d20a3))['deep_link_id'];return(_0x33aa14?yt(vt(_0x33aa14))['link']:null)||_0x33aa14||_0x385cdb||_0x521cfb||_0x3d20a3;}class Ss{constructor(_0x202f1f){const _0x1d185e=yt(vt(_0x202f1f)),_0x1f4ca9=_0x1d185e['apiKey']??null,_0x4870f2=_0x1d185e['oobCode']??null,_0x3d1734=Gf(_0x1d185e['mode']??null);m(_0x1f4ca9&&_0x4870f2&&_0x3d1734,'argument-error'),this['apiKey']=_0x1f4ca9,this['operation']=_0x3d1734,this['code']=_0x4870f2,this['continueUrl']=_0x1d185e['continueUrl']??null,this['languageCode']=_0x1d185e['lang']??null,this['tenantId']=_0x1d185e['tenantId']??null;}static['parseLink'](_0x2f70a7){const _0x55ab6b=qf(_0x2f70a7);try{return new Ss(_0x55ab6b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x4a103a,_0x22a316){return Ft['_fromEmailAndPassword'](_0x4a103a,_0x22a316);}static['credentialWithLink'](_0x13a461,_0x58f9dd){const _0x4b06aa=Ss['parseLink'](_0x58f9dd);return m(_0x4b06aa,'argument-error'),Ft['_fromEmailAndCode'](_0x13a461,_0x4b06aa['code'],_0x4b06aa['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x4cfb71){this['providerId']=_0x4cfb71,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x45724c){this['defaultLanguageCode']=_0x45724c;}['setCustomParameters'](_0x3f6472){return this['customParameters']=_0x3f6472,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x263270){return this['scopes']['includes'](_0x263270)||this['scopes']['push'](_0x263270),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x571d52){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x571d52});}static['credentialFromResult'](_0x1172d1){return he['credentialFromTaggedObject'](_0x1172d1);}static['credentialFromError'](_0x31557e){return he['credentialFromTaggedObject'](_0x31557e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x43347c}){if(!_0x43347c||!('oauthAccessToken'in _0x43347c)||!_0x43347c['oauthAccessToken'])return null;try{return he['credential'](_0x43347c['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x32f036,_0x1536b3){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x32f036,'accessToken':_0x1536b3});}static['credentialFromResult'](_0x468798){return ue['credentialFromTaggedObject'](_0x468798);}static['credentialFromError'](_0x37109b){return ue['credentialFromTaggedObject'](_0x37109b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xdb6b7d}){if(!_0xdb6b7d)return null;const {oauthIdToken:_0x4a46f6,oauthAccessToken:_0x20bc8f}=_0xdb6b7d;if(!_0x4a46f6&&!_0x20bc8f)return null;try{return ue['credential'](_0x4a46f6,_0x20bc8f);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x50a504){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x50a504});}static['credentialFromResult'](_0x1be371){return de['credentialFromTaggedObject'](_0x1be371);}static['credentialFromError'](_0x2c7d4c){return de['credentialFromTaggedObject'](_0x2c7d4c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x421755}){if(!_0x421755||!('oauthAccessToken'in _0x421755)||!_0x421755['oauthAccessToken'])return null;try{return de['credential'](_0x421755['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x4efbd9,_0x5be57c){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4efbd9,'oauthTokenSecret':_0x5be57c});}static['credentialFromResult'](_0x82db34){return fe['credentialFromTaggedObject'](_0x82db34);}static['credentialFromError'](_0x14e8a6){return fe['credentialFromTaggedObject'](_0x14e8a6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2c1a4e}){if(!_0x2c1a4e)return null;const {oauthAccessToken:_0x5b438e,oauthTokenSecret:_0x5e46f5}=_0x2c1a4e;if(!_0x5b438e||!_0x5e46f5)return null;try{return fe['credential'](_0x5b438e,_0x5e46f5);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x4def00,_0x3dcafd){return Yt(_0x4def00,'POST','/v1/accounts:signUp',Re(_0x4def00,_0x3dcafd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x1152c9){this['user']=_0x1152c9['user'],this['providerId']=_0x1152c9['providerId'],this['_tokenResponse']=_0x1152c9['_tokenResponse'],this['operationType']=_0x1152c9['operationType'];}static async['_fromIdTokenResponse'](_0x551853,_0x573c26,_0x363e05,_0x24cd54=!0x1){const _0x373d85=await z['_fromIdTokenResponse'](_0x551853,_0x363e05,_0x24cd54),_0x4ef4d5=Ar(_0x363e05);return new Be({'user':_0x373d85,'providerId':_0x4ef4d5,'_tokenResponse':_0x363e05,'operationType':_0x573c26});}static async['_forOperation'](_0x3e0bf6,_0x3f754a,_0x3c209e){await _0x3e0bf6['_updateTokensIfNecessary'](_0x3c209e,!0x0);const _0x3b301d=Ar(_0x3c209e);return new Be({'user':_0x3e0bf6,'providerId':_0x3b301d,'_tokenResponse':_0x3c209e,'operationType':_0x3f754a});}}function Ar(_0x5b36ca){return _0x5b36ca['providerId']?_0x5b36ca['providerId']:'phoneNumber'in _0x5b36ca?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x45a169,_0x4da36c,_0x4f6b30,_0x400836){super(_0x4da36c['code'],_0x4da36c['message']),this['operationType']=_0x4f6b30,this['user']=_0x400836,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x45a169['name'],'tenantId':_0x45a169['tenantId']??void 0x0,'_serverResponse':_0x4da36c['customData']['_serverResponse'],'operationType':_0x4f6b30};}static['_fromErrorAndOperation'](_0x4a3f0c,_0x6ca56d,_0x260891,_0x1e6deb){return new Rn(_0x4a3f0c,_0x6ca56d,_0x260891,_0x1e6deb);}}function Fa(_0x47dcfa,_0x2093e7,_0x126dd6,_0x25a1b0){return(_0x2093e7==='reauthenticate'?_0x126dd6['_getReauthenticationResolver'](_0x47dcfa):_0x126dd6['_getIdTokenResponse'](_0x47dcfa))['catch'](_0x53347c=>{throw _0x53347c['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x47dcfa,_0x53347c,_0x2093e7,_0x25a1b0):_0x53347c;});}async function jf(_0x19ca86,_0x7d43cf,_0x4d797a=!0x1){const _0x484b8c=await xt(_0x19ca86,_0x7d43cf['_linkToIdToken'](_0x19ca86['auth'],await _0x19ca86['getIdToken']()),_0x4d797a);return Be['_forOperation'](_0x19ca86,'link',_0x484b8c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xb68254,_0x2120f3,_0x33421e=!0x1){const {auth:_0x1507d3}=_0xb68254;if(H(_0x1507d3['app']))return Promise['reject'](se(_0x1507d3));const _0x2b6a61='reauthenticate';try{const _0x5bda6e=await xt(_0xb68254,Fa(_0x1507d3,_0x2b6a61,_0x2120f3,_0xb68254),_0x33421e);m(_0x5bda6e['idToken'],_0x1507d3,'internal-error');const _0x75f592=ws(_0x5bda6e['idToken']);m(_0x75f592,_0x1507d3,'internal-error');const {sub:_0x455030}=_0x75f592;return m(_0xb68254['uid']===_0x455030,_0x1507d3,'user-mismatch'),Be['_forOperation'](_0xb68254,_0x2b6a61,_0x5bda6e);}catch(_0x529578){throw(_0x529578==null?void 0x0:_0x529578['code'])==='auth/user-not-found'&&K(_0x1507d3,'user-mismatch'),_0x529578;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x1114ff,_0x224759,_0x26f09e=!0x1){if(H(_0x1114ff['app']))return Promise['reject'](se(_0x1114ff));const _0x2ec86e='signIn',_0x43c173=await Fa(_0x1114ff,_0x2ec86e,_0x224759),_0x3886b3=await Be['_fromIdTokenResponse'](_0x1114ff,_0x2ec86e,_0x43c173);return _0x26f09e||await _0x1114ff['_updateCurrentUser'](_0x3886b3['user']),_0x3886b3;}async function Yf(_0x42896f,_0x43ae74){return Ua(qe(_0x42896f),_0x43ae74);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x1b4d6d){const _0x584bb1=qe(_0x1b4d6d);_0x584bb1['_getPasswordPolicyInternal']()&&await _0x584bb1['_updatePasswordPolicy']();}async function R_(_0x184eaa,_0x3fd996,_0x219799){if(H(_0x184eaa['app']))return Promise['reject'](se(_0x184eaa));const _0xc6c817=qe(_0x184eaa),_0x3bf1ef=await Oi(_0xc6c817,{'returnSecureToken':!0x0,'email':_0x3fd996,'password':_0x219799,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x40599b=>{throw _0x40599b['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x184eaa),_0x40599b;}),_0x4057d9=await Be['_fromIdTokenResponse'](_0xc6c817,'signIn',_0x3bf1ef);return await _0xc6c817['_updateCurrentUser'](_0x4057d9['user']),_0x4057d9;}function A_(_0x3b770f,_0x5b5941,_0x362b4c){return H(_0x3b770f['app'])?Promise['reject'](se(_0x3b770f)):Yf(k(_0x3b770f),ft['credential'](_0x5b5941,_0x362b4c))['catch'](async _0x2db589=>{throw _0x2db589['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x3b770f),_0x2db589;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0xa51446,_0x1548e4){return k(_0xa51446)['setPersistence'](_0x1548e4);}function Qf(_0x912bbd,_0x12b002,_0x1a1e25,_0x327dff){return k(_0x912bbd)['onIdTokenChanged'](_0x12b002,_0x1a1e25,_0x327dff);}function Jf(_0x198e5e,_0x57c197,_0x41beae){return k(_0x198e5e)['beforeAuthStateChanged'](_0x57c197,_0x41beae);}function N_(_0x269055,_0x58fde3,_0x2ef422,_0x43b249){return k(_0x269055)['onAuthStateChanged'](_0x58fde3,_0x2ef422,_0x43b249);}function P_(_0x4d04df){return k(_0x4d04df)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x35d8be,_0x27a997){this['storageRetriever']=_0x35d8be,this['type']=_0x27a997;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4fb896,_0x53d565){return this['storage']['setItem'](_0x4fb896,JSON['stringify'](_0x53d565)),Promise['resolve']();}['_get'](_0x34bb9d){const _0xc9deb9=this['storage']['getItem'](_0x34bb9d);return Promise['resolve'](_0xc9deb9?JSON['parse'](_0xc9deb9):null);}['_remove'](_0x1c8cce){return this['storage']['removeItem'](_0x1c8cce),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x111b7e,_0x23af8a)=>this['onStorageEvent'](_0x111b7e,_0x23af8a),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5b228e){for(const _0x2da778 of Object['keys'](this['listeners'])){const _0x1ab3ce=this['storage']['getItem'](_0x2da778),_0x7919db=this['localCache'][_0x2da778];_0x1ab3ce!==_0x7919db&&_0x5b228e(_0x2da778,_0x7919db,_0x1ab3ce);}}['onStorageEvent'](_0x353009,_0x46ef31=!0x1){if(!_0x353009['key']){this['forAllChangedKeys']((_0x3c1a18,_0x7aeabc,_0x113566)=>{this['notifyListeners'](_0x3c1a18,_0x113566);});return;}const _0x345631=_0x353009['key'];_0x46ef31?this['detachListener']():this['stopPolling']();const _0x428cdd=()=>{const _0x526717=this['storage']['getItem'](_0x345631);!_0x46ef31&&this['localCache'][_0x345631]===_0x526717||this['notifyListeners'](_0x345631,_0x526717);},_0x58ac33=this['storage']['getItem'](_0x345631);If()&&_0x58ac33!==_0x353009['newValue']&&_0x353009['newValue']!==_0x353009['oldValue']?setTimeout(_0x428cdd,Zf):_0x428cdd();}['notifyListeners'](_0x31afd,_0xbab9e1){this['localCache'][_0x31afd]=_0xbab9e1;const _0x47970c=this['listeners'][_0x31afd];if(_0x47970c){for(const _0x5ed830 of Array['from'](_0x47970c))_0x5ed830(_0xbab9e1&&JSON['parse'](_0xbab9e1));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1d0f08,_0xd8c1a6,_0x17f009)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1d0f08,'oldValue':_0xd8c1a6,'newValue':_0x17f009}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x206fd8,_0x3d73b9){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x206fd8]||(this['listeners'][_0x206fd8]=new Set(),this['localCache'][_0x206fd8]=this['storage']['getItem'](_0x206fd8)),this['listeners'][_0x206fd8]['add'](_0x3d73b9);}['_removeListener'](_0x5afc63,_0x25aa16){this['listeners'][_0x5afc63]&&(this['listeners'][_0x5afc63]['delete'](_0x25aa16),this['listeners'][_0x5afc63]['size']===0x0&&delete this['listeners'][_0x5afc63]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x57fcca,_0x552997){await super['_set'](_0x57fcca,_0x552997),this['localCache'][_0x57fcca]=JSON['stringify'](_0x552997);}async['_get'](_0x326496){const _0x44824b=await super['_get'](_0x326496);return this['localCache'][_0x326496]=JSON['stringify'](_0x44824b),_0x44824b;}async['_remove'](_0x284628){await super['_remove'](_0x284628),delete this['localCache'][_0x284628];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x56d7cd,_0x12f4b2){}['_removeListener'](_0xb3c0d9,_0x59e417){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x4e7fc0){return Promise['all'](_0x4e7fc0['map'](async _0x570c66=>{try{return{'fulfilled':!0x0,'value':await _0x570c66};}catch(_0x2c3af1){return{'fulfilled':!0x1,'reason':_0x2c3af1};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x145f89){this['eventTarget']=_0x145f89,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x184b91){const _0x3ec0a2=this['receivers']['find'](_0x30ad89=>_0x30ad89['isListeningto'](_0x184b91));if(_0x3ec0a2)return _0x3ec0a2;const _0x14c054=new jn(_0x184b91);return this['receivers']['push'](_0x14c054),_0x14c054;}['isListeningto'](_0x2692e7){return this['eventTarget']===_0x2692e7;}async['handleEvent'](_0x4906df){const _0x45a309=_0x4906df,{eventId:_0x20e031,eventType:_0x391c32,data:_0x256e98}=_0x45a309['data'],_0x497193=this['handlersMap'][_0x391c32];if(!(_0x497193!=null&&_0x497193['size']))return;_0x45a309['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x20e031,'eventType':_0x391c32});const _0x290426=Array['from'](_0x497193)['map'](async _0x420883=>_0x420883(_0x45a309['origin'],_0x256e98)),_0x826d2e=await tp(_0x290426);_0x45a309['ports'][0x0]['postMessage']({'status':'done','eventId':_0x20e031,'eventType':_0x391c32,'response':_0x826d2e});}['_subscribe'](_0x5a7d97,_0x274c97){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5a7d97]||(this['handlersMap'][_0x5a7d97]=new Set()),this['handlersMap'][_0x5a7d97]['add'](_0x274c97);}['_unsubscribe'](_0x2736bb,_0x31c198){this['handlersMap'][_0x2736bb]&&_0x31c198&&this['handlersMap'][_0x2736bb]['delete'](_0x31c198),(!_0x31c198||this['handlersMap'][_0x2736bb]['size']===0x0)&&delete this['handlersMap'][_0x2736bb],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x4f11ac='',_0x411019=0xa){let _0x486853='';for(let _0x586151=0x0;_0x586151<_0x411019;_0x586151++)_0x486853+=Math['floor'](Math['random']()*0xa);return _0x4f11ac+_0x486853;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x16af9c){this['target']=_0x16af9c,this['handlers']=new Set();}['removeMessageHandler'](_0x2ef2cd){_0x2ef2cd['messageChannel']&&(_0x2ef2cd['messageChannel']['port1']['removeEventListener']('message',_0x2ef2cd['onMessage']),_0x2ef2cd['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2ef2cd);}async['_send'](_0x38b48d,_0x3c5ce6,_0x8869f=0x32){const _0x25807b=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x25807b)throw new Error('connection_unavailable');let _0x1f809a,_0x28fcc9;return new Promise((_0x1ac9a1,_0x57fd8a)=>{const _0x232b65=bs('',0x14);_0x25807b['port1']['start']();const _0x29e202=setTimeout(()=>{_0x57fd8a(new Error('unsupported_event'));},_0x8869f);_0x28fcc9={'messageChannel':_0x25807b,'onMessage'(_0x2af2af){const _0x1a4dce=_0x2af2af;if(_0x1a4dce['data']['eventId']===_0x232b65)switch(_0x1a4dce['data']['status']){case'ack':clearTimeout(_0x29e202),_0x1f809a=setTimeout(()=>{_0x57fd8a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1f809a),_0x1ac9a1(_0x1a4dce['data']['response']);break;default:clearTimeout(_0x29e202),clearTimeout(_0x1f809a),_0x57fd8a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x28fcc9),_0x25807b['port1']['addEventListener']('message',_0x28fcc9['onMessage']),this['target']['postMessage']({'eventType':_0x38b48d,'eventId':_0x232b65,'data':_0x3c5ce6},[_0x25807b['port2']]);})['finally'](()=>{_0x28fcc9&&this['removeMessageHandler'](_0x28fcc9);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x29b6f1){X()['location']['href']=_0x29b6f1;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x5cafd5;return((_0x5cafd5=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5cafd5['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x7afec8){this['request']=_0x7afec8;}['toPromise'](){return new Promise((_0x5d0726,_0x39a0d8)=>{this['request']['addEventListener']('success',()=>{_0x5d0726(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x39a0d8(this['request']['error']);});});}}function Kn(_0x5dabd,_0x13b3cb){return _0x5dabd['transaction']([kn],_0x13b3cb?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x15e125=indexedDB['deleteDatabase'](qa);return new Jt(_0x15e125)['toPromise']();}function ja(){const _0x5e6c7e=indexedDB['open'](qa,ap);return new Promise((_0x5a1639,_0x5eefeb)=>{_0x5e6c7e['addEventListener']('error',()=>{_0x5eefeb(_0x5e6c7e['error']);}),_0x5e6c7e['addEventListener']('upgradeneeded',()=>{const _0x225141=_0x5e6c7e['result'];try{_0x225141['createObjectStore'](kn,{'keyPath':za});}catch(_0x4cbade){_0x5eefeb(_0x4cbade);}}),_0x5e6c7e['addEventListener']('success',async()=>{const _0x508f6a=_0x5e6c7e['result'];_0x508f6a['objectStoreNames']['contains'](kn)?_0x5a1639(_0x508f6a):(_0x508f6a['close'](),await cp(),_0x5a1639(await ja()));});});}async function kr(_0x229303,_0x33faea,_0x20ef75){const _0x494a65=Kn(_0x229303,!0x0)['put']({[za]:_0x33faea,'value':_0x20ef75});return new Jt(_0x494a65)['toPromise']();}async function lp(_0x2bef4b,_0x1fce38){const _0x2c91db=Kn(_0x2bef4b,!0x1)['get'](_0x1fce38),_0x3f0faa=await new Jt(_0x2c91db)['toPromise']();return _0x3f0faa===void 0x0?null:_0x3f0faa['value'];}function Nr(_0x5ac7a7,_0x4e057c){const _0x22d8ba=Kn(_0x5ac7a7,!0x0)['delete'](_0x4e057c);return new Jt(_0x22d8ba)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x51d1d9){let _0xe08575=0x0;for(;;)try{const _0x3a5efe=await this['_openDb']();return await _0x51d1d9(_0x3a5efe);}catch(_0x111df7){if(_0xe08575++>up)throw _0x111df7;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x5f4fa2,_0x5707c8)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5707c8['key'])})),this['receiver']['_subscribe']('ping',async(_0x380f64,_0x4763a9)=>['keyChanged']);}async['initializeSender'](){var _0x19585f,_0x3d5d70;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x277ca6=await this['sender']['_send']('ping',{},0x320);_0x277ca6&&(_0x19585f=_0x277ca6[0x0])!=null&&_0x19585f['fulfilled']&&(_0x3d5d70=_0x277ca6[0x0])!=null&&_0x3d5d70['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2f47c5){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2f47c5},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x250fe6=>{await kr(_0x250fe6,An,'1'),await Nr(_0x250fe6,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x280cd6){this['pendingWrites']++;try{await _0x280cd6();}finally{this['pendingWrites']--;}}async['_set'](_0x155238,_0x377119){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x25ce45=>kr(_0x25ce45,_0x155238,_0x377119)),this['localCache'][_0x155238]=_0x377119,this['notifyServiceWorker'](_0x155238)));}async['_get'](_0x3c45e7){const _0x1b4d76=await this['_withRetries'](_0xec3c5f=>lp(_0xec3c5f,_0x3c45e7));return this['localCache'][_0x3c45e7]=_0x1b4d76,_0x1b4d76;}async['_remove'](_0x306837){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4c8097=>Nr(_0x4c8097,_0x306837)),delete this['localCache'][_0x306837],this['notifyServiceWorker'](_0x306837)));}async['_poll'](){const _0x49c269=await this['_withRetries'](_0x234786=>{const _0x3ed829=Kn(_0x234786,!0x1)['getAll']();return new Jt(_0x3ed829)['toPromise']();});if(!_0x49c269)return[];if(this['pendingWrites']!==0x0)return[];const _0x4214ab=[],_0xcd6e8b=new Set();if(_0x49c269['length']!==0x0){for(const {fbase_key:_0x14e790,value:_0x19e5e7}of _0x49c269)_0xcd6e8b['add'](_0x14e790),JSON['stringify'](this['localCache'][_0x14e790])!==JSON['stringify'](_0x19e5e7)&&(this['notifyListeners'](_0x14e790,_0x19e5e7),_0x4214ab['push'](_0x14e790));}for(const _0x4df97e of Object['keys'](this['localCache']))this['localCache'][_0x4df97e]&&!_0xcd6e8b['has'](_0x4df97e)&&(this['notifyListeners'](_0x4df97e,null),_0x4214ab['push'](_0x4df97e));return _0x4214ab;}['notifyListeners'](_0xf0dbaf,_0x320e99){this['localCache'][_0xf0dbaf]=_0x320e99;const _0x1bab65=this['listeners'][_0xf0dbaf];if(_0x1bab65){for(const _0x21bbdb of Array['from'](_0x1bab65))_0x21bbdb(_0x320e99);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x53c2df,_0x29c334){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x53c2df]||(this['listeners'][_0x53c2df]=new Set(),this['_get'](_0x53c2df)),this['listeners'][_0x53c2df]['add'](_0x29c334);}['_removeListener'](_0x310e9b,_0x4e8fc6){this['listeners'][_0x310e9b]&&(this['listeners'][_0x310e9b]['delete'](_0x4e8fc6),this['listeners'][_0x310e9b]['size']===0x0&&delete this['listeners'][_0x310e9b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x14201b,_0x4f6813){return _0x4f6813?ne(_0x4f6813):(m(_0x14201b['_popupRedirectResolver'],_0x14201b,'argument-error'),_0x14201b['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x4c7209){super('custom','custom'),this['params']=_0x4c7209;}['_getIdTokenResponse'](_0x422ec0){return Ze(_0x422ec0,this['_buildIdpRequest']());}['_linkToIdToken'](_0xe6faec,_0x1981ba){return Ze(_0xe6faec,this['_buildIdpRequest'](_0x1981ba));}['_getReauthenticationResolver'](_0x232017){return Ze(_0x232017,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x114505){const _0x2ffda4={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x114505&&(_0x2ffda4['idToken']=_0x114505),_0x2ffda4;}}function pp(_0x2a4ad3){return Ua(_0x2a4ad3['auth'],new Rs(_0x2a4ad3),_0x2a4ad3['bypassAuthState']);}function _p(_0x92e997){const {auth:_0x460c38,user:_0x5d9a52}=_0x92e997;return m(_0x5d9a52,_0x460c38,'internal-error'),Kf(_0x5d9a52,new Rs(_0x92e997),_0x92e997['bypassAuthState']);}async function gp(_0xf68094){const {auth:_0xd0b5,user:_0x57c51a}=_0xf68094;return m(_0x57c51a,_0xd0b5,'internal-error'),jf(_0x57c51a,new Rs(_0xf68094),_0xf68094['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x5ab14a,_0x15ad4e,_0x46ba8a,_0xe24829,_0x28ff1d=!0x1){this['auth']=_0x5ab14a,this['resolver']=_0x46ba8a,this['user']=_0xe24829,this['bypassAuthState']=_0x28ff1d,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x15ad4e)?_0x15ad4e:[_0x15ad4e];}['execute'](){return new Promise(async(_0x4cd191,_0x164794)=>{this['pendingPromise']={'resolve':_0x4cd191,'reject':_0x164794};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x1a480f){this['reject'](_0x1a480f);}});}async['onAuthEvent'](_0x5866d8){const {urlResponse:_0x198f4b,sessionId:_0xe03178,postBody:_0x5cc1c2,tenantId:_0x356c67,error:_0x5ab649,type:_0x188185}=_0x5866d8;if(_0x5ab649){this['reject'](_0x5ab649);return;}const _0x31edec={'auth':this['auth'],'requestUri':_0x198f4b,'sessionId':_0xe03178,'tenantId':_0x356c67||void 0x0,'postBody':_0x5cc1c2||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x188185)(_0x31edec));}catch(_0x759409){this['reject'](_0x759409);}}['onError'](_0x3fdf51){this['reject'](_0x3fdf51);}['getIdpTask'](_0x46245f){switch(_0x46245f){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x15af37){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x15af37),this['unregisterAndCleanUp']();}['reject'](_0x3c6bed){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3c6bed),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x3d19bd,_0x34556f,_0x1e3233,_0x1d25d2,_0x26d1b1){super(_0x3d19bd,_0x34556f,_0x1d25d2,_0x26d1b1),this['provider']=_0x1e3233,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x3bd5a6=await this['execute']();return m(_0x3bd5a6,this['auth'],'internal-error'),_0x3bd5a6;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x11e404=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x11e404),this['authWindow']['associatedEvent']=_0x11e404,this['resolver']['_originValidation'](this['auth'])['catch'](_0x3cc34c=>{this['reject'](_0x3cc34c);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x329714=>{_0x329714||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1e9f93;return((_0x1e9f93=this['authWindow'])==null?void 0x0:_0x1e9f93['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0xe4ab63=()=>{var _0x557ad7,_0x2d64e5;if((_0x2d64e5=(_0x557ad7=this['authWindow'])==null?void 0x0:_0x557ad7['window'])!=null&&_0x2d64e5['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xe4ab63,mp['get']());};_0xe4ab63();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x1daa59,_0x4a0a71,_0x1feb0c=!0x1){super(_0x1daa59,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4a0a71,void 0x0,_0x1feb0c),this['eventId']=null;}async['execute'](){let _0x389f53=rn['get'](this['auth']['_key']());if(!_0x389f53){try{const _0x2d83a2=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x389f53=()=>Promise['resolve'](_0x2d83a2);}catch(_0x27469a){_0x389f53=()=>Promise['reject'](_0x27469a);}rn['set'](this['auth']['_key'](),_0x389f53);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x389f53();}async['onAuthEvent'](_0x570e6d){if(_0x570e6d['type']==='signInViaRedirect')return super['onAuthEvent'](_0x570e6d);if(_0x570e6d['type']==='unknown'){this['resolve'](null);return;}if(_0x570e6d['eventId']){const _0x4c6a11=await this['auth']['_redirectUserForId'](_0x570e6d['eventId']);if(_0x4c6a11)return this['user']=_0x4c6a11,super['onAuthEvent'](_0x570e6d);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x3433b7,_0x47ba63){const _0x54c183=Cp(_0x47ba63),_0xbc4622=wp(_0x3433b7);if(!await _0xbc4622['_isAvailable']())return!0x1;const _0x549ab5=await _0xbc4622['_get'](_0x54c183)==='true';return await _0xbc4622['_remove'](_0x54c183),_0x549ab5;}function Ip(_0x42bb90,_0x5d4148){rn['set'](_0x42bb90['_key'](),_0x5d4148);}function wp(_0x101d39){return ne(_0x101d39['_redirectPersistence']);}function Cp(_0x139558){return sn(yp,_0x139558['config']['apiKey'],_0x139558['name']);}async function Tp(_0x84046,_0x4a708b,_0xcbc054=!0x1){if(H(_0x84046['app']))return Promise['reject'](se(_0x84046));const _0x464cd9=qe(_0x84046),_0x2c1d6d=fp(_0x464cd9,_0x4a708b),_0x1301f1=await new vp(_0x464cd9,_0x2c1d6d,_0xcbc054)['execute']();return _0x1301f1&&!_0xcbc054&&(delete _0x1301f1['user']['_redirectEventId'],await _0x464cd9['_persistUserIfCurrent'](_0x1301f1['user']),await _0x464cd9['_setRedirectUser'](null,_0x4a708b)),_0x1301f1;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x4ce424){this['auth']=_0x4ce424,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x34d02c){this['consumers']['add'](_0x34d02c),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x34d02c)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x34d02c),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1e9610){this['consumers']['delete'](_0x1e9610);}['onEvent'](_0x1189a6){if(this['hasEventBeenHandled'](_0x1189a6))return!0x1;let _0x3a5b15=!0x1;return this['consumers']['forEach'](_0x384d24=>{this['isEventForConsumer'](_0x1189a6,_0x384d24)&&(_0x3a5b15=!0x0,this['sendToConsumer'](_0x1189a6,_0x384d24),this['saveEventToCache'](_0x1189a6));}),this['hasHandledPotentialRedirect']||!Rp(_0x1189a6)||(this['hasHandledPotentialRedirect']=!0x0,_0x3a5b15||(this['queuedRedirectEvent']=_0x1189a6,_0x3a5b15=!0x0)),_0x3a5b15;}['sendToConsumer'](_0x1ced65,_0x1aef2b){var _0x542bdd;if(_0x1ced65['error']&&!Qa(_0x1ced65)){const _0xd916eb=((_0x542bdd=_0x1ced65['error']['code'])==null?void 0x0:_0x542bdd['split']('auth/')[0x1])||'internal-error';_0x1aef2b['onError'](J(this['auth'],_0xd916eb));}else _0x1aef2b['onAuthEvent'](_0x1ced65);}['isEventForConsumer'](_0x17f997,_0x17300b){const _0x5c000b=_0x17300b['eventId']===null||!!_0x17f997['eventId']&&_0x17f997['eventId']===_0x17300b['eventId'];return _0x17300b['filter']['includes'](_0x17f997['type'])&&_0x5c000b;}['hasEventBeenHandled'](_0x18a25f){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x18a25f));}['saveEventToCache'](_0x492633){this['cachedEventUids']['add'](Pr(_0x492633)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0xe5ec7a){return[_0xe5ec7a['type'],_0xe5ec7a['eventId'],_0xe5ec7a['sessionId'],_0xe5ec7a['tenantId']]['filter'](_0x9367f7=>_0x9367f7)['join']('-');}function Qa({type:_0x1ff210,error:_0x3cdd26}){return _0x1ff210==='unknown'&&(_0x3cdd26==null?void 0x0:_0x3cdd26['code'])==='auth/no-auth-event';}function Rp(_0x264526){switch(_0x264526['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x264526);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x595f75,_0x5141be={}){return Ae(_0x595f75,'GET','/v1/projects',_0x5141be);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0xe50f8a){if(_0xe50f8a['config']['emulator'])return;const {authorizedDomains:_0x6bd69f}=await Ap(_0xe50f8a);for(const _0x1e8ef2 of _0x6bd69f)try{if(Op(_0x1e8ef2))return;}catch{}K(_0xe50f8a,'unauthorized-domain');}function Op(_0x34f733){const _0x442422=Ni(),{protocol:_0x2bb790,hostname:_0x3dd245}=new URL(_0x442422);if(_0x34f733['startsWith']('chrome-extension://')){const _0x138435=new URL(_0x34f733);return _0x138435['hostname']===''&&_0x3dd245===''?_0x2bb790==='chrome-extension:'&&_0x34f733['replace']('chrome-extension://','')===_0x442422['replace']('chrome-extension://',''):_0x2bb790==='chrome-extension:'&&_0x138435['hostname']===_0x3dd245;}if(!Np['test'](_0x2bb790))return!0x1;if(kp['test'](_0x34f733))return _0x3dd245===_0x34f733;const _0x171775=_0x34f733['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x171775+'|'+_0x171775+')$','i')['test'](_0x3dd245);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x1e1972=X()['___jsl'];if(_0x1e1972!=null&&_0x1e1972['H']){for(const _0x26aae5 of Object['keys'](_0x1e1972['H']))if(_0x1e1972['H'][_0x26aae5]['r']=_0x1e1972['H'][_0x26aae5]['r']||[],_0x1e1972['H'][_0x26aae5]['L']=_0x1e1972['H'][_0x26aae5]['L']||[],_0x1e1972['H'][_0x26aae5]['r']=[..._0x1e1972['H'][_0x26aae5]['L']],_0x1e1972['CP']){for(let _0x22e8fe=0x0;_0x22e8fe<_0x1e1972['CP']['length'];_0x22e8fe++)_0x1e1972['CP'][_0x22e8fe]=null;}}}function Mp(_0x4fac2a){return new Promise((_0x1558a4,_0x5b87fe)=>{var _0x1b1a3c,_0x434037,_0x9d7987;function _0x56b92e(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1558a4(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x5b87fe(J(_0x4fac2a,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x434037=(_0x1b1a3c=X()['gapi'])==null?void 0x0:_0x1b1a3c['iframes'])!=null&&_0x434037['Iframe'])_0x1558a4(gapi['iframes']['getContext']());else{if((_0x9d7987=X()['gapi'])!=null&&_0x9d7987['load'])_0x56b92e();else{const _0x4e651b=Nf('iframefcb');return X()[_0x4e651b]=()=>{gapi['load']?_0x56b92e():_0x5b87fe(J(_0x4fac2a,'network-request-failed'));},Da(kf()+'?onload='+_0x4e651b)['catch'](_0x4138db=>_0x5b87fe(_0x4138db));}}})['catch'](_0x101565=>{throw on=null,_0x101565;});}let on=null;function Lp(_0x26ddda){return on=on||Mp(_0x26ddda),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x800b87){const _0x4e8171=_0x800b87['config'];m(_0x4e8171['authDomain'],_0x800b87,'auth-domain-config-required');const _0x1cea46=_0x4e8171['emulator']?Is(_0x4e8171,Up):'https://'+_0x800b87['config']['authDomain']+'/'+Fp,_0x17526a={'apiKey':_0x4e8171['apiKey'],'appName':_0x800b87['name'],'v':ct},_0x1cd77d=Bp['get'](_0x800b87['config']['apiHost']);_0x1cd77d&&(_0x17526a['eid']=_0x1cd77d);const _0x21a309=_0x800b87['_getFrameworks']();return _0x21a309['length']&&(_0x17526a['fw']=_0x21a309['join'](',')),_0x1cea46+'?'+at(_0x17526a)['slice'](0x1);}async function Hp(_0x1e40e0){const _0x167268=await Lp(_0x1e40e0),_0x1ad549=X()['gapi'];return m(_0x1ad549,_0x1e40e0,'internal-error'),_0x167268['open']({'where':document['body'],'url':Vp(_0x1e40e0),'messageHandlersFilter':_0x1ad549['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x201464=>new Promise(async(_0x4aa50a,_0x4691c8)=>{await _0x201464['restyle']({'setHideOnLeave':!0x1});const _0x4b61ce=J(_0x1e40e0,'network-request-failed'),_0x2d99e8=X()['setTimeout'](()=>{_0x4691c8(_0x4b61ce);},xp['get']());function _0x36f59d(){X()['clearTimeout'](_0x2d99e8),_0x4aa50a(_0x201464);}_0x201464['ping'](_0x36f59d)['then'](_0x36f59d,()=>{_0x4691c8(_0x4b61ce);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x5e92cf){this['window']=_0x5e92cf,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x3ed032,_0x3eb304,_0x1c366f,_0x58f5fd=Gp,_0x5e896d=qp){const _0x5d2275=Math['max']((window['screen']['availHeight']-_0x5e896d)/0x2,0x0)['toString'](),_0x1b7afb=Math['max']((window['screen']['availWidth']-_0x58f5fd)/0x2,0x0)['toString']();let _0x407f91='';const _0x3d3b5c={...$p,'width':_0x58f5fd['toString'](),'height':_0x5e896d['toString'](),'top':_0x5d2275,'left':_0x1b7afb},_0x3a90db=W()['toLowerCase']();_0x1c366f&&(_0x407f91=ba(_0x3a90db)?zp:_0x1c366f),Ta(_0x3a90db)&&(_0x3eb304=_0x3eb304||jp,_0x3d3b5c['scrollbars']='yes');const _0x40fee2=Object['entries'](_0x3d3b5c)['reduce']((_0x1a016a,[_0x5911cd,_0xd9c9a9])=>''+_0x1a016a+_0x5911cd+'='+_0xd9c9a9+',','');if(Ef(_0x3a90db)&&_0x407f91!=='_self')return Yp(_0x3eb304||'',_0x407f91),new Dr(null);const _0x5265fe=window['open'](_0x3eb304||'',_0x407f91,_0x40fee2);m(_0x5265fe,_0x3ed032,'popup-blocked');try{_0x5265fe['focus']();}catch{}return new Dr(_0x5265fe);}function Yp(_0x4a5d24,_0x1d708a){const _0x3a7217=document['createElement']('a');_0x3a7217['href']=_0x4a5d24,_0x3a7217['target']=_0x1d708a;const _0x4568aa=document['createEvent']('MouseEvent');_0x4568aa['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x3a7217['dispatchEvent'](_0x4568aa);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x306736,_0x43b5fe,_0x44e426,_0x5683b2,_0x26b708,_0x43259b){m(_0x306736['config']['authDomain'],_0x306736,'auth-domain-config-required'),m(_0x306736['config']['apiKey'],_0x306736,'invalid-api-key');const _0x3a1056={'apiKey':_0x306736['config']['apiKey'],'appName':_0x306736['name'],'authType':_0x44e426,'redirectUrl':_0x5683b2,'v':ct,'eventId':_0x26b708};if(_0x43b5fe instanceof xa){_0x43b5fe['setDefaultLanguage'](_0x306736['languageCode']),_0x3a1056['providerId']=_0x43b5fe['providerId']||'',hi(_0x43b5fe['getCustomParameters']())||(_0x3a1056['customParameters']=JSON['stringify'](_0x43b5fe['getCustomParameters']()));for(const [_0x32fb92,_0x3c124b]of Object['entries']({}))_0x3a1056[_0x32fb92]=_0x3c124b;}if(_0x43b5fe instanceof Qt){const _0x2b7030=_0x43b5fe['getScopes']()['filter'](_0x305168=>_0x305168!=='');_0x2b7030['length']>0x0&&(_0x3a1056['scopes']=_0x2b7030['join'](','));}_0x306736['tenantId']&&(_0x3a1056['tid']=_0x306736['tenantId']);const _0x45a7e2=_0x3a1056;for(const _0xc57bcc of Object['keys'](_0x45a7e2))_0x45a7e2[_0xc57bcc]===void 0x0&&delete _0x45a7e2[_0xc57bcc];const _0x1cf15e=await _0x306736['_getAppCheckToken'](),_0x4f514c=_0x1cf15e?'#'+Xp+'='+encodeURIComponent(_0x1cf15e):'';return Zp(_0x306736)+'?'+at(_0x45a7e2)['slice'](0x1)+_0x4f514c;}function Zp({config:_0x26bf7d}){return _0x26bf7d['emulator']?Is(_0x26bf7d,Jp):'https://'+_0x26bf7d['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x34d03d,_0xb13171,_0x10bc06,_0x5f53c8){var _0x1b887c;ae((_0x1b887c=this['eventManagers'][_0x34d03d['_key']()])==null?void 0x0:_0x1b887c['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x17a755=await Mr(_0x34d03d,_0xb13171,_0x10bc06,Ni(),_0x5f53c8);return Kp(_0x34d03d,_0x17a755,bs());}async['_openRedirect'](_0x319852,_0x207200,_0x573f6c,_0xba8f51){await this['_originValidation'](_0x319852);const _0x16b441=await Mr(_0x319852,_0x207200,_0x573f6c,Ni(),_0xba8f51);return ip(_0x16b441),new Promise(()=>{});}['_initialize'](_0x27f2df){const _0x34290e=_0x27f2df['_key']();if(this['eventManagers'][_0x34290e]){const {manager:_0x5ec2a0,promise:_0x1ab332}=this['eventManagers'][_0x34290e];return _0x5ec2a0?Promise['resolve'](_0x5ec2a0):(ae(_0x1ab332,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1ab332);}const _0x101b96=this['initAndGetManager'](_0x27f2df);return this['eventManagers'][_0x34290e]={'promise':_0x101b96},_0x101b96['catch'](()=>{delete this['eventManagers'][_0x34290e];}),_0x101b96;}async['initAndGetManager'](_0x262d46){const _0x2a2b18=await Hp(_0x262d46),_0x558445=new bp(_0x262d46);return _0x2a2b18['register']('authEvent',_0x32067f=>(m(_0x32067f==null?void 0x0:_0x32067f['authEvent'],_0x262d46,'invalid-auth-event'),{'status':_0x558445['onEvent'](_0x32067f['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x262d46['_key']()]={'manager':_0x558445},this['iframes'][_0x262d46['_key']()]=_0x2a2b18,_0x558445;}['_isIframeWebStorageSupported'](_0x4c22d1,_0x4270bb){this['iframes'][_0x4c22d1['_key']()]['send'](li,{'type':li},_0x2470ef=>{var _0x45d06d;const _0xfa695=(_0x45d06d=_0x2470ef==null?void 0x0:_0x2470ef[0x0])==null?void 0x0:_0x45d06d[li];_0xfa695!==void 0x0&&_0x4270bb(!!_0xfa695),K(_0x4c22d1,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4e0bde){const _0x151c07=_0x4e0bde['_key']();return this['originValidationPromises'][_0x151c07]||(this['originValidationPromises'][_0x151c07]=Pp(_0x4e0bde)),this['originValidationPromises'][_0x151c07];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x53d457){this['auth']=_0x53d457,this['internalListeners']=new Map();}['getUid'](){var _0x181eae;return this['assertAuthConfigured'](),((_0x181eae=this['auth']['currentUser'])==null?void 0x0:_0x181eae['uid'])||null;}async['getToken'](_0x4c0548){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4c0548)}:null;}['addAuthTokenListener'](_0x22b24f){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x22b24f))return;const _0x1ee4f1=this['auth']['onIdTokenChanged'](_0x291726=>{_0x22b24f((_0x291726==null?void 0x0:_0x291726['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x22b24f,_0x1ee4f1),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5a36b0){this['assertAuthConfigured']();const _0xfc610a=this['internalListeners']['get'](_0x5a36b0);_0xfc610a&&(this['internalListeners']['delete'](_0x5a36b0),_0xfc610a(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x5351c9){switch(_0x5351c9){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x527c18){et(new Me('auth',(_0x2d192d,{options:_0x54d217})=>{const _0x455a4d=_0x2d192d['getProvider']('app')['getImmediate'](),_0x4b2e9f=_0x2d192d['getProvider']('heartbeat'),_0x39d6db=_0x2d192d['getProvider']('app-check-internal'),{apiKey:_0x15b45b,authDomain:_0x1af3b}=_0x455a4d['options'];m(_0x15b45b&&!_0x15b45b['includes'](':'),'invalid-api-key',{'appName':_0x455a4d['name']});const _0x3f5b9b={'apiKey':_0x15b45b,'authDomain':_0x1af3b,'clientPlatform':_0x527c18,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x527c18)},_0xc8f037=new bf(_0x455a4d,_0x4b2e9f,_0x39d6db,_0x3f5b9b);return Lf(_0xc8f037,_0x54d217),_0xc8f037;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x29a7b6,_0x559fea,_0x44df0e)=>{_0x29a7b6['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x252d7e=>{const _0x5b2a1e=qe(_0x252d7e['getProvider']('auth')['getImmediate']());return(_0x2cbee6=>new n_(_0x2cbee6))(_0x5b2a1e);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x527c18)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x41f906=>async _0x386f87=>{const _0x37da1d=_0x386f87&&await _0x386f87['getIdTokenResult'](),_0x1646a0=_0x37da1d&&(new Date()['getTime']()-Date['parse'](_0x37da1d['issuedAtTime']))/0x3e8;if(_0x1646a0&&_0x1646a0>o_)return;const _0xfe6c52=_0x37da1d==null?void 0x0:_0x37da1d['token'];Fr!==_0xfe6c52&&(Fr=_0xfe6c52,await fetch(_0x41f906,{'method':_0xfe6c52?'POST':'DELETE','headers':_0xfe6c52?{'Authorization':'Bearer\x20'+_0xfe6c52}:{}}));};function O_(_0x5e3150=Qr()){const _0x3df1de=Ui(_0x5e3150,'auth');if(_0x3df1de['isInitialized']())return _0x3df1de['getImmediate']();const _0x3592bc=Mf(_0x5e3150,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x4756b4=Gr('authTokenSyncURL');if(_0x4756b4&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x217a1e=new URL(_0x4756b4,location['origin']);if(location['origin']===_0x217a1e['origin']){const _0x42fb32=a_(_0x217a1e['toString']());Jf(_0x3592bc,_0x42fb32,()=>_0x42fb32(_0x3592bc['currentUser'])),Qf(_0x3592bc,_0x4bdb74=>_0x42fb32(_0x4bdb74));}}const _0x4e0b1c=Hr('auth');return _0x4e0b1c&&xf(_0x3592bc,'http://'+_0x4e0b1c),_0x3592bc;}function c_(){var _0x9ad9f3;return((_0x9ad9f3=document['getElementsByTagName']('head'))==null?void 0x0:_0x9ad9f3[0x0])??document;}Rf({'loadJS'(_0x1d9b86){return new Promise((_0x28bed9,_0xe6da58)=>{const _0x1e0f50=document['createElement']('script');_0x1e0f50['setAttribute']('src',_0x1d9b86),_0x1e0f50['onload']=_0x28bed9,_0x1e0f50['onerror']=_0x3f23fc=>{const _0x7e0a45=J('internal-error');_0x7e0a45['customData']=_0x3f23fc,_0xe6da58(_0x7e0a45);},_0x1e0f50['type']='text/javascript',_0x1e0f50['charset']='UTF-8',c_()['appendChild'](_0x1e0f50);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};