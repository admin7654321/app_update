const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1ff549,_0x408d23){if(!_0x1ff549)throw ot(_0x408d23);},ot=function(_0xa77456){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xa77456);},Wr=function(_0x27a472){const _0x451e83=[];let _0x474479=0x0;for(let _0x59723e=0x0;_0x59723e<_0x27a472['length'];_0x59723e++){let _0x4c458d=_0x27a472['charCodeAt'](_0x59723e);_0x4c458d<0x80?_0x451e83[_0x474479++]=_0x4c458d:_0x4c458d<0x800?(_0x451e83[_0x474479++]=_0x4c458d>>0x6|0xc0,_0x451e83[_0x474479++]=_0x4c458d&0x3f|0x80):(_0x4c458d&0xfc00)===0xd800&&_0x59723e+0x1<_0x27a472['length']&&(_0x27a472['charCodeAt'](_0x59723e+0x1)&0xfc00)===0xdc00?(_0x4c458d=0x10000+((_0x4c458d&0x3ff)<<0xa)+(_0x27a472['charCodeAt'](++_0x59723e)&0x3ff),_0x451e83[_0x474479++]=_0x4c458d>>0x12|0xf0,_0x451e83[_0x474479++]=_0x4c458d>>0xc&0x3f|0x80,_0x451e83[_0x474479++]=_0x4c458d>>0x6&0x3f|0x80,_0x451e83[_0x474479++]=_0x4c458d&0x3f|0x80):(_0x451e83[_0x474479++]=_0x4c458d>>0xc|0xe0,_0x451e83[_0x474479++]=_0x4c458d>>0x6&0x3f|0x80,_0x451e83[_0x474479++]=_0x4c458d&0x3f|0x80);}return _0x451e83;},Za=function(_0x474010){const _0xed6abb=[];let _0x3a9292=0x0,_0x1bd6a9=0x0;for(;_0x3a9292<_0x474010['length'];){const _0x3f29ac=_0x474010[_0x3a9292++];if(_0x3f29ac<0x80)_0xed6abb[_0x1bd6a9++]=String['fromCharCode'](_0x3f29ac);else{if(_0x3f29ac>0xbf&&_0x3f29ac<0xe0){const _0x368128=_0x474010[_0x3a9292++];_0xed6abb[_0x1bd6a9++]=String['fromCharCode']((_0x3f29ac&0x1f)<<0x6|_0x368128&0x3f);}else{if(_0x3f29ac>0xef&&_0x3f29ac<0x16d){const _0xc1383b=_0x474010[_0x3a9292++],_0x22f3d4=_0x474010[_0x3a9292++],_0x555ded=_0x474010[_0x3a9292++],_0x45c17f=((_0x3f29ac&0x7)<<0x12|(_0xc1383b&0x3f)<<0xc|(_0x22f3d4&0x3f)<<0x6|_0x555ded&0x3f)-0x10000;_0xed6abb[_0x1bd6a9++]=String['fromCharCode'](0xd800+(_0x45c17f>>0xa)),_0xed6abb[_0x1bd6a9++]=String['fromCharCode'](0xdc00+(_0x45c17f&0x3ff));}else{const _0x35eb40=_0x474010[_0x3a9292++],_0x49477d=_0x474010[_0x3a9292++];_0xed6abb[_0x1bd6a9++]=String['fromCharCode']((_0x3f29ac&0xf)<<0xc|(_0x35eb40&0x3f)<<0x6|_0x49477d&0x3f);}}}}return _0xed6abb['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x201a14,_0x208df1){if(!Array['isArray'](_0x201a14))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x366136=_0x208df1?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x410157=[];for(let _0x326c44=0x0;_0x326c44<_0x201a14['length'];_0x326c44+=0x3){const _0x40bc69=_0x201a14[_0x326c44],_0x32e50f=_0x326c44+0x1<_0x201a14['length'],_0x506d68=_0x32e50f?_0x201a14[_0x326c44+0x1]:0x0,_0x154295=_0x326c44+0x2<_0x201a14['length'],_0x7cea11=_0x154295?_0x201a14[_0x326c44+0x2]:0x0,_0x25d2f3=_0x40bc69>>0x2,_0x4fe6dc=(_0x40bc69&0x3)<<0x4|_0x506d68>>0x4;let _0x192f25=(_0x506d68&0xf)<<0x2|_0x7cea11>>0x6,_0x1470e3=_0x7cea11&0x3f;_0x154295||(_0x1470e3=0x40,_0x32e50f||(_0x192f25=0x40)),_0x410157['push'](_0x366136[_0x25d2f3],_0x366136[_0x4fe6dc],_0x366136[_0x192f25],_0x366136[_0x1470e3]);}return _0x410157['join']('');},'encodeString'(_0x50a73e,_0x138e6d){return this['HAS_NATIVE_SUPPORT']&&!_0x138e6d?btoa(_0x50a73e):this['encodeByteArray'](Wr(_0x50a73e),_0x138e6d);},'decodeString'(_0x5e5070,_0x209a2a){return this['HAS_NATIVE_SUPPORT']&&!_0x209a2a?atob(_0x5e5070):Za(this['decodeStringToByteArray'](_0x5e5070,_0x209a2a));},'decodeStringToByteArray'(_0x4cc907,_0x3a5966){this['init_']();const _0x510514=_0x3a5966?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x376e6d=[];for(let _0x17fb4f=0x0;_0x17fb4f<_0x4cc907['length'];){const _0x157772=_0x510514[_0x4cc907['charAt'](_0x17fb4f++)],_0x14dbf5=_0x17fb4f<_0x4cc907['length']?_0x510514[_0x4cc907['charAt'](_0x17fb4f)]:0x0;++_0x17fb4f;const _0x34e681=_0x17fb4f<_0x4cc907['length']?_0x510514[_0x4cc907['charAt'](_0x17fb4f)]:0x40;++_0x17fb4f;const _0x882667=_0x17fb4f<_0x4cc907['length']?_0x510514[_0x4cc907['charAt'](_0x17fb4f)]:0x40;if(++_0x17fb4f,_0x157772==null||_0x14dbf5==null||_0x34e681==null||_0x882667==null)throw new ec();const _0x584049=_0x157772<<0x2|_0x14dbf5>>0x4;if(_0x376e6d['push'](_0x584049),_0x34e681!==0x40){const _0x382d1b=_0x14dbf5<<0x4&0xf0|_0x34e681>>0x2;if(_0x376e6d['push'](_0x382d1b),_0x882667!==0x40){const _0x18b89f=_0x34e681<<0x6&0xc0|_0x882667;_0x376e6d['push'](_0x18b89f);}}}return _0x376e6d;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x37a448=0x0;_0x37a448<this['ENCODED_VALS']['length'];_0x37a448++)this['byteToCharMap_'][_0x37a448]=this['ENCODED_VALS']['charAt'](_0x37a448),this['charToByteMap_'][this['byteToCharMap_'][_0x37a448]]=_0x37a448,this['byteToCharMapWebSafe_'][_0x37a448]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x37a448),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x37a448]]=_0x37a448,_0x37a448>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x37a448)]=_0x37a448,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x37a448)]=_0x37a448);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x37bfb7){const _0x480dbf=Wr(_0x37bfb7);return Di['encodeByteArray'](_0x480dbf,!0x0);},an=function(_0xbaa5ed){return Br(_0xbaa5ed)['replace'](/\./g,'');},cn=function(_0x10f705){try{return Di['decodeString'](_0x10f705,!0x0);}catch(_0x54c074){console['error']('base64Decode\x20failed:\x20',_0x54c074);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x49bda4){return Vr(void 0x0,_0x49bda4);}function Vr(_0x2f872d,_0x4b0d7d){if(!(_0x4b0d7d instanceof Object))return _0x4b0d7d;switch(_0x4b0d7d['constructor']){case Date:const _0x57f6c4=_0x4b0d7d;return new Date(_0x57f6c4['getTime']());case Object:_0x2f872d===void 0x0&&(_0x2f872d={});break;case Array:_0x2f872d=[];break;default:return _0x4b0d7d;}for(const _0x5834a9 in _0x4b0d7d)!_0x4b0d7d['hasOwnProperty'](_0x5834a9)||!nc(_0x5834a9)||(_0x2f872d[_0x5834a9]=Vr(_0x2f872d[_0x5834a9],_0x4b0d7d[_0x5834a9]));return _0x2f872d;}function nc(_0x4cf536){return _0x4cf536!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x4f7c08=As['__FIREBASE_DEFAULTS__'];if(_0x4f7c08)return JSON['parse'](_0x4f7c08);},oc=()=>{if(typeof document>'u')return;let _0xe4a757;try{_0xe4a757=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2af44d=_0xe4a757&&cn(_0xe4a757[0x1]);return _0x2af44d&&JSON['parse'](_0x2af44d);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0xe3d3dd){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xe3d3dd);return;}},Hr=_0x17c7ff=>{var _0x47a4a0,_0x5a4ee1;return(_0x5a4ee1=(_0x47a4a0=Mi())==null?void 0x0:_0x47a4a0['emulatorHosts'])==null?void 0x0:_0x5a4ee1[_0x17c7ff];},ac=_0x3b46c9=>{const _0x303e93=Hr(_0x3b46c9);if(!_0x303e93)return;const _0x1de1cb=_0x303e93['lastIndexOf'](':');if(_0x1de1cb<=0x0||_0x1de1cb+0x1===_0x303e93['length'])throw new Error('Invalid\x20host\x20'+_0x303e93+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5a2032=parseInt(_0x303e93['substring'](_0x1de1cb+0x1),0xa);return _0x303e93[0x0]==='['?[_0x303e93['substring'](0x1,_0x1de1cb-0x1),_0x5a2032]:[_0x303e93['substring'](0x0,_0x1de1cb),_0x5a2032];},$r=()=>{var _0x52c011;return(_0x52c011=Mi())==null?void 0x0:_0x52c011['config'];},Gr=_0x6d39bf=>{var _0x1a36d4;return(_0x1a36d4=Mi())==null?void 0x0:_0x1a36d4['_'+_0x6d39bf];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3e3834,_0x846f14)=>{this['resolve']=_0x3e3834,this['reject']=_0x846f14;});}['wrapCallback'](_0x15e6bf){return(_0x229a17,_0x2dcdd3)=>{_0x229a17?this['reject'](_0x229a17):this['resolve'](_0x2dcdd3),typeof _0x15e6bf=='function'&&(this['promise']['catch'](()=>{}),_0x15e6bf['length']===0x1?_0x15e6bf(_0x229a17):_0x15e6bf(_0x229a17,_0x2dcdd3));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x104853,_0x1779fa){if(_0x104853['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x452aab={'alg':'none','type':'JWT'},_0x4a8f23=_0x1779fa||'demo-project',_0x524692=_0x104853['iat']||0x0,_0x2fa12e=_0x104853['sub']||_0x104853['user_id'];if(!_0x2fa12e)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x57fe47={'iss':'https://securetoken.google.com/'+_0x4a8f23,'aud':_0x4a8f23,'iat':_0x524692,'exp':_0x524692+0xe10,'auth_time':_0x524692,'sub':_0x2fa12e,'user_id':_0x2fa12e,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x104853};return[an(JSON['stringify'](_0x452aab)),an(JSON['stringify'](_0x57fe47)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x10341b=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x10341b=='object'&&_0x10341b['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x39e6b4=W();return _0x39e6b4['indexOf']('MSIE\x20')>=0x0||_0x39e6b4['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x4b7219,_0xb05606)=>{try{let _0x2071bf=!0x0;const _0x18f817='validate-browser-context-for-indexeddb-analytics-module',_0x298c24=self['indexedDB']['open'](_0x18f817);_0x298c24['onsuccess']=()=>{_0x298c24['result']['close'](),_0x2071bf||self['indexedDB']['deleteDatabase'](_0x18f817),_0x4b7219(!0x0);},_0x298c24['onupgradeneeded']=()=>{_0x2071bf=!0x1;},_0x298c24['onerror']=()=>{var _0x531c98;_0xb05606(((_0x531c98=_0x298c24['error'])==null?void 0x0:_0x531c98['message'])||'');};}catch(_0x798261){_0xb05606(_0x798261);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x5ac26f,_0x2fcbca,_0x240950){super(_0x2fcbca),this['code']=_0x5ac26f,this['customData']=_0x240950,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x718761,_0x53a839,_0x1e1cb1){this['service']=_0x718761,this['serviceName']=_0x53a839,this['errors']=_0x1e1cb1;}['create'](_0x2a5930,..._0xca4e62){const _0x47e6b8=_0xca4e62[0x0]||{},_0x203549=this['service']+'/'+_0x2a5930,_0x55cca9=this['errors'][_0x2a5930],_0x3dc54a=_0x55cca9?gc(_0x55cca9,_0x47e6b8):'Error',_0x2702ad=this['serviceName']+':\x20'+_0x3dc54a+'\x20('+_0x203549+').';return new Se(_0x203549,_0x2702ad,_0x47e6b8);}}function gc(_0x133d35,_0x3f1fa3){return _0x133d35['replace'](mc,(_0x29bba2,_0x576d26)=>{const _0x100d34=_0x3f1fa3[_0x576d26];return _0x100d34!=null?String(_0x100d34):'<'+_0x576d26+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0xf287a6){return JSON['parse'](_0xf287a6);}function O(_0x7bc169){return JSON['stringify'](_0x7bc169);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x3a6bb1){let _0x22dcf1={},_0x3422be={},_0x1aaa76={},_0x33742f='';try{const _0x2107e3=_0x3a6bb1['split']('.');_0x22dcf1=bt(cn(_0x2107e3[0x0])||''),_0x3422be=bt(cn(_0x2107e3[0x1])||''),_0x33742f=_0x2107e3[0x2],_0x1aaa76=_0x3422be['d']||{},delete _0x3422be['d'];}catch{}return{'header':_0x22dcf1,'claims':_0x3422be,'data':_0x1aaa76,'signature':_0x33742f};},yc=function(_0x21edbf){const _0x5f4fae=zr(_0x21edbf),_0x1f7e4d=_0x5f4fae['claims'];return!!_0x1f7e4d&&typeof _0x1f7e4d=='object'&&_0x1f7e4d['hasOwnProperty']('iat');},vc=function(_0x30cde7){const _0x5f3e78=zr(_0x30cde7)['claims'];return typeof _0x5f3e78=='object'&&_0x5f3e78['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3ab940,_0x1c7d8d){return Object['prototype']['hasOwnProperty']['call'](_0x3ab940,_0x1c7d8d);}function Oe(_0x16dc46,_0x496781){if(Object['prototype']['hasOwnProperty']['call'](_0x16dc46,_0x496781))return _0x16dc46[_0x496781];}function hi(_0x6182ab){for(const _0x4c162c in _0x6182ab)if(Object['prototype']['hasOwnProperty']['call'](_0x6182ab,_0x4c162c))return!0x1;return!0x0;}function ln(_0x1958b5,_0x4ceec2,_0x23fab3){const _0x3f907d={};for(const _0xc7781 in _0x1958b5)Object['prototype']['hasOwnProperty']['call'](_0x1958b5,_0xc7781)&&(_0x3f907d[_0xc7781]=_0x4ceec2['call'](_0x23fab3,_0x1958b5[_0xc7781],_0xc7781,_0x1958b5));return _0x3f907d;}function De(_0x1072b7,_0x13829c){if(_0x1072b7===_0x13829c)return!0x0;const _0x354437=Object['keys'](_0x1072b7),_0xc9ee9=Object['keys'](_0x13829c);for(const _0x280d68 of _0x354437){if(!_0xc9ee9['includes'](_0x280d68))return!0x1;const _0x4ba789=_0x1072b7[_0x280d68],_0x1caa8f=_0x13829c[_0x280d68];if(ks(_0x4ba789)&&ks(_0x1caa8f)){if(!De(_0x4ba789,_0x1caa8f))return!0x1;}else{if(_0x4ba789!==_0x1caa8f)return!0x1;}}for(const _0x39bbdc of _0xc9ee9)if(!_0x354437['includes'](_0x39bbdc))return!0x1;return!0x0;}function ks(_0x573e61){return _0x573e61!==null&&typeof _0x573e61=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5b5472){const _0x17587f=[];for(const [_0x17e824,_0x22c13b]of Object['entries'](_0x5b5472))Array['isArray'](_0x22c13b)?_0x22c13b['forEach'](_0x3adfb7=>{_0x17587f['push'](encodeURIComponent(_0x17e824)+'='+encodeURIComponent(_0x3adfb7));}):_0x17587f['push'](encodeURIComponent(_0x17e824)+'='+encodeURIComponent(_0x22c13b));return _0x17587f['length']?'&'+_0x17587f['join']('&'):'';}function yt(_0xc9c0e9){const _0x27cd2d={};return _0xc9c0e9['replace'](/^\?/,'')['split']('&')['forEach'](_0x360fda=>{if(_0x360fda){const [_0x38a257,_0x340d70]=_0x360fda['split']('=');_0x27cd2d[decodeURIComponent(_0x38a257)]=decodeURIComponent(_0x340d70);}}),_0x27cd2d;}function vt(_0x364b86){const _0x132863=_0x364b86['indexOf']('?');if(!_0x132863)return'';const _0xdce5f4=_0x364b86['indexOf']('#',_0x132863);return _0x364b86['substring'](_0x132863,_0xdce5f4>0x0?_0xdce5f4:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x21b214=0x1;_0x21b214<this['blockSize'];++_0x21b214)this['pad_'][_0x21b214]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1b266d,_0x4d9c3a){_0x4d9c3a||(_0x4d9c3a=0x0);const _0x520a02=this['W_'];if(typeof _0x1b266d=='string'){for(let _0xee2732=0x0;_0xee2732<0x10;_0xee2732++)_0x520a02[_0xee2732]=_0x1b266d['charCodeAt'](_0x4d9c3a)<<0x18|_0x1b266d['charCodeAt'](_0x4d9c3a+0x1)<<0x10|_0x1b266d['charCodeAt'](_0x4d9c3a+0x2)<<0x8|_0x1b266d['charCodeAt'](_0x4d9c3a+0x3),_0x4d9c3a+=0x4;}else{for(let _0x490395=0x0;_0x490395<0x10;_0x490395++)_0x520a02[_0x490395]=_0x1b266d[_0x4d9c3a]<<0x18|_0x1b266d[_0x4d9c3a+0x1]<<0x10|_0x1b266d[_0x4d9c3a+0x2]<<0x8|_0x1b266d[_0x4d9c3a+0x3],_0x4d9c3a+=0x4;}for(let _0x4760be=0x10;_0x4760be<0x50;_0x4760be++){const _0x255a0d=_0x520a02[_0x4760be-0x3]^_0x520a02[_0x4760be-0x8]^_0x520a02[_0x4760be-0xe]^_0x520a02[_0x4760be-0x10];_0x520a02[_0x4760be]=(_0x255a0d<<0x1|_0x255a0d>>>0x1f)&0xffffffff;}let _0x3d48b9=this['chain_'][0x0],_0x468ad4=this['chain_'][0x1],_0x593132=this['chain_'][0x2],_0xcb2544=this['chain_'][0x3],_0x3e9d6b=this['chain_'][0x4],_0x32bec6,_0x10068c;for(let _0xf7358c=0x0;_0xf7358c<0x50;_0xf7358c++){_0xf7358c<0x28?_0xf7358c<0x14?(_0x32bec6=_0xcb2544^_0x468ad4&(_0x593132^_0xcb2544),_0x10068c=0x5a827999):(_0x32bec6=_0x468ad4^_0x593132^_0xcb2544,_0x10068c=0x6ed9eba1):_0xf7358c<0x3c?(_0x32bec6=_0x468ad4&_0x593132|_0xcb2544&(_0x468ad4|_0x593132),_0x10068c=0x8f1bbcdc):(_0x32bec6=_0x468ad4^_0x593132^_0xcb2544,_0x10068c=0xca62c1d6);const _0x32667f=(_0x3d48b9<<0x5|_0x3d48b9>>>0x1b)+_0x32bec6+_0x3e9d6b+_0x10068c+_0x520a02[_0xf7358c]&0xffffffff;_0x3e9d6b=_0xcb2544,_0xcb2544=_0x593132,_0x593132=(_0x468ad4<<0x1e|_0x468ad4>>>0x2)&0xffffffff,_0x468ad4=_0x3d48b9,_0x3d48b9=_0x32667f;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3d48b9&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x468ad4&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x593132&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0xcb2544&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3e9d6b&0xffffffff;}['update'](_0x8a9416,_0x287c9d){if(_0x8a9416==null)return;_0x287c9d===void 0x0&&(_0x287c9d=_0x8a9416['length']);const _0x154903=_0x287c9d-this['blockSize'];let _0x2de4a1=0x0;const _0x734281=this['buf_'];let _0x454228=this['inbuf_'];for(;_0x2de4a1<_0x287c9d;){if(_0x454228===0x0){for(;_0x2de4a1<=_0x154903;)this['compress_'](_0x8a9416,_0x2de4a1),_0x2de4a1+=this['blockSize'];}if(typeof _0x8a9416=='string'){for(;_0x2de4a1<_0x287c9d;)if(_0x734281[_0x454228]=_0x8a9416['charCodeAt'](_0x2de4a1),++_0x454228,++_0x2de4a1,_0x454228===this['blockSize']){this['compress_'](_0x734281),_0x454228=0x0;break;}}else{for(;_0x2de4a1<_0x287c9d;)if(_0x734281[_0x454228]=_0x8a9416[_0x2de4a1],++_0x454228,++_0x2de4a1,_0x454228===this['blockSize']){this['compress_'](_0x734281),_0x454228=0x0;break;}}}this['inbuf_']=_0x454228,this['total_']+=_0x287c9d;}['digest'](){const _0x27035c=[];let _0x3ce1a2=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x350a4e=this['blockSize']-0x1;_0x350a4e>=0x38;_0x350a4e--)this['buf_'][_0x350a4e]=_0x3ce1a2&0xff,_0x3ce1a2/=0x100;this['compress_'](this['buf_']);let _0xec8b1c=0x0;for(let _0x2248e4=0x0;_0x2248e4<0x5;_0x2248e4++)for(let _0x1a2446=0x18;_0x1a2446>=0x0;_0x1a2446-=0x8)_0x27035c[_0xec8b1c]=this['chain_'][_0x2248e4]>>_0x1a2446&0xff,++_0xec8b1c;return _0x27035c;}}function Ic(_0x102e09,_0x115616){const _0x1986bf=new wc(_0x102e09,_0x115616);return _0x1986bf['subscribe']['bind'](_0x1986bf);}class wc{constructor(_0x43067b,_0x682f78){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x682f78,this['task']['then'](()=>{_0x43067b(this);})['catch'](_0x5ed4e1=>{this['error'](_0x5ed4e1);});}['next'](_0x54d1bc){this['forEachObserver'](_0x3ba39c=>{_0x3ba39c['next'](_0x54d1bc);});}['error'](_0x1f8159){this['forEachObserver'](_0x121006=>{_0x121006['error'](_0x1f8159);}),this['close'](_0x1f8159);}['complete'](){this['forEachObserver'](_0x39ae21=>{_0x39ae21['complete']();}),this['close']();}['subscribe'](_0x29d93b,_0x1e1c69,_0x50c29f){let _0xa03e15;if(_0x29d93b===void 0x0&&_0x1e1c69===void 0x0&&_0x50c29f===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x29d93b,['next','error','complete'])?_0xa03e15=_0x29d93b:_0xa03e15={'next':_0x29d93b,'error':_0x1e1c69,'complete':_0x50c29f},_0xa03e15['next']===void 0x0&&(_0xa03e15['next']=Qn),_0xa03e15['error']===void 0x0&&(_0xa03e15['error']=Qn),_0xa03e15['complete']===void 0x0&&(_0xa03e15['complete']=Qn);const _0x3216b2=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0xa03e15['error'](this['finalError']):_0xa03e15['complete']();}catch{}}),this['observers']['push'](_0xa03e15),_0x3216b2;}['unsubscribeOne'](_0x530bae){this['observers']===void 0x0||this['observers'][_0x530bae]===void 0x0||(delete this['observers'][_0x530bae],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4b99a5){if(!this['finalized']){for(let _0x258e4a=0x0;_0x258e4a<this['observers']['length'];_0x258e4a++)this['sendOne'](_0x258e4a,_0x4b99a5);}}['sendOne'](_0x2328fd,_0x58f57d){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2328fd]!==void 0x0)try{_0x58f57d(this['observers'][_0x2328fd]);}catch(_0xf522){typeof console<'u'&&console['error']&&console['error'](_0xf522);}});}['close'](_0x900d4e){this['finalized']||(this['finalized']=!0x0,_0x900d4e!==void 0x0&&(this['finalError']=_0x900d4e),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x671528,_0x1297fb){if(typeof _0x671528!='object'||_0x671528===null)return!0x1;for(const _0x178da2 of _0x1297fb)if(_0x178da2 in _0x671528&&typeof _0x671528[_0x178da2]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x48a398,_0x37c6e9){return _0x48a398+'\x20failed:\x20'+_0x37c6e9+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x216c12){const _0x280db8=[];let _0x5e1e56=0x0;for(let _0x16c498=0x0;_0x16c498<_0x216c12['length'];_0x16c498++){let _0x2c4051=_0x216c12['charCodeAt'](_0x16c498);if(_0x2c4051>=0xd800&&_0x2c4051<=0xdbff){const _0x5da2be=_0x2c4051-0xd800;_0x16c498++,f(_0x16c498<_0x216c12['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x51767c=_0x216c12['charCodeAt'](_0x16c498)-0xdc00;_0x2c4051=0x10000+(_0x5da2be<<0xa)+_0x51767c;}_0x2c4051<0x80?_0x280db8[_0x5e1e56++]=_0x2c4051:_0x2c4051<0x800?(_0x280db8[_0x5e1e56++]=_0x2c4051>>0x6|0xc0,_0x280db8[_0x5e1e56++]=_0x2c4051&0x3f|0x80):_0x2c4051<0x10000?(_0x280db8[_0x5e1e56++]=_0x2c4051>>0xc|0xe0,_0x280db8[_0x5e1e56++]=_0x2c4051>>0x6&0x3f|0x80,_0x280db8[_0x5e1e56++]=_0x2c4051&0x3f|0x80):(_0x280db8[_0x5e1e56++]=_0x2c4051>>0x12|0xf0,_0x280db8[_0x5e1e56++]=_0x2c4051>>0xc&0x3f|0x80,_0x280db8[_0x5e1e56++]=_0x2c4051>>0x6&0x3f|0x80,_0x280db8[_0x5e1e56++]=_0x2c4051&0x3f|0x80);}return _0x280db8;},Pn=function(_0x5e3aaa){let _0x5730aa=0x0;for(let _0x219ddb=0x0;_0x219ddb<_0x5e3aaa['length'];_0x219ddb++){const _0x5a6cc6=_0x5e3aaa['charCodeAt'](_0x219ddb);_0x5a6cc6<0x80?_0x5730aa++:_0x5a6cc6<0x800?_0x5730aa+=0x2:_0x5a6cc6>=0xd800&&_0x5a6cc6<=0xdbff?(_0x5730aa+=0x4,_0x219ddb++):_0x5730aa+=0x3;}return _0x5730aa;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x555881){return _0x555881&&_0x555881['_delegate']?_0x555881['_delegate']:_0x555881;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x2fcd0c){try{return(_0x2fcd0c['startsWith']('http://')||_0x2fcd0c['startsWith']('https://')?new URL(_0x2fcd0c)['hostname']:_0x2fcd0c)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x30a56f){return(await fetch(_0x30a56f,{'credentials':'include'}))['ok'];}class Me{constructor(_0x3b2de4,_0x3cb804,_0x39510d){this['name']=_0x3b2de4,this['instanceFactory']=_0x3cb804,this['type']=_0x39510d,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1c640a){return this['instantiationMode']=_0x1c640a,this;}['setMultipleInstances'](_0x485406){return this['multipleInstances']=_0x485406,this;}['setServiceProps'](_0x3abf17){return this['serviceProps']=_0x3abf17,this;}['setInstanceCreatedCallback'](_0xe8ceb){return this['onInstanceCreated']=_0xe8ceb,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x2b6f65,_0x1f8c31){this['name']=_0x2b6f65,this['container']=_0x1f8c31,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2c558d){const _0x41dfe0=this['normalizeInstanceIdentifier'](_0x2c558d);if(!this['instancesDeferred']['has'](_0x41dfe0)){const _0x2bde51=new Ve();if(this['instancesDeferred']['set'](_0x41dfe0,_0x2bde51),this['isInitialized'](_0x41dfe0)||this['shouldAutoInitialize']())try{const _0x43934b=this['getOrInitializeService']({'instanceIdentifier':_0x41dfe0});_0x43934b&&_0x2bde51['resolve'](_0x43934b);}catch{}}return this['instancesDeferred']['get'](_0x41dfe0)['promise'];}['getImmediate'](_0x4a3802){const _0x120404=this['normalizeInstanceIdentifier'](_0x4a3802==null?void 0x0:_0x4a3802['identifier']),_0x4a8488=(_0x4a3802==null?void 0x0:_0x4a3802['optional'])??!0x1;if(this['isInitialized'](_0x120404)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x120404});}catch(_0x399108){if(_0x4a8488)return null;throw _0x399108;}else{if(_0x4a8488)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0xa31b7d){if(_0xa31b7d['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0xa31b7d['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0xa31b7d,!!this['shouldAutoInitialize']()){if(Rc(_0xa31b7d))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x488193,_0x458f9f]of this['instancesDeferred']['entries']()){const _0x5ae56b=this['normalizeInstanceIdentifier'](_0x488193);try{const _0x7ce143=this['getOrInitializeService']({'instanceIdentifier':_0x5ae56b});_0x458f9f['resolve'](_0x7ce143);}catch{}}}}['clearInstance'](_0x4716c1=ke){this['instancesDeferred']['delete'](_0x4716c1),this['instancesOptions']['delete'](_0x4716c1),this['instances']['delete'](_0x4716c1);}async['delete'](){const _0x1d930d=Array['from'](this['instances']['values']());await Promise['all']([..._0x1d930d['filter'](_0xb8ec67=>'INTERNAL'in _0xb8ec67)['map'](_0x452de4=>_0x452de4['INTERNAL']['delete']()),..._0x1d930d['filter'](_0x16084d=>'_delete'in _0x16084d)['map'](_0x4b7047=>_0x4b7047['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x24cc1d=ke){return this['instances']['has'](_0x24cc1d);}['getOptions'](_0x2da1f6=ke){return this['instancesOptions']['get'](_0x2da1f6)||{};}['initialize'](_0x5874e7={}){const {options:_0x4900fc={}}=_0x5874e7,_0x96968a=this['normalizeInstanceIdentifier'](_0x5874e7['instanceIdentifier']);if(this['isInitialized'](_0x96968a))throw Error(this['name']+'('+_0x96968a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x252f2e=this['getOrInitializeService']({'instanceIdentifier':_0x96968a,'options':_0x4900fc});for(const [_0x5cdaa1,_0x54869d]of this['instancesDeferred']['entries']()){const _0x1066ec=this['normalizeInstanceIdentifier'](_0x5cdaa1);_0x96968a===_0x1066ec&&_0x54869d['resolve'](_0x252f2e);}return _0x252f2e;}['onInit'](_0x44d5fe,_0xa4cc80){const _0x5e8e04=this['normalizeInstanceIdentifier'](_0xa4cc80),_0x28b897=this['onInitCallbacks']['get'](_0x5e8e04)??new Set();_0x28b897['add'](_0x44d5fe),this['onInitCallbacks']['set'](_0x5e8e04,_0x28b897);const _0x1ce2b9=this['instances']['get'](_0x5e8e04);return _0x1ce2b9&&_0x44d5fe(_0x1ce2b9,_0x5e8e04),()=>{_0x28b897['delete'](_0x44d5fe);};}['invokeOnInitCallbacks'](_0x172224,_0x14be9d){const _0x216ac6=this['onInitCallbacks']['get'](_0x14be9d);if(_0x216ac6){for(const _0x54a38b of _0x216ac6)try{_0x54a38b(_0x172224,_0x14be9d);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x193578,options:_0xaf699f={}}){let _0x5805a4=this['instances']['get'](_0x193578);if(!_0x5805a4&&this['component']&&(_0x5805a4=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x193578),'options':_0xaf699f}),this['instances']['set'](_0x193578,_0x5805a4),this['instancesOptions']['set'](_0x193578,_0xaf699f),this['invokeOnInitCallbacks'](_0x5805a4,_0x193578),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x193578,_0x5805a4);}catch{}return _0x5805a4||null;}['normalizeInstanceIdentifier'](_0x2e870f=ke){return this['component']?this['component']['multipleInstances']?_0x2e870f:ke:_0x2e870f;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0xbd2135){return _0xbd2135===ke?void 0x0:_0xbd2135;}function Rc(_0x48b27e){return _0x48b27e['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x5b64ad){this['name']=_0x5b64ad,this['providers']=new Map();}['addComponent'](_0x2c68d9){const _0x428fc3=this['getProvider'](_0x2c68d9['name']);if(_0x428fc3['isComponentSet']())throw new Error('Component\x20'+_0x2c68d9['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x428fc3['setComponent'](_0x2c68d9);}['addOrOverwriteComponent'](_0x2718c4){this['getProvider'](_0x2718c4['name'])['isComponentSet']()&&this['providers']['delete'](_0x2718c4['name']),this['addComponent'](_0x2718c4);}['getProvider'](_0xde79db){if(this['providers']['has'](_0xde79db))return this['providers']['get'](_0xde79db);const _0xe68549=new Sc(_0xde79db,this);return this['providers']['set'](_0xde79db,_0xe68549),_0xe68549;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1816a4){_0x1816a4[_0x1816a4['DEBUG']=0x0]='DEBUG',_0x1816a4[_0x1816a4['VERBOSE']=0x1]='VERBOSE',_0x1816a4[_0x1816a4['INFO']=0x2]='INFO',_0x1816a4[_0x1816a4['WARN']=0x3]='WARN',_0x1816a4[_0x1816a4['ERROR']=0x4]='ERROR',_0x1816a4[_0x1816a4['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x2a2aa1,_0x4ea1e6,..._0x586a6c)=>{if(_0x4ea1e6<_0x2a2aa1['logLevel'])return;const _0x15b869=new Date()['toISOString'](),_0x153618=Pc[_0x4ea1e6];if(_0x153618)console[_0x153618]('['+_0x15b869+']\x20\x20'+_0x2a2aa1['name']+':',..._0x586a6c);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x4ea1e6+')');};class xi{constructor(_0x4b4466){this['name']=_0x4b4466,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x143a41){if(!(_0x143a41 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x143a41+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x143a41;}['setLogLevel'](_0x4c4de2){this['_logLevel']=typeof _0x4c4de2=='string'?kc[_0x4c4de2]:_0x4c4de2;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x173e31){if(typeof _0x173e31!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x173e31;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x28d644){this['_userLogHandler']=_0x28d644;}['debug'](..._0x4288ef){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4288ef),this['_logHandler'](this,T['DEBUG'],..._0x4288ef);}['log'](..._0x402f52){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x402f52),this['_logHandler'](this,T['VERBOSE'],..._0x402f52);}['info'](..._0x3a2921){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3a2921),this['_logHandler'](this,T['INFO'],..._0x3a2921);}['warn'](..._0x1de977){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1de977),this['_logHandler'](this,T['WARN'],..._0x1de977);}['error'](..._0x31326e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x31326e),this['_logHandler'](this,T['ERROR'],..._0x31326e);}}const Dc=(_0xba0006,_0x3eb06b)=>_0x3eb06b['some'](_0x59bf73=>_0xba0006 instanceof _0x59bf73);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x587f47){const _0x2a64f2=new Promise((_0x57cd9e,_0x15f1af)=>{const _0xe3a7e4=()=>{_0x587f47['removeEventListener']('success',_0x54d598),_0x587f47['removeEventListener']('error',_0x56b24a);},_0x54d598=()=>{_0x57cd9e(_e(_0x587f47['result'])),_0xe3a7e4();},_0x56b24a=()=>{_0x15f1af(_0x587f47['error']),_0xe3a7e4();};_0x587f47['addEventListener']('success',_0x54d598),_0x587f47['addEventListener']('error',_0x56b24a);});return _0x2a64f2['then'](_0x278f5c=>{_0x278f5c instanceof IDBCursor&&Kr['set'](_0x278f5c,_0x587f47);})['catch'](()=>{}),Fi['set'](_0x2a64f2,_0x587f47),_0x2a64f2;}function Fc(_0x32d6bd){if(ui['has'](_0x32d6bd))return;const _0x2d44b2=new Promise((_0x1c61a4,_0x30cb5d)=>{const _0x5f023d=()=>{_0x32d6bd['removeEventListener']('complete',_0x279b7c),_0x32d6bd['removeEventListener']('error',_0x1f9e02),_0x32d6bd['removeEventListener']('abort',_0x1f9e02);},_0x279b7c=()=>{_0x1c61a4(),_0x5f023d();},_0x1f9e02=()=>{_0x30cb5d(_0x32d6bd['error']||new DOMException('AbortError','AbortError')),_0x5f023d();};_0x32d6bd['addEventListener']('complete',_0x279b7c),_0x32d6bd['addEventListener']('error',_0x1f9e02),_0x32d6bd['addEventListener']('abort',_0x1f9e02);});ui['set'](_0x32d6bd,_0x2d44b2);}let di={'get'(_0xf8c419,_0x734947,_0x3f4120){if(_0xf8c419 instanceof IDBTransaction){if(_0x734947==='done')return ui['get'](_0xf8c419);if(_0x734947==='objectStoreNames')return _0xf8c419['objectStoreNames']||Yr['get'](_0xf8c419);if(_0x734947==='store')return _0x3f4120['objectStoreNames'][0x1]?void 0x0:_0x3f4120['objectStore'](_0x3f4120['objectStoreNames'][0x0]);}return _e(_0xf8c419[_0x734947]);},'set'(_0x55bde7,_0x590a58,_0x16dee6){return _0x55bde7[_0x590a58]=_0x16dee6,!0x0;},'has'(_0x2a8048,_0x44f69c){return _0x2a8048 instanceof IDBTransaction&&(_0x44f69c==='done'||_0x44f69c==='store')?!0x0:_0x44f69c in _0x2a8048;}};function Uc(_0x50a0ba){di=_0x50a0ba(di);}function Wc(_0x2ebfc0){return _0x2ebfc0===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2f3de5,..._0x41726e){const _0x11301b=_0x2ebfc0['call'](Xn(this),_0x2f3de5,..._0x41726e);return Yr['set'](_0x11301b,_0x2f3de5['sort']?_0x2f3de5['sort']():[_0x2f3de5]),_e(_0x11301b);}:Lc()['includes'](_0x2ebfc0)?function(..._0x5a74dd){return _0x2ebfc0['apply'](Xn(this),_0x5a74dd),_e(Kr['get'](this));}:function(..._0x302e7a){return _e(_0x2ebfc0['apply'](Xn(this),_0x302e7a));};}function Bc(_0x5bb53){return typeof _0x5bb53=='function'?Wc(_0x5bb53):(_0x5bb53 instanceof IDBTransaction&&Fc(_0x5bb53),Dc(_0x5bb53,Mc())?new Proxy(_0x5bb53,di):_0x5bb53);}function _e(_0x47c2d6){if(_0x47c2d6 instanceof IDBRequest)return xc(_0x47c2d6);if(Jn['has'](_0x47c2d6))return Jn['get'](_0x47c2d6);const _0x1a2b01=Bc(_0x47c2d6);return _0x1a2b01!==_0x47c2d6&&(Jn['set'](_0x47c2d6,_0x1a2b01),Fi['set'](_0x1a2b01,_0x47c2d6)),_0x1a2b01;}const Xn=_0x2a69cc=>Fi['get'](_0x2a69cc);function Vc(_0x4747ef,_0x2eb975,{blocked:_0x380b0b,upgrade:_0x380139,blocking:_0x45b943,terminated:_0x514c67}={}){const _0x21cae3=indexedDB['open'](_0x4747ef,_0x2eb975),_0x3a72e7=_e(_0x21cae3);return _0x380139&&_0x21cae3['addEventListener']('upgradeneeded',_0x2e93d7=>{_0x380139(_e(_0x21cae3['result']),_0x2e93d7['oldVersion'],_0x2e93d7['newVersion'],_e(_0x21cae3['transaction']),_0x2e93d7);}),_0x380b0b&&_0x21cae3['addEventListener']('blocked',_0x53f85a=>_0x380b0b(_0x53f85a['oldVersion'],_0x53f85a['newVersion'],_0x53f85a)),_0x3a72e7['then'](_0x28844d=>{_0x514c67&&_0x28844d['addEventListener']('close',()=>_0x514c67()),_0x45b943&&_0x28844d['addEventListener']('versionchange',_0x37a8ad=>_0x45b943(_0x37a8ad['oldVersion'],_0x37a8ad['newVersion'],_0x37a8ad));})['catch'](()=>{}),_0x3a72e7;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x11c79a,_0x57aef6){if(!(_0x11c79a instanceof IDBDatabase&&!(_0x57aef6 in _0x11c79a)&&typeof _0x57aef6=='string'))return;if(Zn['get'](_0x57aef6))return Zn['get'](_0x57aef6);const _0x15b4c3=_0x57aef6['replace'](/FromIndex$/,''),_0x38f157=_0x57aef6!==_0x15b4c3,_0x33c590=$c['includes'](_0x15b4c3);if(!(_0x15b4c3 in(_0x38f157?IDBIndex:IDBObjectStore)['prototype'])||!(_0x33c590||Hc['includes'](_0x15b4c3)))return;const _0x382172=async function(_0x44920f,..._0x43da2b){const _0x258aab=this['transaction'](_0x44920f,_0x33c590?'readwrite':'readonly');let _0x25f77a=_0x258aab['store'];return _0x38f157&&(_0x25f77a=_0x25f77a['index'](_0x43da2b['shift']())),(await Promise['all']([_0x25f77a[_0x15b4c3](..._0x43da2b),_0x33c590&&_0x258aab['done']]))[0x0];};return Zn['set'](_0x57aef6,_0x382172),_0x382172;}Uc(_0x26d7c5=>({..._0x26d7c5,'get':(_0x213243,_0x295b96,_0x5231c2)=>Os(_0x213243,_0x295b96)||_0x26d7c5['get'](_0x213243,_0x295b96,_0x5231c2),'has':(_0x1ae6f8,_0x4bed17)=>!!Os(_0x1ae6f8,_0x4bed17)||_0x26d7c5['has'](_0x1ae6f8,_0x4bed17)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x41ec5a){this['container']=_0x41ec5a;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x905620=>{if(qc(_0x905620)){const _0x33e9e1=_0x905620['getImmediate']();return _0x33e9e1['library']+'/'+_0x33e9e1['version'];}else return null;})['filter'](_0x3a6800=>_0x3a6800)['join']('\x20');}}function qc(_0x18cd58){const _0x591db7=_0x18cd58['getComponent']();return(_0x591db7==null?void 0x0:_0x591db7['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x30c7ff,_0x33dcfe){try{_0x30c7ff['container']['addComponent'](_0x33dcfe);}catch(_0x4ace0b){re['debug']('Component\x20'+_0x33dcfe['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x30c7ff['name'],_0x4ace0b);}}function et(_0x3e4a54){const _0x2202dd=_0x3e4a54['name'];if(gi['has'](_0x2202dd))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x2202dd+'.'),!0x1;gi['set'](_0x2202dd,_0x3e4a54);for(const _0x1f3e50 of Le['values']())Ms(_0x1f3e50,_0x3e4a54);for(const _0x69812e of _i['values']())Ms(_0x69812e,_0x3e4a54);return!0x0;}function Ui(_0x5c9ac9,_0x21b259){const _0x907bf=_0x5c9ac9['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x907bf&&_0x907bf['triggerHeartbeat'](),_0x5c9ac9['container']['getProvider'](_0x21b259);}function H(_0x733697){return _0x733697==null?!0x1:_0x733697['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x4b31e4,_0x728343,_0x8c67a){this['_isDeleted']=!0x1,this['_options']={..._0x4b31e4},this['_config']={..._0x728343},this['_name']=_0x728343['name'],this['_automaticDataCollectionEnabled']=_0x728343['automaticDataCollectionEnabled'],this['_container']=_0x8c67a,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x266cd0){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x266cd0;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x27537f){this['_isDeleted']=_0x27537f;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x3d1b44,_0x3a03f3={}){let _0x21a584=_0x3d1b44;typeof _0x3a03f3!='object'&&(_0x3a03f3={'name':_0x3a03f3});const _0x20e3ae={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x3a03f3},_0x58d18c=_0x20e3ae['name'];if(typeof _0x58d18c!='string'||!_0x58d18c)throw ge['create']('bad-app-name',{'appName':String(_0x58d18c)});if(_0x21a584||(_0x21a584=$r()),!_0x21a584)throw ge['create']('no-options');const _0x247f08=Le['get'](_0x58d18c);if(_0x247f08){if(De(_0x21a584,_0x247f08['options'])&&De(_0x20e3ae,_0x247f08['config']))return _0x247f08;throw ge['create']('duplicate-app',{'appName':_0x58d18c});}const _0x2c3512=new Ac(_0x58d18c);for(const _0x353962 of gi['values']())_0x2c3512['addComponent'](_0x353962);const _0x58b31d=new Il(_0x21a584,_0x20e3ae,_0x2c3512);return Le['set'](_0x58d18c,_0x58b31d),_0x58b31d;}function Qr(_0xf94300=pi){const _0x4f17d8=Le['get'](_0xf94300);if(!_0x4f17d8&&_0xf94300===pi&&$r())return wl();if(!_0x4f17d8)throw ge['create']('no-app',{'appName':_0xf94300});return _0x4f17d8;}function l_(){return Array['from'](Le['values']());}async function h_(_0x5706b8){let _0x185137=!0x1;const _0x2e3a09=_0x5706b8['name'];Le['has'](_0x2e3a09)?(_0x185137=!0x0,Le['delete'](_0x2e3a09)):_i['has'](_0x2e3a09)&&_0x5706b8['decRefCount']()<=0x0&&(_i['delete'](_0x2e3a09),_0x185137=!0x0),_0x185137&&(await Promise['all'](_0x5706b8['container']['getProviders']()['map'](_0x34755a=>_0x34755a['delete']())),_0x5706b8['isDeleted']=!0x0);}function me(_0x15d55f,_0x2e1400,_0x5065be){let _0x4c3c77=vl[_0x15d55f]??_0x15d55f;_0x5065be&&(_0x4c3c77+='-'+_0x5065be);const _0x1783e9=_0x4c3c77['match'](/\s|\//),_0x74967f=_0x2e1400['match'](/\s|\//);if(_0x1783e9||_0x74967f){const _0x493d4d=['Unable\x20to\x20register\x20library\x20\x22'+_0x4c3c77+'\x22\x20with\x20version\x20\x22'+_0x2e1400+'\x22:'];_0x1783e9&&_0x493d4d['push']('library\x20name\x20\x22'+_0x4c3c77+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1783e9&&_0x74967f&&_0x493d4d['push']('and'),_0x74967f&&_0x493d4d['push']('version\x20name\x20\x22'+_0x2e1400+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x493d4d['join']('\x20'));return;}et(new Me(_0x4c3c77+'-version',()=>({'library':_0x4c3c77,'version':_0x2e1400}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x242265,_0x402c9c)=>{switch(_0x402c9c){case 0x0:try{_0x242265['createObjectStore'](Rt);}catch(_0x1725d6){console['warn'](_0x1725d6);}}}})['catch'](_0x388ad4=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x388ad4['message']});})),ei;}async function Sl(_0x1c8f28){try{const _0x282fb5=(await Jr())['transaction'](Rt),_0x159c66=await _0x282fb5['objectStore'](Rt)['get'](Xr(_0x1c8f28));return await _0x282fb5['done'],_0x159c66;}catch(_0x503849){if(_0x503849 instanceof Se)re['warn'](_0x503849['message']);else{const _0x45eef1=ge['create']('idb-get',{'originalErrorMessage':_0x503849==null?void 0x0:_0x503849['message']});re['warn'](_0x45eef1['message']);}}}async function Ls(_0x223da6,_0x417718){try{const _0x5f14e8=(await Jr())['transaction'](Rt,'readwrite');await _0x5f14e8['objectStore'](Rt)['put'](_0x417718,Xr(_0x223da6)),await _0x5f14e8['done'];}catch(_0x3a4ec1){if(_0x3a4ec1 instanceof Se)re['warn'](_0x3a4ec1['message']);else{const _0x5ef3df=ge['create']('idb-set',{'originalErrorMessage':_0x3a4ec1==null?void 0x0:_0x3a4ec1['message']});re['warn'](_0x5ef3df['message']);}}}function Xr(_0x334819){return _0x334819['name']+'!'+_0x334819['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x132bdc){this['container']=_0x132bdc,this['_heartbeatsCache']=null;const _0xef2ee2=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0xef2ee2),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4f22b4=>(this['_heartbeatsCache']=_0x4f22b4,_0x4f22b4));}async['triggerHeartbeat'](){var _0x175fc9,_0x4a2beb;try{const _0x530909=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x5f942b=xs();if(((_0x175fc9=this['_heartbeatsCache'])==null?void 0x0:_0x175fc9['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4a2beb=this['_heartbeatsCache'])==null?void 0x0:_0x4a2beb['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x5f942b||this['_heartbeatsCache']['heartbeats']['some'](_0x1f1dd0=>_0x1f1dd0['date']===_0x5f942b))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x5f942b,'agent':_0x530909}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x39f4a9=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x39f4a9,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4f2073){re['warn'](_0x4f2073);}}async['getHeartbeatsHeader'](){var _0xc1435e;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xc1435e=this['_heartbeatsCache'])==null?void 0x0:_0xc1435e['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x415f2a=xs(),{heartbeatsToSend:_0x1cf714,unsentEntries:_0x206620}=kl(this['_heartbeatsCache']['heartbeats']),_0x351cde=an(JSON['stringify']({'version':0x2,'heartbeats':_0x1cf714}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x415f2a,_0x206620['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x206620,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x351cde;}catch(_0x47e17d){return re['warn'](_0x47e17d),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x39bc7c,_0x4a7cee=bl){const _0x55caea=[];let _0xaffd43=_0x39bc7c['slice']();for(const _0x14115d of _0x39bc7c){const _0x25767e=_0x55caea['find'](_0x24f328=>_0x24f328['agent']===_0x14115d['agent']);if(_0x25767e){if(_0x25767e['dates']['push'](_0x14115d['date']),Fs(_0x55caea)>_0x4a7cee){_0x25767e['dates']['pop']();break;}}else{if(_0x55caea['push']({'agent':_0x14115d['agent'],'dates':[_0x14115d['date']]}),Fs(_0x55caea)>_0x4a7cee){_0x55caea['pop']();break;}}_0xaffd43=_0xaffd43['slice'](0x1);}return{'heartbeatsToSend':_0x55caea,'unsentEntries':_0xaffd43};}class Nl{constructor(_0xf85a62){this['app']=_0xf85a62,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x47fa09=await Sl(this['app']);return _0x47fa09!=null&&_0x47fa09['heartbeats']?_0x47fa09:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x14f1eb){if(await this['_canUseIndexedDBPromise']){const _0x487ede=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x14f1eb['lastSentHeartbeatDate']??_0x487ede['lastSentHeartbeatDate'],'heartbeats':_0x14f1eb['heartbeats']});}else return;}async['add'](_0x4603ba){if(await this['_canUseIndexedDBPromise']){const _0x59df57=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x4603ba['lastSentHeartbeatDate']??_0x59df57['lastSentHeartbeatDate'],'heartbeats':[..._0x59df57['heartbeats'],..._0x4603ba['heartbeats']]});}else return;}}function Fs(_0x4d0b5c){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x4d0b5c}))['length'];}function Pl(_0xc6ca3){if(_0xc6ca3['length']===0x0)return-0x1;let _0x1deb9c=0x0,_0x27cf5f=_0xc6ca3[0x0]['date'];for(let _0x5ea7d3=0x1;_0x5ea7d3<_0xc6ca3['length'];_0x5ea7d3++)_0xc6ca3[_0x5ea7d3]['date']<_0x27cf5f&&(_0x27cf5f=_0xc6ca3[_0x5ea7d3]['date'],_0x1deb9c=_0x5ea7d3);return _0x1deb9c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x234e27){et(new Me('platform-logger',_0x55e1cf=>new Gc(_0x55e1cf),'PRIVATE')),et(new Me('heartbeat',_0x3d48fa=>new Al(_0x3d48fa),'PRIVATE')),me(fi,Ds,_0x234e27),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x24a1a5){Zr=_0x24a1a5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x4af582){this['domStorage_']=_0x4af582,this['prefix_']='firebase:';}['set'](_0xf95d80,_0x421873){_0x421873==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0xf95d80)):this['domStorage_']['setItem'](this['prefixedName_'](_0xf95d80),O(_0x421873));}['get'](_0x4e2a24){const _0x1c6e13=this['domStorage_']['getItem'](this['prefixedName_'](_0x4e2a24));return _0x1c6e13==null?null:bt(_0x1c6e13);}['remove'](_0x315fa7){this['domStorage_']['removeItem'](this['prefixedName_'](_0x315fa7));}['prefixedName_'](_0x499e47){return this['prefix_']+_0x499e47;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1119cd,_0x179ffd){_0x179ffd==null?delete this['cache_'][_0x1119cd]:this['cache_'][_0x1119cd]=_0x179ffd;}['get'](_0x2b13f2){return Y(this['cache_'],_0x2b13f2)?this['cache_'][_0x2b13f2]:null;}['remove'](_0x2d11d5){delete this['cache_'][_0x2d11d5];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x46d73d){try{if(typeof window<'u'&&typeof window[_0x46d73d]<'u'){const _0x48d8a3=window[_0x46d73d];return _0x48d8a3['setItem']('firebase:sentinel','cache'),_0x48d8a3['removeItem']('firebase:sentinel'),new xl(_0x48d8a3);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x382a02=0x1;return function(){return _0x382a02++;};}()),no=function(_0x4e7567){const _0x13fa52=Tc(_0x4e7567),_0x291104=new Ec();_0x291104['update'](_0x13fa52);const _0x56adee=_0x291104['digest']();return Di['encodeByteArray'](_0x56adee);},Bt=function(..._0x50b16b){let _0x3b4c80='';for(let _0x3d065d=0x0;_0x3d065d<_0x50b16b['length'];_0x3d065d++){const _0x5015bd=_0x50b16b[_0x3d065d];Array['isArray'](_0x5015bd)||_0x5015bd&&typeof _0x5015bd=='object'&&typeof _0x5015bd['length']=='number'?_0x3b4c80+=Bt['apply'](null,_0x5015bd):typeof _0x5015bd=='object'?_0x3b4c80+=O(_0x5015bd):_0x3b4c80+=_0x5015bd,_0x3b4c80+='\x20';}return _0x3b4c80;};let Et=null,Vs=!0x0;const Wl=function(_0xf0e5dc,_0x270d9a){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x14be09){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x4a4181=Bt['apply'](null,_0x14be09);Et(_0x4a4181);}},Vt=function(_0x37db94){return function(..._0x2aeb30){L(_0x37db94,..._0x2aeb30);};},mi=function(..._0x3b6e43){const _0x33c052='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x3b6e43);Qe['error'](_0x33c052);},oe=function(..._0x903c38){const _0x305b1b='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x903c38);throw Qe['error'](_0x305b1b),new Error(_0x305b1b);},U=function(..._0x3f1e6a){const _0x28319d='FIREBASE\x20WARNING:\x20'+Bt(..._0x3f1e6a);Qe['warn'](_0x28319d);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x9f5ba0){return typeof _0x9f5ba0=='number'&&(_0x9f5ba0!==_0x9f5ba0||_0x9f5ba0===Number['POSITIVE_INFINITY']||_0x9f5ba0===Number['NEGATIVE_INFINITY']);},Vl=function(_0x28d296){if(document['readyState']==='complete')_0x28d296();else{let _0x59228c=!0x1;const _0x3a0c98=function(){if(!document['body']){setTimeout(_0x3a0c98,Math['floor'](0xa));return;}_0x59228c||(_0x59228c=!0x0,_0x28d296());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3a0c98,!0x1),window['addEventListener']('load',_0x3a0c98,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3a0c98();}),window['attachEvent']('onload',_0x3a0c98));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x591fb1,_0x464ad2){if(_0x591fb1===_0x464ad2)return 0x0;if(_0x591fb1===xe||_0x464ad2===Ie)return-0x1;if(_0x464ad2===xe||_0x591fb1===Ie)return 0x1;{const _0x1917cb=Hs(_0x591fb1),_0x1bbc23=Hs(_0x464ad2);return _0x1917cb!==null?_0x1bbc23!==null?_0x1917cb-_0x1bbc23===0x0?_0x591fb1['length']-_0x464ad2['length']:_0x1917cb-_0x1bbc23:-0x1:_0x1bbc23!==null?0x1:_0x591fb1<_0x464ad2?-0x1:0x1;}},Hl=function(_0x3ff555,_0x17e5d2){return _0x3ff555===_0x17e5d2?0x0:_0x3ff555<_0x17e5d2?-0x1:0x1;},pt=function(_0x1bded2,_0xb490){if(_0xb490&&_0x1bded2 in _0xb490)return _0xb490[_0x1bded2];throw new Error('Missing\x20required\x20key\x20('+_0x1bded2+')\x20in\x20object:\x20'+O(_0xb490));},Bi=function(_0x34ed95){if(typeof _0x34ed95!='object'||_0x34ed95===null)return O(_0x34ed95);const _0x1d577f=[];for(const _0x1d35cc in _0x34ed95)_0x1d577f['push'](_0x1d35cc);_0x1d577f['sort']();let _0x317fd3='{';for(let _0x2d12cc=0x0;_0x2d12cc<_0x1d577f['length'];_0x2d12cc++)_0x2d12cc!==0x0&&(_0x317fd3+=','),_0x317fd3+=O(_0x1d577f[_0x2d12cc]),_0x317fd3+=':',_0x317fd3+=Bi(_0x34ed95[_0x1d577f[_0x2d12cc]]);return _0x317fd3+='}',_0x317fd3;},io=function(_0x4e643d,_0x2b5768){const _0x55d7b2=_0x4e643d['length'];if(_0x55d7b2<=_0x2b5768)return[_0x4e643d];const _0x5b8e23=[];for(let _0x2492ab=0x0;_0x2492ab<_0x55d7b2;_0x2492ab+=_0x2b5768)_0x2492ab+_0x2b5768>_0x55d7b2?_0x5b8e23['push'](_0x4e643d['substring'](_0x2492ab,_0x55d7b2)):_0x5b8e23['push'](_0x4e643d['substring'](_0x2492ab,_0x2492ab+_0x2b5768));return _0x5b8e23;};function x(_0x1c1e28,_0x11c467){for(const _0xd4e09 in _0x1c1e28)_0x1c1e28['hasOwnProperty'](_0xd4e09)&&_0x11c467(_0xd4e09,_0x1c1e28[_0xd4e09]);}const so=function(_0x51dc06){f(!Wi(_0x51dc06),'Invalid\x20JSON\x20number');const _0x485792=0xb,_0x3a0a86=0x34,_0x36cbb0=(0x1<<_0x485792-0x1)-0x1;let _0x41a4c3,_0xe069ef,_0x69114b,_0x4d34ad,_0x848856;_0x51dc06===0x0?(_0xe069ef=0x0,_0x69114b=0x0,_0x41a4c3=0x1/_0x51dc06===-0x1/0x0?0x1:0x0):(_0x41a4c3=_0x51dc06<0x0,_0x51dc06=Math['abs'](_0x51dc06),_0x51dc06>=Math['pow'](0x2,0x1-_0x36cbb0)?(_0x4d34ad=Math['min'](Math['floor'](Math['log'](_0x51dc06)/Math['LN2']),_0x36cbb0),_0xe069ef=_0x4d34ad+_0x36cbb0,_0x69114b=Math['round'](_0x51dc06*Math['pow'](0x2,_0x3a0a86-_0x4d34ad)-Math['pow'](0x2,_0x3a0a86))):(_0xe069ef=0x0,_0x69114b=Math['round'](_0x51dc06/Math['pow'](0x2,0x1-_0x36cbb0-_0x3a0a86))));const _0x18c49d=[];for(_0x848856=_0x3a0a86;_0x848856;_0x848856-=0x1)_0x18c49d['push'](_0x69114b%0x2?0x1:0x0),_0x69114b=Math['floor'](_0x69114b/0x2);for(_0x848856=_0x485792;_0x848856;_0x848856-=0x1)_0x18c49d['push'](_0xe069ef%0x2?0x1:0x0),_0xe069ef=Math['floor'](_0xe069ef/0x2);_0x18c49d['push'](_0x41a4c3?0x1:0x0),_0x18c49d['reverse']();const _0x3a3dd1=_0x18c49d['join']('');let _0x10b090='';for(_0x848856=0x0;_0x848856<0x40;_0x848856+=0x8){let _0x11f7ff=parseInt(_0x3a3dd1['substr'](_0x848856,0x8),0x2)['toString'](0x10);_0x11f7ff['length']===0x1&&(_0x11f7ff='0'+_0x11f7ff),_0x10b090=_0x10b090+_0x11f7ff;}return _0x10b090['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x1c2833,_0x2ea68b){let _0x2a3184='Unknown\x20Error';_0x1c2833==='too_big'?_0x2a3184='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1c2833==='permission_denied'?_0x2a3184='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1c2833==='unavailable'&&(_0x2a3184='The\x20service\x20is\x20unavailable');const _0x75e962=new Error(_0x1c2833+'\x20at\x20'+_0x2ea68b['_path']['toString']()+':\x20'+_0x2a3184);return _0x75e962['code']=_0x1c2833['toUpperCase'](),_0x75e962;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x514e26){if(zl['test'](_0x514e26)){const _0x3c9cb3=Number(_0x514e26);if(_0x3c9cb3>=jl&&_0x3c9cb3<=Kl)return _0x3c9cb3;}return null;},lt=function(_0x976f7e){try{_0x976f7e();}catch(_0x473f9b){setTimeout(()=>{const _0x1063c3=_0x473f9b['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1063c3),_0x473f9b;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x154b62,_0x373ff2){const _0x9191c4=setTimeout(_0x154b62,_0x373ff2);return typeof _0x9191c4=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x9191c4):typeof _0x9191c4=='object'&&_0x9191c4['unref']&&_0x9191c4['unref'](),_0x9191c4;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x479c68,_0xa52cb4){this['appCheckProvider']=_0xa52cb4,this['appName']=_0x479c68['name'],H(_0x479c68)&&_0x479c68['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x479c68['settings']['appCheckToken']),this['appCheck']=_0xa52cb4==null?void 0x0:_0xa52cb4['getImmediate']({'optional':!0x0}),this['appCheck']||_0xa52cb4==null||_0xa52cb4['get']()['then'](_0x35c180=>this['appCheck']=_0x35c180);}['getToken'](_0xdb3e1){if(this['serverAppAppCheckToken']){if(_0xdb3e1)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0xdb3e1):new Promise((_0x5e94ab,_0x568379)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0xdb3e1)['then'](_0x5e94ab,_0x568379):_0x5e94ab(null);},0x0);});}['addTokenChangeListener'](_0x1d20bf){var _0x263794;(_0x263794=this['appCheckProvider'])==null||_0x263794['get']()['then'](_0x32350d=>_0x32350d['addTokenListener'](_0x1d20bf));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x116fc2,_0x1c1f9a,_0x173b5f){this['appName_']=_0x116fc2,this['firebaseOptions_']=_0x1c1f9a,this['authProvider_']=_0x173b5f,this['auth_']=null,this['auth_']=_0x173b5f['getImmediate']({'optional':!0x0}),this['auth_']||_0x173b5f['onInit'](_0x1b7dfd=>this['auth_']=_0x1b7dfd);}['getToken'](_0x375830){return this['auth_']?this['auth_']['getToken'](_0x375830)['catch'](_0x13d221=>_0x13d221&&_0x13d221['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x13d221)):new Promise((_0x2ef022,_0x5e7b8c)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x375830)['then'](_0x2ef022,_0x5e7b8c):_0x2ef022(null);},0x0);});}['addTokenChangeListener'](_0x459979){this['auth_']?this['auth_']['addAuthTokenListener'](_0x459979):this['authProvider_']['get']()['then'](_0x301e3f=>_0x301e3f['addAuthTokenListener'](_0x459979));}['removeTokenChangeListener'](_0x399e2f){this['authProvider_']['get']()['then'](_0x1434f9=>_0x1434f9['removeAuthTokenListener'](_0x399e2f));}['notifyForInvalidToken'](){let _0x13bf8e='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x13bf8e+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x13bf8e+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x13bf8e+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x13bf8e);}}class tn{constructor(_0x5e71bb){this['accessToken']=_0x5e71bb;}['getToken'](_0x7ea6){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x431b4a){_0x431b4a(this['accessToken']);}['removeTokenChangeListener'](_0x20de91){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0xb55aa0,_0x18878a,_0x1ac6ad,_0x2a22a2,_0x629f96=!0x1,_0x3c4581='',_0x1f1da1=!0x1,_0x39055b=!0x1,_0x5ee72f=null){this['secure']=_0x18878a,this['namespace']=_0x1ac6ad,this['webSocketOnly']=_0x2a22a2,this['nodeAdmin']=_0x629f96,this['persistenceKey']=_0x3c4581,this['includeNamespaceInQueryParams']=_0x1f1da1,this['isUsingEmulator']=_0x39055b,this['emulatorOptions']=_0x5ee72f,this['_host']=_0xb55aa0['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0xb55aa0)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x26f402){_0x26f402!==this['internalHost']&&(this['internalHost']=_0x26f402,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x316ad9=this['toURLString']();return this['persistenceKey']&&(_0x316ad9+='<'+this['persistenceKey']+'>'),_0x316ad9;}['toURLString'](){const _0x1e2689=this['secure']?'https://':'http://',_0x1fcf4b=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x1e2689+this['host']+'/'+_0x1fcf4b;}}function Xl(_0x418d6d){return _0x418d6d['host']!==_0x418d6d['internalHost']||_0x418d6d['isCustomHost']()||_0x418d6d['includeNamespaceInQueryParams'];}function go(_0x52f223,_0x3ac355,_0x2644b9){f(typeof _0x3ac355=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2644b9=='object','typeof\x20params\x20must\x20==\x20object');let _0x4d2598;if(_0x3ac355===fo)_0x4d2598=(_0x52f223['secure']?'wss://':'ws://')+_0x52f223['internalHost']+'/.ws?';else{if(_0x3ac355===po)_0x4d2598=(_0x52f223['secure']?'https://':'http://')+_0x52f223['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3ac355);}Xl(_0x52f223)&&(_0x2644b9['ns']=_0x52f223['namespace']);const _0x476ea9=[];return x(_0x2644b9,(_0x77e9e6,_0xf96f3)=>{_0x476ea9['push'](_0x77e9e6+'='+_0xf96f3);}),_0x4d2598+_0x476ea9['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x576424,_0x22586c=0x1){Y(this['counters_'],_0x576424)||(this['counters_'][_0x576424]=0x0),this['counters_'][_0x576424]+=_0x22586c;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x24c774){const _0x412b90=_0x24c774['toString']();return ti[_0x412b90]||(ti[_0x412b90]=new Zl()),ti[_0x412b90];}function eh(_0x3951ad,_0x3517d3){const _0x3245b0=_0x3951ad['toString']();return ni[_0x3245b0]||(ni[_0x3245b0]=_0x3517d3()),ni[_0x3245b0];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x324778){this['onMessage_']=_0x324778,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x257c66,_0x1037d2){this['closeAfterResponse']=_0x257c66,this['onClose']=_0x1037d2,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4366b4,_0x50e9e0){for(this['pendingResponses'][_0x4366b4]=_0x50e9e0;this['pendingResponses'][this['currentResponseNum']];){const _0x6850e4=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3f756d=0x0;_0x3f756d<_0x6850e4['length'];++_0x3f756d)_0x6850e4[_0x3f756d]&&lt(()=>{this['onMessage_'](_0x6850e4[_0x3f756d]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x196f2e,_0x191772,_0x26fd7a,_0xb284fc,_0x53921c,_0xb1d0d9,_0x8b674d){this['connId']=_0x196f2e,this['repoInfo']=_0x191772,this['applicationId']=_0x26fd7a,this['appCheckToken']=_0xb284fc,this['authToken']=_0x53921c,this['transportSessionId']=_0xb1d0d9,this['lastSessionId']=_0x8b674d,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x196f2e),this['stats_']=Hi(_0x191772),this['urlFn']=_0x32de31=>(this['appCheckToken']&&(_0x32de31[yi]=this['appCheckToken']),go(_0x191772,po,_0x32de31));}['open'](_0x3fe98f,_0x2ac79){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2ac79,this['myPacketOrderer']=new th(_0x3fe98f),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x1b2c92)=>{const [_0x307be,_0x42f120,_0xbf1f44,_0x1b89ed,_0x4a5b26]=_0x1b2c92;if(this['incrementIncomingBytes_'](_0x1b2c92),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x307be===$s)this['id']=_0x42f120,this['password']=_0xbf1f44;else{if(_0x307be===nh)_0x42f120?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x42f120,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x307be);}}},(..._0x2b3e32)=>{const [_0x391586,_0x1b0f45]=_0x2b3e32;this['incrementIncomingBytes_'](_0x2b3e32),this['myPacketOrderer']['handleResponse'](_0x391586,_0x1b0f45);},()=>{this['onClosed_']();},this['urlFn']);const _0x100c7f={};_0x100c7f[$s]='t',_0x100c7f[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x100c7f[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x100c7f[ro]=Vi,this['transportSessionId']&&(_0x100c7f[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x100c7f[ho]=this['lastSessionId']),this['applicationId']&&(_0x100c7f[uo]=this['applicationId']),this['appCheckToken']&&(_0x100c7f[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x100c7f[ao]=co);const _0x17ff1c=this['urlFn'](_0x100c7f);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x17ff1c),this['scriptTagHolder']['addTag'](_0x17ff1c,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x290dd8){const _0x47d135=O(_0x290dd8);this['bytesSent']+=_0x47d135['length'],this['stats_']['incrementCounter']('bytes_sent',_0x47d135['length']);const _0x42e9bc=Br(_0x47d135),_0x1e997c=io(_0x42e9bc,hh);for(let _0x2a54ee=0x0;_0x2a54ee<_0x1e997c['length'];_0x2a54ee++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1e997c['length'],_0x1e997c[_0x2a54ee]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4e6ce0,_0x269b92){this['myDisconnFrame']=document['createElement']('iframe');const _0x5071a1={};_0x5071a1[lh]='t',_0x5071a1[mo]=_0x4e6ce0,_0x5071a1[yo]=_0x269b92,this['myDisconnFrame']['src']=this['urlFn'](_0x5071a1),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1bda1a){const _0x524bf3=O(_0x1bda1a)['length'];this['bytesReceived']+=_0x524bf3,this['stats_']['incrementCounter']('bytes_received',_0x524bf3);}}class $i{constructor(_0xa76864,_0x438d42,_0x27a5a3,_0x20dd7d){this['onDisconnect']=_0x27a5a3,this['urlFn']=_0x20dd7d,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0xa76864,window[sh+this['uniqueCallbackIdentifier']]=_0x438d42,this['myIFrame']=$i['createIFrame_']();let _0x3bd52d='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3bd52d='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4cacd4='<html><body>'+_0x3bd52d+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4cacd4),this['myIFrame']['doc']['close']();}catch(_0x117ddb){L('frame\x20writing\x20exception'),_0x117ddb['stack']&&L(_0x117ddb['stack']),L(_0x117ddb);}}}static['createIFrame_'](){const _0x35f22a=document['createElement']('iframe');if(_0x35f22a['style']['display']='none',document['body']){document['body']['appendChild'](_0x35f22a);try{_0x35f22a['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1f1079=document['domain'];_0x35f22a['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1f1079+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x35f22a['contentDocument']?_0x35f22a['doc']=_0x35f22a['contentDocument']:_0x35f22a['contentWindow']?_0x35f22a['doc']=_0x35f22a['contentWindow']['document']:_0x35f22a['document']&&(_0x35f22a['doc']=_0x35f22a['document']),_0x35f22a;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x250830=this['onDisconnect'];_0x250830&&(this['onDisconnect']=null,_0x250830());}['startLongPoll'](_0x1d853a,_0x27f084){for(this['myID']=_0x1d853a,this['myPW']=_0x27f084,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5eead9={};_0x5eead9[mo]=this['myID'],_0x5eead9[yo]=this['myPW'],_0x5eead9[vo]=this['currentSerial'];let _0x138c51=this['urlFn'](_0x5eead9),_0x519f6a='',_0x1122c9=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x519f6a['length']<=Eo;){const _0x3fe699=this['pendingSegs']['shift']();_0x519f6a=_0x519f6a+'&'+oh+_0x1122c9+'='+_0x3fe699['seg']+'&'+ah+_0x1122c9+'='+_0x3fe699['ts']+'&'+ch+_0x1122c9+'='+_0x3fe699['d'],_0x1122c9++;}return _0x138c51=_0x138c51+_0x519f6a,this['addLongPollTag_'](_0x138c51,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x36972e,_0x456914,_0x54a90c){this['pendingSegs']['push']({'seg':_0x36972e,'ts':_0x456914,'d':_0x54a90c}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x51d408,_0x53583f){this['outstandingRequests']['add'](_0x53583f);const _0x317336=()=>{this['outstandingRequests']['delete'](_0x53583f),this['newRequest_']();},_0x3d0284=setTimeout(_0x317336,Math['floor'](uh)),_0x2316de=()=>{clearTimeout(_0x3d0284),_0x317336();};this['addTag'](_0x51d408,_0x2316de);}['addTag'](_0x2af5b8,_0x2bc287){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x523a37=this['myIFrame']['doc']['createElement']('script');_0x523a37['type']='text/javascript',_0x523a37['async']=!0x0,_0x523a37['src']=_0x2af5b8,_0x523a37['onload']=_0x523a37['onreadystatechange']=function(){const _0x72780d=_0x523a37['readyState'];(!_0x72780d||_0x72780d==='loaded'||_0x72780d==='complete')&&(_0x523a37['onload']=_0x523a37['onreadystatechange']=null,_0x523a37['parentNode']&&_0x523a37['parentNode']['removeChild'](_0x523a37),_0x2bc287());},_0x523a37['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2af5b8),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x523a37);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x300251,_0x565a04,_0x3bf654,_0x2624d8,_0x5571b8,_0x4dbe59,_0x3b6c63){this['connId']=_0x300251,this['applicationId']=_0x3bf654,this['appCheckToken']=_0x2624d8,this['authToken']=_0x5571b8,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x565a04),this['connURL']=G['connectionURL_'](_0x565a04,_0x4dbe59,_0x3b6c63,_0x2624d8,_0x3bf654),this['nodeAdmin']=_0x565a04['nodeAdmin'];}static['connectionURL_'](_0x35fa57,_0x5cd965,_0x348b5a,_0x5767b1,_0x14b694){const _0x4563b4={};return _0x4563b4[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4563b4[ao]=co),_0x5cd965&&(_0x4563b4[oo]=_0x5cd965),_0x348b5a&&(_0x4563b4[ho]=_0x348b5a),_0x5767b1&&(_0x4563b4[yi]=_0x5767b1),_0x14b694&&(_0x4563b4[uo]=_0x14b694),go(_0x35fa57,fo,_0x4563b4);}['open'](_0x116f8b,_0x5425ff){this['onDisconnect']=_0x5425ff,this['onMessage']=_0x116f8b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x49494f;dc(),this['mySock']=new hn(this['connURL'],[],_0x49494f);}catch(_0x13fefd){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x199abe=_0x13fefd['message']||_0x13fefd['data'];_0x199abe&&this['log_'](_0x199abe),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x435f31=>{this['handleIncomingFrame'](_0x435f31);},this['mySock']['onerror']=_0x4b4196=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3f040b=_0x4b4196['message']||_0x4b4196['data'];_0x3f040b&&this['log_'](_0x3f040b),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x120f63=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1fdd94=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4c6016=navigator['userAgent']['match'](_0x1fdd94);_0x4c6016&&_0x4c6016['length']>0x1&&parseFloat(_0x4c6016[0x1])<4.4&&(_0x120f63=!0x0);}return!_0x120f63&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x5d30c9){if(this['frames']['push'](_0x5d30c9),this['frames']['length']===this['totalFrames']){const _0xa738d2=this['frames']['join']('');this['frames']=null;const _0x55c71c=bt(_0xa738d2);this['onMessage'](_0x55c71c);}}['handleNewFrameCount_'](_0x5f730){this['totalFrames']=_0x5f730,this['frames']=[];}['extractFrameCount_'](_0x378834){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x378834['length']<=0x6){const _0x73b5f=Number(_0x378834);if(!isNaN(_0x73b5f))return this['handleNewFrameCount_'](_0x73b5f),null;}return this['handleNewFrameCount_'](0x1),_0x378834;}['handleIncomingFrame'](_0x2e5639){if(this['mySock']===null)return;const _0x4c196e=_0x2e5639['data'];if(this['bytesReceived']+=_0x4c196e['length'],this['stats_']['incrementCounter']('bytes_received',_0x4c196e['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4c196e);else{const _0x4df9dc=this['extractFrameCount_'](_0x4c196e);_0x4df9dc!==null&&this['appendFrame_'](_0x4df9dc);}}['send'](_0x11cb0d){this['resetKeepAlive']();const _0x4a09dd=O(_0x11cb0d);this['bytesSent']+=_0x4a09dd['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4a09dd['length']);const _0x48e993=io(_0x4a09dd,fh);_0x48e993['length']>0x1&&this['sendString_'](String(_0x48e993['length']));for(let _0x376cfa=0x0;_0x376cfa<_0x48e993['length'];_0x376cfa++)this['sendString_'](_0x48e993[_0x376cfa]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x20d4b7){try{this['mySock']['send'](_0x20d4b7);}catch(_0x542de3){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x542de3['message']||_0x542de3['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0xb66604){this['initTransports_'](_0xb66604);}['initTransports_'](_0x5874cf){const _0x348e7d=G&&G['isAvailable']();let _0x493e09=_0x348e7d&&!G['previouslyFailed']();if(_0x5874cf['webSocketOnly']&&(_0x348e7d||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x493e09=!0x0),_0x493e09)this['transports_']=[G];else{const _0x2d65d5=this['transports_']=[];for(const _0x3f8be4 of At['ALL_TRANSPORTS'])_0x3f8be4&&_0x3f8be4['isAvailable']()&&_0x2d65d5['push'](_0x3f8be4);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x690e91,_0x33b261,_0x9a2e0f,_0x2324a5,_0x157106,_0x3c7164,_0x1a6eec,_0x2d6ddd,_0x3f3047,_0x23db2e){this['id']=_0x690e91,this['repoInfo_']=_0x33b261,this['applicationId_']=_0x9a2e0f,this['appCheckToken_']=_0x2324a5,this['authToken_']=_0x157106,this['onMessage_']=_0x3c7164,this['onReady_']=_0x1a6eec,this['onDisconnect_']=_0x2d6ddd,this['onKill_']=_0x3f3047,this['lastSessionId']=_0x23db2e,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x33b261),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4d772f=this['transportManager_']['initialTransport']();this['conn_']=new _0x4d772f(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4d772f['responsesRequiredToBeHealthy']||0x0;const _0x3a03aa=this['connReceiver_'](this['conn_']),_0xec20cf=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3a03aa,_0xec20cf);},Math['floor'](0x0));const _0x43b035=_0x4d772f['healthyTimeout']||0x0;_0x43b035>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x43b035)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x3d5ebd){return _0x17c878=>{_0x3d5ebd===this['conn_']?this['onConnectionLost_'](_0x17c878):_0x3d5ebd===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x111f02){return _0x57809f=>{this['state_']!==0x2&&(_0x111f02===this['rx_']?this['onPrimaryMessageReceived_'](_0x57809f):_0x111f02===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x57809f):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5f52e8){const _0x3d6dec={'t':'d','d':_0x5f52e8};this['sendData_'](_0x3d6dec);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1ae3a3){if(ii in _0x1ae3a3){const _0x5d5fca=_0x1ae3a3[ii];_0x5d5fca===js?this['upgradeIfSecondaryHealthy_']():_0x5d5fca===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5d5fca===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x72fe90){const _0x10bc4b=pt('t',_0x72fe90),_0x358c00=pt('d',_0x72fe90);if(_0x10bc4b==='c')this['onSecondaryControl_'](_0x358c00);else{if(_0x10bc4b==='d')this['pendingDataMessages']['push'](_0x358c00);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x10bc4b);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x587635){const _0x57cb4c=pt('t',_0x587635),_0x3ee7d2=pt('d',_0x587635);_0x57cb4c==='c'?this['onControl_'](_0x3ee7d2):_0x57cb4c==='d'&&this['onDataMessage_'](_0x3ee7d2);}['onDataMessage_'](_0x1a60d4){this['onPrimaryResponse_'](),this['onMessage_'](_0x1a60d4);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x1d5174){const _0x40427a=pt(ii,_0x1d5174);if(Gs in _0x1d5174){const _0x4a44fc=_0x1d5174[Gs];if(_0x40427a===Ih){const _0x3246ca={..._0x4a44fc};this['repoInfo_']['isUsingEmulator']&&(_0x3246ca['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x3246ca);}else{if(_0x40427a===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x283460=0x0;_0x283460<this['pendingDataMessages']['length'];++_0x283460)this['onDataMessage_'](this['pendingDataMessages'][_0x283460]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x40427a===vh?this['onConnectionShutdown_'](_0x4a44fc):_0x40427a===qs?this['onReset_'](_0x4a44fc):_0x40427a===Eh?mi('Server\x20Error:\x20'+_0x4a44fc):_0x40427a===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x40427a);}}}['onHandshake_'](_0x108581){const _0x2e6baa=_0x108581['ts'],_0x2625b0=_0x108581['v'],_0x1b2158=_0x108581['h'];this['sessionId']=_0x108581['s'],this['repoInfo_']['host']=_0x1b2158,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2e6baa),Vi!==_0x2625b0&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x3c7c3c=this['transportManager_']['upgradeTransport']();_0x3c7c3c&&this['startUpgrade_'](_0x3c7c3c);}['startUpgrade_'](_0x24a751){this['secondaryConn_']=new _0x24a751(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x24a751['responsesRequiredToBeHealthy']||0x0;const _0x47e021=this['connReceiver_'](this['secondaryConn_']),_0x28450e=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x47e021,_0x28450e),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x1317dc){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x1317dc),this['repoInfo_']['host']=_0x1317dc,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x45affc,_0xf52bd5){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x45affc,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xf52bd5,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x396b77=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x396b77||this['rx_']===_0x396b77)&&this['close']();}['onConnectionLost_'](_0x488640){this['conn_']=null,!_0x488640&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x818a3b){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x818a3b),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1e8640){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1e8640);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x3f4619,_0x5e6d73,_0x38abc1,_0x582406){}['merge'](_0x4e0705,_0x35e2b6,_0x52a1e3,_0x261fe8){}['refreshAuthToken'](_0x5a358d){}['refreshAppCheckToken'](_0x422a33){}['onDisconnectPut'](_0x58a553,_0x6fdae6,_0x53ffe8){}['onDisconnectMerge'](_0x51b485,_0x7167d2,_0x6cfd45){}['onDisconnectCancel'](_0x4936a9,_0x35b256){}['reportStats'](_0x330c6b){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x2b755d){this['allowedEvents_']=_0x2b755d,this['listeners_']={},f(Array['isArray'](_0x2b755d)&&_0x2b755d['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x21daa3,..._0x3b1a93){if(Array['isArray'](this['listeners_'][_0x21daa3])){const _0x555bef=[...this['listeners_'][_0x21daa3]];for(let _0x483f0b=0x0;_0x483f0b<_0x555bef['length'];_0x483f0b++)_0x555bef[_0x483f0b]['callback']['apply'](_0x555bef[_0x483f0b]['context'],_0x3b1a93);}}['on'](_0x5bf652,_0x4efb4e,_0x2d88e9){this['validateEventType_'](_0x5bf652),this['listeners_'][_0x5bf652]=this['listeners_'][_0x5bf652]||[],this['listeners_'][_0x5bf652]['push']({'callback':_0x4efb4e,'context':_0x2d88e9});const _0xd96000=this['getInitialEvent'](_0x5bf652);_0xd96000&&_0x4efb4e['apply'](_0x2d88e9,_0xd96000);}['off'](_0x246e6a,_0x23cc07,_0x41cd87){this['validateEventType_'](_0x246e6a);const _0x3c6ca8=this['listeners_'][_0x246e6a]||[];for(let _0x3b8e32=0x0;_0x3b8e32<_0x3c6ca8['length'];_0x3b8e32++)if(_0x3c6ca8[_0x3b8e32]['callback']===_0x23cc07&&(!_0x41cd87||_0x41cd87===_0x3c6ca8[_0x3b8e32]['context'])){_0x3c6ca8['splice'](_0x3b8e32,0x1);return;}}['validateEventType_'](_0x37e375){f(this['allowedEvents_']['find'](_0x4e9003=>_0x4e9003===_0x37e375),'Unknown\x20event:\x20'+_0x37e375);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x3f24a2){return f(_0x3f24a2==='online','Unknown\x20event\x20type:\x20'+_0x3f24a2),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x1ec2f,_0x44e955){if(_0x44e955===void 0x0){this['pieces_']=_0x1ec2f['split']('/');let _0x2a6730=0x0;for(let _0x4baac5=0x0;_0x4baac5<this['pieces_']['length'];_0x4baac5++)this['pieces_'][_0x4baac5]['length']>0x0&&(this['pieces_'][_0x2a6730]=this['pieces_'][_0x4baac5],_0x2a6730++);this['pieces_']['length']=_0x2a6730,this['pieceNum_']=0x0;}else this['pieces_']=_0x1ec2f,this['pieceNum_']=_0x44e955;}['toString'](){let _0x6d4280='';for(let _0x2b70bf=this['pieceNum_'];_0x2b70bf<this['pieces_']['length'];_0x2b70bf++)this['pieces_'][_0x2b70bf]!==''&&(_0x6d4280+='/'+this['pieces_'][_0x2b70bf]);return _0x6d4280||'/';}}function w(){return new C('');}function y(_0x3f59d2){return _0x3f59d2['pieceNum_']>=_0x3f59d2['pieces_']['length']?null:_0x3f59d2['pieces_'][_0x3f59d2['pieceNum_']];}function we(_0x30c925){return _0x30c925['pieces_']['length']-_0x30c925['pieceNum_'];}function b(_0x520589){let _0x1fec0e=_0x520589['pieceNum_'];return _0x1fec0e<_0x520589['pieces_']['length']&&_0x1fec0e++,new C(_0x520589['pieces_'],_0x1fec0e);}function Gi(_0x7cc4bd){return _0x7cc4bd['pieceNum_']<_0x7cc4bd['pieces_']['length']?_0x7cc4bd['pieces_'][_0x7cc4bd['pieces_']['length']-0x1]:null;}function Ch(_0x1dfc18){let _0x4ca3be='';for(let _0x50d3f0=_0x1dfc18['pieceNum_'];_0x50d3f0<_0x1dfc18['pieces_']['length'];_0x50d3f0++)_0x1dfc18['pieces_'][_0x50d3f0]!==''&&(_0x4ca3be+='/'+encodeURIComponent(String(_0x1dfc18['pieces_'][_0x50d3f0])));return _0x4ca3be||'/';}function kt(_0x4e9b1e,_0x2db743=0x0){return _0x4e9b1e['pieces_']['slice'](_0x4e9b1e['pieceNum_']+_0x2db743);}function To(_0x23ec3c){if(_0x23ec3c['pieceNum_']>=_0x23ec3c['pieces_']['length'])return null;const _0x242309=[];for(let _0x4be4ac=_0x23ec3c['pieceNum_'];_0x4be4ac<_0x23ec3c['pieces_']['length']-0x1;_0x4be4ac++)_0x242309['push'](_0x23ec3c['pieces_'][_0x4be4ac]);return new C(_0x242309,0x0);}function A(_0x14aef1,_0xba486c){const _0x1e07dd=[];for(let _0x7ee8a5=_0x14aef1['pieceNum_'];_0x7ee8a5<_0x14aef1['pieces_']['length'];_0x7ee8a5++)_0x1e07dd['push'](_0x14aef1['pieces_'][_0x7ee8a5]);if(_0xba486c instanceof C){for(let _0x4d81ce=_0xba486c['pieceNum_'];_0x4d81ce<_0xba486c['pieces_']['length'];_0x4d81ce++)_0x1e07dd['push'](_0xba486c['pieces_'][_0x4d81ce]);}else{const _0x951c0b=_0xba486c['split']('/');for(let _0x22c268=0x0;_0x22c268<_0x951c0b['length'];_0x22c268++)_0x951c0b[_0x22c268]['length']>0x0&&_0x1e07dd['push'](_0x951c0b[_0x22c268]);}return new C(_0x1e07dd,0x0);}function v(_0x4d608b){return _0x4d608b['pieceNum_']>=_0x4d608b['pieces_']['length'];}function F(_0x2fca90,_0x11271c){const _0x5ddc43=y(_0x2fca90),_0x58db9e=y(_0x11271c);if(_0x5ddc43===null)return _0x11271c;if(_0x5ddc43===_0x58db9e)return F(b(_0x2fca90),b(_0x11271c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x11271c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2fca90+')');}function Th(_0x57d900,_0x1c5e37){const _0x2947b7=kt(_0x57d900,0x0),_0x1e557f=kt(_0x1c5e37,0x0);for(let _0x3494ec=0x0;_0x3494ec<_0x2947b7['length']&&_0x3494ec<_0x1e557f['length'];_0x3494ec++){const _0x240592=He(_0x2947b7[_0x3494ec],_0x1e557f[_0x3494ec]);if(_0x240592!==0x0)return _0x240592;}return _0x2947b7['length']===_0x1e557f['length']?0x0:_0x2947b7['length']<_0x1e557f['length']?-0x1:0x1;}function qi(_0x2809fc,_0x3f8d72){if(we(_0x2809fc)!==we(_0x3f8d72))return!0x1;for(let _0x340539=_0x2809fc['pieceNum_'],_0x36b63d=_0x3f8d72['pieceNum_'];_0x340539<=_0x2809fc['pieces_']['length'];_0x340539++,_0x36b63d++)if(_0x2809fc['pieces_'][_0x340539]!==_0x3f8d72['pieces_'][_0x36b63d])return!0x1;return!0x0;}function $(_0x558d4a,_0x223099){let _0x9bbe8f=_0x558d4a['pieceNum_'],_0x54adae=_0x223099['pieceNum_'];if(we(_0x558d4a)>we(_0x223099))return!0x1;for(;_0x9bbe8f<_0x558d4a['pieces_']['length'];){if(_0x558d4a['pieces_'][_0x9bbe8f]!==_0x223099['pieces_'][_0x54adae])return!0x1;++_0x9bbe8f,++_0x54adae;}return!0x0;}class Sh{constructor(_0x1ca159,_0x599f74){this['errorPrefix_']=_0x599f74,this['parts_']=kt(_0x1ca159,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x44b7e4=0x0;_0x44b7e4<this['parts_']['length'];_0x44b7e4++)this['byteLength_']+=Pn(this['parts_'][_0x44b7e4]);So(this);}}function bh(_0x26386e,_0x3642c9){_0x26386e['parts_']['length']>0x0&&(_0x26386e['byteLength_']+=0x1),_0x26386e['parts_']['push'](_0x3642c9),_0x26386e['byteLength_']+=Pn(_0x3642c9),So(_0x26386e);}function Rh(_0x3c50ba){const _0x524063=_0x3c50ba['parts_']['pop']();_0x3c50ba['byteLength_']-=Pn(_0x524063),_0x3c50ba['parts_']['length']>0x0&&(_0x3c50ba['byteLength_']-=0x1);}function So(_0x4a449e){if(_0x4a449e['byteLength_']>Js)throw new Error(_0x4a449e['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x4a449e['byteLength_']+').');if(_0x4a449e['parts_']['length']>Qs)throw new Error(_0x4a449e['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x4a449e));}function Ne(_0x4ebcb1){return _0x4ebcb1['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4ebcb1['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x59ece6,_0x59b9ca;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x59b9ca='visibilitychange',_0x59ece6='hidden'):typeof document['mozHidden']<'u'?(_0x59b9ca='mozvisibilitychange',_0x59ece6='mozHidden'):typeof document['msHidden']<'u'?(_0x59b9ca='msvisibilitychange',_0x59ece6='msHidden'):typeof document['webkitHidden']<'u'&&(_0x59b9ca='webkitvisibilitychange',_0x59ece6='webkitHidden')),this['visible_']=!0x0,_0x59b9ca&&document['addEventListener'](_0x59b9ca,()=>{const _0xa7cb7a=!document[_0x59ece6];_0xa7cb7a!==this['visible_']&&(this['visible_']=_0xa7cb7a,this['trigger']('visible',_0xa7cb7a));},!0x1);}['getInitialEvent'](_0x532a56){return f(_0x532a56==='visible','Unknown\x20event\x20type:\x20'+_0x532a56),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x265275,_0xc45ab8,_0x51b341,_0x50a8a5,_0x468672,_0x3936b3,_0x262dc0,_0xd3dbf0){if(super(),this['repoInfo_']=_0x265275,this['applicationId_']=_0xc45ab8,this['onDataUpdate_']=_0x51b341,this['onConnectStatus_']=_0x50a8a5,this['onServerInfoUpdate_']=_0x468672,this['authTokenProvider_']=_0x3936b3,this['appCheckTokenProvider_']=_0x262dc0,this['authOverride_']=_0xd3dbf0,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xd3dbf0)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x265275['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x29e449,_0x12ad0a,_0x256866){const _0x476c5f=++this['requestNumber_'],_0x120c3b={'r':_0x476c5f,'a':_0x29e449,'b':_0x12ad0a};this['log_'](O(_0x120c3b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x120c3b),_0x256866&&(this['requestCBHash_'][_0x476c5f]=_0x256866);}['get'](_0x3660e5){this['initConnection_']();const _0x1166a8=new Ve(),_0x2019d5={'action':'g','request':{'p':_0x3660e5['_path']['toString'](),'q':_0x3660e5['_queryObject']},'onComplete':_0x12f80d=>{const _0xe611f4=_0x12f80d['d'];_0x12f80d['s']==='ok'?_0x1166a8['resolve'](_0xe611f4):_0x1166a8['reject'](_0xe611f4);}};this['outstandingGets_']['push'](_0x2019d5),this['outstandingGetCount_']++;const _0x25a09b=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x25a09b),_0x1166a8['promise'];}['listen'](_0x27cfea,_0xe57fe9,_0x5a25ee,_0x1318b0){this['initConnection_']();const _0x49495d=_0x27cfea['_queryIdentifier'],_0x50daa5=_0x27cfea['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x50daa5+'\x20'+_0x49495d),this['listens']['has'](_0x50daa5)||this['listens']['set'](_0x50daa5,new Map()),f(_0x27cfea['_queryParams']['isDefault']()||!_0x27cfea['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x50daa5)['has'](_0x49495d),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x12ccc={'onComplete':_0x1318b0,'hashFn':_0xe57fe9,'query':_0x27cfea,'tag':_0x5a25ee};this['listens']['get'](_0x50daa5)['set'](_0x49495d,_0x12ccc),this['connected_']&&this['sendListen_'](_0x12ccc);}['sendGet_'](_0xe494f6){const _0x132746=this['outstandingGets_'][_0xe494f6];this['sendRequest']('g',_0x132746['request'],_0x3f3a58=>{delete this['outstandingGets_'][_0xe494f6],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x132746['onComplete']&&_0x132746['onComplete'](_0x3f3a58);});}['sendListen_'](_0x11ba9c){const _0x291ca7=_0x11ba9c['query'],_0x5d342b=_0x291ca7['_path']['toString'](),_0x4f37c7=_0x291ca7['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5d342b+'\x20for\x20'+_0x4f37c7);const _0x16eb53={'p':_0x5d342b},_0x3e79b2='q';_0x11ba9c['tag']&&(_0x16eb53['q']=_0x291ca7['_queryObject'],_0x16eb53['t']=_0x11ba9c['tag']),_0x16eb53['h']=_0x11ba9c['hashFn'](),this['sendRequest'](_0x3e79b2,_0x16eb53,_0x2af0ec=>{const _0x3bd368=_0x2af0ec['d'],_0x32160f=_0x2af0ec['s'];ie['warnOnListenWarnings_'](_0x3bd368,_0x291ca7),(this['listens']['get'](_0x5d342b)&&this['listens']['get'](_0x5d342b)['get'](_0x4f37c7))===_0x11ba9c&&(this['log_']('listen\x20response',_0x2af0ec),_0x32160f!=='ok'&&this['removeListen_'](_0x5d342b,_0x4f37c7),_0x11ba9c['onComplete']&&_0x11ba9c['onComplete'](_0x32160f,_0x3bd368));});}static['warnOnListenWarnings_'](_0x23e56b,_0xa44902){if(_0x23e56b&&typeof _0x23e56b=='object'&&Y(_0x23e56b,'w')){const _0x25c33a=Oe(_0x23e56b,'w');if(Array['isArray'](_0x25c33a)&&~_0x25c33a['indexOf']('no_index')){const _0x41ce81='\x22.indexOn\x22:\x20\x22'+_0xa44902['_queryParams']['getIndex']()['toString']()+'\x22',_0x524b79=_0xa44902['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x41ce81+'\x20at\x20'+_0x524b79+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x72a8ff){this['authToken_']=_0x72a8ff,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x72a8ff);}['reduceReconnectDelayIfAdminCredential_'](_0x54d988){(_0x54d988&&_0x54d988['length']===0x28||vc(_0x54d988))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x4ffaae){this['appCheckToken_']=_0x4ffaae,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x40cb7b=this['authToken_'],_0x50c56c=yc(_0x40cb7b)?'auth':'gauth',_0x3d33dd={'cred':_0x40cb7b};this['authOverride_']===null?_0x3d33dd['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x3d33dd['authvar']=this['authOverride_']),this['sendRequest'](_0x50c56c,_0x3d33dd,_0x58b96d=>{const _0xc99d79=_0x58b96d['s'],_0x4ad491=_0x58b96d['d']||'error';this['authToken_']===_0x40cb7b&&(_0xc99d79==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0xc99d79,_0x4ad491));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3d6e3a=>{const _0x4f9390=_0x3d6e3a['s'],_0x286831=_0x3d6e3a['d']||'error';_0x4f9390==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4f9390,_0x286831);});}['unlisten'](_0x1c8aae,_0x14f6be){const _0x38c69f=_0x1c8aae['_path']['toString'](),_0x5eecd4=_0x1c8aae['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x38c69f+'\x20'+_0x5eecd4),f(_0x1c8aae['_queryParams']['isDefault']()||!_0x1c8aae['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x38c69f,_0x5eecd4)&&this['connected_']&&this['sendUnlisten_'](_0x38c69f,_0x5eecd4,_0x1c8aae['_queryObject'],_0x14f6be);}['sendUnlisten_'](_0x1b4a7d,_0x6eed43,_0x2579b8,_0x1be303){this['log_']('Unlisten\x20on\x20'+_0x1b4a7d+'\x20for\x20'+_0x6eed43);const _0x45c9c7={'p':_0x1b4a7d},_0x109986='n';_0x1be303&&(_0x45c9c7['q']=_0x2579b8,_0x45c9c7['t']=_0x1be303),this['sendRequest'](_0x109986,_0x45c9c7);}['onDisconnectPut'](_0x5347cb,_0x493805,_0x523918){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5347cb,_0x493805,_0x523918):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5347cb,'action':'o','data':_0x493805,'onComplete':_0x523918});}['onDisconnectMerge'](_0x5f58ba,_0x404420,_0x397dd4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x5f58ba,_0x404420,_0x397dd4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5f58ba,'action':'om','data':_0x404420,'onComplete':_0x397dd4});}['onDisconnectCancel'](_0x4507ca,_0x19e4a4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x4507ca,null,_0x19e4a4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4507ca,'action':'oc','data':null,'onComplete':_0x19e4a4});}['sendOnDisconnect_'](_0xcb9f81,_0xee6d63,_0x25dbb1,_0x4745e5){const _0x1f2dd3={'p':_0xee6d63,'d':_0x25dbb1};this['log_']('onDisconnect\x20'+_0xcb9f81,_0x1f2dd3),this['sendRequest'](_0xcb9f81,_0x1f2dd3,_0xec67a5=>{_0x4745e5&&setTimeout(()=>{_0x4745e5(_0xec67a5['s'],_0xec67a5['d']);},Math['floor'](0x0));});}['put'](_0x3e07ef,_0x205058,_0xa9b001,_0x17ae03){this['putInternal']('p',_0x3e07ef,_0x205058,_0xa9b001,_0x17ae03);}['merge'](_0x489b5c,_0x20958a,_0x2b0469,_0x2d9519){this['putInternal']('m',_0x489b5c,_0x20958a,_0x2b0469,_0x2d9519);}['putInternal'](_0x2748ec,_0x597fad,_0x39038b,_0xecd1d6,_0x2e3344){this['initConnection_']();const _0x3ac4d9={'p':_0x597fad,'d':_0x39038b};_0x2e3344!==void 0x0&&(_0x3ac4d9['h']=_0x2e3344),this['outstandingPuts_']['push']({'action':_0x2748ec,'request':_0x3ac4d9,'onComplete':_0xecd1d6}),this['outstandingPutCount_']++;const _0x5ce841=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x5ce841):this['log_']('Buffering\x20put:\x20'+_0x597fad);}['sendPut_'](_0x18e89a){const _0x40e44a=this['outstandingPuts_'][_0x18e89a]['action'],_0x11cb70=this['outstandingPuts_'][_0x18e89a]['request'],_0x4262ba=this['outstandingPuts_'][_0x18e89a]['onComplete'];this['outstandingPuts_'][_0x18e89a]['queued']=this['connected_'],this['sendRequest'](_0x40e44a,_0x11cb70,_0x24febc=>{this['log_'](_0x40e44a+'\x20response',_0x24febc),delete this['outstandingPuts_'][_0x18e89a],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x4262ba&&_0x4262ba(_0x24febc['s'],_0x24febc['d']);});}['reportStats'](_0x64c4a0){if(this['connected_']){const _0x535b9b={'c':_0x64c4a0};this['log_']('reportStats',_0x535b9b),this['sendRequest']('s',_0x535b9b,_0x46b68d=>{if(_0x46b68d['s']!=='ok'){const _0x458f4b=_0x46b68d['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x458f4b);}});}}['onDataMessage_'](_0x2eaf82){if('r'in _0x2eaf82){this['log_']('from\x20server:\x20'+O(_0x2eaf82));const _0x2014ff=_0x2eaf82['r'],_0x5d3cbd=this['requestCBHash_'][_0x2014ff];_0x5d3cbd&&(delete this['requestCBHash_'][_0x2014ff],_0x5d3cbd(_0x2eaf82['b']));}else{if('error'in _0x2eaf82)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2eaf82['error'];'a'in _0x2eaf82&&this['onDataPush_'](_0x2eaf82['a'],_0x2eaf82['b']);}}['onDataPush_'](_0xd6eab3,_0x5bf013){this['log_']('handleServerMessage',_0xd6eab3,_0x5bf013),_0xd6eab3==='d'?this['onDataUpdate_'](_0x5bf013['p'],_0x5bf013['d'],!0x1,_0x5bf013['t']):_0xd6eab3==='m'?this['onDataUpdate_'](_0x5bf013['p'],_0x5bf013['d'],!0x0,_0x5bf013['t']):_0xd6eab3==='c'?this['onListenRevoked_'](_0x5bf013['p'],_0x5bf013['q']):_0xd6eab3==='ac'?this['onAuthRevoked_'](_0x5bf013['s'],_0x5bf013['d']):_0xd6eab3==='apc'?this['onAppCheckRevoked_'](_0x5bf013['s'],_0x5bf013['d']):_0xd6eab3==='sd'?this['onSecurityDebugPacket_'](_0x5bf013):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0xd6eab3)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4c7a56,_0x484c50){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4c7a56),this['lastSessionId']=_0x484c50,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x38bc81){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x38bc81));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5f5a86){_0x5f5a86&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5f5a86;}['onOnline_'](_0x47515f){_0x47515f?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3c478f=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x13145a=Math['max'](0x0,this['reconnectDelay_']-_0x3c478f);_0x13145a=Math['random']()*_0x13145a,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x13145a+'ms'),this['scheduleConnect_'](_0x13145a),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x52ff7d=this['onDataMessage_']['bind'](this),_0x52f386=this['onReady_']['bind'](this),_0x39cbc5=this['onRealtimeDisconnect_']['bind'](this),_0x216c05=this['id']+':'+ie['nextConnectionId_']++,_0x2089de=this['lastSessionId'];let _0xf709bb=!0x1,_0x23ac5b=null;const _0x3c5c53=function(){_0x23ac5b?_0x23ac5b['close']():(_0xf709bb=!0x0,_0x39cbc5());},_0x2bc2e8=function(_0x15fcd5){f(_0x23ac5b,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x23ac5b['sendRequest'](_0x15fcd5);};this['realtime_']={'close':_0x3c5c53,'sendRequest':_0x2bc2e8};const _0x19c24d=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2c6465,_0x4749c7]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x19c24d),this['appCheckTokenProvider_']['getToken'](_0x19c24d)]);_0xf709bb?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2c6465&&_0x2c6465['accessToken'],this['appCheckToken_']=_0x4749c7&&_0x4749c7['token'],_0x23ac5b=new wh(_0x216c05,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x52ff7d,_0x52f386,_0x39cbc5,_0x33e04f=>{U(_0x33e04f+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x2089de));}catch(_0x3fc4a4){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3fc4a4),_0xf709bb||(this['repoInfo_']['nodeAdmin']&&U(_0x3fc4a4),_0x3c5c53());}}}['interrupt'](_0x3c5494){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3c5494),this['interruptReasons_'][_0x3c5494]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x29681b){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x29681b),delete this['interruptReasons_'][_0x29681b],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1892cd){const _0x51e19b=_0x1892cd-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x51e19b});}['cancelSentTransactions_'](){for(let _0x1323cf=0x0;_0x1323cf<this['outstandingPuts_']['length'];_0x1323cf++){const _0x282cd6=this['outstandingPuts_'][_0x1323cf];_0x282cd6&&'h'in _0x282cd6['request']&&_0x282cd6['queued']&&(_0x282cd6['onComplete']&&_0x282cd6['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1323cf],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2982b7,_0xf32a3c){let _0x39087b;_0xf32a3c?_0x39087b=_0xf32a3c['map'](_0x255423=>Bi(_0x255423))['join']('$'):_0x39087b='default';const _0x175aa2=this['removeListen_'](_0x2982b7,_0x39087b);_0x175aa2&&_0x175aa2['onComplete']&&_0x175aa2['onComplete']('permission_denied');}['removeListen_'](_0x4d7415,_0x459744){const _0x4cef4f=new C(_0x4d7415)['toString']();let _0x742c29;if(this['listens']['has'](_0x4cef4f)){const _0x3295bc=this['listens']['get'](_0x4cef4f);_0x742c29=_0x3295bc['get'](_0x459744),_0x3295bc['delete'](_0x459744),_0x3295bc['size']===0x0&&this['listens']['delete'](_0x4cef4f);}else _0x742c29=void 0x0;return _0x742c29;}['onAuthRevoked_'](_0x4df1b6,_0x465ce3){L('Auth\x20token\x20revoked:\x20'+_0x4df1b6+'/'+_0x465ce3),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x4df1b6==='invalid_token'||_0x4df1b6==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x311bef,_0x72ce04){L('App\x20check\x20token\x20revoked:\x20'+_0x311bef+'/'+_0x72ce04),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x311bef==='invalid_token'||_0x311bef==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x3f6b2a){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x3f6b2a):'msg'in _0x3f6b2a&&console['log']('FIREBASE:\x20'+_0x3f6b2a['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4cef00 of this['listens']['values']())for(const _0x6ee36d of _0x4cef00['values']())this['sendListen_'](_0x6ee36d);for(let _0x1d2341=0x0;_0x1d2341<this['outstandingPuts_']['length'];_0x1d2341++)this['outstandingPuts_'][_0x1d2341]&&this['sendPut_'](_0x1d2341);for(;this['onDisconnectRequestQueue_']['length'];){const _0x25d23e=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x25d23e['action'],_0x25d23e['pathString'],_0x25d23e['data'],_0x25d23e['onComplete']);}for(let _0x13f644=0x0;_0x13f644<this['outstandingGets_']['length'];_0x13f644++)this['outstandingGets_'][_0x13f644]&&this['sendGet_'](_0x13f644);}['sendConnectStats_'](){const _0x285872={};let _0xd7ae9b='js';_0x285872['sdk.'+_0xd7ae9b+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x285872['framework.cordova']=0x1:qr()&&(_0x285872['framework.reactnative']=0x1),this['reportStats'](_0x285872);}['shouldReconnect_'](){const _0x5248eb=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x5248eb;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x69f2ce,_0x45dc19){this['name']=_0x69f2ce,this['node']=_0x45dc19;}static['Wrap'](_0x535b3b,_0x4e84b8){return new E(_0x535b3b,_0x4e84b8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xd2fb9c,_0x50cc25){const _0x38f0db=new E(xe,_0xd2fb9c),_0x253213=new E(xe,_0x50cc25);return this['compare'](_0x38f0db,_0x253213)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x2cef7f){Xt=_0x2cef7f;}['compare'](_0x4ce52b,_0x852515){return He(_0x4ce52b['name'],_0x852515['name']);}['isDefinedOn'](_0x49f796){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0xe000c6,_0x39092f){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x4b2481,_0x2c2ee3){return f(typeof _0x4b2481=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4b2481,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2233ec,_0x42a8e0,_0x444f27,_0x3160fe,_0x147bed=null){this['isReverse_']=_0x3160fe,this['resultGenerator_']=_0x147bed,this['nodeStack_']=[];let _0x5702a6=0x1;for(;!_0x2233ec['isEmpty']();)if(_0x2233ec=_0x2233ec,_0x5702a6=_0x42a8e0?_0x444f27(_0x2233ec['key'],_0x42a8e0):0x1,_0x3160fe&&(_0x5702a6*=-0x1),_0x5702a6<0x0)this['isReverse_']?_0x2233ec=_0x2233ec['left']:_0x2233ec=_0x2233ec['right'];else{if(_0x5702a6===0x0){this['nodeStack_']['push'](_0x2233ec);break;}else this['nodeStack_']['push'](_0x2233ec),this['isReverse_']?_0x2233ec=_0x2233ec['right']:_0x2233ec=_0x2233ec['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x57e170=this['nodeStack_']['pop'](),_0x3337f9;if(this['resultGenerator_']?_0x3337f9=this['resultGenerator_'](_0x57e170['key'],_0x57e170['value']):_0x3337f9={'key':_0x57e170['key'],'value':_0x57e170['value']},this['isReverse_']){for(_0x57e170=_0x57e170['left'];!_0x57e170['isEmpty']();)this['nodeStack_']['push'](_0x57e170),_0x57e170=_0x57e170['right'];}else{for(_0x57e170=_0x57e170['right'];!_0x57e170['isEmpty']();)this['nodeStack_']['push'](_0x57e170),_0x57e170=_0x57e170['left'];}return _0x3337f9;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x3a05b7=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x3a05b7['key'],_0x3a05b7['value']):{'key':_0x3a05b7['key'],'value':_0x3a05b7['value']};}}class M{constructor(_0x41ac32,_0xbd3b42,_0x41ec41,_0x797923,_0x42e8d2){this['key']=_0x41ac32,this['value']=_0xbd3b42,this['color']=_0x41ec41??M['RED'],this['left']=_0x797923??B['EMPTY_NODE'],this['right']=_0x42e8d2??B['EMPTY_NODE'];}['copy'](_0x3343ec,_0x12173d,_0x23f798,_0x161dde,_0x108260){return new M(_0x3343ec??this['key'],_0x12173d??this['value'],_0x23f798??this['color'],_0x161dde??this['left'],_0x108260??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x5cd42c){return this['left']['inorderTraversal'](_0x5cd42c)||!!_0x5cd42c(this['key'],this['value'])||this['right']['inorderTraversal'](_0x5cd42c);}['reverseTraversal'](_0x590ca6){return this['right']['reverseTraversal'](_0x590ca6)||_0x590ca6(this['key'],this['value'])||this['left']['reverseTraversal'](_0x590ca6);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2630ed,_0x26d118,_0x2b7125){let _0x3a53b9=this;const _0x2062b5=_0x2b7125(_0x2630ed,_0x3a53b9['key']);return _0x2062b5<0x0?_0x3a53b9=_0x3a53b9['copy'](null,null,null,_0x3a53b9['left']['insert'](_0x2630ed,_0x26d118,_0x2b7125),null):_0x2062b5===0x0?_0x3a53b9=_0x3a53b9['copy'](null,_0x26d118,null,null,null):_0x3a53b9=_0x3a53b9['copy'](null,null,null,null,_0x3a53b9['right']['insert'](_0x2630ed,_0x26d118,_0x2b7125)),_0x3a53b9['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x196a34=this;return!_0x196a34['left']['isRed_']()&&!_0x196a34['left']['left']['isRed_']()&&(_0x196a34=_0x196a34['moveRedLeft_']()),_0x196a34=_0x196a34['copy'](null,null,null,_0x196a34['left']['removeMin_'](),null),_0x196a34['fixUp_']();}['remove'](_0x59c5dc,_0x156295){let _0x4d3d94,_0x120e18;if(_0x4d3d94=this,_0x156295(_0x59c5dc,_0x4d3d94['key'])<0x0)!_0x4d3d94['left']['isEmpty']()&&!_0x4d3d94['left']['isRed_']()&&!_0x4d3d94['left']['left']['isRed_']()&&(_0x4d3d94=_0x4d3d94['moveRedLeft_']()),_0x4d3d94=_0x4d3d94['copy'](null,null,null,_0x4d3d94['left']['remove'](_0x59c5dc,_0x156295),null);else{if(_0x4d3d94['left']['isRed_']()&&(_0x4d3d94=_0x4d3d94['rotateRight_']()),!_0x4d3d94['right']['isEmpty']()&&!_0x4d3d94['right']['isRed_']()&&!_0x4d3d94['right']['left']['isRed_']()&&(_0x4d3d94=_0x4d3d94['moveRedRight_']()),_0x156295(_0x59c5dc,_0x4d3d94['key'])===0x0){if(_0x4d3d94['right']['isEmpty']())return B['EMPTY_NODE'];_0x120e18=_0x4d3d94['right']['min_'](),_0x4d3d94=_0x4d3d94['copy'](_0x120e18['key'],_0x120e18['value'],null,null,_0x4d3d94['right']['removeMin_']());}_0x4d3d94=_0x4d3d94['copy'](null,null,null,null,_0x4d3d94['right']['remove'](_0x59c5dc,_0x156295));}return _0x4d3d94['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2220f9=this;return _0x2220f9['right']['isRed_']()&&!_0x2220f9['left']['isRed_']()&&(_0x2220f9=_0x2220f9['rotateLeft_']()),_0x2220f9['left']['isRed_']()&&_0x2220f9['left']['left']['isRed_']()&&(_0x2220f9=_0x2220f9['rotateRight_']()),_0x2220f9['left']['isRed_']()&&_0x2220f9['right']['isRed_']()&&(_0x2220f9=_0x2220f9['colorFlip_']()),_0x2220f9;}['moveRedLeft_'](){let _0x1641a1=this['colorFlip_']();return _0x1641a1['right']['left']['isRed_']()&&(_0x1641a1=_0x1641a1['copy'](null,null,null,null,_0x1641a1['right']['rotateRight_']()),_0x1641a1=_0x1641a1['rotateLeft_'](),_0x1641a1=_0x1641a1['colorFlip_']()),_0x1641a1;}['moveRedRight_'](){let _0x11ab20=this['colorFlip_']();return _0x11ab20['left']['left']['isRed_']()&&(_0x11ab20=_0x11ab20['rotateRight_'](),_0x11ab20=_0x11ab20['colorFlip_']()),_0x11ab20;}['rotateLeft_'](){const _0x560b27=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x560b27,null);}['rotateRight_'](){const _0x4c0eb5=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4c0eb5);}['colorFlip_'](){const _0x42b97d=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xdbf610=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x42b97d,_0xdbf610);}['checkMaxDepth_'](){const _0x348ef8=this['check_']();return Math['pow'](0x2,_0x348ef8)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x32f616=this['left']['check_']();if(_0x32f616!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x32f616+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x51860a,_0x172797,_0x5c3963,_0x116ce5,_0x5c906f){return this;}['insert'](_0x250de0,_0x4488d3,_0x16f3ac){return new M(_0x250de0,_0x4488d3,null);}['remove'](_0x16041c,_0x53cedd){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x465355){return!0x1;}['reverseTraversal'](_0xae8d90){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x15e9d4,_0x5b0bd5=B['EMPTY_NODE']){this['comparator_']=_0x15e9d4,this['root_']=_0x5b0bd5;}['insert'](_0xabac25,_0x4a17f2){return new B(this['comparator_'],this['root_']['insert'](_0xabac25,_0x4a17f2,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x163622){return new B(this['comparator_'],this['root_']['remove'](_0x163622,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x24245b){let _0x1b4ca2,_0x375761=this['root_'];for(;!_0x375761['isEmpty']();){if(_0x1b4ca2=this['comparator_'](_0x24245b,_0x375761['key']),_0x1b4ca2===0x0)return _0x375761['value'];_0x1b4ca2<0x0?_0x375761=_0x375761['left']:_0x1b4ca2>0x0&&(_0x375761=_0x375761['right']);}return null;}['getPredecessorKey'](_0x1cc692){let _0x3bd07e,_0x1f5ff4=this['root_'],_0x41ac18=null;for(;!_0x1f5ff4['isEmpty']();)if(_0x3bd07e=this['comparator_'](_0x1cc692,_0x1f5ff4['key']),_0x3bd07e===0x0){if(_0x1f5ff4['left']['isEmpty']())return _0x41ac18?_0x41ac18['key']:null;for(_0x1f5ff4=_0x1f5ff4['left'];!_0x1f5ff4['right']['isEmpty']();)_0x1f5ff4=_0x1f5ff4['right'];return _0x1f5ff4['key'];}else _0x3bd07e<0x0?_0x1f5ff4=_0x1f5ff4['left']:_0x3bd07e>0x0&&(_0x41ac18=_0x1f5ff4,_0x1f5ff4=_0x1f5ff4['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x437ef7){return this['root_']['inorderTraversal'](_0x437ef7);}['reverseTraversal'](_0x574cbb){return this['root_']['reverseTraversal'](_0x574cbb);}['getIterator'](_0x17120b){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x17120b);}['getIteratorFrom'](_0x18eec8,_0x25a4c7){return new Zt(this['root_'],_0x18eec8,this['comparator_'],!0x1,_0x25a4c7);}['getReverseIteratorFrom'](_0x2bc5e8,_0x36e0f7){return new Zt(this['root_'],_0x2bc5e8,this['comparator_'],!0x0,_0x36e0f7);}['getReverseIterator'](_0x1bf7e2){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x1bf7e2);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x53b24f,_0x5086e0){return He(_0x53b24f['name'],_0x5086e0['name']);}function ji(_0x214382,_0x313dd4){return He(_0x214382,_0x313dd4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x251199){vi=_0x251199;}const Ro=function(_0x45b88a){return typeof _0x45b88a=='number'?'number:'+so(_0x45b88a):'string:'+_0x45b88a;},Ao=function(_0x1f0a4c){if(_0x1f0a4c['isLeafNode']()){const _0x25fdd4=_0x1f0a4c['val']();f(typeof _0x25fdd4=='string'||typeof _0x25fdd4=='number'||typeof _0x25fdd4=='object'&&Y(_0x25fdd4,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x1f0a4c===vi||_0x1f0a4c['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x1f0a4c===vi||_0x1f0a4c['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x168bd7){er=_0x168bd7;}static get['__childrenNodeConstructor'](){return er;}constructor(_0xa4bcba,_0x3d203e=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xa4bcba,this['priorityNode_']=_0x3d203e,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1fd7f6){return new D(this['value_'],_0x1fd7f6);}['getImmediateChild'](_0x12378c){return _0x12378c==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x20a339){return v(_0x20a339)?this:y(_0x20a339)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x39de1d,_0xf45831){return null;}['updateImmediateChild'](_0x22bfbf,_0x4e3702){return _0x22bfbf==='.priority'?this['updatePriority'](_0x4e3702):_0x4e3702['isEmpty']()&&_0x22bfbf!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x22bfbf,_0x4e3702)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x59e9e7,_0x8add34){const _0x24ecd0=y(_0x59e9e7);return _0x24ecd0===null?_0x8add34:_0x8add34['isEmpty']()&&_0x24ecd0!=='.priority'?this:(f(_0x24ecd0!=='.priority'||we(_0x59e9e7)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x24ecd0,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x59e9e7),_0x8add34)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x446972,_0x1ae901){return!0x1;}['val'](_0x4282f6){return _0x4282f6&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xb6d2f9='';this['priorityNode_']['isEmpty']()||(_0xb6d2f9+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x1bb2d2=typeof this['value_'];_0xb6d2f9+=_0x1bb2d2+':',_0x1bb2d2==='number'?_0xb6d2f9+=so(this['value_']):_0xb6d2f9+=this['value_'],this['lazyHash_']=no(_0xb6d2f9);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x58d707){return _0x58d707===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x58d707 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x58d707['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x58d707));}['compareToLeafNode_'](_0x40e518){const _0x6cc762=typeof _0x40e518['value_'],_0x2b2e83=typeof this['value_'],_0x4aa08b=D['VALUE_TYPE_ORDER']['indexOf'](_0x6cc762),_0x2da994=D['VALUE_TYPE_ORDER']['indexOf'](_0x2b2e83);return f(_0x4aa08b>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x6cc762),f(_0x2da994>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2b2e83),_0x4aa08b===_0x2da994?_0x2b2e83==='object'?0x0:this['value_']<_0x40e518['value_']?-0x1:this['value_']===_0x40e518['value_']?0x0:0x1:_0x2da994-_0x4aa08b;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2ead4e){if(_0x2ead4e===this)return!0x0;if(_0x2ead4e['isLeafNode']()){const _0x78c192=_0x2ead4e;return this['value_']===_0x78c192['value_']&&this['priorityNode_']['equals'](_0x78c192['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x2a119e){ko=_0x2a119e;}function xh(_0x251b2c){No=_0x251b2c;}class Fh extends On{['compare'](_0x407d9d,_0xf84353){const _0x232e3d=_0x407d9d['node']['getPriority'](),_0x4d0198=_0xf84353['node']['getPriority'](),_0x4eb09d=_0x232e3d['compareTo'](_0x4d0198);return _0x4eb09d===0x0?He(_0x407d9d['name'],_0xf84353['name']):_0x4eb09d;}['isDefinedOn'](_0x4c7246){return!_0x4c7246['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x46255a,_0x7a46df){return!_0x46255a['getPriority']()['equals'](_0x7a46df['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x4b6d41,_0x1c03fa){const _0xd824f5=ko(_0x4b6d41);return new E(_0x1c03fa,new D('[PRIORITY-POST]',_0xd824f5));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x3e4e7a){const _0x29d226=_0x1f59a6=>parseInt(Math['log'](_0x1f59a6)/Uh,0xa),_0x557f35=_0x901cc4=>parseInt(Array(_0x901cc4+0x1)['join']('1'),0x2);this['count']=_0x29d226(_0x3e4e7a+0x1),this['current_']=this['count']-0x1;const _0x423fd0=_0x557f35(this['count']);this['bits_']=_0x3e4e7a+0x1&_0x423fd0;}['nextBitIsOne'](){const _0x1e4337=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x1e4337;}}const dn=function(_0x5a6d29,_0x41c60d,_0x56db45,_0x2f3504){_0x5a6d29['sort'](_0x41c60d);const _0x3fac05=function(_0x5419aa,_0x251e07){const _0x147e15=_0x251e07-_0x5419aa;let _0x3824d3,_0x4cda3d;if(_0x147e15===0x0)return null;if(_0x147e15===0x1)return _0x3824d3=_0x5a6d29[_0x5419aa],_0x4cda3d=_0x56db45?_0x56db45(_0x3824d3):_0x3824d3,new M(_0x4cda3d,_0x3824d3['node'],M['BLACK'],null,null);{const _0x1fa7ec=parseInt(_0x147e15/0x2,0xa)+_0x5419aa,_0x443e14=_0x3fac05(_0x5419aa,_0x1fa7ec),_0x2b16c3=_0x3fac05(_0x1fa7ec+0x1,_0x251e07);return _0x3824d3=_0x5a6d29[_0x1fa7ec],_0x4cda3d=_0x56db45?_0x56db45(_0x3824d3):_0x3824d3,new M(_0x4cda3d,_0x3824d3['node'],M['BLACK'],_0x443e14,_0x2b16c3);}},_0x2eb158=function(_0x5a65cb){let _0x3ad594=null,_0x3e49aa=null,_0x340f71=_0x5a6d29['length'];const _0x10c102=function(_0x3a967b,_0x74b84a){const _0x5b1436=_0x340f71-_0x3a967b,_0x204d4e=_0x340f71;_0x340f71-=_0x3a967b;const _0x1d1eaa=_0x3fac05(_0x5b1436+0x1,_0x204d4e),_0x66f77=_0x5a6d29[_0x5b1436],_0x66216f=_0x56db45?_0x56db45(_0x66f77):_0x66f77;_0x3f9668(new M(_0x66216f,_0x66f77['node'],_0x74b84a,null,_0x1d1eaa));},_0x3f9668=function(_0x111ab0){_0x3ad594?(_0x3ad594['left']=_0x111ab0,_0x3ad594=_0x111ab0):(_0x3e49aa=_0x111ab0,_0x3ad594=_0x111ab0);};for(let _0x453c48=0x0;_0x453c48<_0x5a65cb['count'];++_0x453c48){const _0x332271=_0x5a65cb['nextBitIsOne'](),_0x27c247=Math['pow'](0x2,_0x5a65cb['count']-(_0x453c48+0x1));_0x332271?_0x10c102(_0x27c247,M['BLACK']):(_0x10c102(_0x27c247,M['BLACK']),_0x10c102(_0x27c247,M['RED']));}return _0x3e49aa;},_0x48b0c4=new Wh(_0x5a6d29['length']),_0x2ebea0=_0x2eb158(_0x48b0c4);return new B(_0x2f3504||_0x41c60d,_0x2ebea0);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x2c1001,_0x1ad0bb){this['indexes_']=_0x2c1001,this['indexSet_']=_0x1ad0bb;}['get'](_0x327869){const _0x889b26=Oe(this['indexes_'],_0x327869);if(!_0x889b26)throw new Error('No\x20index\x20defined\x20for\x20'+_0x327869);return _0x889b26 instanceof B?_0x889b26:null;}['hasIndex'](_0x3c4b4d){return Y(this['indexSet_'],_0x3c4b4d['toString']());}['addIndex'](_0x14eed8,_0x2674ca){f(_0x14eed8!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x17bc1b=[];let _0x2703fd=!0x1;const _0x155d1d=_0x2674ca['getIterator'](E['Wrap']);let _0x3cebed=_0x155d1d['getNext']();for(;_0x3cebed;)_0x2703fd=_0x2703fd||_0x14eed8['isDefinedOn'](_0x3cebed['node']),_0x17bc1b['push'](_0x3cebed),_0x3cebed=_0x155d1d['getNext']();let _0xfc66c5;_0x2703fd?_0xfc66c5=dn(_0x17bc1b,_0x14eed8['getCompare']()):_0xfc66c5=je;const _0x2a340a=_0x14eed8['toString'](),_0x26c590={...this['indexSet_']};_0x26c590[_0x2a340a]=_0x14eed8;const _0x3cc2fd={...this['indexes_']};return _0x3cc2fd[_0x2a340a]=_0xfc66c5,new ee(_0x3cc2fd,_0x26c590);}['addToIndexes'](_0x45e648,_0x3547e3){const _0x272f14=ln(this['indexes_'],(_0x56e8ab,_0x417bdd)=>{const _0x15c705=Oe(this['indexSet_'],_0x417bdd);if(f(_0x15c705,'Missing\x20index\x20implementation\x20for\x20'+_0x417bdd),_0x56e8ab===je){if(_0x15c705['isDefinedOn'](_0x45e648['node'])){const _0x4e5b23=[],_0x9078ba=_0x3547e3['getIterator'](E['Wrap']);let _0x58e54b=_0x9078ba['getNext']();for(;_0x58e54b;)_0x58e54b['name']!==_0x45e648['name']&&_0x4e5b23['push'](_0x58e54b),_0x58e54b=_0x9078ba['getNext']();return _0x4e5b23['push'](_0x45e648),dn(_0x4e5b23,_0x15c705['getCompare']());}else return je;}else{const _0x452399=_0x3547e3['get'](_0x45e648['name']);let _0x4982ab=_0x56e8ab;return _0x452399&&(_0x4982ab=_0x4982ab['remove'](new E(_0x45e648['name'],_0x452399))),_0x4982ab['insert'](_0x45e648,_0x45e648['node']);}});return new ee(_0x272f14,this['indexSet_']);}['removeFromIndexes'](_0x931014,_0x1c8432){const _0x5d17d3=ln(this['indexes_'],_0x53273e=>{if(_0x53273e===je)return _0x53273e;{const _0x482a40=_0x1c8432['get'](_0x931014['name']);return _0x482a40?_0x53273e['remove'](new E(_0x931014['name'],_0x482a40)):_0x53273e;}});return new ee(_0x5d17d3,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x543a50,_0x4b0de5,_0x938930){this['children_']=_0x543a50,this['priorityNode_']=_0x4b0de5,this['indexMap_']=_0x938930,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x3d4bde){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x3d4bde,this['indexMap_']);}['getImmediateChild'](_0x15f688){if(_0x15f688==='.priority')return this['getPriority']();{const _0x26ea6b=this['children_']['get'](_0x15f688);return _0x26ea6b===null?gt:_0x26ea6b;}}['getChild'](_0x2409c3){const _0x5c7219=y(_0x2409c3);return _0x5c7219===null?this:this['getImmediateChild'](_0x5c7219)['getChild'](b(_0x2409c3));}['hasChild'](_0x805109){return this['children_']['get'](_0x805109)!==null;}['updateImmediateChild'](_0x4725e6,_0x256f74){if(f(_0x256f74,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4725e6==='.priority')return this['updatePriority'](_0x256f74);{const _0xb303db=new E(_0x4725e6,_0x256f74);let _0x5eea6c,_0xc748f3;_0x256f74['isEmpty']()?(_0x5eea6c=this['children_']['remove'](_0x4725e6),_0xc748f3=this['indexMap_']['removeFromIndexes'](_0xb303db,this['children_'])):(_0x5eea6c=this['children_']['insert'](_0x4725e6,_0x256f74),_0xc748f3=this['indexMap_']['addToIndexes'](_0xb303db,this['children_']));const _0x368f89=_0x5eea6c['isEmpty']()?gt:this['priorityNode_'];return new g(_0x5eea6c,_0x368f89,_0xc748f3);}}['updateChild'](_0x157489,_0x56bb61){const _0x3ace9e=y(_0x157489);if(_0x3ace9e===null)return _0x56bb61;{f(y(_0x157489)!=='.priority'||we(_0x157489)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5ce3dd=this['getImmediateChild'](_0x3ace9e)['updateChild'](b(_0x157489),_0x56bb61);return this['updateImmediateChild'](_0x3ace9e,_0x5ce3dd);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x47e6b4){if(this['isEmpty']())return null;const _0x17c7e2={};let _0x7d2f2f=0x0,_0x15e8ec=0x0,_0x5510b1=!0x0;if(this['forEachChild'](R,(_0x104ad5,_0x3b0af7)=>{_0x17c7e2[_0x104ad5]=_0x3b0af7['val'](_0x47e6b4),_0x7d2f2f++,_0x5510b1&&g['INTEGER_REGEXP_']['test'](_0x104ad5)?_0x15e8ec=Math['max'](_0x15e8ec,Number(_0x104ad5)):_0x5510b1=!0x1;}),!_0x47e6b4&&_0x5510b1&&_0x15e8ec<0x2*_0x7d2f2f){const _0x3adbe3=[];for(const _0x28c781 in _0x17c7e2)_0x3adbe3[_0x28c781]=_0x17c7e2[_0x28c781];return _0x3adbe3;}else return _0x47e6b4&&!this['getPriority']()['isEmpty']()&&(_0x17c7e2['.priority']=this['getPriority']()['val']()),_0x17c7e2;}['hash'](){if(this['lazyHash_']===null){let _0x48ec51='';this['getPriority']()['isEmpty']()||(_0x48ec51+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x392f98,_0xfd20d6)=>{const _0x161f76=_0xfd20d6['hash']();_0x161f76!==''&&(_0x48ec51+=':'+_0x392f98+':'+_0x161f76);}),this['lazyHash_']=_0x48ec51===''?'':no(_0x48ec51);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1254dc,_0x5746cf,_0x660400){const _0x23319d=this['resolveIndex_'](_0x660400);if(_0x23319d){const _0x519145=_0x23319d['getPredecessorKey'](new E(_0x1254dc,_0x5746cf));return _0x519145?_0x519145['name']:null;}else return this['children_']['getPredecessorKey'](_0x1254dc);}['getFirstChildName'](_0x20638b){const _0x455abb=this['resolveIndex_'](_0x20638b);if(_0x455abb){const _0x4e5007=_0x455abb['minKey']();return _0x4e5007&&_0x4e5007['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1d4ad5){const _0x482762=this['getFirstChildName'](_0x1d4ad5);return _0x482762?new E(_0x482762,this['children_']['get'](_0x482762)):null;}['getLastChildName'](_0x4313db){const _0x52c540=this['resolveIndex_'](_0x4313db);if(_0x52c540){const _0x36d3db=_0x52c540['maxKey']();return _0x36d3db&&_0x36d3db['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5b769a){const _0x428f80=this['getLastChildName'](_0x5b769a);return _0x428f80?new E(_0x428f80,this['children_']['get'](_0x428f80)):null;}['forEachChild'](_0x54fcee,_0x2f7ce0){const _0x274a60=this['resolveIndex_'](_0x54fcee);return _0x274a60?_0x274a60['inorderTraversal'](_0x561569=>_0x2f7ce0(_0x561569['name'],_0x561569['node'])):this['children_']['inorderTraversal'](_0x2f7ce0);}['getIterator'](_0x1dcd96){return this['getIteratorFrom'](_0x1dcd96['minPost'](),_0x1dcd96);}['getIteratorFrom'](_0x515d48,_0x2e5772){const _0x55c837=this['resolveIndex_'](_0x2e5772);if(_0x55c837)return _0x55c837['getIteratorFrom'](_0x515d48,_0x315c2c=>_0x315c2c);{const _0x4847cf=this['children_']['getIteratorFrom'](_0x515d48['name'],E['Wrap']);let _0x261268=_0x4847cf['peek']();for(;_0x261268!=null&&_0x2e5772['compare'](_0x261268,_0x515d48)<0x0;)_0x4847cf['getNext'](),_0x261268=_0x4847cf['peek']();return _0x4847cf;}}['getReverseIterator'](_0x5cf7dd){return this['getReverseIteratorFrom'](_0x5cf7dd['maxPost'](),_0x5cf7dd);}['getReverseIteratorFrom'](_0xc87677,_0x412610){const _0x371348=this['resolveIndex_'](_0x412610);if(_0x371348)return _0x371348['getReverseIteratorFrom'](_0xc87677,_0x4b4473=>_0x4b4473);{const _0x14ff83=this['children_']['getReverseIteratorFrom'](_0xc87677['name'],E['Wrap']);let _0xed593c=_0x14ff83['peek']();for(;_0xed593c!=null&&_0x412610['compare'](_0xed593c,_0xc87677)>0x0;)_0x14ff83['getNext'](),_0xed593c=_0x14ff83['peek']();return _0x14ff83;}}['compareTo'](_0x2ced8d){return this['isEmpty']()?_0x2ced8d['isEmpty']()?0x0:-0x1:_0x2ced8d['isLeafNode']()||_0x2ced8d['isEmpty']()?0x1:_0x2ced8d===Ht?-0x1:0x0;}['withIndex'](_0x1bc6af){if(_0x1bc6af===ye||this['indexMap_']['hasIndex'](_0x1bc6af))return this;{const _0x3b4d4d=this['indexMap_']['addIndex'](_0x1bc6af,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x3b4d4d);}}['isIndexed'](_0x5359be){return _0x5359be===ye||this['indexMap_']['hasIndex'](_0x5359be);}['equals'](_0x10cd5c){if(_0x10cd5c===this)return!0x0;if(_0x10cd5c['isLeafNode']())return!0x1;{const _0x3a381d=_0x10cd5c;if(this['getPriority']()['equals'](_0x3a381d['getPriority']())){if(this['children_']['count']()===_0x3a381d['children_']['count']()){const _0x224c64=this['getIterator'](R),_0x56cb69=_0x3a381d['getIterator'](R);let _0x272dca=_0x224c64['getNext'](),_0x166a0e=_0x56cb69['getNext']();for(;_0x272dca&&_0x166a0e;){if(_0x272dca['name']!==_0x166a0e['name']||!_0x272dca['node']['equals'](_0x166a0e['node']))return!0x1;_0x272dca=_0x224c64['getNext'](),_0x166a0e=_0x56cb69['getNext']();}return _0x272dca===null&&_0x166a0e===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x430dc6){return _0x430dc6===ye?null:this['indexMap_']['get'](_0x430dc6['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0xb6ebb){return _0xb6ebb===this?0x0:0x1;}['equals'](_0x2904bc){return _0x2904bc===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4a6aac){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0xa3b958,_0x27e223=null){if(_0xa3b958===null)return g['EMPTY_NODE'];if(typeof _0xa3b958=='object'&&'.priority'in _0xa3b958&&(_0x27e223=_0xa3b958['.priority']),f(_0x27e223===null||typeof _0x27e223=='string'||typeof _0x27e223=='number'||typeof _0x27e223=='object'&&'.sv'in _0x27e223,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x27e223),typeof _0xa3b958=='object'&&'.value'in _0xa3b958&&_0xa3b958['.value']!==null&&(_0xa3b958=_0xa3b958['.value']),typeof _0xa3b958!='object'||'.sv'in _0xa3b958){const _0x29364a=_0xa3b958;return new D(_0x29364a,N(_0x27e223));}if(!(_0xa3b958 instanceof Array)&&Vh){const _0x3c193a=[];let _0x148165=!0x1;if(x(_0xa3b958,(_0x416f5c,_0xf464c6)=>{if(_0x416f5c['substring'](0x0,0x1)!=='.'){const _0xa44391=N(_0xf464c6);_0xa44391['isEmpty']()||(_0x148165=_0x148165||!_0xa44391['getPriority']()['isEmpty'](),_0x3c193a['push'](new E(_0x416f5c,_0xa44391)));}}),_0x3c193a['length']===0x0)return g['EMPTY_NODE'];const _0x371a30=dn(_0x3c193a,Dh,_0x1c2f5a=>_0x1c2f5a['name'],ji);if(_0x148165){const _0x12ee70=dn(_0x3c193a,R['getCompare']());return new g(_0x371a30,N(_0x27e223),new ee({'.priority':_0x12ee70},{'.priority':R}));}else return new g(_0x371a30,N(_0x27e223),ee['Default']);}else{let _0x3bf0eb=g['EMPTY_NODE'];return x(_0xa3b958,(_0x5a0080,_0x5160ca)=>{if(Y(_0xa3b958,_0x5a0080)&&_0x5a0080['substring'](0x0,0x1)!=='.'){const _0x322511=N(_0x5160ca);(_0x322511['isLeafNode']()||!_0x322511['isEmpty']())&&(_0x3bf0eb=_0x3bf0eb['updateImmediateChild'](_0x5a0080,_0x322511));}}),_0x3bf0eb['updatePriority'](N(_0x27e223));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x1ace0c){super(),this['indexPath_']=_0x1ace0c,f(!v(_0x1ace0c)&&y(_0x1ace0c)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x290c3d){return _0x290c3d['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3e7d49){return!_0x3e7d49['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x29cfe0,_0x522b01){const _0x3d63bb=this['extractChild'](_0x29cfe0['node']),_0x4a3a5c=this['extractChild'](_0x522b01['node']),_0x19ac4f=_0x3d63bb['compareTo'](_0x4a3a5c);return _0x19ac4f===0x0?He(_0x29cfe0['name'],_0x522b01['name']):_0x19ac4f;}['makePost'](_0x1e8f7f,_0x1e4530){const _0x34b5ee=N(_0x1e8f7f),_0x2a5ce8=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x34b5ee);return new E(_0x1e4530,_0x2a5ce8);}['maxPost'](){const _0x4af368=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x4af368);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x1be545,_0x2c7340){const _0x30322c=_0x1be545['node']['compareTo'](_0x2c7340['node']);return _0x30322c===0x0?He(_0x1be545['name'],_0x2c7340['name']):_0x30322c;}['isDefinedOn'](_0x3f412f){return!0x0;}['indexedValueChanged'](_0x1e8869,_0x86e77b){return!_0x1e8869['equals'](_0x86e77b);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x502f61,_0x3a363e){const _0xee02f=N(_0x502f61);return new E(_0x3a363e,_0xee02f);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x359724){return{'type':'value','snapshotNode':_0x359724};}function tt(_0x7f606a,_0x1198f0){return{'type':'child_added','snapshotNode':_0x1198f0,'childName':_0x7f606a};}function Nt(_0xd98c6b,_0x25802d){return{'type':'child_removed','snapshotNode':_0x25802d,'childName':_0xd98c6b};}function Pt(_0xa12841,_0x4f8745,_0x582347){return{'type':'child_changed','snapshotNode':_0x4f8745,'childName':_0xa12841,'oldSnap':_0x582347};}function $h(_0x4d85af,_0xf890f){return{'type':'child_moved','snapshotNode':_0xf890f,'childName':_0x4d85af};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x32f49d){this['index_']=_0x32f49d;}['updateChild'](_0x4e187a,_0x2dbb95,_0x4095c1,_0x27a67c,_0x3f2bfd,_0x54fd97){f(_0x4e187a['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x14cade=_0x4e187a['getImmediateChild'](_0x2dbb95);return _0x14cade['getChild'](_0x27a67c)['equals'](_0x4095c1['getChild'](_0x27a67c))&&_0x14cade['isEmpty']()===_0x4095c1['isEmpty']()||(_0x54fd97!=null&&(_0x4095c1['isEmpty']()?_0x4e187a['hasChild'](_0x2dbb95)?_0x54fd97['trackChildChange'](Nt(_0x2dbb95,_0x14cade)):f(_0x4e187a['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x14cade['isEmpty']()?_0x54fd97['trackChildChange'](tt(_0x2dbb95,_0x4095c1)):_0x54fd97['trackChildChange'](Pt(_0x2dbb95,_0x4095c1,_0x14cade))),_0x4e187a['isLeafNode']()&&_0x4095c1['isEmpty']())?_0x4e187a:_0x4e187a['updateImmediateChild'](_0x2dbb95,_0x4095c1)['withIndex'](this['index_']);}['updateFullNode'](_0x572317,_0x24dc11,_0x2c9270){return _0x2c9270!=null&&(_0x572317['isLeafNode']()||_0x572317['forEachChild'](R,(_0x3bcd3a,_0x2f2e23)=>{_0x24dc11['hasChild'](_0x3bcd3a)||_0x2c9270['trackChildChange'](Nt(_0x3bcd3a,_0x2f2e23));}),_0x24dc11['isLeafNode']()||_0x24dc11['forEachChild'](R,(_0x2f35bc,_0x188c3f)=>{if(_0x572317['hasChild'](_0x2f35bc)){const _0x43daa7=_0x572317['getImmediateChild'](_0x2f35bc);_0x43daa7['equals'](_0x188c3f)||_0x2c9270['trackChildChange'](Pt(_0x2f35bc,_0x188c3f,_0x43daa7));}else _0x2c9270['trackChildChange'](tt(_0x2f35bc,_0x188c3f));})),_0x24dc11['withIndex'](this['index_']);}['updatePriority'](_0x319531,_0x4e9345){return _0x319531['isEmpty']()?g['EMPTY_NODE']:_0x319531['updatePriority'](_0x4e9345);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x5a7758){this['indexedFilter_']=new Yi(_0x5a7758['getIndex']()),this['index_']=_0x5a7758['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x5a7758),this['endPost_']=Ot['getEndPost_'](_0x5a7758),this['startIsInclusive_']=!_0x5a7758['startAfterSet_'],this['endIsInclusive_']=!_0x5a7758['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x526e74){const _0x3ce8ba=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x526e74)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x526e74)<0x0,_0xd73ad1=this['endIsInclusive_']?this['index_']['compare'](_0x526e74,this['getEndPost']())<=0x0:this['index_']['compare'](_0x526e74,this['getEndPost']())<0x0;return _0x3ce8ba&&_0xd73ad1;}['updateChild'](_0x1281da,_0x44384a,_0x18c6c5,_0x5e562f,_0x38638c,_0xaccd60){return this['matches'](new E(_0x44384a,_0x18c6c5))||(_0x18c6c5=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1281da,_0x44384a,_0x18c6c5,_0x5e562f,_0x38638c,_0xaccd60);}['updateFullNode'](_0x5114c8,_0x20f78d,_0x30f923){_0x20f78d['isLeafNode']()&&(_0x20f78d=g['EMPTY_NODE']);let _0x488b48=_0x20f78d['withIndex'](this['index_']);_0x488b48=_0x488b48['updatePriority'](g['EMPTY_NODE']);const _0x374e46=this;return _0x20f78d['forEachChild'](R,(_0x57d77f,_0x29d5e1)=>{_0x374e46['matches'](new E(_0x57d77f,_0x29d5e1))||(_0x488b48=_0x488b48['updateImmediateChild'](_0x57d77f,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x5114c8,_0x488b48,_0x30f923);}['updatePriority'](_0x2836ef,_0x2b47f4){return _0x2836ef;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x385d8b){if(_0x385d8b['hasStart']()){const _0x382688=_0x385d8b['getIndexStartName']();return _0x385d8b['getIndex']()['makePost'](_0x385d8b['getIndexStartValue'](),_0x382688);}else return _0x385d8b['getIndex']()['minPost']();}static['getEndPost_'](_0x202cb){if(_0x202cb['hasEnd']()){const _0x56d6f9=_0x202cb['getIndexEndName']();return _0x202cb['getIndex']()['makePost'](_0x202cb['getIndexEndValue'](),_0x56d6f9);}else return _0x202cb['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0xee32ca){this['withinDirectionalStart']=_0xe0422a=>this['reverse_']?this['withinEndPost'](_0xe0422a):this['withinStartPost'](_0xe0422a),this['withinDirectionalEnd']=_0x26cb5a=>this['reverse_']?this['withinStartPost'](_0x26cb5a):this['withinEndPost'](_0x26cb5a),this['withinStartPost']=_0x10d87b=>{const _0x438f31=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x10d87b);return this['startIsInclusive_']?_0x438f31<=0x0:_0x438f31<0x0;},this['withinEndPost']=_0x5ea597=>{const _0x425e1d=this['index_']['compare'](_0x5ea597,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x425e1d<=0x0:_0x425e1d<0x0;},this['rangedFilter_']=new Ot(_0xee32ca),this['index_']=_0xee32ca['getIndex'](),this['limit_']=_0xee32ca['getLimit'](),this['reverse_']=!_0xee32ca['isViewFromLeft'](),this['startIsInclusive_']=!_0xee32ca['startAfterSet_'],this['endIsInclusive_']=!_0xee32ca['endBeforeSet_'];}['updateChild'](_0x5f7623,_0x30012d,_0x5d9f90,_0x321812,_0x699fb9,_0x1086a6){return this['rangedFilter_']['matches'](new E(_0x30012d,_0x5d9f90))||(_0x5d9f90=g['EMPTY_NODE']),_0x5f7623['getImmediateChild'](_0x30012d)['equals'](_0x5d9f90)?_0x5f7623:_0x5f7623['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5f7623,_0x30012d,_0x5d9f90,_0x321812,_0x699fb9,_0x1086a6):this['fullLimitUpdateChild_'](_0x5f7623,_0x30012d,_0x5d9f90,_0x699fb9,_0x1086a6);}['updateFullNode'](_0x3c2c17,_0x5d2c0e,_0x50b8c6){let _0x430c91;if(_0x5d2c0e['isLeafNode']()||_0x5d2c0e['isEmpty']())_0x430c91=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5d2c0e['numChildren']()&&_0x5d2c0e['isIndexed'](this['index_'])){_0x430c91=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3a4330;this['reverse_']?_0x3a4330=_0x5d2c0e['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3a4330=_0x5d2c0e['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x5bca32=0x0;for(;_0x3a4330['hasNext']()&&_0x5bca32<this['limit_'];){const _0x4268a8=_0x3a4330['getNext']();if(this['withinDirectionalStart'](_0x4268a8)){if(this['withinDirectionalEnd'](_0x4268a8))_0x430c91=_0x430c91['updateImmediateChild'](_0x4268a8['name'],_0x4268a8['node']),_0x5bca32++;else break;}else continue;}}else{_0x430c91=_0x5d2c0e['withIndex'](this['index_']),_0x430c91=_0x430c91['updatePriority'](g['EMPTY_NODE']);let _0x5cd145;this['reverse_']?_0x5cd145=_0x430c91['getReverseIterator'](this['index_']):_0x5cd145=_0x430c91['getIterator'](this['index_']);let _0x3cb8b5=0x0;for(;_0x5cd145['hasNext']();){const _0x10a0ad=_0x5cd145['getNext']();_0x3cb8b5<this['limit_']&&this['withinDirectionalStart'](_0x10a0ad)&&this['withinDirectionalEnd'](_0x10a0ad)?_0x3cb8b5++:_0x430c91=_0x430c91['updateImmediateChild'](_0x10a0ad['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x3c2c17,_0x430c91,_0x50b8c6);}['updatePriority'](_0x535bff,_0x20da96){return _0x535bff;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x496488,_0x5f3c97,_0x197905,_0x5232cb,_0x5ee214){let _0x325706;if(this['reverse_']){const _0x19fef3=this['index_']['getCompare']();_0x325706=(_0x55df9c,_0x1d86dd)=>_0x19fef3(_0x1d86dd,_0x55df9c);}else _0x325706=this['index_']['getCompare']();const _0x45dc00=_0x496488;f(_0x45dc00['numChildren']()===this['limit_'],'');const _0x2a8571=new E(_0x5f3c97,_0x197905),_0xc76e58=this['reverse_']?_0x45dc00['getFirstChild'](this['index_']):_0x45dc00['getLastChild'](this['index_']),_0x696133=this['rangedFilter_']['matches'](_0x2a8571);if(_0x45dc00['hasChild'](_0x5f3c97)){const _0x459db1=_0x45dc00['getImmediateChild'](_0x5f3c97);let _0x363857=_0x5232cb['getChildAfterChild'](this['index_'],_0xc76e58,this['reverse_']);for(;_0x363857!=null&&(_0x363857['name']===_0x5f3c97||_0x45dc00['hasChild'](_0x363857['name']));)_0x363857=_0x5232cb['getChildAfterChild'](this['index_'],_0x363857,this['reverse_']);const _0x78e84a=_0x363857==null?0x1:_0x325706(_0x363857,_0x2a8571);if(_0x696133&&!_0x197905['isEmpty']()&&_0x78e84a>=0x0)return _0x5ee214!=null&&_0x5ee214['trackChildChange'](Pt(_0x5f3c97,_0x197905,_0x459db1)),_0x45dc00['updateImmediateChild'](_0x5f3c97,_0x197905);{_0x5ee214!=null&&_0x5ee214['trackChildChange'](Nt(_0x5f3c97,_0x459db1));const _0x6ce7c8=_0x45dc00['updateImmediateChild'](_0x5f3c97,g['EMPTY_NODE']);return _0x363857!=null&&this['rangedFilter_']['matches'](_0x363857)?(_0x5ee214!=null&&_0x5ee214['trackChildChange'](tt(_0x363857['name'],_0x363857['node'])),_0x6ce7c8['updateImmediateChild'](_0x363857['name'],_0x363857['node'])):_0x6ce7c8;}}else return _0x197905['isEmpty']()?_0x496488:_0x696133&&_0x325706(_0xc76e58,_0x2a8571)>=0x0?(_0x5ee214!=null&&(_0x5ee214['trackChildChange'](Nt(_0xc76e58['name'],_0xc76e58['node'])),_0x5ee214['trackChildChange'](tt(_0x5f3c97,_0x197905))),_0x45dc00['updateImmediateChild'](_0x5f3c97,_0x197905)['updateImmediateChild'](_0xc76e58['name'],g['EMPTY_NODE'])):_0x496488;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x14f009=new Qi();return _0x14f009['limitSet_']=this['limitSet_'],_0x14f009['limit_']=this['limit_'],_0x14f009['startSet_']=this['startSet_'],_0x14f009['startAfterSet_']=this['startAfterSet_'],_0x14f009['indexStartValue_']=this['indexStartValue_'],_0x14f009['startNameSet_']=this['startNameSet_'],_0x14f009['indexStartName_']=this['indexStartName_'],_0x14f009['endSet_']=this['endSet_'],_0x14f009['endBeforeSet_']=this['endBeforeSet_'],_0x14f009['indexEndValue_']=this['indexEndValue_'],_0x14f009['endNameSet_']=this['endNameSet_'],_0x14f009['indexEndName_']=this['indexEndName_'],_0x14f009['index_']=this['index_'],_0x14f009['viewFrom_']=this['viewFrom_'],_0x14f009;}}function qh(_0x524a1e){return _0x524a1e['loadsAllData']()?new Yi(_0x524a1e['getIndex']()):_0x524a1e['hasLimit']()?new Gh(_0x524a1e):new Ot(_0x524a1e);}function zh(_0x24a635,_0x3e4c94){const _0x3496e0=_0x24a635['copy']();return _0x3496e0['limitSet_']=!0x0,_0x3496e0['limit_']=_0x3e4c94,_0x3496e0['viewFrom_']='l',_0x3496e0;}function jh(_0x4654d5,_0x39dc29,_0x1f6999){const _0x27d1fd=_0x4654d5['copy']();return _0x27d1fd['startSet_']=!0x0,_0x39dc29===void 0x0&&(_0x39dc29=null),_0x27d1fd['indexStartValue_']=_0x39dc29,_0x1f6999!=null?(_0x27d1fd['startNameSet_']=!0x0,_0x27d1fd['indexStartName_']=_0x1f6999):(_0x27d1fd['startNameSet_']=!0x1,_0x27d1fd['indexStartName_']=''),_0x27d1fd;}function Kh(_0x501766,_0x2a37c1,_0x6e1d91){const _0x379b65=_0x501766['copy']();return _0x379b65['endSet_']=!0x0,_0x2a37c1===void 0x0&&(_0x2a37c1=null),_0x379b65['indexEndValue_']=_0x2a37c1,_0x6e1d91!==void 0x0?(_0x379b65['endNameSet_']=!0x0,_0x379b65['indexEndName_']=_0x6e1d91):(_0x379b65['endNameSet_']=!0x1,_0x379b65['indexEndName_']=''),_0x379b65;}function Do(_0x57fc81,_0x171ef2){const _0x35e73d=_0x57fc81['copy']();return _0x35e73d['index_']=_0x171ef2,_0x35e73d;}function tr(_0x48d3c0){const _0x5e706c={};if(_0x48d3c0['isDefault']())return _0x5e706c;let _0x2c869a;if(_0x48d3c0['index_']===R?_0x2c869a='$priority':_0x48d3c0['index_']===Po?_0x2c869a='$value':_0x48d3c0['index_']===ye?_0x2c869a='$key':(f(_0x48d3c0['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x2c869a=_0x48d3c0['index_']['toString']()),_0x5e706c['orderBy']=O(_0x2c869a),_0x48d3c0['startSet_']){const _0x191260=_0x48d3c0['startAfterSet_']?'startAfter':'startAt';_0x5e706c[_0x191260]=O(_0x48d3c0['indexStartValue_']),_0x48d3c0['startNameSet_']&&(_0x5e706c[_0x191260]+=','+O(_0x48d3c0['indexStartName_']));}if(_0x48d3c0['endSet_']){const _0x14722c=_0x48d3c0['endBeforeSet_']?'endBefore':'endAt';_0x5e706c[_0x14722c]=O(_0x48d3c0['indexEndValue_']),_0x48d3c0['endNameSet_']&&(_0x5e706c[_0x14722c]+=','+O(_0x48d3c0['indexEndName_']));}return _0x48d3c0['limitSet_']&&(_0x48d3c0['isViewFromLeft']()?_0x5e706c['limitToFirst']=_0x48d3c0['limit_']:_0x5e706c['limitToLast']=_0x48d3c0['limit_']),_0x5e706c;}function nr(_0x19dda0){const _0x86f3c7={};if(_0x19dda0['startSet_']&&(_0x86f3c7['sp']=_0x19dda0['indexStartValue_'],_0x19dda0['startNameSet_']&&(_0x86f3c7['sn']=_0x19dda0['indexStartName_']),_0x86f3c7['sin']=!_0x19dda0['startAfterSet_']),_0x19dda0['endSet_']&&(_0x86f3c7['ep']=_0x19dda0['indexEndValue_'],_0x19dda0['endNameSet_']&&(_0x86f3c7['en']=_0x19dda0['indexEndName_']),_0x86f3c7['ein']=!_0x19dda0['endBeforeSet_']),_0x19dda0['limitSet_']){_0x86f3c7['l']=_0x19dda0['limit_'];let _0x31656d=_0x19dda0['viewFrom_'];_0x31656d===''&&(_0x19dda0['isViewFromLeft']()?_0x31656d='l':_0x31656d='r'),_0x86f3c7['vf']=_0x31656d;}return _0x19dda0['index_']!==R&&(_0x86f3c7['i']=_0x19dda0['index_']['toString']()),_0x86f3c7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x37be2b){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x816b2a,_0x374d09){return _0x374d09!==void 0x0?'tag$'+_0x374d09:(f(_0x816b2a['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x816b2a['_path']['toString']());}constructor(_0x2463f5,_0x5e2bda,_0x393eac,_0x4ca700){super(),this['repoInfo_']=_0x2463f5,this['onDataUpdate_']=_0x5e2bda,this['authTokenProvider_']=_0x393eac,this['appCheckTokenProvider_']=_0x4ca700,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x251fe8,_0x4e9380,_0x5526a2,_0xa291df){const _0x68db7e=_0x251fe8['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x68db7e+'\x20'+_0x251fe8['_queryIdentifier']);const _0x26913b=fn['getListenId_'](_0x251fe8,_0x5526a2),_0x48a431={};this['listens_'][_0x26913b]=_0x48a431;const _0x5036b5=tr(_0x251fe8['_queryParams']);this['restRequest_'](_0x68db7e+'.json',_0x5036b5,(_0x5bde8d,_0xbd0748)=>{let _0x17c4f6=_0xbd0748;if(_0x5bde8d===0x194&&(_0x17c4f6=null,_0x5bde8d=null),_0x5bde8d===null&&this['onDataUpdate_'](_0x68db7e,_0x17c4f6,!0x1,_0x5526a2),Oe(this['listens_'],_0x26913b)===_0x48a431){let _0x428456;_0x5bde8d?_0x5bde8d===0x191?_0x428456='permission_denied':_0x428456='rest_error:'+_0x5bde8d:_0x428456='ok',_0xa291df(_0x428456,null);}});}['unlisten'](_0xd4ed19,_0x4f5663){const _0x5a739d=fn['getListenId_'](_0xd4ed19,_0x4f5663);delete this['listens_'][_0x5a739d];}['get'](_0xf34cc1){const _0xa027c9=tr(_0xf34cc1['_queryParams']),_0x1503e6=_0xf34cc1['_path']['toString'](),_0x567c55=new Ve();return this['restRequest_'](_0x1503e6+'.json',_0xa027c9,(_0x52499b,_0x2ebc85)=>{let _0x9b22ea=_0x2ebc85;_0x52499b===0x194&&(_0x9b22ea=null,_0x52499b=null),_0x52499b===null?(this['onDataUpdate_'](_0x1503e6,_0x9b22ea,!0x1,null),_0x567c55['resolve'](_0x9b22ea)):_0x567c55['reject'](new Error(_0x9b22ea));}),_0x567c55['promise'];}['refreshAuthToken'](_0x13c93b){}['restRequest_'](_0x1e7a54,_0x28c8a6={},_0x20d462){return _0x28c8a6['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4b24b6,_0x5ccd24])=>{_0x4b24b6&&_0x4b24b6['accessToken']&&(_0x28c8a6['auth']=_0x4b24b6['accessToken']),_0x5ccd24&&_0x5ccd24['token']&&(_0x28c8a6['ac']=_0x5ccd24['token']);const _0x51e9ff=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x1e7a54+'?ns='+this['repoInfo_']['namespace']+at(_0x28c8a6);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x51e9ff);const _0x3ca415=new XMLHttpRequest();_0x3ca415['onreadystatechange']=()=>{if(_0x20d462&&_0x3ca415['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x51e9ff+'\x20received.\x20status:',_0x3ca415['status'],'response:',_0x3ca415['responseText']);let _0x493093=null;if(_0x3ca415['status']>=0xc8&&_0x3ca415['status']<0x12c){try{_0x493093=bt(_0x3ca415['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x51e9ff+':\x20'+_0x3ca415['responseText']);}_0x20d462(null,_0x493093);}else _0x3ca415['status']!==0x191&&_0x3ca415['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x51e9ff+'\x20Status:\x20'+_0x3ca415['status']),_0x20d462(_0x3ca415['status']);_0x20d462=null;}},_0x3ca415['open']('GET',_0x51e9ff,!0x0),_0x3ca415['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x454b27){return this['rootNode_']['getChild'](_0x454b27);}['updateSnapshot'](_0x1c6cfe,_0x3d94c3){this['rootNode_']=this['rootNode_']['updateChild'](_0x1c6cfe,_0x3d94c3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x43ed58,_0x492381,_0x5ef7dd){if(v(_0x492381))_0x43ed58['value']=_0x5ef7dd,_0x43ed58['children']['clear']();else{if(_0x43ed58['value']!==null)_0x43ed58['value']=_0x43ed58['value']['updateChild'](_0x492381,_0x5ef7dd);else{const _0x55090a=y(_0x492381);_0x43ed58['children']['has'](_0x55090a)||_0x43ed58['children']['set'](_0x55090a,pn());const _0x10b19b=_0x43ed58['children']['get'](_0x55090a);_0x492381=b(_0x492381),Mo(_0x10b19b,_0x492381,_0x5ef7dd);}}}function Ei(_0xeef72c,_0x4ebe79,_0x32757b){_0xeef72c['value']!==null?_0x32757b(_0x4ebe79,_0xeef72c['value']):Qh(_0xeef72c,(_0x222b3a,_0x59ce10)=>{const _0x5c49ee=new C(_0x4ebe79['toString']()+'/'+_0x222b3a);Ei(_0x59ce10,_0x5c49ee,_0x32757b);});}function Qh(_0x243900,_0x1482a9){_0x243900['children']['forEach']((_0x198729,_0x288578)=>{_0x1482a9(_0x288578,_0x198729);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x3a981f){this['collection_']=_0x3a981f,this['last_']=null;}['get'](){const _0xad2803=this['collection_']['get'](),_0x390701={..._0xad2803};return this['last_']&&x(this['last_'],(_0x55a42b,_0x36ed0c)=>{_0x390701[_0x55a42b]=_0x390701[_0x55a42b]-_0x36ed0c;}),this['last_']=_0xad2803,_0x390701;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x3db932,_0x20b181){this['server_']=_0x20b181,this['statsToReport_']={},this['statsListener_']=new Jh(_0x3db932);const _0x3149ea=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x3149ea));}['reportStats_'](){const _0x426983=this['statsListener_']['get'](),_0x2dcd10={};let _0x1742cc=!0x1;x(_0x426983,(_0x2986f6,_0x5719f7)=>{_0x5719f7>0x0&&Y(this['statsToReport_'],_0x2986f6)&&(_0x2dcd10[_0x2986f6]=_0x5719f7,_0x1742cc=!0x0);}),_0x1742cc&&this['server_']['reportStats'](_0x2dcd10),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x33f30d){_0x33f30d[_0x33f30d['OVERWRITE']=0x0]='OVERWRITE',_0x33f30d[_0x33f30d['MERGE']=0x1]='MERGE',_0x33f30d[_0x33f30d['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x33f30d[_0x33f30d['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x1b6772){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1b6772,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x32df31,_0x219d21,_0x4c6257){this['path']=_0x32df31,this['affectedTree']=_0x219d21,this['revert']=_0x4c6257,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x464d65){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x7e21d9=this['affectedTree']['subtree'](new C(_0x464d65));return new _n(w(),_0x7e21d9,this['revert']);}}else return f(y(this['path'])===_0x464d65,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x4bd82f,_0x56955d){this['source']=_0x4bd82f,this['path']=_0x56955d,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x2dc0ac){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x5f08c9,_0x11e38f,_0x1b2104){this['source']=_0x5f08c9,this['path']=_0x11e38f,this['snap']=_0x1b2104,this['type']=q['OVERWRITE'];}['operationForChild'](_0x3d3d17){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x3d3d17)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x223f4c,_0x469002,_0x5acc84){this['source']=_0x223f4c,this['path']=_0x469002,this['children']=_0x5acc84,this['type']=q['MERGE'];}['operationForChild'](_0x5f542a){if(v(this['path'])){const _0x4ad8f6=this['children']['subtree'](new C(_0x5f542a));return _0x4ad8f6['isEmpty']()?null:_0x4ad8f6['value']?new Fe(this['source'],w(),_0x4ad8f6['value']):new nt(this['source'],w(),_0x4ad8f6);}else return f(y(this['path'])===_0x5f542a,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x254d6e,_0x1cdfe0,_0x5b4746){this['node_']=_0x254d6e,this['fullyInitialized_']=_0x1cdfe0,this['filtered_']=_0x5b4746;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x28e9f1){if(v(_0x28e9f1))return this['isFullyInitialized']()&&!this['filtered_'];const _0x46fe17=y(_0x28e9f1);return this['isCompleteForChild'](_0x46fe17);}['isCompleteForChild'](_0x27802f){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x27802f);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x29b428){this['query_']=_0x29b428,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x3579af,_0x25b562,_0x32c0fd,_0x1402bb){const _0x523e21=[],_0x2332c3=[];return _0x25b562['forEach'](_0x4ea175=>{_0x4ea175['type']==='child_changed'&&_0x3579af['index_']['indexedValueChanged'](_0x4ea175['oldSnap'],_0x4ea175['snapshotNode'])&&_0x2332c3['push']($h(_0x4ea175['childName'],_0x4ea175['snapshotNode']));}),mt(_0x3579af,_0x523e21,'child_removed',_0x25b562,_0x1402bb,_0x32c0fd),mt(_0x3579af,_0x523e21,'child_added',_0x25b562,_0x1402bb,_0x32c0fd),mt(_0x3579af,_0x523e21,'child_moved',_0x2332c3,_0x1402bb,_0x32c0fd),mt(_0x3579af,_0x523e21,'child_changed',_0x25b562,_0x1402bb,_0x32c0fd),mt(_0x3579af,_0x523e21,'value',_0x25b562,_0x1402bb,_0x32c0fd),_0x523e21;}function mt(_0x51936d,_0x1f6a57,_0x3d37b6,_0x14b3c4,_0x4c3793,_0x127e19){const _0x428331=_0x14b3c4['filter'](_0x352529=>_0x352529['type']===_0x3d37b6);_0x428331['sort']((_0x12d812,_0x328c89)=>su(_0x51936d,_0x12d812,_0x328c89)),_0x428331['forEach'](_0x129009=>{const _0x1f7fa6=iu(_0x51936d,_0x129009,_0x127e19);_0x4c3793['forEach'](_0x18a773=>{_0x18a773['respondsTo'](_0x129009['type'])&&_0x1f6a57['push'](_0x18a773['createEvent'](_0x1f7fa6,_0x51936d['query_']));});});}function iu(_0x10adda,_0x29c92,_0xfd0f58){return _0x29c92['type']==='value'||_0x29c92['type']==='child_removed'||(_0x29c92['prevName']=_0xfd0f58['getPredecessorChildName'](_0x29c92['childName'],_0x29c92['snapshotNode'],_0x10adda['index_'])),_0x29c92;}function su(_0x1db814,_0x3c843d,_0x5cbd0a){if(_0x3c843d['childName']==null||_0x5cbd0a['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x3b9ea8=new E(_0x3c843d['childName'],_0x3c843d['snapshotNode']),_0x5b6e58=new E(_0x5cbd0a['childName'],_0x5cbd0a['snapshotNode']);return _0x1db814['index_']['compare'](_0x3b9ea8,_0x5b6e58);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x212fb1,_0x8b4299){return{'eventCache':_0x212fb1,'serverCache':_0x8b4299};}function wt(_0x294b7b,_0x1a2fe5,_0x4fb496,_0x4ea021){return Dn(new Ce(_0x1a2fe5,_0x4fb496,_0x4ea021),_0x294b7b['serverCache']);}function Lo(_0x19b15a,_0x17c2ae,_0x158bee,_0x14e62a){return Dn(_0x19b15a['eventCache'],new Ce(_0x17c2ae,_0x158bee,_0x14e62a));}function gn(_0x50ea75){return _0x50ea75['eventCache']['isFullyInitialized']()?_0x50ea75['eventCache']['getNode']():null;}function Ue(_0x3c7fce){return _0x3c7fce['serverCache']['isFullyInitialized']()?_0x3c7fce['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x227aee){let _0x590b1e=new S(null);return x(_0x227aee,(_0x47b776,_0x52b9fd)=>{_0x590b1e=_0x590b1e['set'](new C(_0x47b776),_0x52b9fd);}),_0x590b1e;}constructor(_0x1977d5,_0x2787ea=ru()){this['value']=_0x1977d5,this['children']=_0x2787ea;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x501e8e,_0x49be0b){if(this['value']!=null&&_0x49be0b(this['value']))return{'path':w(),'value':this['value']};if(v(_0x501e8e))return null;{const _0x4432c6=y(_0x501e8e),_0x42fae8=this['children']['get'](_0x4432c6);if(_0x42fae8!==null){const _0x108d64=_0x42fae8['findRootMostMatchingPathAndValue'](b(_0x501e8e),_0x49be0b);return _0x108d64!=null?{'path':A(new C(_0x4432c6),_0x108d64['path']),'value':_0x108d64['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x49e183){return this['findRootMostMatchingPathAndValue'](_0x49e183,()=>!0x0);}['subtree'](_0x16ce7e){if(v(_0x16ce7e))return this;{const _0x51522e=y(_0x16ce7e),_0x4702fa=this['children']['get'](_0x51522e);return _0x4702fa!==null?_0x4702fa['subtree'](b(_0x16ce7e)):new S(null);}}['set'](_0x11deb9,_0x3f9c20){if(v(_0x11deb9))return new S(_0x3f9c20,this['children']);{const _0x402164=y(_0x11deb9),_0x487d44=(this['children']['get'](_0x402164)||new S(null))['set'](b(_0x11deb9),_0x3f9c20),_0x4ff382=this['children']['insert'](_0x402164,_0x487d44);return new S(this['value'],_0x4ff382);}}['remove'](_0xdaf282){if(v(_0xdaf282))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x300e8d=y(_0xdaf282),_0x2fced7=this['children']['get'](_0x300e8d);if(_0x2fced7){const _0x496a30=_0x2fced7['remove'](b(_0xdaf282));let _0x5dceaa;return _0x496a30['isEmpty']()?_0x5dceaa=this['children']['remove'](_0x300e8d):_0x5dceaa=this['children']['insert'](_0x300e8d,_0x496a30),this['value']===null&&_0x5dceaa['isEmpty']()?new S(null):new S(this['value'],_0x5dceaa);}else return this;}}['get'](_0x52372f){if(v(_0x52372f))return this['value'];{const _0x267518=y(_0x52372f),_0x297d85=this['children']['get'](_0x267518);return _0x297d85?_0x297d85['get'](b(_0x52372f)):null;}}['setTree'](_0x2b99d4,_0x2285f4){if(v(_0x2b99d4))return _0x2285f4;{const _0x5280be=y(_0x2b99d4),_0x364974=(this['children']['get'](_0x5280be)||new S(null))['setTree'](b(_0x2b99d4),_0x2285f4);let _0x522fb0;return _0x364974['isEmpty']()?_0x522fb0=this['children']['remove'](_0x5280be):_0x522fb0=this['children']['insert'](_0x5280be,_0x364974),new S(this['value'],_0x522fb0);}}['fold'](_0x253405){return this['fold_'](w(),_0x253405);}['fold_'](_0x189368,_0x55d109){const _0x468523={};return this['children']['inorderTraversal']((_0x267dee,_0x5a1121)=>{_0x468523[_0x267dee]=_0x5a1121['fold_'](A(_0x189368,_0x267dee),_0x55d109);}),_0x55d109(_0x189368,this['value'],_0x468523);}['findOnPath'](_0x23153d,_0x4c0307){return this['findOnPath_'](_0x23153d,w(),_0x4c0307);}['findOnPath_'](_0x5963b4,_0x4284eb,_0x368cc2){const _0x4ec036=this['value']?_0x368cc2(_0x4284eb,this['value']):!0x1;if(_0x4ec036)return _0x4ec036;if(v(_0x5963b4))return null;{const _0x15ee98=y(_0x5963b4),_0x5e1225=this['children']['get'](_0x15ee98);return _0x5e1225?_0x5e1225['findOnPath_'](b(_0x5963b4),A(_0x4284eb,_0x15ee98),_0x368cc2):null;}}['foreachOnPath'](_0x7580d0,_0x7bce44){return this['foreachOnPath_'](_0x7580d0,w(),_0x7bce44);}['foreachOnPath_'](_0x861842,_0x1d24cf,_0x135656){if(v(_0x861842))return this;{this['value']&&_0x135656(_0x1d24cf,this['value']);const _0x1374be=y(_0x861842),_0x2570f3=this['children']['get'](_0x1374be);return _0x2570f3?_0x2570f3['foreachOnPath_'](b(_0x861842),A(_0x1d24cf,_0x1374be),_0x135656):new S(null);}}['foreach'](_0x536b28){this['foreach_'](w(),_0x536b28);}['foreach_'](_0x351f7f,_0x2246c4){this['children']['inorderTraversal']((_0x1088b3,_0x5b621a)=>{_0x5b621a['foreach_'](A(_0x351f7f,_0x1088b3),_0x2246c4);}),this['value']&&_0x2246c4(_0x351f7f,this['value']);}['foreachChild'](_0x2e58a8){this['children']['inorderTraversal']((_0x126735,_0x36a2cf)=>{_0x36a2cf['value']&&_0x2e58a8(_0x126735,_0x36a2cf['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x36ac82){this['writeTree_']=_0x36ac82;}static['empty'](){return new j(new S(null));}}function Ct(_0x304fcb,_0x271338,_0x5e557b){if(v(_0x271338))return new j(new S(_0x5e557b));{const _0x10efa7=_0x304fcb['writeTree_']['findRootMostValueAndPath'](_0x271338);if(_0x10efa7!=null){const _0x2e2a0f=_0x10efa7['path'];let _0x21d686=_0x10efa7['value'];const _0x33c4c9=F(_0x2e2a0f,_0x271338);return _0x21d686=_0x21d686['updateChild'](_0x33c4c9,_0x5e557b),new j(_0x304fcb['writeTree_']['set'](_0x2e2a0f,_0x21d686));}else{const _0x6f6fe6=new S(_0x5e557b),_0x4b2ec0=_0x304fcb['writeTree_']['setTree'](_0x271338,_0x6f6fe6);return new j(_0x4b2ec0);}}}function Ii(_0x364544,_0x4b46ca,_0x509108){let _0x4c6fe6=_0x364544;return x(_0x509108,(_0x3f4c60,_0x35ca17)=>{_0x4c6fe6=Ct(_0x4c6fe6,A(_0x4b46ca,_0x3f4c60),_0x35ca17);}),_0x4c6fe6;}function sr(_0x5d64e8,_0x2656d0){if(v(_0x2656d0))return j['empty']();{const _0x168b7e=_0x5d64e8['writeTree_']['setTree'](_0x2656d0,new S(null));return new j(_0x168b7e);}}function wi(_0x8da66a,_0xd2411c){return $e(_0x8da66a,_0xd2411c)!=null;}function $e(_0x588ee4,_0x52534a){const _0x272ac1=_0x588ee4['writeTree_']['findRootMostValueAndPath'](_0x52534a);return _0x272ac1!=null?_0x588ee4['writeTree_']['get'](_0x272ac1['path'])['getChild'](F(_0x272ac1['path'],_0x52534a)):null;}function rr(_0xf91a62){const _0x1f5d95=[],_0x2f5c30=_0xf91a62['writeTree_']['value'];return _0x2f5c30!=null?_0x2f5c30['isLeafNode']()||_0x2f5c30['forEachChild'](R,(_0x1a217c,_0x34dfcc)=>{_0x1f5d95['push'](new E(_0x1a217c,_0x34dfcc));}):_0xf91a62['writeTree_']['children']['inorderTraversal']((_0x4879a3,_0x5a382c)=>{_0x5a382c['value']!=null&&_0x1f5d95['push'](new E(_0x4879a3,_0x5a382c['value']));}),_0x1f5d95;}function ve(_0x64f63e,_0x30899b){if(v(_0x30899b))return _0x64f63e;{const _0x461ec3=$e(_0x64f63e,_0x30899b);return _0x461ec3!=null?new j(new S(_0x461ec3)):new j(_0x64f63e['writeTree_']['subtree'](_0x30899b));}}function Ci(_0x4c868b){return _0x4c868b['writeTree_']['isEmpty']();}function it(_0x56ea00,_0x4d5c96){return xo(w(),_0x56ea00['writeTree_'],_0x4d5c96);}function xo(_0x42ca5f,_0x1f09f5,_0x5e010c){if(_0x1f09f5['value']!=null)return _0x5e010c['updateChild'](_0x42ca5f,_0x1f09f5['value']);{let _0x3ec2d3=null;return _0x1f09f5['children']['inorderTraversal']((_0x2b4ef7,_0x289c9a)=>{_0x2b4ef7==='.priority'?(f(_0x289c9a['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3ec2d3=_0x289c9a['value']):_0x5e010c=xo(A(_0x42ca5f,_0x2b4ef7),_0x289c9a,_0x5e010c);}),!_0x5e010c['getChild'](_0x42ca5f)['isEmpty']()&&_0x3ec2d3!==null&&(_0x5e010c=_0x5e010c['updateChild'](A(_0x42ca5f,'.priority'),_0x3ec2d3)),_0x5e010c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x530d21,_0x3297c9){return Bo(_0x3297c9,_0x530d21);}function ou(_0x44d39d,_0xfdae8a,_0x219f46,_0x503c8a,_0x5b55c8){f(_0x503c8a>_0x44d39d['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x5b55c8===void 0x0&&(_0x5b55c8=!0x0),_0x44d39d['allWrites']['push']({'path':_0xfdae8a,'snap':_0x219f46,'writeId':_0x503c8a,'visible':_0x5b55c8}),_0x5b55c8&&(_0x44d39d['visibleWrites']=Ct(_0x44d39d['visibleWrites'],_0xfdae8a,_0x219f46)),_0x44d39d['lastWriteId']=_0x503c8a;}function au(_0x5d4fec,_0xbe81e3,_0x11d940,_0x57c9db){f(_0x57c9db>_0x5d4fec['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5d4fec['allWrites']['push']({'path':_0xbe81e3,'children':_0x11d940,'writeId':_0x57c9db,'visible':!0x0}),_0x5d4fec['visibleWrites']=Ii(_0x5d4fec['visibleWrites'],_0xbe81e3,_0x11d940),_0x5d4fec['lastWriteId']=_0x57c9db;}function cu(_0x4cddba,_0x2a3c34){for(let _0x468b3b=0x0;_0x468b3b<_0x4cddba['allWrites']['length'];_0x468b3b++){const _0x123546=_0x4cddba['allWrites'][_0x468b3b];if(_0x123546['writeId']===_0x2a3c34)return _0x123546;}return null;}function lu(_0x4902a3,_0x52b59e){const _0x38fd70=_0x4902a3['allWrites']['findIndex'](_0x3600bd=>_0x3600bd['writeId']===_0x52b59e);f(_0x38fd70>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x12c7b2=_0x4902a3['allWrites'][_0x38fd70];_0x4902a3['allWrites']['splice'](_0x38fd70,0x1);let _0x1344f4=_0x12c7b2['visible'],_0x22cbde=!0x1,_0x15a480=_0x4902a3['allWrites']['length']-0x1;for(;_0x1344f4&&_0x15a480>=0x0;){const _0x4cb3ba=_0x4902a3['allWrites'][_0x15a480];_0x4cb3ba['visible']&&(_0x15a480>=_0x38fd70&&hu(_0x4cb3ba,_0x12c7b2['path'])?_0x1344f4=!0x1:$(_0x12c7b2['path'],_0x4cb3ba['path'])&&(_0x22cbde=!0x0)),_0x15a480--;}if(_0x1344f4){if(_0x22cbde)return uu(_0x4902a3),!0x0;if(_0x12c7b2['snap'])_0x4902a3['visibleWrites']=sr(_0x4902a3['visibleWrites'],_0x12c7b2['path']);else{const _0x558152=_0x12c7b2['children'];x(_0x558152,_0x2e6552=>{_0x4902a3['visibleWrites']=sr(_0x4902a3['visibleWrites'],A(_0x12c7b2['path'],_0x2e6552));});}return!0x0;}else return!0x1;}function hu(_0x26fc24,_0x287f2b){if(_0x26fc24['snap'])return $(_0x26fc24['path'],_0x287f2b);for(const _0x3f7729 in _0x26fc24['children'])if(_0x26fc24['children']['hasOwnProperty'](_0x3f7729)&&$(A(_0x26fc24['path'],_0x3f7729),_0x287f2b))return!0x0;return!0x1;}function uu(_0x104bdd){_0x104bdd['visibleWrites']=Fo(_0x104bdd['allWrites'],du,w()),_0x104bdd['allWrites']['length']>0x0?_0x104bdd['lastWriteId']=_0x104bdd['allWrites'][_0x104bdd['allWrites']['length']-0x1]['writeId']:_0x104bdd['lastWriteId']=-0x1;}function du(_0x1e960d){return _0x1e960d['visible'];}function Fo(_0x31defb,_0x2d8f20,_0x28e035){let _0x29c4bb=j['empty']();for(let _0x311c6d=0x0;_0x311c6d<_0x31defb['length'];++_0x311c6d){const _0x226c47=_0x31defb[_0x311c6d];if(_0x2d8f20(_0x226c47)){const _0xdecd61=_0x226c47['path'];let _0x421acd;if(_0x226c47['snap'])$(_0x28e035,_0xdecd61)?(_0x421acd=F(_0x28e035,_0xdecd61),_0x29c4bb=Ct(_0x29c4bb,_0x421acd,_0x226c47['snap'])):$(_0xdecd61,_0x28e035)&&(_0x421acd=F(_0xdecd61,_0x28e035),_0x29c4bb=Ct(_0x29c4bb,w(),_0x226c47['snap']['getChild'](_0x421acd)));else{if(_0x226c47['children']){if($(_0x28e035,_0xdecd61))_0x421acd=F(_0x28e035,_0xdecd61),_0x29c4bb=Ii(_0x29c4bb,_0x421acd,_0x226c47['children']);else{if($(_0xdecd61,_0x28e035)){if(_0x421acd=F(_0xdecd61,_0x28e035),v(_0x421acd))_0x29c4bb=Ii(_0x29c4bb,w(),_0x226c47['children']);else{const _0x1d7fc9=Oe(_0x226c47['children'],y(_0x421acd));if(_0x1d7fc9){const _0x3f06b8=_0x1d7fc9['getChild'](b(_0x421acd));_0x29c4bb=Ct(_0x29c4bb,w(),_0x3f06b8);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x29c4bb;}function Uo(_0x4f5bf3,_0x418498,_0x12d8f1,_0x258c23,_0x582ece){if(!_0x258c23&&!_0x582ece){const _0x39388c=$e(_0x4f5bf3['visibleWrites'],_0x418498);if(_0x39388c!=null)return _0x39388c;{const _0x4bf159=ve(_0x4f5bf3['visibleWrites'],_0x418498);if(Ci(_0x4bf159))return _0x12d8f1;if(_0x12d8f1==null&&!wi(_0x4bf159,w()))return null;{const _0x35ca51=_0x12d8f1||g['EMPTY_NODE'];return it(_0x4bf159,_0x35ca51);}}}else{const _0x370dbb=ve(_0x4f5bf3['visibleWrites'],_0x418498);if(!_0x582ece&&Ci(_0x370dbb))return _0x12d8f1;if(!_0x582ece&&_0x12d8f1==null&&!wi(_0x370dbb,w()))return null;{const _0x5da703=function(_0x42a17a){return(_0x42a17a['visible']||_0x582ece)&&(!_0x258c23||!~_0x258c23['indexOf'](_0x42a17a['writeId']))&&($(_0x42a17a['path'],_0x418498)||$(_0x418498,_0x42a17a['path']));},_0x27957b=Fo(_0x4f5bf3['allWrites'],_0x5da703,_0x418498),_0x19849b=_0x12d8f1||g['EMPTY_NODE'];return it(_0x27957b,_0x19849b);}}}function fu(_0x59f6ec,_0x2bf35a,_0xc63cb3){let _0x241ff2=g['EMPTY_NODE'];const _0xc661d9=$e(_0x59f6ec['visibleWrites'],_0x2bf35a);if(_0xc661d9)return _0xc661d9['isLeafNode']()||_0xc661d9['forEachChild'](R,(_0x45c186,_0x4d4975)=>{_0x241ff2=_0x241ff2['updateImmediateChild'](_0x45c186,_0x4d4975);}),_0x241ff2;if(_0xc63cb3){const _0x2d176b=ve(_0x59f6ec['visibleWrites'],_0x2bf35a);return _0xc63cb3['forEachChild'](R,(_0x443cd7,_0x3b8418)=>{const _0x57a158=it(ve(_0x2d176b,new C(_0x443cd7)),_0x3b8418);_0x241ff2=_0x241ff2['updateImmediateChild'](_0x443cd7,_0x57a158);}),rr(_0x2d176b)['forEach'](_0x39fd0a=>{_0x241ff2=_0x241ff2['updateImmediateChild'](_0x39fd0a['name'],_0x39fd0a['node']);}),_0x241ff2;}else{const _0x240c04=ve(_0x59f6ec['visibleWrites'],_0x2bf35a);return rr(_0x240c04)['forEach'](_0xf0d1ac=>{_0x241ff2=_0x241ff2['updateImmediateChild'](_0xf0d1ac['name'],_0xf0d1ac['node']);}),_0x241ff2;}}function pu(_0x2b9781,_0xb1e995,_0x590aac,_0x520825,_0x1a3a3b){f(_0x520825||_0x1a3a3b,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x426c18=A(_0xb1e995,_0x590aac);if(wi(_0x2b9781['visibleWrites'],_0x426c18))return null;{const _0x2860a1=ve(_0x2b9781['visibleWrites'],_0x426c18);return Ci(_0x2860a1)?_0x1a3a3b['getChild'](_0x590aac):it(_0x2860a1,_0x1a3a3b['getChild'](_0x590aac));}}function _u(_0x315277,_0x263abc,_0x23a2b5,_0x22467f){const _0x8e503f=A(_0x263abc,_0x23a2b5),_0x491436=$e(_0x315277['visibleWrites'],_0x8e503f);if(_0x491436!=null)return _0x491436;if(_0x22467f['isCompleteForChild'](_0x23a2b5)){const _0x48dfd8=ve(_0x315277['visibleWrites'],_0x8e503f);return it(_0x48dfd8,_0x22467f['getNode']()['getImmediateChild'](_0x23a2b5));}else return null;}function gu(_0x43d289,_0x7d9701){return $e(_0x43d289['visibleWrites'],_0x7d9701);}function mu(_0x403bac,_0x3416a0,_0x87138b,_0x1e7e16,_0x56acfc,_0x4c3c44,_0x4189d5){let _0x1d299c;const _0x5af612=ve(_0x403bac['visibleWrites'],_0x3416a0),_0xc64340=$e(_0x5af612,w());if(_0xc64340!=null)_0x1d299c=_0xc64340;else{if(_0x87138b!=null)_0x1d299c=it(_0x5af612,_0x87138b);else return[];}if(_0x1d299c=_0x1d299c['withIndex'](_0x4189d5),!_0x1d299c['isEmpty']()&&!_0x1d299c['isLeafNode']()){const _0x525d55=[],_0x4b0ebe=_0x4189d5['getCompare'](),_0x213428=_0x4c3c44?_0x1d299c['getReverseIteratorFrom'](_0x1e7e16,_0x4189d5):_0x1d299c['getIteratorFrom'](_0x1e7e16,_0x4189d5);let _0x88d0e3=_0x213428['getNext']();for(;_0x88d0e3&&_0x525d55['length']<_0x56acfc;)_0x4b0ebe(_0x88d0e3,_0x1e7e16)!==0x0&&_0x525d55['push'](_0x88d0e3),_0x88d0e3=_0x213428['getNext']();return _0x525d55;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x4e8cb3,_0x149a24,_0x9b743c,_0x4b87d3){return Uo(_0x4e8cb3['writeTree'],_0x4e8cb3['treePath'],_0x149a24,_0x9b743c,_0x4b87d3);}function es(_0x598b40,_0xafda85){return fu(_0x598b40['writeTree'],_0x598b40['treePath'],_0xafda85);}function or(_0x3735c6,_0x4e75fb,_0x3338c9,_0x331bd5){return pu(_0x3735c6['writeTree'],_0x3735c6['treePath'],_0x4e75fb,_0x3338c9,_0x331bd5);}function yn(_0x23ef83,_0x197334){return gu(_0x23ef83['writeTree'],A(_0x23ef83['treePath'],_0x197334));}function vu(_0x2e2c6e,_0x516885,_0x48177c,_0x4b64c4,_0x430e78,_0x427f94){return mu(_0x2e2c6e['writeTree'],_0x2e2c6e['treePath'],_0x516885,_0x48177c,_0x4b64c4,_0x430e78,_0x427f94);}function ts(_0x581051,_0x465b21,_0x279151){return _u(_0x581051['writeTree'],_0x581051['treePath'],_0x465b21,_0x279151);}function Wo(_0x965f54,_0x17cf57){return Bo(A(_0x965f54['treePath'],_0x17cf57),_0x965f54['writeTree']);}function Bo(_0x174f4f,_0x295b30){return{'treePath':_0x174f4f,'writeTree':_0x295b30};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4111db){const _0x54b656=_0x4111db['type'],_0x2e03a1=_0x4111db['childName'];f(_0x54b656==='child_added'||_0x54b656==='child_changed'||_0x54b656==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2e03a1!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x23d6ed=this['changeMap']['get'](_0x2e03a1);if(_0x23d6ed){const _0x4c4c2f=_0x23d6ed['type'];if(_0x54b656==='child_added'&&_0x4c4c2f==='child_removed')this['changeMap']['set'](_0x2e03a1,Pt(_0x2e03a1,_0x4111db['snapshotNode'],_0x23d6ed['snapshotNode']));else{if(_0x54b656==='child_removed'&&_0x4c4c2f==='child_added')this['changeMap']['delete'](_0x2e03a1);else{if(_0x54b656==='child_removed'&&_0x4c4c2f==='child_changed')this['changeMap']['set'](_0x2e03a1,Nt(_0x2e03a1,_0x23d6ed['oldSnap']));else{if(_0x54b656==='child_changed'&&_0x4c4c2f==='child_added')this['changeMap']['set'](_0x2e03a1,tt(_0x2e03a1,_0x4111db['snapshotNode']));else{if(_0x54b656==='child_changed'&&_0x4c4c2f==='child_changed')this['changeMap']['set'](_0x2e03a1,Pt(_0x2e03a1,_0x4111db['snapshotNode'],_0x23d6ed['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x4111db+'\x20occurred\x20after\x20'+_0x23d6ed);}}}}}else this['changeMap']['set'](_0x2e03a1,_0x4111db);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x4a00b3){return null;}['getChildAfterChild'](_0x1f7ccb,_0x3034c4,_0x20caab){return null;}}const Vo=new Iu();class ns{constructor(_0x23f7bd,_0x218335,_0x108124=null){this['writes_']=_0x23f7bd,this['viewCache_']=_0x218335,this['optCompleteServerCache_']=_0x108124;}['getCompleteChild'](_0x1c2ec4){const _0x4d88c=this['viewCache_']['eventCache'];if(_0x4d88c['isCompleteForChild'](_0x1c2ec4))return _0x4d88c['getNode']()['getImmediateChild'](_0x1c2ec4);{const _0x17e418=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x1c2ec4,_0x17e418);}}['getChildAfterChild'](_0x371c76,_0x531672,_0x14b98e){const _0x2cb7ab=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x372f3a=vu(this['writes_'],_0x2cb7ab,_0x531672,0x1,_0x14b98e,_0x371c76);return _0x372f3a['length']===0x0?null:_0x372f3a[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x5e23e7){return{'filter':_0x5e23e7};}function Cu(_0x2c58cc,_0x4a8085){f(_0x4a8085['eventCache']['getNode']()['isIndexed'](_0x2c58cc['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4a8085['serverCache']['getNode']()['isIndexed'](_0x2c58cc['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x132dc1,_0x303f7a,_0x2cc07e,_0x2a3577,_0x46a88){const _0x59d588=new Eu();let _0x34de4b,_0x5b797b;if(_0x2cc07e['type']===q['OVERWRITE']){const _0x45c6eb=_0x2cc07e;_0x45c6eb['source']['fromUser']?_0x34de4b=Ti(_0x132dc1,_0x303f7a,_0x45c6eb['path'],_0x45c6eb['snap'],_0x2a3577,_0x46a88,_0x59d588):(f(_0x45c6eb['source']['fromServer'],'Unknown\x20source.'),_0x5b797b=_0x45c6eb['source']['tagged']||_0x303f7a['serverCache']['isFiltered']()&&!v(_0x45c6eb['path']),_0x34de4b=vn(_0x132dc1,_0x303f7a,_0x45c6eb['path'],_0x45c6eb['snap'],_0x2a3577,_0x46a88,_0x5b797b,_0x59d588));}else{if(_0x2cc07e['type']===q['MERGE']){const _0x3fe2b0=_0x2cc07e;_0x3fe2b0['source']['fromUser']?_0x34de4b=bu(_0x132dc1,_0x303f7a,_0x3fe2b0['path'],_0x3fe2b0['children'],_0x2a3577,_0x46a88,_0x59d588):(f(_0x3fe2b0['source']['fromServer'],'Unknown\x20source.'),_0x5b797b=_0x3fe2b0['source']['tagged']||_0x303f7a['serverCache']['isFiltered'](),_0x34de4b=Si(_0x132dc1,_0x303f7a,_0x3fe2b0['path'],_0x3fe2b0['children'],_0x2a3577,_0x46a88,_0x5b797b,_0x59d588));}else{if(_0x2cc07e['type']===q['ACK_USER_WRITE']){const _0xf233cb=_0x2cc07e;_0xf233cb['revert']?_0x34de4b=ku(_0x132dc1,_0x303f7a,_0xf233cb['path'],_0x2a3577,_0x46a88,_0x59d588):_0x34de4b=Ru(_0x132dc1,_0x303f7a,_0xf233cb['path'],_0xf233cb['affectedTree'],_0x2a3577,_0x46a88,_0x59d588);}else{if(_0x2cc07e['type']===q['LISTEN_COMPLETE'])_0x34de4b=Au(_0x132dc1,_0x303f7a,_0x2cc07e['path'],_0x2a3577,_0x59d588);else throw ot('Unknown\x20operation\x20type:\x20'+_0x2cc07e['type']);}}}const _0x259e52=_0x59d588['getChanges']();return Su(_0x303f7a,_0x34de4b,_0x259e52),{'viewCache':_0x34de4b,'changes':_0x259e52};}function Su(_0x2d2247,_0x591d6,_0x5372c2){const _0x24cf04=_0x591d6['eventCache'];if(_0x24cf04['isFullyInitialized']()){const _0x47e47f=_0x24cf04['getNode']()['isLeafNode']()||_0x24cf04['getNode']()['isEmpty'](),_0x40952a=gn(_0x2d2247);(_0x5372c2['length']>0x0||!_0x2d2247['eventCache']['isFullyInitialized']()||_0x47e47f&&!_0x24cf04['getNode']()['equals'](_0x40952a)||!_0x24cf04['getNode']()['getPriority']()['equals'](_0x40952a['getPriority']()))&&_0x5372c2['push'](Oo(gn(_0x591d6)));}}function Ho(_0x3c8e76,_0x14e1b5,_0x36440b,_0x13d13d,_0x55f798,_0x3db0e2){const _0x519bc4=_0x14e1b5['eventCache'];if(yn(_0x13d13d,_0x36440b)!=null)return _0x14e1b5;{let _0x40905b,_0x121a15;if(v(_0x36440b)){if(f(_0x14e1b5['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x14e1b5['serverCache']['isFiltered']()){const _0x4223e7=Ue(_0x14e1b5),_0x1b92ad=_0x4223e7 instanceof g?_0x4223e7:g['EMPTY_NODE'],_0x3a7a8d=es(_0x13d13d,_0x1b92ad);_0x40905b=_0x3c8e76['filter']['updateFullNode'](_0x14e1b5['eventCache']['getNode'](),_0x3a7a8d,_0x3db0e2);}else{const _0x5abdc0=mn(_0x13d13d,Ue(_0x14e1b5));_0x40905b=_0x3c8e76['filter']['updateFullNode'](_0x14e1b5['eventCache']['getNode'](),_0x5abdc0,_0x3db0e2);}}else{const _0x1cd5d5=y(_0x36440b);if(_0x1cd5d5==='.priority'){f(we(_0x36440b)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1c8761=_0x519bc4['getNode']();_0x121a15=_0x14e1b5['serverCache']['getNode']();const _0x52a1fb=or(_0x13d13d,_0x36440b,_0x1c8761,_0x121a15);_0x52a1fb!=null?_0x40905b=_0x3c8e76['filter']['updatePriority'](_0x1c8761,_0x52a1fb):_0x40905b=_0x519bc4['getNode']();}else{const _0x51cc0d=b(_0x36440b);let _0x3940ba;if(_0x519bc4['isCompleteForChild'](_0x1cd5d5)){_0x121a15=_0x14e1b5['serverCache']['getNode']();const _0x181937=or(_0x13d13d,_0x36440b,_0x519bc4['getNode'](),_0x121a15);_0x181937!=null?_0x3940ba=_0x519bc4['getNode']()['getImmediateChild'](_0x1cd5d5)['updateChild'](_0x51cc0d,_0x181937):_0x3940ba=_0x519bc4['getNode']()['getImmediateChild'](_0x1cd5d5);}else _0x3940ba=ts(_0x13d13d,_0x1cd5d5,_0x14e1b5['serverCache']);_0x3940ba!=null?_0x40905b=_0x3c8e76['filter']['updateChild'](_0x519bc4['getNode'](),_0x1cd5d5,_0x3940ba,_0x51cc0d,_0x55f798,_0x3db0e2):_0x40905b=_0x519bc4['getNode']();}}return wt(_0x14e1b5,_0x40905b,_0x519bc4['isFullyInitialized']()||v(_0x36440b),_0x3c8e76['filter']['filtersNodes']());}}function vn(_0x5ead3b,_0x137bb7,_0x758450,_0x2b18cb,_0x226ffb,_0x4ef42a,_0x14d0a1,_0x36f210){const _0x330b24=_0x137bb7['serverCache'];let _0x153dd1;const _0x366a79=_0x14d0a1?_0x5ead3b['filter']:_0x5ead3b['filter']['getIndexedFilter']();if(v(_0x758450))_0x153dd1=_0x366a79['updateFullNode'](_0x330b24['getNode'](),_0x2b18cb,null);else{if(_0x366a79['filtersNodes']()&&!_0x330b24['isFiltered']()){const _0x2d68d4=_0x330b24['getNode']()['updateChild'](_0x758450,_0x2b18cb);_0x153dd1=_0x366a79['updateFullNode'](_0x330b24['getNode'](),_0x2d68d4,null);}else{const _0x3f5171=y(_0x758450);if(!_0x330b24['isCompleteForPath'](_0x758450)&&we(_0x758450)>0x1)return _0x137bb7;const _0x209e83=b(_0x758450),_0xfcc135=_0x330b24['getNode']()['getImmediateChild'](_0x3f5171)['updateChild'](_0x209e83,_0x2b18cb);_0x3f5171==='.priority'?_0x153dd1=_0x366a79['updatePriority'](_0x330b24['getNode'](),_0xfcc135):_0x153dd1=_0x366a79['updateChild'](_0x330b24['getNode'](),_0x3f5171,_0xfcc135,_0x209e83,Vo,null);}}const _0x14b86b=Lo(_0x137bb7,_0x153dd1,_0x330b24['isFullyInitialized']()||v(_0x758450),_0x366a79['filtersNodes']()),_0x43d339=new ns(_0x226ffb,_0x14b86b,_0x4ef42a);return Ho(_0x5ead3b,_0x14b86b,_0x758450,_0x226ffb,_0x43d339,_0x36f210);}function Ti(_0xd1d78d,_0x28ad30,_0x1fe18f,_0x5c768b,_0x4f4360,_0x175366,_0x2d5a0c){const _0x4f0839=_0x28ad30['eventCache'];let _0x3c08bc,_0x33e301;const _0x27e4f4=new ns(_0x4f4360,_0x28ad30,_0x175366);if(v(_0x1fe18f))_0x33e301=_0xd1d78d['filter']['updateFullNode'](_0x28ad30['eventCache']['getNode'](),_0x5c768b,_0x2d5a0c),_0x3c08bc=wt(_0x28ad30,_0x33e301,!0x0,_0xd1d78d['filter']['filtersNodes']());else{const _0x52bc6c=y(_0x1fe18f);if(_0x52bc6c==='.priority')_0x33e301=_0xd1d78d['filter']['updatePriority'](_0x28ad30['eventCache']['getNode'](),_0x5c768b),_0x3c08bc=wt(_0x28ad30,_0x33e301,_0x4f0839['isFullyInitialized'](),_0x4f0839['isFiltered']());else{const _0x2d82e2=b(_0x1fe18f),_0x48dbd2=_0x4f0839['getNode']()['getImmediateChild'](_0x52bc6c);let _0x1b1b34;if(v(_0x2d82e2))_0x1b1b34=_0x5c768b;else{const _0x3379da=_0x27e4f4['getCompleteChild'](_0x52bc6c);_0x3379da!=null?Gi(_0x2d82e2)==='.priority'&&_0x3379da['getChild'](To(_0x2d82e2))['isEmpty']()?_0x1b1b34=_0x3379da:_0x1b1b34=_0x3379da['updateChild'](_0x2d82e2,_0x5c768b):_0x1b1b34=g['EMPTY_NODE'];}if(_0x48dbd2['equals'](_0x1b1b34))_0x3c08bc=_0x28ad30;else{const _0x43d581=_0xd1d78d['filter']['updateChild'](_0x4f0839['getNode'](),_0x52bc6c,_0x1b1b34,_0x2d82e2,_0x27e4f4,_0x2d5a0c);_0x3c08bc=wt(_0x28ad30,_0x43d581,_0x4f0839['isFullyInitialized'](),_0xd1d78d['filter']['filtersNodes']());}}}return _0x3c08bc;}function ar(_0x4be1a6,_0x178a95){return _0x4be1a6['eventCache']['isCompleteForChild'](_0x178a95);}function bu(_0x25e801,_0x3b60b,_0x27be42,_0x562f11,_0x58bf7a,_0x419f9f,_0x17c61d){let _0x36118d=_0x3b60b;return _0x562f11['foreach']((_0xee412,_0x53faa8)=>{const _0x587bfb=A(_0x27be42,_0xee412);ar(_0x3b60b,y(_0x587bfb))&&(_0x36118d=Ti(_0x25e801,_0x36118d,_0x587bfb,_0x53faa8,_0x58bf7a,_0x419f9f,_0x17c61d));}),_0x562f11['foreach']((_0x3b0e83,_0x3e83b4)=>{const _0x5d6b56=A(_0x27be42,_0x3b0e83);ar(_0x3b60b,y(_0x5d6b56))||(_0x36118d=Ti(_0x25e801,_0x36118d,_0x5d6b56,_0x3e83b4,_0x58bf7a,_0x419f9f,_0x17c61d));}),_0x36118d;}function cr(_0x186d5d,_0x55549f,_0x16ad77){return _0x16ad77['foreach']((_0x2463ea,_0x1b0120)=>{_0x55549f=_0x55549f['updateChild'](_0x2463ea,_0x1b0120);}),_0x55549f;}function Si(_0x40d130,_0x53c1d7,_0x3370be,_0x5ca317,_0x2af884,_0x466160,_0x181dc0,_0x2872f7){if(_0x53c1d7['serverCache']['getNode']()['isEmpty']()&&!_0x53c1d7['serverCache']['isFullyInitialized']())return _0x53c1d7;let _0x2068d4=_0x53c1d7,_0x5891a6;v(_0x3370be)?_0x5891a6=_0x5ca317:_0x5891a6=new S(null)['setTree'](_0x3370be,_0x5ca317);const _0x58ee90=_0x53c1d7['serverCache']['getNode']();return _0x5891a6['children']['inorderTraversal']((_0x3ae0cb,_0x2d09a9)=>{if(_0x58ee90['hasChild'](_0x3ae0cb)){const _0x5f31a3=_0x53c1d7['serverCache']['getNode']()['getImmediateChild'](_0x3ae0cb),_0x4af17e=cr(_0x40d130,_0x5f31a3,_0x2d09a9);_0x2068d4=vn(_0x40d130,_0x2068d4,new C(_0x3ae0cb),_0x4af17e,_0x2af884,_0x466160,_0x181dc0,_0x2872f7);}}),_0x5891a6['children']['inorderTraversal']((_0x13d99c,_0x22ebeb)=>{const _0x55dad2=!_0x53c1d7['serverCache']['isCompleteForChild'](_0x13d99c)&&_0x22ebeb['value']===null;if(!_0x58ee90['hasChild'](_0x13d99c)&&!_0x55dad2){const _0x5c969b=_0x53c1d7['serverCache']['getNode']()['getImmediateChild'](_0x13d99c),_0x4ca733=cr(_0x40d130,_0x5c969b,_0x22ebeb);_0x2068d4=vn(_0x40d130,_0x2068d4,new C(_0x13d99c),_0x4ca733,_0x2af884,_0x466160,_0x181dc0,_0x2872f7);}}),_0x2068d4;}function Ru(_0x3eea0f,_0x5b1f10,_0x28b744,_0x5669bc,_0x5e1e0b,_0x4bb979,_0x261187){if(yn(_0x5e1e0b,_0x28b744)!=null)return _0x5b1f10;const _0x14a270=_0x5b1f10['serverCache']['isFiltered'](),_0x509dff=_0x5b1f10['serverCache'];if(_0x5669bc['value']!=null){if(v(_0x28b744)&&_0x509dff['isFullyInitialized']()||_0x509dff['isCompleteForPath'](_0x28b744))return vn(_0x3eea0f,_0x5b1f10,_0x28b744,_0x509dff['getNode']()['getChild'](_0x28b744),_0x5e1e0b,_0x4bb979,_0x14a270,_0x261187);if(v(_0x28b744)){let _0x2052c9=new S(null);return _0x509dff['getNode']()['forEachChild'](ye,(_0x327be7,_0xa2be53)=>{_0x2052c9=_0x2052c9['set'](new C(_0x327be7),_0xa2be53);}),Si(_0x3eea0f,_0x5b1f10,_0x28b744,_0x2052c9,_0x5e1e0b,_0x4bb979,_0x14a270,_0x261187);}else return _0x5b1f10;}else{let _0x4b9085=new S(null);return _0x5669bc['foreach']((_0x3a5a91,_0xd97894)=>{const _0x2caa5b=A(_0x28b744,_0x3a5a91);_0x509dff['isCompleteForPath'](_0x2caa5b)&&(_0x4b9085=_0x4b9085['set'](_0x3a5a91,_0x509dff['getNode']()['getChild'](_0x2caa5b)));}),Si(_0x3eea0f,_0x5b1f10,_0x28b744,_0x4b9085,_0x5e1e0b,_0x4bb979,_0x14a270,_0x261187);}}function Au(_0x36615f,_0x16acd2,_0x2ead2f,_0x6241f9,_0x33f006){const _0x28bd36=_0x16acd2['serverCache'],_0x46a6a4=Lo(_0x16acd2,_0x28bd36['getNode'](),_0x28bd36['isFullyInitialized']()||v(_0x2ead2f),_0x28bd36['isFiltered']());return Ho(_0x36615f,_0x46a6a4,_0x2ead2f,_0x6241f9,Vo,_0x33f006);}function ku(_0x3c4b25,_0x4628ff,_0x38644f,_0x2af2be,_0x46f90f,_0x39b396){let _0x1ed2dd;if(yn(_0x2af2be,_0x38644f)!=null)return _0x4628ff;{const _0x4c3e31=new ns(_0x2af2be,_0x4628ff,_0x46f90f),_0x6dad67=_0x4628ff['eventCache']['getNode']();let _0x3aac81;if(v(_0x38644f)||y(_0x38644f)==='.priority'){let _0x49ac52;if(_0x4628ff['serverCache']['isFullyInitialized']())_0x49ac52=mn(_0x2af2be,Ue(_0x4628ff));else{const _0x1611e4=_0x4628ff['serverCache']['getNode']();f(_0x1611e4 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x49ac52=es(_0x2af2be,_0x1611e4);}_0x49ac52=_0x49ac52,_0x3aac81=_0x3c4b25['filter']['updateFullNode'](_0x6dad67,_0x49ac52,_0x39b396);}else{const _0x340d5b=y(_0x38644f);let _0x418f96=ts(_0x2af2be,_0x340d5b,_0x4628ff['serverCache']);_0x418f96==null&&_0x4628ff['serverCache']['isCompleteForChild'](_0x340d5b)&&(_0x418f96=_0x6dad67['getImmediateChild'](_0x340d5b)),_0x418f96!=null?_0x3aac81=_0x3c4b25['filter']['updateChild'](_0x6dad67,_0x340d5b,_0x418f96,b(_0x38644f),_0x4c3e31,_0x39b396):_0x4628ff['eventCache']['getNode']()['hasChild'](_0x340d5b)?_0x3aac81=_0x3c4b25['filter']['updateChild'](_0x6dad67,_0x340d5b,g['EMPTY_NODE'],b(_0x38644f),_0x4c3e31,_0x39b396):_0x3aac81=_0x6dad67,_0x3aac81['isEmpty']()&&_0x4628ff['serverCache']['isFullyInitialized']()&&(_0x1ed2dd=mn(_0x2af2be,Ue(_0x4628ff)),_0x1ed2dd['isLeafNode']()&&(_0x3aac81=_0x3c4b25['filter']['updateFullNode'](_0x3aac81,_0x1ed2dd,_0x39b396)));}return _0x1ed2dd=_0x4628ff['serverCache']['isFullyInitialized']()||yn(_0x2af2be,w())!=null,wt(_0x4628ff,_0x3aac81,_0x1ed2dd,_0x3c4b25['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x19c854,_0x9714bc){this['query_']=_0x19c854,this['eventRegistrations_']=[];const _0x267420=this['query_']['_queryParams'],_0x164ff4=new Yi(_0x267420['getIndex']()),_0x2d1cdb=qh(_0x267420);this['processor_']=wu(_0x2d1cdb);const _0x160ecd=_0x9714bc['serverCache'],_0x2e0b05=_0x9714bc['eventCache'],_0x29399e=_0x164ff4['updateFullNode'](g['EMPTY_NODE'],_0x160ecd['getNode'](),null),_0x24203d=_0x2d1cdb['updateFullNode'](g['EMPTY_NODE'],_0x2e0b05['getNode'](),null),_0x251212=new Ce(_0x29399e,_0x160ecd['isFullyInitialized'](),_0x164ff4['filtersNodes']()),_0x72e94=new Ce(_0x24203d,_0x2e0b05['isFullyInitialized'](),_0x2d1cdb['filtersNodes']());this['viewCache_']=Dn(_0x72e94,_0x251212),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x14ef92){return _0x14ef92['viewCache_']['serverCache']['getNode']();}function Ou(_0x5464ab){return gn(_0x5464ab['viewCache_']);}function Du(_0x56c808,_0x100f4f){const _0x13a77e=Ue(_0x56c808['viewCache_']);return _0x13a77e&&(_0x56c808['query']['_queryParams']['loadsAllData']()||!v(_0x100f4f)&&!_0x13a77e['getImmediateChild'](y(_0x100f4f))['isEmpty']())?_0x13a77e['getChild'](_0x100f4f):null;}function lr(_0x245784){return _0x245784['eventRegistrations_']['length']===0x0;}function Mu(_0x19ee8c,_0x523de4){_0x19ee8c['eventRegistrations_']['push'](_0x523de4);}function hr(_0x457e57,_0x310376,_0x489333){const _0x1c9796=[];if(_0x489333){f(_0x310376==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x58d335=_0x457e57['query']['_path'];_0x457e57['eventRegistrations_']['forEach'](_0x9d3309=>{const _0x269f08=_0x9d3309['createCancelEvent'](_0x489333,_0x58d335);_0x269f08&&_0x1c9796['push'](_0x269f08);});}if(_0x310376){let _0x399a5c=[];for(let _0x2e17d2=0x0;_0x2e17d2<_0x457e57['eventRegistrations_']['length'];++_0x2e17d2){const _0x5332e5=_0x457e57['eventRegistrations_'][_0x2e17d2];if(!_0x5332e5['matches'](_0x310376))_0x399a5c['push'](_0x5332e5);else{if(_0x310376['hasAnyCallback']()){_0x399a5c=_0x399a5c['concat'](_0x457e57['eventRegistrations_']['slice'](_0x2e17d2+0x1));break;}}}_0x457e57['eventRegistrations_']=_0x399a5c;}else _0x457e57['eventRegistrations_']=[];return _0x1c9796;}function ur(_0x2f4149,_0x3f8e70,_0x8a742b,_0x9ba148){_0x3f8e70['type']===q['MERGE']&&_0x3f8e70['source']['queryId']!==null&&(f(Ue(_0x2f4149['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x2f4149['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0xe16eca=_0x2f4149['viewCache_'],_0x564850=Tu(_0x2f4149['processor_'],_0xe16eca,_0x3f8e70,_0x8a742b,_0x9ba148);return Cu(_0x2f4149['processor_'],_0x564850['viewCache']),f(_0x564850['viewCache']['serverCache']['isFullyInitialized']()||!_0xe16eca['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2f4149['viewCache_']=_0x564850['viewCache'],$o(_0x2f4149,_0x564850['changes'],_0x564850['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x243cb8,_0x24a527){const _0x16e070=_0x243cb8['viewCache_']['eventCache'],_0x1715b4=[];return _0x16e070['getNode']()['isLeafNode']()||_0x16e070['getNode']()['forEachChild'](R,(_0x3a3185,_0x40ff35)=>{_0x1715b4['push'](tt(_0x3a3185,_0x40ff35));}),_0x16e070['isFullyInitialized']()&&_0x1715b4['push'](Oo(_0x16e070['getNode']())),$o(_0x243cb8,_0x1715b4,_0x16e070['getNode'](),_0x24a527);}function $o(_0x3fe52e,_0xbfd76b,_0xffa634,_0x1d7aa0){const _0x5ad784=_0x1d7aa0?[_0x1d7aa0]:_0x3fe52e['eventRegistrations_'];return nu(_0x3fe52e['eventGenerator_'],_0xbfd76b,_0xffa634,_0x5ad784);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x3bf2d3){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x3bf2d3;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x49c954){return _0x49c954['views']['size']===0x0;}function is(_0x38685a,_0x1514c8,_0x5d90f7,_0x3de9a9){const _0x48582e=_0x1514c8['source']['queryId'];if(_0x48582e!==null){const _0x2665e2=_0x38685a['views']['get'](_0x48582e);return f(_0x2665e2!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x2665e2,_0x1514c8,_0x5d90f7,_0x3de9a9);}else{let _0x218f23=[];for(const _0x4fbf3d of _0x38685a['views']['values']())_0x218f23=_0x218f23['concat'](ur(_0x4fbf3d,_0x1514c8,_0x5d90f7,_0x3de9a9));return _0x218f23;}}function qo(_0x19266a,_0x87587e,_0x23a1d0,_0x5d9f93,_0x46beda){const _0x25ec80=_0x87587e['_queryIdentifier'],_0x53ebd4=_0x19266a['views']['get'](_0x25ec80);if(!_0x53ebd4){let _0x5f451c=mn(_0x23a1d0,_0x46beda?_0x5d9f93:null),_0x196de6=!0x1;_0x5f451c?_0x196de6=!0x0:_0x5d9f93 instanceof g?(_0x5f451c=es(_0x23a1d0,_0x5d9f93),_0x196de6=!0x1):(_0x5f451c=g['EMPTY_NODE'],_0x196de6=!0x1);const _0x2eab12=Dn(new Ce(_0x5f451c,_0x196de6,!0x1),new Ce(_0x5d9f93,_0x46beda,!0x1));return new Nu(_0x87587e,_0x2eab12);}return _0x53ebd4;}function Wu(_0x498c8b,_0x8f5971,_0x3509c4,_0x4b9a5a,_0x5a6213,_0x369719){const _0x426152=qo(_0x498c8b,_0x8f5971,_0x4b9a5a,_0x5a6213,_0x369719);return _0x498c8b['views']['has'](_0x8f5971['_queryIdentifier'])||_0x498c8b['views']['set'](_0x8f5971['_queryIdentifier'],_0x426152),Mu(_0x426152,_0x3509c4),Lu(_0x426152,_0x3509c4);}function Bu(_0x2173cb,_0x29aab5,_0x37201b,_0x114936){const _0x1072f9=_0x29aab5['_queryIdentifier'],_0x5f5559=[];let _0x58a5df=[];const _0x16303d=Te(_0x2173cb);if(_0x1072f9==='default'){for(const [_0x4776c2,_0x4c663c]of _0x2173cb['views']['entries']())_0x58a5df=_0x58a5df['concat'](hr(_0x4c663c,_0x37201b,_0x114936)),lr(_0x4c663c)&&(_0x2173cb['views']['delete'](_0x4776c2),_0x4c663c['query']['_queryParams']['loadsAllData']()||_0x5f5559['push'](_0x4c663c['query']));}else{const _0xe0d2b8=_0x2173cb['views']['get'](_0x1072f9);_0xe0d2b8&&(_0x58a5df=_0x58a5df['concat'](hr(_0xe0d2b8,_0x37201b,_0x114936)),lr(_0xe0d2b8)&&(_0x2173cb['views']['delete'](_0x1072f9),_0xe0d2b8['query']['_queryParams']['loadsAllData']()||_0x5f5559['push'](_0xe0d2b8['query'])));}return _0x16303d&&!Te(_0x2173cb)&&_0x5f5559['push'](new(Fu())(_0x29aab5['_repo'],_0x29aab5['_path'])),{'removed':_0x5f5559,'events':_0x58a5df};}function zo(_0x5a4ab3){const _0x4febf2=[];for(const _0x50db5e of _0x5a4ab3['views']['values']())_0x50db5e['query']['_queryParams']['loadsAllData']()||_0x4febf2['push'](_0x50db5e);return _0x4febf2;}function Ee(_0x3f72dc,_0x4130cd){let _0x33fdc2=null;for(const _0x481ebe of _0x3f72dc['views']['values']())_0x33fdc2=_0x33fdc2||Du(_0x481ebe,_0x4130cd);return _0x33fdc2;}function jo(_0x449c87,_0xea0d60){if(_0xea0d60['_queryParams']['loadsAllData']())return Ln(_0x449c87);{const _0x5060b6=_0xea0d60['_queryIdentifier'];return _0x449c87['views']['get'](_0x5060b6);}}function Ko(_0x2f4610,_0x62029){return jo(_0x2f4610,_0x62029)!=null;}function Te(_0x2f9c53){return Ln(_0x2f9c53)!=null;}function Ln(_0x94219f){for(const _0x73133b of _0x94219f['views']['values']())if(_0x73133b['query']['_queryParams']['loadsAllData']())return _0x73133b;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x475ce1){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x475ce1;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x1f4b98){this['listenProvider_']=_0x1f4b98,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x38c468,_0x18a49e,_0x2b0b0c,_0x3f6c90,_0x4ffac1){return ou(_0x38c468['pendingWriteTree_'],_0x18a49e,_0x2b0b0c,_0x3f6c90,_0x4ffac1),_0x4ffac1?ht(_0x38c468,new Fe(Ji(),_0x18a49e,_0x2b0b0c)):[];}function Gu(_0x42576c,_0x49fcb4,_0x9260c9,_0x3a4113){au(_0x42576c['pendingWriteTree_'],_0x49fcb4,_0x9260c9,_0x3a4113);const _0x2b89f0=S['fromObject'](_0x9260c9);return ht(_0x42576c,new nt(Ji(),_0x49fcb4,_0x2b89f0));}function pe(_0x5b1b5e,_0x3a5789,_0x1ac504=!0x1){const _0x539089=cu(_0x5b1b5e['pendingWriteTree_'],_0x3a5789);if(lu(_0x5b1b5e['pendingWriteTree_'],_0x3a5789)){let _0x55d53a=new S(null);return _0x539089['snap']!=null?_0x55d53a=_0x55d53a['set'](w(),!0x0):x(_0x539089['children'],_0x1d99f5=>{_0x55d53a=_0x55d53a['set'](new C(_0x1d99f5),!0x0);}),ht(_0x5b1b5e,new _n(_0x539089['path'],_0x55d53a,_0x1ac504));}else return[];}function $t(_0x52ccf1,_0x4b73a8,_0x14a8f3){return ht(_0x52ccf1,new Fe(Xi(),_0x4b73a8,_0x14a8f3));}function qu(_0x9b6741,_0x1b3f5e,_0x34af80){const _0x1c822c=S['fromObject'](_0x34af80);return ht(_0x9b6741,new nt(Xi(),_0x1b3f5e,_0x1c822c));}function zu(_0x56065f,_0x2597c2){return ht(_0x56065f,new Dt(Xi(),_0x2597c2));}function ju(_0x4c7c9c,_0x1d5ab5,_0x4f907e){const _0x47a191=rs(_0x4c7c9c,_0x4f907e);if(_0x47a191){const _0x548510=os(_0x47a191),_0x14c3d3=_0x548510['path'],_0x12872e=_0x548510['queryId'],_0xca992c=F(_0x14c3d3,_0x1d5ab5),_0x444f47=new Dt(Zi(_0x12872e),_0xca992c);return as(_0x4c7c9c,_0x14c3d3,_0x444f47);}else return[];}function wn(_0x5c4310,_0x5b3c25,_0x3307d0,_0x17748d,_0x2584b0=!0x1){const _0x3b0a36=_0x5b3c25['_path'],_0x31a148=_0x5c4310['syncPointTree_']['get'](_0x3b0a36);let _0x451cf3=[];if(_0x31a148&&(_0x5b3c25['_queryIdentifier']==='default'||Ko(_0x31a148,_0x5b3c25))){const _0x4d09a4=Bu(_0x31a148,_0x5b3c25,_0x3307d0,_0x17748d);Uu(_0x31a148)&&(_0x5c4310['syncPointTree_']=_0x5c4310['syncPointTree_']['remove'](_0x3b0a36));const _0x1d4009=_0x4d09a4['removed'];if(_0x451cf3=_0x4d09a4['events'],!_0x2584b0){const _0x226798=_0x1d4009['findIndex'](_0x4f3c6f=>_0x4f3c6f['_queryParams']['loadsAllData']())!==-0x1,_0x3090a8=_0x5c4310['syncPointTree_']['findOnPath'](_0x3b0a36,(_0x3a809f,_0x396526)=>Te(_0x396526));if(_0x226798&&!_0x3090a8){const _0x1f3402=_0x5c4310['syncPointTree_']['subtree'](_0x3b0a36);if(!_0x1f3402['isEmpty']()){const _0x1f14a3=Qu(_0x1f3402);for(let _0x26fdc0=0x0;_0x26fdc0<_0x1f14a3['length'];++_0x26fdc0){const _0x414dd1=_0x1f14a3[_0x26fdc0],_0x4e75a2=_0x414dd1['query'],_0x253a0f=Xo(_0x5c4310,_0x414dd1);_0x5c4310['listenProvider_']['startListening'](Tt(_0x4e75a2),Mt(_0x5c4310,_0x4e75a2),_0x253a0f['hashFn'],_0x253a0f['onComplete']);}}}!_0x3090a8&&_0x1d4009['length']>0x0&&!_0x17748d&&(_0x226798?_0x5c4310['listenProvider_']['stopListening'](Tt(_0x5b3c25),null):_0x1d4009['forEach'](_0x7b2b6c=>{const _0x3ff742=_0x5c4310['queryToTagMap']['get'](Fn(_0x7b2b6c));_0x5c4310['listenProvider_']['stopListening'](Tt(_0x7b2b6c),_0x3ff742);}));}Ju(_0x5c4310,_0x1d4009);}return _0x451cf3;}function Yo(_0x7dc684,_0x34cde6,_0x3af044,_0x3415a5){const _0x1cf654=rs(_0x7dc684,_0x3415a5);if(_0x1cf654!=null){const _0x5e139e=os(_0x1cf654),_0x31b308=_0x5e139e['path'],_0x5422f3=_0x5e139e['queryId'],_0x3f9af9=F(_0x31b308,_0x34cde6),_0x46a818=new Fe(Zi(_0x5422f3),_0x3f9af9,_0x3af044);return as(_0x7dc684,_0x31b308,_0x46a818);}else return[];}function Ku(_0x15b70b,_0x3be36f,_0x204006,_0x7f9886){const _0x31bf26=rs(_0x15b70b,_0x7f9886);if(_0x31bf26){const _0xa6972d=os(_0x31bf26),_0x79d9c=_0xa6972d['path'],_0x406b0d=_0xa6972d['queryId'],_0x1c90c2=F(_0x79d9c,_0x3be36f),_0x225c53=S['fromObject'](_0x204006),_0x4ea4fe=new nt(Zi(_0x406b0d),_0x1c90c2,_0x225c53);return as(_0x15b70b,_0x79d9c,_0x4ea4fe);}else return[];}function bi(_0x5f0d83,_0x101caa,_0x40d92c,_0x1add15=!0x1){const _0x204cbd=_0x101caa['_path'];let _0x442d0c=null,_0x22ac61=!0x1;_0x5f0d83['syncPointTree_']['foreachOnPath'](_0x204cbd,(_0x5ed5f2,_0x4fa343)=>{const _0x200939=F(_0x5ed5f2,_0x204cbd);_0x442d0c=_0x442d0c||Ee(_0x4fa343,_0x200939),_0x22ac61=_0x22ac61||Te(_0x4fa343);});let _0x56c12d=_0x5f0d83['syncPointTree_']['get'](_0x204cbd);_0x56c12d?(_0x22ac61=_0x22ac61||Te(_0x56c12d),_0x442d0c=_0x442d0c||Ee(_0x56c12d,w())):(_0x56c12d=new Go(),_0x5f0d83['syncPointTree_']=_0x5f0d83['syncPointTree_']['set'](_0x204cbd,_0x56c12d));let _0x58ac52;_0x442d0c!=null?_0x58ac52=!0x0:(_0x58ac52=!0x1,_0x442d0c=g['EMPTY_NODE'],_0x5f0d83['syncPointTree_']['subtree'](_0x204cbd)['foreachChild']((_0x3685bf,_0x344aec)=>{const _0x348ce9=Ee(_0x344aec,w());_0x348ce9&&(_0x442d0c=_0x442d0c['updateImmediateChild'](_0x3685bf,_0x348ce9));}));const _0x4f6467=Ko(_0x56c12d,_0x101caa);if(!_0x4f6467&&!_0x101caa['_queryParams']['loadsAllData']()){const _0x252705=Fn(_0x101caa);f(!_0x5f0d83['queryToTagMap']['has'](_0x252705),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1912d0=Xu();_0x5f0d83['queryToTagMap']['set'](_0x252705,_0x1912d0),_0x5f0d83['tagToQueryMap']['set'](_0x1912d0,_0x252705);}const _0x20ed83=Mn(_0x5f0d83['pendingWriteTree_'],_0x204cbd);let _0x3e228c=Wu(_0x56c12d,_0x101caa,_0x40d92c,_0x20ed83,_0x442d0c,_0x58ac52);if(!_0x4f6467&&!_0x22ac61&&!_0x1add15){const _0xcbf201=jo(_0x56c12d,_0x101caa);_0x3e228c=_0x3e228c['concat'](Zu(_0x5f0d83,_0x101caa,_0xcbf201));}return _0x3e228c;}function xn(_0x3ff178,_0x46fab9,_0x3c9ed1){const _0x448bcd=_0x3ff178['pendingWriteTree_'],_0x32a5c0=_0x3ff178['syncPointTree_']['findOnPath'](_0x46fab9,(_0x4bc177,_0x47a8a4)=>{const _0x5597ab=F(_0x4bc177,_0x46fab9),_0xfbf799=Ee(_0x47a8a4,_0x5597ab);if(_0xfbf799)return _0xfbf799;});return Uo(_0x448bcd,_0x46fab9,_0x32a5c0,_0x3c9ed1,!0x0);}function Yu(_0x29ec56,_0x56b88c){const _0x5398d2=_0x56b88c['_path'];let _0x327822=null;_0x29ec56['syncPointTree_']['foreachOnPath'](_0x5398d2,(_0x2a0051,_0x2dfe6d)=>{const _0x5b1660=F(_0x2a0051,_0x5398d2);_0x327822=_0x327822||Ee(_0x2dfe6d,_0x5b1660);});let _0x8a1abf=_0x29ec56['syncPointTree_']['get'](_0x5398d2);_0x8a1abf?_0x327822=_0x327822||Ee(_0x8a1abf,w()):(_0x8a1abf=new Go(),_0x29ec56['syncPointTree_']=_0x29ec56['syncPointTree_']['set'](_0x5398d2,_0x8a1abf));const _0x1bf96e=_0x327822!=null,_0x114363=_0x1bf96e?new Ce(_0x327822,!0x0,!0x1):null,_0x453cb7=Mn(_0x29ec56['pendingWriteTree_'],_0x56b88c['_path']),_0x167d35=qo(_0x8a1abf,_0x56b88c,_0x453cb7,_0x1bf96e?_0x114363['getNode']():g['EMPTY_NODE'],_0x1bf96e);return Ou(_0x167d35);}function ht(_0x18b470,_0x44b2df){return Qo(_0x44b2df,_0x18b470['syncPointTree_'],null,Mn(_0x18b470['pendingWriteTree_'],w()));}function Qo(_0x5afdbc,_0xff9574,_0xdb388b,_0x456b68){if(v(_0x5afdbc['path']))return Jo(_0x5afdbc,_0xff9574,_0xdb388b,_0x456b68);{const _0x196127=_0xff9574['get'](w());_0xdb388b==null&&_0x196127!=null&&(_0xdb388b=Ee(_0x196127,w()));let _0x4b76b3=[];const _0x2f2f6a=y(_0x5afdbc['path']),_0x2a7c02=_0x5afdbc['operationForChild'](_0x2f2f6a),_0x56be84=_0xff9574['children']['get'](_0x2f2f6a);if(_0x56be84&&_0x2a7c02){const _0x286018=_0xdb388b?_0xdb388b['getImmediateChild'](_0x2f2f6a):null,_0x5f29ef=Wo(_0x456b68,_0x2f2f6a);_0x4b76b3=_0x4b76b3['concat'](Qo(_0x2a7c02,_0x56be84,_0x286018,_0x5f29ef));}return _0x196127&&(_0x4b76b3=_0x4b76b3['concat'](is(_0x196127,_0x5afdbc,_0x456b68,_0xdb388b))),_0x4b76b3;}}function Jo(_0x29c829,_0x37b79b,_0x12ec31,_0x3b6819){const _0x27f2dd=_0x37b79b['get'](w());_0x12ec31==null&&_0x27f2dd!=null&&(_0x12ec31=Ee(_0x27f2dd,w()));let _0x180411=[];return _0x37b79b['children']['inorderTraversal']((_0xc68cbc,_0xab44e7)=>{const _0x267331=_0x12ec31?_0x12ec31['getImmediateChild'](_0xc68cbc):null,_0x37c468=Wo(_0x3b6819,_0xc68cbc),_0x3116e0=_0x29c829['operationForChild'](_0xc68cbc);_0x3116e0&&(_0x180411=_0x180411['concat'](Jo(_0x3116e0,_0xab44e7,_0x267331,_0x37c468)));}),_0x27f2dd&&(_0x180411=_0x180411['concat'](is(_0x27f2dd,_0x29c829,_0x3b6819,_0x12ec31))),_0x180411;}function Xo(_0x439f0b,_0x4810d7){const _0x39e93e=_0x4810d7['query'],_0x3ee9a6=Mt(_0x439f0b,_0x39e93e);return{'hashFn':()=>(Pu(_0x4810d7)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x35a81f=>{if(_0x35a81f==='ok')return _0x3ee9a6?ju(_0x439f0b,_0x39e93e['_path'],_0x3ee9a6):zu(_0x439f0b,_0x39e93e['_path']);{const _0x4d4b0a=ql(_0x35a81f,_0x39e93e);return wn(_0x439f0b,_0x39e93e,null,_0x4d4b0a);}}};}function Mt(_0x33433a,_0xb65cd6){const _0x4d50df=Fn(_0xb65cd6);return _0x33433a['queryToTagMap']['get'](_0x4d50df);}function Fn(_0x9297cd){return _0x9297cd['_path']['toString']()+'$'+_0x9297cd['_queryIdentifier'];}function rs(_0x20154f,_0x2b8b67){return _0x20154f['tagToQueryMap']['get'](_0x2b8b67);}function os(_0x49483d){const _0x22454c=_0x49483d['indexOf']('$');return f(_0x22454c!==-0x1&&_0x22454c<_0x49483d['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x49483d['substr'](_0x22454c+0x1),'path':new C(_0x49483d['substr'](0x0,_0x22454c))};}function as(_0x344e16,_0x676067,_0x261677){const _0x2d9284=_0x344e16['syncPointTree_']['get'](_0x676067);f(_0x2d9284,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3dac74=Mn(_0x344e16['pendingWriteTree_'],_0x676067);return is(_0x2d9284,_0x261677,_0x3dac74,null);}function Qu(_0x47a6e0){return _0x47a6e0['fold']((_0x5779bb,_0x2da5a5,_0x43d303)=>{if(_0x2da5a5&&Te(_0x2da5a5))return[Ln(_0x2da5a5)];{let _0x22cf79=[];return _0x2da5a5&&(_0x22cf79=zo(_0x2da5a5)),x(_0x43d303,(_0x34cdfb,_0x2f70ea)=>{_0x22cf79=_0x22cf79['concat'](_0x2f70ea);}),_0x22cf79;}});}function Tt(_0x405af7){return _0x405af7['_queryParams']['loadsAllData']()&&!_0x405af7['_queryParams']['isDefault']()?new(Hu())(_0x405af7['_repo'],_0x405af7['_path']):_0x405af7;}function Ju(_0x4fbfb5,_0x23ab2a){for(let _0x325e37=0x0;_0x325e37<_0x23ab2a['length'];++_0x325e37){const _0x286391=_0x23ab2a[_0x325e37];if(!_0x286391['_queryParams']['loadsAllData']()){const _0x2bfe09=Fn(_0x286391),_0x2a2a86=_0x4fbfb5['queryToTagMap']['get'](_0x2bfe09);_0x4fbfb5['queryToTagMap']['delete'](_0x2bfe09),_0x4fbfb5['tagToQueryMap']['delete'](_0x2a2a86);}}}function Xu(){return $u++;}function Zu(_0x2b2474,_0x1fea77,_0xb8b3e){const _0x103ef1=_0x1fea77['_path'],_0x4d2dfb=Mt(_0x2b2474,_0x1fea77),_0x32c924=Xo(_0x2b2474,_0xb8b3e),_0x36752f=_0x2b2474['listenProvider_']['startListening'](Tt(_0x1fea77),_0x4d2dfb,_0x32c924['hashFn'],_0x32c924['onComplete']),_0x21564e=_0x2b2474['syncPointTree_']['subtree'](_0x103ef1);if(_0x4d2dfb)f(!Te(_0x21564e['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x14e2dd=_0x21564e['fold']((_0x3a71da,_0x209f37,_0x58e5e5)=>{if(!v(_0x3a71da)&&_0x209f37&&Te(_0x209f37))return[Ln(_0x209f37)['query']];{let _0x44beeb=[];return _0x209f37&&(_0x44beeb=_0x44beeb['concat'](zo(_0x209f37)['map'](_0x5f4286=>_0x5f4286['query']))),x(_0x58e5e5,(_0x44277a,_0x5bfa96)=>{_0x44beeb=_0x44beeb['concat'](_0x5bfa96);}),_0x44beeb;}});for(let _0x15f07c=0x0;_0x15f07c<_0x14e2dd['length'];++_0x15f07c){const _0x7efe0f=_0x14e2dd[_0x15f07c];_0x2b2474['listenProvider_']['stopListening'](Tt(_0x7efe0f),Mt(_0x2b2474,_0x7efe0f));}}return _0x36752f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x3fe966){this['node_']=_0x3fe966;}['getImmediateChild'](_0x37eaf8){const _0x3a82cf=this['node_']['getImmediateChild'](_0x37eaf8);return new cs(_0x3a82cf);}['node'](){return this['node_'];}}class ls{constructor(_0x47624c,_0xc02b8){this['syncTree_']=_0x47624c,this['path_']=_0xc02b8;}['getImmediateChild'](_0x2ddcd8){const _0x23aeb4=A(this['path_'],_0x2ddcd8);return new ls(this['syncTree_'],_0x23aeb4);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x5f4a94){return _0x5f4a94=_0x5f4a94||{},_0x5f4a94['timestamp']=_0x5f4a94['timestamp']||new Date()['getTime'](),_0x5f4a94;},fr=function(_0x255ad5,_0x4dc8ed,_0x285a02){if(!_0x255ad5||typeof _0x255ad5!='object')return _0x255ad5;if(f('.sv'in _0x255ad5,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x255ad5['.sv']=='string')return td(_0x255ad5['.sv'],_0x4dc8ed,_0x285a02);if(typeof _0x255ad5['.sv']=='object')return nd(_0x255ad5['.sv'],_0x4dc8ed);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x255ad5,null,0x2));},td=function(_0xedcbf3,_0xab8d01,_0x4723c3){switch(_0xedcbf3){case'timestamp':return _0x4723c3['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0xedcbf3);}},nd=function(_0xa5cfaa,_0x5bfb36,_0x407d75){_0xa5cfaa['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xa5cfaa,null,0x2));const _0x1863bd=_0xa5cfaa['increment'];typeof _0x1863bd!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1863bd);const _0x393ed3=_0x5bfb36['node']();if(f(_0x393ed3!==null&&typeof _0x393ed3<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x393ed3['isLeafNode']())return _0x1863bd;const _0x2065d5=_0x393ed3['getValue']();return typeof _0x2065d5!='number'?_0x1863bd:_0x2065d5+_0x1863bd;},Zo=function(_0x4924b5,_0x4047fa,_0x1d4c83,_0x3612f0){return us(_0x4047fa,new ls(_0x1d4c83,_0x4924b5),_0x3612f0);},hs=function(_0xd680ed,_0x4027c6,_0x2c2be2){return us(_0xd680ed,new cs(_0x4027c6),_0x2c2be2);};function us(_0x1613cf,_0x3bf0c6,_0x40a515){const _0x5da24a=_0x1613cf['getPriority']()['val'](),_0x39f8ef=fr(_0x5da24a,_0x3bf0c6['getImmediateChild']('.priority'),_0x40a515);let _0x370ac5;if(_0x1613cf['isLeafNode']()){const _0x4befbb=_0x1613cf,_0x23d284=fr(_0x4befbb['getValue'](),_0x3bf0c6,_0x40a515);return _0x23d284!==_0x4befbb['getValue']()||_0x39f8ef!==_0x4befbb['getPriority']()['val']()?new D(_0x23d284,N(_0x39f8ef)):_0x1613cf;}else{const _0x36ffac=_0x1613cf;return _0x370ac5=_0x36ffac,_0x39f8ef!==_0x36ffac['getPriority']()['val']()&&(_0x370ac5=_0x370ac5['updatePriority'](new D(_0x39f8ef))),_0x36ffac['forEachChild'](R,(_0x2f6894,_0x40ed23)=>{const _0x4dcc0a=us(_0x40ed23,_0x3bf0c6['getImmediateChild'](_0x2f6894),_0x40a515);_0x4dcc0a!==_0x40ed23&&(_0x370ac5=_0x370ac5['updateImmediateChild'](_0x2f6894,_0x4dcc0a));}),_0x370ac5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x1b01d1='',_0xf376c9=null,_0x3678ec={'children':{},'childCount':0x0}){this['name']=_0x1b01d1,this['parent']=_0xf376c9,this['node']=_0x3678ec;}}function Un(_0x54cdca,_0x3afb93){let _0x404175=_0x3afb93 instanceof C?_0x3afb93:new C(_0x3afb93),_0x3561c6=_0x54cdca,_0x45e822=y(_0x404175);for(;_0x45e822!==null;){const _0x134135=Oe(_0x3561c6['node']['children'],_0x45e822)||{'children':{},'childCount':0x0};_0x3561c6=new ds(_0x45e822,_0x3561c6,_0x134135),_0x404175=b(_0x404175),_0x45e822=y(_0x404175);}return _0x3561c6;}function Ge(_0x55ebcb){return _0x55ebcb['node']['value'];}function fs(_0x4ebc1d,_0x396dc7){_0x4ebc1d['node']['value']=_0x396dc7,Ri(_0x4ebc1d);}function ea(_0x24e6ad){return _0x24e6ad['node']['childCount']>0x0;}function id(_0xf8ef5){return Ge(_0xf8ef5)===void 0x0&&!ea(_0xf8ef5);}function Wn(_0x4ea9ed,_0x2b7f43){x(_0x4ea9ed['node']['children'],(_0x2f79de,_0x3d471c)=>{_0x2b7f43(new ds(_0x2f79de,_0x4ea9ed,_0x3d471c));});}function ta(_0x1cc729,_0x355fdd,_0x1b2c70,_0x4e8ca0){_0x1b2c70&&_0x355fdd(_0x1cc729),Wn(_0x1cc729,_0x26d9be=>{ta(_0x26d9be,_0x355fdd,!0x0);});}function sd(_0x1dc61f,_0x4d6e04,_0x4daf02){let _0x124da0=_0x1dc61f['parent'];for(;_0x124da0!==null;){if(_0x4d6e04(_0x124da0))return!0x0;_0x124da0=_0x124da0['parent'];}return!0x1;}function Gt(_0x2e9c2e){return new C(_0x2e9c2e['parent']===null?_0x2e9c2e['name']:Gt(_0x2e9c2e['parent'])+'/'+_0x2e9c2e['name']);}function Ri(_0x307b70){_0x307b70['parent']!==null&&rd(_0x307b70['parent'],_0x307b70['name'],_0x307b70);}function rd(_0x59bc7e,_0x553ca6,_0xd88cf2){const _0x40c984=id(_0xd88cf2),_0x23c164=Y(_0x59bc7e['node']['children'],_0x553ca6);_0x40c984&&_0x23c164?(delete _0x59bc7e['node']['children'][_0x553ca6],_0x59bc7e['node']['childCount']--,Ri(_0x59bc7e)):!_0x40c984&&!_0x23c164&&(_0x59bc7e['node']['children'][_0x553ca6]=_0xd88cf2['node'],_0x59bc7e['node']['childCount']++,Ri(_0x59bc7e));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x510e6a){return typeof _0x510e6a=='string'&&_0x510e6a['length']!==0x0&&!od['test'](_0x510e6a);},na=function(_0x3c7d23){return typeof _0x3c7d23=='string'&&_0x3c7d23['length']!==0x0&&!ad['test'](_0x3c7d23);},cd=function(_0x2e712e){return _0x2e712e&&(_0x2e712e=_0x2e712e['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x2e712e);},Cn=function(_0x22141c){return _0x22141c===null||typeof _0x22141c=='string'||typeof _0x22141c=='number'&&!Wi(_0x22141c)||_0x22141c&&typeof _0x22141c=='object'&&Y(_0x22141c,'.sv');},qt=function(_0x1d9f3e,_0x469d09,_0x109eab,_0x2b26d8){_0x2b26d8&&_0x469d09===void 0x0||zt(Nn(_0x1d9f3e,'value'),_0x469d09,_0x109eab);},zt=function(_0x3ab1e0,_0xe5f2c0,_0x332829){const _0x16a10c=_0x332829 instanceof C?new Sh(_0x332829,_0x3ab1e0):_0x332829;if(_0xe5f2c0===void 0x0)throw new Error(_0x3ab1e0+'contains\x20undefined\x20'+Ne(_0x16a10c));if(typeof _0xe5f2c0=='function')throw new Error(_0x3ab1e0+'contains\x20a\x20function\x20'+Ne(_0x16a10c)+'\x20with\x20contents\x20=\x20'+_0xe5f2c0['toString']());if(Wi(_0xe5f2c0))throw new Error(_0x3ab1e0+'contains\x20'+_0xe5f2c0['toString']()+'\x20'+Ne(_0x16a10c));if(typeof _0xe5f2c0=='string'&&_0xe5f2c0['length']>oi/0x3&&Pn(_0xe5f2c0)>oi)throw new Error(_0x3ab1e0+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x16a10c)+'\x20(\x27'+_0xe5f2c0['substring'](0x0,0x32)+'...\x27)');if(_0xe5f2c0&&typeof _0xe5f2c0=='object'){let _0x44ea9c=!0x1,_0x45b637=!0x1;if(x(_0xe5f2c0,(_0x53dc11,_0x5aa718)=>{if(_0x53dc11==='.value')_0x44ea9c=!0x0;else{if(_0x53dc11!=='.priority'&&_0x53dc11!=='.sv'&&(_0x45b637=!0x0,!ps(_0x53dc11)))throw new Error(_0x3ab1e0+'\x20contains\x20an\x20invalid\x20key\x20('+_0x53dc11+')\x20'+Ne(_0x16a10c)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x16a10c,_0x53dc11),zt(_0x3ab1e0,_0x5aa718,_0x16a10c),Rh(_0x16a10c);}),_0x44ea9c&&_0x45b637)throw new Error(_0x3ab1e0+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x16a10c)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x12000a,_0x5a593f){let _0x44e3e8,_0x41d8cc;for(_0x44e3e8=0x0;_0x44e3e8<_0x5a593f['length'];_0x44e3e8++){_0x41d8cc=_0x5a593f[_0x44e3e8];const _0x5b511b=kt(_0x41d8cc);for(let _0x42a627=0x0;_0x42a627<_0x5b511b['length'];_0x42a627++)if(!(_0x5b511b[_0x42a627]==='.priority'&&_0x42a627===_0x5b511b['length']-0x1)){if(!ps(_0x5b511b[_0x42a627]))throw new Error(_0x12000a+'contains\x20an\x20invalid\x20key\x20('+_0x5b511b[_0x42a627]+')\x20in\x20path\x20'+_0x41d8cc['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5a593f['sort'](Th);let _0xa90ab2=null;for(_0x44e3e8=0x0;_0x44e3e8<_0x5a593f['length'];_0x44e3e8++){if(_0x41d8cc=_0x5a593f[_0x44e3e8],_0xa90ab2!==null&&$(_0xa90ab2,_0x41d8cc))throw new Error(_0x12000a+'contains\x20a\x20path\x20'+_0xa90ab2['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x41d8cc['toString']());_0xa90ab2=_0x41d8cc;}},hd=function(_0x54a4c1,_0xe22064,_0x530a04,_0x5b0661){const _0x4a6633=Nn(_0x54a4c1,'values');if(!(_0xe22064&&typeof _0xe22064=='object')||Array['isArray'](_0xe22064))throw new Error(_0x4a6633+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2bb8ae=[];x(_0xe22064,(_0x9a8dda,_0x35513e)=>{const _0x235c04=new C(_0x9a8dda);if(zt(_0x4a6633,_0x35513e,A(_0x530a04,_0x235c04)),Gi(_0x235c04)==='.priority'&&!Cn(_0x35513e))throw new Error(_0x4a6633+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x235c04['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2bb8ae['push'](_0x235c04);}),ld(_0x4a6633,_0x2bb8ae);},_s=function(_0x559177,_0x3ce2dd,_0x3e7afc,_0x3850ce){if(!na(_0x3e7afc))throw new Error(Nn(_0x559177,_0x3ce2dd)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3e7afc+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x26cc22,_0x4a20cc,_0x3f6d51,_0x521f85){_0x3f6d51&&(_0x3f6d51=_0x3f6d51['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x26cc22,_0x4a20cc,_0x3f6d51);},gs=function(_0x4b043c,_0x78f972){if(y(_0x78f972)==='.info')throw new Error(_0x4b043c+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x2dbce8,_0x57aa58){const _0xbf2bb1=_0x57aa58['path']['toString']();if(typeof _0x57aa58['repoInfo']['host']!='string'||_0x57aa58['repoInfo']['host']['length']===0x0||!ps(_0x57aa58['repoInfo']['namespace'])&&_0x57aa58['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xbf2bb1['length']!==0x0&&!cd(_0xbf2bb1))throw new Error(Nn(_0x2dbce8,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x5f7c0e,_0x325025){let _0x37b9e8=null;for(let _0x4f71f7=0x0;_0x4f71f7<_0x325025['length'];_0x4f71f7++){const _0xa60d68=_0x325025[_0x4f71f7],_0x569b75=_0xa60d68['getPath']();_0x37b9e8!==null&&!qi(_0x569b75,_0x37b9e8['path'])&&(_0x5f7c0e['eventLists_']['push'](_0x37b9e8),_0x37b9e8=null),_0x37b9e8===null&&(_0x37b9e8={'events':[],'path':_0x569b75}),_0x37b9e8['events']['push'](_0xa60d68);}_0x37b9e8&&_0x5f7c0e['eventLists_']['push'](_0x37b9e8);}function ia(_0x39bf52,_0x30cf05,_0x56351f){Bn(_0x39bf52,_0x56351f),sa(_0x39bf52,_0x4cac32=>qi(_0x4cac32,_0x30cf05));}function V(_0x65d3bc,_0xe794c8,_0x10e788){Bn(_0x65d3bc,_0x10e788),sa(_0x65d3bc,_0x47f28e=>$(_0x47f28e,_0xe794c8)||$(_0xe794c8,_0x47f28e));}function sa(_0x5c82b3,_0x5f1900){_0x5c82b3['recursionDepth_']++;let _0x7c9958=!0x0;for(let _0x463aa5=0x0;_0x463aa5<_0x5c82b3['eventLists_']['length'];_0x463aa5++){const _0x5dbf11=_0x5c82b3['eventLists_'][_0x463aa5];if(_0x5dbf11){const _0x5cb8ed=_0x5dbf11['path'];_0x5f1900(_0x5cb8ed)?(pd(_0x5c82b3['eventLists_'][_0x463aa5]),_0x5c82b3['eventLists_'][_0x463aa5]=null):_0x7c9958=!0x1;}}_0x7c9958&&(_0x5c82b3['eventLists_']=[]),_0x5c82b3['recursionDepth_']--;}function pd(_0x3a440f){for(let _0x109b54=0x0;_0x109b54<_0x3a440f['events']['length'];_0x109b54++){const _0x22a088=_0x3a440f['events'][_0x109b54];if(_0x22a088!==null){_0x3a440f['events'][_0x109b54]=null;const _0x5c98c2=_0x22a088['getEventRunner']();Et&&L('event:\x20'+_0x22a088['toString']()),lt(_0x5c98c2);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x369fb8,_0x5a62a7,_0x54e104,_0xe3af75){this['repoInfo_']=_0x369fb8,this['forceRestClient_']=_0x5a62a7,this['authTokenProvider_']=_0x54e104,this['appCheckProvider_']=_0xe3af75,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x5b2822,_0x24ba80,_0x83836f){if(_0x5b2822['stats_']=Hi(_0x5b2822['repoInfo_']),_0x5b2822['forceRestClient_']||Yl())_0x5b2822['server_']=new fn(_0x5b2822['repoInfo_'],(_0x12fbfd,_0x150cd3,_0x3e77eb,_0x3a571a)=>{pr(_0x5b2822,_0x12fbfd,_0x150cd3,_0x3e77eb,_0x3a571a);},_0x5b2822['authTokenProvider_'],_0x5b2822['appCheckProvider_']),setTimeout(()=>_r(_0x5b2822,!0x0),0x0);else{if(typeof _0x83836f<'u'&&_0x83836f!==null){if(typeof _0x83836f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x83836f);}catch(_0x2f8ae6){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x2f8ae6);}}_0x5b2822['persistentConnection_']=new ie(_0x5b2822['repoInfo_'],_0x24ba80,(_0x26e69e,_0x263016,_0x497777,_0x23e452)=>{pr(_0x5b2822,_0x26e69e,_0x263016,_0x497777,_0x23e452);},_0x1ed759=>{_r(_0x5b2822,_0x1ed759);},_0x4307cc=>{yd(_0x5b2822,_0x4307cc);},_0x5b2822['authTokenProvider_'],_0x5b2822['appCheckProvider_'],_0x83836f),_0x5b2822['server_']=_0x5b2822['persistentConnection_'];}_0x5b2822['authTokenProvider_']['addTokenChangeListener'](_0x4f1637=>{_0x5b2822['server_']['refreshAuthToken'](_0x4f1637);}),_0x5b2822['appCheckProvider_']['addTokenChangeListener'](_0xf83d72=>{_0x5b2822['server_']['refreshAppCheckToken'](_0xf83d72['token']);}),_0x5b2822['statsReporter_']=eh(_0x5b2822['repoInfo_'],()=>new eu(_0x5b2822['stats_'],_0x5b2822['server_'])),_0x5b2822['infoData_']=new Yh(),_0x5b2822['infoSyncTree_']=new dr({'startListening':(_0x507a9d,_0x1494e3,_0x19a96a,_0x400e32)=>{let _0x2d9d1b=[];const _0x2cea2d=_0x5b2822['infoData_']['getNode'](_0x507a9d['_path']);return _0x2cea2d['isEmpty']()||(_0x2d9d1b=$t(_0x5b2822['infoSyncTree_'],_0x507a9d['_path'],_0x2cea2d),setTimeout(()=>{_0x400e32('ok');},0x0)),_0x2d9d1b;},'stopListening':()=>{}}),ms(_0x5b2822,'connected',!0x1),_0x5b2822['serverSyncTree_']=new dr({'startListening':(_0xc9dde3,_0x1ff142,_0x1ef7d0,_0x463d13)=>(_0x5b2822['server_']['listen'](_0xc9dde3,_0x1ef7d0,_0x1ff142,(_0x31bf3f,_0x2fc353)=>{const _0x1c773a=_0x463d13(_0x31bf3f,_0x2fc353);V(_0x5b2822['eventQueue_'],_0xc9dde3['_path'],_0x1c773a);}),[]),'stopListening':(_0x1c5199,_0x447abf)=>{_0x5b2822['server_']['unlisten'](_0x1c5199,_0x447abf);}});}function oa(_0x1adc59){const _0x259a51=_0x1adc59['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x259a51;}function jt(_0x24d2c5){return ed({'timestamp':oa(_0x24d2c5)});}function pr(_0x2b0140,_0x1bf68f,_0x3aaef8,_0xf51d4d,_0x14d60b){_0x2b0140['dataUpdateCount']++;const _0x2ab044=new C(_0x1bf68f);_0x3aaef8=_0x2b0140['interceptServerDataCallback_']?_0x2b0140['interceptServerDataCallback_'](_0x1bf68f,_0x3aaef8):_0x3aaef8;let _0x4ddb11=[];if(_0x14d60b){if(_0xf51d4d){const _0x1187d3=ln(_0x3aaef8,_0x43fd70=>N(_0x43fd70));_0x4ddb11=Ku(_0x2b0140['serverSyncTree_'],_0x2ab044,_0x1187d3,_0x14d60b);}else{const _0x4a8d42=N(_0x3aaef8);_0x4ddb11=Yo(_0x2b0140['serverSyncTree_'],_0x2ab044,_0x4a8d42,_0x14d60b);}}else{if(_0xf51d4d){const _0xaa3253=ln(_0x3aaef8,_0x14fd3c=>N(_0x14fd3c));_0x4ddb11=qu(_0x2b0140['serverSyncTree_'],_0x2ab044,_0xaa3253);}else{const _0x39d159=N(_0x3aaef8);_0x4ddb11=$t(_0x2b0140['serverSyncTree_'],_0x2ab044,_0x39d159);}}let _0x460a37=_0x2ab044;_0x4ddb11['length']>0x0&&(_0x460a37=st(_0x2b0140,_0x2ab044)),V(_0x2b0140['eventQueue_'],_0x460a37,_0x4ddb11);}function _r(_0x1a270d,_0x540ee3){ms(_0x1a270d,'connected',_0x540ee3),_0x540ee3===!0x1&&wd(_0x1a270d);}function yd(_0x7bd815,_0x219a10){x(_0x219a10,(_0x2fca6b,_0x2043cc)=>{ms(_0x7bd815,_0x2fca6b,_0x2043cc);});}function ms(_0x228839,_0x39dd17,_0x3b250e){const _0x5b0438=new C('/.info/'+_0x39dd17),_0x1675b8=N(_0x3b250e);_0x228839['infoData_']['updateSnapshot'](_0x5b0438,_0x1675b8);const _0x1ce714=$t(_0x228839['infoSyncTree_'],_0x5b0438,_0x1675b8);V(_0x228839['eventQueue_'],_0x5b0438,_0x1ce714);}function Vn(_0x36f175){return _0x36f175['nextWriteId_']++;}function vd(_0x4e9ba3,_0x30a6d1,_0x433d22){const _0x4ce006=Yu(_0x4e9ba3['serverSyncTree_'],_0x30a6d1);return _0x4ce006!=null?Promise['resolve'](_0x4ce006):_0x4e9ba3['server_']['get'](_0x30a6d1)['then'](_0x522d00=>{const _0x3e4b55=N(_0x522d00)['withIndex'](_0x30a6d1['_queryParams']['getIndex']());bi(_0x4e9ba3['serverSyncTree_'],_0x30a6d1,_0x433d22,!0x0);let _0x50601a;if(_0x30a6d1['_queryParams']['loadsAllData']())_0x50601a=$t(_0x4e9ba3['serverSyncTree_'],_0x30a6d1['_path'],_0x3e4b55);else{const _0x467300=Mt(_0x4e9ba3['serverSyncTree_'],_0x30a6d1);_0x50601a=Yo(_0x4e9ba3['serverSyncTree_'],_0x30a6d1['_path'],_0x3e4b55,_0x467300);}return V(_0x4e9ba3['eventQueue_'],_0x30a6d1['_path'],_0x50601a),wn(_0x4e9ba3['serverSyncTree_'],_0x30a6d1,_0x433d22,null,!0x0),_0x3e4b55;},_0x32c56d=>(ut(_0x4e9ba3,'get\x20for\x20query\x20'+O(_0x30a6d1)+'\x20failed:\x20'+_0x32c56d),Promise['reject'](new Error(_0x32c56d))));}function Ed(_0x547545,_0xe14f70,_0x47a6e6,_0x21dacb,_0x34f85d){ut(_0x547545,'set',{'path':_0xe14f70['toString'](),'value':_0x47a6e6,'priority':_0x21dacb});const _0x4a566f=jt(_0x547545),_0x4322b7=N(_0x47a6e6,_0x21dacb),_0x4e2b5a=xn(_0x547545['serverSyncTree_'],_0xe14f70),_0x5e7d37=hs(_0x4322b7,_0x4e2b5a,_0x4a566f),_0x3ca182=Vn(_0x547545),_0x42ec96=ss(_0x547545['serverSyncTree_'],_0xe14f70,_0x5e7d37,_0x3ca182,!0x0);Bn(_0x547545['eventQueue_'],_0x42ec96),_0x547545['server_']['put'](_0xe14f70['toString'](),_0x4322b7['val'](!0x0),(_0x272a1d,_0x387c0c)=>{const _0x48118f=_0x272a1d==='ok';_0x48118f||U('set\x20at\x20'+_0xe14f70+'\x20failed:\x20'+_0x272a1d);const _0x1daa22=pe(_0x547545['serverSyncTree_'],_0x3ca182,!_0x48118f);V(_0x547545['eventQueue_'],_0xe14f70,_0x1daa22),Ai(_0x547545,_0x34f85d,_0x272a1d,_0x387c0c);});const _0x3d8c6a=vs(_0x547545,_0xe14f70);st(_0x547545,_0x3d8c6a),V(_0x547545['eventQueue_'],_0x3d8c6a,[]);}function Id(_0x768d1c,_0x565274,_0x5387c6,_0x32ee87){ut(_0x768d1c,'update',{'path':_0x565274['toString'](),'value':_0x5387c6});let _0x34e527=!0x0;const _0x3b67dd=jt(_0x768d1c),_0x33aafe={};if(x(_0x5387c6,(_0x5e5bf7,_0x2ccc48)=>{_0x34e527=!0x1,_0x33aafe[_0x5e5bf7]=Zo(A(_0x565274,_0x5e5bf7),N(_0x2ccc48),_0x768d1c['serverSyncTree_'],_0x3b67dd);}),_0x34e527)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x768d1c,_0x32ee87,'ok',void 0x0);else{const _0x18b475=Vn(_0x768d1c),_0x5b3a5c=Gu(_0x768d1c['serverSyncTree_'],_0x565274,_0x33aafe,_0x18b475);Bn(_0x768d1c['eventQueue_'],_0x5b3a5c),_0x768d1c['server_']['merge'](_0x565274['toString'](),_0x5387c6,(_0x639207,_0x467969)=>{const _0x536185=_0x639207==='ok';_0x536185||U('update\x20at\x20'+_0x565274+'\x20failed:\x20'+_0x639207);const _0x1ae561=pe(_0x768d1c['serverSyncTree_'],_0x18b475,!_0x536185),_0x125df5=_0x1ae561['length']>0x0?st(_0x768d1c,_0x565274):_0x565274;V(_0x768d1c['eventQueue_'],_0x125df5,_0x1ae561),Ai(_0x768d1c,_0x32ee87,_0x639207,_0x467969);}),x(_0x5387c6,_0x41d37f=>{const _0x8ab448=vs(_0x768d1c,A(_0x565274,_0x41d37f));st(_0x768d1c,_0x8ab448);}),V(_0x768d1c['eventQueue_'],_0x565274,[]);}}function wd(_0x711655){ut(_0x711655,'onDisconnectEvents');const _0x58c4c1=jt(_0x711655),_0x4376e1=pn();Ei(_0x711655['onDisconnect_'],w(),(_0x4ef9e6,_0x4a7595)=>{const _0x3bc656=Zo(_0x4ef9e6,_0x4a7595,_0x711655['serverSyncTree_'],_0x58c4c1);Mo(_0x4376e1,_0x4ef9e6,_0x3bc656);});let _0x31d544=[];Ei(_0x4376e1,w(),(_0x2844a0,_0x223e11)=>{_0x31d544=_0x31d544['concat']($t(_0x711655['serverSyncTree_'],_0x2844a0,_0x223e11));const _0x853950=vs(_0x711655,_0x2844a0);st(_0x711655,_0x853950);}),_0x711655['onDisconnect_']=pn(),V(_0x711655['eventQueue_'],w(),_0x31d544);}function Cd(_0x41612c,_0x5f504c,_0x2c17b5){let _0x39803f;y(_0x5f504c['_path'])==='.info'?_0x39803f=bi(_0x41612c['infoSyncTree_'],_0x5f504c,_0x2c17b5):_0x39803f=bi(_0x41612c['serverSyncTree_'],_0x5f504c,_0x2c17b5),ia(_0x41612c['eventQueue_'],_0x5f504c['_path'],_0x39803f);}function Td(_0x52b1fd,_0x310d36,_0x2398bd){let _0x587cdc;y(_0x310d36['_path'])==='.info'?_0x587cdc=wn(_0x52b1fd['infoSyncTree_'],_0x310d36,_0x2398bd):_0x587cdc=wn(_0x52b1fd['serverSyncTree_'],_0x310d36,_0x2398bd),ia(_0x52b1fd['eventQueue_'],_0x310d36['_path'],_0x587cdc);}function aa(_0x3e0aaa){_0x3e0aaa['persistentConnection_']&&_0x3e0aaa['persistentConnection_']['interrupt'](ra);}function Sd(_0x4e7933){_0x4e7933['persistentConnection_']&&_0x4e7933['persistentConnection_']['resume'](ra);}function ut(_0x222009,..._0x115267){let _0x40da4f='';_0x222009['persistentConnection_']&&(_0x40da4f=_0x222009['persistentConnection_']['id']+':'),L(_0x40da4f,..._0x115267);}function Ai(_0x2e9ef7,_0x34e1,_0x3b40dd,_0x28c3b0){_0x34e1&&lt(()=>{if(_0x3b40dd==='ok')_0x34e1(null);else{const _0x21da75=(_0x3b40dd||'error')['toUpperCase']();let _0x1e36bd=_0x21da75;_0x28c3b0&&(_0x1e36bd+=':\x20'+_0x28c3b0);const _0x137e00=new Error(_0x1e36bd);_0x137e00['code']=_0x21da75,_0x34e1(_0x137e00);}});}function bd(_0x211f59,_0x368b7d,_0x12edc3,_0x26e12a,_0x258fc3,_0x498410){ut(_0x211f59,'transaction\x20on\x20'+_0x368b7d);const _0x50f384={'path':_0x368b7d,'update':_0x12edc3,'onComplete':_0x26e12a,'status':null,'order':to(),'applyLocally':_0x498410,'retryCount':0x0,'unwatcher':_0x258fc3,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x27eda3=ys(_0x211f59,_0x368b7d,void 0x0);_0x50f384['currentInputSnapshot']=_0x27eda3;const _0x1b0096=_0x50f384['update'](_0x27eda3['val']());if(_0x1b0096===void 0x0)_0x50f384['unwatcher'](),_0x50f384['currentOutputSnapshotRaw']=null,_0x50f384['currentOutputSnapshotResolved']=null,_0x50f384['onComplete']&&_0x50f384['onComplete'](null,!0x1,_0x50f384['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1b0096,_0x50f384['path']),_0x50f384['status']=0x0;const _0x89dd2a=Un(_0x211f59['transactionQueueTree_'],_0x368b7d),_0x37346e=Ge(_0x89dd2a)||[];_0x37346e['push'](_0x50f384),fs(_0x89dd2a,_0x37346e);let _0x45a1e7;typeof _0x1b0096=='object'&&_0x1b0096!==null&&Y(_0x1b0096,'.priority')?(_0x45a1e7=Oe(_0x1b0096,'.priority'),f(Cn(_0x45a1e7),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x45a1e7=(xn(_0x211f59['serverSyncTree_'],_0x368b7d)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3ea04f=jt(_0x211f59),_0x545a6b=N(_0x1b0096,_0x45a1e7),_0xc8c054=hs(_0x545a6b,_0x27eda3,_0x3ea04f);_0x50f384['currentOutputSnapshotRaw']=_0x545a6b,_0x50f384['currentOutputSnapshotResolved']=_0xc8c054,_0x50f384['currentWriteId']=Vn(_0x211f59);const _0x29b678=ss(_0x211f59['serverSyncTree_'],_0x368b7d,_0xc8c054,_0x50f384['currentWriteId'],_0x50f384['applyLocally']);V(_0x211f59['eventQueue_'],_0x368b7d,_0x29b678),Hn(_0x211f59,_0x211f59['transactionQueueTree_']);}}function ys(_0x122277,_0x4b5188,_0x23b616){return xn(_0x122277['serverSyncTree_'],_0x4b5188,_0x23b616)||g['EMPTY_NODE'];}function Hn(_0x20ccec,_0x3e7878=_0x20ccec['transactionQueueTree_']){if(_0x3e7878||$n(_0x20ccec,_0x3e7878),Ge(_0x3e7878)){const _0x41b873=la(_0x20ccec,_0x3e7878);f(_0x41b873['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x41b873['every'](_0x486730=>_0x486730['status']===0x0)&&Rd(_0x20ccec,Gt(_0x3e7878),_0x41b873);}else ea(_0x3e7878)&&Wn(_0x3e7878,_0xc69ee9=>{Hn(_0x20ccec,_0xc69ee9);});}function Rd(_0x576a48,_0x19aed5,_0x53c1a7){const _0xce3f2d=_0x53c1a7['map'](_0x219b3d=>_0x219b3d['currentWriteId']),_0xb47f17=ys(_0x576a48,_0x19aed5,_0xce3f2d);let _0xe224b9=_0xb47f17;const _0x4bf1d2=_0xb47f17['hash']();for(let _0x2f24e3=0x0;_0x2f24e3<_0x53c1a7['length'];_0x2f24e3++){const _0x103c25=_0x53c1a7[_0x2f24e3];f(_0x103c25['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x103c25['status']=0x1,_0x103c25['retryCount']++;const _0x46756e=F(_0x19aed5,_0x103c25['path']);_0xe224b9=_0xe224b9['updateChild'](_0x46756e,_0x103c25['currentOutputSnapshotRaw']);}const _0x11f259=_0xe224b9['val'](!0x0),_0x52c949=_0x19aed5;_0x576a48['server_']['put'](_0x52c949['toString'](),_0x11f259,_0x30a8d0=>{ut(_0x576a48,'transaction\x20put\x20response',{'path':_0x52c949['toString'](),'status':_0x30a8d0});let _0x2e6578=[];if(_0x30a8d0==='ok'){const _0x4d7818=[];for(let _0x14ce6f=0x0;_0x14ce6f<_0x53c1a7['length'];_0x14ce6f++)_0x53c1a7[_0x14ce6f]['status']=0x2,_0x2e6578=_0x2e6578['concat'](pe(_0x576a48['serverSyncTree_'],_0x53c1a7[_0x14ce6f]['currentWriteId'])),_0x53c1a7[_0x14ce6f]['onComplete']&&_0x4d7818['push'](()=>_0x53c1a7[_0x14ce6f]['onComplete'](null,!0x0,_0x53c1a7[_0x14ce6f]['currentOutputSnapshotResolved'])),_0x53c1a7[_0x14ce6f]['unwatcher']();$n(_0x576a48,Un(_0x576a48['transactionQueueTree_'],_0x19aed5)),Hn(_0x576a48,_0x576a48['transactionQueueTree_']),V(_0x576a48['eventQueue_'],_0x19aed5,_0x2e6578);for(let _0x481794=0x0;_0x481794<_0x4d7818['length'];_0x481794++)lt(_0x4d7818[_0x481794]);}else{if(_0x30a8d0==='datastale'){for(let _0x265493=0x0;_0x265493<_0x53c1a7['length'];_0x265493++)_0x53c1a7[_0x265493]['status']===0x3?_0x53c1a7[_0x265493]['status']=0x4:_0x53c1a7[_0x265493]['status']=0x0;}else{U('transaction\x20at\x20'+_0x52c949['toString']()+'\x20failed:\x20'+_0x30a8d0);for(let _0x59afec=0x0;_0x59afec<_0x53c1a7['length'];_0x59afec++)_0x53c1a7[_0x59afec]['status']=0x4,_0x53c1a7[_0x59afec]['abortReason']=_0x30a8d0;}st(_0x576a48,_0x19aed5);}},_0x4bf1d2);}function st(_0x3b225c,_0x1ed166){const _0x52232a=ca(_0x3b225c,_0x1ed166),_0x585c32=Gt(_0x52232a),_0x587ef7=la(_0x3b225c,_0x52232a);return Ad(_0x3b225c,_0x587ef7,_0x585c32),_0x585c32;}function Ad(_0x21096e,_0x3a7e2b,_0x12be0b){if(_0x3a7e2b['length']===0x0)return;const _0x58b2a2=[];let _0x513e68=[];const _0x2bde3c=_0x3a7e2b['filter'](_0x343e03=>_0x343e03['status']===0x0)['map'](_0x2af9e6=>_0x2af9e6['currentWriteId']);for(let _0xc28d47=0x0;_0xc28d47<_0x3a7e2b['length'];_0xc28d47++){const _0x5c6b1f=_0x3a7e2b[_0xc28d47],_0x3a0111=F(_0x12be0b,_0x5c6b1f['path']);let _0x3a5887=!0x1,_0x413270;if(f(_0x3a0111!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x5c6b1f['status']===0x4)_0x3a5887=!0x0,_0x413270=_0x5c6b1f['abortReason'],_0x513e68=_0x513e68['concat'](pe(_0x21096e['serverSyncTree_'],_0x5c6b1f['currentWriteId'],!0x0));else{if(_0x5c6b1f['status']===0x0){if(_0x5c6b1f['retryCount']>=_d)_0x3a5887=!0x0,_0x413270='maxretry',_0x513e68=_0x513e68['concat'](pe(_0x21096e['serverSyncTree_'],_0x5c6b1f['currentWriteId'],!0x0));else{const _0x5012a5=ys(_0x21096e,_0x5c6b1f['path'],_0x2bde3c);_0x5c6b1f['currentInputSnapshot']=_0x5012a5;const _0x5eb6a3=_0x3a7e2b[_0xc28d47]['update'](_0x5012a5['val']());if(_0x5eb6a3!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x5eb6a3,_0x5c6b1f['path']);let _0x347830=N(_0x5eb6a3);typeof _0x5eb6a3=='object'&&_0x5eb6a3!=null&&Y(_0x5eb6a3,'.priority')||(_0x347830=_0x347830['updatePriority'](_0x5012a5['getPriority']()));const _0x524da7=_0x5c6b1f['currentWriteId'],_0x3d8b4c=jt(_0x21096e),_0x1ea80a=hs(_0x347830,_0x5012a5,_0x3d8b4c);_0x5c6b1f['currentOutputSnapshotRaw']=_0x347830,_0x5c6b1f['currentOutputSnapshotResolved']=_0x1ea80a,_0x5c6b1f['currentWriteId']=Vn(_0x21096e),_0x2bde3c['splice'](_0x2bde3c['indexOf'](_0x524da7),0x1),_0x513e68=_0x513e68['concat'](ss(_0x21096e['serverSyncTree_'],_0x5c6b1f['path'],_0x1ea80a,_0x5c6b1f['currentWriteId'],_0x5c6b1f['applyLocally'])),_0x513e68=_0x513e68['concat'](pe(_0x21096e['serverSyncTree_'],_0x524da7,!0x0));}else _0x3a5887=!0x0,_0x413270='nodata',_0x513e68=_0x513e68['concat'](pe(_0x21096e['serverSyncTree_'],_0x5c6b1f['currentWriteId'],!0x0));}}}V(_0x21096e['eventQueue_'],_0x12be0b,_0x513e68),_0x513e68=[],_0x3a5887&&(_0x3a7e2b[_0xc28d47]['status']=0x2,function(_0x18d031){setTimeout(_0x18d031,Math['floor'](0x0));}(_0x3a7e2b[_0xc28d47]['unwatcher']),_0x3a7e2b[_0xc28d47]['onComplete']&&(_0x413270==='nodata'?_0x58b2a2['push'](()=>_0x3a7e2b[_0xc28d47]['onComplete'](null,!0x1,_0x3a7e2b[_0xc28d47]['currentInputSnapshot'])):_0x58b2a2['push'](()=>_0x3a7e2b[_0xc28d47]['onComplete'](new Error(_0x413270),!0x1,null))));}$n(_0x21096e,_0x21096e['transactionQueueTree_']);for(let _0x25cfbe=0x0;_0x25cfbe<_0x58b2a2['length'];_0x25cfbe++)lt(_0x58b2a2[_0x25cfbe]);Hn(_0x21096e,_0x21096e['transactionQueueTree_']);}function ca(_0x1ad743,_0x1aa11b){let _0x1b272a,_0x5d2278=_0x1ad743['transactionQueueTree_'];for(_0x1b272a=y(_0x1aa11b);_0x1b272a!==null&&Ge(_0x5d2278)===void 0x0;)_0x5d2278=Un(_0x5d2278,_0x1b272a),_0x1aa11b=b(_0x1aa11b),_0x1b272a=y(_0x1aa11b);return _0x5d2278;}function la(_0x5ac774,_0x5061ef){const _0x4a2ffe=[];return ha(_0x5ac774,_0x5061ef,_0x4a2ffe),_0x4a2ffe['sort']((_0x47f024,_0x33b86f)=>_0x47f024['order']-_0x33b86f['order']),_0x4a2ffe;}function ha(_0xe9d86a,_0x4fe85a,_0x3d4c26){const _0x1ddcfc=Ge(_0x4fe85a);if(_0x1ddcfc){for(let _0x352714=0x0;_0x352714<_0x1ddcfc['length'];_0x352714++)_0x3d4c26['push'](_0x1ddcfc[_0x352714]);}Wn(_0x4fe85a,_0xf28097=>{ha(_0xe9d86a,_0xf28097,_0x3d4c26);});}function $n(_0x169ac9,_0x2cf50f){const _0x2e7be2=Ge(_0x2cf50f);if(_0x2e7be2){let _0x217c2d=0x0;for(let _0x268a1e=0x0;_0x268a1e<_0x2e7be2['length'];_0x268a1e++)_0x2e7be2[_0x268a1e]['status']!==0x2&&(_0x2e7be2[_0x217c2d]=_0x2e7be2[_0x268a1e],_0x217c2d++);_0x2e7be2['length']=_0x217c2d,fs(_0x2cf50f,_0x2e7be2['length']>0x0?_0x2e7be2:void 0x0);}Wn(_0x2cf50f,_0x26de55=>{$n(_0x169ac9,_0x26de55);});}function vs(_0x23d7e6,_0x3373e8){const _0x58ed5b=Gt(ca(_0x23d7e6,_0x3373e8)),_0x76d48f=Un(_0x23d7e6['transactionQueueTree_'],_0x3373e8);return sd(_0x76d48f,_0x30d50e=>{ai(_0x23d7e6,_0x30d50e);}),ai(_0x23d7e6,_0x76d48f),ta(_0x76d48f,_0x266d25=>{ai(_0x23d7e6,_0x266d25);}),_0x58ed5b;}function ai(_0x1f54d1,_0x50ec0d){const _0x4adc17=Ge(_0x50ec0d);if(_0x4adc17){const _0x3c824d=[];let _0x20f0b7=[],_0x56e838=-0x1;for(let _0x213c31=0x0;_0x213c31<_0x4adc17['length'];_0x213c31++)_0x4adc17[_0x213c31]['status']===0x3||(_0x4adc17[_0x213c31]['status']===0x1?(f(_0x56e838===_0x213c31-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x56e838=_0x213c31,_0x4adc17[_0x213c31]['status']=0x3,_0x4adc17[_0x213c31]['abortReason']='set'):(f(_0x4adc17[_0x213c31]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4adc17[_0x213c31]['unwatcher'](),_0x20f0b7=_0x20f0b7['concat'](pe(_0x1f54d1['serverSyncTree_'],_0x4adc17[_0x213c31]['currentWriteId'],!0x0)),_0x4adc17[_0x213c31]['onComplete']&&_0x3c824d['push'](_0x4adc17[_0x213c31]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x56e838===-0x1?fs(_0x50ec0d,void 0x0):_0x4adc17['length']=_0x56e838+0x1,V(_0x1f54d1['eventQueue_'],Gt(_0x50ec0d),_0x20f0b7);for(let _0x4dbae0=0x0;_0x4dbae0<_0x3c824d['length'];_0x4dbae0++)lt(_0x3c824d[_0x4dbae0]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x1cbcc4){let _0x6a2cd0='';const _0x4de0a6=_0x1cbcc4['split']('/');for(let _0x23b426=0x0;_0x23b426<_0x4de0a6['length'];_0x23b426++)if(_0x4de0a6[_0x23b426]['length']>0x0){let _0x18ed7a=_0x4de0a6[_0x23b426];try{_0x18ed7a=decodeURIComponent(_0x18ed7a['replace'](/\+/g,'\x20'));}catch{}_0x6a2cd0+='/'+_0x18ed7a;}return _0x6a2cd0;}function Nd(_0x568e4a){const _0x4b394b={};_0x568e4a['charAt'](0x0)==='?'&&(_0x568e4a=_0x568e4a['substring'](0x1));for(const _0x4f74c2 of _0x568e4a['split']('&')){if(_0x4f74c2['length']===0x0)continue;const _0x452802=_0x4f74c2['split']('=');_0x452802['length']===0x2?_0x4b394b[decodeURIComponent(_0x452802[0x0])]=decodeURIComponent(_0x452802[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4f74c2+'\x27\x20in\x20query\x20\x27'+_0x568e4a+'\x27');}return _0x4b394b;}const gr=function(_0x2d8fa3,_0x3cb1a4){const _0x5afb3d=Pd(_0x2d8fa3),_0x4a445d=_0x5afb3d['namespace'];_0x5afb3d['domain']==='firebase.com'&&oe(_0x5afb3d['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4a445d||_0x4a445d==='undefined')&&_0x5afb3d['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x5afb3d['secure']||Bl();const _0x4cdd2c=_0x5afb3d['scheme']==='ws'||_0x5afb3d['scheme']==='wss';return{'repoInfo':new _o(_0x5afb3d['host'],_0x5afb3d['secure'],_0x4a445d,_0x4cdd2c,_0x3cb1a4,'',_0x4a445d!==_0x5afb3d['subdomain']),'path':new C(_0x5afb3d['pathString'])};},Pd=function(_0x14abd){let _0x4cfa9d='',_0x1c4fe3='',_0x3aacdc='',_0x3267e1='',_0x242a06='',_0x3470ff=!0x0,_0x337c1a='https',_0x4dba3b=0x1bb;if(typeof _0x14abd=='string'){let _0x518e6d=_0x14abd['indexOf']('//');_0x518e6d>=0x0&&(_0x337c1a=_0x14abd['substring'](0x0,_0x518e6d-0x1),_0x14abd=_0x14abd['substring'](_0x518e6d+0x2));let _0x3711d3=_0x14abd['indexOf']('/');_0x3711d3===-0x1&&(_0x3711d3=_0x14abd['length']);let _0x15b4c2=_0x14abd['indexOf']('?');_0x15b4c2===-0x1&&(_0x15b4c2=_0x14abd['length']),_0x4cfa9d=_0x14abd['substring'](0x0,Math['min'](_0x3711d3,_0x15b4c2)),_0x3711d3<_0x15b4c2&&(_0x3267e1=kd(_0x14abd['substring'](_0x3711d3,_0x15b4c2)));const _0x310f86=Nd(_0x14abd['substring'](Math['min'](_0x14abd['length'],_0x15b4c2)));_0x518e6d=_0x4cfa9d['indexOf'](':'),_0x518e6d>=0x0?(_0x3470ff=_0x337c1a==='https'||_0x337c1a==='wss',_0x4dba3b=parseInt(_0x4cfa9d['substring'](_0x518e6d+0x1),0xa)):_0x518e6d=_0x4cfa9d['length'];const _0x42f8cd=_0x4cfa9d['slice'](0x0,_0x518e6d);if(_0x42f8cd['toLowerCase']()==='localhost')_0x1c4fe3='localhost';else{if(_0x42f8cd['split']('.')['length']<=0x2)_0x1c4fe3=_0x42f8cd;else{const _0x528925=_0x4cfa9d['indexOf']('.');_0x3aacdc=_0x4cfa9d['substring'](0x0,_0x528925)['toLowerCase'](),_0x1c4fe3=_0x4cfa9d['substring'](_0x528925+0x1),_0x242a06=_0x3aacdc;}}'ns'in _0x310f86&&(_0x242a06=_0x310f86['ns']);}return{'host':_0x4cfa9d,'port':_0x4dba3b,'domain':_0x1c4fe3,'subdomain':_0x3aacdc,'secure':_0x3470ff,'scheme':_0x337c1a,'pathString':_0x3267e1,'namespace':_0x242a06};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x12d4f3=0x0;const _0x1633d2=[];return function(_0x36bb82){const _0x271424=_0x36bb82===_0x12d4f3;_0x12d4f3=_0x36bb82;let _0x43e9ba;const _0x40799b=new Array(0x8);for(_0x43e9ba=0x7;_0x43e9ba>=0x0;_0x43e9ba--)_0x40799b[_0x43e9ba]=mr['charAt'](_0x36bb82%0x40),_0x36bb82=Math['floor'](_0x36bb82/0x40);f(_0x36bb82===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x397717=_0x40799b['join']('');if(_0x271424){for(_0x43e9ba=0xb;_0x43e9ba>=0x0&&_0x1633d2[_0x43e9ba]===0x3f;_0x43e9ba--)_0x1633d2[_0x43e9ba]=0x0;_0x1633d2[_0x43e9ba]++;}else{for(_0x43e9ba=0x0;_0x43e9ba<0xc;_0x43e9ba++)_0x1633d2[_0x43e9ba]=Math['floor'](Math['random']()*0x40);}for(_0x43e9ba=0x0;_0x43e9ba<0xc;_0x43e9ba++)_0x397717+=mr['charAt'](_0x1633d2[_0x43e9ba]);return f(_0x397717['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x397717;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0xff8daa,_0x2bbc2b,_0x2ae537,_0x1099b7){this['eventType']=_0xff8daa,this['eventRegistration']=_0x2bbc2b,this['snapshot']=_0x2ae537,this['prevName']=_0x1099b7;}['getPath'](){const _0x6578b=this['snapshot']['ref'];return this['eventType']==='value'?_0x6578b['_path']:_0x6578b['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x50fddd,_0x18c74b,_0x5bbf0e){this['eventRegistration']=_0x50fddd,this['error']=_0x18c74b,this['path']=_0x5bbf0e;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x327f00,_0x376247){this['snapshotCallback']=_0x327f00,this['cancelCallback']=_0x376247;}['onValue'](_0xc65c80,_0x118b9c){this['snapshotCallback']['call'](null,_0xc65c80,_0x118b9c);}['onCancel'](_0x950e69){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x950e69);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x16351f){return this['snapshotCallback']===_0x16351f['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x16351f['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x16351f['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x2ad17c,_0x23a3be,_0xde2757,_0x4636d2){this['_repo']=_0x2ad17c,this['_path']=_0x23a3be,this['_queryParams']=_0xde2757,this['_orderByCalled']=_0x4636d2;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x239a69=nr(this['_queryParams']),_0x39d291=Bi(_0x239a69);return _0x39d291==='{}'?'default':_0x39d291;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x46634f){if(_0x46634f=k(_0x46634f),!(_0x46634f instanceof be))return!0x1;const _0x33318a=this['_repo']===_0x46634f['_repo'],_0x18aa91=qi(this['_path'],_0x46634f['_path']),_0x42d6d5=this['_queryIdentifier']===_0x46634f['_queryIdentifier'];return _0x33318a&&_0x18aa91&&_0x42d6d5;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x429736,_0x4c911e){if(_0x429736['_orderByCalled']===!0x0)throw new Error(_0x4c911e+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x4639e6){let _0x36909c=null,_0x1a503c=null;if(_0x4639e6['hasStart']()&&(_0x36909c=_0x4639e6['getIndexStartValue']()),_0x4639e6['hasEnd']()&&(_0x1a503c=_0x4639e6['getIndexEndValue']()),_0x4639e6['getIndex']()===ye){const _0x4865f5='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x5ae152='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4639e6['hasStart']()){if(_0x4639e6['getIndexStartName']()!==xe)throw new Error(_0x4865f5);if(typeof _0x36909c!='string')throw new Error(_0x5ae152);}if(_0x4639e6['hasEnd']()){if(_0x4639e6['getIndexEndName']()!==Ie)throw new Error(_0x4865f5);if(typeof _0x1a503c!='string')throw new Error(_0x5ae152);}}else{if(_0x4639e6['getIndex']()===R){if(_0x36909c!=null&&!Cn(_0x36909c)||_0x1a503c!=null&&!Cn(_0x1a503c))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4639e6['getIndex']()instanceof Ki||_0x4639e6['getIndex']()===Po,'unknown\x20index\x20type.'),_0x36909c!=null&&typeof _0x36909c=='object'||_0x1a503c!=null&&typeof _0x1a503c=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2e228d){if(_0x2e228d['hasStart']()&&_0x2e228d['hasEnd']()&&_0x2e228d['hasLimit']()&&!_0x2e228d['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x3dbef8,_0x4a1108){super(_0x3dbef8,_0x4a1108,new Qi(),!0x1);}get['parent'](){const _0x19d1c7=To(this['_path']);return _0x19d1c7===null?null:new Z(this['_repo'],_0x19d1c7);}get['root'](){let _0x5ec10d=this;for(;_0x5ec10d['parent']!==null;)_0x5ec10d=_0x5ec10d['parent'];return _0x5ec10d;}}class rt{constructor(_0x1e003f,_0x273eee,_0x4c3125){this['_node']=_0x1e003f,this['ref']=_0x273eee,this['_index']=_0x4c3125;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0xc59fb9){const _0x4b916b=new C(_0xc59fb9),_0x130515=Lt(this['ref'],_0xc59fb9);return new rt(this['_node']['getChild'](_0x4b916b),_0x130515,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x51c39f){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x35bc30,_0x26791b)=>_0x51c39f(new rt(_0x26791b,Lt(this['ref'],_0x35bc30),R)));}['hasChild'](_0x4452dd){const _0xedbdcd=new C(_0x4452dd);return!this['_node']['getChild'](_0xedbdcd)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x43c4ee,_0x1d16d3){return _0x43c4ee=k(_0x43c4ee),_0x43c4ee['_checkNotDeleted']('ref'),_0x1d16d3!==void 0x0?Lt(_0x43c4ee['_root'],_0x1d16d3):_0x43c4ee['_root'];}function Lt(_0x317826,_0x4676f2){return _0x317826=k(_0x317826),y(_0x317826['_path'])===null?ud('child','path',_0x4676f2):_s('child','path',_0x4676f2),new Z(_0x317826['_repo'],A(_0x317826['_path'],_0x4676f2));}function d_(_0x5920f9,_0x1712ec){_0x5920f9=k(_0x5920f9),gs('push',_0x5920f9['_path']),qt('push',_0x1712ec,_0x5920f9['_path'],!0x0);const _0x35f8be=oa(_0x5920f9['_repo']),_0x47e1f3=Od(_0x35f8be),_0x153cf0=Lt(_0x5920f9,_0x47e1f3),_0x2eb37d=Lt(_0x5920f9,_0x47e1f3);let _0x4132b8;return _0x1712ec!=null?_0x4132b8=Ld(_0x2eb37d,_0x1712ec)['then'](()=>_0x2eb37d):_0x4132b8=Promise['resolve'](_0x2eb37d),_0x153cf0['then']=_0x4132b8['then']['bind'](_0x4132b8),_0x153cf0['catch']=_0x4132b8['then']['bind'](_0x4132b8,void 0x0),_0x153cf0;}function Ld(_0x3aad56,_0x96ca0a){_0x3aad56=k(_0x3aad56),gs('set',_0x3aad56['_path']),qt('set',_0x96ca0a,_0x3aad56['_path'],!0x1);const _0x3d145b=new Ve();return Ed(_0x3aad56['_repo'],_0x3aad56['_path'],_0x96ca0a,null,_0x3d145b['wrapCallback'](()=>{})),_0x3d145b['promise'];}function f_(_0x4d5e44,_0x12bbc5){hd('update',_0x12bbc5,_0x4d5e44['_path']);const _0xe5d047=new Ve();return Id(_0x4d5e44['_repo'],_0x4d5e44['_path'],_0x12bbc5,_0xe5d047['wrapCallback'](()=>{})),_0xe5d047['promise'];}function p_(_0x49b8b0){_0x49b8b0=k(_0x49b8b0);const _0x464964=new ua(()=>{}),_0x1088d5=new qn(_0x464964);return vd(_0x49b8b0['_repo'],_0x49b8b0,_0x1088d5)['then'](_0x5cb5f5=>new rt(_0x5cb5f5,new Z(_0x49b8b0['_repo'],_0x49b8b0['_path']),_0x49b8b0['_queryParams']['getIndex']()));}class qn{constructor(_0x31a16e){this['callbackContext']=_0x31a16e;}['respondsTo'](_0x45e24f){return _0x45e24f==='value';}['createEvent'](_0x2b4c40,_0x45a512){const _0x4014e2=_0x45a512['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x2b4c40['snapshotNode'],new Z(_0x45a512['_repo'],_0x45a512['_path']),_0x4014e2));}['getEventRunner'](_0x5a48b5){return _0x5a48b5['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x5a48b5['error']):()=>this['callbackContext']['onValue'](_0x5a48b5['snapshot'],null);}['createCancelEvent'](_0x44934a,_0x6f63df){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x44934a,_0x6f63df):null;}['matches'](_0x2893be){return _0x2893be instanceof qn?!_0x2893be['callbackContext']||!this['callbackContext']?!0x0:_0x2893be['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x4c3564,_0x15a863,_0x5da28a,_0x502f58,_0x2990e3){const _0x85bcb9=new ua(_0x5da28a,void 0x0),_0x51618=new qn(_0x85bcb9);return Cd(_0x4c3564['_repo'],_0x4c3564,_0x51618),()=>Td(_0x4c3564['_repo'],_0x4c3564,_0x51618);}function Fd(_0x54fb65,_0x19cecf,_0x49551e,_0x4e605e){return xd(_0x54fb65,'value',_0x19cecf);}class dt{}class pa extends dt{constructor(_0x58f9d4,_0x5420bf){super(),this['_value']=_0x58f9d4,this['_key']=_0x5420bf,this['type']='endAt';}['_apply'](_0x327a18){qt('endAt',this['_value'],_0x327a18['_path'],!0x0);const _0x11195e=Kh(_0x327a18['_queryParams'],this['_value'],this['_key']);if(fa(_0x11195e),Gn(_0x11195e),_0x327a18['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x327a18['_repo'],_0x327a18['_path'],_0x11195e,_0x327a18['_orderByCalled']);}}function __(_0x1717de,_0x2374ed){return new pa(_0x1717de,_0x2374ed);}class _a extends dt{constructor(_0x574895,_0x32d185){super(),this['_value']=_0x574895,this['_key']=_0x32d185,this['type']='startAt';}['_apply'](_0x1d6b02){qt('startAt',this['_value'],_0x1d6b02['_path'],!0x0);const _0x277a9f=jh(_0x1d6b02['_queryParams'],this['_value'],this['_key']);if(fa(_0x277a9f),Gn(_0x277a9f),_0x1d6b02['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x1d6b02['_repo'],_0x1d6b02['_path'],_0x277a9f,_0x1d6b02['_orderByCalled']);}}function g_(_0x4119c3=null,_0x21b206){return new _a(_0x4119c3,_0x21b206);}class Ud extends dt{constructor(_0x20101f){super(),this['_limit']=_0x20101f,this['type']='limitToFirst';}['_apply'](_0x10f5a5){if(_0x10f5a5['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x10f5a5['_repo'],_0x10f5a5['_path'],zh(_0x10f5a5['_queryParams'],this['_limit']),_0x10f5a5['_orderByCalled']);}}function m_(_0x3d8e8a){if(Math['floor'](_0x3d8e8a)!==_0x3d8e8a||_0x3d8e8a<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x3d8e8a);}class Wd extends dt{constructor(_0xbb9cef){super(),this['_path']=_0xbb9cef,this['type']='orderByChild';}['_apply'](_0x2daa75){da(_0x2daa75,'orderByChild');const _0x2a3733=new C(this['_path']);if(v(_0x2a3733))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x459554=new Ki(_0x2a3733),_0x5bdff5=Do(_0x2daa75['_queryParams'],_0x459554);return Gn(_0x5bdff5),new be(_0x2daa75['_repo'],_0x2daa75['_path'],_0x5bdff5,!0x0);}}function y_(_0x3b5496){if(_0x3b5496==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x3b5496==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x3b5496==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x3b5496),new Wd(_0x3b5496);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x57c727){da(_0x57c727,'orderByKey');const _0x1cf390=Do(_0x57c727['_queryParams'],ye);return Gn(_0x1cf390),new be(_0x57c727['_repo'],_0x57c727['_path'],_0x1cf390,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x1f98f6,_0x5c8223){super(),this['_value']=_0x1f98f6,this['_key']=_0x5c8223,this['type']='equalTo';}['_apply'](_0x1a3a91){if(qt('equalTo',this['_value'],_0x1a3a91['_path'],!0x1),_0x1a3a91['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1a3a91['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x1a3a91));}}function E_(_0x555f74,_0x2918dd){return new Vd(_0x555f74,_0x2918dd);}function I_(_0x5b8de2,..._0x2f340a){let _0x5124be=k(_0x5b8de2);for(const _0x1c6b33 of _0x2f340a)_0x5124be=_0x1c6b33['_apply'](_0x5124be);return _0x5124be;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x1a1c1c,_0x2215f3,_0x5bbc75,_0x3da182){const _0x553178=_0x2215f3['lastIndexOf'](':'),_0x25676e=_0x2215f3['substring'](0x0,_0x553178),_0x3f7ca5=Wt(_0x25676e);_0x1a1c1c['repoInfo_']=new _o(_0x2215f3,_0x3f7ca5,_0x1a1c1c['repoInfo_']['namespace'],_0x1a1c1c['repoInfo_']['webSocketOnly'],_0x1a1c1c['repoInfo_']['nodeAdmin'],_0x1a1c1c['repoInfo_']['persistenceKey'],_0x1a1c1c['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x5bbc75),_0x3da182&&(_0x1a1c1c['authTokenProvider_']=_0x3da182);}function qd(_0x180041,_0x29dbd1,_0x3b6c7a,_0x479d7e,_0x684358){let _0x4e504d=_0x479d7e||_0x180041['options']['databaseURL'];_0x4e504d===void 0x0&&(_0x180041['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x180041['options']['projectId']),_0x4e504d=_0x180041['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2bea39=gr(_0x4e504d,_0x684358),_0xff875b=_0x2bea39['repoInfo'],_0x323adb;typeof process<'u'&&Us&&(_0x323adb=Us[Hd]),_0x323adb?(_0x4e504d='http://'+_0x323adb+'?ns='+_0xff875b['namespace'],_0x2bea39=gr(_0x4e504d,_0x684358),_0xff875b=_0x2bea39['repoInfo']):_0x2bea39['repoInfo']['secure'];const _0x5d4d4e=new Jl(_0x180041['name'],_0x180041['options'],_0x29dbd1);dd('Invalid\x20Firebase\x20Database\x20URL',_0x2bea39),v(_0x2bea39['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0xdfcb0c=jd(_0xff875b,_0x180041,_0x5d4d4e,new Ql(_0x180041,_0x3b6c7a));return new Kd(_0xdfcb0c,_0x180041);}function zd(_0x3401e6,_0x2a2091){const _0x27a626=ki[_0x2a2091];(!_0x27a626||_0x27a626[_0x3401e6['key']]!==_0x3401e6)&&oe('Database\x20'+_0x2a2091+'('+_0x3401e6['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x3401e6),delete _0x27a626[_0x3401e6['key']];}function jd(_0x3bc917,_0x4234e4,_0x17fdd6,_0x138aae){let _0x54a7c2=ki[_0x4234e4['name']];_0x54a7c2||(_0x54a7c2={},ki[_0x4234e4['name']]=_0x54a7c2);let _0x4d0097=_0x54a7c2[_0x3bc917['toURLString']()];return _0x4d0097&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4d0097=new gd(_0x3bc917,$d,_0x17fdd6,_0x138aae),_0x54a7c2[_0x3bc917['toURLString']()]=_0x4d0097,_0x4d0097;}class Kd{constructor(_0x56992d,_0x482025){this['_repoInternal']=_0x56992d,this['app']=_0x482025,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x22495e){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x22495e+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x4ad30f=Qr(),_0x594bd2){const _0x2328c2=Ui(_0x4ad30f,'database')['getImmediate']({'identifier':_0x594bd2});if(!_0x2328c2['_instanceStarted']){const _0x4fde97=ac('database');_0x4fde97&&Yd(_0x2328c2,..._0x4fde97);}return _0x2328c2;}function Yd(_0x78dd26,_0x593e72,_0x189264,_0x175fbf={}){_0x78dd26=k(_0x78dd26),_0x78dd26['_checkNotDeleted']('useEmulator');const _0x2329ce=_0x593e72+':'+_0x189264,_0x47e97e=_0x78dd26['_repoInternal'];if(_0x78dd26['_instanceStarted']){if(_0x2329ce===_0x78dd26['_repoInternal']['repoInfo_']['host']&&De(_0x175fbf,_0x47e97e['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4110b9;if(_0x47e97e['repoInfo_']['nodeAdmin'])_0x175fbf['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4110b9=new tn(tn['OWNER']);else{if(_0x175fbf['mockUserToken']){const _0x47ae26=typeof _0x175fbf['mockUserToken']=='string'?_0x175fbf['mockUserToken']:cc(_0x175fbf['mockUserToken'],_0x78dd26['app']['options']['projectId']);_0x4110b9=new tn(_0x47ae26);}}Wt(_0x593e72)&&jr(_0x593e72),Gd(_0x47e97e,_0x2329ce,_0x175fbf,_0x4110b9);}function C_(_0x4de778){_0x4de778=k(_0x4de778),_0x4de778['_checkNotDeleted']('goOffline'),aa(_0x4de778['_repo']);}function T_(_0x172102){_0x172102=k(_0x172102),_0x172102['_checkNotDeleted']('goOnline'),Sd(_0x172102['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x2336a7){Ll(ct),et(new Me('database',(_0x479ea7,{instanceIdentifier:_0x3512a6})=>{const _0x31ae0a=_0x479ea7['getProvider']('app')['getImmediate'](),_0x4ae5d5=_0x479ea7['getProvider']('auth-internal'),_0x13ec0c=_0x479ea7['getProvider']('app-check-internal');return qd(_0x31ae0a,_0x4ae5d5,_0x13ec0c,_0x3512a6);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x2336a7),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x2fed76,_0x1dcaf5){this['committed']=_0x2fed76,this['snapshot']=_0x1dcaf5;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x2aafa1,_0x57e0f6,_0x17f149){if(_0x2aafa1=k(_0x2aafa1),gs('Reference.transaction',_0x2aafa1['_path']),_0x2aafa1['key']==='.length'||_0x2aafa1['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x2aafa1['key']+'\x20is\x20a\x20read-only\x20object.';const _0x2b5f05=!0x0,_0x2e6a3e=new Ve(),_0x5c194e=(_0x5a9883,_0x200df7,_0x4da97d)=>{let _0xf5efd=null;_0x5a9883?_0x2e6a3e['reject'](_0x5a9883):(_0xf5efd=new rt(_0x4da97d,new Z(_0x2aafa1['_repo'],_0x2aafa1['_path']),R),_0x2e6a3e['resolve'](new Xd(_0x200df7,_0xf5efd)));},_0x231a12=Fd(_0x2aafa1,()=>{});return bd(_0x2aafa1['_repo'],_0x2aafa1['_path'],_0x57e0f6,_0x5c194e,_0x231a12,_0x2b5f05),_0x2e6a3e['promise'];}ie['prototype']['simpleListen']=function(_0x4ece21,_0x2d4f04){this['sendRequest']('q',{'p':_0x4ece21},_0x2d4f04);},ie['prototype']['echo']=function(_0x78e13d,_0x947210){this['sendRequest']('echo',{'d':_0x78e13d},_0x947210);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x3d012e,..._0xe50309){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x3d012e,..._0xe50309);}function nn(_0x1da933,..._0x4c3d06){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x1da933,..._0x4c3d06);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x2880a6,..._0x14521d){throw Es(_0x2880a6,..._0x14521d);}function J(_0x55abd3,..._0x3a7098){return Es(_0x55abd3,..._0x3a7098);}function ya(_0xacae33,_0x37478d,_0x27c7cb){const _0x50dd27={...Zd(),[_0x37478d]:_0x27c7cb};return new Ut('auth','Firebase',_0x50dd27)['create'](_0x37478d,{'appName':_0xacae33['name']});}function se(_0x1c01bf){return ya(_0x1c01bf,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x5c3bc3,..._0x1b37ca){if(typeof _0x5c3bc3!='string'){const _0x32d455=_0x1b37ca[0x0],_0x16e39d=[..._0x1b37ca['slice'](0x1)];return _0x16e39d[0x0]&&(_0x16e39d[0x0]['appName']=_0x5c3bc3['name']),_0x5c3bc3['_errorFactory']['create'](_0x32d455,..._0x16e39d);}return ma['create'](_0x5c3bc3,..._0x1b37ca);}function m(_0x5c7db4,_0x2abefa,..._0x342138){if(!_0x5c7db4)throw Es(_0x2abefa,..._0x342138);}function te(_0x370f63){const _0x4263f0='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x370f63;throw nn(_0x4263f0),new Error(_0x4263f0);}function ae(_0x7f8cbf,_0x43e166){_0x7f8cbf||te(_0x43e166);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x48dcb6;return typeof self<'u'&&((_0x48dcb6=self['location'])==null?void 0x0:_0x48dcb6['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x1422ad;return typeof self<'u'&&((_0x1422ad=self['location'])==null?void 0x0:_0x1422ad['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x46dbb4=navigator;return _0x46dbb4['languages']&&_0x46dbb4['languages'][0x0]||_0x46dbb4['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x4f0be3,_0xa0dde1){this['shortDelay']=_0x4f0be3,this['longDelay']=_0xa0dde1,ae(_0xa0dde1>_0x4f0be3,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x1355ad,_0x262628){ae(_0x1355ad['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0xe4ed8b}=_0x1355ad['emulator'];return _0x262628?''+_0xe4ed8b+(_0x262628['startsWith']('/')?_0x262628['slice'](0x1):_0x262628):_0xe4ed8b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x879d35,_0x711d04,_0x7fbb09){this['fetchImpl']=_0x879d35,_0x711d04&&(this['headersImpl']=_0x711d04),_0x7fbb09&&(this['responseImpl']=_0x7fbb09);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x4a7a89,_0x39d4d7){return _0x4a7a89['tenantId']&&!_0x39d4d7['tenantId']?{..._0x39d4d7,'tenantId':_0x4a7a89['tenantId']}:_0x39d4d7;}async function Ae(_0x40300b,_0x5bd521,_0x42f1fc,_0x1d761c,_0xd2aab9={}){return Ea(_0x40300b,_0xd2aab9,async()=>{let _0x49c4b1={},_0xdfe3ab={};_0x1d761c&&(_0x5bd521==='GET'?_0xdfe3ab=_0x1d761c:_0x49c4b1={'body':JSON['stringify'](_0x1d761c)});const _0xc60d66=at({..._0xdfe3ab,'key':_0x40300b['config']['apiKey']})['slice'](0x1),_0x2a1d26=await _0x40300b['_getAdditionalHeaders']();_0x2a1d26['Content-Type']='application/json',_0x40300b['languageCode']&&(_0x2a1d26['X-Firebase-Locale']=_0x40300b['languageCode']);const _0x541bb6={'method':_0x5bd521,'headers':_0x2a1d26,..._0x49c4b1};return lc()||(_0x541bb6['referrerPolicy']='strict-origin-when-cross-origin'),_0x40300b['emulatorConfig']&&Wt(_0x40300b['emulatorConfig']['host'])&&(_0x541bb6['credentials']='include'),va['fetch']()(await Ia(_0x40300b,_0x40300b['config']['apiHost'],_0x42f1fc,_0xc60d66),_0x541bb6);});}async function Ea(_0x4518c5,_0x5b3ceb,_0x5f395f){_0x4518c5['_canInitEmulator']=!0x1;const _0x43e5ef={...rf,..._0x5b3ceb};try{const _0x4bc3a7=new lf(_0x4518c5),_0x3e669a=await Promise['race']([_0x5f395f(),_0x4bc3a7['promise']]);_0x4bc3a7['clearNetworkTimeout']();const _0x4c25e7=await _0x3e669a['json']();if('needConfirmation'in _0x4c25e7)throw en(_0x4518c5,'account-exists-with-different-credential',_0x4c25e7);if(_0x3e669a['ok']&&!('errorMessage'in _0x4c25e7))return _0x4c25e7;{const _0x236bc2=_0x3e669a['ok']?_0x4c25e7['errorMessage']:_0x4c25e7['error']['message'],[_0x4b4d00,_0x56ff73]=_0x236bc2['split']('\x20:\x20');if(_0x4b4d00==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x4518c5,'credential-already-in-use',_0x4c25e7);if(_0x4b4d00==='EMAIL_EXISTS')throw en(_0x4518c5,'email-already-in-use',_0x4c25e7);if(_0x4b4d00==='USER_DISABLED')throw en(_0x4518c5,'user-disabled',_0x4c25e7);const _0xfe759e=_0x43e5ef[_0x4b4d00]||_0x4b4d00['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x56ff73)throw ya(_0x4518c5,_0xfe759e,_0x56ff73);K(_0x4518c5,_0xfe759e);}}catch(_0x4d06ac){if(_0x4d06ac instanceof Se)throw _0x4d06ac;K(_0x4518c5,'network-request-failed',{'message':String(_0x4d06ac)});}}async function Yt(_0x185ac2,_0x562efc,_0x4cadd7,_0x4ed3fb,_0x2057b0={}){const _0x10e180=await Ae(_0x185ac2,_0x562efc,_0x4cadd7,_0x4ed3fb,_0x2057b0);return'mfaPendingCredential'in _0x10e180&&K(_0x185ac2,'multi-factor-auth-required',{'_serverResponse':_0x10e180}),_0x10e180;}async function Ia(_0x156456,_0x3883ac,_0x5bbfcc,_0x2b6d39){const _0x1ed193=''+_0x3883ac+_0x5bbfcc+'?'+_0x2b6d39,_0x16eb7b=_0x156456,_0x43632d=_0x16eb7b['config']['emulator']?Is(_0x156456['config'],_0x1ed193):_0x156456['config']['apiScheme']+'://'+_0x1ed193;return of['includes'](_0x5bbfcc)&&(await _0x16eb7b['_persistenceManagerAvailable'],_0x16eb7b['_getPersistenceType']()==='COOKIE')?_0x16eb7b['_getPersistence']()['_getFinalTarget'](_0x43632d)['toString']():_0x43632d;}function cf(_0x4d695c){switch(_0x4d695c){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3b21ad){this['auth']=_0x3b21ad,this['timer']=null,this['promise']=new Promise((_0x3aa3c7,_0x1a922d)=>{this['timer']=setTimeout(()=>_0x1a922d(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x5707fd,_0x49ba33,_0xe323d0){const _0x36bcba={'appName':_0x5707fd['name']};_0xe323d0['email']&&(_0x36bcba['email']=_0xe323d0['email']),_0xe323d0['phoneNumber']&&(_0x36bcba['phoneNumber']=_0xe323d0['phoneNumber']);const _0x3349ea=J(_0x5707fd,_0x49ba33,_0x36bcba);return _0x3349ea['customData']['_tokenResponse']=_0xe323d0,_0x3349ea;}function vr(_0x5b18e7){return _0x5b18e7!==void 0x0&&_0x5b18e7['enterprise']!==void 0x0;}class hf{constructor(_0x5a277b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5a277b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5a277b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5a277b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0xe5d0e3){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3564e9 of this['recaptchaEnforcementState'])if(_0x3564e9['provider']&&_0x3564e9['provider']===_0xe5d0e3)return cf(_0x3564e9['enforcementState']);return null;}['isProviderEnabled'](_0x257c6b){return this['getProviderEnforcementState'](_0x257c6b)==='ENFORCE'||this['getProviderEnforcementState'](_0x257c6b)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x3059ef,_0x3f072b){return Ae(_0x3059ef,'GET','/v2/recaptchaConfig',Re(_0x3059ef,_0x3f072b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x39d1c4,_0x162ffd){return Ae(_0x39d1c4,'POST','/v1/accounts:delete',_0x162ffd);}async function Sn(_0x491507,_0x53c3a0){return Ae(_0x491507,'POST','/v1/accounts:lookup',_0x53c3a0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x14493d){if(_0x14493d)try{const _0x15d1cb=new Date(Number(_0x14493d));if(!isNaN(_0x15d1cb['getTime']()))return _0x15d1cb['toUTCString']();}catch{}}async function ff(_0x46c997,_0x4f2704=!0x1){const _0x38e099=k(_0x46c997),_0x394675=await _0x38e099['getIdToken'](_0x4f2704),_0x15be0d=ws(_0x394675);m(_0x15be0d&&_0x15be0d['exp']&&_0x15be0d['auth_time']&&_0x15be0d['iat'],_0x38e099['auth'],'internal-error');const _0x4d57b5=typeof _0x15be0d['firebase']=='object'?_0x15be0d['firebase']:void 0x0,_0x3b7ddf=_0x4d57b5==null?void 0x0:_0x4d57b5['sign_in_provider'];return{'claims':_0x15be0d,'token':_0x394675,'authTime':St(ci(_0x15be0d['auth_time'])),'issuedAtTime':St(ci(_0x15be0d['iat'])),'expirationTime':St(ci(_0x15be0d['exp'])),'signInProvider':_0x3b7ddf||null,'signInSecondFactor':(_0x4d57b5==null?void 0x0:_0x4d57b5['sign_in_second_factor'])||null};}function ci(_0x10ea55){return Number(_0x10ea55)*0x3e8;}function ws(_0x5bccfd){const [_0x5a2d61,_0x37109b,_0xdf1573]=_0x5bccfd['split']('.');if(_0x5a2d61===void 0x0||_0x37109b===void 0x0||_0xdf1573===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2e63d1=cn(_0x37109b);return _0x2e63d1?JSON['parse'](_0x2e63d1):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x147896){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x147896==null?void 0x0:_0x147896['toString']()),null;}}function Er(_0xa1b3df){const _0x4016c2=ws(_0xa1b3df);return m(_0x4016c2,'internal-error'),m(typeof _0x4016c2['exp']<'u','internal-error'),m(typeof _0x4016c2['iat']<'u','internal-error'),Number(_0x4016c2['exp'])-Number(_0x4016c2['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0xa9ae69,_0x358f1e,_0x1e45eb=!0x1){if(_0x1e45eb)return _0x358f1e;try{return await _0x358f1e;}catch(_0x4e56c3){throw _0x4e56c3 instanceof Se&&pf(_0x4e56c3)&&_0xa9ae69['auth']['currentUser']===_0xa9ae69&&await _0xa9ae69['auth']['signOut'](),_0x4e56c3;}}function pf({code:_0x57a273}){return _0x57a273==='auth/user-disabled'||_0x57a273==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x1132ec){this['user']=_0x1132ec,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2a70ef){if(_0x2a70ef){const _0x5e719e=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x5e719e;}else{this['errorBackoff']=0x7530;const _0x1cc741=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1cc741);}}['schedule'](_0x35c8d8=!0x1){if(!this['isRunning'])return;const _0x13e286=this['getInterval'](_0x35c8d8);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x13e286);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x3f9df1){(_0x3f9df1==null?void 0x0:_0x3f9df1['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x4fa905,_0x352393){this['createdAt']=_0x4fa905,this['lastLoginAt']=_0x352393,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x456251){this['createdAt']=_0x456251['createdAt'],this['lastLoginAt']=_0x456251['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x536ac3){var _0x1a4c63;const _0x1ca1fe=_0x536ac3['auth'],_0x37c3fc=await _0x536ac3['getIdToken'](),_0x24af85=await xt(_0x536ac3,Sn(_0x1ca1fe,{'idToken':_0x37c3fc}));m(_0x24af85==null?void 0x0:_0x24af85['users']['length'],_0x1ca1fe,'internal-error');const _0xe455c7=_0x24af85['users'][0x0];_0x536ac3['_notifyReloadListener'](_0xe455c7);const _0x582f79=(_0x1a4c63=_0xe455c7['providerUserInfo'])!=null&&_0x1a4c63['length']?wa(_0xe455c7['providerUserInfo']):[],_0x354832=mf(_0x536ac3['providerData'],_0x582f79),_0x315170=_0x536ac3['isAnonymous'],_0x3db616=!(_0x536ac3['email']&&_0xe455c7['passwordHash'])&&!(_0x354832!=null&&_0x354832['length']),_0x49994d=_0x315170?_0x3db616:!0x1,_0x389975={'uid':_0xe455c7['localId'],'displayName':_0xe455c7['displayName']||null,'photoURL':_0xe455c7['photoUrl']||null,'email':_0xe455c7['email']||null,'emailVerified':_0xe455c7['emailVerified']||!0x1,'phoneNumber':_0xe455c7['phoneNumber']||null,'tenantId':_0xe455c7['tenantId']||null,'providerData':_0x354832,'metadata':new Pi(_0xe455c7['createdAt'],_0xe455c7['lastLoginAt']),'isAnonymous':_0x49994d};Object['assign'](_0x536ac3,_0x389975);}async function gf(_0x407c15){const _0x3f6a43=k(_0x407c15);await bn(_0x3f6a43),await _0x3f6a43['auth']['_persistUserIfCurrent'](_0x3f6a43),_0x3f6a43['auth']['_notifyListenersIfCurrent'](_0x3f6a43);}function mf(_0x15db59,_0x168e74){return[..._0x15db59['filter'](_0x5b7a95=>!_0x168e74['some'](_0x10f0f2=>_0x10f0f2['providerId']===_0x5b7a95['providerId'])),..._0x168e74];}function wa(_0x587e84){return _0x587e84['map'](({providerId:_0x180b36,..._0xa8899})=>({'providerId':_0x180b36,'uid':_0xa8899['rawId']||'','displayName':_0xa8899['displayName']||null,'email':_0xa8899['email']||null,'phoneNumber':_0xa8899['phoneNumber']||null,'photoURL':_0xa8899['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x16ee72,_0x5f69ec){const _0x3281fd=await Ea(_0x16ee72,{},async()=>{const _0x1a8aee=at({'grant_type':'refresh_token','refresh_token':_0x5f69ec})['slice'](0x1),{tokenApiHost:_0x50184a,apiKey:_0x4d18c9}=_0x16ee72['config'],_0x464987=await Ia(_0x16ee72,_0x50184a,'/v1/token','key='+_0x4d18c9),_0x1fd0b9=await _0x16ee72['_getAdditionalHeaders']();_0x1fd0b9['Content-Type']='application/x-www-form-urlencoded';const _0x3be7b1={'method':'POST','headers':_0x1fd0b9,'body':_0x1a8aee};return _0x16ee72['emulatorConfig']&&Wt(_0x16ee72['emulatorConfig']['host'])&&(_0x3be7b1['credentials']='include'),va['fetch']()(_0x464987,_0x3be7b1);});return{'accessToken':_0x3281fd['access_token'],'expiresIn':_0x3281fd['expires_in'],'refreshToken':_0x3281fd['refresh_token']};}async function vf(_0xc0445,_0x1b3e94){return Ae(_0xc0445,'POST','/v2/accounts:revokeToken',Re(_0xc0445,_0x1b3e94));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xbab8f2){m(_0xbab8f2['idToken'],'internal-error'),m(typeof _0xbab8f2['idToken']<'u','internal-error'),m(typeof _0xbab8f2['refreshToken']<'u','internal-error');const _0x22c51f='expiresIn'in _0xbab8f2&&typeof _0xbab8f2['expiresIn']<'u'?Number(_0xbab8f2['expiresIn']):Er(_0xbab8f2['idToken']);this['updateTokensAndExpiration'](_0xbab8f2['idToken'],_0xbab8f2['refreshToken'],_0x22c51f);}['updateFromIdToken'](_0xa9cda5){m(_0xa9cda5['length']!==0x0,'internal-error');const _0x4a2df0=Er(_0xa9cda5);this['updateTokensAndExpiration'](_0xa9cda5,null,_0x4a2df0);}async['getToken'](_0x5af3d2,_0x484833=!0x1){return!_0x484833&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x5af3d2,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x5af3d2,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x48efdd,_0x3d91f9){const {accessToken:_0x1e1468,refreshToken:_0x4e8cdc,expiresIn:_0x3b8658}=await yf(_0x48efdd,_0x3d91f9);this['updateTokensAndExpiration'](_0x1e1468,_0x4e8cdc,Number(_0x3b8658));}['updateTokensAndExpiration'](_0x25cbf7,_0x16b6f7,_0x23bf25){this['refreshToken']=_0x16b6f7||null,this['accessToken']=_0x25cbf7||null,this['expirationTime']=Date['now']()+_0x23bf25*0x3e8;}static['fromJSON'](_0x24e357,_0x252142){const {refreshToken:_0x56a4fe,accessToken:_0x1cf436,expirationTime:_0x2e6361}=_0x252142,_0x3f1d54=new Je();return _0x56a4fe&&(m(typeof _0x56a4fe=='string','internal-error',{'appName':_0x24e357}),_0x3f1d54['refreshToken']=_0x56a4fe),_0x1cf436&&(m(typeof _0x1cf436=='string','internal-error',{'appName':_0x24e357}),_0x3f1d54['accessToken']=_0x1cf436),_0x2e6361&&(m(typeof _0x2e6361=='number','internal-error',{'appName':_0x24e357}),_0x3f1d54['expirationTime']=_0x2e6361),_0x3f1d54;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x43730c){this['accessToken']=_0x43730c['accessToken'],this['refreshToken']=_0x43730c['refreshToken'],this['expirationTime']=_0x43730c['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x50f64d,_0x4c841e){m(typeof _0x50f64d=='string'||typeof _0x50f64d>'u','internal-error',{'appName':_0x4c841e});}class z{constructor({uid:_0x2fd16a,auth:_0x1bde23,stsTokenManager:_0x389e41,..._0x2d989d}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2fd16a,this['auth']=_0x1bde23,this['stsTokenManager']=_0x389e41,this['accessToken']=_0x389e41['accessToken'],this['displayName']=_0x2d989d['displayName']||null,this['email']=_0x2d989d['email']||null,this['emailVerified']=_0x2d989d['emailVerified']||!0x1,this['phoneNumber']=_0x2d989d['phoneNumber']||null,this['photoURL']=_0x2d989d['photoURL']||null,this['isAnonymous']=_0x2d989d['isAnonymous']||!0x1,this['tenantId']=_0x2d989d['tenantId']||null,this['providerData']=_0x2d989d['providerData']?[..._0x2d989d['providerData']]:[],this['metadata']=new Pi(_0x2d989d['createdAt']||void 0x0,_0x2d989d['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2d1fc5){const _0x3f219d=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x2d1fc5));return m(_0x3f219d,this['auth'],'internal-error'),this['accessToken']!==_0x3f219d&&(this['accessToken']=_0x3f219d,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3f219d;}['getIdTokenResult'](_0x3a79da){return ff(this,_0x3a79da);}['reload'](){return gf(this);}['_assign'](_0x1d9b19){this!==_0x1d9b19&&(m(this['uid']===_0x1d9b19['uid'],this['auth'],'internal-error'),this['displayName']=_0x1d9b19['displayName'],this['photoURL']=_0x1d9b19['photoURL'],this['email']=_0x1d9b19['email'],this['emailVerified']=_0x1d9b19['emailVerified'],this['phoneNumber']=_0x1d9b19['phoneNumber'],this['isAnonymous']=_0x1d9b19['isAnonymous'],this['tenantId']=_0x1d9b19['tenantId'],this['providerData']=_0x1d9b19['providerData']['map'](_0x30ae1f=>({..._0x30ae1f})),this['metadata']['_copy'](_0x1d9b19['metadata']),this['stsTokenManager']['_assign'](_0x1d9b19['stsTokenManager']));}['_clone'](_0x2ddbb0){const _0x24cc4c=new z({...this,'auth':_0x2ddbb0,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x24cc4c['metadata']['_copy'](this['metadata']),_0x24cc4c;}['_onReload'](_0x59eb7a){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x59eb7a,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x356172){this['reloadListener']?this['reloadListener'](_0x356172):this['reloadUserInfo']=_0x356172;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2511de,_0x3d5ec4=!0x1){let _0x10b3f6=!0x1;_0x2511de['idToken']&&_0x2511de['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2511de),_0x10b3f6=!0x0),_0x3d5ec4&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x10b3f6&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x349e73=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x349e73})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x471ef0=>({..._0x471ef0})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x1d514f,_0x44899c){const _0x25e653=_0x44899c['displayName']??void 0x0,_0x23a646=_0x44899c['email']??void 0x0,_0x1e4c73=_0x44899c['phoneNumber']??void 0x0,_0x48c081=_0x44899c['photoURL']??void 0x0,_0x5ad7ab=_0x44899c['tenantId']??void 0x0,_0x128e9a=_0x44899c['_redirectEventId']??void 0x0,_0x124d6f=_0x44899c['createdAt']??void 0x0,_0x235a2f=_0x44899c['lastLoginAt']??void 0x0,{uid:_0xd1347a,emailVerified:_0x51f83a,isAnonymous:_0x54f9c8,providerData:_0x5e9132,stsTokenManager:_0x394e07}=_0x44899c;m(_0xd1347a&&_0x394e07,_0x1d514f,'internal-error');const _0x14ecce=Je['fromJSON'](this['name'],_0x394e07);m(typeof _0xd1347a=='string',_0x1d514f,'internal-error'),ce(_0x25e653,_0x1d514f['name']),ce(_0x23a646,_0x1d514f['name']),m(typeof _0x51f83a=='boolean',_0x1d514f,'internal-error'),m(typeof _0x54f9c8=='boolean',_0x1d514f,'internal-error'),ce(_0x1e4c73,_0x1d514f['name']),ce(_0x48c081,_0x1d514f['name']),ce(_0x5ad7ab,_0x1d514f['name']),ce(_0x128e9a,_0x1d514f['name']),ce(_0x124d6f,_0x1d514f['name']),ce(_0x235a2f,_0x1d514f['name']);const _0x190de7=new z({'uid':_0xd1347a,'auth':_0x1d514f,'email':_0x23a646,'emailVerified':_0x51f83a,'displayName':_0x25e653,'isAnonymous':_0x54f9c8,'photoURL':_0x48c081,'phoneNumber':_0x1e4c73,'tenantId':_0x5ad7ab,'stsTokenManager':_0x14ecce,'createdAt':_0x124d6f,'lastLoginAt':_0x235a2f});return _0x5e9132&&Array['isArray'](_0x5e9132)&&(_0x190de7['providerData']=_0x5e9132['map'](_0x4e54af=>({..._0x4e54af}))),_0x128e9a&&(_0x190de7['_redirectEventId']=_0x128e9a),_0x190de7;}static async['_fromIdTokenResponse'](_0x50b930,_0x5078f9,_0x167912=!0x1){const _0x3f36ef=new Je();_0x3f36ef['updateFromServerResponse'](_0x5078f9);const _0x5c73b0=new z({'uid':_0x5078f9['localId'],'auth':_0x50b930,'stsTokenManager':_0x3f36ef,'isAnonymous':_0x167912});return await bn(_0x5c73b0),_0x5c73b0;}static async['_fromGetAccountInfoResponse'](_0x323457,_0x4b49bd,_0x373378){const _0x472e0b=_0x4b49bd['users'][0x0];m(_0x472e0b['localId']!==void 0x0,'internal-error');const _0xe23537=_0x472e0b['providerUserInfo']!==void 0x0?wa(_0x472e0b['providerUserInfo']):[],_0x5401ba=!(_0x472e0b['email']&&_0x472e0b['passwordHash'])&&!(_0xe23537!=null&&_0xe23537['length']),_0xe652c1=new Je();_0xe652c1['updateFromIdToken'](_0x373378);const _0x2072a7=new z({'uid':_0x472e0b['localId'],'auth':_0x323457,'stsTokenManager':_0xe652c1,'isAnonymous':_0x5401ba}),_0x56fdf8={'uid':_0x472e0b['localId'],'displayName':_0x472e0b['displayName']||null,'photoURL':_0x472e0b['photoUrl']||null,'email':_0x472e0b['email']||null,'emailVerified':_0x472e0b['emailVerified']||!0x1,'phoneNumber':_0x472e0b['phoneNumber']||null,'tenantId':_0x472e0b['tenantId']||null,'providerData':_0xe23537,'metadata':new Pi(_0x472e0b['createdAt'],_0x472e0b['lastLoginAt']),'isAnonymous':!(_0x472e0b['email']&&_0x472e0b['passwordHash'])&&!(_0xe23537!=null&&_0xe23537['length'])};return Object['assign'](_0x2072a7,_0x56fdf8),_0x2072a7;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x5a9e0e){ae(_0x5a9e0e instanceof Function,'Expected\x20a\x20class\x20definition');let _0x421436=Ir['get'](_0x5a9e0e);return _0x421436?(ae(_0x421436 instanceof _0x5a9e0e,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x421436):(_0x421436=new _0x5a9e0e(),Ir['set'](_0x5a9e0e,_0x421436),_0x421436);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x543522,_0x3d80d1){this['storage'][_0x543522]=_0x3d80d1;}async['_get'](_0x2695b1){const _0x3785f9=this['storage'][_0x2695b1];return _0x3785f9===void 0x0?null:_0x3785f9;}async['_remove'](_0x17c4cf){delete this['storage'][_0x17c4cf];}['_addListener'](_0x520ea7,_0x38c0ce){}['_removeListener'](_0x4d46b0,_0xc915c9){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x38ba03,_0x34211b,_0x534eb3){return'firebase:'+_0x38ba03+':'+_0x34211b+':'+_0x534eb3;}class Xe{constructor(_0x1f84b7,_0x2858a8,_0x5cbe4b){this['persistence']=_0x1f84b7,this['auth']=_0x2858a8,this['userKey']=_0x5cbe4b;const {config:_0x496eb1,name:_0x2fab66}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x496eb1['apiKey'],_0x2fab66),this['fullPersistenceKey']=sn('persistence',_0x496eb1['apiKey'],_0x2fab66),this['boundEventHandler']=_0x2858a8['_onStorageEvent']['bind'](_0x2858a8),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x14fea8){return this['persistence']['_set'](this['fullUserKey'],_0x14fea8['toJSON']());}async['getCurrentUser'](){const _0x1c8ea1=await this['persistence']['_get'](this['fullUserKey']);if(!_0x1c8ea1)return null;if(typeof _0x1c8ea1=='string'){const _0x1d2916=await Sn(this['auth'],{'idToken':_0x1c8ea1})['catch'](()=>{});return _0x1d2916?z['_fromGetAccountInfoResponse'](this['auth'],_0x1d2916,_0x1c8ea1):null;}return z['_fromJSON'](this['auth'],_0x1c8ea1);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x7a0359){if(this['persistence']===_0x7a0359)return;const _0x1c275f=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x7a0359,_0x1c275f)return this['setCurrentUser'](_0x1c275f);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x19ec47,_0x564061,_0xd3eb38='authUser'){if(!_0x564061['length'])return new Xe(ne(wr),_0x19ec47,_0xd3eb38);const _0x296a51=(await Promise['all'](_0x564061['map'](async _0x1e25a7=>{if(await _0x1e25a7['_isAvailable']())return _0x1e25a7;})))['filter'](_0x237b8e=>_0x237b8e);let _0x4362fc=_0x296a51[0x0]||ne(wr);const _0x1fbbe0=sn(_0xd3eb38,_0x19ec47['config']['apiKey'],_0x19ec47['name']);let _0x58ca53=null;for(const _0x4026fe of _0x564061)try{const _0x231fa3=await _0x4026fe['_get'](_0x1fbbe0);if(_0x231fa3){let _0x387853;if(typeof _0x231fa3=='string'){const _0x336983=await Sn(_0x19ec47,{'idToken':_0x231fa3})['catch'](()=>{});if(!_0x336983)break;_0x387853=await z['_fromGetAccountInfoResponse'](_0x19ec47,_0x336983,_0x231fa3);}else _0x387853=z['_fromJSON'](_0x19ec47,_0x231fa3);_0x4026fe!==_0x4362fc&&(_0x58ca53=_0x387853),_0x4362fc=_0x4026fe;break;}}catch{}const _0x5dd5cf=_0x296a51['filter'](_0x5b8aa2=>_0x5b8aa2['_shouldAllowMigration']);return!_0x4362fc['_shouldAllowMigration']||!_0x5dd5cf['length']?new Xe(_0x4362fc,_0x19ec47,_0xd3eb38):(_0x4362fc=_0x5dd5cf[0x0],_0x58ca53&&await _0x4362fc['_set'](_0x1fbbe0,_0x58ca53['toJSON']()),await Promise['all'](_0x564061['map'](async _0xcc275a=>{if(_0xcc275a!==_0x4362fc)try{await _0xcc275a['_remove'](_0x1fbbe0);}catch{}})),new Xe(_0x4362fc,_0x19ec47,_0xd3eb38));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x599c40){const _0xd8c25a=_0x599c40['toLowerCase']();if(_0xd8c25a['includes']('opera/')||_0xd8c25a['includes']('opr/')||_0xd8c25a['includes']('opios/'))return'Opera';if(Ra(_0xd8c25a))return'IEMobile';if(_0xd8c25a['includes']('msie')||_0xd8c25a['includes']('trident/'))return'IE';if(_0xd8c25a['includes']('edge/'))return'Edge';if(Ta(_0xd8c25a))return'Firefox';if(_0xd8c25a['includes']('silk/'))return'Silk';if(ka(_0xd8c25a))return'Blackberry';if(Na(_0xd8c25a))return'Webos';if(Sa(_0xd8c25a))return'Safari';if((_0xd8c25a['includes']('chrome/')||ba(_0xd8c25a))&&!_0xd8c25a['includes']('edge/'))return'Chrome';if(Aa(_0xd8c25a))return'Android';{const _0x4feda5=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x32638c=_0x599c40['match'](_0x4feda5);if((_0x32638c==null?void 0x0:_0x32638c['length'])===0x2)return _0x32638c[0x1];}return'Other';}function Ta(_0xf1367e=W()){return/firefox\//i['test'](_0xf1367e);}function Sa(_0x46b310=W()){const _0x38a642=_0x46b310['toLowerCase']();return _0x38a642['includes']('safari/')&&!_0x38a642['includes']('chrome/')&&!_0x38a642['includes']('crios/')&&!_0x38a642['includes']('android');}function ba(_0x20e832=W()){return/crios\//i['test'](_0x20e832);}function Ra(_0x303d6e=W()){return/iemobile/i['test'](_0x303d6e);}function Aa(_0x592dec=W()){return/android/i['test'](_0x592dec);}function ka(_0x4ec3e3=W()){return/blackberry/i['test'](_0x4ec3e3);}function Na(_0x547ed6=W()){return/webos/i['test'](_0x547ed6);}function Cs(_0x1f81c0=W()){return/iphone|ipad|ipod/i['test'](_0x1f81c0)||/macintosh/i['test'](_0x1f81c0)&&/mobile/i['test'](_0x1f81c0);}function Ef(_0x449f9e=W()){var _0x364446;return Cs(_0x449f9e)&&!!((_0x364446=window['navigator'])!=null&&_0x364446['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x122c79=W()){return Cs(_0x122c79)||Aa(_0x122c79)||Na(_0x122c79)||ka(_0x122c79)||/windows phone/i['test'](_0x122c79)||Ra(_0x122c79);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x526487,_0x5f4e9e=[]){let _0x1e3220;switch(_0x526487){case'Browser':_0x1e3220=Cr(W());break;case'Worker':_0x1e3220=Cr(W())+'-'+_0x526487;break;default:_0x1e3220=_0x526487;}const _0x598f9e=_0x5f4e9e['length']?_0x5f4e9e['join'](','):'FirebaseCore-web';return _0x1e3220+'/JsCore/'+ct+'/'+_0x598f9e;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x56b58d){this['auth']=_0x56b58d,this['queue']=[];}['pushCallback'](_0x278b2e,_0x2be399){const _0x116e8f=_0x129ada=>new Promise((_0x414108,_0x5399db)=>{try{const _0x555636=_0x278b2e(_0x129ada);_0x414108(_0x555636);}catch(_0x84a3ea){_0x5399db(_0x84a3ea);}});_0x116e8f['onAbort']=_0x2be399,this['queue']['push'](_0x116e8f);const _0x40f1a9=this['queue']['length']-0x1;return()=>{this['queue'][_0x40f1a9]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4a8cbc){if(this['auth']['currentUser']===_0x4a8cbc)return;const _0x3fea7=[];try{for(const _0x3ef648 of this['queue'])await _0x3ef648(_0x4a8cbc),_0x3ef648['onAbort']&&_0x3fea7['push'](_0x3ef648['onAbort']);}catch(_0xe16c0){_0x3fea7['reverse']();for(const _0x4a23b0 of _0x3fea7)try{_0x4a23b0();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xe16c0==null?void 0x0:_0xe16c0['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x1fea21,_0x177201={}){return Ae(_0x1fea21,'GET','/v2/passwordPolicy',Re(_0x1fea21,_0x177201));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0xcbb0e){var _0x1b64b9;const _0x15108e=_0xcbb0e['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x15108e['minPasswordLength']??Tf,_0x15108e['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x15108e['maxPasswordLength']),_0x15108e['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x15108e['containsLowercaseCharacter']),_0x15108e['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x15108e['containsUppercaseCharacter']),_0x15108e['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x15108e['containsNumericCharacter']),_0x15108e['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x15108e['containsNonAlphanumericCharacter']),this['enforcementState']=_0xcbb0e['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1b64b9=_0xcbb0e['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1b64b9['join'](''))??'',this['forceUpgradeOnSignin']=_0xcbb0e['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xcbb0e['schemaVersion'];}['validatePassword'](_0x4504a7){const _0x2d820e={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4504a7,_0x2d820e),this['validatePasswordCharacterOptions'](_0x4504a7,_0x2d820e),_0x2d820e['isValid']&&(_0x2d820e['isValid']=_0x2d820e['meetsMinPasswordLength']??!0x0),_0x2d820e['isValid']&&(_0x2d820e['isValid']=_0x2d820e['meetsMaxPasswordLength']??!0x0),_0x2d820e['isValid']&&(_0x2d820e['isValid']=_0x2d820e['containsLowercaseLetter']??!0x0),_0x2d820e['isValid']&&(_0x2d820e['isValid']=_0x2d820e['containsUppercaseLetter']??!0x0),_0x2d820e['isValid']&&(_0x2d820e['isValid']=_0x2d820e['containsNumericCharacter']??!0x0),_0x2d820e['isValid']&&(_0x2d820e['isValid']=_0x2d820e['containsNonAlphanumericCharacter']??!0x0),_0x2d820e;}['validatePasswordLengthOptions'](_0x983db4,_0x1dd775){const _0x32705d=this['customStrengthOptions']['minPasswordLength'],_0xf5dd6b=this['customStrengthOptions']['maxPasswordLength'];_0x32705d&&(_0x1dd775['meetsMinPasswordLength']=_0x983db4['length']>=_0x32705d),_0xf5dd6b&&(_0x1dd775['meetsMaxPasswordLength']=_0x983db4['length']<=_0xf5dd6b);}['validatePasswordCharacterOptions'](_0x43078d,_0x4b42f7){this['updatePasswordCharacterOptionsStatuses'](_0x4b42f7,!0x1,!0x1,!0x1,!0x1);let _0xcdc455;for(let _0x315e85=0x0;_0x315e85<_0x43078d['length'];_0x315e85++)_0xcdc455=_0x43078d['charAt'](_0x315e85),this['updatePasswordCharacterOptionsStatuses'](_0x4b42f7,_0xcdc455>='a'&&_0xcdc455<='z',_0xcdc455>='A'&&_0xcdc455<='Z',_0xcdc455>='0'&&_0xcdc455<='9',this['allowedNonAlphanumericCharacters']['includes'](_0xcdc455));}['updatePasswordCharacterOptionsStatuses'](_0x565ea5,_0x1ca841,_0x533c04,_0x7bb735,_0x555fcf){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x565ea5['containsLowercaseLetter']||(_0x565ea5['containsLowercaseLetter']=_0x1ca841)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x565ea5['containsUppercaseLetter']||(_0x565ea5['containsUppercaseLetter']=_0x533c04)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x565ea5['containsNumericCharacter']||(_0x565ea5['containsNumericCharacter']=_0x7bb735)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x565ea5['containsNonAlphanumericCharacter']||(_0x565ea5['containsNonAlphanumericCharacter']=_0x555fcf));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x3edf83,_0x18f9f5,_0x488a7f,_0x5b3c8b){this['app']=_0x3edf83,this['heartbeatServiceProvider']=_0x18f9f5,this['appCheckServiceProvider']=_0x488a7f,this['config']=_0x5b3c8b,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3edf83['name'],this['clientVersion']=_0x5b3c8b['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x3275f8=>this['_resolvePersistenceManagerAvailable']=_0x3275f8);}['_initializeWithPersistence'](_0x3bf513,_0x2dbd77){return _0x2dbd77&&(this['_popupRedirectResolver']=ne(_0x2dbd77)),this['_initializationPromise']=this['queue'](async()=>{var _0x2a885,_0x1c133c,_0x3d6386;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x3bf513),(_0x2a885=this['_resolvePersistenceManagerAvailable'])==null||_0x2a885['call'](this),!this['_deleted'])){if((_0x1c133c=this['_popupRedirectResolver'])!=null&&_0x1c133c['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2dbd77),this['lastNotifiedUid']=((_0x3d6386=this['currentUser'])==null?void 0x0:_0x3d6386['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x443862=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x443862)){if(this['currentUser']&&_0x443862&&this['currentUser']['uid']===_0x443862['uid']){this['_currentUser']['_assign'](_0x443862),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x443862,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1fffba){try{const _0x1585be=await Sn(this,{'idToken':_0x1fffba}),_0x4c5e59=await z['_fromGetAccountInfoResponse'](this,_0x1585be,_0x1fffba);await this['directlySetCurrentUser'](_0x4c5e59);}catch(_0xa2fdc2){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0xa2fdc2),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5de54b){var _0x29f179;if(H(this['app'])){const _0x3add95=this['app']['settings']['authIdToken'];return _0x3add95?new Promise(_0xf28662=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3add95)['then'](_0xf28662,_0xf28662));}):this['directlySetCurrentUser'](null);}const _0x3de444=await this['assertedPersistence']['getCurrentUser']();let _0x55949f=_0x3de444,_0x1b4b77=!0x1;if(_0x5de54b&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x59d562=(_0x29f179=this['redirectUser'])==null?void 0x0:_0x29f179['_redirectEventId'],_0x47eebc=_0x55949f==null?void 0x0:_0x55949f['_redirectEventId'],_0x579161=await this['tryRedirectSignIn'](_0x5de54b);(!_0x59d562||_0x59d562===_0x47eebc)&&(_0x579161!=null&&_0x579161['user'])&&(_0x55949f=_0x579161['user'],_0x1b4b77=!0x0);}if(!_0x55949f)return this['directlySetCurrentUser'](null);if(!_0x55949f['_redirectEventId']){if(_0x1b4b77)try{await this['beforeStateQueue']['runMiddleware'](_0x55949f);}catch(_0x5a205b){_0x55949f=_0x3de444,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x5a205b));}return _0x55949f?this['reloadAndSetCurrentUserOrClear'](_0x55949f):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x55949f['_redirectEventId']?this['directlySetCurrentUser'](_0x55949f):this['reloadAndSetCurrentUserOrClear'](_0x55949f);}async['tryRedirectSignIn'](_0x53fa1b){let _0x674819=null;try{_0x674819=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x53fa1b,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x674819;}async['reloadAndSetCurrentUserOrClear'](_0x49185e){try{await bn(_0x49185e);}catch(_0x155682){if((_0x155682==null?void 0x0:_0x155682['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x49185e);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2c0b27){if(H(this['app']))return Promise['reject'](se(this));const _0x26d69=_0x2c0b27?k(_0x2c0b27):null;return _0x26d69&&m(_0x26d69['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x26d69&&_0x26d69['_clone'](this));}async['_updateCurrentUser'](_0x245663,_0x2991ca=!0x1){if(!this['_deleted'])return _0x245663&&m(this['tenantId']===_0x245663['tenantId'],this,'tenant-id-mismatch'),_0x2991ca||await this['beforeStateQueue']['runMiddleware'](_0x245663),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x245663),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3541f4){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x3541f4));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xcfc831){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1fbaa4=this['_getPasswordPolicyInternal']();return _0x1fbaa4['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1fbaa4['validatePassword'](_0xcfc831);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x53c230=await Cf(this),_0x3c8ac5=new Sf(_0x53c230);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3c8ac5:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3c8ac5;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x26125f){this['_errorFactory']=new Ut('auth','Firebase',_0x26125f());}['onAuthStateChanged'](_0x5b0516,_0x27af26,_0x4f91a4){return this['registerStateListener'](this['authStateSubscription'],_0x5b0516,_0x27af26,_0x4f91a4);}['beforeAuthStateChanged'](_0x36b475,_0x2ef458){return this['beforeStateQueue']['pushCallback'](_0x36b475,_0x2ef458);}['onIdTokenChanged'](_0x1a48a3,_0x1804e8,_0x5cbaec){return this['registerStateListener'](this['idTokenSubscription'],_0x1a48a3,_0x1804e8,_0x5cbaec);}['authStateReady'](){return new Promise((_0x36e698,_0x27b2b8)=>{if(this['currentUser'])_0x36e698();else{const _0x14caf2=this['onAuthStateChanged'](()=>{_0x14caf2(),_0x36e698();},_0x27b2b8);}});}async['revokeAccessToken'](_0x2ecbe8){if(this['currentUser']){const _0x18d7da=await this['currentUser']['getIdToken'](),_0x197781={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2ecbe8,'idToken':_0x18d7da};this['tenantId']!=null&&(_0x197781['tenantId']=this['tenantId']),await vf(this,_0x197781);}}['toJSON'](){var _0x138b8d;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x138b8d=this['_currentUser'])==null?void 0x0:_0x138b8d['toJSON']()};}async['_setRedirectUser'](_0x309d45,_0x1e23f2){const _0x57c46b=await this['getOrInitRedirectPersistenceManager'](_0x1e23f2);return _0x309d45===null?_0x57c46b['removeCurrentUser']():_0x57c46b['setCurrentUser'](_0x309d45);}async['getOrInitRedirectPersistenceManager'](_0x5f1af1){if(!this['redirectPersistenceManager']){const _0x449d29=_0x5f1af1&&ne(_0x5f1af1)||this['_popupRedirectResolver'];m(_0x449d29,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x449d29['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x7a3989){var _0x45ab88,_0x37fad8;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x45ab88=this['_currentUser'])==null?void 0x0:_0x45ab88['_redirectEventId'])===_0x7a3989?this['_currentUser']:((_0x37fad8=this['redirectUser'])==null?void 0x0:_0x37fad8['_redirectEventId'])===_0x7a3989?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0xc72312){if(_0xc72312===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0xc72312));}['_notifyListenersIfCurrent'](_0x1cd134){_0x1cd134===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0xae2841;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x544b0f=((_0xae2841=this['currentUser'])==null?void 0x0:_0xae2841['uid'])??null;this['lastNotifiedUid']!==_0x544b0f&&(this['lastNotifiedUid']=_0x544b0f,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1b4173,_0x1d81c1,_0x137100,_0x3c6a03){if(this['_deleted'])return()=>{};const _0xad3166=typeof _0x1d81c1=='function'?_0x1d81c1:_0x1d81c1['next']['bind'](_0x1d81c1);let _0x1eace0=!0x1;const _0x5e3e96=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x5e3e96,this,'internal-error'),_0x5e3e96['then'](()=>{_0x1eace0||_0xad3166(this['currentUser']);}),typeof _0x1d81c1=='function'){const _0xcaae=_0x1b4173['addObserver'](_0x1d81c1,_0x137100,_0x3c6a03);return()=>{_0x1eace0=!0x0,_0xcaae();};}else{const _0x1ec4bc=_0x1b4173['addObserver'](_0x1d81c1);return()=>{_0x1eace0=!0x0,_0x1ec4bc();};}}async['directlySetCurrentUser'](_0x11a97a){this['currentUser']&&this['currentUser']!==_0x11a97a&&this['_currentUser']['_stopProactiveRefresh'](),_0x11a97a&&this['isProactiveRefreshEnabled']&&_0x11a97a['_startProactiveRefresh'](),this['currentUser']=_0x11a97a,_0x11a97a?await this['assertedPersistence']['setCurrentUser'](_0x11a97a):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x392bde){return this['operations']=this['operations']['then'](_0x392bde,_0x392bde),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5b104e){!_0x5b104e||this['frameworks']['includes'](_0x5b104e)||(this['frameworks']['push'](_0x5b104e),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0xbda744;const _0x341e85={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x341e85['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x595f0b=await((_0xbda744=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xbda744['getHeartbeatsHeader']());_0x595f0b&&(_0x341e85['X-Firebase-Client']=_0x595f0b);const _0x361413=await this['_getAppCheckToken']();return _0x361413&&(_0x341e85['X-Firebase-AppCheck']=_0x361413),_0x341e85;}async['_getAppCheckToken'](){var _0x3cc56a;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x597cf8=await((_0x3cc56a=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3cc56a['getToken']());return _0x597cf8!=null&&_0x597cf8['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x597cf8['error']),_0x597cf8==null?void 0x0:_0x597cf8['token'];}}function qe(_0x1df382){return k(_0x1df382);}class Tr{constructor(_0x50800c){this['auth']=_0x50800c,this['observer']=null,this['addObserver']=Ic(_0x5c1210=>this['observer']=_0x5c1210);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x44203c){zn=_0x44203c;}function Da(_0x147d41){return zn['loadJS'](_0x147d41);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x440643){return'__'+_0x440643+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x166e7e){_0x166e7e();}['execute'](_0x598063,_0x551bfa){return Promise['resolve']('token');}['render'](_0x15361d,_0x18c9fd){return'';}}class Of{['ready'](_0x500806){_0x500806();}['execute'](_0x2c2ac3,_0x3e5e26){return Promise['resolve']('token');}['render'](_0x3a48bd,_0x2c2101){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x2c9c2f){this['type']=Df,this['auth']=qe(_0x2c9c2f);}async['verify'](_0x4f92b3='verify',_0x57e565=!0x1){async function _0x51dc65(_0x5418f3){if(!_0x57e565){if(_0x5418f3['tenantId']==null&&_0x5418f3['_agentRecaptchaConfig']!=null)return _0x5418f3['_agentRecaptchaConfig']['siteKey'];if(_0x5418f3['tenantId']!=null&&_0x5418f3['_tenantRecaptchaConfigs'][_0x5418f3['tenantId']]!==void 0x0)return _0x5418f3['_tenantRecaptchaConfigs'][_0x5418f3['tenantId']]['siteKey'];}return new Promise(async(_0x3e574c,_0x502aac)=>{uf(_0x5418f3,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x718aca=>{if(_0x718aca['recaptchaKey']===void 0x0)_0x502aac(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xd5eb44=new hf(_0x718aca);return _0x5418f3['tenantId']==null?_0x5418f3['_agentRecaptchaConfig']=_0xd5eb44:_0x5418f3['_tenantRecaptchaConfigs'][_0x5418f3['tenantId']]=_0xd5eb44,_0x3e574c(_0xd5eb44['siteKey']);}})['catch'](_0x3639e8=>{_0x502aac(_0x3639e8);});});}function _0x12ddb6(_0x24d365,_0x4759c4,_0x2ba2b7){const _0x23bdae=window['grecaptcha'];vr(_0x23bdae)?_0x23bdae['enterprise']['ready'](()=>{_0x23bdae['enterprise']['execute'](_0x24d365,{'action':_0x4f92b3})['then'](_0x5f2621=>{_0x4759c4(_0x5f2621);})['catch'](()=>{_0x4759c4(Ma);});}):_0x2ba2b7(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x599c32,_0x50af38)=>{_0x51dc65(this['auth'])['then'](async _0x20c9bd=>{if(!_0x57e565&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x12ddb6(_0x20c9bd,_0x599c32,_0x50af38);else{if(typeof window>'u'){_0x50af38(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x435456=Af();_0x435456['length']!==0x0&&(_0x435456+=_0x20c9bd+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x59d5f1;(_0x59d5f1=le['scriptInjectionDeferred'])==null||_0x59d5f1['resolve']();},Da(_0x435456)['then'](()=>{var _0x31cb64;return(_0x31cb64=le['scriptInjectionDeferred'])==null?void 0x0:_0x31cb64['promise'];})['then'](()=>{_0x12ddb6(_0x20c9bd,_0x599c32,_0x50af38);})['catch'](_0x4a574d=>{_0x50af38(_0x4a574d);});}})['catch'](_0x1f0bad=>{_0x50af38(_0x1f0bad);});});}}le['scriptInjectionDeferred']=null;async function br(_0x4d8ee,_0x3ace69,_0x447301,_0x221364=!0x1,_0x2d6ce5=!0x1){const _0x57f559=new le(_0x4d8ee);let _0xb0da80;if(_0x2d6ce5)_0xb0da80=Ma;else try{_0xb0da80=await _0x57f559['verify'](_0x447301);}catch{_0xb0da80=await _0x57f559['verify'](_0x447301,!0x0);}const _0x543dd6={..._0x3ace69};if(_0x447301==='mfaSmsEnrollment'||_0x447301==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x543dd6){const _0x4387b8=_0x543dd6['phoneEnrollmentInfo']['phoneNumber'],_0x8fb46c=_0x543dd6['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x543dd6,{'phoneEnrollmentInfo':{'phoneNumber':_0x4387b8,'recaptchaToken':_0x8fb46c,'captchaResponse':_0xb0da80,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x543dd6){const _0x3de1bc=_0x543dd6['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x543dd6,{'phoneSignInInfo':{'recaptchaToken':_0x3de1bc,'captchaResponse':_0xb0da80,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x543dd6;}return _0x221364?Object['assign'](_0x543dd6,{'captchaResp':_0xb0da80}):Object['assign'](_0x543dd6,{'captchaResponse':_0xb0da80}),Object['assign'](_0x543dd6,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x543dd6,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x543dd6;}async function Oi(_0x2146e1,_0x137d26,_0x4b9e07,_0x5eae1e,_0x4db091){var _0x48a5e1;if((_0x48a5e1=_0x2146e1['_getRecaptchaConfig']())!=null&&_0x48a5e1['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x54fcea=await br(_0x2146e1,_0x137d26,_0x4b9e07,_0x4b9e07==='getOobCode');return _0x5eae1e(_0x2146e1,_0x54fcea);}else return _0x5eae1e(_0x2146e1,_0x137d26)['catch'](async _0x5e98cd=>{if(_0x5e98cd['code']==='auth/missing-recaptcha-token'){console['log'](_0x4b9e07+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x175721=await br(_0x2146e1,_0x137d26,_0x4b9e07,_0x4b9e07==='getOobCode');return _0x5eae1e(_0x2146e1,_0x175721);}else return Promise['reject'](_0x5e98cd);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x2d9dc4,_0x41f948){const _0x4e01e9=Ui(_0x2d9dc4,'auth');if(_0x4e01e9['isInitialized']()){const _0x2365df=_0x4e01e9['getImmediate'](),_0x1c99d5=_0x4e01e9['getOptions']();if(De(_0x1c99d5,_0x41f948??{}))return _0x2365df;K(_0x2365df,'already-initialized');}return _0x4e01e9['initialize']({'options':_0x41f948});}function Lf(_0x18489b,_0x266b44){const _0x437df6=(_0x266b44==null?void 0x0:_0x266b44['persistence'])||[],_0x14f604=(Array['isArray'](_0x437df6)?_0x437df6:[_0x437df6])['map'](ne);_0x266b44!=null&&_0x266b44['errorMap']&&_0x18489b['_updateErrorMap'](_0x266b44['errorMap']),_0x18489b['_initializeWithPersistence'](_0x14f604,_0x266b44==null?void 0x0:_0x266b44['popupRedirectResolver']);}function xf(_0x1d7ac7,_0x56dd3a,_0x879a3a){const _0x4657f1=qe(_0x1d7ac7);m(/^https?:\/\//['test'](_0x56dd3a),_0x4657f1,'invalid-emulator-scheme');const _0x212fb0=!0x1,_0x2f02d3=La(_0x56dd3a),{host:_0x352bb5,port:_0x2d8343}=Ff(_0x56dd3a),_0x542c0a=_0x2d8343===null?'':':'+_0x2d8343,_0x390661={'url':_0x2f02d3+'//'+_0x352bb5+_0x542c0a+'/'},_0x28f7f9=Object['freeze']({'host':_0x352bb5,'port':_0x2d8343,'protocol':_0x2f02d3['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x212fb0})});if(!_0x4657f1['_canInitEmulator']){m(_0x4657f1['config']['emulator']&&_0x4657f1['emulatorConfig'],_0x4657f1,'emulator-config-failed'),m(De(_0x390661,_0x4657f1['config']['emulator'])&&De(_0x28f7f9,_0x4657f1['emulatorConfig']),_0x4657f1,'emulator-config-failed');return;}_0x4657f1['config']['emulator']=_0x390661,_0x4657f1['emulatorConfig']=_0x28f7f9,_0x4657f1['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x352bb5)?jr(_0x2f02d3+'//'+_0x352bb5+_0x542c0a):Uf();}function La(_0x139490){const _0x30dd05=_0x139490['indexOf'](':');return _0x30dd05<0x0?'':_0x139490['substr'](0x0,_0x30dd05+0x1);}function Ff(_0x2aea02){const _0x6bde6e=La(_0x2aea02),_0x263004=/(\/\/)?([^?#/]+)/['exec'](_0x2aea02['substr'](_0x6bde6e['length']));if(!_0x263004)return{'host':'','port':null};const _0x211946=_0x263004[0x2]['split']('@')['pop']()||'',_0x4525fc=/^(\[[^\]]+\])(:|$)/['exec'](_0x211946);if(_0x4525fc){const _0x5aed27=_0x4525fc[0x1];return{'host':_0x5aed27,'port':Rr(_0x211946['substr'](_0x5aed27['length']+0x1))};}else{const [_0x48af79,_0x551aca]=_0x211946['split'](':');return{'host':_0x48af79,'port':Rr(_0x551aca)};}}function Rr(_0x4c6a8a){if(!_0x4c6a8a)return null;const _0x3aa02e=Number(_0x4c6a8a);return isNaN(_0x3aa02e)?null:_0x3aa02e;}function Uf(){function _0x3cb9c5(){const _0x525cd6=document['createElement']('p'),_0x2de55e=_0x525cd6['style'];_0x525cd6['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2de55e['position']='fixed',_0x2de55e['width']='100%',_0x2de55e['backgroundColor']='#ffffff',_0x2de55e['border']='.1em\x20solid\x20#000000',_0x2de55e['color']='#b50000',_0x2de55e['bottom']='0px',_0x2de55e['left']='0px',_0x2de55e['margin']='0px',_0x2de55e['zIndex']='10000',_0x2de55e['textAlign']='center',_0x525cd6['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x525cd6);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x3cb9c5):_0x3cb9c5());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x40b415,_0x1c326d){this['providerId']=_0x40b415,this['signInMethod']=_0x1c326d;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x2748d9){return te('not\x20implemented');}['_linkToIdToken'](_0x5bd077,_0x43ad56){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x3418fe){return te('not\x20implemented');}}async function Wf(_0x5b8cb7,_0x2e1d7e){return Ae(_0x5b8cb7,'POST','/v1/accounts:signUp',_0x2e1d7e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x1b10bb,_0x29ce82){return Yt(_0x1b10bb,'POST','/v1/accounts:signInWithPassword',Re(_0x1b10bb,_0x29ce82));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0xe4760a,_0x4ff008){return Yt(_0xe4760a,'POST','/v1/accounts:signInWithEmailLink',Re(_0xe4760a,_0x4ff008));}async function Hf(_0x593063,_0x4d68ee){return Yt(_0x593063,'POST','/v1/accounts:signInWithEmailLink',Re(_0x593063,_0x4d68ee));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x48f605,_0x451859,_0x12d963,_0x1e95c9=null){super('password',_0x12d963),this['_email']=_0x48f605,this['_password']=_0x451859,this['_tenantId']=_0x1e95c9;}static['_fromEmailAndPassword'](_0x3c2c9f,_0x1f9a4d){return new Ft(_0x3c2c9f,_0x1f9a4d,'password');}static['_fromEmailAndCode'](_0x211908,_0x3ba154,_0x41f3c2=null){return new Ft(_0x211908,_0x3ba154,'emailLink',_0x41f3c2);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3477cc){const _0x6ca282=typeof _0x3477cc=='string'?JSON['parse'](_0x3477cc):_0x3477cc;if(_0x6ca282!=null&&_0x6ca282['email']&&(_0x6ca282!=null&&_0x6ca282['password'])){if(_0x6ca282['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x6ca282['email'],_0x6ca282['password']);if(_0x6ca282['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x6ca282['email'],_0x6ca282['password'],_0x6ca282['tenantId']);}return null;}async['_getIdTokenResponse'](_0x49f3e1){switch(this['signInMethod']){case'password':const _0x3ee7c8={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x49f3e1,_0x3ee7c8,'signInWithPassword',Bf);case'emailLink':return Vf(_0x49f3e1,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x49f3e1,'internal-error');}}async['_linkToIdToken'](_0x505950,_0x55da6d){switch(this['signInMethod']){case'password':const _0x28e4d1={'idToken':_0x55da6d,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x505950,_0x28e4d1,'signUpPassword',Wf);case'emailLink':return Hf(_0x505950,{'idToken':_0x55da6d,'email':this['_email'],'oobCode':this['_password']});default:K(_0x505950,'internal-error');}}['_getReauthenticationResolver'](_0x4d8a61){return this['_getIdTokenResponse'](_0x4d8a61);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x5160a8,_0x1da733){return Yt(_0x5160a8,'POST','/v1/accounts:signInWithIdp',Re(_0x5160a8,_0x1da733));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x13572d){const _0x53c5b7=new We(_0x13572d['providerId'],_0x13572d['signInMethod']);return _0x13572d['idToken']||_0x13572d['accessToken']?(_0x13572d['idToken']&&(_0x53c5b7['idToken']=_0x13572d['idToken']),_0x13572d['accessToken']&&(_0x53c5b7['accessToken']=_0x13572d['accessToken']),_0x13572d['nonce']&&!_0x13572d['pendingToken']&&(_0x53c5b7['nonce']=_0x13572d['nonce']),_0x13572d['pendingToken']&&(_0x53c5b7['pendingToken']=_0x13572d['pendingToken'])):_0x13572d['oauthToken']&&_0x13572d['oauthTokenSecret']?(_0x53c5b7['accessToken']=_0x13572d['oauthToken'],_0x53c5b7['secret']=_0x13572d['oauthTokenSecret']):K('argument-error'),_0x53c5b7;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3e2c00){const _0x7b4de4=typeof _0x3e2c00=='string'?JSON['parse'](_0x3e2c00):_0x3e2c00,{providerId:_0x1f1a5c,signInMethod:_0x5b6d4b,..._0x2abcbf}=_0x7b4de4;if(!_0x1f1a5c||!_0x5b6d4b)return null;const _0xa564df=new We(_0x1f1a5c,_0x5b6d4b);return _0xa564df['idToken']=_0x2abcbf['idToken']||void 0x0,_0xa564df['accessToken']=_0x2abcbf['accessToken']||void 0x0,_0xa564df['secret']=_0x2abcbf['secret'],_0xa564df['nonce']=_0x2abcbf['nonce'],_0xa564df['pendingToken']=_0x2abcbf['pendingToken']||null,_0xa564df;}['_getIdTokenResponse'](_0x2e6dd6){const _0x5df7b5=this['buildRequest']();return Ze(_0x2e6dd6,_0x5df7b5);}['_linkToIdToken'](_0x12350c,_0x4948b6){const _0x5b2f9c=this['buildRequest']();return _0x5b2f9c['idToken']=_0x4948b6,Ze(_0x12350c,_0x5b2f9c);}['_getReauthenticationResolver'](_0xb7a5de){const _0x53c085=this['buildRequest']();return _0x53c085['autoCreate']=!0x1,Ze(_0xb7a5de,_0x53c085);}['buildRequest'](){const _0x492ecb={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x492ecb['pendingToken']=this['pendingToken'];else{const _0x9e392e={};this['idToken']&&(_0x9e392e['id_token']=this['idToken']),this['accessToken']&&(_0x9e392e['access_token']=this['accessToken']),this['secret']&&(_0x9e392e['oauth_token_secret']=this['secret']),_0x9e392e['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x9e392e['nonce']=this['nonce']),_0x492ecb['postBody']=at(_0x9e392e);}return _0x492ecb;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x4f2c28){switch(_0x4f2c28){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x8361bc){const _0x470325=yt(vt(_0x8361bc))['link'],_0x2917c0=_0x470325?yt(vt(_0x470325))['deep_link_id']:null,_0x52c489=yt(vt(_0x8361bc))['deep_link_id'];return(_0x52c489?yt(vt(_0x52c489))['link']:null)||_0x52c489||_0x2917c0||_0x470325||_0x8361bc;}class Ss{constructor(_0x4a5038){const _0x5d3a2e=yt(vt(_0x4a5038)),_0x362742=_0x5d3a2e['apiKey']??null,_0x2a4608=_0x5d3a2e['oobCode']??null,_0x5e10a7=Gf(_0x5d3a2e['mode']??null);m(_0x362742&&_0x2a4608&&_0x5e10a7,'argument-error'),this['apiKey']=_0x362742,this['operation']=_0x5e10a7,this['code']=_0x2a4608,this['continueUrl']=_0x5d3a2e['continueUrl']??null,this['languageCode']=_0x5d3a2e['lang']??null,this['tenantId']=_0x5d3a2e['tenantId']??null;}static['parseLink'](_0xf2014b){const _0x295af1=qf(_0xf2014b);try{return new Ss(_0x295af1);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x24be4a,_0x41fcc3){return Ft['_fromEmailAndPassword'](_0x24be4a,_0x41fcc3);}static['credentialWithLink'](_0x51170d,_0x2ce4fc){const _0x2dad1a=Ss['parseLink'](_0x2ce4fc);return m(_0x2dad1a,'argument-error'),Ft['_fromEmailAndCode'](_0x51170d,_0x2dad1a['code'],_0x2dad1a['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x143ef1){this['providerId']=_0x143ef1,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x47dbfc){this['defaultLanguageCode']=_0x47dbfc;}['setCustomParameters'](_0xa3ba15){return this['customParameters']=_0xa3ba15,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x38d888){return this['scopes']['includes'](_0x38d888)||this['scopes']['push'](_0x38d888),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x3749f0){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3749f0});}static['credentialFromResult'](_0x2b2c01){return he['credentialFromTaggedObject'](_0x2b2c01);}static['credentialFromError'](_0x391383){return he['credentialFromTaggedObject'](_0x391383['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4a4fea}){if(!_0x4a4fea||!('oauthAccessToken'in _0x4a4fea)||!_0x4a4fea['oauthAccessToken'])return null;try{return he['credential'](_0x4a4fea['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x4bcf84,_0x2d328f){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x4bcf84,'accessToken':_0x2d328f});}static['credentialFromResult'](_0x31f5c3){return ue['credentialFromTaggedObject'](_0x31f5c3);}static['credentialFromError'](_0x1d4125){return ue['credentialFromTaggedObject'](_0x1d4125['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x22b78a}){if(!_0x22b78a)return null;const {oauthIdToken:_0x1cf4de,oauthAccessToken:_0x94a8b4}=_0x22b78a;if(!_0x1cf4de&&!_0x94a8b4)return null;try{return ue['credential'](_0x1cf4de,_0x94a8b4);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x1ece41){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1ece41});}static['credentialFromResult'](_0x3065f8){return de['credentialFromTaggedObject'](_0x3065f8);}static['credentialFromError'](_0xdc352f){return de['credentialFromTaggedObject'](_0xdc352f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5a09c7}){if(!_0x5a09c7||!('oauthAccessToken'in _0x5a09c7)||!_0x5a09c7['oauthAccessToken'])return null;try{return de['credential'](_0x5a09c7['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x4e7883,_0x3eb792){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4e7883,'oauthTokenSecret':_0x3eb792});}static['credentialFromResult'](_0x5506a1){return fe['credentialFromTaggedObject'](_0x5506a1);}static['credentialFromError'](_0x2007a1){return fe['credentialFromTaggedObject'](_0x2007a1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x45b421}){if(!_0x45b421)return null;const {oauthAccessToken:_0x2d4320,oauthTokenSecret:_0x1a351d}=_0x45b421;if(!_0x2d4320||!_0x1a351d)return null;try{return fe['credential'](_0x2d4320,_0x1a351d);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x4cd2e2,_0x3ae93f){return Yt(_0x4cd2e2,'POST','/v1/accounts:signUp',Re(_0x4cd2e2,_0x3ae93f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x286d07){this['user']=_0x286d07['user'],this['providerId']=_0x286d07['providerId'],this['_tokenResponse']=_0x286d07['_tokenResponse'],this['operationType']=_0x286d07['operationType'];}static async['_fromIdTokenResponse'](_0xb6572e,_0x1cbe84,_0x42237b,_0x400f5d=!0x1){const _0x3ef61e=await z['_fromIdTokenResponse'](_0xb6572e,_0x42237b,_0x400f5d),_0x2bb52c=Ar(_0x42237b);return new Be({'user':_0x3ef61e,'providerId':_0x2bb52c,'_tokenResponse':_0x42237b,'operationType':_0x1cbe84});}static async['_forOperation'](_0x4e6191,_0x461c3c,_0x353f64){await _0x4e6191['_updateTokensIfNecessary'](_0x353f64,!0x0);const _0x7bd9b0=Ar(_0x353f64);return new Be({'user':_0x4e6191,'providerId':_0x7bd9b0,'_tokenResponse':_0x353f64,'operationType':_0x461c3c});}}function Ar(_0xbcac3c){return _0xbcac3c['providerId']?_0xbcac3c['providerId']:'phoneNumber'in _0xbcac3c?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0xf7bcc1,_0x3eb295,_0x4ba12c,_0x1bfd66){super(_0x3eb295['code'],_0x3eb295['message']),this['operationType']=_0x4ba12c,this['user']=_0x1bfd66,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0xf7bcc1['name'],'tenantId':_0xf7bcc1['tenantId']??void 0x0,'_serverResponse':_0x3eb295['customData']['_serverResponse'],'operationType':_0x4ba12c};}static['_fromErrorAndOperation'](_0x1d6c98,_0x393130,_0x3557f9,_0x52bc2e){return new Rn(_0x1d6c98,_0x393130,_0x3557f9,_0x52bc2e);}}function Fa(_0x3132c1,_0x269628,_0x552a0a,_0x2d6b18){return(_0x269628==='reauthenticate'?_0x552a0a['_getReauthenticationResolver'](_0x3132c1):_0x552a0a['_getIdTokenResponse'](_0x3132c1))['catch'](_0x459768=>{throw _0x459768['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x3132c1,_0x459768,_0x269628,_0x2d6b18):_0x459768;});}async function jf(_0x22e00f,_0x262747,_0xbb5d2=!0x1){const _0x1e8f22=await xt(_0x22e00f,_0x262747['_linkToIdToken'](_0x22e00f['auth'],await _0x22e00f['getIdToken']()),_0xbb5d2);return Be['_forOperation'](_0x22e00f,'link',_0x1e8f22);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x158621,_0x26c16b,_0x4489cd=!0x1){const {auth:_0x4b1d9e}=_0x158621;if(H(_0x4b1d9e['app']))return Promise['reject'](se(_0x4b1d9e));const _0x4acfbc='reauthenticate';try{const _0xa31526=await xt(_0x158621,Fa(_0x4b1d9e,_0x4acfbc,_0x26c16b,_0x158621),_0x4489cd);m(_0xa31526['idToken'],_0x4b1d9e,'internal-error');const _0xe8979a=ws(_0xa31526['idToken']);m(_0xe8979a,_0x4b1d9e,'internal-error');const {sub:_0x5ac71c}=_0xe8979a;return m(_0x158621['uid']===_0x5ac71c,_0x4b1d9e,'user-mismatch'),Be['_forOperation'](_0x158621,_0x4acfbc,_0xa31526);}catch(_0x323b3d){throw(_0x323b3d==null?void 0x0:_0x323b3d['code'])==='auth/user-not-found'&&K(_0x4b1d9e,'user-mismatch'),_0x323b3d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x19cd7f,_0x22465b,_0x4a6193=!0x1){if(H(_0x19cd7f['app']))return Promise['reject'](se(_0x19cd7f));const _0xaed0aa='signIn',_0xc43712=await Fa(_0x19cd7f,_0xaed0aa,_0x22465b),_0x41ca91=await Be['_fromIdTokenResponse'](_0x19cd7f,_0xaed0aa,_0xc43712);return _0x4a6193||await _0x19cd7f['_updateCurrentUser'](_0x41ca91['user']),_0x41ca91;}async function Yf(_0x132a52,_0x200ca9){return Ua(qe(_0x132a52),_0x200ca9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x53cbf1){const _0x74067f=qe(_0x53cbf1);_0x74067f['_getPasswordPolicyInternal']()&&await _0x74067f['_updatePasswordPolicy']();}async function R_(_0x413b38,_0x1d9523,_0x255d03){if(H(_0x413b38['app']))return Promise['reject'](se(_0x413b38));const _0x27c0f6=qe(_0x413b38),_0x4f57fa=await Oi(_0x27c0f6,{'returnSecureToken':!0x0,'email':_0x1d9523,'password':_0x255d03,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x7bfa7a=>{throw _0x7bfa7a['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x413b38),_0x7bfa7a;}),_0x10b6c7=await Be['_fromIdTokenResponse'](_0x27c0f6,'signIn',_0x4f57fa);return await _0x27c0f6['_updateCurrentUser'](_0x10b6c7['user']),_0x10b6c7;}function A_(_0x37f93d,_0x584743,_0x596838){return H(_0x37f93d['app'])?Promise['reject'](se(_0x37f93d)):Yf(k(_0x37f93d),ft['credential'](_0x584743,_0x596838))['catch'](async _0x183755=>{throw _0x183755['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x37f93d),_0x183755;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x6a010f,_0x423eb1){return k(_0x6a010f)['setPersistence'](_0x423eb1);}function Qf(_0x520180,_0x228e4b,_0x40058b,_0x24b553){return k(_0x520180)['onIdTokenChanged'](_0x228e4b,_0x40058b,_0x24b553);}function Jf(_0x4fd008,_0x3c2862,_0x433f65){return k(_0x4fd008)['beforeAuthStateChanged'](_0x3c2862,_0x433f65);}function N_(_0x495ad9,_0x2091a2,_0x117d0f,_0xf11056){return k(_0x495ad9)['onAuthStateChanged'](_0x2091a2,_0x117d0f,_0xf11056);}function P_(_0x1277c2){return k(_0x1277c2)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x5c53ae,_0x1ac111){this['storageRetriever']=_0x5c53ae,this['type']=_0x1ac111;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x13f107,_0x27051b){return this['storage']['setItem'](_0x13f107,JSON['stringify'](_0x27051b)),Promise['resolve']();}['_get'](_0x1c96ff){const _0x4653b4=this['storage']['getItem'](_0x1c96ff);return Promise['resolve'](_0x4653b4?JSON['parse'](_0x4653b4):null);}['_remove'](_0x5f28c5){return this['storage']['removeItem'](_0x5f28c5),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0xd5e259,_0x26f339)=>this['onStorageEvent'](_0xd5e259,_0x26f339),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x264a1f){for(const _0x2cd87b of Object['keys'](this['listeners'])){const _0x3241e8=this['storage']['getItem'](_0x2cd87b),_0x25f6bb=this['localCache'][_0x2cd87b];_0x3241e8!==_0x25f6bb&&_0x264a1f(_0x2cd87b,_0x25f6bb,_0x3241e8);}}['onStorageEvent'](_0x9e496a,_0x298b16=!0x1){if(!_0x9e496a['key']){this['forAllChangedKeys']((_0xe94830,_0x4d8ef6,_0x13e3bf)=>{this['notifyListeners'](_0xe94830,_0x13e3bf);});return;}const _0x2d5892=_0x9e496a['key'];_0x298b16?this['detachListener']():this['stopPolling']();const _0x5a0233=()=>{const _0x2847ee=this['storage']['getItem'](_0x2d5892);!_0x298b16&&this['localCache'][_0x2d5892]===_0x2847ee||this['notifyListeners'](_0x2d5892,_0x2847ee);},_0x4c54f6=this['storage']['getItem'](_0x2d5892);If()&&_0x4c54f6!==_0x9e496a['newValue']&&_0x9e496a['newValue']!==_0x9e496a['oldValue']?setTimeout(_0x5a0233,Zf):_0x5a0233();}['notifyListeners'](_0x42ddd8,_0x16914d){this['localCache'][_0x42ddd8]=_0x16914d;const _0x30a092=this['listeners'][_0x42ddd8];if(_0x30a092){for(const _0x35dc09 of Array['from'](_0x30a092))_0x35dc09(_0x16914d&&JSON['parse'](_0x16914d));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5751fb,_0x5455e6,_0x47b488)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5751fb,'oldValue':_0x5455e6,'newValue':_0x47b488}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x23e64b,_0x443492){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x23e64b]||(this['listeners'][_0x23e64b]=new Set(),this['localCache'][_0x23e64b]=this['storage']['getItem'](_0x23e64b)),this['listeners'][_0x23e64b]['add'](_0x443492);}['_removeListener'](_0x625ebb,_0x4e4284){this['listeners'][_0x625ebb]&&(this['listeners'][_0x625ebb]['delete'](_0x4e4284),this['listeners'][_0x625ebb]['size']===0x0&&delete this['listeners'][_0x625ebb]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x31fdb5,_0xaaad3){await super['_set'](_0x31fdb5,_0xaaad3),this['localCache'][_0x31fdb5]=JSON['stringify'](_0xaaad3);}async['_get'](_0x172245){const _0x5a8265=await super['_get'](_0x172245);return this['localCache'][_0x172245]=JSON['stringify'](_0x5a8265),_0x5a8265;}async['_remove'](_0xbad1c4){await super['_remove'](_0xbad1c4),delete this['localCache'][_0xbad1c4];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x157c4a,_0x3379fc){}['_removeListener'](_0x4da7ec,_0x15ca39){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x37f6d5){return Promise['all'](_0x37f6d5['map'](async _0x13453f=>{try{return{'fulfilled':!0x0,'value':await _0x13453f};}catch(_0x248da8){return{'fulfilled':!0x1,'reason':_0x248da8};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x10f5e7){this['eventTarget']=_0x10f5e7,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x4cf27a){const _0x27ccf0=this['receivers']['find'](_0x51dbef=>_0x51dbef['isListeningto'](_0x4cf27a));if(_0x27ccf0)return _0x27ccf0;const _0x288439=new jn(_0x4cf27a);return this['receivers']['push'](_0x288439),_0x288439;}['isListeningto'](_0x139444){return this['eventTarget']===_0x139444;}async['handleEvent'](_0x3ba544){const _0x989714=_0x3ba544,{eventId:_0x556bb2,eventType:_0x269ca1,data:_0x3853d1}=_0x989714['data'],_0x13c6f2=this['handlersMap'][_0x269ca1];if(!(_0x13c6f2!=null&&_0x13c6f2['size']))return;_0x989714['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x556bb2,'eventType':_0x269ca1});const _0x5e7673=Array['from'](_0x13c6f2)['map'](async _0x2c1206=>_0x2c1206(_0x989714['origin'],_0x3853d1)),_0x15d703=await tp(_0x5e7673);_0x989714['ports'][0x0]['postMessage']({'status':'done','eventId':_0x556bb2,'eventType':_0x269ca1,'response':_0x15d703});}['_subscribe'](_0x1f5b95,_0x586516){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1f5b95]||(this['handlersMap'][_0x1f5b95]=new Set()),this['handlersMap'][_0x1f5b95]['add'](_0x586516);}['_unsubscribe'](_0x3acc9a,_0x484731){this['handlersMap'][_0x3acc9a]&&_0x484731&&this['handlersMap'][_0x3acc9a]['delete'](_0x484731),(!_0x484731||this['handlersMap'][_0x3acc9a]['size']===0x0)&&delete this['handlersMap'][_0x3acc9a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x22cb5f='',_0x5c128c=0xa){let _0x2c166c='';for(let _0x1c331b=0x0;_0x1c331b<_0x5c128c;_0x1c331b++)_0x2c166c+=Math['floor'](Math['random']()*0xa);return _0x22cb5f+_0x2c166c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x58d787){this['target']=_0x58d787,this['handlers']=new Set();}['removeMessageHandler'](_0x24342f){_0x24342f['messageChannel']&&(_0x24342f['messageChannel']['port1']['removeEventListener']('message',_0x24342f['onMessage']),_0x24342f['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x24342f);}async['_send'](_0xcf2a3d,_0x2d1bc7,_0xb5c7c7=0x32){const _0x387e49=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x387e49)throw new Error('connection_unavailable');let _0x4c4e5e,_0x59082f;return new Promise((_0x4a379d,_0x57afdf)=>{const _0x36364b=bs('',0x14);_0x387e49['port1']['start']();const _0xa383ab=setTimeout(()=>{_0x57afdf(new Error('unsupported_event'));},_0xb5c7c7);_0x59082f={'messageChannel':_0x387e49,'onMessage'(_0x2f7ad2){const _0x152724=_0x2f7ad2;if(_0x152724['data']['eventId']===_0x36364b)switch(_0x152724['data']['status']){case'ack':clearTimeout(_0xa383ab),_0x4c4e5e=setTimeout(()=>{_0x57afdf(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4c4e5e),_0x4a379d(_0x152724['data']['response']);break;default:clearTimeout(_0xa383ab),clearTimeout(_0x4c4e5e),_0x57afdf(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x59082f),_0x387e49['port1']['addEventListener']('message',_0x59082f['onMessage']),this['target']['postMessage']({'eventType':_0xcf2a3d,'eventId':_0x36364b,'data':_0x2d1bc7},[_0x387e49['port2']]);})['finally'](()=>{_0x59082f&&this['removeMessageHandler'](_0x59082f);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0xaa2882){X()['location']['href']=_0xaa2882;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x26e530;return((_0x26e530=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x26e530['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x38c663){this['request']=_0x38c663;}['toPromise'](){return new Promise((_0x557819,_0xa285ee)=>{this['request']['addEventListener']('success',()=>{_0x557819(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xa285ee(this['request']['error']);});});}}function Kn(_0xf1a56a,_0x58e266){return _0xf1a56a['transaction']([kn],_0x58e266?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x39ef74=indexedDB['deleteDatabase'](qa);return new Jt(_0x39ef74)['toPromise']();}function ja(){const _0x432d33=indexedDB['open'](qa,ap);return new Promise((_0x2610dd,_0x1e69f0)=>{_0x432d33['addEventListener']('error',()=>{_0x1e69f0(_0x432d33['error']);}),_0x432d33['addEventListener']('upgradeneeded',()=>{const _0x1bac42=_0x432d33['result'];try{_0x1bac42['createObjectStore'](kn,{'keyPath':za});}catch(_0xe2e7c3){_0x1e69f0(_0xe2e7c3);}}),_0x432d33['addEventListener']('success',async()=>{const _0x16e16c=_0x432d33['result'];_0x16e16c['objectStoreNames']['contains'](kn)?_0x2610dd(_0x16e16c):(_0x16e16c['close'](),await cp(),_0x2610dd(await ja()));});});}async function kr(_0x2cd7ab,_0x232a53,_0x14d433){const _0x4465ac=Kn(_0x2cd7ab,!0x0)['put']({[za]:_0x232a53,'value':_0x14d433});return new Jt(_0x4465ac)['toPromise']();}async function lp(_0x3d9b89,_0x41c75c){const _0x472519=Kn(_0x3d9b89,!0x1)['get'](_0x41c75c),_0x4197ab=await new Jt(_0x472519)['toPromise']();return _0x4197ab===void 0x0?null:_0x4197ab['value'];}function Nr(_0x5daf33,_0x2fb99f){const _0x456bab=Kn(_0x5daf33,!0x0)['delete'](_0x2fb99f);return new Jt(_0x456bab)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5ad029){let _0x5b0ab8=0x0;for(;;)try{const _0x317c21=await this['_openDb']();return await _0x5ad029(_0x317c21);}catch(_0x4b4c81){if(_0x5b0ab8++>up)throw _0x4b4c81;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x34ff6d,_0x5ce0b2)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5ce0b2['key'])})),this['receiver']['_subscribe']('ping',async(_0x52a30d,_0x1dac2e)=>['keyChanged']);}async['initializeSender'](){var _0x3346e7,_0x3ffb14;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x15bc10=await this['sender']['_send']('ping',{},0x320);_0x15bc10&&(_0x3346e7=_0x15bc10[0x0])!=null&&_0x3346e7['fulfilled']&&(_0x3ffb14=_0x15bc10[0x0])!=null&&_0x3ffb14['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4f69ba){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4f69ba},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x234cd4=>{await kr(_0x234cd4,An,'1'),await Nr(_0x234cd4,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x14c684){this['pendingWrites']++;try{await _0x14c684();}finally{this['pendingWrites']--;}}async['_set'](_0x5008a7,_0x242eb6){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x52813c=>kr(_0x52813c,_0x5008a7,_0x242eb6)),this['localCache'][_0x5008a7]=_0x242eb6,this['notifyServiceWorker'](_0x5008a7)));}async['_get'](_0x30e62c){const _0x595495=await this['_withRetries'](_0x694525=>lp(_0x694525,_0x30e62c));return this['localCache'][_0x30e62c]=_0x595495,_0x595495;}async['_remove'](_0x404ffd){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2baf23=>Nr(_0x2baf23,_0x404ffd)),delete this['localCache'][_0x404ffd],this['notifyServiceWorker'](_0x404ffd)));}async['_poll'](){const _0x32f6e0=await this['_withRetries'](_0x4c6ed0=>{const _0x58f507=Kn(_0x4c6ed0,!0x1)['getAll']();return new Jt(_0x58f507)['toPromise']();});if(!_0x32f6e0)return[];if(this['pendingWrites']!==0x0)return[];const _0xa4740c=[],_0x2e5c25=new Set();if(_0x32f6e0['length']!==0x0){for(const {fbase_key:_0x35a660,value:_0x4c3c81}of _0x32f6e0)_0x2e5c25['add'](_0x35a660),JSON['stringify'](this['localCache'][_0x35a660])!==JSON['stringify'](_0x4c3c81)&&(this['notifyListeners'](_0x35a660,_0x4c3c81),_0xa4740c['push'](_0x35a660));}for(const _0x1d5626 of Object['keys'](this['localCache']))this['localCache'][_0x1d5626]&&!_0x2e5c25['has'](_0x1d5626)&&(this['notifyListeners'](_0x1d5626,null),_0xa4740c['push'](_0x1d5626));return _0xa4740c;}['notifyListeners'](_0xd32a35,_0x25c9a9){this['localCache'][_0xd32a35]=_0x25c9a9;const _0x19a106=this['listeners'][_0xd32a35];if(_0x19a106){for(const _0x4ca4a7 of Array['from'](_0x19a106))_0x4ca4a7(_0x25c9a9);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x165630,_0x3ca54c){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x165630]||(this['listeners'][_0x165630]=new Set(),this['_get'](_0x165630)),this['listeners'][_0x165630]['add'](_0x3ca54c);}['_removeListener'](_0x506c9f,_0x383e1e){this['listeners'][_0x506c9f]&&(this['listeners'][_0x506c9f]['delete'](_0x383e1e),this['listeners'][_0x506c9f]['size']===0x0&&delete this['listeners'][_0x506c9f]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x514763,_0x50abb8){return _0x50abb8?ne(_0x50abb8):(m(_0x514763['_popupRedirectResolver'],_0x514763,'argument-error'),_0x514763['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x570bc9){super('custom','custom'),this['params']=_0x570bc9;}['_getIdTokenResponse'](_0x3ae775){return Ze(_0x3ae775,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2ab610,_0x41b3c3){return Ze(_0x2ab610,this['_buildIdpRequest'](_0x41b3c3));}['_getReauthenticationResolver'](_0x2e69b7){return Ze(_0x2e69b7,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x4d981f){const _0x37632d={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x4d981f&&(_0x37632d['idToken']=_0x4d981f),_0x37632d;}}function pp(_0xd85250){return Ua(_0xd85250['auth'],new Rs(_0xd85250),_0xd85250['bypassAuthState']);}function _p(_0x1e98cb){const {auth:_0x39220c,user:_0x5f4bb1}=_0x1e98cb;return m(_0x5f4bb1,_0x39220c,'internal-error'),Kf(_0x5f4bb1,new Rs(_0x1e98cb),_0x1e98cb['bypassAuthState']);}async function gp(_0x1a6ad0){const {auth:_0x729705,user:_0x3cc605}=_0x1a6ad0;return m(_0x3cc605,_0x729705,'internal-error'),jf(_0x3cc605,new Rs(_0x1a6ad0),_0x1a6ad0['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x27c78a,_0xb37d04,_0x4bf045,_0x36f12e,_0x3cab1a=!0x1){this['auth']=_0x27c78a,this['resolver']=_0x4bf045,this['user']=_0x36f12e,this['bypassAuthState']=_0x3cab1a,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0xb37d04)?_0xb37d04:[_0xb37d04];}['execute'](){return new Promise(async(_0x49ed21,_0x579ba3)=>{this['pendingPromise']={'resolve':_0x49ed21,'reject':_0x579ba3};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xd1fbfa){this['reject'](_0xd1fbfa);}});}async['onAuthEvent'](_0x53f1eb){const {urlResponse:_0x1f9873,sessionId:_0x5beccb,postBody:_0x53345c,tenantId:_0xe0e6e5,error:_0x4b7d5d,type:_0x2a55d7}=_0x53f1eb;if(_0x4b7d5d){this['reject'](_0x4b7d5d);return;}const _0x4ef3b2={'auth':this['auth'],'requestUri':_0x1f9873,'sessionId':_0x5beccb,'tenantId':_0xe0e6e5||void 0x0,'postBody':_0x53345c||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2a55d7)(_0x4ef3b2));}catch(_0x180917){this['reject'](_0x180917);}}['onError'](_0x42d97e){this['reject'](_0x42d97e);}['getIdpTask'](_0x3da890){switch(_0x3da890){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0xfb66ae){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xfb66ae),this['unregisterAndCleanUp']();}['reject'](_0x180d6f){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x180d6f),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x250834,_0x38cf02,_0x34a2bd,_0x3ad15c,_0x3561ce){super(_0x250834,_0x38cf02,_0x3ad15c,_0x3561ce),this['provider']=_0x34a2bd,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x172cf3=await this['execute']();return m(_0x172cf3,this['auth'],'internal-error'),_0x172cf3;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4c148b=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4c148b),this['authWindow']['associatedEvent']=_0x4c148b,this['resolver']['_originValidation'](this['auth'])['catch'](_0x92e14c=>{this['reject'](_0x92e14c);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x68b2f3=>{_0x68b2f3||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x58b7d0;return((_0x58b7d0=this['authWindow'])==null?void 0x0:_0x58b7d0['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x5ab45a=()=>{var _0x46f9cf,_0x40fa15;if((_0x40fa15=(_0x46f9cf=this['authWindow'])==null?void 0x0:_0x46f9cf['window'])!=null&&_0x40fa15['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x5ab45a,mp['get']());};_0x5ab45a();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x114b39,_0x21ae74,_0x404140=!0x1){super(_0x114b39,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x21ae74,void 0x0,_0x404140),this['eventId']=null;}async['execute'](){let _0x136a14=rn['get'](this['auth']['_key']());if(!_0x136a14){try{const _0x2a10c1=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x136a14=()=>Promise['resolve'](_0x2a10c1);}catch(_0x4d7246){_0x136a14=()=>Promise['reject'](_0x4d7246);}rn['set'](this['auth']['_key'](),_0x136a14);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x136a14();}async['onAuthEvent'](_0x52813a){if(_0x52813a['type']==='signInViaRedirect')return super['onAuthEvent'](_0x52813a);if(_0x52813a['type']==='unknown'){this['resolve'](null);return;}if(_0x52813a['eventId']){const _0x1680d5=await this['auth']['_redirectUserForId'](_0x52813a['eventId']);if(_0x1680d5)return this['user']=_0x1680d5,super['onAuthEvent'](_0x52813a);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x47a333,_0x27bd6b){const _0x5c0b6b=Cp(_0x27bd6b),_0x45abe6=wp(_0x47a333);if(!await _0x45abe6['_isAvailable']())return!0x1;const _0x479f75=await _0x45abe6['_get'](_0x5c0b6b)==='true';return await _0x45abe6['_remove'](_0x5c0b6b),_0x479f75;}function Ip(_0x177134,_0x272407){rn['set'](_0x177134['_key'](),_0x272407);}function wp(_0x49d1d2){return ne(_0x49d1d2['_redirectPersistence']);}function Cp(_0x18290b){return sn(yp,_0x18290b['config']['apiKey'],_0x18290b['name']);}async function Tp(_0x1a2741,_0x390742,_0x1dfdb8=!0x1){if(H(_0x1a2741['app']))return Promise['reject'](se(_0x1a2741));const _0x6b6ee9=qe(_0x1a2741),_0x36c967=fp(_0x6b6ee9,_0x390742),_0x30fca7=await new vp(_0x6b6ee9,_0x36c967,_0x1dfdb8)['execute']();return _0x30fca7&&!_0x1dfdb8&&(delete _0x30fca7['user']['_redirectEventId'],await _0x6b6ee9['_persistUserIfCurrent'](_0x30fca7['user']),await _0x6b6ee9['_setRedirectUser'](null,_0x390742)),_0x30fca7;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0xb2e03e){this['auth']=_0xb2e03e,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1da47f){this['consumers']['add'](_0x1da47f),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1da47f)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1da47f),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x239536){this['consumers']['delete'](_0x239536);}['onEvent'](_0x1c7b9c){if(this['hasEventBeenHandled'](_0x1c7b9c))return!0x1;let _0x36f9e5=!0x1;return this['consumers']['forEach'](_0x338c8e=>{this['isEventForConsumer'](_0x1c7b9c,_0x338c8e)&&(_0x36f9e5=!0x0,this['sendToConsumer'](_0x1c7b9c,_0x338c8e),this['saveEventToCache'](_0x1c7b9c));}),this['hasHandledPotentialRedirect']||!Rp(_0x1c7b9c)||(this['hasHandledPotentialRedirect']=!0x0,_0x36f9e5||(this['queuedRedirectEvent']=_0x1c7b9c,_0x36f9e5=!0x0)),_0x36f9e5;}['sendToConsumer'](_0x3f244d,_0x15a76a){var _0x3418e1;if(_0x3f244d['error']&&!Qa(_0x3f244d)){const _0x149525=((_0x3418e1=_0x3f244d['error']['code'])==null?void 0x0:_0x3418e1['split']('auth/')[0x1])||'internal-error';_0x15a76a['onError'](J(this['auth'],_0x149525));}else _0x15a76a['onAuthEvent'](_0x3f244d);}['isEventForConsumer'](_0x315f3a,_0x1dea1c){const _0x264ad1=_0x1dea1c['eventId']===null||!!_0x315f3a['eventId']&&_0x315f3a['eventId']===_0x1dea1c['eventId'];return _0x1dea1c['filter']['includes'](_0x315f3a['type'])&&_0x264ad1;}['hasEventBeenHandled'](_0x52bcd1){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x52bcd1));}['saveEventToCache'](_0x3ccf44){this['cachedEventUids']['add'](Pr(_0x3ccf44)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x549c9b){return[_0x549c9b['type'],_0x549c9b['eventId'],_0x549c9b['sessionId'],_0x549c9b['tenantId']]['filter'](_0x21b3fc=>_0x21b3fc)['join']('-');}function Qa({type:_0x154e77,error:_0x38b99f}){return _0x154e77==='unknown'&&(_0x38b99f==null?void 0x0:_0x38b99f['code'])==='auth/no-auth-event';}function Rp(_0x243316){switch(_0x243316['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x243316);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x20cc3e,_0x14a62c={}){return Ae(_0x20cc3e,'GET','/v1/projects',_0x14a62c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x40f220){if(_0x40f220['config']['emulator'])return;const {authorizedDomains:_0x1218a9}=await Ap(_0x40f220);for(const _0x25271c of _0x1218a9)try{if(Op(_0x25271c))return;}catch{}K(_0x40f220,'unauthorized-domain');}function Op(_0xe45048){const _0x4200e7=Ni(),{protocol:_0x3b3fdc,hostname:_0x37485c}=new URL(_0x4200e7);if(_0xe45048['startsWith']('chrome-extension://')){const _0x570986=new URL(_0xe45048);return _0x570986['hostname']===''&&_0x37485c===''?_0x3b3fdc==='chrome-extension:'&&_0xe45048['replace']('chrome-extension://','')===_0x4200e7['replace']('chrome-extension://',''):_0x3b3fdc==='chrome-extension:'&&_0x570986['hostname']===_0x37485c;}if(!Np['test'](_0x3b3fdc))return!0x1;if(kp['test'](_0xe45048))return _0x37485c===_0xe45048;const _0x4a9353=_0xe45048['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x4a9353+'|'+_0x4a9353+')$','i')['test'](_0x37485c);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x1ae1fa=X()['___jsl'];if(_0x1ae1fa!=null&&_0x1ae1fa['H']){for(const _0x584b92 of Object['keys'](_0x1ae1fa['H']))if(_0x1ae1fa['H'][_0x584b92]['r']=_0x1ae1fa['H'][_0x584b92]['r']||[],_0x1ae1fa['H'][_0x584b92]['L']=_0x1ae1fa['H'][_0x584b92]['L']||[],_0x1ae1fa['H'][_0x584b92]['r']=[..._0x1ae1fa['H'][_0x584b92]['L']],_0x1ae1fa['CP']){for(let _0x22bf54=0x0;_0x22bf54<_0x1ae1fa['CP']['length'];_0x22bf54++)_0x1ae1fa['CP'][_0x22bf54]=null;}}}function Mp(_0x4b048d){return new Promise((_0x53ba8e,_0xad82ed)=>{var _0x49fcdd,_0x5ce702,_0x4a27e2;function _0x14ed0e(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x53ba8e(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0xad82ed(J(_0x4b048d,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x5ce702=(_0x49fcdd=X()['gapi'])==null?void 0x0:_0x49fcdd['iframes'])!=null&&_0x5ce702['Iframe'])_0x53ba8e(gapi['iframes']['getContext']());else{if((_0x4a27e2=X()['gapi'])!=null&&_0x4a27e2['load'])_0x14ed0e();else{const _0xaa52d4=Nf('iframefcb');return X()[_0xaa52d4]=()=>{gapi['load']?_0x14ed0e():_0xad82ed(J(_0x4b048d,'network-request-failed'));},Da(kf()+'?onload='+_0xaa52d4)['catch'](_0x5e8a20=>_0xad82ed(_0x5e8a20));}}})['catch'](_0x1b0ac3=>{throw on=null,_0x1b0ac3;});}let on=null;function Lp(_0x47e133){return on=on||Mp(_0x47e133),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x4b92fe){const _0x688f0e=_0x4b92fe['config'];m(_0x688f0e['authDomain'],_0x4b92fe,'auth-domain-config-required');const _0x32f8e2=_0x688f0e['emulator']?Is(_0x688f0e,Up):'https://'+_0x4b92fe['config']['authDomain']+'/'+Fp,_0x84a9cd={'apiKey':_0x688f0e['apiKey'],'appName':_0x4b92fe['name'],'v':ct},_0x363331=Bp['get'](_0x4b92fe['config']['apiHost']);_0x363331&&(_0x84a9cd['eid']=_0x363331);const _0x2ea6de=_0x4b92fe['_getFrameworks']();return _0x2ea6de['length']&&(_0x84a9cd['fw']=_0x2ea6de['join'](',')),_0x32f8e2+'?'+at(_0x84a9cd)['slice'](0x1);}async function Hp(_0x2285fc){const _0x31357b=await Lp(_0x2285fc),_0x43b354=X()['gapi'];return m(_0x43b354,_0x2285fc,'internal-error'),_0x31357b['open']({'where':document['body'],'url':Vp(_0x2285fc),'messageHandlersFilter':_0x43b354['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0xdbc6f3=>new Promise(async(_0xb74e95,_0x499064)=>{await _0xdbc6f3['restyle']({'setHideOnLeave':!0x1});const _0x4be137=J(_0x2285fc,'network-request-failed'),_0x1c789b=X()['setTimeout'](()=>{_0x499064(_0x4be137);},xp['get']());function _0x3088fb(){X()['clearTimeout'](_0x1c789b),_0xb74e95(_0xdbc6f3);}_0xdbc6f3['ping'](_0x3088fb)['then'](_0x3088fb,()=>{_0x499064(_0x4be137);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x3c94f9){this['window']=_0x3c94f9,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x59b1e8,_0x22728c,_0x263bba,_0x596478=Gp,_0x48f9fa=qp){const _0x21cd45=Math['max']((window['screen']['availHeight']-_0x48f9fa)/0x2,0x0)['toString'](),_0x26a3de=Math['max']((window['screen']['availWidth']-_0x596478)/0x2,0x0)['toString']();let _0x1b284c='';const _0x5c9c14={...$p,'width':_0x596478['toString'](),'height':_0x48f9fa['toString'](),'top':_0x21cd45,'left':_0x26a3de},_0x1a43fd=W()['toLowerCase']();_0x263bba&&(_0x1b284c=ba(_0x1a43fd)?zp:_0x263bba),Ta(_0x1a43fd)&&(_0x22728c=_0x22728c||jp,_0x5c9c14['scrollbars']='yes');const _0x45ae52=Object['entries'](_0x5c9c14)['reduce']((_0x2d11ff,[_0x5c1616,_0x4bb74c])=>''+_0x2d11ff+_0x5c1616+'='+_0x4bb74c+',','');if(Ef(_0x1a43fd)&&_0x1b284c!=='_self')return Yp(_0x22728c||'',_0x1b284c),new Dr(null);const _0x4d63f1=window['open'](_0x22728c||'',_0x1b284c,_0x45ae52);m(_0x4d63f1,_0x59b1e8,'popup-blocked');try{_0x4d63f1['focus']();}catch{}return new Dr(_0x4d63f1);}function Yp(_0x1d5a70,_0x4d376b){const _0x4c0d20=document['createElement']('a');_0x4c0d20['href']=_0x1d5a70,_0x4c0d20['target']=_0x4d376b;const _0x445242=document['createEvent']('MouseEvent');_0x445242['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x4c0d20['dispatchEvent'](_0x445242);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x59735e,_0x1db5f9,_0x54d669,_0x1950ec,_0x2fd903,_0x466fb9){m(_0x59735e['config']['authDomain'],_0x59735e,'auth-domain-config-required'),m(_0x59735e['config']['apiKey'],_0x59735e,'invalid-api-key');const _0x166fda={'apiKey':_0x59735e['config']['apiKey'],'appName':_0x59735e['name'],'authType':_0x54d669,'redirectUrl':_0x1950ec,'v':ct,'eventId':_0x2fd903};if(_0x1db5f9 instanceof xa){_0x1db5f9['setDefaultLanguage'](_0x59735e['languageCode']),_0x166fda['providerId']=_0x1db5f9['providerId']||'',hi(_0x1db5f9['getCustomParameters']())||(_0x166fda['customParameters']=JSON['stringify'](_0x1db5f9['getCustomParameters']()));for(const [_0xd4dfd9,_0x189bb3]of Object['entries']({}))_0x166fda[_0xd4dfd9]=_0x189bb3;}if(_0x1db5f9 instanceof Qt){const _0x462e5f=_0x1db5f9['getScopes']()['filter'](_0x380eca=>_0x380eca!=='');_0x462e5f['length']>0x0&&(_0x166fda['scopes']=_0x462e5f['join'](','));}_0x59735e['tenantId']&&(_0x166fda['tid']=_0x59735e['tenantId']);const _0x52e504=_0x166fda;for(const _0x12ba89 of Object['keys'](_0x52e504))_0x52e504[_0x12ba89]===void 0x0&&delete _0x52e504[_0x12ba89];const _0x1d38f0=await _0x59735e['_getAppCheckToken'](),_0x47d22d=_0x1d38f0?'#'+Xp+'='+encodeURIComponent(_0x1d38f0):'';return Zp(_0x59735e)+'?'+at(_0x52e504)['slice'](0x1)+_0x47d22d;}function Zp({config:_0x4f150a}){return _0x4f150a['emulator']?Is(_0x4f150a,Jp):'https://'+_0x4f150a['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x3c7f4c,_0x54eba2,_0x3a7083,_0x14af5d){var _0x4f88b4;ae((_0x4f88b4=this['eventManagers'][_0x3c7f4c['_key']()])==null?void 0x0:_0x4f88b4['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x315c08=await Mr(_0x3c7f4c,_0x54eba2,_0x3a7083,Ni(),_0x14af5d);return Kp(_0x3c7f4c,_0x315c08,bs());}async['_openRedirect'](_0x4b8d34,_0x510281,_0x1d5ff3,_0x4e4281){await this['_originValidation'](_0x4b8d34);const _0x2bc457=await Mr(_0x4b8d34,_0x510281,_0x1d5ff3,Ni(),_0x4e4281);return ip(_0x2bc457),new Promise(()=>{});}['_initialize'](_0x1dd948){const _0x4b0675=_0x1dd948['_key']();if(this['eventManagers'][_0x4b0675]){const {manager:_0x16fdf7,promise:_0x958ae8}=this['eventManagers'][_0x4b0675];return _0x16fdf7?Promise['resolve'](_0x16fdf7):(ae(_0x958ae8,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x958ae8);}const _0x48aa64=this['initAndGetManager'](_0x1dd948);return this['eventManagers'][_0x4b0675]={'promise':_0x48aa64},_0x48aa64['catch'](()=>{delete this['eventManagers'][_0x4b0675];}),_0x48aa64;}async['initAndGetManager'](_0x1e5e41){const _0x44a88d=await Hp(_0x1e5e41),_0x44ce69=new bp(_0x1e5e41);return _0x44a88d['register']('authEvent',_0x3c9c2d=>(m(_0x3c9c2d==null?void 0x0:_0x3c9c2d['authEvent'],_0x1e5e41,'invalid-auth-event'),{'status':_0x44ce69['onEvent'](_0x3c9c2d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1e5e41['_key']()]={'manager':_0x44ce69},this['iframes'][_0x1e5e41['_key']()]=_0x44a88d,_0x44ce69;}['_isIframeWebStorageSupported'](_0x4501eb,_0x35b74a){this['iframes'][_0x4501eb['_key']()]['send'](li,{'type':li},_0x138641=>{var _0x2641b6;const _0x234796=(_0x2641b6=_0x138641==null?void 0x0:_0x138641[0x0])==null?void 0x0:_0x2641b6[li];_0x234796!==void 0x0&&_0x35b74a(!!_0x234796),K(_0x4501eb,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2c8d3c){const _0x110520=_0x2c8d3c['_key']();return this['originValidationPromises'][_0x110520]||(this['originValidationPromises'][_0x110520]=Pp(_0x2c8d3c)),this['originValidationPromises'][_0x110520];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x4f1407){this['auth']=_0x4f1407,this['internalListeners']=new Map();}['getUid'](){var _0x386a62;return this['assertAuthConfigured'](),((_0x386a62=this['auth']['currentUser'])==null?void 0x0:_0x386a62['uid'])||null;}async['getToken'](_0xa7eb04){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xa7eb04)}:null;}['addAuthTokenListener'](_0x3e408b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3e408b))return;const _0x3d8746=this['auth']['onIdTokenChanged'](_0x48479a=>{_0x3e408b((_0x48479a==null?void 0x0:_0x48479a['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3e408b,_0x3d8746),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2bf102){this['assertAuthConfigured']();const _0x3d39ad=this['internalListeners']['get'](_0x2bf102);_0x3d39ad&&(this['internalListeners']['delete'](_0x2bf102),_0x3d39ad(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x50ae90){switch(_0x50ae90){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x54307e){et(new Me('auth',(_0x9f8a59,{options:_0x293f8e})=>{const _0x3e65c6=_0x9f8a59['getProvider']('app')['getImmediate'](),_0x594e9b=_0x9f8a59['getProvider']('heartbeat'),_0x37a5fc=_0x9f8a59['getProvider']('app-check-internal'),{apiKey:_0x19f1fc,authDomain:_0x41f14c}=_0x3e65c6['options'];m(_0x19f1fc&&!_0x19f1fc['includes'](':'),'invalid-api-key',{'appName':_0x3e65c6['name']});const _0x1e924f={'apiKey':_0x19f1fc,'authDomain':_0x41f14c,'clientPlatform':_0x54307e,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x54307e)},_0x127e4c=new bf(_0x3e65c6,_0x594e9b,_0x37a5fc,_0x1e924f);return Lf(_0x127e4c,_0x293f8e),_0x127e4c;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x517dd8,_0x387cc4,_0x16569f)=>{_0x517dd8['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x355777=>{const _0x43b240=qe(_0x355777['getProvider']('auth')['getImmediate']());return(_0x93dabc=>new n_(_0x93dabc))(_0x43b240);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x54307e)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x354f32=>async _0x29e578=>{const _0x1bfb39=_0x29e578&&await _0x29e578['getIdTokenResult'](),_0x11c4c3=_0x1bfb39&&(new Date()['getTime']()-Date['parse'](_0x1bfb39['issuedAtTime']))/0x3e8;if(_0x11c4c3&&_0x11c4c3>o_)return;const _0x3b65aa=_0x1bfb39==null?void 0x0:_0x1bfb39['token'];Fr!==_0x3b65aa&&(Fr=_0x3b65aa,await fetch(_0x354f32,{'method':_0x3b65aa?'POST':'DELETE','headers':_0x3b65aa?{'Authorization':'Bearer\x20'+_0x3b65aa}:{}}));};function O_(_0x57fc2f=Qr()){const _0x53cb8a=Ui(_0x57fc2f,'auth');if(_0x53cb8a['isInitialized']())return _0x53cb8a['getImmediate']();const _0x59bbd1=Mf(_0x57fc2f,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x235f75=Gr('authTokenSyncURL');if(_0x235f75&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x415290=new URL(_0x235f75,location['origin']);if(location['origin']===_0x415290['origin']){const _0x5960d2=a_(_0x415290['toString']());Jf(_0x59bbd1,_0x5960d2,()=>_0x5960d2(_0x59bbd1['currentUser'])),Qf(_0x59bbd1,_0x33e5d2=>_0x5960d2(_0x33e5d2));}}const _0x2b18c7=Hr('auth');return _0x2b18c7&&xf(_0x59bbd1,'http://'+_0x2b18c7),_0x59bbd1;}function c_(){var _0xb29219;return((_0xb29219=document['getElementsByTagName']('head'))==null?void 0x0:_0xb29219[0x0])??document;}Rf({'loadJS'(_0x2ca75c){return new Promise((_0x4cbe36,_0x3cdc6a)=>{const _0x7999b4=document['createElement']('script');_0x7999b4['setAttribute']('src',_0x2ca75c),_0x7999b4['onload']=_0x4cbe36,_0x7999b4['onerror']=_0x501fe3=>{const _0x59427a=J('internal-error');_0x59427a['customData']=_0x501fe3,_0x3cdc6a(_0x59427a);},_0x7999b4['type']='text/javascript',_0x7999b4['charset']='UTF-8',c_()['appendChild'](_0x7999b4);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};