const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x47a830,_0x33530a){if(!_0x47a830)throw ot(_0x33530a);},ot=function(_0x411e9f){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x411e9f);},Wr=function(_0x1703d9){const _0x4cc37b=[];let _0x1efa1c=0x0;for(let _0x3e2b6f=0x0;_0x3e2b6f<_0x1703d9['length'];_0x3e2b6f++){let _0x3cda83=_0x1703d9['charCodeAt'](_0x3e2b6f);_0x3cda83<0x80?_0x4cc37b[_0x1efa1c++]=_0x3cda83:_0x3cda83<0x800?(_0x4cc37b[_0x1efa1c++]=_0x3cda83>>0x6|0xc0,_0x4cc37b[_0x1efa1c++]=_0x3cda83&0x3f|0x80):(_0x3cda83&0xfc00)===0xd800&&_0x3e2b6f+0x1<_0x1703d9['length']&&(_0x1703d9['charCodeAt'](_0x3e2b6f+0x1)&0xfc00)===0xdc00?(_0x3cda83=0x10000+((_0x3cda83&0x3ff)<<0xa)+(_0x1703d9['charCodeAt'](++_0x3e2b6f)&0x3ff),_0x4cc37b[_0x1efa1c++]=_0x3cda83>>0x12|0xf0,_0x4cc37b[_0x1efa1c++]=_0x3cda83>>0xc&0x3f|0x80,_0x4cc37b[_0x1efa1c++]=_0x3cda83>>0x6&0x3f|0x80,_0x4cc37b[_0x1efa1c++]=_0x3cda83&0x3f|0x80):(_0x4cc37b[_0x1efa1c++]=_0x3cda83>>0xc|0xe0,_0x4cc37b[_0x1efa1c++]=_0x3cda83>>0x6&0x3f|0x80,_0x4cc37b[_0x1efa1c++]=_0x3cda83&0x3f|0x80);}return _0x4cc37b;},Za=function(_0xab53f){const _0xcf4f45=[];let _0x281410=0x0,_0x333715=0x0;for(;_0x281410<_0xab53f['length'];){const _0x472264=_0xab53f[_0x281410++];if(_0x472264<0x80)_0xcf4f45[_0x333715++]=String['fromCharCode'](_0x472264);else{if(_0x472264>0xbf&&_0x472264<0xe0){const _0x72a380=_0xab53f[_0x281410++];_0xcf4f45[_0x333715++]=String['fromCharCode']((_0x472264&0x1f)<<0x6|_0x72a380&0x3f);}else{if(_0x472264>0xef&&_0x472264<0x16d){const _0x25bb0d=_0xab53f[_0x281410++],_0x59b8ba=_0xab53f[_0x281410++],_0x49f0ee=_0xab53f[_0x281410++],_0x380db9=((_0x472264&0x7)<<0x12|(_0x25bb0d&0x3f)<<0xc|(_0x59b8ba&0x3f)<<0x6|_0x49f0ee&0x3f)-0x10000;_0xcf4f45[_0x333715++]=String['fromCharCode'](0xd800+(_0x380db9>>0xa)),_0xcf4f45[_0x333715++]=String['fromCharCode'](0xdc00+(_0x380db9&0x3ff));}else{const _0x22f722=_0xab53f[_0x281410++],_0x14a529=_0xab53f[_0x281410++];_0xcf4f45[_0x333715++]=String['fromCharCode']((_0x472264&0xf)<<0xc|(_0x22f722&0x3f)<<0x6|_0x14a529&0x3f);}}}}return _0xcf4f45['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x873ea7,_0x394a9a){if(!Array['isArray'](_0x873ea7))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2108ea=_0x394a9a?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x156b9a=[];for(let _0x5d55e7=0x0;_0x5d55e7<_0x873ea7['length'];_0x5d55e7+=0x3){const _0x28097a=_0x873ea7[_0x5d55e7],_0x46b818=_0x5d55e7+0x1<_0x873ea7['length'],_0xbef170=_0x46b818?_0x873ea7[_0x5d55e7+0x1]:0x0,_0x5c5cb9=_0x5d55e7+0x2<_0x873ea7['length'],_0x3366b3=_0x5c5cb9?_0x873ea7[_0x5d55e7+0x2]:0x0,_0x41a0bb=_0x28097a>>0x2,_0x435015=(_0x28097a&0x3)<<0x4|_0xbef170>>0x4;let _0x5a2703=(_0xbef170&0xf)<<0x2|_0x3366b3>>0x6,_0x40fadb=_0x3366b3&0x3f;_0x5c5cb9||(_0x40fadb=0x40,_0x46b818||(_0x5a2703=0x40)),_0x156b9a['push'](_0x2108ea[_0x41a0bb],_0x2108ea[_0x435015],_0x2108ea[_0x5a2703],_0x2108ea[_0x40fadb]);}return _0x156b9a['join']('');},'encodeString'(_0x4e789c,_0x3a828e){return this['HAS_NATIVE_SUPPORT']&&!_0x3a828e?btoa(_0x4e789c):this['encodeByteArray'](Wr(_0x4e789c),_0x3a828e);},'decodeString'(_0x4a8540,_0x4943e6){return this['HAS_NATIVE_SUPPORT']&&!_0x4943e6?atob(_0x4a8540):Za(this['decodeStringToByteArray'](_0x4a8540,_0x4943e6));},'decodeStringToByteArray'(_0x274661,_0x236193){this['init_']();const _0x19b6d6=_0x236193?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x360f54=[];for(let _0x8b7800=0x0;_0x8b7800<_0x274661['length'];){const _0x196705=_0x19b6d6[_0x274661['charAt'](_0x8b7800++)],_0x5c51db=_0x8b7800<_0x274661['length']?_0x19b6d6[_0x274661['charAt'](_0x8b7800)]:0x0;++_0x8b7800;const _0x502340=_0x8b7800<_0x274661['length']?_0x19b6d6[_0x274661['charAt'](_0x8b7800)]:0x40;++_0x8b7800;const _0x406fc0=_0x8b7800<_0x274661['length']?_0x19b6d6[_0x274661['charAt'](_0x8b7800)]:0x40;if(++_0x8b7800,_0x196705==null||_0x5c51db==null||_0x502340==null||_0x406fc0==null)throw new ec();const _0x3c58d7=_0x196705<<0x2|_0x5c51db>>0x4;if(_0x360f54['push'](_0x3c58d7),_0x502340!==0x40){const _0x2e8144=_0x5c51db<<0x4&0xf0|_0x502340>>0x2;if(_0x360f54['push'](_0x2e8144),_0x406fc0!==0x40){const _0x34bc6d=_0x502340<<0x6&0xc0|_0x406fc0;_0x360f54['push'](_0x34bc6d);}}}return _0x360f54;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x2f848c=0x0;_0x2f848c<this['ENCODED_VALS']['length'];_0x2f848c++)this['byteToCharMap_'][_0x2f848c]=this['ENCODED_VALS']['charAt'](_0x2f848c),this['charToByteMap_'][this['byteToCharMap_'][_0x2f848c]]=_0x2f848c,this['byteToCharMapWebSafe_'][_0x2f848c]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2f848c),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x2f848c]]=_0x2f848c,_0x2f848c>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2f848c)]=_0x2f848c,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x2f848c)]=_0x2f848c);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x1bb5fb){const _0x20a849=Wr(_0x1bb5fb);return Di['encodeByteArray'](_0x20a849,!0x0);},an=function(_0x46b9b9){return Br(_0x46b9b9)['replace'](/\./g,'');},cn=function(_0x3aa0a1){try{return Di['decodeString'](_0x3aa0a1,!0x0);}catch(_0x1f63dc){console['error']('base64Decode\x20failed:\x20',_0x1f63dc);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x33d6ad){return Vr(void 0x0,_0x33d6ad);}function Vr(_0x11f2d4,_0x577a20){if(!(_0x577a20 instanceof Object))return _0x577a20;switch(_0x577a20['constructor']){case Date:const _0x137465=_0x577a20;return new Date(_0x137465['getTime']());case Object:_0x11f2d4===void 0x0&&(_0x11f2d4={});break;case Array:_0x11f2d4=[];break;default:return _0x577a20;}for(const _0x1399fa in _0x577a20)!_0x577a20['hasOwnProperty'](_0x1399fa)||!nc(_0x1399fa)||(_0x11f2d4[_0x1399fa]=Vr(_0x11f2d4[_0x1399fa],_0x577a20[_0x1399fa]));return _0x11f2d4;}function nc(_0x3333de){return _0x3333de!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x1a91dc=As['__FIREBASE_DEFAULTS__'];if(_0x1a91dc)return JSON['parse'](_0x1a91dc);},oc=()=>{if(typeof document>'u')return;let _0x32254f;try{_0x32254f=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2d09dd=_0x32254f&&cn(_0x32254f[0x1]);return _0x2d09dd&&JSON['parse'](_0x2d09dd);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x114f02){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x114f02);return;}},Hr=_0x177ba3=>{var _0x1b6cc4,_0x33e1c;return(_0x33e1c=(_0x1b6cc4=Mi())==null?void 0x0:_0x1b6cc4['emulatorHosts'])==null?void 0x0:_0x33e1c[_0x177ba3];},ac=_0x3138c0=>{const _0x12fe86=Hr(_0x3138c0);if(!_0x12fe86)return;const _0x9b7b1e=_0x12fe86['lastIndexOf'](':');if(_0x9b7b1e<=0x0||_0x9b7b1e+0x1===_0x12fe86['length'])throw new Error('Invalid\x20host\x20'+_0x12fe86+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x9aa4e6=parseInt(_0x12fe86['substring'](_0x9b7b1e+0x1),0xa);return _0x12fe86[0x0]==='['?[_0x12fe86['substring'](0x1,_0x9b7b1e-0x1),_0x9aa4e6]:[_0x12fe86['substring'](0x0,_0x9b7b1e),_0x9aa4e6];},$r=()=>{var _0x30e268;return(_0x30e268=Mi())==null?void 0x0:_0x30e268['config'];},Gr=_0x4482eb=>{var _0x5af7c5;return(_0x5af7c5=Mi())==null?void 0x0:_0x5af7c5['_'+_0x4482eb];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3e02a1,_0x31bf25)=>{this['resolve']=_0x3e02a1,this['reject']=_0x31bf25;});}['wrapCallback'](_0x26f643){return(_0x4c152c,_0x3f30bc)=>{_0x4c152c?this['reject'](_0x4c152c):this['resolve'](_0x3f30bc),typeof _0x26f643=='function'&&(this['promise']['catch'](()=>{}),_0x26f643['length']===0x1?_0x26f643(_0x4c152c):_0x26f643(_0x4c152c,_0x3f30bc));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3cfbd3,_0x4de9a6){if(_0x3cfbd3['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x270939={'alg':'none','type':'JWT'},_0x30188c=_0x4de9a6||'demo-project',_0x2ab2df=_0x3cfbd3['iat']||0x0,_0x7cbb60=_0x3cfbd3['sub']||_0x3cfbd3['user_id'];if(!_0x7cbb60)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x27fdec={'iss':'https://securetoken.google.com/'+_0x30188c,'aud':_0x30188c,'iat':_0x2ab2df,'exp':_0x2ab2df+0xe10,'auth_time':_0x2ab2df,'sub':_0x7cbb60,'user_id':_0x7cbb60,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3cfbd3};return[an(JSON['stringify'](_0x270939)),an(JSON['stringify'](_0x27fdec)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x3191fc=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x3191fc=='object'&&_0x3191fc['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x49fca1=W();return _0x49fca1['indexOf']('MSIE\x20')>=0x0||_0x49fca1['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x588fb4,_0x9e936d)=>{try{let _0x2df626=!0x0;const _0x183653='validate-browser-context-for-indexeddb-analytics-module',_0x233f37=self['indexedDB']['open'](_0x183653);_0x233f37['onsuccess']=()=>{_0x233f37['result']['close'](),_0x2df626||self['indexedDB']['deleteDatabase'](_0x183653),_0x588fb4(!0x0);},_0x233f37['onupgradeneeded']=()=>{_0x2df626=!0x1;},_0x233f37['onerror']=()=>{var _0x21e0e4;_0x9e936d(((_0x21e0e4=_0x233f37['error'])==null?void 0x0:_0x21e0e4['message'])||'');};}catch(_0x538e98){_0x9e936d(_0x538e98);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x3c9728,_0x52dd1f,_0x68e4f3){super(_0x52dd1f),this['code']=_0x3c9728,this['customData']=_0x68e4f3,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x50a3b9,_0x4ad06c,_0xea8fee){this['service']=_0x50a3b9,this['serviceName']=_0x4ad06c,this['errors']=_0xea8fee;}['create'](_0x254f6f,..._0x265522){const _0xfeaa3a=_0x265522[0x0]||{},_0x8b5d1c=this['service']+'/'+_0x254f6f,_0x3aac2f=this['errors'][_0x254f6f],_0x48d50d=_0x3aac2f?gc(_0x3aac2f,_0xfeaa3a):'Error',_0x5f8633=this['serviceName']+':\x20'+_0x48d50d+'\x20('+_0x8b5d1c+').';return new Se(_0x8b5d1c,_0x5f8633,_0xfeaa3a);}}function gc(_0x253254,_0x261bc7){return _0x253254['replace'](mc,(_0x587a0e,_0x22b2d4)=>{const _0x46bb26=_0x261bc7[_0x22b2d4];return _0x46bb26!=null?String(_0x46bb26):'<'+_0x22b2d4+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x10eee0){return JSON['parse'](_0x10eee0);}function O(_0x40ca61){return JSON['stringify'](_0x40ca61);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x2023c7){let _0x1b71ab={},_0x54f032={},_0x52b940={},_0x31bfbf='';try{const _0xe0b481=_0x2023c7['split']('.');_0x1b71ab=bt(cn(_0xe0b481[0x0])||''),_0x54f032=bt(cn(_0xe0b481[0x1])||''),_0x31bfbf=_0xe0b481[0x2],_0x52b940=_0x54f032['d']||{},delete _0x54f032['d'];}catch{}return{'header':_0x1b71ab,'claims':_0x54f032,'data':_0x52b940,'signature':_0x31bfbf};},yc=function(_0x24a8a9){const _0x125bc9=zr(_0x24a8a9),_0x23aaaf=_0x125bc9['claims'];return!!_0x23aaaf&&typeof _0x23aaaf=='object'&&_0x23aaaf['hasOwnProperty']('iat');},vc=function(_0x1f9090){const _0x14826e=zr(_0x1f9090)['claims'];return typeof _0x14826e=='object'&&_0x14826e['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x469f5a,_0x51867e){return Object['prototype']['hasOwnProperty']['call'](_0x469f5a,_0x51867e);}function Oe(_0x1c79f4,_0x3290e3){if(Object['prototype']['hasOwnProperty']['call'](_0x1c79f4,_0x3290e3))return _0x1c79f4[_0x3290e3];}function hi(_0x47a215){for(const _0x193d03 in _0x47a215)if(Object['prototype']['hasOwnProperty']['call'](_0x47a215,_0x193d03))return!0x1;return!0x0;}function ln(_0x4b8779,_0x45df87,_0x5297f0){const _0x5e1678={};for(const _0x485168 in _0x4b8779)Object['prototype']['hasOwnProperty']['call'](_0x4b8779,_0x485168)&&(_0x5e1678[_0x485168]=_0x45df87['call'](_0x5297f0,_0x4b8779[_0x485168],_0x485168,_0x4b8779));return _0x5e1678;}function De(_0xc38412,_0x21c776){if(_0xc38412===_0x21c776)return!0x0;const _0x5efae0=Object['keys'](_0xc38412),_0x42eebc=Object['keys'](_0x21c776);for(const _0x49030e of _0x5efae0){if(!_0x42eebc['includes'](_0x49030e))return!0x1;const _0x115337=_0xc38412[_0x49030e],_0x245d7a=_0x21c776[_0x49030e];if(ks(_0x115337)&&ks(_0x245d7a)){if(!De(_0x115337,_0x245d7a))return!0x1;}else{if(_0x115337!==_0x245d7a)return!0x1;}}for(const _0x414e81 of _0x42eebc)if(!_0x5efae0['includes'](_0x414e81))return!0x1;return!0x0;}function ks(_0xda7bbb){return _0xda7bbb!==null&&typeof _0xda7bbb=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x10ca50){const _0x489006=[];for(const [_0x3d311b,_0x5629b6]of Object['entries'](_0x10ca50))Array['isArray'](_0x5629b6)?_0x5629b6['forEach'](_0x6b721b=>{_0x489006['push'](encodeURIComponent(_0x3d311b)+'='+encodeURIComponent(_0x6b721b));}):_0x489006['push'](encodeURIComponent(_0x3d311b)+'='+encodeURIComponent(_0x5629b6));return _0x489006['length']?'&'+_0x489006['join']('&'):'';}function yt(_0x37a8bd){const _0x21b785={};return _0x37a8bd['replace'](/^\?/,'')['split']('&')['forEach'](_0x8c6505=>{if(_0x8c6505){const [_0x1add29,_0x434620]=_0x8c6505['split']('=');_0x21b785[decodeURIComponent(_0x1add29)]=decodeURIComponent(_0x434620);}}),_0x21b785;}function vt(_0x4da635){const _0x10b8e8=_0x4da635['indexOf']('?');if(!_0x10b8e8)return'';const _0x480cc7=_0x4da635['indexOf']('#',_0x10b8e8);return _0x4da635['substring'](_0x10b8e8,_0x480cc7>0x0?_0x480cc7:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x55c130=0x1;_0x55c130<this['blockSize'];++_0x55c130)this['pad_'][_0x55c130]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1d6296,_0x5133ed){_0x5133ed||(_0x5133ed=0x0);const _0x2f51bb=this['W_'];if(typeof _0x1d6296=='string'){for(let _0x7e1fa3=0x0;_0x7e1fa3<0x10;_0x7e1fa3++)_0x2f51bb[_0x7e1fa3]=_0x1d6296['charCodeAt'](_0x5133ed)<<0x18|_0x1d6296['charCodeAt'](_0x5133ed+0x1)<<0x10|_0x1d6296['charCodeAt'](_0x5133ed+0x2)<<0x8|_0x1d6296['charCodeAt'](_0x5133ed+0x3),_0x5133ed+=0x4;}else{for(let _0x58179b=0x0;_0x58179b<0x10;_0x58179b++)_0x2f51bb[_0x58179b]=_0x1d6296[_0x5133ed]<<0x18|_0x1d6296[_0x5133ed+0x1]<<0x10|_0x1d6296[_0x5133ed+0x2]<<0x8|_0x1d6296[_0x5133ed+0x3],_0x5133ed+=0x4;}for(let _0x333c9f=0x10;_0x333c9f<0x50;_0x333c9f++){const _0xc7b77a=_0x2f51bb[_0x333c9f-0x3]^_0x2f51bb[_0x333c9f-0x8]^_0x2f51bb[_0x333c9f-0xe]^_0x2f51bb[_0x333c9f-0x10];_0x2f51bb[_0x333c9f]=(_0xc7b77a<<0x1|_0xc7b77a>>>0x1f)&0xffffffff;}let _0x738c31=this['chain_'][0x0],_0x273e69=this['chain_'][0x1],_0x3d2fbd=this['chain_'][0x2],_0x18f452=this['chain_'][0x3],_0x224b8e=this['chain_'][0x4],_0x155d3d,_0x17a115;for(let _0x55510c=0x0;_0x55510c<0x50;_0x55510c++){_0x55510c<0x28?_0x55510c<0x14?(_0x155d3d=_0x18f452^_0x273e69&(_0x3d2fbd^_0x18f452),_0x17a115=0x5a827999):(_0x155d3d=_0x273e69^_0x3d2fbd^_0x18f452,_0x17a115=0x6ed9eba1):_0x55510c<0x3c?(_0x155d3d=_0x273e69&_0x3d2fbd|_0x18f452&(_0x273e69|_0x3d2fbd),_0x17a115=0x8f1bbcdc):(_0x155d3d=_0x273e69^_0x3d2fbd^_0x18f452,_0x17a115=0xca62c1d6);const _0x17a15c=(_0x738c31<<0x5|_0x738c31>>>0x1b)+_0x155d3d+_0x224b8e+_0x17a115+_0x2f51bb[_0x55510c]&0xffffffff;_0x224b8e=_0x18f452,_0x18f452=_0x3d2fbd,_0x3d2fbd=(_0x273e69<<0x1e|_0x273e69>>>0x2)&0xffffffff,_0x273e69=_0x738c31,_0x738c31=_0x17a15c;}this['chain_'][0x0]=this['chain_'][0x0]+_0x738c31&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x273e69&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3d2fbd&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x18f452&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x224b8e&0xffffffff;}['update'](_0x16a239,_0x3f4506){if(_0x16a239==null)return;_0x3f4506===void 0x0&&(_0x3f4506=_0x16a239['length']);const _0x395d39=_0x3f4506-this['blockSize'];let _0x2c7beb=0x0;const _0x59b0f8=this['buf_'];let _0x1d5f6d=this['inbuf_'];for(;_0x2c7beb<_0x3f4506;){if(_0x1d5f6d===0x0){for(;_0x2c7beb<=_0x395d39;)this['compress_'](_0x16a239,_0x2c7beb),_0x2c7beb+=this['blockSize'];}if(typeof _0x16a239=='string'){for(;_0x2c7beb<_0x3f4506;)if(_0x59b0f8[_0x1d5f6d]=_0x16a239['charCodeAt'](_0x2c7beb),++_0x1d5f6d,++_0x2c7beb,_0x1d5f6d===this['blockSize']){this['compress_'](_0x59b0f8),_0x1d5f6d=0x0;break;}}else{for(;_0x2c7beb<_0x3f4506;)if(_0x59b0f8[_0x1d5f6d]=_0x16a239[_0x2c7beb],++_0x1d5f6d,++_0x2c7beb,_0x1d5f6d===this['blockSize']){this['compress_'](_0x59b0f8),_0x1d5f6d=0x0;break;}}}this['inbuf_']=_0x1d5f6d,this['total_']+=_0x3f4506;}['digest'](){const _0x1ac6bf=[];let _0x332771=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x517d84=this['blockSize']-0x1;_0x517d84>=0x38;_0x517d84--)this['buf_'][_0x517d84]=_0x332771&0xff,_0x332771/=0x100;this['compress_'](this['buf_']);let _0xee50ae=0x0;for(let _0x3749ee=0x0;_0x3749ee<0x5;_0x3749ee++)for(let _0x5b8d4b=0x18;_0x5b8d4b>=0x0;_0x5b8d4b-=0x8)_0x1ac6bf[_0xee50ae]=this['chain_'][_0x3749ee]>>_0x5b8d4b&0xff,++_0xee50ae;return _0x1ac6bf;}}function Ic(_0x165244,_0x2a95fd){const _0x5157a2=new wc(_0x165244,_0x2a95fd);return _0x5157a2['subscribe']['bind'](_0x5157a2);}class wc{constructor(_0x3fa3a9,_0x3c9991){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3c9991,this['task']['then'](()=>{_0x3fa3a9(this);})['catch'](_0x4b647a=>{this['error'](_0x4b647a);});}['next'](_0x298b51){this['forEachObserver'](_0x2599e7=>{_0x2599e7['next'](_0x298b51);});}['error'](_0x247b68){this['forEachObserver'](_0x2584b2=>{_0x2584b2['error'](_0x247b68);}),this['close'](_0x247b68);}['complete'](){this['forEachObserver'](_0x19b103=>{_0x19b103['complete']();}),this['close']();}['subscribe'](_0x497b09,_0x28219e,_0x5189d6){let _0x884fa6;if(_0x497b09===void 0x0&&_0x28219e===void 0x0&&_0x5189d6===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x497b09,['next','error','complete'])?_0x884fa6=_0x497b09:_0x884fa6={'next':_0x497b09,'error':_0x28219e,'complete':_0x5189d6},_0x884fa6['next']===void 0x0&&(_0x884fa6['next']=Qn),_0x884fa6['error']===void 0x0&&(_0x884fa6['error']=Qn),_0x884fa6['complete']===void 0x0&&(_0x884fa6['complete']=Qn);const _0x296b3b=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x884fa6['error'](this['finalError']):_0x884fa6['complete']();}catch{}}),this['observers']['push'](_0x884fa6),_0x296b3b;}['unsubscribeOne'](_0xe30b7a){this['observers']===void 0x0||this['observers'][_0xe30b7a]===void 0x0||(delete this['observers'][_0xe30b7a],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x540797){if(!this['finalized']){for(let _0x3ccbbe=0x0;_0x3ccbbe<this['observers']['length'];_0x3ccbbe++)this['sendOne'](_0x3ccbbe,_0x540797);}}['sendOne'](_0x2b987d,_0x2aff96){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2b987d]!==void 0x0)try{_0x2aff96(this['observers'][_0x2b987d]);}catch(_0x5be111){typeof console<'u'&&console['error']&&console['error'](_0x5be111);}});}['close'](_0x5c1d85){this['finalized']||(this['finalized']=!0x0,_0x5c1d85!==void 0x0&&(this['finalError']=_0x5c1d85),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0xe43220,_0x376a03){if(typeof _0xe43220!='object'||_0xe43220===null)return!0x1;for(const _0x57a8e7 of _0x376a03)if(_0x57a8e7 in _0xe43220&&typeof _0xe43220[_0x57a8e7]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x3ae9e6,_0x4f4e51){return _0x3ae9e6+'\x20failed:\x20'+_0x4f4e51+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x243fef){const _0x22af71=[];let _0x206dde=0x0;for(let _0x26b397=0x0;_0x26b397<_0x243fef['length'];_0x26b397++){let _0x141c29=_0x243fef['charCodeAt'](_0x26b397);if(_0x141c29>=0xd800&&_0x141c29<=0xdbff){const _0x15ffe4=_0x141c29-0xd800;_0x26b397++,f(_0x26b397<_0x243fef['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x4ab267=_0x243fef['charCodeAt'](_0x26b397)-0xdc00;_0x141c29=0x10000+(_0x15ffe4<<0xa)+_0x4ab267;}_0x141c29<0x80?_0x22af71[_0x206dde++]=_0x141c29:_0x141c29<0x800?(_0x22af71[_0x206dde++]=_0x141c29>>0x6|0xc0,_0x22af71[_0x206dde++]=_0x141c29&0x3f|0x80):_0x141c29<0x10000?(_0x22af71[_0x206dde++]=_0x141c29>>0xc|0xe0,_0x22af71[_0x206dde++]=_0x141c29>>0x6&0x3f|0x80,_0x22af71[_0x206dde++]=_0x141c29&0x3f|0x80):(_0x22af71[_0x206dde++]=_0x141c29>>0x12|0xf0,_0x22af71[_0x206dde++]=_0x141c29>>0xc&0x3f|0x80,_0x22af71[_0x206dde++]=_0x141c29>>0x6&0x3f|0x80,_0x22af71[_0x206dde++]=_0x141c29&0x3f|0x80);}return _0x22af71;},Pn=function(_0x4a68ea){let _0x1c47a4=0x0;for(let _0x1ad3b2=0x0;_0x1ad3b2<_0x4a68ea['length'];_0x1ad3b2++){const _0x145142=_0x4a68ea['charCodeAt'](_0x1ad3b2);_0x145142<0x80?_0x1c47a4++:_0x145142<0x800?_0x1c47a4+=0x2:_0x145142>=0xd800&&_0x145142<=0xdbff?(_0x1c47a4+=0x4,_0x1ad3b2++):_0x1c47a4+=0x3;}return _0x1c47a4;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x438a9e){return _0x438a9e&&_0x438a9e['_delegate']?_0x438a9e['_delegate']:_0x438a9e;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x1e5f62){try{return(_0x1e5f62['startsWith']('http://')||_0x1e5f62['startsWith']('https://')?new URL(_0x1e5f62)['hostname']:_0x1e5f62)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x3643b7){return(await fetch(_0x3643b7,{'credentials':'include'}))['ok'];}class Me{constructor(_0xd4c1ac,_0xb5fe39,_0x2f768c){this['name']=_0xd4c1ac,this['instanceFactory']=_0xb5fe39,this['type']=_0x2f768c,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x391354){return this['instantiationMode']=_0x391354,this;}['setMultipleInstances'](_0x2b22d9){return this['multipleInstances']=_0x2b22d9,this;}['setServiceProps'](_0x2dd834){return this['serviceProps']=_0x2dd834,this;}['setInstanceCreatedCallback'](_0x26ca9e){return this['onInstanceCreated']=_0x26ca9e,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x485bbc,_0x2dd13b){this['name']=_0x485bbc,this['container']=_0x2dd13b,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x115c5e){const _0x1124ad=this['normalizeInstanceIdentifier'](_0x115c5e);if(!this['instancesDeferred']['has'](_0x1124ad)){const _0x556a40=new Ve();if(this['instancesDeferred']['set'](_0x1124ad,_0x556a40),this['isInitialized'](_0x1124ad)||this['shouldAutoInitialize']())try{const _0x13eccd=this['getOrInitializeService']({'instanceIdentifier':_0x1124ad});_0x13eccd&&_0x556a40['resolve'](_0x13eccd);}catch{}}return this['instancesDeferred']['get'](_0x1124ad)['promise'];}['getImmediate'](_0x1d8b53){const _0x5ebb01=this['normalizeInstanceIdentifier'](_0x1d8b53==null?void 0x0:_0x1d8b53['identifier']),_0x1fb5e7=(_0x1d8b53==null?void 0x0:_0x1d8b53['optional'])??!0x1;if(this['isInitialized'](_0x5ebb01)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x5ebb01});}catch(_0x36af93){if(_0x1fb5e7)return null;throw _0x36af93;}else{if(_0x1fb5e7)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x56aa14){if(_0x56aa14['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x56aa14['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x56aa14,!!this['shouldAutoInitialize']()){if(Rc(_0x56aa14))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x1acb3f,_0x13ab29]of this['instancesDeferred']['entries']()){const _0x2b2382=this['normalizeInstanceIdentifier'](_0x1acb3f);try{const _0x5e9285=this['getOrInitializeService']({'instanceIdentifier':_0x2b2382});_0x13ab29['resolve'](_0x5e9285);}catch{}}}}['clearInstance'](_0x17993d=ke){this['instancesDeferred']['delete'](_0x17993d),this['instancesOptions']['delete'](_0x17993d),this['instances']['delete'](_0x17993d);}async['delete'](){const _0xb2c738=Array['from'](this['instances']['values']());await Promise['all']([..._0xb2c738['filter'](_0x547506=>'INTERNAL'in _0x547506)['map'](_0x1eb56e=>_0x1eb56e['INTERNAL']['delete']()),..._0xb2c738['filter'](_0xc4e17f=>'_delete'in _0xc4e17f)['map'](_0x3cfdc2=>_0x3cfdc2['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x179bd4=ke){return this['instances']['has'](_0x179bd4);}['getOptions'](_0x2bd229=ke){return this['instancesOptions']['get'](_0x2bd229)||{};}['initialize'](_0x218bf2={}){const {options:_0xca4e7a={}}=_0x218bf2,_0x5d3cd9=this['normalizeInstanceIdentifier'](_0x218bf2['instanceIdentifier']);if(this['isInitialized'](_0x5d3cd9))throw Error(this['name']+'('+_0x5d3cd9+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x463e69=this['getOrInitializeService']({'instanceIdentifier':_0x5d3cd9,'options':_0xca4e7a});for(const [_0x4bc75a,_0x53199b]of this['instancesDeferred']['entries']()){const _0x5c602d=this['normalizeInstanceIdentifier'](_0x4bc75a);_0x5d3cd9===_0x5c602d&&_0x53199b['resolve'](_0x463e69);}return _0x463e69;}['onInit'](_0x23137e,_0x274ae2){const _0x34a083=this['normalizeInstanceIdentifier'](_0x274ae2),_0x2593dc=this['onInitCallbacks']['get'](_0x34a083)??new Set();_0x2593dc['add'](_0x23137e),this['onInitCallbacks']['set'](_0x34a083,_0x2593dc);const _0x5c6a87=this['instances']['get'](_0x34a083);return _0x5c6a87&&_0x23137e(_0x5c6a87,_0x34a083),()=>{_0x2593dc['delete'](_0x23137e);};}['invokeOnInitCallbacks'](_0x3272e7,_0x9b9720){const _0x3344df=this['onInitCallbacks']['get'](_0x9b9720);if(_0x3344df){for(const _0x129568 of _0x3344df)try{_0x129568(_0x3272e7,_0x9b9720);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2fa772,options:_0x4c261b={}}){let _0x1cbead=this['instances']['get'](_0x2fa772);if(!_0x1cbead&&this['component']&&(_0x1cbead=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x2fa772),'options':_0x4c261b}),this['instances']['set'](_0x2fa772,_0x1cbead),this['instancesOptions']['set'](_0x2fa772,_0x4c261b),this['invokeOnInitCallbacks'](_0x1cbead,_0x2fa772),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2fa772,_0x1cbead);}catch{}return _0x1cbead||null;}['normalizeInstanceIdentifier'](_0x2bce78=ke){return this['component']?this['component']['multipleInstances']?_0x2bce78:ke:_0x2bce78;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x3d34aa){return _0x3d34aa===ke?void 0x0:_0x3d34aa;}function Rc(_0x3298b3){return _0x3298b3['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x31c9c2){this['name']=_0x31c9c2,this['providers']=new Map();}['addComponent'](_0x313a83){const _0x42acc7=this['getProvider'](_0x313a83['name']);if(_0x42acc7['isComponentSet']())throw new Error('Component\x20'+_0x313a83['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x42acc7['setComponent'](_0x313a83);}['addOrOverwriteComponent'](_0x18cdcd){this['getProvider'](_0x18cdcd['name'])['isComponentSet']()&&this['providers']['delete'](_0x18cdcd['name']),this['addComponent'](_0x18cdcd);}['getProvider'](_0x4512ff){if(this['providers']['has'](_0x4512ff))return this['providers']['get'](_0x4512ff);const _0x5e3305=new Sc(_0x4512ff,this);return this['providers']['set'](_0x4512ff,_0x5e3305),_0x5e3305;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x27cd33){_0x27cd33[_0x27cd33['DEBUG']=0x0]='DEBUG',_0x27cd33[_0x27cd33['VERBOSE']=0x1]='VERBOSE',_0x27cd33[_0x27cd33['INFO']=0x2]='INFO',_0x27cd33[_0x27cd33['WARN']=0x3]='WARN',_0x27cd33[_0x27cd33['ERROR']=0x4]='ERROR',_0x27cd33[_0x27cd33['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x93a18,_0xc27407,..._0x3bbf14)=>{if(_0xc27407<_0x93a18['logLevel'])return;const _0x3aa63d=new Date()['toISOString'](),_0x16d8aa=Pc[_0xc27407];if(_0x16d8aa)console[_0x16d8aa]('['+_0x3aa63d+']\x20\x20'+_0x93a18['name']+':',..._0x3bbf14);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0xc27407+')');};class xi{constructor(_0x1ac9cd){this['name']=_0x1ac9cd,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x1c2712){if(!(_0x1c2712 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x1c2712+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x1c2712;}['setLogLevel'](_0x2e9e1d){this['_logLevel']=typeof _0x2e9e1d=='string'?kc[_0x2e9e1d]:_0x2e9e1d;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x539fdf){if(typeof _0x539fdf!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x539fdf;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x33c79d){this['_userLogHandler']=_0x33c79d;}['debug'](..._0x43359d){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x43359d),this['_logHandler'](this,T['DEBUG'],..._0x43359d);}['log'](..._0x21f584){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x21f584),this['_logHandler'](this,T['VERBOSE'],..._0x21f584);}['info'](..._0x3f2d7e){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3f2d7e),this['_logHandler'](this,T['INFO'],..._0x3f2d7e);}['warn'](..._0x1ed921){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1ed921),this['_logHandler'](this,T['WARN'],..._0x1ed921);}['error'](..._0x1d0c98){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1d0c98),this['_logHandler'](this,T['ERROR'],..._0x1d0c98);}}const Dc=(_0x39effc,_0x288adf)=>_0x288adf['some'](_0xed503d=>_0x39effc instanceof _0xed503d);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x2a2968){const _0x3fbd7b=new Promise((_0x363ab4,_0x1e33c1)=>{const _0x3596ec=()=>{_0x2a2968['removeEventListener']('success',_0x31a562),_0x2a2968['removeEventListener']('error',_0x4c7f4d);},_0x31a562=()=>{_0x363ab4(_e(_0x2a2968['result'])),_0x3596ec();},_0x4c7f4d=()=>{_0x1e33c1(_0x2a2968['error']),_0x3596ec();};_0x2a2968['addEventListener']('success',_0x31a562),_0x2a2968['addEventListener']('error',_0x4c7f4d);});return _0x3fbd7b['then'](_0x220fd3=>{_0x220fd3 instanceof IDBCursor&&Kr['set'](_0x220fd3,_0x2a2968);})['catch'](()=>{}),Fi['set'](_0x3fbd7b,_0x2a2968),_0x3fbd7b;}function Fc(_0x21ab26){if(ui['has'](_0x21ab26))return;const _0x16bf72=new Promise((_0x4d3eb2,_0x46838e)=>{const _0x5ca182=()=>{_0x21ab26['removeEventListener']('complete',_0x4f3aca),_0x21ab26['removeEventListener']('error',_0x15156e),_0x21ab26['removeEventListener']('abort',_0x15156e);},_0x4f3aca=()=>{_0x4d3eb2(),_0x5ca182();},_0x15156e=()=>{_0x46838e(_0x21ab26['error']||new DOMException('AbortError','AbortError')),_0x5ca182();};_0x21ab26['addEventListener']('complete',_0x4f3aca),_0x21ab26['addEventListener']('error',_0x15156e),_0x21ab26['addEventListener']('abort',_0x15156e);});ui['set'](_0x21ab26,_0x16bf72);}let di={'get'(_0x1c4096,_0x1a3829,_0x4d5422){if(_0x1c4096 instanceof IDBTransaction){if(_0x1a3829==='done')return ui['get'](_0x1c4096);if(_0x1a3829==='objectStoreNames')return _0x1c4096['objectStoreNames']||Yr['get'](_0x1c4096);if(_0x1a3829==='store')return _0x4d5422['objectStoreNames'][0x1]?void 0x0:_0x4d5422['objectStore'](_0x4d5422['objectStoreNames'][0x0]);}return _e(_0x1c4096[_0x1a3829]);},'set'(_0x5da735,_0x366808,_0x17bacf){return _0x5da735[_0x366808]=_0x17bacf,!0x0;},'has'(_0x74432e,_0x538b6c){return _0x74432e instanceof IDBTransaction&&(_0x538b6c==='done'||_0x538b6c==='store')?!0x0:_0x538b6c in _0x74432e;}};function Uc(_0x542d9c){di=_0x542d9c(di);}function Wc(_0x49304d){return _0x49304d===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x10eaea,..._0x2c3f52){const _0x2d5268=_0x49304d['call'](Xn(this),_0x10eaea,..._0x2c3f52);return Yr['set'](_0x2d5268,_0x10eaea['sort']?_0x10eaea['sort']():[_0x10eaea]),_e(_0x2d5268);}:Lc()['includes'](_0x49304d)?function(..._0x12cfb7){return _0x49304d['apply'](Xn(this),_0x12cfb7),_e(Kr['get'](this));}:function(..._0x3a789f){return _e(_0x49304d['apply'](Xn(this),_0x3a789f));};}function Bc(_0x256454){return typeof _0x256454=='function'?Wc(_0x256454):(_0x256454 instanceof IDBTransaction&&Fc(_0x256454),Dc(_0x256454,Mc())?new Proxy(_0x256454,di):_0x256454);}function _e(_0x32b29a){if(_0x32b29a instanceof IDBRequest)return xc(_0x32b29a);if(Jn['has'](_0x32b29a))return Jn['get'](_0x32b29a);const _0x3aaf85=Bc(_0x32b29a);return _0x3aaf85!==_0x32b29a&&(Jn['set'](_0x32b29a,_0x3aaf85),Fi['set'](_0x3aaf85,_0x32b29a)),_0x3aaf85;}const Xn=_0x482846=>Fi['get'](_0x482846);function Vc(_0x21a962,_0x811d72,{blocked:_0x3d596f,upgrade:_0x2f19dc,blocking:_0x24ea95,terminated:_0x4b9248}={}){const _0xb7b051=indexedDB['open'](_0x21a962,_0x811d72),_0x3b3a33=_e(_0xb7b051);return _0x2f19dc&&_0xb7b051['addEventListener']('upgradeneeded',_0x37f62f=>{_0x2f19dc(_e(_0xb7b051['result']),_0x37f62f['oldVersion'],_0x37f62f['newVersion'],_e(_0xb7b051['transaction']),_0x37f62f);}),_0x3d596f&&_0xb7b051['addEventListener']('blocked',_0x1cc910=>_0x3d596f(_0x1cc910['oldVersion'],_0x1cc910['newVersion'],_0x1cc910)),_0x3b3a33['then'](_0x4073fe=>{_0x4b9248&&_0x4073fe['addEventListener']('close',()=>_0x4b9248()),_0x24ea95&&_0x4073fe['addEventListener']('versionchange',_0x83702a=>_0x24ea95(_0x83702a['oldVersion'],_0x83702a['newVersion'],_0x83702a));})['catch'](()=>{}),_0x3b3a33;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x2680d6,_0x5b925e){if(!(_0x2680d6 instanceof IDBDatabase&&!(_0x5b925e in _0x2680d6)&&typeof _0x5b925e=='string'))return;if(Zn['get'](_0x5b925e))return Zn['get'](_0x5b925e);const _0x461db1=_0x5b925e['replace'](/FromIndex$/,''),_0x44b3fb=_0x5b925e!==_0x461db1,_0x2e11ac=$c['includes'](_0x461db1);if(!(_0x461db1 in(_0x44b3fb?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2e11ac||Hc['includes'](_0x461db1)))return;const _0x4f409b=async function(_0x23e1bc,..._0x358c2e){const _0x5be97d=this['transaction'](_0x23e1bc,_0x2e11ac?'readwrite':'readonly');let _0x2890a4=_0x5be97d['store'];return _0x44b3fb&&(_0x2890a4=_0x2890a4['index'](_0x358c2e['shift']())),(await Promise['all']([_0x2890a4[_0x461db1](..._0x358c2e),_0x2e11ac&&_0x5be97d['done']]))[0x0];};return Zn['set'](_0x5b925e,_0x4f409b),_0x4f409b;}Uc(_0x4e295b=>({..._0x4e295b,'get':(_0x3a1e70,_0x1c5cf4,_0x2cb4c7)=>Os(_0x3a1e70,_0x1c5cf4)||_0x4e295b['get'](_0x3a1e70,_0x1c5cf4,_0x2cb4c7),'has':(_0x55a0a6,_0x462919)=>!!Os(_0x55a0a6,_0x462919)||_0x4e295b['has'](_0x55a0a6,_0x462919)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x4386ec){this['container']=_0x4386ec;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x41b65=>{if(qc(_0x41b65)){const _0x3fd4ae=_0x41b65['getImmediate']();return _0x3fd4ae['library']+'/'+_0x3fd4ae['version'];}else return null;})['filter'](_0x55e945=>_0x55e945)['join']('\x20');}}function qc(_0x2c4787){const _0x2b648d=_0x2c4787['getComponent']();return(_0x2b648d==null?void 0x0:_0x2b648d['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x37d66b,_0x54f7b3){try{_0x37d66b['container']['addComponent'](_0x54f7b3);}catch(_0x2c503f){re['debug']('Component\x20'+_0x54f7b3['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x37d66b['name'],_0x2c503f);}}function et(_0x1dc4a5){const _0x3733bd=_0x1dc4a5['name'];if(gi['has'](_0x3733bd))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x3733bd+'.'),!0x1;gi['set'](_0x3733bd,_0x1dc4a5);for(const _0x42ac88 of Le['values']())Ms(_0x42ac88,_0x1dc4a5);for(const _0x1c175e of _i['values']())Ms(_0x1c175e,_0x1dc4a5);return!0x0;}function Ui(_0x12e9f7,_0x19b9af){const _0x1f1e02=_0x12e9f7['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1f1e02&&_0x1f1e02['triggerHeartbeat'](),_0x12e9f7['container']['getProvider'](_0x19b9af);}function H(_0x1e82ea){return _0x1e82ea==null?!0x1:_0x1e82ea['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x5c4f94,_0x59c3b4,_0x2f4518){this['_isDeleted']=!0x1,this['_options']={..._0x5c4f94},this['_config']={..._0x59c3b4},this['_name']=_0x59c3b4['name'],this['_automaticDataCollectionEnabled']=_0x59c3b4['automaticDataCollectionEnabled'],this['_container']=_0x2f4518,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x25ea86){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x25ea86;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x9f304c){this['_isDeleted']=_0x9f304c;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x1b8827,_0x163ec7={}){let _0x22e1f7=_0x1b8827;typeof _0x163ec7!='object'&&(_0x163ec7={'name':_0x163ec7});const _0x7dff28={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x163ec7},_0x3f1933=_0x7dff28['name'];if(typeof _0x3f1933!='string'||!_0x3f1933)throw ge['create']('bad-app-name',{'appName':String(_0x3f1933)});if(_0x22e1f7||(_0x22e1f7=$r()),!_0x22e1f7)throw ge['create']('no-options');const _0x2b1ca2=Le['get'](_0x3f1933);if(_0x2b1ca2){if(De(_0x22e1f7,_0x2b1ca2['options'])&&De(_0x7dff28,_0x2b1ca2['config']))return _0x2b1ca2;throw ge['create']('duplicate-app',{'appName':_0x3f1933});}const _0x1ad824=new Ac(_0x3f1933);for(const _0x1ad8b1 of gi['values']())_0x1ad824['addComponent'](_0x1ad8b1);const _0xc7c352=new Il(_0x22e1f7,_0x7dff28,_0x1ad824);return Le['set'](_0x3f1933,_0xc7c352),_0xc7c352;}function Qr(_0x2c6713=pi){const _0x58d8bf=Le['get'](_0x2c6713);if(!_0x58d8bf&&_0x2c6713===pi&&$r())return wl();if(!_0x58d8bf)throw ge['create']('no-app',{'appName':_0x2c6713});return _0x58d8bf;}function l_(){return Array['from'](Le['values']());}async function h_(_0x1430ad){let _0x690bcf=!0x1;const _0x5ed4c6=_0x1430ad['name'];Le['has'](_0x5ed4c6)?(_0x690bcf=!0x0,Le['delete'](_0x5ed4c6)):_i['has'](_0x5ed4c6)&&_0x1430ad['decRefCount']()<=0x0&&(_i['delete'](_0x5ed4c6),_0x690bcf=!0x0),_0x690bcf&&(await Promise['all'](_0x1430ad['container']['getProviders']()['map'](_0x416369=>_0x416369['delete']())),_0x1430ad['isDeleted']=!0x0);}function me(_0x2f8011,_0x3d0635,_0xafe8b5){let _0x491a3a=vl[_0x2f8011]??_0x2f8011;_0xafe8b5&&(_0x491a3a+='-'+_0xafe8b5);const _0x31ef28=_0x491a3a['match'](/\s|\//),_0x4cb74f=_0x3d0635['match'](/\s|\//);if(_0x31ef28||_0x4cb74f){const _0x50b40b=['Unable\x20to\x20register\x20library\x20\x22'+_0x491a3a+'\x22\x20with\x20version\x20\x22'+_0x3d0635+'\x22:'];_0x31ef28&&_0x50b40b['push']('library\x20name\x20\x22'+_0x491a3a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x31ef28&&_0x4cb74f&&_0x50b40b['push']('and'),_0x4cb74f&&_0x50b40b['push']('version\x20name\x20\x22'+_0x3d0635+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x50b40b['join']('\x20'));return;}et(new Me(_0x491a3a+'-version',()=>({'library':_0x491a3a,'version':_0x3d0635}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x1a82f4,_0x1d5963)=>{switch(_0x1d5963){case 0x0:try{_0x1a82f4['createObjectStore'](Rt);}catch(_0x5466c0){console['warn'](_0x5466c0);}}}})['catch'](_0x4a69f4=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x4a69f4['message']});})),ei;}async function Sl(_0x1558da){try{const _0xe48716=(await Jr())['transaction'](Rt),_0x4fb876=await _0xe48716['objectStore'](Rt)['get'](Xr(_0x1558da));return await _0xe48716['done'],_0x4fb876;}catch(_0x2b4322){if(_0x2b4322 instanceof Se)re['warn'](_0x2b4322['message']);else{const _0x476b71=ge['create']('idb-get',{'originalErrorMessage':_0x2b4322==null?void 0x0:_0x2b4322['message']});re['warn'](_0x476b71['message']);}}}async function Ls(_0x781287,_0x1ddc6b){try{const _0x4b87ad=(await Jr())['transaction'](Rt,'readwrite');await _0x4b87ad['objectStore'](Rt)['put'](_0x1ddc6b,Xr(_0x781287)),await _0x4b87ad['done'];}catch(_0x885cd9){if(_0x885cd9 instanceof Se)re['warn'](_0x885cd9['message']);else{const _0x4aa128=ge['create']('idb-set',{'originalErrorMessage':_0x885cd9==null?void 0x0:_0x885cd9['message']});re['warn'](_0x4aa128['message']);}}}function Xr(_0xe39459){return _0xe39459['name']+'!'+_0xe39459['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x34b5da){this['container']=_0x34b5da,this['_heartbeatsCache']=null;const _0x1c4abe=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x1c4abe),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x5e3a5d=>(this['_heartbeatsCache']=_0x5e3a5d,_0x5e3a5d));}async['triggerHeartbeat'](){var _0xfc3614,_0xad04b9;try{const _0x1d75e2=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x56e1ef=xs();if(((_0xfc3614=this['_heartbeatsCache'])==null?void 0x0:_0xfc3614['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0xad04b9=this['_heartbeatsCache'])==null?void 0x0:_0xad04b9['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x56e1ef||this['_heartbeatsCache']['heartbeats']['some'](_0x546799=>_0x546799['date']===_0x56e1ef))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x56e1ef,'agent':_0x1d75e2}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x558671=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x558671,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0xd15d09){re['warn'](_0xd15d09);}}async['getHeartbeatsHeader'](){var _0x1a1961;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1a1961=this['_heartbeatsCache'])==null?void 0x0:_0x1a1961['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4f70c2=xs(),{heartbeatsToSend:_0x54f284,unsentEntries:_0x8310c1}=kl(this['_heartbeatsCache']['heartbeats']),_0x21944f=an(JSON['stringify']({'version':0x2,'heartbeats':_0x54f284}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4f70c2,_0x8310c1['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x8310c1,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x21944f;}catch(_0x2bb226){return re['warn'](_0x2bb226),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x3c163a,_0x1c545a=bl){const _0x4edd06=[];let _0x16512d=_0x3c163a['slice']();for(const _0x4432e8 of _0x3c163a){const _0x2444d7=_0x4edd06['find'](_0x121ec3=>_0x121ec3['agent']===_0x4432e8['agent']);if(_0x2444d7){if(_0x2444d7['dates']['push'](_0x4432e8['date']),Fs(_0x4edd06)>_0x1c545a){_0x2444d7['dates']['pop']();break;}}else{if(_0x4edd06['push']({'agent':_0x4432e8['agent'],'dates':[_0x4432e8['date']]}),Fs(_0x4edd06)>_0x1c545a){_0x4edd06['pop']();break;}}_0x16512d=_0x16512d['slice'](0x1);}return{'heartbeatsToSend':_0x4edd06,'unsentEntries':_0x16512d};}class Nl{constructor(_0x4046fe){this['app']=_0x4046fe,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4d347d=await Sl(this['app']);return _0x4d347d!=null&&_0x4d347d['heartbeats']?_0x4d347d:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x54a67c){if(await this['_canUseIndexedDBPromise']){const _0x4e26bd=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x54a67c['lastSentHeartbeatDate']??_0x4e26bd['lastSentHeartbeatDate'],'heartbeats':_0x54a67c['heartbeats']});}else return;}async['add'](_0x2bb609){if(await this['_canUseIndexedDBPromise']){const _0x4d2b66=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x2bb609['lastSentHeartbeatDate']??_0x4d2b66['lastSentHeartbeatDate'],'heartbeats':[..._0x4d2b66['heartbeats'],..._0x2bb609['heartbeats']]});}else return;}}function Fs(_0x3e0535){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x3e0535}))['length'];}function Pl(_0x454b14){if(_0x454b14['length']===0x0)return-0x1;let _0xd4aa48=0x0,_0x22fca3=_0x454b14[0x0]['date'];for(let _0xe9df6=0x1;_0xe9df6<_0x454b14['length'];_0xe9df6++)_0x454b14[_0xe9df6]['date']<_0x22fca3&&(_0x22fca3=_0x454b14[_0xe9df6]['date'],_0xd4aa48=_0xe9df6);return _0xd4aa48;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x388bf9){et(new Me('platform-logger',_0x3b9dac=>new Gc(_0x3b9dac),'PRIVATE')),et(new Me('heartbeat',_0x497887=>new Al(_0x497887),'PRIVATE')),me(fi,Ds,_0x388bf9),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x32cd58){Zr=_0x32cd58;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x317a6a){this['domStorage_']=_0x317a6a,this['prefix_']='firebase:';}['set'](_0x1db1ed,_0x24ef97){_0x24ef97==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1db1ed)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1db1ed),O(_0x24ef97));}['get'](_0x5ac27f){const _0x580fbe=this['domStorage_']['getItem'](this['prefixedName_'](_0x5ac27f));return _0x580fbe==null?null:bt(_0x580fbe);}['remove'](_0xb1f5f7){this['domStorage_']['removeItem'](this['prefixedName_'](_0xb1f5f7));}['prefixedName_'](_0x580879){return this['prefix_']+_0x580879;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2a0d08,_0x41a5d1){_0x41a5d1==null?delete this['cache_'][_0x2a0d08]:this['cache_'][_0x2a0d08]=_0x41a5d1;}['get'](_0x14e032){return Y(this['cache_'],_0x14e032)?this['cache_'][_0x14e032]:null;}['remove'](_0x141b7c){delete this['cache_'][_0x141b7c];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x35fbbf){try{if(typeof window<'u'&&typeof window[_0x35fbbf]<'u'){const _0x258ac4=window[_0x35fbbf];return _0x258ac4['setItem']('firebase:sentinel','cache'),_0x258ac4['removeItem']('firebase:sentinel'),new xl(_0x258ac4);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x1e7fd3=0x1;return function(){return _0x1e7fd3++;};}()),no=function(_0x7c27db){const _0x586c23=Tc(_0x7c27db),_0x5cc5df=new Ec();_0x5cc5df['update'](_0x586c23);const _0x3cb359=_0x5cc5df['digest']();return Di['encodeByteArray'](_0x3cb359);},Bt=function(..._0x50f149){let _0x4c9b07='';for(let _0x5370bb=0x0;_0x5370bb<_0x50f149['length'];_0x5370bb++){const _0x5b4624=_0x50f149[_0x5370bb];Array['isArray'](_0x5b4624)||_0x5b4624&&typeof _0x5b4624=='object'&&typeof _0x5b4624['length']=='number'?_0x4c9b07+=Bt['apply'](null,_0x5b4624):typeof _0x5b4624=='object'?_0x4c9b07+=O(_0x5b4624):_0x4c9b07+=_0x5b4624,_0x4c9b07+='\x20';}return _0x4c9b07;};let Et=null,Vs=!0x0;const Wl=function(_0x3411fa,_0xf26131){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x19b4ba){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x3c2ef6=Bt['apply'](null,_0x19b4ba);Et(_0x3c2ef6);}},Vt=function(_0x236c8){return function(..._0x262f5e){L(_0x236c8,..._0x262f5e);};},mi=function(..._0x396754){const _0xbdb846='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x396754);Qe['error'](_0xbdb846);},oe=function(..._0x5a672b){const _0x5abc7e='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x5a672b);throw Qe['error'](_0x5abc7e),new Error(_0x5abc7e);},U=function(..._0xaf2bd9){const _0x17a601='FIREBASE\x20WARNING:\x20'+Bt(..._0xaf2bd9);Qe['warn'](_0x17a601);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x19a53f){return typeof _0x19a53f=='number'&&(_0x19a53f!==_0x19a53f||_0x19a53f===Number['POSITIVE_INFINITY']||_0x19a53f===Number['NEGATIVE_INFINITY']);},Vl=function(_0x1ed8ae){if(document['readyState']==='complete')_0x1ed8ae();else{let _0x165aa7=!0x1;const _0xd3881d=function(){if(!document['body']){setTimeout(_0xd3881d,Math['floor'](0xa));return;}_0x165aa7||(_0x165aa7=!0x0,_0x1ed8ae());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0xd3881d,!0x1),window['addEventListener']('load',_0xd3881d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0xd3881d();}),window['attachEvent']('onload',_0xd3881d));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x4eaa85,_0xcfd155){if(_0x4eaa85===_0xcfd155)return 0x0;if(_0x4eaa85===xe||_0xcfd155===Ie)return-0x1;if(_0xcfd155===xe||_0x4eaa85===Ie)return 0x1;{const _0x459bce=Hs(_0x4eaa85),_0x289266=Hs(_0xcfd155);return _0x459bce!==null?_0x289266!==null?_0x459bce-_0x289266===0x0?_0x4eaa85['length']-_0xcfd155['length']:_0x459bce-_0x289266:-0x1:_0x289266!==null?0x1:_0x4eaa85<_0xcfd155?-0x1:0x1;}},Hl=function(_0x212bee,_0x127384){return _0x212bee===_0x127384?0x0:_0x212bee<_0x127384?-0x1:0x1;},pt=function(_0x15c07e,_0x389256){if(_0x389256&&_0x15c07e in _0x389256)return _0x389256[_0x15c07e];throw new Error('Missing\x20required\x20key\x20('+_0x15c07e+')\x20in\x20object:\x20'+O(_0x389256));},Bi=function(_0x38aef6){if(typeof _0x38aef6!='object'||_0x38aef6===null)return O(_0x38aef6);const _0x1a9c1a=[];for(const _0x11009c in _0x38aef6)_0x1a9c1a['push'](_0x11009c);_0x1a9c1a['sort']();let _0x53fb4a='{';for(let _0x3abdf4=0x0;_0x3abdf4<_0x1a9c1a['length'];_0x3abdf4++)_0x3abdf4!==0x0&&(_0x53fb4a+=','),_0x53fb4a+=O(_0x1a9c1a[_0x3abdf4]),_0x53fb4a+=':',_0x53fb4a+=Bi(_0x38aef6[_0x1a9c1a[_0x3abdf4]]);return _0x53fb4a+='}',_0x53fb4a;},io=function(_0x229cb4,_0x4c44a9){const _0x4d58e8=_0x229cb4['length'];if(_0x4d58e8<=_0x4c44a9)return[_0x229cb4];const _0x2fe89f=[];for(let _0x57a956=0x0;_0x57a956<_0x4d58e8;_0x57a956+=_0x4c44a9)_0x57a956+_0x4c44a9>_0x4d58e8?_0x2fe89f['push'](_0x229cb4['substring'](_0x57a956,_0x4d58e8)):_0x2fe89f['push'](_0x229cb4['substring'](_0x57a956,_0x57a956+_0x4c44a9));return _0x2fe89f;};function x(_0x1cb4b0,_0x3168cd){for(const _0x5be87c in _0x1cb4b0)_0x1cb4b0['hasOwnProperty'](_0x5be87c)&&_0x3168cd(_0x5be87c,_0x1cb4b0[_0x5be87c]);}const so=function(_0x5335f8){f(!Wi(_0x5335f8),'Invalid\x20JSON\x20number');const _0x272081=0xb,_0xedda6=0x34,_0x14f788=(0x1<<_0x272081-0x1)-0x1;let _0x9409ee,_0x5cfc02,_0x50f8c9,_0x470bf8,_0x579d7a;_0x5335f8===0x0?(_0x5cfc02=0x0,_0x50f8c9=0x0,_0x9409ee=0x1/_0x5335f8===-0x1/0x0?0x1:0x0):(_0x9409ee=_0x5335f8<0x0,_0x5335f8=Math['abs'](_0x5335f8),_0x5335f8>=Math['pow'](0x2,0x1-_0x14f788)?(_0x470bf8=Math['min'](Math['floor'](Math['log'](_0x5335f8)/Math['LN2']),_0x14f788),_0x5cfc02=_0x470bf8+_0x14f788,_0x50f8c9=Math['round'](_0x5335f8*Math['pow'](0x2,_0xedda6-_0x470bf8)-Math['pow'](0x2,_0xedda6))):(_0x5cfc02=0x0,_0x50f8c9=Math['round'](_0x5335f8/Math['pow'](0x2,0x1-_0x14f788-_0xedda6))));const _0x310081=[];for(_0x579d7a=_0xedda6;_0x579d7a;_0x579d7a-=0x1)_0x310081['push'](_0x50f8c9%0x2?0x1:0x0),_0x50f8c9=Math['floor'](_0x50f8c9/0x2);for(_0x579d7a=_0x272081;_0x579d7a;_0x579d7a-=0x1)_0x310081['push'](_0x5cfc02%0x2?0x1:0x0),_0x5cfc02=Math['floor'](_0x5cfc02/0x2);_0x310081['push'](_0x9409ee?0x1:0x0),_0x310081['reverse']();const _0x4a4cc1=_0x310081['join']('');let _0x29ac74='';for(_0x579d7a=0x0;_0x579d7a<0x40;_0x579d7a+=0x8){let _0x1e3a39=parseInt(_0x4a4cc1['substr'](_0x579d7a,0x8),0x2)['toString'](0x10);_0x1e3a39['length']===0x1&&(_0x1e3a39='0'+_0x1e3a39),_0x29ac74=_0x29ac74+_0x1e3a39;}return _0x29ac74['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x344458,_0x1d2584){let _0x23811d='Unknown\x20Error';_0x344458==='too_big'?_0x23811d='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x344458==='permission_denied'?_0x23811d='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x344458==='unavailable'&&(_0x23811d='The\x20service\x20is\x20unavailable');const _0x14887e=new Error(_0x344458+'\x20at\x20'+_0x1d2584['_path']['toString']()+':\x20'+_0x23811d);return _0x14887e['code']=_0x344458['toUpperCase'](),_0x14887e;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x319983){if(zl['test'](_0x319983)){const _0x533089=Number(_0x319983);if(_0x533089>=jl&&_0x533089<=Kl)return _0x533089;}return null;},lt=function(_0x2235ec){try{_0x2235ec();}catch(_0x156101){setTimeout(()=>{const _0x354e7b=_0x156101['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x354e7b),_0x156101;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x4ab58a,_0x54c84d){const _0x2f5f4c=setTimeout(_0x4ab58a,_0x54c84d);return typeof _0x2f5f4c=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2f5f4c):typeof _0x2f5f4c=='object'&&_0x2f5f4c['unref']&&_0x2f5f4c['unref'](),_0x2f5f4c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x3a2fe0,_0xf86c0c){this['appCheckProvider']=_0xf86c0c,this['appName']=_0x3a2fe0['name'],H(_0x3a2fe0)&&_0x3a2fe0['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3a2fe0['settings']['appCheckToken']),this['appCheck']=_0xf86c0c==null?void 0x0:_0xf86c0c['getImmediate']({'optional':!0x0}),this['appCheck']||_0xf86c0c==null||_0xf86c0c['get']()['then'](_0x56cd56=>this['appCheck']=_0x56cd56);}['getToken'](_0x27c4cf){if(this['serverAppAppCheckToken']){if(_0x27c4cf)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x27c4cf):new Promise((_0x12166c,_0x3d9104)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x27c4cf)['then'](_0x12166c,_0x3d9104):_0x12166c(null);},0x0);});}['addTokenChangeListener'](_0x34994e){var _0x34a94f;(_0x34a94f=this['appCheckProvider'])==null||_0x34a94f['get']()['then'](_0x238c7f=>_0x238c7f['addTokenListener'](_0x34994e));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x5035f2,_0x184835,_0x31d008){this['appName_']=_0x5035f2,this['firebaseOptions_']=_0x184835,this['authProvider_']=_0x31d008,this['auth_']=null,this['auth_']=_0x31d008['getImmediate']({'optional':!0x0}),this['auth_']||_0x31d008['onInit'](_0xad8ad7=>this['auth_']=_0xad8ad7);}['getToken'](_0x4fd92a){return this['auth_']?this['auth_']['getToken'](_0x4fd92a)['catch'](_0x1da85f=>_0x1da85f&&_0x1da85f['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1da85f)):new Promise((_0xd621f8,_0x16827c)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4fd92a)['then'](_0xd621f8,_0x16827c):_0xd621f8(null);},0x0);});}['addTokenChangeListener'](_0x5a16fc){this['auth_']?this['auth_']['addAuthTokenListener'](_0x5a16fc):this['authProvider_']['get']()['then'](_0x4d0da8=>_0x4d0da8['addAuthTokenListener'](_0x5a16fc));}['removeTokenChangeListener'](_0x50b1f2){this['authProvider_']['get']()['then'](_0x2c373e=>_0x2c373e['removeAuthTokenListener'](_0x50b1f2));}['notifyForInvalidToken'](){let _0x15fee6='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x15fee6+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x15fee6+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x15fee6+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x15fee6);}}class tn{constructor(_0x4f3c67){this['accessToken']=_0x4f3c67;}['getToken'](_0x5b003d){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4bb4e4){_0x4bb4e4(this['accessToken']);}['removeTokenChangeListener'](_0x455416){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x191150,_0x1d875a,_0xaf821f,_0x31fae3,_0x2f1dab=!0x1,_0x2ec672='',_0x272322=!0x1,_0x24024a=!0x1,_0x538d79=null){this['secure']=_0x1d875a,this['namespace']=_0xaf821f,this['webSocketOnly']=_0x31fae3,this['nodeAdmin']=_0x2f1dab,this['persistenceKey']=_0x2ec672,this['includeNamespaceInQueryParams']=_0x272322,this['isUsingEmulator']=_0x24024a,this['emulatorOptions']=_0x538d79,this['_host']=_0x191150['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x191150)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x794c35){_0x794c35!==this['internalHost']&&(this['internalHost']=_0x794c35,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4ac62b=this['toURLString']();return this['persistenceKey']&&(_0x4ac62b+='<'+this['persistenceKey']+'>'),_0x4ac62b;}['toURLString'](){const _0x52c14b=this['secure']?'https://':'http://',_0x11c876=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x52c14b+this['host']+'/'+_0x11c876;}}function Xl(_0x29ec4b){return _0x29ec4b['host']!==_0x29ec4b['internalHost']||_0x29ec4b['isCustomHost']()||_0x29ec4b['includeNamespaceInQueryParams'];}function go(_0x17d5d9,_0x3ca6e0,_0x51f8e1){f(typeof _0x3ca6e0=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x51f8e1=='object','typeof\x20params\x20must\x20==\x20object');let _0x183aec;if(_0x3ca6e0===fo)_0x183aec=(_0x17d5d9['secure']?'wss://':'ws://')+_0x17d5d9['internalHost']+'/.ws?';else{if(_0x3ca6e0===po)_0x183aec=(_0x17d5d9['secure']?'https://':'http://')+_0x17d5d9['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3ca6e0);}Xl(_0x17d5d9)&&(_0x51f8e1['ns']=_0x17d5d9['namespace']);const _0x23db31=[];return x(_0x51f8e1,(_0x5e9bc8,_0x15f9dc)=>{_0x23db31['push'](_0x5e9bc8+'='+_0x15f9dc);}),_0x183aec+_0x23db31['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x4c1bc2,_0x20aa3a=0x1){Y(this['counters_'],_0x4c1bc2)||(this['counters_'][_0x4c1bc2]=0x0),this['counters_'][_0x4c1bc2]+=_0x20aa3a;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x5b89db){const _0x50a98a=_0x5b89db['toString']();return ti[_0x50a98a]||(ti[_0x50a98a]=new Zl()),ti[_0x50a98a];}function eh(_0x29831f,_0x127a49){const _0x44a17c=_0x29831f['toString']();return ni[_0x44a17c]||(ni[_0x44a17c]=_0x127a49()),ni[_0x44a17c];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x2a642a){this['onMessage_']=_0x2a642a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x55eabe,_0x5369c9){this['closeAfterResponse']=_0x55eabe,this['onClose']=_0x5369c9,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3118af,_0x290af7){for(this['pendingResponses'][_0x3118af]=_0x290af7;this['pendingResponses'][this['currentResponseNum']];){const _0x2dbd0e=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x10959a=0x0;_0x10959a<_0x2dbd0e['length'];++_0x10959a)_0x2dbd0e[_0x10959a]&&lt(()=>{this['onMessage_'](_0x2dbd0e[_0x10959a]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x5eae5b,_0x209536,_0x42a4ec,_0x223332,_0x110db4,_0xcb5e0b,_0x558758){this['connId']=_0x5eae5b,this['repoInfo']=_0x209536,this['applicationId']=_0x42a4ec,this['appCheckToken']=_0x223332,this['authToken']=_0x110db4,this['transportSessionId']=_0xcb5e0b,this['lastSessionId']=_0x558758,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x5eae5b),this['stats_']=Hi(_0x209536),this['urlFn']=_0x44d64f=>(this['appCheckToken']&&(_0x44d64f[yi]=this['appCheckToken']),go(_0x209536,po,_0x44d64f));}['open'](_0xa44971,_0x1fc661){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1fc661,this['myPacketOrderer']=new th(_0xa44971),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x10dd28)=>{const [_0x4cd534,_0x2d9175,_0x1e64ae,_0x3ff1e2,_0x5e4d2b]=_0x10dd28;if(this['incrementIncomingBytes_'](_0x10dd28),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4cd534===$s)this['id']=_0x2d9175,this['password']=_0x1e64ae;else{if(_0x4cd534===nh)_0x2d9175?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2d9175,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4cd534);}}},(..._0x3007fe)=>{const [_0x1d6a33,_0x1130d1]=_0x3007fe;this['incrementIncomingBytes_'](_0x3007fe),this['myPacketOrderer']['handleResponse'](_0x1d6a33,_0x1130d1);},()=>{this['onClosed_']();},this['urlFn']);const _0x54fbf5={};_0x54fbf5[$s]='t',_0x54fbf5[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x54fbf5[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x54fbf5[ro]=Vi,this['transportSessionId']&&(_0x54fbf5[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x54fbf5[ho]=this['lastSessionId']),this['applicationId']&&(_0x54fbf5[uo]=this['applicationId']),this['appCheckToken']&&(_0x54fbf5[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x54fbf5[ao]=co);const _0x48e84d=this['urlFn'](_0x54fbf5);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x48e84d),this['scriptTagHolder']['addTag'](_0x48e84d,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5ea84e){const _0x2b716c=O(_0x5ea84e);this['bytesSent']+=_0x2b716c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2b716c['length']);const _0x19816e=Br(_0x2b716c),_0x58e498=io(_0x19816e,hh);for(let _0x2d55de=0x0;_0x2d55de<_0x58e498['length'];_0x2d55de++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x58e498['length'],_0x58e498[_0x2d55de]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x43df69,_0x3f16ae){this['myDisconnFrame']=document['createElement']('iframe');const _0x33bc51={};_0x33bc51[lh]='t',_0x33bc51[mo]=_0x43df69,_0x33bc51[yo]=_0x3f16ae,this['myDisconnFrame']['src']=this['urlFn'](_0x33bc51),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x261b45){const _0x274872=O(_0x261b45)['length'];this['bytesReceived']+=_0x274872,this['stats_']['incrementCounter']('bytes_received',_0x274872);}}class $i{constructor(_0x246ab4,_0x4a60c2,_0x5b1c44,_0x307b39){this['onDisconnect']=_0x5b1c44,this['urlFn']=_0x307b39,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x246ab4,window[sh+this['uniqueCallbackIdentifier']]=_0x4a60c2,this['myIFrame']=$i['createIFrame_']();let _0x19575c='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x19575c='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x546465='<html><body>'+_0x19575c+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x546465),this['myIFrame']['doc']['close']();}catch(_0x3c8bc9){L('frame\x20writing\x20exception'),_0x3c8bc9['stack']&&L(_0x3c8bc9['stack']),L(_0x3c8bc9);}}}static['createIFrame_'](){const _0x109fd7=document['createElement']('iframe');if(_0x109fd7['style']['display']='none',document['body']){document['body']['appendChild'](_0x109fd7);try{_0x109fd7['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2a6021=document['domain'];_0x109fd7['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2a6021+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x109fd7['contentDocument']?_0x109fd7['doc']=_0x109fd7['contentDocument']:_0x109fd7['contentWindow']?_0x109fd7['doc']=_0x109fd7['contentWindow']['document']:_0x109fd7['document']&&(_0x109fd7['doc']=_0x109fd7['document']),_0x109fd7;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x17bf29=this['onDisconnect'];_0x17bf29&&(this['onDisconnect']=null,_0x17bf29());}['startLongPoll'](_0x136edc,_0x5e809a){for(this['myID']=_0x136edc,this['myPW']=_0x5e809a,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2b77b0={};_0x2b77b0[mo]=this['myID'],_0x2b77b0[yo]=this['myPW'],_0x2b77b0[vo]=this['currentSerial'];let _0x51a781=this['urlFn'](_0x2b77b0),_0x16043b='',_0x5a17a4=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x16043b['length']<=Eo;){const _0xa4506=this['pendingSegs']['shift']();_0x16043b=_0x16043b+'&'+oh+_0x5a17a4+'='+_0xa4506['seg']+'&'+ah+_0x5a17a4+'='+_0xa4506['ts']+'&'+ch+_0x5a17a4+'='+_0xa4506['d'],_0x5a17a4++;}return _0x51a781=_0x51a781+_0x16043b,this['addLongPollTag_'](_0x51a781,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x156e24,_0x315d02,_0x120f6d){this['pendingSegs']['push']({'seg':_0x156e24,'ts':_0x315d02,'d':_0x120f6d}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x92edf9,_0x55a53e){this['outstandingRequests']['add'](_0x55a53e);const _0x596435=()=>{this['outstandingRequests']['delete'](_0x55a53e),this['newRequest_']();},_0x1d47b1=setTimeout(_0x596435,Math['floor'](uh)),_0x281092=()=>{clearTimeout(_0x1d47b1),_0x596435();};this['addTag'](_0x92edf9,_0x281092);}['addTag'](_0x7af22f,_0x2ecb66){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3fb816=this['myIFrame']['doc']['createElement']('script');_0x3fb816['type']='text/javascript',_0x3fb816['async']=!0x0,_0x3fb816['src']=_0x7af22f,_0x3fb816['onload']=_0x3fb816['onreadystatechange']=function(){const _0x4f678d=_0x3fb816['readyState'];(!_0x4f678d||_0x4f678d==='loaded'||_0x4f678d==='complete')&&(_0x3fb816['onload']=_0x3fb816['onreadystatechange']=null,_0x3fb816['parentNode']&&_0x3fb816['parentNode']['removeChild'](_0x3fb816),_0x2ecb66());},_0x3fb816['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x7af22f),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3fb816);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x558d58,_0x39db72,_0x24d1cd,_0x52db7b,_0x16f55b,_0x527db1,_0x5a969e){this['connId']=_0x558d58,this['applicationId']=_0x24d1cd,this['appCheckToken']=_0x52db7b,this['authToken']=_0x16f55b,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x39db72),this['connURL']=G['connectionURL_'](_0x39db72,_0x527db1,_0x5a969e,_0x52db7b,_0x24d1cd),this['nodeAdmin']=_0x39db72['nodeAdmin'];}static['connectionURL_'](_0x3951c4,_0x1dc72c,_0x4e201d,_0x2690a7,_0x42350d){const _0x10073d={};return _0x10073d[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x10073d[ao]=co),_0x1dc72c&&(_0x10073d[oo]=_0x1dc72c),_0x4e201d&&(_0x10073d[ho]=_0x4e201d),_0x2690a7&&(_0x10073d[yi]=_0x2690a7),_0x42350d&&(_0x10073d[uo]=_0x42350d),go(_0x3951c4,fo,_0x10073d);}['open'](_0x448118,_0x1e8af2){this['onDisconnect']=_0x1e8af2,this['onMessage']=_0x448118,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x3afa20;dc(),this['mySock']=new hn(this['connURL'],[],_0x3afa20);}catch(_0x218c0e){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x492edb=_0x218c0e['message']||_0x218c0e['data'];_0x492edb&&this['log_'](_0x492edb),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1b242d=>{this['handleIncomingFrame'](_0x1b242d);},this['mySock']['onerror']=_0x1e90bf=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2716b1=_0x1e90bf['message']||_0x1e90bf['data'];_0x2716b1&&this['log_'](_0x2716b1),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x4331ca=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xec7fd0=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xd560d5=navigator['userAgent']['match'](_0xec7fd0);_0xd560d5&&_0xd560d5['length']>0x1&&parseFloat(_0xd560d5[0x1])<4.4&&(_0x4331ca=!0x0);}return!_0x4331ca&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0xf9f429){if(this['frames']['push'](_0xf9f429),this['frames']['length']===this['totalFrames']){const _0xd03a57=this['frames']['join']('');this['frames']=null;const _0x4fb9f5=bt(_0xd03a57);this['onMessage'](_0x4fb9f5);}}['handleNewFrameCount_'](_0x67757a){this['totalFrames']=_0x67757a,this['frames']=[];}['extractFrameCount_'](_0x4a124e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4a124e['length']<=0x6){const _0x2747fc=Number(_0x4a124e);if(!isNaN(_0x2747fc))return this['handleNewFrameCount_'](_0x2747fc),null;}return this['handleNewFrameCount_'](0x1),_0x4a124e;}['handleIncomingFrame'](_0x3be128){if(this['mySock']===null)return;const _0x479002=_0x3be128['data'];if(this['bytesReceived']+=_0x479002['length'],this['stats_']['incrementCounter']('bytes_received',_0x479002['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x479002);else{const _0x2c29da=this['extractFrameCount_'](_0x479002);_0x2c29da!==null&&this['appendFrame_'](_0x2c29da);}}['send'](_0x287197){this['resetKeepAlive']();const _0x3c8f6e=O(_0x287197);this['bytesSent']+=_0x3c8f6e['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3c8f6e['length']);const _0x3b236b=io(_0x3c8f6e,fh);_0x3b236b['length']>0x1&&this['sendString_'](String(_0x3b236b['length']));for(let _0x1bc23b=0x0;_0x1bc23b<_0x3b236b['length'];_0x1bc23b++)this['sendString_'](_0x3b236b[_0x1bc23b]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x3c0624){try{this['mySock']['send'](_0x3c0624);}catch(_0x36e3f5){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x36e3f5['message']||_0x36e3f5['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x55559a){this['initTransports_'](_0x55559a);}['initTransports_'](_0x43101f){const _0x377f44=G&&G['isAvailable']();let _0x43f36e=_0x377f44&&!G['previouslyFailed']();if(_0x43101f['webSocketOnly']&&(_0x377f44||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x43f36e=!0x0),_0x43f36e)this['transports_']=[G];else{const _0x5a17ff=this['transports_']=[];for(const _0x1c5dae of At['ALL_TRANSPORTS'])_0x1c5dae&&_0x1c5dae['isAvailable']()&&_0x5a17ff['push'](_0x1c5dae);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x5e799c,_0x4a2e88,_0x1093f7,_0xb7bb9f,_0x19f1ab,_0x5f4f26,_0x469fd7,_0x4552f2,_0x753639,_0xd411a6){this['id']=_0x5e799c,this['repoInfo_']=_0x4a2e88,this['applicationId_']=_0x1093f7,this['appCheckToken_']=_0xb7bb9f,this['authToken_']=_0x19f1ab,this['onMessage_']=_0x5f4f26,this['onReady_']=_0x469fd7,this['onDisconnect_']=_0x4552f2,this['onKill_']=_0x753639,this['lastSessionId']=_0xd411a6,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x4a2e88),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x33cb85=this['transportManager_']['initialTransport']();this['conn_']=new _0x33cb85(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x33cb85['responsesRequiredToBeHealthy']||0x0;const _0x3e57df=this['connReceiver_'](this['conn_']),_0x18849b=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3e57df,_0x18849b);},Math['floor'](0x0));const _0x315322=_0x33cb85['healthyTimeout']||0x0;_0x315322>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x315322)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x141162){return _0x20d5c1=>{_0x141162===this['conn_']?this['onConnectionLost_'](_0x20d5c1):_0x141162===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x59d22f){return _0x2cbfac=>{this['state_']!==0x2&&(_0x59d22f===this['rx_']?this['onPrimaryMessageReceived_'](_0x2cbfac):_0x59d22f===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2cbfac):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x334c3b){const _0x13b26a={'t':'d','d':_0x334c3b};this['sendData_'](_0x13b26a);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x147405){if(ii in _0x147405){const _0x45f898=_0x147405[ii];_0x45f898===js?this['upgradeIfSecondaryHealthy_']():_0x45f898===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x45f898===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x88023f){const _0x24caa9=pt('t',_0x88023f),_0x160787=pt('d',_0x88023f);if(_0x24caa9==='c')this['onSecondaryControl_'](_0x160787);else{if(_0x24caa9==='d')this['pendingDataMessages']['push'](_0x160787);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x24caa9);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3f1dab){const _0x3f1519=pt('t',_0x3f1dab),_0xc6cbb=pt('d',_0x3f1dab);_0x3f1519==='c'?this['onControl_'](_0xc6cbb):_0x3f1519==='d'&&this['onDataMessage_'](_0xc6cbb);}['onDataMessage_'](_0x4ad6a5){this['onPrimaryResponse_'](),this['onMessage_'](_0x4ad6a5);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3f4cad){const _0x4fcd6d=pt(ii,_0x3f4cad);if(Gs in _0x3f4cad){const _0x5056f2=_0x3f4cad[Gs];if(_0x4fcd6d===Ih){const _0x37f8a0={..._0x5056f2};this['repoInfo_']['isUsingEmulator']&&(_0x37f8a0['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x37f8a0);}else{if(_0x4fcd6d===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4c1f6d=0x0;_0x4c1f6d<this['pendingDataMessages']['length'];++_0x4c1f6d)this['onDataMessage_'](this['pendingDataMessages'][_0x4c1f6d]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4fcd6d===vh?this['onConnectionShutdown_'](_0x5056f2):_0x4fcd6d===qs?this['onReset_'](_0x5056f2):_0x4fcd6d===Eh?mi('Server\x20Error:\x20'+_0x5056f2):_0x4fcd6d===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x4fcd6d);}}}['onHandshake_'](_0x17c4fd){const _0x3dc290=_0x17c4fd['ts'],_0x486fbe=_0x17c4fd['v'],_0x56bd36=_0x17c4fd['h'];this['sessionId']=_0x17c4fd['s'],this['repoInfo_']['host']=_0x56bd36,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3dc290),Vi!==_0x486fbe&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x200745=this['transportManager_']['upgradeTransport']();_0x200745&&this['startUpgrade_'](_0x200745);}['startUpgrade_'](_0x4db94b){this['secondaryConn_']=new _0x4db94b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4db94b['responsesRequiredToBeHealthy']||0x0;const _0x9e8f02=this['connReceiver_'](this['secondaryConn_']),_0x1a65e7=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x9e8f02,_0x1a65e7),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x2241c7){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2241c7),this['repoInfo_']['host']=_0x2241c7,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x21740d,_0x3646b7){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x21740d,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3646b7,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x583f01=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x583f01||this['rx_']===_0x583f01)&&this['close']();}['onConnectionLost_'](_0x2c7662){this['conn_']=null,!_0x2c7662&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x1fa0bb){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x1fa0bb),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x57c06e){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x57c06e);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x1b396b,_0x2feba1,_0x11a24a,_0x33f95c){}['merge'](_0x5baac5,_0x35df24,_0x15ecb6,_0x4e2e26){}['refreshAuthToken'](_0x4c277c){}['refreshAppCheckToken'](_0x1693e3){}['onDisconnectPut'](_0x3f9fb2,_0x260b78,_0x5a3aef){}['onDisconnectMerge'](_0x1a7143,_0x36ceb6,_0x744ec4){}['onDisconnectCancel'](_0x3705fe,_0x47e079){}['reportStats'](_0x46480f){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0xe03b9a){this['allowedEvents_']=_0xe03b9a,this['listeners_']={},f(Array['isArray'](_0xe03b9a)&&_0xe03b9a['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5e480f,..._0x4670b7){if(Array['isArray'](this['listeners_'][_0x5e480f])){const _0x4eb286=[...this['listeners_'][_0x5e480f]];for(let _0x359d3e=0x0;_0x359d3e<_0x4eb286['length'];_0x359d3e++)_0x4eb286[_0x359d3e]['callback']['apply'](_0x4eb286[_0x359d3e]['context'],_0x4670b7);}}['on'](_0x13900,_0x4d75af,_0x548e61){this['validateEventType_'](_0x13900),this['listeners_'][_0x13900]=this['listeners_'][_0x13900]||[],this['listeners_'][_0x13900]['push']({'callback':_0x4d75af,'context':_0x548e61});const _0x494349=this['getInitialEvent'](_0x13900);_0x494349&&_0x4d75af['apply'](_0x548e61,_0x494349);}['off'](_0x4afba7,_0x4b29ed,_0x2a08e2){this['validateEventType_'](_0x4afba7);const _0x59ae80=this['listeners_'][_0x4afba7]||[];for(let _0x41e104=0x0;_0x41e104<_0x59ae80['length'];_0x41e104++)if(_0x59ae80[_0x41e104]['callback']===_0x4b29ed&&(!_0x2a08e2||_0x2a08e2===_0x59ae80[_0x41e104]['context'])){_0x59ae80['splice'](_0x41e104,0x1);return;}}['validateEventType_'](_0x340e14){f(this['allowedEvents_']['find'](_0x5a4349=>_0x5a4349===_0x340e14),'Unknown\x20event:\x20'+_0x340e14);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x63fd56){return f(_0x63fd56==='online','Unknown\x20event\x20type:\x20'+_0x63fd56),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x1c267d,_0x508b28){if(_0x508b28===void 0x0){this['pieces_']=_0x1c267d['split']('/');let _0x3e228c=0x0;for(let _0x52e21e=0x0;_0x52e21e<this['pieces_']['length'];_0x52e21e++)this['pieces_'][_0x52e21e]['length']>0x0&&(this['pieces_'][_0x3e228c]=this['pieces_'][_0x52e21e],_0x3e228c++);this['pieces_']['length']=_0x3e228c,this['pieceNum_']=0x0;}else this['pieces_']=_0x1c267d,this['pieceNum_']=_0x508b28;}['toString'](){let _0x354f77='';for(let _0x21b062=this['pieceNum_'];_0x21b062<this['pieces_']['length'];_0x21b062++)this['pieces_'][_0x21b062]!==''&&(_0x354f77+='/'+this['pieces_'][_0x21b062]);return _0x354f77||'/';}}function w(){return new C('');}function y(_0xdd785a){return _0xdd785a['pieceNum_']>=_0xdd785a['pieces_']['length']?null:_0xdd785a['pieces_'][_0xdd785a['pieceNum_']];}function we(_0x5cdd1b){return _0x5cdd1b['pieces_']['length']-_0x5cdd1b['pieceNum_'];}function b(_0x240364){let _0x39809f=_0x240364['pieceNum_'];return _0x39809f<_0x240364['pieces_']['length']&&_0x39809f++,new C(_0x240364['pieces_'],_0x39809f);}function Gi(_0x2cf1a1){return _0x2cf1a1['pieceNum_']<_0x2cf1a1['pieces_']['length']?_0x2cf1a1['pieces_'][_0x2cf1a1['pieces_']['length']-0x1]:null;}function Ch(_0x1b930b){let _0x5db771='';for(let _0x4c0ff8=_0x1b930b['pieceNum_'];_0x4c0ff8<_0x1b930b['pieces_']['length'];_0x4c0ff8++)_0x1b930b['pieces_'][_0x4c0ff8]!==''&&(_0x5db771+='/'+encodeURIComponent(String(_0x1b930b['pieces_'][_0x4c0ff8])));return _0x5db771||'/';}function kt(_0x18b702,_0x5bf826=0x0){return _0x18b702['pieces_']['slice'](_0x18b702['pieceNum_']+_0x5bf826);}function To(_0x5f373d){if(_0x5f373d['pieceNum_']>=_0x5f373d['pieces_']['length'])return null;const _0x9c5d6d=[];for(let _0xe20da9=_0x5f373d['pieceNum_'];_0xe20da9<_0x5f373d['pieces_']['length']-0x1;_0xe20da9++)_0x9c5d6d['push'](_0x5f373d['pieces_'][_0xe20da9]);return new C(_0x9c5d6d,0x0);}function A(_0x4bf181,_0x22ce12){const _0x1b96dd=[];for(let _0x4dda0a=_0x4bf181['pieceNum_'];_0x4dda0a<_0x4bf181['pieces_']['length'];_0x4dda0a++)_0x1b96dd['push'](_0x4bf181['pieces_'][_0x4dda0a]);if(_0x22ce12 instanceof C){for(let _0x229fbf=_0x22ce12['pieceNum_'];_0x229fbf<_0x22ce12['pieces_']['length'];_0x229fbf++)_0x1b96dd['push'](_0x22ce12['pieces_'][_0x229fbf]);}else{const _0xd601cd=_0x22ce12['split']('/');for(let _0x4953ee=0x0;_0x4953ee<_0xd601cd['length'];_0x4953ee++)_0xd601cd[_0x4953ee]['length']>0x0&&_0x1b96dd['push'](_0xd601cd[_0x4953ee]);}return new C(_0x1b96dd,0x0);}function v(_0x52bcce){return _0x52bcce['pieceNum_']>=_0x52bcce['pieces_']['length'];}function F(_0x3d4d3d,_0x4358fb){const _0x591a1f=y(_0x3d4d3d),_0x1825f9=y(_0x4358fb);if(_0x591a1f===null)return _0x4358fb;if(_0x591a1f===_0x1825f9)return F(b(_0x3d4d3d),b(_0x4358fb));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x4358fb+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3d4d3d+')');}function Th(_0x3cdfd5,_0x2698d3){const _0x8de68d=kt(_0x3cdfd5,0x0),_0x243c7b=kt(_0x2698d3,0x0);for(let _0x37fdb8=0x0;_0x37fdb8<_0x8de68d['length']&&_0x37fdb8<_0x243c7b['length'];_0x37fdb8++){const _0x101510=He(_0x8de68d[_0x37fdb8],_0x243c7b[_0x37fdb8]);if(_0x101510!==0x0)return _0x101510;}return _0x8de68d['length']===_0x243c7b['length']?0x0:_0x8de68d['length']<_0x243c7b['length']?-0x1:0x1;}function qi(_0x19c3bf,_0xc103ae){if(we(_0x19c3bf)!==we(_0xc103ae))return!0x1;for(let _0x26424b=_0x19c3bf['pieceNum_'],_0x456ddd=_0xc103ae['pieceNum_'];_0x26424b<=_0x19c3bf['pieces_']['length'];_0x26424b++,_0x456ddd++)if(_0x19c3bf['pieces_'][_0x26424b]!==_0xc103ae['pieces_'][_0x456ddd])return!0x1;return!0x0;}function $(_0x4ab0e2,_0x53285e){let _0x158a53=_0x4ab0e2['pieceNum_'],_0x4406f2=_0x53285e['pieceNum_'];if(we(_0x4ab0e2)>we(_0x53285e))return!0x1;for(;_0x158a53<_0x4ab0e2['pieces_']['length'];){if(_0x4ab0e2['pieces_'][_0x158a53]!==_0x53285e['pieces_'][_0x4406f2])return!0x1;++_0x158a53,++_0x4406f2;}return!0x0;}class Sh{constructor(_0xcb24b4,_0x19bdb4){this['errorPrefix_']=_0x19bdb4,this['parts_']=kt(_0xcb24b4,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x125d55=0x0;_0x125d55<this['parts_']['length'];_0x125d55++)this['byteLength_']+=Pn(this['parts_'][_0x125d55]);So(this);}}function bh(_0x428fec,_0x292108){_0x428fec['parts_']['length']>0x0&&(_0x428fec['byteLength_']+=0x1),_0x428fec['parts_']['push'](_0x292108),_0x428fec['byteLength_']+=Pn(_0x292108),So(_0x428fec);}function Rh(_0x300bc2){const _0xf9f944=_0x300bc2['parts_']['pop']();_0x300bc2['byteLength_']-=Pn(_0xf9f944),_0x300bc2['parts_']['length']>0x0&&(_0x300bc2['byteLength_']-=0x1);}function So(_0x2a4e82){if(_0x2a4e82['byteLength_']>Js)throw new Error(_0x2a4e82['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x2a4e82['byteLength_']+').');if(_0x2a4e82['parts_']['length']>Qs)throw new Error(_0x2a4e82['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x2a4e82));}function Ne(_0x557c81){return _0x557c81['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x557c81['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x5450a2,_0x13ca68;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x13ca68='visibilitychange',_0x5450a2='hidden'):typeof document['mozHidden']<'u'?(_0x13ca68='mozvisibilitychange',_0x5450a2='mozHidden'):typeof document['msHidden']<'u'?(_0x13ca68='msvisibilitychange',_0x5450a2='msHidden'):typeof document['webkitHidden']<'u'&&(_0x13ca68='webkitvisibilitychange',_0x5450a2='webkitHidden')),this['visible_']=!0x0,_0x13ca68&&document['addEventListener'](_0x13ca68,()=>{const _0x59ef94=!document[_0x5450a2];_0x59ef94!==this['visible_']&&(this['visible_']=_0x59ef94,this['trigger']('visible',_0x59ef94));},!0x1);}['getInitialEvent'](_0x4ccb1c){return f(_0x4ccb1c==='visible','Unknown\x20event\x20type:\x20'+_0x4ccb1c),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x24ad2a,_0x37f4bf,_0x2fbffd,_0x570f2b,_0x40203e,_0x5f24b6,_0x19c98e,_0x236ba2){if(super(),this['repoInfo_']=_0x24ad2a,this['applicationId_']=_0x37f4bf,this['onDataUpdate_']=_0x2fbffd,this['onConnectStatus_']=_0x570f2b,this['onServerInfoUpdate_']=_0x40203e,this['authTokenProvider_']=_0x5f24b6,this['appCheckTokenProvider_']=_0x19c98e,this['authOverride_']=_0x236ba2,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x236ba2)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x24ad2a['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x1117d1,_0x2dcf9b,_0x227472){const _0x2ecea3=++this['requestNumber_'],_0x725e5f={'r':_0x2ecea3,'a':_0x1117d1,'b':_0x2dcf9b};this['log_'](O(_0x725e5f)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x725e5f),_0x227472&&(this['requestCBHash_'][_0x2ecea3]=_0x227472);}['get'](_0x18d14d){this['initConnection_']();const _0xcb89b=new Ve(),_0xe42831={'action':'g','request':{'p':_0x18d14d['_path']['toString'](),'q':_0x18d14d['_queryObject']},'onComplete':_0x82dc4e=>{const _0x1b2b18=_0x82dc4e['d'];_0x82dc4e['s']==='ok'?_0xcb89b['resolve'](_0x1b2b18):_0xcb89b['reject'](_0x1b2b18);}};this['outstandingGets_']['push'](_0xe42831),this['outstandingGetCount_']++;const _0x40cf86=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x40cf86),_0xcb89b['promise'];}['listen'](_0x371cc5,_0x59750f,_0x1cff22,_0x297a3a){this['initConnection_']();const _0x5d34f6=_0x371cc5['_queryIdentifier'],_0x59d201=_0x371cc5['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x59d201+'\x20'+_0x5d34f6),this['listens']['has'](_0x59d201)||this['listens']['set'](_0x59d201,new Map()),f(_0x371cc5['_queryParams']['isDefault']()||!_0x371cc5['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x59d201)['has'](_0x5d34f6),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x44c1f4={'onComplete':_0x297a3a,'hashFn':_0x59750f,'query':_0x371cc5,'tag':_0x1cff22};this['listens']['get'](_0x59d201)['set'](_0x5d34f6,_0x44c1f4),this['connected_']&&this['sendListen_'](_0x44c1f4);}['sendGet_'](_0x11653f){const _0x2595bf=this['outstandingGets_'][_0x11653f];this['sendRequest']('g',_0x2595bf['request'],_0x23bb72=>{delete this['outstandingGets_'][_0x11653f],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2595bf['onComplete']&&_0x2595bf['onComplete'](_0x23bb72);});}['sendListen_'](_0x59e340){const _0x414fce=_0x59e340['query'],_0x26b323=_0x414fce['_path']['toString'](),_0x19b181=_0x414fce['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x26b323+'\x20for\x20'+_0x19b181);const _0x4914ad={'p':_0x26b323},_0x365e8b='q';_0x59e340['tag']&&(_0x4914ad['q']=_0x414fce['_queryObject'],_0x4914ad['t']=_0x59e340['tag']),_0x4914ad['h']=_0x59e340['hashFn'](),this['sendRequest'](_0x365e8b,_0x4914ad,_0x51f138=>{const _0x2928f8=_0x51f138['d'],_0x452ffb=_0x51f138['s'];ie['warnOnListenWarnings_'](_0x2928f8,_0x414fce),(this['listens']['get'](_0x26b323)&&this['listens']['get'](_0x26b323)['get'](_0x19b181))===_0x59e340&&(this['log_']('listen\x20response',_0x51f138),_0x452ffb!=='ok'&&this['removeListen_'](_0x26b323,_0x19b181),_0x59e340['onComplete']&&_0x59e340['onComplete'](_0x452ffb,_0x2928f8));});}static['warnOnListenWarnings_'](_0x284b92,_0x5a9ef0){if(_0x284b92&&typeof _0x284b92=='object'&&Y(_0x284b92,'w')){const _0x4fd045=Oe(_0x284b92,'w');if(Array['isArray'](_0x4fd045)&&~_0x4fd045['indexOf']('no_index')){const _0x3d4939='\x22.indexOn\x22:\x20\x22'+_0x5a9ef0['_queryParams']['getIndex']()['toString']()+'\x22',_0x4a3c51=_0x5a9ef0['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3d4939+'\x20at\x20'+_0x4a3c51+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x46fa03){this['authToken_']=_0x46fa03,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x46fa03);}['reduceReconnectDelayIfAdminCredential_'](_0x1d26f9){(_0x1d26f9&&_0x1d26f9['length']===0x28||vc(_0x1d26f9))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x459a0d){this['appCheckToken_']=_0x459a0d,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x527b8f=this['authToken_'],_0x922d8e=yc(_0x527b8f)?'auth':'gauth',_0x249a0f={'cred':_0x527b8f};this['authOverride_']===null?_0x249a0f['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x249a0f['authvar']=this['authOverride_']),this['sendRequest'](_0x922d8e,_0x249a0f,_0x2622dd=>{const _0x2230c8=_0x2622dd['s'],_0x2ed738=_0x2622dd['d']||'error';this['authToken_']===_0x527b8f&&(_0x2230c8==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2230c8,_0x2ed738));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x18fca0=>{const _0x31ca2e=_0x18fca0['s'],_0x3817e8=_0x18fca0['d']||'error';_0x31ca2e==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x31ca2e,_0x3817e8);});}['unlisten'](_0x25b294,_0x5ecb05){const _0x2ae497=_0x25b294['_path']['toString'](),_0x34466e=_0x25b294['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x2ae497+'\x20'+_0x34466e),f(_0x25b294['_queryParams']['isDefault']()||!_0x25b294['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x2ae497,_0x34466e)&&this['connected_']&&this['sendUnlisten_'](_0x2ae497,_0x34466e,_0x25b294['_queryObject'],_0x5ecb05);}['sendUnlisten_'](_0x4c7d2c,_0x41ad11,_0x1c5d0b,_0x35d3e7){this['log_']('Unlisten\x20on\x20'+_0x4c7d2c+'\x20for\x20'+_0x41ad11);const _0x2491d3={'p':_0x4c7d2c},_0x59a1d6='n';_0x35d3e7&&(_0x2491d3['q']=_0x1c5d0b,_0x2491d3['t']=_0x35d3e7),this['sendRequest'](_0x59a1d6,_0x2491d3);}['onDisconnectPut'](_0x1825a8,_0x48ddde,_0x364ad3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1825a8,_0x48ddde,_0x364ad3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1825a8,'action':'o','data':_0x48ddde,'onComplete':_0x364ad3});}['onDisconnectMerge'](_0x86bc8a,_0xa0be6c,_0x63c59c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x86bc8a,_0xa0be6c,_0x63c59c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x86bc8a,'action':'om','data':_0xa0be6c,'onComplete':_0x63c59c});}['onDisconnectCancel'](_0x11b035,_0x26f287){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x11b035,null,_0x26f287):this['onDisconnectRequestQueue_']['push']({'pathString':_0x11b035,'action':'oc','data':null,'onComplete':_0x26f287});}['sendOnDisconnect_'](_0x301954,_0x195159,_0x474c13,_0xa5dfc3){const _0x487021={'p':_0x195159,'d':_0x474c13};this['log_']('onDisconnect\x20'+_0x301954,_0x487021),this['sendRequest'](_0x301954,_0x487021,_0x3250f2=>{_0xa5dfc3&&setTimeout(()=>{_0xa5dfc3(_0x3250f2['s'],_0x3250f2['d']);},Math['floor'](0x0));});}['put'](_0x5085fa,_0x522666,_0x289c79,_0x32bd55){this['putInternal']('p',_0x5085fa,_0x522666,_0x289c79,_0x32bd55);}['merge'](_0x3e1a1d,_0x2bd6c9,_0x2a344,_0x18e2b5){this['putInternal']('m',_0x3e1a1d,_0x2bd6c9,_0x2a344,_0x18e2b5);}['putInternal'](_0x168a4f,_0x7c24c3,_0x3c9a6a,_0x281d8a,_0x669ca2){this['initConnection_']();const _0x4f4b59={'p':_0x7c24c3,'d':_0x3c9a6a};_0x669ca2!==void 0x0&&(_0x4f4b59['h']=_0x669ca2),this['outstandingPuts_']['push']({'action':_0x168a4f,'request':_0x4f4b59,'onComplete':_0x281d8a}),this['outstandingPutCount_']++;const _0x1e5e0b=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x1e5e0b):this['log_']('Buffering\x20put:\x20'+_0x7c24c3);}['sendPut_'](_0x20bf61){const _0x774afa=this['outstandingPuts_'][_0x20bf61]['action'],_0x221830=this['outstandingPuts_'][_0x20bf61]['request'],_0x2d0f2f=this['outstandingPuts_'][_0x20bf61]['onComplete'];this['outstandingPuts_'][_0x20bf61]['queued']=this['connected_'],this['sendRequest'](_0x774afa,_0x221830,_0x316246=>{this['log_'](_0x774afa+'\x20response',_0x316246),delete this['outstandingPuts_'][_0x20bf61],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2d0f2f&&_0x2d0f2f(_0x316246['s'],_0x316246['d']);});}['reportStats'](_0x166f50){if(this['connected_']){const _0x164a9c={'c':_0x166f50};this['log_']('reportStats',_0x164a9c),this['sendRequest']('s',_0x164a9c,_0x500164=>{if(_0x500164['s']!=='ok'){const _0x3e9a65=_0x500164['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3e9a65);}});}}['onDataMessage_'](_0x4c280a){if('r'in _0x4c280a){this['log_']('from\x20server:\x20'+O(_0x4c280a));const _0xe98521=_0x4c280a['r'],_0x11b01c=this['requestCBHash_'][_0xe98521];_0x11b01c&&(delete this['requestCBHash_'][_0xe98521],_0x11b01c(_0x4c280a['b']));}else{if('error'in _0x4c280a)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4c280a['error'];'a'in _0x4c280a&&this['onDataPush_'](_0x4c280a['a'],_0x4c280a['b']);}}['onDataPush_'](_0x1c7598,_0x52db85){this['log_']('handleServerMessage',_0x1c7598,_0x52db85),_0x1c7598==='d'?this['onDataUpdate_'](_0x52db85['p'],_0x52db85['d'],!0x1,_0x52db85['t']):_0x1c7598==='m'?this['onDataUpdate_'](_0x52db85['p'],_0x52db85['d'],!0x0,_0x52db85['t']):_0x1c7598==='c'?this['onListenRevoked_'](_0x52db85['p'],_0x52db85['q']):_0x1c7598==='ac'?this['onAuthRevoked_'](_0x52db85['s'],_0x52db85['d']):_0x1c7598==='apc'?this['onAppCheckRevoked_'](_0x52db85['s'],_0x52db85['d']):_0x1c7598==='sd'?this['onSecurityDebugPacket_'](_0x52db85):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x1c7598)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x13a249,_0x45e159){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x13a249),this['lastSessionId']=_0x45e159,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x309698){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x309698));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x59d763){_0x59d763&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x59d763;}['onOnline_'](_0x4fc822){_0x4fc822?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x306c21=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x45f80c=Math['max'](0x0,this['reconnectDelay_']-_0x306c21);_0x45f80c=Math['random']()*_0x45f80c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x45f80c+'ms'),this['scheduleConnect_'](_0x45f80c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x33c8b6=this['onDataMessage_']['bind'](this),_0x718996=this['onReady_']['bind'](this),_0x2bcccd=this['onRealtimeDisconnect_']['bind'](this),_0x2f5d43=this['id']+':'+ie['nextConnectionId_']++,_0x236c70=this['lastSessionId'];let _0x3e1b00=!0x1,_0x3b8cb0=null;const _0x55a69a=function(){_0x3b8cb0?_0x3b8cb0['close']():(_0x3e1b00=!0x0,_0x2bcccd());},_0x4c263a=function(_0x116e66){f(_0x3b8cb0,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3b8cb0['sendRequest'](_0x116e66);};this['realtime_']={'close':_0x55a69a,'sendRequest':_0x4c263a};const _0x4806d7=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x512f39,_0x27c52c]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4806d7),this['appCheckTokenProvider_']['getToken'](_0x4806d7)]);_0x3e1b00?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x512f39&&_0x512f39['accessToken'],this['appCheckToken_']=_0x27c52c&&_0x27c52c['token'],_0x3b8cb0=new wh(_0x2f5d43,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x33c8b6,_0x718996,_0x2bcccd,_0x346b18=>{U(_0x346b18+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x236c70));}catch(_0x21be07){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x21be07),_0x3e1b00||(this['repoInfo_']['nodeAdmin']&&U(_0x21be07),_0x55a69a());}}}['interrupt'](_0x468128){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x468128),this['interruptReasons_'][_0x468128]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5654ec){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5654ec),delete this['interruptReasons_'][_0x5654ec],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0xd0becf){const _0x5a3e24=_0xd0becf-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5a3e24});}['cancelSentTransactions_'](){for(let _0x3ec876=0x0;_0x3ec876<this['outstandingPuts_']['length'];_0x3ec876++){const _0xaf2c43=this['outstandingPuts_'][_0x3ec876];_0xaf2c43&&'h'in _0xaf2c43['request']&&_0xaf2c43['queued']&&(_0xaf2c43['onComplete']&&_0xaf2c43['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x3ec876],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x328def,_0x2bc528){let _0x2a5d56;_0x2bc528?_0x2a5d56=_0x2bc528['map'](_0x246941=>Bi(_0x246941))['join']('$'):_0x2a5d56='default';const _0x554dbe=this['removeListen_'](_0x328def,_0x2a5d56);_0x554dbe&&_0x554dbe['onComplete']&&_0x554dbe['onComplete']('permission_denied');}['removeListen_'](_0x1a8a7e,_0x6bd627){const _0x2b60f7=new C(_0x1a8a7e)['toString']();let _0xf91dc1;if(this['listens']['has'](_0x2b60f7)){const _0x4362ca=this['listens']['get'](_0x2b60f7);_0xf91dc1=_0x4362ca['get'](_0x6bd627),_0x4362ca['delete'](_0x6bd627),_0x4362ca['size']===0x0&&this['listens']['delete'](_0x2b60f7);}else _0xf91dc1=void 0x0;return _0xf91dc1;}['onAuthRevoked_'](_0x377645,_0x57de02){L('Auth\x20token\x20revoked:\x20'+_0x377645+'/'+_0x57de02),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x377645==='invalid_token'||_0x377645==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x14cb3a,_0x5d191a){L('App\x20check\x20token\x20revoked:\x20'+_0x14cb3a+'/'+_0x5d191a),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x14cb3a==='invalid_token'||_0x14cb3a==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2e5dfc){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2e5dfc):'msg'in _0x2e5dfc&&console['log']('FIREBASE:\x20'+_0x2e5dfc['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1e8b86 of this['listens']['values']())for(const _0x49fe35 of _0x1e8b86['values']())this['sendListen_'](_0x49fe35);for(let _0x104389=0x0;_0x104389<this['outstandingPuts_']['length'];_0x104389++)this['outstandingPuts_'][_0x104389]&&this['sendPut_'](_0x104389);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2e5c75=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2e5c75['action'],_0x2e5c75['pathString'],_0x2e5c75['data'],_0x2e5c75['onComplete']);}for(let _0x5d37df=0x0;_0x5d37df<this['outstandingGets_']['length'];_0x5d37df++)this['outstandingGets_'][_0x5d37df]&&this['sendGet_'](_0x5d37df);}['sendConnectStats_'](){const _0x2f3f34={};let _0x257d71='js';_0x2f3f34['sdk.'+_0x257d71+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x2f3f34['framework.cordova']=0x1:qr()&&(_0x2f3f34['framework.reactnative']=0x1),this['reportStats'](_0x2f3f34);}['shouldReconnect_'](){const _0x41db66=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x41db66;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5e16d9,_0x23ae69){this['name']=_0x5e16d9,this['node']=_0x23ae69;}static['Wrap'](_0x38b3de,_0x517eb3){return new E(_0x38b3de,_0x517eb3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x555481,_0x3390c6){const _0x3fdc03=new E(xe,_0x555481),_0x28a1ee=new E(xe,_0x3390c6);return this['compare'](_0x3fdc03,_0x28a1ee)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x4bcad7){Xt=_0x4bcad7;}['compare'](_0x202d4d,_0x3df02d){return He(_0x202d4d['name'],_0x3df02d['name']);}['isDefinedOn'](_0x9e6ddc){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x27b61d,_0x5c7768){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x51d3fc,_0x2540dc){return f(typeof _0x51d3fc=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x51d3fc,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x11cc6f,_0x4b7910,_0x563bee,_0x2cfca9,_0x34a67e=null){this['isReverse_']=_0x2cfca9,this['resultGenerator_']=_0x34a67e,this['nodeStack_']=[];let _0x3afa9c=0x1;for(;!_0x11cc6f['isEmpty']();)if(_0x11cc6f=_0x11cc6f,_0x3afa9c=_0x4b7910?_0x563bee(_0x11cc6f['key'],_0x4b7910):0x1,_0x2cfca9&&(_0x3afa9c*=-0x1),_0x3afa9c<0x0)this['isReverse_']?_0x11cc6f=_0x11cc6f['left']:_0x11cc6f=_0x11cc6f['right'];else{if(_0x3afa9c===0x0){this['nodeStack_']['push'](_0x11cc6f);break;}else this['nodeStack_']['push'](_0x11cc6f),this['isReverse_']?_0x11cc6f=_0x11cc6f['right']:_0x11cc6f=_0x11cc6f['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3ac450=this['nodeStack_']['pop'](),_0x17be4e;if(this['resultGenerator_']?_0x17be4e=this['resultGenerator_'](_0x3ac450['key'],_0x3ac450['value']):_0x17be4e={'key':_0x3ac450['key'],'value':_0x3ac450['value']},this['isReverse_']){for(_0x3ac450=_0x3ac450['left'];!_0x3ac450['isEmpty']();)this['nodeStack_']['push'](_0x3ac450),_0x3ac450=_0x3ac450['right'];}else{for(_0x3ac450=_0x3ac450['right'];!_0x3ac450['isEmpty']();)this['nodeStack_']['push'](_0x3ac450),_0x3ac450=_0x3ac450['left'];}return _0x17be4e;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2e939=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2e939['key'],_0x2e939['value']):{'key':_0x2e939['key'],'value':_0x2e939['value']};}}class M{constructor(_0x1c0463,_0x5cc83f,_0x5be084,_0x2f3097,_0x169e4f){this['key']=_0x1c0463,this['value']=_0x5cc83f,this['color']=_0x5be084??M['RED'],this['left']=_0x2f3097??B['EMPTY_NODE'],this['right']=_0x169e4f??B['EMPTY_NODE'];}['copy'](_0x1013e1,_0x4e670e,_0x3faf0,_0x5b8f77,_0x480182){return new M(_0x1013e1??this['key'],_0x4e670e??this['value'],_0x3faf0??this['color'],_0x5b8f77??this['left'],_0x480182??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3c532e){return this['left']['inorderTraversal'](_0x3c532e)||!!_0x3c532e(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3c532e);}['reverseTraversal'](_0x303dce){return this['right']['reverseTraversal'](_0x303dce)||_0x303dce(this['key'],this['value'])||this['left']['reverseTraversal'](_0x303dce);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x37f1fe,_0x261b50,_0x1210e2){let _0x404102=this;const _0x4a2362=_0x1210e2(_0x37f1fe,_0x404102['key']);return _0x4a2362<0x0?_0x404102=_0x404102['copy'](null,null,null,_0x404102['left']['insert'](_0x37f1fe,_0x261b50,_0x1210e2),null):_0x4a2362===0x0?_0x404102=_0x404102['copy'](null,_0x261b50,null,null,null):_0x404102=_0x404102['copy'](null,null,null,null,_0x404102['right']['insert'](_0x37f1fe,_0x261b50,_0x1210e2)),_0x404102['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x481a47=this;return!_0x481a47['left']['isRed_']()&&!_0x481a47['left']['left']['isRed_']()&&(_0x481a47=_0x481a47['moveRedLeft_']()),_0x481a47=_0x481a47['copy'](null,null,null,_0x481a47['left']['removeMin_'](),null),_0x481a47['fixUp_']();}['remove'](_0x5f106b,_0x5aecf6){let _0x52aa4c,_0x17c9b3;if(_0x52aa4c=this,_0x5aecf6(_0x5f106b,_0x52aa4c['key'])<0x0)!_0x52aa4c['left']['isEmpty']()&&!_0x52aa4c['left']['isRed_']()&&!_0x52aa4c['left']['left']['isRed_']()&&(_0x52aa4c=_0x52aa4c['moveRedLeft_']()),_0x52aa4c=_0x52aa4c['copy'](null,null,null,_0x52aa4c['left']['remove'](_0x5f106b,_0x5aecf6),null);else{if(_0x52aa4c['left']['isRed_']()&&(_0x52aa4c=_0x52aa4c['rotateRight_']()),!_0x52aa4c['right']['isEmpty']()&&!_0x52aa4c['right']['isRed_']()&&!_0x52aa4c['right']['left']['isRed_']()&&(_0x52aa4c=_0x52aa4c['moveRedRight_']()),_0x5aecf6(_0x5f106b,_0x52aa4c['key'])===0x0){if(_0x52aa4c['right']['isEmpty']())return B['EMPTY_NODE'];_0x17c9b3=_0x52aa4c['right']['min_'](),_0x52aa4c=_0x52aa4c['copy'](_0x17c9b3['key'],_0x17c9b3['value'],null,null,_0x52aa4c['right']['removeMin_']());}_0x52aa4c=_0x52aa4c['copy'](null,null,null,null,_0x52aa4c['right']['remove'](_0x5f106b,_0x5aecf6));}return _0x52aa4c['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x9a7d31=this;return _0x9a7d31['right']['isRed_']()&&!_0x9a7d31['left']['isRed_']()&&(_0x9a7d31=_0x9a7d31['rotateLeft_']()),_0x9a7d31['left']['isRed_']()&&_0x9a7d31['left']['left']['isRed_']()&&(_0x9a7d31=_0x9a7d31['rotateRight_']()),_0x9a7d31['left']['isRed_']()&&_0x9a7d31['right']['isRed_']()&&(_0x9a7d31=_0x9a7d31['colorFlip_']()),_0x9a7d31;}['moveRedLeft_'](){let _0x4d5936=this['colorFlip_']();return _0x4d5936['right']['left']['isRed_']()&&(_0x4d5936=_0x4d5936['copy'](null,null,null,null,_0x4d5936['right']['rotateRight_']()),_0x4d5936=_0x4d5936['rotateLeft_'](),_0x4d5936=_0x4d5936['colorFlip_']()),_0x4d5936;}['moveRedRight_'](){let _0x597567=this['colorFlip_']();return _0x597567['left']['left']['isRed_']()&&(_0x597567=_0x597567['rotateRight_'](),_0x597567=_0x597567['colorFlip_']()),_0x597567;}['rotateLeft_'](){const _0x21302c=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x21302c,null);}['rotateRight_'](){const _0x28280a=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x28280a);}['colorFlip_'](){const _0x3b4436=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4c4ed7=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3b4436,_0x4c4ed7);}['checkMaxDepth_'](){const _0x8b8570=this['check_']();return Math['pow'](0x2,_0x8b8570)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2538ec=this['left']['check_']();if(_0x2538ec!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2538ec+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x1ac473,_0x76fa4d,_0x17fe27,_0x545d6d,_0x19fb59){return this;}['insert'](_0x2d3bee,_0x2f3002,_0x18b662){return new M(_0x2d3bee,_0x2f3002,null);}['remove'](_0x45a112,_0x41182a){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x200274){return!0x1;}['reverseTraversal'](_0x24d1b2){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x450991,_0x5a9095=B['EMPTY_NODE']){this['comparator_']=_0x450991,this['root_']=_0x5a9095;}['insert'](_0x115980,_0xc683c0){return new B(this['comparator_'],this['root_']['insert'](_0x115980,_0xc683c0,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x58434f){return new B(this['comparator_'],this['root_']['remove'](_0x58434f,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x280672){let _0x41dd3d,_0x216da9=this['root_'];for(;!_0x216da9['isEmpty']();){if(_0x41dd3d=this['comparator_'](_0x280672,_0x216da9['key']),_0x41dd3d===0x0)return _0x216da9['value'];_0x41dd3d<0x0?_0x216da9=_0x216da9['left']:_0x41dd3d>0x0&&(_0x216da9=_0x216da9['right']);}return null;}['getPredecessorKey'](_0x57b491){let _0x354020,_0x461f4d=this['root_'],_0x53669f=null;for(;!_0x461f4d['isEmpty']();)if(_0x354020=this['comparator_'](_0x57b491,_0x461f4d['key']),_0x354020===0x0){if(_0x461f4d['left']['isEmpty']())return _0x53669f?_0x53669f['key']:null;for(_0x461f4d=_0x461f4d['left'];!_0x461f4d['right']['isEmpty']();)_0x461f4d=_0x461f4d['right'];return _0x461f4d['key'];}else _0x354020<0x0?_0x461f4d=_0x461f4d['left']:_0x354020>0x0&&(_0x53669f=_0x461f4d,_0x461f4d=_0x461f4d['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x43bb2c){return this['root_']['inorderTraversal'](_0x43bb2c);}['reverseTraversal'](_0x50aa2e){return this['root_']['reverseTraversal'](_0x50aa2e);}['getIterator'](_0x5b6080){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x5b6080);}['getIteratorFrom'](_0x44eac7,_0x37d8d1){return new Zt(this['root_'],_0x44eac7,this['comparator_'],!0x1,_0x37d8d1);}['getReverseIteratorFrom'](_0x591d8a,_0x329e90){return new Zt(this['root_'],_0x591d8a,this['comparator_'],!0x0,_0x329e90);}['getReverseIterator'](_0x47b7c9){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x47b7c9);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x2e35bb,_0x34202f){return He(_0x2e35bb['name'],_0x34202f['name']);}function ji(_0x9cf19b,_0x332336){return He(_0x9cf19b,_0x332336);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x1cdd9d){vi=_0x1cdd9d;}const Ro=function(_0x428d80){return typeof _0x428d80=='number'?'number:'+so(_0x428d80):'string:'+_0x428d80;},Ao=function(_0x562f0e){if(_0x562f0e['isLeafNode']()){const _0x11289c=_0x562f0e['val']();f(typeof _0x11289c=='string'||typeof _0x11289c=='number'||typeof _0x11289c=='object'&&Y(_0x11289c,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x562f0e===vi||_0x562f0e['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x562f0e===vi||_0x562f0e['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x8b1629){er=_0x8b1629;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x36eac1,_0x21545d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x36eac1,this['priorityNode_']=_0x21545d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x499d70){return new D(this['value_'],_0x499d70);}['getImmediateChild'](_0x36829e){return _0x36829e==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x18eec6){return v(_0x18eec6)?this:y(_0x18eec6)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x247282,_0x1ba504){return null;}['updateImmediateChild'](_0x108999,_0x23d84d){return _0x108999==='.priority'?this['updatePriority'](_0x23d84d):_0x23d84d['isEmpty']()&&_0x108999!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x108999,_0x23d84d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x485bf9,_0x12aeb7){const _0x47714a=y(_0x485bf9);return _0x47714a===null?_0x12aeb7:_0x12aeb7['isEmpty']()&&_0x47714a!=='.priority'?this:(f(_0x47714a!=='.priority'||we(_0x485bf9)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x47714a,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x485bf9),_0x12aeb7)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x353718,_0x44d080){return!0x1;}['val'](_0x35abd2){return _0x35abd2&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x388ef1='';this['priorityNode_']['isEmpty']()||(_0x388ef1+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0xe11c85=typeof this['value_'];_0x388ef1+=_0xe11c85+':',_0xe11c85==='number'?_0x388ef1+=so(this['value_']):_0x388ef1+=this['value_'],this['lazyHash_']=no(_0x388ef1);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2e46c7){return _0x2e46c7===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2e46c7 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2e46c7['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2e46c7));}['compareToLeafNode_'](_0x51c170){const _0x55f4ab=typeof _0x51c170['value_'],_0x46e4f2=typeof this['value_'],_0x41b580=D['VALUE_TYPE_ORDER']['indexOf'](_0x55f4ab),_0x3c051d=D['VALUE_TYPE_ORDER']['indexOf'](_0x46e4f2);return f(_0x41b580>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x55f4ab),f(_0x3c051d>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x46e4f2),_0x41b580===_0x3c051d?_0x46e4f2==='object'?0x0:this['value_']<_0x51c170['value_']?-0x1:this['value_']===_0x51c170['value_']?0x0:0x1:_0x3c051d-_0x41b580;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1d185e){if(_0x1d185e===this)return!0x0;if(_0x1d185e['isLeafNode']()){const _0x3cc0ef=_0x1d185e;return this['value_']===_0x3cc0ef['value_']&&this['priorityNode_']['equals'](_0x3cc0ef['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x4f456d){ko=_0x4f456d;}function xh(_0x370abc){No=_0x370abc;}class Fh extends On{['compare'](_0x1285d1,_0x496e81){const _0x25167c=_0x1285d1['node']['getPriority'](),_0x584f35=_0x496e81['node']['getPriority'](),_0xea64c=_0x25167c['compareTo'](_0x584f35);return _0xea64c===0x0?He(_0x1285d1['name'],_0x496e81['name']):_0xea64c;}['isDefinedOn'](_0x28d16e){return!_0x28d16e['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x30f2df,_0x45774f){return!_0x30f2df['getPriority']()['equals'](_0x45774f['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x4f13f9,_0x15740d){const _0xde7b2a=ko(_0x4f13f9);return new E(_0x15740d,new D('[PRIORITY-POST]',_0xde7b2a));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x193ee8){const _0x15f327=_0x46ffa8=>parseInt(Math['log'](_0x46ffa8)/Uh,0xa),_0x3b8178=_0x16e373=>parseInt(Array(_0x16e373+0x1)['join']('1'),0x2);this['count']=_0x15f327(_0x193ee8+0x1),this['current_']=this['count']-0x1;const _0x585adb=_0x3b8178(this['count']);this['bits_']=_0x193ee8+0x1&_0x585adb;}['nextBitIsOne'](){const _0x55f8f1=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x55f8f1;}}const dn=function(_0x54649f,_0x17b426,_0x331659,_0x3f9195){_0x54649f['sort'](_0x17b426);const _0x43cd2b=function(_0x1f57fd,_0x27a721){const _0x5430d7=_0x27a721-_0x1f57fd;let _0x24fe44,_0x257100;if(_0x5430d7===0x0)return null;if(_0x5430d7===0x1)return _0x24fe44=_0x54649f[_0x1f57fd],_0x257100=_0x331659?_0x331659(_0x24fe44):_0x24fe44,new M(_0x257100,_0x24fe44['node'],M['BLACK'],null,null);{const _0x3f16fa=parseInt(_0x5430d7/0x2,0xa)+_0x1f57fd,_0x1f6398=_0x43cd2b(_0x1f57fd,_0x3f16fa),_0x4b567d=_0x43cd2b(_0x3f16fa+0x1,_0x27a721);return _0x24fe44=_0x54649f[_0x3f16fa],_0x257100=_0x331659?_0x331659(_0x24fe44):_0x24fe44,new M(_0x257100,_0x24fe44['node'],M['BLACK'],_0x1f6398,_0x4b567d);}},_0x1a1ca1=function(_0xb49022){let _0x2baa09=null,_0x174103=null,_0x3b95d5=_0x54649f['length'];const _0x4d982f=function(_0x2d71d7,_0x1282c0){const _0x34641e=_0x3b95d5-_0x2d71d7,_0x1e1b10=_0x3b95d5;_0x3b95d5-=_0x2d71d7;const _0x38db5b=_0x43cd2b(_0x34641e+0x1,_0x1e1b10),_0x382507=_0x54649f[_0x34641e],_0x2b1093=_0x331659?_0x331659(_0x382507):_0x382507;_0x5f70d0(new M(_0x2b1093,_0x382507['node'],_0x1282c0,null,_0x38db5b));},_0x5f70d0=function(_0x1b967b){_0x2baa09?(_0x2baa09['left']=_0x1b967b,_0x2baa09=_0x1b967b):(_0x174103=_0x1b967b,_0x2baa09=_0x1b967b);};for(let _0x4ddce8=0x0;_0x4ddce8<_0xb49022['count'];++_0x4ddce8){const _0x5c51ae=_0xb49022['nextBitIsOne'](),_0x4576fd=Math['pow'](0x2,_0xb49022['count']-(_0x4ddce8+0x1));_0x5c51ae?_0x4d982f(_0x4576fd,M['BLACK']):(_0x4d982f(_0x4576fd,M['BLACK']),_0x4d982f(_0x4576fd,M['RED']));}return _0x174103;},_0x5a5b8f=new Wh(_0x54649f['length']),_0x53bd12=_0x1a1ca1(_0x5a5b8f);return new B(_0x3f9195||_0x17b426,_0x53bd12);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x3f0e0f,_0x2d13a7){this['indexes_']=_0x3f0e0f,this['indexSet_']=_0x2d13a7;}['get'](_0x3c8c18){const _0x90de69=Oe(this['indexes_'],_0x3c8c18);if(!_0x90de69)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3c8c18);return _0x90de69 instanceof B?_0x90de69:null;}['hasIndex'](_0x104804){return Y(this['indexSet_'],_0x104804['toString']());}['addIndex'](_0x172e53,_0x55e74c){f(_0x172e53!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xa31001=[];let _0x6cfb12=!0x1;const _0x127454=_0x55e74c['getIterator'](E['Wrap']);let _0x17eec4=_0x127454['getNext']();for(;_0x17eec4;)_0x6cfb12=_0x6cfb12||_0x172e53['isDefinedOn'](_0x17eec4['node']),_0xa31001['push'](_0x17eec4),_0x17eec4=_0x127454['getNext']();let _0x131a93;_0x6cfb12?_0x131a93=dn(_0xa31001,_0x172e53['getCompare']()):_0x131a93=je;const _0x11a2ed=_0x172e53['toString'](),_0x4e9a35={...this['indexSet_']};_0x4e9a35[_0x11a2ed]=_0x172e53;const _0x44ed38={...this['indexes_']};return _0x44ed38[_0x11a2ed]=_0x131a93,new ee(_0x44ed38,_0x4e9a35);}['addToIndexes'](_0x50a8a0,_0x3bd896){const _0x3f1f2c=ln(this['indexes_'],(_0x5d0be3,_0x361ee7)=>{const _0x622dca=Oe(this['indexSet_'],_0x361ee7);if(f(_0x622dca,'Missing\x20index\x20implementation\x20for\x20'+_0x361ee7),_0x5d0be3===je){if(_0x622dca['isDefinedOn'](_0x50a8a0['node'])){const _0x3f1177=[],_0x5ecdff=_0x3bd896['getIterator'](E['Wrap']);let _0x5846f2=_0x5ecdff['getNext']();for(;_0x5846f2;)_0x5846f2['name']!==_0x50a8a0['name']&&_0x3f1177['push'](_0x5846f2),_0x5846f2=_0x5ecdff['getNext']();return _0x3f1177['push'](_0x50a8a0),dn(_0x3f1177,_0x622dca['getCompare']());}else return je;}else{const _0x5c1d28=_0x3bd896['get'](_0x50a8a0['name']);let _0x36445d=_0x5d0be3;return _0x5c1d28&&(_0x36445d=_0x36445d['remove'](new E(_0x50a8a0['name'],_0x5c1d28))),_0x36445d['insert'](_0x50a8a0,_0x50a8a0['node']);}});return new ee(_0x3f1f2c,this['indexSet_']);}['removeFromIndexes'](_0x3ea0fd,_0x51c4c6){const _0x34efc2=ln(this['indexes_'],_0xd52b4c=>{if(_0xd52b4c===je)return _0xd52b4c;{const _0x491487=_0x51c4c6['get'](_0x3ea0fd['name']);return _0x491487?_0xd52b4c['remove'](new E(_0x3ea0fd['name'],_0x491487)):_0xd52b4c;}});return new ee(_0x34efc2,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x5ba2ed,_0x56dad8,_0x3f183e){this['children_']=_0x5ba2ed,this['priorityNode_']=_0x56dad8,this['indexMap_']=_0x3f183e,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x218815){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x218815,this['indexMap_']);}['getImmediateChild'](_0x5e70f6){if(_0x5e70f6==='.priority')return this['getPriority']();{const _0xc0d8d3=this['children_']['get'](_0x5e70f6);return _0xc0d8d3===null?gt:_0xc0d8d3;}}['getChild'](_0x362fb8){const _0x5f0623=y(_0x362fb8);return _0x5f0623===null?this:this['getImmediateChild'](_0x5f0623)['getChild'](b(_0x362fb8));}['hasChild'](_0x427c56){return this['children_']['get'](_0x427c56)!==null;}['updateImmediateChild'](_0x18775b,_0x3f10a0){if(f(_0x3f10a0,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x18775b==='.priority')return this['updatePriority'](_0x3f10a0);{const _0xe0f483=new E(_0x18775b,_0x3f10a0);let _0x20604d,_0x4e2710;_0x3f10a0['isEmpty']()?(_0x20604d=this['children_']['remove'](_0x18775b),_0x4e2710=this['indexMap_']['removeFromIndexes'](_0xe0f483,this['children_'])):(_0x20604d=this['children_']['insert'](_0x18775b,_0x3f10a0),_0x4e2710=this['indexMap_']['addToIndexes'](_0xe0f483,this['children_']));const _0x33eaab=_0x20604d['isEmpty']()?gt:this['priorityNode_'];return new g(_0x20604d,_0x33eaab,_0x4e2710);}}['updateChild'](_0x4a55a4,_0x5d368d){const _0x347900=y(_0x4a55a4);if(_0x347900===null)return _0x5d368d;{f(y(_0x4a55a4)!=='.priority'||we(_0x4a55a4)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x564c86=this['getImmediateChild'](_0x347900)['updateChild'](b(_0x4a55a4),_0x5d368d);return this['updateImmediateChild'](_0x347900,_0x564c86);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x42b1f4){if(this['isEmpty']())return null;const _0x5c94a={};let _0x15dc47=0x0,_0x34f0f0=0x0,_0x5cecfb=!0x0;if(this['forEachChild'](R,(_0x335e03,_0x50fdc9)=>{_0x5c94a[_0x335e03]=_0x50fdc9['val'](_0x42b1f4),_0x15dc47++,_0x5cecfb&&g['INTEGER_REGEXP_']['test'](_0x335e03)?_0x34f0f0=Math['max'](_0x34f0f0,Number(_0x335e03)):_0x5cecfb=!0x1;}),!_0x42b1f4&&_0x5cecfb&&_0x34f0f0<0x2*_0x15dc47){const _0x30e990=[];for(const _0x5d20bf in _0x5c94a)_0x30e990[_0x5d20bf]=_0x5c94a[_0x5d20bf];return _0x30e990;}else return _0x42b1f4&&!this['getPriority']()['isEmpty']()&&(_0x5c94a['.priority']=this['getPriority']()['val']()),_0x5c94a;}['hash'](){if(this['lazyHash_']===null){let _0x350908='';this['getPriority']()['isEmpty']()||(_0x350908+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x206958,_0xfb8d0f)=>{const _0x15333e=_0xfb8d0f['hash']();_0x15333e!==''&&(_0x350908+=':'+_0x206958+':'+_0x15333e);}),this['lazyHash_']=_0x350908===''?'':no(_0x350908);}return this['lazyHash_'];}['getPredecessorChildName'](_0x28c228,_0xa2f979,_0x1e8bbd){const _0x543929=this['resolveIndex_'](_0x1e8bbd);if(_0x543929){const _0x4128c6=_0x543929['getPredecessorKey'](new E(_0x28c228,_0xa2f979));return _0x4128c6?_0x4128c6['name']:null;}else return this['children_']['getPredecessorKey'](_0x28c228);}['getFirstChildName'](_0x576dc7){const _0x4a6774=this['resolveIndex_'](_0x576dc7);if(_0x4a6774){const _0x40b25b=_0x4a6774['minKey']();return _0x40b25b&&_0x40b25b['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x375611){const _0x46e228=this['getFirstChildName'](_0x375611);return _0x46e228?new E(_0x46e228,this['children_']['get'](_0x46e228)):null;}['getLastChildName'](_0x1954ec){const _0x2fd376=this['resolveIndex_'](_0x1954ec);if(_0x2fd376){const _0xb2a70d=_0x2fd376['maxKey']();return _0xb2a70d&&_0xb2a70d['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1708c3){const _0x1e1f81=this['getLastChildName'](_0x1708c3);return _0x1e1f81?new E(_0x1e1f81,this['children_']['get'](_0x1e1f81)):null;}['forEachChild'](_0x102bdb,_0xb91252){const _0x127713=this['resolveIndex_'](_0x102bdb);return _0x127713?_0x127713['inorderTraversal'](_0x505222=>_0xb91252(_0x505222['name'],_0x505222['node'])):this['children_']['inorderTraversal'](_0xb91252);}['getIterator'](_0x248485){return this['getIteratorFrom'](_0x248485['minPost'](),_0x248485);}['getIteratorFrom'](_0x546e3b,_0x5435c4){const _0x559e19=this['resolveIndex_'](_0x5435c4);if(_0x559e19)return _0x559e19['getIteratorFrom'](_0x546e3b,_0x563523=>_0x563523);{const _0x4cd8c3=this['children_']['getIteratorFrom'](_0x546e3b['name'],E['Wrap']);let _0x3ba032=_0x4cd8c3['peek']();for(;_0x3ba032!=null&&_0x5435c4['compare'](_0x3ba032,_0x546e3b)<0x0;)_0x4cd8c3['getNext'](),_0x3ba032=_0x4cd8c3['peek']();return _0x4cd8c3;}}['getReverseIterator'](_0x4af5c7){return this['getReverseIteratorFrom'](_0x4af5c7['maxPost'](),_0x4af5c7);}['getReverseIteratorFrom'](_0xfbe857,_0x43600d){const _0xd6504f=this['resolveIndex_'](_0x43600d);if(_0xd6504f)return _0xd6504f['getReverseIteratorFrom'](_0xfbe857,_0x236c6b=>_0x236c6b);{const _0x4256ba=this['children_']['getReverseIteratorFrom'](_0xfbe857['name'],E['Wrap']);let _0x2c9aa9=_0x4256ba['peek']();for(;_0x2c9aa9!=null&&_0x43600d['compare'](_0x2c9aa9,_0xfbe857)>0x0;)_0x4256ba['getNext'](),_0x2c9aa9=_0x4256ba['peek']();return _0x4256ba;}}['compareTo'](_0x241ae3){return this['isEmpty']()?_0x241ae3['isEmpty']()?0x0:-0x1:_0x241ae3['isLeafNode']()||_0x241ae3['isEmpty']()?0x1:_0x241ae3===Ht?-0x1:0x0;}['withIndex'](_0x30fa4c){if(_0x30fa4c===ye||this['indexMap_']['hasIndex'](_0x30fa4c))return this;{const _0x24d267=this['indexMap_']['addIndex'](_0x30fa4c,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x24d267);}}['isIndexed'](_0x2cb00e){return _0x2cb00e===ye||this['indexMap_']['hasIndex'](_0x2cb00e);}['equals'](_0x5f26c3){if(_0x5f26c3===this)return!0x0;if(_0x5f26c3['isLeafNode']())return!0x1;{const _0x156395=_0x5f26c3;if(this['getPriority']()['equals'](_0x156395['getPriority']())){if(this['children_']['count']()===_0x156395['children_']['count']()){const _0x2a561b=this['getIterator'](R),_0x4c8deb=_0x156395['getIterator'](R);let _0x505cb3=_0x2a561b['getNext'](),_0x2373b6=_0x4c8deb['getNext']();for(;_0x505cb3&&_0x2373b6;){if(_0x505cb3['name']!==_0x2373b6['name']||!_0x505cb3['node']['equals'](_0x2373b6['node']))return!0x1;_0x505cb3=_0x2a561b['getNext'](),_0x2373b6=_0x4c8deb['getNext']();}return _0x505cb3===null&&_0x2373b6===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x9cbd59){return _0x9cbd59===ye?null:this['indexMap_']['get'](_0x9cbd59['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x5e0f5b){return _0x5e0f5b===this?0x0:0x1;}['equals'](_0x479687){return _0x479687===this;}['getPriority'](){return this;}['getImmediateChild'](_0x252853){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x5b2b8b,_0x3e5ca4=null){if(_0x5b2b8b===null)return g['EMPTY_NODE'];if(typeof _0x5b2b8b=='object'&&'.priority'in _0x5b2b8b&&(_0x3e5ca4=_0x5b2b8b['.priority']),f(_0x3e5ca4===null||typeof _0x3e5ca4=='string'||typeof _0x3e5ca4=='number'||typeof _0x3e5ca4=='object'&&'.sv'in _0x3e5ca4,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3e5ca4),typeof _0x5b2b8b=='object'&&'.value'in _0x5b2b8b&&_0x5b2b8b['.value']!==null&&(_0x5b2b8b=_0x5b2b8b['.value']),typeof _0x5b2b8b!='object'||'.sv'in _0x5b2b8b){const _0x2dbe9f=_0x5b2b8b;return new D(_0x2dbe9f,N(_0x3e5ca4));}if(!(_0x5b2b8b instanceof Array)&&Vh){const _0x2ce6d5=[];let _0x1f4e3a=!0x1;if(x(_0x5b2b8b,(_0x486370,_0x48eadc)=>{if(_0x486370['substring'](0x0,0x1)!=='.'){const _0x5ab90e=N(_0x48eadc);_0x5ab90e['isEmpty']()||(_0x1f4e3a=_0x1f4e3a||!_0x5ab90e['getPriority']()['isEmpty'](),_0x2ce6d5['push'](new E(_0x486370,_0x5ab90e)));}}),_0x2ce6d5['length']===0x0)return g['EMPTY_NODE'];const _0x5dd121=dn(_0x2ce6d5,Dh,_0x38be26=>_0x38be26['name'],ji);if(_0x1f4e3a){const _0x380a65=dn(_0x2ce6d5,R['getCompare']());return new g(_0x5dd121,N(_0x3e5ca4),new ee({'.priority':_0x380a65},{'.priority':R}));}else return new g(_0x5dd121,N(_0x3e5ca4),ee['Default']);}else{let _0x54c43d=g['EMPTY_NODE'];return x(_0x5b2b8b,(_0x9f71fe,_0x1ef952)=>{if(Y(_0x5b2b8b,_0x9f71fe)&&_0x9f71fe['substring'](0x0,0x1)!=='.'){const _0x25b4d6=N(_0x1ef952);(_0x25b4d6['isLeafNode']()||!_0x25b4d6['isEmpty']())&&(_0x54c43d=_0x54c43d['updateImmediateChild'](_0x9f71fe,_0x25b4d6));}}),_0x54c43d['updatePriority'](N(_0x3e5ca4));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x137947){super(),this['indexPath_']=_0x137947,f(!v(_0x137947)&&y(_0x137947)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5302b1){return _0x5302b1['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1938bd){return!_0x1938bd['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3cf8da,_0x41ca49){const _0x6dae96=this['extractChild'](_0x3cf8da['node']),_0x1a9dca=this['extractChild'](_0x41ca49['node']),_0x5aebfa=_0x6dae96['compareTo'](_0x1a9dca);return _0x5aebfa===0x0?He(_0x3cf8da['name'],_0x41ca49['name']):_0x5aebfa;}['makePost'](_0xa1e33f,_0x46ce7d){const _0x251ff6=N(_0xa1e33f),_0x505b9f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x251ff6);return new E(_0x46ce7d,_0x505b9f);}['maxPost'](){const _0x1b32fc=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x1b32fc);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x5dd47c,_0xf157d0){const _0x2d4db8=_0x5dd47c['node']['compareTo'](_0xf157d0['node']);return _0x2d4db8===0x0?He(_0x5dd47c['name'],_0xf157d0['name']):_0x2d4db8;}['isDefinedOn'](_0x176ec4){return!0x0;}['indexedValueChanged'](_0x1548cf,_0xf6c6ee){return!_0x1548cf['equals'](_0xf6c6ee);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2bf151,_0x15fb94){const _0x26fe8b=N(_0x2bf151);return new E(_0x15fb94,_0x26fe8b);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x51a33e){return{'type':'value','snapshotNode':_0x51a33e};}function tt(_0x4f98d9,_0x1136f0){return{'type':'child_added','snapshotNode':_0x1136f0,'childName':_0x4f98d9};}function Nt(_0x41898d,_0x4dd392){return{'type':'child_removed','snapshotNode':_0x4dd392,'childName':_0x41898d};}function Pt(_0x578ce8,_0x2220d0,_0x1fe333){return{'type':'child_changed','snapshotNode':_0x2220d0,'childName':_0x578ce8,'oldSnap':_0x1fe333};}function $h(_0x32dd8c,_0x1d35bf){return{'type':'child_moved','snapshotNode':_0x1d35bf,'childName':_0x32dd8c};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x249071){this['index_']=_0x249071;}['updateChild'](_0x315871,_0x56e1d3,_0x2b1f2a,_0x42effd,_0x4ba5af,_0x319211){f(_0x315871['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x5a33a1=_0x315871['getImmediateChild'](_0x56e1d3);return _0x5a33a1['getChild'](_0x42effd)['equals'](_0x2b1f2a['getChild'](_0x42effd))&&_0x5a33a1['isEmpty']()===_0x2b1f2a['isEmpty']()||(_0x319211!=null&&(_0x2b1f2a['isEmpty']()?_0x315871['hasChild'](_0x56e1d3)?_0x319211['trackChildChange'](Nt(_0x56e1d3,_0x5a33a1)):f(_0x315871['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x5a33a1['isEmpty']()?_0x319211['trackChildChange'](tt(_0x56e1d3,_0x2b1f2a)):_0x319211['trackChildChange'](Pt(_0x56e1d3,_0x2b1f2a,_0x5a33a1))),_0x315871['isLeafNode']()&&_0x2b1f2a['isEmpty']())?_0x315871:_0x315871['updateImmediateChild'](_0x56e1d3,_0x2b1f2a)['withIndex'](this['index_']);}['updateFullNode'](_0x38651c,_0xae2941,_0x3b5e45){return _0x3b5e45!=null&&(_0x38651c['isLeafNode']()||_0x38651c['forEachChild'](R,(_0x438830,_0x1ae22a)=>{_0xae2941['hasChild'](_0x438830)||_0x3b5e45['trackChildChange'](Nt(_0x438830,_0x1ae22a));}),_0xae2941['isLeafNode']()||_0xae2941['forEachChild'](R,(_0x1e4a3a,_0x1f9843)=>{if(_0x38651c['hasChild'](_0x1e4a3a)){const _0x4c45c7=_0x38651c['getImmediateChild'](_0x1e4a3a);_0x4c45c7['equals'](_0x1f9843)||_0x3b5e45['trackChildChange'](Pt(_0x1e4a3a,_0x1f9843,_0x4c45c7));}else _0x3b5e45['trackChildChange'](tt(_0x1e4a3a,_0x1f9843));})),_0xae2941['withIndex'](this['index_']);}['updatePriority'](_0x1e7520,_0x71ae03){return _0x1e7520['isEmpty']()?g['EMPTY_NODE']:_0x1e7520['updatePriority'](_0x71ae03);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x55852a){this['indexedFilter_']=new Yi(_0x55852a['getIndex']()),this['index_']=_0x55852a['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x55852a),this['endPost_']=Ot['getEndPost_'](_0x55852a),this['startIsInclusive_']=!_0x55852a['startAfterSet_'],this['endIsInclusive_']=!_0x55852a['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x176c8e){const _0x17324a=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x176c8e)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x176c8e)<0x0,_0x1beae9=this['endIsInclusive_']?this['index_']['compare'](_0x176c8e,this['getEndPost']())<=0x0:this['index_']['compare'](_0x176c8e,this['getEndPost']())<0x0;return _0x17324a&&_0x1beae9;}['updateChild'](_0x341455,_0x193557,_0x28ffd9,_0x5667c1,_0x49c087,_0x5987ef){return this['matches'](new E(_0x193557,_0x28ffd9))||(_0x28ffd9=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x341455,_0x193557,_0x28ffd9,_0x5667c1,_0x49c087,_0x5987ef);}['updateFullNode'](_0x160877,_0x4dab53,_0x525574){_0x4dab53['isLeafNode']()&&(_0x4dab53=g['EMPTY_NODE']);let _0x43a1c4=_0x4dab53['withIndex'](this['index_']);_0x43a1c4=_0x43a1c4['updatePriority'](g['EMPTY_NODE']);const _0x5a667d=this;return _0x4dab53['forEachChild'](R,(_0x5ece68,_0x48d544)=>{_0x5a667d['matches'](new E(_0x5ece68,_0x48d544))||(_0x43a1c4=_0x43a1c4['updateImmediateChild'](_0x5ece68,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x160877,_0x43a1c4,_0x525574);}['updatePriority'](_0x21a410,_0x3304f6){return _0x21a410;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x5a6a5f){if(_0x5a6a5f['hasStart']()){const _0x57fcdb=_0x5a6a5f['getIndexStartName']();return _0x5a6a5f['getIndex']()['makePost'](_0x5a6a5f['getIndexStartValue'](),_0x57fcdb);}else return _0x5a6a5f['getIndex']()['minPost']();}static['getEndPost_'](_0x342854){if(_0x342854['hasEnd']()){const _0x4c37de=_0x342854['getIndexEndName']();return _0x342854['getIndex']()['makePost'](_0x342854['getIndexEndValue'](),_0x4c37de);}else return _0x342854['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x58af7b){this['withinDirectionalStart']=_0x224dc2=>this['reverse_']?this['withinEndPost'](_0x224dc2):this['withinStartPost'](_0x224dc2),this['withinDirectionalEnd']=_0x58a33f=>this['reverse_']?this['withinStartPost'](_0x58a33f):this['withinEndPost'](_0x58a33f),this['withinStartPost']=_0x3558c6=>{const _0x19c8dd=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x3558c6);return this['startIsInclusive_']?_0x19c8dd<=0x0:_0x19c8dd<0x0;},this['withinEndPost']=_0x3496ec=>{const _0x499cac=this['index_']['compare'](_0x3496ec,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x499cac<=0x0:_0x499cac<0x0;},this['rangedFilter_']=new Ot(_0x58af7b),this['index_']=_0x58af7b['getIndex'](),this['limit_']=_0x58af7b['getLimit'](),this['reverse_']=!_0x58af7b['isViewFromLeft'](),this['startIsInclusive_']=!_0x58af7b['startAfterSet_'],this['endIsInclusive_']=!_0x58af7b['endBeforeSet_'];}['updateChild'](_0x5cf05b,_0x4672bf,_0x1f15c2,_0x23e85e,_0x530edd,_0x216dc5){return this['rangedFilter_']['matches'](new E(_0x4672bf,_0x1f15c2))||(_0x1f15c2=g['EMPTY_NODE']),_0x5cf05b['getImmediateChild'](_0x4672bf)['equals'](_0x1f15c2)?_0x5cf05b:_0x5cf05b['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5cf05b,_0x4672bf,_0x1f15c2,_0x23e85e,_0x530edd,_0x216dc5):this['fullLimitUpdateChild_'](_0x5cf05b,_0x4672bf,_0x1f15c2,_0x530edd,_0x216dc5);}['updateFullNode'](_0x119530,_0x5bfa5a,_0x3cc2a7){let _0x1ae7c1;if(_0x5bfa5a['isLeafNode']()||_0x5bfa5a['isEmpty']())_0x1ae7c1=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5bfa5a['numChildren']()&&_0x5bfa5a['isIndexed'](this['index_'])){_0x1ae7c1=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x23e0d4;this['reverse_']?_0x23e0d4=_0x5bfa5a['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x23e0d4=_0x5bfa5a['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x51b1f5=0x0;for(;_0x23e0d4['hasNext']()&&_0x51b1f5<this['limit_'];){const _0x3b6ca8=_0x23e0d4['getNext']();if(this['withinDirectionalStart'](_0x3b6ca8)){if(this['withinDirectionalEnd'](_0x3b6ca8))_0x1ae7c1=_0x1ae7c1['updateImmediateChild'](_0x3b6ca8['name'],_0x3b6ca8['node']),_0x51b1f5++;else break;}else continue;}}else{_0x1ae7c1=_0x5bfa5a['withIndex'](this['index_']),_0x1ae7c1=_0x1ae7c1['updatePriority'](g['EMPTY_NODE']);let _0x1c9e73;this['reverse_']?_0x1c9e73=_0x1ae7c1['getReverseIterator'](this['index_']):_0x1c9e73=_0x1ae7c1['getIterator'](this['index_']);let _0x4f2e03=0x0;for(;_0x1c9e73['hasNext']();){const _0x4fa531=_0x1c9e73['getNext']();_0x4f2e03<this['limit_']&&this['withinDirectionalStart'](_0x4fa531)&&this['withinDirectionalEnd'](_0x4fa531)?_0x4f2e03++:_0x1ae7c1=_0x1ae7c1['updateImmediateChild'](_0x4fa531['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x119530,_0x1ae7c1,_0x3cc2a7);}['updatePriority'](_0x368f62,_0x50bcbb){return _0x368f62;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x110fd6,_0x399d8d,_0x3f7f42,_0x40f520,_0x3fbbcb){let _0x3dd65c;if(this['reverse_']){const _0x39b99a=this['index_']['getCompare']();_0x3dd65c=(_0x136328,_0x4aa40b)=>_0x39b99a(_0x4aa40b,_0x136328);}else _0x3dd65c=this['index_']['getCompare']();const _0x2a700d=_0x110fd6;f(_0x2a700d['numChildren']()===this['limit_'],'');const _0x1dc716=new E(_0x399d8d,_0x3f7f42),_0x434b84=this['reverse_']?_0x2a700d['getFirstChild'](this['index_']):_0x2a700d['getLastChild'](this['index_']),_0x648628=this['rangedFilter_']['matches'](_0x1dc716);if(_0x2a700d['hasChild'](_0x399d8d)){const _0x3aa9fd=_0x2a700d['getImmediateChild'](_0x399d8d);let _0x33f149=_0x40f520['getChildAfterChild'](this['index_'],_0x434b84,this['reverse_']);for(;_0x33f149!=null&&(_0x33f149['name']===_0x399d8d||_0x2a700d['hasChild'](_0x33f149['name']));)_0x33f149=_0x40f520['getChildAfterChild'](this['index_'],_0x33f149,this['reverse_']);const _0x890ff3=_0x33f149==null?0x1:_0x3dd65c(_0x33f149,_0x1dc716);if(_0x648628&&!_0x3f7f42['isEmpty']()&&_0x890ff3>=0x0)return _0x3fbbcb!=null&&_0x3fbbcb['trackChildChange'](Pt(_0x399d8d,_0x3f7f42,_0x3aa9fd)),_0x2a700d['updateImmediateChild'](_0x399d8d,_0x3f7f42);{_0x3fbbcb!=null&&_0x3fbbcb['trackChildChange'](Nt(_0x399d8d,_0x3aa9fd));const _0x45cc12=_0x2a700d['updateImmediateChild'](_0x399d8d,g['EMPTY_NODE']);return _0x33f149!=null&&this['rangedFilter_']['matches'](_0x33f149)?(_0x3fbbcb!=null&&_0x3fbbcb['trackChildChange'](tt(_0x33f149['name'],_0x33f149['node'])),_0x45cc12['updateImmediateChild'](_0x33f149['name'],_0x33f149['node'])):_0x45cc12;}}else return _0x3f7f42['isEmpty']()?_0x110fd6:_0x648628&&_0x3dd65c(_0x434b84,_0x1dc716)>=0x0?(_0x3fbbcb!=null&&(_0x3fbbcb['trackChildChange'](Nt(_0x434b84['name'],_0x434b84['node'])),_0x3fbbcb['trackChildChange'](tt(_0x399d8d,_0x3f7f42))),_0x2a700d['updateImmediateChild'](_0x399d8d,_0x3f7f42)['updateImmediateChild'](_0x434b84['name'],g['EMPTY_NODE'])):_0x110fd6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3b2343=new Qi();return _0x3b2343['limitSet_']=this['limitSet_'],_0x3b2343['limit_']=this['limit_'],_0x3b2343['startSet_']=this['startSet_'],_0x3b2343['startAfterSet_']=this['startAfterSet_'],_0x3b2343['indexStartValue_']=this['indexStartValue_'],_0x3b2343['startNameSet_']=this['startNameSet_'],_0x3b2343['indexStartName_']=this['indexStartName_'],_0x3b2343['endSet_']=this['endSet_'],_0x3b2343['endBeforeSet_']=this['endBeforeSet_'],_0x3b2343['indexEndValue_']=this['indexEndValue_'],_0x3b2343['endNameSet_']=this['endNameSet_'],_0x3b2343['indexEndName_']=this['indexEndName_'],_0x3b2343['index_']=this['index_'],_0x3b2343['viewFrom_']=this['viewFrom_'],_0x3b2343;}}function qh(_0x2caf87){return _0x2caf87['loadsAllData']()?new Yi(_0x2caf87['getIndex']()):_0x2caf87['hasLimit']()?new Gh(_0x2caf87):new Ot(_0x2caf87);}function zh(_0x441166,_0x431a3d){const _0x32ecb2=_0x441166['copy']();return _0x32ecb2['limitSet_']=!0x0,_0x32ecb2['limit_']=_0x431a3d,_0x32ecb2['viewFrom_']='l',_0x32ecb2;}function jh(_0x38fd21,_0x2ed021,_0x1308de){const _0x1b1018=_0x38fd21['copy']();return _0x1b1018['startSet_']=!0x0,_0x2ed021===void 0x0&&(_0x2ed021=null),_0x1b1018['indexStartValue_']=_0x2ed021,_0x1308de!=null?(_0x1b1018['startNameSet_']=!0x0,_0x1b1018['indexStartName_']=_0x1308de):(_0x1b1018['startNameSet_']=!0x1,_0x1b1018['indexStartName_']=''),_0x1b1018;}function Kh(_0x1d6c7f,_0x50e007,_0x29a3fc){const _0x555ace=_0x1d6c7f['copy']();return _0x555ace['endSet_']=!0x0,_0x50e007===void 0x0&&(_0x50e007=null),_0x555ace['indexEndValue_']=_0x50e007,_0x29a3fc!==void 0x0?(_0x555ace['endNameSet_']=!0x0,_0x555ace['indexEndName_']=_0x29a3fc):(_0x555ace['endNameSet_']=!0x1,_0x555ace['indexEndName_']=''),_0x555ace;}function Do(_0x4dba50,_0xef4ed0){const _0x16c4ed=_0x4dba50['copy']();return _0x16c4ed['index_']=_0xef4ed0,_0x16c4ed;}function tr(_0x1acc84){const _0x441637={};if(_0x1acc84['isDefault']())return _0x441637;let _0x57fff3;if(_0x1acc84['index_']===R?_0x57fff3='$priority':_0x1acc84['index_']===Po?_0x57fff3='$value':_0x1acc84['index_']===ye?_0x57fff3='$key':(f(_0x1acc84['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x57fff3=_0x1acc84['index_']['toString']()),_0x441637['orderBy']=O(_0x57fff3),_0x1acc84['startSet_']){const _0x3ba81f=_0x1acc84['startAfterSet_']?'startAfter':'startAt';_0x441637[_0x3ba81f]=O(_0x1acc84['indexStartValue_']),_0x1acc84['startNameSet_']&&(_0x441637[_0x3ba81f]+=','+O(_0x1acc84['indexStartName_']));}if(_0x1acc84['endSet_']){const _0x533cda=_0x1acc84['endBeforeSet_']?'endBefore':'endAt';_0x441637[_0x533cda]=O(_0x1acc84['indexEndValue_']),_0x1acc84['endNameSet_']&&(_0x441637[_0x533cda]+=','+O(_0x1acc84['indexEndName_']));}return _0x1acc84['limitSet_']&&(_0x1acc84['isViewFromLeft']()?_0x441637['limitToFirst']=_0x1acc84['limit_']:_0x441637['limitToLast']=_0x1acc84['limit_']),_0x441637;}function nr(_0x2c1b9a){const _0x6d18c7={};if(_0x2c1b9a['startSet_']&&(_0x6d18c7['sp']=_0x2c1b9a['indexStartValue_'],_0x2c1b9a['startNameSet_']&&(_0x6d18c7['sn']=_0x2c1b9a['indexStartName_']),_0x6d18c7['sin']=!_0x2c1b9a['startAfterSet_']),_0x2c1b9a['endSet_']&&(_0x6d18c7['ep']=_0x2c1b9a['indexEndValue_'],_0x2c1b9a['endNameSet_']&&(_0x6d18c7['en']=_0x2c1b9a['indexEndName_']),_0x6d18c7['ein']=!_0x2c1b9a['endBeforeSet_']),_0x2c1b9a['limitSet_']){_0x6d18c7['l']=_0x2c1b9a['limit_'];let _0x5bd3e6=_0x2c1b9a['viewFrom_'];_0x5bd3e6===''&&(_0x2c1b9a['isViewFromLeft']()?_0x5bd3e6='l':_0x5bd3e6='r'),_0x6d18c7['vf']=_0x5bd3e6;}return _0x2c1b9a['index_']!==R&&(_0x6d18c7['i']=_0x2c1b9a['index_']['toString']()),_0x6d18c7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x437fd9){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x1c946f,_0x252fda){return _0x252fda!==void 0x0?'tag$'+_0x252fda:(f(_0x1c946f['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x1c946f['_path']['toString']());}constructor(_0x64130b,_0x2a63e0,_0x1e6fc1,_0x2259e2){super(),this['repoInfo_']=_0x64130b,this['onDataUpdate_']=_0x2a63e0,this['authTokenProvider_']=_0x1e6fc1,this['appCheckTokenProvider_']=_0x2259e2,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x2e4326,_0x1cd254,_0x1afeaa,_0x591412){const _0x436e70=_0x2e4326['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x436e70+'\x20'+_0x2e4326['_queryIdentifier']);const _0x3c2295=fn['getListenId_'](_0x2e4326,_0x1afeaa),_0x3c6d2a={};this['listens_'][_0x3c2295]=_0x3c6d2a;const _0x5d8280=tr(_0x2e4326['_queryParams']);this['restRequest_'](_0x436e70+'.json',_0x5d8280,(_0x5bc41e,_0x543427)=>{let _0x3ca63e=_0x543427;if(_0x5bc41e===0x194&&(_0x3ca63e=null,_0x5bc41e=null),_0x5bc41e===null&&this['onDataUpdate_'](_0x436e70,_0x3ca63e,!0x1,_0x1afeaa),Oe(this['listens_'],_0x3c2295)===_0x3c6d2a){let _0x42b870;_0x5bc41e?_0x5bc41e===0x191?_0x42b870='permission_denied':_0x42b870='rest_error:'+_0x5bc41e:_0x42b870='ok',_0x591412(_0x42b870,null);}});}['unlisten'](_0x3a9a95,_0x8e8a){const _0xd60c04=fn['getListenId_'](_0x3a9a95,_0x8e8a);delete this['listens_'][_0xd60c04];}['get'](_0x482003){const _0x4c9fc2=tr(_0x482003['_queryParams']),_0x1589b3=_0x482003['_path']['toString'](),_0xa72d9a=new Ve();return this['restRequest_'](_0x1589b3+'.json',_0x4c9fc2,(_0x157c4b,_0x1585a5)=>{let _0x58ad4f=_0x1585a5;_0x157c4b===0x194&&(_0x58ad4f=null,_0x157c4b=null),_0x157c4b===null?(this['onDataUpdate_'](_0x1589b3,_0x58ad4f,!0x1,null),_0xa72d9a['resolve'](_0x58ad4f)):_0xa72d9a['reject'](new Error(_0x58ad4f));}),_0xa72d9a['promise'];}['refreshAuthToken'](_0x2c4d63){}['restRequest_'](_0x31d500,_0x4a0b10={},_0x44fde1){return _0x4a0b10['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x506197,_0x40367c])=>{_0x506197&&_0x506197['accessToken']&&(_0x4a0b10['auth']=_0x506197['accessToken']),_0x40367c&&_0x40367c['token']&&(_0x4a0b10['ac']=_0x40367c['token']);const _0xeb06fd=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x31d500+'?ns='+this['repoInfo_']['namespace']+at(_0x4a0b10);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xeb06fd);const _0x5105a3=new XMLHttpRequest();_0x5105a3['onreadystatechange']=()=>{if(_0x44fde1&&_0x5105a3['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xeb06fd+'\x20received.\x20status:',_0x5105a3['status'],'response:',_0x5105a3['responseText']);let _0x522222=null;if(_0x5105a3['status']>=0xc8&&_0x5105a3['status']<0x12c){try{_0x522222=bt(_0x5105a3['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xeb06fd+':\x20'+_0x5105a3['responseText']);}_0x44fde1(null,_0x522222);}else _0x5105a3['status']!==0x191&&_0x5105a3['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xeb06fd+'\x20Status:\x20'+_0x5105a3['status']),_0x44fde1(_0x5105a3['status']);_0x44fde1=null;}},_0x5105a3['open']('GET',_0xeb06fd,!0x0),_0x5105a3['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x285a2f){return this['rootNode_']['getChild'](_0x285a2f);}['updateSnapshot'](_0x51146f,_0x4e2e90){this['rootNode_']=this['rootNode_']['updateChild'](_0x51146f,_0x4e2e90);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x3ead94,_0x209283,_0x1cde6d){if(v(_0x209283))_0x3ead94['value']=_0x1cde6d,_0x3ead94['children']['clear']();else{if(_0x3ead94['value']!==null)_0x3ead94['value']=_0x3ead94['value']['updateChild'](_0x209283,_0x1cde6d);else{const _0x195a5b=y(_0x209283);_0x3ead94['children']['has'](_0x195a5b)||_0x3ead94['children']['set'](_0x195a5b,pn());const _0x508cad=_0x3ead94['children']['get'](_0x195a5b);_0x209283=b(_0x209283),Mo(_0x508cad,_0x209283,_0x1cde6d);}}}function Ei(_0x438baf,_0x51aeae,_0x5bab13){_0x438baf['value']!==null?_0x5bab13(_0x51aeae,_0x438baf['value']):Qh(_0x438baf,(_0x3198f6,_0x45294c)=>{const _0x45d7ee=new C(_0x51aeae['toString']()+'/'+_0x3198f6);Ei(_0x45294c,_0x45d7ee,_0x5bab13);});}function Qh(_0x5f3421,_0x229bd0){_0x5f3421['children']['forEach']((_0x2c0d84,_0x321b08)=>{_0x229bd0(_0x321b08,_0x2c0d84);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x233c9b){this['collection_']=_0x233c9b,this['last_']=null;}['get'](){const _0x1f92b7=this['collection_']['get'](),_0x45b878={..._0x1f92b7};return this['last_']&&x(this['last_'],(_0x46e354,_0x4f3aa9)=>{_0x45b878[_0x46e354]=_0x45b878[_0x46e354]-_0x4f3aa9;}),this['last_']=_0x1f92b7,_0x45b878;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x3f39b8,_0x56ac49){this['server_']=_0x56ac49,this['statsToReport_']={},this['statsListener_']=new Jh(_0x3f39b8);const _0x2e4166=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x2e4166));}['reportStats_'](){const _0x3a2f6b=this['statsListener_']['get'](),_0x526dbd={};let _0x4704ef=!0x1;x(_0x3a2f6b,(_0x1acd0f,_0xe6486b)=>{_0xe6486b>0x0&&Y(this['statsToReport_'],_0x1acd0f)&&(_0x526dbd[_0x1acd0f]=_0xe6486b,_0x4704ef=!0x0);}),_0x4704ef&&this['server_']['reportStats'](_0x526dbd),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x3ac9dd){_0x3ac9dd[_0x3ac9dd['OVERWRITE']=0x0]='OVERWRITE',_0x3ac9dd[_0x3ac9dd['MERGE']=0x1]='MERGE',_0x3ac9dd[_0x3ac9dd['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x3ac9dd[_0x3ac9dd['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x453021){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x453021,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x29f21c,_0x624b88,_0x3ce42b){this['path']=_0x29f21c,this['affectedTree']=_0x624b88,this['revert']=_0x3ce42b,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0xd9aabc){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3b99a8=this['affectedTree']['subtree'](new C(_0xd9aabc));return new _n(w(),_0x3b99a8,this['revert']);}}else return f(y(this['path'])===_0xd9aabc,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x26aacd,_0xc576e){this['source']=_0x26aacd,this['path']=_0xc576e,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0xb918e8){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x1b01c6,_0x4103b6,_0x12e2d8){this['source']=_0x1b01c6,this['path']=_0x4103b6,this['snap']=_0x12e2d8,this['type']=q['OVERWRITE'];}['operationForChild'](_0x54a066){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x54a066)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x54ab3f,_0xc28210,_0x30c075){this['source']=_0x54ab3f,this['path']=_0xc28210,this['children']=_0x30c075,this['type']=q['MERGE'];}['operationForChild'](_0x5e20ca){if(v(this['path'])){const _0x55e5f8=this['children']['subtree'](new C(_0x5e20ca));return _0x55e5f8['isEmpty']()?null:_0x55e5f8['value']?new Fe(this['source'],w(),_0x55e5f8['value']):new nt(this['source'],w(),_0x55e5f8);}else return f(y(this['path'])===_0x5e20ca,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x3672b7,_0x77a3a3,_0x471e2a){this['node_']=_0x3672b7,this['fullyInitialized_']=_0x77a3a3,this['filtered_']=_0x471e2a;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4738e2){if(v(_0x4738e2))return this['isFullyInitialized']()&&!this['filtered_'];const _0x12a0d4=y(_0x4738e2);return this['isCompleteForChild'](_0x12a0d4);}['isCompleteForChild'](_0x313154){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x313154);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x5b0f92){this['query_']=_0x5b0f92,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x11f96d,_0x3b2f9c,_0x1dd31c,_0x4febd7){const _0x4562f8=[],_0x4c9549=[];return _0x3b2f9c['forEach'](_0x5a48df=>{_0x5a48df['type']==='child_changed'&&_0x11f96d['index_']['indexedValueChanged'](_0x5a48df['oldSnap'],_0x5a48df['snapshotNode'])&&_0x4c9549['push']($h(_0x5a48df['childName'],_0x5a48df['snapshotNode']));}),mt(_0x11f96d,_0x4562f8,'child_removed',_0x3b2f9c,_0x4febd7,_0x1dd31c),mt(_0x11f96d,_0x4562f8,'child_added',_0x3b2f9c,_0x4febd7,_0x1dd31c),mt(_0x11f96d,_0x4562f8,'child_moved',_0x4c9549,_0x4febd7,_0x1dd31c),mt(_0x11f96d,_0x4562f8,'child_changed',_0x3b2f9c,_0x4febd7,_0x1dd31c),mt(_0x11f96d,_0x4562f8,'value',_0x3b2f9c,_0x4febd7,_0x1dd31c),_0x4562f8;}function mt(_0x44176e,_0x142a4a,_0x66dd33,_0x1524b6,_0x5dbd9a,_0x1c196c){const _0x24adcd=_0x1524b6['filter'](_0x20592f=>_0x20592f['type']===_0x66dd33);_0x24adcd['sort']((_0x1b5325,_0x125125)=>su(_0x44176e,_0x1b5325,_0x125125)),_0x24adcd['forEach'](_0x4674b6=>{const _0x1d55c5=iu(_0x44176e,_0x4674b6,_0x1c196c);_0x5dbd9a['forEach'](_0x122cef=>{_0x122cef['respondsTo'](_0x4674b6['type'])&&_0x142a4a['push'](_0x122cef['createEvent'](_0x1d55c5,_0x44176e['query_']));});});}function iu(_0x46b3f4,_0x19c9cc,_0x2bf4ed){return _0x19c9cc['type']==='value'||_0x19c9cc['type']==='child_removed'||(_0x19c9cc['prevName']=_0x2bf4ed['getPredecessorChildName'](_0x19c9cc['childName'],_0x19c9cc['snapshotNode'],_0x46b3f4['index_'])),_0x19c9cc;}function su(_0x3e03cf,_0x43bc26,_0x4f5fdd){if(_0x43bc26['childName']==null||_0x4f5fdd['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x54b992=new E(_0x43bc26['childName'],_0x43bc26['snapshotNode']),_0x9db12b=new E(_0x4f5fdd['childName'],_0x4f5fdd['snapshotNode']);return _0x3e03cf['index_']['compare'](_0x54b992,_0x9db12b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x8fddfb,_0x5db104){return{'eventCache':_0x8fddfb,'serverCache':_0x5db104};}function wt(_0x5f443f,_0x4d17d0,_0x55764b,_0x3a6de6){return Dn(new Ce(_0x4d17d0,_0x55764b,_0x3a6de6),_0x5f443f['serverCache']);}function Lo(_0x1eb65f,_0x3f989a,_0x413ee9,_0x2f7312){return Dn(_0x1eb65f['eventCache'],new Ce(_0x3f989a,_0x413ee9,_0x2f7312));}function gn(_0x4f5b68){return _0x4f5b68['eventCache']['isFullyInitialized']()?_0x4f5b68['eventCache']['getNode']():null;}function Ue(_0x30509f){return _0x30509f['serverCache']['isFullyInitialized']()?_0x30509f['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x59ed89){let _0x5fccb=new S(null);return x(_0x59ed89,(_0x267dc3,_0x44ca7c)=>{_0x5fccb=_0x5fccb['set'](new C(_0x267dc3),_0x44ca7c);}),_0x5fccb;}constructor(_0x28c308,_0xe69b05=ru()){this['value']=_0x28c308,this['children']=_0xe69b05;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x31c673,_0x551596){if(this['value']!=null&&_0x551596(this['value']))return{'path':w(),'value':this['value']};if(v(_0x31c673))return null;{const _0x5228b5=y(_0x31c673),_0x26639a=this['children']['get'](_0x5228b5);if(_0x26639a!==null){const _0xa59490=_0x26639a['findRootMostMatchingPathAndValue'](b(_0x31c673),_0x551596);return _0xa59490!=null?{'path':A(new C(_0x5228b5),_0xa59490['path']),'value':_0xa59490['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3e4166){return this['findRootMostMatchingPathAndValue'](_0x3e4166,()=>!0x0);}['subtree'](_0x3ff9f6){if(v(_0x3ff9f6))return this;{const _0x460b70=y(_0x3ff9f6),_0xd4bc8b=this['children']['get'](_0x460b70);return _0xd4bc8b!==null?_0xd4bc8b['subtree'](b(_0x3ff9f6)):new S(null);}}['set'](_0x1f2cfe,_0x59d49){if(v(_0x1f2cfe))return new S(_0x59d49,this['children']);{const _0x274c2c=y(_0x1f2cfe),_0x400dae=(this['children']['get'](_0x274c2c)||new S(null))['set'](b(_0x1f2cfe),_0x59d49),_0x89593f=this['children']['insert'](_0x274c2c,_0x400dae);return new S(this['value'],_0x89593f);}}['remove'](_0x1a569d){if(v(_0x1a569d))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x94304=y(_0x1a569d),_0x2699fa=this['children']['get'](_0x94304);if(_0x2699fa){const _0x1dfe5c=_0x2699fa['remove'](b(_0x1a569d));let _0x1d224f;return _0x1dfe5c['isEmpty']()?_0x1d224f=this['children']['remove'](_0x94304):_0x1d224f=this['children']['insert'](_0x94304,_0x1dfe5c),this['value']===null&&_0x1d224f['isEmpty']()?new S(null):new S(this['value'],_0x1d224f);}else return this;}}['get'](_0x363371){if(v(_0x363371))return this['value'];{const _0x469266=y(_0x363371),_0x35ccaa=this['children']['get'](_0x469266);return _0x35ccaa?_0x35ccaa['get'](b(_0x363371)):null;}}['setTree'](_0x37b749,_0x4b842d){if(v(_0x37b749))return _0x4b842d;{const _0x17b15b=y(_0x37b749),_0x422e8b=(this['children']['get'](_0x17b15b)||new S(null))['setTree'](b(_0x37b749),_0x4b842d);let _0x5e87c0;return _0x422e8b['isEmpty']()?_0x5e87c0=this['children']['remove'](_0x17b15b):_0x5e87c0=this['children']['insert'](_0x17b15b,_0x422e8b),new S(this['value'],_0x5e87c0);}}['fold'](_0x130e08){return this['fold_'](w(),_0x130e08);}['fold_'](_0x11bc29,_0x260684){const _0x516c83={};return this['children']['inorderTraversal']((_0xcafdc8,_0x55cd2f)=>{_0x516c83[_0xcafdc8]=_0x55cd2f['fold_'](A(_0x11bc29,_0xcafdc8),_0x260684);}),_0x260684(_0x11bc29,this['value'],_0x516c83);}['findOnPath'](_0x4c5f21,_0x325832){return this['findOnPath_'](_0x4c5f21,w(),_0x325832);}['findOnPath_'](_0x4dd837,_0x53b502,_0x2c546b){const _0x34d566=this['value']?_0x2c546b(_0x53b502,this['value']):!0x1;if(_0x34d566)return _0x34d566;if(v(_0x4dd837))return null;{const _0x346a7e=y(_0x4dd837),_0x235b6f=this['children']['get'](_0x346a7e);return _0x235b6f?_0x235b6f['findOnPath_'](b(_0x4dd837),A(_0x53b502,_0x346a7e),_0x2c546b):null;}}['foreachOnPath'](_0x87bf64,_0x27aace){return this['foreachOnPath_'](_0x87bf64,w(),_0x27aace);}['foreachOnPath_'](_0x11dfd4,_0x52bf17,_0x6e31ac){if(v(_0x11dfd4))return this;{this['value']&&_0x6e31ac(_0x52bf17,this['value']);const _0x2fe68e=y(_0x11dfd4),_0x5d8e91=this['children']['get'](_0x2fe68e);return _0x5d8e91?_0x5d8e91['foreachOnPath_'](b(_0x11dfd4),A(_0x52bf17,_0x2fe68e),_0x6e31ac):new S(null);}}['foreach'](_0x21eac0){this['foreach_'](w(),_0x21eac0);}['foreach_'](_0x377b90,_0x214d77){this['children']['inorderTraversal']((_0x2f9646,_0x225b8d)=>{_0x225b8d['foreach_'](A(_0x377b90,_0x2f9646),_0x214d77);}),this['value']&&_0x214d77(_0x377b90,this['value']);}['foreachChild'](_0x1849ac){this['children']['inorderTraversal']((_0x26dbc1,_0xcd4c10)=>{_0xcd4c10['value']&&_0x1849ac(_0x26dbc1,_0xcd4c10['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x239b56){this['writeTree_']=_0x239b56;}static['empty'](){return new j(new S(null));}}function Ct(_0x38b45f,_0x236c1a,_0xe60201){if(v(_0x236c1a))return new j(new S(_0xe60201));{const _0x159022=_0x38b45f['writeTree_']['findRootMostValueAndPath'](_0x236c1a);if(_0x159022!=null){const _0x1a0a7d=_0x159022['path'];let _0x1c539b=_0x159022['value'];const _0x489322=F(_0x1a0a7d,_0x236c1a);return _0x1c539b=_0x1c539b['updateChild'](_0x489322,_0xe60201),new j(_0x38b45f['writeTree_']['set'](_0x1a0a7d,_0x1c539b));}else{const _0x101609=new S(_0xe60201),_0x47a644=_0x38b45f['writeTree_']['setTree'](_0x236c1a,_0x101609);return new j(_0x47a644);}}}function Ii(_0x181533,_0x547ed1,_0x5e31f4){let _0x58ce23=_0x181533;return x(_0x5e31f4,(_0x317cb9,_0x5aab69)=>{_0x58ce23=Ct(_0x58ce23,A(_0x547ed1,_0x317cb9),_0x5aab69);}),_0x58ce23;}function sr(_0x125c5d,_0x3ad0e4){if(v(_0x3ad0e4))return j['empty']();{const _0x37e632=_0x125c5d['writeTree_']['setTree'](_0x3ad0e4,new S(null));return new j(_0x37e632);}}function wi(_0x2a8309,_0x1a8151){return $e(_0x2a8309,_0x1a8151)!=null;}function $e(_0x3920c4,_0x497b22){const _0x297f4d=_0x3920c4['writeTree_']['findRootMostValueAndPath'](_0x497b22);return _0x297f4d!=null?_0x3920c4['writeTree_']['get'](_0x297f4d['path'])['getChild'](F(_0x297f4d['path'],_0x497b22)):null;}function rr(_0x212ad6){const _0x1bdea1=[],_0x5e8bc7=_0x212ad6['writeTree_']['value'];return _0x5e8bc7!=null?_0x5e8bc7['isLeafNode']()||_0x5e8bc7['forEachChild'](R,(_0x57fbd8,_0x157758)=>{_0x1bdea1['push'](new E(_0x57fbd8,_0x157758));}):_0x212ad6['writeTree_']['children']['inorderTraversal']((_0x3bf0ef,_0x12b4ee)=>{_0x12b4ee['value']!=null&&_0x1bdea1['push'](new E(_0x3bf0ef,_0x12b4ee['value']));}),_0x1bdea1;}function ve(_0x11d5a6,_0x3c254b){if(v(_0x3c254b))return _0x11d5a6;{const _0x4f2a1a=$e(_0x11d5a6,_0x3c254b);return _0x4f2a1a!=null?new j(new S(_0x4f2a1a)):new j(_0x11d5a6['writeTree_']['subtree'](_0x3c254b));}}function Ci(_0x283dda){return _0x283dda['writeTree_']['isEmpty']();}function it(_0x120c5f,_0x55f123){return xo(w(),_0x120c5f['writeTree_'],_0x55f123);}function xo(_0x2539ff,_0x239c9b,_0x2780dc){if(_0x239c9b['value']!=null)return _0x2780dc['updateChild'](_0x2539ff,_0x239c9b['value']);{let _0x3f5978=null;return _0x239c9b['children']['inorderTraversal']((_0x33d8c5,_0x5a61b1)=>{_0x33d8c5==='.priority'?(f(_0x5a61b1['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3f5978=_0x5a61b1['value']):_0x2780dc=xo(A(_0x2539ff,_0x33d8c5),_0x5a61b1,_0x2780dc);}),!_0x2780dc['getChild'](_0x2539ff)['isEmpty']()&&_0x3f5978!==null&&(_0x2780dc=_0x2780dc['updateChild'](A(_0x2539ff,'.priority'),_0x3f5978)),_0x2780dc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x17cdb9,_0x39f143){return Bo(_0x39f143,_0x17cdb9);}function ou(_0x588ebd,_0x3e4516,_0x4ed330,_0x2923e7,_0x1a90fb){f(_0x2923e7>_0x588ebd['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1a90fb===void 0x0&&(_0x1a90fb=!0x0),_0x588ebd['allWrites']['push']({'path':_0x3e4516,'snap':_0x4ed330,'writeId':_0x2923e7,'visible':_0x1a90fb}),_0x1a90fb&&(_0x588ebd['visibleWrites']=Ct(_0x588ebd['visibleWrites'],_0x3e4516,_0x4ed330)),_0x588ebd['lastWriteId']=_0x2923e7;}function au(_0x83289a,_0x3172bc,_0x48a5bc,_0x40b35c){f(_0x40b35c>_0x83289a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x83289a['allWrites']['push']({'path':_0x3172bc,'children':_0x48a5bc,'writeId':_0x40b35c,'visible':!0x0}),_0x83289a['visibleWrites']=Ii(_0x83289a['visibleWrites'],_0x3172bc,_0x48a5bc),_0x83289a['lastWriteId']=_0x40b35c;}function cu(_0x2b9ea1,_0x393a7e){for(let _0x267589=0x0;_0x267589<_0x2b9ea1['allWrites']['length'];_0x267589++){const _0xe6492=_0x2b9ea1['allWrites'][_0x267589];if(_0xe6492['writeId']===_0x393a7e)return _0xe6492;}return null;}function lu(_0x481527,_0x4cccad){const _0xac179d=_0x481527['allWrites']['findIndex'](_0x134ea6=>_0x134ea6['writeId']===_0x4cccad);f(_0xac179d>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x3ff373=_0x481527['allWrites'][_0xac179d];_0x481527['allWrites']['splice'](_0xac179d,0x1);let _0xaedb05=_0x3ff373['visible'],_0xf11697=!0x1,_0x300c7e=_0x481527['allWrites']['length']-0x1;for(;_0xaedb05&&_0x300c7e>=0x0;){const _0x3a5436=_0x481527['allWrites'][_0x300c7e];_0x3a5436['visible']&&(_0x300c7e>=_0xac179d&&hu(_0x3a5436,_0x3ff373['path'])?_0xaedb05=!0x1:$(_0x3ff373['path'],_0x3a5436['path'])&&(_0xf11697=!0x0)),_0x300c7e--;}if(_0xaedb05){if(_0xf11697)return uu(_0x481527),!0x0;if(_0x3ff373['snap'])_0x481527['visibleWrites']=sr(_0x481527['visibleWrites'],_0x3ff373['path']);else{const _0x221261=_0x3ff373['children'];x(_0x221261,_0x363d08=>{_0x481527['visibleWrites']=sr(_0x481527['visibleWrites'],A(_0x3ff373['path'],_0x363d08));});}return!0x0;}else return!0x1;}function hu(_0x38b476,_0x1531c6){if(_0x38b476['snap'])return $(_0x38b476['path'],_0x1531c6);for(const _0x372c0b in _0x38b476['children'])if(_0x38b476['children']['hasOwnProperty'](_0x372c0b)&&$(A(_0x38b476['path'],_0x372c0b),_0x1531c6))return!0x0;return!0x1;}function uu(_0x5f17e5){_0x5f17e5['visibleWrites']=Fo(_0x5f17e5['allWrites'],du,w()),_0x5f17e5['allWrites']['length']>0x0?_0x5f17e5['lastWriteId']=_0x5f17e5['allWrites'][_0x5f17e5['allWrites']['length']-0x1]['writeId']:_0x5f17e5['lastWriteId']=-0x1;}function du(_0x56ae52){return _0x56ae52['visible'];}function Fo(_0x5cefc6,_0x300bc0,_0x347b10){let _0x2d67ad=j['empty']();for(let _0x1dc7b9=0x0;_0x1dc7b9<_0x5cefc6['length'];++_0x1dc7b9){const _0x37c7bf=_0x5cefc6[_0x1dc7b9];if(_0x300bc0(_0x37c7bf)){const _0x1aa196=_0x37c7bf['path'];let _0x2f90f9;if(_0x37c7bf['snap'])$(_0x347b10,_0x1aa196)?(_0x2f90f9=F(_0x347b10,_0x1aa196),_0x2d67ad=Ct(_0x2d67ad,_0x2f90f9,_0x37c7bf['snap'])):$(_0x1aa196,_0x347b10)&&(_0x2f90f9=F(_0x1aa196,_0x347b10),_0x2d67ad=Ct(_0x2d67ad,w(),_0x37c7bf['snap']['getChild'](_0x2f90f9)));else{if(_0x37c7bf['children']){if($(_0x347b10,_0x1aa196))_0x2f90f9=F(_0x347b10,_0x1aa196),_0x2d67ad=Ii(_0x2d67ad,_0x2f90f9,_0x37c7bf['children']);else{if($(_0x1aa196,_0x347b10)){if(_0x2f90f9=F(_0x1aa196,_0x347b10),v(_0x2f90f9))_0x2d67ad=Ii(_0x2d67ad,w(),_0x37c7bf['children']);else{const _0x2507d7=Oe(_0x37c7bf['children'],y(_0x2f90f9));if(_0x2507d7){const _0x33d6b5=_0x2507d7['getChild'](b(_0x2f90f9));_0x2d67ad=Ct(_0x2d67ad,w(),_0x33d6b5);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x2d67ad;}function Uo(_0x4ce563,_0x2aa531,_0x10b84d,_0x181b6d,_0xc4651d){if(!_0x181b6d&&!_0xc4651d){const _0x34aeb4=$e(_0x4ce563['visibleWrites'],_0x2aa531);if(_0x34aeb4!=null)return _0x34aeb4;{const _0x17fc76=ve(_0x4ce563['visibleWrites'],_0x2aa531);if(Ci(_0x17fc76))return _0x10b84d;if(_0x10b84d==null&&!wi(_0x17fc76,w()))return null;{const _0xaa98f8=_0x10b84d||g['EMPTY_NODE'];return it(_0x17fc76,_0xaa98f8);}}}else{const _0x92f61c=ve(_0x4ce563['visibleWrites'],_0x2aa531);if(!_0xc4651d&&Ci(_0x92f61c))return _0x10b84d;if(!_0xc4651d&&_0x10b84d==null&&!wi(_0x92f61c,w()))return null;{const _0x39cf54=function(_0x5a2103){return(_0x5a2103['visible']||_0xc4651d)&&(!_0x181b6d||!~_0x181b6d['indexOf'](_0x5a2103['writeId']))&&($(_0x5a2103['path'],_0x2aa531)||$(_0x2aa531,_0x5a2103['path']));},_0x514232=Fo(_0x4ce563['allWrites'],_0x39cf54,_0x2aa531),_0x2996e4=_0x10b84d||g['EMPTY_NODE'];return it(_0x514232,_0x2996e4);}}}function fu(_0x5162f1,_0x1760cd,_0x251fa1){let _0x2701c7=g['EMPTY_NODE'];const _0x1f04c3=$e(_0x5162f1['visibleWrites'],_0x1760cd);if(_0x1f04c3)return _0x1f04c3['isLeafNode']()||_0x1f04c3['forEachChild'](R,(_0x3d3d19,_0x534352)=>{_0x2701c7=_0x2701c7['updateImmediateChild'](_0x3d3d19,_0x534352);}),_0x2701c7;if(_0x251fa1){const _0x274999=ve(_0x5162f1['visibleWrites'],_0x1760cd);return _0x251fa1['forEachChild'](R,(_0x4a2008,_0x29a0a5)=>{const _0x29242d=it(ve(_0x274999,new C(_0x4a2008)),_0x29a0a5);_0x2701c7=_0x2701c7['updateImmediateChild'](_0x4a2008,_0x29242d);}),rr(_0x274999)['forEach'](_0x10898f=>{_0x2701c7=_0x2701c7['updateImmediateChild'](_0x10898f['name'],_0x10898f['node']);}),_0x2701c7;}else{const _0x437b72=ve(_0x5162f1['visibleWrites'],_0x1760cd);return rr(_0x437b72)['forEach'](_0x594777=>{_0x2701c7=_0x2701c7['updateImmediateChild'](_0x594777['name'],_0x594777['node']);}),_0x2701c7;}}function pu(_0x4aaf40,_0x3ad1e7,_0x385538,_0x4fec35,_0x2ed500){f(_0x4fec35||_0x2ed500,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x22f0e4=A(_0x3ad1e7,_0x385538);if(wi(_0x4aaf40['visibleWrites'],_0x22f0e4))return null;{const _0x42b043=ve(_0x4aaf40['visibleWrites'],_0x22f0e4);return Ci(_0x42b043)?_0x2ed500['getChild'](_0x385538):it(_0x42b043,_0x2ed500['getChild'](_0x385538));}}function _u(_0x1a1ef6,_0x3a23f6,_0x59efe7,_0x162c20){const _0x4fbb25=A(_0x3a23f6,_0x59efe7),_0x59d4d3=$e(_0x1a1ef6['visibleWrites'],_0x4fbb25);if(_0x59d4d3!=null)return _0x59d4d3;if(_0x162c20['isCompleteForChild'](_0x59efe7)){const _0xb3dc38=ve(_0x1a1ef6['visibleWrites'],_0x4fbb25);return it(_0xb3dc38,_0x162c20['getNode']()['getImmediateChild'](_0x59efe7));}else return null;}function gu(_0xb4cc8c,_0x1e37dc){return $e(_0xb4cc8c['visibleWrites'],_0x1e37dc);}function mu(_0x5d95ee,_0xf3d859,_0x33b241,_0x49759a,_0x7534f2,_0x279104,_0x2cdb2d){let _0x520fe7;const _0x5ec93a=ve(_0x5d95ee['visibleWrites'],_0xf3d859),_0x54845c=$e(_0x5ec93a,w());if(_0x54845c!=null)_0x520fe7=_0x54845c;else{if(_0x33b241!=null)_0x520fe7=it(_0x5ec93a,_0x33b241);else return[];}if(_0x520fe7=_0x520fe7['withIndex'](_0x2cdb2d),!_0x520fe7['isEmpty']()&&!_0x520fe7['isLeafNode']()){const _0x3ff891=[],_0x214c07=_0x2cdb2d['getCompare'](),_0x985853=_0x279104?_0x520fe7['getReverseIteratorFrom'](_0x49759a,_0x2cdb2d):_0x520fe7['getIteratorFrom'](_0x49759a,_0x2cdb2d);let _0x5ac387=_0x985853['getNext']();for(;_0x5ac387&&_0x3ff891['length']<_0x7534f2;)_0x214c07(_0x5ac387,_0x49759a)!==0x0&&_0x3ff891['push'](_0x5ac387),_0x5ac387=_0x985853['getNext']();return _0x3ff891;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x7ec583,_0x1e5eee,_0x3073eb,_0x2ae7bb){return Uo(_0x7ec583['writeTree'],_0x7ec583['treePath'],_0x1e5eee,_0x3073eb,_0x2ae7bb);}function es(_0x5d8b52,_0x5010fa){return fu(_0x5d8b52['writeTree'],_0x5d8b52['treePath'],_0x5010fa);}function or(_0x50f51d,_0x469d9a,_0x9b5214,_0x1c7421){return pu(_0x50f51d['writeTree'],_0x50f51d['treePath'],_0x469d9a,_0x9b5214,_0x1c7421);}function yn(_0x27743a,_0x197aa1){return gu(_0x27743a['writeTree'],A(_0x27743a['treePath'],_0x197aa1));}function vu(_0x265d8d,_0x50a516,_0x10f60f,_0x2c878c,_0xbe4905,_0x16d10c){return mu(_0x265d8d['writeTree'],_0x265d8d['treePath'],_0x50a516,_0x10f60f,_0x2c878c,_0xbe4905,_0x16d10c);}function ts(_0x4c93d6,_0x588c98,_0x4f9d85){return _u(_0x4c93d6['writeTree'],_0x4c93d6['treePath'],_0x588c98,_0x4f9d85);}function Wo(_0x285264,_0xc57b12){return Bo(A(_0x285264['treePath'],_0xc57b12),_0x285264['writeTree']);}function Bo(_0x16871d,_0x3113bd){return{'treePath':_0x16871d,'writeTree':_0x3113bd};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x320175){const _0x4d29db=_0x320175['type'],_0xb2e28=_0x320175['childName'];f(_0x4d29db==='child_added'||_0x4d29db==='child_changed'||_0x4d29db==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xb2e28!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2e2d5f=this['changeMap']['get'](_0xb2e28);if(_0x2e2d5f){const _0x4e0531=_0x2e2d5f['type'];if(_0x4d29db==='child_added'&&_0x4e0531==='child_removed')this['changeMap']['set'](_0xb2e28,Pt(_0xb2e28,_0x320175['snapshotNode'],_0x2e2d5f['snapshotNode']));else{if(_0x4d29db==='child_removed'&&_0x4e0531==='child_added')this['changeMap']['delete'](_0xb2e28);else{if(_0x4d29db==='child_removed'&&_0x4e0531==='child_changed')this['changeMap']['set'](_0xb2e28,Nt(_0xb2e28,_0x2e2d5f['oldSnap']));else{if(_0x4d29db==='child_changed'&&_0x4e0531==='child_added')this['changeMap']['set'](_0xb2e28,tt(_0xb2e28,_0x320175['snapshotNode']));else{if(_0x4d29db==='child_changed'&&_0x4e0531==='child_changed')this['changeMap']['set'](_0xb2e28,Pt(_0xb2e28,_0x320175['snapshotNode'],_0x2e2d5f['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x320175+'\x20occurred\x20after\x20'+_0x2e2d5f);}}}}}else this['changeMap']['set'](_0xb2e28,_0x320175);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x46b1b2){return null;}['getChildAfterChild'](_0x164b72,_0x2225e4,_0x1dc980){return null;}}const Vo=new Iu();class ns{constructor(_0x59d7f9,_0x48218f,_0x3903cc=null){this['writes_']=_0x59d7f9,this['viewCache_']=_0x48218f,this['optCompleteServerCache_']=_0x3903cc;}['getCompleteChild'](_0x5105a0){const _0x39482f=this['viewCache_']['eventCache'];if(_0x39482f['isCompleteForChild'](_0x5105a0))return _0x39482f['getNode']()['getImmediateChild'](_0x5105a0);{const _0x53a4cd=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x5105a0,_0x53a4cd);}}['getChildAfterChild'](_0x5c18ee,_0x1c78f4,_0x1d711a){const _0x42027c=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x1c0bab=vu(this['writes_'],_0x42027c,_0x1c78f4,0x1,_0x1d711a,_0x5c18ee);return _0x1c0bab['length']===0x0?null:_0x1c0bab[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x3d24c2){return{'filter':_0x3d24c2};}function Cu(_0x16c426,_0xdbf9a6){f(_0xdbf9a6['eventCache']['getNode']()['isIndexed'](_0x16c426['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xdbf9a6['serverCache']['getNode']()['isIndexed'](_0x16c426['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x1eef2f,_0x33ecca,_0x4dccbe,_0x38c2e4,_0x49d172){const _0x37434f=new Eu();let _0x14b45f,_0xd88d87;if(_0x4dccbe['type']===q['OVERWRITE']){const _0x14bdfc=_0x4dccbe;_0x14bdfc['source']['fromUser']?_0x14b45f=Ti(_0x1eef2f,_0x33ecca,_0x14bdfc['path'],_0x14bdfc['snap'],_0x38c2e4,_0x49d172,_0x37434f):(f(_0x14bdfc['source']['fromServer'],'Unknown\x20source.'),_0xd88d87=_0x14bdfc['source']['tagged']||_0x33ecca['serverCache']['isFiltered']()&&!v(_0x14bdfc['path']),_0x14b45f=vn(_0x1eef2f,_0x33ecca,_0x14bdfc['path'],_0x14bdfc['snap'],_0x38c2e4,_0x49d172,_0xd88d87,_0x37434f));}else{if(_0x4dccbe['type']===q['MERGE']){const _0x20f5c6=_0x4dccbe;_0x20f5c6['source']['fromUser']?_0x14b45f=bu(_0x1eef2f,_0x33ecca,_0x20f5c6['path'],_0x20f5c6['children'],_0x38c2e4,_0x49d172,_0x37434f):(f(_0x20f5c6['source']['fromServer'],'Unknown\x20source.'),_0xd88d87=_0x20f5c6['source']['tagged']||_0x33ecca['serverCache']['isFiltered'](),_0x14b45f=Si(_0x1eef2f,_0x33ecca,_0x20f5c6['path'],_0x20f5c6['children'],_0x38c2e4,_0x49d172,_0xd88d87,_0x37434f));}else{if(_0x4dccbe['type']===q['ACK_USER_WRITE']){const _0x450694=_0x4dccbe;_0x450694['revert']?_0x14b45f=ku(_0x1eef2f,_0x33ecca,_0x450694['path'],_0x38c2e4,_0x49d172,_0x37434f):_0x14b45f=Ru(_0x1eef2f,_0x33ecca,_0x450694['path'],_0x450694['affectedTree'],_0x38c2e4,_0x49d172,_0x37434f);}else{if(_0x4dccbe['type']===q['LISTEN_COMPLETE'])_0x14b45f=Au(_0x1eef2f,_0x33ecca,_0x4dccbe['path'],_0x38c2e4,_0x37434f);else throw ot('Unknown\x20operation\x20type:\x20'+_0x4dccbe['type']);}}}const _0x3a58c4=_0x37434f['getChanges']();return Su(_0x33ecca,_0x14b45f,_0x3a58c4),{'viewCache':_0x14b45f,'changes':_0x3a58c4};}function Su(_0x494d93,_0x243b5c,_0x3947fb){const _0x886fd8=_0x243b5c['eventCache'];if(_0x886fd8['isFullyInitialized']()){const _0x2d49f2=_0x886fd8['getNode']()['isLeafNode']()||_0x886fd8['getNode']()['isEmpty'](),_0xfe35e3=gn(_0x494d93);(_0x3947fb['length']>0x0||!_0x494d93['eventCache']['isFullyInitialized']()||_0x2d49f2&&!_0x886fd8['getNode']()['equals'](_0xfe35e3)||!_0x886fd8['getNode']()['getPriority']()['equals'](_0xfe35e3['getPriority']()))&&_0x3947fb['push'](Oo(gn(_0x243b5c)));}}function Ho(_0x13a71f,_0x127051,_0x146004,_0xdb705e,_0x442c7a,_0x45fb52){const _0x77be65=_0x127051['eventCache'];if(yn(_0xdb705e,_0x146004)!=null)return _0x127051;{let _0x166b24,_0x3bed58;if(v(_0x146004)){if(f(_0x127051['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x127051['serverCache']['isFiltered']()){const _0x49bdca=Ue(_0x127051),_0x2bb149=_0x49bdca instanceof g?_0x49bdca:g['EMPTY_NODE'],_0x3675ec=es(_0xdb705e,_0x2bb149);_0x166b24=_0x13a71f['filter']['updateFullNode'](_0x127051['eventCache']['getNode'](),_0x3675ec,_0x45fb52);}else{const _0xf413d5=mn(_0xdb705e,Ue(_0x127051));_0x166b24=_0x13a71f['filter']['updateFullNode'](_0x127051['eventCache']['getNode'](),_0xf413d5,_0x45fb52);}}else{const _0x360c4c=y(_0x146004);if(_0x360c4c==='.priority'){f(we(_0x146004)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4c7a50=_0x77be65['getNode']();_0x3bed58=_0x127051['serverCache']['getNode']();const _0x5929bd=or(_0xdb705e,_0x146004,_0x4c7a50,_0x3bed58);_0x5929bd!=null?_0x166b24=_0x13a71f['filter']['updatePriority'](_0x4c7a50,_0x5929bd):_0x166b24=_0x77be65['getNode']();}else{const _0x2c33d1=b(_0x146004);let _0x174dbd;if(_0x77be65['isCompleteForChild'](_0x360c4c)){_0x3bed58=_0x127051['serverCache']['getNode']();const _0x1164ec=or(_0xdb705e,_0x146004,_0x77be65['getNode'](),_0x3bed58);_0x1164ec!=null?_0x174dbd=_0x77be65['getNode']()['getImmediateChild'](_0x360c4c)['updateChild'](_0x2c33d1,_0x1164ec):_0x174dbd=_0x77be65['getNode']()['getImmediateChild'](_0x360c4c);}else _0x174dbd=ts(_0xdb705e,_0x360c4c,_0x127051['serverCache']);_0x174dbd!=null?_0x166b24=_0x13a71f['filter']['updateChild'](_0x77be65['getNode'](),_0x360c4c,_0x174dbd,_0x2c33d1,_0x442c7a,_0x45fb52):_0x166b24=_0x77be65['getNode']();}}return wt(_0x127051,_0x166b24,_0x77be65['isFullyInitialized']()||v(_0x146004),_0x13a71f['filter']['filtersNodes']());}}function vn(_0x2958a1,_0x2673bf,_0x3276d4,_0x48dc2b,_0x273d8f,_0x35bc36,_0x412bc4,_0x33523b){const _0x2d40b5=_0x2673bf['serverCache'];let _0x16b052;const _0x22f6cf=_0x412bc4?_0x2958a1['filter']:_0x2958a1['filter']['getIndexedFilter']();if(v(_0x3276d4))_0x16b052=_0x22f6cf['updateFullNode'](_0x2d40b5['getNode'](),_0x48dc2b,null);else{if(_0x22f6cf['filtersNodes']()&&!_0x2d40b5['isFiltered']()){const _0x2ee4c7=_0x2d40b5['getNode']()['updateChild'](_0x3276d4,_0x48dc2b);_0x16b052=_0x22f6cf['updateFullNode'](_0x2d40b5['getNode'](),_0x2ee4c7,null);}else{const _0xa34dab=y(_0x3276d4);if(!_0x2d40b5['isCompleteForPath'](_0x3276d4)&&we(_0x3276d4)>0x1)return _0x2673bf;const _0x57a201=b(_0x3276d4),_0x4e213f=_0x2d40b5['getNode']()['getImmediateChild'](_0xa34dab)['updateChild'](_0x57a201,_0x48dc2b);_0xa34dab==='.priority'?_0x16b052=_0x22f6cf['updatePriority'](_0x2d40b5['getNode'](),_0x4e213f):_0x16b052=_0x22f6cf['updateChild'](_0x2d40b5['getNode'](),_0xa34dab,_0x4e213f,_0x57a201,Vo,null);}}const _0xc81222=Lo(_0x2673bf,_0x16b052,_0x2d40b5['isFullyInitialized']()||v(_0x3276d4),_0x22f6cf['filtersNodes']()),_0x34cf6f=new ns(_0x273d8f,_0xc81222,_0x35bc36);return Ho(_0x2958a1,_0xc81222,_0x3276d4,_0x273d8f,_0x34cf6f,_0x33523b);}function Ti(_0x101376,_0x35e436,_0x393359,_0x28357c,_0x5624f8,_0x3c2925,_0x36e2b2){const _0x17dbb6=_0x35e436['eventCache'];let _0x3ebe39,_0xa004f1;const _0x565dab=new ns(_0x5624f8,_0x35e436,_0x3c2925);if(v(_0x393359))_0xa004f1=_0x101376['filter']['updateFullNode'](_0x35e436['eventCache']['getNode'](),_0x28357c,_0x36e2b2),_0x3ebe39=wt(_0x35e436,_0xa004f1,!0x0,_0x101376['filter']['filtersNodes']());else{const _0x1b3a21=y(_0x393359);if(_0x1b3a21==='.priority')_0xa004f1=_0x101376['filter']['updatePriority'](_0x35e436['eventCache']['getNode'](),_0x28357c),_0x3ebe39=wt(_0x35e436,_0xa004f1,_0x17dbb6['isFullyInitialized'](),_0x17dbb6['isFiltered']());else{const _0x504f06=b(_0x393359),_0x250086=_0x17dbb6['getNode']()['getImmediateChild'](_0x1b3a21);let _0x132ab5;if(v(_0x504f06))_0x132ab5=_0x28357c;else{const _0x23f217=_0x565dab['getCompleteChild'](_0x1b3a21);_0x23f217!=null?Gi(_0x504f06)==='.priority'&&_0x23f217['getChild'](To(_0x504f06))['isEmpty']()?_0x132ab5=_0x23f217:_0x132ab5=_0x23f217['updateChild'](_0x504f06,_0x28357c):_0x132ab5=g['EMPTY_NODE'];}if(_0x250086['equals'](_0x132ab5))_0x3ebe39=_0x35e436;else{const _0x1e85dd=_0x101376['filter']['updateChild'](_0x17dbb6['getNode'](),_0x1b3a21,_0x132ab5,_0x504f06,_0x565dab,_0x36e2b2);_0x3ebe39=wt(_0x35e436,_0x1e85dd,_0x17dbb6['isFullyInitialized'](),_0x101376['filter']['filtersNodes']());}}}return _0x3ebe39;}function ar(_0x5d8dcb,_0x527395){return _0x5d8dcb['eventCache']['isCompleteForChild'](_0x527395);}function bu(_0x195a53,_0x1808a0,_0x3627a0,_0x4232c2,_0x547cde,_0x1b6731,_0xc13382){let _0x45bd13=_0x1808a0;return _0x4232c2['foreach']((_0x26da55,_0x552769)=>{const _0x45a0f1=A(_0x3627a0,_0x26da55);ar(_0x1808a0,y(_0x45a0f1))&&(_0x45bd13=Ti(_0x195a53,_0x45bd13,_0x45a0f1,_0x552769,_0x547cde,_0x1b6731,_0xc13382));}),_0x4232c2['foreach']((_0x8c20eb,_0x5d79c3)=>{const _0x29f742=A(_0x3627a0,_0x8c20eb);ar(_0x1808a0,y(_0x29f742))||(_0x45bd13=Ti(_0x195a53,_0x45bd13,_0x29f742,_0x5d79c3,_0x547cde,_0x1b6731,_0xc13382));}),_0x45bd13;}function cr(_0x4b2b84,_0x5e1d66,_0x3accdd){return _0x3accdd['foreach']((_0x2a906a,_0x149f83)=>{_0x5e1d66=_0x5e1d66['updateChild'](_0x2a906a,_0x149f83);}),_0x5e1d66;}function Si(_0x255915,_0x40af62,_0x2b51e2,_0x1fed40,_0x2f1181,_0x3e6d71,_0x5effdb,_0x3b0110){if(_0x40af62['serverCache']['getNode']()['isEmpty']()&&!_0x40af62['serverCache']['isFullyInitialized']())return _0x40af62;let _0x2e52e2=_0x40af62,_0x1fdbe0;v(_0x2b51e2)?_0x1fdbe0=_0x1fed40:_0x1fdbe0=new S(null)['setTree'](_0x2b51e2,_0x1fed40);const _0x1a69a3=_0x40af62['serverCache']['getNode']();return _0x1fdbe0['children']['inorderTraversal']((_0x4d9bd4,_0x411d74)=>{if(_0x1a69a3['hasChild'](_0x4d9bd4)){const _0x225b6e=_0x40af62['serverCache']['getNode']()['getImmediateChild'](_0x4d9bd4),_0x336688=cr(_0x255915,_0x225b6e,_0x411d74);_0x2e52e2=vn(_0x255915,_0x2e52e2,new C(_0x4d9bd4),_0x336688,_0x2f1181,_0x3e6d71,_0x5effdb,_0x3b0110);}}),_0x1fdbe0['children']['inorderTraversal']((_0xc030ac,_0xa87d04)=>{const _0x545af4=!_0x40af62['serverCache']['isCompleteForChild'](_0xc030ac)&&_0xa87d04['value']===null;if(!_0x1a69a3['hasChild'](_0xc030ac)&&!_0x545af4){const _0x39a1c3=_0x40af62['serverCache']['getNode']()['getImmediateChild'](_0xc030ac),_0x47e4ed=cr(_0x255915,_0x39a1c3,_0xa87d04);_0x2e52e2=vn(_0x255915,_0x2e52e2,new C(_0xc030ac),_0x47e4ed,_0x2f1181,_0x3e6d71,_0x5effdb,_0x3b0110);}}),_0x2e52e2;}function Ru(_0x32359c,_0x5b1ffc,_0x93f91f,_0x4f029e,_0xd3fd9,_0x3a45fe,_0x356b43){if(yn(_0xd3fd9,_0x93f91f)!=null)return _0x5b1ffc;const _0xeceb34=_0x5b1ffc['serverCache']['isFiltered'](),_0x2e3f78=_0x5b1ffc['serverCache'];if(_0x4f029e['value']!=null){if(v(_0x93f91f)&&_0x2e3f78['isFullyInitialized']()||_0x2e3f78['isCompleteForPath'](_0x93f91f))return vn(_0x32359c,_0x5b1ffc,_0x93f91f,_0x2e3f78['getNode']()['getChild'](_0x93f91f),_0xd3fd9,_0x3a45fe,_0xeceb34,_0x356b43);if(v(_0x93f91f)){let _0x14f7e3=new S(null);return _0x2e3f78['getNode']()['forEachChild'](ye,(_0xf65c7c,_0x1c78b8)=>{_0x14f7e3=_0x14f7e3['set'](new C(_0xf65c7c),_0x1c78b8);}),Si(_0x32359c,_0x5b1ffc,_0x93f91f,_0x14f7e3,_0xd3fd9,_0x3a45fe,_0xeceb34,_0x356b43);}else return _0x5b1ffc;}else{let _0x356ef1=new S(null);return _0x4f029e['foreach']((_0x324d5e,_0x2af338)=>{const _0x1e35b8=A(_0x93f91f,_0x324d5e);_0x2e3f78['isCompleteForPath'](_0x1e35b8)&&(_0x356ef1=_0x356ef1['set'](_0x324d5e,_0x2e3f78['getNode']()['getChild'](_0x1e35b8)));}),Si(_0x32359c,_0x5b1ffc,_0x93f91f,_0x356ef1,_0xd3fd9,_0x3a45fe,_0xeceb34,_0x356b43);}}function Au(_0x57ed3a,_0x36c91d,_0x24d97b,_0x57bd82,_0x247ee6){const _0x236bb2=_0x36c91d['serverCache'],_0x1fcd19=Lo(_0x36c91d,_0x236bb2['getNode'](),_0x236bb2['isFullyInitialized']()||v(_0x24d97b),_0x236bb2['isFiltered']());return Ho(_0x57ed3a,_0x1fcd19,_0x24d97b,_0x57bd82,Vo,_0x247ee6);}function ku(_0x4d5fd5,_0x9596cb,_0x366e81,_0x51ebe5,_0x4fd458,_0x1605e3){let _0x4ff15a;if(yn(_0x51ebe5,_0x366e81)!=null)return _0x9596cb;{const _0x27e5ce=new ns(_0x51ebe5,_0x9596cb,_0x4fd458),_0x3d2c8c=_0x9596cb['eventCache']['getNode']();let _0x1df9ee;if(v(_0x366e81)||y(_0x366e81)==='.priority'){let _0x1e1200;if(_0x9596cb['serverCache']['isFullyInitialized']())_0x1e1200=mn(_0x51ebe5,Ue(_0x9596cb));else{const _0x390071=_0x9596cb['serverCache']['getNode']();f(_0x390071 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1e1200=es(_0x51ebe5,_0x390071);}_0x1e1200=_0x1e1200,_0x1df9ee=_0x4d5fd5['filter']['updateFullNode'](_0x3d2c8c,_0x1e1200,_0x1605e3);}else{const _0x39f542=y(_0x366e81);let _0x455552=ts(_0x51ebe5,_0x39f542,_0x9596cb['serverCache']);_0x455552==null&&_0x9596cb['serverCache']['isCompleteForChild'](_0x39f542)&&(_0x455552=_0x3d2c8c['getImmediateChild'](_0x39f542)),_0x455552!=null?_0x1df9ee=_0x4d5fd5['filter']['updateChild'](_0x3d2c8c,_0x39f542,_0x455552,b(_0x366e81),_0x27e5ce,_0x1605e3):_0x9596cb['eventCache']['getNode']()['hasChild'](_0x39f542)?_0x1df9ee=_0x4d5fd5['filter']['updateChild'](_0x3d2c8c,_0x39f542,g['EMPTY_NODE'],b(_0x366e81),_0x27e5ce,_0x1605e3):_0x1df9ee=_0x3d2c8c,_0x1df9ee['isEmpty']()&&_0x9596cb['serverCache']['isFullyInitialized']()&&(_0x4ff15a=mn(_0x51ebe5,Ue(_0x9596cb)),_0x4ff15a['isLeafNode']()&&(_0x1df9ee=_0x4d5fd5['filter']['updateFullNode'](_0x1df9ee,_0x4ff15a,_0x1605e3)));}return _0x4ff15a=_0x9596cb['serverCache']['isFullyInitialized']()||yn(_0x51ebe5,w())!=null,wt(_0x9596cb,_0x1df9ee,_0x4ff15a,_0x4d5fd5['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x1fb05a,_0x1e9dc7){this['query_']=_0x1fb05a,this['eventRegistrations_']=[];const _0x3f7894=this['query_']['_queryParams'],_0x473828=new Yi(_0x3f7894['getIndex']()),_0xa7b3f9=qh(_0x3f7894);this['processor_']=wu(_0xa7b3f9);const _0x880327=_0x1e9dc7['serverCache'],_0x3ba1b8=_0x1e9dc7['eventCache'],_0x3d0b10=_0x473828['updateFullNode'](g['EMPTY_NODE'],_0x880327['getNode'](),null),_0xb20a63=_0xa7b3f9['updateFullNode'](g['EMPTY_NODE'],_0x3ba1b8['getNode'](),null),_0x424b92=new Ce(_0x3d0b10,_0x880327['isFullyInitialized'](),_0x473828['filtersNodes']()),_0x333241=new Ce(_0xb20a63,_0x3ba1b8['isFullyInitialized'](),_0xa7b3f9['filtersNodes']());this['viewCache_']=Dn(_0x333241,_0x424b92),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x1f26a4){return _0x1f26a4['viewCache_']['serverCache']['getNode']();}function Ou(_0x37ccc6){return gn(_0x37ccc6['viewCache_']);}function Du(_0x2dee87,_0x5e68e5){const _0x32c40e=Ue(_0x2dee87['viewCache_']);return _0x32c40e&&(_0x2dee87['query']['_queryParams']['loadsAllData']()||!v(_0x5e68e5)&&!_0x32c40e['getImmediateChild'](y(_0x5e68e5))['isEmpty']())?_0x32c40e['getChild'](_0x5e68e5):null;}function lr(_0x5f1a91){return _0x5f1a91['eventRegistrations_']['length']===0x0;}function Mu(_0xcc62a4,_0x2a6051){_0xcc62a4['eventRegistrations_']['push'](_0x2a6051);}function hr(_0x5a13a7,_0x4f3c0d,_0x40e10d){const _0x45feda=[];if(_0x40e10d){f(_0x4f3c0d==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x166253=_0x5a13a7['query']['_path'];_0x5a13a7['eventRegistrations_']['forEach'](_0x3522bd=>{const _0x58fc64=_0x3522bd['createCancelEvent'](_0x40e10d,_0x166253);_0x58fc64&&_0x45feda['push'](_0x58fc64);});}if(_0x4f3c0d){let _0x3f2723=[];for(let _0xc87dea=0x0;_0xc87dea<_0x5a13a7['eventRegistrations_']['length'];++_0xc87dea){const _0x32080a=_0x5a13a7['eventRegistrations_'][_0xc87dea];if(!_0x32080a['matches'](_0x4f3c0d))_0x3f2723['push'](_0x32080a);else{if(_0x4f3c0d['hasAnyCallback']()){_0x3f2723=_0x3f2723['concat'](_0x5a13a7['eventRegistrations_']['slice'](_0xc87dea+0x1));break;}}}_0x5a13a7['eventRegistrations_']=_0x3f2723;}else _0x5a13a7['eventRegistrations_']=[];return _0x45feda;}function ur(_0x348d06,_0x4ff1b5,_0x575036,_0x4f5b3e){_0x4ff1b5['type']===q['MERGE']&&_0x4ff1b5['source']['queryId']!==null&&(f(Ue(_0x348d06['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x348d06['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x573747=_0x348d06['viewCache_'],_0x4292ca=Tu(_0x348d06['processor_'],_0x573747,_0x4ff1b5,_0x575036,_0x4f5b3e);return Cu(_0x348d06['processor_'],_0x4292ca['viewCache']),f(_0x4292ca['viewCache']['serverCache']['isFullyInitialized']()||!_0x573747['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x348d06['viewCache_']=_0x4292ca['viewCache'],$o(_0x348d06,_0x4292ca['changes'],_0x4292ca['viewCache']['eventCache']['getNode'](),null);}function Lu(_0xe6f6bd,_0x3c6379){const _0x1989ad=_0xe6f6bd['viewCache_']['eventCache'],_0x4990b5=[];return _0x1989ad['getNode']()['isLeafNode']()||_0x1989ad['getNode']()['forEachChild'](R,(_0x40fa13,_0x38d7cc)=>{_0x4990b5['push'](tt(_0x40fa13,_0x38d7cc));}),_0x1989ad['isFullyInitialized']()&&_0x4990b5['push'](Oo(_0x1989ad['getNode']())),$o(_0xe6f6bd,_0x4990b5,_0x1989ad['getNode'](),_0x3c6379);}function $o(_0x1601f0,_0x260e56,_0x30e039,_0x3d56a3){const _0x17b29f=_0x3d56a3?[_0x3d56a3]:_0x1601f0['eventRegistrations_'];return nu(_0x1601f0['eventGenerator_'],_0x260e56,_0x30e039,_0x17b29f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x2f5787){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x2f5787;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x1ad526){return _0x1ad526['views']['size']===0x0;}function is(_0x478355,_0x3231c2,_0x485565,_0x452032){const _0x371b37=_0x3231c2['source']['queryId'];if(_0x371b37!==null){const _0x367780=_0x478355['views']['get'](_0x371b37);return f(_0x367780!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x367780,_0x3231c2,_0x485565,_0x452032);}else{let _0x54dcae=[];for(const _0x524b2a of _0x478355['views']['values']())_0x54dcae=_0x54dcae['concat'](ur(_0x524b2a,_0x3231c2,_0x485565,_0x452032));return _0x54dcae;}}function qo(_0x4bd8f7,_0x381786,_0x268a0a,_0x534cff,_0x44d3f0){const _0x4473bc=_0x381786['_queryIdentifier'],_0x2f4ebe=_0x4bd8f7['views']['get'](_0x4473bc);if(!_0x2f4ebe){let _0x5e1674=mn(_0x268a0a,_0x44d3f0?_0x534cff:null),_0x3a2114=!0x1;_0x5e1674?_0x3a2114=!0x0:_0x534cff instanceof g?(_0x5e1674=es(_0x268a0a,_0x534cff),_0x3a2114=!0x1):(_0x5e1674=g['EMPTY_NODE'],_0x3a2114=!0x1);const _0x596327=Dn(new Ce(_0x5e1674,_0x3a2114,!0x1),new Ce(_0x534cff,_0x44d3f0,!0x1));return new Nu(_0x381786,_0x596327);}return _0x2f4ebe;}function Wu(_0x2a11b0,_0x56df37,_0x2d86f1,_0x52a2fc,_0x1ccd93,_0x3f79f1){const _0x21f660=qo(_0x2a11b0,_0x56df37,_0x52a2fc,_0x1ccd93,_0x3f79f1);return _0x2a11b0['views']['has'](_0x56df37['_queryIdentifier'])||_0x2a11b0['views']['set'](_0x56df37['_queryIdentifier'],_0x21f660),Mu(_0x21f660,_0x2d86f1),Lu(_0x21f660,_0x2d86f1);}function Bu(_0x27d2ac,_0x217856,_0x5362a2,_0x5de625){const _0xc081=_0x217856['_queryIdentifier'],_0x2735e7=[];let _0x3aa508=[];const _0x557ed8=Te(_0x27d2ac);if(_0xc081==='default'){for(const [_0x3feae8,_0x36230f]of _0x27d2ac['views']['entries']())_0x3aa508=_0x3aa508['concat'](hr(_0x36230f,_0x5362a2,_0x5de625)),lr(_0x36230f)&&(_0x27d2ac['views']['delete'](_0x3feae8),_0x36230f['query']['_queryParams']['loadsAllData']()||_0x2735e7['push'](_0x36230f['query']));}else{const _0x230735=_0x27d2ac['views']['get'](_0xc081);_0x230735&&(_0x3aa508=_0x3aa508['concat'](hr(_0x230735,_0x5362a2,_0x5de625)),lr(_0x230735)&&(_0x27d2ac['views']['delete'](_0xc081),_0x230735['query']['_queryParams']['loadsAllData']()||_0x2735e7['push'](_0x230735['query'])));}return _0x557ed8&&!Te(_0x27d2ac)&&_0x2735e7['push'](new(Fu())(_0x217856['_repo'],_0x217856['_path'])),{'removed':_0x2735e7,'events':_0x3aa508};}function zo(_0x249840){const _0x2ebd20=[];for(const _0x6057eb of _0x249840['views']['values']())_0x6057eb['query']['_queryParams']['loadsAllData']()||_0x2ebd20['push'](_0x6057eb);return _0x2ebd20;}function Ee(_0x55b8e0,_0x2567ca){let _0x580f71=null;for(const _0x4049dd of _0x55b8e0['views']['values']())_0x580f71=_0x580f71||Du(_0x4049dd,_0x2567ca);return _0x580f71;}function jo(_0x470bcb,_0xbb673b){if(_0xbb673b['_queryParams']['loadsAllData']())return Ln(_0x470bcb);{const _0x3718fc=_0xbb673b['_queryIdentifier'];return _0x470bcb['views']['get'](_0x3718fc);}}function Ko(_0x3d6ada,_0xf8a09a){return jo(_0x3d6ada,_0xf8a09a)!=null;}function Te(_0x98dfd8){return Ln(_0x98dfd8)!=null;}function Ln(_0xccd0f3){for(const _0x2e9991 of _0xccd0f3['views']['values']())if(_0x2e9991['query']['_queryParams']['loadsAllData']())return _0x2e9991;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x17e3ff){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x17e3ff;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x26c7a5){this['listenProvider_']=_0x26c7a5,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x2ab706,_0x4c348e,_0x3b7807,_0x26fcc1,_0x39b44a){return ou(_0x2ab706['pendingWriteTree_'],_0x4c348e,_0x3b7807,_0x26fcc1,_0x39b44a),_0x39b44a?ht(_0x2ab706,new Fe(Ji(),_0x4c348e,_0x3b7807)):[];}function Gu(_0x34ee04,_0x492153,_0x3c43c5,_0x5407dc){au(_0x34ee04['pendingWriteTree_'],_0x492153,_0x3c43c5,_0x5407dc);const _0x6eb9d=S['fromObject'](_0x3c43c5);return ht(_0x34ee04,new nt(Ji(),_0x492153,_0x6eb9d));}function pe(_0x4c274a,_0x4f1597,_0xf60030=!0x1){const _0x1e064d=cu(_0x4c274a['pendingWriteTree_'],_0x4f1597);if(lu(_0x4c274a['pendingWriteTree_'],_0x4f1597)){let _0x2652bf=new S(null);return _0x1e064d['snap']!=null?_0x2652bf=_0x2652bf['set'](w(),!0x0):x(_0x1e064d['children'],_0x3ff57f=>{_0x2652bf=_0x2652bf['set'](new C(_0x3ff57f),!0x0);}),ht(_0x4c274a,new _n(_0x1e064d['path'],_0x2652bf,_0xf60030));}else return[];}function $t(_0x56c284,_0x5c5395,_0x3355bd){return ht(_0x56c284,new Fe(Xi(),_0x5c5395,_0x3355bd));}function qu(_0x2b69b6,_0x4e6578,_0x84d10c){const _0x43a225=S['fromObject'](_0x84d10c);return ht(_0x2b69b6,new nt(Xi(),_0x4e6578,_0x43a225));}function zu(_0x558b70,_0x2bfd18){return ht(_0x558b70,new Dt(Xi(),_0x2bfd18));}function ju(_0x50d23b,_0x48699f,_0xc16f0b){const _0x4405bd=rs(_0x50d23b,_0xc16f0b);if(_0x4405bd){const _0x54a7a4=os(_0x4405bd),_0x85bc96=_0x54a7a4['path'],_0x41160f=_0x54a7a4['queryId'],_0x173bbf=F(_0x85bc96,_0x48699f),_0x345260=new Dt(Zi(_0x41160f),_0x173bbf);return as(_0x50d23b,_0x85bc96,_0x345260);}else return[];}function wn(_0x3f1ad8,_0x4e1f7a,_0x46d4bc,_0x341094,_0x314605=!0x1){const _0x3455e6=_0x4e1f7a['_path'],_0x5812a6=_0x3f1ad8['syncPointTree_']['get'](_0x3455e6);let _0xdfaebb=[];if(_0x5812a6&&(_0x4e1f7a['_queryIdentifier']==='default'||Ko(_0x5812a6,_0x4e1f7a))){const _0x2da337=Bu(_0x5812a6,_0x4e1f7a,_0x46d4bc,_0x341094);Uu(_0x5812a6)&&(_0x3f1ad8['syncPointTree_']=_0x3f1ad8['syncPointTree_']['remove'](_0x3455e6));const _0x33ca3d=_0x2da337['removed'];if(_0xdfaebb=_0x2da337['events'],!_0x314605){const _0x107c73=_0x33ca3d['findIndex'](_0x54a915=>_0x54a915['_queryParams']['loadsAllData']())!==-0x1,_0x40ca17=_0x3f1ad8['syncPointTree_']['findOnPath'](_0x3455e6,(_0x35768c,_0x5954a3)=>Te(_0x5954a3));if(_0x107c73&&!_0x40ca17){const _0x207b11=_0x3f1ad8['syncPointTree_']['subtree'](_0x3455e6);if(!_0x207b11['isEmpty']()){const _0x4c1860=Qu(_0x207b11);for(let _0x34319e=0x0;_0x34319e<_0x4c1860['length'];++_0x34319e){const _0x980156=_0x4c1860[_0x34319e],_0x17daa5=_0x980156['query'],_0xae0075=Xo(_0x3f1ad8,_0x980156);_0x3f1ad8['listenProvider_']['startListening'](Tt(_0x17daa5),Mt(_0x3f1ad8,_0x17daa5),_0xae0075['hashFn'],_0xae0075['onComplete']);}}}!_0x40ca17&&_0x33ca3d['length']>0x0&&!_0x341094&&(_0x107c73?_0x3f1ad8['listenProvider_']['stopListening'](Tt(_0x4e1f7a),null):_0x33ca3d['forEach'](_0x3aa915=>{const _0x3ae278=_0x3f1ad8['queryToTagMap']['get'](Fn(_0x3aa915));_0x3f1ad8['listenProvider_']['stopListening'](Tt(_0x3aa915),_0x3ae278);}));}Ju(_0x3f1ad8,_0x33ca3d);}return _0xdfaebb;}function Yo(_0x254f8d,_0x2cf20f,_0x3495c5,_0x603b71){const _0x566bbe=rs(_0x254f8d,_0x603b71);if(_0x566bbe!=null){const _0x99f6e9=os(_0x566bbe),_0xcc5a76=_0x99f6e9['path'],_0x361e35=_0x99f6e9['queryId'],_0x59de6a=F(_0xcc5a76,_0x2cf20f),_0xf270e1=new Fe(Zi(_0x361e35),_0x59de6a,_0x3495c5);return as(_0x254f8d,_0xcc5a76,_0xf270e1);}else return[];}function Ku(_0x5565ee,_0x4c4490,_0x338d58,_0x3d6e0d){const _0x2804ad=rs(_0x5565ee,_0x3d6e0d);if(_0x2804ad){const _0x111c68=os(_0x2804ad),_0x471477=_0x111c68['path'],_0x1a28ee=_0x111c68['queryId'],_0x562c37=F(_0x471477,_0x4c4490),_0x4aba5f=S['fromObject'](_0x338d58),_0x1e2839=new nt(Zi(_0x1a28ee),_0x562c37,_0x4aba5f);return as(_0x5565ee,_0x471477,_0x1e2839);}else return[];}function bi(_0x3a0826,_0x50ef83,_0x113b82,_0x8de682=!0x1){const _0x129830=_0x50ef83['_path'];let _0x4450bf=null,_0x4ea98c=!0x1;_0x3a0826['syncPointTree_']['foreachOnPath'](_0x129830,(_0xd46fa0,_0x459b04)=>{const _0x838d6a=F(_0xd46fa0,_0x129830);_0x4450bf=_0x4450bf||Ee(_0x459b04,_0x838d6a),_0x4ea98c=_0x4ea98c||Te(_0x459b04);});let _0x543e3b=_0x3a0826['syncPointTree_']['get'](_0x129830);_0x543e3b?(_0x4ea98c=_0x4ea98c||Te(_0x543e3b),_0x4450bf=_0x4450bf||Ee(_0x543e3b,w())):(_0x543e3b=new Go(),_0x3a0826['syncPointTree_']=_0x3a0826['syncPointTree_']['set'](_0x129830,_0x543e3b));let _0x3d5dbe;_0x4450bf!=null?_0x3d5dbe=!0x0:(_0x3d5dbe=!0x1,_0x4450bf=g['EMPTY_NODE'],_0x3a0826['syncPointTree_']['subtree'](_0x129830)['foreachChild']((_0x3bcb90,_0x10f608)=>{const _0x52d671=Ee(_0x10f608,w());_0x52d671&&(_0x4450bf=_0x4450bf['updateImmediateChild'](_0x3bcb90,_0x52d671));}));const _0x5a9389=Ko(_0x543e3b,_0x50ef83);if(!_0x5a9389&&!_0x50ef83['_queryParams']['loadsAllData']()){const _0x4ab1e9=Fn(_0x50ef83);f(!_0x3a0826['queryToTagMap']['has'](_0x4ab1e9),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xcd0804=Xu();_0x3a0826['queryToTagMap']['set'](_0x4ab1e9,_0xcd0804),_0x3a0826['tagToQueryMap']['set'](_0xcd0804,_0x4ab1e9);}const _0x41c8b0=Mn(_0x3a0826['pendingWriteTree_'],_0x129830);let _0x2ce268=Wu(_0x543e3b,_0x50ef83,_0x113b82,_0x41c8b0,_0x4450bf,_0x3d5dbe);if(!_0x5a9389&&!_0x4ea98c&&!_0x8de682){const _0x25c508=jo(_0x543e3b,_0x50ef83);_0x2ce268=_0x2ce268['concat'](Zu(_0x3a0826,_0x50ef83,_0x25c508));}return _0x2ce268;}function xn(_0x579fb6,_0x1380cf,_0x4a1e27){const _0x4f8c5e=_0x579fb6['pendingWriteTree_'],_0x52a73e=_0x579fb6['syncPointTree_']['findOnPath'](_0x1380cf,(_0x3bb277,_0x44573d)=>{const _0x49f89d=F(_0x3bb277,_0x1380cf),_0x223174=Ee(_0x44573d,_0x49f89d);if(_0x223174)return _0x223174;});return Uo(_0x4f8c5e,_0x1380cf,_0x52a73e,_0x4a1e27,!0x0);}function Yu(_0x30ab55,_0x1ce4d8){const _0x3f26fa=_0x1ce4d8['_path'];let _0x5a0e1c=null;_0x30ab55['syncPointTree_']['foreachOnPath'](_0x3f26fa,(_0x108ac9,_0x30d900)=>{const _0x1a3ef3=F(_0x108ac9,_0x3f26fa);_0x5a0e1c=_0x5a0e1c||Ee(_0x30d900,_0x1a3ef3);});let _0x326a87=_0x30ab55['syncPointTree_']['get'](_0x3f26fa);_0x326a87?_0x5a0e1c=_0x5a0e1c||Ee(_0x326a87,w()):(_0x326a87=new Go(),_0x30ab55['syncPointTree_']=_0x30ab55['syncPointTree_']['set'](_0x3f26fa,_0x326a87));const _0x49eafa=_0x5a0e1c!=null,_0x462e33=_0x49eafa?new Ce(_0x5a0e1c,!0x0,!0x1):null,_0x20d116=Mn(_0x30ab55['pendingWriteTree_'],_0x1ce4d8['_path']),_0x56889c=qo(_0x326a87,_0x1ce4d8,_0x20d116,_0x49eafa?_0x462e33['getNode']():g['EMPTY_NODE'],_0x49eafa);return Ou(_0x56889c);}function ht(_0x200266,_0x485898){return Qo(_0x485898,_0x200266['syncPointTree_'],null,Mn(_0x200266['pendingWriteTree_'],w()));}function Qo(_0x3b6c48,_0x471c12,_0x2eeeb1,_0x161904){if(v(_0x3b6c48['path']))return Jo(_0x3b6c48,_0x471c12,_0x2eeeb1,_0x161904);{const _0x3db0e0=_0x471c12['get'](w());_0x2eeeb1==null&&_0x3db0e0!=null&&(_0x2eeeb1=Ee(_0x3db0e0,w()));let _0x41fe8d=[];const _0x259d97=y(_0x3b6c48['path']),_0x499ed1=_0x3b6c48['operationForChild'](_0x259d97),_0x43ff13=_0x471c12['children']['get'](_0x259d97);if(_0x43ff13&&_0x499ed1){const _0x3d5fa8=_0x2eeeb1?_0x2eeeb1['getImmediateChild'](_0x259d97):null,_0x286939=Wo(_0x161904,_0x259d97);_0x41fe8d=_0x41fe8d['concat'](Qo(_0x499ed1,_0x43ff13,_0x3d5fa8,_0x286939));}return _0x3db0e0&&(_0x41fe8d=_0x41fe8d['concat'](is(_0x3db0e0,_0x3b6c48,_0x161904,_0x2eeeb1))),_0x41fe8d;}}function Jo(_0x194961,_0x4a6a7d,_0x10fedb,_0x15fc01){const _0x2a3b26=_0x4a6a7d['get'](w());_0x10fedb==null&&_0x2a3b26!=null&&(_0x10fedb=Ee(_0x2a3b26,w()));let _0x568cff=[];return _0x4a6a7d['children']['inorderTraversal']((_0x5e9a3b,_0x36b34e)=>{const _0xeb6529=_0x10fedb?_0x10fedb['getImmediateChild'](_0x5e9a3b):null,_0x21f4bc=Wo(_0x15fc01,_0x5e9a3b),_0xbd3be2=_0x194961['operationForChild'](_0x5e9a3b);_0xbd3be2&&(_0x568cff=_0x568cff['concat'](Jo(_0xbd3be2,_0x36b34e,_0xeb6529,_0x21f4bc)));}),_0x2a3b26&&(_0x568cff=_0x568cff['concat'](is(_0x2a3b26,_0x194961,_0x15fc01,_0x10fedb))),_0x568cff;}function Xo(_0x27a0e2,_0xec46a0){const _0x18355d=_0xec46a0['query'],_0x42cc33=Mt(_0x27a0e2,_0x18355d);return{'hashFn':()=>(Pu(_0xec46a0)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2bc52b=>{if(_0x2bc52b==='ok')return _0x42cc33?ju(_0x27a0e2,_0x18355d['_path'],_0x42cc33):zu(_0x27a0e2,_0x18355d['_path']);{const _0x17b1c6=ql(_0x2bc52b,_0x18355d);return wn(_0x27a0e2,_0x18355d,null,_0x17b1c6);}}};}function Mt(_0x84bb25,_0x3b8353){const _0x421daa=Fn(_0x3b8353);return _0x84bb25['queryToTagMap']['get'](_0x421daa);}function Fn(_0x397ec8){return _0x397ec8['_path']['toString']()+'$'+_0x397ec8['_queryIdentifier'];}function rs(_0x5938ce,_0x414d7d){return _0x5938ce['tagToQueryMap']['get'](_0x414d7d);}function os(_0x145d0a){const _0x58d29e=_0x145d0a['indexOf']('$');return f(_0x58d29e!==-0x1&&_0x58d29e<_0x145d0a['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x145d0a['substr'](_0x58d29e+0x1),'path':new C(_0x145d0a['substr'](0x0,_0x58d29e))};}function as(_0x5d8ca9,_0x2b076d,_0x3becb1){const _0x1ceb84=_0x5d8ca9['syncPointTree_']['get'](_0x2b076d);f(_0x1ceb84,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x311023=Mn(_0x5d8ca9['pendingWriteTree_'],_0x2b076d);return is(_0x1ceb84,_0x3becb1,_0x311023,null);}function Qu(_0x35312e){return _0x35312e['fold']((_0x452ca4,_0x3464a4,_0x577f70)=>{if(_0x3464a4&&Te(_0x3464a4))return[Ln(_0x3464a4)];{let _0x276c45=[];return _0x3464a4&&(_0x276c45=zo(_0x3464a4)),x(_0x577f70,(_0x695b67,_0x4d164e)=>{_0x276c45=_0x276c45['concat'](_0x4d164e);}),_0x276c45;}});}function Tt(_0x2e7251){return _0x2e7251['_queryParams']['loadsAllData']()&&!_0x2e7251['_queryParams']['isDefault']()?new(Hu())(_0x2e7251['_repo'],_0x2e7251['_path']):_0x2e7251;}function Ju(_0x4eec3a,_0xf6534d){for(let _0xca4511=0x0;_0xca4511<_0xf6534d['length'];++_0xca4511){const _0x1fab28=_0xf6534d[_0xca4511];if(!_0x1fab28['_queryParams']['loadsAllData']()){const _0x1f002d=Fn(_0x1fab28),_0x5ee7ce=_0x4eec3a['queryToTagMap']['get'](_0x1f002d);_0x4eec3a['queryToTagMap']['delete'](_0x1f002d),_0x4eec3a['tagToQueryMap']['delete'](_0x5ee7ce);}}}function Xu(){return $u++;}function Zu(_0x251cc0,_0x1b54b5,_0x3d9079){const _0x488b0d=_0x1b54b5['_path'],_0x7cc619=Mt(_0x251cc0,_0x1b54b5),_0x379945=Xo(_0x251cc0,_0x3d9079),_0x3d9409=_0x251cc0['listenProvider_']['startListening'](Tt(_0x1b54b5),_0x7cc619,_0x379945['hashFn'],_0x379945['onComplete']),_0x261555=_0x251cc0['syncPointTree_']['subtree'](_0x488b0d);if(_0x7cc619)f(!Te(_0x261555['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x26ec5b=_0x261555['fold']((_0x473112,_0x9c3075,_0x544531)=>{if(!v(_0x473112)&&_0x9c3075&&Te(_0x9c3075))return[Ln(_0x9c3075)['query']];{let _0x34b81b=[];return _0x9c3075&&(_0x34b81b=_0x34b81b['concat'](zo(_0x9c3075)['map'](_0x17fa9a=>_0x17fa9a['query']))),x(_0x544531,(_0x9869b1,_0x49d81a)=>{_0x34b81b=_0x34b81b['concat'](_0x49d81a);}),_0x34b81b;}});for(let _0x11fcc2=0x0;_0x11fcc2<_0x26ec5b['length'];++_0x11fcc2){const _0x15a3c5=_0x26ec5b[_0x11fcc2];_0x251cc0['listenProvider_']['stopListening'](Tt(_0x15a3c5),Mt(_0x251cc0,_0x15a3c5));}}return _0x3d9409;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x2a72bd){this['node_']=_0x2a72bd;}['getImmediateChild'](_0x54a7d4){const _0xd5008a=this['node_']['getImmediateChild'](_0x54a7d4);return new cs(_0xd5008a);}['node'](){return this['node_'];}}class ls{constructor(_0x178daf,_0x410e83){this['syncTree_']=_0x178daf,this['path_']=_0x410e83;}['getImmediateChild'](_0x303590){const _0x3dc5d7=A(this['path_'],_0x303590);return new ls(this['syncTree_'],_0x3dc5d7);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x428363){return _0x428363=_0x428363||{},_0x428363['timestamp']=_0x428363['timestamp']||new Date()['getTime'](),_0x428363;},fr=function(_0x57074a,_0x49fdc5,_0x1041f2){if(!_0x57074a||typeof _0x57074a!='object')return _0x57074a;if(f('.sv'in _0x57074a,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x57074a['.sv']=='string')return td(_0x57074a['.sv'],_0x49fdc5,_0x1041f2);if(typeof _0x57074a['.sv']=='object')return nd(_0x57074a['.sv'],_0x49fdc5);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x57074a,null,0x2));},td=function(_0x565ee5,_0x384247,_0x5bee29){switch(_0x565ee5){case'timestamp':return _0x5bee29['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x565ee5);}},nd=function(_0xea5656,_0x323bfd,_0x129194){_0xea5656['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xea5656,null,0x2));const _0x5af6c3=_0xea5656['increment'];typeof _0x5af6c3!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x5af6c3);const _0x58bfbc=_0x323bfd['node']();if(f(_0x58bfbc!==null&&typeof _0x58bfbc<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x58bfbc['isLeafNode']())return _0x5af6c3;const _0x413e99=_0x58bfbc['getValue']();return typeof _0x413e99!='number'?_0x5af6c3:_0x413e99+_0x5af6c3;},Zo=function(_0xd7b6d6,_0x4cdcdd,_0x283a03,_0x277efa){return us(_0x4cdcdd,new ls(_0x283a03,_0xd7b6d6),_0x277efa);},hs=function(_0x37c5a7,_0x5f5af6,_0x4f26b9){return us(_0x37c5a7,new cs(_0x5f5af6),_0x4f26b9);};function us(_0x17b09a,_0x1923b5,_0x3a25ea){const _0x1ecac3=_0x17b09a['getPriority']()['val'](),_0x42fa69=fr(_0x1ecac3,_0x1923b5['getImmediateChild']('.priority'),_0x3a25ea);let _0x1136fd;if(_0x17b09a['isLeafNode']()){const _0x739211=_0x17b09a,_0x12f196=fr(_0x739211['getValue'](),_0x1923b5,_0x3a25ea);return _0x12f196!==_0x739211['getValue']()||_0x42fa69!==_0x739211['getPriority']()['val']()?new D(_0x12f196,N(_0x42fa69)):_0x17b09a;}else{const _0x286760=_0x17b09a;return _0x1136fd=_0x286760,_0x42fa69!==_0x286760['getPriority']()['val']()&&(_0x1136fd=_0x1136fd['updatePriority'](new D(_0x42fa69))),_0x286760['forEachChild'](R,(_0x377e6e,_0x2e931b)=>{const _0x199025=us(_0x2e931b,_0x1923b5['getImmediateChild'](_0x377e6e),_0x3a25ea);_0x199025!==_0x2e931b&&(_0x1136fd=_0x1136fd['updateImmediateChild'](_0x377e6e,_0x199025));}),_0x1136fd;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x4e96d6='',_0x341935=null,_0x37be7d={'children':{},'childCount':0x0}){this['name']=_0x4e96d6,this['parent']=_0x341935,this['node']=_0x37be7d;}}function Un(_0x46f6c6,_0x3167e2){let _0x1ed579=_0x3167e2 instanceof C?_0x3167e2:new C(_0x3167e2),_0x403143=_0x46f6c6,_0x11d698=y(_0x1ed579);for(;_0x11d698!==null;){const _0x252b4e=Oe(_0x403143['node']['children'],_0x11d698)||{'children':{},'childCount':0x0};_0x403143=new ds(_0x11d698,_0x403143,_0x252b4e),_0x1ed579=b(_0x1ed579),_0x11d698=y(_0x1ed579);}return _0x403143;}function Ge(_0xe610a){return _0xe610a['node']['value'];}function fs(_0x24cd1a,_0xdc9cc7){_0x24cd1a['node']['value']=_0xdc9cc7,Ri(_0x24cd1a);}function ea(_0x3b3380){return _0x3b3380['node']['childCount']>0x0;}function id(_0x448184){return Ge(_0x448184)===void 0x0&&!ea(_0x448184);}function Wn(_0x39c18a,_0x5b381b){x(_0x39c18a['node']['children'],(_0x56d1f8,_0x2d3e22)=>{_0x5b381b(new ds(_0x56d1f8,_0x39c18a,_0x2d3e22));});}function ta(_0x156099,_0x4ab81d,_0x4e6975,_0x12e029){_0x4e6975&&_0x4ab81d(_0x156099),Wn(_0x156099,_0xdb90ec=>{ta(_0xdb90ec,_0x4ab81d,!0x0);});}function sd(_0x3e1d75,_0x13ca1c,_0x30cbf6){let _0x20f028=_0x3e1d75['parent'];for(;_0x20f028!==null;){if(_0x13ca1c(_0x20f028))return!0x0;_0x20f028=_0x20f028['parent'];}return!0x1;}function Gt(_0xa2d31e){return new C(_0xa2d31e['parent']===null?_0xa2d31e['name']:Gt(_0xa2d31e['parent'])+'/'+_0xa2d31e['name']);}function Ri(_0x45c61e){_0x45c61e['parent']!==null&&rd(_0x45c61e['parent'],_0x45c61e['name'],_0x45c61e);}function rd(_0x108e80,_0x36650f,_0x11dcaa){const _0x512a65=id(_0x11dcaa),_0x5dc6d3=Y(_0x108e80['node']['children'],_0x36650f);_0x512a65&&_0x5dc6d3?(delete _0x108e80['node']['children'][_0x36650f],_0x108e80['node']['childCount']--,Ri(_0x108e80)):!_0x512a65&&!_0x5dc6d3&&(_0x108e80['node']['children'][_0x36650f]=_0x11dcaa['node'],_0x108e80['node']['childCount']++,Ri(_0x108e80));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x5ee82a){return typeof _0x5ee82a=='string'&&_0x5ee82a['length']!==0x0&&!od['test'](_0x5ee82a);},na=function(_0xdef279){return typeof _0xdef279=='string'&&_0xdef279['length']!==0x0&&!ad['test'](_0xdef279);},cd=function(_0x4da7b4){return _0x4da7b4&&(_0x4da7b4=_0x4da7b4['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x4da7b4);},Cn=function(_0x52eebf){return _0x52eebf===null||typeof _0x52eebf=='string'||typeof _0x52eebf=='number'&&!Wi(_0x52eebf)||_0x52eebf&&typeof _0x52eebf=='object'&&Y(_0x52eebf,'.sv');},qt=function(_0x5b0c11,_0x5c699b,_0x2a32ab,_0x3bf3cd){_0x3bf3cd&&_0x5c699b===void 0x0||zt(Nn(_0x5b0c11,'value'),_0x5c699b,_0x2a32ab);},zt=function(_0x198318,_0x23024c,_0x399933){const _0x5a7f89=_0x399933 instanceof C?new Sh(_0x399933,_0x198318):_0x399933;if(_0x23024c===void 0x0)throw new Error(_0x198318+'contains\x20undefined\x20'+Ne(_0x5a7f89));if(typeof _0x23024c=='function')throw new Error(_0x198318+'contains\x20a\x20function\x20'+Ne(_0x5a7f89)+'\x20with\x20contents\x20=\x20'+_0x23024c['toString']());if(Wi(_0x23024c))throw new Error(_0x198318+'contains\x20'+_0x23024c['toString']()+'\x20'+Ne(_0x5a7f89));if(typeof _0x23024c=='string'&&_0x23024c['length']>oi/0x3&&Pn(_0x23024c)>oi)throw new Error(_0x198318+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x5a7f89)+'\x20(\x27'+_0x23024c['substring'](0x0,0x32)+'...\x27)');if(_0x23024c&&typeof _0x23024c=='object'){let _0x1fcb7b=!0x1,_0x233a04=!0x1;if(x(_0x23024c,(_0x4d3d80,_0x4d40b3)=>{if(_0x4d3d80==='.value')_0x1fcb7b=!0x0;else{if(_0x4d3d80!=='.priority'&&_0x4d3d80!=='.sv'&&(_0x233a04=!0x0,!ps(_0x4d3d80)))throw new Error(_0x198318+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4d3d80+')\x20'+Ne(_0x5a7f89)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x5a7f89,_0x4d3d80),zt(_0x198318,_0x4d40b3,_0x5a7f89),Rh(_0x5a7f89);}),_0x1fcb7b&&_0x233a04)throw new Error(_0x198318+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x5a7f89)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x90fc48,_0x2bbf6a){let _0xbcd113,_0x495a2e;for(_0xbcd113=0x0;_0xbcd113<_0x2bbf6a['length'];_0xbcd113++){_0x495a2e=_0x2bbf6a[_0xbcd113];const _0x578812=kt(_0x495a2e);for(let _0x3fa8fa=0x0;_0x3fa8fa<_0x578812['length'];_0x3fa8fa++)if(!(_0x578812[_0x3fa8fa]==='.priority'&&_0x3fa8fa===_0x578812['length']-0x1)){if(!ps(_0x578812[_0x3fa8fa]))throw new Error(_0x90fc48+'contains\x20an\x20invalid\x20key\x20('+_0x578812[_0x3fa8fa]+')\x20in\x20path\x20'+_0x495a2e['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x2bbf6a['sort'](Th);let _0x552f63=null;for(_0xbcd113=0x0;_0xbcd113<_0x2bbf6a['length'];_0xbcd113++){if(_0x495a2e=_0x2bbf6a[_0xbcd113],_0x552f63!==null&&$(_0x552f63,_0x495a2e))throw new Error(_0x90fc48+'contains\x20a\x20path\x20'+_0x552f63['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x495a2e['toString']());_0x552f63=_0x495a2e;}},hd=function(_0x20aec9,_0x26b5b5,_0x47e7a4,_0xb54a56){const _0x26d226=Nn(_0x20aec9,'values');if(!(_0x26b5b5&&typeof _0x26b5b5=='object')||Array['isArray'](_0x26b5b5))throw new Error(_0x26d226+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x27158d=[];x(_0x26b5b5,(_0x530a4,_0x3c58ed)=>{const _0xa05157=new C(_0x530a4);if(zt(_0x26d226,_0x3c58ed,A(_0x47e7a4,_0xa05157)),Gi(_0xa05157)==='.priority'&&!Cn(_0x3c58ed))throw new Error(_0x26d226+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0xa05157['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x27158d['push'](_0xa05157);}),ld(_0x26d226,_0x27158d);},_s=function(_0x2e5bee,_0x1ba37d,_0x4ab97b,_0x3e709f){if(!na(_0x4ab97b))throw new Error(Nn(_0x2e5bee,_0x1ba37d)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4ab97b+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x394861,_0x4e08e7,_0x219c6b,_0x258a66){_0x219c6b&&(_0x219c6b=_0x219c6b['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x394861,_0x4e08e7,_0x219c6b);},gs=function(_0x52adc8,_0x2673d3){if(y(_0x2673d3)==='.info')throw new Error(_0x52adc8+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x185bbc,_0x461f4a){const _0x20b2e6=_0x461f4a['path']['toString']();if(typeof _0x461f4a['repoInfo']['host']!='string'||_0x461f4a['repoInfo']['host']['length']===0x0||!ps(_0x461f4a['repoInfo']['namespace'])&&_0x461f4a['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x20b2e6['length']!==0x0&&!cd(_0x20b2e6))throw new Error(Nn(_0x185bbc,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x38d0db,_0x4bd20f){let _0x127258=null;for(let _0x5d0a59=0x0;_0x5d0a59<_0x4bd20f['length'];_0x5d0a59++){const _0x1e7285=_0x4bd20f[_0x5d0a59],_0x4865f1=_0x1e7285['getPath']();_0x127258!==null&&!qi(_0x4865f1,_0x127258['path'])&&(_0x38d0db['eventLists_']['push'](_0x127258),_0x127258=null),_0x127258===null&&(_0x127258={'events':[],'path':_0x4865f1}),_0x127258['events']['push'](_0x1e7285);}_0x127258&&_0x38d0db['eventLists_']['push'](_0x127258);}function ia(_0xb495c3,_0x483194,_0x1b40f5){Bn(_0xb495c3,_0x1b40f5),sa(_0xb495c3,_0x3950a9=>qi(_0x3950a9,_0x483194));}function V(_0x5d7dd9,_0x4f729f,_0x495ba6){Bn(_0x5d7dd9,_0x495ba6),sa(_0x5d7dd9,_0x274cf6=>$(_0x274cf6,_0x4f729f)||$(_0x4f729f,_0x274cf6));}function sa(_0x59db6a,_0x194a3e){_0x59db6a['recursionDepth_']++;let _0x2910a7=!0x0;for(let _0xf27080=0x0;_0xf27080<_0x59db6a['eventLists_']['length'];_0xf27080++){const _0x488d8f=_0x59db6a['eventLists_'][_0xf27080];if(_0x488d8f){const _0x1daec4=_0x488d8f['path'];_0x194a3e(_0x1daec4)?(pd(_0x59db6a['eventLists_'][_0xf27080]),_0x59db6a['eventLists_'][_0xf27080]=null):_0x2910a7=!0x1;}}_0x2910a7&&(_0x59db6a['eventLists_']=[]),_0x59db6a['recursionDepth_']--;}function pd(_0x12e265){for(let _0x2d58a2=0x0;_0x2d58a2<_0x12e265['events']['length'];_0x2d58a2++){const _0x206d89=_0x12e265['events'][_0x2d58a2];if(_0x206d89!==null){_0x12e265['events'][_0x2d58a2]=null;const _0x2d2a32=_0x206d89['getEventRunner']();Et&&L('event:\x20'+_0x206d89['toString']()),lt(_0x2d2a32);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x4dd1bd,_0xf2a369,_0x580130,_0x4972ec){this['repoInfo_']=_0x4dd1bd,this['forceRestClient_']=_0xf2a369,this['authTokenProvider_']=_0x580130,this['appCheckProvider_']=_0x4972ec,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x1b8d1f,_0x28d084,_0x522cf4){if(_0x1b8d1f['stats_']=Hi(_0x1b8d1f['repoInfo_']),_0x1b8d1f['forceRestClient_']||Yl())_0x1b8d1f['server_']=new fn(_0x1b8d1f['repoInfo_'],(_0x34a452,_0x2ba609,_0x498318,_0x585c29)=>{pr(_0x1b8d1f,_0x34a452,_0x2ba609,_0x498318,_0x585c29);},_0x1b8d1f['authTokenProvider_'],_0x1b8d1f['appCheckProvider_']),setTimeout(()=>_r(_0x1b8d1f,!0x0),0x0);else{if(typeof _0x522cf4<'u'&&_0x522cf4!==null){if(typeof _0x522cf4!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x522cf4);}catch(_0x4e9b6b){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4e9b6b);}}_0x1b8d1f['persistentConnection_']=new ie(_0x1b8d1f['repoInfo_'],_0x28d084,(_0x202d94,_0x20552d,_0x4eaddc,_0x59803d)=>{pr(_0x1b8d1f,_0x202d94,_0x20552d,_0x4eaddc,_0x59803d);},_0x3ef29c=>{_r(_0x1b8d1f,_0x3ef29c);},_0x474a3b=>{yd(_0x1b8d1f,_0x474a3b);},_0x1b8d1f['authTokenProvider_'],_0x1b8d1f['appCheckProvider_'],_0x522cf4),_0x1b8d1f['server_']=_0x1b8d1f['persistentConnection_'];}_0x1b8d1f['authTokenProvider_']['addTokenChangeListener'](_0x6c2c54=>{_0x1b8d1f['server_']['refreshAuthToken'](_0x6c2c54);}),_0x1b8d1f['appCheckProvider_']['addTokenChangeListener'](_0x566b74=>{_0x1b8d1f['server_']['refreshAppCheckToken'](_0x566b74['token']);}),_0x1b8d1f['statsReporter_']=eh(_0x1b8d1f['repoInfo_'],()=>new eu(_0x1b8d1f['stats_'],_0x1b8d1f['server_'])),_0x1b8d1f['infoData_']=new Yh(),_0x1b8d1f['infoSyncTree_']=new dr({'startListening':(_0x25f008,_0xf6fd5f,_0x192de2,_0x235457)=>{let _0x40aca2=[];const _0x7df40=_0x1b8d1f['infoData_']['getNode'](_0x25f008['_path']);return _0x7df40['isEmpty']()||(_0x40aca2=$t(_0x1b8d1f['infoSyncTree_'],_0x25f008['_path'],_0x7df40),setTimeout(()=>{_0x235457('ok');},0x0)),_0x40aca2;},'stopListening':()=>{}}),ms(_0x1b8d1f,'connected',!0x1),_0x1b8d1f['serverSyncTree_']=new dr({'startListening':(_0x14e891,_0x909a13,_0xd1d2e8,_0xa36059)=>(_0x1b8d1f['server_']['listen'](_0x14e891,_0xd1d2e8,_0x909a13,(_0x28dee0,_0x16bb37)=>{const _0x43648a=_0xa36059(_0x28dee0,_0x16bb37);V(_0x1b8d1f['eventQueue_'],_0x14e891['_path'],_0x43648a);}),[]),'stopListening':(_0x4aed70,_0x59ab5c)=>{_0x1b8d1f['server_']['unlisten'](_0x4aed70,_0x59ab5c);}});}function oa(_0x5a1b15){const _0x55ad4c=_0x5a1b15['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x55ad4c;}function jt(_0x29cef4){return ed({'timestamp':oa(_0x29cef4)});}function pr(_0xb65348,_0x4a635f,_0x58e9e2,_0x1d14cc,_0x4257a6){_0xb65348['dataUpdateCount']++;const _0x1c9c9d=new C(_0x4a635f);_0x58e9e2=_0xb65348['interceptServerDataCallback_']?_0xb65348['interceptServerDataCallback_'](_0x4a635f,_0x58e9e2):_0x58e9e2;let _0x2a97e4=[];if(_0x4257a6){if(_0x1d14cc){const _0x40d5d2=ln(_0x58e9e2,_0x2fed12=>N(_0x2fed12));_0x2a97e4=Ku(_0xb65348['serverSyncTree_'],_0x1c9c9d,_0x40d5d2,_0x4257a6);}else{const _0x5abfc8=N(_0x58e9e2);_0x2a97e4=Yo(_0xb65348['serverSyncTree_'],_0x1c9c9d,_0x5abfc8,_0x4257a6);}}else{if(_0x1d14cc){const _0x5245a7=ln(_0x58e9e2,_0x190723=>N(_0x190723));_0x2a97e4=qu(_0xb65348['serverSyncTree_'],_0x1c9c9d,_0x5245a7);}else{const _0x16c589=N(_0x58e9e2);_0x2a97e4=$t(_0xb65348['serverSyncTree_'],_0x1c9c9d,_0x16c589);}}let _0x280024=_0x1c9c9d;_0x2a97e4['length']>0x0&&(_0x280024=st(_0xb65348,_0x1c9c9d)),V(_0xb65348['eventQueue_'],_0x280024,_0x2a97e4);}function _r(_0x31588d,_0x841eba){ms(_0x31588d,'connected',_0x841eba),_0x841eba===!0x1&&wd(_0x31588d);}function yd(_0x46dfd5,_0x44ca39){x(_0x44ca39,(_0x23bf43,_0x2fc49b)=>{ms(_0x46dfd5,_0x23bf43,_0x2fc49b);});}function ms(_0xf5577d,_0x3a8645,_0x2af4bf){const _0x11cd4e=new C('/.info/'+_0x3a8645),_0x3a7146=N(_0x2af4bf);_0xf5577d['infoData_']['updateSnapshot'](_0x11cd4e,_0x3a7146);const _0x327c65=$t(_0xf5577d['infoSyncTree_'],_0x11cd4e,_0x3a7146);V(_0xf5577d['eventQueue_'],_0x11cd4e,_0x327c65);}function Vn(_0x26423a){return _0x26423a['nextWriteId_']++;}function vd(_0x36fb39,_0x3c51a3,_0x592823){const _0x28cbf8=Yu(_0x36fb39['serverSyncTree_'],_0x3c51a3);return _0x28cbf8!=null?Promise['resolve'](_0x28cbf8):_0x36fb39['server_']['get'](_0x3c51a3)['then'](_0x3da3fc=>{const _0x1add2c=N(_0x3da3fc)['withIndex'](_0x3c51a3['_queryParams']['getIndex']());bi(_0x36fb39['serverSyncTree_'],_0x3c51a3,_0x592823,!0x0);let _0x3aceff;if(_0x3c51a3['_queryParams']['loadsAllData']())_0x3aceff=$t(_0x36fb39['serverSyncTree_'],_0x3c51a3['_path'],_0x1add2c);else{const _0x15b4cb=Mt(_0x36fb39['serverSyncTree_'],_0x3c51a3);_0x3aceff=Yo(_0x36fb39['serverSyncTree_'],_0x3c51a3['_path'],_0x1add2c,_0x15b4cb);}return V(_0x36fb39['eventQueue_'],_0x3c51a3['_path'],_0x3aceff),wn(_0x36fb39['serverSyncTree_'],_0x3c51a3,_0x592823,null,!0x0),_0x1add2c;},_0x4ce8cf=>(ut(_0x36fb39,'get\x20for\x20query\x20'+O(_0x3c51a3)+'\x20failed:\x20'+_0x4ce8cf),Promise['reject'](new Error(_0x4ce8cf))));}function Ed(_0x3107ed,_0x5b354c,_0x5d133d,_0x558d6c,_0x149b1a){ut(_0x3107ed,'set',{'path':_0x5b354c['toString'](),'value':_0x5d133d,'priority':_0x558d6c});const _0x3260fb=jt(_0x3107ed),_0x5749f9=N(_0x5d133d,_0x558d6c),_0x2abae0=xn(_0x3107ed['serverSyncTree_'],_0x5b354c),_0x1b3cf7=hs(_0x5749f9,_0x2abae0,_0x3260fb),_0x507f3b=Vn(_0x3107ed),_0x148281=ss(_0x3107ed['serverSyncTree_'],_0x5b354c,_0x1b3cf7,_0x507f3b,!0x0);Bn(_0x3107ed['eventQueue_'],_0x148281),_0x3107ed['server_']['put'](_0x5b354c['toString'](),_0x5749f9['val'](!0x0),(_0x2eab84,_0x4dadc0)=>{const _0x124154=_0x2eab84==='ok';_0x124154||U('set\x20at\x20'+_0x5b354c+'\x20failed:\x20'+_0x2eab84);const _0x2bcb12=pe(_0x3107ed['serverSyncTree_'],_0x507f3b,!_0x124154);V(_0x3107ed['eventQueue_'],_0x5b354c,_0x2bcb12),Ai(_0x3107ed,_0x149b1a,_0x2eab84,_0x4dadc0);});const _0x305fb9=vs(_0x3107ed,_0x5b354c);st(_0x3107ed,_0x305fb9),V(_0x3107ed['eventQueue_'],_0x305fb9,[]);}function Id(_0x38ce6b,_0x5ab02f,_0x522385,_0x5c43ad){ut(_0x38ce6b,'update',{'path':_0x5ab02f['toString'](),'value':_0x522385});let _0x2ca8e5=!0x0;const _0xfad8=jt(_0x38ce6b),_0x25fcb3={};if(x(_0x522385,(_0x46019e,_0x37246a)=>{_0x2ca8e5=!0x1,_0x25fcb3[_0x46019e]=Zo(A(_0x5ab02f,_0x46019e),N(_0x37246a),_0x38ce6b['serverSyncTree_'],_0xfad8);}),_0x2ca8e5)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x38ce6b,_0x5c43ad,'ok',void 0x0);else{const _0x3fe3db=Vn(_0x38ce6b),_0x45bde9=Gu(_0x38ce6b['serverSyncTree_'],_0x5ab02f,_0x25fcb3,_0x3fe3db);Bn(_0x38ce6b['eventQueue_'],_0x45bde9),_0x38ce6b['server_']['merge'](_0x5ab02f['toString'](),_0x522385,(_0x5289f3,_0x4d0ec6)=>{const _0x2c4fd7=_0x5289f3==='ok';_0x2c4fd7||U('update\x20at\x20'+_0x5ab02f+'\x20failed:\x20'+_0x5289f3);const _0x33253d=pe(_0x38ce6b['serverSyncTree_'],_0x3fe3db,!_0x2c4fd7),_0x507fe2=_0x33253d['length']>0x0?st(_0x38ce6b,_0x5ab02f):_0x5ab02f;V(_0x38ce6b['eventQueue_'],_0x507fe2,_0x33253d),Ai(_0x38ce6b,_0x5c43ad,_0x5289f3,_0x4d0ec6);}),x(_0x522385,_0x37636a=>{const _0x530b06=vs(_0x38ce6b,A(_0x5ab02f,_0x37636a));st(_0x38ce6b,_0x530b06);}),V(_0x38ce6b['eventQueue_'],_0x5ab02f,[]);}}function wd(_0x2e8dfd){ut(_0x2e8dfd,'onDisconnectEvents');const _0x3c623a=jt(_0x2e8dfd),_0x163298=pn();Ei(_0x2e8dfd['onDisconnect_'],w(),(_0x46d887,_0x314495)=>{const _0x2f280e=Zo(_0x46d887,_0x314495,_0x2e8dfd['serverSyncTree_'],_0x3c623a);Mo(_0x163298,_0x46d887,_0x2f280e);});let _0x2a0165=[];Ei(_0x163298,w(),(_0x1e7e67,_0x2534e5)=>{_0x2a0165=_0x2a0165['concat']($t(_0x2e8dfd['serverSyncTree_'],_0x1e7e67,_0x2534e5));const _0x79b294=vs(_0x2e8dfd,_0x1e7e67);st(_0x2e8dfd,_0x79b294);}),_0x2e8dfd['onDisconnect_']=pn(),V(_0x2e8dfd['eventQueue_'],w(),_0x2a0165);}function Cd(_0x3a9914,_0x1fc6f9,_0x45b257){let _0x44981b;y(_0x1fc6f9['_path'])==='.info'?_0x44981b=bi(_0x3a9914['infoSyncTree_'],_0x1fc6f9,_0x45b257):_0x44981b=bi(_0x3a9914['serverSyncTree_'],_0x1fc6f9,_0x45b257),ia(_0x3a9914['eventQueue_'],_0x1fc6f9['_path'],_0x44981b);}function Td(_0x24bba9,_0x3272b1,_0x447352){let _0x2dbe84;y(_0x3272b1['_path'])==='.info'?_0x2dbe84=wn(_0x24bba9['infoSyncTree_'],_0x3272b1,_0x447352):_0x2dbe84=wn(_0x24bba9['serverSyncTree_'],_0x3272b1,_0x447352),ia(_0x24bba9['eventQueue_'],_0x3272b1['_path'],_0x2dbe84);}function aa(_0x5134d4){_0x5134d4['persistentConnection_']&&_0x5134d4['persistentConnection_']['interrupt'](ra);}function Sd(_0x3621c3){_0x3621c3['persistentConnection_']&&_0x3621c3['persistentConnection_']['resume'](ra);}function ut(_0x4ad209,..._0x57694c){let _0x2fb2d2='';_0x4ad209['persistentConnection_']&&(_0x2fb2d2=_0x4ad209['persistentConnection_']['id']+':'),L(_0x2fb2d2,..._0x57694c);}function Ai(_0x1c74c0,_0x55ab60,_0x2ac1b1,_0xb8073e){_0x55ab60&&lt(()=>{if(_0x2ac1b1==='ok')_0x55ab60(null);else{const _0x48565=(_0x2ac1b1||'error')['toUpperCase']();let _0x54fdf2=_0x48565;_0xb8073e&&(_0x54fdf2+=':\x20'+_0xb8073e);const _0x184287=new Error(_0x54fdf2);_0x184287['code']=_0x48565,_0x55ab60(_0x184287);}});}function bd(_0x1fa8e2,_0x70cff5,_0x24fd39,_0x21a068,_0x4b4d86,_0x5a1b1){ut(_0x1fa8e2,'transaction\x20on\x20'+_0x70cff5);const _0x471174={'path':_0x70cff5,'update':_0x24fd39,'onComplete':_0x21a068,'status':null,'order':to(),'applyLocally':_0x5a1b1,'retryCount':0x0,'unwatcher':_0x4b4d86,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x57b2d2=ys(_0x1fa8e2,_0x70cff5,void 0x0);_0x471174['currentInputSnapshot']=_0x57b2d2;const _0x2b71ce=_0x471174['update'](_0x57b2d2['val']());if(_0x2b71ce===void 0x0)_0x471174['unwatcher'](),_0x471174['currentOutputSnapshotRaw']=null,_0x471174['currentOutputSnapshotResolved']=null,_0x471174['onComplete']&&_0x471174['onComplete'](null,!0x1,_0x471174['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x2b71ce,_0x471174['path']),_0x471174['status']=0x0;const _0x21af77=Un(_0x1fa8e2['transactionQueueTree_'],_0x70cff5),_0x6493ed=Ge(_0x21af77)||[];_0x6493ed['push'](_0x471174),fs(_0x21af77,_0x6493ed);let _0x29e025;typeof _0x2b71ce=='object'&&_0x2b71ce!==null&&Y(_0x2b71ce,'.priority')?(_0x29e025=Oe(_0x2b71ce,'.priority'),f(Cn(_0x29e025),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x29e025=(xn(_0x1fa8e2['serverSyncTree_'],_0x70cff5)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x424c02=jt(_0x1fa8e2),_0x12201c=N(_0x2b71ce,_0x29e025),_0x18e49e=hs(_0x12201c,_0x57b2d2,_0x424c02);_0x471174['currentOutputSnapshotRaw']=_0x12201c,_0x471174['currentOutputSnapshotResolved']=_0x18e49e,_0x471174['currentWriteId']=Vn(_0x1fa8e2);const _0xd409f9=ss(_0x1fa8e2['serverSyncTree_'],_0x70cff5,_0x18e49e,_0x471174['currentWriteId'],_0x471174['applyLocally']);V(_0x1fa8e2['eventQueue_'],_0x70cff5,_0xd409f9),Hn(_0x1fa8e2,_0x1fa8e2['transactionQueueTree_']);}}function ys(_0x144664,_0x18e76f,_0x47b8b8){return xn(_0x144664['serverSyncTree_'],_0x18e76f,_0x47b8b8)||g['EMPTY_NODE'];}function Hn(_0x5bbb3a,_0x5da573=_0x5bbb3a['transactionQueueTree_']){if(_0x5da573||$n(_0x5bbb3a,_0x5da573),Ge(_0x5da573)){const _0x1b5ba0=la(_0x5bbb3a,_0x5da573);f(_0x1b5ba0['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1b5ba0['every'](_0x57b0ce=>_0x57b0ce['status']===0x0)&&Rd(_0x5bbb3a,Gt(_0x5da573),_0x1b5ba0);}else ea(_0x5da573)&&Wn(_0x5da573,_0x44fbde=>{Hn(_0x5bbb3a,_0x44fbde);});}function Rd(_0x1a5bda,_0x114647,_0x2d5583){const _0xaf75bb=_0x2d5583['map'](_0x13d76c=>_0x13d76c['currentWriteId']),_0x2cf496=ys(_0x1a5bda,_0x114647,_0xaf75bb);let _0x11d80a=_0x2cf496;const _0x1a33a0=_0x2cf496['hash']();for(let _0x520c39=0x0;_0x520c39<_0x2d5583['length'];_0x520c39++){const _0x5604cd=_0x2d5583[_0x520c39];f(_0x5604cd['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x5604cd['status']=0x1,_0x5604cd['retryCount']++;const _0x1e8506=F(_0x114647,_0x5604cd['path']);_0x11d80a=_0x11d80a['updateChild'](_0x1e8506,_0x5604cd['currentOutputSnapshotRaw']);}const _0x455846=_0x11d80a['val'](!0x0),_0x53cfdc=_0x114647;_0x1a5bda['server_']['put'](_0x53cfdc['toString'](),_0x455846,_0xfcf20e=>{ut(_0x1a5bda,'transaction\x20put\x20response',{'path':_0x53cfdc['toString'](),'status':_0xfcf20e});let _0x15fd52=[];if(_0xfcf20e==='ok'){const _0x4accc6=[];for(let _0x32b7b9=0x0;_0x32b7b9<_0x2d5583['length'];_0x32b7b9++)_0x2d5583[_0x32b7b9]['status']=0x2,_0x15fd52=_0x15fd52['concat'](pe(_0x1a5bda['serverSyncTree_'],_0x2d5583[_0x32b7b9]['currentWriteId'])),_0x2d5583[_0x32b7b9]['onComplete']&&_0x4accc6['push'](()=>_0x2d5583[_0x32b7b9]['onComplete'](null,!0x0,_0x2d5583[_0x32b7b9]['currentOutputSnapshotResolved'])),_0x2d5583[_0x32b7b9]['unwatcher']();$n(_0x1a5bda,Un(_0x1a5bda['transactionQueueTree_'],_0x114647)),Hn(_0x1a5bda,_0x1a5bda['transactionQueueTree_']),V(_0x1a5bda['eventQueue_'],_0x114647,_0x15fd52);for(let _0x21ed61=0x0;_0x21ed61<_0x4accc6['length'];_0x21ed61++)lt(_0x4accc6[_0x21ed61]);}else{if(_0xfcf20e==='datastale'){for(let _0x2cc057=0x0;_0x2cc057<_0x2d5583['length'];_0x2cc057++)_0x2d5583[_0x2cc057]['status']===0x3?_0x2d5583[_0x2cc057]['status']=0x4:_0x2d5583[_0x2cc057]['status']=0x0;}else{U('transaction\x20at\x20'+_0x53cfdc['toString']()+'\x20failed:\x20'+_0xfcf20e);for(let _0x228e8a=0x0;_0x228e8a<_0x2d5583['length'];_0x228e8a++)_0x2d5583[_0x228e8a]['status']=0x4,_0x2d5583[_0x228e8a]['abortReason']=_0xfcf20e;}st(_0x1a5bda,_0x114647);}},_0x1a33a0);}function st(_0xa38574,_0x5b676d){const _0x10f3ec=ca(_0xa38574,_0x5b676d),_0x1c494b=Gt(_0x10f3ec),_0x315c38=la(_0xa38574,_0x10f3ec);return Ad(_0xa38574,_0x315c38,_0x1c494b),_0x1c494b;}function Ad(_0x4f7491,_0x32263a,_0x5540aa){if(_0x32263a['length']===0x0)return;const _0x2d4055=[];let _0x342756=[];const _0x39338b=_0x32263a['filter'](_0x4f806e=>_0x4f806e['status']===0x0)['map'](_0x43a693=>_0x43a693['currentWriteId']);for(let _0x363bcd=0x0;_0x363bcd<_0x32263a['length'];_0x363bcd++){const _0x5a2151=_0x32263a[_0x363bcd],_0xb9d3c2=F(_0x5540aa,_0x5a2151['path']);let _0x3114ba=!0x1,_0x2bf2e0;if(f(_0xb9d3c2!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x5a2151['status']===0x4)_0x3114ba=!0x0,_0x2bf2e0=_0x5a2151['abortReason'],_0x342756=_0x342756['concat'](pe(_0x4f7491['serverSyncTree_'],_0x5a2151['currentWriteId'],!0x0));else{if(_0x5a2151['status']===0x0){if(_0x5a2151['retryCount']>=_d)_0x3114ba=!0x0,_0x2bf2e0='maxretry',_0x342756=_0x342756['concat'](pe(_0x4f7491['serverSyncTree_'],_0x5a2151['currentWriteId'],!0x0));else{const _0x44a451=ys(_0x4f7491,_0x5a2151['path'],_0x39338b);_0x5a2151['currentInputSnapshot']=_0x44a451;const _0x3b9935=_0x32263a[_0x363bcd]['update'](_0x44a451['val']());if(_0x3b9935!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x3b9935,_0x5a2151['path']);let _0x106516=N(_0x3b9935);typeof _0x3b9935=='object'&&_0x3b9935!=null&&Y(_0x3b9935,'.priority')||(_0x106516=_0x106516['updatePriority'](_0x44a451['getPriority']()));const _0x243f85=_0x5a2151['currentWriteId'],_0x34c957=jt(_0x4f7491),_0x18ce27=hs(_0x106516,_0x44a451,_0x34c957);_0x5a2151['currentOutputSnapshotRaw']=_0x106516,_0x5a2151['currentOutputSnapshotResolved']=_0x18ce27,_0x5a2151['currentWriteId']=Vn(_0x4f7491),_0x39338b['splice'](_0x39338b['indexOf'](_0x243f85),0x1),_0x342756=_0x342756['concat'](ss(_0x4f7491['serverSyncTree_'],_0x5a2151['path'],_0x18ce27,_0x5a2151['currentWriteId'],_0x5a2151['applyLocally'])),_0x342756=_0x342756['concat'](pe(_0x4f7491['serverSyncTree_'],_0x243f85,!0x0));}else _0x3114ba=!0x0,_0x2bf2e0='nodata',_0x342756=_0x342756['concat'](pe(_0x4f7491['serverSyncTree_'],_0x5a2151['currentWriteId'],!0x0));}}}V(_0x4f7491['eventQueue_'],_0x5540aa,_0x342756),_0x342756=[],_0x3114ba&&(_0x32263a[_0x363bcd]['status']=0x2,function(_0x547a63){setTimeout(_0x547a63,Math['floor'](0x0));}(_0x32263a[_0x363bcd]['unwatcher']),_0x32263a[_0x363bcd]['onComplete']&&(_0x2bf2e0==='nodata'?_0x2d4055['push'](()=>_0x32263a[_0x363bcd]['onComplete'](null,!0x1,_0x32263a[_0x363bcd]['currentInputSnapshot'])):_0x2d4055['push'](()=>_0x32263a[_0x363bcd]['onComplete'](new Error(_0x2bf2e0),!0x1,null))));}$n(_0x4f7491,_0x4f7491['transactionQueueTree_']);for(let _0x435779=0x0;_0x435779<_0x2d4055['length'];_0x435779++)lt(_0x2d4055[_0x435779]);Hn(_0x4f7491,_0x4f7491['transactionQueueTree_']);}function ca(_0x1fa29b,_0x3ccbd3){let _0x42c96c,_0x465dbd=_0x1fa29b['transactionQueueTree_'];for(_0x42c96c=y(_0x3ccbd3);_0x42c96c!==null&&Ge(_0x465dbd)===void 0x0;)_0x465dbd=Un(_0x465dbd,_0x42c96c),_0x3ccbd3=b(_0x3ccbd3),_0x42c96c=y(_0x3ccbd3);return _0x465dbd;}function la(_0x381e21,_0x3b0e91){const _0x3c5908=[];return ha(_0x381e21,_0x3b0e91,_0x3c5908),_0x3c5908['sort']((_0x24bfae,_0x4fd567)=>_0x24bfae['order']-_0x4fd567['order']),_0x3c5908;}function ha(_0x281634,_0xc31e37,_0x17d4bc){const _0x83d6f9=Ge(_0xc31e37);if(_0x83d6f9){for(let _0xa1b78e=0x0;_0xa1b78e<_0x83d6f9['length'];_0xa1b78e++)_0x17d4bc['push'](_0x83d6f9[_0xa1b78e]);}Wn(_0xc31e37,_0x377a59=>{ha(_0x281634,_0x377a59,_0x17d4bc);});}function $n(_0xa8354c,_0x45ece5){const _0x14c54a=Ge(_0x45ece5);if(_0x14c54a){let _0x802535=0x0;for(let _0x55a254=0x0;_0x55a254<_0x14c54a['length'];_0x55a254++)_0x14c54a[_0x55a254]['status']!==0x2&&(_0x14c54a[_0x802535]=_0x14c54a[_0x55a254],_0x802535++);_0x14c54a['length']=_0x802535,fs(_0x45ece5,_0x14c54a['length']>0x0?_0x14c54a:void 0x0);}Wn(_0x45ece5,_0xf70f2b=>{$n(_0xa8354c,_0xf70f2b);});}function vs(_0x2116e5,_0x76a159){const _0xdae673=Gt(ca(_0x2116e5,_0x76a159)),_0xa6919b=Un(_0x2116e5['transactionQueueTree_'],_0x76a159);return sd(_0xa6919b,_0x34fa62=>{ai(_0x2116e5,_0x34fa62);}),ai(_0x2116e5,_0xa6919b),ta(_0xa6919b,_0x4acfa1=>{ai(_0x2116e5,_0x4acfa1);}),_0xdae673;}function ai(_0x317949,_0x289d1e){const _0x552b17=Ge(_0x289d1e);if(_0x552b17){const _0x4b5451=[];let _0x2ad5b3=[],_0x173d39=-0x1;for(let _0x310d43=0x0;_0x310d43<_0x552b17['length'];_0x310d43++)_0x552b17[_0x310d43]['status']===0x3||(_0x552b17[_0x310d43]['status']===0x1?(f(_0x173d39===_0x310d43-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x173d39=_0x310d43,_0x552b17[_0x310d43]['status']=0x3,_0x552b17[_0x310d43]['abortReason']='set'):(f(_0x552b17[_0x310d43]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x552b17[_0x310d43]['unwatcher'](),_0x2ad5b3=_0x2ad5b3['concat'](pe(_0x317949['serverSyncTree_'],_0x552b17[_0x310d43]['currentWriteId'],!0x0)),_0x552b17[_0x310d43]['onComplete']&&_0x4b5451['push'](_0x552b17[_0x310d43]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x173d39===-0x1?fs(_0x289d1e,void 0x0):_0x552b17['length']=_0x173d39+0x1,V(_0x317949['eventQueue_'],Gt(_0x289d1e),_0x2ad5b3);for(let _0x1b1de0=0x0;_0x1b1de0<_0x4b5451['length'];_0x1b1de0++)lt(_0x4b5451[_0x1b1de0]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x457785){let _0x192f70='';const _0x16001c=_0x457785['split']('/');for(let _0x8d82a0=0x0;_0x8d82a0<_0x16001c['length'];_0x8d82a0++)if(_0x16001c[_0x8d82a0]['length']>0x0){let _0x7d2048=_0x16001c[_0x8d82a0];try{_0x7d2048=decodeURIComponent(_0x7d2048['replace'](/\+/g,'\x20'));}catch{}_0x192f70+='/'+_0x7d2048;}return _0x192f70;}function Nd(_0x5d183f){const _0xeb2f93={};_0x5d183f['charAt'](0x0)==='?'&&(_0x5d183f=_0x5d183f['substring'](0x1));for(const _0x34f612 of _0x5d183f['split']('&')){if(_0x34f612['length']===0x0)continue;const _0x5ee8d2=_0x34f612['split']('=');_0x5ee8d2['length']===0x2?_0xeb2f93[decodeURIComponent(_0x5ee8d2[0x0])]=decodeURIComponent(_0x5ee8d2[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x34f612+'\x27\x20in\x20query\x20\x27'+_0x5d183f+'\x27');}return _0xeb2f93;}const gr=function(_0x530cac,_0x2e4903){const _0x18c5c5=Pd(_0x530cac),_0xfb394f=_0x18c5c5['namespace'];_0x18c5c5['domain']==='firebase.com'&&oe(_0x18c5c5['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xfb394f||_0xfb394f==='undefined')&&_0x18c5c5['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x18c5c5['secure']||Bl();const _0xd36657=_0x18c5c5['scheme']==='ws'||_0x18c5c5['scheme']==='wss';return{'repoInfo':new _o(_0x18c5c5['host'],_0x18c5c5['secure'],_0xfb394f,_0xd36657,_0x2e4903,'',_0xfb394f!==_0x18c5c5['subdomain']),'path':new C(_0x18c5c5['pathString'])};},Pd=function(_0x4b6a49){let _0xf4af3b='',_0x20962a='',_0x45700f='',_0x5249cb='',_0x3ad13f='',_0x33b932=!0x0,_0x2559e5='https',_0x14ae76=0x1bb;if(typeof _0x4b6a49=='string'){let _0x2abe61=_0x4b6a49['indexOf']('//');_0x2abe61>=0x0&&(_0x2559e5=_0x4b6a49['substring'](0x0,_0x2abe61-0x1),_0x4b6a49=_0x4b6a49['substring'](_0x2abe61+0x2));let _0x3c4d77=_0x4b6a49['indexOf']('/');_0x3c4d77===-0x1&&(_0x3c4d77=_0x4b6a49['length']);let _0x581d51=_0x4b6a49['indexOf']('?');_0x581d51===-0x1&&(_0x581d51=_0x4b6a49['length']),_0xf4af3b=_0x4b6a49['substring'](0x0,Math['min'](_0x3c4d77,_0x581d51)),_0x3c4d77<_0x581d51&&(_0x5249cb=kd(_0x4b6a49['substring'](_0x3c4d77,_0x581d51)));const _0x40ea98=Nd(_0x4b6a49['substring'](Math['min'](_0x4b6a49['length'],_0x581d51)));_0x2abe61=_0xf4af3b['indexOf'](':'),_0x2abe61>=0x0?(_0x33b932=_0x2559e5==='https'||_0x2559e5==='wss',_0x14ae76=parseInt(_0xf4af3b['substring'](_0x2abe61+0x1),0xa)):_0x2abe61=_0xf4af3b['length'];const _0x4f1db6=_0xf4af3b['slice'](0x0,_0x2abe61);if(_0x4f1db6['toLowerCase']()==='localhost')_0x20962a='localhost';else{if(_0x4f1db6['split']('.')['length']<=0x2)_0x20962a=_0x4f1db6;else{const _0x181eff=_0xf4af3b['indexOf']('.');_0x45700f=_0xf4af3b['substring'](0x0,_0x181eff)['toLowerCase'](),_0x20962a=_0xf4af3b['substring'](_0x181eff+0x1),_0x3ad13f=_0x45700f;}}'ns'in _0x40ea98&&(_0x3ad13f=_0x40ea98['ns']);}return{'host':_0xf4af3b,'port':_0x14ae76,'domain':_0x20962a,'subdomain':_0x45700f,'secure':_0x33b932,'scheme':_0x2559e5,'pathString':_0x5249cb,'namespace':_0x3ad13f};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x28a39a=0x0;const _0x330e9c=[];return function(_0x4a41fa){const _0x1374bd=_0x4a41fa===_0x28a39a;_0x28a39a=_0x4a41fa;let _0x3f4071;const _0x167c38=new Array(0x8);for(_0x3f4071=0x7;_0x3f4071>=0x0;_0x3f4071--)_0x167c38[_0x3f4071]=mr['charAt'](_0x4a41fa%0x40),_0x4a41fa=Math['floor'](_0x4a41fa/0x40);f(_0x4a41fa===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x19518d=_0x167c38['join']('');if(_0x1374bd){for(_0x3f4071=0xb;_0x3f4071>=0x0&&_0x330e9c[_0x3f4071]===0x3f;_0x3f4071--)_0x330e9c[_0x3f4071]=0x0;_0x330e9c[_0x3f4071]++;}else{for(_0x3f4071=0x0;_0x3f4071<0xc;_0x3f4071++)_0x330e9c[_0x3f4071]=Math['floor'](Math['random']()*0x40);}for(_0x3f4071=0x0;_0x3f4071<0xc;_0x3f4071++)_0x19518d+=mr['charAt'](_0x330e9c[_0x3f4071]);return f(_0x19518d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x19518d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x51bdb4,_0x500438,_0x2ccd56,_0x132fe3){this['eventType']=_0x51bdb4,this['eventRegistration']=_0x500438,this['snapshot']=_0x2ccd56,this['prevName']=_0x132fe3;}['getPath'](){const _0x8e5861=this['snapshot']['ref'];return this['eventType']==='value'?_0x8e5861['_path']:_0x8e5861['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x411900,_0x3badf8,_0x16e8ad){this['eventRegistration']=_0x411900,this['error']=_0x3badf8,this['path']=_0x16e8ad;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x30f46f,_0x3bb4b4){this['snapshotCallback']=_0x30f46f,this['cancelCallback']=_0x3bb4b4;}['onValue'](_0x52ba3a,_0x11492a){this['snapshotCallback']['call'](null,_0x52ba3a,_0x11492a);}['onCancel'](_0x20be43){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x20be43);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x578bf1){return this['snapshotCallback']===_0x578bf1['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x578bf1['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x578bf1['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x4d4448,_0x5c83fd,_0x1ed6da,_0x4337fd){this['_repo']=_0x4d4448,this['_path']=_0x5c83fd,this['_queryParams']=_0x1ed6da,this['_orderByCalled']=_0x4337fd;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x3383d9=nr(this['_queryParams']),_0x1cf3a2=Bi(_0x3383d9);return _0x1cf3a2==='{}'?'default':_0x1cf3a2;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x11e592){if(_0x11e592=k(_0x11e592),!(_0x11e592 instanceof be))return!0x1;const _0x458fd8=this['_repo']===_0x11e592['_repo'],_0x552bff=qi(this['_path'],_0x11e592['_path']),_0x3877c4=this['_queryIdentifier']===_0x11e592['_queryIdentifier'];return _0x458fd8&&_0x552bff&&_0x3877c4;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x1019f5,_0x56e759){if(_0x1019f5['_orderByCalled']===!0x0)throw new Error(_0x56e759+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x400291){let _0x4f6c81=null,_0x550cd8=null;if(_0x400291['hasStart']()&&(_0x4f6c81=_0x400291['getIndexStartValue']()),_0x400291['hasEnd']()&&(_0x550cd8=_0x400291['getIndexEndValue']()),_0x400291['getIndex']()===ye){const _0x2d7e8f='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3fb8c9='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x400291['hasStart']()){if(_0x400291['getIndexStartName']()!==xe)throw new Error(_0x2d7e8f);if(typeof _0x4f6c81!='string')throw new Error(_0x3fb8c9);}if(_0x400291['hasEnd']()){if(_0x400291['getIndexEndName']()!==Ie)throw new Error(_0x2d7e8f);if(typeof _0x550cd8!='string')throw new Error(_0x3fb8c9);}}else{if(_0x400291['getIndex']()===R){if(_0x4f6c81!=null&&!Cn(_0x4f6c81)||_0x550cd8!=null&&!Cn(_0x550cd8))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x400291['getIndex']()instanceof Ki||_0x400291['getIndex']()===Po,'unknown\x20index\x20type.'),_0x4f6c81!=null&&typeof _0x4f6c81=='object'||_0x550cd8!=null&&typeof _0x550cd8=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x3efeb9){if(_0x3efeb9['hasStart']()&&_0x3efeb9['hasEnd']()&&_0x3efeb9['hasLimit']()&&!_0x3efeb9['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x465563,_0x3b9ccf){super(_0x465563,_0x3b9ccf,new Qi(),!0x1);}get['parent'](){const _0x1a4fb8=To(this['_path']);return _0x1a4fb8===null?null:new Z(this['_repo'],_0x1a4fb8);}get['root'](){let _0x5bcc08=this;for(;_0x5bcc08['parent']!==null;)_0x5bcc08=_0x5bcc08['parent'];return _0x5bcc08;}}class rt{constructor(_0xa243f4,_0x6e446b,_0x1799c8){this['_node']=_0xa243f4,this['ref']=_0x6e446b,this['_index']=_0x1799c8;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x42a7c3){const _0x18afb5=new C(_0x42a7c3),_0x3d0fc4=Lt(this['ref'],_0x42a7c3);return new rt(this['_node']['getChild'](_0x18afb5),_0x3d0fc4,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x25b9f2){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x19ca3b,_0x8e50e)=>_0x25b9f2(new rt(_0x8e50e,Lt(this['ref'],_0x19ca3b),R)));}['hasChild'](_0x5f32b9){const _0x264f0b=new C(_0x5f32b9);return!this['_node']['getChild'](_0x264f0b)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x4e0f16,_0x5035e6){return _0x4e0f16=k(_0x4e0f16),_0x4e0f16['_checkNotDeleted']('ref'),_0x5035e6!==void 0x0?Lt(_0x4e0f16['_root'],_0x5035e6):_0x4e0f16['_root'];}function Lt(_0x136a1d,_0x19c77b){return _0x136a1d=k(_0x136a1d),y(_0x136a1d['_path'])===null?ud('child','path',_0x19c77b):_s('child','path',_0x19c77b),new Z(_0x136a1d['_repo'],A(_0x136a1d['_path'],_0x19c77b));}function d_(_0x33dbbb,_0xac36a3){_0x33dbbb=k(_0x33dbbb),gs('push',_0x33dbbb['_path']),qt('push',_0xac36a3,_0x33dbbb['_path'],!0x0);const _0xcf3d6f=oa(_0x33dbbb['_repo']),_0x58faf6=Od(_0xcf3d6f),_0x363fd2=Lt(_0x33dbbb,_0x58faf6),_0x59c4c3=Lt(_0x33dbbb,_0x58faf6);let _0x64ff6f;return _0xac36a3!=null?_0x64ff6f=Ld(_0x59c4c3,_0xac36a3)['then'](()=>_0x59c4c3):_0x64ff6f=Promise['resolve'](_0x59c4c3),_0x363fd2['then']=_0x64ff6f['then']['bind'](_0x64ff6f),_0x363fd2['catch']=_0x64ff6f['then']['bind'](_0x64ff6f,void 0x0),_0x363fd2;}function Ld(_0x2f4c11,_0x20db68){_0x2f4c11=k(_0x2f4c11),gs('set',_0x2f4c11['_path']),qt('set',_0x20db68,_0x2f4c11['_path'],!0x1);const _0x44c0c9=new Ve();return Ed(_0x2f4c11['_repo'],_0x2f4c11['_path'],_0x20db68,null,_0x44c0c9['wrapCallback'](()=>{})),_0x44c0c9['promise'];}function f_(_0x1ccde1,_0x53d9d1){hd('update',_0x53d9d1,_0x1ccde1['_path']);const _0x120ccd=new Ve();return Id(_0x1ccde1['_repo'],_0x1ccde1['_path'],_0x53d9d1,_0x120ccd['wrapCallback'](()=>{})),_0x120ccd['promise'];}function p_(_0x57193e){_0x57193e=k(_0x57193e);const _0x37129b=new ua(()=>{}),_0x590ee6=new qn(_0x37129b);return vd(_0x57193e['_repo'],_0x57193e,_0x590ee6)['then'](_0x3c7570=>new rt(_0x3c7570,new Z(_0x57193e['_repo'],_0x57193e['_path']),_0x57193e['_queryParams']['getIndex']()));}class qn{constructor(_0x4af0a5){this['callbackContext']=_0x4af0a5;}['respondsTo'](_0x25ce94){return _0x25ce94==='value';}['createEvent'](_0x47abd3,_0x269d9d){const _0x1feff7=_0x269d9d['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x47abd3['snapshotNode'],new Z(_0x269d9d['_repo'],_0x269d9d['_path']),_0x1feff7));}['getEventRunner'](_0x17a6d2){return _0x17a6d2['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x17a6d2['error']):()=>this['callbackContext']['onValue'](_0x17a6d2['snapshot'],null);}['createCancelEvent'](_0x55f3c0,_0xfad453){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x55f3c0,_0xfad453):null;}['matches'](_0x59e3ae){return _0x59e3ae instanceof qn?!_0x59e3ae['callbackContext']||!this['callbackContext']?!0x0:_0x59e3ae['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x233751,_0x509493,_0x536639,_0x274f6a,_0x5e2bf2){const _0xda8621=new ua(_0x536639,void 0x0),_0x3ca06b=new qn(_0xda8621);return Cd(_0x233751['_repo'],_0x233751,_0x3ca06b),()=>Td(_0x233751['_repo'],_0x233751,_0x3ca06b);}function Fd(_0x46aef1,_0x7af613,_0x4569e9,_0x103749){return xd(_0x46aef1,'value',_0x7af613);}class dt{}class pa extends dt{constructor(_0x32b2f0,_0x1752d7){super(),this['_value']=_0x32b2f0,this['_key']=_0x1752d7,this['type']='endAt';}['_apply'](_0x1e0e4a){qt('endAt',this['_value'],_0x1e0e4a['_path'],!0x0);const _0x1e1c71=Kh(_0x1e0e4a['_queryParams'],this['_value'],this['_key']);if(fa(_0x1e1c71),Gn(_0x1e1c71),_0x1e0e4a['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x1e0e4a['_repo'],_0x1e0e4a['_path'],_0x1e1c71,_0x1e0e4a['_orderByCalled']);}}function __(_0x28e49a,_0x3bd807){return new pa(_0x28e49a,_0x3bd807);}class _a extends dt{constructor(_0x5916c7,_0x38ccdf){super(),this['_value']=_0x5916c7,this['_key']=_0x38ccdf,this['type']='startAt';}['_apply'](_0x2a1b19){qt('startAt',this['_value'],_0x2a1b19['_path'],!0x0);const _0x3309b2=jh(_0x2a1b19['_queryParams'],this['_value'],this['_key']);if(fa(_0x3309b2),Gn(_0x3309b2),_0x2a1b19['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x2a1b19['_repo'],_0x2a1b19['_path'],_0x3309b2,_0x2a1b19['_orderByCalled']);}}function g_(_0x389dfe=null,_0x5398ee){return new _a(_0x389dfe,_0x5398ee);}class Ud extends dt{constructor(_0x519c9e){super(),this['_limit']=_0x519c9e,this['type']='limitToFirst';}['_apply'](_0x1b3671){if(_0x1b3671['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x1b3671['_repo'],_0x1b3671['_path'],zh(_0x1b3671['_queryParams'],this['_limit']),_0x1b3671['_orderByCalled']);}}function m_(_0x330f42){if(Math['floor'](_0x330f42)!==_0x330f42||_0x330f42<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x330f42);}class Wd extends dt{constructor(_0xc4c3cf){super(),this['_path']=_0xc4c3cf,this['type']='orderByChild';}['_apply'](_0x298948){da(_0x298948,'orderByChild');const _0x1f3451=new C(this['_path']);if(v(_0x1f3451))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x551571=new Ki(_0x1f3451),_0x5200c4=Do(_0x298948['_queryParams'],_0x551571);return Gn(_0x5200c4),new be(_0x298948['_repo'],_0x298948['_path'],_0x5200c4,!0x0);}}function y_(_0xbc7e52){if(_0xbc7e52==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0xbc7e52==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0xbc7e52==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0xbc7e52),new Wd(_0xbc7e52);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x48d138){da(_0x48d138,'orderByKey');const _0x3b6b5f=Do(_0x48d138['_queryParams'],ye);return Gn(_0x3b6b5f),new be(_0x48d138['_repo'],_0x48d138['_path'],_0x3b6b5f,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x5f1bd0,_0xe94f79){super(),this['_value']=_0x5f1bd0,this['_key']=_0xe94f79,this['type']='equalTo';}['_apply'](_0xddca2b){if(qt('equalTo',this['_value'],_0xddca2b['_path'],!0x1),_0xddca2b['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0xddca2b['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0xddca2b));}}function E_(_0x4cb39f,_0x2bb648){return new Vd(_0x4cb39f,_0x2bb648);}function I_(_0xf8ab71,..._0x4ea925){let _0x8456f3=k(_0xf8ab71);for(const _0x46288a of _0x4ea925)_0x8456f3=_0x46288a['_apply'](_0x8456f3);return _0x8456f3;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x123629,_0x4dfa1d,_0x348995,_0x481b7b){const _0x5c4eb6=_0x4dfa1d['lastIndexOf'](':'),_0x5400c0=_0x4dfa1d['substring'](0x0,_0x5c4eb6),_0x405d2e=Wt(_0x5400c0);_0x123629['repoInfo_']=new _o(_0x4dfa1d,_0x405d2e,_0x123629['repoInfo_']['namespace'],_0x123629['repoInfo_']['webSocketOnly'],_0x123629['repoInfo_']['nodeAdmin'],_0x123629['repoInfo_']['persistenceKey'],_0x123629['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x348995),_0x481b7b&&(_0x123629['authTokenProvider_']=_0x481b7b);}function qd(_0x44ceb4,_0x4a5bd6,_0x27da01,_0x1dabc2,_0x1b3e28){let _0x3c0340=_0x1dabc2||_0x44ceb4['options']['databaseURL'];_0x3c0340===void 0x0&&(_0x44ceb4['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x44ceb4['options']['projectId']),_0x3c0340=_0x44ceb4['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x37caf2=gr(_0x3c0340,_0x1b3e28),_0x40f88c=_0x37caf2['repoInfo'],_0x4a33a4;typeof process<'u'&&Us&&(_0x4a33a4=Us[Hd]),_0x4a33a4?(_0x3c0340='http://'+_0x4a33a4+'?ns='+_0x40f88c['namespace'],_0x37caf2=gr(_0x3c0340,_0x1b3e28),_0x40f88c=_0x37caf2['repoInfo']):_0x37caf2['repoInfo']['secure'];const _0x1024ae=new Jl(_0x44ceb4['name'],_0x44ceb4['options'],_0x4a5bd6);dd('Invalid\x20Firebase\x20Database\x20URL',_0x37caf2),v(_0x37caf2['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x304c0f=jd(_0x40f88c,_0x44ceb4,_0x1024ae,new Ql(_0x44ceb4,_0x27da01));return new Kd(_0x304c0f,_0x44ceb4);}function zd(_0x453f3a,_0x43cf5b){const _0x2fd7fe=ki[_0x43cf5b];(!_0x2fd7fe||_0x2fd7fe[_0x453f3a['key']]!==_0x453f3a)&&oe('Database\x20'+_0x43cf5b+'('+_0x453f3a['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x453f3a),delete _0x2fd7fe[_0x453f3a['key']];}function jd(_0x3c751d,_0x443293,_0x299fa7,_0x267955){let _0x20de07=ki[_0x443293['name']];_0x20de07||(_0x20de07={},ki[_0x443293['name']]=_0x20de07);let _0x1b2518=_0x20de07[_0x3c751d['toURLString']()];return _0x1b2518&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1b2518=new gd(_0x3c751d,$d,_0x299fa7,_0x267955),_0x20de07[_0x3c751d['toURLString']()]=_0x1b2518,_0x1b2518;}class Kd{constructor(_0x12db46,_0x4d58cd){this['_repoInternal']=_0x12db46,this['app']=_0x4d58cd,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x7cdef6){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x7cdef6+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x3ddb51=Qr(),_0x55aaf4){const _0x3e99c7=Ui(_0x3ddb51,'database')['getImmediate']({'identifier':_0x55aaf4});if(!_0x3e99c7['_instanceStarted']){const _0xd3b831=ac('database');_0xd3b831&&Yd(_0x3e99c7,..._0xd3b831);}return _0x3e99c7;}function Yd(_0x4ed7c4,_0x477bb2,_0x3d73a9,_0x370c53={}){_0x4ed7c4=k(_0x4ed7c4),_0x4ed7c4['_checkNotDeleted']('useEmulator');const _0x17c89c=_0x477bb2+':'+_0x3d73a9,_0x33ba4a=_0x4ed7c4['_repoInternal'];if(_0x4ed7c4['_instanceStarted']){if(_0x17c89c===_0x4ed7c4['_repoInternal']['repoInfo_']['host']&&De(_0x370c53,_0x33ba4a['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4c8f31;if(_0x33ba4a['repoInfo_']['nodeAdmin'])_0x370c53['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4c8f31=new tn(tn['OWNER']);else{if(_0x370c53['mockUserToken']){const _0x224aa3=typeof _0x370c53['mockUserToken']=='string'?_0x370c53['mockUserToken']:cc(_0x370c53['mockUserToken'],_0x4ed7c4['app']['options']['projectId']);_0x4c8f31=new tn(_0x224aa3);}}Wt(_0x477bb2)&&jr(_0x477bb2),Gd(_0x33ba4a,_0x17c89c,_0x370c53,_0x4c8f31);}function C_(_0x5ead2f){_0x5ead2f=k(_0x5ead2f),_0x5ead2f['_checkNotDeleted']('goOffline'),aa(_0x5ead2f['_repo']);}function T_(_0x12c420){_0x12c420=k(_0x12c420),_0x12c420['_checkNotDeleted']('goOnline'),Sd(_0x12c420['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x4baf22){Ll(ct),et(new Me('database',(_0x4f279,{instanceIdentifier:_0x37dd10})=>{const _0x7591e=_0x4f279['getProvider']('app')['getImmediate'](),_0x472eae=_0x4f279['getProvider']('auth-internal'),_0x2cb802=_0x4f279['getProvider']('app-check-internal');return qd(_0x7591e,_0x472eae,_0x2cb802,_0x37dd10);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x4baf22),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x4fa96e,_0x7ea257){this['committed']=_0x4fa96e,this['snapshot']=_0x7ea257;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x3acb95,_0xe835ae,_0x38e47e){if(_0x3acb95=k(_0x3acb95),gs('Reference.transaction',_0x3acb95['_path']),_0x3acb95['key']==='.length'||_0x3acb95['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3acb95['key']+'\x20is\x20a\x20read-only\x20object.';const _0x145694=!0x0,_0x4e3b5a=new Ve(),_0x5ebc37=(_0x283555,_0x116e71,_0x13da97)=>{let _0xc51ee6=null;_0x283555?_0x4e3b5a['reject'](_0x283555):(_0xc51ee6=new rt(_0x13da97,new Z(_0x3acb95['_repo'],_0x3acb95['_path']),R),_0x4e3b5a['resolve'](new Xd(_0x116e71,_0xc51ee6)));},_0x30a2e0=Fd(_0x3acb95,()=>{});return bd(_0x3acb95['_repo'],_0x3acb95['_path'],_0xe835ae,_0x5ebc37,_0x30a2e0,_0x145694),_0x4e3b5a['promise'];}ie['prototype']['simpleListen']=function(_0x314ce5,_0x32a18e){this['sendRequest']('q',{'p':_0x314ce5},_0x32a18e);},ie['prototype']['echo']=function(_0x3361e2,_0x17dfdc){this['sendRequest']('echo',{'d':_0x3361e2},_0x17dfdc);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x9b926e,..._0x594ea4){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x9b926e,..._0x594ea4);}function nn(_0x4d9e71,..._0x35e31e){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x4d9e71,..._0x35e31e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x5011d4,..._0x4d67e3){throw Es(_0x5011d4,..._0x4d67e3);}function J(_0x5c848b,..._0x244bb0){return Es(_0x5c848b,..._0x244bb0);}function ya(_0x12c138,_0x53d808,_0x38f14b){const _0x280580={...Zd(),[_0x53d808]:_0x38f14b};return new Ut('auth','Firebase',_0x280580)['create'](_0x53d808,{'appName':_0x12c138['name']});}function se(_0x2bbb32){return ya(_0x2bbb32,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x261bf3,..._0x540cef){if(typeof _0x261bf3!='string'){const _0x1230d8=_0x540cef[0x0],_0x1af90b=[..._0x540cef['slice'](0x1)];return _0x1af90b[0x0]&&(_0x1af90b[0x0]['appName']=_0x261bf3['name']),_0x261bf3['_errorFactory']['create'](_0x1230d8,..._0x1af90b);}return ma['create'](_0x261bf3,..._0x540cef);}function m(_0x290db9,_0x137573,..._0x16c876){if(!_0x290db9)throw Es(_0x137573,..._0x16c876);}function te(_0x119d70){const _0x4ef501='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x119d70;throw nn(_0x4ef501),new Error(_0x4ef501);}function ae(_0x1b21a5,_0x2e4f78){_0x1b21a5||te(_0x2e4f78);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x16f8d8;return typeof self<'u'&&((_0x16f8d8=self['location'])==null?void 0x0:_0x16f8d8['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x26defc;return typeof self<'u'&&((_0x26defc=self['location'])==null?void 0x0:_0x26defc['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x18ce5e=navigator;return _0x18ce5e['languages']&&_0x18ce5e['languages'][0x0]||_0x18ce5e['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0xcdaf56,_0x2a7587){this['shortDelay']=_0xcdaf56,this['longDelay']=_0x2a7587,ae(_0x2a7587>_0xcdaf56,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x47d2d8,_0x15f002){ae(_0x47d2d8['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3b1681}=_0x47d2d8['emulator'];return _0x15f002?''+_0x3b1681+(_0x15f002['startsWith']('/')?_0x15f002['slice'](0x1):_0x15f002):_0x3b1681;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x5637ed,_0x5537d5,_0x5e1217){this['fetchImpl']=_0x5637ed,_0x5537d5&&(this['headersImpl']=_0x5537d5),_0x5e1217&&(this['responseImpl']=_0x5e1217);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x14c805,_0x2add22){return _0x14c805['tenantId']&&!_0x2add22['tenantId']?{..._0x2add22,'tenantId':_0x14c805['tenantId']}:_0x2add22;}async function Ae(_0x2b3b21,_0x298473,_0x324395,_0x31ffcf,_0x3d06b8={}){return Ea(_0x2b3b21,_0x3d06b8,async()=>{let _0xcd4c51={},_0x4e2119={};_0x31ffcf&&(_0x298473==='GET'?_0x4e2119=_0x31ffcf:_0xcd4c51={'body':JSON['stringify'](_0x31ffcf)});const _0x407369=at({..._0x4e2119,'key':_0x2b3b21['config']['apiKey']})['slice'](0x1),_0x2cdf36=await _0x2b3b21['_getAdditionalHeaders']();_0x2cdf36['Content-Type']='application/json',_0x2b3b21['languageCode']&&(_0x2cdf36['X-Firebase-Locale']=_0x2b3b21['languageCode']);const _0x473569={'method':_0x298473,'headers':_0x2cdf36,..._0xcd4c51};return lc()||(_0x473569['referrerPolicy']='strict-origin-when-cross-origin'),_0x2b3b21['emulatorConfig']&&Wt(_0x2b3b21['emulatorConfig']['host'])&&(_0x473569['credentials']='include'),va['fetch']()(await Ia(_0x2b3b21,_0x2b3b21['config']['apiHost'],_0x324395,_0x407369),_0x473569);});}async function Ea(_0x379f25,_0xf7e1ec,_0x350bfe){_0x379f25['_canInitEmulator']=!0x1;const _0x43ffdc={...rf,..._0xf7e1ec};try{const _0x29c14d=new lf(_0x379f25),_0x3ae0f3=await Promise['race']([_0x350bfe(),_0x29c14d['promise']]);_0x29c14d['clearNetworkTimeout']();const _0x117604=await _0x3ae0f3['json']();if('needConfirmation'in _0x117604)throw en(_0x379f25,'account-exists-with-different-credential',_0x117604);if(_0x3ae0f3['ok']&&!('errorMessage'in _0x117604))return _0x117604;{const _0x35a6e0=_0x3ae0f3['ok']?_0x117604['errorMessage']:_0x117604['error']['message'],[_0x443c5c,_0x4284a8]=_0x35a6e0['split']('\x20:\x20');if(_0x443c5c==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x379f25,'credential-already-in-use',_0x117604);if(_0x443c5c==='EMAIL_EXISTS')throw en(_0x379f25,'email-already-in-use',_0x117604);if(_0x443c5c==='USER_DISABLED')throw en(_0x379f25,'user-disabled',_0x117604);const _0x49ebc1=_0x43ffdc[_0x443c5c]||_0x443c5c['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4284a8)throw ya(_0x379f25,_0x49ebc1,_0x4284a8);K(_0x379f25,_0x49ebc1);}}catch(_0x5de725){if(_0x5de725 instanceof Se)throw _0x5de725;K(_0x379f25,'network-request-failed',{'message':String(_0x5de725)});}}async function Yt(_0x4b5a4b,_0x4dd0e2,_0x562d7c,_0x316633,_0x501d14={}){const _0x45c964=await Ae(_0x4b5a4b,_0x4dd0e2,_0x562d7c,_0x316633,_0x501d14);return'mfaPendingCredential'in _0x45c964&&K(_0x4b5a4b,'multi-factor-auth-required',{'_serverResponse':_0x45c964}),_0x45c964;}async function Ia(_0x49b964,_0x1ee703,_0x1fe5a5,_0x12eced){const _0x50ee62=''+_0x1ee703+_0x1fe5a5+'?'+_0x12eced,_0x57ffdf=_0x49b964,_0xeb7b=_0x57ffdf['config']['emulator']?Is(_0x49b964['config'],_0x50ee62):_0x49b964['config']['apiScheme']+'://'+_0x50ee62;return of['includes'](_0x1fe5a5)&&(await _0x57ffdf['_persistenceManagerAvailable'],_0x57ffdf['_getPersistenceType']()==='COOKIE')?_0x57ffdf['_getPersistence']()['_getFinalTarget'](_0xeb7b)['toString']():_0xeb7b;}function cf(_0x1ee126){switch(_0x1ee126){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x310e6b){this['auth']=_0x310e6b,this['timer']=null,this['promise']=new Promise((_0x82c835,_0x495898)=>{this['timer']=setTimeout(()=>_0x495898(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0xc4c7fa,_0x547566,_0x590de9){const _0x5a205c={'appName':_0xc4c7fa['name']};_0x590de9['email']&&(_0x5a205c['email']=_0x590de9['email']),_0x590de9['phoneNumber']&&(_0x5a205c['phoneNumber']=_0x590de9['phoneNumber']);const _0x41b33f=J(_0xc4c7fa,_0x547566,_0x5a205c);return _0x41b33f['customData']['_tokenResponse']=_0x590de9,_0x41b33f;}function vr(_0x2e3fe7){return _0x2e3fe7!==void 0x0&&_0x2e3fe7['enterprise']!==void 0x0;}class hf{constructor(_0x4a325b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4a325b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4a325b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4a325b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1380ef){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x18c86a of this['recaptchaEnforcementState'])if(_0x18c86a['provider']&&_0x18c86a['provider']===_0x1380ef)return cf(_0x18c86a['enforcementState']);return null;}['isProviderEnabled'](_0x3c1eb3){return this['getProviderEnforcementState'](_0x3c1eb3)==='ENFORCE'||this['getProviderEnforcementState'](_0x3c1eb3)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x4b261b,_0x5a5ab2){return Ae(_0x4b261b,'GET','/v2/recaptchaConfig',Re(_0x4b261b,_0x5a5ab2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x1de94c,_0xdc8c1d){return Ae(_0x1de94c,'POST','/v1/accounts:delete',_0xdc8c1d);}async function Sn(_0x56f68d,_0x47755e){return Ae(_0x56f68d,'POST','/v1/accounts:lookup',_0x47755e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x59810e){if(_0x59810e)try{const _0x48b1be=new Date(Number(_0x59810e));if(!isNaN(_0x48b1be['getTime']()))return _0x48b1be['toUTCString']();}catch{}}async function ff(_0x5264e6,_0x5d74e1=!0x1){const _0x2ab051=k(_0x5264e6),_0x3c5b4c=await _0x2ab051['getIdToken'](_0x5d74e1),_0x254418=ws(_0x3c5b4c);m(_0x254418&&_0x254418['exp']&&_0x254418['auth_time']&&_0x254418['iat'],_0x2ab051['auth'],'internal-error');const _0x2fe1ce=typeof _0x254418['firebase']=='object'?_0x254418['firebase']:void 0x0,_0x3ed4d4=_0x2fe1ce==null?void 0x0:_0x2fe1ce['sign_in_provider'];return{'claims':_0x254418,'token':_0x3c5b4c,'authTime':St(ci(_0x254418['auth_time'])),'issuedAtTime':St(ci(_0x254418['iat'])),'expirationTime':St(ci(_0x254418['exp'])),'signInProvider':_0x3ed4d4||null,'signInSecondFactor':(_0x2fe1ce==null?void 0x0:_0x2fe1ce['sign_in_second_factor'])||null};}function ci(_0x26e8a8){return Number(_0x26e8a8)*0x3e8;}function ws(_0x4ee72b){const [_0x2d91ed,_0x26b89a,_0x5245f0]=_0x4ee72b['split']('.');if(_0x2d91ed===void 0x0||_0x26b89a===void 0x0||_0x5245f0===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x5af1c5=cn(_0x26b89a);return _0x5af1c5?JSON['parse'](_0x5af1c5):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x10d4ee){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x10d4ee==null?void 0x0:_0x10d4ee['toString']()),null;}}function Er(_0x33acb4){const _0x13e9da=ws(_0x33acb4);return m(_0x13e9da,'internal-error'),m(typeof _0x13e9da['exp']<'u','internal-error'),m(typeof _0x13e9da['iat']<'u','internal-error'),Number(_0x13e9da['exp'])-Number(_0x13e9da['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x245af7,_0x39133b,_0x3a57c4=!0x1){if(_0x3a57c4)return _0x39133b;try{return await _0x39133b;}catch(_0x3002fc){throw _0x3002fc instanceof Se&&pf(_0x3002fc)&&_0x245af7['auth']['currentUser']===_0x245af7&&await _0x245af7['auth']['signOut'](),_0x3002fc;}}function pf({code:_0x12094e}){return _0x12094e==='auth/user-disabled'||_0x12094e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x409159){this['user']=_0x409159,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2d15c8){if(_0x2d15c8){const _0x2334d8=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2334d8;}else{this['errorBackoff']=0x7530;const _0x5bdd6f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5bdd6f);}}['schedule'](_0x37593b=!0x1){if(!this['isRunning'])return;const _0x5a1b3b=this['getInterval'](_0x37593b);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5a1b3b);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x527f62){(_0x527f62==null?void 0x0:_0x527f62['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5cb6ef,_0x462f23){this['createdAt']=_0x5cb6ef,this['lastLoginAt']=_0x462f23,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x2c055d){this['createdAt']=_0x2c055d['createdAt'],this['lastLoginAt']=_0x2c055d['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x21df0c){var _0x254101;const _0x12e87f=_0x21df0c['auth'],_0x5462ea=await _0x21df0c['getIdToken'](),_0xcd4784=await xt(_0x21df0c,Sn(_0x12e87f,{'idToken':_0x5462ea}));m(_0xcd4784==null?void 0x0:_0xcd4784['users']['length'],_0x12e87f,'internal-error');const _0x28352e=_0xcd4784['users'][0x0];_0x21df0c['_notifyReloadListener'](_0x28352e);const _0x17ff02=(_0x254101=_0x28352e['providerUserInfo'])!=null&&_0x254101['length']?wa(_0x28352e['providerUserInfo']):[],_0x418983=mf(_0x21df0c['providerData'],_0x17ff02),_0x51176b=_0x21df0c['isAnonymous'],_0x12425c=!(_0x21df0c['email']&&_0x28352e['passwordHash'])&&!(_0x418983!=null&&_0x418983['length']),_0x33c87c=_0x51176b?_0x12425c:!0x1,_0x3a6920={'uid':_0x28352e['localId'],'displayName':_0x28352e['displayName']||null,'photoURL':_0x28352e['photoUrl']||null,'email':_0x28352e['email']||null,'emailVerified':_0x28352e['emailVerified']||!0x1,'phoneNumber':_0x28352e['phoneNumber']||null,'tenantId':_0x28352e['tenantId']||null,'providerData':_0x418983,'metadata':new Pi(_0x28352e['createdAt'],_0x28352e['lastLoginAt']),'isAnonymous':_0x33c87c};Object['assign'](_0x21df0c,_0x3a6920);}async function gf(_0x47a6d7){const _0x54cbd9=k(_0x47a6d7);await bn(_0x54cbd9),await _0x54cbd9['auth']['_persistUserIfCurrent'](_0x54cbd9),_0x54cbd9['auth']['_notifyListenersIfCurrent'](_0x54cbd9);}function mf(_0x5f3eb4,_0x584fa9){return[..._0x5f3eb4['filter'](_0x107c39=>!_0x584fa9['some'](_0x2e4117=>_0x2e4117['providerId']===_0x107c39['providerId'])),..._0x584fa9];}function wa(_0x4b6693){return _0x4b6693['map'](({providerId:_0x5dcc1e,..._0x58d32d})=>({'providerId':_0x5dcc1e,'uid':_0x58d32d['rawId']||'','displayName':_0x58d32d['displayName']||null,'email':_0x58d32d['email']||null,'phoneNumber':_0x58d32d['phoneNumber']||null,'photoURL':_0x58d32d['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x5d26ba,_0x311971){const _0x301d16=await Ea(_0x5d26ba,{},async()=>{const _0x279b92=at({'grant_type':'refresh_token','refresh_token':_0x311971})['slice'](0x1),{tokenApiHost:_0x423b92,apiKey:_0x34a8c6}=_0x5d26ba['config'],_0x30fc27=await Ia(_0x5d26ba,_0x423b92,'/v1/token','key='+_0x34a8c6),_0x560da4=await _0x5d26ba['_getAdditionalHeaders']();_0x560da4['Content-Type']='application/x-www-form-urlencoded';const _0x1d5927={'method':'POST','headers':_0x560da4,'body':_0x279b92};return _0x5d26ba['emulatorConfig']&&Wt(_0x5d26ba['emulatorConfig']['host'])&&(_0x1d5927['credentials']='include'),va['fetch']()(_0x30fc27,_0x1d5927);});return{'accessToken':_0x301d16['access_token'],'expiresIn':_0x301d16['expires_in'],'refreshToken':_0x301d16['refresh_token']};}async function vf(_0x126563,_0x198881){return Ae(_0x126563,'POST','/v2/accounts:revokeToken',Re(_0x126563,_0x198881));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x30f9cc){m(_0x30f9cc['idToken'],'internal-error'),m(typeof _0x30f9cc['idToken']<'u','internal-error'),m(typeof _0x30f9cc['refreshToken']<'u','internal-error');const _0x2ab957='expiresIn'in _0x30f9cc&&typeof _0x30f9cc['expiresIn']<'u'?Number(_0x30f9cc['expiresIn']):Er(_0x30f9cc['idToken']);this['updateTokensAndExpiration'](_0x30f9cc['idToken'],_0x30f9cc['refreshToken'],_0x2ab957);}['updateFromIdToken'](_0x1cd973){m(_0x1cd973['length']!==0x0,'internal-error');const _0x1b5f14=Er(_0x1cd973);this['updateTokensAndExpiration'](_0x1cd973,null,_0x1b5f14);}async['getToken'](_0x16c0a2,_0x5eb9c=!0x1){return!_0x5eb9c&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x16c0a2,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x16c0a2,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x5dacef,_0xeb324d){const {accessToken:_0x40b9b5,refreshToken:_0x23ec56,expiresIn:_0x595c95}=await yf(_0x5dacef,_0xeb324d);this['updateTokensAndExpiration'](_0x40b9b5,_0x23ec56,Number(_0x595c95));}['updateTokensAndExpiration'](_0xb50b5c,_0x320f3f,_0x3a2ca4){this['refreshToken']=_0x320f3f||null,this['accessToken']=_0xb50b5c||null,this['expirationTime']=Date['now']()+_0x3a2ca4*0x3e8;}static['fromJSON'](_0x13415f,_0x118efb){const {refreshToken:_0xd456a3,accessToken:_0x3b0e8d,expirationTime:_0x2faa67}=_0x118efb,_0x1bd29a=new Je();return _0xd456a3&&(m(typeof _0xd456a3=='string','internal-error',{'appName':_0x13415f}),_0x1bd29a['refreshToken']=_0xd456a3),_0x3b0e8d&&(m(typeof _0x3b0e8d=='string','internal-error',{'appName':_0x13415f}),_0x1bd29a['accessToken']=_0x3b0e8d),_0x2faa67&&(m(typeof _0x2faa67=='number','internal-error',{'appName':_0x13415f}),_0x1bd29a['expirationTime']=_0x2faa67),_0x1bd29a;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x28bba7){this['accessToken']=_0x28bba7['accessToken'],this['refreshToken']=_0x28bba7['refreshToken'],this['expirationTime']=_0x28bba7['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x1b63c2,_0x1f3c67){m(typeof _0x1b63c2=='string'||typeof _0x1b63c2>'u','internal-error',{'appName':_0x1f3c67});}class z{constructor({uid:_0x1fa481,auth:_0x3ca9bb,stsTokenManager:_0x77e4b5,..._0x14e5f6}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1fa481,this['auth']=_0x3ca9bb,this['stsTokenManager']=_0x77e4b5,this['accessToken']=_0x77e4b5['accessToken'],this['displayName']=_0x14e5f6['displayName']||null,this['email']=_0x14e5f6['email']||null,this['emailVerified']=_0x14e5f6['emailVerified']||!0x1,this['phoneNumber']=_0x14e5f6['phoneNumber']||null,this['photoURL']=_0x14e5f6['photoURL']||null,this['isAnonymous']=_0x14e5f6['isAnonymous']||!0x1,this['tenantId']=_0x14e5f6['tenantId']||null,this['providerData']=_0x14e5f6['providerData']?[..._0x14e5f6['providerData']]:[],this['metadata']=new Pi(_0x14e5f6['createdAt']||void 0x0,_0x14e5f6['lastLoginAt']||void 0x0);}async['getIdToken'](_0x59e05e){const _0x3ac87e=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x59e05e));return m(_0x3ac87e,this['auth'],'internal-error'),this['accessToken']!==_0x3ac87e&&(this['accessToken']=_0x3ac87e,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3ac87e;}['getIdTokenResult'](_0x1dbcfb){return ff(this,_0x1dbcfb);}['reload'](){return gf(this);}['_assign'](_0x5b65ae){this!==_0x5b65ae&&(m(this['uid']===_0x5b65ae['uid'],this['auth'],'internal-error'),this['displayName']=_0x5b65ae['displayName'],this['photoURL']=_0x5b65ae['photoURL'],this['email']=_0x5b65ae['email'],this['emailVerified']=_0x5b65ae['emailVerified'],this['phoneNumber']=_0x5b65ae['phoneNumber'],this['isAnonymous']=_0x5b65ae['isAnonymous'],this['tenantId']=_0x5b65ae['tenantId'],this['providerData']=_0x5b65ae['providerData']['map'](_0x428c11=>({..._0x428c11})),this['metadata']['_copy'](_0x5b65ae['metadata']),this['stsTokenManager']['_assign'](_0x5b65ae['stsTokenManager']));}['_clone'](_0x540cb9){const _0x111dbf=new z({...this,'auth':_0x540cb9,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x111dbf['metadata']['_copy'](this['metadata']),_0x111dbf;}['_onReload'](_0x52d54a){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x52d54a,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x264754){this['reloadListener']?this['reloadListener'](_0x264754):this['reloadUserInfo']=_0x264754;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5addc7,_0x45a689=!0x1){let _0xeaf44a=!0x1;_0x5addc7['idToken']&&_0x5addc7['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5addc7),_0xeaf44a=!0x0),_0x45a689&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0xeaf44a&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x3ba23e=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x3ba23e})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x128447=>({..._0x128447})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x59ccc5,_0x454b84){const _0x46f955=_0x454b84['displayName']??void 0x0,_0x64516a=_0x454b84['email']??void 0x0,_0x2d9e46=_0x454b84['phoneNumber']??void 0x0,_0x1af906=_0x454b84['photoURL']??void 0x0,_0xae282f=_0x454b84['tenantId']??void 0x0,_0x4854dd=_0x454b84['_redirectEventId']??void 0x0,_0x1eb660=_0x454b84['createdAt']??void 0x0,_0x485b18=_0x454b84['lastLoginAt']??void 0x0,{uid:_0x2c2d69,emailVerified:_0x13b419,isAnonymous:_0x2c2ec8,providerData:_0x4e73a7,stsTokenManager:_0x343e0c}=_0x454b84;m(_0x2c2d69&&_0x343e0c,_0x59ccc5,'internal-error');const _0x355048=Je['fromJSON'](this['name'],_0x343e0c);m(typeof _0x2c2d69=='string',_0x59ccc5,'internal-error'),ce(_0x46f955,_0x59ccc5['name']),ce(_0x64516a,_0x59ccc5['name']),m(typeof _0x13b419=='boolean',_0x59ccc5,'internal-error'),m(typeof _0x2c2ec8=='boolean',_0x59ccc5,'internal-error'),ce(_0x2d9e46,_0x59ccc5['name']),ce(_0x1af906,_0x59ccc5['name']),ce(_0xae282f,_0x59ccc5['name']),ce(_0x4854dd,_0x59ccc5['name']),ce(_0x1eb660,_0x59ccc5['name']),ce(_0x485b18,_0x59ccc5['name']);const _0x1adb3f=new z({'uid':_0x2c2d69,'auth':_0x59ccc5,'email':_0x64516a,'emailVerified':_0x13b419,'displayName':_0x46f955,'isAnonymous':_0x2c2ec8,'photoURL':_0x1af906,'phoneNumber':_0x2d9e46,'tenantId':_0xae282f,'stsTokenManager':_0x355048,'createdAt':_0x1eb660,'lastLoginAt':_0x485b18});return _0x4e73a7&&Array['isArray'](_0x4e73a7)&&(_0x1adb3f['providerData']=_0x4e73a7['map'](_0x50a5bf=>({..._0x50a5bf}))),_0x4854dd&&(_0x1adb3f['_redirectEventId']=_0x4854dd),_0x1adb3f;}static async['_fromIdTokenResponse'](_0x558895,_0xfef424,_0x59f87a=!0x1){const _0x471e3e=new Je();_0x471e3e['updateFromServerResponse'](_0xfef424);const _0x25dc15=new z({'uid':_0xfef424['localId'],'auth':_0x558895,'stsTokenManager':_0x471e3e,'isAnonymous':_0x59f87a});return await bn(_0x25dc15),_0x25dc15;}static async['_fromGetAccountInfoResponse'](_0x3995f1,_0x4dfc66,_0x57e0ad){const _0x72d189=_0x4dfc66['users'][0x0];m(_0x72d189['localId']!==void 0x0,'internal-error');const _0x56c3fb=_0x72d189['providerUserInfo']!==void 0x0?wa(_0x72d189['providerUserInfo']):[],_0x22135d=!(_0x72d189['email']&&_0x72d189['passwordHash'])&&!(_0x56c3fb!=null&&_0x56c3fb['length']),_0x441b7b=new Je();_0x441b7b['updateFromIdToken'](_0x57e0ad);const _0x3b5539=new z({'uid':_0x72d189['localId'],'auth':_0x3995f1,'stsTokenManager':_0x441b7b,'isAnonymous':_0x22135d}),_0x56a38a={'uid':_0x72d189['localId'],'displayName':_0x72d189['displayName']||null,'photoURL':_0x72d189['photoUrl']||null,'email':_0x72d189['email']||null,'emailVerified':_0x72d189['emailVerified']||!0x1,'phoneNumber':_0x72d189['phoneNumber']||null,'tenantId':_0x72d189['tenantId']||null,'providerData':_0x56c3fb,'metadata':new Pi(_0x72d189['createdAt'],_0x72d189['lastLoginAt']),'isAnonymous':!(_0x72d189['email']&&_0x72d189['passwordHash'])&&!(_0x56c3fb!=null&&_0x56c3fb['length'])};return Object['assign'](_0x3b5539,_0x56a38a),_0x3b5539;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x405306){ae(_0x405306 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x4721b9=Ir['get'](_0x405306);return _0x4721b9?(ae(_0x4721b9 instanceof _0x405306,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x4721b9):(_0x4721b9=new _0x405306(),Ir['set'](_0x405306,_0x4721b9),_0x4721b9);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3127cf,_0x3f478b){this['storage'][_0x3127cf]=_0x3f478b;}async['_get'](_0x706004){const _0xb1b0b2=this['storage'][_0x706004];return _0xb1b0b2===void 0x0?null:_0xb1b0b2;}async['_remove'](_0x1e9de0){delete this['storage'][_0x1e9de0];}['_addListener'](_0x536e59,_0xb5e6ba){}['_removeListener'](_0x1fe290,_0x1a14f2){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x2871f0,_0x87c898,_0x50fe1a){return'firebase:'+_0x2871f0+':'+_0x87c898+':'+_0x50fe1a;}class Xe{constructor(_0xe43e61,_0xee70c,_0x48a7ad){this['persistence']=_0xe43e61,this['auth']=_0xee70c,this['userKey']=_0x48a7ad;const {config:_0x3e7983,name:_0x146f68}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x3e7983['apiKey'],_0x146f68),this['fullPersistenceKey']=sn('persistence',_0x3e7983['apiKey'],_0x146f68),this['boundEventHandler']=_0xee70c['_onStorageEvent']['bind'](_0xee70c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3f47f7){return this['persistence']['_set'](this['fullUserKey'],_0x3f47f7['toJSON']());}async['getCurrentUser'](){const _0x51579b=await this['persistence']['_get'](this['fullUserKey']);if(!_0x51579b)return null;if(typeof _0x51579b=='string'){const _0x537f77=await Sn(this['auth'],{'idToken':_0x51579b})['catch'](()=>{});return _0x537f77?z['_fromGetAccountInfoResponse'](this['auth'],_0x537f77,_0x51579b):null;}return z['_fromJSON'](this['auth'],_0x51579b);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x675a56){if(this['persistence']===_0x675a56)return;const _0x1de1d1=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x675a56,_0x1de1d1)return this['setCurrentUser'](_0x1de1d1);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1e2bfc,_0x250e1a,_0x140d72='authUser'){if(!_0x250e1a['length'])return new Xe(ne(wr),_0x1e2bfc,_0x140d72);const _0x28ad9c=(await Promise['all'](_0x250e1a['map'](async _0x39fdb6=>{if(await _0x39fdb6['_isAvailable']())return _0x39fdb6;})))['filter'](_0x13dc6=>_0x13dc6);let _0x487c4e=_0x28ad9c[0x0]||ne(wr);const _0x506935=sn(_0x140d72,_0x1e2bfc['config']['apiKey'],_0x1e2bfc['name']);let _0x5134fc=null;for(const _0x5ef186 of _0x250e1a)try{const _0xeee2c5=await _0x5ef186['_get'](_0x506935);if(_0xeee2c5){let _0x1a97b0;if(typeof _0xeee2c5=='string'){const _0x542750=await Sn(_0x1e2bfc,{'idToken':_0xeee2c5})['catch'](()=>{});if(!_0x542750)break;_0x1a97b0=await z['_fromGetAccountInfoResponse'](_0x1e2bfc,_0x542750,_0xeee2c5);}else _0x1a97b0=z['_fromJSON'](_0x1e2bfc,_0xeee2c5);_0x5ef186!==_0x487c4e&&(_0x5134fc=_0x1a97b0),_0x487c4e=_0x5ef186;break;}}catch{}const _0x42d7b9=_0x28ad9c['filter'](_0x33bb06=>_0x33bb06['_shouldAllowMigration']);return!_0x487c4e['_shouldAllowMigration']||!_0x42d7b9['length']?new Xe(_0x487c4e,_0x1e2bfc,_0x140d72):(_0x487c4e=_0x42d7b9[0x0],_0x5134fc&&await _0x487c4e['_set'](_0x506935,_0x5134fc['toJSON']()),await Promise['all'](_0x250e1a['map'](async _0xf42dc0=>{if(_0xf42dc0!==_0x487c4e)try{await _0xf42dc0['_remove'](_0x506935);}catch{}})),new Xe(_0x487c4e,_0x1e2bfc,_0x140d72));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x21356e){const _0x2a77fb=_0x21356e['toLowerCase']();if(_0x2a77fb['includes']('opera/')||_0x2a77fb['includes']('opr/')||_0x2a77fb['includes']('opios/'))return'Opera';if(Ra(_0x2a77fb))return'IEMobile';if(_0x2a77fb['includes']('msie')||_0x2a77fb['includes']('trident/'))return'IE';if(_0x2a77fb['includes']('edge/'))return'Edge';if(Ta(_0x2a77fb))return'Firefox';if(_0x2a77fb['includes']('silk/'))return'Silk';if(ka(_0x2a77fb))return'Blackberry';if(Na(_0x2a77fb))return'Webos';if(Sa(_0x2a77fb))return'Safari';if((_0x2a77fb['includes']('chrome/')||ba(_0x2a77fb))&&!_0x2a77fb['includes']('edge/'))return'Chrome';if(Aa(_0x2a77fb))return'Android';{const _0x75781d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x2a0cf9=_0x21356e['match'](_0x75781d);if((_0x2a0cf9==null?void 0x0:_0x2a0cf9['length'])===0x2)return _0x2a0cf9[0x1];}return'Other';}function Ta(_0x19e534=W()){return/firefox\//i['test'](_0x19e534);}function Sa(_0x56ea40=W()){const _0x512922=_0x56ea40['toLowerCase']();return _0x512922['includes']('safari/')&&!_0x512922['includes']('chrome/')&&!_0x512922['includes']('crios/')&&!_0x512922['includes']('android');}function ba(_0x1d82de=W()){return/crios\//i['test'](_0x1d82de);}function Ra(_0x7c635a=W()){return/iemobile/i['test'](_0x7c635a);}function Aa(_0x49bd5c=W()){return/android/i['test'](_0x49bd5c);}function ka(_0x13b9c4=W()){return/blackberry/i['test'](_0x13b9c4);}function Na(_0x39082a=W()){return/webos/i['test'](_0x39082a);}function Cs(_0x160b2b=W()){return/iphone|ipad|ipod/i['test'](_0x160b2b)||/macintosh/i['test'](_0x160b2b)&&/mobile/i['test'](_0x160b2b);}function Ef(_0x1e74de=W()){var _0x2e63f2;return Cs(_0x1e74de)&&!!((_0x2e63f2=window['navigator'])!=null&&_0x2e63f2['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x535e72=W()){return Cs(_0x535e72)||Aa(_0x535e72)||Na(_0x535e72)||ka(_0x535e72)||/windows phone/i['test'](_0x535e72)||Ra(_0x535e72);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x3e72b3,_0x12e26e=[]){let _0x3a5f08;switch(_0x3e72b3){case'Browser':_0x3a5f08=Cr(W());break;case'Worker':_0x3a5f08=Cr(W())+'-'+_0x3e72b3;break;default:_0x3a5f08=_0x3e72b3;}const _0x1b168f=_0x12e26e['length']?_0x12e26e['join'](','):'FirebaseCore-web';return _0x3a5f08+'/JsCore/'+ct+'/'+_0x1b168f;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x4e13a0){this['auth']=_0x4e13a0,this['queue']=[];}['pushCallback'](_0x253f51,_0x20a0cb){const _0x51685e=_0x573e6c=>new Promise((_0x1f116e,_0x5d3744)=>{try{const _0x580ffe=_0x253f51(_0x573e6c);_0x1f116e(_0x580ffe);}catch(_0x684f5){_0x5d3744(_0x684f5);}});_0x51685e['onAbort']=_0x20a0cb,this['queue']['push'](_0x51685e);const _0x4d027d=this['queue']['length']-0x1;return()=>{this['queue'][_0x4d027d]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5d1678){if(this['auth']['currentUser']===_0x5d1678)return;const _0x3a42ba=[];try{for(const _0x333934 of this['queue'])await _0x333934(_0x5d1678),_0x333934['onAbort']&&_0x3a42ba['push'](_0x333934['onAbort']);}catch(_0x504478){_0x3a42ba['reverse']();for(const _0x34602a of _0x3a42ba)try{_0x34602a();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x504478==null?void 0x0:_0x504478['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x734b6c,_0x4bd176={}){return Ae(_0x734b6c,'GET','/v2/passwordPolicy',Re(_0x734b6c,_0x4bd176));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x54702f){var _0x113bd8;const _0x106d5e=_0x54702f['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x106d5e['minPasswordLength']??Tf,_0x106d5e['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x106d5e['maxPasswordLength']),_0x106d5e['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x106d5e['containsLowercaseCharacter']),_0x106d5e['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x106d5e['containsUppercaseCharacter']),_0x106d5e['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x106d5e['containsNumericCharacter']),_0x106d5e['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x106d5e['containsNonAlphanumericCharacter']),this['enforcementState']=_0x54702f['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x113bd8=_0x54702f['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x113bd8['join'](''))??'',this['forceUpgradeOnSignin']=_0x54702f['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x54702f['schemaVersion'];}['validatePassword'](_0x535dcf){const _0x2eb0a2={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x535dcf,_0x2eb0a2),this['validatePasswordCharacterOptions'](_0x535dcf,_0x2eb0a2),_0x2eb0a2['isValid']&&(_0x2eb0a2['isValid']=_0x2eb0a2['meetsMinPasswordLength']??!0x0),_0x2eb0a2['isValid']&&(_0x2eb0a2['isValid']=_0x2eb0a2['meetsMaxPasswordLength']??!0x0),_0x2eb0a2['isValid']&&(_0x2eb0a2['isValid']=_0x2eb0a2['containsLowercaseLetter']??!0x0),_0x2eb0a2['isValid']&&(_0x2eb0a2['isValid']=_0x2eb0a2['containsUppercaseLetter']??!0x0),_0x2eb0a2['isValid']&&(_0x2eb0a2['isValid']=_0x2eb0a2['containsNumericCharacter']??!0x0),_0x2eb0a2['isValid']&&(_0x2eb0a2['isValid']=_0x2eb0a2['containsNonAlphanumericCharacter']??!0x0),_0x2eb0a2;}['validatePasswordLengthOptions'](_0x33ebec,_0x1f7038){const _0x46185f=this['customStrengthOptions']['minPasswordLength'],_0x2fb9dd=this['customStrengthOptions']['maxPasswordLength'];_0x46185f&&(_0x1f7038['meetsMinPasswordLength']=_0x33ebec['length']>=_0x46185f),_0x2fb9dd&&(_0x1f7038['meetsMaxPasswordLength']=_0x33ebec['length']<=_0x2fb9dd);}['validatePasswordCharacterOptions'](_0x49de19,_0x5aa1e4){this['updatePasswordCharacterOptionsStatuses'](_0x5aa1e4,!0x1,!0x1,!0x1,!0x1);let _0x78c35b;for(let _0x26956b=0x0;_0x26956b<_0x49de19['length'];_0x26956b++)_0x78c35b=_0x49de19['charAt'](_0x26956b),this['updatePasswordCharacterOptionsStatuses'](_0x5aa1e4,_0x78c35b>='a'&&_0x78c35b<='z',_0x78c35b>='A'&&_0x78c35b<='Z',_0x78c35b>='0'&&_0x78c35b<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x78c35b));}['updatePasswordCharacterOptionsStatuses'](_0x48b5d8,_0x453810,_0x3bfd1d,_0x2e1f83,_0x57f03e){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x48b5d8['containsLowercaseLetter']||(_0x48b5d8['containsLowercaseLetter']=_0x453810)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x48b5d8['containsUppercaseLetter']||(_0x48b5d8['containsUppercaseLetter']=_0x3bfd1d)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x48b5d8['containsNumericCharacter']||(_0x48b5d8['containsNumericCharacter']=_0x2e1f83)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x48b5d8['containsNonAlphanumericCharacter']||(_0x48b5d8['containsNonAlphanumericCharacter']=_0x57f03e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x3beb60,_0x3d1782,_0x5d58e7,_0x4ebd32){this['app']=_0x3beb60,this['heartbeatServiceProvider']=_0x3d1782,this['appCheckServiceProvider']=_0x5d58e7,this['config']=_0x4ebd32,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3beb60['name'],this['clientVersion']=_0x4ebd32['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2a1a75=>this['_resolvePersistenceManagerAvailable']=_0x2a1a75);}['_initializeWithPersistence'](_0x3c8478,_0x2753c2){return _0x2753c2&&(this['_popupRedirectResolver']=ne(_0x2753c2)),this['_initializationPromise']=this['queue'](async()=>{var _0x160644,_0x36a3f0,_0x1b69be;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x3c8478),(_0x160644=this['_resolvePersistenceManagerAvailable'])==null||_0x160644['call'](this),!this['_deleted'])){if((_0x36a3f0=this['_popupRedirectResolver'])!=null&&_0x36a3f0['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2753c2),this['lastNotifiedUid']=((_0x1b69be=this['currentUser'])==null?void 0x0:_0x1b69be['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3a3c9e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3a3c9e)){if(this['currentUser']&&_0x3a3c9e&&this['currentUser']['uid']===_0x3a3c9e['uid']){this['_currentUser']['_assign'](_0x3a3c9e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3a3c9e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x197005){try{const _0xabbbc3=await Sn(this,{'idToken':_0x197005}),_0x471579=await z['_fromGetAccountInfoResponse'](this,_0xabbbc3,_0x197005);await this['directlySetCurrentUser'](_0x471579);}catch(_0x49e2f1){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x49e2f1),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x443b1d){var _0x314c03;if(H(this['app'])){const _0x37fafe=this['app']['settings']['authIdToken'];return _0x37fafe?new Promise(_0x3fd034=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x37fafe)['then'](_0x3fd034,_0x3fd034));}):this['directlySetCurrentUser'](null);}const _0x21183c=await this['assertedPersistence']['getCurrentUser']();let _0x1bf9da=_0x21183c,_0x5bd629=!0x1;if(_0x443b1d&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5244e1=(_0x314c03=this['redirectUser'])==null?void 0x0:_0x314c03['_redirectEventId'],_0x5528dd=_0x1bf9da==null?void 0x0:_0x1bf9da['_redirectEventId'],_0x6e68e0=await this['tryRedirectSignIn'](_0x443b1d);(!_0x5244e1||_0x5244e1===_0x5528dd)&&(_0x6e68e0!=null&&_0x6e68e0['user'])&&(_0x1bf9da=_0x6e68e0['user'],_0x5bd629=!0x0);}if(!_0x1bf9da)return this['directlySetCurrentUser'](null);if(!_0x1bf9da['_redirectEventId']){if(_0x5bd629)try{await this['beforeStateQueue']['runMiddleware'](_0x1bf9da);}catch(_0x1f9b79){_0x1bf9da=_0x21183c,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1f9b79));}return _0x1bf9da?this['reloadAndSetCurrentUserOrClear'](_0x1bf9da):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1bf9da['_redirectEventId']?this['directlySetCurrentUser'](_0x1bf9da):this['reloadAndSetCurrentUserOrClear'](_0x1bf9da);}async['tryRedirectSignIn'](_0x1ec5ea){let _0x5bcdb9=null;try{_0x5bcdb9=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1ec5ea,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5bcdb9;}async['reloadAndSetCurrentUserOrClear'](_0x13e1d7){try{await bn(_0x13e1d7);}catch(_0x126ff9){if((_0x126ff9==null?void 0x0:_0x126ff9['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x13e1d7);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x32dd35){if(H(this['app']))return Promise['reject'](se(this));const _0x584979=_0x32dd35?k(_0x32dd35):null;return _0x584979&&m(_0x584979['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x584979&&_0x584979['_clone'](this));}async['_updateCurrentUser'](_0x328d97,_0x18d4e2=!0x1){if(!this['_deleted'])return _0x328d97&&m(this['tenantId']===_0x328d97['tenantId'],this,'tenant-id-mismatch'),_0x18d4e2||await this['beforeStateQueue']['runMiddleware'](_0x328d97),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x328d97),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4236c6){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x4236c6));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3c5bc8){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x47b722=this['_getPasswordPolicyInternal']();return _0x47b722['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x47b722['validatePassword'](_0x3c5bc8);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x7e00c7=await Cf(this),_0x3f36da=new Sf(_0x7e00c7);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3f36da:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3f36da;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x1a4a60){this['_errorFactory']=new Ut('auth','Firebase',_0x1a4a60());}['onAuthStateChanged'](_0x31a9ea,_0x56adc8,_0x5626e9){return this['registerStateListener'](this['authStateSubscription'],_0x31a9ea,_0x56adc8,_0x5626e9);}['beforeAuthStateChanged'](_0x576592,_0x1ec374){return this['beforeStateQueue']['pushCallback'](_0x576592,_0x1ec374);}['onIdTokenChanged'](_0x4e4848,_0x41ef2f,_0x5aa344){return this['registerStateListener'](this['idTokenSubscription'],_0x4e4848,_0x41ef2f,_0x5aa344);}['authStateReady'](){return new Promise((_0x591df0,_0x367c7d)=>{if(this['currentUser'])_0x591df0();else{const _0x258d7a=this['onAuthStateChanged'](()=>{_0x258d7a(),_0x591df0();},_0x367c7d);}});}async['revokeAccessToken'](_0x2e7155){if(this['currentUser']){const _0x234052=await this['currentUser']['getIdToken'](),_0x4d4dfc={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2e7155,'idToken':_0x234052};this['tenantId']!=null&&(_0x4d4dfc['tenantId']=this['tenantId']),await vf(this,_0x4d4dfc);}}['toJSON'](){var _0xa07911;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xa07911=this['_currentUser'])==null?void 0x0:_0xa07911['toJSON']()};}async['_setRedirectUser'](_0x196f0b,_0x2ddf6d){const _0x36b524=await this['getOrInitRedirectPersistenceManager'](_0x2ddf6d);return _0x196f0b===null?_0x36b524['removeCurrentUser']():_0x36b524['setCurrentUser'](_0x196f0b);}async['getOrInitRedirectPersistenceManager'](_0x11cf6b){if(!this['redirectPersistenceManager']){const _0x1004a6=_0x11cf6b&&ne(_0x11cf6b)||this['_popupRedirectResolver'];m(_0x1004a6,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x1004a6['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x567e52){var _0x2c1d5d,_0x45bdf4;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2c1d5d=this['_currentUser'])==null?void 0x0:_0x2c1d5d['_redirectEventId'])===_0x567e52?this['_currentUser']:((_0x45bdf4=this['redirectUser'])==null?void 0x0:_0x45bdf4['_redirectEventId'])===_0x567e52?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x492721){if(_0x492721===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x492721));}['_notifyListenersIfCurrent'](_0x50690a){_0x50690a===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x551503;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x422698=((_0x551503=this['currentUser'])==null?void 0x0:_0x551503['uid'])??null;this['lastNotifiedUid']!==_0x422698&&(this['lastNotifiedUid']=_0x422698,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1efc75,_0x3f74c5,_0x30c21c,_0x3c1b7b){if(this['_deleted'])return()=>{};const _0x35973d=typeof _0x3f74c5=='function'?_0x3f74c5:_0x3f74c5['next']['bind'](_0x3f74c5);let _0x1534c1=!0x1;const _0x5010f1=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x5010f1,this,'internal-error'),_0x5010f1['then'](()=>{_0x1534c1||_0x35973d(this['currentUser']);}),typeof _0x3f74c5=='function'){const _0x1fa58d=_0x1efc75['addObserver'](_0x3f74c5,_0x30c21c,_0x3c1b7b);return()=>{_0x1534c1=!0x0,_0x1fa58d();};}else{const _0x1e21a5=_0x1efc75['addObserver'](_0x3f74c5);return()=>{_0x1534c1=!0x0,_0x1e21a5();};}}async['directlySetCurrentUser'](_0x244ca9){this['currentUser']&&this['currentUser']!==_0x244ca9&&this['_currentUser']['_stopProactiveRefresh'](),_0x244ca9&&this['isProactiveRefreshEnabled']&&_0x244ca9['_startProactiveRefresh'](),this['currentUser']=_0x244ca9,_0x244ca9?await this['assertedPersistence']['setCurrentUser'](_0x244ca9):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3436ce){return this['operations']=this['operations']['then'](_0x3436ce,_0x3436ce),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x49c223){!_0x49c223||this['frameworks']['includes'](_0x49c223)||(this['frameworks']['push'](_0x49c223),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x11596c;const _0x4768e7={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4768e7['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4e46cb=await((_0x11596c=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x11596c['getHeartbeatsHeader']());_0x4e46cb&&(_0x4768e7['X-Firebase-Client']=_0x4e46cb);const _0x495722=await this['_getAppCheckToken']();return _0x495722&&(_0x4768e7['X-Firebase-AppCheck']=_0x495722),_0x4768e7;}async['_getAppCheckToken'](){var _0x391c7a;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x49a5d1=await((_0x391c7a=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x391c7a['getToken']());return _0x49a5d1!=null&&_0x49a5d1['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x49a5d1['error']),_0x49a5d1==null?void 0x0:_0x49a5d1['token'];}}function qe(_0x2ef019){return k(_0x2ef019);}class Tr{constructor(_0x145c65){this['auth']=_0x145c65,this['observer']=null,this['addObserver']=Ic(_0x566e4f=>this['observer']=_0x566e4f);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x52b0db){zn=_0x52b0db;}function Da(_0x254588){return zn['loadJS'](_0x254588);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x1e4010){return'__'+_0x1e4010+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x162a6f){_0x162a6f();}['execute'](_0x4d83c1,_0x1a8a1b){return Promise['resolve']('token');}['render'](_0x722c50,_0x1f3f04){return'';}}class Of{['ready'](_0x4b5b21){_0x4b5b21();}['execute'](_0x2191c7,_0x595fe9){return Promise['resolve']('token');}['render'](_0x4754b5,_0x262375){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x354398){this['type']=Df,this['auth']=qe(_0x354398);}async['verify'](_0x5a8df9='verify',_0x2d36d7=!0x1){async function _0x129432(_0xf821f8){if(!_0x2d36d7){if(_0xf821f8['tenantId']==null&&_0xf821f8['_agentRecaptchaConfig']!=null)return _0xf821f8['_agentRecaptchaConfig']['siteKey'];if(_0xf821f8['tenantId']!=null&&_0xf821f8['_tenantRecaptchaConfigs'][_0xf821f8['tenantId']]!==void 0x0)return _0xf821f8['_tenantRecaptchaConfigs'][_0xf821f8['tenantId']]['siteKey'];}return new Promise(async(_0x5b68dc,_0x5a0ecf)=>{uf(_0xf821f8,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x5c312c=>{if(_0x5c312c['recaptchaKey']===void 0x0)_0x5a0ecf(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x13f84e=new hf(_0x5c312c);return _0xf821f8['tenantId']==null?_0xf821f8['_agentRecaptchaConfig']=_0x13f84e:_0xf821f8['_tenantRecaptchaConfigs'][_0xf821f8['tenantId']]=_0x13f84e,_0x5b68dc(_0x13f84e['siteKey']);}})['catch'](_0x59d50a=>{_0x5a0ecf(_0x59d50a);});});}function _0x3f9723(_0x3d6035,_0x5b39df,_0x9a38){const _0x364c27=window['grecaptcha'];vr(_0x364c27)?_0x364c27['enterprise']['ready'](()=>{_0x364c27['enterprise']['execute'](_0x3d6035,{'action':_0x5a8df9})['then'](_0x40e442=>{_0x5b39df(_0x40e442);})['catch'](()=>{_0x5b39df(Ma);});}):_0x9a38(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x42519e,_0x86d3f4)=>{_0x129432(this['auth'])['then'](async _0x36c21d=>{if(!_0x2d36d7&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x3f9723(_0x36c21d,_0x42519e,_0x86d3f4);else{if(typeof window>'u'){_0x86d3f4(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x56e4e5=Af();_0x56e4e5['length']!==0x0&&(_0x56e4e5+=_0x36c21d+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x540d84;(_0x540d84=le['scriptInjectionDeferred'])==null||_0x540d84['resolve']();},Da(_0x56e4e5)['then'](()=>{var _0x18c87a;return(_0x18c87a=le['scriptInjectionDeferred'])==null?void 0x0:_0x18c87a['promise'];})['then'](()=>{_0x3f9723(_0x36c21d,_0x42519e,_0x86d3f4);})['catch'](_0x35b59f=>{_0x86d3f4(_0x35b59f);});}})['catch'](_0x527b28=>{_0x86d3f4(_0x527b28);});});}}le['scriptInjectionDeferred']=null;async function br(_0x6d3980,_0x8db631,_0x26b108,_0x2d308e=!0x1,_0x38330e=!0x1){const _0x13ce3f=new le(_0x6d3980);let _0x3e561e;if(_0x38330e)_0x3e561e=Ma;else try{_0x3e561e=await _0x13ce3f['verify'](_0x26b108);}catch{_0x3e561e=await _0x13ce3f['verify'](_0x26b108,!0x0);}const _0x448a1c={..._0x8db631};if(_0x26b108==='mfaSmsEnrollment'||_0x26b108==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x448a1c){const _0xed7eea=_0x448a1c['phoneEnrollmentInfo']['phoneNumber'],_0x344782=_0x448a1c['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x448a1c,{'phoneEnrollmentInfo':{'phoneNumber':_0xed7eea,'recaptchaToken':_0x344782,'captchaResponse':_0x3e561e,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x448a1c){const _0x34e423=_0x448a1c['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x448a1c,{'phoneSignInInfo':{'recaptchaToken':_0x34e423,'captchaResponse':_0x3e561e,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x448a1c;}return _0x2d308e?Object['assign'](_0x448a1c,{'captchaResp':_0x3e561e}):Object['assign'](_0x448a1c,{'captchaResponse':_0x3e561e}),Object['assign'](_0x448a1c,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x448a1c,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x448a1c;}async function Oi(_0x6461f3,_0x4dd86e,_0x29f1b6,_0x510a19,_0x146126){var _0x359cb5;if((_0x359cb5=_0x6461f3['_getRecaptchaConfig']())!=null&&_0x359cb5['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x13aa5a=await br(_0x6461f3,_0x4dd86e,_0x29f1b6,_0x29f1b6==='getOobCode');return _0x510a19(_0x6461f3,_0x13aa5a);}else return _0x510a19(_0x6461f3,_0x4dd86e)['catch'](async _0x443270=>{if(_0x443270['code']==='auth/missing-recaptcha-token'){console['log'](_0x29f1b6+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5ae2c7=await br(_0x6461f3,_0x4dd86e,_0x29f1b6,_0x29f1b6==='getOobCode');return _0x510a19(_0x6461f3,_0x5ae2c7);}else return Promise['reject'](_0x443270);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x42be14,_0x58971d){const _0x493288=Ui(_0x42be14,'auth');if(_0x493288['isInitialized']()){const _0xdefde6=_0x493288['getImmediate'](),_0x4a9c24=_0x493288['getOptions']();if(De(_0x4a9c24,_0x58971d??{}))return _0xdefde6;K(_0xdefde6,'already-initialized');}return _0x493288['initialize']({'options':_0x58971d});}function Lf(_0x4b8eee,_0x3e8bcc){const _0x56e567=(_0x3e8bcc==null?void 0x0:_0x3e8bcc['persistence'])||[],_0x2458e0=(Array['isArray'](_0x56e567)?_0x56e567:[_0x56e567])['map'](ne);_0x3e8bcc!=null&&_0x3e8bcc['errorMap']&&_0x4b8eee['_updateErrorMap'](_0x3e8bcc['errorMap']),_0x4b8eee['_initializeWithPersistence'](_0x2458e0,_0x3e8bcc==null?void 0x0:_0x3e8bcc['popupRedirectResolver']);}function xf(_0x534119,_0x1c49f1,_0x52f1b4){const _0x1b0ecd=qe(_0x534119);m(/^https?:\/\//['test'](_0x1c49f1),_0x1b0ecd,'invalid-emulator-scheme');const _0x4bf7c5=!0x1,_0x5c681b=La(_0x1c49f1),{host:_0x5629f7,port:_0x309565}=Ff(_0x1c49f1),_0x229e25=_0x309565===null?'':':'+_0x309565,_0x354237={'url':_0x5c681b+'//'+_0x5629f7+_0x229e25+'/'},_0x2b80a1=Object['freeze']({'host':_0x5629f7,'port':_0x309565,'protocol':_0x5c681b['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4bf7c5})});if(!_0x1b0ecd['_canInitEmulator']){m(_0x1b0ecd['config']['emulator']&&_0x1b0ecd['emulatorConfig'],_0x1b0ecd,'emulator-config-failed'),m(De(_0x354237,_0x1b0ecd['config']['emulator'])&&De(_0x2b80a1,_0x1b0ecd['emulatorConfig']),_0x1b0ecd,'emulator-config-failed');return;}_0x1b0ecd['config']['emulator']=_0x354237,_0x1b0ecd['emulatorConfig']=_0x2b80a1,_0x1b0ecd['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x5629f7)?jr(_0x5c681b+'//'+_0x5629f7+_0x229e25):Uf();}function La(_0x232cd0){const _0x58354f=_0x232cd0['indexOf'](':');return _0x58354f<0x0?'':_0x232cd0['substr'](0x0,_0x58354f+0x1);}function Ff(_0x4b1dbb){const _0x10044f=La(_0x4b1dbb),_0x542367=/(\/\/)?([^?#/]+)/['exec'](_0x4b1dbb['substr'](_0x10044f['length']));if(!_0x542367)return{'host':'','port':null};const _0x4f2b4c=_0x542367[0x2]['split']('@')['pop']()||'',_0x139294=/^(\[[^\]]+\])(:|$)/['exec'](_0x4f2b4c);if(_0x139294){const _0x4eadec=_0x139294[0x1];return{'host':_0x4eadec,'port':Rr(_0x4f2b4c['substr'](_0x4eadec['length']+0x1))};}else{const [_0x340709,_0x90eecd]=_0x4f2b4c['split'](':');return{'host':_0x340709,'port':Rr(_0x90eecd)};}}function Rr(_0x57c9d4){if(!_0x57c9d4)return null;const _0x2725eb=Number(_0x57c9d4);return isNaN(_0x2725eb)?null:_0x2725eb;}function Uf(){function _0x2789cf(){const _0x2b2ddd=document['createElement']('p'),_0x29f8d1=_0x2b2ddd['style'];_0x2b2ddd['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x29f8d1['position']='fixed',_0x29f8d1['width']='100%',_0x29f8d1['backgroundColor']='#ffffff',_0x29f8d1['border']='.1em\x20solid\x20#000000',_0x29f8d1['color']='#b50000',_0x29f8d1['bottom']='0px',_0x29f8d1['left']='0px',_0x29f8d1['margin']='0px',_0x29f8d1['zIndex']='10000',_0x29f8d1['textAlign']='center',_0x2b2ddd['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2b2ddd);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2789cf):_0x2789cf());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x555164,_0x326cc4){this['providerId']=_0x555164,this['signInMethod']=_0x326cc4;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x5dbd52){return te('not\x20implemented');}['_linkToIdToken'](_0x22ee56,_0x37dc99){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x2b5544){return te('not\x20implemented');}}async function Wf(_0x12e100,_0x5b5ad8){return Ae(_0x12e100,'POST','/v1/accounts:signUp',_0x5b5ad8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x1d0be4,_0x3c84fc){return Yt(_0x1d0be4,'POST','/v1/accounts:signInWithPassword',Re(_0x1d0be4,_0x3c84fc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x4b5440,_0x283133){return Yt(_0x4b5440,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4b5440,_0x283133));}async function Hf(_0x2046bf,_0xc7b3e){return Yt(_0x2046bf,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2046bf,_0xc7b3e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x81e11d,_0x44ae3c,_0x3f4d6b,_0x5f0d2e=null){super('password',_0x3f4d6b),this['_email']=_0x81e11d,this['_password']=_0x44ae3c,this['_tenantId']=_0x5f0d2e;}static['_fromEmailAndPassword'](_0x669677,_0x33a9b2){return new Ft(_0x669677,_0x33a9b2,'password');}static['_fromEmailAndCode'](_0x1f6248,_0x45df86,_0x16a50d=null){return new Ft(_0x1f6248,_0x45df86,'emailLink',_0x16a50d);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2315ef){const _0x5797ef=typeof _0x2315ef=='string'?JSON['parse'](_0x2315ef):_0x2315ef;if(_0x5797ef!=null&&_0x5797ef['email']&&(_0x5797ef!=null&&_0x5797ef['password'])){if(_0x5797ef['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5797ef['email'],_0x5797ef['password']);if(_0x5797ef['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5797ef['email'],_0x5797ef['password'],_0x5797ef['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2f718f){switch(this['signInMethod']){case'password':const _0x33213f={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x2f718f,_0x33213f,'signInWithPassword',Bf);case'emailLink':return Vf(_0x2f718f,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x2f718f,'internal-error');}}async['_linkToIdToken'](_0x42db67,_0x27a510){switch(this['signInMethod']){case'password':const _0x1646d8={'idToken':_0x27a510,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x42db67,_0x1646d8,'signUpPassword',Wf);case'emailLink':return Hf(_0x42db67,{'idToken':_0x27a510,'email':this['_email'],'oobCode':this['_password']});default:K(_0x42db67,'internal-error');}}['_getReauthenticationResolver'](_0x59e56b){return this['_getIdTokenResponse'](_0x59e56b);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x24ad89,_0x4cf1de){return Yt(_0x24ad89,'POST','/v1/accounts:signInWithIdp',Re(_0x24ad89,_0x4cf1de));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3cf7b8){const _0x27e47=new We(_0x3cf7b8['providerId'],_0x3cf7b8['signInMethod']);return _0x3cf7b8['idToken']||_0x3cf7b8['accessToken']?(_0x3cf7b8['idToken']&&(_0x27e47['idToken']=_0x3cf7b8['idToken']),_0x3cf7b8['accessToken']&&(_0x27e47['accessToken']=_0x3cf7b8['accessToken']),_0x3cf7b8['nonce']&&!_0x3cf7b8['pendingToken']&&(_0x27e47['nonce']=_0x3cf7b8['nonce']),_0x3cf7b8['pendingToken']&&(_0x27e47['pendingToken']=_0x3cf7b8['pendingToken'])):_0x3cf7b8['oauthToken']&&_0x3cf7b8['oauthTokenSecret']?(_0x27e47['accessToken']=_0x3cf7b8['oauthToken'],_0x27e47['secret']=_0x3cf7b8['oauthTokenSecret']):K('argument-error'),_0x27e47;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2eac0a){const _0x30559a=typeof _0x2eac0a=='string'?JSON['parse'](_0x2eac0a):_0x2eac0a,{providerId:_0x322150,signInMethod:_0x32b97f,..._0x14fce6}=_0x30559a;if(!_0x322150||!_0x32b97f)return null;const _0xdcfdcd=new We(_0x322150,_0x32b97f);return _0xdcfdcd['idToken']=_0x14fce6['idToken']||void 0x0,_0xdcfdcd['accessToken']=_0x14fce6['accessToken']||void 0x0,_0xdcfdcd['secret']=_0x14fce6['secret'],_0xdcfdcd['nonce']=_0x14fce6['nonce'],_0xdcfdcd['pendingToken']=_0x14fce6['pendingToken']||null,_0xdcfdcd;}['_getIdTokenResponse'](_0x3d5c4d){const _0x211628=this['buildRequest']();return Ze(_0x3d5c4d,_0x211628);}['_linkToIdToken'](_0x4b20b0,_0x2a7947){const _0x3b32dd=this['buildRequest']();return _0x3b32dd['idToken']=_0x2a7947,Ze(_0x4b20b0,_0x3b32dd);}['_getReauthenticationResolver'](_0x24cd26){const _0x1f3207=this['buildRequest']();return _0x1f3207['autoCreate']=!0x1,Ze(_0x24cd26,_0x1f3207);}['buildRequest'](){const _0x43491b={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x43491b['pendingToken']=this['pendingToken'];else{const _0x153cc={};this['idToken']&&(_0x153cc['id_token']=this['idToken']),this['accessToken']&&(_0x153cc['access_token']=this['accessToken']),this['secret']&&(_0x153cc['oauth_token_secret']=this['secret']),_0x153cc['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x153cc['nonce']=this['nonce']),_0x43491b['postBody']=at(_0x153cc);}return _0x43491b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x1c7752){switch(_0x1c7752){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x2b0629){const _0x1b86eb=yt(vt(_0x2b0629))['link'],_0x3d633d=_0x1b86eb?yt(vt(_0x1b86eb))['deep_link_id']:null,_0x89a72c=yt(vt(_0x2b0629))['deep_link_id'];return(_0x89a72c?yt(vt(_0x89a72c))['link']:null)||_0x89a72c||_0x3d633d||_0x1b86eb||_0x2b0629;}class Ss{constructor(_0x865d08){const _0x3f9d3e=yt(vt(_0x865d08)),_0x2d6723=_0x3f9d3e['apiKey']??null,_0xd008c7=_0x3f9d3e['oobCode']??null,_0x595153=Gf(_0x3f9d3e['mode']??null);m(_0x2d6723&&_0xd008c7&&_0x595153,'argument-error'),this['apiKey']=_0x2d6723,this['operation']=_0x595153,this['code']=_0xd008c7,this['continueUrl']=_0x3f9d3e['continueUrl']??null,this['languageCode']=_0x3f9d3e['lang']??null,this['tenantId']=_0x3f9d3e['tenantId']??null;}static['parseLink'](_0x3022de){const _0x16fad4=qf(_0x3022de);try{return new Ss(_0x16fad4);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x1616be,_0xaa5fd4){return Ft['_fromEmailAndPassword'](_0x1616be,_0xaa5fd4);}static['credentialWithLink'](_0x5ce624,_0x497f03){const _0x5dee22=Ss['parseLink'](_0x497f03);return m(_0x5dee22,'argument-error'),Ft['_fromEmailAndCode'](_0x5ce624,_0x5dee22['code'],_0x5dee22['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x49aa05){this['providerId']=_0x49aa05,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x57bb30){this['defaultLanguageCode']=_0x57bb30;}['setCustomParameters'](_0x4a4ef1){return this['customParameters']=_0x4a4ef1,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5dd265){return this['scopes']['includes'](_0x5dd265)||this['scopes']['push'](_0x5dd265),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x19fa7e){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x19fa7e});}static['credentialFromResult'](_0x31fddb){return he['credentialFromTaggedObject'](_0x31fddb);}static['credentialFromError'](_0x2e8bf2){return he['credentialFromTaggedObject'](_0x2e8bf2['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1a3c94}){if(!_0x1a3c94||!('oauthAccessToken'in _0x1a3c94)||!_0x1a3c94['oauthAccessToken'])return null;try{return he['credential'](_0x1a3c94['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x118012,_0x5b1353){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x118012,'accessToken':_0x5b1353});}static['credentialFromResult'](_0xaef27f){return ue['credentialFromTaggedObject'](_0xaef27f);}static['credentialFromError'](_0x2768a9){return ue['credentialFromTaggedObject'](_0x2768a9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1f3cf7}){if(!_0x1f3cf7)return null;const {oauthIdToken:_0x42548f,oauthAccessToken:_0x2ffa65}=_0x1f3cf7;if(!_0x42548f&&!_0x2ffa65)return null;try{return ue['credential'](_0x42548f,_0x2ffa65);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x3b9299){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3b9299});}static['credentialFromResult'](_0x4022af){return de['credentialFromTaggedObject'](_0x4022af);}static['credentialFromError'](_0x1c3dc4){return de['credentialFromTaggedObject'](_0x1c3dc4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x377969}){if(!_0x377969||!('oauthAccessToken'in _0x377969)||!_0x377969['oauthAccessToken'])return null;try{return de['credential'](_0x377969['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x4910a8,_0x2bf4c7){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4910a8,'oauthTokenSecret':_0x2bf4c7});}static['credentialFromResult'](_0x56ab91){return fe['credentialFromTaggedObject'](_0x56ab91);}static['credentialFromError'](_0x24109c){return fe['credentialFromTaggedObject'](_0x24109c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2455bd}){if(!_0x2455bd)return null;const {oauthAccessToken:_0x12fb7a,oauthTokenSecret:_0x3c3b17}=_0x2455bd;if(!_0x12fb7a||!_0x3c3b17)return null;try{return fe['credential'](_0x12fb7a,_0x3c3b17);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x1f431a,_0x237dfd){return Yt(_0x1f431a,'POST','/v1/accounts:signUp',Re(_0x1f431a,_0x237dfd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x38a83a){this['user']=_0x38a83a['user'],this['providerId']=_0x38a83a['providerId'],this['_tokenResponse']=_0x38a83a['_tokenResponse'],this['operationType']=_0x38a83a['operationType'];}static async['_fromIdTokenResponse'](_0x24e0ff,_0x350332,_0x18a165,_0x4802cd=!0x1){const _0x54d964=await z['_fromIdTokenResponse'](_0x24e0ff,_0x18a165,_0x4802cd),_0x3da963=Ar(_0x18a165);return new Be({'user':_0x54d964,'providerId':_0x3da963,'_tokenResponse':_0x18a165,'operationType':_0x350332});}static async['_forOperation'](_0x28283f,_0xd6f1bf,_0x1bf912){await _0x28283f['_updateTokensIfNecessary'](_0x1bf912,!0x0);const _0x4dae2e=Ar(_0x1bf912);return new Be({'user':_0x28283f,'providerId':_0x4dae2e,'_tokenResponse':_0x1bf912,'operationType':_0xd6f1bf});}}function Ar(_0x4b97fe){return _0x4b97fe['providerId']?_0x4b97fe['providerId']:'phoneNumber'in _0x4b97fe?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x2b65b6,_0x4ae3b0,_0x833ff,_0x5d06f5){super(_0x4ae3b0['code'],_0x4ae3b0['message']),this['operationType']=_0x833ff,this['user']=_0x5d06f5,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x2b65b6['name'],'tenantId':_0x2b65b6['tenantId']??void 0x0,'_serverResponse':_0x4ae3b0['customData']['_serverResponse'],'operationType':_0x833ff};}static['_fromErrorAndOperation'](_0x370782,_0xce22d3,_0x41831b,_0x4a940f){return new Rn(_0x370782,_0xce22d3,_0x41831b,_0x4a940f);}}function Fa(_0x422c75,_0x310d73,_0x5e463c,_0xa46668){return(_0x310d73==='reauthenticate'?_0x5e463c['_getReauthenticationResolver'](_0x422c75):_0x5e463c['_getIdTokenResponse'](_0x422c75))['catch'](_0x2da747=>{throw _0x2da747['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x422c75,_0x2da747,_0x310d73,_0xa46668):_0x2da747;});}async function jf(_0x31f284,_0x43ec72,_0x118c7f=!0x1){const _0x5340da=await xt(_0x31f284,_0x43ec72['_linkToIdToken'](_0x31f284['auth'],await _0x31f284['getIdToken']()),_0x118c7f);return Be['_forOperation'](_0x31f284,'link',_0x5340da);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x49b0dc,_0x257364,_0x5b2701=!0x1){const {auth:_0x13fc00}=_0x49b0dc;if(H(_0x13fc00['app']))return Promise['reject'](se(_0x13fc00));const _0x4abeb4='reauthenticate';try{const _0x225b2d=await xt(_0x49b0dc,Fa(_0x13fc00,_0x4abeb4,_0x257364,_0x49b0dc),_0x5b2701);m(_0x225b2d['idToken'],_0x13fc00,'internal-error');const _0x248fe7=ws(_0x225b2d['idToken']);m(_0x248fe7,_0x13fc00,'internal-error');const {sub:_0x4c590d}=_0x248fe7;return m(_0x49b0dc['uid']===_0x4c590d,_0x13fc00,'user-mismatch'),Be['_forOperation'](_0x49b0dc,_0x4abeb4,_0x225b2d);}catch(_0x1bbbc3){throw(_0x1bbbc3==null?void 0x0:_0x1bbbc3['code'])==='auth/user-not-found'&&K(_0x13fc00,'user-mismatch'),_0x1bbbc3;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4a7c50,_0x5ea169,_0xbb8da3=!0x1){if(H(_0x4a7c50['app']))return Promise['reject'](se(_0x4a7c50));const _0x5d3909='signIn',_0xe8be62=await Fa(_0x4a7c50,_0x5d3909,_0x5ea169),_0x44796e=await Be['_fromIdTokenResponse'](_0x4a7c50,_0x5d3909,_0xe8be62);return _0xbb8da3||await _0x4a7c50['_updateCurrentUser'](_0x44796e['user']),_0x44796e;}async function Yf(_0x1eb510,_0x25fd36){return Ua(qe(_0x1eb510),_0x25fd36);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x1b1bc1){const _0xf8341=qe(_0x1b1bc1);_0xf8341['_getPasswordPolicyInternal']()&&await _0xf8341['_updatePasswordPolicy']();}async function R_(_0xd3bc7f,_0x5eaac0,_0x217907){if(H(_0xd3bc7f['app']))return Promise['reject'](se(_0xd3bc7f));const _0x16b49b=qe(_0xd3bc7f),_0xc14412=await Oi(_0x16b49b,{'returnSecureToken':!0x0,'email':_0x5eaac0,'password':_0x217907,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x44929b=>{throw _0x44929b['code']==='auth/password-does-not-meet-requirements'&&Wa(_0xd3bc7f),_0x44929b;}),_0x13ea1=await Be['_fromIdTokenResponse'](_0x16b49b,'signIn',_0xc14412);return await _0x16b49b['_updateCurrentUser'](_0x13ea1['user']),_0x13ea1;}function A_(_0x195f01,_0x23142a,_0x4f539d){return H(_0x195f01['app'])?Promise['reject'](se(_0x195f01)):Yf(k(_0x195f01),ft['credential'](_0x23142a,_0x4f539d))['catch'](async _0x46ac75=>{throw _0x46ac75['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x195f01),_0x46ac75;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x50370a,_0x48c4f2){return k(_0x50370a)['setPersistence'](_0x48c4f2);}function Qf(_0x2bfe63,_0x561a78,_0x174d74,_0xa9bca7){return k(_0x2bfe63)['onIdTokenChanged'](_0x561a78,_0x174d74,_0xa9bca7);}function Jf(_0x39556d,_0x30f797,_0x1ddb13){return k(_0x39556d)['beforeAuthStateChanged'](_0x30f797,_0x1ddb13);}function N_(_0xf83e0f,_0x30a4ea,_0x38f8ef,_0x55c041){return k(_0xf83e0f)['onAuthStateChanged'](_0x30a4ea,_0x38f8ef,_0x55c041);}function P_(_0x42a08a){return k(_0x42a08a)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x3f8a32,_0x2e51af){this['storageRetriever']=_0x3f8a32,this['type']=_0x2e51af;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4e637d,_0x1f31a2){return this['storage']['setItem'](_0x4e637d,JSON['stringify'](_0x1f31a2)),Promise['resolve']();}['_get'](_0x3b54c8){const _0xbcf8bf=this['storage']['getItem'](_0x3b54c8);return Promise['resolve'](_0xbcf8bf?JSON['parse'](_0xbcf8bf):null);}['_remove'](_0x30c548){return this['storage']['removeItem'](_0x30c548),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x57aebf,_0x3faccf)=>this['onStorageEvent'](_0x57aebf,_0x3faccf),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x286e16){for(const _0x4f40f9 of Object['keys'](this['listeners'])){const _0x4c8955=this['storage']['getItem'](_0x4f40f9),_0x1c3d16=this['localCache'][_0x4f40f9];_0x4c8955!==_0x1c3d16&&_0x286e16(_0x4f40f9,_0x1c3d16,_0x4c8955);}}['onStorageEvent'](_0x1818c0,_0xd6634e=!0x1){if(!_0x1818c0['key']){this['forAllChangedKeys']((_0x123579,_0xd89ac9,_0x5c34b5)=>{this['notifyListeners'](_0x123579,_0x5c34b5);});return;}const _0x22eeae=_0x1818c0['key'];_0xd6634e?this['detachListener']():this['stopPolling']();const _0x2bb0bb=()=>{const _0x41b8f8=this['storage']['getItem'](_0x22eeae);!_0xd6634e&&this['localCache'][_0x22eeae]===_0x41b8f8||this['notifyListeners'](_0x22eeae,_0x41b8f8);},_0x2837d6=this['storage']['getItem'](_0x22eeae);If()&&_0x2837d6!==_0x1818c0['newValue']&&_0x1818c0['newValue']!==_0x1818c0['oldValue']?setTimeout(_0x2bb0bb,Zf):_0x2bb0bb();}['notifyListeners'](_0x54b395,_0x14c969){this['localCache'][_0x54b395]=_0x14c969;const _0x5e79c5=this['listeners'][_0x54b395];if(_0x5e79c5){for(const _0x472bc1 of Array['from'](_0x5e79c5))_0x472bc1(_0x14c969&&JSON['parse'](_0x14c969));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1e5570,_0x13c689,_0x1a3640)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1e5570,'oldValue':_0x13c689,'newValue':_0x1a3640}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x507b81,_0x1311db){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x507b81]||(this['listeners'][_0x507b81]=new Set(),this['localCache'][_0x507b81]=this['storage']['getItem'](_0x507b81)),this['listeners'][_0x507b81]['add'](_0x1311db);}['_removeListener'](_0x2e05ce,_0x32799b){this['listeners'][_0x2e05ce]&&(this['listeners'][_0x2e05ce]['delete'](_0x32799b),this['listeners'][_0x2e05ce]['size']===0x0&&delete this['listeners'][_0x2e05ce]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1c46fe,_0x4b638e){await super['_set'](_0x1c46fe,_0x4b638e),this['localCache'][_0x1c46fe]=JSON['stringify'](_0x4b638e);}async['_get'](_0x5a2d57){const _0x4f36f8=await super['_get'](_0x5a2d57);return this['localCache'][_0x5a2d57]=JSON['stringify'](_0x4f36f8),_0x4f36f8;}async['_remove'](_0x21948f){await super['_remove'](_0x21948f),delete this['localCache'][_0x21948f];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x218327,_0x3ef88b){}['_removeListener'](_0x2ba2c3,_0x445803){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x30827e){return Promise['all'](_0x30827e['map'](async _0x22bb82=>{try{return{'fulfilled':!0x0,'value':await _0x22bb82};}catch(_0x3de24d){return{'fulfilled':!0x1,'reason':_0x3de24d};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x3a4b96){this['eventTarget']=_0x3a4b96,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x447f00){const _0x4646a9=this['receivers']['find'](_0x415382=>_0x415382['isListeningto'](_0x447f00));if(_0x4646a9)return _0x4646a9;const _0x38b17c=new jn(_0x447f00);return this['receivers']['push'](_0x38b17c),_0x38b17c;}['isListeningto'](_0x1a6ec2){return this['eventTarget']===_0x1a6ec2;}async['handleEvent'](_0x14ae30){const _0x1f22b4=_0x14ae30,{eventId:_0x4801eb,eventType:_0x5e6f9b,data:_0x5b929f}=_0x1f22b4['data'],_0x32d450=this['handlersMap'][_0x5e6f9b];if(!(_0x32d450!=null&&_0x32d450['size']))return;_0x1f22b4['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4801eb,'eventType':_0x5e6f9b});const _0x51a351=Array['from'](_0x32d450)['map'](async _0x2de00f=>_0x2de00f(_0x1f22b4['origin'],_0x5b929f)),_0x51afc6=await tp(_0x51a351);_0x1f22b4['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4801eb,'eventType':_0x5e6f9b,'response':_0x51afc6});}['_subscribe'](_0x5f543a,_0x2c19c5){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5f543a]||(this['handlersMap'][_0x5f543a]=new Set()),this['handlersMap'][_0x5f543a]['add'](_0x2c19c5);}['_unsubscribe'](_0x7fb72c,_0x1a930e){this['handlersMap'][_0x7fb72c]&&_0x1a930e&&this['handlersMap'][_0x7fb72c]['delete'](_0x1a930e),(!_0x1a930e||this['handlersMap'][_0x7fb72c]['size']===0x0)&&delete this['handlersMap'][_0x7fb72c],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x4a2748='',_0x4dc7ff=0xa){let _0x5aa5ca='';for(let _0x84ff76=0x0;_0x84ff76<_0x4dc7ff;_0x84ff76++)_0x5aa5ca+=Math['floor'](Math['random']()*0xa);return _0x4a2748+_0x5aa5ca;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x54f3f5){this['target']=_0x54f3f5,this['handlers']=new Set();}['removeMessageHandler'](_0x4ae031){_0x4ae031['messageChannel']&&(_0x4ae031['messageChannel']['port1']['removeEventListener']('message',_0x4ae031['onMessage']),_0x4ae031['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4ae031);}async['_send'](_0x2e98d7,_0xecdb83,_0x3d0226=0x32){const _0x3a4e0d=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3a4e0d)throw new Error('connection_unavailable');let _0x28f577,_0x391f91;return new Promise((_0x3225fd,_0x413df5)=>{const _0x2163cb=bs('',0x14);_0x3a4e0d['port1']['start']();const _0x340814=setTimeout(()=>{_0x413df5(new Error('unsupported_event'));},_0x3d0226);_0x391f91={'messageChannel':_0x3a4e0d,'onMessage'(_0x501e64){const _0x1ea906=_0x501e64;if(_0x1ea906['data']['eventId']===_0x2163cb)switch(_0x1ea906['data']['status']){case'ack':clearTimeout(_0x340814),_0x28f577=setTimeout(()=>{_0x413df5(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x28f577),_0x3225fd(_0x1ea906['data']['response']);break;default:clearTimeout(_0x340814),clearTimeout(_0x28f577),_0x413df5(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x391f91),_0x3a4e0d['port1']['addEventListener']('message',_0x391f91['onMessage']),this['target']['postMessage']({'eventType':_0x2e98d7,'eventId':_0x2163cb,'data':_0xecdb83},[_0x3a4e0d['port2']]);})['finally'](()=>{_0x391f91&&this['removeMessageHandler'](_0x391f91);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x83e1ca){X()['location']['href']=_0x83e1ca;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x3dc4a7;return((_0x3dc4a7=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3dc4a7['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x1a52f2){this['request']=_0x1a52f2;}['toPromise'](){return new Promise((_0x4b21e6,_0x2b5928)=>{this['request']['addEventListener']('success',()=>{_0x4b21e6(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x2b5928(this['request']['error']);});});}}function Kn(_0x518c11,_0x756062){return _0x518c11['transaction']([kn],_0x756062?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x5d981b=indexedDB['deleteDatabase'](qa);return new Jt(_0x5d981b)['toPromise']();}function ja(){const _0x249546=indexedDB['open'](qa,ap);return new Promise((_0x329e0d,_0x5106e7)=>{_0x249546['addEventListener']('error',()=>{_0x5106e7(_0x249546['error']);}),_0x249546['addEventListener']('upgradeneeded',()=>{const _0x2a1bc8=_0x249546['result'];try{_0x2a1bc8['createObjectStore'](kn,{'keyPath':za});}catch(_0x21e8f9){_0x5106e7(_0x21e8f9);}}),_0x249546['addEventListener']('success',async()=>{const _0x2bd803=_0x249546['result'];_0x2bd803['objectStoreNames']['contains'](kn)?_0x329e0d(_0x2bd803):(_0x2bd803['close'](),await cp(),_0x329e0d(await ja()));});});}async function kr(_0x32b1b2,_0x124862,_0x500736){const _0x449664=Kn(_0x32b1b2,!0x0)['put']({[za]:_0x124862,'value':_0x500736});return new Jt(_0x449664)['toPromise']();}async function lp(_0x3aa729,_0x45ea89){const _0x24c3a1=Kn(_0x3aa729,!0x1)['get'](_0x45ea89),_0x3ed46e=await new Jt(_0x24c3a1)['toPromise']();return _0x3ed46e===void 0x0?null:_0x3ed46e['value'];}function Nr(_0x18aee1,_0x574d93){const _0x182044=Kn(_0x18aee1,!0x0)['delete'](_0x574d93);return new Jt(_0x182044)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x3f9884){let _0x32ee63=0x0;for(;;)try{const _0x2bb689=await this['_openDb']();return await _0x3f9884(_0x2bb689);}catch(_0x521632){if(_0x32ee63++>up)throw _0x521632;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0xfbcc35,_0x5a83fe)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5a83fe['key'])})),this['receiver']['_subscribe']('ping',async(_0x432b3b,_0x264464)=>['keyChanged']);}async['initializeSender'](){var _0x1c7fa0,_0x1dae84;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x205ef3=await this['sender']['_send']('ping',{},0x320);_0x205ef3&&(_0x1c7fa0=_0x205ef3[0x0])!=null&&_0x1c7fa0['fulfilled']&&(_0x1dae84=_0x205ef3[0x0])!=null&&_0x1dae84['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x369c88){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x369c88},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x6839b8=>{await kr(_0x6839b8,An,'1'),await Nr(_0x6839b8,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x9ae701){this['pendingWrites']++;try{await _0x9ae701();}finally{this['pendingWrites']--;}}async['_set'](_0x20504d,_0x1ebdfa){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4daaa5=>kr(_0x4daaa5,_0x20504d,_0x1ebdfa)),this['localCache'][_0x20504d]=_0x1ebdfa,this['notifyServiceWorker'](_0x20504d)));}async['_get'](_0x401eec){const _0x4d2e16=await this['_withRetries'](_0x1a28ed=>lp(_0x1a28ed,_0x401eec));return this['localCache'][_0x401eec]=_0x4d2e16,_0x4d2e16;}async['_remove'](_0x61ef49){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3ec4be=>Nr(_0x3ec4be,_0x61ef49)),delete this['localCache'][_0x61ef49],this['notifyServiceWorker'](_0x61ef49)));}async['_poll'](){const _0x53e95b=await this['_withRetries'](_0x45b39a=>{const _0x34cf55=Kn(_0x45b39a,!0x1)['getAll']();return new Jt(_0x34cf55)['toPromise']();});if(!_0x53e95b)return[];if(this['pendingWrites']!==0x0)return[];const _0x388240=[],_0xaf4341=new Set();if(_0x53e95b['length']!==0x0){for(const {fbase_key:_0x547de6,value:_0x4d07b5}of _0x53e95b)_0xaf4341['add'](_0x547de6),JSON['stringify'](this['localCache'][_0x547de6])!==JSON['stringify'](_0x4d07b5)&&(this['notifyListeners'](_0x547de6,_0x4d07b5),_0x388240['push'](_0x547de6));}for(const _0x5b2e7a of Object['keys'](this['localCache']))this['localCache'][_0x5b2e7a]&&!_0xaf4341['has'](_0x5b2e7a)&&(this['notifyListeners'](_0x5b2e7a,null),_0x388240['push'](_0x5b2e7a));return _0x388240;}['notifyListeners'](_0x156e50,_0xf757d9){this['localCache'][_0x156e50]=_0xf757d9;const _0x61d45a=this['listeners'][_0x156e50];if(_0x61d45a){for(const _0x9d4334 of Array['from'](_0x61d45a))_0x9d4334(_0xf757d9);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0xf32630,_0x37133b){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0xf32630]||(this['listeners'][_0xf32630]=new Set(),this['_get'](_0xf32630)),this['listeners'][_0xf32630]['add'](_0x37133b);}['_removeListener'](_0x18bc3e,_0x34bc0f){this['listeners'][_0x18bc3e]&&(this['listeners'][_0x18bc3e]['delete'](_0x34bc0f),this['listeners'][_0x18bc3e]['size']===0x0&&delete this['listeners'][_0x18bc3e]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x421516,_0x25bf6d){return _0x25bf6d?ne(_0x25bf6d):(m(_0x421516['_popupRedirectResolver'],_0x421516,'argument-error'),_0x421516['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x51dd74){super('custom','custom'),this['params']=_0x51dd74;}['_getIdTokenResponse'](_0x545343){return Ze(_0x545343,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1c29c8,_0x55b38f){return Ze(_0x1c29c8,this['_buildIdpRequest'](_0x55b38f));}['_getReauthenticationResolver'](_0x539395){return Ze(_0x539395,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x45786b){const _0x50237b={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x45786b&&(_0x50237b['idToken']=_0x45786b),_0x50237b;}}function pp(_0x41ed7b){return Ua(_0x41ed7b['auth'],new Rs(_0x41ed7b),_0x41ed7b['bypassAuthState']);}function _p(_0x31ea20){const {auth:_0x4bc19c,user:_0x36f74f}=_0x31ea20;return m(_0x36f74f,_0x4bc19c,'internal-error'),Kf(_0x36f74f,new Rs(_0x31ea20),_0x31ea20['bypassAuthState']);}async function gp(_0xec53af){const {auth:_0x3cab3d,user:_0x4cdea6}=_0xec53af;return m(_0x4cdea6,_0x3cab3d,'internal-error'),jf(_0x4cdea6,new Rs(_0xec53af),_0xec53af['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x1bd058,_0x509036,_0x1d987d,_0x39bbdd,_0x193430=!0x1){this['auth']=_0x1bd058,this['resolver']=_0x1d987d,this['user']=_0x39bbdd,this['bypassAuthState']=_0x193430,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x509036)?_0x509036:[_0x509036];}['execute'](){return new Promise(async(_0x3be354,_0x402d64)=>{this['pendingPromise']={'resolve':_0x3be354,'reject':_0x402d64};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x10f092){this['reject'](_0x10f092);}});}async['onAuthEvent'](_0x2892dc){const {urlResponse:_0x2d1d34,sessionId:_0xd4c96e,postBody:_0x32cdd6,tenantId:_0x127b4b,error:_0x4d9b0c,type:_0x1e6d6f}=_0x2892dc;if(_0x4d9b0c){this['reject'](_0x4d9b0c);return;}const _0x4706d5={'auth':this['auth'],'requestUri':_0x2d1d34,'sessionId':_0xd4c96e,'tenantId':_0x127b4b||void 0x0,'postBody':_0x32cdd6||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x1e6d6f)(_0x4706d5));}catch(_0xc7ebf2){this['reject'](_0xc7ebf2);}}['onError'](_0x334e69){this['reject'](_0x334e69);}['getIdpTask'](_0x325a7a){switch(_0x325a7a){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x4131a1){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4131a1),this['unregisterAndCleanUp']();}['reject'](_0x345c5b){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x345c5b),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x454286,_0x22d20b,_0x3d556c,_0x23164a,_0x15bf08){super(_0x454286,_0x22d20b,_0x23164a,_0x15bf08),this['provider']=_0x3d556c,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x491fb0=await this['execute']();return m(_0x491fb0,this['auth'],'internal-error'),_0x491fb0;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3b1de9=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3b1de9),this['authWindow']['associatedEvent']=_0x3b1de9,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4a3bc6=>{this['reject'](_0x4a3bc6);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x436594=>{_0x436594||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x342627;return((_0x342627=this['authWindow'])==null?void 0x0:_0x342627['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x4a1cdf=()=>{var _0x2c3bec,_0x8cc865;if((_0x8cc865=(_0x2c3bec=this['authWindow'])==null?void 0x0:_0x2c3bec['window'])!=null&&_0x8cc865['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x4a1cdf,mp['get']());};_0x4a1cdf();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x2a5b96,_0x26aa71,_0x215e5b=!0x1){super(_0x2a5b96,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x26aa71,void 0x0,_0x215e5b),this['eventId']=null;}async['execute'](){let _0x4c9362=rn['get'](this['auth']['_key']());if(!_0x4c9362){try{const _0x4f96d2=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x4c9362=()=>Promise['resolve'](_0x4f96d2);}catch(_0x264fb5){_0x4c9362=()=>Promise['reject'](_0x264fb5);}rn['set'](this['auth']['_key'](),_0x4c9362);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4c9362();}async['onAuthEvent'](_0x1f5f20){if(_0x1f5f20['type']==='signInViaRedirect')return super['onAuthEvent'](_0x1f5f20);if(_0x1f5f20['type']==='unknown'){this['resolve'](null);return;}if(_0x1f5f20['eventId']){const _0x1b1a87=await this['auth']['_redirectUserForId'](_0x1f5f20['eventId']);if(_0x1b1a87)return this['user']=_0x1b1a87,super['onAuthEvent'](_0x1f5f20);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x32627b,_0x564451){const _0x5240ff=Cp(_0x564451),_0x476ce9=wp(_0x32627b);if(!await _0x476ce9['_isAvailable']())return!0x1;const _0x54f47e=await _0x476ce9['_get'](_0x5240ff)==='true';return await _0x476ce9['_remove'](_0x5240ff),_0x54f47e;}function Ip(_0x3255ea,_0xed81f5){rn['set'](_0x3255ea['_key'](),_0xed81f5);}function wp(_0x37edb7){return ne(_0x37edb7['_redirectPersistence']);}function Cp(_0x283969){return sn(yp,_0x283969['config']['apiKey'],_0x283969['name']);}async function Tp(_0x4ef2da,_0x2c01cb,_0xd0eb78=!0x1){if(H(_0x4ef2da['app']))return Promise['reject'](se(_0x4ef2da));const _0x3f50bf=qe(_0x4ef2da),_0x3ae37a=fp(_0x3f50bf,_0x2c01cb),_0x4712f7=await new vp(_0x3f50bf,_0x3ae37a,_0xd0eb78)['execute']();return _0x4712f7&&!_0xd0eb78&&(delete _0x4712f7['user']['_redirectEventId'],await _0x3f50bf['_persistUserIfCurrent'](_0x4712f7['user']),await _0x3f50bf['_setRedirectUser'](null,_0x2c01cb)),_0x4712f7;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x37a77a){this['auth']=_0x37a77a,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x308707){this['consumers']['add'](_0x308707),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x308707)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x308707),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5ccb96){this['consumers']['delete'](_0x5ccb96);}['onEvent'](_0x494d48){if(this['hasEventBeenHandled'](_0x494d48))return!0x1;let _0x10aab1=!0x1;return this['consumers']['forEach'](_0x1f6943=>{this['isEventForConsumer'](_0x494d48,_0x1f6943)&&(_0x10aab1=!0x0,this['sendToConsumer'](_0x494d48,_0x1f6943),this['saveEventToCache'](_0x494d48));}),this['hasHandledPotentialRedirect']||!Rp(_0x494d48)||(this['hasHandledPotentialRedirect']=!0x0,_0x10aab1||(this['queuedRedirectEvent']=_0x494d48,_0x10aab1=!0x0)),_0x10aab1;}['sendToConsumer'](_0x3faa54,_0x1bf27c){var _0x57ff37;if(_0x3faa54['error']&&!Qa(_0x3faa54)){const _0x34aaf8=((_0x57ff37=_0x3faa54['error']['code'])==null?void 0x0:_0x57ff37['split']('auth/')[0x1])||'internal-error';_0x1bf27c['onError'](J(this['auth'],_0x34aaf8));}else _0x1bf27c['onAuthEvent'](_0x3faa54);}['isEventForConsumer'](_0xfe4531,_0x107965){const _0x911297=_0x107965['eventId']===null||!!_0xfe4531['eventId']&&_0xfe4531['eventId']===_0x107965['eventId'];return _0x107965['filter']['includes'](_0xfe4531['type'])&&_0x911297;}['hasEventBeenHandled'](_0x3c0ebd){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x3c0ebd));}['saveEventToCache'](_0x573688){this['cachedEventUids']['add'](Pr(_0x573688)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x2aa422){return[_0x2aa422['type'],_0x2aa422['eventId'],_0x2aa422['sessionId'],_0x2aa422['tenantId']]['filter'](_0x5a3d45=>_0x5a3d45)['join']('-');}function Qa({type:_0x3ec2a8,error:_0x392141}){return _0x3ec2a8==='unknown'&&(_0x392141==null?void 0x0:_0x392141['code'])==='auth/no-auth-event';}function Rp(_0x49cbf0){switch(_0x49cbf0['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x49cbf0);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x55fb23,_0xb68996={}){return Ae(_0x55fb23,'GET','/v1/projects',_0xb68996);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x20f76b){if(_0x20f76b['config']['emulator'])return;const {authorizedDomains:_0x3ab87a}=await Ap(_0x20f76b);for(const _0x1143bc of _0x3ab87a)try{if(Op(_0x1143bc))return;}catch{}K(_0x20f76b,'unauthorized-domain');}function Op(_0x519680){const _0x295e95=Ni(),{protocol:_0xb8f630,hostname:_0x5499a7}=new URL(_0x295e95);if(_0x519680['startsWith']('chrome-extension://')){const _0x29367d=new URL(_0x519680);return _0x29367d['hostname']===''&&_0x5499a7===''?_0xb8f630==='chrome-extension:'&&_0x519680['replace']('chrome-extension://','')===_0x295e95['replace']('chrome-extension://',''):_0xb8f630==='chrome-extension:'&&_0x29367d['hostname']===_0x5499a7;}if(!Np['test'](_0xb8f630))return!0x1;if(kp['test'](_0x519680))return _0x5499a7===_0x519680;const _0x488c82=_0x519680['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x488c82+'|'+_0x488c82+')$','i')['test'](_0x5499a7);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x25fd44=X()['___jsl'];if(_0x25fd44!=null&&_0x25fd44['H']){for(const _0x266cc9 of Object['keys'](_0x25fd44['H']))if(_0x25fd44['H'][_0x266cc9]['r']=_0x25fd44['H'][_0x266cc9]['r']||[],_0x25fd44['H'][_0x266cc9]['L']=_0x25fd44['H'][_0x266cc9]['L']||[],_0x25fd44['H'][_0x266cc9]['r']=[..._0x25fd44['H'][_0x266cc9]['L']],_0x25fd44['CP']){for(let _0x265f1e=0x0;_0x265f1e<_0x25fd44['CP']['length'];_0x265f1e++)_0x25fd44['CP'][_0x265f1e]=null;}}}function Mp(_0x407167){return new Promise((_0x5d00c9,_0x4284cc)=>{var _0x4878f6,_0x1538bc,_0x5aa633;function _0x179fc6(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x5d00c9(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x4284cc(J(_0x407167,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x1538bc=(_0x4878f6=X()['gapi'])==null?void 0x0:_0x4878f6['iframes'])!=null&&_0x1538bc['Iframe'])_0x5d00c9(gapi['iframes']['getContext']());else{if((_0x5aa633=X()['gapi'])!=null&&_0x5aa633['load'])_0x179fc6();else{const _0x41a737=Nf('iframefcb');return X()[_0x41a737]=()=>{gapi['load']?_0x179fc6():_0x4284cc(J(_0x407167,'network-request-failed'));},Da(kf()+'?onload='+_0x41a737)['catch'](_0x2e14f4=>_0x4284cc(_0x2e14f4));}}})['catch'](_0x2d3cfa=>{throw on=null,_0x2d3cfa;});}let on=null;function Lp(_0x53b8c8){return on=on||Mp(_0x53b8c8),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x164680){const _0x42780d=_0x164680['config'];m(_0x42780d['authDomain'],_0x164680,'auth-domain-config-required');const _0x5de2e9=_0x42780d['emulator']?Is(_0x42780d,Up):'https://'+_0x164680['config']['authDomain']+'/'+Fp,_0x41afa4={'apiKey':_0x42780d['apiKey'],'appName':_0x164680['name'],'v':ct},_0x2ef520=Bp['get'](_0x164680['config']['apiHost']);_0x2ef520&&(_0x41afa4['eid']=_0x2ef520);const _0x2ded79=_0x164680['_getFrameworks']();return _0x2ded79['length']&&(_0x41afa4['fw']=_0x2ded79['join'](',')),_0x5de2e9+'?'+at(_0x41afa4)['slice'](0x1);}async function Hp(_0x3a4777){const _0x229e99=await Lp(_0x3a4777),_0x422821=X()['gapi'];return m(_0x422821,_0x3a4777,'internal-error'),_0x229e99['open']({'where':document['body'],'url':Vp(_0x3a4777),'messageHandlersFilter':_0x422821['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x1edb3d=>new Promise(async(_0x1e0166,_0x4dc5f9)=>{await _0x1edb3d['restyle']({'setHideOnLeave':!0x1});const _0x409d17=J(_0x3a4777,'network-request-failed'),_0x3a2e05=X()['setTimeout'](()=>{_0x4dc5f9(_0x409d17);},xp['get']());function _0x562c41(){X()['clearTimeout'](_0x3a2e05),_0x1e0166(_0x1edb3d);}_0x1edb3d['ping'](_0x562c41)['then'](_0x562c41,()=>{_0x4dc5f9(_0x409d17);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x32c32b){this['window']=_0x32c32b,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x5f2b97,_0x103b10,_0x529276,_0x52abd9=Gp,_0x3a1ae1=qp){const _0x5f2940=Math['max']((window['screen']['availHeight']-_0x3a1ae1)/0x2,0x0)['toString'](),_0x2a6577=Math['max']((window['screen']['availWidth']-_0x52abd9)/0x2,0x0)['toString']();let _0x296d06='';const _0x2b0f10={...$p,'width':_0x52abd9['toString'](),'height':_0x3a1ae1['toString'](),'top':_0x5f2940,'left':_0x2a6577},_0x243771=W()['toLowerCase']();_0x529276&&(_0x296d06=ba(_0x243771)?zp:_0x529276),Ta(_0x243771)&&(_0x103b10=_0x103b10||jp,_0x2b0f10['scrollbars']='yes');const _0x3836ab=Object['entries'](_0x2b0f10)['reduce']((_0xf2045a,[_0x2877f4,_0x1bb709])=>''+_0xf2045a+_0x2877f4+'='+_0x1bb709+',','');if(Ef(_0x243771)&&_0x296d06!=='_self')return Yp(_0x103b10||'',_0x296d06),new Dr(null);const _0x46739c=window['open'](_0x103b10||'',_0x296d06,_0x3836ab);m(_0x46739c,_0x5f2b97,'popup-blocked');try{_0x46739c['focus']();}catch{}return new Dr(_0x46739c);}function Yp(_0x50f839,_0x547404){const _0x1459d3=document['createElement']('a');_0x1459d3['href']=_0x50f839,_0x1459d3['target']=_0x547404;const _0x485b7e=document['createEvent']('MouseEvent');_0x485b7e['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1459d3['dispatchEvent'](_0x485b7e);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x482a57,_0x407752,_0x3e1aaf,_0x229548,_0x3b8f0a,_0x2e06bf){m(_0x482a57['config']['authDomain'],_0x482a57,'auth-domain-config-required'),m(_0x482a57['config']['apiKey'],_0x482a57,'invalid-api-key');const _0x3cbd22={'apiKey':_0x482a57['config']['apiKey'],'appName':_0x482a57['name'],'authType':_0x3e1aaf,'redirectUrl':_0x229548,'v':ct,'eventId':_0x3b8f0a};if(_0x407752 instanceof xa){_0x407752['setDefaultLanguage'](_0x482a57['languageCode']),_0x3cbd22['providerId']=_0x407752['providerId']||'',hi(_0x407752['getCustomParameters']())||(_0x3cbd22['customParameters']=JSON['stringify'](_0x407752['getCustomParameters']()));for(const [_0x1d8ebb,_0x544b00]of Object['entries']({}))_0x3cbd22[_0x1d8ebb]=_0x544b00;}if(_0x407752 instanceof Qt){const _0x57eb8b=_0x407752['getScopes']()['filter'](_0x37706c=>_0x37706c!=='');_0x57eb8b['length']>0x0&&(_0x3cbd22['scopes']=_0x57eb8b['join'](','));}_0x482a57['tenantId']&&(_0x3cbd22['tid']=_0x482a57['tenantId']);const _0x3728ba=_0x3cbd22;for(const _0x389e63 of Object['keys'](_0x3728ba))_0x3728ba[_0x389e63]===void 0x0&&delete _0x3728ba[_0x389e63];const _0x10b11a=await _0x482a57['_getAppCheckToken'](),_0x559db3=_0x10b11a?'#'+Xp+'='+encodeURIComponent(_0x10b11a):'';return Zp(_0x482a57)+'?'+at(_0x3728ba)['slice'](0x1)+_0x559db3;}function Zp({config:_0x48bb59}){return _0x48bb59['emulator']?Is(_0x48bb59,Jp):'https://'+_0x48bb59['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0xba9465,_0x17d78c,_0x35d2b9,_0x1a4006){var _0x329b7b;ae((_0x329b7b=this['eventManagers'][_0xba9465['_key']()])==null?void 0x0:_0x329b7b['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4f2e81=await Mr(_0xba9465,_0x17d78c,_0x35d2b9,Ni(),_0x1a4006);return Kp(_0xba9465,_0x4f2e81,bs());}async['_openRedirect'](_0x404056,_0x2cffdd,_0x421b05,_0xc7f606){await this['_originValidation'](_0x404056);const _0x30d2b2=await Mr(_0x404056,_0x2cffdd,_0x421b05,Ni(),_0xc7f606);return ip(_0x30d2b2),new Promise(()=>{});}['_initialize'](_0x1376f9){const _0x25ea18=_0x1376f9['_key']();if(this['eventManagers'][_0x25ea18]){const {manager:_0xcfc5e0,promise:_0x4f88ba}=this['eventManagers'][_0x25ea18];return _0xcfc5e0?Promise['resolve'](_0xcfc5e0):(ae(_0x4f88ba,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4f88ba);}const _0x1c792b=this['initAndGetManager'](_0x1376f9);return this['eventManagers'][_0x25ea18]={'promise':_0x1c792b},_0x1c792b['catch'](()=>{delete this['eventManagers'][_0x25ea18];}),_0x1c792b;}async['initAndGetManager'](_0x496ec7){const _0x545683=await Hp(_0x496ec7),_0x5a44d2=new bp(_0x496ec7);return _0x545683['register']('authEvent',_0x538fa0=>(m(_0x538fa0==null?void 0x0:_0x538fa0['authEvent'],_0x496ec7,'invalid-auth-event'),{'status':_0x5a44d2['onEvent'](_0x538fa0['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x496ec7['_key']()]={'manager':_0x5a44d2},this['iframes'][_0x496ec7['_key']()]=_0x545683,_0x5a44d2;}['_isIframeWebStorageSupported'](_0x1467b1,_0x592e7b){this['iframes'][_0x1467b1['_key']()]['send'](li,{'type':li},_0x90ed40=>{var _0xa9f825;const _0x516d33=(_0xa9f825=_0x90ed40==null?void 0x0:_0x90ed40[0x0])==null?void 0x0:_0xa9f825[li];_0x516d33!==void 0x0&&_0x592e7b(!!_0x516d33),K(_0x1467b1,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x543efe){const _0x38d5f7=_0x543efe['_key']();return this['originValidationPromises'][_0x38d5f7]||(this['originValidationPromises'][_0x38d5f7]=Pp(_0x543efe)),this['originValidationPromises'][_0x38d5f7];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x56820c){this['auth']=_0x56820c,this['internalListeners']=new Map();}['getUid'](){var _0x1445d3;return this['assertAuthConfigured'](),((_0x1445d3=this['auth']['currentUser'])==null?void 0x0:_0x1445d3['uid'])||null;}async['getToken'](_0x49e43c){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x49e43c)}:null;}['addAuthTokenListener'](_0x22bb04){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x22bb04))return;const _0x1efea7=this['auth']['onIdTokenChanged'](_0x259734=>{_0x22bb04((_0x259734==null?void 0x0:_0x259734['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x22bb04,_0x1efea7),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xc35103){this['assertAuthConfigured']();const _0x93a32b=this['internalListeners']['get'](_0xc35103);_0x93a32b&&(this['internalListeners']['delete'](_0xc35103),_0x93a32b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x84d286){switch(_0x84d286){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x3515d9){et(new Me('auth',(_0x12039c,{options:_0x53321a})=>{const _0x145a61=_0x12039c['getProvider']('app')['getImmediate'](),_0x46ea6d=_0x12039c['getProvider']('heartbeat'),_0x413042=_0x12039c['getProvider']('app-check-internal'),{apiKey:_0x5544dc,authDomain:_0x87d6e5}=_0x145a61['options'];m(_0x5544dc&&!_0x5544dc['includes'](':'),'invalid-api-key',{'appName':_0x145a61['name']});const _0x45f872={'apiKey':_0x5544dc,'authDomain':_0x87d6e5,'clientPlatform':_0x3515d9,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x3515d9)},_0x532649=new bf(_0x145a61,_0x46ea6d,_0x413042,_0x45f872);return Lf(_0x532649,_0x53321a),_0x532649;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x371018,_0x3d4744,_0x143100)=>{_0x371018['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x4c81be=>{const _0x58fae5=qe(_0x4c81be['getProvider']('auth')['getImmediate']());return(_0x51be99=>new n_(_0x51be99))(_0x58fae5);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x3515d9)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x1bff60=>async _0x4d9904=>{const _0x31ed3c=_0x4d9904&&await _0x4d9904['getIdTokenResult'](),_0x46b49a=_0x31ed3c&&(new Date()['getTime']()-Date['parse'](_0x31ed3c['issuedAtTime']))/0x3e8;if(_0x46b49a&&_0x46b49a>o_)return;const _0x3fcc18=_0x31ed3c==null?void 0x0:_0x31ed3c['token'];Fr!==_0x3fcc18&&(Fr=_0x3fcc18,await fetch(_0x1bff60,{'method':_0x3fcc18?'POST':'DELETE','headers':_0x3fcc18?{'Authorization':'Bearer\x20'+_0x3fcc18}:{}}));};function O_(_0x43f8f4=Qr()){const _0x53079c=Ui(_0x43f8f4,'auth');if(_0x53079c['isInitialized']())return _0x53079c['getImmediate']();const _0x773fb1=Mf(_0x43f8f4,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x270f53=Gr('authTokenSyncURL');if(_0x270f53&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x316b0c=new URL(_0x270f53,location['origin']);if(location['origin']===_0x316b0c['origin']){const _0x228a05=a_(_0x316b0c['toString']());Jf(_0x773fb1,_0x228a05,()=>_0x228a05(_0x773fb1['currentUser'])),Qf(_0x773fb1,_0x584da9=>_0x228a05(_0x584da9));}}const _0x1e675b=Hr('auth');return _0x1e675b&&xf(_0x773fb1,'http://'+_0x1e675b),_0x773fb1;}function c_(){var _0x204c71;return((_0x204c71=document['getElementsByTagName']('head'))==null?void 0x0:_0x204c71[0x0])??document;}Rf({'loadJS'(_0x5830b2){return new Promise((_0x1aa310,_0x4dd06d)=>{const _0x57b813=document['createElement']('script');_0x57b813['setAttribute']('src',_0x5830b2),_0x57b813['onload']=_0x1aa310,_0x57b813['onerror']=_0x4e4435=>{const _0x5ccdc8=J('internal-error');_0x5ccdc8['customData']=_0x4e4435,_0x4dd06d(_0x5ccdc8);},_0x57b813['type']='text/javascript',_0x57b813['charset']='UTF-8',c_()['appendChild'](_0x57b813);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};