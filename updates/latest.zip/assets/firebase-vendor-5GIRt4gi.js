const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4f097c,_0x1ff25d){if(!_0x4f097c)throw ot(_0x1ff25d);},ot=function(_0xf0e8de){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xf0e8de);},Wr=function(_0x479db0){const _0x5e13b0=[];let _0x14ac59=0x0;for(let _0x195b5b=0x0;_0x195b5b<_0x479db0['length'];_0x195b5b++){let _0x34f3f2=_0x479db0['charCodeAt'](_0x195b5b);_0x34f3f2<0x80?_0x5e13b0[_0x14ac59++]=_0x34f3f2:_0x34f3f2<0x800?(_0x5e13b0[_0x14ac59++]=_0x34f3f2>>0x6|0xc0,_0x5e13b0[_0x14ac59++]=_0x34f3f2&0x3f|0x80):(_0x34f3f2&0xfc00)===0xd800&&_0x195b5b+0x1<_0x479db0['length']&&(_0x479db0['charCodeAt'](_0x195b5b+0x1)&0xfc00)===0xdc00?(_0x34f3f2=0x10000+((_0x34f3f2&0x3ff)<<0xa)+(_0x479db0['charCodeAt'](++_0x195b5b)&0x3ff),_0x5e13b0[_0x14ac59++]=_0x34f3f2>>0x12|0xf0,_0x5e13b0[_0x14ac59++]=_0x34f3f2>>0xc&0x3f|0x80,_0x5e13b0[_0x14ac59++]=_0x34f3f2>>0x6&0x3f|0x80,_0x5e13b0[_0x14ac59++]=_0x34f3f2&0x3f|0x80):(_0x5e13b0[_0x14ac59++]=_0x34f3f2>>0xc|0xe0,_0x5e13b0[_0x14ac59++]=_0x34f3f2>>0x6&0x3f|0x80,_0x5e13b0[_0x14ac59++]=_0x34f3f2&0x3f|0x80);}return _0x5e13b0;},Za=function(_0x42fdda){const _0x2d5168=[];let _0x2c4116=0x0,_0x321e02=0x0;for(;_0x2c4116<_0x42fdda['length'];){const _0x30ab3f=_0x42fdda[_0x2c4116++];if(_0x30ab3f<0x80)_0x2d5168[_0x321e02++]=String['fromCharCode'](_0x30ab3f);else{if(_0x30ab3f>0xbf&&_0x30ab3f<0xe0){const _0x362a6e=_0x42fdda[_0x2c4116++];_0x2d5168[_0x321e02++]=String['fromCharCode']((_0x30ab3f&0x1f)<<0x6|_0x362a6e&0x3f);}else{if(_0x30ab3f>0xef&&_0x30ab3f<0x16d){const _0x270519=_0x42fdda[_0x2c4116++],_0x5acd62=_0x42fdda[_0x2c4116++],_0x27877d=_0x42fdda[_0x2c4116++],_0x10f81a=((_0x30ab3f&0x7)<<0x12|(_0x270519&0x3f)<<0xc|(_0x5acd62&0x3f)<<0x6|_0x27877d&0x3f)-0x10000;_0x2d5168[_0x321e02++]=String['fromCharCode'](0xd800+(_0x10f81a>>0xa)),_0x2d5168[_0x321e02++]=String['fromCharCode'](0xdc00+(_0x10f81a&0x3ff));}else{const _0x307c17=_0x42fdda[_0x2c4116++],_0x598e41=_0x42fdda[_0x2c4116++];_0x2d5168[_0x321e02++]=String['fromCharCode']((_0x30ab3f&0xf)<<0xc|(_0x307c17&0x3f)<<0x6|_0x598e41&0x3f);}}}}return _0x2d5168['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4296ce,_0x100705){if(!Array['isArray'](_0x4296ce))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x456cf2=_0x100705?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x1b98ed=[];for(let _0x2ea637=0x0;_0x2ea637<_0x4296ce['length'];_0x2ea637+=0x3){const _0x1c712d=_0x4296ce[_0x2ea637],_0x17c721=_0x2ea637+0x1<_0x4296ce['length'],_0x3ee7b4=_0x17c721?_0x4296ce[_0x2ea637+0x1]:0x0,_0x5c3710=_0x2ea637+0x2<_0x4296ce['length'],_0x3b5aeb=_0x5c3710?_0x4296ce[_0x2ea637+0x2]:0x0,_0x1015b1=_0x1c712d>>0x2,_0x5bcb80=(_0x1c712d&0x3)<<0x4|_0x3ee7b4>>0x4;let _0x39c343=(_0x3ee7b4&0xf)<<0x2|_0x3b5aeb>>0x6,_0x3cb22c=_0x3b5aeb&0x3f;_0x5c3710||(_0x3cb22c=0x40,_0x17c721||(_0x39c343=0x40)),_0x1b98ed['push'](_0x456cf2[_0x1015b1],_0x456cf2[_0x5bcb80],_0x456cf2[_0x39c343],_0x456cf2[_0x3cb22c]);}return _0x1b98ed['join']('');},'encodeString'(_0x49ebe2,_0xb91e49){return this['HAS_NATIVE_SUPPORT']&&!_0xb91e49?btoa(_0x49ebe2):this['encodeByteArray'](Wr(_0x49ebe2),_0xb91e49);},'decodeString'(_0x5ab6bc,_0x57db1d){return this['HAS_NATIVE_SUPPORT']&&!_0x57db1d?atob(_0x5ab6bc):Za(this['decodeStringToByteArray'](_0x5ab6bc,_0x57db1d));},'decodeStringToByteArray'(_0x216112,_0x5aa102){this['init_']();const _0x110840=_0x5aa102?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x21e340=[];for(let _0x3e8286=0x0;_0x3e8286<_0x216112['length'];){const _0x3c16cd=_0x110840[_0x216112['charAt'](_0x3e8286++)],_0x34c35f=_0x3e8286<_0x216112['length']?_0x110840[_0x216112['charAt'](_0x3e8286)]:0x0;++_0x3e8286;const _0x3a98b7=_0x3e8286<_0x216112['length']?_0x110840[_0x216112['charAt'](_0x3e8286)]:0x40;++_0x3e8286;const _0x5abb12=_0x3e8286<_0x216112['length']?_0x110840[_0x216112['charAt'](_0x3e8286)]:0x40;if(++_0x3e8286,_0x3c16cd==null||_0x34c35f==null||_0x3a98b7==null||_0x5abb12==null)throw new ec();const _0x2eabc6=_0x3c16cd<<0x2|_0x34c35f>>0x4;if(_0x21e340['push'](_0x2eabc6),_0x3a98b7!==0x40){const _0x3b3294=_0x34c35f<<0x4&0xf0|_0x3a98b7>>0x2;if(_0x21e340['push'](_0x3b3294),_0x5abb12!==0x40){const _0x5894c9=_0x3a98b7<<0x6&0xc0|_0x5abb12;_0x21e340['push'](_0x5894c9);}}}return _0x21e340;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x373744=0x0;_0x373744<this['ENCODED_VALS']['length'];_0x373744++)this['byteToCharMap_'][_0x373744]=this['ENCODED_VALS']['charAt'](_0x373744),this['charToByteMap_'][this['byteToCharMap_'][_0x373744]]=_0x373744,this['byteToCharMapWebSafe_'][_0x373744]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x373744),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x373744]]=_0x373744,_0x373744>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x373744)]=_0x373744,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x373744)]=_0x373744);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x2437d4){const _0x158832=Wr(_0x2437d4);return Di['encodeByteArray'](_0x158832,!0x0);},an=function(_0x98af3a){return Br(_0x98af3a)['replace'](/\./g,'');},cn=function(_0x367150){try{return Di['decodeString'](_0x367150,!0x0);}catch(_0x270482){console['error']('base64Decode\x20failed:\x20',_0x270482);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x591a40){return Vr(void 0x0,_0x591a40);}function Vr(_0x435f12,_0x344ef3){if(!(_0x344ef3 instanceof Object))return _0x344ef3;switch(_0x344ef3['constructor']){case Date:const _0xa3f8f7=_0x344ef3;return new Date(_0xa3f8f7['getTime']());case Object:_0x435f12===void 0x0&&(_0x435f12={});break;case Array:_0x435f12=[];break;default:return _0x344ef3;}for(const _0x1268be in _0x344ef3)!_0x344ef3['hasOwnProperty'](_0x1268be)||!nc(_0x1268be)||(_0x435f12[_0x1268be]=Vr(_0x435f12[_0x1268be],_0x344ef3[_0x1268be]));return _0x435f12;}function nc(_0x46bcf5){return _0x46bcf5!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0xcbd3e0=As['__FIREBASE_DEFAULTS__'];if(_0xcbd3e0)return JSON['parse'](_0xcbd3e0);},oc=()=>{if(typeof document>'u')return;let _0x44718c;try{_0x44718c=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3dc979=_0x44718c&&cn(_0x44718c[0x1]);return _0x3dc979&&JSON['parse'](_0x3dc979);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x5096f0){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5096f0);return;}},Hr=_0x433b18=>{var _0x285672,_0x7833a5;return(_0x7833a5=(_0x285672=Mi())==null?void 0x0:_0x285672['emulatorHosts'])==null?void 0x0:_0x7833a5[_0x433b18];},ac=_0x172e31=>{const _0x74e04e=Hr(_0x172e31);if(!_0x74e04e)return;const _0x3df253=_0x74e04e['lastIndexOf'](':');if(_0x3df253<=0x0||_0x3df253+0x1===_0x74e04e['length'])throw new Error('Invalid\x20host\x20'+_0x74e04e+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x221f9b=parseInt(_0x74e04e['substring'](_0x3df253+0x1),0xa);return _0x74e04e[0x0]==='['?[_0x74e04e['substring'](0x1,_0x3df253-0x1),_0x221f9b]:[_0x74e04e['substring'](0x0,_0x3df253),_0x221f9b];},$r=()=>{var _0x22bd09;return(_0x22bd09=Mi())==null?void 0x0:_0x22bd09['config'];},Gr=_0x3ae86b=>{var _0x277cb7;return(_0x277cb7=Mi())==null?void 0x0:_0x277cb7['_'+_0x3ae86b];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4553c5,_0x4c1315)=>{this['resolve']=_0x4553c5,this['reject']=_0x4c1315;});}['wrapCallback'](_0x2a9fd6){return(_0x50bcb8,_0xe926bd)=>{_0x50bcb8?this['reject'](_0x50bcb8):this['resolve'](_0xe926bd),typeof _0x2a9fd6=='function'&&(this['promise']['catch'](()=>{}),_0x2a9fd6['length']===0x1?_0x2a9fd6(_0x50bcb8):_0x2a9fd6(_0x50bcb8,_0xe926bd));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x36eef9,_0x38df7a){if(_0x36eef9['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x557f03={'alg':'none','type':'JWT'},_0x223462=_0x38df7a||'demo-project',_0x553bd1=_0x36eef9['iat']||0x0,_0x4fc0e1=_0x36eef9['sub']||_0x36eef9['user_id'];if(!_0x4fc0e1)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2bc4b2={'iss':'https://securetoken.google.com/'+_0x223462,'aud':_0x223462,'iat':_0x553bd1,'exp':_0x553bd1+0xe10,'auth_time':_0x553bd1,'sub':_0x4fc0e1,'user_id':_0x4fc0e1,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x36eef9};return[an(JSON['stringify'](_0x557f03)),an(JSON['stringify'](_0x2bc4b2)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x164695=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x164695=='object'&&_0x164695['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x3e08d0=W();return _0x3e08d0['indexOf']('MSIE\x20')>=0x0||_0x3e08d0['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x1bcb4b,_0x4203dd)=>{try{let _0x2853e0=!0x0;const _0x3e5b9c='validate-browser-context-for-indexeddb-analytics-module',_0x2b55ec=self['indexedDB']['open'](_0x3e5b9c);_0x2b55ec['onsuccess']=()=>{_0x2b55ec['result']['close'](),_0x2853e0||self['indexedDB']['deleteDatabase'](_0x3e5b9c),_0x1bcb4b(!0x0);},_0x2b55ec['onupgradeneeded']=()=>{_0x2853e0=!0x1;},_0x2b55ec['onerror']=()=>{var _0x55d61c;_0x4203dd(((_0x55d61c=_0x2b55ec['error'])==null?void 0x0:_0x55d61c['message'])||'');};}catch(_0x19a193){_0x4203dd(_0x19a193);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x2f8e7f,_0x16e5ef,_0x43a332){super(_0x16e5ef),this['code']=_0x2f8e7f,this['customData']=_0x43a332,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x16a90e,_0x3bba4f,_0x1eb8a3){this['service']=_0x16a90e,this['serviceName']=_0x3bba4f,this['errors']=_0x1eb8a3;}['create'](_0x46a9e9,..._0x253a56){const _0x1177f3=_0x253a56[0x0]||{},_0x29f44f=this['service']+'/'+_0x46a9e9,_0x5d1732=this['errors'][_0x46a9e9],_0x1a83a7=_0x5d1732?gc(_0x5d1732,_0x1177f3):'Error',_0x1787a0=this['serviceName']+':\x20'+_0x1a83a7+'\x20('+_0x29f44f+').';return new Se(_0x29f44f,_0x1787a0,_0x1177f3);}}function gc(_0x17f3b5,_0x15b275){return _0x17f3b5['replace'](mc,(_0x57fd35,_0x22cbf0)=>{const _0x5d9fbf=_0x15b275[_0x22cbf0];return _0x5d9fbf!=null?String(_0x5d9fbf):'<'+_0x22cbf0+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x5d67a9){return JSON['parse'](_0x5d67a9);}function O(_0x1b4fac){return JSON['stringify'](_0x1b4fac);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x56dd20){let _0x4bb260={},_0x31a3ed={},_0x34201a={},_0x4afed9='';try{const _0x2f8df3=_0x56dd20['split']('.');_0x4bb260=bt(cn(_0x2f8df3[0x0])||''),_0x31a3ed=bt(cn(_0x2f8df3[0x1])||''),_0x4afed9=_0x2f8df3[0x2],_0x34201a=_0x31a3ed['d']||{},delete _0x31a3ed['d'];}catch{}return{'header':_0x4bb260,'claims':_0x31a3ed,'data':_0x34201a,'signature':_0x4afed9};},yc=function(_0x277f16){const _0x541c02=zr(_0x277f16),_0x37cc7c=_0x541c02['claims'];return!!_0x37cc7c&&typeof _0x37cc7c=='object'&&_0x37cc7c['hasOwnProperty']('iat');},vc=function(_0x4d0900){const _0x360250=zr(_0x4d0900)['claims'];return typeof _0x360250=='object'&&_0x360250['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3e4d20,_0x37b671){return Object['prototype']['hasOwnProperty']['call'](_0x3e4d20,_0x37b671);}function Oe(_0x220a43,_0x37b7b5){if(Object['prototype']['hasOwnProperty']['call'](_0x220a43,_0x37b7b5))return _0x220a43[_0x37b7b5];}function hi(_0x3ca4fe){for(const _0x206a32 in _0x3ca4fe)if(Object['prototype']['hasOwnProperty']['call'](_0x3ca4fe,_0x206a32))return!0x1;return!0x0;}function ln(_0x16722e,_0x385154,_0xaa9801){const _0x7aeefe={};for(const _0x53b8b3 in _0x16722e)Object['prototype']['hasOwnProperty']['call'](_0x16722e,_0x53b8b3)&&(_0x7aeefe[_0x53b8b3]=_0x385154['call'](_0xaa9801,_0x16722e[_0x53b8b3],_0x53b8b3,_0x16722e));return _0x7aeefe;}function De(_0x5ae008,_0x5d7e26){if(_0x5ae008===_0x5d7e26)return!0x0;const _0x1d18db=Object['keys'](_0x5ae008),_0x1d2f1f=Object['keys'](_0x5d7e26);for(const _0x47d683 of _0x1d18db){if(!_0x1d2f1f['includes'](_0x47d683))return!0x1;const _0x1e0248=_0x5ae008[_0x47d683],_0x466e9b=_0x5d7e26[_0x47d683];if(ks(_0x1e0248)&&ks(_0x466e9b)){if(!De(_0x1e0248,_0x466e9b))return!0x1;}else{if(_0x1e0248!==_0x466e9b)return!0x1;}}for(const _0x3a79ab of _0x1d2f1f)if(!_0x1d18db['includes'](_0x3a79ab))return!0x1;return!0x0;}function ks(_0x3ad65f){return _0x3ad65f!==null&&typeof _0x3ad65f=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x24d5ca){const _0x2df17a=[];for(const [_0x272dde,_0x45c512]of Object['entries'](_0x24d5ca))Array['isArray'](_0x45c512)?_0x45c512['forEach'](_0x16e7ad=>{_0x2df17a['push'](encodeURIComponent(_0x272dde)+'='+encodeURIComponent(_0x16e7ad));}):_0x2df17a['push'](encodeURIComponent(_0x272dde)+'='+encodeURIComponent(_0x45c512));return _0x2df17a['length']?'&'+_0x2df17a['join']('&'):'';}function yt(_0x5ce1c9){const _0x53bd89={};return _0x5ce1c9['replace'](/^\?/,'')['split']('&')['forEach'](_0x447fc1=>{if(_0x447fc1){const [_0x4131e9,_0x59cfa0]=_0x447fc1['split']('=');_0x53bd89[decodeURIComponent(_0x4131e9)]=decodeURIComponent(_0x59cfa0);}}),_0x53bd89;}function vt(_0x20bca6){const _0x5a6d4c=_0x20bca6['indexOf']('?');if(!_0x5a6d4c)return'';const _0x8ebf2e=_0x20bca6['indexOf']('#',_0x5a6d4c);return _0x20bca6['substring'](_0x5a6d4c,_0x8ebf2e>0x0?_0x8ebf2e:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3146d7=0x1;_0x3146d7<this['blockSize'];++_0x3146d7)this['pad_'][_0x3146d7]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5c6ffc,_0x87bf91){_0x87bf91||(_0x87bf91=0x0);const _0x592847=this['W_'];if(typeof _0x5c6ffc=='string'){for(let _0x369036=0x0;_0x369036<0x10;_0x369036++)_0x592847[_0x369036]=_0x5c6ffc['charCodeAt'](_0x87bf91)<<0x18|_0x5c6ffc['charCodeAt'](_0x87bf91+0x1)<<0x10|_0x5c6ffc['charCodeAt'](_0x87bf91+0x2)<<0x8|_0x5c6ffc['charCodeAt'](_0x87bf91+0x3),_0x87bf91+=0x4;}else{for(let _0xe1e219=0x0;_0xe1e219<0x10;_0xe1e219++)_0x592847[_0xe1e219]=_0x5c6ffc[_0x87bf91]<<0x18|_0x5c6ffc[_0x87bf91+0x1]<<0x10|_0x5c6ffc[_0x87bf91+0x2]<<0x8|_0x5c6ffc[_0x87bf91+0x3],_0x87bf91+=0x4;}for(let _0x488dd2=0x10;_0x488dd2<0x50;_0x488dd2++){const _0x161f5a=_0x592847[_0x488dd2-0x3]^_0x592847[_0x488dd2-0x8]^_0x592847[_0x488dd2-0xe]^_0x592847[_0x488dd2-0x10];_0x592847[_0x488dd2]=(_0x161f5a<<0x1|_0x161f5a>>>0x1f)&0xffffffff;}let _0x2a418f=this['chain_'][0x0],_0x4d1344=this['chain_'][0x1],_0x4377c7=this['chain_'][0x2],_0x5dc202=this['chain_'][0x3],_0xf81684=this['chain_'][0x4],_0x5ecdc1,_0x4185c0;for(let _0x1b1a8c=0x0;_0x1b1a8c<0x50;_0x1b1a8c++){_0x1b1a8c<0x28?_0x1b1a8c<0x14?(_0x5ecdc1=_0x5dc202^_0x4d1344&(_0x4377c7^_0x5dc202),_0x4185c0=0x5a827999):(_0x5ecdc1=_0x4d1344^_0x4377c7^_0x5dc202,_0x4185c0=0x6ed9eba1):_0x1b1a8c<0x3c?(_0x5ecdc1=_0x4d1344&_0x4377c7|_0x5dc202&(_0x4d1344|_0x4377c7),_0x4185c0=0x8f1bbcdc):(_0x5ecdc1=_0x4d1344^_0x4377c7^_0x5dc202,_0x4185c0=0xca62c1d6);const _0x416c71=(_0x2a418f<<0x5|_0x2a418f>>>0x1b)+_0x5ecdc1+_0xf81684+_0x4185c0+_0x592847[_0x1b1a8c]&0xffffffff;_0xf81684=_0x5dc202,_0x5dc202=_0x4377c7,_0x4377c7=(_0x4d1344<<0x1e|_0x4d1344>>>0x2)&0xffffffff,_0x4d1344=_0x2a418f,_0x2a418f=_0x416c71;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2a418f&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x4d1344&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4377c7&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5dc202&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0xf81684&0xffffffff;}['update'](_0x24f869,_0x309b6c){if(_0x24f869==null)return;_0x309b6c===void 0x0&&(_0x309b6c=_0x24f869['length']);const _0x55c2bb=_0x309b6c-this['blockSize'];let _0x273c14=0x0;const _0x2b0a62=this['buf_'];let _0x58efcd=this['inbuf_'];for(;_0x273c14<_0x309b6c;){if(_0x58efcd===0x0){for(;_0x273c14<=_0x55c2bb;)this['compress_'](_0x24f869,_0x273c14),_0x273c14+=this['blockSize'];}if(typeof _0x24f869=='string'){for(;_0x273c14<_0x309b6c;)if(_0x2b0a62[_0x58efcd]=_0x24f869['charCodeAt'](_0x273c14),++_0x58efcd,++_0x273c14,_0x58efcd===this['blockSize']){this['compress_'](_0x2b0a62),_0x58efcd=0x0;break;}}else{for(;_0x273c14<_0x309b6c;)if(_0x2b0a62[_0x58efcd]=_0x24f869[_0x273c14],++_0x58efcd,++_0x273c14,_0x58efcd===this['blockSize']){this['compress_'](_0x2b0a62),_0x58efcd=0x0;break;}}}this['inbuf_']=_0x58efcd,this['total_']+=_0x309b6c;}['digest'](){const _0x3181b2=[];let _0x289be8=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x3e3f8a=this['blockSize']-0x1;_0x3e3f8a>=0x38;_0x3e3f8a--)this['buf_'][_0x3e3f8a]=_0x289be8&0xff,_0x289be8/=0x100;this['compress_'](this['buf_']);let _0x5c593d=0x0;for(let _0x145687=0x0;_0x145687<0x5;_0x145687++)for(let _0x1f1924=0x18;_0x1f1924>=0x0;_0x1f1924-=0x8)_0x3181b2[_0x5c593d]=this['chain_'][_0x145687]>>_0x1f1924&0xff,++_0x5c593d;return _0x3181b2;}}function Ic(_0x38089d,_0x271c40){const _0x3cbbd3=new wc(_0x38089d,_0x271c40);return _0x3cbbd3['subscribe']['bind'](_0x3cbbd3);}class wc{constructor(_0x14ba38,_0x32a1ff){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x32a1ff,this['task']['then'](()=>{_0x14ba38(this);})['catch'](_0xeff94d=>{this['error'](_0xeff94d);});}['next'](_0x60a979){this['forEachObserver'](_0x5300d2=>{_0x5300d2['next'](_0x60a979);});}['error'](_0xe464c6){this['forEachObserver'](_0x3882a0=>{_0x3882a0['error'](_0xe464c6);}),this['close'](_0xe464c6);}['complete'](){this['forEachObserver'](_0x3a2b8b=>{_0x3a2b8b['complete']();}),this['close']();}['subscribe'](_0x4e9041,_0x29a044,_0x1cdeac){let _0x20b9cb;if(_0x4e9041===void 0x0&&_0x29a044===void 0x0&&_0x1cdeac===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x4e9041,['next','error','complete'])?_0x20b9cb=_0x4e9041:_0x20b9cb={'next':_0x4e9041,'error':_0x29a044,'complete':_0x1cdeac},_0x20b9cb['next']===void 0x0&&(_0x20b9cb['next']=Qn),_0x20b9cb['error']===void 0x0&&(_0x20b9cb['error']=Qn),_0x20b9cb['complete']===void 0x0&&(_0x20b9cb['complete']=Qn);const _0x410e5f=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x20b9cb['error'](this['finalError']):_0x20b9cb['complete']();}catch{}}),this['observers']['push'](_0x20b9cb),_0x410e5f;}['unsubscribeOne'](_0x33c943){this['observers']===void 0x0||this['observers'][_0x33c943]===void 0x0||(delete this['observers'][_0x33c943],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x568a79){if(!this['finalized']){for(let _0x16098d=0x0;_0x16098d<this['observers']['length'];_0x16098d++)this['sendOne'](_0x16098d,_0x568a79);}}['sendOne'](_0x129731,_0x5c7af0){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x129731]!==void 0x0)try{_0x5c7af0(this['observers'][_0x129731]);}catch(_0x8b614a){typeof console<'u'&&console['error']&&console['error'](_0x8b614a);}});}['close'](_0x56c7b7){this['finalized']||(this['finalized']=!0x0,_0x56c7b7!==void 0x0&&(this['finalError']=_0x56c7b7),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x34514c,_0x15c5d5){if(typeof _0x34514c!='object'||_0x34514c===null)return!0x1;for(const _0x50391c of _0x15c5d5)if(_0x50391c in _0x34514c&&typeof _0x34514c[_0x50391c]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x151431,_0x424610){return _0x151431+'\x20failed:\x20'+_0x424610+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x4785bf){const _0x3179df=[];let _0x25fe9a=0x0;for(let _0x1eb137=0x0;_0x1eb137<_0x4785bf['length'];_0x1eb137++){let _0x56d57f=_0x4785bf['charCodeAt'](_0x1eb137);if(_0x56d57f>=0xd800&&_0x56d57f<=0xdbff){const _0x2d1bae=_0x56d57f-0xd800;_0x1eb137++,f(_0x1eb137<_0x4785bf['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x48e2c2=_0x4785bf['charCodeAt'](_0x1eb137)-0xdc00;_0x56d57f=0x10000+(_0x2d1bae<<0xa)+_0x48e2c2;}_0x56d57f<0x80?_0x3179df[_0x25fe9a++]=_0x56d57f:_0x56d57f<0x800?(_0x3179df[_0x25fe9a++]=_0x56d57f>>0x6|0xc0,_0x3179df[_0x25fe9a++]=_0x56d57f&0x3f|0x80):_0x56d57f<0x10000?(_0x3179df[_0x25fe9a++]=_0x56d57f>>0xc|0xe0,_0x3179df[_0x25fe9a++]=_0x56d57f>>0x6&0x3f|0x80,_0x3179df[_0x25fe9a++]=_0x56d57f&0x3f|0x80):(_0x3179df[_0x25fe9a++]=_0x56d57f>>0x12|0xf0,_0x3179df[_0x25fe9a++]=_0x56d57f>>0xc&0x3f|0x80,_0x3179df[_0x25fe9a++]=_0x56d57f>>0x6&0x3f|0x80,_0x3179df[_0x25fe9a++]=_0x56d57f&0x3f|0x80);}return _0x3179df;},Pn=function(_0x195de6){let _0x315419=0x0;for(let _0x5606fb=0x0;_0x5606fb<_0x195de6['length'];_0x5606fb++){const _0x43345f=_0x195de6['charCodeAt'](_0x5606fb);_0x43345f<0x80?_0x315419++:_0x43345f<0x800?_0x315419+=0x2:_0x43345f>=0xd800&&_0x43345f<=0xdbff?(_0x315419+=0x4,_0x5606fb++):_0x315419+=0x3;}return _0x315419;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x5a2757){return _0x5a2757&&_0x5a2757['_delegate']?_0x5a2757['_delegate']:_0x5a2757;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x474e2e){try{return(_0x474e2e['startsWith']('http://')||_0x474e2e['startsWith']('https://')?new URL(_0x474e2e)['hostname']:_0x474e2e)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x58fcdc){return(await fetch(_0x58fcdc,{'credentials':'include'}))['ok'];}class Me{constructor(_0x3443b5,_0x5b3dbc,_0x1ec7cc){this['name']=_0x3443b5,this['instanceFactory']=_0x5b3dbc,this['type']=_0x1ec7cc,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1622b7){return this['instantiationMode']=_0x1622b7,this;}['setMultipleInstances'](_0xf88dc7){return this['multipleInstances']=_0xf88dc7,this;}['setServiceProps'](_0x5c0fbf){return this['serviceProps']=_0x5c0fbf,this;}['setInstanceCreatedCallback'](_0x1f0a2a){return this['onInstanceCreated']=_0x1f0a2a,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x1355e5,_0x2ccbee){this['name']=_0x1355e5,this['container']=_0x2ccbee,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x387a2a){const _0x481341=this['normalizeInstanceIdentifier'](_0x387a2a);if(!this['instancesDeferred']['has'](_0x481341)){const _0x418c86=new Ve();if(this['instancesDeferred']['set'](_0x481341,_0x418c86),this['isInitialized'](_0x481341)||this['shouldAutoInitialize']())try{const _0x11f082=this['getOrInitializeService']({'instanceIdentifier':_0x481341});_0x11f082&&_0x418c86['resolve'](_0x11f082);}catch{}}return this['instancesDeferred']['get'](_0x481341)['promise'];}['getImmediate'](_0x3be0e4){const _0x99e556=this['normalizeInstanceIdentifier'](_0x3be0e4==null?void 0x0:_0x3be0e4['identifier']),_0x179cca=(_0x3be0e4==null?void 0x0:_0x3be0e4['optional'])??!0x1;if(this['isInitialized'](_0x99e556)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x99e556});}catch(_0x3ac999){if(_0x179cca)return null;throw _0x3ac999;}else{if(_0x179cca)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x169dda){if(_0x169dda['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x169dda['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x169dda,!!this['shouldAutoInitialize']()){if(Rc(_0x169dda))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x2d4eff,_0x945ec1]of this['instancesDeferred']['entries']()){const _0x5b6861=this['normalizeInstanceIdentifier'](_0x2d4eff);try{const _0x42a76a=this['getOrInitializeService']({'instanceIdentifier':_0x5b6861});_0x945ec1['resolve'](_0x42a76a);}catch{}}}}['clearInstance'](_0x2e1f94=ke){this['instancesDeferred']['delete'](_0x2e1f94),this['instancesOptions']['delete'](_0x2e1f94),this['instances']['delete'](_0x2e1f94);}async['delete'](){const _0x170484=Array['from'](this['instances']['values']());await Promise['all']([..._0x170484['filter'](_0x4cc954=>'INTERNAL'in _0x4cc954)['map'](_0x5f5648=>_0x5f5648['INTERNAL']['delete']()),..._0x170484['filter'](_0x1816ff=>'_delete'in _0x1816ff)['map'](_0x3e5982=>_0x3e5982['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x3727e3=ke){return this['instances']['has'](_0x3727e3);}['getOptions'](_0x5c2bc7=ke){return this['instancesOptions']['get'](_0x5c2bc7)||{};}['initialize'](_0x3700cd={}){const {options:_0x36f1a4={}}=_0x3700cd,_0x3c9a17=this['normalizeInstanceIdentifier'](_0x3700cd['instanceIdentifier']);if(this['isInitialized'](_0x3c9a17))throw Error(this['name']+'('+_0x3c9a17+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3f4e08=this['getOrInitializeService']({'instanceIdentifier':_0x3c9a17,'options':_0x36f1a4});for(const [_0x104aaf,_0x4aecfa]of this['instancesDeferred']['entries']()){const _0x28adea=this['normalizeInstanceIdentifier'](_0x104aaf);_0x3c9a17===_0x28adea&&_0x4aecfa['resolve'](_0x3f4e08);}return _0x3f4e08;}['onInit'](_0x3224c5,_0x4ab0d9){const _0x8021bc=this['normalizeInstanceIdentifier'](_0x4ab0d9),_0x40e582=this['onInitCallbacks']['get'](_0x8021bc)??new Set();_0x40e582['add'](_0x3224c5),this['onInitCallbacks']['set'](_0x8021bc,_0x40e582);const _0x41f84b=this['instances']['get'](_0x8021bc);return _0x41f84b&&_0x3224c5(_0x41f84b,_0x8021bc),()=>{_0x40e582['delete'](_0x3224c5);};}['invokeOnInitCallbacks'](_0x32adbf,_0x3c9c86){const _0x1a3d18=this['onInitCallbacks']['get'](_0x3c9c86);if(_0x1a3d18){for(const _0xa39e63 of _0x1a3d18)try{_0xa39e63(_0x32adbf,_0x3c9c86);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x490add,options:_0x42e400={}}){let _0x5ecf4e=this['instances']['get'](_0x490add);if(!_0x5ecf4e&&this['component']&&(_0x5ecf4e=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x490add),'options':_0x42e400}),this['instances']['set'](_0x490add,_0x5ecf4e),this['instancesOptions']['set'](_0x490add,_0x42e400),this['invokeOnInitCallbacks'](_0x5ecf4e,_0x490add),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x490add,_0x5ecf4e);}catch{}return _0x5ecf4e||null;}['normalizeInstanceIdentifier'](_0x13a94b=ke){return this['component']?this['component']['multipleInstances']?_0x13a94b:ke:_0x13a94b;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x4eecc9){return _0x4eecc9===ke?void 0x0:_0x4eecc9;}function Rc(_0x3bde0b){return _0x3bde0b['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x10fd4d){this['name']=_0x10fd4d,this['providers']=new Map();}['addComponent'](_0x3c31f2){const _0x31250a=this['getProvider'](_0x3c31f2['name']);if(_0x31250a['isComponentSet']())throw new Error('Component\x20'+_0x3c31f2['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x31250a['setComponent'](_0x3c31f2);}['addOrOverwriteComponent'](_0x3a48d2){this['getProvider'](_0x3a48d2['name'])['isComponentSet']()&&this['providers']['delete'](_0x3a48d2['name']),this['addComponent'](_0x3a48d2);}['getProvider'](_0x1afa12){if(this['providers']['has'](_0x1afa12))return this['providers']['get'](_0x1afa12);const _0x426fc5=new Sc(_0x1afa12,this);return this['providers']['set'](_0x1afa12,_0x426fc5),_0x426fc5;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x2b46f7){_0x2b46f7[_0x2b46f7['DEBUG']=0x0]='DEBUG',_0x2b46f7[_0x2b46f7['VERBOSE']=0x1]='VERBOSE',_0x2b46f7[_0x2b46f7['INFO']=0x2]='INFO',_0x2b46f7[_0x2b46f7['WARN']=0x3]='WARN',_0x2b46f7[_0x2b46f7['ERROR']=0x4]='ERROR',_0x2b46f7[_0x2b46f7['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x53202b,_0x5cb6e7,..._0x3b8909)=>{if(_0x5cb6e7<_0x53202b['logLevel'])return;const _0x211c06=new Date()['toISOString'](),_0x175035=Pc[_0x5cb6e7];if(_0x175035)console[_0x175035]('['+_0x211c06+']\x20\x20'+_0x53202b['name']+':',..._0x3b8909);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x5cb6e7+')');};class xi{constructor(_0x1cea6a){this['name']=_0x1cea6a,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x58d912){if(!(_0x58d912 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x58d912+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x58d912;}['setLogLevel'](_0x55ed6e){this['_logLevel']=typeof _0x55ed6e=='string'?kc[_0x55ed6e]:_0x55ed6e;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x7e6e82){if(typeof _0x7e6e82!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x7e6e82;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x150649){this['_userLogHandler']=_0x150649;}['debug'](..._0x5278dc){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x5278dc),this['_logHandler'](this,T['DEBUG'],..._0x5278dc);}['log'](..._0xd62db6){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0xd62db6),this['_logHandler'](this,T['VERBOSE'],..._0xd62db6);}['info'](..._0xf9b7c6){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xf9b7c6),this['_logHandler'](this,T['INFO'],..._0xf9b7c6);}['warn'](..._0x27fbde){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x27fbde),this['_logHandler'](this,T['WARN'],..._0x27fbde);}['error'](..._0x4c594f){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4c594f),this['_logHandler'](this,T['ERROR'],..._0x4c594f);}}const Dc=(_0xfd575f,_0x3bd84e)=>_0x3bd84e['some'](_0x3ad7fc=>_0xfd575f instanceof _0x3ad7fc);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x59b6ff){const _0x3280d8=new Promise((_0x5f4cff,_0x305275)=>{const _0x786d6f=()=>{_0x59b6ff['removeEventListener']('success',_0x2f0fae),_0x59b6ff['removeEventListener']('error',_0x2e1930);},_0x2f0fae=()=>{_0x5f4cff(_e(_0x59b6ff['result'])),_0x786d6f();},_0x2e1930=()=>{_0x305275(_0x59b6ff['error']),_0x786d6f();};_0x59b6ff['addEventListener']('success',_0x2f0fae),_0x59b6ff['addEventListener']('error',_0x2e1930);});return _0x3280d8['then'](_0x2e9ed1=>{_0x2e9ed1 instanceof IDBCursor&&Kr['set'](_0x2e9ed1,_0x59b6ff);})['catch'](()=>{}),Fi['set'](_0x3280d8,_0x59b6ff),_0x3280d8;}function Fc(_0x5d2957){if(ui['has'](_0x5d2957))return;const _0xc3942e=new Promise((_0x1a2238,_0x4af842)=>{const _0x471b52=()=>{_0x5d2957['removeEventListener']('complete',_0x301a0f),_0x5d2957['removeEventListener']('error',_0x522123),_0x5d2957['removeEventListener']('abort',_0x522123);},_0x301a0f=()=>{_0x1a2238(),_0x471b52();},_0x522123=()=>{_0x4af842(_0x5d2957['error']||new DOMException('AbortError','AbortError')),_0x471b52();};_0x5d2957['addEventListener']('complete',_0x301a0f),_0x5d2957['addEventListener']('error',_0x522123),_0x5d2957['addEventListener']('abort',_0x522123);});ui['set'](_0x5d2957,_0xc3942e);}let di={'get'(_0x56968f,_0x4f1740,_0x42a65e){if(_0x56968f instanceof IDBTransaction){if(_0x4f1740==='done')return ui['get'](_0x56968f);if(_0x4f1740==='objectStoreNames')return _0x56968f['objectStoreNames']||Yr['get'](_0x56968f);if(_0x4f1740==='store')return _0x42a65e['objectStoreNames'][0x1]?void 0x0:_0x42a65e['objectStore'](_0x42a65e['objectStoreNames'][0x0]);}return _e(_0x56968f[_0x4f1740]);},'set'(_0x5d9957,_0x5c2ef1,_0x3ac645){return _0x5d9957[_0x5c2ef1]=_0x3ac645,!0x0;},'has'(_0xf928dd,_0x478917){return _0xf928dd instanceof IDBTransaction&&(_0x478917==='done'||_0x478917==='store')?!0x0:_0x478917 in _0xf928dd;}};function Uc(_0x4a9e00){di=_0x4a9e00(di);}function Wc(_0x35003a){return _0x35003a===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x966d45,..._0x2c8b17){const _0x3ce574=_0x35003a['call'](Xn(this),_0x966d45,..._0x2c8b17);return Yr['set'](_0x3ce574,_0x966d45['sort']?_0x966d45['sort']():[_0x966d45]),_e(_0x3ce574);}:Lc()['includes'](_0x35003a)?function(..._0xb9517e){return _0x35003a['apply'](Xn(this),_0xb9517e),_e(Kr['get'](this));}:function(..._0x4a65d5){return _e(_0x35003a['apply'](Xn(this),_0x4a65d5));};}function Bc(_0xe8ffee){return typeof _0xe8ffee=='function'?Wc(_0xe8ffee):(_0xe8ffee instanceof IDBTransaction&&Fc(_0xe8ffee),Dc(_0xe8ffee,Mc())?new Proxy(_0xe8ffee,di):_0xe8ffee);}function _e(_0x51b984){if(_0x51b984 instanceof IDBRequest)return xc(_0x51b984);if(Jn['has'](_0x51b984))return Jn['get'](_0x51b984);const _0x3606c9=Bc(_0x51b984);return _0x3606c9!==_0x51b984&&(Jn['set'](_0x51b984,_0x3606c9),Fi['set'](_0x3606c9,_0x51b984)),_0x3606c9;}const Xn=_0x34b5ef=>Fi['get'](_0x34b5ef);function Vc(_0x346de7,_0x35a7de,{blocked:_0x6ad571,upgrade:_0xeeb404,blocking:_0x3bbfbb,terminated:_0x2a6885}={}){const _0x336d8e=indexedDB['open'](_0x346de7,_0x35a7de),_0x2f29ea=_e(_0x336d8e);return _0xeeb404&&_0x336d8e['addEventListener']('upgradeneeded',_0x25d200=>{_0xeeb404(_e(_0x336d8e['result']),_0x25d200['oldVersion'],_0x25d200['newVersion'],_e(_0x336d8e['transaction']),_0x25d200);}),_0x6ad571&&_0x336d8e['addEventListener']('blocked',_0x3dd00c=>_0x6ad571(_0x3dd00c['oldVersion'],_0x3dd00c['newVersion'],_0x3dd00c)),_0x2f29ea['then'](_0x1b2c0e=>{_0x2a6885&&_0x1b2c0e['addEventListener']('close',()=>_0x2a6885()),_0x3bbfbb&&_0x1b2c0e['addEventListener']('versionchange',_0x2977f5=>_0x3bbfbb(_0x2977f5['oldVersion'],_0x2977f5['newVersion'],_0x2977f5));})['catch'](()=>{}),_0x2f29ea;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x13d11b,_0x58df94){if(!(_0x13d11b instanceof IDBDatabase&&!(_0x58df94 in _0x13d11b)&&typeof _0x58df94=='string'))return;if(Zn['get'](_0x58df94))return Zn['get'](_0x58df94);const _0x5b1179=_0x58df94['replace'](/FromIndex$/,''),_0x582f08=_0x58df94!==_0x5b1179,_0x5777a1=$c['includes'](_0x5b1179);if(!(_0x5b1179 in(_0x582f08?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5777a1||Hc['includes'](_0x5b1179)))return;const _0x6392bd=async function(_0x3dfae5,..._0x4f51b6){const _0x1ca11b=this['transaction'](_0x3dfae5,_0x5777a1?'readwrite':'readonly');let _0x22f185=_0x1ca11b['store'];return _0x582f08&&(_0x22f185=_0x22f185['index'](_0x4f51b6['shift']())),(await Promise['all']([_0x22f185[_0x5b1179](..._0x4f51b6),_0x5777a1&&_0x1ca11b['done']]))[0x0];};return Zn['set'](_0x58df94,_0x6392bd),_0x6392bd;}Uc(_0x2c1035=>({..._0x2c1035,'get':(_0xf68e7c,_0x4d0908,_0x24b905)=>Os(_0xf68e7c,_0x4d0908)||_0x2c1035['get'](_0xf68e7c,_0x4d0908,_0x24b905),'has':(_0x15486e,_0x3b3feb)=>!!Os(_0x15486e,_0x3b3feb)||_0x2c1035['has'](_0x15486e,_0x3b3feb)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x38b377){this['container']=_0x38b377;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x132e04=>{if(qc(_0x132e04)){const _0x450bd4=_0x132e04['getImmediate']();return _0x450bd4['library']+'/'+_0x450bd4['version'];}else return null;})['filter'](_0xdc9c89=>_0xdc9c89)['join']('\x20');}}function qc(_0x505002){const _0x181a9d=_0x505002['getComponent']();return(_0x181a9d==null?void 0x0:_0x181a9d['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x572763,_0x5cf1ac){try{_0x572763['container']['addComponent'](_0x5cf1ac);}catch(_0x5de345){re['debug']('Component\x20'+_0x5cf1ac['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x572763['name'],_0x5de345);}}function et(_0x105813){const _0x3d1e99=_0x105813['name'];if(gi['has'](_0x3d1e99))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x3d1e99+'.'),!0x1;gi['set'](_0x3d1e99,_0x105813);for(const _0x3e3b18 of Le['values']())Ms(_0x3e3b18,_0x105813);for(const _0x463c7c of _i['values']())Ms(_0x463c7c,_0x105813);return!0x0;}function Ui(_0x5c4904,_0x5b9cba){const _0x14566a=_0x5c4904['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x14566a&&_0x14566a['triggerHeartbeat'](),_0x5c4904['container']['getProvider'](_0x5b9cba);}function H(_0x118f95){return _0x118f95==null?!0x1:_0x118f95['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x181916,_0x409eac,_0x31003d){this['_isDeleted']=!0x1,this['_options']={..._0x181916},this['_config']={..._0x409eac},this['_name']=_0x409eac['name'],this['_automaticDataCollectionEnabled']=_0x409eac['automaticDataCollectionEnabled'],this['_container']=_0x31003d,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x5324d3){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x5324d3;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x33ff2e){this['_isDeleted']=_0x33ff2e;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x43929c,_0x4b1d94={}){let _0x3dcf92=_0x43929c;typeof _0x4b1d94!='object'&&(_0x4b1d94={'name':_0x4b1d94});const _0x3de692={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x4b1d94},_0x151ae3=_0x3de692['name'];if(typeof _0x151ae3!='string'||!_0x151ae3)throw ge['create']('bad-app-name',{'appName':String(_0x151ae3)});if(_0x3dcf92||(_0x3dcf92=$r()),!_0x3dcf92)throw ge['create']('no-options');const _0x348974=Le['get'](_0x151ae3);if(_0x348974){if(De(_0x3dcf92,_0x348974['options'])&&De(_0x3de692,_0x348974['config']))return _0x348974;throw ge['create']('duplicate-app',{'appName':_0x151ae3});}const _0x431fbd=new Ac(_0x151ae3);for(const _0x354b80 of gi['values']())_0x431fbd['addComponent'](_0x354b80);const _0x2fac5c=new Il(_0x3dcf92,_0x3de692,_0x431fbd);return Le['set'](_0x151ae3,_0x2fac5c),_0x2fac5c;}function Qr(_0x5bb336=pi){const _0x562d75=Le['get'](_0x5bb336);if(!_0x562d75&&_0x5bb336===pi&&$r())return wl();if(!_0x562d75)throw ge['create']('no-app',{'appName':_0x5bb336});return _0x562d75;}function l_(){return Array['from'](Le['values']());}async function h_(_0x3398bd){let _0x40aeb1=!0x1;const _0x17e143=_0x3398bd['name'];Le['has'](_0x17e143)?(_0x40aeb1=!0x0,Le['delete'](_0x17e143)):_i['has'](_0x17e143)&&_0x3398bd['decRefCount']()<=0x0&&(_i['delete'](_0x17e143),_0x40aeb1=!0x0),_0x40aeb1&&(await Promise['all'](_0x3398bd['container']['getProviders']()['map'](_0x3d9f50=>_0x3d9f50['delete']())),_0x3398bd['isDeleted']=!0x0);}function me(_0x526487,_0xae1291,_0x425b8c){let _0xe93668=vl[_0x526487]??_0x526487;_0x425b8c&&(_0xe93668+='-'+_0x425b8c);const _0x57d81c=_0xe93668['match'](/\s|\//),_0xf206be=_0xae1291['match'](/\s|\//);if(_0x57d81c||_0xf206be){const _0x5404e5=['Unable\x20to\x20register\x20library\x20\x22'+_0xe93668+'\x22\x20with\x20version\x20\x22'+_0xae1291+'\x22:'];_0x57d81c&&_0x5404e5['push']('library\x20name\x20\x22'+_0xe93668+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x57d81c&&_0xf206be&&_0x5404e5['push']('and'),_0xf206be&&_0x5404e5['push']('version\x20name\x20\x22'+_0xae1291+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x5404e5['join']('\x20'));return;}et(new Me(_0xe93668+'-version',()=>({'library':_0xe93668,'version':_0xae1291}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x4cc49c,_0x3566ac)=>{switch(_0x3566ac){case 0x0:try{_0x4cc49c['createObjectStore'](Rt);}catch(_0x40c372){console['warn'](_0x40c372);}}}})['catch'](_0x2159e9=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x2159e9['message']});})),ei;}async function Sl(_0x209cc5){try{const _0x44c289=(await Jr())['transaction'](Rt),_0x373a77=await _0x44c289['objectStore'](Rt)['get'](Xr(_0x209cc5));return await _0x44c289['done'],_0x373a77;}catch(_0x3b7d05){if(_0x3b7d05 instanceof Se)re['warn'](_0x3b7d05['message']);else{const _0x25b4b9=ge['create']('idb-get',{'originalErrorMessage':_0x3b7d05==null?void 0x0:_0x3b7d05['message']});re['warn'](_0x25b4b9['message']);}}}async function Ls(_0x25e9be,_0x4738ae){try{const _0x104f5d=(await Jr())['transaction'](Rt,'readwrite');await _0x104f5d['objectStore'](Rt)['put'](_0x4738ae,Xr(_0x25e9be)),await _0x104f5d['done'];}catch(_0x251c06){if(_0x251c06 instanceof Se)re['warn'](_0x251c06['message']);else{const _0x330944=ge['create']('idb-set',{'originalErrorMessage':_0x251c06==null?void 0x0:_0x251c06['message']});re['warn'](_0x330944['message']);}}}function Xr(_0x3bbfda){return _0x3bbfda['name']+'!'+_0x3bbfda['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x4e2831){this['container']=_0x4e2831,this['_heartbeatsCache']=null;const _0x5810ce=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x5810ce),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3a7336=>(this['_heartbeatsCache']=_0x3a7336,_0x3a7336));}async['triggerHeartbeat'](){var _0x471aca,_0x10dbf7;try{const _0x196aa0=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1824a8=xs();if(((_0x471aca=this['_heartbeatsCache'])==null?void 0x0:_0x471aca['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x10dbf7=this['_heartbeatsCache'])==null?void 0x0:_0x10dbf7['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1824a8||this['_heartbeatsCache']['heartbeats']['some'](_0x2266a2=>_0x2266a2['date']===_0x1824a8))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1824a8,'agent':_0x196aa0}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x1eb35e=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1eb35e,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2d7a63){re['warn'](_0x2d7a63);}}async['getHeartbeatsHeader'](){var _0x4a8753;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4a8753=this['_heartbeatsCache'])==null?void 0x0:_0x4a8753['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3f2f29=xs(),{heartbeatsToSend:_0x1a0480,unsentEntries:_0x4d9771}=kl(this['_heartbeatsCache']['heartbeats']),_0x54508d=an(JSON['stringify']({'version':0x2,'heartbeats':_0x1a0480}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3f2f29,_0x4d9771['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4d9771,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x54508d;}catch(_0x4351c4){return re['warn'](_0x4351c4),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x434332,_0x38ff90=bl){const _0x3ed91=[];let _0x5691e3=_0x434332['slice']();for(const _0x21d826 of _0x434332){const _0x22d179=_0x3ed91['find'](_0x3a09ad=>_0x3a09ad['agent']===_0x21d826['agent']);if(_0x22d179){if(_0x22d179['dates']['push'](_0x21d826['date']),Fs(_0x3ed91)>_0x38ff90){_0x22d179['dates']['pop']();break;}}else{if(_0x3ed91['push']({'agent':_0x21d826['agent'],'dates':[_0x21d826['date']]}),Fs(_0x3ed91)>_0x38ff90){_0x3ed91['pop']();break;}}_0x5691e3=_0x5691e3['slice'](0x1);}return{'heartbeatsToSend':_0x3ed91,'unsentEntries':_0x5691e3};}class Nl{constructor(_0x33dcb2){this['app']=_0x33dcb2,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x71083e=await Sl(this['app']);return _0x71083e!=null&&_0x71083e['heartbeats']?_0x71083e:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1bb0f3){if(await this['_canUseIndexedDBPromise']){const _0x29c74f=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x1bb0f3['lastSentHeartbeatDate']??_0x29c74f['lastSentHeartbeatDate'],'heartbeats':_0x1bb0f3['heartbeats']});}else return;}async['add'](_0x222627){if(await this['_canUseIndexedDBPromise']){const _0x2f0088=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x222627['lastSentHeartbeatDate']??_0x2f0088['lastSentHeartbeatDate'],'heartbeats':[..._0x2f0088['heartbeats'],..._0x222627['heartbeats']]});}else return;}}function Fs(_0x472271){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x472271}))['length'];}function Pl(_0x28b6e5){if(_0x28b6e5['length']===0x0)return-0x1;let _0x116366=0x0,_0x2086cd=_0x28b6e5[0x0]['date'];for(let _0x5c86e4=0x1;_0x5c86e4<_0x28b6e5['length'];_0x5c86e4++)_0x28b6e5[_0x5c86e4]['date']<_0x2086cd&&(_0x2086cd=_0x28b6e5[_0x5c86e4]['date'],_0x116366=_0x5c86e4);return _0x116366;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x32e3d1){et(new Me('platform-logger',_0x3fe9c2=>new Gc(_0x3fe9c2),'PRIVATE')),et(new Me('heartbeat',_0x5822ba=>new Al(_0x5822ba),'PRIVATE')),me(fi,Ds,_0x32e3d1),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x329b86){Zr=_0x329b86;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x1f2cbc){this['domStorage_']=_0x1f2cbc,this['prefix_']='firebase:';}['set'](_0x15a2fd,_0x588c5e){_0x588c5e==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x15a2fd)):this['domStorage_']['setItem'](this['prefixedName_'](_0x15a2fd),O(_0x588c5e));}['get'](_0x32589c){const _0xac42ac=this['domStorage_']['getItem'](this['prefixedName_'](_0x32589c));return _0xac42ac==null?null:bt(_0xac42ac);}['remove'](_0x36d259){this['domStorage_']['removeItem'](this['prefixedName_'](_0x36d259));}['prefixedName_'](_0x12f77d){return this['prefix_']+_0x12f77d;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x3c242f,_0x5642aa){_0x5642aa==null?delete this['cache_'][_0x3c242f]:this['cache_'][_0x3c242f]=_0x5642aa;}['get'](_0x443583){return Y(this['cache_'],_0x443583)?this['cache_'][_0x443583]:null;}['remove'](_0x5736a1){delete this['cache_'][_0x5736a1];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x194086){try{if(typeof window<'u'&&typeof window[_0x194086]<'u'){const _0x281383=window[_0x194086];return _0x281383['setItem']('firebase:sentinel','cache'),_0x281383['removeItem']('firebase:sentinel'),new xl(_0x281383);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x34a72a=0x1;return function(){return _0x34a72a++;};}()),no=function(_0xc2ac9c){const _0x5bdfce=Tc(_0xc2ac9c),_0x1c9e37=new Ec();_0x1c9e37['update'](_0x5bdfce);const _0x4d550c=_0x1c9e37['digest']();return Di['encodeByteArray'](_0x4d550c);},Bt=function(..._0x24fa65){let _0x4bdebb='';for(let _0x3c2b54=0x0;_0x3c2b54<_0x24fa65['length'];_0x3c2b54++){const _0x450016=_0x24fa65[_0x3c2b54];Array['isArray'](_0x450016)||_0x450016&&typeof _0x450016=='object'&&typeof _0x450016['length']=='number'?_0x4bdebb+=Bt['apply'](null,_0x450016):typeof _0x450016=='object'?_0x4bdebb+=O(_0x450016):_0x4bdebb+=_0x450016,_0x4bdebb+='\x20';}return _0x4bdebb;};let Et=null,Vs=!0x0;const Wl=function(_0x48d6d8,_0x56a0e7){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x55b766){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x568652=Bt['apply'](null,_0x55b766);Et(_0x568652);}},Vt=function(_0x2c046a){return function(..._0x293931){L(_0x2c046a,..._0x293931);};},mi=function(..._0x16584){const _0x225368='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x16584);Qe['error'](_0x225368);},oe=function(..._0x3ca511){const _0x16e4ca='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x3ca511);throw Qe['error'](_0x16e4ca),new Error(_0x16e4ca);},U=function(..._0x285eb4){const _0x385f48='FIREBASE\x20WARNING:\x20'+Bt(..._0x285eb4);Qe['warn'](_0x385f48);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x1fa89e){return typeof _0x1fa89e=='number'&&(_0x1fa89e!==_0x1fa89e||_0x1fa89e===Number['POSITIVE_INFINITY']||_0x1fa89e===Number['NEGATIVE_INFINITY']);},Vl=function(_0x578a71){if(document['readyState']==='complete')_0x578a71();else{let _0x59cd02=!0x1;const _0x79546a=function(){if(!document['body']){setTimeout(_0x79546a,Math['floor'](0xa));return;}_0x59cd02||(_0x59cd02=!0x0,_0x578a71());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x79546a,!0x1),window['addEventListener']('load',_0x79546a,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x79546a();}),window['attachEvent']('onload',_0x79546a));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x5909fc,_0x319212){if(_0x5909fc===_0x319212)return 0x0;if(_0x5909fc===xe||_0x319212===Ie)return-0x1;if(_0x319212===xe||_0x5909fc===Ie)return 0x1;{const _0x2e60bf=Hs(_0x5909fc),_0x53d460=Hs(_0x319212);return _0x2e60bf!==null?_0x53d460!==null?_0x2e60bf-_0x53d460===0x0?_0x5909fc['length']-_0x319212['length']:_0x2e60bf-_0x53d460:-0x1:_0x53d460!==null?0x1:_0x5909fc<_0x319212?-0x1:0x1;}},Hl=function(_0x361daf,_0x41366b){return _0x361daf===_0x41366b?0x0:_0x361daf<_0x41366b?-0x1:0x1;},pt=function(_0x1e9ca5,_0x132c84){if(_0x132c84&&_0x1e9ca5 in _0x132c84)return _0x132c84[_0x1e9ca5];throw new Error('Missing\x20required\x20key\x20('+_0x1e9ca5+')\x20in\x20object:\x20'+O(_0x132c84));},Bi=function(_0x12d329){if(typeof _0x12d329!='object'||_0x12d329===null)return O(_0x12d329);const _0x1ec425=[];for(const _0x5141ce in _0x12d329)_0x1ec425['push'](_0x5141ce);_0x1ec425['sort']();let _0x26edeb='{';for(let _0x237eb=0x0;_0x237eb<_0x1ec425['length'];_0x237eb++)_0x237eb!==0x0&&(_0x26edeb+=','),_0x26edeb+=O(_0x1ec425[_0x237eb]),_0x26edeb+=':',_0x26edeb+=Bi(_0x12d329[_0x1ec425[_0x237eb]]);return _0x26edeb+='}',_0x26edeb;},io=function(_0x197098,_0x1461b3){const _0x29c1e9=_0x197098['length'];if(_0x29c1e9<=_0x1461b3)return[_0x197098];const _0x35aaa8=[];for(let _0x34b562=0x0;_0x34b562<_0x29c1e9;_0x34b562+=_0x1461b3)_0x34b562+_0x1461b3>_0x29c1e9?_0x35aaa8['push'](_0x197098['substring'](_0x34b562,_0x29c1e9)):_0x35aaa8['push'](_0x197098['substring'](_0x34b562,_0x34b562+_0x1461b3));return _0x35aaa8;};function x(_0x4049bc,_0x535017){for(const _0x2a80d8 in _0x4049bc)_0x4049bc['hasOwnProperty'](_0x2a80d8)&&_0x535017(_0x2a80d8,_0x4049bc[_0x2a80d8]);}const so=function(_0x25e0eb){f(!Wi(_0x25e0eb),'Invalid\x20JSON\x20number');const _0x593399=0xb,_0x49ceb6=0x34,_0x24f38c=(0x1<<_0x593399-0x1)-0x1;let _0xeaa0f6,_0x29bcac,_0x9969a5,_0x32ae0b,_0x156b3a;_0x25e0eb===0x0?(_0x29bcac=0x0,_0x9969a5=0x0,_0xeaa0f6=0x1/_0x25e0eb===-0x1/0x0?0x1:0x0):(_0xeaa0f6=_0x25e0eb<0x0,_0x25e0eb=Math['abs'](_0x25e0eb),_0x25e0eb>=Math['pow'](0x2,0x1-_0x24f38c)?(_0x32ae0b=Math['min'](Math['floor'](Math['log'](_0x25e0eb)/Math['LN2']),_0x24f38c),_0x29bcac=_0x32ae0b+_0x24f38c,_0x9969a5=Math['round'](_0x25e0eb*Math['pow'](0x2,_0x49ceb6-_0x32ae0b)-Math['pow'](0x2,_0x49ceb6))):(_0x29bcac=0x0,_0x9969a5=Math['round'](_0x25e0eb/Math['pow'](0x2,0x1-_0x24f38c-_0x49ceb6))));const _0x5283c4=[];for(_0x156b3a=_0x49ceb6;_0x156b3a;_0x156b3a-=0x1)_0x5283c4['push'](_0x9969a5%0x2?0x1:0x0),_0x9969a5=Math['floor'](_0x9969a5/0x2);for(_0x156b3a=_0x593399;_0x156b3a;_0x156b3a-=0x1)_0x5283c4['push'](_0x29bcac%0x2?0x1:0x0),_0x29bcac=Math['floor'](_0x29bcac/0x2);_0x5283c4['push'](_0xeaa0f6?0x1:0x0),_0x5283c4['reverse']();const _0x21ed5c=_0x5283c4['join']('');let _0x3f77f7='';for(_0x156b3a=0x0;_0x156b3a<0x40;_0x156b3a+=0x8){let _0x36722f=parseInt(_0x21ed5c['substr'](_0x156b3a,0x8),0x2)['toString'](0x10);_0x36722f['length']===0x1&&(_0x36722f='0'+_0x36722f),_0x3f77f7=_0x3f77f7+_0x36722f;}return _0x3f77f7['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x49dffa,_0x2084a8){let _0x5dada1='Unknown\x20Error';_0x49dffa==='too_big'?_0x5dada1='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x49dffa==='permission_denied'?_0x5dada1='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x49dffa==='unavailable'&&(_0x5dada1='The\x20service\x20is\x20unavailable');const _0x4a74da=new Error(_0x49dffa+'\x20at\x20'+_0x2084a8['_path']['toString']()+':\x20'+_0x5dada1);return _0x4a74da['code']=_0x49dffa['toUpperCase'](),_0x4a74da;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0xf34953){if(zl['test'](_0xf34953)){const _0x428fe2=Number(_0xf34953);if(_0x428fe2>=jl&&_0x428fe2<=Kl)return _0x428fe2;}return null;},lt=function(_0x12994b){try{_0x12994b();}catch(_0x240d3e){setTimeout(()=>{const _0x1c7aed=_0x240d3e['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1c7aed),_0x240d3e;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x5a9cbd,_0x1627e6){const _0x225f1d=setTimeout(_0x5a9cbd,_0x1627e6);return typeof _0x225f1d=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x225f1d):typeof _0x225f1d=='object'&&_0x225f1d['unref']&&_0x225f1d['unref'](),_0x225f1d;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x204af3,_0x1d6e01){this['appCheckProvider']=_0x1d6e01,this['appName']=_0x204af3['name'],H(_0x204af3)&&_0x204af3['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x204af3['settings']['appCheckToken']),this['appCheck']=_0x1d6e01==null?void 0x0:_0x1d6e01['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1d6e01==null||_0x1d6e01['get']()['then'](_0x3774ee=>this['appCheck']=_0x3774ee);}['getToken'](_0x23a108){if(this['serverAppAppCheckToken']){if(_0x23a108)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x23a108):new Promise((_0x21b36e,_0x164cc5)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x23a108)['then'](_0x21b36e,_0x164cc5):_0x21b36e(null);},0x0);});}['addTokenChangeListener'](_0x10f367){var _0x2948a2;(_0x2948a2=this['appCheckProvider'])==null||_0x2948a2['get']()['then'](_0x2393d3=>_0x2393d3['addTokenListener'](_0x10f367));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x438c2a,_0x3e648e,_0xbcd723){this['appName_']=_0x438c2a,this['firebaseOptions_']=_0x3e648e,this['authProvider_']=_0xbcd723,this['auth_']=null,this['auth_']=_0xbcd723['getImmediate']({'optional':!0x0}),this['auth_']||_0xbcd723['onInit'](_0x161f23=>this['auth_']=_0x161f23);}['getToken'](_0x4c3e60){return this['auth_']?this['auth_']['getToken'](_0x4c3e60)['catch'](_0x4a1187=>_0x4a1187&&_0x4a1187['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4a1187)):new Promise((_0x40dc86,_0x2167a4)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4c3e60)['then'](_0x40dc86,_0x2167a4):_0x40dc86(null);},0x0);});}['addTokenChangeListener'](_0x2cd87e){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2cd87e):this['authProvider_']['get']()['then'](_0x459577=>_0x459577['addAuthTokenListener'](_0x2cd87e));}['removeTokenChangeListener'](_0x21c250){this['authProvider_']['get']()['then'](_0x18992c=>_0x18992c['removeAuthTokenListener'](_0x21c250));}['notifyForInvalidToken'](){let _0x2a3ef7='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2a3ef7+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2a3ef7+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2a3ef7+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2a3ef7);}}class tn{constructor(_0x3a5bc3){this['accessToken']=_0x3a5bc3;}['getToken'](_0x199276){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2b1fbb){_0x2b1fbb(this['accessToken']);}['removeTokenChangeListener'](_0xb3970c){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x41f6a8,_0x28384c,_0x22cf94,_0x52186e,_0x2bee81=!0x1,_0x2e30ab='',_0x57b10d=!0x1,_0x262073=!0x1,_0x35784c=null){this['secure']=_0x28384c,this['namespace']=_0x22cf94,this['webSocketOnly']=_0x52186e,this['nodeAdmin']=_0x2bee81,this['persistenceKey']=_0x2e30ab,this['includeNamespaceInQueryParams']=_0x57b10d,this['isUsingEmulator']=_0x262073,this['emulatorOptions']=_0x35784c,this['_host']=_0x41f6a8['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x41f6a8)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x404d71){_0x404d71!==this['internalHost']&&(this['internalHost']=_0x404d71,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x2f62f0=this['toURLString']();return this['persistenceKey']&&(_0x2f62f0+='<'+this['persistenceKey']+'>'),_0x2f62f0;}['toURLString'](){const _0x44948c=this['secure']?'https://':'http://',_0x101737=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x44948c+this['host']+'/'+_0x101737;}}function Xl(_0xadaafe){return _0xadaafe['host']!==_0xadaafe['internalHost']||_0xadaafe['isCustomHost']()||_0xadaafe['includeNamespaceInQueryParams'];}function go(_0x4034d5,_0xfffe54,_0x177089){f(typeof _0xfffe54=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x177089=='object','typeof\x20params\x20must\x20==\x20object');let _0x2ea5e6;if(_0xfffe54===fo)_0x2ea5e6=(_0x4034d5['secure']?'wss://':'ws://')+_0x4034d5['internalHost']+'/.ws?';else{if(_0xfffe54===po)_0x2ea5e6=(_0x4034d5['secure']?'https://':'http://')+_0x4034d5['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0xfffe54);}Xl(_0x4034d5)&&(_0x177089['ns']=_0x4034d5['namespace']);const _0x487ea0=[];return x(_0x177089,(_0x23d6e6,_0x5899f1)=>{_0x487ea0['push'](_0x23d6e6+'='+_0x5899f1);}),_0x2ea5e6+_0x487ea0['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x5a744b,_0x2b9f11=0x1){Y(this['counters_'],_0x5a744b)||(this['counters_'][_0x5a744b]=0x0),this['counters_'][_0x5a744b]+=_0x2b9f11;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x1d68cf){const _0x257c00=_0x1d68cf['toString']();return ti[_0x257c00]||(ti[_0x257c00]=new Zl()),ti[_0x257c00];}function eh(_0x1ee3d4,_0x34a3b7){const _0x563636=_0x1ee3d4['toString']();return ni[_0x563636]||(ni[_0x563636]=_0x34a3b7()),ni[_0x563636];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x5e3649){this['onMessage_']=_0x5e3649,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x8259a6,_0x691f61){this['closeAfterResponse']=_0x8259a6,this['onClose']=_0x691f61,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x538991,_0x44b3a9){for(this['pendingResponses'][_0x538991]=_0x44b3a9;this['pendingResponses'][this['currentResponseNum']];){const _0x5b59c7=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x17c97c=0x0;_0x17c97c<_0x5b59c7['length'];++_0x17c97c)_0x5b59c7[_0x17c97c]&&lt(()=>{this['onMessage_'](_0x5b59c7[_0x17c97c]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x1de4c1,_0x34c9c2,_0x33d4af,_0xfe17cd,_0x2544ab,_0x581c84,_0x284a5e){this['connId']=_0x1de4c1,this['repoInfo']=_0x34c9c2,this['applicationId']=_0x33d4af,this['appCheckToken']=_0xfe17cd,this['authToken']=_0x2544ab,this['transportSessionId']=_0x581c84,this['lastSessionId']=_0x284a5e,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x1de4c1),this['stats_']=Hi(_0x34c9c2),this['urlFn']=_0x62461f=>(this['appCheckToken']&&(_0x62461f[yi]=this['appCheckToken']),go(_0x34c9c2,po,_0x62461f));}['open'](_0xbaf7fd,_0x555121){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x555121,this['myPacketOrderer']=new th(_0xbaf7fd),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x5a699f)=>{const [_0x128b67,_0x40e356,_0xe99c77,_0x2fdd4e,_0xa8b440]=_0x5a699f;if(this['incrementIncomingBytes_'](_0x5a699f),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x128b67===$s)this['id']=_0x40e356,this['password']=_0xe99c77;else{if(_0x128b67===nh)_0x40e356?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x40e356,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x128b67);}}},(..._0x178e15)=>{const [_0x31c90d,_0x2633a9]=_0x178e15;this['incrementIncomingBytes_'](_0x178e15),this['myPacketOrderer']['handleResponse'](_0x31c90d,_0x2633a9);},()=>{this['onClosed_']();},this['urlFn']);const _0x374054={};_0x374054[$s]='t',_0x374054[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x374054[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x374054[ro]=Vi,this['transportSessionId']&&(_0x374054[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x374054[ho]=this['lastSessionId']),this['applicationId']&&(_0x374054[uo]=this['applicationId']),this['appCheckToken']&&(_0x374054[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x374054[ao]=co);const _0x3075f2=this['urlFn'](_0x374054);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x3075f2),this['scriptTagHolder']['addTag'](_0x3075f2,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1c0ccc){const _0xe38420=O(_0x1c0ccc);this['bytesSent']+=_0xe38420['length'],this['stats_']['incrementCounter']('bytes_sent',_0xe38420['length']);const _0x1c352f=Br(_0xe38420),_0x3b05dd=io(_0x1c352f,hh);for(let _0x29310b=0x0;_0x29310b<_0x3b05dd['length'];_0x29310b++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3b05dd['length'],_0x3b05dd[_0x29310b]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x294c2c,_0x4f6856){this['myDisconnFrame']=document['createElement']('iframe');const _0x3e2579={};_0x3e2579[lh]='t',_0x3e2579[mo]=_0x294c2c,_0x3e2579[yo]=_0x4f6856,this['myDisconnFrame']['src']=this['urlFn'](_0x3e2579),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x39a8dc){const _0x483f5f=O(_0x39a8dc)['length'];this['bytesReceived']+=_0x483f5f,this['stats_']['incrementCounter']('bytes_received',_0x483f5f);}}class $i{constructor(_0xbc5dbb,_0xbc766b,_0x3047cb,_0x39c716){this['onDisconnect']=_0x3047cb,this['urlFn']=_0x39c716,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0xbc5dbb,window[sh+this['uniqueCallbackIdentifier']]=_0xbc766b,this['myIFrame']=$i['createIFrame_']();let _0x255e77='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x255e77='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4c7b69='<html><body>'+_0x255e77+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4c7b69),this['myIFrame']['doc']['close']();}catch(_0x2fcef7){L('frame\x20writing\x20exception'),_0x2fcef7['stack']&&L(_0x2fcef7['stack']),L(_0x2fcef7);}}}static['createIFrame_'](){const _0x2ea2f4=document['createElement']('iframe');if(_0x2ea2f4['style']['display']='none',document['body']){document['body']['appendChild'](_0x2ea2f4);try{_0x2ea2f4['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3c01bb=document['domain'];_0x2ea2f4['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3c01bb+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2ea2f4['contentDocument']?_0x2ea2f4['doc']=_0x2ea2f4['contentDocument']:_0x2ea2f4['contentWindow']?_0x2ea2f4['doc']=_0x2ea2f4['contentWindow']['document']:_0x2ea2f4['document']&&(_0x2ea2f4['doc']=_0x2ea2f4['document']),_0x2ea2f4;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x135062=this['onDisconnect'];_0x135062&&(this['onDisconnect']=null,_0x135062());}['startLongPoll'](_0x2e3622,_0x201e9f){for(this['myID']=_0x2e3622,this['myPW']=_0x201e9f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x4f9123={};_0x4f9123[mo]=this['myID'],_0x4f9123[yo]=this['myPW'],_0x4f9123[vo]=this['currentSerial'];let _0x483ecd=this['urlFn'](_0x4f9123),_0x52c060='',_0x4304cf=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x52c060['length']<=Eo;){const _0x50924c=this['pendingSegs']['shift']();_0x52c060=_0x52c060+'&'+oh+_0x4304cf+'='+_0x50924c['seg']+'&'+ah+_0x4304cf+'='+_0x50924c['ts']+'&'+ch+_0x4304cf+'='+_0x50924c['d'],_0x4304cf++;}return _0x483ecd=_0x483ecd+_0x52c060,this['addLongPollTag_'](_0x483ecd,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x9747f3,_0x3911b8,_0x52e080){this['pendingSegs']['push']({'seg':_0x9747f3,'ts':_0x3911b8,'d':_0x52e080}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2d8ed1,_0x55059b){this['outstandingRequests']['add'](_0x55059b);const _0x16b31f=()=>{this['outstandingRequests']['delete'](_0x55059b),this['newRequest_']();},_0x547a20=setTimeout(_0x16b31f,Math['floor'](uh)),_0x51bae8=()=>{clearTimeout(_0x547a20),_0x16b31f();};this['addTag'](_0x2d8ed1,_0x51bae8);}['addTag'](_0x52612d,_0x4c5875){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x586544=this['myIFrame']['doc']['createElement']('script');_0x586544['type']='text/javascript',_0x586544['async']=!0x0,_0x586544['src']=_0x52612d,_0x586544['onload']=_0x586544['onreadystatechange']=function(){const _0x536ce6=_0x586544['readyState'];(!_0x536ce6||_0x536ce6==='loaded'||_0x536ce6==='complete')&&(_0x586544['onload']=_0x586544['onreadystatechange']=null,_0x586544['parentNode']&&_0x586544['parentNode']['removeChild'](_0x586544),_0x4c5875());},_0x586544['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x52612d),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x586544);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x32ccd,_0x2212a4,_0x1416af,_0x3772a3,_0x26106e,_0x59dabb,_0x4652fa){this['connId']=_0x32ccd,this['applicationId']=_0x1416af,this['appCheckToken']=_0x3772a3,this['authToken']=_0x26106e,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x2212a4),this['connURL']=G['connectionURL_'](_0x2212a4,_0x59dabb,_0x4652fa,_0x3772a3,_0x1416af),this['nodeAdmin']=_0x2212a4['nodeAdmin'];}static['connectionURL_'](_0x5b3b75,_0x400efe,_0x252bd9,_0x493502,_0x28b756){const _0x591f36={};return _0x591f36[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x591f36[ao]=co),_0x400efe&&(_0x591f36[oo]=_0x400efe),_0x252bd9&&(_0x591f36[ho]=_0x252bd9),_0x493502&&(_0x591f36[yi]=_0x493502),_0x28b756&&(_0x591f36[uo]=_0x28b756),go(_0x5b3b75,fo,_0x591f36);}['open'](_0xd37286,_0x62daca){this['onDisconnect']=_0x62daca,this['onMessage']=_0xd37286,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x5adcc7;dc(),this['mySock']=new hn(this['connURL'],[],_0x5adcc7);}catch(_0x5a1719){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1e5b02=_0x5a1719['message']||_0x5a1719['data'];_0x1e5b02&&this['log_'](_0x1e5b02),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xe5f3ec=>{this['handleIncomingFrame'](_0xe5f3ec);},this['mySock']['onerror']=_0x434e5f=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x395b7d=_0x434e5f['message']||_0x434e5f['data'];_0x395b7d&&this['log_'](_0x395b7d),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x10e122=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x83a0fd=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x594f92=navigator['userAgent']['match'](_0x83a0fd);_0x594f92&&_0x594f92['length']>0x1&&parseFloat(_0x594f92[0x1])<4.4&&(_0x10e122=!0x0);}return!_0x10e122&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4dbd2b){if(this['frames']['push'](_0x4dbd2b),this['frames']['length']===this['totalFrames']){const _0x582d70=this['frames']['join']('');this['frames']=null;const _0x3c54b0=bt(_0x582d70);this['onMessage'](_0x3c54b0);}}['handleNewFrameCount_'](_0x18767d){this['totalFrames']=_0x18767d,this['frames']=[];}['extractFrameCount_'](_0x30ce79){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x30ce79['length']<=0x6){const _0xff4cdd=Number(_0x30ce79);if(!isNaN(_0xff4cdd))return this['handleNewFrameCount_'](_0xff4cdd),null;}return this['handleNewFrameCount_'](0x1),_0x30ce79;}['handleIncomingFrame'](_0x28c07c){if(this['mySock']===null)return;const _0x5a11b3=_0x28c07c['data'];if(this['bytesReceived']+=_0x5a11b3['length'],this['stats_']['incrementCounter']('bytes_received',_0x5a11b3['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x5a11b3);else{const _0x5c87c7=this['extractFrameCount_'](_0x5a11b3);_0x5c87c7!==null&&this['appendFrame_'](_0x5c87c7);}}['send'](_0x51126e){this['resetKeepAlive']();const _0x1348f7=O(_0x51126e);this['bytesSent']+=_0x1348f7['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1348f7['length']);const _0x4fa183=io(_0x1348f7,fh);_0x4fa183['length']>0x1&&this['sendString_'](String(_0x4fa183['length']));for(let _0x23b6b5=0x0;_0x23b6b5<_0x4fa183['length'];_0x23b6b5++)this['sendString_'](_0x4fa183[_0x23b6b5]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x1fcea1){try{this['mySock']['send'](_0x1fcea1);}catch(_0x3de1d2){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3de1d2['message']||_0x3de1d2['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2fa7a2){this['initTransports_'](_0x2fa7a2);}['initTransports_'](_0x1903bc){const _0x49bb46=G&&G['isAvailable']();let _0x48b948=_0x49bb46&&!G['previouslyFailed']();if(_0x1903bc['webSocketOnly']&&(_0x49bb46||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x48b948=!0x0),_0x48b948)this['transports_']=[G];else{const _0x41ee96=this['transports_']=[];for(const _0x1701e8 of At['ALL_TRANSPORTS'])_0x1701e8&&_0x1701e8['isAvailable']()&&_0x41ee96['push'](_0x1701e8);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x24ffa3,_0x35c6f4,_0x3cda63,_0x1655bb,_0x157a60,_0x18fe6c,_0x4a8d91,_0x16a2fb,_0x3fffc0,_0x5d8416){this['id']=_0x24ffa3,this['repoInfo_']=_0x35c6f4,this['applicationId_']=_0x3cda63,this['appCheckToken_']=_0x1655bb,this['authToken_']=_0x157a60,this['onMessage_']=_0x18fe6c,this['onReady_']=_0x4a8d91,this['onDisconnect_']=_0x16a2fb,this['onKill_']=_0x3fffc0,this['lastSessionId']=_0x5d8416,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x35c6f4),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1feb37=this['transportManager_']['initialTransport']();this['conn_']=new _0x1feb37(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1feb37['responsesRequiredToBeHealthy']||0x0;const _0x38630b=this['connReceiver_'](this['conn_']),_0x24ff1a=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x38630b,_0x24ff1a);},Math['floor'](0x0));const _0x2bc4b3=_0x1feb37['healthyTimeout']||0x0;_0x2bc4b3>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x2bc4b3)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x43d335){return _0x495123=>{_0x43d335===this['conn_']?this['onConnectionLost_'](_0x495123):_0x43d335===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x269047){return _0x3beff4=>{this['state_']!==0x2&&(_0x269047===this['rx_']?this['onPrimaryMessageReceived_'](_0x3beff4):_0x269047===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3beff4):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x275894){const _0x197834={'t':'d','d':_0x275894};this['sendData_'](_0x197834);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x7d920d){if(ii in _0x7d920d){const _0x521cb0=_0x7d920d[ii];_0x521cb0===js?this['upgradeIfSecondaryHealthy_']():_0x521cb0===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x521cb0===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x50d427){const _0x57e1da=pt('t',_0x50d427),_0x43eb10=pt('d',_0x50d427);if(_0x57e1da==='c')this['onSecondaryControl_'](_0x43eb10);else{if(_0x57e1da==='d')this['pendingDataMessages']['push'](_0x43eb10);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x57e1da);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3a9cc8){const _0x5c2529=pt('t',_0x3a9cc8),_0x23d9e8=pt('d',_0x3a9cc8);_0x5c2529==='c'?this['onControl_'](_0x23d9e8):_0x5c2529==='d'&&this['onDataMessage_'](_0x23d9e8);}['onDataMessage_'](_0x2598bc){this['onPrimaryResponse_'](),this['onMessage_'](_0x2598bc);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x326f13){const _0x125e80=pt(ii,_0x326f13);if(Gs in _0x326f13){const _0x2be38c=_0x326f13[Gs];if(_0x125e80===Ih){const _0x1c4b79={..._0x2be38c};this['repoInfo_']['isUsingEmulator']&&(_0x1c4b79['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1c4b79);}else{if(_0x125e80===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x741557=0x0;_0x741557<this['pendingDataMessages']['length'];++_0x741557)this['onDataMessage_'](this['pendingDataMessages'][_0x741557]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x125e80===vh?this['onConnectionShutdown_'](_0x2be38c):_0x125e80===qs?this['onReset_'](_0x2be38c):_0x125e80===Eh?mi('Server\x20Error:\x20'+_0x2be38c):_0x125e80===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x125e80);}}}['onHandshake_'](_0x3c4024){const _0xc8e34=_0x3c4024['ts'],_0xac1ef1=_0x3c4024['v'],_0x5cbf9a=_0x3c4024['h'];this['sessionId']=_0x3c4024['s'],this['repoInfo_']['host']=_0x5cbf9a,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xc8e34),Vi!==_0xac1ef1&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x49172b=this['transportManager_']['upgradeTransport']();_0x49172b&&this['startUpgrade_'](_0x49172b);}['startUpgrade_'](_0x55e53f){this['secondaryConn_']=new _0x55e53f(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x55e53f['responsesRequiredToBeHealthy']||0x0;const _0x39a45a=this['connReceiver_'](this['secondaryConn_']),_0x4d9e94=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x39a45a,_0x4d9e94),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x343f7d){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x343f7d),this['repoInfo_']['host']=_0x343f7d,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4f0293,_0x3a25a4){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4f0293,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3a25a4,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x478344=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x478344||this['rx_']===_0x478344)&&this['close']();}['onConnectionLost_'](_0x316b4a){this['conn_']=null,!_0x316b4a&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x406b2c){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x406b2c),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3ad49f){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3ad49f);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x2195ca,_0x11be75,_0x12bc8d,_0x2b2a14){}['merge'](_0x322c6e,_0xb9ee3b,_0x58daa3,_0x346f43){}['refreshAuthToken'](_0x227f15){}['refreshAppCheckToken'](_0x4fdaed){}['onDisconnectPut'](_0x32c754,_0x283482,_0x4efc6c){}['onDisconnectMerge'](_0x276e7d,_0x39f902,_0x4bc9dd){}['onDisconnectCancel'](_0x550f9a,_0x27776c){}['reportStats'](_0x7a0c63){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x9424db){this['allowedEvents_']=_0x9424db,this['listeners_']={},f(Array['isArray'](_0x9424db)&&_0x9424db['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x557f5c,..._0x37488c){if(Array['isArray'](this['listeners_'][_0x557f5c])){const _0x48fb2b=[...this['listeners_'][_0x557f5c]];for(let _0x175d17=0x0;_0x175d17<_0x48fb2b['length'];_0x175d17++)_0x48fb2b[_0x175d17]['callback']['apply'](_0x48fb2b[_0x175d17]['context'],_0x37488c);}}['on'](_0x213fb1,_0x20c1d4,_0x33e3e9){this['validateEventType_'](_0x213fb1),this['listeners_'][_0x213fb1]=this['listeners_'][_0x213fb1]||[],this['listeners_'][_0x213fb1]['push']({'callback':_0x20c1d4,'context':_0x33e3e9});const _0x1a1a7b=this['getInitialEvent'](_0x213fb1);_0x1a1a7b&&_0x20c1d4['apply'](_0x33e3e9,_0x1a1a7b);}['off'](_0x3c6fa8,_0x55e54a,_0x3c6b53){this['validateEventType_'](_0x3c6fa8);const _0x386f14=this['listeners_'][_0x3c6fa8]||[];for(let _0x52d68d=0x0;_0x52d68d<_0x386f14['length'];_0x52d68d++)if(_0x386f14[_0x52d68d]['callback']===_0x55e54a&&(!_0x3c6b53||_0x3c6b53===_0x386f14[_0x52d68d]['context'])){_0x386f14['splice'](_0x52d68d,0x1);return;}}['validateEventType_'](_0x4d1b18){f(this['allowedEvents_']['find'](_0x56ba50=>_0x56ba50===_0x4d1b18),'Unknown\x20event:\x20'+_0x4d1b18);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x23e0eb){return f(_0x23e0eb==='online','Unknown\x20event\x20type:\x20'+_0x23e0eb),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x5b390b,_0x3a442b){if(_0x3a442b===void 0x0){this['pieces_']=_0x5b390b['split']('/');let _0x331b37=0x0;for(let _0x4b6619=0x0;_0x4b6619<this['pieces_']['length'];_0x4b6619++)this['pieces_'][_0x4b6619]['length']>0x0&&(this['pieces_'][_0x331b37]=this['pieces_'][_0x4b6619],_0x331b37++);this['pieces_']['length']=_0x331b37,this['pieceNum_']=0x0;}else this['pieces_']=_0x5b390b,this['pieceNum_']=_0x3a442b;}['toString'](){let _0x1964a3='';for(let _0x261e8c=this['pieceNum_'];_0x261e8c<this['pieces_']['length'];_0x261e8c++)this['pieces_'][_0x261e8c]!==''&&(_0x1964a3+='/'+this['pieces_'][_0x261e8c]);return _0x1964a3||'/';}}function w(){return new C('');}function y(_0x87a7dc){return _0x87a7dc['pieceNum_']>=_0x87a7dc['pieces_']['length']?null:_0x87a7dc['pieces_'][_0x87a7dc['pieceNum_']];}function we(_0xcf54ad){return _0xcf54ad['pieces_']['length']-_0xcf54ad['pieceNum_'];}function b(_0x495634){let _0x24fe8b=_0x495634['pieceNum_'];return _0x24fe8b<_0x495634['pieces_']['length']&&_0x24fe8b++,new C(_0x495634['pieces_'],_0x24fe8b);}function Gi(_0x15b872){return _0x15b872['pieceNum_']<_0x15b872['pieces_']['length']?_0x15b872['pieces_'][_0x15b872['pieces_']['length']-0x1]:null;}function Ch(_0x2d9d68){let _0x402beb='';for(let _0x260023=_0x2d9d68['pieceNum_'];_0x260023<_0x2d9d68['pieces_']['length'];_0x260023++)_0x2d9d68['pieces_'][_0x260023]!==''&&(_0x402beb+='/'+encodeURIComponent(String(_0x2d9d68['pieces_'][_0x260023])));return _0x402beb||'/';}function kt(_0x523bd2,_0x17e45f=0x0){return _0x523bd2['pieces_']['slice'](_0x523bd2['pieceNum_']+_0x17e45f);}function To(_0x2c1da2){if(_0x2c1da2['pieceNum_']>=_0x2c1da2['pieces_']['length'])return null;const _0x3782f1=[];for(let _0x59c0f8=_0x2c1da2['pieceNum_'];_0x59c0f8<_0x2c1da2['pieces_']['length']-0x1;_0x59c0f8++)_0x3782f1['push'](_0x2c1da2['pieces_'][_0x59c0f8]);return new C(_0x3782f1,0x0);}function A(_0x2c7e1e,_0x2f6d92){const _0x17fad0=[];for(let _0x40eaae=_0x2c7e1e['pieceNum_'];_0x40eaae<_0x2c7e1e['pieces_']['length'];_0x40eaae++)_0x17fad0['push'](_0x2c7e1e['pieces_'][_0x40eaae]);if(_0x2f6d92 instanceof C){for(let _0x27d39e=_0x2f6d92['pieceNum_'];_0x27d39e<_0x2f6d92['pieces_']['length'];_0x27d39e++)_0x17fad0['push'](_0x2f6d92['pieces_'][_0x27d39e]);}else{const _0x5372f5=_0x2f6d92['split']('/');for(let _0x2129d7=0x0;_0x2129d7<_0x5372f5['length'];_0x2129d7++)_0x5372f5[_0x2129d7]['length']>0x0&&_0x17fad0['push'](_0x5372f5[_0x2129d7]);}return new C(_0x17fad0,0x0);}function v(_0x29304b){return _0x29304b['pieceNum_']>=_0x29304b['pieces_']['length'];}function F(_0x38d70e,_0xb7e603){const _0xf07f1b=y(_0x38d70e),_0x40e7e4=y(_0xb7e603);if(_0xf07f1b===null)return _0xb7e603;if(_0xf07f1b===_0x40e7e4)return F(b(_0x38d70e),b(_0xb7e603));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xb7e603+')\x20is\x20not\x20within\x20outerPath\x20('+_0x38d70e+')');}function Th(_0x3a77d7,_0x432d54){const _0x3b0564=kt(_0x3a77d7,0x0),_0x3cd14a=kt(_0x432d54,0x0);for(let _0x12bc39=0x0;_0x12bc39<_0x3b0564['length']&&_0x12bc39<_0x3cd14a['length'];_0x12bc39++){const _0x2901c6=He(_0x3b0564[_0x12bc39],_0x3cd14a[_0x12bc39]);if(_0x2901c6!==0x0)return _0x2901c6;}return _0x3b0564['length']===_0x3cd14a['length']?0x0:_0x3b0564['length']<_0x3cd14a['length']?-0x1:0x1;}function qi(_0x42a2a4,_0x4e5d30){if(we(_0x42a2a4)!==we(_0x4e5d30))return!0x1;for(let _0x524c11=_0x42a2a4['pieceNum_'],_0x1bb18d=_0x4e5d30['pieceNum_'];_0x524c11<=_0x42a2a4['pieces_']['length'];_0x524c11++,_0x1bb18d++)if(_0x42a2a4['pieces_'][_0x524c11]!==_0x4e5d30['pieces_'][_0x1bb18d])return!0x1;return!0x0;}function $(_0x10e195,_0x87005d){let _0x4295e0=_0x10e195['pieceNum_'],_0x21dc97=_0x87005d['pieceNum_'];if(we(_0x10e195)>we(_0x87005d))return!0x1;for(;_0x4295e0<_0x10e195['pieces_']['length'];){if(_0x10e195['pieces_'][_0x4295e0]!==_0x87005d['pieces_'][_0x21dc97])return!0x1;++_0x4295e0,++_0x21dc97;}return!0x0;}class Sh{constructor(_0x4cc794,_0x5cbff9){this['errorPrefix_']=_0x5cbff9,this['parts_']=kt(_0x4cc794,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x30467e=0x0;_0x30467e<this['parts_']['length'];_0x30467e++)this['byteLength_']+=Pn(this['parts_'][_0x30467e]);So(this);}}function bh(_0x19ee19,_0x43e1f8){_0x19ee19['parts_']['length']>0x0&&(_0x19ee19['byteLength_']+=0x1),_0x19ee19['parts_']['push'](_0x43e1f8),_0x19ee19['byteLength_']+=Pn(_0x43e1f8),So(_0x19ee19);}function Rh(_0x7cbc5e){const _0x2947a6=_0x7cbc5e['parts_']['pop']();_0x7cbc5e['byteLength_']-=Pn(_0x2947a6),_0x7cbc5e['parts_']['length']>0x0&&(_0x7cbc5e['byteLength_']-=0x1);}function So(_0x5b403){if(_0x5b403['byteLength_']>Js)throw new Error(_0x5b403['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x5b403['byteLength_']+').');if(_0x5b403['parts_']['length']>Qs)throw new Error(_0x5b403['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x5b403));}function Ne(_0x40bba9){return _0x40bba9['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x40bba9['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x30f32d,_0x17477a;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x17477a='visibilitychange',_0x30f32d='hidden'):typeof document['mozHidden']<'u'?(_0x17477a='mozvisibilitychange',_0x30f32d='mozHidden'):typeof document['msHidden']<'u'?(_0x17477a='msvisibilitychange',_0x30f32d='msHidden'):typeof document['webkitHidden']<'u'&&(_0x17477a='webkitvisibilitychange',_0x30f32d='webkitHidden')),this['visible_']=!0x0,_0x17477a&&document['addEventListener'](_0x17477a,()=>{const _0xa05d51=!document[_0x30f32d];_0xa05d51!==this['visible_']&&(this['visible_']=_0xa05d51,this['trigger']('visible',_0xa05d51));},!0x1);}['getInitialEvent'](_0x3b69c8){return f(_0x3b69c8==='visible','Unknown\x20event\x20type:\x20'+_0x3b69c8),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x373f70,_0x12eca1,_0xcd58a4,_0x44abff,_0x463021,_0x61cea6,_0x86bd1f,_0x46bce4){if(super(),this['repoInfo_']=_0x373f70,this['applicationId_']=_0x12eca1,this['onDataUpdate_']=_0xcd58a4,this['onConnectStatus_']=_0x44abff,this['onServerInfoUpdate_']=_0x463021,this['authTokenProvider_']=_0x61cea6,this['appCheckTokenProvider_']=_0x86bd1f,this['authOverride_']=_0x46bce4,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x46bce4)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x373f70['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0xad23d8,_0x1bebbb,_0x2feb7d){const _0x21eeaf=++this['requestNumber_'],_0x363c28={'r':_0x21eeaf,'a':_0xad23d8,'b':_0x1bebbb};this['log_'](O(_0x363c28)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x363c28),_0x2feb7d&&(this['requestCBHash_'][_0x21eeaf]=_0x2feb7d);}['get'](_0x176173){this['initConnection_']();const _0x2c2623=new Ve(),_0x4ddb60={'action':'g','request':{'p':_0x176173['_path']['toString'](),'q':_0x176173['_queryObject']},'onComplete':_0x6e7785=>{const _0x504534=_0x6e7785['d'];_0x6e7785['s']==='ok'?_0x2c2623['resolve'](_0x504534):_0x2c2623['reject'](_0x504534);}};this['outstandingGets_']['push'](_0x4ddb60),this['outstandingGetCount_']++;const _0x395c47=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x395c47),_0x2c2623['promise'];}['listen'](_0x3c672f,_0x2f31f2,_0x17e18d,_0xd318f5){this['initConnection_']();const _0x5db8af=_0x3c672f['_queryIdentifier'],_0x1b0f17=_0x3c672f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1b0f17+'\x20'+_0x5db8af),this['listens']['has'](_0x1b0f17)||this['listens']['set'](_0x1b0f17,new Map()),f(_0x3c672f['_queryParams']['isDefault']()||!_0x3c672f['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1b0f17)['has'](_0x5db8af),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x268ccb={'onComplete':_0xd318f5,'hashFn':_0x2f31f2,'query':_0x3c672f,'tag':_0x17e18d};this['listens']['get'](_0x1b0f17)['set'](_0x5db8af,_0x268ccb),this['connected_']&&this['sendListen_'](_0x268ccb);}['sendGet_'](_0x465644){const _0x197055=this['outstandingGets_'][_0x465644];this['sendRequest']('g',_0x197055['request'],_0x1d718e=>{delete this['outstandingGets_'][_0x465644],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x197055['onComplete']&&_0x197055['onComplete'](_0x1d718e);});}['sendListen_'](_0x28add6){const _0x1a4226=_0x28add6['query'],_0x11f6ca=_0x1a4226['_path']['toString'](),_0x3bd92d=_0x1a4226['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x11f6ca+'\x20for\x20'+_0x3bd92d);const _0x4e758c={'p':_0x11f6ca},_0x2c7e6a='q';_0x28add6['tag']&&(_0x4e758c['q']=_0x1a4226['_queryObject'],_0x4e758c['t']=_0x28add6['tag']),_0x4e758c['h']=_0x28add6['hashFn'](),this['sendRequest'](_0x2c7e6a,_0x4e758c,_0x2fd628=>{const _0x3f3a83=_0x2fd628['d'],_0x19bfda=_0x2fd628['s'];ie['warnOnListenWarnings_'](_0x3f3a83,_0x1a4226),(this['listens']['get'](_0x11f6ca)&&this['listens']['get'](_0x11f6ca)['get'](_0x3bd92d))===_0x28add6&&(this['log_']('listen\x20response',_0x2fd628),_0x19bfda!=='ok'&&this['removeListen_'](_0x11f6ca,_0x3bd92d),_0x28add6['onComplete']&&_0x28add6['onComplete'](_0x19bfda,_0x3f3a83));});}static['warnOnListenWarnings_'](_0x1524b4,_0xb0cd48){if(_0x1524b4&&typeof _0x1524b4=='object'&&Y(_0x1524b4,'w')){const _0x528e4b=Oe(_0x1524b4,'w');if(Array['isArray'](_0x528e4b)&&~_0x528e4b['indexOf']('no_index')){const _0x46d6a2='\x22.indexOn\x22:\x20\x22'+_0xb0cd48['_queryParams']['getIndex']()['toString']()+'\x22',_0x448cef=_0xb0cd48['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x46d6a2+'\x20at\x20'+_0x448cef+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3aaf77){this['authToken_']=_0x3aaf77,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3aaf77);}['reduceReconnectDelayIfAdminCredential_'](_0x117c24){(_0x117c24&&_0x117c24['length']===0x28||vc(_0x117c24))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x1d2443){this['appCheckToken_']=_0x1d2443,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4b4a4b=this['authToken_'],_0x2b0072=yc(_0x4b4a4b)?'auth':'gauth',_0xc5689f={'cred':_0x4b4a4b};this['authOverride_']===null?_0xc5689f['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xc5689f['authvar']=this['authOverride_']),this['sendRequest'](_0x2b0072,_0xc5689f,_0x182e15=>{const _0x49ee91=_0x182e15['s'],_0x146645=_0x182e15['d']||'error';this['authToken_']===_0x4b4a4b&&(_0x49ee91==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x49ee91,_0x146645));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x91cf92=>{const _0x134fea=_0x91cf92['s'],_0x2e4051=_0x91cf92['d']||'error';_0x134fea==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x134fea,_0x2e4051);});}['unlisten'](_0x34daac,_0x5b6f79){const _0x39b8eb=_0x34daac['_path']['toString'](),_0x1b952a=_0x34daac['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x39b8eb+'\x20'+_0x1b952a),f(_0x34daac['_queryParams']['isDefault']()||!_0x34daac['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x39b8eb,_0x1b952a)&&this['connected_']&&this['sendUnlisten_'](_0x39b8eb,_0x1b952a,_0x34daac['_queryObject'],_0x5b6f79);}['sendUnlisten_'](_0x39b6d9,_0x401abd,_0xd23653,_0x55709d){this['log_']('Unlisten\x20on\x20'+_0x39b6d9+'\x20for\x20'+_0x401abd);const _0xc06952={'p':_0x39b6d9},_0x1abd81='n';_0x55709d&&(_0xc06952['q']=_0xd23653,_0xc06952['t']=_0x55709d),this['sendRequest'](_0x1abd81,_0xc06952);}['onDisconnectPut'](_0x57c72b,_0xe27e7d,_0x5bd675){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x57c72b,_0xe27e7d,_0x5bd675):this['onDisconnectRequestQueue_']['push']({'pathString':_0x57c72b,'action':'o','data':_0xe27e7d,'onComplete':_0x5bd675});}['onDisconnectMerge'](_0x4656a0,_0x3cbb98,_0x55cee8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4656a0,_0x3cbb98,_0x55cee8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4656a0,'action':'om','data':_0x3cbb98,'onComplete':_0x55cee8});}['onDisconnectCancel'](_0x197de5,_0xdf871b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x197de5,null,_0xdf871b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x197de5,'action':'oc','data':null,'onComplete':_0xdf871b});}['sendOnDisconnect_'](_0x1a9721,_0xbf0b2,_0x3b1f4c,_0x522ae7){const _0x550f9f={'p':_0xbf0b2,'d':_0x3b1f4c};this['log_']('onDisconnect\x20'+_0x1a9721,_0x550f9f),this['sendRequest'](_0x1a9721,_0x550f9f,_0x48e018=>{_0x522ae7&&setTimeout(()=>{_0x522ae7(_0x48e018['s'],_0x48e018['d']);},Math['floor'](0x0));});}['put'](_0x5ed639,_0x476bca,_0x4b50a0,_0xef17f5){this['putInternal']('p',_0x5ed639,_0x476bca,_0x4b50a0,_0xef17f5);}['merge'](_0x4f0b6b,_0x284e38,_0x1be8ed,_0xde05c3){this['putInternal']('m',_0x4f0b6b,_0x284e38,_0x1be8ed,_0xde05c3);}['putInternal'](_0x8846bf,_0x369a79,_0x233bb1,_0x4cb5f0,_0x10285f){this['initConnection_']();const _0x1e4804={'p':_0x369a79,'d':_0x233bb1};_0x10285f!==void 0x0&&(_0x1e4804['h']=_0x10285f),this['outstandingPuts_']['push']({'action':_0x8846bf,'request':_0x1e4804,'onComplete':_0x4cb5f0}),this['outstandingPutCount_']++;const _0x4e6060=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4e6060):this['log_']('Buffering\x20put:\x20'+_0x369a79);}['sendPut_'](_0x266a5a){const _0x5c71df=this['outstandingPuts_'][_0x266a5a]['action'],_0xf9efdb=this['outstandingPuts_'][_0x266a5a]['request'],_0x3ae5d0=this['outstandingPuts_'][_0x266a5a]['onComplete'];this['outstandingPuts_'][_0x266a5a]['queued']=this['connected_'],this['sendRequest'](_0x5c71df,_0xf9efdb,_0x20b0d4=>{this['log_'](_0x5c71df+'\x20response',_0x20b0d4),delete this['outstandingPuts_'][_0x266a5a],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x3ae5d0&&_0x3ae5d0(_0x20b0d4['s'],_0x20b0d4['d']);});}['reportStats'](_0x367f7f){if(this['connected_']){const _0x1c307f={'c':_0x367f7f};this['log_']('reportStats',_0x1c307f),this['sendRequest']('s',_0x1c307f,_0xc50ff=>{if(_0xc50ff['s']!=='ok'){const _0x85c9e=_0xc50ff['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x85c9e);}});}}['onDataMessage_'](_0x12c025){if('r'in _0x12c025){this['log_']('from\x20server:\x20'+O(_0x12c025));const _0x5187b2=_0x12c025['r'],_0x11a0ee=this['requestCBHash_'][_0x5187b2];_0x11a0ee&&(delete this['requestCBHash_'][_0x5187b2],_0x11a0ee(_0x12c025['b']));}else{if('error'in _0x12c025)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x12c025['error'];'a'in _0x12c025&&this['onDataPush_'](_0x12c025['a'],_0x12c025['b']);}}['onDataPush_'](_0x485e5d,_0x504cf4){this['log_']('handleServerMessage',_0x485e5d,_0x504cf4),_0x485e5d==='d'?this['onDataUpdate_'](_0x504cf4['p'],_0x504cf4['d'],!0x1,_0x504cf4['t']):_0x485e5d==='m'?this['onDataUpdate_'](_0x504cf4['p'],_0x504cf4['d'],!0x0,_0x504cf4['t']):_0x485e5d==='c'?this['onListenRevoked_'](_0x504cf4['p'],_0x504cf4['q']):_0x485e5d==='ac'?this['onAuthRevoked_'](_0x504cf4['s'],_0x504cf4['d']):_0x485e5d==='apc'?this['onAppCheckRevoked_'](_0x504cf4['s'],_0x504cf4['d']):_0x485e5d==='sd'?this['onSecurityDebugPacket_'](_0x504cf4):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x485e5d)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2fbec8,_0x19ff56){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2fbec8),this['lastSessionId']=_0x19ff56,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2c193d){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2c193d));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4bff94){_0x4bff94&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4bff94;}['onOnline_'](_0x41c03d){_0x41c03d?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3d03fb=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x5b74cd=Math['max'](0x0,this['reconnectDelay_']-_0x3d03fb);_0x5b74cd=Math['random']()*_0x5b74cd,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x5b74cd+'ms'),this['scheduleConnect_'](_0x5b74cd),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x32f639=this['onDataMessage_']['bind'](this),_0x5b1f1c=this['onReady_']['bind'](this),_0x25540f=this['onRealtimeDisconnect_']['bind'](this),_0x3af326=this['id']+':'+ie['nextConnectionId_']++,_0x3f4e1b=this['lastSessionId'];let _0x5e1f4f=!0x1,_0x3c7f68=null;const _0x26776c=function(){_0x3c7f68?_0x3c7f68['close']():(_0x5e1f4f=!0x0,_0x25540f());},_0x2316dc=function(_0x3f92c0){f(_0x3c7f68,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3c7f68['sendRequest'](_0x3f92c0);};this['realtime_']={'close':_0x26776c,'sendRequest':_0x2316dc};const _0x189fdd=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5c0dc3,_0x571f51]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x189fdd),this['appCheckTokenProvider_']['getToken'](_0x189fdd)]);_0x5e1f4f?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5c0dc3&&_0x5c0dc3['accessToken'],this['appCheckToken_']=_0x571f51&&_0x571f51['token'],_0x3c7f68=new wh(_0x3af326,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x32f639,_0x5b1f1c,_0x25540f,_0x50f6e4=>{U(_0x50f6e4+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x3f4e1b));}catch(_0x4dadf6){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4dadf6),_0x5e1f4f||(this['repoInfo_']['nodeAdmin']&&U(_0x4dadf6),_0x26776c());}}}['interrupt'](_0x505aa8){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x505aa8),this['interruptReasons_'][_0x505aa8]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x7a5494){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x7a5494),delete this['interruptReasons_'][_0x7a5494],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2ad7ee){const _0x33f4d6=_0x2ad7ee-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x33f4d6});}['cancelSentTransactions_'](){for(let _0x119485=0x0;_0x119485<this['outstandingPuts_']['length'];_0x119485++){const _0x1581ed=this['outstandingPuts_'][_0x119485];_0x1581ed&&'h'in _0x1581ed['request']&&_0x1581ed['queued']&&(_0x1581ed['onComplete']&&_0x1581ed['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x119485],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x35d6fe,_0x5d261e){let _0x15b8e0;_0x5d261e?_0x15b8e0=_0x5d261e['map'](_0x39e615=>Bi(_0x39e615))['join']('$'):_0x15b8e0='default';const _0x31de0f=this['removeListen_'](_0x35d6fe,_0x15b8e0);_0x31de0f&&_0x31de0f['onComplete']&&_0x31de0f['onComplete']('permission_denied');}['removeListen_'](_0x4312c0,_0x5653b5){const _0x17f830=new C(_0x4312c0)['toString']();let _0x357999;if(this['listens']['has'](_0x17f830)){const _0x43425e=this['listens']['get'](_0x17f830);_0x357999=_0x43425e['get'](_0x5653b5),_0x43425e['delete'](_0x5653b5),_0x43425e['size']===0x0&&this['listens']['delete'](_0x17f830);}else _0x357999=void 0x0;return _0x357999;}['onAuthRevoked_'](_0x5f057f,_0x2e3689){L('Auth\x20token\x20revoked:\x20'+_0x5f057f+'/'+_0x2e3689),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5f057f==='invalid_token'||_0x5f057f==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x3e6283,_0x5665ed){L('App\x20check\x20token\x20revoked:\x20'+_0x3e6283+'/'+_0x5665ed),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x3e6283==='invalid_token'||_0x3e6283==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x44d11e){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x44d11e):'msg'in _0x44d11e&&console['log']('FIREBASE:\x20'+_0x44d11e['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2a43d1 of this['listens']['values']())for(const _0x516133 of _0x2a43d1['values']())this['sendListen_'](_0x516133);for(let _0x3cdb33=0x0;_0x3cdb33<this['outstandingPuts_']['length'];_0x3cdb33++)this['outstandingPuts_'][_0x3cdb33]&&this['sendPut_'](_0x3cdb33);for(;this['onDisconnectRequestQueue_']['length'];){const _0x383ea6=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x383ea6['action'],_0x383ea6['pathString'],_0x383ea6['data'],_0x383ea6['onComplete']);}for(let _0x14a306=0x0;_0x14a306<this['outstandingGets_']['length'];_0x14a306++)this['outstandingGets_'][_0x14a306]&&this['sendGet_'](_0x14a306);}['sendConnectStats_'](){const _0xb999f0={};let _0x5c4edf='js';_0xb999f0['sdk.'+_0x5c4edf+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0xb999f0['framework.cordova']=0x1:qr()&&(_0xb999f0['framework.reactnative']=0x1),this['reportStats'](_0xb999f0);}['shouldReconnect_'](){const _0x4b339a=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x4b339a;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x435350,_0x53b136){this['name']=_0x435350,this['node']=_0x53b136;}static['Wrap'](_0x405986,_0x3e3d1e){return new E(_0x405986,_0x3e3d1e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x52ef62,_0x150a6d){const _0x2a9a40=new E(xe,_0x52ef62),_0x48a85c=new E(xe,_0x150a6d);return this['compare'](_0x2a9a40,_0x48a85c)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x334057){Xt=_0x334057;}['compare'](_0x3ef372,_0x5e696b){return He(_0x3ef372['name'],_0x5e696b['name']);}['isDefinedOn'](_0x501d88){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x497d49,_0x3971e4){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x1ea13f,_0x116bda){return f(typeof _0x1ea13f=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x1ea13f,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x3c3f78,_0x12af7b,_0x58233f,_0x39a002,_0x5c3c16=null){this['isReverse_']=_0x39a002,this['resultGenerator_']=_0x5c3c16,this['nodeStack_']=[];let _0x3653f6=0x1;for(;!_0x3c3f78['isEmpty']();)if(_0x3c3f78=_0x3c3f78,_0x3653f6=_0x12af7b?_0x58233f(_0x3c3f78['key'],_0x12af7b):0x1,_0x39a002&&(_0x3653f6*=-0x1),_0x3653f6<0x0)this['isReverse_']?_0x3c3f78=_0x3c3f78['left']:_0x3c3f78=_0x3c3f78['right'];else{if(_0x3653f6===0x0){this['nodeStack_']['push'](_0x3c3f78);break;}else this['nodeStack_']['push'](_0x3c3f78),this['isReverse_']?_0x3c3f78=_0x3c3f78['right']:_0x3c3f78=_0x3c3f78['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x42c040=this['nodeStack_']['pop'](),_0x25c503;if(this['resultGenerator_']?_0x25c503=this['resultGenerator_'](_0x42c040['key'],_0x42c040['value']):_0x25c503={'key':_0x42c040['key'],'value':_0x42c040['value']},this['isReverse_']){for(_0x42c040=_0x42c040['left'];!_0x42c040['isEmpty']();)this['nodeStack_']['push'](_0x42c040),_0x42c040=_0x42c040['right'];}else{for(_0x42c040=_0x42c040['right'];!_0x42c040['isEmpty']();)this['nodeStack_']['push'](_0x42c040),_0x42c040=_0x42c040['left'];}return _0x25c503;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x531c52=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x531c52['key'],_0x531c52['value']):{'key':_0x531c52['key'],'value':_0x531c52['value']};}}class M{constructor(_0x244b1c,_0x2d8e0c,_0x3864d6,_0x4b0bfd,_0x4e9746){this['key']=_0x244b1c,this['value']=_0x2d8e0c,this['color']=_0x3864d6??M['RED'],this['left']=_0x4b0bfd??B['EMPTY_NODE'],this['right']=_0x4e9746??B['EMPTY_NODE'];}['copy'](_0x59e96c,_0x39c6dd,_0x58c346,_0x12f772,_0x4a762d){return new M(_0x59e96c??this['key'],_0x39c6dd??this['value'],_0x58c346??this['color'],_0x12f772??this['left'],_0x4a762d??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x1d5148){return this['left']['inorderTraversal'](_0x1d5148)||!!_0x1d5148(this['key'],this['value'])||this['right']['inorderTraversal'](_0x1d5148);}['reverseTraversal'](_0x1be544){return this['right']['reverseTraversal'](_0x1be544)||_0x1be544(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1be544);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0xd9b18c,_0x24bb16,_0x5e4273){let _0x4d7fad=this;const _0x38075f=_0x5e4273(_0xd9b18c,_0x4d7fad['key']);return _0x38075f<0x0?_0x4d7fad=_0x4d7fad['copy'](null,null,null,_0x4d7fad['left']['insert'](_0xd9b18c,_0x24bb16,_0x5e4273),null):_0x38075f===0x0?_0x4d7fad=_0x4d7fad['copy'](null,_0x24bb16,null,null,null):_0x4d7fad=_0x4d7fad['copy'](null,null,null,null,_0x4d7fad['right']['insert'](_0xd9b18c,_0x24bb16,_0x5e4273)),_0x4d7fad['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x40c963=this;return!_0x40c963['left']['isRed_']()&&!_0x40c963['left']['left']['isRed_']()&&(_0x40c963=_0x40c963['moveRedLeft_']()),_0x40c963=_0x40c963['copy'](null,null,null,_0x40c963['left']['removeMin_'](),null),_0x40c963['fixUp_']();}['remove'](_0x49d71e,_0x57b32a){let _0x19ef6f,_0x52c1d1;if(_0x19ef6f=this,_0x57b32a(_0x49d71e,_0x19ef6f['key'])<0x0)!_0x19ef6f['left']['isEmpty']()&&!_0x19ef6f['left']['isRed_']()&&!_0x19ef6f['left']['left']['isRed_']()&&(_0x19ef6f=_0x19ef6f['moveRedLeft_']()),_0x19ef6f=_0x19ef6f['copy'](null,null,null,_0x19ef6f['left']['remove'](_0x49d71e,_0x57b32a),null);else{if(_0x19ef6f['left']['isRed_']()&&(_0x19ef6f=_0x19ef6f['rotateRight_']()),!_0x19ef6f['right']['isEmpty']()&&!_0x19ef6f['right']['isRed_']()&&!_0x19ef6f['right']['left']['isRed_']()&&(_0x19ef6f=_0x19ef6f['moveRedRight_']()),_0x57b32a(_0x49d71e,_0x19ef6f['key'])===0x0){if(_0x19ef6f['right']['isEmpty']())return B['EMPTY_NODE'];_0x52c1d1=_0x19ef6f['right']['min_'](),_0x19ef6f=_0x19ef6f['copy'](_0x52c1d1['key'],_0x52c1d1['value'],null,null,_0x19ef6f['right']['removeMin_']());}_0x19ef6f=_0x19ef6f['copy'](null,null,null,null,_0x19ef6f['right']['remove'](_0x49d71e,_0x57b32a));}return _0x19ef6f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x268821=this;return _0x268821['right']['isRed_']()&&!_0x268821['left']['isRed_']()&&(_0x268821=_0x268821['rotateLeft_']()),_0x268821['left']['isRed_']()&&_0x268821['left']['left']['isRed_']()&&(_0x268821=_0x268821['rotateRight_']()),_0x268821['left']['isRed_']()&&_0x268821['right']['isRed_']()&&(_0x268821=_0x268821['colorFlip_']()),_0x268821;}['moveRedLeft_'](){let _0x1ea794=this['colorFlip_']();return _0x1ea794['right']['left']['isRed_']()&&(_0x1ea794=_0x1ea794['copy'](null,null,null,null,_0x1ea794['right']['rotateRight_']()),_0x1ea794=_0x1ea794['rotateLeft_'](),_0x1ea794=_0x1ea794['colorFlip_']()),_0x1ea794;}['moveRedRight_'](){let _0x2bd562=this['colorFlip_']();return _0x2bd562['left']['left']['isRed_']()&&(_0x2bd562=_0x2bd562['rotateRight_'](),_0x2bd562=_0x2bd562['colorFlip_']()),_0x2bd562;}['rotateLeft_'](){const _0x270d43=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x270d43,null);}['rotateRight_'](){const _0x553b6d=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x553b6d);}['colorFlip_'](){const _0x1ede7f=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x207ca4=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1ede7f,_0x207ca4);}['checkMaxDepth_'](){const _0x19e469=this['check_']();return Math['pow'](0x2,_0x19e469)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x33480d=this['left']['check_']();if(_0x33480d!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x33480d+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x35d103,_0x37e783,_0x58e934,_0x10e517,_0x22d18e){return this;}['insert'](_0x3fe88a,_0x165074,_0x22668a){return new M(_0x3fe88a,_0x165074,null);}['remove'](_0x4af18b,_0x29f3f2){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x52cfd9){return!0x1;}['reverseTraversal'](_0x1a2142){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1fd92c,_0x519155=B['EMPTY_NODE']){this['comparator_']=_0x1fd92c,this['root_']=_0x519155;}['insert'](_0x194603,_0x3e920a){return new B(this['comparator_'],this['root_']['insert'](_0x194603,_0x3e920a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3531a7){return new B(this['comparator_'],this['root_']['remove'](_0x3531a7,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x536fc6){let _0x173058,_0x5dc181=this['root_'];for(;!_0x5dc181['isEmpty']();){if(_0x173058=this['comparator_'](_0x536fc6,_0x5dc181['key']),_0x173058===0x0)return _0x5dc181['value'];_0x173058<0x0?_0x5dc181=_0x5dc181['left']:_0x173058>0x0&&(_0x5dc181=_0x5dc181['right']);}return null;}['getPredecessorKey'](_0x2baf43){let _0x497d94,_0x2b3a67=this['root_'],_0x14ae83=null;for(;!_0x2b3a67['isEmpty']();)if(_0x497d94=this['comparator_'](_0x2baf43,_0x2b3a67['key']),_0x497d94===0x0){if(_0x2b3a67['left']['isEmpty']())return _0x14ae83?_0x14ae83['key']:null;for(_0x2b3a67=_0x2b3a67['left'];!_0x2b3a67['right']['isEmpty']();)_0x2b3a67=_0x2b3a67['right'];return _0x2b3a67['key'];}else _0x497d94<0x0?_0x2b3a67=_0x2b3a67['left']:_0x497d94>0x0&&(_0x14ae83=_0x2b3a67,_0x2b3a67=_0x2b3a67['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x46cc11){return this['root_']['inorderTraversal'](_0x46cc11);}['reverseTraversal'](_0x54c8e4){return this['root_']['reverseTraversal'](_0x54c8e4);}['getIterator'](_0x15db6d){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x15db6d);}['getIteratorFrom'](_0x288a4a,_0x231a72){return new Zt(this['root_'],_0x288a4a,this['comparator_'],!0x1,_0x231a72);}['getReverseIteratorFrom'](_0x204010,_0x45d394){return new Zt(this['root_'],_0x204010,this['comparator_'],!0x0,_0x45d394);}['getReverseIterator'](_0x3a4820){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x3a4820);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x3a6acf,_0x24b996){return He(_0x3a6acf['name'],_0x24b996['name']);}function ji(_0x19e5f9,_0x4cc3af){return He(_0x19e5f9,_0x4cc3af);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x2a912b){vi=_0x2a912b;}const Ro=function(_0x26ab37){return typeof _0x26ab37=='number'?'number:'+so(_0x26ab37):'string:'+_0x26ab37;},Ao=function(_0x4ec4fd){if(_0x4ec4fd['isLeafNode']()){const _0x186b38=_0x4ec4fd['val']();f(typeof _0x186b38=='string'||typeof _0x186b38=='number'||typeof _0x186b38=='object'&&Y(_0x186b38,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4ec4fd===vi||_0x4ec4fd['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4ec4fd===vi||_0x4ec4fd['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x3a60c2){er=_0x3a60c2;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x4b8af7,_0x4a3eb4=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4b8af7,this['priorityNode_']=_0x4a3eb4,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x343d38){return new D(this['value_'],_0x343d38);}['getImmediateChild'](_0x418e2b){return _0x418e2b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4bbe7e){return v(_0x4bbe7e)?this:y(_0x4bbe7e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5c39ea,_0x48a2f7){return null;}['updateImmediateChild'](_0xb0ab80,_0x58b286){return _0xb0ab80==='.priority'?this['updatePriority'](_0x58b286):_0x58b286['isEmpty']()&&_0xb0ab80!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0xb0ab80,_0x58b286)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2ad5ed,_0x27096c){const _0x590d5d=y(_0x2ad5ed);return _0x590d5d===null?_0x27096c:_0x27096c['isEmpty']()&&_0x590d5d!=='.priority'?this:(f(_0x590d5d!=='.priority'||we(_0x2ad5ed)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x590d5d,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x2ad5ed),_0x27096c)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x273c8e,_0x2de675){return!0x1;}['val'](_0xeef492){return _0xeef492&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1a1ebb='';this['priorityNode_']['isEmpty']()||(_0x1a1ebb+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x550293=typeof this['value_'];_0x1a1ebb+=_0x550293+':',_0x550293==='number'?_0x1a1ebb+=so(this['value_']):_0x1a1ebb+=this['value_'],this['lazyHash_']=no(_0x1a1ebb);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x5d21a9){return _0x5d21a9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x5d21a9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x5d21a9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x5d21a9));}['compareToLeafNode_'](_0x1730d7){const _0x8c423c=typeof _0x1730d7['value_'],_0x9f3ec=typeof this['value_'],_0x24a21d=D['VALUE_TYPE_ORDER']['indexOf'](_0x8c423c),_0x456575=D['VALUE_TYPE_ORDER']['indexOf'](_0x9f3ec);return f(_0x24a21d>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x8c423c),f(_0x456575>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x9f3ec),_0x24a21d===_0x456575?_0x9f3ec==='object'?0x0:this['value_']<_0x1730d7['value_']?-0x1:this['value_']===_0x1730d7['value_']?0x0:0x1:_0x456575-_0x24a21d;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x29913f){if(_0x29913f===this)return!0x0;if(_0x29913f['isLeafNode']()){const _0x9cc279=_0x29913f;return this['value_']===_0x9cc279['value_']&&this['priorityNode_']['equals'](_0x9cc279['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x194393){ko=_0x194393;}function xh(_0x3daf5f){No=_0x3daf5f;}class Fh extends On{['compare'](_0x526ff4,_0x395a4f){const _0x3e3bd4=_0x526ff4['node']['getPriority'](),_0x1f223f=_0x395a4f['node']['getPriority'](),_0x413961=_0x3e3bd4['compareTo'](_0x1f223f);return _0x413961===0x0?He(_0x526ff4['name'],_0x395a4f['name']):_0x413961;}['isDefinedOn'](_0x1a3577){return!_0x1a3577['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x1aec17,_0x174dc8){return!_0x1aec17['getPriority']()['equals'](_0x174dc8['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x1403d0,_0x59db2b){const _0x89e2f7=ko(_0x1403d0);return new E(_0x59db2b,new D('[PRIORITY-POST]',_0x89e2f7));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x9eaafa){const _0x27b296=_0x12ae44=>parseInt(Math['log'](_0x12ae44)/Uh,0xa),_0x5e3309=_0x1958b3=>parseInt(Array(_0x1958b3+0x1)['join']('1'),0x2);this['count']=_0x27b296(_0x9eaafa+0x1),this['current_']=this['count']-0x1;const _0x5342a2=_0x5e3309(this['count']);this['bits_']=_0x9eaafa+0x1&_0x5342a2;}['nextBitIsOne'](){const _0xb441fa=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0xb441fa;}}const dn=function(_0x295073,_0x50d3f1,_0xfcc0ff,_0x1043d4){_0x295073['sort'](_0x50d3f1);const _0x59b6a0=function(_0x18226d,_0x2772fe){const _0x4a652f=_0x2772fe-_0x18226d;let _0x450805,_0x1f7d8e;if(_0x4a652f===0x0)return null;if(_0x4a652f===0x1)return _0x450805=_0x295073[_0x18226d],_0x1f7d8e=_0xfcc0ff?_0xfcc0ff(_0x450805):_0x450805,new M(_0x1f7d8e,_0x450805['node'],M['BLACK'],null,null);{const _0x1a14e1=parseInt(_0x4a652f/0x2,0xa)+_0x18226d,_0x4be95c=_0x59b6a0(_0x18226d,_0x1a14e1),_0x255aa4=_0x59b6a0(_0x1a14e1+0x1,_0x2772fe);return _0x450805=_0x295073[_0x1a14e1],_0x1f7d8e=_0xfcc0ff?_0xfcc0ff(_0x450805):_0x450805,new M(_0x1f7d8e,_0x450805['node'],M['BLACK'],_0x4be95c,_0x255aa4);}},_0x189aef=function(_0x47d230){let _0x3d3640=null,_0xfe7828=null,_0x2668e6=_0x295073['length'];const _0x247fb3=function(_0x235daa,_0x5f1404){const _0x57fb86=_0x2668e6-_0x235daa,_0x519c21=_0x2668e6;_0x2668e6-=_0x235daa;const _0x3d97d7=_0x59b6a0(_0x57fb86+0x1,_0x519c21),_0x10e509=_0x295073[_0x57fb86],_0x504c69=_0xfcc0ff?_0xfcc0ff(_0x10e509):_0x10e509;_0x3c3c4b(new M(_0x504c69,_0x10e509['node'],_0x5f1404,null,_0x3d97d7));},_0x3c3c4b=function(_0x3b7508){_0x3d3640?(_0x3d3640['left']=_0x3b7508,_0x3d3640=_0x3b7508):(_0xfe7828=_0x3b7508,_0x3d3640=_0x3b7508);};for(let _0x145546=0x0;_0x145546<_0x47d230['count'];++_0x145546){const _0x5d5801=_0x47d230['nextBitIsOne'](),_0x3f3e88=Math['pow'](0x2,_0x47d230['count']-(_0x145546+0x1));_0x5d5801?_0x247fb3(_0x3f3e88,M['BLACK']):(_0x247fb3(_0x3f3e88,M['BLACK']),_0x247fb3(_0x3f3e88,M['RED']));}return _0xfe7828;},_0x1a4e25=new Wh(_0x295073['length']),_0x131105=_0x189aef(_0x1a4e25);return new B(_0x1043d4||_0x50d3f1,_0x131105);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x153124,_0x3474e8){this['indexes_']=_0x153124,this['indexSet_']=_0x3474e8;}['get'](_0x1090a5){const _0x374ef4=Oe(this['indexes_'],_0x1090a5);if(!_0x374ef4)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1090a5);return _0x374ef4 instanceof B?_0x374ef4:null;}['hasIndex'](_0xf4855){return Y(this['indexSet_'],_0xf4855['toString']());}['addIndex'](_0x369529,_0x295a32){f(_0x369529!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x544f9e=[];let _0x554072=!0x1;const _0x1e78f0=_0x295a32['getIterator'](E['Wrap']);let _0x4240e6=_0x1e78f0['getNext']();for(;_0x4240e6;)_0x554072=_0x554072||_0x369529['isDefinedOn'](_0x4240e6['node']),_0x544f9e['push'](_0x4240e6),_0x4240e6=_0x1e78f0['getNext']();let _0x2613b8;_0x554072?_0x2613b8=dn(_0x544f9e,_0x369529['getCompare']()):_0x2613b8=je;const _0x23ac5f=_0x369529['toString'](),_0x66db0c={...this['indexSet_']};_0x66db0c[_0x23ac5f]=_0x369529;const _0x12bbc6={...this['indexes_']};return _0x12bbc6[_0x23ac5f]=_0x2613b8,new ee(_0x12bbc6,_0x66db0c);}['addToIndexes'](_0x503451,_0x2c8a2e){const _0x1070fe=ln(this['indexes_'],(_0x31fdf2,_0x57ea44)=>{const _0x2f8944=Oe(this['indexSet_'],_0x57ea44);if(f(_0x2f8944,'Missing\x20index\x20implementation\x20for\x20'+_0x57ea44),_0x31fdf2===je){if(_0x2f8944['isDefinedOn'](_0x503451['node'])){const _0xeb6b35=[],_0x5bad5a=_0x2c8a2e['getIterator'](E['Wrap']);let _0x1014d6=_0x5bad5a['getNext']();for(;_0x1014d6;)_0x1014d6['name']!==_0x503451['name']&&_0xeb6b35['push'](_0x1014d6),_0x1014d6=_0x5bad5a['getNext']();return _0xeb6b35['push'](_0x503451),dn(_0xeb6b35,_0x2f8944['getCompare']());}else return je;}else{const _0x5be442=_0x2c8a2e['get'](_0x503451['name']);let _0x23a1ee=_0x31fdf2;return _0x5be442&&(_0x23a1ee=_0x23a1ee['remove'](new E(_0x503451['name'],_0x5be442))),_0x23a1ee['insert'](_0x503451,_0x503451['node']);}});return new ee(_0x1070fe,this['indexSet_']);}['removeFromIndexes'](_0x76baa,_0x47c7a3){const _0x6f625b=ln(this['indexes_'],_0x15e348=>{if(_0x15e348===je)return _0x15e348;{const _0x4bd78d=_0x47c7a3['get'](_0x76baa['name']);return _0x4bd78d?_0x15e348['remove'](new E(_0x76baa['name'],_0x4bd78d)):_0x15e348;}});return new ee(_0x6f625b,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x3ae92a,_0x256bca,_0x118b3f){this['children_']=_0x3ae92a,this['priorityNode_']=_0x256bca,this['indexMap_']=_0x118b3f,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x486089){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x486089,this['indexMap_']);}['getImmediateChild'](_0x33e6f5){if(_0x33e6f5==='.priority')return this['getPriority']();{const _0x4c4a26=this['children_']['get'](_0x33e6f5);return _0x4c4a26===null?gt:_0x4c4a26;}}['getChild'](_0x5791ea){const _0x41a72f=y(_0x5791ea);return _0x41a72f===null?this:this['getImmediateChild'](_0x41a72f)['getChild'](b(_0x5791ea));}['hasChild'](_0x4d2ad1){return this['children_']['get'](_0x4d2ad1)!==null;}['updateImmediateChild'](_0x515ef1,_0x334932){if(f(_0x334932,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x515ef1==='.priority')return this['updatePriority'](_0x334932);{const _0x55a8b0=new E(_0x515ef1,_0x334932);let _0x4a72a3,_0x38c303;_0x334932['isEmpty']()?(_0x4a72a3=this['children_']['remove'](_0x515ef1),_0x38c303=this['indexMap_']['removeFromIndexes'](_0x55a8b0,this['children_'])):(_0x4a72a3=this['children_']['insert'](_0x515ef1,_0x334932),_0x38c303=this['indexMap_']['addToIndexes'](_0x55a8b0,this['children_']));const _0x3c32ee=_0x4a72a3['isEmpty']()?gt:this['priorityNode_'];return new g(_0x4a72a3,_0x3c32ee,_0x38c303);}}['updateChild'](_0x488ec2,_0x5de54b){const _0x4d735c=y(_0x488ec2);if(_0x4d735c===null)return _0x5de54b;{f(y(_0x488ec2)!=='.priority'||we(_0x488ec2)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x332ec8=this['getImmediateChild'](_0x4d735c)['updateChild'](b(_0x488ec2),_0x5de54b);return this['updateImmediateChild'](_0x4d735c,_0x332ec8);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x388cdf){if(this['isEmpty']())return null;const _0x4a197a={};let _0xd92442=0x0,_0x1bbeb1=0x0,_0x43b7cd=!0x0;if(this['forEachChild'](R,(_0x49160f,_0x2e9bb5)=>{_0x4a197a[_0x49160f]=_0x2e9bb5['val'](_0x388cdf),_0xd92442++,_0x43b7cd&&g['INTEGER_REGEXP_']['test'](_0x49160f)?_0x1bbeb1=Math['max'](_0x1bbeb1,Number(_0x49160f)):_0x43b7cd=!0x1;}),!_0x388cdf&&_0x43b7cd&&_0x1bbeb1<0x2*_0xd92442){const _0x394903=[];for(const _0x5bb885 in _0x4a197a)_0x394903[_0x5bb885]=_0x4a197a[_0x5bb885];return _0x394903;}else return _0x388cdf&&!this['getPriority']()['isEmpty']()&&(_0x4a197a['.priority']=this['getPriority']()['val']()),_0x4a197a;}['hash'](){if(this['lazyHash_']===null){let _0x597b18='';this['getPriority']()['isEmpty']()||(_0x597b18+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4517c5,_0x5a9ed5)=>{const _0x3fb915=_0x5a9ed5['hash']();_0x3fb915!==''&&(_0x597b18+=':'+_0x4517c5+':'+_0x3fb915);}),this['lazyHash_']=_0x597b18===''?'':no(_0x597b18);}return this['lazyHash_'];}['getPredecessorChildName'](_0x43545e,_0x42c9ef,_0x41ae03){const _0x376a46=this['resolveIndex_'](_0x41ae03);if(_0x376a46){const _0x177ec5=_0x376a46['getPredecessorKey'](new E(_0x43545e,_0x42c9ef));return _0x177ec5?_0x177ec5['name']:null;}else return this['children_']['getPredecessorKey'](_0x43545e);}['getFirstChildName'](_0x592d6f){const _0x219703=this['resolveIndex_'](_0x592d6f);if(_0x219703){const _0x5174d5=_0x219703['minKey']();return _0x5174d5&&_0x5174d5['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1ad1ab){const _0x532527=this['getFirstChildName'](_0x1ad1ab);return _0x532527?new E(_0x532527,this['children_']['get'](_0x532527)):null;}['getLastChildName'](_0x477223){const _0x207b95=this['resolveIndex_'](_0x477223);if(_0x207b95){const _0x1cda5e=_0x207b95['maxKey']();return _0x1cda5e&&_0x1cda5e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x439032){const _0xe50481=this['getLastChildName'](_0x439032);return _0xe50481?new E(_0xe50481,this['children_']['get'](_0xe50481)):null;}['forEachChild'](_0x5cbbaf,_0x210711){const _0x380110=this['resolveIndex_'](_0x5cbbaf);return _0x380110?_0x380110['inorderTraversal'](_0x2eae48=>_0x210711(_0x2eae48['name'],_0x2eae48['node'])):this['children_']['inorderTraversal'](_0x210711);}['getIterator'](_0x14ba5b){return this['getIteratorFrom'](_0x14ba5b['minPost'](),_0x14ba5b);}['getIteratorFrom'](_0x23d674,_0x134623){const _0x5def0a=this['resolveIndex_'](_0x134623);if(_0x5def0a)return _0x5def0a['getIteratorFrom'](_0x23d674,_0xddddd0=>_0xddddd0);{const _0xa3c395=this['children_']['getIteratorFrom'](_0x23d674['name'],E['Wrap']);let _0x77e784=_0xa3c395['peek']();for(;_0x77e784!=null&&_0x134623['compare'](_0x77e784,_0x23d674)<0x0;)_0xa3c395['getNext'](),_0x77e784=_0xa3c395['peek']();return _0xa3c395;}}['getReverseIterator'](_0x3e58d4){return this['getReverseIteratorFrom'](_0x3e58d4['maxPost'](),_0x3e58d4);}['getReverseIteratorFrom'](_0x3002ed,_0x1632a4){const _0x3f8d0e=this['resolveIndex_'](_0x1632a4);if(_0x3f8d0e)return _0x3f8d0e['getReverseIteratorFrom'](_0x3002ed,_0xd3618b=>_0xd3618b);{const _0x338cba=this['children_']['getReverseIteratorFrom'](_0x3002ed['name'],E['Wrap']);let _0x3f918f=_0x338cba['peek']();for(;_0x3f918f!=null&&_0x1632a4['compare'](_0x3f918f,_0x3002ed)>0x0;)_0x338cba['getNext'](),_0x3f918f=_0x338cba['peek']();return _0x338cba;}}['compareTo'](_0x547a0e){return this['isEmpty']()?_0x547a0e['isEmpty']()?0x0:-0x1:_0x547a0e['isLeafNode']()||_0x547a0e['isEmpty']()?0x1:_0x547a0e===Ht?-0x1:0x0;}['withIndex'](_0x2e445e){if(_0x2e445e===ye||this['indexMap_']['hasIndex'](_0x2e445e))return this;{const _0x1afe47=this['indexMap_']['addIndex'](_0x2e445e,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1afe47);}}['isIndexed'](_0x503d53){return _0x503d53===ye||this['indexMap_']['hasIndex'](_0x503d53);}['equals'](_0x2a9bcd){if(_0x2a9bcd===this)return!0x0;if(_0x2a9bcd['isLeafNode']())return!0x1;{const _0x4b318d=_0x2a9bcd;if(this['getPriority']()['equals'](_0x4b318d['getPriority']())){if(this['children_']['count']()===_0x4b318d['children_']['count']()){const _0x38d3af=this['getIterator'](R),_0x3f86ae=_0x4b318d['getIterator'](R);let _0x4d94dc=_0x38d3af['getNext'](),_0x54d86c=_0x3f86ae['getNext']();for(;_0x4d94dc&&_0x54d86c;){if(_0x4d94dc['name']!==_0x54d86c['name']||!_0x4d94dc['node']['equals'](_0x54d86c['node']))return!0x1;_0x4d94dc=_0x38d3af['getNext'](),_0x54d86c=_0x3f86ae['getNext']();}return _0x4d94dc===null&&_0x54d86c===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x26599e){return _0x26599e===ye?null:this['indexMap_']['get'](_0x26599e['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x399d13){return _0x399d13===this?0x0:0x1;}['equals'](_0x3aac76){return _0x3aac76===this;}['getPriority'](){return this;}['getImmediateChild'](_0x52dae7){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x319ca0,_0x5802d4=null){if(_0x319ca0===null)return g['EMPTY_NODE'];if(typeof _0x319ca0=='object'&&'.priority'in _0x319ca0&&(_0x5802d4=_0x319ca0['.priority']),f(_0x5802d4===null||typeof _0x5802d4=='string'||typeof _0x5802d4=='number'||typeof _0x5802d4=='object'&&'.sv'in _0x5802d4,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5802d4),typeof _0x319ca0=='object'&&'.value'in _0x319ca0&&_0x319ca0['.value']!==null&&(_0x319ca0=_0x319ca0['.value']),typeof _0x319ca0!='object'||'.sv'in _0x319ca0){const _0x586e6a=_0x319ca0;return new D(_0x586e6a,N(_0x5802d4));}if(!(_0x319ca0 instanceof Array)&&Vh){const _0x29f84d=[];let _0xaf81fc=!0x1;if(x(_0x319ca0,(_0x765031,_0x44d50d)=>{if(_0x765031['substring'](0x0,0x1)!=='.'){const _0xdc4dab=N(_0x44d50d);_0xdc4dab['isEmpty']()||(_0xaf81fc=_0xaf81fc||!_0xdc4dab['getPriority']()['isEmpty'](),_0x29f84d['push'](new E(_0x765031,_0xdc4dab)));}}),_0x29f84d['length']===0x0)return g['EMPTY_NODE'];const _0x30fd9f=dn(_0x29f84d,Dh,_0x35d2ca=>_0x35d2ca['name'],ji);if(_0xaf81fc){const _0x155eb2=dn(_0x29f84d,R['getCompare']());return new g(_0x30fd9f,N(_0x5802d4),new ee({'.priority':_0x155eb2},{'.priority':R}));}else return new g(_0x30fd9f,N(_0x5802d4),ee['Default']);}else{let _0x12f3bd=g['EMPTY_NODE'];return x(_0x319ca0,(_0xd9c8b3,_0x4d02f4)=>{if(Y(_0x319ca0,_0xd9c8b3)&&_0xd9c8b3['substring'](0x0,0x1)!=='.'){const _0x4d72b5=N(_0x4d02f4);(_0x4d72b5['isLeafNode']()||!_0x4d72b5['isEmpty']())&&(_0x12f3bd=_0x12f3bd['updateImmediateChild'](_0xd9c8b3,_0x4d72b5));}}),_0x12f3bd['updatePriority'](N(_0x5802d4));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x15cf7e){super(),this['indexPath_']=_0x15cf7e,f(!v(_0x15cf7e)&&y(_0x15cf7e)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x484ad0){return _0x484ad0['getChild'](this['indexPath_']);}['isDefinedOn'](_0x179dd1){return!_0x179dd1['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x111f9c,_0x1bd45d){const _0x471a87=this['extractChild'](_0x111f9c['node']),_0x40e529=this['extractChild'](_0x1bd45d['node']),_0x382735=_0x471a87['compareTo'](_0x40e529);return _0x382735===0x0?He(_0x111f9c['name'],_0x1bd45d['name']):_0x382735;}['makePost'](_0x45c750,_0x259dd8){const _0x141469=N(_0x45c750),_0x5461b5=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x141469);return new E(_0x259dd8,_0x5461b5);}['maxPost'](){const _0x163dc8=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x163dc8);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x5db593,_0x2a0dc1){const _0x4e2f39=_0x5db593['node']['compareTo'](_0x2a0dc1['node']);return _0x4e2f39===0x0?He(_0x5db593['name'],_0x2a0dc1['name']):_0x4e2f39;}['isDefinedOn'](_0x173262){return!0x0;}['indexedValueChanged'](_0x33f9a5,_0x35de93){return!_0x33f9a5['equals'](_0x35de93);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2f3bd9,_0x2405b5){const _0x57492b=N(_0x2f3bd9);return new E(_0x2405b5,_0x57492b);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x6cbad){return{'type':'value','snapshotNode':_0x6cbad};}function tt(_0x2bf7ec,_0xc5c9b5){return{'type':'child_added','snapshotNode':_0xc5c9b5,'childName':_0x2bf7ec};}function Nt(_0x209d21,_0x2e755e){return{'type':'child_removed','snapshotNode':_0x2e755e,'childName':_0x209d21};}function Pt(_0x511f66,_0x906f08,_0x5460f7){return{'type':'child_changed','snapshotNode':_0x906f08,'childName':_0x511f66,'oldSnap':_0x5460f7};}function $h(_0xc92ecc,_0x511fed){return{'type':'child_moved','snapshotNode':_0x511fed,'childName':_0xc92ecc};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x33667d){this['index_']=_0x33667d;}['updateChild'](_0x5eb6bb,_0x3c28c5,_0x1df5a1,_0x44f368,_0x49a03f,_0x599633){f(_0x5eb6bb['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x5b2d59=_0x5eb6bb['getImmediateChild'](_0x3c28c5);return _0x5b2d59['getChild'](_0x44f368)['equals'](_0x1df5a1['getChild'](_0x44f368))&&_0x5b2d59['isEmpty']()===_0x1df5a1['isEmpty']()||(_0x599633!=null&&(_0x1df5a1['isEmpty']()?_0x5eb6bb['hasChild'](_0x3c28c5)?_0x599633['trackChildChange'](Nt(_0x3c28c5,_0x5b2d59)):f(_0x5eb6bb['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x5b2d59['isEmpty']()?_0x599633['trackChildChange'](tt(_0x3c28c5,_0x1df5a1)):_0x599633['trackChildChange'](Pt(_0x3c28c5,_0x1df5a1,_0x5b2d59))),_0x5eb6bb['isLeafNode']()&&_0x1df5a1['isEmpty']())?_0x5eb6bb:_0x5eb6bb['updateImmediateChild'](_0x3c28c5,_0x1df5a1)['withIndex'](this['index_']);}['updateFullNode'](_0x5a9c1d,_0x2f0fd1,_0x2d9684){return _0x2d9684!=null&&(_0x5a9c1d['isLeafNode']()||_0x5a9c1d['forEachChild'](R,(_0x4c9b41,_0x417406)=>{_0x2f0fd1['hasChild'](_0x4c9b41)||_0x2d9684['trackChildChange'](Nt(_0x4c9b41,_0x417406));}),_0x2f0fd1['isLeafNode']()||_0x2f0fd1['forEachChild'](R,(_0x7406d2,_0x373647)=>{if(_0x5a9c1d['hasChild'](_0x7406d2)){const _0x57e395=_0x5a9c1d['getImmediateChild'](_0x7406d2);_0x57e395['equals'](_0x373647)||_0x2d9684['trackChildChange'](Pt(_0x7406d2,_0x373647,_0x57e395));}else _0x2d9684['trackChildChange'](tt(_0x7406d2,_0x373647));})),_0x2f0fd1['withIndex'](this['index_']);}['updatePriority'](_0x2e75e4,_0x55ec64){return _0x2e75e4['isEmpty']()?g['EMPTY_NODE']:_0x2e75e4['updatePriority'](_0x55ec64);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0xbeb72a){this['indexedFilter_']=new Yi(_0xbeb72a['getIndex']()),this['index_']=_0xbeb72a['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0xbeb72a),this['endPost_']=Ot['getEndPost_'](_0xbeb72a),this['startIsInclusive_']=!_0xbeb72a['startAfterSet_'],this['endIsInclusive_']=!_0xbeb72a['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x136a39){const _0x10dec5=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x136a39)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x136a39)<0x0,_0x5dc7ae=this['endIsInclusive_']?this['index_']['compare'](_0x136a39,this['getEndPost']())<=0x0:this['index_']['compare'](_0x136a39,this['getEndPost']())<0x0;return _0x10dec5&&_0x5dc7ae;}['updateChild'](_0xe630c6,_0x2c6171,_0x232ad6,_0x41db3c,_0x45b0e5,_0x1111c8){return this['matches'](new E(_0x2c6171,_0x232ad6))||(_0x232ad6=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0xe630c6,_0x2c6171,_0x232ad6,_0x41db3c,_0x45b0e5,_0x1111c8);}['updateFullNode'](_0x9303ac,_0x463c49,_0x477af9){_0x463c49['isLeafNode']()&&(_0x463c49=g['EMPTY_NODE']);let _0x43b96c=_0x463c49['withIndex'](this['index_']);_0x43b96c=_0x43b96c['updatePriority'](g['EMPTY_NODE']);const _0x4a92cb=this;return _0x463c49['forEachChild'](R,(_0xdd69d2,_0x3724f9)=>{_0x4a92cb['matches'](new E(_0xdd69d2,_0x3724f9))||(_0x43b96c=_0x43b96c['updateImmediateChild'](_0xdd69d2,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x9303ac,_0x43b96c,_0x477af9);}['updatePriority'](_0x5d7877,_0x40ede7){return _0x5d7877;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4ed346){if(_0x4ed346['hasStart']()){const _0x2f9058=_0x4ed346['getIndexStartName']();return _0x4ed346['getIndex']()['makePost'](_0x4ed346['getIndexStartValue'](),_0x2f9058);}else return _0x4ed346['getIndex']()['minPost']();}static['getEndPost_'](_0x37a08b){if(_0x37a08b['hasEnd']()){const _0x43d490=_0x37a08b['getIndexEndName']();return _0x37a08b['getIndex']()['makePost'](_0x37a08b['getIndexEndValue'](),_0x43d490);}else return _0x37a08b['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x17f2fe){this['withinDirectionalStart']=_0x27c708=>this['reverse_']?this['withinEndPost'](_0x27c708):this['withinStartPost'](_0x27c708),this['withinDirectionalEnd']=_0x43edb3=>this['reverse_']?this['withinStartPost'](_0x43edb3):this['withinEndPost'](_0x43edb3),this['withinStartPost']=_0x2cbbc5=>{const _0x2a602d=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x2cbbc5);return this['startIsInclusive_']?_0x2a602d<=0x0:_0x2a602d<0x0;},this['withinEndPost']=_0x38f71c=>{const _0x4ff73f=this['index_']['compare'](_0x38f71c,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4ff73f<=0x0:_0x4ff73f<0x0;},this['rangedFilter_']=new Ot(_0x17f2fe),this['index_']=_0x17f2fe['getIndex'](),this['limit_']=_0x17f2fe['getLimit'](),this['reverse_']=!_0x17f2fe['isViewFromLeft'](),this['startIsInclusive_']=!_0x17f2fe['startAfterSet_'],this['endIsInclusive_']=!_0x17f2fe['endBeforeSet_'];}['updateChild'](_0x324e08,_0x357308,_0x2a1ebd,_0xca46f,_0x2e697f,_0x3fb699){return this['rangedFilter_']['matches'](new E(_0x357308,_0x2a1ebd))||(_0x2a1ebd=g['EMPTY_NODE']),_0x324e08['getImmediateChild'](_0x357308)['equals'](_0x2a1ebd)?_0x324e08:_0x324e08['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x324e08,_0x357308,_0x2a1ebd,_0xca46f,_0x2e697f,_0x3fb699):this['fullLimitUpdateChild_'](_0x324e08,_0x357308,_0x2a1ebd,_0x2e697f,_0x3fb699);}['updateFullNode'](_0x45fa5c,_0x2dcacb,_0x11391f){let _0x5c8eca;if(_0x2dcacb['isLeafNode']()||_0x2dcacb['isEmpty']())_0x5c8eca=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2dcacb['numChildren']()&&_0x2dcacb['isIndexed'](this['index_'])){_0x5c8eca=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x336a51;this['reverse_']?_0x336a51=_0x2dcacb['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x336a51=_0x2dcacb['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x58f605=0x0;for(;_0x336a51['hasNext']()&&_0x58f605<this['limit_'];){const _0x563a71=_0x336a51['getNext']();if(this['withinDirectionalStart'](_0x563a71)){if(this['withinDirectionalEnd'](_0x563a71))_0x5c8eca=_0x5c8eca['updateImmediateChild'](_0x563a71['name'],_0x563a71['node']),_0x58f605++;else break;}else continue;}}else{_0x5c8eca=_0x2dcacb['withIndex'](this['index_']),_0x5c8eca=_0x5c8eca['updatePriority'](g['EMPTY_NODE']);let _0x562b95;this['reverse_']?_0x562b95=_0x5c8eca['getReverseIterator'](this['index_']):_0x562b95=_0x5c8eca['getIterator'](this['index_']);let _0x57ece1=0x0;for(;_0x562b95['hasNext']();){const _0x3710a3=_0x562b95['getNext']();_0x57ece1<this['limit_']&&this['withinDirectionalStart'](_0x3710a3)&&this['withinDirectionalEnd'](_0x3710a3)?_0x57ece1++:_0x5c8eca=_0x5c8eca['updateImmediateChild'](_0x3710a3['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x45fa5c,_0x5c8eca,_0x11391f);}['updatePriority'](_0x2c337,_0x27b774){return _0x2c337;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x15a69d,_0x224472,_0x3731b1,_0x2b23d4,_0x26248f){let _0x3948ca;if(this['reverse_']){const _0x5986f4=this['index_']['getCompare']();_0x3948ca=(_0x5c483b,_0x30b994)=>_0x5986f4(_0x30b994,_0x5c483b);}else _0x3948ca=this['index_']['getCompare']();const _0x3fbf27=_0x15a69d;f(_0x3fbf27['numChildren']()===this['limit_'],'');const _0x44d161=new E(_0x224472,_0x3731b1),_0x13d0e1=this['reverse_']?_0x3fbf27['getFirstChild'](this['index_']):_0x3fbf27['getLastChild'](this['index_']),_0x3983d0=this['rangedFilter_']['matches'](_0x44d161);if(_0x3fbf27['hasChild'](_0x224472)){const _0x3f66a7=_0x3fbf27['getImmediateChild'](_0x224472);let _0x53c02b=_0x2b23d4['getChildAfterChild'](this['index_'],_0x13d0e1,this['reverse_']);for(;_0x53c02b!=null&&(_0x53c02b['name']===_0x224472||_0x3fbf27['hasChild'](_0x53c02b['name']));)_0x53c02b=_0x2b23d4['getChildAfterChild'](this['index_'],_0x53c02b,this['reverse_']);const _0x2cd490=_0x53c02b==null?0x1:_0x3948ca(_0x53c02b,_0x44d161);if(_0x3983d0&&!_0x3731b1['isEmpty']()&&_0x2cd490>=0x0)return _0x26248f!=null&&_0x26248f['trackChildChange'](Pt(_0x224472,_0x3731b1,_0x3f66a7)),_0x3fbf27['updateImmediateChild'](_0x224472,_0x3731b1);{_0x26248f!=null&&_0x26248f['trackChildChange'](Nt(_0x224472,_0x3f66a7));const _0x3cb810=_0x3fbf27['updateImmediateChild'](_0x224472,g['EMPTY_NODE']);return _0x53c02b!=null&&this['rangedFilter_']['matches'](_0x53c02b)?(_0x26248f!=null&&_0x26248f['trackChildChange'](tt(_0x53c02b['name'],_0x53c02b['node'])),_0x3cb810['updateImmediateChild'](_0x53c02b['name'],_0x53c02b['node'])):_0x3cb810;}}else return _0x3731b1['isEmpty']()?_0x15a69d:_0x3983d0&&_0x3948ca(_0x13d0e1,_0x44d161)>=0x0?(_0x26248f!=null&&(_0x26248f['trackChildChange'](Nt(_0x13d0e1['name'],_0x13d0e1['node'])),_0x26248f['trackChildChange'](tt(_0x224472,_0x3731b1))),_0x3fbf27['updateImmediateChild'](_0x224472,_0x3731b1)['updateImmediateChild'](_0x13d0e1['name'],g['EMPTY_NODE'])):_0x15a69d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0xe86778=new Qi();return _0xe86778['limitSet_']=this['limitSet_'],_0xe86778['limit_']=this['limit_'],_0xe86778['startSet_']=this['startSet_'],_0xe86778['startAfterSet_']=this['startAfterSet_'],_0xe86778['indexStartValue_']=this['indexStartValue_'],_0xe86778['startNameSet_']=this['startNameSet_'],_0xe86778['indexStartName_']=this['indexStartName_'],_0xe86778['endSet_']=this['endSet_'],_0xe86778['endBeforeSet_']=this['endBeforeSet_'],_0xe86778['indexEndValue_']=this['indexEndValue_'],_0xe86778['endNameSet_']=this['endNameSet_'],_0xe86778['indexEndName_']=this['indexEndName_'],_0xe86778['index_']=this['index_'],_0xe86778['viewFrom_']=this['viewFrom_'],_0xe86778;}}function qh(_0x213537){return _0x213537['loadsAllData']()?new Yi(_0x213537['getIndex']()):_0x213537['hasLimit']()?new Gh(_0x213537):new Ot(_0x213537);}function zh(_0x3d649b,_0x2a5998){const _0x17ef28=_0x3d649b['copy']();return _0x17ef28['limitSet_']=!0x0,_0x17ef28['limit_']=_0x2a5998,_0x17ef28['viewFrom_']='l',_0x17ef28;}function jh(_0x2e4805,_0x4b2e5b,_0xde810e){const _0x13b380=_0x2e4805['copy']();return _0x13b380['startSet_']=!0x0,_0x4b2e5b===void 0x0&&(_0x4b2e5b=null),_0x13b380['indexStartValue_']=_0x4b2e5b,_0xde810e!=null?(_0x13b380['startNameSet_']=!0x0,_0x13b380['indexStartName_']=_0xde810e):(_0x13b380['startNameSet_']=!0x1,_0x13b380['indexStartName_']=''),_0x13b380;}function Kh(_0xa878fe,_0x1558b7,_0x59c7be){const _0xa0b747=_0xa878fe['copy']();return _0xa0b747['endSet_']=!0x0,_0x1558b7===void 0x0&&(_0x1558b7=null),_0xa0b747['indexEndValue_']=_0x1558b7,_0x59c7be!==void 0x0?(_0xa0b747['endNameSet_']=!0x0,_0xa0b747['indexEndName_']=_0x59c7be):(_0xa0b747['endNameSet_']=!0x1,_0xa0b747['indexEndName_']=''),_0xa0b747;}function Do(_0x3e2010,_0x44c9ec){const _0x5e548f=_0x3e2010['copy']();return _0x5e548f['index_']=_0x44c9ec,_0x5e548f;}function tr(_0x19fff6){const _0x27385e={};if(_0x19fff6['isDefault']())return _0x27385e;let _0x5da44f;if(_0x19fff6['index_']===R?_0x5da44f='$priority':_0x19fff6['index_']===Po?_0x5da44f='$value':_0x19fff6['index_']===ye?_0x5da44f='$key':(f(_0x19fff6['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x5da44f=_0x19fff6['index_']['toString']()),_0x27385e['orderBy']=O(_0x5da44f),_0x19fff6['startSet_']){const _0x1ab080=_0x19fff6['startAfterSet_']?'startAfter':'startAt';_0x27385e[_0x1ab080]=O(_0x19fff6['indexStartValue_']),_0x19fff6['startNameSet_']&&(_0x27385e[_0x1ab080]+=','+O(_0x19fff6['indexStartName_']));}if(_0x19fff6['endSet_']){const _0x3836d1=_0x19fff6['endBeforeSet_']?'endBefore':'endAt';_0x27385e[_0x3836d1]=O(_0x19fff6['indexEndValue_']),_0x19fff6['endNameSet_']&&(_0x27385e[_0x3836d1]+=','+O(_0x19fff6['indexEndName_']));}return _0x19fff6['limitSet_']&&(_0x19fff6['isViewFromLeft']()?_0x27385e['limitToFirst']=_0x19fff6['limit_']:_0x27385e['limitToLast']=_0x19fff6['limit_']),_0x27385e;}function nr(_0x896944){const _0x46ac87={};if(_0x896944['startSet_']&&(_0x46ac87['sp']=_0x896944['indexStartValue_'],_0x896944['startNameSet_']&&(_0x46ac87['sn']=_0x896944['indexStartName_']),_0x46ac87['sin']=!_0x896944['startAfterSet_']),_0x896944['endSet_']&&(_0x46ac87['ep']=_0x896944['indexEndValue_'],_0x896944['endNameSet_']&&(_0x46ac87['en']=_0x896944['indexEndName_']),_0x46ac87['ein']=!_0x896944['endBeforeSet_']),_0x896944['limitSet_']){_0x46ac87['l']=_0x896944['limit_'];let _0x176f69=_0x896944['viewFrom_'];_0x176f69===''&&(_0x896944['isViewFromLeft']()?_0x176f69='l':_0x176f69='r'),_0x46ac87['vf']=_0x176f69;}return _0x896944['index_']!==R&&(_0x46ac87['i']=_0x896944['index_']['toString']()),_0x46ac87;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x58586b){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x55bf7f,_0x101634){return _0x101634!==void 0x0?'tag$'+_0x101634:(f(_0x55bf7f['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x55bf7f['_path']['toString']());}constructor(_0x452d4d,_0x3634cb,_0x19a271,_0x584e55){super(),this['repoInfo_']=_0x452d4d,this['onDataUpdate_']=_0x3634cb,this['authTokenProvider_']=_0x19a271,this['appCheckTokenProvider_']=_0x584e55,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x58dfcd,_0x56f0f3,_0x4ce010,_0x1593e5){const _0x423123=_0x58dfcd['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x423123+'\x20'+_0x58dfcd['_queryIdentifier']);const _0x1d6ae4=fn['getListenId_'](_0x58dfcd,_0x4ce010),_0x440fe1={};this['listens_'][_0x1d6ae4]=_0x440fe1;const _0x2c7744=tr(_0x58dfcd['_queryParams']);this['restRequest_'](_0x423123+'.json',_0x2c7744,(_0x5d4130,_0x17660b)=>{let _0x9769e4=_0x17660b;if(_0x5d4130===0x194&&(_0x9769e4=null,_0x5d4130=null),_0x5d4130===null&&this['onDataUpdate_'](_0x423123,_0x9769e4,!0x1,_0x4ce010),Oe(this['listens_'],_0x1d6ae4)===_0x440fe1){let _0x5bc93d;_0x5d4130?_0x5d4130===0x191?_0x5bc93d='permission_denied':_0x5bc93d='rest_error:'+_0x5d4130:_0x5bc93d='ok',_0x1593e5(_0x5bc93d,null);}});}['unlisten'](_0xd38537,_0x29886e){const _0x364f45=fn['getListenId_'](_0xd38537,_0x29886e);delete this['listens_'][_0x364f45];}['get'](_0x359ce2){const _0xba6ab4=tr(_0x359ce2['_queryParams']),_0x8def09=_0x359ce2['_path']['toString'](),_0x47b74a=new Ve();return this['restRequest_'](_0x8def09+'.json',_0xba6ab4,(_0x2aaf12,_0x1898f3)=>{let _0x1c50d1=_0x1898f3;_0x2aaf12===0x194&&(_0x1c50d1=null,_0x2aaf12=null),_0x2aaf12===null?(this['onDataUpdate_'](_0x8def09,_0x1c50d1,!0x1,null),_0x47b74a['resolve'](_0x1c50d1)):_0x47b74a['reject'](new Error(_0x1c50d1));}),_0x47b74a['promise'];}['refreshAuthToken'](_0x439f30){}['restRequest_'](_0x5ce013,_0x196680={},_0xcf9b51){return _0x196680['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2f1885,_0x138dca])=>{_0x2f1885&&_0x2f1885['accessToken']&&(_0x196680['auth']=_0x2f1885['accessToken']),_0x138dca&&_0x138dca['token']&&(_0x196680['ac']=_0x138dca['token']);const _0xff9086=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5ce013+'?ns='+this['repoInfo_']['namespace']+at(_0x196680);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xff9086);const _0x14392d=new XMLHttpRequest();_0x14392d['onreadystatechange']=()=>{if(_0xcf9b51&&_0x14392d['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xff9086+'\x20received.\x20status:',_0x14392d['status'],'response:',_0x14392d['responseText']);let _0x175578=null;if(_0x14392d['status']>=0xc8&&_0x14392d['status']<0x12c){try{_0x175578=bt(_0x14392d['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xff9086+':\x20'+_0x14392d['responseText']);}_0xcf9b51(null,_0x175578);}else _0x14392d['status']!==0x191&&_0x14392d['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xff9086+'\x20Status:\x20'+_0x14392d['status']),_0xcf9b51(_0x14392d['status']);_0xcf9b51=null;}},_0x14392d['open']('GET',_0xff9086,!0x0),_0x14392d['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x559c40){return this['rootNode_']['getChild'](_0x559c40);}['updateSnapshot'](_0x31aa1c,_0x4babc2){this['rootNode_']=this['rootNode_']['updateChild'](_0x31aa1c,_0x4babc2);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x41e731,_0x38dfa3,_0x35547d){if(v(_0x38dfa3))_0x41e731['value']=_0x35547d,_0x41e731['children']['clear']();else{if(_0x41e731['value']!==null)_0x41e731['value']=_0x41e731['value']['updateChild'](_0x38dfa3,_0x35547d);else{const _0x3078ea=y(_0x38dfa3);_0x41e731['children']['has'](_0x3078ea)||_0x41e731['children']['set'](_0x3078ea,pn());const _0x4c36b6=_0x41e731['children']['get'](_0x3078ea);_0x38dfa3=b(_0x38dfa3),Mo(_0x4c36b6,_0x38dfa3,_0x35547d);}}}function Ei(_0x36f5b5,_0x434e90,_0x538bf6){_0x36f5b5['value']!==null?_0x538bf6(_0x434e90,_0x36f5b5['value']):Qh(_0x36f5b5,(_0x156cf6,_0x33d343)=>{const _0xd4416e=new C(_0x434e90['toString']()+'/'+_0x156cf6);Ei(_0x33d343,_0xd4416e,_0x538bf6);});}function Qh(_0xea1023,_0x41cd6e){_0xea1023['children']['forEach']((_0x19b96e,_0x4d3175)=>{_0x41cd6e(_0x4d3175,_0x19b96e);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x37a6a2){this['collection_']=_0x37a6a2,this['last_']=null;}['get'](){const _0x3001bb=this['collection_']['get'](),_0x5b7688={..._0x3001bb};return this['last_']&&x(this['last_'],(_0x4facb9,_0x5a3c9f)=>{_0x5b7688[_0x4facb9]=_0x5b7688[_0x4facb9]-_0x5a3c9f;}),this['last_']=_0x3001bb,_0x5b7688;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x2991c2,_0x4a77e4){this['server_']=_0x4a77e4,this['statsToReport_']={},this['statsListener_']=new Jh(_0x2991c2);const _0x333cf1=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x333cf1));}['reportStats_'](){const _0x271e7e=this['statsListener_']['get'](),_0x23b82a={};let _0x148aee=!0x1;x(_0x271e7e,(_0x5be2d4,_0x564ca7)=>{_0x564ca7>0x0&&Y(this['statsToReport_'],_0x5be2d4)&&(_0x23b82a[_0x5be2d4]=_0x564ca7,_0x148aee=!0x0);}),_0x148aee&&this['server_']['reportStats'](_0x23b82a),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x2f8ae8){_0x2f8ae8[_0x2f8ae8['OVERWRITE']=0x0]='OVERWRITE',_0x2f8ae8[_0x2f8ae8['MERGE']=0x1]='MERGE',_0x2f8ae8[_0x2f8ae8['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2f8ae8[_0x2f8ae8['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x96ac27){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x96ac27,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x35ca4c,_0x433fe0,_0x200752){this['path']=_0x35ca4c,this['affectedTree']=_0x433fe0,this['revert']=_0x200752,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0xa61c66){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x1fa037=this['affectedTree']['subtree'](new C(_0xa61c66));return new _n(w(),_0x1fa037,this['revert']);}}else return f(y(this['path'])===_0xa61c66,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x1ae718,_0x653bd9){this['source']=_0x1ae718,this['path']=_0x653bd9,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x43cbdb){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x2d54f9,_0x3632f7,_0x32737c){this['source']=_0x2d54f9,this['path']=_0x3632f7,this['snap']=_0x32737c,this['type']=q['OVERWRITE'];}['operationForChild'](_0x4ccc08){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x4ccc08)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x15ebfa,_0x3e7e6e,_0x414163){this['source']=_0x15ebfa,this['path']=_0x3e7e6e,this['children']=_0x414163,this['type']=q['MERGE'];}['operationForChild'](_0x15935a){if(v(this['path'])){const _0x244b58=this['children']['subtree'](new C(_0x15935a));return _0x244b58['isEmpty']()?null:_0x244b58['value']?new Fe(this['source'],w(),_0x244b58['value']):new nt(this['source'],w(),_0x244b58);}else return f(y(this['path'])===_0x15935a,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0xc855a5,_0x318490,_0xc68c97){this['node_']=_0xc855a5,this['fullyInitialized_']=_0x318490,this['filtered_']=_0xc68c97;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x41388f){if(v(_0x41388f))return this['isFullyInitialized']()&&!this['filtered_'];const _0x590c2b=y(_0x41388f);return this['isCompleteForChild'](_0x590c2b);}['isCompleteForChild'](_0x21e012){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x21e012);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x1ef8b2){this['query_']=_0x1ef8b2,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x2fefd7,_0x3b3e3c,_0x35a6e0,_0x5a54ce){const _0x2cc832=[],_0x320e75=[];return _0x3b3e3c['forEach'](_0x10e38a=>{_0x10e38a['type']==='child_changed'&&_0x2fefd7['index_']['indexedValueChanged'](_0x10e38a['oldSnap'],_0x10e38a['snapshotNode'])&&_0x320e75['push']($h(_0x10e38a['childName'],_0x10e38a['snapshotNode']));}),mt(_0x2fefd7,_0x2cc832,'child_removed',_0x3b3e3c,_0x5a54ce,_0x35a6e0),mt(_0x2fefd7,_0x2cc832,'child_added',_0x3b3e3c,_0x5a54ce,_0x35a6e0),mt(_0x2fefd7,_0x2cc832,'child_moved',_0x320e75,_0x5a54ce,_0x35a6e0),mt(_0x2fefd7,_0x2cc832,'child_changed',_0x3b3e3c,_0x5a54ce,_0x35a6e0),mt(_0x2fefd7,_0x2cc832,'value',_0x3b3e3c,_0x5a54ce,_0x35a6e0),_0x2cc832;}function mt(_0x31408d,_0x59da77,_0x16c2a0,_0x44a92a,_0x52450e,_0x4f4fed){const _0x580d2d=_0x44a92a['filter'](_0x1bdf29=>_0x1bdf29['type']===_0x16c2a0);_0x580d2d['sort']((_0x2ece8f,_0x14a367)=>su(_0x31408d,_0x2ece8f,_0x14a367)),_0x580d2d['forEach'](_0x300756=>{const _0x1aabd0=iu(_0x31408d,_0x300756,_0x4f4fed);_0x52450e['forEach'](_0x4d9178=>{_0x4d9178['respondsTo'](_0x300756['type'])&&_0x59da77['push'](_0x4d9178['createEvent'](_0x1aabd0,_0x31408d['query_']));});});}function iu(_0x5340d7,_0x527c8d,_0x147bb0){return _0x527c8d['type']==='value'||_0x527c8d['type']==='child_removed'||(_0x527c8d['prevName']=_0x147bb0['getPredecessorChildName'](_0x527c8d['childName'],_0x527c8d['snapshotNode'],_0x5340d7['index_'])),_0x527c8d;}function su(_0x26c18d,_0x38a721,_0x245416){if(_0x38a721['childName']==null||_0x245416['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x10ad74=new E(_0x38a721['childName'],_0x38a721['snapshotNode']),_0x4516f2=new E(_0x245416['childName'],_0x245416['snapshotNode']);return _0x26c18d['index_']['compare'](_0x10ad74,_0x4516f2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x28fc47,_0x3ba3ca){return{'eventCache':_0x28fc47,'serverCache':_0x3ba3ca};}function wt(_0x42fe45,_0x1568e9,_0x3831ad,_0x6fadee){return Dn(new Ce(_0x1568e9,_0x3831ad,_0x6fadee),_0x42fe45['serverCache']);}function Lo(_0x5c3562,_0x216f17,_0x3c0c40,_0x2e4fcf){return Dn(_0x5c3562['eventCache'],new Ce(_0x216f17,_0x3c0c40,_0x2e4fcf));}function gn(_0x7cd6db){return _0x7cd6db['eventCache']['isFullyInitialized']()?_0x7cd6db['eventCache']['getNode']():null;}function Ue(_0x4ad784){return _0x4ad784['serverCache']['isFullyInitialized']()?_0x4ad784['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x4f0f74){let _0x5c1663=new S(null);return x(_0x4f0f74,(_0x2d3be3,_0x362046)=>{_0x5c1663=_0x5c1663['set'](new C(_0x2d3be3),_0x362046);}),_0x5c1663;}constructor(_0x29b053,_0x1442e4=ru()){this['value']=_0x29b053,this['children']=_0x1442e4;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xc4baa3,_0x134f53){if(this['value']!=null&&_0x134f53(this['value']))return{'path':w(),'value':this['value']};if(v(_0xc4baa3))return null;{const _0x3143f8=y(_0xc4baa3),_0x25c68d=this['children']['get'](_0x3143f8);if(_0x25c68d!==null){const _0x97d791=_0x25c68d['findRootMostMatchingPathAndValue'](b(_0xc4baa3),_0x134f53);return _0x97d791!=null?{'path':A(new C(_0x3143f8),_0x97d791['path']),'value':_0x97d791['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4b396c){return this['findRootMostMatchingPathAndValue'](_0x4b396c,()=>!0x0);}['subtree'](_0x496632){if(v(_0x496632))return this;{const _0x8f30d2=y(_0x496632),_0x3dbbbe=this['children']['get'](_0x8f30d2);return _0x3dbbbe!==null?_0x3dbbbe['subtree'](b(_0x496632)):new S(null);}}['set'](_0x370198,_0x2fc098){if(v(_0x370198))return new S(_0x2fc098,this['children']);{const _0x23be5e=y(_0x370198),_0xed1fce=(this['children']['get'](_0x23be5e)||new S(null))['set'](b(_0x370198),_0x2fc098),_0x1c4a88=this['children']['insert'](_0x23be5e,_0xed1fce);return new S(this['value'],_0x1c4a88);}}['remove'](_0x44d986){if(v(_0x44d986))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x144434=y(_0x44d986),_0x390d62=this['children']['get'](_0x144434);if(_0x390d62){const _0x3b2ada=_0x390d62['remove'](b(_0x44d986));let _0x859f8;return _0x3b2ada['isEmpty']()?_0x859f8=this['children']['remove'](_0x144434):_0x859f8=this['children']['insert'](_0x144434,_0x3b2ada),this['value']===null&&_0x859f8['isEmpty']()?new S(null):new S(this['value'],_0x859f8);}else return this;}}['get'](_0x5aa0ce){if(v(_0x5aa0ce))return this['value'];{const _0x158871=y(_0x5aa0ce),_0x424335=this['children']['get'](_0x158871);return _0x424335?_0x424335['get'](b(_0x5aa0ce)):null;}}['setTree'](_0x227f5a,_0x350bce){if(v(_0x227f5a))return _0x350bce;{const _0x377371=y(_0x227f5a),_0x1268f7=(this['children']['get'](_0x377371)||new S(null))['setTree'](b(_0x227f5a),_0x350bce);let _0xc8144;return _0x1268f7['isEmpty']()?_0xc8144=this['children']['remove'](_0x377371):_0xc8144=this['children']['insert'](_0x377371,_0x1268f7),new S(this['value'],_0xc8144);}}['fold'](_0x5e9459){return this['fold_'](w(),_0x5e9459);}['fold_'](_0x639caf,_0x6db5c1){const _0x6d51ca={};return this['children']['inorderTraversal']((_0x3f3e49,_0x2ac9d0)=>{_0x6d51ca[_0x3f3e49]=_0x2ac9d0['fold_'](A(_0x639caf,_0x3f3e49),_0x6db5c1);}),_0x6db5c1(_0x639caf,this['value'],_0x6d51ca);}['findOnPath'](_0x167a36,_0x1c98a7){return this['findOnPath_'](_0x167a36,w(),_0x1c98a7);}['findOnPath_'](_0x5f0e3f,_0x231727,_0x40a956){const _0x1025f8=this['value']?_0x40a956(_0x231727,this['value']):!0x1;if(_0x1025f8)return _0x1025f8;if(v(_0x5f0e3f))return null;{const _0x17455b=y(_0x5f0e3f),_0x1da710=this['children']['get'](_0x17455b);return _0x1da710?_0x1da710['findOnPath_'](b(_0x5f0e3f),A(_0x231727,_0x17455b),_0x40a956):null;}}['foreachOnPath'](_0xc0405e,_0x24d9a9){return this['foreachOnPath_'](_0xc0405e,w(),_0x24d9a9);}['foreachOnPath_'](_0x5a67c5,_0x3831eb,_0x240a21){if(v(_0x5a67c5))return this;{this['value']&&_0x240a21(_0x3831eb,this['value']);const _0x59d87e=y(_0x5a67c5),_0x40b405=this['children']['get'](_0x59d87e);return _0x40b405?_0x40b405['foreachOnPath_'](b(_0x5a67c5),A(_0x3831eb,_0x59d87e),_0x240a21):new S(null);}}['foreach'](_0xaede9d){this['foreach_'](w(),_0xaede9d);}['foreach_'](_0x1393bf,_0x26e1ec){this['children']['inorderTraversal']((_0x1215ad,_0x2793b7)=>{_0x2793b7['foreach_'](A(_0x1393bf,_0x1215ad),_0x26e1ec);}),this['value']&&_0x26e1ec(_0x1393bf,this['value']);}['foreachChild'](_0xd907bb){this['children']['inorderTraversal']((_0xb7cf32,_0x162459)=>{_0x162459['value']&&_0xd907bb(_0xb7cf32,_0x162459['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x400587){this['writeTree_']=_0x400587;}static['empty'](){return new j(new S(null));}}function Ct(_0x37196c,_0x118684,_0x27abee){if(v(_0x118684))return new j(new S(_0x27abee));{const _0x246ba9=_0x37196c['writeTree_']['findRootMostValueAndPath'](_0x118684);if(_0x246ba9!=null){const _0x359496=_0x246ba9['path'];let _0x25a4f6=_0x246ba9['value'];const _0x32bd40=F(_0x359496,_0x118684);return _0x25a4f6=_0x25a4f6['updateChild'](_0x32bd40,_0x27abee),new j(_0x37196c['writeTree_']['set'](_0x359496,_0x25a4f6));}else{const _0x4c8bcc=new S(_0x27abee),_0x198caf=_0x37196c['writeTree_']['setTree'](_0x118684,_0x4c8bcc);return new j(_0x198caf);}}}function Ii(_0xd0c09a,_0xa23167,_0x3c56fd){let _0x2ea0df=_0xd0c09a;return x(_0x3c56fd,(_0x55cc16,_0x5b48e8)=>{_0x2ea0df=Ct(_0x2ea0df,A(_0xa23167,_0x55cc16),_0x5b48e8);}),_0x2ea0df;}function sr(_0x532a9a,_0x218f21){if(v(_0x218f21))return j['empty']();{const _0x4b472d=_0x532a9a['writeTree_']['setTree'](_0x218f21,new S(null));return new j(_0x4b472d);}}function wi(_0x10e07b,_0x20aec1){return $e(_0x10e07b,_0x20aec1)!=null;}function $e(_0x331cf5,_0x1864d5){const _0xadd70e=_0x331cf5['writeTree_']['findRootMostValueAndPath'](_0x1864d5);return _0xadd70e!=null?_0x331cf5['writeTree_']['get'](_0xadd70e['path'])['getChild'](F(_0xadd70e['path'],_0x1864d5)):null;}function rr(_0x50680e){const _0x1daa82=[],_0x16caa1=_0x50680e['writeTree_']['value'];return _0x16caa1!=null?_0x16caa1['isLeafNode']()||_0x16caa1['forEachChild'](R,(_0x1aa621,_0x29a043)=>{_0x1daa82['push'](new E(_0x1aa621,_0x29a043));}):_0x50680e['writeTree_']['children']['inorderTraversal']((_0x16452d,_0x493b6f)=>{_0x493b6f['value']!=null&&_0x1daa82['push'](new E(_0x16452d,_0x493b6f['value']));}),_0x1daa82;}function ve(_0xc76ab,_0x254de3){if(v(_0x254de3))return _0xc76ab;{const _0x2e0f0a=$e(_0xc76ab,_0x254de3);return _0x2e0f0a!=null?new j(new S(_0x2e0f0a)):new j(_0xc76ab['writeTree_']['subtree'](_0x254de3));}}function Ci(_0x507a80){return _0x507a80['writeTree_']['isEmpty']();}function it(_0x449137,_0xffc3c){return xo(w(),_0x449137['writeTree_'],_0xffc3c);}function xo(_0x50ca4f,_0x39532c,_0x4725e8){if(_0x39532c['value']!=null)return _0x4725e8['updateChild'](_0x50ca4f,_0x39532c['value']);{let _0x2fb7c7=null;return _0x39532c['children']['inorderTraversal']((_0x25c422,_0xdb1182)=>{_0x25c422==='.priority'?(f(_0xdb1182['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2fb7c7=_0xdb1182['value']):_0x4725e8=xo(A(_0x50ca4f,_0x25c422),_0xdb1182,_0x4725e8);}),!_0x4725e8['getChild'](_0x50ca4f)['isEmpty']()&&_0x2fb7c7!==null&&(_0x4725e8=_0x4725e8['updateChild'](A(_0x50ca4f,'.priority'),_0x2fb7c7)),_0x4725e8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x193faa,_0x1bccd9){return Bo(_0x1bccd9,_0x193faa);}function ou(_0x55ae5d,_0x2c33fa,_0x4c27ce,_0x1103a2,_0x19f1b8){f(_0x1103a2>_0x55ae5d['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x19f1b8===void 0x0&&(_0x19f1b8=!0x0),_0x55ae5d['allWrites']['push']({'path':_0x2c33fa,'snap':_0x4c27ce,'writeId':_0x1103a2,'visible':_0x19f1b8}),_0x19f1b8&&(_0x55ae5d['visibleWrites']=Ct(_0x55ae5d['visibleWrites'],_0x2c33fa,_0x4c27ce)),_0x55ae5d['lastWriteId']=_0x1103a2;}function au(_0x27955d,_0x3c96f0,_0x37abeb,_0x26b913){f(_0x26b913>_0x27955d['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x27955d['allWrites']['push']({'path':_0x3c96f0,'children':_0x37abeb,'writeId':_0x26b913,'visible':!0x0}),_0x27955d['visibleWrites']=Ii(_0x27955d['visibleWrites'],_0x3c96f0,_0x37abeb),_0x27955d['lastWriteId']=_0x26b913;}function cu(_0x5e4ca5,_0x24f41a){for(let _0x3328ff=0x0;_0x3328ff<_0x5e4ca5['allWrites']['length'];_0x3328ff++){const _0x2839a1=_0x5e4ca5['allWrites'][_0x3328ff];if(_0x2839a1['writeId']===_0x24f41a)return _0x2839a1;}return null;}function lu(_0x562afc,_0x3ea190){const _0x6d54e6=_0x562afc['allWrites']['findIndex'](_0x3f361b=>_0x3f361b['writeId']===_0x3ea190);f(_0x6d54e6>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xc3de3b=_0x562afc['allWrites'][_0x6d54e6];_0x562afc['allWrites']['splice'](_0x6d54e6,0x1);let _0x56e666=_0xc3de3b['visible'],_0x2bd39f=!0x1,_0xefc5f7=_0x562afc['allWrites']['length']-0x1;for(;_0x56e666&&_0xefc5f7>=0x0;){const _0x40798c=_0x562afc['allWrites'][_0xefc5f7];_0x40798c['visible']&&(_0xefc5f7>=_0x6d54e6&&hu(_0x40798c,_0xc3de3b['path'])?_0x56e666=!0x1:$(_0xc3de3b['path'],_0x40798c['path'])&&(_0x2bd39f=!0x0)),_0xefc5f7--;}if(_0x56e666){if(_0x2bd39f)return uu(_0x562afc),!0x0;if(_0xc3de3b['snap'])_0x562afc['visibleWrites']=sr(_0x562afc['visibleWrites'],_0xc3de3b['path']);else{const _0x3d5f91=_0xc3de3b['children'];x(_0x3d5f91,_0x2f5d78=>{_0x562afc['visibleWrites']=sr(_0x562afc['visibleWrites'],A(_0xc3de3b['path'],_0x2f5d78));});}return!0x0;}else return!0x1;}function hu(_0x1b3bcc,_0x3e732c){if(_0x1b3bcc['snap'])return $(_0x1b3bcc['path'],_0x3e732c);for(const _0x3d274d in _0x1b3bcc['children'])if(_0x1b3bcc['children']['hasOwnProperty'](_0x3d274d)&&$(A(_0x1b3bcc['path'],_0x3d274d),_0x3e732c))return!0x0;return!0x1;}function uu(_0x4b46d8){_0x4b46d8['visibleWrites']=Fo(_0x4b46d8['allWrites'],du,w()),_0x4b46d8['allWrites']['length']>0x0?_0x4b46d8['lastWriteId']=_0x4b46d8['allWrites'][_0x4b46d8['allWrites']['length']-0x1]['writeId']:_0x4b46d8['lastWriteId']=-0x1;}function du(_0x36cbad){return _0x36cbad['visible'];}function Fo(_0x37eb45,_0xdab98b,_0x3c8a67){let _0xc2023e=j['empty']();for(let _0x155ddf=0x0;_0x155ddf<_0x37eb45['length'];++_0x155ddf){const _0x5b4d3d=_0x37eb45[_0x155ddf];if(_0xdab98b(_0x5b4d3d)){const _0x34dccd=_0x5b4d3d['path'];let _0x150869;if(_0x5b4d3d['snap'])$(_0x3c8a67,_0x34dccd)?(_0x150869=F(_0x3c8a67,_0x34dccd),_0xc2023e=Ct(_0xc2023e,_0x150869,_0x5b4d3d['snap'])):$(_0x34dccd,_0x3c8a67)&&(_0x150869=F(_0x34dccd,_0x3c8a67),_0xc2023e=Ct(_0xc2023e,w(),_0x5b4d3d['snap']['getChild'](_0x150869)));else{if(_0x5b4d3d['children']){if($(_0x3c8a67,_0x34dccd))_0x150869=F(_0x3c8a67,_0x34dccd),_0xc2023e=Ii(_0xc2023e,_0x150869,_0x5b4d3d['children']);else{if($(_0x34dccd,_0x3c8a67)){if(_0x150869=F(_0x34dccd,_0x3c8a67),v(_0x150869))_0xc2023e=Ii(_0xc2023e,w(),_0x5b4d3d['children']);else{const _0x5b5580=Oe(_0x5b4d3d['children'],y(_0x150869));if(_0x5b5580){const _0x3ef1af=_0x5b5580['getChild'](b(_0x150869));_0xc2023e=Ct(_0xc2023e,w(),_0x3ef1af);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0xc2023e;}function Uo(_0xcc6457,_0xbc0727,_0x439c1a,_0x132fd0,_0x644e4f){if(!_0x132fd0&&!_0x644e4f){const _0x54d761=$e(_0xcc6457['visibleWrites'],_0xbc0727);if(_0x54d761!=null)return _0x54d761;{const _0xc4af46=ve(_0xcc6457['visibleWrites'],_0xbc0727);if(Ci(_0xc4af46))return _0x439c1a;if(_0x439c1a==null&&!wi(_0xc4af46,w()))return null;{const _0x501257=_0x439c1a||g['EMPTY_NODE'];return it(_0xc4af46,_0x501257);}}}else{const _0x2fb901=ve(_0xcc6457['visibleWrites'],_0xbc0727);if(!_0x644e4f&&Ci(_0x2fb901))return _0x439c1a;if(!_0x644e4f&&_0x439c1a==null&&!wi(_0x2fb901,w()))return null;{const _0x172d72=function(_0x1f93d7){return(_0x1f93d7['visible']||_0x644e4f)&&(!_0x132fd0||!~_0x132fd0['indexOf'](_0x1f93d7['writeId']))&&($(_0x1f93d7['path'],_0xbc0727)||$(_0xbc0727,_0x1f93d7['path']));},_0x1480e6=Fo(_0xcc6457['allWrites'],_0x172d72,_0xbc0727),_0x400534=_0x439c1a||g['EMPTY_NODE'];return it(_0x1480e6,_0x400534);}}}function fu(_0x174b9c,_0x27dcb0,_0x52c9ad){let _0x10013f=g['EMPTY_NODE'];const _0x5bcb45=$e(_0x174b9c['visibleWrites'],_0x27dcb0);if(_0x5bcb45)return _0x5bcb45['isLeafNode']()||_0x5bcb45['forEachChild'](R,(_0x489037,_0x391d11)=>{_0x10013f=_0x10013f['updateImmediateChild'](_0x489037,_0x391d11);}),_0x10013f;if(_0x52c9ad){const _0x45cc1e=ve(_0x174b9c['visibleWrites'],_0x27dcb0);return _0x52c9ad['forEachChild'](R,(_0x2c743a,_0x2e986d)=>{const _0x136a7e=it(ve(_0x45cc1e,new C(_0x2c743a)),_0x2e986d);_0x10013f=_0x10013f['updateImmediateChild'](_0x2c743a,_0x136a7e);}),rr(_0x45cc1e)['forEach'](_0x3251e3=>{_0x10013f=_0x10013f['updateImmediateChild'](_0x3251e3['name'],_0x3251e3['node']);}),_0x10013f;}else{const _0x47ad46=ve(_0x174b9c['visibleWrites'],_0x27dcb0);return rr(_0x47ad46)['forEach'](_0x460df0=>{_0x10013f=_0x10013f['updateImmediateChild'](_0x460df0['name'],_0x460df0['node']);}),_0x10013f;}}function pu(_0x474404,_0x57c817,_0x13831b,_0x3ea2c0,_0x24914a){f(_0x3ea2c0||_0x24914a,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x115739=A(_0x57c817,_0x13831b);if(wi(_0x474404['visibleWrites'],_0x115739))return null;{const _0x1b32a8=ve(_0x474404['visibleWrites'],_0x115739);return Ci(_0x1b32a8)?_0x24914a['getChild'](_0x13831b):it(_0x1b32a8,_0x24914a['getChild'](_0x13831b));}}function _u(_0x539ec8,_0x195e5d,_0x310277,_0x33b4bd){const _0x414fd2=A(_0x195e5d,_0x310277),_0x621a26=$e(_0x539ec8['visibleWrites'],_0x414fd2);if(_0x621a26!=null)return _0x621a26;if(_0x33b4bd['isCompleteForChild'](_0x310277)){const _0xbc095a=ve(_0x539ec8['visibleWrites'],_0x414fd2);return it(_0xbc095a,_0x33b4bd['getNode']()['getImmediateChild'](_0x310277));}else return null;}function gu(_0x3ed290,_0x4c1c97){return $e(_0x3ed290['visibleWrites'],_0x4c1c97);}function mu(_0x4cd27a,_0x9204ea,_0xfc730e,_0xeebc27,_0x51c073,_0xf5ffd2,_0x4ec38c){let _0x4e471f;const _0x36bdcf=ve(_0x4cd27a['visibleWrites'],_0x9204ea),_0x4c5b9b=$e(_0x36bdcf,w());if(_0x4c5b9b!=null)_0x4e471f=_0x4c5b9b;else{if(_0xfc730e!=null)_0x4e471f=it(_0x36bdcf,_0xfc730e);else return[];}if(_0x4e471f=_0x4e471f['withIndex'](_0x4ec38c),!_0x4e471f['isEmpty']()&&!_0x4e471f['isLeafNode']()){const _0x4d8340=[],_0x57b6c3=_0x4ec38c['getCompare'](),_0x2778c3=_0xf5ffd2?_0x4e471f['getReverseIteratorFrom'](_0xeebc27,_0x4ec38c):_0x4e471f['getIteratorFrom'](_0xeebc27,_0x4ec38c);let _0x3d8bdf=_0x2778c3['getNext']();for(;_0x3d8bdf&&_0x4d8340['length']<_0x51c073;)_0x57b6c3(_0x3d8bdf,_0xeebc27)!==0x0&&_0x4d8340['push'](_0x3d8bdf),_0x3d8bdf=_0x2778c3['getNext']();return _0x4d8340;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x1973d7,_0x36de81,_0x2c3799,_0x67f501){return Uo(_0x1973d7['writeTree'],_0x1973d7['treePath'],_0x36de81,_0x2c3799,_0x67f501);}function es(_0x42ec61,_0x204403){return fu(_0x42ec61['writeTree'],_0x42ec61['treePath'],_0x204403);}function or(_0x395e6b,_0x1ca1c2,_0x88e44a,_0x2c6b75){return pu(_0x395e6b['writeTree'],_0x395e6b['treePath'],_0x1ca1c2,_0x88e44a,_0x2c6b75);}function yn(_0x42ab1b,_0x44cb9f){return gu(_0x42ab1b['writeTree'],A(_0x42ab1b['treePath'],_0x44cb9f));}function vu(_0x364003,_0x4e57b8,_0x16e634,_0x55e64e,_0x292dd2,_0xbb4699){return mu(_0x364003['writeTree'],_0x364003['treePath'],_0x4e57b8,_0x16e634,_0x55e64e,_0x292dd2,_0xbb4699);}function ts(_0x4e4649,_0x215ab0,_0x58c43a){return _u(_0x4e4649['writeTree'],_0x4e4649['treePath'],_0x215ab0,_0x58c43a);}function Wo(_0x13870e,_0x476c5f){return Bo(A(_0x13870e['treePath'],_0x476c5f),_0x13870e['writeTree']);}function Bo(_0x5b04f5,_0x3439b9){return{'treePath':_0x5b04f5,'writeTree':_0x3439b9};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x5d9f87){const _0x45492e=_0x5d9f87['type'],_0x58d234=_0x5d9f87['childName'];f(_0x45492e==='child_added'||_0x45492e==='child_changed'||_0x45492e==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x58d234!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x37be09=this['changeMap']['get'](_0x58d234);if(_0x37be09){const _0x8790a6=_0x37be09['type'];if(_0x45492e==='child_added'&&_0x8790a6==='child_removed')this['changeMap']['set'](_0x58d234,Pt(_0x58d234,_0x5d9f87['snapshotNode'],_0x37be09['snapshotNode']));else{if(_0x45492e==='child_removed'&&_0x8790a6==='child_added')this['changeMap']['delete'](_0x58d234);else{if(_0x45492e==='child_removed'&&_0x8790a6==='child_changed')this['changeMap']['set'](_0x58d234,Nt(_0x58d234,_0x37be09['oldSnap']));else{if(_0x45492e==='child_changed'&&_0x8790a6==='child_added')this['changeMap']['set'](_0x58d234,tt(_0x58d234,_0x5d9f87['snapshotNode']));else{if(_0x45492e==='child_changed'&&_0x8790a6==='child_changed')this['changeMap']['set'](_0x58d234,Pt(_0x58d234,_0x5d9f87['snapshotNode'],_0x37be09['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x5d9f87+'\x20occurred\x20after\x20'+_0x37be09);}}}}}else this['changeMap']['set'](_0x58d234,_0x5d9f87);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x191e00){return null;}['getChildAfterChild'](_0x44de7a,_0xfc4a07,_0x1c97e2){return null;}}const Vo=new Iu();class ns{constructor(_0xf4198,_0x4f8c16,_0x2118c7=null){this['writes_']=_0xf4198,this['viewCache_']=_0x4f8c16,this['optCompleteServerCache_']=_0x2118c7;}['getCompleteChild'](_0x33f463){const _0x4366d4=this['viewCache_']['eventCache'];if(_0x4366d4['isCompleteForChild'](_0x33f463))return _0x4366d4['getNode']()['getImmediateChild'](_0x33f463);{const _0x369d93=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x33f463,_0x369d93);}}['getChildAfterChild'](_0x5ebefb,_0x3af448,_0x22d9b2){const _0x31f5c2=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x5178eb=vu(this['writes_'],_0x31f5c2,_0x3af448,0x1,_0x22d9b2,_0x5ebefb);return _0x5178eb['length']===0x0?null:_0x5178eb[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0xb9f3fa){return{'filter':_0xb9f3fa};}function Cu(_0x4d821f,_0x1e3177){f(_0x1e3177['eventCache']['getNode']()['isIndexed'](_0x4d821f['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1e3177['serverCache']['getNode']()['isIndexed'](_0x4d821f['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x2d2ea7,_0x55d531,_0x436f4e,_0x932f3,_0x569664){const _0x34f1c8=new Eu();let _0x44f2df,_0x1d578c;if(_0x436f4e['type']===q['OVERWRITE']){const _0x4d4e25=_0x436f4e;_0x4d4e25['source']['fromUser']?_0x44f2df=Ti(_0x2d2ea7,_0x55d531,_0x4d4e25['path'],_0x4d4e25['snap'],_0x932f3,_0x569664,_0x34f1c8):(f(_0x4d4e25['source']['fromServer'],'Unknown\x20source.'),_0x1d578c=_0x4d4e25['source']['tagged']||_0x55d531['serverCache']['isFiltered']()&&!v(_0x4d4e25['path']),_0x44f2df=vn(_0x2d2ea7,_0x55d531,_0x4d4e25['path'],_0x4d4e25['snap'],_0x932f3,_0x569664,_0x1d578c,_0x34f1c8));}else{if(_0x436f4e['type']===q['MERGE']){const _0x1f57a8=_0x436f4e;_0x1f57a8['source']['fromUser']?_0x44f2df=bu(_0x2d2ea7,_0x55d531,_0x1f57a8['path'],_0x1f57a8['children'],_0x932f3,_0x569664,_0x34f1c8):(f(_0x1f57a8['source']['fromServer'],'Unknown\x20source.'),_0x1d578c=_0x1f57a8['source']['tagged']||_0x55d531['serverCache']['isFiltered'](),_0x44f2df=Si(_0x2d2ea7,_0x55d531,_0x1f57a8['path'],_0x1f57a8['children'],_0x932f3,_0x569664,_0x1d578c,_0x34f1c8));}else{if(_0x436f4e['type']===q['ACK_USER_WRITE']){const _0x3fde69=_0x436f4e;_0x3fde69['revert']?_0x44f2df=ku(_0x2d2ea7,_0x55d531,_0x3fde69['path'],_0x932f3,_0x569664,_0x34f1c8):_0x44f2df=Ru(_0x2d2ea7,_0x55d531,_0x3fde69['path'],_0x3fde69['affectedTree'],_0x932f3,_0x569664,_0x34f1c8);}else{if(_0x436f4e['type']===q['LISTEN_COMPLETE'])_0x44f2df=Au(_0x2d2ea7,_0x55d531,_0x436f4e['path'],_0x932f3,_0x34f1c8);else throw ot('Unknown\x20operation\x20type:\x20'+_0x436f4e['type']);}}}const _0x304d6c=_0x34f1c8['getChanges']();return Su(_0x55d531,_0x44f2df,_0x304d6c),{'viewCache':_0x44f2df,'changes':_0x304d6c};}function Su(_0x1048ef,_0x5a39ac,_0x4e65b1){const _0x5659d9=_0x5a39ac['eventCache'];if(_0x5659d9['isFullyInitialized']()){const _0x2115bf=_0x5659d9['getNode']()['isLeafNode']()||_0x5659d9['getNode']()['isEmpty'](),_0x474f3b=gn(_0x1048ef);(_0x4e65b1['length']>0x0||!_0x1048ef['eventCache']['isFullyInitialized']()||_0x2115bf&&!_0x5659d9['getNode']()['equals'](_0x474f3b)||!_0x5659d9['getNode']()['getPriority']()['equals'](_0x474f3b['getPriority']()))&&_0x4e65b1['push'](Oo(gn(_0x5a39ac)));}}function Ho(_0x1f630e,_0x59406c,_0x5924c1,_0x347764,_0x5ea98a,_0x295883){const _0x1ab38a=_0x59406c['eventCache'];if(yn(_0x347764,_0x5924c1)!=null)return _0x59406c;{let _0x51d37a,_0x19219d;if(v(_0x5924c1)){if(f(_0x59406c['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x59406c['serverCache']['isFiltered']()){const _0x579c47=Ue(_0x59406c),_0x58071b=_0x579c47 instanceof g?_0x579c47:g['EMPTY_NODE'],_0x3c2a70=es(_0x347764,_0x58071b);_0x51d37a=_0x1f630e['filter']['updateFullNode'](_0x59406c['eventCache']['getNode'](),_0x3c2a70,_0x295883);}else{const _0xe21a99=mn(_0x347764,Ue(_0x59406c));_0x51d37a=_0x1f630e['filter']['updateFullNode'](_0x59406c['eventCache']['getNode'](),_0xe21a99,_0x295883);}}else{const _0x470561=y(_0x5924c1);if(_0x470561==='.priority'){f(we(_0x5924c1)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x45527f=_0x1ab38a['getNode']();_0x19219d=_0x59406c['serverCache']['getNode']();const _0x48fc75=or(_0x347764,_0x5924c1,_0x45527f,_0x19219d);_0x48fc75!=null?_0x51d37a=_0x1f630e['filter']['updatePriority'](_0x45527f,_0x48fc75):_0x51d37a=_0x1ab38a['getNode']();}else{const _0x18df68=b(_0x5924c1);let _0x23310f;if(_0x1ab38a['isCompleteForChild'](_0x470561)){_0x19219d=_0x59406c['serverCache']['getNode']();const _0x22fb59=or(_0x347764,_0x5924c1,_0x1ab38a['getNode'](),_0x19219d);_0x22fb59!=null?_0x23310f=_0x1ab38a['getNode']()['getImmediateChild'](_0x470561)['updateChild'](_0x18df68,_0x22fb59):_0x23310f=_0x1ab38a['getNode']()['getImmediateChild'](_0x470561);}else _0x23310f=ts(_0x347764,_0x470561,_0x59406c['serverCache']);_0x23310f!=null?_0x51d37a=_0x1f630e['filter']['updateChild'](_0x1ab38a['getNode'](),_0x470561,_0x23310f,_0x18df68,_0x5ea98a,_0x295883):_0x51d37a=_0x1ab38a['getNode']();}}return wt(_0x59406c,_0x51d37a,_0x1ab38a['isFullyInitialized']()||v(_0x5924c1),_0x1f630e['filter']['filtersNodes']());}}function vn(_0x43d77a,_0x4ce703,_0x224c88,_0x48a572,_0x56d144,_0x516b61,_0x1241aa,_0x4f3e5a){const _0x5a99e9=_0x4ce703['serverCache'];let _0x34c2ff;const _0x33f4d5=_0x1241aa?_0x43d77a['filter']:_0x43d77a['filter']['getIndexedFilter']();if(v(_0x224c88))_0x34c2ff=_0x33f4d5['updateFullNode'](_0x5a99e9['getNode'](),_0x48a572,null);else{if(_0x33f4d5['filtersNodes']()&&!_0x5a99e9['isFiltered']()){const _0x198ed4=_0x5a99e9['getNode']()['updateChild'](_0x224c88,_0x48a572);_0x34c2ff=_0x33f4d5['updateFullNode'](_0x5a99e9['getNode'](),_0x198ed4,null);}else{const _0x81f262=y(_0x224c88);if(!_0x5a99e9['isCompleteForPath'](_0x224c88)&&we(_0x224c88)>0x1)return _0x4ce703;const _0x428180=b(_0x224c88),_0x32b0d4=_0x5a99e9['getNode']()['getImmediateChild'](_0x81f262)['updateChild'](_0x428180,_0x48a572);_0x81f262==='.priority'?_0x34c2ff=_0x33f4d5['updatePriority'](_0x5a99e9['getNode'](),_0x32b0d4):_0x34c2ff=_0x33f4d5['updateChild'](_0x5a99e9['getNode'](),_0x81f262,_0x32b0d4,_0x428180,Vo,null);}}const _0x4d1202=Lo(_0x4ce703,_0x34c2ff,_0x5a99e9['isFullyInitialized']()||v(_0x224c88),_0x33f4d5['filtersNodes']()),_0x143e81=new ns(_0x56d144,_0x4d1202,_0x516b61);return Ho(_0x43d77a,_0x4d1202,_0x224c88,_0x56d144,_0x143e81,_0x4f3e5a);}function Ti(_0x4f1e2b,_0x3eef3a,_0x483bad,_0x4747bb,_0x2b2961,_0x509a0a,_0x20e449){const _0x7f4ef5=_0x3eef3a['eventCache'];let _0x5bb372,_0x1d3c37;const _0x1d2646=new ns(_0x2b2961,_0x3eef3a,_0x509a0a);if(v(_0x483bad))_0x1d3c37=_0x4f1e2b['filter']['updateFullNode'](_0x3eef3a['eventCache']['getNode'](),_0x4747bb,_0x20e449),_0x5bb372=wt(_0x3eef3a,_0x1d3c37,!0x0,_0x4f1e2b['filter']['filtersNodes']());else{const _0x5a5dd1=y(_0x483bad);if(_0x5a5dd1==='.priority')_0x1d3c37=_0x4f1e2b['filter']['updatePriority'](_0x3eef3a['eventCache']['getNode'](),_0x4747bb),_0x5bb372=wt(_0x3eef3a,_0x1d3c37,_0x7f4ef5['isFullyInitialized'](),_0x7f4ef5['isFiltered']());else{const _0x47f014=b(_0x483bad),_0x3c69ed=_0x7f4ef5['getNode']()['getImmediateChild'](_0x5a5dd1);let _0x2b68d5;if(v(_0x47f014))_0x2b68d5=_0x4747bb;else{const _0x47f2b1=_0x1d2646['getCompleteChild'](_0x5a5dd1);_0x47f2b1!=null?Gi(_0x47f014)==='.priority'&&_0x47f2b1['getChild'](To(_0x47f014))['isEmpty']()?_0x2b68d5=_0x47f2b1:_0x2b68d5=_0x47f2b1['updateChild'](_0x47f014,_0x4747bb):_0x2b68d5=g['EMPTY_NODE'];}if(_0x3c69ed['equals'](_0x2b68d5))_0x5bb372=_0x3eef3a;else{const _0x56e9e3=_0x4f1e2b['filter']['updateChild'](_0x7f4ef5['getNode'](),_0x5a5dd1,_0x2b68d5,_0x47f014,_0x1d2646,_0x20e449);_0x5bb372=wt(_0x3eef3a,_0x56e9e3,_0x7f4ef5['isFullyInitialized'](),_0x4f1e2b['filter']['filtersNodes']());}}}return _0x5bb372;}function ar(_0xa9df7b,_0x5e9c1d){return _0xa9df7b['eventCache']['isCompleteForChild'](_0x5e9c1d);}function bu(_0x132935,_0x5ce898,_0x17ee45,_0x4ca50e,_0x59ef40,_0x45691a,_0x3c1dcc){let _0x71ffe4=_0x5ce898;return _0x4ca50e['foreach']((_0x1a40bd,_0x3db5f0)=>{const _0x378cef=A(_0x17ee45,_0x1a40bd);ar(_0x5ce898,y(_0x378cef))&&(_0x71ffe4=Ti(_0x132935,_0x71ffe4,_0x378cef,_0x3db5f0,_0x59ef40,_0x45691a,_0x3c1dcc));}),_0x4ca50e['foreach']((_0x499a09,_0x1400c9)=>{const _0x4d2d74=A(_0x17ee45,_0x499a09);ar(_0x5ce898,y(_0x4d2d74))||(_0x71ffe4=Ti(_0x132935,_0x71ffe4,_0x4d2d74,_0x1400c9,_0x59ef40,_0x45691a,_0x3c1dcc));}),_0x71ffe4;}function cr(_0x1004a6,_0x51da05,_0x36d741){return _0x36d741['foreach']((_0x22c1df,_0x209490)=>{_0x51da05=_0x51da05['updateChild'](_0x22c1df,_0x209490);}),_0x51da05;}function Si(_0xfb47d5,_0x288731,_0x11f80a,_0x3669aa,_0x664047,_0x110162,_0x1cc267,_0x1786de){if(_0x288731['serverCache']['getNode']()['isEmpty']()&&!_0x288731['serverCache']['isFullyInitialized']())return _0x288731;let _0x31cfb6=_0x288731,_0x241515;v(_0x11f80a)?_0x241515=_0x3669aa:_0x241515=new S(null)['setTree'](_0x11f80a,_0x3669aa);const _0x2adf8c=_0x288731['serverCache']['getNode']();return _0x241515['children']['inorderTraversal']((_0x58644b,_0x35bba5)=>{if(_0x2adf8c['hasChild'](_0x58644b)){const _0x5012c7=_0x288731['serverCache']['getNode']()['getImmediateChild'](_0x58644b),_0x1d7fb9=cr(_0xfb47d5,_0x5012c7,_0x35bba5);_0x31cfb6=vn(_0xfb47d5,_0x31cfb6,new C(_0x58644b),_0x1d7fb9,_0x664047,_0x110162,_0x1cc267,_0x1786de);}}),_0x241515['children']['inorderTraversal']((_0x1ba929,_0xd5b2e9)=>{const _0x47a0cd=!_0x288731['serverCache']['isCompleteForChild'](_0x1ba929)&&_0xd5b2e9['value']===null;if(!_0x2adf8c['hasChild'](_0x1ba929)&&!_0x47a0cd){const _0x570105=_0x288731['serverCache']['getNode']()['getImmediateChild'](_0x1ba929),_0x45d2f5=cr(_0xfb47d5,_0x570105,_0xd5b2e9);_0x31cfb6=vn(_0xfb47d5,_0x31cfb6,new C(_0x1ba929),_0x45d2f5,_0x664047,_0x110162,_0x1cc267,_0x1786de);}}),_0x31cfb6;}function Ru(_0x73e190,_0x457f0a,_0x232408,_0xcd4f45,_0x43b6ee,_0x4fe89a,_0x5a2ff4){if(yn(_0x43b6ee,_0x232408)!=null)return _0x457f0a;const _0x2ed6fc=_0x457f0a['serverCache']['isFiltered'](),_0x26fc19=_0x457f0a['serverCache'];if(_0xcd4f45['value']!=null){if(v(_0x232408)&&_0x26fc19['isFullyInitialized']()||_0x26fc19['isCompleteForPath'](_0x232408))return vn(_0x73e190,_0x457f0a,_0x232408,_0x26fc19['getNode']()['getChild'](_0x232408),_0x43b6ee,_0x4fe89a,_0x2ed6fc,_0x5a2ff4);if(v(_0x232408)){let _0x41f5cc=new S(null);return _0x26fc19['getNode']()['forEachChild'](ye,(_0x36f39c,_0x167570)=>{_0x41f5cc=_0x41f5cc['set'](new C(_0x36f39c),_0x167570);}),Si(_0x73e190,_0x457f0a,_0x232408,_0x41f5cc,_0x43b6ee,_0x4fe89a,_0x2ed6fc,_0x5a2ff4);}else return _0x457f0a;}else{let _0x1fa5a0=new S(null);return _0xcd4f45['foreach']((_0x5b64fd,_0x107261)=>{const _0x1634c7=A(_0x232408,_0x5b64fd);_0x26fc19['isCompleteForPath'](_0x1634c7)&&(_0x1fa5a0=_0x1fa5a0['set'](_0x5b64fd,_0x26fc19['getNode']()['getChild'](_0x1634c7)));}),Si(_0x73e190,_0x457f0a,_0x232408,_0x1fa5a0,_0x43b6ee,_0x4fe89a,_0x2ed6fc,_0x5a2ff4);}}function Au(_0x29d6cb,_0x9ebe1e,_0xa5509e,_0x5bf40a,_0x1717c4){const _0x5d7d46=_0x9ebe1e['serverCache'],_0x245057=Lo(_0x9ebe1e,_0x5d7d46['getNode'](),_0x5d7d46['isFullyInitialized']()||v(_0xa5509e),_0x5d7d46['isFiltered']());return Ho(_0x29d6cb,_0x245057,_0xa5509e,_0x5bf40a,Vo,_0x1717c4);}function ku(_0x506ed9,_0x5e71b1,_0x15f26f,_0x52885b,_0x5c3464,_0x445411){let _0xf3d8ac;if(yn(_0x52885b,_0x15f26f)!=null)return _0x5e71b1;{const _0x27085d=new ns(_0x52885b,_0x5e71b1,_0x5c3464),_0x35ea43=_0x5e71b1['eventCache']['getNode']();let _0x440ccd;if(v(_0x15f26f)||y(_0x15f26f)==='.priority'){let _0x4a775e;if(_0x5e71b1['serverCache']['isFullyInitialized']())_0x4a775e=mn(_0x52885b,Ue(_0x5e71b1));else{const _0x2928a6=_0x5e71b1['serverCache']['getNode']();f(_0x2928a6 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x4a775e=es(_0x52885b,_0x2928a6);}_0x4a775e=_0x4a775e,_0x440ccd=_0x506ed9['filter']['updateFullNode'](_0x35ea43,_0x4a775e,_0x445411);}else{const _0x2d3878=y(_0x15f26f);let _0x8cda3a=ts(_0x52885b,_0x2d3878,_0x5e71b1['serverCache']);_0x8cda3a==null&&_0x5e71b1['serverCache']['isCompleteForChild'](_0x2d3878)&&(_0x8cda3a=_0x35ea43['getImmediateChild'](_0x2d3878)),_0x8cda3a!=null?_0x440ccd=_0x506ed9['filter']['updateChild'](_0x35ea43,_0x2d3878,_0x8cda3a,b(_0x15f26f),_0x27085d,_0x445411):_0x5e71b1['eventCache']['getNode']()['hasChild'](_0x2d3878)?_0x440ccd=_0x506ed9['filter']['updateChild'](_0x35ea43,_0x2d3878,g['EMPTY_NODE'],b(_0x15f26f),_0x27085d,_0x445411):_0x440ccd=_0x35ea43,_0x440ccd['isEmpty']()&&_0x5e71b1['serverCache']['isFullyInitialized']()&&(_0xf3d8ac=mn(_0x52885b,Ue(_0x5e71b1)),_0xf3d8ac['isLeafNode']()&&(_0x440ccd=_0x506ed9['filter']['updateFullNode'](_0x440ccd,_0xf3d8ac,_0x445411)));}return _0xf3d8ac=_0x5e71b1['serverCache']['isFullyInitialized']()||yn(_0x52885b,w())!=null,wt(_0x5e71b1,_0x440ccd,_0xf3d8ac,_0x506ed9['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x501646,_0x580bfa){this['query_']=_0x501646,this['eventRegistrations_']=[];const _0x103516=this['query_']['_queryParams'],_0x3ed67c=new Yi(_0x103516['getIndex']()),_0x1679cb=qh(_0x103516);this['processor_']=wu(_0x1679cb);const _0x59afac=_0x580bfa['serverCache'],_0x183f3a=_0x580bfa['eventCache'],_0x4fed9b=_0x3ed67c['updateFullNode'](g['EMPTY_NODE'],_0x59afac['getNode'](),null),_0x5b3eee=_0x1679cb['updateFullNode'](g['EMPTY_NODE'],_0x183f3a['getNode'](),null),_0x4dab35=new Ce(_0x4fed9b,_0x59afac['isFullyInitialized'](),_0x3ed67c['filtersNodes']()),_0x18b576=new Ce(_0x5b3eee,_0x183f3a['isFullyInitialized'](),_0x1679cb['filtersNodes']());this['viewCache_']=Dn(_0x18b576,_0x4dab35),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x4c7829){return _0x4c7829['viewCache_']['serverCache']['getNode']();}function Ou(_0x549ae8){return gn(_0x549ae8['viewCache_']);}function Du(_0x57efe6,_0x324496){const _0x4ebf2a=Ue(_0x57efe6['viewCache_']);return _0x4ebf2a&&(_0x57efe6['query']['_queryParams']['loadsAllData']()||!v(_0x324496)&&!_0x4ebf2a['getImmediateChild'](y(_0x324496))['isEmpty']())?_0x4ebf2a['getChild'](_0x324496):null;}function lr(_0x5a7c0c){return _0x5a7c0c['eventRegistrations_']['length']===0x0;}function Mu(_0x5efc7f,_0x3b89e7){_0x5efc7f['eventRegistrations_']['push'](_0x3b89e7);}function hr(_0x4e52c8,_0x16a866,_0x59a18){const _0x4f8a2c=[];if(_0x59a18){f(_0x16a866==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x537ee4=_0x4e52c8['query']['_path'];_0x4e52c8['eventRegistrations_']['forEach'](_0x3cf0de=>{const _0x5d1ac9=_0x3cf0de['createCancelEvent'](_0x59a18,_0x537ee4);_0x5d1ac9&&_0x4f8a2c['push'](_0x5d1ac9);});}if(_0x16a866){let _0x5d716d=[];for(let _0x12e2c3=0x0;_0x12e2c3<_0x4e52c8['eventRegistrations_']['length'];++_0x12e2c3){const _0x51d4c0=_0x4e52c8['eventRegistrations_'][_0x12e2c3];if(!_0x51d4c0['matches'](_0x16a866))_0x5d716d['push'](_0x51d4c0);else{if(_0x16a866['hasAnyCallback']()){_0x5d716d=_0x5d716d['concat'](_0x4e52c8['eventRegistrations_']['slice'](_0x12e2c3+0x1));break;}}}_0x4e52c8['eventRegistrations_']=_0x5d716d;}else _0x4e52c8['eventRegistrations_']=[];return _0x4f8a2c;}function ur(_0x210b15,_0x5e2fb8,_0x41f1a0,_0x19af12){_0x5e2fb8['type']===q['MERGE']&&_0x5e2fb8['source']['queryId']!==null&&(f(Ue(_0x210b15['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x210b15['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5a99db=_0x210b15['viewCache_'],_0x2b49c8=Tu(_0x210b15['processor_'],_0x5a99db,_0x5e2fb8,_0x41f1a0,_0x19af12);return Cu(_0x210b15['processor_'],_0x2b49c8['viewCache']),f(_0x2b49c8['viewCache']['serverCache']['isFullyInitialized']()||!_0x5a99db['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x210b15['viewCache_']=_0x2b49c8['viewCache'],$o(_0x210b15,_0x2b49c8['changes'],_0x2b49c8['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x2fcb49,_0x3920c0){const _0x126e5b=_0x2fcb49['viewCache_']['eventCache'],_0x53b2fb=[];return _0x126e5b['getNode']()['isLeafNode']()||_0x126e5b['getNode']()['forEachChild'](R,(_0x4a5043,_0x4a01b2)=>{_0x53b2fb['push'](tt(_0x4a5043,_0x4a01b2));}),_0x126e5b['isFullyInitialized']()&&_0x53b2fb['push'](Oo(_0x126e5b['getNode']())),$o(_0x2fcb49,_0x53b2fb,_0x126e5b['getNode'](),_0x3920c0);}function $o(_0x44dcaa,_0x5a20ca,_0x1b6a4c,_0xee597d){const _0x234bf7=_0xee597d?[_0xee597d]:_0x44dcaa['eventRegistrations_'];return nu(_0x44dcaa['eventGenerator_'],_0x5a20ca,_0x1b6a4c,_0x234bf7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x52190a){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x52190a;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x177205){return _0x177205['views']['size']===0x0;}function is(_0x17a2a6,_0x312cf4,_0x310e4b,_0x12c55a){const _0x236f5a=_0x312cf4['source']['queryId'];if(_0x236f5a!==null){const _0x54e1b6=_0x17a2a6['views']['get'](_0x236f5a);return f(_0x54e1b6!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x54e1b6,_0x312cf4,_0x310e4b,_0x12c55a);}else{let _0x13e06c=[];for(const _0x4e60d8 of _0x17a2a6['views']['values']())_0x13e06c=_0x13e06c['concat'](ur(_0x4e60d8,_0x312cf4,_0x310e4b,_0x12c55a));return _0x13e06c;}}function qo(_0x50d83c,_0x252b5c,_0x5550d0,_0x508713,_0x43bb83){const _0x1df168=_0x252b5c['_queryIdentifier'],_0x3268a6=_0x50d83c['views']['get'](_0x1df168);if(!_0x3268a6){let _0x314728=mn(_0x5550d0,_0x43bb83?_0x508713:null),_0x375036=!0x1;_0x314728?_0x375036=!0x0:_0x508713 instanceof g?(_0x314728=es(_0x5550d0,_0x508713),_0x375036=!0x1):(_0x314728=g['EMPTY_NODE'],_0x375036=!0x1);const _0x30e279=Dn(new Ce(_0x314728,_0x375036,!0x1),new Ce(_0x508713,_0x43bb83,!0x1));return new Nu(_0x252b5c,_0x30e279);}return _0x3268a6;}function Wu(_0x4490ab,_0x19a5b0,_0xac5b6b,_0xfd56a2,_0x528de7,_0x540325){const _0x2ba6d8=qo(_0x4490ab,_0x19a5b0,_0xfd56a2,_0x528de7,_0x540325);return _0x4490ab['views']['has'](_0x19a5b0['_queryIdentifier'])||_0x4490ab['views']['set'](_0x19a5b0['_queryIdentifier'],_0x2ba6d8),Mu(_0x2ba6d8,_0xac5b6b),Lu(_0x2ba6d8,_0xac5b6b);}function Bu(_0xeaf4e6,_0x161abb,_0x429eb1,_0xcbf524){const _0x2d20ee=_0x161abb['_queryIdentifier'],_0x2c75b2=[];let _0x5450f8=[];const _0x505adb=Te(_0xeaf4e6);if(_0x2d20ee==='default'){for(const [_0x3887b0,_0x2c6533]of _0xeaf4e6['views']['entries']())_0x5450f8=_0x5450f8['concat'](hr(_0x2c6533,_0x429eb1,_0xcbf524)),lr(_0x2c6533)&&(_0xeaf4e6['views']['delete'](_0x3887b0),_0x2c6533['query']['_queryParams']['loadsAllData']()||_0x2c75b2['push'](_0x2c6533['query']));}else{const _0x16978f=_0xeaf4e6['views']['get'](_0x2d20ee);_0x16978f&&(_0x5450f8=_0x5450f8['concat'](hr(_0x16978f,_0x429eb1,_0xcbf524)),lr(_0x16978f)&&(_0xeaf4e6['views']['delete'](_0x2d20ee),_0x16978f['query']['_queryParams']['loadsAllData']()||_0x2c75b2['push'](_0x16978f['query'])));}return _0x505adb&&!Te(_0xeaf4e6)&&_0x2c75b2['push'](new(Fu())(_0x161abb['_repo'],_0x161abb['_path'])),{'removed':_0x2c75b2,'events':_0x5450f8};}function zo(_0x16661b){const _0x31ec5d=[];for(const _0x17adfb of _0x16661b['views']['values']())_0x17adfb['query']['_queryParams']['loadsAllData']()||_0x31ec5d['push'](_0x17adfb);return _0x31ec5d;}function Ee(_0x41023d,_0x306e3c){let _0x16910e=null;for(const _0x2b52c3 of _0x41023d['views']['values']())_0x16910e=_0x16910e||Du(_0x2b52c3,_0x306e3c);return _0x16910e;}function jo(_0x3c15a5,_0x5c697c){if(_0x5c697c['_queryParams']['loadsAllData']())return Ln(_0x3c15a5);{const _0x3eba39=_0x5c697c['_queryIdentifier'];return _0x3c15a5['views']['get'](_0x3eba39);}}function Ko(_0xb2d363,_0x42d113){return jo(_0xb2d363,_0x42d113)!=null;}function Te(_0x5ab9c7){return Ln(_0x5ab9c7)!=null;}function Ln(_0x425dff){for(const _0x49fac8 of _0x425dff['views']['values']())if(_0x49fac8['query']['_queryParams']['loadsAllData']())return _0x49fac8;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x38fde4){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x38fde4;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x1e198a){this['listenProvider_']=_0x1e198a,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x2244ea,_0x5e76e4,_0x26f5c7,_0x24bff0,_0x425788){return ou(_0x2244ea['pendingWriteTree_'],_0x5e76e4,_0x26f5c7,_0x24bff0,_0x425788),_0x425788?ht(_0x2244ea,new Fe(Ji(),_0x5e76e4,_0x26f5c7)):[];}function Gu(_0x2abfbc,_0x45dee6,_0x35b14e,_0x5eb5b9){au(_0x2abfbc['pendingWriteTree_'],_0x45dee6,_0x35b14e,_0x5eb5b9);const _0x277be9=S['fromObject'](_0x35b14e);return ht(_0x2abfbc,new nt(Ji(),_0x45dee6,_0x277be9));}function pe(_0x5e8702,_0x3e15fc,_0x590506=!0x1){const _0x4ababa=cu(_0x5e8702['pendingWriteTree_'],_0x3e15fc);if(lu(_0x5e8702['pendingWriteTree_'],_0x3e15fc)){let _0x244871=new S(null);return _0x4ababa['snap']!=null?_0x244871=_0x244871['set'](w(),!0x0):x(_0x4ababa['children'],_0x1bf695=>{_0x244871=_0x244871['set'](new C(_0x1bf695),!0x0);}),ht(_0x5e8702,new _n(_0x4ababa['path'],_0x244871,_0x590506));}else return[];}function $t(_0x28c154,_0x26b163,_0x56d546){return ht(_0x28c154,new Fe(Xi(),_0x26b163,_0x56d546));}function qu(_0x560395,_0x38a5ec,_0x921428){const _0xea4d53=S['fromObject'](_0x921428);return ht(_0x560395,new nt(Xi(),_0x38a5ec,_0xea4d53));}function zu(_0x4bfdd7,_0xdc760d){return ht(_0x4bfdd7,new Dt(Xi(),_0xdc760d));}function ju(_0x326c78,_0x29ddc3,_0x5826d8){const _0x39e193=rs(_0x326c78,_0x5826d8);if(_0x39e193){const _0x159aa2=os(_0x39e193),_0x5adfb1=_0x159aa2['path'],_0x3327c7=_0x159aa2['queryId'],_0x1c7601=F(_0x5adfb1,_0x29ddc3),_0x4a8bb9=new Dt(Zi(_0x3327c7),_0x1c7601);return as(_0x326c78,_0x5adfb1,_0x4a8bb9);}else return[];}function wn(_0x32e376,_0x33f721,_0x4ef459,_0x5237b1,_0x3a9e49=!0x1){const _0x48ec7a=_0x33f721['_path'],_0x35742a=_0x32e376['syncPointTree_']['get'](_0x48ec7a);let _0x4fa95b=[];if(_0x35742a&&(_0x33f721['_queryIdentifier']==='default'||Ko(_0x35742a,_0x33f721))){const _0x18f99b=Bu(_0x35742a,_0x33f721,_0x4ef459,_0x5237b1);Uu(_0x35742a)&&(_0x32e376['syncPointTree_']=_0x32e376['syncPointTree_']['remove'](_0x48ec7a));const _0x31e75e=_0x18f99b['removed'];if(_0x4fa95b=_0x18f99b['events'],!_0x3a9e49){const _0x12a2db=_0x31e75e['findIndex'](_0x4ddd3b=>_0x4ddd3b['_queryParams']['loadsAllData']())!==-0x1,_0x4896a2=_0x32e376['syncPointTree_']['findOnPath'](_0x48ec7a,(_0x16fbc2,_0x3d39a9)=>Te(_0x3d39a9));if(_0x12a2db&&!_0x4896a2){const _0x4f6cbb=_0x32e376['syncPointTree_']['subtree'](_0x48ec7a);if(!_0x4f6cbb['isEmpty']()){const _0x2ceed7=Qu(_0x4f6cbb);for(let _0x271c96=0x0;_0x271c96<_0x2ceed7['length'];++_0x271c96){const _0x306872=_0x2ceed7[_0x271c96],_0x10690e=_0x306872['query'],_0x184f7e=Xo(_0x32e376,_0x306872);_0x32e376['listenProvider_']['startListening'](Tt(_0x10690e),Mt(_0x32e376,_0x10690e),_0x184f7e['hashFn'],_0x184f7e['onComplete']);}}}!_0x4896a2&&_0x31e75e['length']>0x0&&!_0x5237b1&&(_0x12a2db?_0x32e376['listenProvider_']['stopListening'](Tt(_0x33f721),null):_0x31e75e['forEach'](_0x4a8506=>{const _0x38b761=_0x32e376['queryToTagMap']['get'](Fn(_0x4a8506));_0x32e376['listenProvider_']['stopListening'](Tt(_0x4a8506),_0x38b761);}));}Ju(_0x32e376,_0x31e75e);}return _0x4fa95b;}function Yo(_0x4660db,_0x2d06fd,_0x58615f,_0x5ac76e){const _0x49b165=rs(_0x4660db,_0x5ac76e);if(_0x49b165!=null){const _0x43832c=os(_0x49b165),_0x270e7e=_0x43832c['path'],_0x4c7c4c=_0x43832c['queryId'],_0xd43c4b=F(_0x270e7e,_0x2d06fd),_0x21281f=new Fe(Zi(_0x4c7c4c),_0xd43c4b,_0x58615f);return as(_0x4660db,_0x270e7e,_0x21281f);}else return[];}function Ku(_0x5a1197,_0x3d52e0,_0x5e9698,_0x2fc8e0){const _0x24affd=rs(_0x5a1197,_0x2fc8e0);if(_0x24affd){const _0x1406b5=os(_0x24affd),_0x270d2a=_0x1406b5['path'],_0x466f67=_0x1406b5['queryId'],_0x3723b7=F(_0x270d2a,_0x3d52e0),_0x6cc379=S['fromObject'](_0x5e9698),_0x57abc0=new nt(Zi(_0x466f67),_0x3723b7,_0x6cc379);return as(_0x5a1197,_0x270d2a,_0x57abc0);}else return[];}function bi(_0x5864bd,_0x3eb227,_0x1819ab,_0x1dfc70=!0x1){const _0x18810d=_0x3eb227['_path'];let _0x33cc2a=null,_0x42955a=!0x1;_0x5864bd['syncPointTree_']['foreachOnPath'](_0x18810d,(_0x2f3f4e,_0x49d8bc)=>{const _0x5136d5=F(_0x2f3f4e,_0x18810d);_0x33cc2a=_0x33cc2a||Ee(_0x49d8bc,_0x5136d5),_0x42955a=_0x42955a||Te(_0x49d8bc);});let _0x2f5cab=_0x5864bd['syncPointTree_']['get'](_0x18810d);_0x2f5cab?(_0x42955a=_0x42955a||Te(_0x2f5cab),_0x33cc2a=_0x33cc2a||Ee(_0x2f5cab,w())):(_0x2f5cab=new Go(),_0x5864bd['syncPointTree_']=_0x5864bd['syncPointTree_']['set'](_0x18810d,_0x2f5cab));let _0x41f4a4;_0x33cc2a!=null?_0x41f4a4=!0x0:(_0x41f4a4=!0x1,_0x33cc2a=g['EMPTY_NODE'],_0x5864bd['syncPointTree_']['subtree'](_0x18810d)['foreachChild']((_0x142c27,_0x80a1e1)=>{const _0xe03014=Ee(_0x80a1e1,w());_0xe03014&&(_0x33cc2a=_0x33cc2a['updateImmediateChild'](_0x142c27,_0xe03014));}));const _0x26f267=Ko(_0x2f5cab,_0x3eb227);if(!_0x26f267&&!_0x3eb227['_queryParams']['loadsAllData']()){const _0x41ca46=Fn(_0x3eb227);f(!_0x5864bd['queryToTagMap']['has'](_0x41ca46),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x14ffe3=Xu();_0x5864bd['queryToTagMap']['set'](_0x41ca46,_0x14ffe3),_0x5864bd['tagToQueryMap']['set'](_0x14ffe3,_0x41ca46);}const _0x1b6445=Mn(_0x5864bd['pendingWriteTree_'],_0x18810d);let _0x2ac289=Wu(_0x2f5cab,_0x3eb227,_0x1819ab,_0x1b6445,_0x33cc2a,_0x41f4a4);if(!_0x26f267&&!_0x42955a&&!_0x1dfc70){const _0x116670=jo(_0x2f5cab,_0x3eb227);_0x2ac289=_0x2ac289['concat'](Zu(_0x5864bd,_0x3eb227,_0x116670));}return _0x2ac289;}function xn(_0x2213c0,_0x5bb8f9,_0x58ba4d){const _0x40eadc=_0x2213c0['pendingWriteTree_'],_0x13a8ed=_0x2213c0['syncPointTree_']['findOnPath'](_0x5bb8f9,(_0x3c0200,_0x8232b7)=>{const _0x291976=F(_0x3c0200,_0x5bb8f9),_0x3d5af6=Ee(_0x8232b7,_0x291976);if(_0x3d5af6)return _0x3d5af6;});return Uo(_0x40eadc,_0x5bb8f9,_0x13a8ed,_0x58ba4d,!0x0);}function Yu(_0x51d45c,_0x2ac2b3){const _0x402771=_0x2ac2b3['_path'];let _0x520dc7=null;_0x51d45c['syncPointTree_']['foreachOnPath'](_0x402771,(_0x5ab07b,_0x58b8f3)=>{const _0x2221ae=F(_0x5ab07b,_0x402771);_0x520dc7=_0x520dc7||Ee(_0x58b8f3,_0x2221ae);});let _0x29d87a=_0x51d45c['syncPointTree_']['get'](_0x402771);_0x29d87a?_0x520dc7=_0x520dc7||Ee(_0x29d87a,w()):(_0x29d87a=new Go(),_0x51d45c['syncPointTree_']=_0x51d45c['syncPointTree_']['set'](_0x402771,_0x29d87a));const _0x534191=_0x520dc7!=null,_0xb09551=_0x534191?new Ce(_0x520dc7,!0x0,!0x1):null,_0x53f2d0=Mn(_0x51d45c['pendingWriteTree_'],_0x2ac2b3['_path']),_0x227283=qo(_0x29d87a,_0x2ac2b3,_0x53f2d0,_0x534191?_0xb09551['getNode']():g['EMPTY_NODE'],_0x534191);return Ou(_0x227283);}function ht(_0x453cfe,_0x37b4ce){return Qo(_0x37b4ce,_0x453cfe['syncPointTree_'],null,Mn(_0x453cfe['pendingWriteTree_'],w()));}function Qo(_0x278201,_0x833096,_0x520ffe,_0x2d427c){if(v(_0x278201['path']))return Jo(_0x278201,_0x833096,_0x520ffe,_0x2d427c);{const _0x58b122=_0x833096['get'](w());_0x520ffe==null&&_0x58b122!=null&&(_0x520ffe=Ee(_0x58b122,w()));let _0x557e1c=[];const _0x1d0df7=y(_0x278201['path']),_0x2441c1=_0x278201['operationForChild'](_0x1d0df7),_0x3ea1db=_0x833096['children']['get'](_0x1d0df7);if(_0x3ea1db&&_0x2441c1){const _0xf50471=_0x520ffe?_0x520ffe['getImmediateChild'](_0x1d0df7):null,_0x531781=Wo(_0x2d427c,_0x1d0df7);_0x557e1c=_0x557e1c['concat'](Qo(_0x2441c1,_0x3ea1db,_0xf50471,_0x531781));}return _0x58b122&&(_0x557e1c=_0x557e1c['concat'](is(_0x58b122,_0x278201,_0x2d427c,_0x520ffe))),_0x557e1c;}}function Jo(_0x2a263c,_0x1d6326,_0x2418dc,_0xcc3d6a){const _0xe966d0=_0x1d6326['get'](w());_0x2418dc==null&&_0xe966d0!=null&&(_0x2418dc=Ee(_0xe966d0,w()));let _0x44d3a8=[];return _0x1d6326['children']['inorderTraversal']((_0x529ab8,_0x530785)=>{const _0x1cd8a1=_0x2418dc?_0x2418dc['getImmediateChild'](_0x529ab8):null,_0x44c739=Wo(_0xcc3d6a,_0x529ab8),_0x534aa0=_0x2a263c['operationForChild'](_0x529ab8);_0x534aa0&&(_0x44d3a8=_0x44d3a8['concat'](Jo(_0x534aa0,_0x530785,_0x1cd8a1,_0x44c739)));}),_0xe966d0&&(_0x44d3a8=_0x44d3a8['concat'](is(_0xe966d0,_0x2a263c,_0xcc3d6a,_0x2418dc))),_0x44d3a8;}function Xo(_0x26521e,_0x23cce9){const _0x47d6bb=_0x23cce9['query'],_0xfd9267=Mt(_0x26521e,_0x47d6bb);return{'hashFn':()=>(Pu(_0x23cce9)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x353565=>{if(_0x353565==='ok')return _0xfd9267?ju(_0x26521e,_0x47d6bb['_path'],_0xfd9267):zu(_0x26521e,_0x47d6bb['_path']);{const _0x56b47b=ql(_0x353565,_0x47d6bb);return wn(_0x26521e,_0x47d6bb,null,_0x56b47b);}}};}function Mt(_0x4ebeae,_0x3dc4bc){const _0x45c3bc=Fn(_0x3dc4bc);return _0x4ebeae['queryToTagMap']['get'](_0x45c3bc);}function Fn(_0x132522){return _0x132522['_path']['toString']()+'$'+_0x132522['_queryIdentifier'];}function rs(_0x26e895,_0xd77121){return _0x26e895['tagToQueryMap']['get'](_0xd77121);}function os(_0x4d5fe3){const _0x2e4aff=_0x4d5fe3['indexOf']('$');return f(_0x2e4aff!==-0x1&&_0x2e4aff<_0x4d5fe3['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4d5fe3['substr'](_0x2e4aff+0x1),'path':new C(_0x4d5fe3['substr'](0x0,_0x2e4aff))};}function as(_0xc54118,_0x527c21,_0x24a0c2){const _0x31b01c=_0xc54118['syncPointTree_']['get'](_0x527c21);f(_0x31b01c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x587374=Mn(_0xc54118['pendingWriteTree_'],_0x527c21);return is(_0x31b01c,_0x24a0c2,_0x587374,null);}function Qu(_0x108ea7){return _0x108ea7['fold']((_0x1d64f0,_0x1e0bd9,_0x826a63)=>{if(_0x1e0bd9&&Te(_0x1e0bd9))return[Ln(_0x1e0bd9)];{let _0xd7ad5d=[];return _0x1e0bd9&&(_0xd7ad5d=zo(_0x1e0bd9)),x(_0x826a63,(_0x1aab2c,_0x5ed524)=>{_0xd7ad5d=_0xd7ad5d['concat'](_0x5ed524);}),_0xd7ad5d;}});}function Tt(_0x1664a8){return _0x1664a8['_queryParams']['loadsAllData']()&&!_0x1664a8['_queryParams']['isDefault']()?new(Hu())(_0x1664a8['_repo'],_0x1664a8['_path']):_0x1664a8;}function Ju(_0x1a46b0,_0x30984c){for(let _0x5c3870=0x0;_0x5c3870<_0x30984c['length'];++_0x5c3870){const _0x5cfc96=_0x30984c[_0x5c3870];if(!_0x5cfc96['_queryParams']['loadsAllData']()){const _0x179571=Fn(_0x5cfc96),_0x3ae63d=_0x1a46b0['queryToTagMap']['get'](_0x179571);_0x1a46b0['queryToTagMap']['delete'](_0x179571),_0x1a46b0['tagToQueryMap']['delete'](_0x3ae63d);}}}function Xu(){return $u++;}function Zu(_0x381c8b,_0x3ce26e,_0x3e1a8e){const _0x23a81c=_0x3ce26e['_path'],_0x316ca7=Mt(_0x381c8b,_0x3ce26e),_0x35147c=Xo(_0x381c8b,_0x3e1a8e),_0x4ae294=_0x381c8b['listenProvider_']['startListening'](Tt(_0x3ce26e),_0x316ca7,_0x35147c['hashFn'],_0x35147c['onComplete']),_0x2e429b=_0x381c8b['syncPointTree_']['subtree'](_0x23a81c);if(_0x316ca7)f(!Te(_0x2e429b['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2eaa23=_0x2e429b['fold']((_0x450929,_0x44bef9,_0x406704)=>{if(!v(_0x450929)&&_0x44bef9&&Te(_0x44bef9))return[Ln(_0x44bef9)['query']];{let _0x2b4b21=[];return _0x44bef9&&(_0x2b4b21=_0x2b4b21['concat'](zo(_0x44bef9)['map'](_0x34ab5d=>_0x34ab5d['query']))),x(_0x406704,(_0x33f1e3,_0x3a3047)=>{_0x2b4b21=_0x2b4b21['concat'](_0x3a3047);}),_0x2b4b21;}});for(let _0x4c490b=0x0;_0x4c490b<_0x2eaa23['length'];++_0x4c490b){const _0x24b98c=_0x2eaa23[_0x4c490b];_0x381c8b['listenProvider_']['stopListening'](Tt(_0x24b98c),Mt(_0x381c8b,_0x24b98c));}}return _0x4ae294;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x427327){this['node_']=_0x427327;}['getImmediateChild'](_0x208de5){const _0x4933f7=this['node_']['getImmediateChild'](_0x208de5);return new cs(_0x4933f7);}['node'](){return this['node_'];}}class ls{constructor(_0x36cd1a,_0xdee553){this['syncTree_']=_0x36cd1a,this['path_']=_0xdee553;}['getImmediateChild'](_0x47634a){const _0x1a21c3=A(this['path_'],_0x47634a);return new ls(this['syncTree_'],_0x1a21c3);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x56c9fb){return _0x56c9fb=_0x56c9fb||{},_0x56c9fb['timestamp']=_0x56c9fb['timestamp']||new Date()['getTime'](),_0x56c9fb;},fr=function(_0x344d32,_0x379d76,_0x2c2b38){if(!_0x344d32||typeof _0x344d32!='object')return _0x344d32;if(f('.sv'in _0x344d32,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x344d32['.sv']=='string')return td(_0x344d32['.sv'],_0x379d76,_0x2c2b38);if(typeof _0x344d32['.sv']=='object')return nd(_0x344d32['.sv'],_0x379d76);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x344d32,null,0x2));},td=function(_0x1bf8cd,_0x200d7a,_0x13ffd0){switch(_0x1bf8cd){case'timestamp':return _0x13ffd0['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1bf8cd);}},nd=function(_0x16e11f,_0x16f82c,_0x4adfe5){_0x16e11f['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x16e11f,null,0x2));const _0x4ea037=_0x16e11f['increment'];typeof _0x4ea037!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4ea037);const _0x529e51=_0x16f82c['node']();if(f(_0x529e51!==null&&typeof _0x529e51<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x529e51['isLeafNode']())return _0x4ea037;const _0xb85073=_0x529e51['getValue']();return typeof _0xb85073!='number'?_0x4ea037:_0xb85073+_0x4ea037;},Zo=function(_0xb5843,_0x44dbb8,_0x2d0a6c,_0x4194ab){return us(_0x44dbb8,new ls(_0x2d0a6c,_0xb5843),_0x4194ab);},hs=function(_0x49ecc2,_0x1401ef,_0x4f0685){return us(_0x49ecc2,new cs(_0x1401ef),_0x4f0685);};function us(_0x5b7a48,_0x406d94,_0x6b4eee){const _0x508940=_0x5b7a48['getPriority']()['val'](),_0x8893b0=fr(_0x508940,_0x406d94['getImmediateChild']('.priority'),_0x6b4eee);let _0x44b937;if(_0x5b7a48['isLeafNode']()){const _0x45989d=_0x5b7a48,_0x3fd38c=fr(_0x45989d['getValue'](),_0x406d94,_0x6b4eee);return _0x3fd38c!==_0x45989d['getValue']()||_0x8893b0!==_0x45989d['getPriority']()['val']()?new D(_0x3fd38c,N(_0x8893b0)):_0x5b7a48;}else{const _0x2ba853=_0x5b7a48;return _0x44b937=_0x2ba853,_0x8893b0!==_0x2ba853['getPriority']()['val']()&&(_0x44b937=_0x44b937['updatePriority'](new D(_0x8893b0))),_0x2ba853['forEachChild'](R,(_0x4c9b55,_0x15f2e2)=>{const _0x157946=us(_0x15f2e2,_0x406d94['getImmediateChild'](_0x4c9b55),_0x6b4eee);_0x157946!==_0x15f2e2&&(_0x44b937=_0x44b937['updateImmediateChild'](_0x4c9b55,_0x157946));}),_0x44b937;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x509c5b='',_0x17a008=null,_0x2a9bf4={'children':{},'childCount':0x0}){this['name']=_0x509c5b,this['parent']=_0x17a008,this['node']=_0x2a9bf4;}}function Un(_0x5098f3,_0x2352b6){let _0x34b792=_0x2352b6 instanceof C?_0x2352b6:new C(_0x2352b6),_0x1dfdbd=_0x5098f3,_0x2bf39b=y(_0x34b792);for(;_0x2bf39b!==null;){const _0x312567=Oe(_0x1dfdbd['node']['children'],_0x2bf39b)||{'children':{},'childCount':0x0};_0x1dfdbd=new ds(_0x2bf39b,_0x1dfdbd,_0x312567),_0x34b792=b(_0x34b792),_0x2bf39b=y(_0x34b792);}return _0x1dfdbd;}function Ge(_0x4258fe){return _0x4258fe['node']['value'];}function fs(_0xf460b0,_0x456ef4){_0xf460b0['node']['value']=_0x456ef4,Ri(_0xf460b0);}function ea(_0x5596f3){return _0x5596f3['node']['childCount']>0x0;}function id(_0x2eb531){return Ge(_0x2eb531)===void 0x0&&!ea(_0x2eb531);}function Wn(_0x50bfed,_0x5584ed){x(_0x50bfed['node']['children'],(_0x48752b,_0x13de42)=>{_0x5584ed(new ds(_0x48752b,_0x50bfed,_0x13de42));});}function ta(_0x13e57a,_0x30b6e9,_0x267b64,_0x4e63b3){_0x267b64&&_0x30b6e9(_0x13e57a),Wn(_0x13e57a,_0x14cba4=>{ta(_0x14cba4,_0x30b6e9,!0x0);});}function sd(_0x130721,_0x33f812,_0x3e2855){let _0x59ab46=_0x130721['parent'];for(;_0x59ab46!==null;){if(_0x33f812(_0x59ab46))return!0x0;_0x59ab46=_0x59ab46['parent'];}return!0x1;}function Gt(_0x1b46a7){return new C(_0x1b46a7['parent']===null?_0x1b46a7['name']:Gt(_0x1b46a7['parent'])+'/'+_0x1b46a7['name']);}function Ri(_0x4f9ec8){_0x4f9ec8['parent']!==null&&rd(_0x4f9ec8['parent'],_0x4f9ec8['name'],_0x4f9ec8);}function rd(_0x5ef9c1,_0x343ed1,_0x320427){const _0x305c42=id(_0x320427),_0x523b0e=Y(_0x5ef9c1['node']['children'],_0x343ed1);_0x305c42&&_0x523b0e?(delete _0x5ef9c1['node']['children'][_0x343ed1],_0x5ef9c1['node']['childCount']--,Ri(_0x5ef9c1)):!_0x305c42&&!_0x523b0e&&(_0x5ef9c1['node']['children'][_0x343ed1]=_0x320427['node'],_0x5ef9c1['node']['childCount']++,Ri(_0x5ef9c1));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0xe9aabb){return typeof _0xe9aabb=='string'&&_0xe9aabb['length']!==0x0&&!od['test'](_0xe9aabb);},na=function(_0x3fa049){return typeof _0x3fa049=='string'&&_0x3fa049['length']!==0x0&&!ad['test'](_0x3fa049);},cd=function(_0x495754){return _0x495754&&(_0x495754=_0x495754['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x495754);},Cn=function(_0x1b37f8){return _0x1b37f8===null||typeof _0x1b37f8=='string'||typeof _0x1b37f8=='number'&&!Wi(_0x1b37f8)||_0x1b37f8&&typeof _0x1b37f8=='object'&&Y(_0x1b37f8,'.sv');},qt=function(_0x428f3d,_0x3438cf,_0x4ad9d1,_0x82905c){_0x82905c&&_0x3438cf===void 0x0||zt(Nn(_0x428f3d,'value'),_0x3438cf,_0x4ad9d1);},zt=function(_0x51a93a,_0x24d27b,_0x32b5aa){const _0x1e3241=_0x32b5aa instanceof C?new Sh(_0x32b5aa,_0x51a93a):_0x32b5aa;if(_0x24d27b===void 0x0)throw new Error(_0x51a93a+'contains\x20undefined\x20'+Ne(_0x1e3241));if(typeof _0x24d27b=='function')throw new Error(_0x51a93a+'contains\x20a\x20function\x20'+Ne(_0x1e3241)+'\x20with\x20contents\x20=\x20'+_0x24d27b['toString']());if(Wi(_0x24d27b))throw new Error(_0x51a93a+'contains\x20'+_0x24d27b['toString']()+'\x20'+Ne(_0x1e3241));if(typeof _0x24d27b=='string'&&_0x24d27b['length']>oi/0x3&&Pn(_0x24d27b)>oi)throw new Error(_0x51a93a+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x1e3241)+'\x20(\x27'+_0x24d27b['substring'](0x0,0x32)+'...\x27)');if(_0x24d27b&&typeof _0x24d27b=='object'){let _0x123486=!0x1,_0x4019b9=!0x1;if(x(_0x24d27b,(_0x1fa6bf,_0x4076cb)=>{if(_0x1fa6bf==='.value')_0x123486=!0x0;else{if(_0x1fa6bf!=='.priority'&&_0x1fa6bf!=='.sv'&&(_0x4019b9=!0x0,!ps(_0x1fa6bf)))throw new Error(_0x51a93a+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1fa6bf+')\x20'+Ne(_0x1e3241)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x1e3241,_0x1fa6bf),zt(_0x51a93a,_0x4076cb,_0x1e3241),Rh(_0x1e3241);}),_0x123486&&_0x4019b9)throw new Error(_0x51a93a+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x1e3241)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x27068f,_0x141454){let _0x278fef,_0x405160;for(_0x278fef=0x0;_0x278fef<_0x141454['length'];_0x278fef++){_0x405160=_0x141454[_0x278fef];const _0x196037=kt(_0x405160);for(let _0x7567a2=0x0;_0x7567a2<_0x196037['length'];_0x7567a2++)if(!(_0x196037[_0x7567a2]==='.priority'&&_0x7567a2===_0x196037['length']-0x1)){if(!ps(_0x196037[_0x7567a2]))throw new Error(_0x27068f+'contains\x20an\x20invalid\x20key\x20('+_0x196037[_0x7567a2]+')\x20in\x20path\x20'+_0x405160['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x141454['sort'](Th);let _0xedaf04=null;for(_0x278fef=0x0;_0x278fef<_0x141454['length'];_0x278fef++){if(_0x405160=_0x141454[_0x278fef],_0xedaf04!==null&&$(_0xedaf04,_0x405160))throw new Error(_0x27068f+'contains\x20a\x20path\x20'+_0xedaf04['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x405160['toString']());_0xedaf04=_0x405160;}},hd=function(_0x3737bc,_0x1abd83,_0x4ac992,_0x1f5748){const _0xbd93e5=Nn(_0x3737bc,'values');if(!(_0x1abd83&&typeof _0x1abd83=='object')||Array['isArray'](_0x1abd83))throw new Error(_0xbd93e5+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x36ccc7=[];x(_0x1abd83,(_0x1987d6,_0x12e4e8)=>{const _0x105a4d=new C(_0x1987d6);if(zt(_0xbd93e5,_0x12e4e8,A(_0x4ac992,_0x105a4d)),Gi(_0x105a4d)==='.priority'&&!Cn(_0x12e4e8))throw new Error(_0xbd93e5+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x105a4d['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x36ccc7['push'](_0x105a4d);}),ld(_0xbd93e5,_0x36ccc7);},_s=function(_0x3c66ed,_0x205b73,_0x358a55,_0x4d55f6){if(!na(_0x358a55))throw new Error(Nn(_0x3c66ed,_0x205b73)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x358a55+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0xbbb860,_0x346689,_0xbe3199,_0x5e7774){_0xbe3199&&(_0xbe3199=_0xbe3199['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0xbbb860,_0x346689,_0xbe3199);},gs=function(_0x44aabd,_0x93c417){if(y(_0x93c417)==='.info')throw new Error(_0x44aabd+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0xd2fde6,_0x55bf15){const _0x34c8f1=_0x55bf15['path']['toString']();if(typeof _0x55bf15['repoInfo']['host']!='string'||_0x55bf15['repoInfo']['host']['length']===0x0||!ps(_0x55bf15['repoInfo']['namespace'])&&_0x55bf15['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x34c8f1['length']!==0x0&&!cd(_0x34c8f1))throw new Error(Nn(_0xd2fde6,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x2cc73e,_0x23721a){let _0x2d67bf=null;for(let _0x4c62ce=0x0;_0x4c62ce<_0x23721a['length'];_0x4c62ce++){const _0x51dd0e=_0x23721a[_0x4c62ce],_0x564faa=_0x51dd0e['getPath']();_0x2d67bf!==null&&!qi(_0x564faa,_0x2d67bf['path'])&&(_0x2cc73e['eventLists_']['push'](_0x2d67bf),_0x2d67bf=null),_0x2d67bf===null&&(_0x2d67bf={'events':[],'path':_0x564faa}),_0x2d67bf['events']['push'](_0x51dd0e);}_0x2d67bf&&_0x2cc73e['eventLists_']['push'](_0x2d67bf);}function ia(_0x229671,_0x3bf676,_0x189416){Bn(_0x229671,_0x189416),sa(_0x229671,_0xe5be7a=>qi(_0xe5be7a,_0x3bf676));}function V(_0x37cd13,_0x38faf3,_0x11d58a){Bn(_0x37cd13,_0x11d58a),sa(_0x37cd13,_0x52070b=>$(_0x52070b,_0x38faf3)||$(_0x38faf3,_0x52070b));}function sa(_0x557d2b,_0x23d86b){_0x557d2b['recursionDepth_']++;let _0x51677b=!0x0;for(let _0x20643a=0x0;_0x20643a<_0x557d2b['eventLists_']['length'];_0x20643a++){const _0x3a5ef4=_0x557d2b['eventLists_'][_0x20643a];if(_0x3a5ef4){const _0x3b7a00=_0x3a5ef4['path'];_0x23d86b(_0x3b7a00)?(pd(_0x557d2b['eventLists_'][_0x20643a]),_0x557d2b['eventLists_'][_0x20643a]=null):_0x51677b=!0x1;}}_0x51677b&&(_0x557d2b['eventLists_']=[]),_0x557d2b['recursionDepth_']--;}function pd(_0x573b7a){for(let _0x19aee=0x0;_0x19aee<_0x573b7a['events']['length'];_0x19aee++){const _0x4d90bb=_0x573b7a['events'][_0x19aee];if(_0x4d90bb!==null){_0x573b7a['events'][_0x19aee]=null;const _0x31268d=_0x4d90bb['getEventRunner']();Et&&L('event:\x20'+_0x4d90bb['toString']()),lt(_0x31268d);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x5c5e50,_0x49dae0,_0x41d317,_0x36b931){this['repoInfo_']=_0x5c5e50,this['forceRestClient_']=_0x49dae0,this['authTokenProvider_']=_0x41d317,this['appCheckProvider_']=_0x36b931,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x309e4f,_0x3f36bb,_0x3275d2){if(_0x309e4f['stats_']=Hi(_0x309e4f['repoInfo_']),_0x309e4f['forceRestClient_']||Yl())_0x309e4f['server_']=new fn(_0x309e4f['repoInfo_'],(_0x5ecfb5,_0x249b8a,_0x301290,_0x205b2e)=>{pr(_0x309e4f,_0x5ecfb5,_0x249b8a,_0x301290,_0x205b2e);},_0x309e4f['authTokenProvider_'],_0x309e4f['appCheckProvider_']),setTimeout(()=>_r(_0x309e4f,!0x0),0x0);else{if(typeof _0x3275d2<'u'&&_0x3275d2!==null){if(typeof _0x3275d2!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x3275d2);}catch(_0x1f8e99){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1f8e99);}}_0x309e4f['persistentConnection_']=new ie(_0x309e4f['repoInfo_'],_0x3f36bb,(_0x3c677c,_0xcdf7ba,_0x53497f,_0x582230)=>{pr(_0x309e4f,_0x3c677c,_0xcdf7ba,_0x53497f,_0x582230);},_0x6297=>{_r(_0x309e4f,_0x6297);},_0x344569=>{yd(_0x309e4f,_0x344569);},_0x309e4f['authTokenProvider_'],_0x309e4f['appCheckProvider_'],_0x3275d2),_0x309e4f['server_']=_0x309e4f['persistentConnection_'];}_0x309e4f['authTokenProvider_']['addTokenChangeListener'](_0x11bfa4=>{_0x309e4f['server_']['refreshAuthToken'](_0x11bfa4);}),_0x309e4f['appCheckProvider_']['addTokenChangeListener'](_0x19727c=>{_0x309e4f['server_']['refreshAppCheckToken'](_0x19727c['token']);}),_0x309e4f['statsReporter_']=eh(_0x309e4f['repoInfo_'],()=>new eu(_0x309e4f['stats_'],_0x309e4f['server_'])),_0x309e4f['infoData_']=new Yh(),_0x309e4f['infoSyncTree_']=new dr({'startListening':(_0x3add37,_0x1600fd,_0x18ab26,_0x32f552)=>{let _0x3922d1=[];const _0x598cc3=_0x309e4f['infoData_']['getNode'](_0x3add37['_path']);return _0x598cc3['isEmpty']()||(_0x3922d1=$t(_0x309e4f['infoSyncTree_'],_0x3add37['_path'],_0x598cc3),setTimeout(()=>{_0x32f552('ok');},0x0)),_0x3922d1;},'stopListening':()=>{}}),ms(_0x309e4f,'connected',!0x1),_0x309e4f['serverSyncTree_']=new dr({'startListening':(_0x353ccb,_0x17443e,_0x213de8,_0x1779e5)=>(_0x309e4f['server_']['listen'](_0x353ccb,_0x213de8,_0x17443e,(_0x597f03,_0x42974c)=>{const _0x3f4ede=_0x1779e5(_0x597f03,_0x42974c);V(_0x309e4f['eventQueue_'],_0x353ccb['_path'],_0x3f4ede);}),[]),'stopListening':(_0x157d3a,_0x5f4e19)=>{_0x309e4f['server_']['unlisten'](_0x157d3a,_0x5f4e19);}});}function oa(_0x8172bb){const _0x53bb15=_0x8172bb['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x53bb15;}function jt(_0x497269){return ed({'timestamp':oa(_0x497269)});}function pr(_0x515df8,_0x4c451d,_0x413853,_0x433713,_0x1d39ae){_0x515df8['dataUpdateCount']++;const _0x5d5a22=new C(_0x4c451d);_0x413853=_0x515df8['interceptServerDataCallback_']?_0x515df8['interceptServerDataCallback_'](_0x4c451d,_0x413853):_0x413853;let _0x1571ab=[];if(_0x1d39ae){if(_0x433713){const _0x3949c6=ln(_0x413853,_0xc1c8ee=>N(_0xc1c8ee));_0x1571ab=Ku(_0x515df8['serverSyncTree_'],_0x5d5a22,_0x3949c6,_0x1d39ae);}else{const _0x130710=N(_0x413853);_0x1571ab=Yo(_0x515df8['serverSyncTree_'],_0x5d5a22,_0x130710,_0x1d39ae);}}else{if(_0x433713){const _0x116c7b=ln(_0x413853,_0xe0b0da=>N(_0xe0b0da));_0x1571ab=qu(_0x515df8['serverSyncTree_'],_0x5d5a22,_0x116c7b);}else{const _0x58e663=N(_0x413853);_0x1571ab=$t(_0x515df8['serverSyncTree_'],_0x5d5a22,_0x58e663);}}let _0x4916a5=_0x5d5a22;_0x1571ab['length']>0x0&&(_0x4916a5=st(_0x515df8,_0x5d5a22)),V(_0x515df8['eventQueue_'],_0x4916a5,_0x1571ab);}function _r(_0x2e1624,_0xe7cf71){ms(_0x2e1624,'connected',_0xe7cf71),_0xe7cf71===!0x1&&wd(_0x2e1624);}function yd(_0xef4fea,_0x553eef){x(_0x553eef,(_0x59b936,_0x168a60)=>{ms(_0xef4fea,_0x59b936,_0x168a60);});}function ms(_0x1a6cdb,_0x3b1a26,_0x1b4265){const _0x15a083=new C('/.info/'+_0x3b1a26),_0x78cc8=N(_0x1b4265);_0x1a6cdb['infoData_']['updateSnapshot'](_0x15a083,_0x78cc8);const _0x95f3c1=$t(_0x1a6cdb['infoSyncTree_'],_0x15a083,_0x78cc8);V(_0x1a6cdb['eventQueue_'],_0x15a083,_0x95f3c1);}function Vn(_0x156e4b){return _0x156e4b['nextWriteId_']++;}function vd(_0x1109ed,_0xd111c9,_0x4e9df6){const _0x3d7489=Yu(_0x1109ed['serverSyncTree_'],_0xd111c9);return _0x3d7489!=null?Promise['resolve'](_0x3d7489):_0x1109ed['server_']['get'](_0xd111c9)['then'](_0x2f9a14=>{const _0x2792e7=N(_0x2f9a14)['withIndex'](_0xd111c9['_queryParams']['getIndex']());bi(_0x1109ed['serverSyncTree_'],_0xd111c9,_0x4e9df6,!0x0);let _0x2a2d7f;if(_0xd111c9['_queryParams']['loadsAllData']())_0x2a2d7f=$t(_0x1109ed['serverSyncTree_'],_0xd111c9['_path'],_0x2792e7);else{const _0x30f7eb=Mt(_0x1109ed['serverSyncTree_'],_0xd111c9);_0x2a2d7f=Yo(_0x1109ed['serverSyncTree_'],_0xd111c9['_path'],_0x2792e7,_0x30f7eb);}return V(_0x1109ed['eventQueue_'],_0xd111c9['_path'],_0x2a2d7f),wn(_0x1109ed['serverSyncTree_'],_0xd111c9,_0x4e9df6,null,!0x0),_0x2792e7;},_0x25daa9=>(ut(_0x1109ed,'get\x20for\x20query\x20'+O(_0xd111c9)+'\x20failed:\x20'+_0x25daa9),Promise['reject'](new Error(_0x25daa9))));}function Ed(_0x12f9a5,_0xff167a,_0x5e2181,_0x45c081,_0xd27c66){ut(_0x12f9a5,'set',{'path':_0xff167a['toString'](),'value':_0x5e2181,'priority':_0x45c081});const _0x430695=jt(_0x12f9a5),_0xbb6451=N(_0x5e2181,_0x45c081),_0x521c1b=xn(_0x12f9a5['serverSyncTree_'],_0xff167a),_0x911a7c=hs(_0xbb6451,_0x521c1b,_0x430695),_0x5926e8=Vn(_0x12f9a5),_0x4fdaa2=ss(_0x12f9a5['serverSyncTree_'],_0xff167a,_0x911a7c,_0x5926e8,!0x0);Bn(_0x12f9a5['eventQueue_'],_0x4fdaa2),_0x12f9a5['server_']['put'](_0xff167a['toString'](),_0xbb6451['val'](!0x0),(_0x470527,_0x1dd777)=>{const _0x8d4175=_0x470527==='ok';_0x8d4175||U('set\x20at\x20'+_0xff167a+'\x20failed:\x20'+_0x470527);const _0x237aff=pe(_0x12f9a5['serverSyncTree_'],_0x5926e8,!_0x8d4175);V(_0x12f9a5['eventQueue_'],_0xff167a,_0x237aff),Ai(_0x12f9a5,_0xd27c66,_0x470527,_0x1dd777);});const _0x2830d7=vs(_0x12f9a5,_0xff167a);st(_0x12f9a5,_0x2830d7),V(_0x12f9a5['eventQueue_'],_0x2830d7,[]);}function Id(_0x3f1794,_0xa6cb9d,_0x10a876,_0x2d88b2){ut(_0x3f1794,'update',{'path':_0xa6cb9d['toString'](),'value':_0x10a876});let _0x2c5b09=!0x0;const _0x1744a4=jt(_0x3f1794),_0x54b252={};if(x(_0x10a876,(_0x1e2279,_0x2b7061)=>{_0x2c5b09=!0x1,_0x54b252[_0x1e2279]=Zo(A(_0xa6cb9d,_0x1e2279),N(_0x2b7061),_0x3f1794['serverSyncTree_'],_0x1744a4);}),_0x2c5b09)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x3f1794,_0x2d88b2,'ok',void 0x0);else{const _0x1407cc=Vn(_0x3f1794),_0x1b4c8b=Gu(_0x3f1794['serverSyncTree_'],_0xa6cb9d,_0x54b252,_0x1407cc);Bn(_0x3f1794['eventQueue_'],_0x1b4c8b),_0x3f1794['server_']['merge'](_0xa6cb9d['toString'](),_0x10a876,(_0x4e73a1,_0x276fc4)=>{const _0x422596=_0x4e73a1==='ok';_0x422596||U('update\x20at\x20'+_0xa6cb9d+'\x20failed:\x20'+_0x4e73a1);const _0x439138=pe(_0x3f1794['serverSyncTree_'],_0x1407cc,!_0x422596),_0x520923=_0x439138['length']>0x0?st(_0x3f1794,_0xa6cb9d):_0xa6cb9d;V(_0x3f1794['eventQueue_'],_0x520923,_0x439138),Ai(_0x3f1794,_0x2d88b2,_0x4e73a1,_0x276fc4);}),x(_0x10a876,_0x11ec27=>{const _0x4cc671=vs(_0x3f1794,A(_0xa6cb9d,_0x11ec27));st(_0x3f1794,_0x4cc671);}),V(_0x3f1794['eventQueue_'],_0xa6cb9d,[]);}}function wd(_0x365a21){ut(_0x365a21,'onDisconnectEvents');const _0x6c946c=jt(_0x365a21),_0x1e9df4=pn();Ei(_0x365a21['onDisconnect_'],w(),(_0x4a6575,_0x3c8b4b)=>{const _0x510434=Zo(_0x4a6575,_0x3c8b4b,_0x365a21['serverSyncTree_'],_0x6c946c);Mo(_0x1e9df4,_0x4a6575,_0x510434);});let _0x390d7a=[];Ei(_0x1e9df4,w(),(_0x13a6cb,_0x357cfb)=>{_0x390d7a=_0x390d7a['concat']($t(_0x365a21['serverSyncTree_'],_0x13a6cb,_0x357cfb));const _0x47e043=vs(_0x365a21,_0x13a6cb);st(_0x365a21,_0x47e043);}),_0x365a21['onDisconnect_']=pn(),V(_0x365a21['eventQueue_'],w(),_0x390d7a);}function Cd(_0x197345,_0x515927,_0x732091){let _0x536bce;y(_0x515927['_path'])==='.info'?_0x536bce=bi(_0x197345['infoSyncTree_'],_0x515927,_0x732091):_0x536bce=bi(_0x197345['serverSyncTree_'],_0x515927,_0x732091),ia(_0x197345['eventQueue_'],_0x515927['_path'],_0x536bce);}function Td(_0x5054d4,_0x4b802e,_0x3661ed){let _0x8d06fe;y(_0x4b802e['_path'])==='.info'?_0x8d06fe=wn(_0x5054d4['infoSyncTree_'],_0x4b802e,_0x3661ed):_0x8d06fe=wn(_0x5054d4['serverSyncTree_'],_0x4b802e,_0x3661ed),ia(_0x5054d4['eventQueue_'],_0x4b802e['_path'],_0x8d06fe);}function aa(_0x348003){_0x348003['persistentConnection_']&&_0x348003['persistentConnection_']['interrupt'](ra);}function Sd(_0x98ebfa){_0x98ebfa['persistentConnection_']&&_0x98ebfa['persistentConnection_']['resume'](ra);}function ut(_0x2f7d1c,..._0x304711){let _0x360a89='';_0x2f7d1c['persistentConnection_']&&(_0x360a89=_0x2f7d1c['persistentConnection_']['id']+':'),L(_0x360a89,..._0x304711);}function Ai(_0x1bd012,_0x38eb8b,_0x59f6a9,_0x52bd69){_0x38eb8b&&lt(()=>{if(_0x59f6a9==='ok')_0x38eb8b(null);else{const _0x422416=(_0x59f6a9||'error')['toUpperCase']();let _0x11eb5a=_0x422416;_0x52bd69&&(_0x11eb5a+=':\x20'+_0x52bd69);const _0x29997e=new Error(_0x11eb5a);_0x29997e['code']=_0x422416,_0x38eb8b(_0x29997e);}});}function bd(_0x13ad4c,_0x3cce44,_0x11e436,_0x466def,_0x55791e,_0x21cfdc){ut(_0x13ad4c,'transaction\x20on\x20'+_0x3cce44);const _0x410108={'path':_0x3cce44,'update':_0x11e436,'onComplete':_0x466def,'status':null,'order':to(),'applyLocally':_0x21cfdc,'retryCount':0x0,'unwatcher':_0x55791e,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x340cab=ys(_0x13ad4c,_0x3cce44,void 0x0);_0x410108['currentInputSnapshot']=_0x340cab;const _0x5cf456=_0x410108['update'](_0x340cab['val']());if(_0x5cf456===void 0x0)_0x410108['unwatcher'](),_0x410108['currentOutputSnapshotRaw']=null,_0x410108['currentOutputSnapshotResolved']=null,_0x410108['onComplete']&&_0x410108['onComplete'](null,!0x1,_0x410108['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x5cf456,_0x410108['path']),_0x410108['status']=0x0;const _0x5e9f7f=Un(_0x13ad4c['transactionQueueTree_'],_0x3cce44),_0x58d5ee=Ge(_0x5e9f7f)||[];_0x58d5ee['push'](_0x410108),fs(_0x5e9f7f,_0x58d5ee);let _0x7a2881;typeof _0x5cf456=='object'&&_0x5cf456!==null&&Y(_0x5cf456,'.priority')?(_0x7a2881=Oe(_0x5cf456,'.priority'),f(Cn(_0x7a2881),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x7a2881=(xn(_0x13ad4c['serverSyncTree_'],_0x3cce44)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x4286e3=jt(_0x13ad4c),_0xe4e5a1=N(_0x5cf456,_0x7a2881),_0x3b0874=hs(_0xe4e5a1,_0x340cab,_0x4286e3);_0x410108['currentOutputSnapshotRaw']=_0xe4e5a1,_0x410108['currentOutputSnapshotResolved']=_0x3b0874,_0x410108['currentWriteId']=Vn(_0x13ad4c);const _0x3c8782=ss(_0x13ad4c['serverSyncTree_'],_0x3cce44,_0x3b0874,_0x410108['currentWriteId'],_0x410108['applyLocally']);V(_0x13ad4c['eventQueue_'],_0x3cce44,_0x3c8782),Hn(_0x13ad4c,_0x13ad4c['transactionQueueTree_']);}}function ys(_0x49f9cf,_0x4594f4,_0x254ac9){return xn(_0x49f9cf['serverSyncTree_'],_0x4594f4,_0x254ac9)||g['EMPTY_NODE'];}function Hn(_0x1378ad,_0x4ce008=_0x1378ad['transactionQueueTree_']){if(_0x4ce008||$n(_0x1378ad,_0x4ce008),Ge(_0x4ce008)){const _0x35aa6d=la(_0x1378ad,_0x4ce008);f(_0x35aa6d['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x35aa6d['every'](_0x59e1a8=>_0x59e1a8['status']===0x0)&&Rd(_0x1378ad,Gt(_0x4ce008),_0x35aa6d);}else ea(_0x4ce008)&&Wn(_0x4ce008,_0x509702=>{Hn(_0x1378ad,_0x509702);});}function Rd(_0x6618c9,_0xc0dce9,_0x21b6e4){const _0xb88757=_0x21b6e4['map'](_0xc011d1=>_0xc011d1['currentWriteId']),_0x487069=ys(_0x6618c9,_0xc0dce9,_0xb88757);let _0x557e4c=_0x487069;const _0x550f07=_0x487069['hash']();for(let _0x55530e=0x0;_0x55530e<_0x21b6e4['length'];_0x55530e++){const _0x171ac5=_0x21b6e4[_0x55530e];f(_0x171ac5['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x171ac5['status']=0x1,_0x171ac5['retryCount']++;const _0x282511=F(_0xc0dce9,_0x171ac5['path']);_0x557e4c=_0x557e4c['updateChild'](_0x282511,_0x171ac5['currentOutputSnapshotRaw']);}const _0x12524=_0x557e4c['val'](!0x0),_0x3442cf=_0xc0dce9;_0x6618c9['server_']['put'](_0x3442cf['toString'](),_0x12524,_0x738712=>{ut(_0x6618c9,'transaction\x20put\x20response',{'path':_0x3442cf['toString'](),'status':_0x738712});let _0x5cdd34=[];if(_0x738712==='ok'){const _0xebd0fd=[];for(let _0x14f77b=0x0;_0x14f77b<_0x21b6e4['length'];_0x14f77b++)_0x21b6e4[_0x14f77b]['status']=0x2,_0x5cdd34=_0x5cdd34['concat'](pe(_0x6618c9['serverSyncTree_'],_0x21b6e4[_0x14f77b]['currentWriteId'])),_0x21b6e4[_0x14f77b]['onComplete']&&_0xebd0fd['push'](()=>_0x21b6e4[_0x14f77b]['onComplete'](null,!0x0,_0x21b6e4[_0x14f77b]['currentOutputSnapshotResolved'])),_0x21b6e4[_0x14f77b]['unwatcher']();$n(_0x6618c9,Un(_0x6618c9['transactionQueueTree_'],_0xc0dce9)),Hn(_0x6618c9,_0x6618c9['transactionQueueTree_']),V(_0x6618c9['eventQueue_'],_0xc0dce9,_0x5cdd34);for(let _0x1f23de=0x0;_0x1f23de<_0xebd0fd['length'];_0x1f23de++)lt(_0xebd0fd[_0x1f23de]);}else{if(_0x738712==='datastale'){for(let _0x17854a=0x0;_0x17854a<_0x21b6e4['length'];_0x17854a++)_0x21b6e4[_0x17854a]['status']===0x3?_0x21b6e4[_0x17854a]['status']=0x4:_0x21b6e4[_0x17854a]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3442cf['toString']()+'\x20failed:\x20'+_0x738712);for(let _0x4b54a4=0x0;_0x4b54a4<_0x21b6e4['length'];_0x4b54a4++)_0x21b6e4[_0x4b54a4]['status']=0x4,_0x21b6e4[_0x4b54a4]['abortReason']=_0x738712;}st(_0x6618c9,_0xc0dce9);}},_0x550f07);}function st(_0xe3b61f,_0x26a28b){const _0x267dda=ca(_0xe3b61f,_0x26a28b),_0x4576da=Gt(_0x267dda),_0x4a8abf=la(_0xe3b61f,_0x267dda);return Ad(_0xe3b61f,_0x4a8abf,_0x4576da),_0x4576da;}function Ad(_0x5d7633,_0x6c69ae,_0x2415db){if(_0x6c69ae['length']===0x0)return;const _0x4397c2=[];let _0x5d4cf9=[];const _0x3076a9=_0x6c69ae['filter'](_0x6c7741=>_0x6c7741['status']===0x0)['map'](_0x517c2d=>_0x517c2d['currentWriteId']);for(let _0x299460=0x0;_0x299460<_0x6c69ae['length'];_0x299460++){const _0x3b09cc=_0x6c69ae[_0x299460],_0x4302a2=F(_0x2415db,_0x3b09cc['path']);let _0x50cfb5=!0x1,_0x42daba;if(f(_0x4302a2!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3b09cc['status']===0x4)_0x50cfb5=!0x0,_0x42daba=_0x3b09cc['abortReason'],_0x5d4cf9=_0x5d4cf9['concat'](pe(_0x5d7633['serverSyncTree_'],_0x3b09cc['currentWriteId'],!0x0));else{if(_0x3b09cc['status']===0x0){if(_0x3b09cc['retryCount']>=_d)_0x50cfb5=!0x0,_0x42daba='maxretry',_0x5d4cf9=_0x5d4cf9['concat'](pe(_0x5d7633['serverSyncTree_'],_0x3b09cc['currentWriteId'],!0x0));else{const _0x5e8c9b=ys(_0x5d7633,_0x3b09cc['path'],_0x3076a9);_0x3b09cc['currentInputSnapshot']=_0x5e8c9b;const _0x504a67=_0x6c69ae[_0x299460]['update'](_0x5e8c9b['val']());if(_0x504a67!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x504a67,_0x3b09cc['path']);let _0x44585d=N(_0x504a67);typeof _0x504a67=='object'&&_0x504a67!=null&&Y(_0x504a67,'.priority')||(_0x44585d=_0x44585d['updatePriority'](_0x5e8c9b['getPriority']()));const _0x224d64=_0x3b09cc['currentWriteId'],_0x16504e=jt(_0x5d7633),_0xaa0fa6=hs(_0x44585d,_0x5e8c9b,_0x16504e);_0x3b09cc['currentOutputSnapshotRaw']=_0x44585d,_0x3b09cc['currentOutputSnapshotResolved']=_0xaa0fa6,_0x3b09cc['currentWriteId']=Vn(_0x5d7633),_0x3076a9['splice'](_0x3076a9['indexOf'](_0x224d64),0x1),_0x5d4cf9=_0x5d4cf9['concat'](ss(_0x5d7633['serverSyncTree_'],_0x3b09cc['path'],_0xaa0fa6,_0x3b09cc['currentWriteId'],_0x3b09cc['applyLocally'])),_0x5d4cf9=_0x5d4cf9['concat'](pe(_0x5d7633['serverSyncTree_'],_0x224d64,!0x0));}else _0x50cfb5=!0x0,_0x42daba='nodata',_0x5d4cf9=_0x5d4cf9['concat'](pe(_0x5d7633['serverSyncTree_'],_0x3b09cc['currentWriteId'],!0x0));}}}V(_0x5d7633['eventQueue_'],_0x2415db,_0x5d4cf9),_0x5d4cf9=[],_0x50cfb5&&(_0x6c69ae[_0x299460]['status']=0x2,function(_0x3ad67b){setTimeout(_0x3ad67b,Math['floor'](0x0));}(_0x6c69ae[_0x299460]['unwatcher']),_0x6c69ae[_0x299460]['onComplete']&&(_0x42daba==='nodata'?_0x4397c2['push'](()=>_0x6c69ae[_0x299460]['onComplete'](null,!0x1,_0x6c69ae[_0x299460]['currentInputSnapshot'])):_0x4397c2['push'](()=>_0x6c69ae[_0x299460]['onComplete'](new Error(_0x42daba),!0x1,null))));}$n(_0x5d7633,_0x5d7633['transactionQueueTree_']);for(let _0x2a266e=0x0;_0x2a266e<_0x4397c2['length'];_0x2a266e++)lt(_0x4397c2[_0x2a266e]);Hn(_0x5d7633,_0x5d7633['transactionQueueTree_']);}function ca(_0x4f9995,_0x38e6c1){let _0x3d71f1,_0x50fc11=_0x4f9995['transactionQueueTree_'];for(_0x3d71f1=y(_0x38e6c1);_0x3d71f1!==null&&Ge(_0x50fc11)===void 0x0;)_0x50fc11=Un(_0x50fc11,_0x3d71f1),_0x38e6c1=b(_0x38e6c1),_0x3d71f1=y(_0x38e6c1);return _0x50fc11;}function la(_0x4e1597,_0x5315f4){const _0x213dbc=[];return ha(_0x4e1597,_0x5315f4,_0x213dbc),_0x213dbc['sort']((_0x4bc76c,_0x34d462)=>_0x4bc76c['order']-_0x34d462['order']),_0x213dbc;}function ha(_0xa2d34f,_0x1bcc1b,_0x25e2c5){const _0x3bde5a=Ge(_0x1bcc1b);if(_0x3bde5a){for(let _0x479f9a=0x0;_0x479f9a<_0x3bde5a['length'];_0x479f9a++)_0x25e2c5['push'](_0x3bde5a[_0x479f9a]);}Wn(_0x1bcc1b,_0x40b63=>{ha(_0xa2d34f,_0x40b63,_0x25e2c5);});}function $n(_0x1b762b,_0x5a5151){const _0x37a6b6=Ge(_0x5a5151);if(_0x37a6b6){let _0x4361d9=0x0;for(let _0x44d505=0x0;_0x44d505<_0x37a6b6['length'];_0x44d505++)_0x37a6b6[_0x44d505]['status']!==0x2&&(_0x37a6b6[_0x4361d9]=_0x37a6b6[_0x44d505],_0x4361d9++);_0x37a6b6['length']=_0x4361d9,fs(_0x5a5151,_0x37a6b6['length']>0x0?_0x37a6b6:void 0x0);}Wn(_0x5a5151,_0x54a9a3=>{$n(_0x1b762b,_0x54a9a3);});}function vs(_0x3a240a,_0x13561f){const _0x133a30=Gt(ca(_0x3a240a,_0x13561f)),_0x328a1d=Un(_0x3a240a['transactionQueueTree_'],_0x13561f);return sd(_0x328a1d,_0xbacfe5=>{ai(_0x3a240a,_0xbacfe5);}),ai(_0x3a240a,_0x328a1d),ta(_0x328a1d,_0x4da8e5=>{ai(_0x3a240a,_0x4da8e5);}),_0x133a30;}function ai(_0x36b899,_0x354a14){const _0x3da9ff=Ge(_0x354a14);if(_0x3da9ff){const _0x2a7655=[];let _0x4bcccb=[],_0x30c2c0=-0x1;for(let _0x5cd104=0x0;_0x5cd104<_0x3da9ff['length'];_0x5cd104++)_0x3da9ff[_0x5cd104]['status']===0x3||(_0x3da9ff[_0x5cd104]['status']===0x1?(f(_0x30c2c0===_0x5cd104-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x30c2c0=_0x5cd104,_0x3da9ff[_0x5cd104]['status']=0x3,_0x3da9ff[_0x5cd104]['abortReason']='set'):(f(_0x3da9ff[_0x5cd104]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x3da9ff[_0x5cd104]['unwatcher'](),_0x4bcccb=_0x4bcccb['concat'](pe(_0x36b899['serverSyncTree_'],_0x3da9ff[_0x5cd104]['currentWriteId'],!0x0)),_0x3da9ff[_0x5cd104]['onComplete']&&_0x2a7655['push'](_0x3da9ff[_0x5cd104]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x30c2c0===-0x1?fs(_0x354a14,void 0x0):_0x3da9ff['length']=_0x30c2c0+0x1,V(_0x36b899['eventQueue_'],Gt(_0x354a14),_0x4bcccb);for(let _0x456454=0x0;_0x456454<_0x2a7655['length'];_0x456454++)lt(_0x2a7655[_0x456454]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x544871){let _0x3990c7='';const _0xcfe116=_0x544871['split']('/');for(let _0x2dfc97=0x0;_0x2dfc97<_0xcfe116['length'];_0x2dfc97++)if(_0xcfe116[_0x2dfc97]['length']>0x0){let _0xb39f95=_0xcfe116[_0x2dfc97];try{_0xb39f95=decodeURIComponent(_0xb39f95['replace'](/\+/g,'\x20'));}catch{}_0x3990c7+='/'+_0xb39f95;}return _0x3990c7;}function Nd(_0x369f05){const _0x3e74a8={};_0x369f05['charAt'](0x0)==='?'&&(_0x369f05=_0x369f05['substring'](0x1));for(const _0x519d17 of _0x369f05['split']('&')){if(_0x519d17['length']===0x0)continue;const _0xd8f0b4=_0x519d17['split']('=');_0xd8f0b4['length']===0x2?_0x3e74a8[decodeURIComponent(_0xd8f0b4[0x0])]=decodeURIComponent(_0xd8f0b4[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x519d17+'\x27\x20in\x20query\x20\x27'+_0x369f05+'\x27');}return _0x3e74a8;}const gr=function(_0x339cdd,_0x390ed7){const _0x165067=Pd(_0x339cdd),_0x31bdf4=_0x165067['namespace'];_0x165067['domain']==='firebase.com'&&oe(_0x165067['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x31bdf4||_0x31bdf4==='undefined')&&_0x165067['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x165067['secure']||Bl();const _0x5d9bf0=_0x165067['scheme']==='ws'||_0x165067['scheme']==='wss';return{'repoInfo':new _o(_0x165067['host'],_0x165067['secure'],_0x31bdf4,_0x5d9bf0,_0x390ed7,'',_0x31bdf4!==_0x165067['subdomain']),'path':new C(_0x165067['pathString'])};},Pd=function(_0x5824bd){let _0xdbd6c2='',_0x11c2c8='',_0x27c68c='',_0x4f3ea6='',_0x526778='',_0x1d6b1=!0x0,_0x29656d='https',_0x42eb55=0x1bb;if(typeof _0x5824bd=='string'){let _0x4710ac=_0x5824bd['indexOf']('//');_0x4710ac>=0x0&&(_0x29656d=_0x5824bd['substring'](0x0,_0x4710ac-0x1),_0x5824bd=_0x5824bd['substring'](_0x4710ac+0x2));let _0x5f5a06=_0x5824bd['indexOf']('/');_0x5f5a06===-0x1&&(_0x5f5a06=_0x5824bd['length']);let _0x211007=_0x5824bd['indexOf']('?');_0x211007===-0x1&&(_0x211007=_0x5824bd['length']),_0xdbd6c2=_0x5824bd['substring'](0x0,Math['min'](_0x5f5a06,_0x211007)),_0x5f5a06<_0x211007&&(_0x4f3ea6=kd(_0x5824bd['substring'](_0x5f5a06,_0x211007)));const _0x197967=Nd(_0x5824bd['substring'](Math['min'](_0x5824bd['length'],_0x211007)));_0x4710ac=_0xdbd6c2['indexOf'](':'),_0x4710ac>=0x0?(_0x1d6b1=_0x29656d==='https'||_0x29656d==='wss',_0x42eb55=parseInt(_0xdbd6c2['substring'](_0x4710ac+0x1),0xa)):_0x4710ac=_0xdbd6c2['length'];const _0x3735a1=_0xdbd6c2['slice'](0x0,_0x4710ac);if(_0x3735a1['toLowerCase']()==='localhost')_0x11c2c8='localhost';else{if(_0x3735a1['split']('.')['length']<=0x2)_0x11c2c8=_0x3735a1;else{const _0x20ffc3=_0xdbd6c2['indexOf']('.');_0x27c68c=_0xdbd6c2['substring'](0x0,_0x20ffc3)['toLowerCase'](),_0x11c2c8=_0xdbd6c2['substring'](_0x20ffc3+0x1),_0x526778=_0x27c68c;}}'ns'in _0x197967&&(_0x526778=_0x197967['ns']);}return{'host':_0xdbd6c2,'port':_0x42eb55,'domain':_0x11c2c8,'subdomain':_0x27c68c,'secure':_0x1d6b1,'scheme':_0x29656d,'pathString':_0x4f3ea6,'namespace':_0x526778};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x43f529=0x0;const _0x55ba71=[];return function(_0x1dcb7b){const _0x454800=_0x1dcb7b===_0x43f529;_0x43f529=_0x1dcb7b;let _0x26fbc2;const _0x2eb469=new Array(0x8);for(_0x26fbc2=0x7;_0x26fbc2>=0x0;_0x26fbc2--)_0x2eb469[_0x26fbc2]=mr['charAt'](_0x1dcb7b%0x40),_0x1dcb7b=Math['floor'](_0x1dcb7b/0x40);f(_0x1dcb7b===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x360507=_0x2eb469['join']('');if(_0x454800){for(_0x26fbc2=0xb;_0x26fbc2>=0x0&&_0x55ba71[_0x26fbc2]===0x3f;_0x26fbc2--)_0x55ba71[_0x26fbc2]=0x0;_0x55ba71[_0x26fbc2]++;}else{for(_0x26fbc2=0x0;_0x26fbc2<0xc;_0x26fbc2++)_0x55ba71[_0x26fbc2]=Math['floor'](Math['random']()*0x40);}for(_0x26fbc2=0x0;_0x26fbc2<0xc;_0x26fbc2++)_0x360507+=mr['charAt'](_0x55ba71[_0x26fbc2]);return f(_0x360507['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x360507;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x388def,_0x3ffb52,_0x480a76,_0x3a4895){this['eventType']=_0x388def,this['eventRegistration']=_0x3ffb52,this['snapshot']=_0x480a76,this['prevName']=_0x3a4895;}['getPath'](){const _0x4f0811=this['snapshot']['ref'];return this['eventType']==='value'?_0x4f0811['_path']:_0x4f0811['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x320fe0,_0x34d0cb,_0x586efe){this['eventRegistration']=_0x320fe0,this['error']=_0x34d0cb,this['path']=_0x586efe;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x2f2e9d,_0x10350a){this['snapshotCallback']=_0x2f2e9d,this['cancelCallback']=_0x10350a;}['onValue'](_0x1465a2,_0x4fc5be){this['snapshotCallback']['call'](null,_0x1465a2,_0x4fc5be);}['onCancel'](_0x8873b1){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x8873b1);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1b7995){return this['snapshotCallback']===_0x1b7995['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1b7995['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1b7995['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x588994,_0x40b45b,_0x44cfcb,_0x3c7b8c){this['_repo']=_0x588994,this['_path']=_0x40b45b,this['_queryParams']=_0x44cfcb,this['_orderByCalled']=_0x3c7b8c;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2f9777=nr(this['_queryParams']),_0x1c3832=Bi(_0x2f9777);return _0x1c3832==='{}'?'default':_0x1c3832;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x192788){if(_0x192788=k(_0x192788),!(_0x192788 instanceof be))return!0x1;const _0x1c46da=this['_repo']===_0x192788['_repo'],_0x500b3c=qi(this['_path'],_0x192788['_path']),_0x467f23=this['_queryIdentifier']===_0x192788['_queryIdentifier'];return _0x1c46da&&_0x500b3c&&_0x467f23;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x35bad0,_0x14ba54){if(_0x35bad0['_orderByCalled']===!0x0)throw new Error(_0x14ba54+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x171fbc){let _0x597804=null,_0x5068ee=null;if(_0x171fbc['hasStart']()&&(_0x597804=_0x171fbc['getIndexStartValue']()),_0x171fbc['hasEnd']()&&(_0x5068ee=_0x171fbc['getIndexEndValue']()),_0x171fbc['getIndex']()===ye){const _0x716e5d='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x44b3ba='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x171fbc['hasStart']()){if(_0x171fbc['getIndexStartName']()!==xe)throw new Error(_0x716e5d);if(typeof _0x597804!='string')throw new Error(_0x44b3ba);}if(_0x171fbc['hasEnd']()){if(_0x171fbc['getIndexEndName']()!==Ie)throw new Error(_0x716e5d);if(typeof _0x5068ee!='string')throw new Error(_0x44b3ba);}}else{if(_0x171fbc['getIndex']()===R){if(_0x597804!=null&&!Cn(_0x597804)||_0x5068ee!=null&&!Cn(_0x5068ee))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x171fbc['getIndex']()instanceof Ki||_0x171fbc['getIndex']()===Po,'unknown\x20index\x20type.'),_0x597804!=null&&typeof _0x597804=='object'||_0x5068ee!=null&&typeof _0x5068ee=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x12c8d7){if(_0x12c8d7['hasStart']()&&_0x12c8d7['hasEnd']()&&_0x12c8d7['hasLimit']()&&!_0x12c8d7['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x22c949,_0x10f5fa){super(_0x22c949,_0x10f5fa,new Qi(),!0x1);}get['parent'](){const _0x1a79b9=To(this['_path']);return _0x1a79b9===null?null:new Z(this['_repo'],_0x1a79b9);}get['root'](){let _0x3b2b2f=this;for(;_0x3b2b2f['parent']!==null;)_0x3b2b2f=_0x3b2b2f['parent'];return _0x3b2b2f;}}class rt{constructor(_0x1c1a9b,_0x174bb0,_0x48aa2a){this['_node']=_0x1c1a9b,this['ref']=_0x174bb0,this['_index']=_0x48aa2a;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x500643){const _0x13fd92=new C(_0x500643),_0x3d3538=Lt(this['ref'],_0x500643);return new rt(this['_node']['getChild'](_0x13fd92),_0x3d3538,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4e142c){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0xc57d5b,_0x42d873)=>_0x4e142c(new rt(_0x42d873,Lt(this['ref'],_0xc57d5b),R)));}['hasChild'](_0x378268){const _0x3141e5=new C(_0x378268);return!this['_node']['getChild'](_0x3141e5)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x50c34a,_0x6bebbf){return _0x50c34a=k(_0x50c34a),_0x50c34a['_checkNotDeleted']('ref'),_0x6bebbf!==void 0x0?Lt(_0x50c34a['_root'],_0x6bebbf):_0x50c34a['_root'];}function Lt(_0x19874f,_0x9e93c7){return _0x19874f=k(_0x19874f),y(_0x19874f['_path'])===null?ud('child','path',_0x9e93c7):_s('child','path',_0x9e93c7),new Z(_0x19874f['_repo'],A(_0x19874f['_path'],_0x9e93c7));}function d_(_0x1d6683,_0x188336){_0x1d6683=k(_0x1d6683),gs('push',_0x1d6683['_path']),qt('push',_0x188336,_0x1d6683['_path'],!0x0);const _0x48b6a3=oa(_0x1d6683['_repo']),_0x2c5fae=Od(_0x48b6a3),_0x258fad=Lt(_0x1d6683,_0x2c5fae),_0x5a7a81=Lt(_0x1d6683,_0x2c5fae);let _0x5305e1;return _0x188336!=null?_0x5305e1=Ld(_0x5a7a81,_0x188336)['then'](()=>_0x5a7a81):_0x5305e1=Promise['resolve'](_0x5a7a81),_0x258fad['then']=_0x5305e1['then']['bind'](_0x5305e1),_0x258fad['catch']=_0x5305e1['then']['bind'](_0x5305e1,void 0x0),_0x258fad;}function Ld(_0x4c5beb,_0x2a0e72){_0x4c5beb=k(_0x4c5beb),gs('set',_0x4c5beb['_path']),qt('set',_0x2a0e72,_0x4c5beb['_path'],!0x1);const _0x1c2267=new Ve();return Ed(_0x4c5beb['_repo'],_0x4c5beb['_path'],_0x2a0e72,null,_0x1c2267['wrapCallback'](()=>{})),_0x1c2267['promise'];}function f_(_0x1bcef1,_0x15b39c){hd('update',_0x15b39c,_0x1bcef1['_path']);const _0x4111a=new Ve();return Id(_0x1bcef1['_repo'],_0x1bcef1['_path'],_0x15b39c,_0x4111a['wrapCallback'](()=>{})),_0x4111a['promise'];}function p_(_0x12c790){_0x12c790=k(_0x12c790);const _0x443921=new ua(()=>{}),_0x3060b0=new qn(_0x443921);return vd(_0x12c790['_repo'],_0x12c790,_0x3060b0)['then'](_0x311ae0=>new rt(_0x311ae0,new Z(_0x12c790['_repo'],_0x12c790['_path']),_0x12c790['_queryParams']['getIndex']()));}class qn{constructor(_0x1b849f){this['callbackContext']=_0x1b849f;}['respondsTo'](_0x4d2be7){return _0x4d2be7==='value';}['createEvent'](_0x15ab37,_0x3bf1af){const _0x1da31e=_0x3bf1af['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x15ab37['snapshotNode'],new Z(_0x3bf1af['_repo'],_0x3bf1af['_path']),_0x1da31e));}['getEventRunner'](_0x19def8){return _0x19def8['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x19def8['error']):()=>this['callbackContext']['onValue'](_0x19def8['snapshot'],null);}['createCancelEvent'](_0x2e1f39,_0x328c34){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x2e1f39,_0x328c34):null;}['matches'](_0x335548){return _0x335548 instanceof qn?!_0x335548['callbackContext']||!this['callbackContext']?!0x0:_0x335548['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x5392eb,_0x5b3be7,_0x5e9e21,_0x5e5967,_0x516b32){const _0x5257e3=new ua(_0x5e9e21,void 0x0),_0x2d79e4=new qn(_0x5257e3);return Cd(_0x5392eb['_repo'],_0x5392eb,_0x2d79e4),()=>Td(_0x5392eb['_repo'],_0x5392eb,_0x2d79e4);}function Fd(_0x274f76,_0x3f65b2,_0x52c79f,_0x407216){return xd(_0x274f76,'value',_0x3f65b2);}class dt{}class pa extends dt{constructor(_0x3dd60b,_0x518f01){super(),this['_value']=_0x3dd60b,this['_key']=_0x518f01,this['type']='endAt';}['_apply'](_0x3fd5f6){qt('endAt',this['_value'],_0x3fd5f6['_path'],!0x0);const _0x4072db=Kh(_0x3fd5f6['_queryParams'],this['_value'],this['_key']);if(fa(_0x4072db),Gn(_0x4072db),_0x3fd5f6['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x3fd5f6['_repo'],_0x3fd5f6['_path'],_0x4072db,_0x3fd5f6['_orderByCalled']);}}function __(_0x3766eb,_0x220d14){return new pa(_0x3766eb,_0x220d14);}class _a extends dt{constructor(_0x2a021e,_0xc777df){super(),this['_value']=_0x2a021e,this['_key']=_0xc777df,this['type']='startAt';}['_apply'](_0x5c4d65){qt('startAt',this['_value'],_0x5c4d65['_path'],!0x0);const _0x1afe33=jh(_0x5c4d65['_queryParams'],this['_value'],this['_key']);if(fa(_0x1afe33),Gn(_0x1afe33),_0x5c4d65['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x5c4d65['_repo'],_0x5c4d65['_path'],_0x1afe33,_0x5c4d65['_orderByCalled']);}}function g_(_0x3341fc=null,_0xb0d205){return new _a(_0x3341fc,_0xb0d205);}class Ud extends dt{constructor(_0x56ac5d){super(),this['_limit']=_0x56ac5d,this['type']='limitToFirst';}['_apply'](_0x118e17){if(_0x118e17['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x118e17['_repo'],_0x118e17['_path'],zh(_0x118e17['_queryParams'],this['_limit']),_0x118e17['_orderByCalled']);}}function m_(_0x181ada){if(Math['floor'](_0x181ada)!==_0x181ada||_0x181ada<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x181ada);}class Wd extends dt{constructor(_0x2375d8){super(),this['_path']=_0x2375d8,this['type']='orderByChild';}['_apply'](_0x38e908){da(_0x38e908,'orderByChild');const _0x394c1f=new C(this['_path']);if(v(_0x394c1f))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3fe63d=new Ki(_0x394c1f),_0x1b5bfd=Do(_0x38e908['_queryParams'],_0x3fe63d);return Gn(_0x1b5bfd),new be(_0x38e908['_repo'],_0x38e908['_path'],_0x1b5bfd,!0x0);}}function y_(_0x847fa5){if(_0x847fa5==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x847fa5==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x847fa5==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x847fa5),new Wd(_0x847fa5);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x346558){da(_0x346558,'orderByKey');const _0x5a4d03=Do(_0x346558['_queryParams'],ye);return Gn(_0x5a4d03),new be(_0x346558['_repo'],_0x346558['_path'],_0x5a4d03,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x1216cb,_0x24d0cf){super(),this['_value']=_0x1216cb,this['_key']=_0x24d0cf,this['type']='equalTo';}['_apply'](_0x3490e4){if(qt('equalTo',this['_value'],_0x3490e4['_path'],!0x1),_0x3490e4['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3490e4['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x3490e4));}}function E_(_0x397b4d,_0x4aadfe){return new Vd(_0x397b4d,_0x4aadfe);}function I_(_0x2eec1d,..._0x1d2aa2){let _0x5f1ca6=k(_0x2eec1d);for(const _0xa0e36a of _0x1d2aa2)_0x5f1ca6=_0xa0e36a['_apply'](_0x5f1ca6);return _0x5f1ca6;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x85a7a5,_0x221c82,_0x43f439,_0x3fa98c){const _0x57b077=_0x221c82['lastIndexOf'](':'),_0x4397e2=_0x221c82['substring'](0x0,_0x57b077),_0x5dc318=Wt(_0x4397e2);_0x85a7a5['repoInfo_']=new _o(_0x221c82,_0x5dc318,_0x85a7a5['repoInfo_']['namespace'],_0x85a7a5['repoInfo_']['webSocketOnly'],_0x85a7a5['repoInfo_']['nodeAdmin'],_0x85a7a5['repoInfo_']['persistenceKey'],_0x85a7a5['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x43f439),_0x3fa98c&&(_0x85a7a5['authTokenProvider_']=_0x3fa98c);}function qd(_0x306be9,_0x3bf514,_0x2c53d9,_0x45eaba,_0x4a3311){let _0x3883a1=_0x45eaba||_0x306be9['options']['databaseURL'];_0x3883a1===void 0x0&&(_0x306be9['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x306be9['options']['projectId']),_0x3883a1=_0x306be9['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x5dc2ed=gr(_0x3883a1,_0x4a3311),_0x19a000=_0x5dc2ed['repoInfo'],_0x322098;typeof process<'u'&&Us&&(_0x322098=Us[Hd]),_0x322098?(_0x3883a1='http://'+_0x322098+'?ns='+_0x19a000['namespace'],_0x5dc2ed=gr(_0x3883a1,_0x4a3311),_0x19a000=_0x5dc2ed['repoInfo']):_0x5dc2ed['repoInfo']['secure'];const _0x13eff1=new Jl(_0x306be9['name'],_0x306be9['options'],_0x3bf514);dd('Invalid\x20Firebase\x20Database\x20URL',_0x5dc2ed),v(_0x5dc2ed['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x8ca955=jd(_0x19a000,_0x306be9,_0x13eff1,new Ql(_0x306be9,_0x2c53d9));return new Kd(_0x8ca955,_0x306be9);}function zd(_0x5ab18d,_0x4f3ce4){const _0x7dbbd=ki[_0x4f3ce4];(!_0x7dbbd||_0x7dbbd[_0x5ab18d['key']]!==_0x5ab18d)&&oe('Database\x20'+_0x4f3ce4+'('+_0x5ab18d['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x5ab18d),delete _0x7dbbd[_0x5ab18d['key']];}function jd(_0x369586,_0x5c6ca8,_0x4517cc,_0x2bfcbf){let _0x3f0ab2=ki[_0x5c6ca8['name']];_0x3f0ab2||(_0x3f0ab2={},ki[_0x5c6ca8['name']]=_0x3f0ab2);let _0x577eeb=_0x3f0ab2[_0x369586['toURLString']()];return _0x577eeb&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x577eeb=new gd(_0x369586,$d,_0x4517cc,_0x2bfcbf),_0x3f0ab2[_0x369586['toURLString']()]=_0x577eeb,_0x577eeb;}class Kd{constructor(_0x1522e5,_0x4c992e){this['_repoInternal']=_0x1522e5,this['app']=_0x4c992e,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5595a3){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x5595a3+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x558fba=Qr(),_0x1de317){const _0x26d8f6=Ui(_0x558fba,'database')['getImmediate']({'identifier':_0x1de317});if(!_0x26d8f6['_instanceStarted']){const _0x3cc755=ac('database');_0x3cc755&&Yd(_0x26d8f6,..._0x3cc755);}return _0x26d8f6;}function Yd(_0x3ae3e1,_0x39ace8,_0x13abb4,_0x486d3c={}){_0x3ae3e1=k(_0x3ae3e1),_0x3ae3e1['_checkNotDeleted']('useEmulator');const _0x185afb=_0x39ace8+':'+_0x13abb4,_0x5b1be6=_0x3ae3e1['_repoInternal'];if(_0x3ae3e1['_instanceStarted']){if(_0x185afb===_0x3ae3e1['_repoInternal']['repoInfo_']['host']&&De(_0x486d3c,_0x5b1be6['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1a468;if(_0x5b1be6['repoInfo_']['nodeAdmin'])_0x486d3c['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1a468=new tn(tn['OWNER']);else{if(_0x486d3c['mockUserToken']){const _0x52c670=typeof _0x486d3c['mockUserToken']=='string'?_0x486d3c['mockUserToken']:cc(_0x486d3c['mockUserToken'],_0x3ae3e1['app']['options']['projectId']);_0x1a468=new tn(_0x52c670);}}Wt(_0x39ace8)&&jr(_0x39ace8),Gd(_0x5b1be6,_0x185afb,_0x486d3c,_0x1a468);}function C_(_0x4dd2a3){_0x4dd2a3=k(_0x4dd2a3),_0x4dd2a3['_checkNotDeleted']('goOffline'),aa(_0x4dd2a3['_repo']);}function T_(_0xdb34cd){_0xdb34cd=k(_0xdb34cd),_0xdb34cd['_checkNotDeleted']('goOnline'),Sd(_0xdb34cd['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x398f58){Ll(ct),et(new Me('database',(_0x2a00d4,{instanceIdentifier:_0x34269a})=>{const _0x4eb5a0=_0x2a00d4['getProvider']('app')['getImmediate'](),_0x5d6d15=_0x2a00d4['getProvider']('auth-internal'),_0xe4a0af=_0x2a00d4['getProvider']('app-check-internal');return qd(_0x4eb5a0,_0x5d6d15,_0xe4a0af,_0x34269a);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x398f58),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x3fa516,_0x31dac3){this['committed']=_0x3fa516,this['snapshot']=_0x31dac3;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x47324b,_0x149726,_0x55a8e2){if(_0x47324b=k(_0x47324b),gs('Reference.transaction',_0x47324b['_path']),_0x47324b['key']==='.length'||_0x47324b['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x47324b['key']+'\x20is\x20a\x20read-only\x20object.';const _0x2071a3=!0x0,_0x28f927=new Ve(),_0x15d4f1=(_0x5d3e86,_0x3a10eb,_0x251f72)=>{let _0x2f95a3=null;_0x5d3e86?_0x28f927['reject'](_0x5d3e86):(_0x2f95a3=new rt(_0x251f72,new Z(_0x47324b['_repo'],_0x47324b['_path']),R),_0x28f927['resolve'](new Xd(_0x3a10eb,_0x2f95a3)));},_0x230a32=Fd(_0x47324b,()=>{});return bd(_0x47324b['_repo'],_0x47324b['_path'],_0x149726,_0x15d4f1,_0x230a32,_0x2071a3),_0x28f927['promise'];}ie['prototype']['simpleListen']=function(_0x4b2eee,_0x24ea16){this['sendRequest']('q',{'p':_0x4b2eee},_0x24ea16);},ie['prototype']['echo']=function(_0x2440dd,_0x998f7c){this['sendRequest']('echo',{'d':_0x2440dd},_0x998f7c);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x462566,..._0x334a4e){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x462566,..._0x334a4e);}function nn(_0x5bbcda,..._0x49794e){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x5bbcda,..._0x49794e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x46ee42,..._0x13bf20){throw Es(_0x46ee42,..._0x13bf20);}function J(_0x3501a2,..._0x38bcc8){return Es(_0x3501a2,..._0x38bcc8);}function ya(_0x3e6a91,_0x159f93,_0x334fc3){const _0x4d4eb5={...Zd(),[_0x159f93]:_0x334fc3};return new Ut('auth','Firebase',_0x4d4eb5)['create'](_0x159f93,{'appName':_0x3e6a91['name']});}function se(_0x72fd95){return ya(_0x72fd95,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x1065bd,..._0x5ea72e){if(typeof _0x1065bd!='string'){const _0x962d36=_0x5ea72e[0x0],_0x248a7e=[..._0x5ea72e['slice'](0x1)];return _0x248a7e[0x0]&&(_0x248a7e[0x0]['appName']=_0x1065bd['name']),_0x1065bd['_errorFactory']['create'](_0x962d36,..._0x248a7e);}return ma['create'](_0x1065bd,..._0x5ea72e);}function m(_0x453827,_0x581640,..._0x347658){if(!_0x453827)throw Es(_0x581640,..._0x347658);}function te(_0x187a15){const _0x33f973='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x187a15;throw nn(_0x33f973),new Error(_0x33f973);}function ae(_0x4b402f,_0x1850a6){_0x4b402f||te(_0x1850a6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x28e537;return typeof self<'u'&&((_0x28e537=self['location'])==null?void 0x0:_0x28e537['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x2517b0;return typeof self<'u'&&((_0x2517b0=self['location'])==null?void 0x0:_0x2517b0['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x2d8d81=navigator;return _0x2d8d81['languages']&&_0x2d8d81['languages'][0x0]||_0x2d8d81['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x53fa19,_0x51c8a5){this['shortDelay']=_0x53fa19,this['longDelay']=_0x51c8a5,ae(_0x51c8a5>_0x53fa19,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x2ee316,_0x2b1233){ae(_0x2ee316['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x39f680}=_0x2ee316['emulator'];return _0x2b1233?''+_0x39f680+(_0x2b1233['startsWith']('/')?_0x2b1233['slice'](0x1):_0x2b1233):_0x39f680;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x35d8f0,_0x57df72,_0xc4ca80){this['fetchImpl']=_0x35d8f0,_0x57df72&&(this['headersImpl']=_0x57df72),_0xc4ca80&&(this['responseImpl']=_0xc4ca80);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x3948ab,_0x451ff0){return _0x3948ab['tenantId']&&!_0x451ff0['tenantId']?{..._0x451ff0,'tenantId':_0x3948ab['tenantId']}:_0x451ff0;}async function Ae(_0x388a5f,_0xf5ac4d,_0xb14dd7,_0x19dedf,_0x371531={}){return Ea(_0x388a5f,_0x371531,async()=>{let _0x47bd93={},_0x30507a={};_0x19dedf&&(_0xf5ac4d==='GET'?_0x30507a=_0x19dedf:_0x47bd93={'body':JSON['stringify'](_0x19dedf)});const _0x3d9b78=at({..._0x30507a,'key':_0x388a5f['config']['apiKey']})['slice'](0x1),_0x1c3f0a=await _0x388a5f['_getAdditionalHeaders']();_0x1c3f0a['Content-Type']='application/json',_0x388a5f['languageCode']&&(_0x1c3f0a['X-Firebase-Locale']=_0x388a5f['languageCode']);const _0x7e98e1={'method':_0xf5ac4d,'headers':_0x1c3f0a,..._0x47bd93};return lc()||(_0x7e98e1['referrerPolicy']='strict-origin-when-cross-origin'),_0x388a5f['emulatorConfig']&&Wt(_0x388a5f['emulatorConfig']['host'])&&(_0x7e98e1['credentials']='include'),va['fetch']()(await Ia(_0x388a5f,_0x388a5f['config']['apiHost'],_0xb14dd7,_0x3d9b78),_0x7e98e1);});}async function Ea(_0x46474f,_0x2944ca,_0x401d17){_0x46474f['_canInitEmulator']=!0x1;const _0x126b38={...rf,..._0x2944ca};try{const _0x770c0d=new lf(_0x46474f),_0x15af72=await Promise['race']([_0x401d17(),_0x770c0d['promise']]);_0x770c0d['clearNetworkTimeout']();const _0x52a206=await _0x15af72['json']();if('needConfirmation'in _0x52a206)throw en(_0x46474f,'account-exists-with-different-credential',_0x52a206);if(_0x15af72['ok']&&!('errorMessage'in _0x52a206))return _0x52a206;{const _0x2f3afd=_0x15af72['ok']?_0x52a206['errorMessage']:_0x52a206['error']['message'],[_0x5cfeb6,_0x13d4b2]=_0x2f3afd['split']('\x20:\x20');if(_0x5cfeb6==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x46474f,'credential-already-in-use',_0x52a206);if(_0x5cfeb6==='EMAIL_EXISTS')throw en(_0x46474f,'email-already-in-use',_0x52a206);if(_0x5cfeb6==='USER_DISABLED')throw en(_0x46474f,'user-disabled',_0x52a206);const _0x4da3bc=_0x126b38[_0x5cfeb6]||_0x5cfeb6['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x13d4b2)throw ya(_0x46474f,_0x4da3bc,_0x13d4b2);K(_0x46474f,_0x4da3bc);}}catch(_0x4e1399){if(_0x4e1399 instanceof Se)throw _0x4e1399;K(_0x46474f,'network-request-failed',{'message':String(_0x4e1399)});}}async function Yt(_0x504eee,_0x647bf,_0x29d457,_0x23ebf4,_0x271a1d={}){const _0x1df2a4=await Ae(_0x504eee,_0x647bf,_0x29d457,_0x23ebf4,_0x271a1d);return'mfaPendingCredential'in _0x1df2a4&&K(_0x504eee,'multi-factor-auth-required',{'_serverResponse':_0x1df2a4}),_0x1df2a4;}async function Ia(_0x52e8fd,_0x10e970,_0x4750d2,_0x4ac851){const _0x5082a9=''+_0x10e970+_0x4750d2+'?'+_0x4ac851,_0x1c9b3a=_0x52e8fd,_0x302c98=_0x1c9b3a['config']['emulator']?Is(_0x52e8fd['config'],_0x5082a9):_0x52e8fd['config']['apiScheme']+'://'+_0x5082a9;return of['includes'](_0x4750d2)&&(await _0x1c9b3a['_persistenceManagerAvailable'],_0x1c9b3a['_getPersistenceType']()==='COOKIE')?_0x1c9b3a['_getPersistence']()['_getFinalTarget'](_0x302c98)['toString']():_0x302c98;}function cf(_0x4e7c3f){switch(_0x4e7c3f){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x1357fe){this['auth']=_0x1357fe,this['timer']=null,this['promise']=new Promise((_0x40c2d4,_0x2e6cc1)=>{this['timer']=setTimeout(()=>_0x2e6cc1(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x23c956,_0x4d6373,_0x2cd29c){const _0x4ebe8c={'appName':_0x23c956['name']};_0x2cd29c['email']&&(_0x4ebe8c['email']=_0x2cd29c['email']),_0x2cd29c['phoneNumber']&&(_0x4ebe8c['phoneNumber']=_0x2cd29c['phoneNumber']);const _0x2d9d48=J(_0x23c956,_0x4d6373,_0x4ebe8c);return _0x2d9d48['customData']['_tokenResponse']=_0x2cd29c,_0x2d9d48;}function vr(_0x1cb62d){return _0x1cb62d!==void 0x0&&_0x1cb62d['enterprise']!==void 0x0;}class hf{constructor(_0x4a81bd){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4a81bd['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4a81bd['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4a81bd['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4c47be){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x113f52 of this['recaptchaEnforcementState'])if(_0x113f52['provider']&&_0x113f52['provider']===_0x4c47be)return cf(_0x113f52['enforcementState']);return null;}['isProviderEnabled'](_0x31fe0c){return this['getProviderEnforcementState'](_0x31fe0c)==='ENFORCE'||this['getProviderEnforcementState'](_0x31fe0c)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x4aa577,_0x480060){return Ae(_0x4aa577,'GET','/v2/recaptchaConfig',Re(_0x4aa577,_0x480060));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x414944,_0x403c3d){return Ae(_0x414944,'POST','/v1/accounts:delete',_0x403c3d);}async function Sn(_0x4cccf2,_0x146e9c){return Ae(_0x4cccf2,'POST','/v1/accounts:lookup',_0x146e9c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x4919da){if(_0x4919da)try{const _0x22ab1d=new Date(Number(_0x4919da));if(!isNaN(_0x22ab1d['getTime']()))return _0x22ab1d['toUTCString']();}catch{}}async function ff(_0x44ce01,_0x5f07a7=!0x1){const _0x5432fc=k(_0x44ce01),_0x4cb908=await _0x5432fc['getIdToken'](_0x5f07a7),_0x5d2248=ws(_0x4cb908);m(_0x5d2248&&_0x5d2248['exp']&&_0x5d2248['auth_time']&&_0x5d2248['iat'],_0x5432fc['auth'],'internal-error');const _0x4fa71c=typeof _0x5d2248['firebase']=='object'?_0x5d2248['firebase']:void 0x0,_0x567101=_0x4fa71c==null?void 0x0:_0x4fa71c['sign_in_provider'];return{'claims':_0x5d2248,'token':_0x4cb908,'authTime':St(ci(_0x5d2248['auth_time'])),'issuedAtTime':St(ci(_0x5d2248['iat'])),'expirationTime':St(ci(_0x5d2248['exp'])),'signInProvider':_0x567101||null,'signInSecondFactor':(_0x4fa71c==null?void 0x0:_0x4fa71c['sign_in_second_factor'])||null};}function ci(_0x1284a9){return Number(_0x1284a9)*0x3e8;}function ws(_0x44d8c9){const [_0xaf6d4a,_0x12c1ab,_0x49529b]=_0x44d8c9['split']('.');if(_0xaf6d4a===void 0x0||_0x12c1ab===void 0x0||_0x49529b===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x15245a=cn(_0x12c1ab);return _0x15245a?JSON['parse'](_0x15245a):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x150ad9){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x150ad9==null?void 0x0:_0x150ad9['toString']()),null;}}function Er(_0x34df5a){const _0x273f16=ws(_0x34df5a);return m(_0x273f16,'internal-error'),m(typeof _0x273f16['exp']<'u','internal-error'),m(typeof _0x273f16['iat']<'u','internal-error'),Number(_0x273f16['exp'])-Number(_0x273f16['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x3ff2bc,_0x4aa1f7,_0x130d39=!0x1){if(_0x130d39)return _0x4aa1f7;try{return await _0x4aa1f7;}catch(_0x1d46e9){throw _0x1d46e9 instanceof Se&&pf(_0x1d46e9)&&_0x3ff2bc['auth']['currentUser']===_0x3ff2bc&&await _0x3ff2bc['auth']['signOut'](),_0x1d46e9;}}function pf({code:_0x482c71}){return _0x482c71==='auth/user-disabled'||_0x482c71==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x3b81ef){this['user']=_0x3b81ef,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x58c5d1){if(_0x58c5d1){const _0x11e168=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x11e168;}else{this['errorBackoff']=0x7530;const _0x574b4a=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x574b4a);}}['schedule'](_0x13854e=!0x1){if(!this['isRunning'])return;const _0x3786b8=this['getInterval'](_0x13854e);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3786b8);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x451caf){(_0x451caf==null?void 0x0:_0x451caf['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x2f76d4,_0x1fbae5){this['createdAt']=_0x2f76d4,this['lastLoginAt']=_0x1fbae5,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x259f4f){this['createdAt']=_0x259f4f['createdAt'],this['lastLoginAt']=_0x259f4f['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x41b03b){var _0x2a08f5;const _0x373599=_0x41b03b['auth'],_0x275d37=await _0x41b03b['getIdToken'](),_0x522c39=await xt(_0x41b03b,Sn(_0x373599,{'idToken':_0x275d37}));m(_0x522c39==null?void 0x0:_0x522c39['users']['length'],_0x373599,'internal-error');const _0x45b22e=_0x522c39['users'][0x0];_0x41b03b['_notifyReloadListener'](_0x45b22e);const _0x30d2f5=(_0x2a08f5=_0x45b22e['providerUserInfo'])!=null&&_0x2a08f5['length']?wa(_0x45b22e['providerUserInfo']):[],_0x51a92c=mf(_0x41b03b['providerData'],_0x30d2f5),_0x2b8ac2=_0x41b03b['isAnonymous'],_0xff6d46=!(_0x41b03b['email']&&_0x45b22e['passwordHash'])&&!(_0x51a92c!=null&&_0x51a92c['length']),_0x355ee3=_0x2b8ac2?_0xff6d46:!0x1,_0x5b4d4e={'uid':_0x45b22e['localId'],'displayName':_0x45b22e['displayName']||null,'photoURL':_0x45b22e['photoUrl']||null,'email':_0x45b22e['email']||null,'emailVerified':_0x45b22e['emailVerified']||!0x1,'phoneNumber':_0x45b22e['phoneNumber']||null,'tenantId':_0x45b22e['tenantId']||null,'providerData':_0x51a92c,'metadata':new Pi(_0x45b22e['createdAt'],_0x45b22e['lastLoginAt']),'isAnonymous':_0x355ee3};Object['assign'](_0x41b03b,_0x5b4d4e);}async function gf(_0x23eeec){const _0xe3385f=k(_0x23eeec);await bn(_0xe3385f),await _0xe3385f['auth']['_persistUserIfCurrent'](_0xe3385f),_0xe3385f['auth']['_notifyListenersIfCurrent'](_0xe3385f);}function mf(_0x1caebe,_0x11d4eb){return[..._0x1caebe['filter'](_0x27005e=>!_0x11d4eb['some'](_0x21e575=>_0x21e575['providerId']===_0x27005e['providerId'])),..._0x11d4eb];}function wa(_0x1656cc){return _0x1656cc['map'](({providerId:_0x3866f0,..._0x1cfc37})=>({'providerId':_0x3866f0,'uid':_0x1cfc37['rawId']||'','displayName':_0x1cfc37['displayName']||null,'email':_0x1cfc37['email']||null,'phoneNumber':_0x1cfc37['phoneNumber']||null,'photoURL':_0x1cfc37['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0xfb9ab4,_0xd2a6cf){const _0x2c27e9=await Ea(_0xfb9ab4,{},async()=>{const _0x3d76cf=at({'grant_type':'refresh_token','refresh_token':_0xd2a6cf})['slice'](0x1),{tokenApiHost:_0x15dc9,apiKey:_0x5b069c}=_0xfb9ab4['config'],_0x10b93b=await Ia(_0xfb9ab4,_0x15dc9,'/v1/token','key='+_0x5b069c),_0x1773b9=await _0xfb9ab4['_getAdditionalHeaders']();_0x1773b9['Content-Type']='application/x-www-form-urlencoded';const _0x558278={'method':'POST','headers':_0x1773b9,'body':_0x3d76cf};return _0xfb9ab4['emulatorConfig']&&Wt(_0xfb9ab4['emulatorConfig']['host'])&&(_0x558278['credentials']='include'),va['fetch']()(_0x10b93b,_0x558278);});return{'accessToken':_0x2c27e9['access_token'],'expiresIn':_0x2c27e9['expires_in'],'refreshToken':_0x2c27e9['refresh_token']};}async function vf(_0x37cad2,_0x4e02b6){return Ae(_0x37cad2,'POST','/v2/accounts:revokeToken',Re(_0x37cad2,_0x4e02b6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x41e744){m(_0x41e744['idToken'],'internal-error'),m(typeof _0x41e744['idToken']<'u','internal-error'),m(typeof _0x41e744['refreshToken']<'u','internal-error');const _0x2b8e98='expiresIn'in _0x41e744&&typeof _0x41e744['expiresIn']<'u'?Number(_0x41e744['expiresIn']):Er(_0x41e744['idToken']);this['updateTokensAndExpiration'](_0x41e744['idToken'],_0x41e744['refreshToken'],_0x2b8e98);}['updateFromIdToken'](_0x1e47f7){m(_0x1e47f7['length']!==0x0,'internal-error');const _0x325d73=Er(_0x1e47f7);this['updateTokensAndExpiration'](_0x1e47f7,null,_0x325d73);}async['getToken'](_0x12bced,_0x1a7653=!0x1){return!_0x1a7653&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x12bced,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x12bced,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1c6275,_0x3b8644){const {accessToken:_0x3f716c,refreshToken:_0x1d4783,expiresIn:_0x574fc9}=await yf(_0x1c6275,_0x3b8644);this['updateTokensAndExpiration'](_0x3f716c,_0x1d4783,Number(_0x574fc9));}['updateTokensAndExpiration'](_0x282670,_0x58bda1,_0x3fe335){this['refreshToken']=_0x58bda1||null,this['accessToken']=_0x282670||null,this['expirationTime']=Date['now']()+_0x3fe335*0x3e8;}static['fromJSON'](_0x2d5bbb,_0xf0f8ef){const {refreshToken:_0x468a51,accessToken:_0x2f2aab,expirationTime:_0x31c826}=_0xf0f8ef,_0x1a74ab=new Je();return _0x468a51&&(m(typeof _0x468a51=='string','internal-error',{'appName':_0x2d5bbb}),_0x1a74ab['refreshToken']=_0x468a51),_0x2f2aab&&(m(typeof _0x2f2aab=='string','internal-error',{'appName':_0x2d5bbb}),_0x1a74ab['accessToken']=_0x2f2aab),_0x31c826&&(m(typeof _0x31c826=='number','internal-error',{'appName':_0x2d5bbb}),_0x1a74ab['expirationTime']=_0x31c826),_0x1a74ab;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3779eb){this['accessToken']=_0x3779eb['accessToken'],this['refreshToken']=_0x3779eb['refreshToken'],this['expirationTime']=_0x3779eb['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x2d1498,_0x223864){m(typeof _0x2d1498=='string'||typeof _0x2d1498>'u','internal-error',{'appName':_0x223864});}class z{constructor({uid:_0x259016,auth:_0x5ea7fb,stsTokenManager:_0x1ed7fa,..._0x3a935c}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x259016,this['auth']=_0x5ea7fb,this['stsTokenManager']=_0x1ed7fa,this['accessToken']=_0x1ed7fa['accessToken'],this['displayName']=_0x3a935c['displayName']||null,this['email']=_0x3a935c['email']||null,this['emailVerified']=_0x3a935c['emailVerified']||!0x1,this['phoneNumber']=_0x3a935c['phoneNumber']||null,this['photoURL']=_0x3a935c['photoURL']||null,this['isAnonymous']=_0x3a935c['isAnonymous']||!0x1,this['tenantId']=_0x3a935c['tenantId']||null,this['providerData']=_0x3a935c['providerData']?[..._0x3a935c['providerData']]:[],this['metadata']=new Pi(_0x3a935c['createdAt']||void 0x0,_0x3a935c['lastLoginAt']||void 0x0);}async['getIdToken'](_0x434045){const _0x5cb675=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x434045));return m(_0x5cb675,this['auth'],'internal-error'),this['accessToken']!==_0x5cb675&&(this['accessToken']=_0x5cb675,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5cb675;}['getIdTokenResult'](_0x6b456c){return ff(this,_0x6b456c);}['reload'](){return gf(this);}['_assign'](_0x26c426){this!==_0x26c426&&(m(this['uid']===_0x26c426['uid'],this['auth'],'internal-error'),this['displayName']=_0x26c426['displayName'],this['photoURL']=_0x26c426['photoURL'],this['email']=_0x26c426['email'],this['emailVerified']=_0x26c426['emailVerified'],this['phoneNumber']=_0x26c426['phoneNumber'],this['isAnonymous']=_0x26c426['isAnonymous'],this['tenantId']=_0x26c426['tenantId'],this['providerData']=_0x26c426['providerData']['map'](_0x552a22=>({..._0x552a22})),this['metadata']['_copy'](_0x26c426['metadata']),this['stsTokenManager']['_assign'](_0x26c426['stsTokenManager']));}['_clone'](_0x472efe){const _0x5525ee=new z({...this,'auth':_0x472efe,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5525ee['metadata']['_copy'](this['metadata']),_0x5525ee;}['_onReload'](_0x341ff4){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x341ff4,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x9934e3){this['reloadListener']?this['reloadListener'](_0x9934e3):this['reloadUserInfo']=_0x9934e3;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x7a7e7c,_0x1c881a=!0x1){let _0x18ac20=!0x1;_0x7a7e7c['idToken']&&_0x7a7e7c['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x7a7e7c),_0x18ac20=!0x0),_0x1c881a&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x18ac20&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x5ca58e=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x5ca58e})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x36941f=>({..._0x36941f})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4440bc,_0x7526c0){const _0x23baa6=_0x7526c0['displayName']??void 0x0,_0x52d11e=_0x7526c0['email']??void 0x0,_0x53427c=_0x7526c0['phoneNumber']??void 0x0,_0x3c6d5f=_0x7526c0['photoURL']??void 0x0,_0xcc5467=_0x7526c0['tenantId']??void 0x0,_0x4e3f0d=_0x7526c0['_redirectEventId']??void 0x0,_0x4ccf10=_0x7526c0['createdAt']??void 0x0,_0x555f16=_0x7526c0['lastLoginAt']??void 0x0,{uid:_0x667a3d,emailVerified:_0x1ba908,isAnonymous:_0x58a1c2,providerData:_0x34e19d,stsTokenManager:_0x45b5ec}=_0x7526c0;m(_0x667a3d&&_0x45b5ec,_0x4440bc,'internal-error');const _0xf87691=Je['fromJSON'](this['name'],_0x45b5ec);m(typeof _0x667a3d=='string',_0x4440bc,'internal-error'),ce(_0x23baa6,_0x4440bc['name']),ce(_0x52d11e,_0x4440bc['name']),m(typeof _0x1ba908=='boolean',_0x4440bc,'internal-error'),m(typeof _0x58a1c2=='boolean',_0x4440bc,'internal-error'),ce(_0x53427c,_0x4440bc['name']),ce(_0x3c6d5f,_0x4440bc['name']),ce(_0xcc5467,_0x4440bc['name']),ce(_0x4e3f0d,_0x4440bc['name']),ce(_0x4ccf10,_0x4440bc['name']),ce(_0x555f16,_0x4440bc['name']);const _0x5053a2=new z({'uid':_0x667a3d,'auth':_0x4440bc,'email':_0x52d11e,'emailVerified':_0x1ba908,'displayName':_0x23baa6,'isAnonymous':_0x58a1c2,'photoURL':_0x3c6d5f,'phoneNumber':_0x53427c,'tenantId':_0xcc5467,'stsTokenManager':_0xf87691,'createdAt':_0x4ccf10,'lastLoginAt':_0x555f16});return _0x34e19d&&Array['isArray'](_0x34e19d)&&(_0x5053a2['providerData']=_0x34e19d['map'](_0x2a7edd=>({..._0x2a7edd}))),_0x4e3f0d&&(_0x5053a2['_redirectEventId']=_0x4e3f0d),_0x5053a2;}static async['_fromIdTokenResponse'](_0xb52f5b,_0x515bb1,_0x6c2ee8=!0x1){const _0x3b40c2=new Je();_0x3b40c2['updateFromServerResponse'](_0x515bb1);const _0x3f03a6=new z({'uid':_0x515bb1['localId'],'auth':_0xb52f5b,'stsTokenManager':_0x3b40c2,'isAnonymous':_0x6c2ee8});return await bn(_0x3f03a6),_0x3f03a6;}static async['_fromGetAccountInfoResponse'](_0x997468,_0x507eaf,_0x4b2a8f){const _0x275a4a=_0x507eaf['users'][0x0];m(_0x275a4a['localId']!==void 0x0,'internal-error');const _0x4c53c9=_0x275a4a['providerUserInfo']!==void 0x0?wa(_0x275a4a['providerUserInfo']):[],_0x13312a=!(_0x275a4a['email']&&_0x275a4a['passwordHash'])&&!(_0x4c53c9!=null&&_0x4c53c9['length']),_0x591d8d=new Je();_0x591d8d['updateFromIdToken'](_0x4b2a8f);const _0x1e919d=new z({'uid':_0x275a4a['localId'],'auth':_0x997468,'stsTokenManager':_0x591d8d,'isAnonymous':_0x13312a}),_0x43c0f3={'uid':_0x275a4a['localId'],'displayName':_0x275a4a['displayName']||null,'photoURL':_0x275a4a['photoUrl']||null,'email':_0x275a4a['email']||null,'emailVerified':_0x275a4a['emailVerified']||!0x1,'phoneNumber':_0x275a4a['phoneNumber']||null,'tenantId':_0x275a4a['tenantId']||null,'providerData':_0x4c53c9,'metadata':new Pi(_0x275a4a['createdAt'],_0x275a4a['lastLoginAt']),'isAnonymous':!(_0x275a4a['email']&&_0x275a4a['passwordHash'])&&!(_0x4c53c9!=null&&_0x4c53c9['length'])};return Object['assign'](_0x1e919d,_0x43c0f3),_0x1e919d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x94e320){ae(_0x94e320 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x4a8ec5=Ir['get'](_0x94e320);return _0x4a8ec5?(ae(_0x4a8ec5 instanceof _0x94e320,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x4a8ec5):(_0x4a8ec5=new _0x94e320(),Ir['set'](_0x94e320,_0x4a8ec5),_0x4a8ec5);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x4e14fd,_0x6e15d5){this['storage'][_0x4e14fd]=_0x6e15d5;}async['_get'](_0x390430){const _0x4e4090=this['storage'][_0x390430];return _0x4e4090===void 0x0?null:_0x4e4090;}async['_remove'](_0x5ba545){delete this['storage'][_0x5ba545];}['_addListener'](_0x82a677,_0x4559d5){}['_removeListener'](_0x53b4e6,_0x31c44b){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x590217,_0x41253d,_0x1d5341){return'firebase:'+_0x590217+':'+_0x41253d+':'+_0x1d5341;}class Xe{constructor(_0xccc6d7,_0x44437e,_0x4cd741){this['persistence']=_0xccc6d7,this['auth']=_0x44437e,this['userKey']=_0x4cd741;const {config:_0x1c2966,name:_0x7861cf}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x1c2966['apiKey'],_0x7861cf),this['fullPersistenceKey']=sn('persistence',_0x1c2966['apiKey'],_0x7861cf),this['boundEventHandler']=_0x44437e['_onStorageEvent']['bind'](_0x44437e),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x5b679b){return this['persistence']['_set'](this['fullUserKey'],_0x5b679b['toJSON']());}async['getCurrentUser'](){const _0x75cd8c=await this['persistence']['_get'](this['fullUserKey']);if(!_0x75cd8c)return null;if(typeof _0x75cd8c=='string'){const _0x252538=await Sn(this['auth'],{'idToken':_0x75cd8c})['catch'](()=>{});return _0x252538?z['_fromGetAccountInfoResponse'](this['auth'],_0x252538,_0x75cd8c):null;}return z['_fromJSON'](this['auth'],_0x75cd8c);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x535a8c){if(this['persistence']===_0x535a8c)return;const _0x2b300d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x535a8c,_0x2b300d)return this['setCurrentUser'](_0x2b300d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2dfcb4,_0x198f6e,_0x45d87f='authUser'){if(!_0x198f6e['length'])return new Xe(ne(wr),_0x2dfcb4,_0x45d87f);const _0x248ed=(await Promise['all'](_0x198f6e['map'](async _0x56bf85=>{if(await _0x56bf85['_isAvailable']())return _0x56bf85;})))['filter'](_0x261f83=>_0x261f83);let _0x4a8889=_0x248ed[0x0]||ne(wr);const _0x4adee5=sn(_0x45d87f,_0x2dfcb4['config']['apiKey'],_0x2dfcb4['name']);let _0x2c9a81=null;for(const _0x5d351b of _0x198f6e)try{const _0x500870=await _0x5d351b['_get'](_0x4adee5);if(_0x500870){let _0x5c78e0;if(typeof _0x500870=='string'){const _0x3a20f3=await Sn(_0x2dfcb4,{'idToken':_0x500870})['catch'](()=>{});if(!_0x3a20f3)break;_0x5c78e0=await z['_fromGetAccountInfoResponse'](_0x2dfcb4,_0x3a20f3,_0x500870);}else _0x5c78e0=z['_fromJSON'](_0x2dfcb4,_0x500870);_0x5d351b!==_0x4a8889&&(_0x2c9a81=_0x5c78e0),_0x4a8889=_0x5d351b;break;}}catch{}const _0x2b9d16=_0x248ed['filter'](_0x4fd6ba=>_0x4fd6ba['_shouldAllowMigration']);return!_0x4a8889['_shouldAllowMigration']||!_0x2b9d16['length']?new Xe(_0x4a8889,_0x2dfcb4,_0x45d87f):(_0x4a8889=_0x2b9d16[0x0],_0x2c9a81&&await _0x4a8889['_set'](_0x4adee5,_0x2c9a81['toJSON']()),await Promise['all'](_0x198f6e['map'](async _0x21dba0=>{if(_0x21dba0!==_0x4a8889)try{await _0x21dba0['_remove'](_0x4adee5);}catch{}})),new Xe(_0x4a8889,_0x2dfcb4,_0x45d87f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x48c340){const _0x4369c7=_0x48c340['toLowerCase']();if(_0x4369c7['includes']('opera/')||_0x4369c7['includes']('opr/')||_0x4369c7['includes']('opios/'))return'Opera';if(Ra(_0x4369c7))return'IEMobile';if(_0x4369c7['includes']('msie')||_0x4369c7['includes']('trident/'))return'IE';if(_0x4369c7['includes']('edge/'))return'Edge';if(Ta(_0x4369c7))return'Firefox';if(_0x4369c7['includes']('silk/'))return'Silk';if(ka(_0x4369c7))return'Blackberry';if(Na(_0x4369c7))return'Webos';if(Sa(_0x4369c7))return'Safari';if((_0x4369c7['includes']('chrome/')||ba(_0x4369c7))&&!_0x4369c7['includes']('edge/'))return'Chrome';if(Aa(_0x4369c7))return'Android';{const _0xa8f917=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x2cb6fe=_0x48c340['match'](_0xa8f917);if((_0x2cb6fe==null?void 0x0:_0x2cb6fe['length'])===0x2)return _0x2cb6fe[0x1];}return'Other';}function Ta(_0x358554=W()){return/firefox\//i['test'](_0x358554);}function Sa(_0x33c630=W()){const _0x88b9ab=_0x33c630['toLowerCase']();return _0x88b9ab['includes']('safari/')&&!_0x88b9ab['includes']('chrome/')&&!_0x88b9ab['includes']('crios/')&&!_0x88b9ab['includes']('android');}function ba(_0x32b952=W()){return/crios\//i['test'](_0x32b952);}function Ra(_0x28e042=W()){return/iemobile/i['test'](_0x28e042);}function Aa(_0x3cf50b=W()){return/android/i['test'](_0x3cf50b);}function ka(_0x1953c7=W()){return/blackberry/i['test'](_0x1953c7);}function Na(_0x4a86ea=W()){return/webos/i['test'](_0x4a86ea);}function Cs(_0x284e12=W()){return/iphone|ipad|ipod/i['test'](_0x284e12)||/macintosh/i['test'](_0x284e12)&&/mobile/i['test'](_0x284e12);}function Ef(_0x7104c=W()){var _0x4bf8ab;return Cs(_0x7104c)&&!!((_0x4bf8ab=window['navigator'])!=null&&_0x4bf8ab['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2973e2=W()){return Cs(_0x2973e2)||Aa(_0x2973e2)||Na(_0x2973e2)||ka(_0x2973e2)||/windows phone/i['test'](_0x2973e2)||Ra(_0x2973e2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x518de6,_0x1c1f79=[]){let _0x3bb2e2;switch(_0x518de6){case'Browser':_0x3bb2e2=Cr(W());break;case'Worker':_0x3bb2e2=Cr(W())+'-'+_0x518de6;break;default:_0x3bb2e2=_0x518de6;}const _0x1ca735=_0x1c1f79['length']?_0x1c1f79['join'](','):'FirebaseCore-web';return _0x3bb2e2+'/JsCore/'+ct+'/'+_0x1ca735;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x2cb86a){this['auth']=_0x2cb86a,this['queue']=[];}['pushCallback'](_0x495c3c,_0x24b661){const _0x3b055d=_0x1bb499=>new Promise((_0x5008dc,_0x3bae88)=>{try{const _0x225c7e=_0x495c3c(_0x1bb499);_0x5008dc(_0x225c7e);}catch(_0x45c9ab){_0x3bae88(_0x45c9ab);}});_0x3b055d['onAbort']=_0x24b661,this['queue']['push'](_0x3b055d);const _0x537a08=this['queue']['length']-0x1;return()=>{this['queue'][_0x537a08]=()=>Promise['resolve']();};}async['runMiddleware'](_0x505319){if(this['auth']['currentUser']===_0x505319)return;const _0x487269=[];try{for(const _0x38bc83 of this['queue'])await _0x38bc83(_0x505319),_0x38bc83['onAbort']&&_0x487269['push'](_0x38bc83['onAbort']);}catch(_0x2f334b){_0x487269['reverse']();for(const _0x3c72b1 of _0x487269)try{_0x3c72b1();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x2f334b==null?void 0x0:_0x2f334b['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x122310,_0x1b8a03={}){return Ae(_0x122310,'GET','/v2/passwordPolicy',Re(_0x122310,_0x1b8a03));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x308913){var _0x1951e0;const _0xad6d07=_0x308913['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xad6d07['minPasswordLength']??Tf,_0xad6d07['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xad6d07['maxPasswordLength']),_0xad6d07['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xad6d07['containsLowercaseCharacter']),_0xad6d07['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xad6d07['containsUppercaseCharacter']),_0xad6d07['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xad6d07['containsNumericCharacter']),_0xad6d07['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xad6d07['containsNonAlphanumericCharacter']),this['enforcementState']=_0x308913['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1951e0=_0x308913['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1951e0['join'](''))??'',this['forceUpgradeOnSignin']=_0x308913['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x308913['schemaVersion'];}['validatePassword'](_0x1649f6){const _0x28ac41={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1649f6,_0x28ac41),this['validatePasswordCharacterOptions'](_0x1649f6,_0x28ac41),_0x28ac41['isValid']&&(_0x28ac41['isValid']=_0x28ac41['meetsMinPasswordLength']??!0x0),_0x28ac41['isValid']&&(_0x28ac41['isValid']=_0x28ac41['meetsMaxPasswordLength']??!0x0),_0x28ac41['isValid']&&(_0x28ac41['isValid']=_0x28ac41['containsLowercaseLetter']??!0x0),_0x28ac41['isValid']&&(_0x28ac41['isValid']=_0x28ac41['containsUppercaseLetter']??!0x0),_0x28ac41['isValid']&&(_0x28ac41['isValid']=_0x28ac41['containsNumericCharacter']??!0x0),_0x28ac41['isValid']&&(_0x28ac41['isValid']=_0x28ac41['containsNonAlphanumericCharacter']??!0x0),_0x28ac41;}['validatePasswordLengthOptions'](_0x1ca133,_0x122e47){const _0x198a8d=this['customStrengthOptions']['minPasswordLength'],_0x279bcc=this['customStrengthOptions']['maxPasswordLength'];_0x198a8d&&(_0x122e47['meetsMinPasswordLength']=_0x1ca133['length']>=_0x198a8d),_0x279bcc&&(_0x122e47['meetsMaxPasswordLength']=_0x1ca133['length']<=_0x279bcc);}['validatePasswordCharacterOptions'](_0x4eadfc,_0x5509aa){this['updatePasswordCharacterOptionsStatuses'](_0x5509aa,!0x1,!0x1,!0x1,!0x1);let _0x370234;for(let _0x19604e=0x0;_0x19604e<_0x4eadfc['length'];_0x19604e++)_0x370234=_0x4eadfc['charAt'](_0x19604e),this['updatePasswordCharacterOptionsStatuses'](_0x5509aa,_0x370234>='a'&&_0x370234<='z',_0x370234>='A'&&_0x370234<='Z',_0x370234>='0'&&_0x370234<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x370234));}['updatePasswordCharacterOptionsStatuses'](_0x180323,_0x50f838,_0x59c0e8,_0x251719,_0x4962e4){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x180323['containsLowercaseLetter']||(_0x180323['containsLowercaseLetter']=_0x50f838)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x180323['containsUppercaseLetter']||(_0x180323['containsUppercaseLetter']=_0x59c0e8)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x180323['containsNumericCharacter']||(_0x180323['containsNumericCharacter']=_0x251719)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x180323['containsNonAlphanumericCharacter']||(_0x180323['containsNonAlphanumericCharacter']=_0x4962e4));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0xc380be,_0x2dbca7,_0x3ba0e8,_0x16e234){this['app']=_0xc380be,this['heartbeatServiceProvider']=_0x2dbca7,this['appCheckServiceProvider']=_0x3ba0e8,this['config']=_0x16e234,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xc380be['name'],this['clientVersion']=_0x16e234['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x390d74=>this['_resolvePersistenceManagerAvailable']=_0x390d74);}['_initializeWithPersistence'](_0x38e8c9,_0x15bb9a){return _0x15bb9a&&(this['_popupRedirectResolver']=ne(_0x15bb9a)),this['_initializationPromise']=this['queue'](async()=>{var _0x28dc48,_0x212d55,_0x524288;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x38e8c9),(_0x28dc48=this['_resolvePersistenceManagerAvailable'])==null||_0x28dc48['call'](this),!this['_deleted'])){if((_0x212d55=this['_popupRedirectResolver'])!=null&&_0x212d55['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x15bb9a),this['lastNotifiedUid']=((_0x524288=this['currentUser'])==null?void 0x0:_0x524288['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2aecc1=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2aecc1)){if(this['currentUser']&&_0x2aecc1&&this['currentUser']['uid']===_0x2aecc1['uid']){this['_currentUser']['_assign'](_0x2aecc1),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2aecc1,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x195663){try{const _0x3817bf=await Sn(this,{'idToken':_0x195663}),_0x57dacc=await z['_fromGetAccountInfoResponse'](this,_0x3817bf,_0x195663);await this['directlySetCurrentUser'](_0x57dacc);}catch(_0x4f43fe){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4f43fe),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x1b1e19){var _0x5cf2ff;if(H(this['app'])){const _0x50ef26=this['app']['settings']['authIdToken'];return _0x50ef26?new Promise(_0x4302be=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x50ef26)['then'](_0x4302be,_0x4302be));}):this['directlySetCurrentUser'](null);}const _0x25166d=await this['assertedPersistence']['getCurrentUser']();let _0x48fc76=_0x25166d,_0x2e32c5=!0x1;if(_0x1b1e19&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x4d4c90=(_0x5cf2ff=this['redirectUser'])==null?void 0x0:_0x5cf2ff['_redirectEventId'],_0x1383b4=_0x48fc76==null?void 0x0:_0x48fc76['_redirectEventId'],_0x424e5f=await this['tryRedirectSignIn'](_0x1b1e19);(!_0x4d4c90||_0x4d4c90===_0x1383b4)&&(_0x424e5f!=null&&_0x424e5f['user'])&&(_0x48fc76=_0x424e5f['user'],_0x2e32c5=!0x0);}if(!_0x48fc76)return this['directlySetCurrentUser'](null);if(!_0x48fc76['_redirectEventId']){if(_0x2e32c5)try{await this['beforeStateQueue']['runMiddleware'](_0x48fc76);}catch(_0x292a07){_0x48fc76=_0x25166d,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x292a07));}return _0x48fc76?this['reloadAndSetCurrentUserOrClear'](_0x48fc76):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x48fc76['_redirectEventId']?this['directlySetCurrentUser'](_0x48fc76):this['reloadAndSetCurrentUserOrClear'](_0x48fc76);}async['tryRedirectSignIn'](_0xa0936c){let _0x9d8666=null;try{_0x9d8666=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0xa0936c,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x9d8666;}async['reloadAndSetCurrentUserOrClear'](_0x22b269){try{await bn(_0x22b269);}catch(_0x159487){if((_0x159487==null?void 0x0:_0x159487['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x22b269);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x296631){if(H(this['app']))return Promise['reject'](se(this));const _0x554d8d=_0x296631?k(_0x296631):null;return _0x554d8d&&m(_0x554d8d['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x554d8d&&_0x554d8d['_clone'](this));}async['_updateCurrentUser'](_0x5e31a2,_0x2d5463=!0x1){if(!this['_deleted'])return _0x5e31a2&&m(this['tenantId']===_0x5e31a2['tenantId'],this,'tenant-id-mismatch'),_0x2d5463||await this['beforeStateQueue']['runMiddleware'](_0x5e31a2),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x5e31a2),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x27111d){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x27111d));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2d3aef){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x16c3a2=this['_getPasswordPolicyInternal']();return _0x16c3a2['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x16c3a2['validatePassword'](_0x2d3aef);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x587c2a=await Cf(this),_0x4d7bf2=new Sf(_0x587c2a);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4d7bf2:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4d7bf2;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x494202){this['_errorFactory']=new Ut('auth','Firebase',_0x494202());}['onAuthStateChanged'](_0x3ecc04,_0x5bb267,_0x1ce8b5){return this['registerStateListener'](this['authStateSubscription'],_0x3ecc04,_0x5bb267,_0x1ce8b5);}['beforeAuthStateChanged'](_0xcf3897,_0x576ba5){return this['beforeStateQueue']['pushCallback'](_0xcf3897,_0x576ba5);}['onIdTokenChanged'](_0x117a17,_0x4019ee,_0x874589){return this['registerStateListener'](this['idTokenSubscription'],_0x117a17,_0x4019ee,_0x874589);}['authStateReady'](){return new Promise((_0x315af3,_0x4978db)=>{if(this['currentUser'])_0x315af3();else{const _0x1848db=this['onAuthStateChanged'](()=>{_0x1848db(),_0x315af3();},_0x4978db);}});}async['revokeAccessToken'](_0x41841e){if(this['currentUser']){const _0x9d5811=await this['currentUser']['getIdToken'](),_0x5369eb={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x41841e,'idToken':_0x9d5811};this['tenantId']!=null&&(_0x5369eb['tenantId']=this['tenantId']),await vf(this,_0x5369eb);}}['toJSON'](){var _0x543b2c;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x543b2c=this['_currentUser'])==null?void 0x0:_0x543b2c['toJSON']()};}async['_setRedirectUser'](_0x4e99f0,_0x1112f1){const _0x434222=await this['getOrInitRedirectPersistenceManager'](_0x1112f1);return _0x4e99f0===null?_0x434222['removeCurrentUser']():_0x434222['setCurrentUser'](_0x4e99f0);}async['getOrInitRedirectPersistenceManager'](_0x129624){if(!this['redirectPersistenceManager']){const _0x2faac4=_0x129624&&ne(_0x129624)||this['_popupRedirectResolver'];m(_0x2faac4,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x2faac4['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x49b9b1){var _0x577738,_0xc1419c;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x577738=this['_currentUser'])==null?void 0x0:_0x577738['_redirectEventId'])===_0x49b9b1?this['_currentUser']:((_0xc1419c=this['redirectUser'])==null?void 0x0:_0xc1419c['_redirectEventId'])===_0x49b9b1?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5739d1){if(_0x5739d1===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5739d1));}['_notifyListenersIfCurrent'](_0x5dc4f0){_0x5dc4f0===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x485efc;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4e3634=((_0x485efc=this['currentUser'])==null?void 0x0:_0x485efc['uid'])??null;this['lastNotifiedUid']!==_0x4e3634&&(this['lastNotifiedUid']=_0x4e3634,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x294df3,_0x3026f6,_0x38566e,_0x3a0356){if(this['_deleted'])return()=>{};const _0xbb9644=typeof _0x3026f6=='function'?_0x3026f6:_0x3026f6['next']['bind'](_0x3026f6);let _0x4379f2=!0x1;const _0x1c4bf=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x1c4bf,this,'internal-error'),_0x1c4bf['then'](()=>{_0x4379f2||_0xbb9644(this['currentUser']);}),typeof _0x3026f6=='function'){const _0x307f0c=_0x294df3['addObserver'](_0x3026f6,_0x38566e,_0x3a0356);return()=>{_0x4379f2=!0x0,_0x307f0c();};}else{const _0x1f6797=_0x294df3['addObserver'](_0x3026f6);return()=>{_0x4379f2=!0x0,_0x1f6797();};}}async['directlySetCurrentUser'](_0x3efdb3){this['currentUser']&&this['currentUser']!==_0x3efdb3&&this['_currentUser']['_stopProactiveRefresh'](),_0x3efdb3&&this['isProactiveRefreshEnabled']&&_0x3efdb3['_startProactiveRefresh'](),this['currentUser']=_0x3efdb3,_0x3efdb3?await this['assertedPersistence']['setCurrentUser'](_0x3efdb3):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5aaf9c){return this['operations']=this['operations']['then'](_0x5aaf9c,_0x5aaf9c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4188c0){!_0x4188c0||this['frameworks']['includes'](_0x4188c0)||(this['frameworks']['push'](_0x4188c0),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0xa05b1b;const _0x18ffb1={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x18ffb1['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1b5133=await((_0xa05b1b=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xa05b1b['getHeartbeatsHeader']());_0x1b5133&&(_0x18ffb1['X-Firebase-Client']=_0x1b5133);const _0x4849ad=await this['_getAppCheckToken']();return _0x4849ad&&(_0x18ffb1['X-Firebase-AppCheck']=_0x4849ad),_0x18ffb1;}async['_getAppCheckToken'](){var _0x5f19ad;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3d790a=await((_0x5f19ad=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5f19ad['getToken']());return _0x3d790a!=null&&_0x3d790a['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3d790a['error']),_0x3d790a==null?void 0x0:_0x3d790a['token'];}}function qe(_0x211c42){return k(_0x211c42);}class Tr{constructor(_0x257f25){this['auth']=_0x257f25,this['observer']=null,this['addObserver']=Ic(_0x1e0ad6=>this['observer']=_0x1e0ad6);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x3b553){zn=_0x3b553;}function Da(_0xbce163){return zn['loadJS'](_0xbce163);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x21c59d){return'__'+_0x21c59d+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x528c82){_0x528c82();}['execute'](_0x51de98,_0xfafeb9){return Promise['resolve']('token');}['render'](_0x197f52,_0x54bd60){return'';}}class Of{['ready'](_0x42139c){_0x42139c();}['execute'](_0x1102ef,_0x58b2ad){return Promise['resolve']('token');}['render'](_0x2c8521,_0x2221f9){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0xd7bde8){this['type']=Df,this['auth']=qe(_0xd7bde8);}async['verify'](_0x4a741b='verify',_0x57f08a=!0x1){async function _0x257136(_0x4e5738){if(!_0x57f08a){if(_0x4e5738['tenantId']==null&&_0x4e5738['_agentRecaptchaConfig']!=null)return _0x4e5738['_agentRecaptchaConfig']['siteKey'];if(_0x4e5738['tenantId']!=null&&_0x4e5738['_tenantRecaptchaConfigs'][_0x4e5738['tenantId']]!==void 0x0)return _0x4e5738['_tenantRecaptchaConfigs'][_0x4e5738['tenantId']]['siteKey'];}return new Promise(async(_0x3b913b,_0x504754)=>{uf(_0x4e5738,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x3b6dfa=>{if(_0x3b6dfa['recaptchaKey']===void 0x0)_0x504754(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x577da7=new hf(_0x3b6dfa);return _0x4e5738['tenantId']==null?_0x4e5738['_agentRecaptchaConfig']=_0x577da7:_0x4e5738['_tenantRecaptchaConfigs'][_0x4e5738['tenantId']]=_0x577da7,_0x3b913b(_0x577da7['siteKey']);}})['catch'](_0x4ed391=>{_0x504754(_0x4ed391);});});}function _0x364788(_0x73483f,_0x5ed5bb,_0x3c06f0){const _0x29a06b=window['grecaptcha'];vr(_0x29a06b)?_0x29a06b['enterprise']['ready'](()=>{_0x29a06b['enterprise']['execute'](_0x73483f,{'action':_0x4a741b})['then'](_0x1dd785=>{_0x5ed5bb(_0x1dd785);})['catch'](()=>{_0x5ed5bb(Ma);});}):_0x3c06f0(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x46f95d,_0x42bbee)=>{_0x257136(this['auth'])['then'](async _0x211259=>{if(!_0x57f08a&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x364788(_0x211259,_0x46f95d,_0x42bbee);else{if(typeof window>'u'){_0x42bbee(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4f67cb=Af();_0x4f67cb['length']!==0x0&&(_0x4f67cb+=_0x211259+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x2c7c5c;(_0x2c7c5c=le['scriptInjectionDeferred'])==null||_0x2c7c5c['resolve']();},Da(_0x4f67cb)['then'](()=>{var _0x566ab1;return(_0x566ab1=le['scriptInjectionDeferred'])==null?void 0x0:_0x566ab1['promise'];})['then'](()=>{_0x364788(_0x211259,_0x46f95d,_0x42bbee);})['catch'](_0x505ca1=>{_0x42bbee(_0x505ca1);});}})['catch'](_0x25f25d=>{_0x42bbee(_0x25f25d);});});}}le['scriptInjectionDeferred']=null;async function br(_0x3d051b,_0x461303,_0x32ba2c,_0x383eda=!0x1,_0x179bd9=!0x1){const _0x35a01f=new le(_0x3d051b);let _0xde3d2;if(_0x179bd9)_0xde3d2=Ma;else try{_0xde3d2=await _0x35a01f['verify'](_0x32ba2c);}catch{_0xde3d2=await _0x35a01f['verify'](_0x32ba2c,!0x0);}const _0x541bc0={..._0x461303};if(_0x32ba2c==='mfaSmsEnrollment'||_0x32ba2c==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x541bc0){const _0x42eab4=_0x541bc0['phoneEnrollmentInfo']['phoneNumber'],_0x153aae=_0x541bc0['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x541bc0,{'phoneEnrollmentInfo':{'phoneNumber':_0x42eab4,'recaptchaToken':_0x153aae,'captchaResponse':_0xde3d2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x541bc0){const _0x10b841=_0x541bc0['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x541bc0,{'phoneSignInInfo':{'recaptchaToken':_0x10b841,'captchaResponse':_0xde3d2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x541bc0;}return _0x383eda?Object['assign'](_0x541bc0,{'captchaResp':_0xde3d2}):Object['assign'](_0x541bc0,{'captchaResponse':_0xde3d2}),Object['assign'](_0x541bc0,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x541bc0,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x541bc0;}async function Oi(_0x37a7a4,_0x430cc4,_0x130974,_0x29cc2e,_0x9994b0){var _0x3e2150;if((_0x3e2150=_0x37a7a4['_getRecaptchaConfig']())!=null&&_0x3e2150['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1cee30=await br(_0x37a7a4,_0x430cc4,_0x130974,_0x130974==='getOobCode');return _0x29cc2e(_0x37a7a4,_0x1cee30);}else return _0x29cc2e(_0x37a7a4,_0x430cc4)['catch'](async _0x33dce2=>{if(_0x33dce2['code']==='auth/missing-recaptcha-token'){console['log'](_0x130974+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4a7ba9=await br(_0x37a7a4,_0x430cc4,_0x130974,_0x130974==='getOobCode');return _0x29cc2e(_0x37a7a4,_0x4a7ba9);}else return Promise['reject'](_0x33dce2);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x5814b4,_0x5e8ae3){const _0x4bde7e=Ui(_0x5814b4,'auth');if(_0x4bde7e['isInitialized']()){const _0x9c780=_0x4bde7e['getImmediate'](),_0x27fa4d=_0x4bde7e['getOptions']();if(De(_0x27fa4d,_0x5e8ae3??{}))return _0x9c780;K(_0x9c780,'already-initialized');}return _0x4bde7e['initialize']({'options':_0x5e8ae3});}function Lf(_0x5e1166,_0xadb242){const _0x2055f1=(_0xadb242==null?void 0x0:_0xadb242['persistence'])||[],_0x28571e=(Array['isArray'](_0x2055f1)?_0x2055f1:[_0x2055f1])['map'](ne);_0xadb242!=null&&_0xadb242['errorMap']&&_0x5e1166['_updateErrorMap'](_0xadb242['errorMap']),_0x5e1166['_initializeWithPersistence'](_0x28571e,_0xadb242==null?void 0x0:_0xadb242['popupRedirectResolver']);}function xf(_0xd34127,_0x4f0370,_0x4cf4a6){const _0xda2c02=qe(_0xd34127);m(/^https?:\/\//['test'](_0x4f0370),_0xda2c02,'invalid-emulator-scheme');const _0x197ede=!0x1,_0x13305d=La(_0x4f0370),{host:_0x1088ca,port:_0x435bbe}=Ff(_0x4f0370),_0x538546=_0x435bbe===null?'':':'+_0x435bbe,_0x11ed0c={'url':_0x13305d+'//'+_0x1088ca+_0x538546+'/'},_0xc00ee=Object['freeze']({'host':_0x1088ca,'port':_0x435bbe,'protocol':_0x13305d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x197ede})});if(!_0xda2c02['_canInitEmulator']){m(_0xda2c02['config']['emulator']&&_0xda2c02['emulatorConfig'],_0xda2c02,'emulator-config-failed'),m(De(_0x11ed0c,_0xda2c02['config']['emulator'])&&De(_0xc00ee,_0xda2c02['emulatorConfig']),_0xda2c02,'emulator-config-failed');return;}_0xda2c02['config']['emulator']=_0x11ed0c,_0xda2c02['emulatorConfig']=_0xc00ee,_0xda2c02['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x1088ca)?jr(_0x13305d+'//'+_0x1088ca+_0x538546):Uf();}function La(_0x106d5a){const _0x12b9a0=_0x106d5a['indexOf'](':');return _0x12b9a0<0x0?'':_0x106d5a['substr'](0x0,_0x12b9a0+0x1);}function Ff(_0x5eab22){const _0x42de99=La(_0x5eab22),_0x2bfe81=/(\/\/)?([^?#/]+)/['exec'](_0x5eab22['substr'](_0x42de99['length']));if(!_0x2bfe81)return{'host':'','port':null};const _0x55e96e=_0x2bfe81[0x2]['split']('@')['pop']()||'',_0x2bd871=/^(\[[^\]]+\])(:|$)/['exec'](_0x55e96e);if(_0x2bd871){const _0x27a04a=_0x2bd871[0x1];return{'host':_0x27a04a,'port':Rr(_0x55e96e['substr'](_0x27a04a['length']+0x1))};}else{const [_0x1b3438,_0x22836a]=_0x55e96e['split'](':');return{'host':_0x1b3438,'port':Rr(_0x22836a)};}}function Rr(_0x19eb5d){if(!_0x19eb5d)return null;const _0x575ae0=Number(_0x19eb5d);return isNaN(_0x575ae0)?null:_0x575ae0;}function Uf(){function _0x58a7ae(){const _0x3863fc=document['createElement']('p'),_0x444a1c=_0x3863fc['style'];_0x3863fc['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x444a1c['position']='fixed',_0x444a1c['width']='100%',_0x444a1c['backgroundColor']='#ffffff',_0x444a1c['border']='.1em\x20solid\x20#000000',_0x444a1c['color']='#b50000',_0x444a1c['bottom']='0px',_0x444a1c['left']='0px',_0x444a1c['margin']='0px',_0x444a1c['zIndex']='10000',_0x444a1c['textAlign']='center',_0x3863fc['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3863fc);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x58a7ae):_0x58a7ae());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x2e45cf,_0x129ee6){this['providerId']=_0x2e45cf,this['signInMethod']=_0x129ee6;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x4d0138){return te('not\x20implemented');}['_linkToIdToken'](_0x3d621e,_0x501a39){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x289b81){return te('not\x20implemented');}}async function Wf(_0x12a12f,_0x13ba1f){return Ae(_0x12a12f,'POST','/v1/accounts:signUp',_0x13ba1f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x54d502,_0x2068fd){return Yt(_0x54d502,'POST','/v1/accounts:signInWithPassword',Re(_0x54d502,_0x2068fd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x2ab3ce,_0x48c5a1){return Yt(_0x2ab3ce,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2ab3ce,_0x48c5a1));}async function Hf(_0x225e28,_0x1ce1b6){return Yt(_0x225e28,'POST','/v1/accounts:signInWithEmailLink',Re(_0x225e28,_0x1ce1b6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x56ab24,_0x596d53,_0x1a5598,_0x25a7f0=null){super('password',_0x1a5598),this['_email']=_0x56ab24,this['_password']=_0x596d53,this['_tenantId']=_0x25a7f0;}static['_fromEmailAndPassword'](_0x5dd064,_0x50fb57){return new Ft(_0x5dd064,_0x50fb57,'password');}static['_fromEmailAndCode'](_0x13bdc5,_0x3c9705,_0x5871b3=null){return new Ft(_0x13bdc5,_0x3c9705,'emailLink',_0x5871b3);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2c9f21){const _0x3bba84=typeof _0x2c9f21=='string'?JSON['parse'](_0x2c9f21):_0x2c9f21;if(_0x3bba84!=null&&_0x3bba84['email']&&(_0x3bba84!=null&&_0x3bba84['password'])){if(_0x3bba84['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3bba84['email'],_0x3bba84['password']);if(_0x3bba84['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3bba84['email'],_0x3bba84['password'],_0x3bba84['tenantId']);}return null;}async['_getIdTokenResponse'](_0x15c88c){switch(this['signInMethod']){case'password':const _0x14bd93={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x15c88c,_0x14bd93,'signInWithPassword',Bf);case'emailLink':return Vf(_0x15c88c,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x15c88c,'internal-error');}}async['_linkToIdToken'](_0x5170b8,_0x4c118d){switch(this['signInMethod']){case'password':const _0x57bbe7={'idToken':_0x4c118d,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5170b8,_0x57bbe7,'signUpPassword',Wf);case'emailLink':return Hf(_0x5170b8,{'idToken':_0x4c118d,'email':this['_email'],'oobCode':this['_password']});default:K(_0x5170b8,'internal-error');}}['_getReauthenticationResolver'](_0x4c1aea){return this['_getIdTokenResponse'](_0x4c1aea);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x4e0351,_0x56c49e){return Yt(_0x4e0351,'POST','/v1/accounts:signInWithIdp',Re(_0x4e0351,_0x56c49e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3deb05){const _0x30f0e1=new We(_0x3deb05['providerId'],_0x3deb05['signInMethod']);return _0x3deb05['idToken']||_0x3deb05['accessToken']?(_0x3deb05['idToken']&&(_0x30f0e1['idToken']=_0x3deb05['idToken']),_0x3deb05['accessToken']&&(_0x30f0e1['accessToken']=_0x3deb05['accessToken']),_0x3deb05['nonce']&&!_0x3deb05['pendingToken']&&(_0x30f0e1['nonce']=_0x3deb05['nonce']),_0x3deb05['pendingToken']&&(_0x30f0e1['pendingToken']=_0x3deb05['pendingToken'])):_0x3deb05['oauthToken']&&_0x3deb05['oauthTokenSecret']?(_0x30f0e1['accessToken']=_0x3deb05['oauthToken'],_0x30f0e1['secret']=_0x3deb05['oauthTokenSecret']):K('argument-error'),_0x30f0e1;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3c6247){const _0xa065bb=typeof _0x3c6247=='string'?JSON['parse'](_0x3c6247):_0x3c6247,{providerId:_0x3e5db6,signInMethod:_0x2f04df,..._0x457672}=_0xa065bb;if(!_0x3e5db6||!_0x2f04df)return null;const _0x4539c2=new We(_0x3e5db6,_0x2f04df);return _0x4539c2['idToken']=_0x457672['idToken']||void 0x0,_0x4539c2['accessToken']=_0x457672['accessToken']||void 0x0,_0x4539c2['secret']=_0x457672['secret'],_0x4539c2['nonce']=_0x457672['nonce'],_0x4539c2['pendingToken']=_0x457672['pendingToken']||null,_0x4539c2;}['_getIdTokenResponse'](_0xe7e9b5){const _0x5ec12e=this['buildRequest']();return Ze(_0xe7e9b5,_0x5ec12e);}['_linkToIdToken'](_0x5a2dc3,_0x5d6db2){const _0x14c5c8=this['buildRequest']();return _0x14c5c8['idToken']=_0x5d6db2,Ze(_0x5a2dc3,_0x14c5c8);}['_getReauthenticationResolver'](_0x371b88){const _0xda9453=this['buildRequest']();return _0xda9453['autoCreate']=!0x1,Ze(_0x371b88,_0xda9453);}['buildRequest'](){const _0x56e5bf={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x56e5bf['pendingToken']=this['pendingToken'];else{const _0x5a3190={};this['idToken']&&(_0x5a3190['id_token']=this['idToken']),this['accessToken']&&(_0x5a3190['access_token']=this['accessToken']),this['secret']&&(_0x5a3190['oauth_token_secret']=this['secret']),_0x5a3190['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5a3190['nonce']=this['nonce']),_0x56e5bf['postBody']=at(_0x5a3190);}return _0x56e5bf;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x2214a0){switch(_0x2214a0){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x8272a2){const _0x476603=yt(vt(_0x8272a2))['link'],_0x2ed8af=_0x476603?yt(vt(_0x476603))['deep_link_id']:null,_0x5353b7=yt(vt(_0x8272a2))['deep_link_id'];return(_0x5353b7?yt(vt(_0x5353b7))['link']:null)||_0x5353b7||_0x2ed8af||_0x476603||_0x8272a2;}class Ss{constructor(_0x273945){const _0x5a094e=yt(vt(_0x273945)),_0x4870ae=_0x5a094e['apiKey']??null,_0xd6b10d=_0x5a094e['oobCode']??null,_0x3a5011=Gf(_0x5a094e['mode']??null);m(_0x4870ae&&_0xd6b10d&&_0x3a5011,'argument-error'),this['apiKey']=_0x4870ae,this['operation']=_0x3a5011,this['code']=_0xd6b10d,this['continueUrl']=_0x5a094e['continueUrl']??null,this['languageCode']=_0x5a094e['lang']??null,this['tenantId']=_0x5a094e['tenantId']??null;}static['parseLink'](_0x517713){const _0x32a8f1=qf(_0x517713);try{return new Ss(_0x32a8f1);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0xc43253,_0x22d2f2){return Ft['_fromEmailAndPassword'](_0xc43253,_0x22d2f2);}static['credentialWithLink'](_0x30ee18,_0x46ebc9){const _0x14bb8c=Ss['parseLink'](_0x46ebc9);return m(_0x14bb8c,'argument-error'),Ft['_fromEmailAndCode'](_0x30ee18,_0x14bb8c['code'],_0x14bb8c['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x5693e9){this['providerId']=_0x5693e9,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x26ae16){this['defaultLanguageCode']=_0x26ae16;}['setCustomParameters'](_0x1f7863){return this['customParameters']=_0x1f7863,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x556482){return this['scopes']['includes'](_0x556482)||this['scopes']['push'](_0x556482),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0xcfe57){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xcfe57});}static['credentialFromResult'](_0x859ad0){return he['credentialFromTaggedObject'](_0x859ad0);}static['credentialFromError'](_0x44230d){return he['credentialFromTaggedObject'](_0x44230d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x26c825}){if(!_0x26c825||!('oauthAccessToken'in _0x26c825)||!_0x26c825['oauthAccessToken'])return null;try{return he['credential'](_0x26c825['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x130366,_0x16d2ab){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x130366,'accessToken':_0x16d2ab});}static['credentialFromResult'](_0x22945f){return ue['credentialFromTaggedObject'](_0x22945f);}static['credentialFromError'](_0x48ef0f){return ue['credentialFromTaggedObject'](_0x48ef0f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x364df6}){if(!_0x364df6)return null;const {oauthIdToken:_0x381beb,oauthAccessToken:_0x6de9c6}=_0x364df6;if(!_0x381beb&&!_0x6de9c6)return null;try{return ue['credential'](_0x381beb,_0x6de9c6);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x19c76e){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x19c76e});}static['credentialFromResult'](_0x1811df){return de['credentialFromTaggedObject'](_0x1811df);}static['credentialFromError'](_0x285931){return de['credentialFromTaggedObject'](_0x285931['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x57f45f}){if(!_0x57f45f||!('oauthAccessToken'in _0x57f45f)||!_0x57f45f['oauthAccessToken'])return null;try{return de['credential'](_0x57f45f['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x235371,_0x5b9c70){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x235371,'oauthTokenSecret':_0x5b9c70});}static['credentialFromResult'](_0x2d57e5){return fe['credentialFromTaggedObject'](_0x2d57e5);}static['credentialFromError'](_0x49dc8a){return fe['credentialFromTaggedObject'](_0x49dc8a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xb7d5cb}){if(!_0xb7d5cb)return null;const {oauthAccessToken:_0x43d7db,oauthTokenSecret:_0x55ab69}=_0xb7d5cb;if(!_0x43d7db||!_0x55ab69)return null;try{return fe['credential'](_0x43d7db,_0x55ab69);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x22e1f1,_0x5af7e1){return Yt(_0x22e1f1,'POST','/v1/accounts:signUp',Re(_0x22e1f1,_0x5af7e1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x18b9d5){this['user']=_0x18b9d5['user'],this['providerId']=_0x18b9d5['providerId'],this['_tokenResponse']=_0x18b9d5['_tokenResponse'],this['operationType']=_0x18b9d5['operationType'];}static async['_fromIdTokenResponse'](_0x17fe41,_0x24a902,_0x589096,_0x373803=!0x1){const _0x51119d=await z['_fromIdTokenResponse'](_0x17fe41,_0x589096,_0x373803),_0x3ddd6a=Ar(_0x589096);return new Be({'user':_0x51119d,'providerId':_0x3ddd6a,'_tokenResponse':_0x589096,'operationType':_0x24a902});}static async['_forOperation'](_0x57d59d,_0x147715,_0x71a9c){await _0x57d59d['_updateTokensIfNecessary'](_0x71a9c,!0x0);const _0x60fc72=Ar(_0x71a9c);return new Be({'user':_0x57d59d,'providerId':_0x60fc72,'_tokenResponse':_0x71a9c,'operationType':_0x147715});}}function Ar(_0x37d69e){return _0x37d69e['providerId']?_0x37d69e['providerId']:'phoneNumber'in _0x37d69e?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x299ca5,_0x2a9b29,_0x2f43a2,_0x2a4996){super(_0x2a9b29['code'],_0x2a9b29['message']),this['operationType']=_0x2f43a2,this['user']=_0x2a4996,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x299ca5['name'],'tenantId':_0x299ca5['tenantId']??void 0x0,'_serverResponse':_0x2a9b29['customData']['_serverResponse'],'operationType':_0x2f43a2};}static['_fromErrorAndOperation'](_0x526302,_0x3b50fa,_0x243af6,_0x516bc9){return new Rn(_0x526302,_0x3b50fa,_0x243af6,_0x516bc9);}}function Fa(_0x1f4dc7,_0x5c9a96,_0x2a57b7,_0x45ca57){return(_0x5c9a96==='reauthenticate'?_0x2a57b7['_getReauthenticationResolver'](_0x1f4dc7):_0x2a57b7['_getIdTokenResponse'](_0x1f4dc7))['catch'](_0xc8ba41=>{throw _0xc8ba41['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x1f4dc7,_0xc8ba41,_0x5c9a96,_0x45ca57):_0xc8ba41;});}async function jf(_0x122c00,_0x425a39,_0x2cff0d=!0x1){const _0x2c02cb=await xt(_0x122c00,_0x425a39['_linkToIdToken'](_0x122c00['auth'],await _0x122c00['getIdToken']()),_0x2cff0d);return Be['_forOperation'](_0x122c00,'link',_0x2c02cb);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x1dbe7f,_0x470b5a,_0xa51429=!0x1){const {auth:_0x1ba508}=_0x1dbe7f;if(H(_0x1ba508['app']))return Promise['reject'](se(_0x1ba508));const _0x573399='reauthenticate';try{const _0x2e8a78=await xt(_0x1dbe7f,Fa(_0x1ba508,_0x573399,_0x470b5a,_0x1dbe7f),_0xa51429);m(_0x2e8a78['idToken'],_0x1ba508,'internal-error');const _0x4e3331=ws(_0x2e8a78['idToken']);m(_0x4e3331,_0x1ba508,'internal-error');const {sub:_0x5d2915}=_0x4e3331;return m(_0x1dbe7f['uid']===_0x5d2915,_0x1ba508,'user-mismatch'),Be['_forOperation'](_0x1dbe7f,_0x573399,_0x2e8a78);}catch(_0x33c798){throw(_0x33c798==null?void 0x0:_0x33c798['code'])==='auth/user-not-found'&&K(_0x1ba508,'user-mismatch'),_0x33c798;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x2916d5,_0x139683,_0x589eba=!0x1){if(H(_0x2916d5['app']))return Promise['reject'](se(_0x2916d5));const _0xfbefa='signIn',_0x468c22=await Fa(_0x2916d5,_0xfbefa,_0x139683),_0x516184=await Be['_fromIdTokenResponse'](_0x2916d5,_0xfbefa,_0x468c22);return _0x589eba||await _0x2916d5['_updateCurrentUser'](_0x516184['user']),_0x516184;}async function Yf(_0x348a58,_0x4309ab){return Ua(qe(_0x348a58),_0x4309ab);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x49d89e){const _0x34c2b0=qe(_0x49d89e);_0x34c2b0['_getPasswordPolicyInternal']()&&await _0x34c2b0['_updatePasswordPolicy']();}async function R_(_0x2e1501,_0x27468f,_0x33cfc6){if(H(_0x2e1501['app']))return Promise['reject'](se(_0x2e1501));const _0x4ec0e1=qe(_0x2e1501),_0x1b7990=await Oi(_0x4ec0e1,{'returnSecureToken':!0x0,'email':_0x27468f,'password':_0x33cfc6,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x39a580=>{throw _0x39a580['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x2e1501),_0x39a580;}),_0x36e42c=await Be['_fromIdTokenResponse'](_0x4ec0e1,'signIn',_0x1b7990);return await _0x4ec0e1['_updateCurrentUser'](_0x36e42c['user']),_0x36e42c;}function A_(_0x49a73f,_0x1f3a21,_0x48f310){return H(_0x49a73f['app'])?Promise['reject'](se(_0x49a73f)):Yf(k(_0x49a73f),ft['credential'](_0x1f3a21,_0x48f310))['catch'](async _0x148fe5=>{throw _0x148fe5['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x49a73f),_0x148fe5;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0xa8a972,_0x33652e){return k(_0xa8a972)['setPersistence'](_0x33652e);}function Qf(_0x2eaaad,_0x23d539,_0x43fb1f,_0x504635){return k(_0x2eaaad)['onIdTokenChanged'](_0x23d539,_0x43fb1f,_0x504635);}function Jf(_0x1d7c05,_0x57241a,_0x15ada0){return k(_0x1d7c05)['beforeAuthStateChanged'](_0x57241a,_0x15ada0);}function N_(_0x5bfe4d,_0x3460ff,_0x2f06b9,_0x4dc7f0){return k(_0x5bfe4d)['onAuthStateChanged'](_0x3460ff,_0x2f06b9,_0x4dc7f0);}function P_(_0x5b6f68){return k(_0x5b6f68)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x121574,_0x5b1477){this['storageRetriever']=_0x121574,this['type']=_0x5b1477;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3d5ff1,_0x578c25){return this['storage']['setItem'](_0x3d5ff1,JSON['stringify'](_0x578c25)),Promise['resolve']();}['_get'](_0x2e423f){const _0x163a95=this['storage']['getItem'](_0x2e423f);return Promise['resolve'](_0x163a95?JSON['parse'](_0x163a95):null);}['_remove'](_0x56e041){return this['storage']['removeItem'](_0x56e041),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3771d4,_0x4693d6)=>this['onStorageEvent'](_0x3771d4,_0x4693d6),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5237dd){for(const _0xa5b492 of Object['keys'](this['listeners'])){const _0x1ae441=this['storage']['getItem'](_0xa5b492),_0x2769bb=this['localCache'][_0xa5b492];_0x1ae441!==_0x2769bb&&_0x5237dd(_0xa5b492,_0x2769bb,_0x1ae441);}}['onStorageEvent'](_0x52b234,_0xed62c1=!0x1){if(!_0x52b234['key']){this['forAllChangedKeys']((_0x4e5739,_0x164c90,_0xa82218)=>{this['notifyListeners'](_0x4e5739,_0xa82218);});return;}const _0x213ba5=_0x52b234['key'];_0xed62c1?this['detachListener']():this['stopPolling']();const _0x567154=()=>{const _0x1a51ba=this['storage']['getItem'](_0x213ba5);!_0xed62c1&&this['localCache'][_0x213ba5]===_0x1a51ba||this['notifyListeners'](_0x213ba5,_0x1a51ba);},_0x5865cc=this['storage']['getItem'](_0x213ba5);If()&&_0x5865cc!==_0x52b234['newValue']&&_0x52b234['newValue']!==_0x52b234['oldValue']?setTimeout(_0x567154,Zf):_0x567154();}['notifyListeners'](_0x9a3e56,_0x2a9fd8){this['localCache'][_0x9a3e56]=_0x2a9fd8;const _0x1dfc49=this['listeners'][_0x9a3e56];if(_0x1dfc49){for(const _0xbe6346 of Array['from'](_0x1dfc49))_0xbe6346(_0x2a9fd8&&JSON['parse'](_0x2a9fd8));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x252c86,_0x213fd9,_0x3e4ec6)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x252c86,'oldValue':_0x213fd9,'newValue':_0x3e4ec6}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x32adb3,_0x4b3de8){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x32adb3]||(this['listeners'][_0x32adb3]=new Set(),this['localCache'][_0x32adb3]=this['storage']['getItem'](_0x32adb3)),this['listeners'][_0x32adb3]['add'](_0x4b3de8);}['_removeListener'](_0x323a1c,_0x6919f0){this['listeners'][_0x323a1c]&&(this['listeners'][_0x323a1c]['delete'](_0x6919f0),this['listeners'][_0x323a1c]['size']===0x0&&delete this['listeners'][_0x323a1c]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3cd92e,_0x446a66){await super['_set'](_0x3cd92e,_0x446a66),this['localCache'][_0x3cd92e]=JSON['stringify'](_0x446a66);}async['_get'](_0x4ea36d){const _0x590cb8=await super['_get'](_0x4ea36d);return this['localCache'][_0x4ea36d]=JSON['stringify'](_0x590cb8),_0x590cb8;}async['_remove'](_0x509639){await super['_remove'](_0x509639),delete this['localCache'][_0x509639];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x598e24,_0x154c2){}['_removeListener'](_0x2c0414,_0x33e28a){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0xa723ef){return Promise['all'](_0xa723ef['map'](async _0x36168b=>{try{return{'fulfilled':!0x0,'value':await _0x36168b};}catch(_0x4828bb){return{'fulfilled':!0x1,'reason':_0x4828bb};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x426176){this['eventTarget']=_0x426176,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3c12e0){const _0x3933ed=this['receivers']['find'](_0xc35bb9=>_0xc35bb9['isListeningto'](_0x3c12e0));if(_0x3933ed)return _0x3933ed;const _0x3ff615=new jn(_0x3c12e0);return this['receivers']['push'](_0x3ff615),_0x3ff615;}['isListeningto'](_0x3da275){return this['eventTarget']===_0x3da275;}async['handleEvent'](_0x8981ee){const _0x11c01a=_0x8981ee,{eventId:_0x87628c,eventType:_0x152f87,data:_0x40dc37}=_0x11c01a['data'],_0x5aa91e=this['handlersMap'][_0x152f87];if(!(_0x5aa91e!=null&&_0x5aa91e['size']))return;_0x11c01a['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x87628c,'eventType':_0x152f87});const _0x30fb97=Array['from'](_0x5aa91e)['map'](async _0x4870a2=>_0x4870a2(_0x11c01a['origin'],_0x40dc37)),_0x5debd5=await tp(_0x30fb97);_0x11c01a['ports'][0x0]['postMessage']({'status':'done','eventId':_0x87628c,'eventType':_0x152f87,'response':_0x5debd5});}['_subscribe'](_0x2abc2e,_0xd43d){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2abc2e]||(this['handlersMap'][_0x2abc2e]=new Set()),this['handlersMap'][_0x2abc2e]['add'](_0xd43d);}['_unsubscribe'](_0x928986,_0x1a9fb5){this['handlersMap'][_0x928986]&&_0x1a9fb5&&this['handlersMap'][_0x928986]['delete'](_0x1a9fb5),(!_0x1a9fb5||this['handlersMap'][_0x928986]['size']===0x0)&&delete this['handlersMap'][_0x928986],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x173a13='',_0x493f69=0xa){let _0x3f0fdc='';for(let _0x15b681=0x0;_0x15b681<_0x493f69;_0x15b681++)_0x3f0fdc+=Math['floor'](Math['random']()*0xa);return _0x173a13+_0x3f0fdc;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x5392ad){this['target']=_0x5392ad,this['handlers']=new Set();}['removeMessageHandler'](_0x13ec15){_0x13ec15['messageChannel']&&(_0x13ec15['messageChannel']['port1']['removeEventListener']('message',_0x13ec15['onMessage']),_0x13ec15['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x13ec15);}async['_send'](_0x8ecbb5,_0x5e8c5f,_0x9d4210=0x32){const _0x401cdb=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x401cdb)throw new Error('connection_unavailable');let _0x5d4898,_0x3523f9;return new Promise((_0x58bf09,_0x2ccb97)=>{const _0x1fc610=bs('',0x14);_0x401cdb['port1']['start']();const _0x3191f5=setTimeout(()=>{_0x2ccb97(new Error('unsupported_event'));},_0x9d4210);_0x3523f9={'messageChannel':_0x401cdb,'onMessage'(_0x49e5cb){const _0x47f654=_0x49e5cb;if(_0x47f654['data']['eventId']===_0x1fc610)switch(_0x47f654['data']['status']){case'ack':clearTimeout(_0x3191f5),_0x5d4898=setTimeout(()=>{_0x2ccb97(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5d4898),_0x58bf09(_0x47f654['data']['response']);break;default:clearTimeout(_0x3191f5),clearTimeout(_0x5d4898),_0x2ccb97(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3523f9),_0x401cdb['port1']['addEventListener']('message',_0x3523f9['onMessage']),this['target']['postMessage']({'eventType':_0x8ecbb5,'eventId':_0x1fc610,'data':_0x5e8c5f},[_0x401cdb['port2']]);})['finally'](()=>{_0x3523f9&&this['removeMessageHandler'](_0x3523f9);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0xd44b15){X()['location']['href']=_0xd44b15;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x3e708c;return((_0x3e708c=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3e708c['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x434f0f){this['request']=_0x434f0f;}['toPromise'](){return new Promise((_0x3dbd3c,_0xa03790)=>{this['request']['addEventListener']('success',()=>{_0x3dbd3c(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xa03790(this['request']['error']);});});}}function Kn(_0x4ad929,_0x2e9577){return _0x4ad929['transaction']([kn],_0x2e9577?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x4eb03f=indexedDB['deleteDatabase'](qa);return new Jt(_0x4eb03f)['toPromise']();}function ja(){const _0xec3dc9=indexedDB['open'](qa,ap);return new Promise((_0x21b0b9,_0x589000)=>{_0xec3dc9['addEventListener']('error',()=>{_0x589000(_0xec3dc9['error']);}),_0xec3dc9['addEventListener']('upgradeneeded',()=>{const _0x508c3a=_0xec3dc9['result'];try{_0x508c3a['createObjectStore'](kn,{'keyPath':za});}catch(_0x3bff1d){_0x589000(_0x3bff1d);}}),_0xec3dc9['addEventListener']('success',async()=>{const _0x24df4f=_0xec3dc9['result'];_0x24df4f['objectStoreNames']['contains'](kn)?_0x21b0b9(_0x24df4f):(_0x24df4f['close'](),await cp(),_0x21b0b9(await ja()));});});}async function kr(_0x9d8351,_0x547179,_0x2d8f9c){const _0x3cca9c=Kn(_0x9d8351,!0x0)['put']({[za]:_0x547179,'value':_0x2d8f9c});return new Jt(_0x3cca9c)['toPromise']();}async function lp(_0x5bf685,_0x2d82d3){const _0x261bf1=Kn(_0x5bf685,!0x1)['get'](_0x2d82d3),_0x47fd85=await new Jt(_0x261bf1)['toPromise']();return _0x47fd85===void 0x0?null:_0x47fd85['value'];}function Nr(_0x11533e,_0x476586){const _0x364dca=Kn(_0x11533e,!0x0)['delete'](_0x476586);return new Jt(_0x364dca)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2bd877){let _0x4312ac=0x0;for(;;)try{const _0x471864=await this['_openDb']();return await _0x2bd877(_0x471864);}catch(_0x2ded64){if(_0x4312ac++>up)throw _0x2ded64;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x3077e1,_0x4ccf5b)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4ccf5b['key'])})),this['receiver']['_subscribe']('ping',async(_0x5bfed3,_0x7311fd)=>['keyChanged']);}async['initializeSender'](){var _0x194b9b,_0x4e961e;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x1df24f=await this['sender']['_send']('ping',{},0x320);_0x1df24f&&(_0x194b9b=_0x1df24f[0x0])!=null&&_0x194b9b['fulfilled']&&(_0x4e961e=_0x1df24f[0x0])!=null&&_0x4e961e['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x107a7d){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x107a7d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xe3f5ca=>{await kr(_0xe3f5ca,An,'1'),await Nr(_0xe3f5ca,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2de1e9){this['pendingWrites']++;try{await _0x2de1e9();}finally{this['pendingWrites']--;}}async['_set'](_0x5f3028,_0x45a958){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x24d905=>kr(_0x24d905,_0x5f3028,_0x45a958)),this['localCache'][_0x5f3028]=_0x45a958,this['notifyServiceWorker'](_0x5f3028)));}async['_get'](_0xfb9c20){const _0xc352dc=await this['_withRetries'](_0x3a95b7=>lp(_0x3a95b7,_0xfb9c20));return this['localCache'][_0xfb9c20]=_0xc352dc,_0xc352dc;}async['_remove'](_0x171dc5){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1ce421=>Nr(_0x1ce421,_0x171dc5)),delete this['localCache'][_0x171dc5],this['notifyServiceWorker'](_0x171dc5)));}async['_poll'](){const _0x5ce041=await this['_withRetries'](_0x1ff5c7=>{const _0x451bbe=Kn(_0x1ff5c7,!0x1)['getAll']();return new Jt(_0x451bbe)['toPromise']();});if(!_0x5ce041)return[];if(this['pendingWrites']!==0x0)return[];const _0x56cec8=[],_0x4848de=new Set();if(_0x5ce041['length']!==0x0){for(const {fbase_key:_0x2b7d1f,value:_0xdde69d}of _0x5ce041)_0x4848de['add'](_0x2b7d1f),JSON['stringify'](this['localCache'][_0x2b7d1f])!==JSON['stringify'](_0xdde69d)&&(this['notifyListeners'](_0x2b7d1f,_0xdde69d),_0x56cec8['push'](_0x2b7d1f));}for(const _0x55db93 of Object['keys'](this['localCache']))this['localCache'][_0x55db93]&&!_0x4848de['has'](_0x55db93)&&(this['notifyListeners'](_0x55db93,null),_0x56cec8['push'](_0x55db93));return _0x56cec8;}['notifyListeners'](_0x42255e,_0x5477af){this['localCache'][_0x42255e]=_0x5477af;const _0x467c2e=this['listeners'][_0x42255e];if(_0x467c2e){for(const _0x1178d6 of Array['from'](_0x467c2e))_0x1178d6(_0x5477af);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x22368d,_0x1c376c){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x22368d]||(this['listeners'][_0x22368d]=new Set(),this['_get'](_0x22368d)),this['listeners'][_0x22368d]['add'](_0x1c376c);}['_removeListener'](_0x42f301,_0x166341){this['listeners'][_0x42f301]&&(this['listeners'][_0x42f301]['delete'](_0x166341),this['listeners'][_0x42f301]['size']===0x0&&delete this['listeners'][_0x42f301]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x4236db,_0x2db283){return _0x2db283?ne(_0x2db283):(m(_0x4236db['_popupRedirectResolver'],_0x4236db,'argument-error'),_0x4236db['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x1e9036){super('custom','custom'),this['params']=_0x1e9036;}['_getIdTokenResponse'](_0x2be65b){return Ze(_0x2be65b,this['_buildIdpRequest']());}['_linkToIdToken'](_0x597ffc,_0x37486e){return Ze(_0x597ffc,this['_buildIdpRequest'](_0x37486e));}['_getReauthenticationResolver'](_0x5e0bf4){return Ze(_0x5e0bf4,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x243789){const _0x419f5c={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x243789&&(_0x419f5c['idToken']=_0x243789),_0x419f5c;}}function pp(_0x11ddfe){return Ua(_0x11ddfe['auth'],new Rs(_0x11ddfe),_0x11ddfe['bypassAuthState']);}function _p(_0x3b73fd){const {auth:_0x37d304,user:_0x226307}=_0x3b73fd;return m(_0x226307,_0x37d304,'internal-error'),Kf(_0x226307,new Rs(_0x3b73fd),_0x3b73fd['bypassAuthState']);}async function gp(_0x3d0bbb){const {auth:_0x32b8fe,user:_0xe98a39}=_0x3d0bbb;return m(_0xe98a39,_0x32b8fe,'internal-error'),jf(_0xe98a39,new Rs(_0x3d0bbb),_0x3d0bbb['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x34856f,_0x5d3864,_0x274360,_0x24c3be,_0x1423bd=!0x1){this['auth']=_0x34856f,this['resolver']=_0x274360,this['user']=_0x24c3be,this['bypassAuthState']=_0x1423bd,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5d3864)?_0x5d3864:[_0x5d3864];}['execute'](){return new Promise(async(_0x27195d,_0x16ca40)=>{this['pendingPromise']={'resolve':_0x27195d,'reject':_0x16ca40};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x47679b){this['reject'](_0x47679b);}});}async['onAuthEvent'](_0x576c3e){const {urlResponse:_0x4bbfd5,sessionId:_0x3ecb42,postBody:_0xe2f615,tenantId:_0x5afa4c,error:_0x164668,type:_0xa5ef5f}=_0x576c3e;if(_0x164668){this['reject'](_0x164668);return;}const _0xff2758={'auth':this['auth'],'requestUri':_0x4bbfd5,'sessionId':_0x3ecb42,'tenantId':_0x5afa4c||void 0x0,'postBody':_0xe2f615||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0xa5ef5f)(_0xff2758));}catch(_0x58e9ef){this['reject'](_0x58e9ef);}}['onError'](_0x461c5c){this['reject'](_0x461c5c);}['getIdpTask'](_0x4aafb3){switch(_0x4aafb3){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x983c07){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x983c07),this['unregisterAndCleanUp']();}['reject'](_0x4c8518){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x4c8518),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x17e010,_0x4d16dc,_0x50cb0f,_0x112c67,_0x1b8330){super(_0x17e010,_0x4d16dc,_0x112c67,_0x1b8330),this['provider']=_0x50cb0f,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x3eb449=await this['execute']();return m(_0x3eb449,this['auth'],'internal-error'),_0x3eb449;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xc380d8=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xc380d8),this['authWindow']['associatedEvent']=_0xc380d8,this['resolver']['_originValidation'](this['auth'])['catch'](_0x18dc85=>{this['reject'](_0x18dc85);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5eb832=>{_0x5eb832||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x42f967;return((_0x42f967=this['authWindow'])==null?void 0x0:_0x42f967['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2af1bd=()=>{var _0x359e82,_0x46da4d;if((_0x46da4d=(_0x359e82=this['authWindow'])==null?void 0x0:_0x359e82['window'])!=null&&_0x46da4d['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2af1bd,mp['get']());};_0x2af1bd();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x217264,_0x46478b,_0x482f9a=!0x1){super(_0x217264,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x46478b,void 0x0,_0x482f9a),this['eventId']=null;}async['execute'](){let _0x9cd26e=rn['get'](this['auth']['_key']());if(!_0x9cd26e){try{const _0x3e7c5f=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x9cd26e=()=>Promise['resolve'](_0x3e7c5f);}catch(_0x25b90f){_0x9cd26e=()=>Promise['reject'](_0x25b90f);}rn['set'](this['auth']['_key'](),_0x9cd26e);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x9cd26e();}async['onAuthEvent'](_0x42d488){if(_0x42d488['type']==='signInViaRedirect')return super['onAuthEvent'](_0x42d488);if(_0x42d488['type']==='unknown'){this['resolve'](null);return;}if(_0x42d488['eventId']){const _0x5c8fef=await this['auth']['_redirectUserForId'](_0x42d488['eventId']);if(_0x5c8fef)return this['user']=_0x5c8fef,super['onAuthEvent'](_0x42d488);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x45f878,_0x117e6b){const _0x26197c=Cp(_0x117e6b),_0x3dd7c6=wp(_0x45f878);if(!await _0x3dd7c6['_isAvailable']())return!0x1;const _0x263615=await _0x3dd7c6['_get'](_0x26197c)==='true';return await _0x3dd7c6['_remove'](_0x26197c),_0x263615;}function Ip(_0x4b8984,_0x13c468){rn['set'](_0x4b8984['_key'](),_0x13c468);}function wp(_0x21f006){return ne(_0x21f006['_redirectPersistence']);}function Cp(_0x548403){return sn(yp,_0x548403['config']['apiKey'],_0x548403['name']);}async function Tp(_0x516210,_0x256f2e,_0x14c51c=!0x1){if(H(_0x516210['app']))return Promise['reject'](se(_0x516210));const _0x4706db=qe(_0x516210),_0x366970=fp(_0x4706db,_0x256f2e),_0x4104f5=await new vp(_0x4706db,_0x366970,_0x14c51c)['execute']();return _0x4104f5&&!_0x14c51c&&(delete _0x4104f5['user']['_redirectEventId'],await _0x4706db['_persistUserIfCurrent'](_0x4104f5['user']),await _0x4706db['_setRedirectUser'](null,_0x256f2e)),_0x4104f5;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x281250){this['auth']=_0x281250,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4e610a){this['consumers']['add'](_0x4e610a),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4e610a)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4e610a),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2905f6){this['consumers']['delete'](_0x2905f6);}['onEvent'](_0x5ca616){if(this['hasEventBeenHandled'](_0x5ca616))return!0x1;let _0x5b61c2=!0x1;return this['consumers']['forEach'](_0x23a156=>{this['isEventForConsumer'](_0x5ca616,_0x23a156)&&(_0x5b61c2=!0x0,this['sendToConsumer'](_0x5ca616,_0x23a156),this['saveEventToCache'](_0x5ca616));}),this['hasHandledPotentialRedirect']||!Rp(_0x5ca616)||(this['hasHandledPotentialRedirect']=!0x0,_0x5b61c2||(this['queuedRedirectEvent']=_0x5ca616,_0x5b61c2=!0x0)),_0x5b61c2;}['sendToConsumer'](_0x2f43ce,_0x3c4b9e){var _0x4e2591;if(_0x2f43ce['error']&&!Qa(_0x2f43ce)){const _0xb3a940=((_0x4e2591=_0x2f43ce['error']['code'])==null?void 0x0:_0x4e2591['split']('auth/')[0x1])||'internal-error';_0x3c4b9e['onError'](J(this['auth'],_0xb3a940));}else _0x3c4b9e['onAuthEvent'](_0x2f43ce);}['isEventForConsumer'](_0x36b475,_0x1f259c){const _0x127dae=_0x1f259c['eventId']===null||!!_0x36b475['eventId']&&_0x36b475['eventId']===_0x1f259c['eventId'];return _0x1f259c['filter']['includes'](_0x36b475['type'])&&_0x127dae;}['hasEventBeenHandled'](_0xcb0f0c){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0xcb0f0c));}['saveEventToCache'](_0xd8faea){this['cachedEventUids']['add'](Pr(_0xd8faea)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x4679c7){return[_0x4679c7['type'],_0x4679c7['eventId'],_0x4679c7['sessionId'],_0x4679c7['tenantId']]['filter'](_0x7f67e9=>_0x7f67e9)['join']('-');}function Qa({type:_0x502eaa,error:_0xebd7ae}){return _0x502eaa==='unknown'&&(_0xebd7ae==null?void 0x0:_0xebd7ae['code'])==='auth/no-auth-event';}function Rp(_0x40d9fb){switch(_0x40d9fb['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x40d9fb);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x1785e2,_0x3935c7={}){return Ae(_0x1785e2,'GET','/v1/projects',_0x3935c7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x590a0d){if(_0x590a0d['config']['emulator'])return;const {authorizedDomains:_0x14992f}=await Ap(_0x590a0d);for(const _0x1fe5f3 of _0x14992f)try{if(Op(_0x1fe5f3))return;}catch{}K(_0x590a0d,'unauthorized-domain');}function Op(_0x587e49){const _0x179046=Ni(),{protocol:_0x4b1675,hostname:_0x12b3e3}=new URL(_0x179046);if(_0x587e49['startsWith']('chrome-extension://')){const _0x15c0b2=new URL(_0x587e49);return _0x15c0b2['hostname']===''&&_0x12b3e3===''?_0x4b1675==='chrome-extension:'&&_0x587e49['replace']('chrome-extension://','')===_0x179046['replace']('chrome-extension://',''):_0x4b1675==='chrome-extension:'&&_0x15c0b2['hostname']===_0x12b3e3;}if(!Np['test'](_0x4b1675))return!0x1;if(kp['test'](_0x587e49))return _0x12b3e3===_0x587e49;const _0x21cb09=_0x587e49['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x21cb09+'|'+_0x21cb09+')$','i')['test'](_0x12b3e3);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x23e157=X()['___jsl'];if(_0x23e157!=null&&_0x23e157['H']){for(const _0x5dbc91 of Object['keys'](_0x23e157['H']))if(_0x23e157['H'][_0x5dbc91]['r']=_0x23e157['H'][_0x5dbc91]['r']||[],_0x23e157['H'][_0x5dbc91]['L']=_0x23e157['H'][_0x5dbc91]['L']||[],_0x23e157['H'][_0x5dbc91]['r']=[..._0x23e157['H'][_0x5dbc91]['L']],_0x23e157['CP']){for(let _0x14712e=0x0;_0x14712e<_0x23e157['CP']['length'];_0x14712e++)_0x23e157['CP'][_0x14712e]=null;}}}function Mp(_0x117c25){return new Promise((_0x397e3e,_0x32200e)=>{var _0x386b1b,_0x4b2e4e,_0xf78615;function _0x1a2be1(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x397e3e(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x32200e(J(_0x117c25,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x4b2e4e=(_0x386b1b=X()['gapi'])==null?void 0x0:_0x386b1b['iframes'])!=null&&_0x4b2e4e['Iframe'])_0x397e3e(gapi['iframes']['getContext']());else{if((_0xf78615=X()['gapi'])!=null&&_0xf78615['load'])_0x1a2be1();else{const _0x1c5213=Nf('iframefcb');return X()[_0x1c5213]=()=>{gapi['load']?_0x1a2be1():_0x32200e(J(_0x117c25,'network-request-failed'));},Da(kf()+'?onload='+_0x1c5213)['catch'](_0x1a8ace=>_0x32200e(_0x1a8ace));}}})['catch'](_0x517695=>{throw on=null,_0x517695;});}let on=null;function Lp(_0x347edc){return on=on||Mp(_0x347edc),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x48600d){const _0x2a50e0=_0x48600d['config'];m(_0x2a50e0['authDomain'],_0x48600d,'auth-domain-config-required');const _0x28b7f9=_0x2a50e0['emulator']?Is(_0x2a50e0,Up):'https://'+_0x48600d['config']['authDomain']+'/'+Fp,_0x3725cb={'apiKey':_0x2a50e0['apiKey'],'appName':_0x48600d['name'],'v':ct},_0x108aaf=Bp['get'](_0x48600d['config']['apiHost']);_0x108aaf&&(_0x3725cb['eid']=_0x108aaf);const _0x4e2dcf=_0x48600d['_getFrameworks']();return _0x4e2dcf['length']&&(_0x3725cb['fw']=_0x4e2dcf['join'](',')),_0x28b7f9+'?'+at(_0x3725cb)['slice'](0x1);}async function Hp(_0x29a326){const _0x678d1=await Lp(_0x29a326),_0x5d8c46=X()['gapi'];return m(_0x5d8c46,_0x29a326,'internal-error'),_0x678d1['open']({'where':document['body'],'url':Vp(_0x29a326),'messageHandlersFilter':_0x5d8c46['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x141db1=>new Promise(async(_0xceadc,_0x3541d0)=>{await _0x141db1['restyle']({'setHideOnLeave':!0x1});const _0xe471b0=J(_0x29a326,'network-request-failed'),_0x7b7897=X()['setTimeout'](()=>{_0x3541d0(_0xe471b0);},xp['get']());function _0x422dbb(){X()['clearTimeout'](_0x7b7897),_0xceadc(_0x141db1);}_0x141db1['ping'](_0x422dbb)['then'](_0x422dbb,()=>{_0x3541d0(_0xe471b0);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x548f82){this['window']=_0x548f82,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x45a4e6,_0x5a1d02,_0x246b69,_0x373f3f=Gp,_0x445004=qp){const _0x531a3a=Math['max']((window['screen']['availHeight']-_0x445004)/0x2,0x0)['toString'](),_0x580454=Math['max']((window['screen']['availWidth']-_0x373f3f)/0x2,0x0)['toString']();let _0x3be46c='';const _0xc6832a={...$p,'width':_0x373f3f['toString'](),'height':_0x445004['toString'](),'top':_0x531a3a,'left':_0x580454},_0x2a06b0=W()['toLowerCase']();_0x246b69&&(_0x3be46c=ba(_0x2a06b0)?zp:_0x246b69),Ta(_0x2a06b0)&&(_0x5a1d02=_0x5a1d02||jp,_0xc6832a['scrollbars']='yes');const _0x3bdfe3=Object['entries'](_0xc6832a)['reduce']((_0xe48438,[_0x48cb48,_0x1c5b8b])=>''+_0xe48438+_0x48cb48+'='+_0x1c5b8b+',','');if(Ef(_0x2a06b0)&&_0x3be46c!=='_self')return Yp(_0x5a1d02||'',_0x3be46c),new Dr(null);const _0x460368=window['open'](_0x5a1d02||'',_0x3be46c,_0x3bdfe3);m(_0x460368,_0x45a4e6,'popup-blocked');try{_0x460368['focus']();}catch{}return new Dr(_0x460368);}function Yp(_0x330a5c,_0x4ed3af){const _0x1e9b86=document['createElement']('a');_0x1e9b86['href']=_0x330a5c,_0x1e9b86['target']=_0x4ed3af;const _0x3aefe6=document['createEvent']('MouseEvent');_0x3aefe6['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1e9b86['dispatchEvent'](_0x3aefe6);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x3706ae,_0x55b66c,_0x3a1fb0,_0x2df148,_0x5c6320,_0x2420bb){m(_0x3706ae['config']['authDomain'],_0x3706ae,'auth-domain-config-required'),m(_0x3706ae['config']['apiKey'],_0x3706ae,'invalid-api-key');const _0x2fc588={'apiKey':_0x3706ae['config']['apiKey'],'appName':_0x3706ae['name'],'authType':_0x3a1fb0,'redirectUrl':_0x2df148,'v':ct,'eventId':_0x5c6320};if(_0x55b66c instanceof xa){_0x55b66c['setDefaultLanguage'](_0x3706ae['languageCode']),_0x2fc588['providerId']=_0x55b66c['providerId']||'',hi(_0x55b66c['getCustomParameters']())||(_0x2fc588['customParameters']=JSON['stringify'](_0x55b66c['getCustomParameters']()));for(const [_0x11bc4e,_0x216b00]of Object['entries']({}))_0x2fc588[_0x11bc4e]=_0x216b00;}if(_0x55b66c instanceof Qt){const _0x9a7810=_0x55b66c['getScopes']()['filter'](_0x90d562=>_0x90d562!=='');_0x9a7810['length']>0x0&&(_0x2fc588['scopes']=_0x9a7810['join'](','));}_0x3706ae['tenantId']&&(_0x2fc588['tid']=_0x3706ae['tenantId']);const _0x23b09c=_0x2fc588;for(const _0x397ec9 of Object['keys'](_0x23b09c))_0x23b09c[_0x397ec9]===void 0x0&&delete _0x23b09c[_0x397ec9];const _0x865d68=await _0x3706ae['_getAppCheckToken'](),_0x5f3310=_0x865d68?'#'+Xp+'='+encodeURIComponent(_0x865d68):'';return Zp(_0x3706ae)+'?'+at(_0x23b09c)['slice'](0x1)+_0x5f3310;}function Zp({config:_0x2d036b}){return _0x2d036b['emulator']?Is(_0x2d036b,Jp):'https://'+_0x2d036b['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x1b33b2,_0x5a5592,_0x7a3c11,_0x45b606){var _0x350db2;ae((_0x350db2=this['eventManagers'][_0x1b33b2['_key']()])==null?void 0x0:_0x350db2['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x39e0d3=await Mr(_0x1b33b2,_0x5a5592,_0x7a3c11,Ni(),_0x45b606);return Kp(_0x1b33b2,_0x39e0d3,bs());}async['_openRedirect'](_0x45dc00,_0x484fed,_0x190db5,_0x13ddd5){await this['_originValidation'](_0x45dc00);const _0xbd4768=await Mr(_0x45dc00,_0x484fed,_0x190db5,Ni(),_0x13ddd5);return ip(_0xbd4768),new Promise(()=>{});}['_initialize'](_0x5d367b){const _0x35f514=_0x5d367b['_key']();if(this['eventManagers'][_0x35f514]){const {manager:_0x117f42,promise:_0xc2339b}=this['eventManagers'][_0x35f514];return _0x117f42?Promise['resolve'](_0x117f42):(ae(_0xc2339b,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xc2339b);}const _0x2e3629=this['initAndGetManager'](_0x5d367b);return this['eventManagers'][_0x35f514]={'promise':_0x2e3629},_0x2e3629['catch'](()=>{delete this['eventManagers'][_0x35f514];}),_0x2e3629;}async['initAndGetManager'](_0x18acb4){const _0x1a53da=await Hp(_0x18acb4),_0x4ab8cf=new bp(_0x18acb4);return _0x1a53da['register']('authEvent',_0x74335d=>(m(_0x74335d==null?void 0x0:_0x74335d['authEvent'],_0x18acb4,'invalid-auth-event'),{'status':_0x4ab8cf['onEvent'](_0x74335d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x18acb4['_key']()]={'manager':_0x4ab8cf},this['iframes'][_0x18acb4['_key']()]=_0x1a53da,_0x4ab8cf;}['_isIframeWebStorageSupported'](_0x3dd966,_0x2beda9){this['iframes'][_0x3dd966['_key']()]['send'](li,{'type':li},_0x405672=>{var _0x164ab2;const _0x340b4a=(_0x164ab2=_0x405672==null?void 0x0:_0x405672[0x0])==null?void 0x0:_0x164ab2[li];_0x340b4a!==void 0x0&&_0x2beda9(!!_0x340b4a),K(_0x3dd966,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x45f82e){const _0x4741a5=_0x45f82e['_key']();return this['originValidationPromises'][_0x4741a5]||(this['originValidationPromises'][_0x4741a5]=Pp(_0x45f82e)),this['originValidationPromises'][_0x4741a5];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x402240){this['auth']=_0x402240,this['internalListeners']=new Map();}['getUid'](){var _0x33be72;return this['assertAuthConfigured'](),((_0x33be72=this['auth']['currentUser'])==null?void 0x0:_0x33be72['uid'])||null;}async['getToken'](_0x302ce7){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x302ce7)}:null;}['addAuthTokenListener'](_0x283c56){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x283c56))return;const _0x5785ea=this['auth']['onIdTokenChanged'](_0xa09c64=>{_0x283c56((_0xa09c64==null?void 0x0:_0xa09c64['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x283c56,_0x5785ea),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2505a7){this['assertAuthConfigured']();const _0xd9af89=this['internalListeners']['get'](_0x2505a7);_0xd9af89&&(this['internalListeners']['delete'](_0x2505a7),_0xd9af89(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x125943){switch(_0x125943){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x32e114){et(new Me('auth',(_0x16fd57,{options:_0x12b83c})=>{const _0x28999a=_0x16fd57['getProvider']('app')['getImmediate'](),_0xbbea95=_0x16fd57['getProvider']('heartbeat'),_0x272d21=_0x16fd57['getProvider']('app-check-internal'),{apiKey:_0x1df70,authDomain:_0x3d195b}=_0x28999a['options'];m(_0x1df70&&!_0x1df70['includes'](':'),'invalid-api-key',{'appName':_0x28999a['name']});const _0x28124f={'apiKey':_0x1df70,'authDomain':_0x3d195b,'clientPlatform':_0x32e114,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x32e114)},_0x553cd9=new bf(_0x28999a,_0xbbea95,_0x272d21,_0x28124f);return Lf(_0x553cd9,_0x12b83c),_0x553cd9;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x118135,_0x9bfae8,_0x58c92a)=>{_0x118135['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x48601e=>{const _0x44a475=qe(_0x48601e['getProvider']('auth')['getImmediate']());return(_0x1e6624=>new n_(_0x1e6624))(_0x44a475);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x32e114)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x4f3758=>async _0x191e07=>{const _0x23c2a8=_0x191e07&&await _0x191e07['getIdTokenResult'](),_0x387082=_0x23c2a8&&(new Date()['getTime']()-Date['parse'](_0x23c2a8['issuedAtTime']))/0x3e8;if(_0x387082&&_0x387082>o_)return;const _0x2df856=_0x23c2a8==null?void 0x0:_0x23c2a8['token'];Fr!==_0x2df856&&(Fr=_0x2df856,await fetch(_0x4f3758,{'method':_0x2df856?'POST':'DELETE','headers':_0x2df856?{'Authorization':'Bearer\x20'+_0x2df856}:{}}));};function O_(_0x328f4e=Qr()){const _0x574ee6=Ui(_0x328f4e,'auth');if(_0x574ee6['isInitialized']())return _0x574ee6['getImmediate']();const _0x27a780=Mf(_0x328f4e,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x175646=Gr('authTokenSyncURL');if(_0x175646&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x22230d=new URL(_0x175646,location['origin']);if(location['origin']===_0x22230d['origin']){const _0x493f6d=a_(_0x22230d['toString']());Jf(_0x27a780,_0x493f6d,()=>_0x493f6d(_0x27a780['currentUser'])),Qf(_0x27a780,_0x984414=>_0x493f6d(_0x984414));}}const _0x197b0d=Hr('auth');return _0x197b0d&&xf(_0x27a780,'http://'+_0x197b0d),_0x27a780;}function c_(){var _0x4ef34d;return((_0x4ef34d=document['getElementsByTagName']('head'))==null?void 0x0:_0x4ef34d[0x0])??document;}Rf({'loadJS'(_0x58851e){return new Promise((_0x5d035f,_0x3a76d8)=>{const _0x3b6a68=document['createElement']('script');_0x3b6a68['setAttribute']('src',_0x58851e),_0x3b6a68['onload']=_0x5d035f,_0x3b6a68['onerror']=_0x4a8828=>{const _0x185946=J('internal-error');_0x185946['customData']=_0x4a8828,_0x3a76d8(_0x185946);},_0x3b6a68['type']='text/javascript',_0x3b6a68['charset']='UTF-8',c_()['appendChild'](_0x3b6a68);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};