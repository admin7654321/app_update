const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4787c3,_0x21f9ab){if(!_0x4787c3)throw ot(_0x21f9ab);},ot=function(_0x5490ce){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5490ce);},Wr=function(_0x5c1fdb){const _0x38910a=[];let _0x5734fd=0x0;for(let _0x46b9d8=0x0;_0x46b9d8<_0x5c1fdb['length'];_0x46b9d8++){let _0x89d278=_0x5c1fdb['charCodeAt'](_0x46b9d8);_0x89d278<0x80?_0x38910a[_0x5734fd++]=_0x89d278:_0x89d278<0x800?(_0x38910a[_0x5734fd++]=_0x89d278>>0x6|0xc0,_0x38910a[_0x5734fd++]=_0x89d278&0x3f|0x80):(_0x89d278&0xfc00)===0xd800&&_0x46b9d8+0x1<_0x5c1fdb['length']&&(_0x5c1fdb['charCodeAt'](_0x46b9d8+0x1)&0xfc00)===0xdc00?(_0x89d278=0x10000+((_0x89d278&0x3ff)<<0xa)+(_0x5c1fdb['charCodeAt'](++_0x46b9d8)&0x3ff),_0x38910a[_0x5734fd++]=_0x89d278>>0x12|0xf0,_0x38910a[_0x5734fd++]=_0x89d278>>0xc&0x3f|0x80,_0x38910a[_0x5734fd++]=_0x89d278>>0x6&0x3f|0x80,_0x38910a[_0x5734fd++]=_0x89d278&0x3f|0x80):(_0x38910a[_0x5734fd++]=_0x89d278>>0xc|0xe0,_0x38910a[_0x5734fd++]=_0x89d278>>0x6&0x3f|0x80,_0x38910a[_0x5734fd++]=_0x89d278&0x3f|0x80);}return _0x38910a;},Za=function(_0x2abe36){const _0x2deab6=[];let _0x5e27cd=0x0,_0x428daa=0x0;for(;_0x5e27cd<_0x2abe36['length'];){const _0x57d974=_0x2abe36[_0x5e27cd++];if(_0x57d974<0x80)_0x2deab6[_0x428daa++]=String['fromCharCode'](_0x57d974);else{if(_0x57d974>0xbf&&_0x57d974<0xe0){const _0x2263b1=_0x2abe36[_0x5e27cd++];_0x2deab6[_0x428daa++]=String['fromCharCode']((_0x57d974&0x1f)<<0x6|_0x2263b1&0x3f);}else{if(_0x57d974>0xef&&_0x57d974<0x16d){const _0x586fe2=_0x2abe36[_0x5e27cd++],_0x2b100b=_0x2abe36[_0x5e27cd++],_0x12c353=_0x2abe36[_0x5e27cd++],_0x5f5d8e=((_0x57d974&0x7)<<0x12|(_0x586fe2&0x3f)<<0xc|(_0x2b100b&0x3f)<<0x6|_0x12c353&0x3f)-0x10000;_0x2deab6[_0x428daa++]=String['fromCharCode'](0xd800+(_0x5f5d8e>>0xa)),_0x2deab6[_0x428daa++]=String['fromCharCode'](0xdc00+(_0x5f5d8e&0x3ff));}else{const _0x546fbb=_0x2abe36[_0x5e27cd++],_0x3c893a=_0x2abe36[_0x5e27cd++];_0x2deab6[_0x428daa++]=String['fromCharCode']((_0x57d974&0xf)<<0xc|(_0x546fbb&0x3f)<<0x6|_0x3c893a&0x3f);}}}}return _0x2deab6['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x19d75b,_0x1f1a9c){if(!Array['isArray'](_0x19d75b))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3f4739=_0x1f1a9c?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x58c04e=[];for(let _0x19a8f9=0x0;_0x19a8f9<_0x19d75b['length'];_0x19a8f9+=0x3){const _0x243b9b=_0x19d75b[_0x19a8f9],_0x3e8d90=_0x19a8f9+0x1<_0x19d75b['length'],_0x5b634b=_0x3e8d90?_0x19d75b[_0x19a8f9+0x1]:0x0,_0x3aa5cb=_0x19a8f9+0x2<_0x19d75b['length'],_0x161122=_0x3aa5cb?_0x19d75b[_0x19a8f9+0x2]:0x0,_0x2f97da=_0x243b9b>>0x2,_0x59b409=(_0x243b9b&0x3)<<0x4|_0x5b634b>>0x4;let _0x38c9a1=(_0x5b634b&0xf)<<0x2|_0x161122>>0x6,_0x59d99e=_0x161122&0x3f;_0x3aa5cb||(_0x59d99e=0x40,_0x3e8d90||(_0x38c9a1=0x40)),_0x58c04e['push'](_0x3f4739[_0x2f97da],_0x3f4739[_0x59b409],_0x3f4739[_0x38c9a1],_0x3f4739[_0x59d99e]);}return _0x58c04e['join']('');},'encodeString'(_0x512894,_0x2038e6){return this['HAS_NATIVE_SUPPORT']&&!_0x2038e6?btoa(_0x512894):this['encodeByteArray'](Wr(_0x512894),_0x2038e6);},'decodeString'(_0x3825a8,_0xa2f259){return this['HAS_NATIVE_SUPPORT']&&!_0xa2f259?atob(_0x3825a8):Za(this['decodeStringToByteArray'](_0x3825a8,_0xa2f259));},'decodeStringToByteArray'(_0x167455,_0x3e5f42){this['init_']();const _0x43084a=_0x3e5f42?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0xc9b9ea=[];for(let _0x970b9e=0x0;_0x970b9e<_0x167455['length'];){const _0x2b3edb=_0x43084a[_0x167455['charAt'](_0x970b9e++)],_0x55cd97=_0x970b9e<_0x167455['length']?_0x43084a[_0x167455['charAt'](_0x970b9e)]:0x0;++_0x970b9e;const _0x4a401e=_0x970b9e<_0x167455['length']?_0x43084a[_0x167455['charAt'](_0x970b9e)]:0x40;++_0x970b9e;const _0xa71120=_0x970b9e<_0x167455['length']?_0x43084a[_0x167455['charAt'](_0x970b9e)]:0x40;if(++_0x970b9e,_0x2b3edb==null||_0x55cd97==null||_0x4a401e==null||_0xa71120==null)throw new ec();const _0xd7c11c=_0x2b3edb<<0x2|_0x55cd97>>0x4;if(_0xc9b9ea['push'](_0xd7c11c),_0x4a401e!==0x40){const _0x3297ad=_0x55cd97<<0x4&0xf0|_0x4a401e>>0x2;if(_0xc9b9ea['push'](_0x3297ad),_0xa71120!==0x40){const _0x1690f8=_0x4a401e<<0x6&0xc0|_0xa71120;_0xc9b9ea['push'](_0x1690f8);}}}return _0xc9b9ea;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x158958=0x0;_0x158958<this['ENCODED_VALS']['length'];_0x158958++)this['byteToCharMap_'][_0x158958]=this['ENCODED_VALS']['charAt'](_0x158958),this['charToByteMap_'][this['byteToCharMap_'][_0x158958]]=_0x158958,this['byteToCharMapWebSafe_'][_0x158958]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x158958),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x158958]]=_0x158958,_0x158958>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x158958)]=_0x158958,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x158958)]=_0x158958);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x26fad2){const _0x29ecd9=Wr(_0x26fad2);return Di['encodeByteArray'](_0x29ecd9,!0x0);},an=function(_0x303192){return Br(_0x303192)['replace'](/\./g,'');},cn=function(_0x4d921f){try{return Di['decodeString'](_0x4d921f,!0x0);}catch(_0xedd7fd){console['error']('base64Decode\x20failed:\x20',_0xedd7fd);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x34c9f2){return Vr(void 0x0,_0x34c9f2);}function Vr(_0x16e083,_0x3e0717){if(!(_0x3e0717 instanceof Object))return _0x3e0717;switch(_0x3e0717['constructor']){case Date:const _0x26c45e=_0x3e0717;return new Date(_0x26c45e['getTime']());case Object:_0x16e083===void 0x0&&(_0x16e083={});break;case Array:_0x16e083=[];break;default:return _0x3e0717;}for(const _0x40e664 in _0x3e0717)!_0x3e0717['hasOwnProperty'](_0x40e664)||!nc(_0x40e664)||(_0x16e083[_0x40e664]=Vr(_0x16e083[_0x40e664],_0x3e0717[_0x40e664]));return _0x16e083;}function nc(_0x314df9){return _0x314df9!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x824bff=As['__FIREBASE_DEFAULTS__'];if(_0x824bff)return JSON['parse'](_0x824bff);},oc=()=>{if(typeof document>'u')return;let _0x111129;try{_0x111129=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x274aca=_0x111129&&cn(_0x111129[0x1]);return _0x274aca&&JSON['parse'](_0x274aca);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x369bc2){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x369bc2);return;}},Hr=_0x1ff2b1=>{var _0x53bf76,_0x2c633d;return(_0x2c633d=(_0x53bf76=Mi())==null?void 0x0:_0x53bf76['emulatorHosts'])==null?void 0x0:_0x2c633d[_0x1ff2b1];},ac=_0x5a9937=>{const _0x2fc282=Hr(_0x5a9937);if(!_0x2fc282)return;const _0x4e036d=_0x2fc282['lastIndexOf'](':');if(_0x4e036d<=0x0||_0x4e036d+0x1===_0x2fc282['length'])throw new Error('Invalid\x20host\x20'+_0x2fc282+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1f298a=parseInt(_0x2fc282['substring'](_0x4e036d+0x1),0xa);return _0x2fc282[0x0]==='['?[_0x2fc282['substring'](0x1,_0x4e036d-0x1),_0x1f298a]:[_0x2fc282['substring'](0x0,_0x4e036d),_0x1f298a];},$r=()=>{var _0x5bb348;return(_0x5bb348=Mi())==null?void 0x0:_0x5bb348['config'];},Gr=_0x16cb76=>{var _0x1750e5;return(_0x1750e5=Mi())==null?void 0x0:_0x1750e5['_'+_0x16cb76];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0xe8976,_0x3f81b0)=>{this['resolve']=_0xe8976,this['reject']=_0x3f81b0;});}['wrapCallback'](_0x392afe){return(_0x5e0350,_0x352ace)=>{_0x5e0350?this['reject'](_0x5e0350):this['resolve'](_0x352ace),typeof _0x392afe=='function'&&(this['promise']['catch'](()=>{}),_0x392afe['length']===0x1?_0x392afe(_0x5e0350):_0x392afe(_0x5e0350,_0x352ace));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x118b91,_0x32ce14){if(_0x118b91['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x556fdb={'alg':'none','type':'JWT'},_0x29cc63=_0x32ce14||'demo-project',_0x4d34b8=_0x118b91['iat']||0x0,_0x334583=_0x118b91['sub']||_0x118b91['user_id'];if(!_0x334583)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x75064b={'iss':'https://securetoken.google.com/'+_0x29cc63,'aud':_0x29cc63,'iat':_0x4d34b8,'exp':_0x4d34b8+0xe10,'auth_time':_0x4d34b8,'sub':_0x334583,'user_id':_0x334583,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x118b91};return[an(JSON['stringify'](_0x556fdb)),an(JSON['stringify'](_0x75064b)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x25c1f1=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x25c1f1=='object'&&_0x25c1f1['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x1cd05f=W();return _0x1cd05f['indexOf']('MSIE\x20')>=0x0||_0x1cd05f['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x2e9afc,_0x3e71f0)=>{try{let _0x3b117b=!0x0;const _0x504d0='validate-browser-context-for-indexeddb-analytics-module',_0x30b3fe=self['indexedDB']['open'](_0x504d0);_0x30b3fe['onsuccess']=()=>{_0x30b3fe['result']['close'](),_0x3b117b||self['indexedDB']['deleteDatabase'](_0x504d0),_0x2e9afc(!0x0);},_0x30b3fe['onupgradeneeded']=()=>{_0x3b117b=!0x1;},_0x30b3fe['onerror']=()=>{var _0xb542fb;_0x3e71f0(((_0xb542fb=_0x30b3fe['error'])==null?void 0x0:_0xb542fb['message'])||'');};}catch(_0x16b632){_0x3e71f0(_0x16b632);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x16d9a6,_0xd0ff56,_0x3efdcd){super(_0xd0ff56),this['code']=_0x16d9a6,this['customData']=_0x3efdcd,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x10e0aa,_0x572119,_0x3e9a7a){this['service']=_0x10e0aa,this['serviceName']=_0x572119,this['errors']=_0x3e9a7a;}['create'](_0x11ea57,..._0xab0f9f){const _0x276e50=_0xab0f9f[0x0]||{},_0x581c04=this['service']+'/'+_0x11ea57,_0x5151de=this['errors'][_0x11ea57],_0x2566f2=_0x5151de?gc(_0x5151de,_0x276e50):'Error',_0x3799ef=this['serviceName']+':\x20'+_0x2566f2+'\x20('+_0x581c04+').';return new Se(_0x581c04,_0x3799ef,_0x276e50);}}function gc(_0x1a2c34,_0x2ad4f0){return _0x1a2c34['replace'](mc,(_0x5a7619,_0x50fb06)=>{const _0x3efb86=_0x2ad4f0[_0x50fb06];return _0x3efb86!=null?String(_0x3efb86):'<'+_0x50fb06+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0xe6f963){return JSON['parse'](_0xe6f963);}function O(_0x17983c){return JSON['stringify'](_0x17983c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x51e103){let _0x277c08={},_0x347717={},_0x535f3c={},_0x44a322='';try{const _0x1676b3=_0x51e103['split']('.');_0x277c08=bt(cn(_0x1676b3[0x0])||''),_0x347717=bt(cn(_0x1676b3[0x1])||''),_0x44a322=_0x1676b3[0x2],_0x535f3c=_0x347717['d']||{},delete _0x347717['d'];}catch{}return{'header':_0x277c08,'claims':_0x347717,'data':_0x535f3c,'signature':_0x44a322};},yc=function(_0x1faa86){const _0x947576=zr(_0x1faa86),_0x8b4b77=_0x947576['claims'];return!!_0x8b4b77&&typeof _0x8b4b77=='object'&&_0x8b4b77['hasOwnProperty']('iat');},vc=function(_0x3ed898){const _0x1d05b2=zr(_0x3ed898)['claims'];return typeof _0x1d05b2=='object'&&_0x1d05b2['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x43607e,_0x57faaf){return Object['prototype']['hasOwnProperty']['call'](_0x43607e,_0x57faaf);}function Oe(_0xe1ef05,_0x5b6b1d){if(Object['prototype']['hasOwnProperty']['call'](_0xe1ef05,_0x5b6b1d))return _0xe1ef05[_0x5b6b1d];}function hi(_0x53977e){for(const _0x5a829c in _0x53977e)if(Object['prototype']['hasOwnProperty']['call'](_0x53977e,_0x5a829c))return!0x1;return!0x0;}function ln(_0x1ebea1,_0x240035,_0x202361){const _0x521566={};for(const _0x3008ef in _0x1ebea1)Object['prototype']['hasOwnProperty']['call'](_0x1ebea1,_0x3008ef)&&(_0x521566[_0x3008ef]=_0x240035['call'](_0x202361,_0x1ebea1[_0x3008ef],_0x3008ef,_0x1ebea1));return _0x521566;}function De(_0x34f5ee,_0x256c36){if(_0x34f5ee===_0x256c36)return!0x0;const _0x109ced=Object['keys'](_0x34f5ee),_0x26413e=Object['keys'](_0x256c36);for(const _0x5981c0 of _0x109ced){if(!_0x26413e['includes'](_0x5981c0))return!0x1;const _0x27b671=_0x34f5ee[_0x5981c0],_0x14fa8d=_0x256c36[_0x5981c0];if(ks(_0x27b671)&&ks(_0x14fa8d)){if(!De(_0x27b671,_0x14fa8d))return!0x1;}else{if(_0x27b671!==_0x14fa8d)return!0x1;}}for(const _0x2a1fea of _0x26413e)if(!_0x109ced['includes'](_0x2a1fea))return!0x1;return!0x0;}function ks(_0x340e1e){return _0x340e1e!==null&&typeof _0x340e1e=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x468961){const _0x44d1a3=[];for(const [_0x1fa86d,_0x1a3918]of Object['entries'](_0x468961))Array['isArray'](_0x1a3918)?_0x1a3918['forEach'](_0x21dc2e=>{_0x44d1a3['push'](encodeURIComponent(_0x1fa86d)+'='+encodeURIComponent(_0x21dc2e));}):_0x44d1a3['push'](encodeURIComponent(_0x1fa86d)+'='+encodeURIComponent(_0x1a3918));return _0x44d1a3['length']?'&'+_0x44d1a3['join']('&'):'';}function yt(_0x15e1a0){const _0x34bb6e={};return _0x15e1a0['replace'](/^\?/,'')['split']('&')['forEach'](_0x8dd2a0=>{if(_0x8dd2a0){const [_0x1b73d2,_0x125235]=_0x8dd2a0['split']('=');_0x34bb6e[decodeURIComponent(_0x1b73d2)]=decodeURIComponent(_0x125235);}}),_0x34bb6e;}function vt(_0x49df4f){const _0x21e9c1=_0x49df4f['indexOf']('?');if(!_0x21e9c1)return'';const _0x21643c=_0x49df4f['indexOf']('#',_0x21e9c1);return _0x49df4f['substring'](_0x21e9c1,_0x21643c>0x0?_0x21643c:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3539c5=0x1;_0x3539c5<this['blockSize'];++_0x3539c5)this['pad_'][_0x3539c5]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x4c562d,_0x4649ff){_0x4649ff||(_0x4649ff=0x0);const _0x19f3bd=this['W_'];if(typeof _0x4c562d=='string'){for(let _0x753647=0x0;_0x753647<0x10;_0x753647++)_0x19f3bd[_0x753647]=_0x4c562d['charCodeAt'](_0x4649ff)<<0x18|_0x4c562d['charCodeAt'](_0x4649ff+0x1)<<0x10|_0x4c562d['charCodeAt'](_0x4649ff+0x2)<<0x8|_0x4c562d['charCodeAt'](_0x4649ff+0x3),_0x4649ff+=0x4;}else{for(let _0x75c8f0=0x0;_0x75c8f0<0x10;_0x75c8f0++)_0x19f3bd[_0x75c8f0]=_0x4c562d[_0x4649ff]<<0x18|_0x4c562d[_0x4649ff+0x1]<<0x10|_0x4c562d[_0x4649ff+0x2]<<0x8|_0x4c562d[_0x4649ff+0x3],_0x4649ff+=0x4;}for(let _0x457295=0x10;_0x457295<0x50;_0x457295++){const _0x3e795c=_0x19f3bd[_0x457295-0x3]^_0x19f3bd[_0x457295-0x8]^_0x19f3bd[_0x457295-0xe]^_0x19f3bd[_0x457295-0x10];_0x19f3bd[_0x457295]=(_0x3e795c<<0x1|_0x3e795c>>>0x1f)&0xffffffff;}let _0x81215=this['chain_'][0x0],_0x19f630=this['chain_'][0x1],_0x1764e7=this['chain_'][0x2],_0x539bbe=this['chain_'][0x3],_0x3aad28=this['chain_'][0x4],_0x49dcd8,_0x114b9c;for(let _0x7c4a4f=0x0;_0x7c4a4f<0x50;_0x7c4a4f++){_0x7c4a4f<0x28?_0x7c4a4f<0x14?(_0x49dcd8=_0x539bbe^_0x19f630&(_0x1764e7^_0x539bbe),_0x114b9c=0x5a827999):(_0x49dcd8=_0x19f630^_0x1764e7^_0x539bbe,_0x114b9c=0x6ed9eba1):_0x7c4a4f<0x3c?(_0x49dcd8=_0x19f630&_0x1764e7|_0x539bbe&(_0x19f630|_0x1764e7),_0x114b9c=0x8f1bbcdc):(_0x49dcd8=_0x19f630^_0x1764e7^_0x539bbe,_0x114b9c=0xca62c1d6);const _0x4c9b27=(_0x81215<<0x5|_0x81215>>>0x1b)+_0x49dcd8+_0x3aad28+_0x114b9c+_0x19f3bd[_0x7c4a4f]&0xffffffff;_0x3aad28=_0x539bbe,_0x539bbe=_0x1764e7,_0x1764e7=(_0x19f630<<0x1e|_0x19f630>>>0x2)&0xffffffff,_0x19f630=_0x81215,_0x81215=_0x4c9b27;}this['chain_'][0x0]=this['chain_'][0x0]+_0x81215&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x19f630&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1764e7&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x539bbe&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3aad28&0xffffffff;}['update'](_0x168f6c,_0x5d66c1){if(_0x168f6c==null)return;_0x5d66c1===void 0x0&&(_0x5d66c1=_0x168f6c['length']);const _0x26f965=_0x5d66c1-this['blockSize'];let _0x13a09f=0x0;const _0x3aaae8=this['buf_'];let _0x57f113=this['inbuf_'];for(;_0x13a09f<_0x5d66c1;){if(_0x57f113===0x0){for(;_0x13a09f<=_0x26f965;)this['compress_'](_0x168f6c,_0x13a09f),_0x13a09f+=this['blockSize'];}if(typeof _0x168f6c=='string'){for(;_0x13a09f<_0x5d66c1;)if(_0x3aaae8[_0x57f113]=_0x168f6c['charCodeAt'](_0x13a09f),++_0x57f113,++_0x13a09f,_0x57f113===this['blockSize']){this['compress_'](_0x3aaae8),_0x57f113=0x0;break;}}else{for(;_0x13a09f<_0x5d66c1;)if(_0x3aaae8[_0x57f113]=_0x168f6c[_0x13a09f],++_0x57f113,++_0x13a09f,_0x57f113===this['blockSize']){this['compress_'](_0x3aaae8),_0x57f113=0x0;break;}}}this['inbuf_']=_0x57f113,this['total_']+=_0x5d66c1;}['digest'](){const _0x24dd4e=[];let _0x1e03d1=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x168a3a=this['blockSize']-0x1;_0x168a3a>=0x38;_0x168a3a--)this['buf_'][_0x168a3a]=_0x1e03d1&0xff,_0x1e03d1/=0x100;this['compress_'](this['buf_']);let _0x971c83=0x0;for(let _0x100359=0x0;_0x100359<0x5;_0x100359++)for(let _0x2d9b84=0x18;_0x2d9b84>=0x0;_0x2d9b84-=0x8)_0x24dd4e[_0x971c83]=this['chain_'][_0x100359]>>_0x2d9b84&0xff,++_0x971c83;return _0x24dd4e;}}function Ic(_0x3b0a45,_0x117702){const _0x3ff79e=new wc(_0x3b0a45,_0x117702);return _0x3ff79e['subscribe']['bind'](_0x3ff79e);}class wc{constructor(_0x19dc6b,_0x35886f){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x35886f,this['task']['then'](()=>{_0x19dc6b(this);})['catch'](_0x25c31e=>{this['error'](_0x25c31e);});}['next'](_0x105d72){this['forEachObserver'](_0x2ae664=>{_0x2ae664['next'](_0x105d72);});}['error'](_0x579ade){this['forEachObserver'](_0x3b7bf9=>{_0x3b7bf9['error'](_0x579ade);}),this['close'](_0x579ade);}['complete'](){this['forEachObserver'](_0x4a385a=>{_0x4a385a['complete']();}),this['close']();}['subscribe'](_0x5abb04,_0x27a82e,_0x237c9f){let _0x1aecbc;if(_0x5abb04===void 0x0&&_0x27a82e===void 0x0&&_0x237c9f===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x5abb04,['next','error','complete'])?_0x1aecbc=_0x5abb04:_0x1aecbc={'next':_0x5abb04,'error':_0x27a82e,'complete':_0x237c9f},_0x1aecbc['next']===void 0x0&&(_0x1aecbc['next']=Qn),_0x1aecbc['error']===void 0x0&&(_0x1aecbc['error']=Qn),_0x1aecbc['complete']===void 0x0&&(_0x1aecbc['complete']=Qn);const _0x5611d0=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x1aecbc['error'](this['finalError']):_0x1aecbc['complete']();}catch{}}),this['observers']['push'](_0x1aecbc),_0x5611d0;}['unsubscribeOne'](_0xa17999){this['observers']===void 0x0||this['observers'][_0xa17999]===void 0x0||(delete this['observers'][_0xa17999],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x55a344){if(!this['finalized']){for(let _0x16fac5=0x0;_0x16fac5<this['observers']['length'];_0x16fac5++)this['sendOne'](_0x16fac5,_0x55a344);}}['sendOne'](_0x17410f,_0x4e50f3){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x17410f]!==void 0x0)try{_0x4e50f3(this['observers'][_0x17410f]);}catch(_0x35fae7){typeof console<'u'&&console['error']&&console['error'](_0x35fae7);}});}['close'](_0x5f09c4){this['finalized']||(this['finalized']=!0x0,_0x5f09c4!==void 0x0&&(this['finalError']=_0x5f09c4),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x2c747d,_0x333132){if(typeof _0x2c747d!='object'||_0x2c747d===null)return!0x1;for(const _0x2790f9 of _0x333132)if(_0x2790f9 in _0x2c747d&&typeof _0x2c747d[_0x2790f9]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x3d0b5a,_0x10c943){return _0x3d0b5a+'\x20failed:\x20'+_0x10c943+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0xb4b40c){const _0x4d37d9=[];let _0x4fbd50=0x0;for(let _0x366e46=0x0;_0x366e46<_0xb4b40c['length'];_0x366e46++){let _0x100217=_0xb4b40c['charCodeAt'](_0x366e46);if(_0x100217>=0xd800&&_0x100217<=0xdbff){const _0x2c6f8e=_0x100217-0xd800;_0x366e46++,f(_0x366e46<_0xb4b40c['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5d242f=_0xb4b40c['charCodeAt'](_0x366e46)-0xdc00;_0x100217=0x10000+(_0x2c6f8e<<0xa)+_0x5d242f;}_0x100217<0x80?_0x4d37d9[_0x4fbd50++]=_0x100217:_0x100217<0x800?(_0x4d37d9[_0x4fbd50++]=_0x100217>>0x6|0xc0,_0x4d37d9[_0x4fbd50++]=_0x100217&0x3f|0x80):_0x100217<0x10000?(_0x4d37d9[_0x4fbd50++]=_0x100217>>0xc|0xe0,_0x4d37d9[_0x4fbd50++]=_0x100217>>0x6&0x3f|0x80,_0x4d37d9[_0x4fbd50++]=_0x100217&0x3f|0x80):(_0x4d37d9[_0x4fbd50++]=_0x100217>>0x12|0xf0,_0x4d37d9[_0x4fbd50++]=_0x100217>>0xc&0x3f|0x80,_0x4d37d9[_0x4fbd50++]=_0x100217>>0x6&0x3f|0x80,_0x4d37d9[_0x4fbd50++]=_0x100217&0x3f|0x80);}return _0x4d37d9;},Pn=function(_0x4e470e){let _0x5e7c44=0x0;for(let _0x56fc11=0x0;_0x56fc11<_0x4e470e['length'];_0x56fc11++){const _0x10ead8=_0x4e470e['charCodeAt'](_0x56fc11);_0x10ead8<0x80?_0x5e7c44++:_0x10ead8<0x800?_0x5e7c44+=0x2:_0x10ead8>=0xd800&&_0x10ead8<=0xdbff?(_0x5e7c44+=0x4,_0x56fc11++):_0x5e7c44+=0x3;}return _0x5e7c44;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0xe289a1){return _0xe289a1&&_0xe289a1['_delegate']?_0xe289a1['_delegate']:_0xe289a1;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x546899){try{return(_0x546899['startsWith']('http://')||_0x546899['startsWith']('https://')?new URL(_0x546899)['hostname']:_0x546899)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x443da0){return(await fetch(_0x443da0,{'credentials':'include'}))['ok'];}class Me{constructor(_0xd80a38,_0x40750c,_0x14044a){this['name']=_0xd80a38,this['instanceFactory']=_0x40750c,this['type']=_0x14044a,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1cc036){return this['instantiationMode']=_0x1cc036,this;}['setMultipleInstances'](_0x4e96fd){return this['multipleInstances']=_0x4e96fd,this;}['setServiceProps'](_0x32e7bc){return this['serviceProps']=_0x32e7bc,this;}['setInstanceCreatedCallback'](_0x18a847){return this['onInstanceCreated']=_0x18a847,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x3f77a2,_0x153f4f){this['name']=_0x3f77a2,this['container']=_0x153f4f,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1ed1b6){const _0x130670=this['normalizeInstanceIdentifier'](_0x1ed1b6);if(!this['instancesDeferred']['has'](_0x130670)){const _0x1f0518=new Ve();if(this['instancesDeferred']['set'](_0x130670,_0x1f0518),this['isInitialized'](_0x130670)||this['shouldAutoInitialize']())try{const _0x4df808=this['getOrInitializeService']({'instanceIdentifier':_0x130670});_0x4df808&&_0x1f0518['resolve'](_0x4df808);}catch{}}return this['instancesDeferred']['get'](_0x130670)['promise'];}['getImmediate'](_0x28aa98){const _0x5d6886=this['normalizeInstanceIdentifier'](_0x28aa98==null?void 0x0:_0x28aa98['identifier']),_0x5d7a40=(_0x28aa98==null?void 0x0:_0x28aa98['optional'])??!0x1;if(this['isInitialized'](_0x5d6886)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x5d6886});}catch(_0x334481){if(_0x5d7a40)return null;throw _0x334481;}else{if(_0x5d7a40)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x331915){if(_0x331915['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x331915['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x331915,!!this['shouldAutoInitialize']()){if(Rc(_0x331915))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x5b4ac1,_0x311a6e]of this['instancesDeferred']['entries']()){const _0x296730=this['normalizeInstanceIdentifier'](_0x5b4ac1);try{const _0x54e691=this['getOrInitializeService']({'instanceIdentifier':_0x296730});_0x311a6e['resolve'](_0x54e691);}catch{}}}}['clearInstance'](_0x42495e=ke){this['instancesDeferred']['delete'](_0x42495e),this['instancesOptions']['delete'](_0x42495e),this['instances']['delete'](_0x42495e);}async['delete'](){const _0x2d71c2=Array['from'](this['instances']['values']());await Promise['all']([..._0x2d71c2['filter'](_0x31ef23=>'INTERNAL'in _0x31ef23)['map'](_0x7225e8=>_0x7225e8['INTERNAL']['delete']()),..._0x2d71c2['filter'](_0x488812=>'_delete'in _0x488812)['map'](_0x17dd71=>_0x17dd71['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4f60d8=ke){return this['instances']['has'](_0x4f60d8);}['getOptions'](_0x11a2e7=ke){return this['instancesOptions']['get'](_0x11a2e7)||{};}['initialize'](_0x436665={}){const {options:_0x5c40cd={}}=_0x436665,_0x4142ee=this['normalizeInstanceIdentifier'](_0x436665['instanceIdentifier']);if(this['isInitialized'](_0x4142ee))throw Error(this['name']+'('+_0x4142ee+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x301d2d=this['getOrInitializeService']({'instanceIdentifier':_0x4142ee,'options':_0x5c40cd});for(const [_0x3f3e85,_0x1a0fea]of this['instancesDeferred']['entries']()){const _0x8dc05=this['normalizeInstanceIdentifier'](_0x3f3e85);_0x4142ee===_0x8dc05&&_0x1a0fea['resolve'](_0x301d2d);}return _0x301d2d;}['onInit'](_0x307388,_0x1fd3bb){const _0x598e52=this['normalizeInstanceIdentifier'](_0x1fd3bb),_0x2d7be6=this['onInitCallbacks']['get'](_0x598e52)??new Set();_0x2d7be6['add'](_0x307388),this['onInitCallbacks']['set'](_0x598e52,_0x2d7be6);const _0x32a836=this['instances']['get'](_0x598e52);return _0x32a836&&_0x307388(_0x32a836,_0x598e52),()=>{_0x2d7be6['delete'](_0x307388);};}['invokeOnInitCallbacks'](_0x39259f,_0x58d271){const _0x5af709=this['onInitCallbacks']['get'](_0x58d271);if(_0x5af709){for(const _0x312725 of _0x5af709)try{_0x312725(_0x39259f,_0x58d271);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x3df744,options:_0x2d09eb={}}){let _0x40c508=this['instances']['get'](_0x3df744);if(!_0x40c508&&this['component']&&(_0x40c508=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x3df744),'options':_0x2d09eb}),this['instances']['set'](_0x3df744,_0x40c508),this['instancesOptions']['set'](_0x3df744,_0x2d09eb),this['invokeOnInitCallbacks'](_0x40c508,_0x3df744),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x3df744,_0x40c508);}catch{}return _0x40c508||null;}['normalizeInstanceIdentifier'](_0x560517=ke){return this['component']?this['component']['multipleInstances']?_0x560517:ke:_0x560517;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x39a20e){return _0x39a20e===ke?void 0x0:_0x39a20e;}function Rc(_0x377fe8){return _0x377fe8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4f6dac){this['name']=_0x4f6dac,this['providers']=new Map();}['addComponent'](_0x2fcf7b){const _0x1883f1=this['getProvider'](_0x2fcf7b['name']);if(_0x1883f1['isComponentSet']())throw new Error('Component\x20'+_0x2fcf7b['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1883f1['setComponent'](_0x2fcf7b);}['addOrOverwriteComponent'](_0x27c777){this['getProvider'](_0x27c777['name'])['isComponentSet']()&&this['providers']['delete'](_0x27c777['name']),this['addComponent'](_0x27c777);}['getProvider'](_0x1faa4f){if(this['providers']['has'](_0x1faa4f))return this['providers']['get'](_0x1faa4f);const _0x41e22b=new Sc(_0x1faa4f,this);return this['providers']['set'](_0x1faa4f,_0x41e22b),_0x41e22b;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x5a0f98){_0x5a0f98[_0x5a0f98['DEBUG']=0x0]='DEBUG',_0x5a0f98[_0x5a0f98['VERBOSE']=0x1]='VERBOSE',_0x5a0f98[_0x5a0f98['INFO']=0x2]='INFO',_0x5a0f98[_0x5a0f98['WARN']=0x3]='WARN',_0x5a0f98[_0x5a0f98['ERROR']=0x4]='ERROR',_0x5a0f98[_0x5a0f98['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x398c75,_0x2fd0ba,..._0x59f4dd)=>{if(_0x2fd0ba<_0x398c75['logLevel'])return;const _0x26184c=new Date()['toISOString'](),_0xe0976c=Pc[_0x2fd0ba];if(_0xe0976c)console[_0xe0976c]('['+_0x26184c+']\x20\x20'+_0x398c75['name']+':',..._0x59f4dd);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2fd0ba+')');};class xi{constructor(_0x2441ac){this['name']=_0x2441ac,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0xe7880f){if(!(_0xe7880f in T))throw new TypeError('Invalid\x20value\x20\x22'+_0xe7880f+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0xe7880f;}['setLogLevel'](_0x2262d9){this['_logLevel']=typeof _0x2262d9=='string'?kc[_0x2262d9]:_0x2262d9;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x421661){if(typeof _0x421661!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x421661;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1974db){this['_userLogHandler']=_0x1974db;}['debug'](..._0x39a401){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x39a401),this['_logHandler'](this,T['DEBUG'],..._0x39a401);}['log'](..._0x4db4ae){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4db4ae),this['_logHandler'](this,T['VERBOSE'],..._0x4db4ae);}['info'](..._0x1ee33c){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1ee33c),this['_logHandler'](this,T['INFO'],..._0x1ee33c);}['warn'](..._0x107250){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x107250),this['_logHandler'](this,T['WARN'],..._0x107250);}['error'](..._0x153175){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x153175),this['_logHandler'](this,T['ERROR'],..._0x153175);}}const Dc=(_0x3f901e,_0x5da036)=>_0x5da036['some'](_0x2156f3=>_0x3f901e instanceof _0x2156f3);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x4417ed){const _0x1c527c=new Promise((_0xf8daa9,_0x4b66f6)=>{const _0x2eb6c9=()=>{_0x4417ed['removeEventListener']('success',_0x210cf8),_0x4417ed['removeEventListener']('error',_0x1bf66f);},_0x210cf8=()=>{_0xf8daa9(_e(_0x4417ed['result'])),_0x2eb6c9();},_0x1bf66f=()=>{_0x4b66f6(_0x4417ed['error']),_0x2eb6c9();};_0x4417ed['addEventListener']('success',_0x210cf8),_0x4417ed['addEventListener']('error',_0x1bf66f);});return _0x1c527c['then'](_0x44f26d=>{_0x44f26d instanceof IDBCursor&&Kr['set'](_0x44f26d,_0x4417ed);})['catch'](()=>{}),Fi['set'](_0x1c527c,_0x4417ed),_0x1c527c;}function Fc(_0x3ac540){if(ui['has'](_0x3ac540))return;const _0x601c64=new Promise((_0x45ab91,_0x15718b)=>{const _0x51a0bb=()=>{_0x3ac540['removeEventListener']('complete',_0x26b042),_0x3ac540['removeEventListener']('error',_0x5c2b63),_0x3ac540['removeEventListener']('abort',_0x5c2b63);},_0x26b042=()=>{_0x45ab91(),_0x51a0bb();},_0x5c2b63=()=>{_0x15718b(_0x3ac540['error']||new DOMException('AbortError','AbortError')),_0x51a0bb();};_0x3ac540['addEventListener']('complete',_0x26b042),_0x3ac540['addEventListener']('error',_0x5c2b63),_0x3ac540['addEventListener']('abort',_0x5c2b63);});ui['set'](_0x3ac540,_0x601c64);}let di={'get'(_0x1b6376,_0x3f9965,_0x17c81c){if(_0x1b6376 instanceof IDBTransaction){if(_0x3f9965==='done')return ui['get'](_0x1b6376);if(_0x3f9965==='objectStoreNames')return _0x1b6376['objectStoreNames']||Yr['get'](_0x1b6376);if(_0x3f9965==='store')return _0x17c81c['objectStoreNames'][0x1]?void 0x0:_0x17c81c['objectStore'](_0x17c81c['objectStoreNames'][0x0]);}return _e(_0x1b6376[_0x3f9965]);},'set'(_0x1a83e3,_0x254582,_0x34008a){return _0x1a83e3[_0x254582]=_0x34008a,!0x0;},'has'(_0x1692d3,_0x1a38b5){return _0x1692d3 instanceof IDBTransaction&&(_0x1a38b5==='done'||_0x1a38b5==='store')?!0x0:_0x1a38b5 in _0x1692d3;}};function Uc(_0x259890){di=_0x259890(di);}function Wc(_0x16f863){return _0x16f863===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x446a5d,..._0xdca12){const _0x5ee2b1=_0x16f863['call'](Xn(this),_0x446a5d,..._0xdca12);return Yr['set'](_0x5ee2b1,_0x446a5d['sort']?_0x446a5d['sort']():[_0x446a5d]),_e(_0x5ee2b1);}:Lc()['includes'](_0x16f863)?function(..._0x21b4cd){return _0x16f863['apply'](Xn(this),_0x21b4cd),_e(Kr['get'](this));}:function(..._0x38179c){return _e(_0x16f863['apply'](Xn(this),_0x38179c));};}function Bc(_0x46d0b2){return typeof _0x46d0b2=='function'?Wc(_0x46d0b2):(_0x46d0b2 instanceof IDBTransaction&&Fc(_0x46d0b2),Dc(_0x46d0b2,Mc())?new Proxy(_0x46d0b2,di):_0x46d0b2);}function _e(_0x36886a){if(_0x36886a instanceof IDBRequest)return xc(_0x36886a);if(Jn['has'](_0x36886a))return Jn['get'](_0x36886a);const _0x15b6b7=Bc(_0x36886a);return _0x15b6b7!==_0x36886a&&(Jn['set'](_0x36886a,_0x15b6b7),Fi['set'](_0x15b6b7,_0x36886a)),_0x15b6b7;}const Xn=_0x43540b=>Fi['get'](_0x43540b);function Vc(_0x576c6b,_0x385507,{blocked:_0x36a4ed,upgrade:_0x48e10f,blocking:_0x3d0b7e,terminated:_0x2de205}={}){const _0x222529=indexedDB['open'](_0x576c6b,_0x385507),_0x1ac3d0=_e(_0x222529);return _0x48e10f&&_0x222529['addEventListener']('upgradeneeded',_0x162ac6=>{_0x48e10f(_e(_0x222529['result']),_0x162ac6['oldVersion'],_0x162ac6['newVersion'],_e(_0x222529['transaction']),_0x162ac6);}),_0x36a4ed&&_0x222529['addEventListener']('blocked',_0x2e219e=>_0x36a4ed(_0x2e219e['oldVersion'],_0x2e219e['newVersion'],_0x2e219e)),_0x1ac3d0['then'](_0x375500=>{_0x2de205&&_0x375500['addEventListener']('close',()=>_0x2de205()),_0x3d0b7e&&_0x375500['addEventListener']('versionchange',_0xadebd8=>_0x3d0b7e(_0xadebd8['oldVersion'],_0xadebd8['newVersion'],_0xadebd8));})['catch'](()=>{}),_0x1ac3d0;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x58f547,_0x209bd1){if(!(_0x58f547 instanceof IDBDatabase&&!(_0x209bd1 in _0x58f547)&&typeof _0x209bd1=='string'))return;if(Zn['get'](_0x209bd1))return Zn['get'](_0x209bd1);const _0x143c18=_0x209bd1['replace'](/FromIndex$/,''),_0x51d721=_0x209bd1!==_0x143c18,_0x2de523=$c['includes'](_0x143c18);if(!(_0x143c18 in(_0x51d721?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2de523||Hc['includes'](_0x143c18)))return;const _0xa19614=async function(_0x2137bb,..._0x5785f9){const _0x2ff274=this['transaction'](_0x2137bb,_0x2de523?'readwrite':'readonly');let _0x425958=_0x2ff274['store'];return _0x51d721&&(_0x425958=_0x425958['index'](_0x5785f9['shift']())),(await Promise['all']([_0x425958[_0x143c18](..._0x5785f9),_0x2de523&&_0x2ff274['done']]))[0x0];};return Zn['set'](_0x209bd1,_0xa19614),_0xa19614;}Uc(_0x52277d=>({..._0x52277d,'get':(_0x855127,_0x4d1afc,_0x185252)=>Os(_0x855127,_0x4d1afc)||_0x52277d['get'](_0x855127,_0x4d1afc,_0x185252),'has':(_0x173d3a,_0x3d8e79)=>!!Os(_0x173d3a,_0x3d8e79)||_0x52277d['has'](_0x173d3a,_0x3d8e79)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x2fc535){this['container']=_0x2fc535;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x55c176=>{if(qc(_0x55c176)){const _0x5737b5=_0x55c176['getImmediate']();return _0x5737b5['library']+'/'+_0x5737b5['version'];}else return null;})['filter'](_0x2de0d8=>_0x2de0d8)['join']('\x20');}}function qc(_0x8118bd){const _0x429f1a=_0x8118bd['getComponent']();return(_0x429f1a==null?void 0x0:_0x429f1a['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x6ba345,_0x511da5){try{_0x6ba345['container']['addComponent'](_0x511da5);}catch(_0x4d36bd){re['debug']('Component\x20'+_0x511da5['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x6ba345['name'],_0x4d36bd);}}function et(_0x4456df){const _0x119293=_0x4456df['name'];if(gi['has'](_0x119293))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x119293+'.'),!0x1;gi['set'](_0x119293,_0x4456df);for(const _0x4a0c25 of Le['values']())Ms(_0x4a0c25,_0x4456df);for(const _0x2dca29 of _i['values']())Ms(_0x2dca29,_0x4456df);return!0x0;}function Ui(_0x300017,_0x58f8f2){const _0x2c2d7c=_0x300017['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x2c2d7c&&_0x2c2d7c['triggerHeartbeat'](),_0x300017['container']['getProvider'](_0x58f8f2);}function H(_0x175701){return _0x175701==null?!0x1:_0x175701['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x5b7aa3,_0x20c79c,_0x1026df){this['_isDeleted']=!0x1,this['_options']={..._0x5b7aa3},this['_config']={..._0x20c79c},this['_name']=_0x20c79c['name'],this['_automaticDataCollectionEnabled']=_0x20c79c['automaticDataCollectionEnabled'],this['_container']=_0x1026df,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x281512){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x281512;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x271af8){this['_isDeleted']=_0x271af8;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x5e5428,_0x4a5d24={}){let _0x4a52c3=_0x5e5428;typeof _0x4a5d24!='object'&&(_0x4a5d24={'name':_0x4a5d24});const _0x3dff0f={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x4a5d24},_0x10eb7d=_0x3dff0f['name'];if(typeof _0x10eb7d!='string'||!_0x10eb7d)throw ge['create']('bad-app-name',{'appName':String(_0x10eb7d)});if(_0x4a52c3||(_0x4a52c3=$r()),!_0x4a52c3)throw ge['create']('no-options');const _0x182b3f=Le['get'](_0x10eb7d);if(_0x182b3f){if(De(_0x4a52c3,_0x182b3f['options'])&&De(_0x3dff0f,_0x182b3f['config']))return _0x182b3f;throw ge['create']('duplicate-app',{'appName':_0x10eb7d});}const _0x1fffc9=new Ac(_0x10eb7d);for(const _0x143d25 of gi['values']())_0x1fffc9['addComponent'](_0x143d25);const _0x27cdcf=new Il(_0x4a52c3,_0x3dff0f,_0x1fffc9);return Le['set'](_0x10eb7d,_0x27cdcf),_0x27cdcf;}function Qr(_0x367bee=pi){const _0xf02ef8=Le['get'](_0x367bee);if(!_0xf02ef8&&_0x367bee===pi&&$r())return wl();if(!_0xf02ef8)throw ge['create']('no-app',{'appName':_0x367bee});return _0xf02ef8;}function l_(){return Array['from'](Le['values']());}async function h_(_0x2e272b){let _0x414559=!0x1;const _0xcbb50d=_0x2e272b['name'];Le['has'](_0xcbb50d)?(_0x414559=!0x0,Le['delete'](_0xcbb50d)):_i['has'](_0xcbb50d)&&_0x2e272b['decRefCount']()<=0x0&&(_i['delete'](_0xcbb50d),_0x414559=!0x0),_0x414559&&(await Promise['all'](_0x2e272b['container']['getProviders']()['map'](_0x22bfc6=>_0x22bfc6['delete']())),_0x2e272b['isDeleted']=!0x0);}function me(_0x8d9e76,_0x551007,_0x134d07){let _0x33271c=vl[_0x8d9e76]??_0x8d9e76;_0x134d07&&(_0x33271c+='-'+_0x134d07);const _0x4604ef=_0x33271c['match'](/\s|\//),_0x58a47b=_0x551007['match'](/\s|\//);if(_0x4604ef||_0x58a47b){const _0x59070e=['Unable\x20to\x20register\x20library\x20\x22'+_0x33271c+'\x22\x20with\x20version\x20\x22'+_0x551007+'\x22:'];_0x4604ef&&_0x59070e['push']('library\x20name\x20\x22'+_0x33271c+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4604ef&&_0x58a47b&&_0x59070e['push']('and'),_0x58a47b&&_0x59070e['push']('version\x20name\x20\x22'+_0x551007+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x59070e['join']('\x20'));return;}et(new Me(_0x33271c+'-version',()=>({'library':_0x33271c,'version':_0x551007}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0xb3a393,_0x468447)=>{switch(_0x468447){case 0x0:try{_0xb3a393['createObjectStore'](Rt);}catch(_0x549768){console['warn'](_0x549768);}}}})['catch'](_0x315ca7=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x315ca7['message']});})),ei;}async function Sl(_0x1daaef){try{const _0x2d8fef=(await Jr())['transaction'](Rt),_0x274220=await _0x2d8fef['objectStore'](Rt)['get'](Xr(_0x1daaef));return await _0x2d8fef['done'],_0x274220;}catch(_0xd659d4){if(_0xd659d4 instanceof Se)re['warn'](_0xd659d4['message']);else{const _0x40af18=ge['create']('idb-get',{'originalErrorMessage':_0xd659d4==null?void 0x0:_0xd659d4['message']});re['warn'](_0x40af18['message']);}}}async function Ls(_0x5668a5,_0x5c1461){try{const _0x5d0f22=(await Jr())['transaction'](Rt,'readwrite');await _0x5d0f22['objectStore'](Rt)['put'](_0x5c1461,Xr(_0x5668a5)),await _0x5d0f22['done'];}catch(_0x5258ac){if(_0x5258ac instanceof Se)re['warn'](_0x5258ac['message']);else{const _0x486efd=ge['create']('idb-set',{'originalErrorMessage':_0x5258ac==null?void 0x0:_0x5258ac['message']});re['warn'](_0x486efd['message']);}}}function Xr(_0x4dc946){return _0x4dc946['name']+'!'+_0x4dc946['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x317d8b){this['container']=_0x317d8b,this['_heartbeatsCache']=null;const _0x5ce92a=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x5ce92a),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x283b89=>(this['_heartbeatsCache']=_0x283b89,_0x283b89));}async['triggerHeartbeat'](){var _0x33d875,_0xeb9a15;try{const _0x3f45a6=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x4936ca=xs();if(((_0x33d875=this['_heartbeatsCache'])==null?void 0x0:_0x33d875['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0xeb9a15=this['_heartbeatsCache'])==null?void 0x0:_0xeb9a15['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x4936ca||this['_heartbeatsCache']['heartbeats']['some'](_0x3a6d5c=>_0x3a6d5c['date']===_0x4936ca))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x4936ca,'agent':_0x3f45a6}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x35967b=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x35967b,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4d35cf){re['warn'](_0x4d35cf);}}async['getHeartbeatsHeader'](){var _0x3721ea;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3721ea=this['_heartbeatsCache'])==null?void 0x0:_0x3721ea['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x37430b=xs(),{heartbeatsToSend:_0x50323d,unsentEntries:_0x51d138}=kl(this['_heartbeatsCache']['heartbeats']),_0x5031d8=an(JSON['stringify']({'version':0x2,'heartbeats':_0x50323d}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x37430b,_0x51d138['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x51d138,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5031d8;}catch(_0x39b457){return re['warn'](_0x39b457),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x3389fe,_0x5362b2=bl){const _0x539902=[];let _0x578dfc=_0x3389fe['slice']();for(const _0x19d474 of _0x3389fe){const _0x2e49c8=_0x539902['find'](_0x5ce49d=>_0x5ce49d['agent']===_0x19d474['agent']);if(_0x2e49c8){if(_0x2e49c8['dates']['push'](_0x19d474['date']),Fs(_0x539902)>_0x5362b2){_0x2e49c8['dates']['pop']();break;}}else{if(_0x539902['push']({'agent':_0x19d474['agent'],'dates':[_0x19d474['date']]}),Fs(_0x539902)>_0x5362b2){_0x539902['pop']();break;}}_0x578dfc=_0x578dfc['slice'](0x1);}return{'heartbeatsToSend':_0x539902,'unsentEntries':_0x578dfc};}class Nl{constructor(_0x35bf67){this['app']=_0x35bf67,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x3728a0=await Sl(this['app']);return _0x3728a0!=null&&_0x3728a0['heartbeats']?_0x3728a0:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x583cc0){if(await this['_canUseIndexedDBPromise']){const _0x8a70c0=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x583cc0['lastSentHeartbeatDate']??_0x8a70c0['lastSentHeartbeatDate'],'heartbeats':_0x583cc0['heartbeats']});}else return;}async['add'](_0xe731db){if(await this['_canUseIndexedDBPromise']){const _0x3f9c83=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0xe731db['lastSentHeartbeatDate']??_0x3f9c83['lastSentHeartbeatDate'],'heartbeats':[..._0x3f9c83['heartbeats'],..._0xe731db['heartbeats']]});}else return;}}function Fs(_0x404a33){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x404a33}))['length'];}function Pl(_0x249b36){if(_0x249b36['length']===0x0)return-0x1;let _0xd40f2d=0x0,_0x1b54b9=_0x249b36[0x0]['date'];for(let _0x8a373c=0x1;_0x8a373c<_0x249b36['length'];_0x8a373c++)_0x249b36[_0x8a373c]['date']<_0x1b54b9&&(_0x1b54b9=_0x249b36[_0x8a373c]['date'],_0xd40f2d=_0x8a373c);return _0xd40f2d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x406122){et(new Me('platform-logger',_0x1c9eec=>new Gc(_0x1c9eec),'PRIVATE')),et(new Me('heartbeat',_0x134b05=>new Al(_0x134b05),'PRIVATE')),me(fi,Ds,_0x406122),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x1cbcad){Zr=_0x1cbcad;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x345fd9){this['domStorage_']=_0x345fd9,this['prefix_']='firebase:';}['set'](_0x444446,_0x4001ef){_0x4001ef==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x444446)):this['domStorage_']['setItem'](this['prefixedName_'](_0x444446),O(_0x4001ef));}['get'](_0x21a1f1){const _0x29a383=this['domStorage_']['getItem'](this['prefixedName_'](_0x21a1f1));return _0x29a383==null?null:bt(_0x29a383);}['remove'](_0x498726){this['domStorage_']['removeItem'](this['prefixedName_'](_0x498726));}['prefixedName_'](_0x4f4588){return this['prefix_']+_0x4f4588;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x36bc0e,_0x13ddde){_0x13ddde==null?delete this['cache_'][_0x36bc0e]:this['cache_'][_0x36bc0e]=_0x13ddde;}['get'](_0x482afc){return Y(this['cache_'],_0x482afc)?this['cache_'][_0x482afc]:null;}['remove'](_0x4aad4a){delete this['cache_'][_0x4aad4a];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x294dfc){try{if(typeof window<'u'&&typeof window[_0x294dfc]<'u'){const _0x4d054a=window[_0x294dfc];return _0x4d054a['setItem']('firebase:sentinel','cache'),_0x4d054a['removeItem']('firebase:sentinel'),new xl(_0x4d054a);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x532df2=0x1;return function(){return _0x532df2++;};}()),no=function(_0xcae056){const _0x2c36f3=Tc(_0xcae056),_0x196d7d=new Ec();_0x196d7d['update'](_0x2c36f3);const _0x25e7c4=_0x196d7d['digest']();return Di['encodeByteArray'](_0x25e7c4);},Bt=function(..._0x839981){let _0x19f79b='';for(let _0x274f39=0x0;_0x274f39<_0x839981['length'];_0x274f39++){const _0x262c58=_0x839981[_0x274f39];Array['isArray'](_0x262c58)||_0x262c58&&typeof _0x262c58=='object'&&typeof _0x262c58['length']=='number'?_0x19f79b+=Bt['apply'](null,_0x262c58):typeof _0x262c58=='object'?_0x19f79b+=O(_0x262c58):_0x19f79b+=_0x262c58,_0x19f79b+='\x20';}return _0x19f79b;};let Et=null,Vs=!0x0;const Wl=function(_0x4ebcb4,_0x5aca3a){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x25adad){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x1446bd=Bt['apply'](null,_0x25adad);Et(_0x1446bd);}},Vt=function(_0x28db72){return function(..._0x55f627){L(_0x28db72,..._0x55f627);};},mi=function(..._0xf5c86e){const _0x1950de='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0xf5c86e);Qe['error'](_0x1950de);},oe=function(..._0x45c568){const _0x1fd0e6='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x45c568);throw Qe['error'](_0x1fd0e6),new Error(_0x1fd0e6);},U=function(..._0x347bcf){const _0x2436ef='FIREBASE\x20WARNING:\x20'+Bt(..._0x347bcf);Qe['warn'](_0x2436ef);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x377295){return typeof _0x377295=='number'&&(_0x377295!==_0x377295||_0x377295===Number['POSITIVE_INFINITY']||_0x377295===Number['NEGATIVE_INFINITY']);},Vl=function(_0x550bf4){if(document['readyState']==='complete')_0x550bf4();else{let _0x81054f=!0x1;const _0x57a5d2=function(){if(!document['body']){setTimeout(_0x57a5d2,Math['floor'](0xa));return;}_0x81054f||(_0x81054f=!0x0,_0x550bf4());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x57a5d2,!0x1),window['addEventListener']('load',_0x57a5d2,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x57a5d2();}),window['attachEvent']('onload',_0x57a5d2));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x3db7ed,_0x2684c9){if(_0x3db7ed===_0x2684c9)return 0x0;if(_0x3db7ed===xe||_0x2684c9===Ie)return-0x1;if(_0x2684c9===xe||_0x3db7ed===Ie)return 0x1;{const _0x3e4e56=Hs(_0x3db7ed),_0x5cad2c=Hs(_0x2684c9);return _0x3e4e56!==null?_0x5cad2c!==null?_0x3e4e56-_0x5cad2c===0x0?_0x3db7ed['length']-_0x2684c9['length']:_0x3e4e56-_0x5cad2c:-0x1:_0x5cad2c!==null?0x1:_0x3db7ed<_0x2684c9?-0x1:0x1;}},Hl=function(_0x3b7f48,_0x186485){return _0x3b7f48===_0x186485?0x0:_0x3b7f48<_0x186485?-0x1:0x1;},pt=function(_0x74cfce,_0x2f2f50){if(_0x2f2f50&&_0x74cfce in _0x2f2f50)return _0x2f2f50[_0x74cfce];throw new Error('Missing\x20required\x20key\x20('+_0x74cfce+')\x20in\x20object:\x20'+O(_0x2f2f50));},Bi=function(_0x273dcd){if(typeof _0x273dcd!='object'||_0x273dcd===null)return O(_0x273dcd);const _0x1202ce=[];for(const _0x5ace03 in _0x273dcd)_0x1202ce['push'](_0x5ace03);_0x1202ce['sort']();let _0x3a3aa1='{';for(let _0x3354b4=0x0;_0x3354b4<_0x1202ce['length'];_0x3354b4++)_0x3354b4!==0x0&&(_0x3a3aa1+=','),_0x3a3aa1+=O(_0x1202ce[_0x3354b4]),_0x3a3aa1+=':',_0x3a3aa1+=Bi(_0x273dcd[_0x1202ce[_0x3354b4]]);return _0x3a3aa1+='}',_0x3a3aa1;},io=function(_0x52f27f,_0x46ea2d){const _0x1eb9fc=_0x52f27f['length'];if(_0x1eb9fc<=_0x46ea2d)return[_0x52f27f];const _0x208734=[];for(let _0x3fb591=0x0;_0x3fb591<_0x1eb9fc;_0x3fb591+=_0x46ea2d)_0x3fb591+_0x46ea2d>_0x1eb9fc?_0x208734['push'](_0x52f27f['substring'](_0x3fb591,_0x1eb9fc)):_0x208734['push'](_0x52f27f['substring'](_0x3fb591,_0x3fb591+_0x46ea2d));return _0x208734;};function x(_0x4e36aa,_0x3724d5){for(const _0x22c216 in _0x4e36aa)_0x4e36aa['hasOwnProperty'](_0x22c216)&&_0x3724d5(_0x22c216,_0x4e36aa[_0x22c216]);}const so=function(_0x4b2bd8){f(!Wi(_0x4b2bd8),'Invalid\x20JSON\x20number');const _0x28f0c5=0xb,_0x412647=0x34,_0x447114=(0x1<<_0x28f0c5-0x1)-0x1;let _0xdf5b3b,_0x320eb0,_0x5c90ed,_0x11defb,_0x5102af;_0x4b2bd8===0x0?(_0x320eb0=0x0,_0x5c90ed=0x0,_0xdf5b3b=0x1/_0x4b2bd8===-0x1/0x0?0x1:0x0):(_0xdf5b3b=_0x4b2bd8<0x0,_0x4b2bd8=Math['abs'](_0x4b2bd8),_0x4b2bd8>=Math['pow'](0x2,0x1-_0x447114)?(_0x11defb=Math['min'](Math['floor'](Math['log'](_0x4b2bd8)/Math['LN2']),_0x447114),_0x320eb0=_0x11defb+_0x447114,_0x5c90ed=Math['round'](_0x4b2bd8*Math['pow'](0x2,_0x412647-_0x11defb)-Math['pow'](0x2,_0x412647))):(_0x320eb0=0x0,_0x5c90ed=Math['round'](_0x4b2bd8/Math['pow'](0x2,0x1-_0x447114-_0x412647))));const _0x151c3a=[];for(_0x5102af=_0x412647;_0x5102af;_0x5102af-=0x1)_0x151c3a['push'](_0x5c90ed%0x2?0x1:0x0),_0x5c90ed=Math['floor'](_0x5c90ed/0x2);for(_0x5102af=_0x28f0c5;_0x5102af;_0x5102af-=0x1)_0x151c3a['push'](_0x320eb0%0x2?0x1:0x0),_0x320eb0=Math['floor'](_0x320eb0/0x2);_0x151c3a['push'](_0xdf5b3b?0x1:0x0),_0x151c3a['reverse']();const _0x119b2f=_0x151c3a['join']('');let _0x5a7dd6='';for(_0x5102af=0x0;_0x5102af<0x40;_0x5102af+=0x8){let _0xea0570=parseInt(_0x119b2f['substr'](_0x5102af,0x8),0x2)['toString'](0x10);_0xea0570['length']===0x1&&(_0xea0570='0'+_0xea0570),_0x5a7dd6=_0x5a7dd6+_0xea0570;}return _0x5a7dd6['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x530dd9,_0x47e2c4){let _0x2944c9='Unknown\x20Error';_0x530dd9==='too_big'?_0x2944c9='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x530dd9==='permission_denied'?_0x2944c9='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x530dd9==='unavailable'&&(_0x2944c9='The\x20service\x20is\x20unavailable');const _0x30dd80=new Error(_0x530dd9+'\x20at\x20'+_0x47e2c4['_path']['toString']()+':\x20'+_0x2944c9);return _0x30dd80['code']=_0x530dd9['toUpperCase'](),_0x30dd80;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x44643f){if(zl['test'](_0x44643f)){const _0x6307=Number(_0x44643f);if(_0x6307>=jl&&_0x6307<=Kl)return _0x6307;}return null;},lt=function(_0x3cbac9){try{_0x3cbac9();}catch(_0x980a0f){setTimeout(()=>{const _0x23c885=_0x980a0f['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x23c885),_0x980a0f;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x433314,_0x188bec){const _0x3dbab3=setTimeout(_0x433314,_0x188bec);return typeof _0x3dbab3=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3dbab3):typeof _0x3dbab3=='object'&&_0x3dbab3['unref']&&_0x3dbab3['unref'](),_0x3dbab3;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x173c46,_0x3dc929){this['appCheckProvider']=_0x3dc929,this['appName']=_0x173c46['name'],H(_0x173c46)&&_0x173c46['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x173c46['settings']['appCheckToken']),this['appCheck']=_0x3dc929==null?void 0x0:_0x3dc929['getImmediate']({'optional':!0x0}),this['appCheck']||_0x3dc929==null||_0x3dc929['get']()['then'](_0x2c8b7a=>this['appCheck']=_0x2c8b7a);}['getToken'](_0x246f70){if(this['serverAppAppCheckToken']){if(_0x246f70)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x246f70):new Promise((_0x559a62,_0x280971)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x246f70)['then'](_0x559a62,_0x280971):_0x559a62(null);},0x0);});}['addTokenChangeListener'](_0x4dfcad){var _0x4d573e;(_0x4d573e=this['appCheckProvider'])==null||_0x4d573e['get']()['then'](_0x498711=>_0x498711['addTokenListener'](_0x4dfcad));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0xcb368c,_0x4350b5,_0x52224e){this['appName_']=_0xcb368c,this['firebaseOptions_']=_0x4350b5,this['authProvider_']=_0x52224e,this['auth_']=null,this['auth_']=_0x52224e['getImmediate']({'optional':!0x0}),this['auth_']||_0x52224e['onInit'](_0x338310=>this['auth_']=_0x338310);}['getToken'](_0x4ba09c){return this['auth_']?this['auth_']['getToken'](_0x4ba09c)['catch'](_0x443f59=>_0x443f59&&_0x443f59['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x443f59)):new Promise((_0x23559b,_0x516d6a)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4ba09c)['then'](_0x23559b,_0x516d6a):_0x23559b(null);},0x0);});}['addTokenChangeListener'](_0x3d93bd){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3d93bd):this['authProvider_']['get']()['then'](_0x5087e2=>_0x5087e2['addAuthTokenListener'](_0x3d93bd));}['removeTokenChangeListener'](_0x4dcbba){this['authProvider_']['get']()['then'](_0x506381=>_0x506381['removeAuthTokenListener'](_0x4dcbba));}['notifyForInvalidToken'](){let _0x3467a9='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3467a9+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3467a9+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3467a9+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3467a9);}}class tn{constructor(_0xc89bbe){this['accessToken']=_0xc89bbe;}['getToken'](_0x39b753){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x1cd677){_0x1cd677(this['accessToken']);}['removeTokenChangeListener'](_0x192336){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x52ee70,_0x423f65,_0x4da0ed,_0x5b19ea,_0x43bd6b=!0x1,_0x143ffa='',_0x2971b5=!0x1,_0x352255=!0x1,_0x4c9ea0=null){this['secure']=_0x423f65,this['namespace']=_0x4da0ed,this['webSocketOnly']=_0x5b19ea,this['nodeAdmin']=_0x43bd6b,this['persistenceKey']=_0x143ffa,this['includeNamespaceInQueryParams']=_0x2971b5,this['isUsingEmulator']=_0x352255,this['emulatorOptions']=_0x4c9ea0,this['_host']=_0x52ee70['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x52ee70)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x16c91a){_0x16c91a!==this['internalHost']&&(this['internalHost']=_0x16c91a,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x264888=this['toURLString']();return this['persistenceKey']&&(_0x264888+='<'+this['persistenceKey']+'>'),_0x264888;}['toURLString'](){const _0x2d9b3a=this['secure']?'https://':'http://',_0x264355=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2d9b3a+this['host']+'/'+_0x264355;}}function Xl(_0x5ceae5){return _0x5ceae5['host']!==_0x5ceae5['internalHost']||_0x5ceae5['isCustomHost']()||_0x5ceae5['includeNamespaceInQueryParams'];}function go(_0x55314a,_0x276a65,_0x24f2e9){f(typeof _0x276a65=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x24f2e9=='object','typeof\x20params\x20must\x20==\x20object');let _0x34cbf4;if(_0x276a65===fo)_0x34cbf4=(_0x55314a['secure']?'wss://':'ws://')+_0x55314a['internalHost']+'/.ws?';else{if(_0x276a65===po)_0x34cbf4=(_0x55314a['secure']?'https://':'http://')+_0x55314a['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x276a65);}Xl(_0x55314a)&&(_0x24f2e9['ns']=_0x55314a['namespace']);const _0x3ed210=[];return x(_0x24f2e9,(_0x1ae34b,_0x4cdbf8)=>{_0x3ed210['push'](_0x1ae34b+'='+_0x4cdbf8);}),_0x34cbf4+_0x3ed210['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x355d5e,_0x56660e=0x1){Y(this['counters_'],_0x355d5e)||(this['counters_'][_0x355d5e]=0x0),this['counters_'][_0x355d5e]+=_0x56660e;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0xfb5254){const _0x2d2568=_0xfb5254['toString']();return ti[_0x2d2568]||(ti[_0x2d2568]=new Zl()),ti[_0x2d2568];}function eh(_0x2938cb,_0x8f0ae8){const _0x2fc7df=_0x2938cb['toString']();return ni[_0x2fc7df]||(ni[_0x2fc7df]=_0x8f0ae8()),ni[_0x2fc7df];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x406c06){this['onMessage_']=_0x406c06,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x32e493,_0x21884f){this['closeAfterResponse']=_0x32e493,this['onClose']=_0x21884f,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x1e010b,_0x3d1c57){for(this['pendingResponses'][_0x1e010b]=_0x3d1c57;this['pendingResponses'][this['currentResponseNum']];){const _0x546f94=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xf75a91=0x0;_0xf75a91<_0x546f94['length'];++_0xf75a91)_0x546f94[_0xf75a91]&&lt(()=>{this['onMessage_'](_0x546f94[_0xf75a91]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x308542,_0x5317fd,_0x305a95,_0x5a465e,_0x23780d,_0x43de41,_0x4b5ab5){this['connId']=_0x308542,this['repoInfo']=_0x5317fd,this['applicationId']=_0x305a95,this['appCheckToken']=_0x5a465e,this['authToken']=_0x23780d,this['transportSessionId']=_0x43de41,this['lastSessionId']=_0x4b5ab5,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x308542),this['stats_']=Hi(_0x5317fd),this['urlFn']=_0xe4ecb9=>(this['appCheckToken']&&(_0xe4ecb9[yi]=this['appCheckToken']),go(_0x5317fd,po,_0xe4ecb9));}['open'](_0x29420f,_0x55e56a){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x55e56a,this['myPacketOrderer']=new th(_0x29420f),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x28df43)=>{const [_0x2bcb0a,_0x124462,_0x271638,_0x6a7a50,_0x3a1166]=_0x28df43;if(this['incrementIncomingBytes_'](_0x28df43),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2bcb0a===$s)this['id']=_0x124462,this['password']=_0x271638;else{if(_0x2bcb0a===nh)_0x124462?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x124462,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2bcb0a);}}},(..._0x106d33)=>{const [_0x51b571,_0x36a33e]=_0x106d33;this['incrementIncomingBytes_'](_0x106d33),this['myPacketOrderer']['handleResponse'](_0x51b571,_0x36a33e);},()=>{this['onClosed_']();},this['urlFn']);const _0x60ae2c={};_0x60ae2c[$s]='t',_0x60ae2c[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x60ae2c[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x60ae2c[ro]=Vi,this['transportSessionId']&&(_0x60ae2c[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x60ae2c[ho]=this['lastSessionId']),this['applicationId']&&(_0x60ae2c[uo]=this['applicationId']),this['appCheckToken']&&(_0x60ae2c[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x60ae2c[ao]=co);const _0x11a56e=this['urlFn'](_0x60ae2c);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x11a56e),this['scriptTagHolder']['addTag'](_0x11a56e,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2c7dc1){const _0xff6b39=O(_0x2c7dc1);this['bytesSent']+=_0xff6b39['length'],this['stats_']['incrementCounter']('bytes_sent',_0xff6b39['length']);const _0x580b3b=Br(_0xff6b39),_0x22f45d=io(_0x580b3b,hh);for(let _0x4e2c44=0x0;_0x4e2c44<_0x22f45d['length'];_0x4e2c44++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x22f45d['length'],_0x22f45d[_0x4e2c44]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x158715,_0x5ceafb){this['myDisconnFrame']=document['createElement']('iframe');const _0x16fe99={};_0x16fe99[lh]='t',_0x16fe99[mo]=_0x158715,_0x16fe99[yo]=_0x5ceafb,this['myDisconnFrame']['src']=this['urlFn'](_0x16fe99),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x53fe58){const _0x320b5a=O(_0x53fe58)['length'];this['bytesReceived']+=_0x320b5a,this['stats_']['incrementCounter']('bytes_received',_0x320b5a);}}class $i{constructor(_0x1fddfe,_0x373e4c,_0x2c2408,_0x4f69fc){this['onDisconnect']=_0x2c2408,this['urlFn']=_0x4f69fc,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x1fddfe,window[sh+this['uniqueCallbackIdentifier']]=_0x373e4c,this['myIFrame']=$i['createIFrame_']();let _0x526eba='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x526eba='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x32f90b='<html><body>'+_0x526eba+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x32f90b),this['myIFrame']['doc']['close']();}catch(_0x49bb52){L('frame\x20writing\x20exception'),_0x49bb52['stack']&&L(_0x49bb52['stack']),L(_0x49bb52);}}}static['createIFrame_'](){const _0x1d5cbd=document['createElement']('iframe');if(_0x1d5cbd['style']['display']='none',document['body']){document['body']['appendChild'](_0x1d5cbd);try{_0x1d5cbd['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x4608bb=document['domain'];_0x1d5cbd['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x4608bb+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1d5cbd['contentDocument']?_0x1d5cbd['doc']=_0x1d5cbd['contentDocument']:_0x1d5cbd['contentWindow']?_0x1d5cbd['doc']=_0x1d5cbd['contentWindow']['document']:_0x1d5cbd['document']&&(_0x1d5cbd['doc']=_0x1d5cbd['document']),_0x1d5cbd;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1645c8=this['onDisconnect'];_0x1645c8&&(this['onDisconnect']=null,_0x1645c8());}['startLongPoll'](_0x241818,_0x521dfa){for(this['myID']=_0x241818,this['myPW']=_0x521dfa,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1d32ce={};_0x1d32ce[mo]=this['myID'],_0x1d32ce[yo]=this['myPW'],_0x1d32ce[vo]=this['currentSerial'];let _0x48b114=this['urlFn'](_0x1d32ce),_0xede1dc='',_0x1ba26f=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0xede1dc['length']<=Eo;){const _0x52bb0e=this['pendingSegs']['shift']();_0xede1dc=_0xede1dc+'&'+oh+_0x1ba26f+'='+_0x52bb0e['seg']+'&'+ah+_0x1ba26f+'='+_0x52bb0e['ts']+'&'+ch+_0x1ba26f+'='+_0x52bb0e['d'],_0x1ba26f++;}return _0x48b114=_0x48b114+_0xede1dc,this['addLongPollTag_'](_0x48b114,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x50800c,_0xb107ed,_0x24b2d8){this['pendingSegs']['push']({'seg':_0x50800c,'ts':_0xb107ed,'d':_0x24b2d8}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x548893,_0x2eb94d){this['outstandingRequests']['add'](_0x2eb94d);const _0xeb367e=()=>{this['outstandingRequests']['delete'](_0x2eb94d),this['newRequest_']();},_0x2cffd6=setTimeout(_0xeb367e,Math['floor'](uh)),_0x50d7de=()=>{clearTimeout(_0x2cffd6),_0xeb367e();};this['addTag'](_0x548893,_0x50d7de);}['addTag'](_0x4b43f5,_0x53f95d){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x165dc4=this['myIFrame']['doc']['createElement']('script');_0x165dc4['type']='text/javascript',_0x165dc4['async']=!0x0,_0x165dc4['src']=_0x4b43f5,_0x165dc4['onload']=_0x165dc4['onreadystatechange']=function(){const _0x1bd5d0=_0x165dc4['readyState'];(!_0x1bd5d0||_0x1bd5d0==='loaded'||_0x1bd5d0==='complete')&&(_0x165dc4['onload']=_0x165dc4['onreadystatechange']=null,_0x165dc4['parentNode']&&_0x165dc4['parentNode']['removeChild'](_0x165dc4),_0x53f95d());},_0x165dc4['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4b43f5),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x165dc4);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x30796d,_0x123684,_0x305a51,_0x2c1d7d,_0x515be7,_0x1433d7,_0x3f2774){this['connId']=_0x30796d,this['applicationId']=_0x305a51,this['appCheckToken']=_0x2c1d7d,this['authToken']=_0x515be7,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x123684),this['connURL']=G['connectionURL_'](_0x123684,_0x1433d7,_0x3f2774,_0x2c1d7d,_0x305a51),this['nodeAdmin']=_0x123684['nodeAdmin'];}static['connectionURL_'](_0x32b325,_0x3c2ee6,_0x391d09,_0x26d011,_0x372d88){const _0x304eb3={};return _0x304eb3[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x304eb3[ao]=co),_0x3c2ee6&&(_0x304eb3[oo]=_0x3c2ee6),_0x391d09&&(_0x304eb3[ho]=_0x391d09),_0x26d011&&(_0x304eb3[yi]=_0x26d011),_0x372d88&&(_0x304eb3[uo]=_0x372d88),go(_0x32b325,fo,_0x304eb3);}['open'](_0x4bc032,_0x37ab4c){this['onDisconnect']=_0x37ab4c,this['onMessage']=_0x4bc032,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x5bbbf3;dc(),this['mySock']=new hn(this['connURL'],[],_0x5bbbf3);}catch(_0xb77664){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x378dd7=_0xb77664['message']||_0xb77664['data'];_0x378dd7&&this['log_'](_0x378dd7),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x32da18=>{this['handleIncomingFrame'](_0x32da18);},this['mySock']['onerror']=_0x3ecbff=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x223882=_0x3ecbff['message']||_0x3ecbff['data'];_0x223882&&this['log_'](_0x223882),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x287848=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4e75ff=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2dac5b=navigator['userAgent']['match'](_0x4e75ff);_0x2dac5b&&_0x2dac5b['length']>0x1&&parseFloat(_0x2dac5b[0x1])<4.4&&(_0x287848=!0x0);}return!_0x287848&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x1df269){if(this['frames']['push'](_0x1df269),this['frames']['length']===this['totalFrames']){const _0x1b7fc8=this['frames']['join']('');this['frames']=null;const _0x4c4c14=bt(_0x1b7fc8);this['onMessage'](_0x4c4c14);}}['handleNewFrameCount_'](_0xb1b814){this['totalFrames']=_0xb1b814,this['frames']=[];}['extractFrameCount_'](_0x31e88b){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x31e88b['length']<=0x6){const _0x3291f7=Number(_0x31e88b);if(!isNaN(_0x3291f7))return this['handleNewFrameCount_'](_0x3291f7),null;}return this['handleNewFrameCount_'](0x1),_0x31e88b;}['handleIncomingFrame'](_0x281a7f){if(this['mySock']===null)return;const _0x40ba9f=_0x281a7f['data'];if(this['bytesReceived']+=_0x40ba9f['length'],this['stats_']['incrementCounter']('bytes_received',_0x40ba9f['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x40ba9f);else{const _0x29bbba=this['extractFrameCount_'](_0x40ba9f);_0x29bbba!==null&&this['appendFrame_'](_0x29bbba);}}['send'](_0xe6d972){this['resetKeepAlive']();const _0x380a22=O(_0xe6d972);this['bytesSent']+=_0x380a22['length'],this['stats_']['incrementCounter']('bytes_sent',_0x380a22['length']);const _0x44396b=io(_0x380a22,fh);_0x44396b['length']>0x1&&this['sendString_'](String(_0x44396b['length']));for(let _0x4ce347=0x0;_0x4ce347<_0x44396b['length'];_0x4ce347++)this['sendString_'](_0x44396b[_0x4ce347]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x3e338f){try{this['mySock']['send'](_0x3e338f);}catch(_0x459a10){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x459a10['message']||_0x459a10['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4e420b){this['initTransports_'](_0x4e420b);}['initTransports_'](_0x5d7eca){const _0x4167a3=G&&G['isAvailable']();let _0x26546d=_0x4167a3&&!G['previouslyFailed']();if(_0x5d7eca['webSocketOnly']&&(_0x4167a3||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x26546d=!0x0),_0x26546d)this['transports_']=[G];else{const _0x5a1f17=this['transports_']=[];for(const _0x3d91ec of At['ALL_TRANSPORTS'])_0x3d91ec&&_0x3d91ec['isAvailable']()&&_0x5a1f17['push'](_0x3d91ec);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x454a45,_0x3eaeb2,_0x218731,_0x1a1d82,_0x31e0d6,_0x30f9a7,_0x1864fc,_0x46986b,_0x2c1da4,_0x1fc806){this['id']=_0x454a45,this['repoInfo_']=_0x3eaeb2,this['applicationId_']=_0x218731,this['appCheckToken_']=_0x1a1d82,this['authToken_']=_0x31e0d6,this['onMessage_']=_0x30f9a7,this['onReady_']=_0x1864fc,this['onDisconnect_']=_0x46986b,this['onKill_']=_0x2c1da4,this['lastSessionId']=_0x1fc806,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x3eaeb2),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x38c29b=this['transportManager_']['initialTransport']();this['conn_']=new _0x38c29b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x38c29b['responsesRequiredToBeHealthy']||0x0;const _0x3a0a5e=this['connReceiver_'](this['conn_']),_0x61ba28=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3a0a5e,_0x61ba28);},Math['floor'](0x0));const _0x4854e7=_0x38c29b['healthyTimeout']||0x0;_0x4854e7>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x4854e7)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5c3b0b){return _0x3cc1ef=>{_0x5c3b0b===this['conn_']?this['onConnectionLost_'](_0x3cc1ef):_0x5c3b0b===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x84c566){return _0x420564=>{this['state_']!==0x2&&(_0x84c566===this['rx_']?this['onPrimaryMessageReceived_'](_0x420564):_0x84c566===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x420564):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3ca0fa){const _0x580e97={'t':'d','d':_0x3ca0fa};this['sendData_'](_0x580e97);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1ea1ae){if(ii in _0x1ea1ae){const _0x4cbdc2=_0x1ea1ae[ii];_0x4cbdc2===js?this['upgradeIfSecondaryHealthy_']():_0x4cbdc2===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4cbdc2===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x11a47a){const _0x1c26f6=pt('t',_0x11a47a),_0x2efe61=pt('d',_0x11a47a);if(_0x1c26f6==='c')this['onSecondaryControl_'](_0x2efe61);else{if(_0x1c26f6==='d')this['pendingDataMessages']['push'](_0x2efe61);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x1c26f6);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x304a28){const _0x445395=pt('t',_0x304a28),_0x20e6dc=pt('d',_0x304a28);_0x445395==='c'?this['onControl_'](_0x20e6dc):_0x445395==='d'&&this['onDataMessage_'](_0x20e6dc);}['onDataMessage_'](_0x905981){this['onPrimaryResponse_'](),this['onMessage_'](_0x905981);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x488e70){const _0x1dacbb=pt(ii,_0x488e70);if(Gs in _0x488e70){const _0x22a297=_0x488e70[Gs];if(_0x1dacbb===Ih){const _0x4611f={..._0x22a297};this['repoInfo_']['isUsingEmulator']&&(_0x4611f['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x4611f);}else{if(_0x1dacbb===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x33f603=0x0;_0x33f603<this['pendingDataMessages']['length'];++_0x33f603)this['onDataMessage_'](this['pendingDataMessages'][_0x33f603]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x1dacbb===vh?this['onConnectionShutdown_'](_0x22a297):_0x1dacbb===qs?this['onReset_'](_0x22a297):_0x1dacbb===Eh?mi('Server\x20Error:\x20'+_0x22a297):_0x1dacbb===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x1dacbb);}}}['onHandshake_'](_0x1cc94b){const _0x2a5492=_0x1cc94b['ts'],_0x4b8fa4=_0x1cc94b['v'],_0x4a6512=_0x1cc94b['h'];this['sessionId']=_0x1cc94b['s'],this['repoInfo_']['host']=_0x4a6512,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2a5492),Vi!==_0x4b8fa4&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x49793b=this['transportManager_']['upgradeTransport']();_0x49793b&&this['startUpgrade_'](_0x49793b);}['startUpgrade_'](_0x1572ec){this['secondaryConn_']=new _0x1572ec(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1572ec['responsesRequiredToBeHealthy']||0x0;const _0x2d3dcb=this['connReceiver_'](this['secondaryConn_']),_0x50c3f7=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x2d3dcb,_0x50c3f7),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x33266a){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x33266a),this['repoInfo_']['host']=_0x33266a,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x796beb,_0x4aec88){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x796beb,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4aec88,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2302f3=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2302f3||this['rx_']===_0x2302f3)&&this['close']();}['onConnectionLost_'](_0x2e2e4c){this['conn_']=null,!_0x2e2e4c&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2c547a){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2c547a),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5b8cd1){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5b8cd1);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x564ab2,_0x2245dc,_0x355934,_0x586401){}['merge'](_0x38d823,_0x4cd7e4,_0x397e38,_0xbef8cc){}['refreshAuthToken'](_0x152bfb){}['refreshAppCheckToken'](_0x1db8f5){}['onDisconnectPut'](_0x48fce8,_0x4e713a,_0x3dc547){}['onDisconnectMerge'](_0x455b60,_0x31aa91,_0x5f19fa){}['onDisconnectCancel'](_0x2f6fab,_0x389eea){}['reportStats'](_0x3ca71f){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x1ee4cd){this['allowedEvents_']=_0x1ee4cd,this['listeners_']={},f(Array['isArray'](_0x1ee4cd)&&_0x1ee4cd['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x144c44,..._0x28d351){if(Array['isArray'](this['listeners_'][_0x144c44])){const _0x18ea09=[...this['listeners_'][_0x144c44]];for(let _0x526eb0=0x0;_0x526eb0<_0x18ea09['length'];_0x526eb0++)_0x18ea09[_0x526eb0]['callback']['apply'](_0x18ea09[_0x526eb0]['context'],_0x28d351);}}['on'](_0x368f71,_0x52f34a,_0xd1aa84){this['validateEventType_'](_0x368f71),this['listeners_'][_0x368f71]=this['listeners_'][_0x368f71]||[],this['listeners_'][_0x368f71]['push']({'callback':_0x52f34a,'context':_0xd1aa84});const _0x382d15=this['getInitialEvent'](_0x368f71);_0x382d15&&_0x52f34a['apply'](_0xd1aa84,_0x382d15);}['off'](_0x1c7817,_0x1c199c,_0x2fee3e){this['validateEventType_'](_0x1c7817);const _0x34f9a0=this['listeners_'][_0x1c7817]||[];for(let _0x308eb1=0x0;_0x308eb1<_0x34f9a0['length'];_0x308eb1++)if(_0x34f9a0[_0x308eb1]['callback']===_0x1c199c&&(!_0x2fee3e||_0x2fee3e===_0x34f9a0[_0x308eb1]['context'])){_0x34f9a0['splice'](_0x308eb1,0x1);return;}}['validateEventType_'](_0x528c16){f(this['allowedEvents_']['find'](_0x47848c=>_0x47848c===_0x528c16),'Unknown\x20event:\x20'+_0x528c16);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x4721d0){return f(_0x4721d0==='online','Unknown\x20event\x20type:\x20'+_0x4721d0),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x2f6934,_0x5b56a5){if(_0x5b56a5===void 0x0){this['pieces_']=_0x2f6934['split']('/');let _0x2aa0ea=0x0;for(let _0x100c4f=0x0;_0x100c4f<this['pieces_']['length'];_0x100c4f++)this['pieces_'][_0x100c4f]['length']>0x0&&(this['pieces_'][_0x2aa0ea]=this['pieces_'][_0x100c4f],_0x2aa0ea++);this['pieces_']['length']=_0x2aa0ea,this['pieceNum_']=0x0;}else this['pieces_']=_0x2f6934,this['pieceNum_']=_0x5b56a5;}['toString'](){let _0x1a6713='';for(let _0x4a755c=this['pieceNum_'];_0x4a755c<this['pieces_']['length'];_0x4a755c++)this['pieces_'][_0x4a755c]!==''&&(_0x1a6713+='/'+this['pieces_'][_0x4a755c]);return _0x1a6713||'/';}}function w(){return new C('');}function y(_0x3e7a4f){return _0x3e7a4f['pieceNum_']>=_0x3e7a4f['pieces_']['length']?null:_0x3e7a4f['pieces_'][_0x3e7a4f['pieceNum_']];}function we(_0x489571){return _0x489571['pieces_']['length']-_0x489571['pieceNum_'];}function b(_0x6e6c29){let _0x57cb5d=_0x6e6c29['pieceNum_'];return _0x57cb5d<_0x6e6c29['pieces_']['length']&&_0x57cb5d++,new C(_0x6e6c29['pieces_'],_0x57cb5d);}function Gi(_0x587179){return _0x587179['pieceNum_']<_0x587179['pieces_']['length']?_0x587179['pieces_'][_0x587179['pieces_']['length']-0x1]:null;}function Ch(_0x1bced5){let _0x134dfd='';for(let _0x156cce=_0x1bced5['pieceNum_'];_0x156cce<_0x1bced5['pieces_']['length'];_0x156cce++)_0x1bced5['pieces_'][_0x156cce]!==''&&(_0x134dfd+='/'+encodeURIComponent(String(_0x1bced5['pieces_'][_0x156cce])));return _0x134dfd||'/';}function kt(_0x42bf40,_0xc13f1d=0x0){return _0x42bf40['pieces_']['slice'](_0x42bf40['pieceNum_']+_0xc13f1d);}function To(_0x1bc7ac){if(_0x1bc7ac['pieceNum_']>=_0x1bc7ac['pieces_']['length'])return null;const _0xdbe136=[];for(let _0x337b65=_0x1bc7ac['pieceNum_'];_0x337b65<_0x1bc7ac['pieces_']['length']-0x1;_0x337b65++)_0xdbe136['push'](_0x1bc7ac['pieces_'][_0x337b65]);return new C(_0xdbe136,0x0);}function A(_0x11c1cd,_0x1659a9){const _0x4e1c2b=[];for(let _0xd950c1=_0x11c1cd['pieceNum_'];_0xd950c1<_0x11c1cd['pieces_']['length'];_0xd950c1++)_0x4e1c2b['push'](_0x11c1cd['pieces_'][_0xd950c1]);if(_0x1659a9 instanceof C){for(let _0x43c8f2=_0x1659a9['pieceNum_'];_0x43c8f2<_0x1659a9['pieces_']['length'];_0x43c8f2++)_0x4e1c2b['push'](_0x1659a9['pieces_'][_0x43c8f2]);}else{const _0x1b38e2=_0x1659a9['split']('/');for(let _0x3f0aa0=0x0;_0x3f0aa0<_0x1b38e2['length'];_0x3f0aa0++)_0x1b38e2[_0x3f0aa0]['length']>0x0&&_0x4e1c2b['push'](_0x1b38e2[_0x3f0aa0]);}return new C(_0x4e1c2b,0x0);}function v(_0x1278a0){return _0x1278a0['pieceNum_']>=_0x1278a0['pieces_']['length'];}function F(_0xb8d95,_0x55d729){const _0x17bf26=y(_0xb8d95),_0x204a78=y(_0x55d729);if(_0x17bf26===null)return _0x55d729;if(_0x17bf26===_0x204a78)return F(b(_0xb8d95),b(_0x55d729));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x55d729+')\x20is\x20not\x20within\x20outerPath\x20('+_0xb8d95+')');}function Th(_0x2b4d81,_0x2aaaea){const _0x3bbe4f=kt(_0x2b4d81,0x0),_0x254a92=kt(_0x2aaaea,0x0);for(let _0x58df19=0x0;_0x58df19<_0x3bbe4f['length']&&_0x58df19<_0x254a92['length'];_0x58df19++){const _0x28a791=He(_0x3bbe4f[_0x58df19],_0x254a92[_0x58df19]);if(_0x28a791!==0x0)return _0x28a791;}return _0x3bbe4f['length']===_0x254a92['length']?0x0:_0x3bbe4f['length']<_0x254a92['length']?-0x1:0x1;}function qi(_0x9541fc,_0x1aa342){if(we(_0x9541fc)!==we(_0x1aa342))return!0x1;for(let _0x24fc0e=_0x9541fc['pieceNum_'],_0x49b738=_0x1aa342['pieceNum_'];_0x24fc0e<=_0x9541fc['pieces_']['length'];_0x24fc0e++,_0x49b738++)if(_0x9541fc['pieces_'][_0x24fc0e]!==_0x1aa342['pieces_'][_0x49b738])return!0x1;return!0x0;}function $(_0x5e993e,_0x1c6479){let _0x3a7a81=_0x5e993e['pieceNum_'],_0x37e99e=_0x1c6479['pieceNum_'];if(we(_0x5e993e)>we(_0x1c6479))return!0x1;for(;_0x3a7a81<_0x5e993e['pieces_']['length'];){if(_0x5e993e['pieces_'][_0x3a7a81]!==_0x1c6479['pieces_'][_0x37e99e])return!0x1;++_0x3a7a81,++_0x37e99e;}return!0x0;}class Sh{constructor(_0x1848b2,_0x12447e){this['errorPrefix_']=_0x12447e,this['parts_']=kt(_0x1848b2,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1b8c74=0x0;_0x1b8c74<this['parts_']['length'];_0x1b8c74++)this['byteLength_']+=Pn(this['parts_'][_0x1b8c74]);So(this);}}function bh(_0x369608,_0x238a57){_0x369608['parts_']['length']>0x0&&(_0x369608['byteLength_']+=0x1),_0x369608['parts_']['push'](_0x238a57),_0x369608['byteLength_']+=Pn(_0x238a57),So(_0x369608);}function Rh(_0x4030b5){const _0x3f625f=_0x4030b5['parts_']['pop']();_0x4030b5['byteLength_']-=Pn(_0x3f625f),_0x4030b5['parts_']['length']>0x0&&(_0x4030b5['byteLength_']-=0x1);}function So(_0x4e3d28){if(_0x4e3d28['byteLength_']>Js)throw new Error(_0x4e3d28['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x4e3d28['byteLength_']+').');if(_0x4e3d28['parts_']['length']>Qs)throw new Error(_0x4e3d28['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x4e3d28));}function Ne(_0x32fb1e){return _0x32fb1e['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x32fb1e['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x266d70,_0x5111d5;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5111d5='visibilitychange',_0x266d70='hidden'):typeof document['mozHidden']<'u'?(_0x5111d5='mozvisibilitychange',_0x266d70='mozHidden'):typeof document['msHidden']<'u'?(_0x5111d5='msvisibilitychange',_0x266d70='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5111d5='webkitvisibilitychange',_0x266d70='webkitHidden')),this['visible_']=!0x0,_0x5111d5&&document['addEventListener'](_0x5111d5,()=>{const _0x4323db=!document[_0x266d70];_0x4323db!==this['visible_']&&(this['visible_']=_0x4323db,this['trigger']('visible',_0x4323db));},!0x1);}['getInitialEvent'](_0x163ddc){return f(_0x163ddc==='visible','Unknown\x20event\x20type:\x20'+_0x163ddc),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x29c94a,_0xe2a797,_0x15a593,_0x532ef4,_0x357d6c,_0x27e7b5,_0x1b43f1,_0xb4a5fe){if(super(),this['repoInfo_']=_0x29c94a,this['applicationId_']=_0xe2a797,this['onDataUpdate_']=_0x15a593,this['onConnectStatus_']=_0x532ef4,this['onServerInfoUpdate_']=_0x357d6c,this['authTokenProvider_']=_0x27e7b5,this['appCheckTokenProvider_']=_0x1b43f1,this['authOverride_']=_0xb4a5fe,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xb4a5fe)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x29c94a['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x2e6bdd,_0xc0cb2d,_0x46b10c){const _0x4df445=++this['requestNumber_'],_0x40d34f={'r':_0x4df445,'a':_0x2e6bdd,'b':_0xc0cb2d};this['log_'](O(_0x40d34f)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x40d34f),_0x46b10c&&(this['requestCBHash_'][_0x4df445]=_0x46b10c);}['get'](_0x4c5632){this['initConnection_']();const _0xee651c=new Ve(),_0x24aa40={'action':'g','request':{'p':_0x4c5632['_path']['toString'](),'q':_0x4c5632['_queryObject']},'onComplete':_0x38a9c8=>{const _0x1e3981=_0x38a9c8['d'];_0x38a9c8['s']==='ok'?_0xee651c['resolve'](_0x1e3981):_0xee651c['reject'](_0x1e3981);}};this['outstandingGets_']['push'](_0x24aa40),this['outstandingGetCount_']++;const _0x447b6b=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x447b6b),_0xee651c['promise'];}['listen'](_0x1b95cf,_0x199885,_0x55bc59,_0x551726){this['initConnection_']();const _0x546dae=_0x1b95cf['_queryIdentifier'],_0x2f4163=_0x1b95cf['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2f4163+'\x20'+_0x546dae),this['listens']['has'](_0x2f4163)||this['listens']['set'](_0x2f4163,new Map()),f(_0x1b95cf['_queryParams']['isDefault']()||!_0x1b95cf['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2f4163)['has'](_0x546dae),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x155689={'onComplete':_0x551726,'hashFn':_0x199885,'query':_0x1b95cf,'tag':_0x55bc59};this['listens']['get'](_0x2f4163)['set'](_0x546dae,_0x155689),this['connected_']&&this['sendListen_'](_0x155689);}['sendGet_'](_0x4cfdc2){const _0x228d4d=this['outstandingGets_'][_0x4cfdc2];this['sendRequest']('g',_0x228d4d['request'],_0x562e1b=>{delete this['outstandingGets_'][_0x4cfdc2],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x228d4d['onComplete']&&_0x228d4d['onComplete'](_0x562e1b);});}['sendListen_'](_0x3e5b11){const _0x4c9068=_0x3e5b11['query'],_0x396d46=_0x4c9068['_path']['toString'](),_0x76a678=_0x4c9068['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x396d46+'\x20for\x20'+_0x76a678);const _0x13ecce={'p':_0x396d46},_0xd4ea2d='q';_0x3e5b11['tag']&&(_0x13ecce['q']=_0x4c9068['_queryObject'],_0x13ecce['t']=_0x3e5b11['tag']),_0x13ecce['h']=_0x3e5b11['hashFn'](),this['sendRequest'](_0xd4ea2d,_0x13ecce,_0x506d88=>{const _0x489929=_0x506d88['d'],_0x25fa51=_0x506d88['s'];ie['warnOnListenWarnings_'](_0x489929,_0x4c9068),(this['listens']['get'](_0x396d46)&&this['listens']['get'](_0x396d46)['get'](_0x76a678))===_0x3e5b11&&(this['log_']('listen\x20response',_0x506d88),_0x25fa51!=='ok'&&this['removeListen_'](_0x396d46,_0x76a678),_0x3e5b11['onComplete']&&_0x3e5b11['onComplete'](_0x25fa51,_0x489929));});}static['warnOnListenWarnings_'](_0x12a502,_0x280565){if(_0x12a502&&typeof _0x12a502=='object'&&Y(_0x12a502,'w')){const _0x30e6b2=Oe(_0x12a502,'w');if(Array['isArray'](_0x30e6b2)&&~_0x30e6b2['indexOf']('no_index')){const _0x10db25='\x22.indexOn\x22:\x20\x22'+_0x280565['_queryParams']['getIndex']()['toString']()+'\x22',_0x23e6e8=_0x280565['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x10db25+'\x20at\x20'+_0x23e6e8+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1254d5){this['authToken_']=_0x1254d5,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1254d5);}['reduceReconnectDelayIfAdminCredential_'](_0xc4f87f){(_0xc4f87f&&_0xc4f87f['length']===0x28||vc(_0xc4f87f))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x407d85){this['appCheckToken_']=_0x407d85,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x46f105=this['authToken_'],_0x4bb43e=yc(_0x46f105)?'auth':'gauth',_0x17a890={'cred':_0x46f105};this['authOverride_']===null?_0x17a890['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x17a890['authvar']=this['authOverride_']),this['sendRequest'](_0x4bb43e,_0x17a890,_0x5c9743=>{const _0x2aab74=_0x5c9743['s'],_0x9373b1=_0x5c9743['d']||'error';this['authToken_']===_0x46f105&&(_0x2aab74==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2aab74,_0x9373b1));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x44b9c7=>{const _0x51b791=_0x44b9c7['s'],_0x31fed9=_0x44b9c7['d']||'error';_0x51b791==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x51b791,_0x31fed9);});}['unlisten'](_0x5366e1,_0xf52453){const _0x3a454c=_0x5366e1['_path']['toString'](),_0x203159=_0x5366e1['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3a454c+'\x20'+_0x203159),f(_0x5366e1['_queryParams']['isDefault']()||!_0x5366e1['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3a454c,_0x203159)&&this['connected_']&&this['sendUnlisten_'](_0x3a454c,_0x203159,_0x5366e1['_queryObject'],_0xf52453);}['sendUnlisten_'](_0x27f4db,_0x1ef7c8,_0xc25427,_0x3ba653){this['log_']('Unlisten\x20on\x20'+_0x27f4db+'\x20for\x20'+_0x1ef7c8);const _0x4eafaf={'p':_0x27f4db},_0x52f40c='n';_0x3ba653&&(_0x4eafaf['q']=_0xc25427,_0x4eafaf['t']=_0x3ba653),this['sendRequest'](_0x52f40c,_0x4eafaf);}['onDisconnectPut'](_0x1a7b8d,_0x80e7ed,_0x13c0e8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1a7b8d,_0x80e7ed,_0x13c0e8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1a7b8d,'action':'o','data':_0x80e7ed,'onComplete':_0x13c0e8});}['onDisconnectMerge'](_0x1f471d,_0x5263c,_0x21a80e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1f471d,_0x5263c,_0x21a80e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1f471d,'action':'om','data':_0x5263c,'onComplete':_0x21a80e});}['onDisconnectCancel'](_0x24205a,_0x916f0f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x24205a,null,_0x916f0f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x24205a,'action':'oc','data':null,'onComplete':_0x916f0f});}['sendOnDisconnect_'](_0xaa7a,_0x13ef58,_0x2931e5,_0xe551fe){const _0x5c75ee={'p':_0x13ef58,'d':_0x2931e5};this['log_']('onDisconnect\x20'+_0xaa7a,_0x5c75ee),this['sendRequest'](_0xaa7a,_0x5c75ee,_0x762f07=>{_0xe551fe&&setTimeout(()=>{_0xe551fe(_0x762f07['s'],_0x762f07['d']);},Math['floor'](0x0));});}['put'](_0xa0f16b,_0x45409b,_0x35f649,_0x39f702){this['putInternal']('p',_0xa0f16b,_0x45409b,_0x35f649,_0x39f702);}['merge'](_0x50054e,_0x2dd1b1,_0x4c2508,_0x2abdbe){this['putInternal']('m',_0x50054e,_0x2dd1b1,_0x4c2508,_0x2abdbe);}['putInternal'](_0x9097dc,_0x49fb72,_0x22e386,_0x599809,_0x724427){this['initConnection_']();const _0x2c7525={'p':_0x49fb72,'d':_0x22e386};_0x724427!==void 0x0&&(_0x2c7525['h']=_0x724427),this['outstandingPuts_']['push']({'action':_0x9097dc,'request':_0x2c7525,'onComplete':_0x599809}),this['outstandingPutCount_']++;const _0x2d14e8=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2d14e8):this['log_']('Buffering\x20put:\x20'+_0x49fb72);}['sendPut_'](_0x3b3904){const _0x902deb=this['outstandingPuts_'][_0x3b3904]['action'],_0x5c81f2=this['outstandingPuts_'][_0x3b3904]['request'],_0x44cc2a=this['outstandingPuts_'][_0x3b3904]['onComplete'];this['outstandingPuts_'][_0x3b3904]['queued']=this['connected_'],this['sendRequest'](_0x902deb,_0x5c81f2,_0x5387b6=>{this['log_'](_0x902deb+'\x20response',_0x5387b6),delete this['outstandingPuts_'][_0x3b3904],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x44cc2a&&_0x44cc2a(_0x5387b6['s'],_0x5387b6['d']);});}['reportStats'](_0x5bdd99){if(this['connected_']){const _0x5cb5e4={'c':_0x5bdd99};this['log_']('reportStats',_0x5cb5e4),this['sendRequest']('s',_0x5cb5e4,_0x35a069=>{if(_0x35a069['s']!=='ok'){const _0x959c0e=_0x35a069['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x959c0e);}});}}['onDataMessage_'](_0x398dfa){if('r'in _0x398dfa){this['log_']('from\x20server:\x20'+O(_0x398dfa));const _0x13f3ea=_0x398dfa['r'],_0x47e868=this['requestCBHash_'][_0x13f3ea];_0x47e868&&(delete this['requestCBHash_'][_0x13f3ea],_0x47e868(_0x398dfa['b']));}else{if('error'in _0x398dfa)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x398dfa['error'];'a'in _0x398dfa&&this['onDataPush_'](_0x398dfa['a'],_0x398dfa['b']);}}['onDataPush_'](_0x328881,_0x3b2565){this['log_']('handleServerMessage',_0x328881,_0x3b2565),_0x328881==='d'?this['onDataUpdate_'](_0x3b2565['p'],_0x3b2565['d'],!0x1,_0x3b2565['t']):_0x328881==='m'?this['onDataUpdate_'](_0x3b2565['p'],_0x3b2565['d'],!0x0,_0x3b2565['t']):_0x328881==='c'?this['onListenRevoked_'](_0x3b2565['p'],_0x3b2565['q']):_0x328881==='ac'?this['onAuthRevoked_'](_0x3b2565['s'],_0x3b2565['d']):_0x328881==='apc'?this['onAppCheckRevoked_'](_0x3b2565['s'],_0x3b2565['d']):_0x328881==='sd'?this['onSecurityDebugPacket_'](_0x3b2565):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x328881)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x316248,_0x22c6d3){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x316248),this['lastSessionId']=_0x22c6d3,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x1f07b5){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x1f07b5));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x469093){_0x469093&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x469093;}['onOnline_'](_0x1dab99){_0x1dab99?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4d54cc=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x31ac78=Math['max'](0x0,this['reconnectDelay_']-_0x4d54cc);_0x31ac78=Math['random']()*_0x31ac78,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x31ac78+'ms'),this['scheduleConnect_'](_0x31ac78),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1265d7=this['onDataMessage_']['bind'](this),_0x55fc64=this['onReady_']['bind'](this),_0x2825e8=this['onRealtimeDisconnect_']['bind'](this),_0x1bb48a=this['id']+':'+ie['nextConnectionId_']++,_0x20c09a=this['lastSessionId'];let _0x42c3e7=!0x1,_0x20d937=null;const _0x2a99c8=function(){_0x20d937?_0x20d937['close']():(_0x42c3e7=!0x0,_0x2825e8());},_0x47bf92=function(_0x27b22e){f(_0x20d937,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x20d937['sendRequest'](_0x27b22e);};this['realtime_']={'close':_0x2a99c8,'sendRequest':_0x47bf92};const _0x1fe7e3=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1f84be,_0x572a11]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x1fe7e3),this['appCheckTokenProvider_']['getToken'](_0x1fe7e3)]);_0x42c3e7?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1f84be&&_0x1f84be['accessToken'],this['appCheckToken_']=_0x572a11&&_0x572a11['token'],_0x20d937=new wh(_0x1bb48a,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1265d7,_0x55fc64,_0x2825e8,_0x583ca3=>{U(_0x583ca3+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x20c09a));}catch(_0x8aff96){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x8aff96),_0x42c3e7||(this['repoInfo_']['nodeAdmin']&&U(_0x8aff96),_0x2a99c8());}}}['interrupt'](_0x15af5c){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x15af5c),this['interruptReasons_'][_0x15af5c]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0xc69fa7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0xc69fa7),delete this['interruptReasons_'][_0xc69fa7],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x103af5){const _0x5d2678=_0x103af5-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5d2678});}['cancelSentTransactions_'](){for(let _0x231ef1=0x0;_0x231ef1<this['outstandingPuts_']['length'];_0x231ef1++){const _0x54b65c=this['outstandingPuts_'][_0x231ef1];_0x54b65c&&'h'in _0x54b65c['request']&&_0x54b65c['queued']&&(_0x54b65c['onComplete']&&_0x54b65c['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x231ef1],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xa4f7c5,_0x50ddb2){let _0x3929af;_0x50ddb2?_0x3929af=_0x50ddb2['map'](_0x3ac7bf=>Bi(_0x3ac7bf))['join']('$'):_0x3929af='default';const _0x1118e7=this['removeListen_'](_0xa4f7c5,_0x3929af);_0x1118e7&&_0x1118e7['onComplete']&&_0x1118e7['onComplete']('permission_denied');}['removeListen_'](_0x41599d,_0x24e047){const _0x5f481f=new C(_0x41599d)['toString']();let _0x3d32e2;if(this['listens']['has'](_0x5f481f)){const _0x485673=this['listens']['get'](_0x5f481f);_0x3d32e2=_0x485673['get'](_0x24e047),_0x485673['delete'](_0x24e047),_0x485673['size']===0x0&&this['listens']['delete'](_0x5f481f);}else _0x3d32e2=void 0x0;return _0x3d32e2;}['onAuthRevoked_'](_0x2f1b0b,_0x455523){L('Auth\x20token\x20revoked:\x20'+_0x2f1b0b+'/'+_0x455523),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2f1b0b==='invalid_token'||_0x2f1b0b==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x50d512,_0x2ddc19){L('App\x20check\x20token\x20revoked:\x20'+_0x50d512+'/'+_0x2ddc19),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x50d512==='invalid_token'||_0x50d512==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x275dc3){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x275dc3):'msg'in _0x275dc3&&console['log']('FIREBASE:\x20'+_0x275dc3['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x45e16c of this['listens']['values']())for(const _0x314645 of _0x45e16c['values']())this['sendListen_'](_0x314645);for(let _0x1e998a=0x0;_0x1e998a<this['outstandingPuts_']['length'];_0x1e998a++)this['outstandingPuts_'][_0x1e998a]&&this['sendPut_'](_0x1e998a);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3f3584=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3f3584['action'],_0x3f3584['pathString'],_0x3f3584['data'],_0x3f3584['onComplete']);}for(let _0x1000ee=0x0;_0x1000ee<this['outstandingGets_']['length'];_0x1000ee++)this['outstandingGets_'][_0x1000ee]&&this['sendGet_'](_0x1000ee);}['sendConnectStats_'](){const _0x35f2cd={};let _0x30005a='js';_0x35f2cd['sdk.'+_0x30005a+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x35f2cd['framework.cordova']=0x1:qr()&&(_0x35f2cd['framework.reactnative']=0x1),this['reportStats'](_0x35f2cd);}['shouldReconnect_'](){const _0x4d0944=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x4d0944;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x542302,_0x3f64e2){this['name']=_0x542302,this['node']=_0x3f64e2;}static['Wrap'](_0xd94bdc,_0x44a1e7){return new E(_0xd94bdc,_0x44a1e7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3a4277,_0x501f0a){const _0x3020fc=new E(xe,_0x3a4277),_0x249707=new E(xe,_0x501f0a);return this['compare'](_0x3020fc,_0x249707)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x25a4d7){Xt=_0x25a4d7;}['compare'](_0x49a501,_0x1325ae){return He(_0x49a501['name'],_0x1325ae['name']);}['isDefinedOn'](_0x396f0f){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x1cd544,_0x1024d4){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x5964d2,_0x48bde8){return f(typeof _0x5964d2=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x5964d2,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x5afe4d,_0x309467,_0x3295ad,_0x5c2ae5,_0x3cb0b3=null){this['isReverse_']=_0x5c2ae5,this['resultGenerator_']=_0x3cb0b3,this['nodeStack_']=[];let _0x1f16b8=0x1;for(;!_0x5afe4d['isEmpty']();)if(_0x5afe4d=_0x5afe4d,_0x1f16b8=_0x309467?_0x3295ad(_0x5afe4d['key'],_0x309467):0x1,_0x5c2ae5&&(_0x1f16b8*=-0x1),_0x1f16b8<0x0)this['isReverse_']?_0x5afe4d=_0x5afe4d['left']:_0x5afe4d=_0x5afe4d['right'];else{if(_0x1f16b8===0x0){this['nodeStack_']['push'](_0x5afe4d);break;}else this['nodeStack_']['push'](_0x5afe4d),this['isReverse_']?_0x5afe4d=_0x5afe4d['right']:_0x5afe4d=_0x5afe4d['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0xc4f92=this['nodeStack_']['pop'](),_0x5423f7;if(this['resultGenerator_']?_0x5423f7=this['resultGenerator_'](_0xc4f92['key'],_0xc4f92['value']):_0x5423f7={'key':_0xc4f92['key'],'value':_0xc4f92['value']},this['isReverse_']){for(_0xc4f92=_0xc4f92['left'];!_0xc4f92['isEmpty']();)this['nodeStack_']['push'](_0xc4f92),_0xc4f92=_0xc4f92['right'];}else{for(_0xc4f92=_0xc4f92['right'];!_0xc4f92['isEmpty']();)this['nodeStack_']['push'](_0xc4f92),_0xc4f92=_0xc4f92['left'];}return _0x5423f7;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x444e23=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x444e23['key'],_0x444e23['value']):{'key':_0x444e23['key'],'value':_0x444e23['value']};}}class M{constructor(_0x4f68ca,_0xd772e5,_0x4e507d,_0x540271,_0x249485){this['key']=_0x4f68ca,this['value']=_0xd772e5,this['color']=_0x4e507d??M['RED'],this['left']=_0x540271??B['EMPTY_NODE'],this['right']=_0x249485??B['EMPTY_NODE'];}['copy'](_0x1483dc,_0x57063f,_0x1074af,_0x5a0a0f,_0x121ad6){return new M(_0x1483dc??this['key'],_0x57063f??this['value'],_0x1074af??this['color'],_0x5a0a0f??this['left'],_0x121ad6??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x9ea5a8){return this['left']['inorderTraversal'](_0x9ea5a8)||!!_0x9ea5a8(this['key'],this['value'])||this['right']['inorderTraversal'](_0x9ea5a8);}['reverseTraversal'](_0x1c19c5){return this['right']['reverseTraversal'](_0x1c19c5)||_0x1c19c5(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1c19c5);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3cf0da,_0x5f247a,_0x27d5a0){let _0x3f1124=this;const _0x47fc65=_0x27d5a0(_0x3cf0da,_0x3f1124['key']);return _0x47fc65<0x0?_0x3f1124=_0x3f1124['copy'](null,null,null,_0x3f1124['left']['insert'](_0x3cf0da,_0x5f247a,_0x27d5a0),null):_0x47fc65===0x0?_0x3f1124=_0x3f1124['copy'](null,_0x5f247a,null,null,null):_0x3f1124=_0x3f1124['copy'](null,null,null,null,_0x3f1124['right']['insert'](_0x3cf0da,_0x5f247a,_0x27d5a0)),_0x3f1124['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2b58fe=this;return!_0x2b58fe['left']['isRed_']()&&!_0x2b58fe['left']['left']['isRed_']()&&(_0x2b58fe=_0x2b58fe['moveRedLeft_']()),_0x2b58fe=_0x2b58fe['copy'](null,null,null,_0x2b58fe['left']['removeMin_'](),null),_0x2b58fe['fixUp_']();}['remove'](_0x5d4fc3,_0x1a52f1){let _0x547e6c,_0x426d93;if(_0x547e6c=this,_0x1a52f1(_0x5d4fc3,_0x547e6c['key'])<0x0)!_0x547e6c['left']['isEmpty']()&&!_0x547e6c['left']['isRed_']()&&!_0x547e6c['left']['left']['isRed_']()&&(_0x547e6c=_0x547e6c['moveRedLeft_']()),_0x547e6c=_0x547e6c['copy'](null,null,null,_0x547e6c['left']['remove'](_0x5d4fc3,_0x1a52f1),null);else{if(_0x547e6c['left']['isRed_']()&&(_0x547e6c=_0x547e6c['rotateRight_']()),!_0x547e6c['right']['isEmpty']()&&!_0x547e6c['right']['isRed_']()&&!_0x547e6c['right']['left']['isRed_']()&&(_0x547e6c=_0x547e6c['moveRedRight_']()),_0x1a52f1(_0x5d4fc3,_0x547e6c['key'])===0x0){if(_0x547e6c['right']['isEmpty']())return B['EMPTY_NODE'];_0x426d93=_0x547e6c['right']['min_'](),_0x547e6c=_0x547e6c['copy'](_0x426d93['key'],_0x426d93['value'],null,null,_0x547e6c['right']['removeMin_']());}_0x547e6c=_0x547e6c['copy'](null,null,null,null,_0x547e6c['right']['remove'](_0x5d4fc3,_0x1a52f1));}return _0x547e6c['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x25d2a5=this;return _0x25d2a5['right']['isRed_']()&&!_0x25d2a5['left']['isRed_']()&&(_0x25d2a5=_0x25d2a5['rotateLeft_']()),_0x25d2a5['left']['isRed_']()&&_0x25d2a5['left']['left']['isRed_']()&&(_0x25d2a5=_0x25d2a5['rotateRight_']()),_0x25d2a5['left']['isRed_']()&&_0x25d2a5['right']['isRed_']()&&(_0x25d2a5=_0x25d2a5['colorFlip_']()),_0x25d2a5;}['moveRedLeft_'](){let _0x11ce66=this['colorFlip_']();return _0x11ce66['right']['left']['isRed_']()&&(_0x11ce66=_0x11ce66['copy'](null,null,null,null,_0x11ce66['right']['rotateRight_']()),_0x11ce66=_0x11ce66['rotateLeft_'](),_0x11ce66=_0x11ce66['colorFlip_']()),_0x11ce66;}['moveRedRight_'](){let _0x414f29=this['colorFlip_']();return _0x414f29['left']['left']['isRed_']()&&(_0x414f29=_0x414f29['rotateRight_'](),_0x414f29=_0x414f29['colorFlip_']()),_0x414f29;}['rotateLeft_'](){const _0x434f81=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x434f81,null);}['rotateRight_'](){const _0x34bdcb=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x34bdcb);}['colorFlip_'](){const _0x48204b=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x1fee1c=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x48204b,_0x1fee1c);}['checkMaxDepth_'](){const _0x5e3f57=this['check_']();return Math['pow'](0x2,_0x5e3f57)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x9cd5fe=this['left']['check_']();if(_0x9cd5fe!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x9cd5fe+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x2de37c,_0x346eac,_0x3883f5,_0x353948,_0x5da4b6){return this;}['insert'](_0x4b33b2,_0x576662,_0x35b205){return new M(_0x4b33b2,_0x576662,null);}['remove'](_0x3db586,_0x1727b2){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x32751f){return!0x1;}['reverseTraversal'](_0x244a75){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1de30d,_0xa7e6e9=B['EMPTY_NODE']){this['comparator_']=_0x1de30d,this['root_']=_0xa7e6e9;}['insert'](_0x3568d3,_0x78f040){return new B(this['comparator_'],this['root_']['insert'](_0x3568d3,_0x78f040,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x50c4fa){return new B(this['comparator_'],this['root_']['remove'](_0x50c4fa,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x409377){let _0x209023,_0x156730=this['root_'];for(;!_0x156730['isEmpty']();){if(_0x209023=this['comparator_'](_0x409377,_0x156730['key']),_0x209023===0x0)return _0x156730['value'];_0x209023<0x0?_0x156730=_0x156730['left']:_0x209023>0x0&&(_0x156730=_0x156730['right']);}return null;}['getPredecessorKey'](_0x5d1491){let _0x53d26c,_0x2c8d7e=this['root_'],_0x484767=null;for(;!_0x2c8d7e['isEmpty']();)if(_0x53d26c=this['comparator_'](_0x5d1491,_0x2c8d7e['key']),_0x53d26c===0x0){if(_0x2c8d7e['left']['isEmpty']())return _0x484767?_0x484767['key']:null;for(_0x2c8d7e=_0x2c8d7e['left'];!_0x2c8d7e['right']['isEmpty']();)_0x2c8d7e=_0x2c8d7e['right'];return _0x2c8d7e['key'];}else _0x53d26c<0x0?_0x2c8d7e=_0x2c8d7e['left']:_0x53d26c>0x0&&(_0x484767=_0x2c8d7e,_0x2c8d7e=_0x2c8d7e['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x15212e){return this['root_']['inorderTraversal'](_0x15212e);}['reverseTraversal'](_0x11f6bd){return this['root_']['reverseTraversal'](_0x11f6bd);}['getIterator'](_0x34de01){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x34de01);}['getIteratorFrom'](_0x19929b,_0x5b661f){return new Zt(this['root_'],_0x19929b,this['comparator_'],!0x1,_0x5b661f);}['getReverseIteratorFrom'](_0x2a6f01,_0x36873b){return new Zt(this['root_'],_0x2a6f01,this['comparator_'],!0x0,_0x36873b);}['getReverseIterator'](_0x1e1763){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x1e1763);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x388a8c,_0x27e7bd){return He(_0x388a8c['name'],_0x27e7bd['name']);}function ji(_0x1f6706,_0x505cf1){return He(_0x1f6706,_0x505cf1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x229185){vi=_0x229185;}const Ro=function(_0x5a4cd9){return typeof _0x5a4cd9=='number'?'number:'+so(_0x5a4cd9):'string:'+_0x5a4cd9;},Ao=function(_0x710401){if(_0x710401['isLeafNode']()){const _0x5004ad=_0x710401['val']();f(typeof _0x5004ad=='string'||typeof _0x5004ad=='number'||typeof _0x5004ad=='object'&&Y(_0x5004ad,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x710401===vi||_0x710401['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x710401===vi||_0x710401['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x18f87c){er=_0x18f87c;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x55dca8,_0x325610=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x55dca8,this['priorityNode_']=_0x325610,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x39196a){return new D(this['value_'],_0x39196a);}['getImmediateChild'](_0x2c1b19){return _0x2c1b19==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3d2f79){return v(_0x3d2f79)?this:y(_0x3d2f79)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x11be68,_0x5ae5cd){return null;}['updateImmediateChild'](_0x257080,_0x465fe2){return _0x257080==='.priority'?this['updatePriority'](_0x465fe2):_0x465fe2['isEmpty']()&&_0x257080!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x257080,_0x465fe2)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x5ccdf0,_0x10aa2a){const _0x689f3c=y(_0x5ccdf0);return _0x689f3c===null?_0x10aa2a:_0x10aa2a['isEmpty']()&&_0x689f3c!=='.priority'?this:(f(_0x689f3c!=='.priority'||we(_0x5ccdf0)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x689f3c,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x5ccdf0),_0x10aa2a)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x35ac2f,_0x28a4d5){return!0x1;}['val'](_0x47b85c){return _0x47b85c&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x325cd0='';this['priorityNode_']['isEmpty']()||(_0x325cd0+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x1305ac=typeof this['value_'];_0x325cd0+=_0x1305ac+':',_0x1305ac==='number'?_0x325cd0+=so(this['value_']):_0x325cd0+=this['value_'],this['lazyHash_']=no(_0x325cd0);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x5abb6c){return _0x5abb6c===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x5abb6c instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x5abb6c['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x5abb6c));}['compareToLeafNode_'](_0xca1e56){const _0x4a1274=typeof _0xca1e56['value_'],_0x275dee=typeof this['value_'],_0x3626f5=D['VALUE_TYPE_ORDER']['indexOf'](_0x4a1274),_0x240df5=D['VALUE_TYPE_ORDER']['indexOf'](_0x275dee);return f(_0x3626f5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4a1274),f(_0x240df5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x275dee),_0x3626f5===_0x240df5?_0x275dee==='object'?0x0:this['value_']<_0xca1e56['value_']?-0x1:this['value_']===_0xca1e56['value_']?0x0:0x1:_0x240df5-_0x3626f5;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x25f640){if(_0x25f640===this)return!0x0;if(_0x25f640['isLeafNode']()){const _0x3cbc31=_0x25f640;return this['value_']===_0x3cbc31['value_']&&this['priorityNode_']['equals'](_0x3cbc31['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x2035c4){ko=_0x2035c4;}function xh(_0x30747d){No=_0x30747d;}class Fh extends On{['compare'](_0x2d22df,_0x276e91){const _0x5bb901=_0x2d22df['node']['getPriority'](),_0x4000d6=_0x276e91['node']['getPriority'](),_0x144fdd=_0x5bb901['compareTo'](_0x4000d6);return _0x144fdd===0x0?He(_0x2d22df['name'],_0x276e91['name']):_0x144fdd;}['isDefinedOn'](_0x40aa71){return!_0x40aa71['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x468e69,_0x11c347){return!_0x468e69['getPriority']()['equals'](_0x11c347['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x3daa87,_0x5a80ee){const _0x162529=ko(_0x3daa87);return new E(_0x5a80ee,new D('[PRIORITY-POST]',_0x162529));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x19acf0){const _0xde27fd=_0x5f3abd=>parseInt(Math['log'](_0x5f3abd)/Uh,0xa),_0xf7576e=_0x5932e1=>parseInt(Array(_0x5932e1+0x1)['join']('1'),0x2);this['count']=_0xde27fd(_0x19acf0+0x1),this['current_']=this['count']-0x1;const _0x421e57=_0xf7576e(this['count']);this['bits_']=_0x19acf0+0x1&_0x421e57;}['nextBitIsOne'](){const _0x581cc0=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x581cc0;}}const dn=function(_0x505b49,_0x31ec43,_0x35345d,_0x19c097){_0x505b49['sort'](_0x31ec43);const _0x587163=function(_0x216bae,_0x4a35f4){const _0x6930b7=_0x4a35f4-_0x216bae;let _0x4441e7,_0x3faad5;if(_0x6930b7===0x0)return null;if(_0x6930b7===0x1)return _0x4441e7=_0x505b49[_0x216bae],_0x3faad5=_0x35345d?_0x35345d(_0x4441e7):_0x4441e7,new M(_0x3faad5,_0x4441e7['node'],M['BLACK'],null,null);{const _0x5c9682=parseInt(_0x6930b7/0x2,0xa)+_0x216bae,_0xc63b55=_0x587163(_0x216bae,_0x5c9682),_0x5cbe52=_0x587163(_0x5c9682+0x1,_0x4a35f4);return _0x4441e7=_0x505b49[_0x5c9682],_0x3faad5=_0x35345d?_0x35345d(_0x4441e7):_0x4441e7,new M(_0x3faad5,_0x4441e7['node'],M['BLACK'],_0xc63b55,_0x5cbe52);}},_0x32a006=function(_0xf15690){let _0x58f483=null,_0x1e5a37=null,_0x9af499=_0x505b49['length'];const _0x345a87=function(_0x43c0ba,_0x1e0947){const _0x17d949=_0x9af499-_0x43c0ba,_0x2f3f05=_0x9af499;_0x9af499-=_0x43c0ba;const _0x56f0ca=_0x587163(_0x17d949+0x1,_0x2f3f05),_0x5b056c=_0x505b49[_0x17d949],_0x1bd331=_0x35345d?_0x35345d(_0x5b056c):_0x5b056c;_0x2d3688(new M(_0x1bd331,_0x5b056c['node'],_0x1e0947,null,_0x56f0ca));},_0x2d3688=function(_0x527b47){_0x58f483?(_0x58f483['left']=_0x527b47,_0x58f483=_0x527b47):(_0x1e5a37=_0x527b47,_0x58f483=_0x527b47);};for(let _0x37ce05=0x0;_0x37ce05<_0xf15690['count'];++_0x37ce05){const _0x1ccb9c=_0xf15690['nextBitIsOne'](),_0xfaad15=Math['pow'](0x2,_0xf15690['count']-(_0x37ce05+0x1));_0x1ccb9c?_0x345a87(_0xfaad15,M['BLACK']):(_0x345a87(_0xfaad15,M['BLACK']),_0x345a87(_0xfaad15,M['RED']));}return _0x1e5a37;},_0x4775dd=new Wh(_0x505b49['length']),_0x1a3837=_0x32a006(_0x4775dd);return new B(_0x19c097||_0x31ec43,_0x1a3837);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x3aa4b8,_0x507a70){this['indexes_']=_0x3aa4b8,this['indexSet_']=_0x507a70;}['get'](_0x5e6ef9){const _0x268491=Oe(this['indexes_'],_0x5e6ef9);if(!_0x268491)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5e6ef9);return _0x268491 instanceof B?_0x268491:null;}['hasIndex'](_0x5bdf29){return Y(this['indexSet_'],_0x5bdf29['toString']());}['addIndex'](_0x4632be,_0x98fb84){f(_0x4632be!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xcba39d=[];let _0x140a4a=!0x1;const _0xa11bf5=_0x98fb84['getIterator'](E['Wrap']);let _0x1bb6af=_0xa11bf5['getNext']();for(;_0x1bb6af;)_0x140a4a=_0x140a4a||_0x4632be['isDefinedOn'](_0x1bb6af['node']),_0xcba39d['push'](_0x1bb6af),_0x1bb6af=_0xa11bf5['getNext']();let _0x25d0d6;_0x140a4a?_0x25d0d6=dn(_0xcba39d,_0x4632be['getCompare']()):_0x25d0d6=je;const _0x1e1b9a=_0x4632be['toString'](),_0x25846f={...this['indexSet_']};_0x25846f[_0x1e1b9a]=_0x4632be;const _0x44ca37={...this['indexes_']};return _0x44ca37[_0x1e1b9a]=_0x25d0d6,new ee(_0x44ca37,_0x25846f);}['addToIndexes'](_0x41b440,_0x1c67ad){const _0x449d76=ln(this['indexes_'],(_0x5815e8,_0x2a0f2f)=>{const _0x29388a=Oe(this['indexSet_'],_0x2a0f2f);if(f(_0x29388a,'Missing\x20index\x20implementation\x20for\x20'+_0x2a0f2f),_0x5815e8===je){if(_0x29388a['isDefinedOn'](_0x41b440['node'])){const _0x3adcca=[],_0xc58f85=_0x1c67ad['getIterator'](E['Wrap']);let _0x551528=_0xc58f85['getNext']();for(;_0x551528;)_0x551528['name']!==_0x41b440['name']&&_0x3adcca['push'](_0x551528),_0x551528=_0xc58f85['getNext']();return _0x3adcca['push'](_0x41b440),dn(_0x3adcca,_0x29388a['getCompare']());}else return je;}else{const _0x4f3b5f=_0x1c67ad['get'](_0x41b440['name']);let _0x43e21f=_0x5815e8;return _0x4f3b5f&&(_0x43e21f=_0x43e21f['remove'](new E(_0x41b440['name'],_0x4f3b5f))),_0x43e21f['insert'](_0x41b440,_0x41b440['node']);}});return new ee(_0x449d76,this['indexSet_']);}['removeFromIndexes'](_0x49400d,_0xdd50d6){const _0x4d0c1a=ln(this['indexes_'],_0x42b2c6=>{if(_0x42b2c6===je)return _0x42b2c6;{const _0x3e1485=_0xdd50d6['get'](_0x49400d['name']);return _0x3e1485?_0x42b2c6['remove'](new E(_0x49400d['name'],_0x3e1485)):_0x42b2c6;}});return new ee(_0x4d0c1a,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x2b1b78,_0x453312,_0x60e3f1){this['children_']=_0x2b1b78,this['priorityNode_']=_0x453312,this['indexMap_']=_0x60e3f1,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x5cde29){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x5cde29,this['indexMap_']);}['getImmediateChild'](_0x3d573e){if(_0x3d573e==='.priority')return this['getPriority']();{const _0x4be183=this['children_']['get'](_0x3d573e);return _0x4be183===null?gt:_0x4be183;}}['getChild'](_0xef800e){const _0x5172fa=y(_0xef800e);return _0x5172fa===null?this:this['getImmediateChild'](_0x5172fa)['getChild'](b(_0xef800e));}['hasChild'](_0x54e57f){return this['children_']['get'](_0x54e57f)!==null;}['updateImmediateChild'](_0x398077,_0x8cd005){if(f(_0x8cd005,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x398077==='.priority')return this['updatePriority'](_0x8cd005);{const _0x49d106=new E(_0x398077,_0x8cd005);let _0x5b2c9c,_0x263914;_0x8cd005['isEmpty']()?(_0x5b2c9c=this['children_']['remove'](_0x398077),_0x263914=this['indexMap_']['removeFromIndexes'](_0x49d106,this['children_'])):(_0x5b2c9c=this['children_']['insert'](_0x398077,_0x8cd005),_0x263914=this['indexMap_']['addToIndexes'](_0x49d106,this['children_']));const _0x147741=_0x5b2c9c['isEmpty']()?gt:this['priorityNode_'];return new g(_0x5b2c9c,_0x147741,_0x263914);}}['updateChild'](_0x2f17bc,_0x4d4e7b){const _0x268bff=y(_0x2f17bc);if(_0x268bff===null)return _0x4d4e7b;{f(y(_0x2f17bc)!=='.priority'||we(_0x2f17bc)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x405612=this['getImmediateChild'](_0x268bff)['updateChild'](b(_0x2f17bc),_0x4d4e7b);return this['updateImmediateChild'](_0x268bff,_0x405612);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x81e16){if(this['isEmpty']())return null;const _0x28cd68={};let _0x76b227=0x0,_0x287115=0x0,_0x524772=!0x0;if(this['forEachChild'](R,(_0x184e37,_0x54d330)=>{_0x28cd68[_0x184e37]=_0x54d330['val'](_0x81e16),_0x76b227++,_0x524772&&g['INTEGER_REGEXP_']['test'](_0x184e37)?_0x287115=Math['max'](_0x287115,Number(_0x184e37)):_0x524772=!0x1;}),!_0x81e16&&_0x524772&&_0x287115<0x2*_0x76b227){const _0x38a21c=[];for(const _0x320a57 in _0x28cd68)_0x38a21c[_0x320a57]=_0x28cd68[_0x320a57];return _0x38a21c;}else return _0x81e16&&!this['getPriority']()['isEmpty']()&&(_0x28cd68['.priority']=this['getPriority']()['val']()),_0x28cd68;}['hash'](){if(this['lazyHash_']===null){let _0x3bb135='';this['getPriority']()['isEmpty']()||(_0x3bb135+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x102df4,_0x1b0047)=>{const _0x45c03c=_0x1b0047['hash']();_0x45c03c!==''&&(_0x3bb135+=':'+_0x102df4+':'+_0x45c03c);}),this['lazyHash_']=_0x3bb135===''?'':no(_0x3bb135);}return this['lazyHash_'];}['getPredecessorChildName'](_0xa38948,_0x55d412,_0x53cbf1){const _0x21befd=this['resolveIndex_'](_0x53cbf1);if(_0x21befd){const _0x333360=_0x21befd['getPredecessorKey'](new E(_0xa38948,_0x55d412));return _0x333360?_0x333360['name']:null;}else return this['children_']['getPredecessorKey'](_0xa38948);}['getFirstChildName'](_0x5847f9){const _0x3d6733=this['resolveIndex_'](_0x5847f9);if(_0x3d6733){const _0x4a2d78=_0x3d6733['minKey']();return _0x4a2d78&&_0x4a2d78['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x589778){const _0x355839=this['getFirstChildName'](_0x589778);return _0x355839?new E(_0x355839,this['children_']['get'](_0x355839)):null;}['getLastChildName'](_0x19a287){const _0x2c3808=this['resolveIndex_'](_0x19a287);if(_0x2c3808){const _0x4f5b49=_0x2c3808['maxKey']();return _0x4f5b49&&_0x4f5b49['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x374f71){const _0x30f105=this['getLastChildName'](_0x374f71);return _0x30f105?new E(_0x30f105,this['children_']['get'](_0x30f105)):null;}['forEachChild'](_0x5277c2,_0x10247b){const _0x109d51=this['resolveIndex_'](_0x5277c2);return _0x109d51?_0x109d51['inorderTraversal'](_0x4de95d=>_0x10247b(_0x4de95d['name'],_0x4de95d['node'])):this['children_']['inorderTraversal'](_0x10247b);}['getIterator'](_0x445b55){return this['getIteratorFrom'](_0x445b55['minPost'](),_0x445b55);}['getIteratorFrom'](_0x2b806b,_0x58cce8){const _0x44297c=this['resolveIndex_'](_0x58cce8);if(_0x44297c)return _0x44297c['getIteratorFrom'](_0x2b806b,_0x4bf8ad=>_0x4bf8ad);{const _0x257793=this['children_']['getIteratorFrom'](_0x2b806b['name'],E['Wrap']);let _0x43a8eb=_0x257793['peek']();for(;_0x43a8eb!=null&&_0x58cce8['compare'](_0x43a8eb,_0x2b806b)<0x0;)_0x257793['getNext'](),_0x43a8eb=_0x257793['peek']();return _0x257793;}}['getReverseIterator'](_0x759c67){return this['getReverseIteratorFrom'](_0x759c67['maxPost'](),_0x759c67);}['getReverseIteratorFrom'](_0x41be27,_0x41a3a0){const _0x1c45bb=this['resolveIndex_'](_0x41a3a0);if(_0x1c45bb)return _0x1c45bb['getReverseIteratorFrom'](_0x41be27,_0x45c7f8=>_0x45c7f8);{const _0x3862a8=this['children_']['getReverseIteratorFrom'](_0x41be27['name'],E['Wrap']);let _0x337e0d=_0x3862a8['peek']();for(;_0x337e0d!=null&&_0x41a3a0['compare'](_0x337e0d,_0x41be27)>0x0;)_0x3862a8['getNext'](),_0x337e0d=_0x3862a8['peek']();return _0x3862a8;}}['compareTo'](_0xded22a){return this['isEmpty']()?_0xded22a['isEmpty']()?0x0:-0x1:_0xded22a['isLeafNode']()||_0xded22a['isEmpty']()?0x1:_0xded22a===Ht?-0x1:0x0;}['withIndex'](_0x1bec26){if(_0x1bec26===ye||this['indexMap_']['hasIndex'](_0x1bec26))return this;{const _0x113207=this['indexMap_']['addIndex'](_0x1bec26,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x113207);}}['isIndexed'](_0x189545){return _0x189545===ye||this['indexMap_']['hasIndex'](_0x189545);}['equals'](_0x4c5220){if(_0x4c5220===this)return!0x0;if(_0x4c5220['isLeafNode']())return!0x1;{const _0x5146f7=_0x4c5220;if(this['getPriority']()['equals'](_0x5146f7['getPriority']())){if(this['children_']['count']()===_0x5146f7['children_']['count']()){const _0x514c54=this['getIterator'](R),_0xcdce9=_0x5146f7['getIterator'](R);let _0x261a19=_0x514c54['getNext'](),_0x344c6e=_0xcdce9['getNext']();for(;_0x261a19&&_0x344c6e;){if(_0x261a19['name']!==_0x344c6e['name']||!_0x261a19['node']['equals'](_0x344c6e['node']))return!0x1;_0x261a19=_0x514c54['getNext'](),_0x344c6e=_0xcdce9['getNext']();}return _0x261a19===null&&_0x344c6e===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3266bd){return _0x3266bd===ye?null:this['indexMap_']['get'](_0x3266bd['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x355ce5){return _0x355ce5===this?0x0:0x1;}['equals'](_0x18af6a){return _0x18af6a===this;}['getPriority'](){return this;}['getImmediateChild'](_0x171546){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x5137dd,_0x538c28=null){if(_0x5137dd===null)return g['EMPTY_NODE'];if(typeof _0x5137dd=='object'&&'.priority'in _0x5137dd&&(_0x538c28=_0x5137dd['.priority']),f(_0x538c28===null||typeof _0x538c28=='string'||typeof _0x538c28=='number'||typeof _0x538c28=='object'&&'.sv'in _0x538c28,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x538c28),typeof _0x5137dd=='object'&&'.value'in _0x5137dd&&_0x5137dd['.value']!==null&&(_0x5137dd=_0x5137dd['.value']),typeof _0x5137dd!='object'||'.sv'in _0x5137dd){const _0x90446b=_0x5137dd;return new D(_0x90446b,N(_0x538c28));}if(!(_0x5137dd instanceof Array)&&Vh){const _0xf0d46f=[];let _0x4bd0ed=!0x1;if(x(_0x5137dd,(_0xc8e977,_0x4e283b)=>{if(_0xc8e977['substring'](0x0,0x1)!=='.'){const _0x575770=N(_0x4e283b);_0x575770['isEmpty']()||(_0x4bd0ed=_0x4bd0ed||!_0x575770['getPriority']()['isEmpty'](),_0xf0d46f['push'](new E(_0xc8e977,_0x575770)));}}),_0xf0d46f['length']===0x0)return g['EMPTY_NODE'];const _0x3a7346=dn(_0xf0d46f,Dh,_0x23ca21=>_0x23ca21['name'],ji);if(_0x4bd0ed){const _0x1fa657=dn(_0xf0d46f,R['getCompare']());return new g(_0x3a7346,N(_0x538c28),new ee({'.priority':_0x1fa657},{'.priority':R}));}else return new g(_0x3a7346,N(_0x538c28),ee['Default']);}else{let _0x41f426=g['EMPTY_NODE'];return x(_0x5137dd,(_0x29a290,_0x259e41)=>{if(Y(_0x5137dd,_0x29a290)&&_0x29a290['substring'](0x0,0x1)!=='.'){const _0x55f0d1=N(_0x259e41);(_0x55f0d1['isLeafNode']()||!_0x55f0d1['isEmpty']())&&(_0x41f426=_0x41f426['updateImmediateChild'](_0x29a290,_0x55f0d1));}}),_0x41f426['updatePriority'](N(_0x538c28));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x2f517a){super(),this['indexPath_']=_0x2f517a,f(!v(_0x2f517a)&&y(_0x2f517a)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x176193){return _0x176193['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4c33b9){return!_0x4c33b9['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x60f110,_0x57902a){const _0x7bde32=this['extractChild'](_0x60f110['node']),_0x527715=this['extractChild'](_0x57902a['node']),_0x4d4fc4=_0x7bde32['compareTo'](_0x527715);return _0x4d4fc4===0x0?He(_0x60f110['name'],_0x57902a['name']):_0x4d4fc4;}['makePost'](_0x1a599c,_0x2f1b6b){const _0x1c91ee=N(_0x1a599c),_0x5b1f49=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1c91ee);return new E(_0x2f1b6b,_0x5b1f49);}['maxPost'](){const _0x3621c5=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x3621c5);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x32d29b,_0x57de06){const _0x3ca13c=_0x32d29b['node']['compareTo'](_0x57de06['node']);return _0x3ca13c===0x0?He(_0x32d29b['name'],_0x57de06['name']):_0x3ca13c;}['isDefinedOn'](_0x478ebb){return!0x0;}['indexedValueChanged'](_0x2b7047,_0x5f13d7){return!_0x2b7047['equals'](_0x5f13d7);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x158e6c,_0x209e61){const _0xe91419=N(_0x158e6c);return new E(_0x209e61,_0xe91419);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x44f0c3){return{'type':'value','snapshotNode':_0x44f0c3};}function tt(_0xebc68c,_0x496bc4){return{'type':'child_added','snapshotNode':_0x496bc4,'childName':_0xebc68c};}function Nt(_0x180d72,_0x288fb2){return{'type':'child_removed','snapshotNode':_0x288fb2,'childName':_0x180d72};}function Pt(_0x104a98,_0xd4ae1f,_0x335b09){return{'type':'child_changed','snapshotNode':_0xd4ae1f,'childName':_0x104a98,'oldSnap':_0x335b09};}function $h(_0x41b62a,_0x1e0c29){return{'type':'child_moved','snapshotNode':_0x1e0c29,'childName':_0x41b62a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x14ced7){this['index_']=_0x14ced7;}['updateChild'](_0x18f074,_0x719246,_0x468053,_0x1be0df,_0x4ff9ff,_0x33ee71){f(_0x18f074['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3c0ac1=_0x18f074['getImmediateChild'](_0x719246);return _0x3c0ac1['getChild'](_0x1be0df)['equals'](_0x468053['getChild'](_0x1be0df))&&_0x3c0ac1['isEmpty']()===_0x468053['isEmpty']()||(_0x33ee71!=null&&(_0x468053['isEmpty']()?_0x18f074['hasChild'](_0x719246)?_0x33ee71['trackChildChange'](Nt(_0x719246,_0x3c0ac1)):f(_0x18f074['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3c0ac1['isEmpty']()?_0x33ee71['trackChildChange'](tt(_0x719246,_0x468053)):_0x33ee71['trackChildChange'](Pt(_0x719246,_0x468053,_0x3c0ac1))),_0x18f074['isLeafNode']()&&_0x468053['isEmpty']())?_0x18f074:_0x18f074['updateImmediateChild'](_0x719246,_0x468053)['withIndex'](this['index_']);}['updateFullNode'](_0x1db93d,_0x12bf76,_0x50c5bb){return _0x50c5bb!=null&&(_0x1db93d['isLeafNode']()||_0x1db93d['forEachChild'](R,(_0x9130e6,_0x1ebe84)=>{_0x12bf76['hasChild'](_0x9130e6)||_0x50c5bb['trackChildChange'](Nt(_0x9130e6,_0x1ebe84));}),_0x12bf76['isLeafNode']()||_0x12bf76['forEachChild'](R,(_0x2154c4,_0x2282ad)=>{if(_0x1db93d['hasChild'](_0x2154c4)){const _0x5bc0df=_0x1db93d['getImmediateChild'](_0x2154c4);_0x5bc0df['equals'](_0x2282ad)||_0x50c5bb['trackChildChange'](Pt(_0x2154c4,_0x2282ad,_0x5bc0df));}else _0x50c5bb['trackChildChange'](tt(_0x2154c4,_0x2282ad));})),_0x12bf76['withIndex'](this['index_']);}['updatePriority'](_0x3840ca,_0x39b8cf){return _0x3840ca['isEmpty']()?g['EMPTY_NODE']:_0x3840ca['updatePriority'](_0x39b8cf);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x250f43){this['indexedFilter_']=new Yi(_0x250f43['getIndex']()),this['index_']=_0x250f43['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x250f43),this['endPost_']=Ot['getEndPost_'](_0x250f43),this['startIsInclusive_']=!_0x250f43['startAfterSet_'],this['endIsInclusive_']=!_0x250f43['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x401dd1){const _0x2626a1=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x401dd1)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x401dd1)<0x0,_0x56e445=this['endIsInclusive_']?this['index_']['compare'](_0x401dd1,this['getEndPost']())<=0x0:this['index_']['compare'](_0x401dd1,this['getEndPost']())<0x0;return _0x2626a1&&_0x56e445;}['updateChild'](_0x423325,_0x753b75,_0x50c68a,_0x53bd62,_0x16044d,_0x50a5e3){return this['matches'](new E(_0x753b75,_0x50c68a))||(_0x50c68a=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x423325,_0x753b75,_0x50c68a,_0x53bd62,_0x16044d,_0x50a5e3);}['updateFullNode'](_0x5a92f5,_0x3b9714,_0x436496){_0x3b9714['isLeafNode']()&&(_0x3b9714=g['EMPTY_NODE']);let _0x44ccae=_0x3b9714['withIndex'](this['index_']);_0x44ccae=_0x44ccae['updatePriority'](g['EMPTY_NODE']);const _0x333a8a=this;return _0x3b9714['forEachChild'](R,(_0x2f4721,_0xd60695)=>{_0x333a8a['matches'](new E(_0x2f4721,_0xd60695))||(_0x44ccae=_0x44ccae['updateImmediateChild'](_0x2f4721,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x5a92f5,_0x44ccae,_0x436496);}['updatePriority'](_0x544b60,_0x18247e){return _0x544b60;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x537637){if(_0x537637['hasStart']()){const _0x375148=_0x537637['getIndexStartName']();return _0x537637['getIndex']()['makePost'](_0x537637['getIndexStartValue'](),_0x375148);}else return _0x537637['getIndex']()['minPost']();}static['getEndPost_'](_0x5e01ff){if(_0x5e01ff['hasEnd']()){const _0x2a18a8=_0x5e01ff['getIndexEndName']();return _0x5e01ff['getIndex']()['makePost'](_0x5e01ff['getIndexEndValue'](),_0x2a18a8);}else return _0x5e01ff['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x58d371){this['withinDirectionalStart']=_0xe007ab=>this['reverse_']?this['withinEndPost'](_0xe007ab):this['withinStartPost'](_0xe007ab),this['withinDirectionalEnd']=_0x3bf593=>this['reverse_']?this['withinStartPost'](_0x3bf593):this['withinEndPost'](_0x3bf593),this['withinStartPost']=_0x18db8b=>{const _0x58615b=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x18db8b);return this['startIsInclusive_']?_0x58615b<=0x0:_0x58615b<0x0;},this['withinEndPost']=_0x1e01e7=>{const _0x157147=this['index_']['compare'](_0x1e01e7,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x157147<=0x0:_0x157147<0x0;},this['rangedFilter_']=new Ot(_0x58d371),this['index_']=_0x58d371['getIndex'](),this['limit_']=_0x58d371['getLimit'](),this['reverse_']=!_0x58d371['isViewFromLeft'](),this['startIsInclusive_']=!_0x58d371['startAfterSet_'],this['endIsInclusive_']=!_0x58d371['endBeforeSet_'];}['updateChild'](_0x40a43a,_0x2945cf,_0x1387fd,_0x295dd,_0x363f3a,_0x3f6a06){return this['rangedFilter_']['matches'](new E(_0x2945cf,_0x1387fd))||(_0x1387fd=g['EMPTY_NODE']),_0x40a43a['getImmediateChild'](_0x2945cf)['equals'](_0x1387fd)?_0x40a43a:_0x40a43a['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x40a43a,_0x2945cf,_0x1387fd,_0x295dd,_0x363f3a,_0x3f6a06):this['fullLimitUpdateChild_'](_0x40a43a,_0x2945cf,_0x1387fd,_0x363f3a,_0x3f6a06);}['updateFullNode'](_0x2ab722,_0x4c3dc2,_0x2080ef){let _0x35dbdc;if(_0x4c3dc2['isLeafNode']()||_0x4c3dc2['isEmpty']())_0x35dbdc=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x4c3dc2['numChildren']()&&_0x4c3dc2['isIndexed'](this['index_'])){_0x35dbdc=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5591cb;this['reverse_']?_0x5591cb=_0x4c3dc2['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5591cb=_0x4c3dc2['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2fcd80=0x0;for(;_0x5591cb['hasNext']()&&_0x2fcd80<this['limit_'];){const _0x111a3f=_0x5591cb['getNext']();if(this['withinDirectionalStart'](_0x111a3f)){if(this['withinDirectionalEnd'](_0x111a3f))_0x35dbdc=_0x35dbdc['updateImmediateChild'](_0x111a3f['name'],_0x111a3f['node']),_0x2fcd80++;else break;}else continue;}}else{_0x35dbdc=_0x4c3dc2['withIndex'](this['index_']),_0x35dbdc=_0x35dbdc['updatePriority'](g['EMPTY_NODE']);let _0xea9ef;this['reverse_']?_0xea9ef=_0x35dbdc['getReverseIterator'](this['index_']):_0xea9ef=_0x35dbdc['getIterator'](this['index_']);let _0x3b549e=0x0;for(;_0xea9ef['hasNext']();){const _0x2c6c1e=_0xea9ef['getNext']();_0x3b549e<this['limit_']&&this['withinDirectionalStart'](_0x2c6c1e)&&this['withinDirectionalEnd'](_0x2c6c1e)?_0x3b549e++:_0x35dbdc=_0x35dbdc['updateImmediateChild'](_0x2c6c1e['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2ab722,_0x35dbdc,_0x2080ef);}['updatePriority'](_0x28ec15,_0x4738dc){return _0x28ec15;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x4d566d,_0x12eb81,_0x37d2f8,_0x5c0196,_0x167fb7){let _0x342ae8;if(this['reverse_']){const _0x1b9b5d=this['index_']['getCompare']();_0x342ae8=(_0x17bc6a,_0x153cbb)=>_0x1b9b5d(_0x153cbb,_0x17bc6a);}else _0x342ae8=this['index_']['getCompare']();const _0x10eb0c=_0x4d566d;f(_0x10eb0c['numChildren']()===this['limit_'],'');const _0x2f9369=new E(_0x12eb81,_0x37d2f8),_0x5a27f9=this['reverse_']?_0x10eb0c['getFirstChild'](this['index_']):_0x10eb0c['getLastChild'](this['index_']),_0x592006=this['rangedFilter_']['matches'](_0x2f9369);if(_0x10eb0c['hasChild'](_0x12eb81)){const _0x493bd7=_0x10eb0c['getImmediateChild'](_0x12eb81);let _0x2c8e1c=_0x5c0196['getChildAfterChild'](this['index_'],_0x5a27f9,this['reverse_']);for(;_0x2c8e1c!=null&&(_0x2c8e1c['name']===_0x12eb81||_0x10eb0c['hasChild'](_0x2c8e1c['name']));)_0x2c8e1c=_0x5c0196['getChildAfterChild'](this['index_'],_0x2c8e1c,this['reverse_']);const _0x54768e=_0x2c8e1c==null?0x1:_0x342ae8(_0x2c8e1c,_0x2f9369);if(_0x592006&&!_0x37d2f8['isEmpty']()&&_0x54768e>=0x0)return _0x167fb7!=null&&_0x167fb7['trackChildChange'](Pt(_0x12eb81,_0x37d2f8,_0x493bd7)),_0x10eb0c['updateImmediateChild'](_0x12eb81,_0x37d2f8);{_0x167fb7!=null&&_0x167fb7['trackChildChange'](Nt(_0x12eb81,_0x493bd7));const _0x55fa66=_0x10eb0c['updateImmediateChild'](_0x12eb81,g['EMPTY_NODE']);return _0x2c8e1c!=null&&this['rangedFilter_']['matches'](_0x2c8e1c)?(_0x167fb7!=null&&_0x167fb7['trackChildChange'](tt(_0x2c8e1c['name'],_0x2c8e1c['node'])),_0x55fa66['updateImmediateChild'](_0x2c8e1c['name'],_0x2c8e1c['node'])):_0x55fa66;}}else return _0x37d2f8['isEmpty']()?_0x4d566d:_0x592006&&_0x342ae8(_0x5a27f9,_0x2f9369)>=0x0?(_0x167fb7!=null&&(_0x167fb7['trackChildChange'](Nt(_0x5a27f9['name'],_0x5a27f9['node'])),_0x167fb7['trackChildChange'](tt(_0x12eb81,_0x37d2f8))),_0x10eb0c['updateImmediateChild'](_0x12eb81,_0x37d2f8)['updateImmediateChild'](_0x5a27f9['name'],g['EMPTY_NODE'])):_0x4d566d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x13bea7=new Qi();return _0x13bea7['limitSet_']=this['limitSet_'],_0x13bea7['limit_']=this['limit_'],_0x13bea7['startSet_']=this['startSet_'],_0x13bea7['startAfterSet_']=this['startAfterSet_'],_0x13bea7['indexStartValue_']=this['indexStartValue_'],_0x13bea7['startNameSet_']=this['startNameSet_'],_0x13bea7['indexStartName_']=this['indexStartName_'],_0x13bea7['endSet_']=this['endSet_'],_0x13bea7['endBeforeSet_']=this['endBeforeSet_'],_0x13bea7['indexEndValue_']=this['indexEndValue_'],_0x13bea7['endNameSet_']=this['endNameSet_'],_0x13bea7['indexEndName_']=this['indexEndName_'],_0x13bea7['index_']=this['index_'],_0x13bea7['viewFrom_']=this['viewFrom_'],_0x13bea7;}}function qh(_0xb3cda6){return _0xb3cda6['loadsAllData']()?new Yi(_0xb3cda6['getIndex']()):_0xb3cda6['hasLimit']()?new Gh(_0xb3cda6):new Ot(_0xb3cda6);}function zh(_0x28176b,_0x131b48){const _0x34c0dc=_0x28176b['copy']();return _0x34c0dc['limitSet_']=!0x0,_0x34c0dc['limit_']=_0x131b48,_0x34c0dc['viewFrom_']='l',_0x34c0dc;}function jh(_0x3ad20b,_0x530de4,_0x48596d){const _0x378c9c=_0x3ad20b['copy']();return _0x378c9c['startSet_']=!0x0,_0x530de4===void 0x0&&(_0x530de4=null),_0x378c9c['indexStartValue_']=_0x530de4,_0x48596d!=null?(_0x378c9c['startNameSet_']=!0x0,_0x378c9c['indexStartName_']=_0x48596d):(_0x378c9c['startNameSet_']=!0x1,_0x378c9c['indexStartName_']=''),_0x378c9c;}function Kh(_0x3e4e10,_0x440bd3,_0x35e71f){const _0x314001=_0x3e4e10['copy']();return _0x314001['endSet_']=!0x0,_0x440bd3===void 0x0&&(_0x440bd3=null),_0x314001['indexEndValue_']=_0x440bd3,_0x35e71f!==void 0x0?(_0x314001['endNameSet_']=!0x0,_0x314001['indexEndName_']=_0x35e71f):(_0x314001['endNameSet_']=!0x1,_0x314001['indexEndName_']=''),_0x314001;}function Do(_0x629908,_0x2f848a){const _0x43b980=_0x629908['copy']();return _0x43b980['index_']=_0x2f848a,_0x43b980;}function tr(_0x2434f6){const _0x27dbff={};if(_0x2434f6['isDefault']())return _0x27dbff;let _0x52f5b8;if(_0x2434f6['index_']===R?_0x52f5b8='$priority':_0x2434f6['index_']===Po?_0x52f5b8='$value':_0x2434f6['index_']===ye?_0x52f5b8='$key':(f(_0x2434f6['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x52f5b8=_0x2434f6['index_']['toString']()),_0x27dbff['orderBy']=O(_0x52f5b8),_0x2434f6['startSet_']){const _0x288a1f=_0x2434f6['startAfterSet_']?'startAfter':'startAt';_0x27dbff[_0x288a1f]=O(_0x2434f6['indexStartValue_']),_0x2434f6['startNameSet_']&&(_0x27dbff[_0x288a1f]+=','+O(_0x2434f6['indexStartName_']));}if(_0x2434f6['endSet_']){const _0x48edbc=_0x2434f6['endBeforeSet_']?'endBefore':'endAt';_0x27dbff[_0x48edbc]=O(_0x2434f6['indexEndValue_']),_0x2434f6['endNameSet_']&&(_0x27dbff[_0x48edbc]+=','+O(_0x2434f6['indexEndName_']));}return _0x2434f6['limitSet_']&&(_0x2434f6['isViewFromLeft']()?_0x27dbff['limitToFirst']=_0x2434f6['limit_']:_0x27dbff['limitToLast']=_0x2434f6['limit_']),_0x27dbff;}function nr(_0xd43d9c){const _0x1b04c7={};if(_0xd43d9c['startSet_']&&(_0x1b04c7['sp']=_0xd43d9c['indexStartValue_'],_0xd43d9c['startNameSet_']&&(_0x1b04c7['sn']=_0xd43d9c['indexStartName_']),_0x1b04c7['sin']=!_0xd43d9c['startAfterSet_']),_0xd43d9c['endSet_']&&(_0x1b04c7['ep']=_0xd43d9c['indexEndValue_'],_0xd43d9c['endNameSet_']&&(_0x1b04c7['en']=_0xd43d9c['indexEndName_']),_0x1b04c7['ein']=!_0xd43d9c['endBeforeSet_']),_0xd43d9c['limitSet_']){_0x1b04c7['l']=_0xd43d9c['limit_'];let _0xae49b2=_0xd43d9c['viewFrom_'];_0xae49b2===''&&(_0xd43d9c['isViewFromLeft']()?_0xae49b2='l':_0xae49b2='r'),_0x1b04c7['vf']=_0xae49b2;}return _0xd43d9c['index_']!==R&&(_0x1b04c7['i']=_0xd43d9c['index_']['toString']()),_0x1b04c7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x4a680f){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3e51d5,_0x16b5e8){return _0x16b5e8!==void 0x0?'tag$'+_0x16b5e8:(f(_0x3e51d5['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3e51d5['_path']['toString']());}constructor(_0x4c34ae,_0x4afcd9,_0x72b49,_0x2145b6){super(),this['repoInfo_']=_0x4c34ae,this['onDataUpdate_']=_0x4afcd9,this['authTokenProvider_']=_0x72b49,this['appCheckTokenProvider_']=_0x2145b6,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x47a87f,_0x3bcbdf,_0x4ded8a,_0x117289){const _0x381fca=_0x47a87f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x381fca+'\x20'+_0x47a87f['_queryIdentifier']);const _0x2353a2=fn['getListenId_'](_0x47a87f,_0x4ded8a),_0x3c99ec={};this['listens_'][_0x2353a2]=_0x3c99ec;const _0x46abd6=tr(_0x47a87f['_queryParams']);this['restRequest_'](_0x381fca+'.json',_0x46abd6,(_0x22171d,_0x1a431a)=>{let _0x69c9d7=_0x1a431a;if(_0x22171d===0x194&&(_0x69c9d7=null,_0x22171d=null),_0x22171d===null&&this['onDataUpdate_'](_0x381fca,_0x69c9d7,!0x1,_0x4ded8a),Oe(this['listens_'],_0x2353a2)===_0x3c99ec){let _0x1faa0a;_0x22171d?_0x22171d===0x191?_0x1faa0a='permission_denied':_0x1faa0a='rest_error:'+_0x22171d:_0x1faa0a='ok',_0x117289(_0x1faa0a,null);}});}['unlisten'](_0x30646b,_0x3c52ab){const _0x238efb=fn['getListenId_'](_0x30646b,_0x3c52ab);delete this['listens_'][_0x238efb];}['get'](_0x4263b0){const _0x5f8b31=tr(_0x4263b0['_queryParams']),_0x36416f=_0x4263b0['_path']['toString'](),_0x476a79=new Ve();return this['restRequest_'](_0x36416f+'.json',_0x5f8b31,(_0x3210a1,_0x40d25f)=>{let _0x18212e=_0x40d25f;_0x3210a1===0x194&&(_0x18212e=null,_0x3210a1=null),_0x3210a1===null?(this['onDataUpdate_'](_0x36416f,_0x18212e,!0x1,null),_0x476a79['resolve'](_0x18212e)):_0x476a79['reject'](new Error(_0x18212e));}),_0x476a79['promise'];}['refreshAuthToken'](_0x37b26c){}['restRequest_'](_0x30ae18,_0x16ab5a={},_0x583750){return _0x16ab5a['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x11ceeb,_0x3127ad])=>{_0x11ceeb&&_0x11ceeb['accessToken']&&(_0x16ab5a['auth']=_0x11ceeb['accessToken']),_0x3127ad&&_0x3127ad['token']&&(_0x16ab5a['ac']=_0x3127ad['token']);const _0x553c42=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x30ae18+'?ns='+this['repoInfo_']['namespace']+at(_0x16ab5a);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x553c42);const _0x2ef15b=new XMLHttpRequest();_0x2ef15b['onreadystatechange']=()=>{if(_0x583750&&_0x2ef15b['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x553c42+'\x20received.\x20status:',_0x2ef15b['status'],'response:',_0x2ef15b['responseText']);let _0x5e37fd=null;if(_0x2ef15b['status']>=0xc8&&_0x2ef15b['status']<0x12c){try{_0x5e37fd=bt(_0x2ef15b['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x553c42+':\x20'+_0x2ef15b['responseText']);}_0x583750(null,_0x5e37fd);}else _0x2ef15b['status']!==0x191&&_0x2ef15b['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x553c42+'\x20Status:\x20'+_0x2ef15b['status']),_0x583750(_0x2ef15b['status']);_0x583750=null;}},_0x2ef15b['open']('GET',_0x553c42,!0x0),_0x2ef15b['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x40f929){return this['rootNode_']['getChild'](_0x40f929);}['updateSnapshot'](_0xa30096,_0x211264){this['rootNode_']=this['rootNode_']['updateChild'](_0xa30096,_0x211264);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x56fb36,_0x539047,_0x42b133){if(v(_0x539047))_0x56fb36['value']=_0x42b133,_0x56fb36['children']['clear']();else{if(_0x56fb36['value']!==null)_0x56fb36['value']=_0x56fb36['value']['updateChild'](_0x539047,_0x42b133);else{const _0x34ef2d=y(_0x539047);_0x56fb36['children']['has'](_0x34ef2d)||_0x56fb36['children']['set'](_0x34ef2d,pn());const _0x494e08=_0x56fb36['children']['get'](_0x34ef2d);_0x539047=b(_0x539047),Mo(_0x494e08,_0x539047,_0x42b133);}}}function Ei(_0x376e81,_0x405edf,_0x4d53fd){_0x376e81['value']!==null?_0x4d53fd(_0x405edf,_0x376e81['value']):Qh(_0x376e81,(_0x379d09,_0x5e4043)=>{const _0x2b225a=new C(_0x405edf['toString']()+'/'+_0x379d09);Ei(_0x5e4043,_0x2b225a,_0x4d53fd);});}function Qh(_0x30ee4d,_0x58a153){_0x30ee4d['children']['forEach']((_0x2d740d,_0x2f0aae)=>{_0x58a153(_0x2f0aae,_0x2d740d);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x990e36){this['collection_']=_0x990e36,this['last_']=null;}['get'](){const _0x414436=this['collection_']['get'](),_0x4850a8={..._0x414436};return this['last_']&&x(this['last_'],(_0x255776,_0x19371e)=>{_0x4850a8[_0x255776]=_0x4850a8[_0x255776]-_0x19371e;}),this['last_']=_0x414436,_0x4850a8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x4ed97a,_0x5a675b){this['server_']=_0x5a675b,this['statsToReport_']={},this['statsListener_']=new Jh(_0x4ed97a);const _0x220887=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x220887));}['reportStats_'](){const _0x2d4521=this['statsListener_']['get'](),_0x5d6c8b={};let _0x28c1b1=!0x1;x(_0x2d4521,(_0x13c4c7,_0x292b73)=>{_0x292b73>0x0&&Y(this['statsToReport_'],_0x13c4c7)&&(_0x5d6c8b[_0x13c4c7]=_0x292b73,_0x28c1b1=!0x0);}),_0x28c1b1&&this['server_']['reportStats'](_0x5d6c8b),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x839a9b){_0x839a9b[_0x839a9b['OVERWRITE']=0x0]='OVERWRITE',_0x839a9b[_0x839a9b['MERGE']=0x1]='MERGE',_0x839a9b[_0x839a9b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x839a9b[_0x839a9b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x3abce2){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x3abce2,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x381b3d,_0x23a89d,_0xf107f2){this['path']=_0x381b3d,this['affectedTree']=_0x23a89d,this['revert']=_0xf107f2,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x40739b){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x470115=this['affectedTree']['subtree'](new C(_0x40739b));return new _n(w(),_0x470115,this['revert']);}}else return f(y(this['path'])===_0x40739b,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x13edeb,_0x2df0a0){this['source']=_0x13edeb,this['path']=_0x2df0a0,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x257f0b){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x262585,_0x502466,_0x2b9633){this['source']=_0x262585,this['path']=_0x502466,this['snap']=_0x2b9633,this['type']=q['OVERWRITE'];}['operationForChild'](_0x375b37){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x375b37)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x1f6d67,_0x3c988a,_0x362f0d){this['source']=_0x1f6d67,this['path']=_0x3c988a,this['children']=_0x362f0d,this['type']=q['MERGE'];}['operationForChild'](_0xaf4274){if(v(this['path'])){const _0x28db67=this['children']['subtree'](new C(_0xaf4274));return _0x28db67['isEmpty']()?null:_0x28db67['value']?new Fe(this['source'],w(),_0x28db67['value']):new nt(this['source'],w(),_0x28db67);}else return f(y(this['path'])===_0xaf4274,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x393806,_0x484b25,_0x44d55b){this['node_']=_0x393806,this['fullyInitialized_']=_0x484b25,this['filtered_']=_0x44d55b;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x58dd3b){if(v(_0x58dd3b))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4c6d6e=y(_0x58dd3b);return this['isCompleteForChild'](_0x4c6d6e);}['isCompleteForChild'](_0x8db93b){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x8db93b);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x1cbed5){this['query_']=_0x1cbed5,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x3adb41,_0x55bc05,_0x5f3d41,_0x201641){const _0x15db28=[],_0x4264fe=[];return _0x55bc05['forEach'](_0x1788f2=>{_0x1788f2['type']==='child_changed'&&_0x3adb41['index_']['indexedValueChanged'](_0x1788f2['oldSnap'],_0x1788f2['snapshotNode'])&&_0x4264fe['push']($h(_0x1788f2['childName'],_0x1788f2['snapshotNode']));}),mt(_0x3adb41,_0x15db28,'child_removed',_0x55bc05,_0x201641,_0x5f3d41),mt(_0x3adb41,_0x15db28,'child_added',_0x55bc05,_0x201641,_0x5f3d41),mt(_0x3adb41,_0x15db28,'child_moved',_0x4264fe,_0x201641,_0x5f3d41),mt(_0x3adb41,_0x15db28,'child_changed',_0x55bc05,_0x201641,_0x5f3d41),mt(_0x3adb41,_0x15db28,'value',_0x55bc05,_0x201641,_0x5f3d41),_0x15db28;}function mt(_0x58b11b,_0x29fff2,_0x522cc2,_0x4a6370,_0x2a3581,_0x546165){const _0x4670dc=_0x4a6370['filter'](_0x4f29b3=>_0x4f29b3['type']===_0x522cc2);_0x4670dc['sort']((_0x251a17,_0x331c62)=>su(_0x58b11b,_0x251a17,_0x331c62)),_0x4670dc['forEach'](_0x3bcf25=>{const _0x2df23f=iu(_0x58b11b,_0x3bcf25,_0x546165);_0x2a3581['forEach'](_0x48704b=>{_0x48704b['respondsTo'](_0x3bcf25['type'])&&_0x29fff2['push'](_0x48704b['createEvent'](_0x2df23f,_0x58b11b['query_']));});});}function iu(_0x365ed7,_0x12ccdf,_0x4f18a7){return _0x12ccdf['type']==='value'||_0x12ccdf['type']==='child_removed'||(_0x12ccdf['prevName']=_0x4f18a7['getPredecessorChildName'](_0x12ccdf['childName'],_0x12ccdf['snapshotNode'],_0x365ed7['index_'])),_0x12ccdf;}function su(_0x4b93ab,_0x5676c3,_0x5b79f3){if(_0x5676c3['childName']==null||_0x5b79f3['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x54c932=new E(_0x5676c3['childName'],_0x5676c3['snapshotNode']),_0x1269ee=new E(_0x5b79f3['childName'],_0x5b79f3['snapshotNode']);return _0x4b93ab['index_']['compare'](_0x54c932,_0x1269ee);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x4c5fa0,_0x4954ed){return{'eventCache':_0x4c5fa0,'serverCache':_0x4954ed};}function wt(_0x5d7252,_0x30b2fe,_0x5f44e5,_0x5e1b3c){return Dn(new Ce(_0x30b2fe,_0x5f44e5,_0x5e1b3c),_0x5d7252['serverCache']);}function Lo(_0xac4f47,_0xe3ee24,_0x2e8792,_0x170455){return Dn(_0xac4f47['eventCache'],new Ce(_0xe3ee24,_0x2e8792,_0x170455));}function gn(_0x4381ac){return _0x4381ac['eventCache']['isFullyInitialized']()?_0x4381ac['eventCache']['getNode']():null;}function Ue(_0x826af9){return _0x826af9['serverCache']['isFullyInitialized']()?_0x826af9['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x14b5a5){let _0x322b0e=new S(null);return x(_0x14b5a5,(_0x23e228,_0x51541d)=>{_0x322b0e=_0x322b0e['set'](new C(_0x23e228),_0x51541d);}),_0x322b0e;}constructor(_0x29ef8e,_0x136fac=ru()){this['value']=_0x29ef8e,this['children']=_0x136fac;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3cf14c,_0x206aed){if(this['value']!=null&&_0x206aed(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3cf14c))return null;{const _0x5b7801=y(_0x3cf14c),_0x214f55=this['children']['get'](_0x5b7801);if(_0x214f55!==null){const _0x26bd55=_0x214f55['findRootMostMatchingPathAndValue'](b(_0x3cf14c),_0x206aed);return _0x26bd55!=null?{'path':A(new C(_0x5b7801),_0x26bd55['path']),'value':_0x26bd55['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x122331){return this['findRootMostMatchingPathAndValue'](_0x122331,()=>!0x0);}['subtree'](_0x50d59e){if(v(_0x50d59e))return this;{const _0x5ae39a=y(_0x50d59e),_0x3c99a2=this['children']['get'](_0x5ae39a);return _0x3c99a2!==null?_0x3c99a2['subtree'](b(_0x50d59e)):new S(null);}}['set'](_0x519c5b,_0x194e98){if(v(_0x519c5b))return new S(_0x194e98,this['children']);{const _0x15384f=y(_0x519c5b),_0xa39790=(this['children']['get'](_0x15384f)||new S(null))['set'](b(_0x519c5b),_0x194e98),_0x4ff398=this['children']['insert'](_0x15384f,_0xa39790);return new S(this['value'],_0x4ff398);}}['remove'](_0x5920b5){if(v(_0x5920b5))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x39c791=y(_0x5920b5),_0x3ce9c4=this['children']['get'](_0x39c791);if(_0x3ce9c4){const _0x25cb53=_0x3ce9c4['remove'](b(_0x5920b5));let _0x332101;return _0x25cb53['isEmpty']()?_0x332101=this['children']['remove'](_0x39c791):_0x332101=this['children']['insert'](_0x39c791,_0x25cb53),this['value']===null&&_0x332101['isEmpty']()?new S(null):new S(this['value'],_0x332101);}else return this;}}['get'](_0x2b9bf3){if(v(_0x2b9bf3))return this['value'];{const _0x74a0ab=y(_0x2b9bf3),_0x45c875=this['children']['get'](_0x74a0ab);return _0x45c875?_0x45c875['get'](b(_0x2b9bf3)):null;}}['setTree'](_0xa2c4df,_0xd7f19f){if(v(_0xa2c4df))return _0xd7f19f;{const _0x49e763=y(_0xa2c4df),_0x15f10c=(this['children']['get'](_0x49e763)||new S(null))['setTree'](b(_0xa2c4df),_0xd7f19f);let _0x1e6e65;return _0x15f10c['isEmpty']()?_0x1e6e65=this['children']['remove'](_0x49e763):_0x1e6e65=this['children']['insert'](_0x49e763,_0x15f10c),new S(this['value'],_0x1e6e65);}}['fold'](_0xa32228){return this['fold_'](w(),_0xa32228);}['fold_'](_0x4b360a,_0x3f2e95){const _0xe34f51={};return this['children']['inorderTraversal']((_0x108140,_0x1bff7e)=>{_0xe34f51[_0x108140]=_0x1bff7e['fold_'](A(_0x4b360a,_0x108140),_0x3f2e95);}),_0x3f2e95(_0x4b360a,this['value'],_0xe34f51);}['findOnPath'](_0x2f038f,_0x38ac55){return this['findOnPath_'](_0x2f038f,w(),_0x38ac55);}['findOnPath_'](_0x3e0855,_0x2634db,_0x57c917){const _0x5d9713=this['value']?_0x57c917(_0x2634db,this['value']):!0x1;if(_0x5d9713)return _0x5d9713;if(v(_0x3e0855))return null;{const _0x258c18=y(_0x3e0855),_0x13d169=this['children']['get'](_0x258c18);return _0x13d169?_0x13d169['findOnPath_'](b(_0x3e0855),A(_0x2634db,_0x258c18),_0x57c917):null;}}['foreachOnPath'](_0x3e2c03,_0x1100ea){return this['foreachOnPath_'](_0x3e2c03,w(),_0x1100ea);}['foreachOnPath_'](_0x58ee75,_0x138256,_0x146190){if(v(_0x58ee75))return this;{this['value']&&_0x146190(_0x138256,this['value']);const _0xb013db=y(_0x58ee75),_0x1a1839=this['children']['get'](_0xb013db);return _0x1a1839?_0x1a1839['foreachOnPath_'](b(_0x58ee75),A(_0x138256,_0xb013db),_0x146190):new S(null);}}['foreach'](_0x80b3f3){this['foreach_'](w(),_0x80b3f3);}['foreach_'](_0x33dbe7,_0x44a08b){this['children']['inorderTraversal']((_0x52067f,_0x36193f)=>{_0x36193f['foreach_'](A(_0x33dbe7,_0x52067f),_0x44a08b);}),this['value']&&_0x44a08b(_0x33dbe7,this['value']);}['foreachChild'](_0x5e7252){this['children']['inorderTraversal']((_0x1314b2,_0xa02b78)=>{_0xa02b78['value']&&_0x5e7252(_0x1314b2,_0xa02b78['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0xb78dd4){this['writeTree_']=_0xb78dd4;}static['empty'](){return new j(new S(null));}}function Ct(_0x1a9b30,_0x347848,_0x120624){if(v(_0x347848))return new j(new S(_0x120624));{const _0x28b1bb=_0x1a9b30['writeTree_']['findRootMostValueAndPath'](_0x347848);if(_0x28b1bb!=null){const _0x445408=_0x28b1bb['path'];let _0x542161=_0x28b1bb['value'];const _0x50f5fb=F(_0x445408,_0x347848);return _0x542161=_0x542161['updateChild'](_0x50f5fb,_0x120624),new j(_0x1a9b30['writeTree_']['set'](_0x445408,_0x542161));}else{const _0x5a7791=new S(_0x120624),_0x477b1a=_0x1a9b30['writeTree_']['setTree'](_0x347848,_0x5a7791);return new j(_0x477b1a);}}}function Ii(_0x390665,_0xf910ae,_0x331b72){let _0x536e5f=_0x390665;return x(_0x331b72,(_0x3fc34f,_0x115299)=>{_0x536e5f=Ct(_0x536e5f,A(_0xf910ae,_0x3fc34f),_0x115299);}),_0x536e5f;}function sr(_0x525803,_0x358d12){if(v(_0x358d12))return j['empty']();{const _0x1621b8=_0x525803['writeTree_']['setTree'](_0x358d12,new S(null));return new j(_0x1621b8);}}function wi(_0x2938ec,_0x49f18c){return $e(_0x2938ec,_0x49f18c)!=null;}function $e(_0xaac998,_0xc0eca3){const _0x17c844=_0xaac998['writeTree_']['findRootMostValueAndPath'](_0xc0eca3);return _0x17c844!=null?_0xaac998['writeTree_']['get'](_0x17c844['path'])['getChild'](F(_0x17c844['path'],_0xc0eca3)):null;}function rr(_0x49dc9b){const _0x72b3bb=[],_0x30f15d=_0x49dc9b['writeTree_']['value'];return _0x30f15d!=null?_0x30f15d['isLeafNode']()||_0x30f15d['forEachChild'](R,(_0x1cfbc2,_0x3c39b4)=>{_0x72b3bb['push'](new E(_0x1cfbc2,_0x3c39b4));}):_0x49dc9b['writeTree_']['children']['inorderTraversal']((_0x502df8,_0x58e7fa)=>{_0x58e7fa['value']!=null&&_0x72b3bb['push'](new E(_0x502df8,_0x58e7fa['value']));}),_0x72b3bb;}function ve(_0x42e6f0,_0x4a9f9c){if(v(_0x4a9f9c))return _0x42e6f0;{const _0x13fca5=$e(_0x42e6f0,_0x4a9f9c);return _0x13fca5!=null?new j(new S(_0x13fca5)):new j(_0x42e6f0['writeTree_']['subtree'](_0x4a9f9c));}}function Ci(_0x266a21){return _0x266a21['writeTree_']['isEmpty']();}function it(_0x27a018,_0x5f275a){return xo(w(),_0x27a018['writeTree_'],_0x5f275a);}function xo(_0x16493f,_0x44370f,_0xfc89db){if(_0x44370f['value']!=null)return _0xfc89db['updateChild'](_0x16493f,_0x44370f['value']);{let _0x1707c3=null;return _0x44370f['children']['inorderTraversal']((_0x556890,_0x37228b)=>{_0x556890==='.priority'?(f(_0x37228b['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x1707c3=_0x37228b['value']):_0xfc89db=xo(A(_0x16493f,_0x556890),_0x37228b,_0xfc89db);}),!_0xfc89db['getChild'](_0x16493f)['isEmpty']()&&_0x1707c3!==null&&(_0xfc89db=_0xfc89db['updateChild'](A(_0x16493f,'.priority'),_0x1707c3)),_0xfc89db;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x26ef93,_0x4f3012){return Bo(_0x4f3012,_0x26ef93);}function ou(_0x35c923,_0x49fdde,_0x248263,_0x302894,_0x55df13){f(_0x302894>_0x35c923['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x55df13===void 0x0&&(_0x55df13=!0x0),_0x35c923['allWrites']['push']({'path':_0x49fdde,'snap':_0x248263,'writeId':_0x302894,'visible':_0x55df13}),_0x55df13&&(_0x35c923['visibleWrites']=Ct(_0x35c923['visibleWrites'],_0x49fdde,_0x248263)),_0x35c923['lastWriteId']=_0x302894;}function au(_0x4492f1,_0x1fe9a2,_0x30ee0b,_0x300020){f(_0x300020>_0x4492f1['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4492f1['allWrites']['push']({'path':_0x1fe9a2,'children':_0x30ee0b,'writeId':_0x300020,'visible':!0x0}),_0x4492f1['visibleWrites']=Ii(_0x4492f1['visibleWrites'],_0x1fe9a2,_0x30ee0b),_0x4492f1['lastWriteId']=_0x300020;}function cu(_0x26fbad,_0x4eaac7){for(let _0x346a29=0x0;_0x346a29<_0x26fbad['allWrites']['length'];_0x346a29++){const _0x4fc63c=_0x26fbad['allWrites'][_0x346a29];if(_0x4fc63c['writeId']===_0x4eaac7)return _0x4fc63c;}return null;}function lu(_0x444a08,_0x57861f){const _0x37c066=_0x444a08['allWrites']['findIndex'](_0x3a506a=>_0x3a506a['writeId']===_0x57861f);f(_0x37c066>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x325bd4=_0x444a08['allWrites'][_0x37c066];_0x444a08['allWrites']['splice'](_0x37c066,0x1);let _0x44a1e9=_0x325bd4['visible'],_0x5bafba=!0x1,_0x5f0edd=_0x444a08['allWrites']['length']-0x1;for(;_0x44a1e9&&_0x5f0edd>=0x0;){const _0x3494a2=_0x444a08['allWrites'][_0x5f0edd];_0x3494a2['visible']&&(_0x5f0edd>=_0x37c066&&hu(_0x3494a2,_0x325bd4['path'])?_0x44a1e9=!0x1:$(_0x325bd4['path'],_0x3494a2['path'])&&(_0x5bafba=!0x0)),_0x5f0edd--;}if(_0x44a1e9){if(_0x5bafba)return uu(_0x444a08),!0x0;if(_0x325bd4['snap'])_0x444a08['visibleWrites']=sr(_0x444a08['visibleWrites'],_0x325bd4['path']);else{const _0x53984b=_0x325bd4['children'];x(_0x53984b,_0x1c13fb=>{_0x444a08['visibleWrites']=sr(_0x444a08['visibleWrites'],A(_0x325bd4['path'],_0x1c13fb));});}return!0x0;}else return!0x1;}function hu(_0x179b1b,_0x5d5dcf){if(_0x179b1b['snap'])return $(_0x179b1b['path'],_0x5d5dcf);for(const _0x106f82 in _0x179b1b['children'])if(_0x179b1b['children']['hasOwnProperty'](_0x106f82)&&$(A(_0x179b1b['path'],_0x106f82),_0x5d5dcf))return!0x0;return!0x1;}function uu(_0x910ff5){_0x910ff5['visibleWrites']=Fo(_0x910ff5['allWrites'],du,w()),_0x910ff5['allWrites']['length']>0x0?_0x910ff5['lastWriteId']=_0x910ff5['allWrites'][_0x910ff5['allWrites']['length']-0x1]['writeId']:_0x910ff5['lastWriteId']=-0x1;}function du(_0x568a16){return _0x568a16['visible'];}function Fo(_0x240fb8,_0x1c67e0,_0x1d008e){let _0x51e7c5=j['empty']();for(let _0x32ef44=0x0;_0x32ef44<_0x240fb8['length'];++_0x32ef44){const _0x2881ad=_0x240fb8[_0x32ef44];if(_0x1c67e0(_0x2881ad)){const _0x56833b=_0x2881ad['path'];let _0x419455;if(_0x2881ad['snap'])$(_0x1d008e,_0x56833b)?(_0x419455=F(_0x1d008e,_0x56833b),_0x51e7c5=Ct(_0x51e7c5,_0x419455,_0x2881ad['snap'])):$(_0x56833b,_0x1d008e)&&(_0x419455=F(_0x56833b,_0x1d008e),_0x51e7c5=Ct(_0x51e7c5,w(),_0x2881ad['snap']['getChild'](_0x419455)));else{if(_0x2881ad['children']){if($(_0x1d008e,_0x56833b))_0x419455=F(_0x1d008e,_0x56833b),_0x51e7c5=Ii(_0x51e7c5,_0x419455,_0x2881ad['children']);else{if($(_0x56833b,_0x1d008e)){if(_0x419455=F(_0x56833b,_0x1d008e),v(_0x419455))_0x51e7c5=Ii(_0x51e7c5,w(),_0x2881ad['children']);else{const _0x323873=Oe(_0x2881ad['children'],y(_0x419455));if(_0x323873){const _0x37b6e5=_0x323873['getChild'](b(_0x419455));_0x51e7c5=Ct(_0x51e7c5,w(),_0x37b6e5);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x51e7c5;}function Uo(_0x2d7ddc,_0x49a788,_0x465875,_0x423439,_0x32ffc3){if(!_0x423439&&!_0x32ffc3){const _0x384b1c=$e(_0x2d7ddc['visibleWrites'],_0x49a788);if(_0x384b1c!=null)return _0x384b1c;{const _0xc9f9ff=ve(_0x2d7ddc['visibleWrites'],_0x49a788);if(Ci(_0xc9f9ff))return _0x465875;if(_0x465875==null&&!wi(_0xc9f9ff,w()))return null;{const _0x37f3a3=_0x465875||g['EMPTY_NODE'];return it(_0xc9f9ff,_0x37f3a3);}}}else{const _0x41c8c0=ve(_0x2d7ddc['visibleWrites'],_0x49a788);if(!_0x32ffc3&&Ci(_0x41c8c0))return _0x465875;if(!_0x32ffc3&&_0x465875==null&&!wi(_0x41c8c0,w()))return null;{const _0x4e82aa=function(_0x26464f){return(_0x26464f['visible']||_0x32ffc3)&&(!_0x423439||!~_0x423439['indexOf'](_0x26464f['writeId']))&&($(_0x26464f['path'],_0x49a788)||$(_0x49a788,_0x26464f['path']));},_0x17105e=Fo(_0x2d7ddc['allWrites'],_0x4e82aa,_0x49a788),_0x40aef2=_0x465875||g['EMPTY_NODE'];return it(_0x17105e,_0x40aef2);}}}function fu(_0x30c10e,_0x339c9d,_0x5c1751){let _0x31fd97=g['EMPTY_NODE'];const _0x5b10f4=$e(_0x30c10e['visibleWrites'],_0x339c9d);if(_0x5b10f4)return _0x5b10f4['isLeafNode']()||_0x5b10f4['forEachChild'](R,(_0x5c75e7,_0x4bc3c1)=>{_0x31fd97=_0x31fd97['updateImmediateChild'](_0x5c75e7,_0x4bc3c1);}),_0x31fd97;if(_0x5c1751){const _0x29d83e=ve(_0x30c10e['visibleWrites'],_0x339c9d);return _0x5c1751['forEachChild'](R,(_0x3a0569,_0xeea02b)=>{const _0x1b695d=it(ve(_0x29d83e,new C(_0x3a0569)),_0xeea02b);_0x31fd97=_0x31fd97['updateImmediateChild'](_0x3a0569,_0x1b695d);}),rr(_0x29d83e)['forEach'](_0x19bd69=>{_0x31fd97=_0x31fd97['updateImmediateChild'](_0x19bd69['name'],_0x19bd69['node']);}),_0x31fd97;}else{const _0x2aff53=ve(_0x30c10e['visibleWrites'],_0x339c9d);return rr(_0x2aff53)['forEach'](_0x38039e=>{_0x31fd97=_0x31fd97['updateImmediateChild'](_0x38039e['name'],_0x38039e['node']);}),_0x31fd97;}}function pu(_0x571d59,_0x5401d6,_0x4121f8,_0x169a39,_0x3ad883){f(_0x169a39||_0x3ad883,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4b060c=A(_0x5401d6,_0x4121f8);if(wi(_0x571d59['visibleWrites'],_0x4b060c))return null;{const _0x3bbc92=ve(_0x571d59['visibleWrites'],_0x4b060c);return Ci(_0x3bbc92)?_0x3ad883['getChild'](_0x4121f8):it(_0x3bbc92,_0x3ad883['getChild'](_0x4121f8));}}function _u(_0x1a0f1a,_0x3b018f,_0x46b868,_0x285325){const _0x4ceed6=A(_0x3b018f,_0x46b868),_0x3531b5=$e(_0x1a0f1a['visibleWrites'],_0x4ceed6);if(_0x3531b5!=null)return _0x3531b5;if(_0x285325['isCompleteForChild'](_0x46b868)){const _0x2832da=ve(_0x1a0f1a['visibleWrites'],_0x4ceed6);return it(_0x2832da,_0x285325['getNode']()['getImmediateChild'](_0x46b868));}else return null;}function gu(_0x58da14,_0x476d2e){return $e(_0x58da14['visibleWrites'],_0x476d2e);}function mu(_0x60f8ca,_0x586ca9,_0x407c69,_0x16daa1,_0x8180c1,_0x305f5b,_0x1429b3){let _0x5b6da2;const _0x4ace32=ve(_0x60f8ca['visibleWrites'],_0x586ca9),_0x3fdaef=$e(_0x4ace32,w());if(_0x3fdaef!=null)_0x5b6da2=_0x3fdaef;else{if(_0x407c69!=null)_0x5b6da2=it(_0x4ace32,_0x407c69);else return[];}if(_0x5b6da2=_0x5b6da2['withIndex'](_0x1429b3),!_0x5b6da2['isEmpty']()&&!_0x5b6da2['isLeafNode']()){const _0x929cc=[],_0x5ac723=_0x1429b3['getCompare'](),_0xf4f635=_0x305f5b?_0x5b6da2['getReverseIteratorFrom'](_0x16daa1,_0x1429b3):_0x5b6da2['getIteratorFrom'](_0x16daa1,_0x1429b3);let _0x53f32d=_0xf4f635['getNext']();for(;_0x53f32d&&_0x929cc['length']<_0x8180c1;)_0x5ac723(_0x53f32d,_0x16daa1)!==0x0&&_0x929cc['push'](_0x53f32d),_0x53f32d=_0xf4f635['getNext']();return _0x929cc;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x3742a7,_0x21c402,_0x522e7e,_0x5d9c57){return Uo(_0x3742a7['writeTree'],_0x3742a7['treePath'],_0x21c402,_0x522e7e,_0x5d9c57);}function es(_0x16a042,_0xac5705){return fu(_0x16a042['writeTree'],_0x16a042['treePath'],_0xac5705);}function or(_0x30a1c1,_0x47d1da,_0x4f3af8,_0x330c67){return pu(_0x30a1c1['writeTree'],_0x30a1c1['treePath'],_0x47d1da,_0x4f3af8,_0x330c67);}function yn(_0x502e0f,_0x386333){return gu(_0x502e0f['writeTree'],A(_0x502e0f['treePath'],_0x386333));}function vu(_0x383616,_0x9c906f,_0x46be69,_0x45455f,_0x4b038b,_0x269755){return mu(_0x383616['writeTree'],_0x383616['treePath'],_0x9c906f,_0x46be69,_0x45455f,_0x4b038b,_0x269755);}function ts(_0x1991f6,_0x414fe0,_0x3c67d6){return _u(_0x1991f6['writeTree'],_0x1991f6['treePath'],_0x414fe0,_0x3c67d6);}function Wo(_0x328f73,_0x4f3afa){return Bo(A(_0x328f73['treePath'],_0x4f3afa),_0x328f73['writeTree']);}function Bo(_0x3794d8,_0x436553){return{'treePath':_0x3794d8,'writeTree':_0x436553};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3a4ef5){const _0x4209d7=_0x3a4ef5['type'],_0x305f3c=_0x3a4ef5['childName'];f(_0x4209d7==='child_added'||_0x4209d7==='child_changed'||_0x4209d7==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x305f3c!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x29e83a=this['changeMap']['get'](_0x305f3c);if(_0x29e83a){const _0x1f5b6d=_0x29e83a['type'];if(_0x4209d7==='child_added'&&_0x1f5b6d==='child_removed')this['changeMap']['set'](_0x305f3c,Pt(_0x305f3c,_0x3a4ef5['snapshotNode'],_0x29e83a['snapshotNode']));else{if(_0x4209d7==='child_removed'&&_0x1f5b6d==='child_added')this['changeMap']['delete'](_0x305f3c);else{if(_0x4209d7==='child_removed'&&_0x1f5b6d==='child_changed')this['changeMap']['set'](_0x305f3c,Nt(_0x305f3c,_0x29e83a['oldSnap']));else{if(_0x4209d7==='child_changed'&&_0x1f5b6d==='child_added')this['changeMap']['set'](_0x305f3c,tt(_0x305f3c,_0x3a4ef5['snapshotNode']));else{if(_0x4209d7==='child_changed'&&_0x1f5b6d==='child_changed')this['changeMap']['set'](_0x305f3c,Pt(_0x305f3c,_0x3a4ef5['snapshotNode'],_0x29e83a['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x3a4ef5+'\x20occurred\x20after\x20'+_0x29e83a);}}}}}else this['changeMap']['set'](_0x305f3c,_0x3a4ef5);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x46bffa){return null;}['getChildAfterChild'](_0x2ebe62,_0x41f84b,_0x3e1f35){return null;}}const Vo=new Iu();class ns{constructor(_0x38503c,_0x4c395b,_0xec49b6=null){this['writes_']=_0x38503c,this['viewCache_']=_0x4c395b,this['optCompleteServerCache_']=_0xec49b6;}['getCompleteChild'](_0x52c778){const _0x354a4a=this['viewCache_']['eventCache'];if(_0x354a4a['isCompleteForChild'](_0x52c778))return _0x354a4a['getNode']()['getImmediateChild'](_0x52c778);{const _0x5668b8=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x52c778,_0x5668b8);}}['getChildAfterChild'](_0x21cc36,_0x3d9cf1,_0x1a4adb){const _0x496dab=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x4f82f1=vu(this['writes_'],_0x496dab,_0x3d9cf1,0x1,_0x1a4adb,_0x21cc36);return _0x4f82f1['length']===0x0?null:_0x4f82f1[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x157e03){return{'filter':_0x157e03};}function Cu(_0x2f33c3,_0x1404cd){f(_0x1404cd['eventCache']['getNode']()['isIndexed'](_0x2f33c3['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1404cd['serverCache']['getNode']()['isIndexed'](_0x2f33c3['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x2297e3,_0x360ad7,_0x422b25,_0x1f4c9c,_0x88abcd){const _0x1af0ef=new Eu();let _0x54dcbd,_0x4a0660;if(_0x422b25['type']===q['OVERWRITE']){const _0x39a752=_0x422b25;_0x39a752['source']['fromUser']?_0x54dcbd=Ti(_0x2297e3,_0x360ad7,_0x39a752['path'],_0x39a752['snap'],_0x1f4c9c,_0x88abcd,_0x1af0ef):(f(_0x39a752['source']['fromServer'],'Unknown\x20source.'),_0x4a0660=_0x39a752['source']['tagged']||_0x360ad7['serverCache']['isFiltered']()&&!v(_0x39a752['path']),_0x54dcbd=vn(_0x2297e3,_0x360ad7,_0x39a752['path'],_0x39a752['snap'],_0x1f4c9c,_0x88abcd,_0x4a0660,_0x1af0ef));}else{if(_0x422b25['type']===q['MERGE']){const _0x5cc459=_0x422b25;_0x5cc459['source']['fromUser']?_0x54dcbd=bu(_0x2297e3,_0x360ad7,_0x5cc459['path'],_0x5cc459['children'],_0x1f4c9c,_0x88abcd,_0x1af0ef):(f(_0x5cc459['source']['fromServer'],'Unknown\x20source.'),_0x4a0660=_0x5cc459['source']['tagged']||_0x360ad7['serverCache']['isFiltered'](),_0x54dcbd=Si(_0x2297e3,_0x360ad7,_0x5cc459['path'],_0x5cc459['children'],_0x1f4c9c,_0x88abcd,_0x4a0660,_0x1af0ef));}else{if(_0x422b25['type']===q['ACK_USER_WRITE']){const _0x4fb461=_0x422b25;_0x4fb461['revert']?_0x54dcbd=ku(_0x2297e3,_0x360ad7,_0x4fb461['path'],_0x1f4c9c,_0x88abcd,_0x1af0ef):_0x54dcbd=Ru(_0x2297e3,_0x360ad7,_0x4fb461['path'],_0x4fb461['affectedTree'],_0x1f4c9c,_0x88abcd,_0x1af0ef);}else{if(_0x422b25['type']===q['LISTEN_COMPLETE'])_0x54dcbd=Au(_0x2297e3,_0x360ad7,_0x422b25['path'],_0x1f4c9c,_0x1af0ef);else throw ot('Unknown\x20operation\x20type:\x20'+_0x422b25['type']);}}}const _0x3d16f4=_0x1af0ef['getChanges']();return Su(_0x360ad7,_0x54dcbd,_0x3d16f4),{'viewCache':_0x54dcbd,'changes':_0x3d16f4};}function Su(_0x2ede50,_0x5680b5,_0x28bede){const _0xb4650a=_0x5680b5['eventCache'];if(_0xb4650a['isFullyInitialized']()){const _0x7f74cf=_0xb4650a['getNode']()['isLeafNode']()||_0xb4650a['getNode']()['isEmpty'](),_0x2d030f=gn(_0x2ede50);(_0x28bede['length']>0x0||!_0x2ede50['eventCache']['isFullyInitialized']()||_0x7f74cf&&!_0xb4650a['getNode']()['equals'](_0x2d030f)||!_0xb4650a['getNode']()['getPriority']()['equals'](_0x2d030f['getPriority']()))&&_0x28bede['push'](Oo(gn(_0x5680b5)));}}function Ho(_0x3663e6,_0x5aa37f,_0x464f61,_0x5cd80f,_0xdd350c,_0x5e192e){const _0x11b65c=_0x5aa37f['eventCache'];if(yn(_0x5cd80f,_0x464f61)!=null)return _0x5aa37f;{let _0x5c3ebe,_0xd8756f;if(v(_0x464f61)){if(f(_0x5aa37f['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5aa37f['serverCache']['isFiltered']()){const _0x1579a0=Ue(_0x5aa37f),_0x4c1b18=_0x1579a0 instanceof g?_0x1579a0:g['EMPTY_NODE'],_0x4d0360=es(_0x5cd80f,_0x4c1b18);_0x5c3ebe=_0x3663e6['filter']['updateFullNode'](_0x5aa37f['eventCache']['getNode'](),_0x4d0360,_0x5e192e);}else{const _0x2d81fb=mn(_0x5cd80f,Ue(_0x5aa37f));_0x5c3ebe=_0x3663e6['filter']['updateFullNode'](_0x5aa37f['eventCache']['getNode'](),_0x2d81fb,_0x5e192e);}}else{const _0x26a6ae=y(_0x464f61);if(_0x26a6ae==='.priority'){f(we(_0x464f61)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x700001=_0x11b65c['getNode']();_0xd8756f=_0x5aa37f['serverCache']['getNode']();const _0x2b299e=or(_0x5cd80f,_0x464f61,_0x700001,_0xd8756f);_0x2b299e!=null?_0x5c3ebe=_0x3663e6['filter']['updatePriority'](_0x700001,_0x2b299e):_0x5c3ebe=_0x11b65c['getNode']();}else{const _0x27611d=b(_0x464f61);let _0x3a45fb;if(_0x11b65c['isCompleteForChild'](_0x26a6ae)){_0xd8756f=_0x5aa37f['serverCache']['getNode']();const _0x378e07=or(_0x5cd80f,_0x464f61,_0x11b65c['getNode'](),_0xd8756f);_0x378e07!=null?_0x3a45fb=_0x11b65c['getNode']()['getImmediateChild'](_0x26a6ae)['updateChild'](_0x27611d,_0x378e07):_0x3a45fb=_0x11b65c['getNode']()['getImmediateChild'](_0x26a6ae);}else _0x3a45fb=ts(_0x5cd80f,_0x26a6ae,_0x5aa37f['serverCache']);_0x3a45fb!=null?_0x5c3ebe=_0x3663e6['filter']['updateChild'](_0x11b65c['getNode'](),_0x26a6ae,_0x3a45fb,_0x27611d,_0xdd350c,_0x5e192e):_0x5c3ebe=_0x11b65c['getNode']();}}return wt(_0x5aa37f,_0x5c3ebe,_0x11b65c['isFullyInitialized']()||v(_0x464f61),_0x3663e6['filter']['filtersNodes']());}}function vn(_0xa6ead2,_0xd4d5c5,_0x1c4311,_0x473b11,_0x4fdd4c,_0x175e2f,_0x2b9100,_0x5c129e){const _0x13519a=_0xd4d5c5['serverCache'];let _0x5acf8f;const _0x32b7da=_0x2b9100?_0xa6ead2['filter']:_0xa6ead2['filter']['getIndexedFilter']();if(v(_0x1c4311))_0x5acf8f=_0x32b7da['updateFullNode'](_0x13519a['getNode'](),_0x473b11,null);else{if(_0x32b7da['filtersNodes']()&&!_0x13519a['isFiltered']()){const _0x2d26f6=_0x13519a['getNode']()['updateChild'](_0x1c4311,_0x473b11);_0x5acf8f=_0x32b7da['updateFullNode'](_0x13519a['getNode'](),_0x2d26f6,null);}else{const _0x3b10f4=y(_0x1c4311);if(!_0x13519a['isCompleteForPath'](_0x1c4311)&&we(_0x1c4311)>0x1)return _0xd4d5c5;const _0x4dfa56=b(_0x1c4311),_0x4f8e4d=_0x13519a['getNode']()['getImmediateChild'](_0x3b10f4)['updateChild'](_0x4dfa56,_0x473b11);_0x3b10f4==='.priority'?_0x5acf8f=_0x32b7da['updatePriority'](_0x13519a['getNode'](),_0x4f8e4d):_0x5acf8f=_0x32b7da['updateChild'](_0x13519a['getNode'](),_0x3b10f4,_0x4f8e4d,_0x4dfa56,Vo,null);}}const _0x2a732f=Lo(_0xd4d5c5,_0x5acf8f,_0x13519a['isFullyInitialized']()||v(_0x1c4311),_0x32b7da['filtersNodes']()),_0x527cf3=new ns(_0x4fdd4c,_0x2a732f,_0x175e2f);return Ho(_0xa6ead2,_0x2a732f,_0x1c4311,_0x4fdd4c,_0x527cf3,_0x5c129e);}function Ti(_0x1d94cb,_0x4d501b,_0x313b03,_0x169e0d,_0x185b49,_0x29e6bc,_0x62a132){const _0x839baa=_0x4d501b['eventCache'];let _0x3f39cb,_0x1110b1;const _0x18c422=new ns(_0x185b49,_0x4d501b,_0x29e6bc);if(v(_0x313b03))_0x1110b1=_0x1d94cb['filter']['updateFullNode'](_0x4d501b['eventCache']['getNode'](),_0x169e0d,_0x62a132),_0x3f39cb=wt(_0x4d501b,_0x1110b1,!0x0,_0x1d94cb['filter']['filtersNodes']());else{const _0x16897c=y(_0x313b03);if(_0x16897c==='.priority')_0x1110b1=_0x1d94cb['filter']['updatePriority'](_0x4d501b['eventCache']['getNode'](),_0x169e0d),_0x3f39cb=wt(_0x4d501b,_0x1110b1,_0x839baa['isFullyInitialized'](),_0x839baa['isFiltered']());else{const _0x1ad4c1=b(_0x313b03),_0x2b3e89=_0x839baa['getNode']()['getImmediateChild'](_0x16897c);let _0x252528;if(v(_0x1ad4c1))_0x252528=_0x169e0d;else{const _0x34bdf8=_0x18c422['getCompleteChild'](_0x16897c);_0x34bdf8!=null?Gi(_0x1ad4c1)==='.priority'&&_0x34bdf8['getChild'](To(_0x1ad4c1))['isEmpty']()?_0x252528=_0x34bdf8:_0x252528=_0x34bdf8['updateChild'](_0x1ad4c1,_0x169e0d):_0x252528=g['EMPTY_NODE'];}if(_0x2b3e89['equals'](_0x252528))_0x3f39cb=_0x4d501b;else{const _0xa574ec=_0x1d94cb['filter']['updateChild'](_0x839baa['getNode'](),_0x16897c,_0x252528,_0x1ad4c1,_0x18c422,_0x62a132);_0x3f39cb=wt(_0x4d501b,_0xa574ec,_0x839baa['isFullyInitialized'](),_0x1d94cb['filter']['filtersNodes']());}}}return _0x3f39cb;}function ar(_0x1739fa,_0x14f0b4){return _0x1739fa['eventCache']['isCompleteForChild'](_0x14f0b4);}function bu(_0x52eaef,_0x55db9c,_0xd515cd,_0x45edf5,_0xe9d10b,_0x4e3158,_0x73d79c){let _0x47200c=_0x55db9c;return _0x45edf5['foreach']((_0x448111,_0x33facb)=>{const _0x3770d3=A(_0xd515cd,_0x448111);ar(_0x55db9c,y(_0x3770d3))&&(_0x47200c=Ti(_0x52eaef,_0x47200c,_0x3770d3,_0x33facb,_0xe9d10b,_0x4e3158,_0x73d79c));}),_0x45edf5['foreach']((_0x1e8b39,_0x45ceca)=>{const _0xaa561e=A(_0xd515cd,_0x1e8b39);ar(_0x55db9c,y(_0xaa561e))||(_0x47200c=Ti(_0x52eaef,_0x47200c,_0xaa561e,_0x45ceca,_0xe9d10b,_0x4e3158,_0x73d79c));}),_0x47200c;}function cr(_0x3512be,_0x1d0068,_0x3e219d){return _0x3e219d['foreach']((_0x4b8c1e,_0x3c7c98)=>{_0x1d0068=_0x1d0068['updateChild'](_0x4b8c1e,_0x3c7c98);}),_0x1d0068;}function Si(_0x428ccb,_0x2469f4,_0x1959a8,_0x3f6fba,_0x444a7d,_0x398a2b,_0x31c339,_0x586bcb){if(_0x2469f4['serverCache']['getNode']()['isEmpty']()&&!_0x2469f4['serverCache']['isFullyInitialized']())return _0x2469f4;let _0x351b3b=_0x2469f4,_0x595cd3;v(_0x1959a8)?_0x595cd3=_0x3f6fba:_0x595cd3=new S(null)['setTree'](_0x1959a8,_0x3f6fba);const _0x54b804=_0x2469f4['serverCache']['getNode']();return _0x595cd3['children']['inorderTraversal']((_0x5853f4,_0x2de06a)=>{if(_0x54b804['hasChild'](_0x5853f4)){const _0x97172a=_0x2469f4['serverCache']['getNode']()['getImmediateChild'](_0x5853f4),_0x5c05f1=cr(_0x428ccb,_0x97172a,_0x2de06a);_0x351b3b=vn(_0x428ccb,_0x351b3b,new C(_0x5853f4),_0x5c05f1,_0x444a7d,_0x398a2b,_0x31c339,_0x586bcb);}}),_0x595cd3['children']['inorderTraversal']((_0x2439fc,_0x3f4b35)=>{const _0xa74671=!_0x2469f4['serverCache']['isCompleteForChild'](_0x2439fc)&&_0x3f4b35['value']===null;if(!_0x54b804['hasChild'](_0x2439fc)&&!_0xa74671){const _0x46c517=_0x2469f4['serverCache']['getNode']()['getImmediateChild'](_0x2439fc),_0x59191d=cr(_0x428ccb,_0x46c517,_0x3f4b35);_0x351b3b=vn(_0x428ccb,_0x351b3b,new C(_0x2439fc),_0x59191d,_0x444a7d,_0x398a2b,_0x31c339,_0x586bcb);}}),_0x351b3b;}function Ru(_0x2173d4,_0x1a3a04,_0x50c528,_0x4f098d,_0x3c8a80,_0x17d220,_0x66509c){if(yn(_0x3c8a80,_0x50c528)!=null)return _0x1a3a04;const _0xe6086a=_0x1a3a04['serverCache']['isFiltered'](),_0x4da68e=_0x1a3a04['serverCache'];if(_0x4f098d['value']!=null){if(v(_0x50c528)&&_0x4da68e['isFullyInitialized']()||_0x4da68e['isCompleteForPath'](_0x50c528))return vn(_0x2173d4,_0x1a3a04,_0x50c528,_0x4da68e['getNode']()['getChild'](_0x50c528),_0x3c8a80,_0x17d220,_0xe6086a,_0x66509c);if(v(_0x50c528)){let _0x47fc40=new S(null);return _0x4da68e['getNode']()['forEachChild'](ye,(_0x16365b,_0x2c9d2a)=>{_0x47fc40=_0x47fc40['set'](new C(_0x16365b),_0x2c9d2a);}),Si(_0x2173d4,_0x1a3a04,_0x50c528,_0x47fc40,_0x3c8a80,_0x17d220,_0xe6086a,_0x66509c);}else return _0x1a3a04;}else{let _0x411eb2=new S(null);return _0x4f098d['foreach']((_0x818aab,_0x2f0668)=>{const _0xddb252=A(_0x50c528,_0x818aab);_0x4da68e['isCompleteForPath'](_0xddb252)&&(_0x411eb2=_0x411eb2['set'](_0x818aab,_0x4da68e['getNode']()['getChild'](_0xddb252)));}),Si(_0x2173d4,_0x1a3a04,_0x50c528,_0x411eb2,_0x3c8a80,_0x17d220,_0xe6086a,_0x66509c);}}function Au(_0x3f5358,_0x233d27,_0x1da910,_0x233cde,_0x4b8bec){const _0x2c344d=_0x233d27['serverCache'],_0x3b5bb6=Lo(_0x233d27,_0x2c344d['getNode'](),_0x2c344d['isFullyInitialized']()||v(_0x1da910),_0x2c344d['isFiltered']());return Ho(_0x3f5358,_0x3b5bb6,_0x1da910,_0x233cde,Vo,_0x4b8bec);}function ku(_0x18a8e6,_0x38d430,_0x55dc58,_0x28adb9,_0x187657,_0x5b5d4a){let _0x5b6e24;if(yn(_0x28adb9,_0x55dc58)!=null)return _0x38d430;{const _0xf334bc=new ns(_0x28adb9,_0x38d430,_0x187657),_0x4412ae=_0x38d430['eventCache']['getNode']();let _0x3caab7;if(v(_0x55dc58)||y(_0x55dc58)==='.priority'){let _0x3f526a;if(_0x38d430['serverCache']['isFullyInitialized']())_0x3f526a=mn(_0x28adb9,Ue(_0x38d430));else{const _0x1ceb5b=_0x38d430['serverCache']['getNode']();f(_0x1ceb5b instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3f526a=es(_0x28adb9,_0x1ceb5b);}_0x3f526a=_0x3f526a,_0x3caab7=_0x18a8e6['filter']['updateFullNode'](_0x4412ae,_0x3f526a,_0x5b5d4a);}else{const _0x29615a=y(_0x55dc58);let _0xf6b4b9=ts(_0x28adb9,_0x29615a,_0x38d430['serverCache']);_0xf6b4b9==null&&_0x38d430['serverCache']['isCompleteForChild'](_0x29615a)&&(_0xf6b4b9=_0x4412ae['getImmediateChild'](_0x29615a)),_0xf6b4b9!=null?_0x3caab7=_0x18a8e6['filter']['updateChild'](_0x4412ae,_0x29615a,_0xf6b4b9,b(_0x55dc58),_0xf334bc,_0x5b5d4a):_0x38d430['eventCache']['getNode']()['hasChild'](_0x29615a)?_0x3caab7=_0x18a8e6['filter']['updateChild'](_0x4412ae,_0x29615a,g['EMPTY_NODE'],b(_0x55dc58),_0xf334bc,_0x5b5d4a):_0x3caab7=_0x4412ae,_0x3caab7['isEmpty']()&&_0x38d430['serverCache']['isFullyInitialized']()&&(_0x5b6e24=mn(_0x28adb9,Ue(_0x38d430)),_0x5b6e24['isLeafNode']()&&(_0x3caab7=_0x18a8e6['filter']['updateFullNode'](_0x3caab7,_0x5b6e24,_0x5b5d4a)));}return _0x5b6e24=_0x38d430['serverCache']['isFullyInitialized']()||yn(_0x28adb9,w())!=null,wt(_0x38d430,_0x3caab7,_0x5b6e24,_0x18a8e6['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x402ed9,_0x5db658){this['query_']=_0x402ed9,this['eventRegistrations_']=[];const _0xd75eeb=this['query_']['_queryParams'],_0x53ca28=new Yi(_0xd75eeb['getIndex']()),_0x51cdb1=qh(_0xd75eeb);this['processor_']=wu(_0x51cdb1);const _0xbfd9b3=_0x5db658['serverCache'],_0x342903=_0x5db658['eventCache'],_0xf5162c=_0x53ca28['updateFullNode'](g['EMPTY_NODE'],_0xbfd9b3['getNode'](),null),_0x3cc990=_0x51cdb1['updateFullNode'](g['EMPTY_NODE'],_0x342903['getNode'](),null),_0x3b721c=new Ce(_0xf5162c,_0xbfd9b3['isFullyInitialized'](),_0x53ca28['filtersNodes']()),_0x235816=new Ce(_0x3cc990,_0x342903['isFullyInitialized'](),_0x51cdb1['filtersNodes']());this['viewCache_']=Dn(_0x235816,_0x3b721c),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x4e5f3d){return _0x4e5f3d['viewCache_']['serverCache']['getNode']();}function Ou(_0x47db38){return gn(_0x47db38['viewCache_']);}function Du(_0x19f0ee,_0x2f7bbe){const _0x2b9b3e=Ue(_0x19f0ee['viewCache_']);return _0x2b9b3e&&(_0x19f0ee['query']['_queryParams']['loadsAllData']()||!v(_0x2f7bbe)&&!_0x2b9b3e['getImmediateChild'](y(_0x2f7bbe))['isEmpty']())?_0x2b9b3e['getChild'](_0x2f7bbe):null;}function lr(_0x6bb207){return _0x6bb207['eventRegistrations_']['length']===0x0;}function Mu(_0x5cff3f,_0x51e77b){_0x5cff3f['eventRegistrations_']['push'](_0x51e77b);}function hr(_0x5e0ff1,_0x42f521,_0x2bb156){const _0x1e6d68=[];if(_0x2bb156){f(_0x42f521==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x57652b=_0x5e0ff1['query']['_path'];_0x5e0ff1['eventRegistrations_']['forEach'](_0x1460ad=>{const _0xed5a90=_0x1460ad['createCancelEvent'](_0x2bb156,_0x57652b);_0xed5a90&&_0x1e6d68['push'](_0xed5a90);});}if(_0x42f521){let _0x11a9e0=[];for(let _0x490255=0x0;_0x490255<_0x5e0ff1['eventRegistrations_']['length'];++_0x490255){const _0x231e9f=_0x5e0ff1['eventRegistrations_'][_0x490255];if(!_0x231e9f['matches'](_0x42f521))_0x11a9e0['push'](_0x231e9f);else{if(_0x42f521['hasAnyCallback']()){_0x11a9e0=_0x11a9e0['concat'](_0x5e0ff1['eventRegistrations_']['slice'](_0x490255+0x1));break;}}}_0x5e0ff1['eventRegistrations_']=_0x11a9e0;}else _0x5e0ff1['eventRegistrations_']=[];return _0x1e6d68;}function ur(_0x2908bb,_0x261e65,_0x2b87d7,_0x5037d9){_0x261e65['type']===q['MERGE']&&_0x261e65['source']['queryId']!==null&&(f(Ue(_0x2908bb['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x2908bb['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2dfc77=_0x2908bb['viewCache_'],_0x5da8a9=Tu(_0x2908bb['processor_'],_0x2dfc77,_0x261e65,_0x2b87d7,_0x5037d9);return Cu(_0x2908bb['processor_'],_0x5da8a9['viewCache']),f(_0x5da8a9['viewCache']['serverCache']['isFullyInitialized']()||!_0x2dfc77['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2908bb['viewCache_']=_0x5da8a9['viewCache'],$o(_0x2908bb,_0x5da8a9['changes'],_0x5da8a9['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x353872,_0x58b965){const _0x2fb79f=_0x353872['viewCache_']['eventCache'],_0x3bdc60=[];return _0x2fb79f['getNode']()['isLeafNode']()||_0x2fb79f['getNode']()['forEachChild'](R,(_0x5be6ff,_0x25432e)=>{_0x3bdc60['push'](tt(_0x5be6ff,_0x25432e));}),_0x2fb79f['isFullyInitialized']()&&_0x3bdc60['push'](Oo(_0x2fb79f['getNode']())),$o(_0x353872,_0x3bdc60,_0x2fb79f['getNode'](),_0x58b965);}function $o(_0x178010,_0x794cf6,_0x13a2e3,_0x3a2877){const _0x15a5ee=_0x3a2877?[_0x3a2877]:_0x178010['eventRegistrations_'];return nu(_0x178010['eventGenerator_'],_0x794cf6,_0x13a2e3,_0x15a5ee);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x1d9067){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x1d9067;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x44617a){return _0x44617a['views']['size']===0x0;}function is(_0x279695,_0x5a2fd5,_0x304a2d,_0x1413d3){const _0x1dd7de=_0x5a2fd5['source']['queryId'];if(_0x1dd7de!==null){const _0x10b79a=_0x279695['views']['get'](_0x1dd7de);return f(_0x10b79a!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x10b79a,_0x5a2fd5,_0x304a2d,_0x1413d3);}else{let _0x2a36d6=[];for(const _0x4413b0 of _0x279695['views']['values']())_0x2a36d6=_0x2a36d6['concat'](ur(_0x4413b0,_0x5a2fd5,_0x304a2d,_0x1413d3));return _0x2a36d6;}}function qo(_0x3eafae,_0x268623,_0x3eb197,_0x9d2bde,_0x2fbafc){const _0xe3222e=_0x268623['_queryIdentifier'],_0x33c780=_0x3eafae['views']['get'](_0xe3222e);if(!_0x33c780){let _0x89dc75=mn(_0x3eb197,_0x2fbafc?_0x9d2bde:null),_0x785907=!0x1;_0x89dc75?_0x785907=!0x0:_0x9d2bde instanceof g?(_0x89dc75=es(_0x3eb197,_0x9d2bde),_0x785907=!0x1):(_0x89dc75=g['EMPTY_NODE'],_0x785907=!0x1);const _0x4b5dfd=Dn(new Ce(_0x89dc75,_0x785907,!0x1),new Ce(_0x9d2bde,_0x2fbafc,!0x1));return new Nu(_0x268623,_0x4b5dfd);}return _0x33c780;}function Wu(_0x15ef3c,_0x2e2d82,_0x18e91b,_0x3ea561,_0x33e606,_0x1b199d){const _0x203b64=qo(_0x15ef3c,_0x2e2d82,_0x3ea561,_0x33e606,_0x1b199d);return _0x15ef3c['views']['has'](_0x2e2d82['_queryIdentifier'])||_0x15ef3c['views']['set'](_0x2e2d82['_queryIdentifier'],_0x203b64),Mu(_0x203b64,_0x18e91b),Lu(_0x203b64,_0x18e91b);}function Bu(_0x42f2e5,_0x439d68,_0x3f713f,_0x53a46c){const _0x1ddfde=_0x439d68['_queryIdentifier'],_0x2d80c0=[];let _0x169317=[];const _0x58e75d=Te(_0x42f2e5);if(_0x1ddfde==='default'){for(const [_0x105b5b,_0x28946f]of _0x42f2e5['views']['entries']())_0x169317=_0x169317['concat'](hr(_0x28946f,_0x3f713f,_0x53a46c)),lr(_0x28946f)&&(_0x42f2e5['views']['delete'](_0x105b5b),_0x28946f['query']['_queryParams']['loadsAllData']()||_0x2d80c0['push'](_0x28946f['query']));}else{const _0x4a1909=_0x42f2e5['views']['get'](_0x1ddfde);_0x4a1909&&(_0x169317=_0x169317['concat'](hr(_0x4a1909,_0x3f713f,_0x53a46c)),lr(_0x4a1909)&&(_0x42f2e5['views']['delete'](_0x1ddfde),_0x4a1909['query']['_queryParams']['loadsAllData']()||_0x2d80c0['push'](_0x4a1909['query'])));}return _0x58e75d&&!Te(_0x42f2e5)&&_0x2d80c0['push'](new(Fu())(_0x439d68['_repo'],_0x439d68['_path'])),{'removed':_0x2d80c0,'events':_0x169317};}function zo(_0x29e88b){const _0x5cde6d=[];for(const _0x15d089 of _0x29e88b['views']['values']())_0x15d089['query']['_queryParams']['loadsAllData']()||_0x5cde6d['push'](_0x15d089);return _0x5cde6d;}function Ee(_0x445a96,_0xb819f8){let _0x559cf9=null;for(const _0x58ef7f of _0x445a96['views']['values']())_0x559cf9=_0x559cf9||Du(_0x58ef7f,_0xb819f8);return _0x559cf9;}function jo(_0x29f2b9,_0x1e5a0c){if(_0x1e5a0c['_queryParams']['loadsAllData']())return Ln(_0x29f2b9);{const _0x27882b=_0x1e5a0c['_queryIdentifier'];return _0x29f2b9['views']['get'](_0x27882b);}}function Ko(_0x459e8a,_0x136626){return jo(_0x459e8a,_0x136626)!=null;}function Te(_0x4899ab){return Ln(_0x4899ab)!=null;}function Ln(_0x10a5d7){for(const _0x32fe72 of _0x10a5d7['views']['values']())if(_0x32fe72['query']['_queryParams']['loadsAllData']())return _0x32fe72;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x10dbe6){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x10dbe6;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x1ddc1e){this['listenProvider_']=_0x1ddc1e,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x42b690,_0x2a2b3b,_0x4f75d4,_0x270c30,_0x4bf0d7){return ou(_0x42b690['pendingWriteTree_'],_0x2a2b3b,_0x4f75d4,_0x270c30,_0x4bf0d7),_0x4bf0d7?ht(_0x42b690,new Fe(Ji(),_0x2a2b3b,_0x4f75d4)):[];}function Gu(_0x27350e,_0x4269d0,_0x8ef39a,_0x1e729b){au(_0x27350e['pendingWriteTree_'],_0x4269d0,_0x8ef39a,_0x1e729b);const _0xfeae52=S['fromObject'](_0x8ef39a);return ht(_0x27350e,new nt(Ji(),_0x4269d0,_0xfeae52));}function pe(_0x1d48b4,_0x5329d8,_0x4444f3=!0x1){const _0x4789a1=cu(_0x1d48b4['pendingWriteTree_'],_0x5329d8);if(lu(_0x1d48b4['pendingWriteTree_'],_0x5329d8)){let _0x10694c=new S(null);return _0x4789a1['snap']!=null?_0x10694c=_0x10694c['set'](w(),!0x0):x(_0x4789a1['children'],_0x371649=>{_0x10694c=_0x10694c['set'](new C(_0x371649),!0x0);}),ht(_0x1d48b4,new _n(_0x4789a1['path'],_0x10694c,_0x4444f3));}else return[];}function $t(_0x591dc9,_0x26cef1,_0x248e21){return ht(_0x591dc9,new Fe(Xi(),_0x26cef1,_0x248e21));}function qu(_0x4b4c04,_0x48c0f3,_0x5afc44){const _0x21b218=S['fromObject'](_0x5afc44);return ht(_0x4b4c04,new nt(Xi(),_0x48c0f3,_0x21b218));}function zu(_0x21c826,_0x1b3c67){return ht(_0x21c826,new Dt(Xi(),_0x1b3c67));}function ju(_0x129bdf,_0x12304d,_0x1a6d9b){const _0x479bd4=rs(_0x129bdf,_0x1a6d9b);if(_0x479bd4){const _0x5afa80=os(_0x479bd4),_0x815999=_0x5afa80['path'],_0xda61a9=_0x5afa80['queryId'],_0x432a66=F(_0x815999,_0x12304d),_0x20debd=new Dt(Zi(_0xda61a9),_0x432a66);return as(_0x129bdf,_0x815999,_0x20debd);}else return[];}function wn(_0x5ba4ac,_0x14cb99,_0x4ef27f,_0xc9a60c,_0x64571=!0x1){const _0x5cbeee=_0x14cb99['_path'],_0x53b224=_0x5ba4ac['syncPointTree_']['get'](_0x5cbeee);let _0x128d2c=[];if(_0x53b224&&(_0x14cb99['_queryIdentifier']==='default'||Ko(_0x53b224,_0x14cb99))){const _0x1261b3=Bu(_0x53b224,_0x14cb99,_0x4ef27f,_0xc9a60c);Uu(_0x53b224)&&(_0x5ba4ac['syncPointTree_']=_0x5ba4ac['syncPointTree_']['remove'](_0x5cbeee));const _0x5850e3=_0x1261b3['removed'];if(_0x128d2c=_0x1261b3['events'],!_0x64571){const _0x40256b=_0x5850e3['findIndex'](_0x2e4937=>_0x2e4937['_queryParams']['loadsAllData']())!==-0x1,_0x134d38=_0x5ba4ac['syncPointTree_']['findOnPath'](_0x5cbeee,(_0x139edc,_0x696f1a)=>Te(_0x696f1a));if(_0x40256b&&!_0x134d38){const _0x4b9cbe=_0x5ba4ac['syncPointTree_']['subtree'](_0x5cbeee);if(!_0x4b9cbe['isEmpty']()){const _0x16b50d=Qu(_0x4b9cbe);for(let _0x15984a=0x0;_0x15984a<_0x16b50d['length'];++_0x15984a){const _0x2667ff=_0x16b50d[_0x15984a],_0x30e8c7=_0x2667ff['query'],_0x132161=Xo(_0x5ba4ac,_0x2667ff);_0x5ba4ac['listenProvider_']['startListening'](Tt(_0x30e8c7),Mt(_0x5ba4ac,_0x30e8c7),_0x132161['hashFn'],_0x132161['onComplete']);}}}!_0x134d38&&_0x5850e3['length']>0x0&&!_0xc9a60c&&(_0x40256b?_0x5ba4ac['listenProvider_']['stopListening'](Tt(_0x14cb99),null):_0x5850e3['forEach'](_0x1424d8=>{const _0x3e9a83=_0x5ba4ac['queryToTagMap']['get'](Fn(_0x1424d8));_0x5ba4ac['listenProvider_']['stopListening'](Tt(_0x1424d8),_0x3e9a83);}));}Ju(_0x5ba4ac,_0x5850e3);}return _0x128d2c;}function Yo(_0x118ef9,_0x48bf73,_0x383360,_0x5afeaf){const _0x4d00c4=rs(_0x118ef9,_0x5afeaf);if(_0x4d00c4!=null){const _0x38c004=os(_0x4d00c4),_0x3dc43f=_0x38c004['path'],_0xd96002=_0x38c004['queryId'],_0x4dae34=F(_0x3dc43f,_0x48bf73),_0xa33735=new Fe(Zi(_0xd96002),_0x4dae34,_0x383360);return as(_0x118ef9,_0x3dc43f,_0xa33735);}else return[];}function Ku(_0x45dcf6,_0xeadf11,_0x202a1e,_0x5157f3){const _0x3c6368=rs(_0x45dcf6,_0x5157f3);if(_0x3c6368){const _0x1a183f=os(_0x3c6368),_0x41b305=_0x1a183f['path'],_0x1ad356=_0x1a183f['queryId'],_0x33bb6d=F(_0x41b305,_0xeadf11),_0x5adf9c=S['fromObject'](_0x202a1e),_0x24fad9=new nt(Zi(_0x1ad356),_0x33bb6d,_0x5adf9c);return as(_0x45dcf6,_0x41b305,_0x24fad9);}else return[];}function bi(_0x56ff60,_0x4cfbd4,_0x77061b,_0x542273=!0x1){const _0x5f2c06=_0x4cfbd4['_path'];let _0x4ff04e=null,_0x32b5a6=!0x1;_0x56ff60['syncPointTree_']['foreachOnPath'](_0x5f2c06,(_0x4f21c8,_0x199272)=>{const _0x4b11eb=F(_0x4f21c8,_0x5f2c06);_0x4ff04e=_0x4ff04e||Ee(_0x199272,_0x4b11eb),_0x32b5a6=_0x32b5a6||Te(_0x199272);});let _0x3e35d9=_0x56ff60['syncPointTree_']['get'](_0x5f2c06);_0x3e35d9?(_0x32b5a6=_0x32b5a6||Te(_0x3e35d9),_0x4ff04e=_0x4ff04e||Ee(_0x3e35d9,w())):(_0x3e35d9=new Go(),_0x56ff60['syncPointTree_']=_0x56ff60['syncPointTree_']['set'](_0x5f2c06,_0x3e35d9));let _0x4fa9a4;_0x4ff04e!=null?_0x4fa9a4=!0x0:(_0x4fa9a4=!0x1,_0x4ff04e=g['EMPTY_NODE'],_0x56ff60['syncPointTree_']['subtree'](_0x5f2c06)['foreachChild']((_0x1a3203,_0xd70df2)=>{const _0x324fb4=Ee(_0xd70df2,w());_0x324fb4&&(_0x4ff04e=_0x4ff04e['updateImmediateChild'](_0x1a3203,_0x324fb4));}));const _0x310518=Ko(_0x3e35d9,_0x4cfbd4);if(!_0x310518&&!_0x4cfbd4['_queryParams']['loadsAllData']()){const _0xc57f49=Fn(_0x4cfbd4);f(!_0x56ff60['queryToTagMap']['has'](_0xc57f49),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2c65d5=Xu();_0x56ff60['queryToTagMap']['set'](_0xc57f49,_0x2c65d5),_0x56ff60['tagToQueryMap']['set'](_0x2c65d5,_0xc57f49);}const _0x53332a=Mn(_0x56ff60['pendingWriteTree_'],_0x5f2c06);let _0x4c0ea9=Wu(_0x3e35d9,_0x4cfbd4,_0x77061b,_0x53332a,_0x4ff04e,_0x4fa9a4);if(!_0x310518&&!_0x32b5a6&&!_0x542273){const _0x437865=jo(_0x3e35d9,_0x4cfbd4);_0x4c0ea9=_0x4c0ea9['concat'](Zu(_0x56ff60,_0x4cfbd4,_0x437865));}return _0x4c0ea9;}function xn(_0x5eb201,_0x58618a,_0x20d4fa){const _0x1093de=_0x5eb201['pendingWriteTree_'],_0x1d13b0=_0x5eb201['syncPointTree_']['findOnPath'](_0x58618a,(_0x4db1db,_0x203d8d)=>{const _0x47b9be=F(_0x4db1db,_0x58618a),_0x2f6e56=Ee(_0x203d8d,_0x47b9be);if(_0x2f6e56)return _0x2f6e56;});return Uo(_0x1093de,_0x58618a,_0x1d13b0,_0x20d4fa,!0x0);}function Yu(_0x1ddb60,_0x5a1a44){const _0x16bfce=_0x5a1a44['_path'];let _0x526016=null;_0x1ddb60['syncPointTree_']['foreachOnPath'](_0x16bfce,(_0x2f7479,_0x3f0a18)=>{const _0xfccb9f=F(_0x2f7479,_0x16bfce);_0x526016=_0x526016||Ee(_0x3f0a18,_0xfccb9f);});let _0x102f2c=_0x1ddb60['syncPointTree_']['get'](_0x16bfce);_0x102f2c?_0x526016=_0x526016||Ee(_0x102f2c,w()):(_0x102f2c=new Go(),_0x1ddb60['syncPointTree_']=_0x1ddb60['syncPointTree_']['set'](_0x16bfce,_0x102f2c));const _0xbd8600=_0x526016!=null,_0x21d2e3=_0xbd8600?new Ce(_0x526016,!0x0,!0x1):null,_0x437421=Mn(_0x1ddb60['pendingWriteTree_'],_0x5a1a44['_path']),_0x1845ae=qo(_0x102f2c,_0x5a1a44,_0x437421,_0xbd8600?_0x21d2e3['getNode']():g['EMPTY_NODE'],_0xbd8600);return Ou(_0x1845ae);}function ht(_0x4817d5,_0x5842dc){return Qo(_0x5842dc,_0x4817d5['syncPointTree_'],null,Mn(_0x4817d5['pendingWriteTree_'],w()));}function Qo(_0xd9fbf,_0x2b5229,_0x1e24c,_0x59dd14){if(v(_0xd9fbf['path']))return Jo(_0xd9fbf,_0x2b5229,_0x1e24c,_0x59dd14);{const _0x3feca9=_0x2b5229['get'](w());_0x1e24c==null&&_0x3feca9!=null&&(_0x1e24c=Ee(_0x3feca9,w()));let _0x55d9f6=[];const _0x5c3ddf=y(_0xd9fbf['path']),_0x1597a4=_0xd9fbf['operationForChild'](_0x5c3ddf),_0x4e19e2=_0x2b5229['children']['get'](_0x5c3ddf);if(_0x4e19e2&&_0x1597a4){const _0x14c8c9=_0x1e24c?_0x1e24c['getImmediateChild'](_0x5c3ddf):null,_0x23e00a=Wo(_0x59dd14,_0x5c3ddf);_0x55d9f6=_0x55d9f6['concat'](Qo(_0x1597a4,_0x4e19e2,_0x14c8c9,_0x23e00a));}return _0x3feca9&&(_0x55d9f6=_0x55d9f6['concat'](is(_0x3feca9,_0xd9fbf,_0x59dd14,_0x1e24c))),_0x55d9f6;}}function Jo(_0x204392,_0x37c453,_0x11e44e,_0x22d277){const _0x851f12=_0x37c453['get'](w());_0x11e44e==null&&_0x851f12!=null&&(_0x11e44e=Ee(_0x851f12,w()));let _0xdc60f3=[];return _0x37c453['children']['inorderTraversal']((_0x5b17bf,_0x211855)=>{const _0x2f365e=_0x11e44e?_0x11e44e['getImmediateChild'](_0x5b17bf):null,_0x2ab6c9=Wo(_0x22d277,_0x5b17bf),_0xa4ff34=_0x204392['operationForChild'](_0x5b17bf);_0xa4ff34&&(_0xdc60f3=_0xdc60f3['concat'](Jo(_0xa4ff34,_0x211855,_0x2f365e,_0x2ab6c9)));}),_0x851f12&&(_0xdc60f3=_0xdc60f3['concat'](is(_0x851f12,_0x204392,_0x22d277,_0x11e44e))),_0xdc60f3;}function Xo(_0x188f00,_0x3de116){const _0x159172=_0x3de116['query'],_0x19b705=Mt(_0x188f00,_0x159172);return{'hashFn':()=>(Pu(_0x3de116)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x284a4f=>{if(_0x284a4f==='ok')return _0x19b705?ju(_0x188f00,_0x159172['_path'],_0x19b705):zu(_0x188f00,_0x159172['_path']);{const _0x5ac3f3=ql(_0x284a4f,_0x159172);return wn(_0x188f00,_0x159172,null,_0x5ac3f3);}}};}function Mt(_0x4a2b0e,_0x422386){const _0x55828d=Fn(_0x422386);return _0x4a2b0e['queryToTagMap']['get'](_0x55828d);}function Fn(_0xc82f75){return _0xc82f75['_path']['toString']()+'$'+_0xc82f75['_queryIdentifier'];}function rs(_0x1bb01c,_0x1f6879){return _0x1bb01c['tagToQueryMap']['get'](_0x1f6879);}function os(_0x552223){const _0x237821=_0x552223['indexOf']('$');return f(_0x237821!==-0x1&&_0x237821<_0x552223['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x552223['substr'](_0x237821+0x1),'path':new C(_0x552223['substr'](0x0,_0x237821))};}function as(_0x223ee6,_0x484769,_0x1bcbbc){const _0x1847a8=_0x223ee6['syncPointTree_']['get'](_0x484769);f(_0x1847a8,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x52a1bc=Mn(_0x223ee6['pendingWriteTree_'],_0x484769);return is(_0x1847a8,_0x1bcbbc,_0x52a1bc,null);}function Qu(_0x34c43c){return _0x34c43c['fold']((_0x105741,_0x2eaea3,_0x3f5432)=>{if(_0x2eaea3&&Te(_0x2eaea3))return[Ln(_0x2eaea3)];{let _0x461c30=[];return _0x2eaea3&&(_0x461c30=zo(_0x2eaea3)),x(_0x3f5432,(_0x5e6b8d,_0x40d8f8)=>{_0x461c30=_0x461c30['concat'](_0x40d8f8);}),_0x461c30;}});}function Tt(_0xace765){return _0xace765['_queryParams']['loadsAllData']()&&!_0xace765['_queryParams']['isDefault']()?new(Hu())(_0xace765['_repo'],_0xace765['_path']):_0xace765;}function Ju(_0x30f163,_0x4d9fa8){for(let _0x48a8c5=0x0;_0x48a8c5<_0x4d9fa8['length'];++_0x48a8c5){const _0x2c975f=_0x4d9fa8[_0x48a8c5];if(!_0x2c975f['_queryParams']['loadsAllData']()){const _0xcd352f=Fn(_0x2c975f),_0x146dbb=_0x30f163['queryToTagMap']['get'](_0xcd352f);_0x30f163['queryToTagMap']['delete'](_0xcd352f),_0x30f163['tagToQueryMap']['delete'](_0x146dbb);}}}function Xu(){return $u++;}function Zu(_0xa48cc5,_0x4887a2,_0xc72124){const _0x565ae5=_0x4887a2['_path'],_0x407af2=Mt(_0xa48cc5,_0x4887a2),_0x4d2b21=Xo(_0xa48cc5,_0xc72124),_0x48c73a=_0xa48cc5['listenProvider_']['startListening'](Tt(_0x4887a2),_0x407af2,_0x4d2b21['hashFn'],_0x4d2b21['onComplete']),_0x506327=_0xa48cc5['syncPointTree_']['subtree'](_0x565ae5);if(_0x407af2)f(!Te(_0x506327['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x4f64b4=_0x506327['fold']((_0x50d739,_0x5219ec,_0x2a5a67)=>{if(!v(_0x50d739)&&_0x5219ec&&Te(_0x5219ec))return[Ln(_0x5219ec)['query']];{let _0x122831=[];return _0x5219ec&&(_0x122831=_0x122831['concat'](zo(_0x5219ec)['map'](_0x8556a1=>_0x8556a1['query']))),x(_0x2a5a67,(_0x29611b,_0x270bda)=>{_0x122831=_0x122831['concat'](_0x270bda);}),_0x122831;}});for(let _0x2faf4a=0x0;_0x2faf4a<_0x4f64b4['length'];++_0x2faf4a){const _0x27d124=_0x4f64b4[_0x2faf4a];_0xa48cc5['listenProvider_']['stopListening'](Tt(_0x27d124),Mt(_0xa48cc5,_0x27d124));}}return _0x48c73a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x306548){this['node_']=_0x306548;}['getImmediateChild'](_0x5d1182){const _0x14cd8c=this['node_']['getImmediateChild'](_0x5d1182);return new cs(_0x14cd8c);}['node'](){return this['node_'];}}class ls{constructor(_0xabe42e,_0x26bdd6){this['syncTree_']=_0xabe42e,this['path_']=_0x26bdd6;}['getImmediateChild'](_0x1b4d7f){const _0x16fd76=A(this['path_'],_0x1b4d7f);return new ls(this['syncTree_'],_0x16fd76);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x106b54){return _0x106b54=_0x106b54||{},_0x106b54['timestamp']=_0x106b54['timestamp']||new Date()['getTime'](),_0x106b54;},fr=function(_0x4efdcb,_0x35854d,_0x149f95){if(!_0x4efdcb||typeof _0x4efdcb!='object')return _0x4efdcb;if(f('.sv'in _0x4efdcb,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4efdcb['.sv']=='string')return td(_0x4efdcb['.sv'],_0x35854d,_0x149f95);if(typeof _0x4efdcb['.sv']=='object')return nd(_0x4efdcb['.sv'],_0x35854d);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4efdcb,null,0x2));},td=function(_0x47a9d2,_0x1edc77,_0x383fa6){switch(_0x47a9d2){case'timestamp':return _0x383fa6['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x47a9d2);}},nd=function(_0x9c8827,_0x2656a2,_0x4ef1f3){_0x9c8827['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x9c8827,null,0x2));const _0x199e02=_0x9c8827['increment'];typeof _0x199e02!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x199e02);const _0x3f1fd9=_0x2656a2['node']();if(f(_0x3f1fd9!==null&&typeof _0x3f1fd9<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x3f1fd9['isLeafNode']())return _0x199e02;const _0x2988f4=_0x3f1fd9['getValue']();return typeof _0x2988f4!='number'?_0x199e02:_0x2988f4+_0x199e02;},Zo=function(_0x36a753,_0x14bb97,_0x3ebb38,_0x3c7966){return us(_0x14bb97,new ls(_0x3ebb38,_0x36a753),_0x3c7966);},hs=function(_0x3c950c,_0x46c7ca,_0x53a1d6){return us(_0x3c950c,new cs(_0x46c7ca),_0x53a1d6);};function us(_0x926038,_0x3ced69,_0x1898de){const _0x5837b8=_0x926038['getPriority']()['val'](),_0x557097=fr(_0x5837b8,_0x3ced69['getImmediateChild']('.priority'),_0x1898de);let _0x3b5464;if(_0x926038['isLeafNode']()){const _0x194840=_0x926038,_0x26e449=fr(_0x194840['getValue'](),_0x3ced69,_0x1898de);return _0x26e449!==_0x194840['getValue']()||_0x557097!==_0x194840['getPriority']()['val']()?new D(_0x26e449,N(_0x557097)):_0x926038;}else{const _0x34b74e=_0x926038;return _0x3b5464=_0x34b74e,_0x557097!==_0x34b74e['getPriority']()['val']()&&(_0x3b5464=_0x3b5464['updatePriority'](new D(_0x557097))),_0x34b74e['forEachChild'](R,(_0xc80489,_0x42b8a6)=>{const _0x4d5300=us(_0x42b8a6,_0x3ced69['getImmediateChild'](_0xc80489),_0x1898de);_0x4d5300!==_0x42b8a6&&(_0x3b5464=_0x3b5464['updateImmediateChild'](_0xc80489,_0x4d5300));}),_0x3b5464;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x338600='',_0x406e4f=null,_0x4d4d61={'children':{},'childCount':0x0}){this['name']=_0x338600,this['parent']=_0x406e4f,this['node']=_0x4d4d61;}}function Un(_0xac8b1b,_0x10e955){let _0x26080c=_0x10e955 instanceof C?_0x10e955:new C(_0x10e955),_0x242155=_0xac8b1b,_0x3fdf1a=y(_0x26080c);for(;_0x3fdf1a!==null;){const _0x563f29=Oe(_0x242155['node']['children'],_0x3fdf1a)||{'children':{},'childCount':0x0};_0x242155=new ds(_0x3fdf1a,_0x242155,_0x563f29),_0x26080c=b(_0x26080c),_0x3fdf1a=y(_0x26080c);}return _0x242155;}function Ge(_0x52a852){return _0x52a852['node']['value'];}function fs(_0x274332,_0x4e4b08){_0x274332['node']['value']=_0x4e4b08,Ri(_0x274332);}function ea(_0x26c2db){return _0x26c2db['node']['childCount']>0x0;}function id(_0x2a8bd0){return Ge(_0x2a8bd0)===void 0x0&&!ea(_0x2a8bd0);}function Wn(_0x2914f9,_0x422e70){x(_0x2914f9['node']['children'],(_0x13ff63,_0x1d99ed)=>{_0x422e70(new ds(_0x13ff63,_0x2914f9,_0x1d99ed));});}function ta(_0x8475ed,_0x51834a,_0x37e7c6,_0x1fbb23){_0x37e7c6&&_0x51834a(_0x8475ed),Wn(_0x8475ed,_0x40fd73=>{ta(_0x40fd73,_0x51834a,!0x0);});}function sd(_0x112c19,_0x35f5d5,_0x202d01){let _0x22908b=_0x112c19['parent'];for(;_0x22908b!==null;){if(_0x35f5d5(_0x22908b))return!0x0;_0x22908b=_0x22908b['parent'];}return!0x1;}function Gt(_0x30b779){return new C(_0x30b779['parent']===null?_0x30b779['name']:Gt(_0x30b779['parent'])+'/'+_0x30b779['name']);}function Ri(_0x351c23){_0x351c23['parent']!==null&&rd(_0x351c23['parent'],_0x351c23['name'],_0x351c23);}function rd(_0x49634f,_0x57317f,_0x5360bc){const _0x2d3454=id(_0x5360bc),_0x4ed63d=Y(_0x49634f['node']['children'],_0x57317f);_0x2d3454&&_0x4ed63d?(delete _0x49634f['node']['children'][_0x57317f],_0x49634f['node']['childCount']--,Ri(_0x49634f)):!_0x2d3454&&!_0x4ed63d&&(_0x49634f['node']['children'][_0x57317f]=_0x5360bc['node'],_0x49634f['node']['childCount']++,Ri(_0x49634f));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x237c2a){return typeof _0x237c2a=='string'&&_0x237c2a['length']!==0x0&&!od['test'](_0x237c2a);},na=function(_0x446e3f){return typeof _0x446e3f=='string'&&_0x446e3f['length']!==0x0&&!ad['test'](_0x446e3f);},cd=function(_0x362600){return _0x362600&&(_0x362600=_0x362600['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x362600);},Cn=function(_0x298a66){return _0x298a66===null||typeof _0x298a66=='string'||typeof _0x298a66=='number'&&!Wi(_0x298a66)||_0x298a66&&typeof _0x298a66=='object'&&Y(_0x298a66,'.sv');},qt=function(_0x15013e,_0x54dfa3,_0x4d2973,_0x300efc){_0x300efc&&_0x54dfa3===void 0x0||zt(Nn(_0x15013e,'value'),_0x54dfa3,_0x4d2973);},zt=function(_0x2f5ef2,_0x1f0325,_0x151737){const _0x26cdef=_0x151737 instanceof C?new Sh(_0x151737,_0x2f5ef2):_0x151737;if(_0x1f0325===void 0x0)throw new Error(_0x2f5ef2+'contains\x20undefined\x20'+Ne(_0x26cdef));if(typeof _0x1f0325=='function')throw new Error(_0x2f5ef2+'contains\x20a\x20function\x20'+Ne(_0x26cdef)+'\x20with\x20contents\x20=\x20'+_0x1f0325['toString']());if(Wi(_0x1f0325))throw new Error(_0x2f5ef2+'contains\x20'+_0x1f0325['toString']()+'\x20'+Ne(_0x26cdef));if(typeof _0x1f0325=='string'&&_0x1f0325['length']>oi/0x3&&Pn(_0x1f0325)>oi)throw new Error(_0x2f5ef2+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x26cdef)+'\x20(\x27'+_0x1f0325['substring'](0x0,0x32)+'...\x27)');if(_0x1f0325&&typeof _0x1f0325=='object'){let _0x4f8059=!0x1,_0x36d493=!0x1;if(x(_0x1f0325,(_0x1addd2,_0x48b4e0)=>{if(_0x1addd2==='.value')_0x4f8059=!0x0;else{if(_0x1addd2!=='.priority'&&_0x1addd2!=='.sv'&&(_0x36d493=!0x0,!ps(_0x1addd2)))throw new Error(_0x2f5ef2+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1addd2+')\x20'+Ne(_0x26cdef)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x26cdef,_0x1addd2),zt(_0x2f5ef2,_0x48b4e0,_0x26cdef),Rh(_0x26cdef);}),_0x4f8059&&_0x36d493)throw new Error(_0x2f5ef2+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x26cdef)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x39b927,_0x5ed40f){let _0x4a6275,_0x552d6d;for(_0x4a6275=0x0;_0x4a6275<_0x5ed40f['length'];_0x4a6275++){_0x552d6d=_0x5ed40f[_0x4a6275];const _0x1887bd=kt(_0x552d6d);for(let _0x1af7d2=0x0;_0x1af7d2<_0x1887bd['length'];_0x1af7d2++)if(!(_0x1887bd[_0x1af7d2]==='.priority'&&_0x1af7d2===_0x1887bd['length']-0x1)){if(!ps(_0x1887bd[_0x1af7d2]))throw new Error(_0x39b927+'contains\x20an\x20invalid\x20key\x20('+_0x1887bd[_0x1af7d2]+')\x20in\x20path\x20'+_0x552d6d['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5ed40f['sort'](Th);let _0x659a1b=null;for(_0x4a6275=0x0;_0x4a6275<_0x5ed40f['length'];_0x4a6275++){if(_0x552d6d=_0x5ed40f[_0x4a6275],_0x659a1b!==null&&$(_0x659a1b,_0x552d6d))throw new Error(_0x39b927+'contains\x20a\x20path\x20'+_0x659a1b['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x552d6d['toString']());_0x659a1b=_0x552d6d;}},hd=function(_0x1464ff,_0x20b212,_0x40f0d7,_0x13f790){const _0x31c84b=Nn(_0x1464ff,'values');if(!(_0x20b212&&typeof _0x20b212=='object')||Array['isArray'](_0x20b212))throw new Error(_0x31c84b+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4b2227=[];x(_0x20b212,(_0x53d722,_0x57a45e)=>{const _0x55c9f1=new C(_0x53d722);if(zt(_0x31c84b,_0x57a45e,A(_0x40f0d7,_0x55c9f1)),Gi(_0x55c9f1)==='.priority'&&!Cn(_0x57a45e))throw new Error(_0x31c84b+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x55c9f1['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4b2227['push'](_0x55c9f1);}),ld(_0x31c84b,_0x4b2227);},_s=function(_0x4c1998,_0x52ab96,_0x58f43f,_0x252762){if(!na(_0x58f43f))throw new Error(Nn(_0x4c1998,_0x52ab96)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x58f43f+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x1bd4a9,_0x2c1204,_0x39f498,_0x2d985e){_0x39f498&&(_0x39f498=_0x39f498['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x1bd4a9,_0x2c1204,_0x39f498);},gs=function(_0x3a2ab2,_0x139081){if(y(_0x139081)==='.info')throw new Error(_0x3a2ab2+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x32eafe,_0x44d045){const _0x2fece8=_0x44d045['path']['toString']();if(typeof _0x44d045['repoInfo']['host']!='string'||_0x44d045['repoInfo']['host']['length']===0x0||!ps(_0x44d045['repoInfo']['namespace'])&&_0x44d045['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2fece8['length']!==0x0&&!cd(_0x2fece8))throw new Error(Nn(_0x32eafe,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x350c54,_0x498824){let _0x1f639d=null;for(let _0x13cbcd=0x0;_0x13cbcd<_0x498824['length'];_0x13cbcd++){const _0x3b1c2c=_0x498824[_0x13cbcd],_0x2f9b5e=_0x3b1c2c['getPath']();_0x1f639d!==null&&!qi(_0x2f9b5e,_0x1f639d['path'])&&(_0x350c54['eventLists_']['push'](_0x1f639d),_0x1f639d=null),_0x1f639d===null&&(_0x1f639d={'events':[],'path':_0x2f9b5e}),_0x1f639d['events']['push'](_0x3b1c2c);}_0x1f639d&&_0x350c54['eventLists_']['push'](_0x1f639d);}function ia(_0x443fc6,_0x1b6c55,_0x184032){Bn(_0x443fc6,_0x184032),sa(_0x443fc6,_0x3edc5b=>qi(_0x3edc5b,_0x1b6c55));}function V(_0x33c1f0,_0x45d069,_0x38ef5e){Bn(_0x33c1f0,_0x38ef5e),sa(_0x33c1f0,_0x528e1a=>$(_0x528e1a,_0x45d069)||$(_0x45d069,_0x528e1a));}function sa(_0x2a7a56,_0x4e4844){_0x2a7a56['recursionDepth_']++;let _0x3b0c39=!0x0;for(let _0x21f6d1=0x0;_0x21f6d1<_0x2a7a56['eventLists_']['length'];_0x21f6d1++){const _0xec8a72=_0x2a7a56['eventLists_'][_0x21f6d1];if(_0xec8a72){const _0x4c7442=_0xec8a72['path'];_0x4e4844(_0x4c7442)?(pd(_0x2a7a56['eventLists_'][_0x21f6d1]),_0x2a7a56['eventLists_'][_0x21f6d1]=null):_0x3b0c39=!0x1;}}_0x3b0c39&&(_0x2a7a56['eventLists_']=[]),_0x2a7a56['recursionDepth_']--;}function pd(_0x40f5fc){for(let _0x5eeb95=0x0;_0x5eeb95<_0x40f5fc['events']['length'];_0x5eeb95++){const _0xb9e5bb=_0x40f5fc['events'][_0x5eeb95];if(_0xb9e5bb!==null){_0x40f5fc['events'][_0x5eeb95]=null;const _0xa692ba=_0xb9e5bb['getEventRunner']();Et&&L('event:\x20'+_0xb9e5bb['toString']()),lt(_0xa692ba);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x31ebcf,_0x3ae1b5,_0x11c530,_0x21c019){this['repoInfo_']=_0x31ebcf,this['forceRestClient_']=_0x3ae1b5,this['authTokenProvider_']=_0x11c530,this['appCheckProvider_']=_0x21c019,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x2189eb,_0x4e1b0e,_0x32aa4c){if(_0x2189eb['stats_']=Hi(_0x2189eb['repoInfo_']),_0x2189eb['forceRestClient_']||Yl())_0x2189eb['server_']=new fn(_0x2189eb['repoInfo_'],(_0x39ddf8,_0x103b30,_0xfcf950,_0x47a98f)=>{pr(_0x2189eb,_0x39ddf8,_0x103b30,_0xfcf950,_0x47a98f);},_0x2189eb['authTokenProvider_'],_0x2189eb['appCheckProvider_']),setTimeout(()=>_r(_0x2189eb,!0x0),0x0);else{if(typeof _0x32aa4c<'u'&&_0x32aa4c!==null){if(typeof _0x32aa4c!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x32aa4c);}catch(_0x562c13){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x562c13);}}_0x2189eb['persistentConnection_']=new ie(_0x2189eb['repoInfo_'],_0x4e1b0e,(_0x44c9d9,_0x2ece90,_0x19fc71,_0x45312f)=>{pr(_0x2189eb,_0x44c9d9,_0x2ece90,_0x19fc71,_0x45312f);},_0xde4204=>{_r(_0x2189eb,_0xde4204);},_0x40aa2e=>{yd(_0x2189eb,_0x40aa2e);},_0x2189eb['authTokenProvider_'],_0x2189eb['appCheckProvider_'],_0x32aa4c),_0x2189eb['server_']=_0x2189eb['persistentConnection_'];}_0x2189eb['authTokenProvider_']['addTokenChangeListener'](_0x2d6bd6=>{_0x2189eb['server_']['refreshAuthToken'](_0x2d6bd6);}),_0x2189eb['appCheckProvider_']['addTokenChangeListener'](_0x294bbc=>{_0x2189eb['server_']['refreshAppCheckToken'](_0x294bbc['token']);}),_0x2189eb['statsReporter_']=eh(_0x2189eb['repoInfo_'],()=>new eu(_0x2189eb['stats_'],_0x2189eb['server_'])),_0x2189eb['infoData_']=new Yh(),_0x2189eb['infoSyncTree_']=new dr({'startListening':(_0x545ced,_0x379cc9,_0x1f5011,_0x1a0798)=>{let _0x352557=[];const _0x2b48b4=_0x2189eb['infoData_']['getNode'](_0x545ced['_path']);return _0x2b48b4['isEmpty']()||(_0x352557=$t(_0x2189eb['infoSyncTree_'],_0x545ced['_path'],_0x2b48b4),setTimeout(()=>{_0x1a0798('ok');},0x0)),_0x352557;},'stopListening':()=>{}}),ms(_0x2189eb,'connected',!0x1),_0x2189eb['serverSyncTree_']=new dr({'startListening':(_0x77220d,_0x2536e5,_0x5a9075,_0x15b4f6)=>(_0x2189eb['server_']['listen'](_0x77220d,_0x5a9075,_0x2536e5,(_0x13291f,_0x296898)=>{const _0x2d6b91=_0x15b4f6(_0x13291f,_0x296898);V(_0x2189eb['eventQueue_'],_0x77220d['_path'],_0x2d6b91);}),[]),'stopListening':(_0x17a586,_0x4e7e71)=>{_0x2189eb['server_']['unlisten'](_0x17a586,_0x4e7e71);}});}function oa(_0x4ecb5a){const _0x55fa61=_0x4ecb5a['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x55fa61;}function jt(_0x4ce0dc){return ed({'timestamp':oa(_0x4ce0dc)});}function pr(_0x2399bc,_0x1187f1,_0x5a614b,_0x1934b7,_0x4fb53e){_0x2399bc['dataUpdateCount']++;const _0x395e82=new C(_0x1187f1);_0x5a614b=_0x2399bc['interceptServerDataCallback_']?_0x2399bc['interceptServerDataCallback_'](_0x1187f1,_0x5a614b):_0x5a614b;let _0xb9914c=[];if(_0x4fb53e){if(_0x1934b7){const _0xcc380b=ln(_0x5a614b,_0x41d4fc=>N(_0x41d4fc));_0xb9914c=Ku(_0x2399bc['serverSyncTree_'],_0x395e82,_0xcc380b,_0x4fb53e);}else{const _0x3aa8da=N(_0x5a614b);_0xb9914c=Yo(_0x2399bc['serverSyncTree_'],_0x395e82,_0x3aa8da,_0x4fb53e);}}else{if(_0x1934b7){const _0x309398=ln(_0x5a614b,_0x12d4a4=>N(_0x12d4a4));_0xb9914c=qu(_0x2399bc['serverSyncTree_'],_0x395e82,_0x309398);}else{const _0x55cc1e=N(_0x5a614b);_0xb9914c=$t(_0x2399bc['serverSyncTree_'],_0x395e82,_0x55cc1e);}}let _0x4d3705=_0x395e82;_0xb9914c['length']>0x0&&(_0x4d3705=st(_0x2399bc,_0x395e82)),V(_0x2399bc['eventQueue_'],_0x4d3705,_0xb9914c);}function _r(_0x175d8b,_0x5aba6d){ms(_0x175d8b,'connected',_0x5aba6d),_0x5aba6d===!0x1&&wd(_0x175d8b);}function yd(_0x14951b,_0x370cad){x(_0x370cad,(_0x1567a8,_0x39014a)=>{ms(_0x14951b,_0x1567a8,_0x39014a);});}function ms(_0x220b11,_0x49bf40,_0x46a94a){const _0x559ba3=new C('/.info/'+_0x49bf40),_0x259115=N(_0x46a94a);_0x220b11['infoData_']['updateSnapshot'](_0x559ba3,_0x259115);const _0xdfbace=$t(_0x220b11['infoSyncTree_'],_0x559ba3,_0x259115);V(_0x220b11['eventQueue_'],_0x559ba3,_0xdfbace);}function Vn(_0x55cdbd){return _0x55cdbd['nextWriteId_']++;}function vd(_0x28ee4f,_0x3d4f80,_0x2777d9){const _0x2a1b2f=Yu(_0x28ee4f['serverSyncTree_'],_0x3d4f80);return _0x2a1b2f!=null?Promise['resolve'](_0x2a1b2f):_0x28ee4f['server_']['get'](_0x3d4f80)['then'](_0x9fc49d=>{const _0x3b2b38=N(_0x9fc49d)['withIndex'](_0x3d4f80['_queryParams']['getIndex']());bi(_0x28ee4f['serverSyncTree_'],_0x3d4f80,_0x2777d9,!0x0);let _0x139309;if(_0x3d4f80['_queryParams']['loadsAllData']())_0x139309=$t(_0x28ee4f['serverSyncTree_'],_0x3d4f80['_path'],_0x3b2b38);else{const _0x2414ab=Mt(_0x28ee4f['serverSyncTree_'],_0x3d4f80);_0x139309=Yo(_0x28ee4f['serverSyncTree_'],_0x3d4f80['_path'],_0x3b2b38,_0x2414ab);}return V(_0x28ee4f['eventQueue_'],_0x3d4f80['_path'],_0x139309),wn(_0x28ee4f['serverSyncTree_'],_0x3d4f80,_0x2777d9,null,!0x0),_0x3b2b38;},_0xe1dc6=>(ut(_0x28ee4f,'get\x20for\x20query\x20'+O(_0x3d4f80)+'\x20failed:\x20'+_0xe1dc6),Promise['reject'](new Error(_0xe1dc6))));}function Ed(_0x2236b4,_0x59642a,_0xce7eeb,_0x22acc6,_0x548dfc){ut(_0x2236b4,'set',{'path':_0x59642a['toString'](),'value':_0xce7eeb,'priority':_0x22acc6});const _0x372ab1=jt(_0x2236b4),_0x286615=N(_0xce7eeb,_0x22acc6),_0x1cb215=xn(_0x2236b4['serverSyncTree_'],_0x59642a),_0x151973=hs(_0x286615,_0x1cb215,_0x372ab1),_0x231271=Vn(_0x2236b4),_0x2592e7=ss(_0x2236b4['serverSyncTree_'],_0x59642a,_0x151973,_0x231271,!0x0);Bn(_0x2236b4['eventQueue_'],_0x2592e7),_0x2236b4['server_']['put'](_0x59642a['toString'](),_0x286615['val'](!0x0),(_0x4afe4b,_0x528c42)=>{const _0xa73079=_0x4afe4b==='ok';_0xa73079||U('set\x20at\x20'+_0x59642a+'\x20failed:\x20'+_0x4afe4b);const _0x4695bd=pe(_0x2236b4['serverSyncTree_'],_0x231271,!_0xa73079);V(_0x2236b4['eventQueue_'],_0x59642a,_0x4695bd),Ai(_0x2236b4,_0x548dfc,_0x4afe4b,_0x528c42);});const _0x32c700=vs(_0x2236b4,_0x59642a);st(_0x2236b4,_0x32c700),V(_0x2236b4['eventQueue_'],_0x32c700,[]);}function Id(_0x13685a,_0x2ef870,_0x53cf75,_0x5b6396){ut(_0x13685a,'update',{'path':_0x2ef870['toString'](),'value':_0x53cf75});let _0x9347a=!0x0;const _0x31ed20=jt(_0x13685a),_0x5e6b6c={};if(x(_0x53cf75,(_0x8f9a9c,_0x3cd7e5)=>{_0x9347a=!0x1,_0x5e6b6c[_0x8f9a9c]=Zo(A(_0x2ef870,_0x8f9a9c),N(_0x3cd7e5),_0x13685a['serverSyncTree_'],_0x31ed20);}),_0x9347a)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x13685a,_0x5b6396,'ok',void 0x0);else{const _0x21ebd9=Vn(_0x13685a),_0x413020=Gu(_0x13685a['serverSyncTree_'],_0x2ef870,_0x5e6b6c,_0x21ebd9);Bn(_0x13685a['eventQueue_'],_0x413020),_0x13685a['server_']['merge'](_0x2ef870['toString'](),_0x53cf75,(_0x4b66c4,_0x3103ed)=>{const _0xe9b592=_0x4b66c4==='ok';_0xe9b592||U('update\x20at\x20'+_0x2ef870+'\x20failed:\x20'+_0x4b66c4);const _0x1260b3=pe(_0x13685a['serverSyncTree_'],_0x21ebd9,!_0xe9b592),_0x4d1b38=_0x1260b3['length']>0x0?st(_0x13685a,_0x2ef870):_0x2ef870;V(_0x13685a['eventQueue_'],_0x4d1b38,_0x1260b3),Ai(_0x13685a,_0x5b6396,_0x4b66c4,_0x3103ed);}),x(_0x53cf75,_0x2f5c2e=>{const _0x18966b=vs(_0x13685a,A(_0x2ef870,_0x2f5c2e));st(_0x13685a,_0x18966b);}),V(_0x13685a['eventQueue_'],_0x2ef870,[]);}}function wd(_0x2499a5){ut(_0x2499a5,'onDisconnectEvents');const _0x1a2df3=jt(_0x2499a5),_0x165c1a=pn();Ei(_0x2499a5['onDisconnect_'],w(),(_0x13092d,_0x537f3f)=>{const _0x2c6712=Zo(_0x13092d,_0x537f3f,_0x2499a5['serverSyncTree_'],_0x1a2df3);Mo(_0x165c1a,_0x13092d,_0x2c6712);});let _0x40ff00=[];Ei(_0x165c1a,w(),(_0x4746fd,_0x1acade)=>{_0x40ff00=_0x40ff00['concat']($t(_0x2499a5['serverSyncTree_'],_0x4746fd,_0x1acade));const _0x4001f2=vs(_0x2499a5,_0x4746fd);st(_0x2499a5,_0x4001f2);}),_0x2499a5['onDisconnect_']=pn(),V(_0x2499a5['eventQueue_'],w(),_0x40ff00);}function Cd(_0x2f5f08,_0x37b325,_0x2bc06c){let _0x34bfc9;y(_0x37b325['_path'])==='.info'?_0x34bfc9=bi(_0x2f5f08['infoSyncTree_'],_0x37b325,_0x2bc06c):_0x34bfc9=bi(_0x2f5f08['serverSyncTree_'],_0x37b325,_0x2bc06c),ia(_0x2f5f08['eventQueue_'],_0x37b325['_path'],_0x34bfc9);}function Td(_0xd07048,_0x586821,_0x557a7c){let _0x5420b3;y(_0x586821['_path'])==='.info'?_0x5420b3=wn(_0xd07048['infoSyncTree_'],_0x586821,_0x557a7c):_0x5420b3=wn(_0xd07048['serverSyncTree_'],_0x586821,_0x557a7c),ia(_0xd07048['eventQueue_'],_0x586821['_path'],_0x5420b3);}function aa(_0x5d63d6){_0x5d63d6['persistentConnection_']&&_0x5d63d6['persistentConnection_']['interrupt'](ra);}function Sd(_0x2864af){_0x2864af['persistentConnection_']&&_0x2864af['persistentConnection_']['resume'](ra);}function ut(_0x548015,..._0xbf00b1){let _0x397092='';_0x548015['persistentConnection_']&&(_0x397092=_0x548015['persistentConnection_']['id']+':'),L(_0x397092,..._0xbf00b1);}function Ai(_0x911017,_0x210e40,_0xfcdbcc,_0x1e9b12){_0x210e40&&lt(()=>{if(_0xfcdbcc==='ok')_0x210e40(null);else{const _0x2e70a5=(_0xfcdbcc||'error')['toUpperCase']();let _0x1df5b1=_0x2e70a5;_0x1e9b12&&(_0x1df5b1+=':\x20'+_0x1e9b12);const _0x2ea976=new Error(_0x1df5b1);_0x2ea976['code']=_0x2e70a5,_0x210e40(_0x2ea976);}});}function bd(_0x400235,_0x55ab67,_0x54b3c2,_0x5dab9d,_0x3dab25,_0x5b7394){ut(_0x400235,'transaction\x20on\x20'+_0x55ab67);const _0x13576c={'path':_0x55ab67,'update':_0x54b3c2,'onComplete':_0x5dab9d,'status':null,'order':to(),'applyLocally':_0x5b7394,'retryCount':0x0,'unwatcher':_0x3dab25,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x17f2ab=ys(_0x400235,_0x55ab67,void 0x0);_0x13576c['currentInputSnapshot']=_0x17f2ab;const _0x1ad98e=_0x13576c['update'](_0x17f2ab['val']());if(_0x1ad98e===void 0x0)_0x13576c['unwatcher'](),_0x13576c['currentOutputSnapshotRaw']=null,_0x13576c['currentOutputSnapshotResolved']=null,_0x13576c['onComplete']&&_0x13576c['onComplete'](null,!0x1,_0x13576c['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1ad98e,_0x13576c['path']),_0x13576c['status']=0x0;const _0x7f904c=Un(_0x400235['transactionQueueTree_'],_0x55ab67),_0x9585e1=Ge(_0x7f904c)||[];_0x9585e1['push'](_0x13576c),fs(_0x7f904c,_0x9585e1);let _0x3b4e05;typeof _0x1ad98e=='object'&&_0x1ad98e!==null&&Y(_0x1ad98e,'.priority')?(_0x3b4e05=Oe(_0x1ad98e,'.priority'),f(Cn(_0x3b4e05),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3b4e05=(xn(_0x400235['serverSyncTree_'],_0x55ab67)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x2576ca=jt(_0x400235),_0x48d310=N(_0x1ad98e,_0x3b4e05),_0x13b0d0=hs(_0x48d310,_0x17f2ab,_0x2576ca);_0x13576c['currentOutputSnapshotRaw']=_0x48d310,_0x13576c['currentOutputSnapshotResolved']=_0x13b0d0,_0x13576c['currentWriteId']=Vn(_0x400235);const _0x25d853=ss(_0x400235['serverSyncTree_'],_0x55ab67,_0x13b0d0,_0x13576c['currentWriteId'],_0x13576c['applyLocally']);V(_0x400235['eventQueue_'],_0x55ab67,_0x25d853),Hn(_0x400235,_0x400235['transactionQueueTree_']);}}function ys(_0x6694c3,_0x43b020,_0x2171f7){return xn(_0x6694c3['serverSyncTree_'],_0x43b020,_0x2171f7)||g['EMPTY_NODE'];}function Hn(_0x25f3be,_0x1bbcdf=_0x25f3be['transactionQueueTree_']){if(_0x1bbcdf||$n(_0x25f3be,_0x1bbcdf),Ge(_0x1bbcdf)){const _0x23cb74=la(_0x25f3be,_0x1bbcdf);f(_0x23cb74['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x23cb74['every'](_0x370804=>_0x370804['status']===0x0)&&Rd(_0x25f3be,Gt(_0x1bbcdf),_0x23cb74);}else ea(_0x1bbcdf)&&Wn(_0x1bbcdf,_0x1f83c6=>{Hn(_0x25f3be,_0x1f83c6);});}function Rd(_0x44d640,_0x234a9f,_0x5668e6){const _0x2cfc8a=_0x5668e6['map'](_0x1fe1e3=>_0x1fe1e3['currentWriteId']),_0x1808fb=ys(_0x44d640,_0x234a9f,_0x2cfc8a);let _0x198d72=_0x1808fb;const _0xd0183f=_0x1808fb['hash']();for(let _0x175217=0x0;_0x175217<_0x5668e6['length'];_0x175217++){const _0x550c2d=_0x5668e6[_0x175217];f(_0x550c2d['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x550c2d['status']=0x1,_0x550c2d['retryCount']++;const _0x1d3d2c=F(_0x234a9f,_0x550c2d['path']);_0x198d72=_0x198d72['updateChild'](_0x1d3d2c,_0x550c2d['currentOutputSnapshotRaw']);}const _0x15f8b7=_0x198d72['val'](!0x0),_0x52d58e=_0x234a9f;_0x44d640['server_']['put'](_0x52d58e['toString'](),_0x15f8b7,_0x5e4c57=>{ut(_0x44d640,'transaction\x20put\x20response',{'path':_0x52d58e['toString'](),'status':_0x5e4c57});let _0x2bba81=[];if(_0x5e4c57==='ok'){const _0x430ee0=[];for(let _0x5791d8=0x0;_0x5791d8<_0x5668e6['length'];_0x5791d8++)_0x5668e6[_0x5791d8]['status']=0x2,_0x2bba81=_0x2bba81['concat'](pe(_0x44d640['serverSyncTree_'],_0x5668e6[_0x5791d8]['currentWriteId'])),_0x5668e6[_0x5791d8]['onComplete']&&_0x430ee0['push'](()=>_0x5668e6[_0x5791d8]['onComplete'](null,!0x0,_0x5668e6[_0x5791d8]['currentOutputSnapshotResolved'])),_0x5668e6[_0x5791d8]['unwatcher']();$n(_0x44d640,Un(_0x44d640['transactionQueueTree_'],_0x234a9f)),Hn(_0x44d640,_0x44d640['transactionQueueTree_']),V(_0x44d640['eventQueue_'],_0x234a9f,_0x2bba81);for(let _0x39c4ff=0x0;_0x39c4ff<_0x430ee0['length'];_0x39c4ff++)lt(_0x430ee0[_0x39c4ff]);}else{if(_0x5e4c57==='datastale'){for(let _0x114edc=0x0;_0x114edc<_0x5668e6['length'];_0x114edc++)_0x5668e6[_0x114edc]['status']===0x3?_0x5668e6[_0x114edc]['status']=0x4:_0x5668e6[_0x114edc]['status']=0x0;}else{U('transaction\x20at\x20'+_0x52d58e['toString']()+'\x20failed:\x20'+_0x5e4c57);for(let _0x41b5eb=0x0;_0x41b5eb<_0x5668e6['length'];_0x41b5eb++)_0x5668e6[_0x41b5eb]['status']=0x4,_0x5668e6[_0x41b5eb]['abortReason']=_0x5e4c57;}st(_0x44d640,_0x234a9f);}},_0xd0183f);}function st(_0x2c6210,_0x570454){const _0x3bd7b7=ca(_0x2c6210,_0x570454),_0x4f85e0=Gt(_0x3bd7b7),_0x5189c2=la(_0x2c6210,_0x3bd7b7);return Ad(_0x2c6210,_0x5189c2,_0x4f85e0),_0x4f85e0;}function Ad(_0x31cefa,_0x2f899c,_0x7f0cbb){if(_0x2f899c['length']===0x0)return;const _0x3c7a60=[];let _0x106eae=[];const _0x2d53ea=_0x2f899c['filter'](_0x13aa6a=>_0x13aa6a['status']===0x0)['map'](_0x5bd69c=>_0x5bd69c['currentWriteId']);for(let _0x2c9ad5=0x0;_0x2c9ad5<_0x2f899c['length'];_0x2c9ad5++){const _0x31cd85=_0x2f899c[_0x2c9ad5],_0x3923d2=F(_0x7f0cbb,_0x31cd85['path']);let _0x4814d7=!0x1,_0x3964b1;if(f(_0x3923d2!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x31cd85['status']===0x4)_0x4814d7=!0x0,_0x3964b1=_0x31cd85['abortReason'],_0x106eae=_0x106eae['concat'](pe(_0x31cefa['serverSyncTree_'],_0x31cd85['currentWriteId'],!0x0));else{if(_0x31cd85['status']===0x0){if(_0x31cd85['retryCount']>=_d)_0x4814d7=!0x0,_0x3964b1='maxretry',_0x106eae=_0x106eae['concat'](pe(_0x31cefa['serverSyncTree_'],_0x31cd85['currentWriteId'],!0x0));else{const _0x1df38a=ys(_0x31cefa,_0x31cd85['path'],_0x2d53ea);_0x31cd85['currentInputSnapshot']=_0x1df38a;const _0x1c39d4=_0x2f899c[_0x2c9ad5]['update'](_0x1df38a['val']());if(_0x1c39d4!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1c39d4,_0x31cd85['path']);let _0x2cbb2e=N(_0x1c39d4);typeof _0x1c39d4=='object'&&_0x1c39d4!=null&&Y(_0x1c39d4,'.priority')||(_0x2cbb2e=_0x2cbb2e['updatePriority'](_0x1df38a['getPriority']()));const _0x23d5a6=_0x31cd85['currentWriteId'],_0x563a1c=jt(_0x31cefa),_0x256fc3=hs(_0x2cbb2e,_0x1df38a,_0x563a1c);_0x31cd85['currentOutputSnapshotRaw']=_0x2cbb2e,_0x31cd85['currentOutputSnapshotResolved']=_0x256fc3,_0x31cd85['currentWriteId']=Vn(_0x31cefa),_0x2d53ea['splice'](_0x2d53ea['indexOf'](_0x23d5a6),0x1),_0x106eae=_0x106eae['concat'](ss(_0x31cefa['serverSyncTree_'],_0x31cd85['path'],_0x256fc3,_0x31cd85['currentWriteId'],_0x31cd85['applyLocally'])),_0x106eae=_0x106eae['concat'](pe(_0x31cefa['serverSyncTree_'],_0x23d5a6,!0x0));}else _0x4814d7=!0x0,_0x3964b1='nodata',_0x106eae=_0x106eae['concat'](pe(_0x31cefa['serverSyncTree_'],_0x31cd85['currentWriteId'],!0x0));}}}V(_0x31cefa['eventQueue_'],_0x7f0cbb,_0x106eae),_0x106eae=[],_0x4814d7&&(_0x2f899c[_0x2c9ad5]['status']=0x2,function(_0x5e6c8e){setTimeout(_0x5e6c8e,Math['floor'](0x0));}(_0x2f899c[_0x2c9ad5]['unwatcher']),_0x2f899c[_0x2c9ad5]['onComplete']&&(_0x3964b1==='nodata'?_0x3c7a60['push'](()=>_0x2f899c[_0x2c9ad5]['onComplete'](null,!0x1,_0x2f899c[_0x2c9ad5]['currentInputSnapshot'])):_0x3c7a60['push'](()=>_0x2f899c[_0x2c9ad5]['onComplete'](new Error(_0x3964b1),!0x1,null))));}$n(_0x31cefa,_0x31cefa['transactionQueueTree_']);for(let _0x5b5b8e=0x0;_0x5b5b8e<_0x3c7a60['length'];_0x5b5b8e++)lt(_0x3c7a60[_0x5b5b8e]);Hn(_0x31cefa,_0x31cefa['transactionQueueTree_']);}function ca(_0x43f058,_0x6978f4){let _0x85933e,_0x3349f8=_0x43f058['transactionQueueTree_'];for(_0x85933e=y(_0x6978f4);_0x85933e!==null&&Ge(_0x3349f8)===void 0x0;)_0x3349f8=Un(_0x3349f8,_0x85933e),_0x6978f4=b(_0x6978f4),_0x85933e=y(_0x6978f4);return _0x3349f8;}function la(_0x3e48a3,_0x4dc768){const _0x21c8e4=[];return ha(_0x3e48a3,_0x4dc768,_0x21c8e4),_0x21c8e4['sort']((_0x28e147,_0x52ce52)=>_0x28e147['order']-_0x52ce52['order']),_0x21c8e4;}function ha(_0x1a99d4,_0x2e52eb,_0x3cfc54){const _0x37cf52=Ge(_0x2e52eb);if(_0x37cf52){for(let _0x3103be=0x0;_0x3103be<_0x37cf52['length'];_0x3103be++)_0x3cfc54['push'](_0x37cf52[_0x3103be]);}Wn(_0x2e52eb,_0x33ae18=>{ha(_0x1a99d4,_0x33ae18,_0x3cfc54);});}function $n(_0xbedfd0,_0x4ef00c){const _0x95bc6=Ge(_0x4ef00c);if(_0x95bc6){let _0x15c1c8=0x0;for(let _0x278aa9=0x0;_0x278aa9<_0x95bc6['length'];_0x278aa9++)_0x95bc6[_0x278aa9]['status']!==0x2&&(_0x95bc6[_0x15c1c8]=_0x95bc6[_0x278aa9],_0x15c1c8++);_0x95bc6['length']=_0x15c1c8,fs(_0x4ef00c,_0x95bc6['length']>0x0?_0x95bc6:void 0x0);}Wn(_0x4ef00c,_0x57de43=>{$n(_0xbedfd0,_0x57de43);});}function vs(_0x4f7e15,_0x28c928){const _0xe9888c=Gt(ca(_0x4f7e15,_0x28c928)),_0x12bb08=Un(_0x4f7e15['transactionQueueTree_'],_0x28c928);return sd(_0x12bb08,_0x30f019=>{ai(_0x4f7e15,_0x30f019);}),ai(_0x4f7e15,_0x12bb08),ta(_0x12bb08,_0x5ad3c5=>{ai(_0x4f7e15,_0x5ad3c5);}),_0xe9888c;}function ai(_0x82bde,_0x1b521f){const _0x2b6cab=Ge(_0x1b521f);if(_0x2b6cab){const _0x466f3e=[];let _0x25a8c=[],_0x825852=-0x1;for(let _0x12a0bb=0x0;_0x12a0bb<_0x2b6cab['length'];_0x12a0bb++)_0x2b6cab[_0x12a0bb]['status']===0x3||(_0x2b6cab[_0x12a0bb]['status']===0x1?(f(_0x825852===_0x12a0bb-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x825852=_0x12a0bb,_0x2b6cab[_0x12a0bb]['status']=0x3,_0x2b6cab[_0x12a0bb]['abortReason']='set'):(f(_0x2b6cab[_0x12a0bb]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x2b6cab[_0x12a0bb]['unwatcher'](),_0x25a8c=_0x25a8c['concat'](pe(_0x82bde['serverSyncTree_'],_0x2b6cab[_0x12a0bb]['currentWriteId'],!0x0)),_0x2b6cab[_0x12a0bb]['onComplete']&&_0x466f3e['push'](_0x2b6cab[_0x12a0bb]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x825852===-0x1?fs(_0x1b521f,void 0x0):_0x2b6cab['length']=_0x825852+0x1,V(_0x82bde['eventQueue_'],Gt(_0x1b521f),_0x25a8c);for(let _0x5946a9=0x0;_0x5946a9<_0x466f3e['length'];_0x5946a9++)lt(_0x466f3e[_0x5946a9]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x242223){let _0x1f15f6='';const _0x5c62ae=_0x242223['split']('/');for(let _0x3ecdd7=0x0;_0x3ecdd7<_0x5c62ae['length'];_0x3ecdd7++)if(_0x5c62ae[_0x3ecdd7]['length']>0x0){let _0x2452c5=_0x5c62ae[_0x3ecdd7];try{_0x2452c5=decodeURIComponent(_0x2452c5['replace'](/\+/g,'\x20'));}catch{}_0x1f15f6+='/'+_0x2452c5;}return _0x1f15f6;}function Nd(_0x165272){const _0x5846cf={};_0x165272['charAt'](0x0)==='?'&&(_0x165272=_0x165272['substring'](0x1));for(const _0x101a2e of _0x165272['split']('&')){if(_0x101a2e['length']===0x0)continue;const _0x32dba5=_0x101a2e['split']('=');_0x32dba5['length']===0x2?_0x5846cf[decodeURIComponent(_0x32dba5[0x0])]=decodeURIComponent(_0x32dba5[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x101a2e+'\x27\x20in\x20query\x20\x27'+_0x165272+'\x27');}return _0x5846cf;}const gr=function(_0x3554f6,_0x2bc7dc){const _0x346cf0=Pd(_0x3554f6),_0x3590c9=_0x346cf0['namespace'];_0x346cf0['domain']==='firebase.com'&&oe(_0x346cf0['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3590c9||_0x3590c9==='undefined')&&_0x346cf0['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x346cf0['secure']||Bl();const _0x10857c=_0x346cf0['scheme']==='ws'||_0x346cf0['scheme']==='wss';return{'repoInfo':new _o(_0x346cf0['host'],_0x346cf0['secure'],_0x3590c9,_0x10857c,_0x2bc7dc,'',_0x3590c9!==_0x346cf0['subdomain']),'path':new C(_0x346cf0['pathString'])};},Pd=function(_0x45b4d6){let _0x1b596a='',_0x1c2799='',_0x557203='',_0x5ff079='',_0x5b212a='',_0x1b5711=!0x0,_0x450811='https',_0x2d56ea=0x1bb;if(typeof _0x45b4d6=='string'){let _0x146279=_0x45b4d6['indexOf']('//');_0x146279>=0x0&&(_0x450811=_0x45b4d6['substring'](0x0,_0x146279-0x1),_0x45b4d6=_0x45b4d6['substring'](_0x146279+0x2));let _0x21ca23=_0x45b4d6['indexOf']('/');_0x21ca23===-0x1&&(_0x21ca23=_0x45b4d6['length']);let _0x232796=_0x45b4d6['indexOf']('?');_0x232796===-0x1&&(_0x232796=_0x45b4d6['length']),_0x1b596a=_0x45b4d6['substring'](0x0,Math['min'](_0x21ca23,_0x232796)),_0x21ca23<_0x232796&&(_0x5ff079=kd(_0x45b4d6['substring'](_0x21ca23,_0x232796)));const _0x573596=Nd(_0x45b4d6['substring'](Math['min'](_0x45b4d6['length'],_0x232796)));_0x146279=_0x1b596a['indexOf'](':'),_0x146279>=0x0?(_0x1b5711=_0x450811==='https'||_0x450811==='wss',_0x2d56ea=parseInt(_0x1b596a['substring'](_0x146279+0x1),0xa)):_0x146279=_0x1b596a['length'];const _0x2c43f6=_0x1b596a['slice'](0x0,_0x146279);if(_0x2c43f6['toLowerCase']()==='localhost')_0x1c2799='localhost';else{if(_0x2c43f6['split']('.')['length']<=0x2)_0x1c2799=_0x2c43f6;else{const _0x17e048=_0x1b596a['indexOf']('.');_0x557203=_0x1b596a['substring'](0x0,_0x17e048)['toLowerCase'](),_0x1c2799=_0x1b596a['substring'](_0x17e048+0x1),_0x5b212a=_0x557203;}}'ns'in _0x573596&&(_0x5b212a=_0x573596['ns']);}return{'host':_0x1b596a,'port':_0x2d56ea,'domain':_0x1c2799,'subdomain':_0x557203,'secure':_0x1b5711,'scheme':_0x450811,'pathString':_0x5ff079,'namespace':_0x5b212a};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x319067=0x0;const _0x33ee59=[];return function(_0x576b5b){const _0x14bb16=_0x576b5b===_0x319067;_0x319067=_0x576b5b;let _0x47c2c7;const _0x5e8387=new Array(0x8);for(_0x47c2c7=0x7;_0x47c2c7>=0x0;_0x47c2c7--)_0x5e8387[_0x47c2c7]=mr['charAt'](_0x576b5b%0x40),_0x576b5b=Math['floor'](_0x576b5b/0x40);f(_0x576b5b===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x333928=_0x5e8387['join']('');if(_0x14bb16){for(_0x47c2c7=0xb;_0x47c2c7>=0x0&&_0x33ee59[_0x47c2c7]===0x3f;_0x47c2c7--)_0x33ee59[_0x47c2c7]=0x0;_0x33ee59[_0x47c2c7]++;}else{for(_0x47c2c7=0x0;_0x47c2c7<0xc;_0x47c2c7++)_0x33ee59[_0x47c2c7]=Math['floor'](Math['random']()*0x40);}for(_0x47c2c7=0x0;_0x47c2c7<0xc;_0x47c2c7++)_0x333928+=mr['charAt'](_0x33ee59[_0x47c2c7]);return f(_0x333928['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x333928;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x2a5894,_0x570d6d,_0x468585,_0x31d3d6){this['eventType']=_0x2a5894,this['eventRegistration']=_0x570d6d,this['snapshot']=_0x468585,this['prevName']=_0x31d3d6;}['getPath'](){const _0x3f33f7=this['snapshot']['ref'];return this['eventType']==='value'?_0x3f33f7['_path']:_0x3f33f7['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x816817,_0x128fea,_0x2c555a){this['eventRegistration']=_0x816817,this['error']=_0x128fea,this['path']=_0x2c555a;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x452945,_0x5d0e3c){this['snapshotCallback']=_0x452945,this['cancelCallback']=_0x5d0e3c;}['onValue'](_0x3a7700,_0x24da63){this['snapshotCallback']['call'](null,_0x3a7700,_0x24da63);}['onCancel'](_0x28c9e1){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x28c9e1);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x217777){return this['snapshotCallback']===_0x217777['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x217777['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x217777['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x5ef2a8,_0x41fe35,_0x376fca,_0x1d6b5c){this['_repo']=_0x5ef2a8,this['_path']=_0x41fe35,this['_queryParams']=_0x376fca,this['_orderByCalled']=_0x1d6b5c;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x20f4c7=nr(this['_queryParams']),_0x1eed25=Bi(_0x20f4c7);return _0x1eed25==='{}'?'default':_0x1eed25;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x77f013){if(_0x77f013=k(_0x77f013),!(_0x77f013 instanceof be))return!0x1;const _0x14a5be=this['_repo']===_0x77f013['_repo'],_0x46ad8b=qi(this['_path'],_0x77f013['_path']),_0x3c90f5=this['_queryIdentifier']===_0x77f013['_queryIdentifier'];return _0x14a5be&&_0x46ad8b&&_0x3c90f5;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x5a5d49,_0x38a870){if(_0x5a5d49['_orderByCalled']===!0x0)throw new Error(_0x38a870+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x10265f){let _0x42bd26=null,_0x3c4ab4=null;if(_0x10265f['hasStart']()&&(_0x42bd26=_0x10265f['getIndexStartValue']()),_0x10265f['hasEnd']()&&(_0x3c4ab4=_0x10265f['getIndexEndValue']()),_0x10265f['getIndex']()===ye){const _0x2ebfed='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x358524='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x10265f['hasStart']()){if(_0x10265f['getIndexStartName']()!==xe)throw new Error(_0x2ebfed);if(typeof _0x42bd26!='string')throw new Error(_0x358524);}if(_0x10265f['hasEnd']()){if(_0x10265f['getIndexEndName']()!==Ie)throw new Error(_0x2ebfed);if(typeof _0x3c4ab4!='string')throw new Error(_0x358524);}}else{if(_0x10265f['getIndex']()===R){if(_0x42bd26!=null&&!Cn(_0x42bd26)||_0x3c4ab4!=null&&!Cn(_0x3c4ab4))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x10265f['getIndex']()instanceof Ki||_0x10265f['getIndex']()===Po,'unknown\x20index\x20type.'),_0x42bd26!=null&&typeof _0x42bd26=='object'||_0x3c4ab4!=null&&typeof _0x3c4ab4=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x175ad4){if(_0x175ad4['hasStart']()&&_0x175ad4['hasEnd']()&&_0x175ad4['hasLimit']()&&!_0x175ad4['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x33d934,_0x20c24e){super(_0x33d934,_0x20c24e,new Qi(),!0x1);}get['parent'](){const _0x52542f=To(this['_path']);return _0x52542f===null?null:new Z(this['_repo'],_0x52542f);}get['root'](){let _0x5b56bb=this;for(;_0x5b56bb['parent']!==null;)_0x5b56bb=_0x5b56bb['parent'];return _0x5b56bb;}}class rt{constructor(_0x494645,_0x45e383,_0x51e316){this['_node']=_0x494645,this['ref']=_0x45e383,this['_index']=_0x51e316;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x57138c){const _0x5eb8f4=new C(_0x57138c),_0x24c9fa=Lt(this['ref'],_0x57138c);return new rt(this['_node']['getChild'](_0x5eb8f4),_0x24c9fa,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x398f8d){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x474a24,_0x42b230)=>_0x398f8d(new rt(_0x42b230,Lt(this['ref'],_0x474a24),R)));}['hasChild'](_0x2ee918){const _0x55e806=new C(_0x2ee918);return!this['_node']['getChild'](_0x55e806)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x2da850,_0x424ce4){return _0x2da850=k(_0x2da850),_0x2da850['_checkNotDeleted']('ref'),_0x424ce4!==void 0x0?Lt(_0x2da850['_root'],_0x424ce4):_0x2da850['_root'];}function Lt(_0x38c714,_0x53c3b3){return _0x38c714=k(_0x38c714),y(_0x38c714['_path'])===null?ud('child','path',_0x53c3b3):_s('child','path',_0x53c3b3),new Z(_0x38c714['_repo'],A(_0x38c714['_path'],_0x53c3b3));}function d_(_0x360acd,_0xaabc92){_0x360acd=k(_0x360acd),gs('push',_0x360acd['_path']),qt('push',_0xaabc92,_0x360acd['_path'],!0x0);const _0x1e4945=oa(_0x360acd['_repo']),_0x582da8=Od(_0x1e4945),_0x2c9ba5=Lt(_0x360acd,_0x582da8),_0x2e4586=Lt(_0x360acd,_0x582da8);let _0x209872;return _0xaabc92!=null?_0x209872=Ld(_0x2e4586,_0xaabc92)['then'](()=>_0x2e4586):_0x209872=Promise['resolve'](_0x2e4586),_0x2c9ba5['then']=_0x209872['then']['bind'](_0x209872),_0x2c9ba5['catch']=_0x209872['then']['bind'](_0x209872,void 0x0),_0x2c9ba5;}function Ld(_0xbc19a2,_0x489eb6){_0xbc19a2=k(_0xbc19a2),gs('set',_0xbc19a2['_path']),qt('set',_0x489eb6,_0xbc19a2['_path'],!0x1);const _0x54ba37=new Ve();return Ed(_0xbc19a2['_repo'],_0xbc19a2['_path'],_0x489eb6,null,_0x54ba37['wrapCallback'](()=>{})),_0x54ba37['promise'];}function f_(_0xbca2d5,_0x29e933){hd('update',_0x29e933,_0xbca2d5['_path']);const _0x2ff629=new Ve();return Id(_0xbca2d5['_repo'],_0xbca2d5['_path'],_0x29e933,_0x2ff629['wrapCallback'](()=>{})),_0x2ff629['promise'];}function p_(_0x16a85f){_0x16a85f=k(_0x16a85f);const _0xa42847=new ua(()=>{}),_0x23061e=new qn(_0xa42847);return vd(_0x16a85f['_repo'],_0x16a85f,_0x23061e)['then'](_0x54377e=>new rt(_0x54377e,new Z(_0x16a85f['_repo'],_0x16a85f['_path']),_0x16a85f['_queryParams']['getIndex']()));}class qn{constructor(_0x3603e8){this['callbackContext']=_0x3603e8;}['respondsTo'](_0x15fd88){return _0x15fd88==='value';}['createEvent'](_0x270269,_0x4df749){const _0x3a9206=_0x4df749['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x270269['snapshotNode'],new Z(_0x4df749['_repo'],_0x4df749['_path']),_0x3a9206));}['getEventRunner'](_0x3fdb5a){return _0x3fdb5a['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3fdb5a['error']):()=>this['callbackContext']['onValue'](_0x3fdb5a['snapshot'],null);}['createCancelEvent'](_0x4f9279,_0x5410e6){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x4f9279,_0x5410e6):null;}['matches'](_0x2a09d9){return _0x2a09d9 instanceof qn?!_0x2a09d9['callbackContext']||!this['callbackContext']?!0x0:_0x2a09d9['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x5a6180,_0xbd372f,_0x309496,_0x5c429c,_0x580ff8){const _0x5f5242=new ua(_0x309496,void 0x0),_0x553afb=new qn(_0x5f5242);return Cd(_0x5a6180['_repo'],_0x5a6180,_0x553afb),()=>Td(_0x5a6180['_repo'],_0x5a6180,_0x553afb);}function Fd(_0x43e9fb,_0x2c6740,_0x2a8d65,_0x14e778){return xd(_0x43e9fb,'value',_0x2c6740);}class dt{}class pa extends dt{constructor(_0x45f7fd,_0x2e9a97){super(),this['_value']=_0x45f7fd,this['_key']=_0x2e9a97,this['type']='endAt';}['_apply'](_0x34a998){qt('endAt',this['_value'],_0x34a998['_path'],!0x0);const _0x2571f2=Kh(_0x34a998['_queryParams'],this['_value'],this['_key']);if(fa(_0x2571f2),Gn(_0x2571f2),_0x34a998['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x34a998['_repo'],_0x34a998['_path'],_0x2571f2,_0x34a998['_orderByCalled']);}}function __(_0x73ee7c,_0x56e11b){return new pa(_0x73ee7c,_0x56e11b);}class _a extends dt{constructor(_0x3633d8,_0x1b88ff){super(),this['_value']=_0x3633d8,this['_key']=_0x1b88ff,this['type']='startAt';}['_apply'](_0x3b9b33){qt('startAt',this['_value'],_0x3b9b33['_path'],!0x0);const _0x5e7901=jh(_0x3b9b33['_queryParams'],this['_value'],this['_key']);if(fa(_0x5e7901),Gn(_0x5e7901),_0x3b9b33['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x3b9b33['_repo'],_0x3b9b33['_path'],_0x5e7901,_0x3b9b33['_orderByCalled']);}}function g_(_0x5505f8=null,_0xcecf2e){return new _a(_0x5505f8,_0xcecf2e);}class Ud extends dt{constructor(_0x49f622){super(),this['_limit']=_0x49f622,this['type']='limitToFirst';}['_apply'](_0x2d92e3){if(_0x2d92e3['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x2d92e3['_repo'],_0x2d92e3['_path'],zh(_0x2d92e3['_queryParams'],this['_limit']),_0x2d92e3['_orderByCalled']);}}function m_(_0x226578){if(Math['floor'](_0x226578)!==_0x226578||_0x226578<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x226578);}class Wd extends dt{constructor(_0x3a6c3e){super(),this['_path']=_0x3a6c3e,this['type']='orderByChild';}['_apply'](_0x2cd95a){da(_0x2cd95a,'orderByChild');const _0x715f6e=new C(this['_path']);if(v(_0x715f6e))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x1d59a9=new Ki(_0x715f6e),_0x447f4e=Do(_0x2cd95a['_queryParams'],_0x1d59a9);return Gn(_0x447f4e),new be(_0x2cd95a['_repo'],_0x2cd95a['_path'],_0x447f4e,!0x0);}}function y_(_0x120f9f){if(_0x120f9f==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x120f9f==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x120f9f==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x120f9f),new Wd(_0x120f9f);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x14767e){da(_0x14767e,'orderByKey');const _0x259e0f=Do(_0x14767e['_queryParams'],ye);return Gn(_0x259e0f),new be(_0x14767e['_repo'],_0x14767e['_path'],_0x259e0f,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x2038c4,_0x13e2cc){super(),this['_value']=_0x2038c4,this['_key']=_0x13e2cc,this['type']='equalTo';}['_apply'](_0x3f75f7){if(qt('equalTo',this['_value'],_0x3f75f7['_path'],!0x1),_0x3f75f7['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3f75f7['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x3f75f7));}}function E_(_0x41b6d2,_0x1b85f3){return new Vd(_0x41b6d2,_0x1b85f3);}function I_(_0x270c1c,..._0x52f9f5){let _0x5715d3=k(_0x270c1c);for(const _0x56f17f of _0x52f9f5)_0x5715d3=_0x56f17f['_apply'](_0x5715d3);return _0x5715d3;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x34e660,_0x4850e3,_0x3a2d07,_0x4babe7){const _0x29c36b=_0x4850e3['lastIndexOf'](':'),_0x1b352b=_0x4850e3['substring'](0x0,_0x29c36b),_0x9a9a25=Wt(_0x1b352b);_0x34e660['repoInfo_']=new _o(_0x4850e3,_0x9a9a25,_0x34e660['repoInfo_']['namespace'],_0x34e660['repoInfo_']['webSocketOnly'],_0x34e660['repoInfo_']['nodeAdmin'],_0x34e660['repoInfo_']['persistenceKey'],_0x34e660['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x3a2d07),_0x4babe7&&(_0x34e660['authTokenProvider_']=_0x4babe7);}function qd(_0x2c4eb7,_0x5bed47,_0x5342bb,_0x5e519c,_0x2def65){let _0x28e9b3=_0x5e519c||_0x2c4eb7['options']['databaseURL'];_0x28e9b3===void 0x0&&(_0x2c4eb7['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2c4eb7['options']['projectId']),_0x28e9b3=_0x2c4eb7['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x528a34=gr(_0x28e9b3,_0x2def65),_0x5ad023=_0x528a34['repoInfo'],_0x46ce1f;typeof process<'u'&&Us&&(_0x46ce1f=Us[Hd]),_0x46ce1f?(_0x28e9b3='http://'+_0x46ce1f+'?ns='+_0x5ad023['namespace'],_0x528a34=gr(_0x28e9b3,_0x2def65),_0x5ad023=_0x528a34['repoInfo']):_0x528a34['repoInfo']['secure'];const _0x19a61c=new Jl(_0x2c4eb7['name'],_0x2c4eb7['options'],_0x5bed47);dd('Invalid\x20Firebase\x20Database\x20URL',_0x528a34),v(_0x528a34['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x257a2f=jd(_0x5ad023,_0x2c4eb7,_0x19a61c,new Ql(_0x2c4eb7,_0x5342bb));return new Kd(_0x257a2f,_0x2c4eb7);}function zd(_0x18411f,_0x5f4317){const _0x48aa66=ki[_0x5f4317];(!_0x48aa66||_0x48aa66[_0x18411f['key']]!==_0x18411f)&&oe('Database\x20'+_0x5f4317+'('+_0x18411f['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x18411f),delete _0x48aa66[_0x18411f['key']];}function jd(_0x20b83a,_0x4161dd,_0x378c2a,_0x3f1815){let _0x475909=ki[_0x4161dd['name']];_0x475909||(_0x475909={},ki[_0x4161dd['name']]=_0x475909);let _0x40da4f=_0x475909[_0x20b83a['toURLString']()];return _0x40da4f&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x40da4f=new gd(_0x20b83a,$d,_0x378c2a,_0x3f1815),_0x475909[_0x20b83a['toURLString']()]=_0x40da4f,_0x40da4f;}class Kd{constructor(_0x4be9ae,_0x2cba70){this['_repoInternal']=_0x4be9ae,this['app']=_0x2cba70,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x19d41d){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x19d41d+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x385c4f=Qr(),_0x574a6a){const _0x56ea69=Ui(_0x385c4f,'database')['getImmediate']({'identifier':_0x574a6a});if(!_0x56ea69['_instanceStarted']){const _0xbeaba=ac('database');_0xbeaba&&Yd(_0x56ea69,..._0xbeaba);}return _0x56ea69;}function Yd(_0x49c454,_0x677f25,_0x10b73a,_0x3691e0={}){_0x49c454=k(_0x49c454),_0x49c454['_checkNotDeleted']('useEmulator');const _0x54d259=_0x677f25+':'+_0x10b73a,_0x223f9c=_0x49c454['_repoInternal'];if(_0x49c454['_instanceStarted']){if(_0x54d259===_0x49c454['_repoInternal']['repoInfo_']['host']&&De(_0x3691e0,_0x223f9c['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x2b5a09;if(_0x223f9c['repoInfo_']['nodeAdmin'])_0x3691e0['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x2b5a09=new tn(tn['OWNER']);else{if(_0x3691e0['mockUserToken']){const _0x18b778=typeof _0x3691e0['mockUserToken']=='string'?_0x3691e0['mockUserToken']:cc(_0x3691e0['mockUserToken'],_0x49c454['app']['options']['projectId']);_0x2b5a09=new tn(_0x18b778);}}Wt(_0x677f25)&&jr(_0x677f25),Gd(_0x223f9c,_0x54d259,_0x3691e0,_0x2b5a09);}function C_(_0x377206){_0x377206=k(_0x377206),_0x377206['_checkNotDeleted']('goOffline'),aa(_0x377206['_repo']);}function T_(_0x492967){_0x492967=k(_0x492967),_0x492967['_checkNotDeleted']('goOnline'),Sd(_0x492967['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x3a978d){Ll(ct),et(new Me('database',(_0xc789e4,{instanceIdentifier:_0x55e9f6})=>{const _0x290f99=_0xc789e4['getProvider']('app')['getImmediate'](),_0x33bb33=_0xc789e4['getProvider']('auth-internal'),_0x3cd3f8=_0xc789e4['getProvider']('app-check-internal');return qd(_0x290f99,_0x33bb33,_0x3cd3f8,_0x55e9f6);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x3a978d),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x3c932b,_0x114cfc){this['committed']=_0x3c932b,this['snapshot']=_0x114cfc;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x335005,_0xf7dc9c,_0x18179a){if(_0x335005=k(_0x335005),gs('Reference.transaction',_0x335005['_path']),_0x335005['key']==='.length'||_0x335005['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x335005['key']+'\x20is\x20a\x20read-only\x20object.';const _0x55d6bc=!0x0,_0x5493fb=new Ve(),_0x4db948=(_0x312bac,_0x10d381,_0x181c52)=>{let _0x944787=null;_0x312bac?_0x5493fb['reject'](_0x312bac):(_0x944787=new rt(_0x181c52,new Z(_0x335005['_repo'],_0x335005['_path']),R),_0x5493fb['resolve'](new Xd(_0x10d381,_0x944787)));},_0x4b6556=Fd(_0x335005,()=>{});return bd(_0x335005['_repo'],_0x335005['_path'],_0xf7dc9c,_0x4db948,_0x4b6556,_0x55d6bc),_0x5493fb['promise'];}ie['prototype']['simpleListen']=function(_0x4e728f,_0x25495f){this['sendRequest']('q',{'p':_0x4e728f},_0x25495f);},ie['prototype']['echo']=function(_0x304057,_0x1b8b21){this['sendRequest']('echo',{'d':_0x304057},_0x1b8b21);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x3bd455,..._0xc35fdf){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x3bd455,..._0xc35fdf);}function nn(_0x5be55c,..._0x43742d){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x5be55c,..._0x43742d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x4f2099,..._0x57ceb7){throw Es(_0x4f2099,..._0x57ceb7);}function J(_0x5270bb,..._0x538916){return Es(_0x5270bb,..._0x538916);}function ya(_0x3e607d,_0x3e9616,_0x3852ac){const _0x134f78={...Zd(),[_0x3e9616]:_0x3852ac};return new Ut('auth','Firebase',_0x134f78)['create'](_0x3e9616,{'appName':_0x3e607d['name']});}function se(_0x276c87){return ya(_0x276c87,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x1e5c91,..._0x2914c8){if(typeof _0x1e5c91!='string'){const _0xe03ec3=_0x2914c8[0x0],_0x4a4611=[..._0x2914c8['slice'](0x1)];return _0x4a4611[0x0]&&(_0x4a4611[0x0]['appName']=_0x1e5c91['name']),_0x1e5c91['_errorFactory']['create'](_0xe03ec3,..._0x4a4611);}return ma['create'](_0x1e5c91,..._0x2914c8);}function m(_0x47fec4,_0x3a9abb,..._0x4f2302){if(!_0x47fec4)throw Es(_0x3a9abb,..._0x4f2302);}function te(_0x3353f1){const _0x3ac1ee='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3353f1;throw nn(_0x3ac1ee),new Error(_0x3ac1ee);}function ae(_0x2b853a,_0x5d8335){_0x2b853a||te(_0x5d8335);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x2daaeb;return typeof self<'u'&&((_0x2daaeb=self['location'])==null?void 0x0:_0x2daaeb['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x38766e;return typeof self<'u'&&((_0x38766e=self['location'])==null?void 0x0:_0x38766e['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x55bc79=navigator;return _0x55bc79['languages']&&_0x55bc79['languages'][0x0]||_0x55bc79['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x1ce7c0,_0x595cad){this['shortDelay']=_0x1ce7c0,this['longDelay']=_0x595cad,ae(_0x595cad>_0x1ce7c0,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0xb71cbe,_0x17c994){ae(_0xb71cbe['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x4c41d6}=_0xb71cbe['emulator'];return _0x17c994?''+_0x4c41d6+(_0x17c994['startsWith']('/')?_0x17c994['slice'](0x1):_0x17c994):_0x4c41d6;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x59e5c3,_0x2dd64e,_0x3d4146){this['fetchImpl']=_0x59e5c3,_0x2dd64e&&(this['headersImpl']=_0x2dd64e),_0x3d4146&&(this['responseImpl']=_0x3d4146);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x4928fb,_0x4d3153){return _0x4928fb['tenantId']&&!_0x4d3153['tenantId']?{..._0x4d3153,'tenantId':_0x4928fb['tenantId']}:_0x4d3153;}async function Ae(_0x210a9d,_0x3b576a,_0x4414c5,_0x306e87,_0x6ee420={}){return Ea(_0x210a9d,_0x6ee420,async()=>{let _0x1b1ba6={},_0x13b433={};_0x306e87&&(_0x3b576a==='GET'?_0x13b433=_0x306e87:_0x1b1ba6={'body':JSON['stringify'](_0x306e87)});const _0x262c70=at({..._0x13b433,'key':_0x210a9d['config']['apiKey']})['slice'](0x1),_0x27cea1=await _0x210a9d['_getAdditionalHeaders']();_0x27cea1['Content-Type']='application/json',_0x210a9d['languageCode']&&(_0x27cea1['X-Firebase-Locale']=_0x210a9d['languageCode']);const _0x38b6da={'method':_0x3b576a,'headers':_0x27cea1,..._0x1b1ba6};return lc()||(_0x38b6da['referrerPolicy']='strict-origin-when-cross-origin'),_0x210a9d['emulatorConfig']&&Wt(_0x210a9d['emulatorConfig']['host'])&&(_0x38b6da['credentials']='include'),va['fetch']()(await Ia(_0x210a9d,_0x210a9d['config']['apiHost'],_0x4414c5,_0x262c70),_0x38b6da);});}async function Ea(_0x4b344f,_0x1a9655,_0x35e46e){_0x4b344f['_canInitEmulator']=!0x1;const _0x1978c0={...rf,..._0x1a9655};try{const _0x322f8f=new lf(_0x4b344f),_0x625ba3=await Promise['race']([_0x35e46e(),_0x322f8f['promise']]);_0x322f8f['clearNetworkTimeout']();const _0x4046ac=await _0x625ba3['json']();if('needConfirmation'in _0x4046ac)throw en(_0x4b344f,'account-exists-with-different-credential',_0x4046ac);if(_0x625ba3['ok']&&!('errorMessage'in _0x4046ac))return _0x4046ac;{const _0x385125=_0x625ba3['ok']?_0x4046ac['errorMessage']:_0x4046ac['error']['message'],[_0x17d18d,_0x234149]=_0x385125['split']('\x20:\x20');if(_0x17d18d==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x4b344f,'credential-already-in-use',_0x4046ac);if(_0x17d18d==='EMAIL_EXISTS')throw en(_0x4b344f,'email-already-in-use',_0x4046ac);if(_0x17d18d==='USER_DISABLED')throw en(_0x4b344f,'user-disabled',_0x4046ac);const _0x3736ab=_0x1978c0[_0x17d18d]||_0x17d18d['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x234149)throw ya(_0x4b344f,_0x3736ab,_0x234149);K(_0x4b344f,_0x3736ab);}}catch(_0x5b207c){if(_0x5b207c instanceof Se)throw _0x5b207c;K(_0x4b344f,'network-request-failed',{'message':String(_0x5b207c)});}}async function Yt(_0x1e6f84,_0x20e54d,_0x47a834,_0x55dbc8,_0x5f560e={}){const _0x19189a=await Ae(_0x1e6f84,_0x20e54d,_0x47a834,_0x55dbc8,_0x5f560e);return'mfaPendingCredential'in _0x19189a&&K(_0x1e6f84,'multi-factor-auth-required',{'_serverResponse':_0x19189a}),_0x19189a;}async function Ia(_0x1a32c6,_0x7bec9a,_0x84f4df,_0x67fc97){const _0xb208f=''+_0x7bec9a+_0x84f4df+'?'+_0x67fc97,_0x2a28cc=_0x1a32c6,_0x2f9816=_0x2a28cc['config']['emulator']?Is(_0x1a32c6['config'],_0xb208f):_0x1a32c6['config']['apiScheme']+'://'+_0xb208f;return of['includes'](_0x84f4df)&&(await _0x2a28cc['_persistenceManagerAvailable'],_0x2a28cc['_getPersistenceType']()==='COOKIE')?_0x2a28cc['_getPersistence']()['_getFinalTarget'](_0x2f9816)['toString']():_0x2f9816;}function cf(_0x2f3c51){switch(_0x2f3c51){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x18be01){this['auth']=_0x18be01,this['timer']=null,this['promise']=new Promise((_0x504b6c,_0x35eb8d)=>{this['timer']=setTimeout(()=>_0x35eb8d(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x3d0a25,_0x30f8b8,_0x5b0b16){const _0x30c684={'appName':_0x3d0a25['name']};_0x5b0b16['email']&&(_0x30c684['email']=_0x5b0b16['email']),_0x5b0b16['phoneNumber']&&(_0x30c684['phoneNumber']=_0x5b0b16['phoneNumber']);const _0xa58bd1=J(_0x3d0a25,_0x30f8b8,_0x30c684);return _0xa58bd1['customData']['_tokenResponse']=_0x5b0b16,_0xa58bd1;}function vr(_0x5d6bfe){return _0x5d6bfe!==void 0x0&&_0x5d6bfe['enterprise']!==void 0x0;}class hf{constructor(_0xf51681){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0xf51681['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0xf51681['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0xf51681['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x45f376){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x572f7d of this['recaptchaEnforcementState'])if(_0x572f7d['provider']&&_0x572f7d['provider']===_0x45f376)return cf(_0x572f7d['enforcementState']);return null;}['isProviderEnabled'](_0x502be0){return this['getProviderEnforcementState'](_0x502be0)==='ENFORCE'||this['getProviderEnforcementState'](_0x502be0)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x5b9e86,_0x27bb74){return Ae(_0x5b9e86,'GET','/v2/recaptchaConfig',Re(_0x5b9e86,_0x27bb74));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x474f1c,_0x59b7fc){return Ae(_0x474f1c,'POST','/v1/accounts:delete',_0x59b7fc);}async function Sn(_0x531f70,_0x572893){return Ae(_0x531f70,'POST','/v1/accounts:lookup',_0x572893);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0xe2d09a){if(_0xe2d09a)try{const _0x46bb90=new Date(Number(_0xe2d09a));if(!isNaN(_0x46bb90['getTime']()))return _0x46bb90['toUTCString']();}catch{}}async function ff(_0x296aef,_0x583940=!0x1){const _0x313add=k(_0x296aef),_0x55d294=await _0x313add['getIdToken'](_0x583940),_0x3b6b88=ws(_0x55d294);m(_0x3b6b88&&_0x3b6b88['exp']&&_0x3b6b88['auth_time']&&_0x3b6b88['iat'],_0x313add['auth'],'internal-error');const _0x2499b9=typeof _0x3b6b88['firebase']=='object'?_0x3b6b88['firebase']:void 0x0,_0x2817aa=_0x2499b9==null?void 0x0:_0x2499b9['sign_in_provider'];return{'claims':_0x3b6b88,'token':_0x55d294,'authTime':St(ci(_0x3b6b88['auth_time'])),'issuedAtTime':St(ci(_0x3b6b88['iat'])),'expirationTime':St(ci(_0x3b6b88['exp'])),'signInProvider':_0x2817aa||null,'signInSecondFactor':(_0x2499b9==null?void 0x0:_0x2499b9['sign_in_second_factor'])||null};}function ci(_0x280a8e){return Number(_0x280a8e)*0x3e8;}function ws(_0x358d08){const [_0x463ee3,_0x456905,_0x582e1c]=_0x358d08['split']('.');if(_0x463ee3===void 0x0||_0x456905===void 0x0||_0x582e1c===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x5e916a=cn(_0x456905);return _0x5e916a?JSON['parse'](_0x5e916a):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x418347){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x418347==null?void 0x0:_0x418347['toString']()),null;}}function Er(_0x4b3def){const _0xd10f48=ws(_0x4b3def);return m(_0xd10f48,'internal-error'),m(typeof _0xd10f48['exp']<'u','internal-error'),m(typeof _0xd10f48['iat']<'u','internal-error'),Number(_0xd10f48['exp'])-Number(_0xd10f48['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x97d926,_0x1a8d2d,_0x4ad789=!0x1){if(_0x4ad789)return _0x1a8d2d;try{return await _0x1a8d2d;}catch(_0x59f495){throw _0x59f495 instanceof Se&&pf(_0x59f495)&&_0x97d926['auth']['currentUser']===_0x97d926&&await _0x97d926['auth']['signOut'](),_0x59f495;}}function pf({code:_0x3d3164}){return _0x3d3164==='auth/user-disabled'||_0x3d3164==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x1edaed){this['user']=_0x1edaed,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x417fda){if(_0x417fda){const _0x2780ca=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2780ca;}else{this['errorBackoff']=0x7530;const _0x259568=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x259568);}}['schedule'](_0xc425c8=!0x1){if(!this['isRunning'])return;const _0x13e781=this['getInterval'](_0xc425c8);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x13e781);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x3bbfb1){(_0x3bbfb1==null?void 0x0:_0x3bbfb1['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x2b3be1,_0x4be194){this['createdAt']=_0x2b3be1,this['lastLoginAt']=_0x4be194,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x502e6f){this['createdAt']=_0x502e6f['createdAt'],this['lastLoginAt']=_0x502e6f['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x5750d8){var _0x327b93;const _0xb4bc41=_0x5750d8['auth'],_0x4a46d1=await _0x5750d8['getIdToken'](),_0x1fd761=await xt(_0x5750d8,Sn(_0xb4bc41,{'idToken':_0x4a46d1}));m(_0x1fd761==null?void 0x0:_0x1fd761['users']['length'],_0xb4bc41,'internal-error');const _0x4cfa7a=_0x1fd761['users'][0x0];_0x5750d8['_notifyReloadListener'](_0x4cfa7a);const _0x402e74=(_0x327b93=_0x4cfa7a['providerUserInfo'])!=null&&_0x327b93['length']?wa(_0x4cfa7a['providerUserInfo']):[],_0x237e5c=mf(_0x5750d8['providerData'],_0x402e74),_0x5d99cd=_0x5750d8['isAnonymous'],_0x8af142=!(_0x5750d8['email']&&_0x4cfa7a['passwordHash'])&&!(_0x237e5c!=null&&_0x237e5c['length']),_0x317b06=_0x5d99cd?_0x8af142:!0x1,_0x2a9478={'uid':_0x4cfa7a['localId'],'displayName':_0x4cfa7a['displayName']||null,'photoURL':_0x4cfa7a['photoUrl']||null,'email':_0x4cfa7a['email']||null,'emailVerified':_0x4cfa7a['emailVerified']||!0x1,'phoneNumber':_0x4cfa7a['phoneNumber']||null,'tenantId':_0x4cfa7a['tenantId']||null,'providerData':_0x237e5c,'metadata':new Pi(_0x4cfa7a['createdAt'],_0x4cfa7a['lastLoginAt']),'isAnonymous':_0x317b06};Object['assign'](_0x5750d8,_0x2a9478);}async function gf(_0x4eda23){const _0xb01994=k(_0x4eda23);await bn(_0xb01994),await _0xb01994['auth']['_persistUserIfCurrent'](_0xb01994),_0xb01994['auth']['_notifyListenersIfCurrent'](_0xb01994);}function mf(_0x5ee9cc,_0x393454){return[..._0x5ee9cc['filter'](_0x5f258a=>!_0x393454['some'](_0x847437=>_0x847437['providerId']===_0x5f258a['providerId'])),..._0x393454];}function wa(_0x2b2c93){return _0x2b2c93['map'](({providerId:_0x5ccc24,..._0x62e129})=>({'providerId':_0x5ccc24,'uid':_0x62e129['rawId']||'','displayName':_0x62e129['displayName']||null,'email':_0x62e129['email']||null,'phoneNumber':_0x62e129['phoneNumber']||null,'photoURL':_0x62e129['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x97e14c,_0x19f984){const _0x30ff29=await Ea(_0x97e14c,{},async()=>{const _0x3eda06=at({'grant_type':'refresh_token','refresh_token':_0x19f984})['slice'](0x1),{tokenApiHost:_0x3e19c8,apiKey:_0x5928d1}=_0x97e14c['config'],_0x56f5f0=await Ia(_0x97e14c,_0x3e19c8,'/v1/token','key='+_0x5928d1),_0xfd634f=await _0x97e14c['_getAdditionalHeaders']();_0xfd634f['Content-Type']='application/x-www-form-urlencoded';const _0x49e1db={'method':'POST','headers':_0xfd634f,'body':_0x3eda06};return _0x97e14c['emulatorConfig']&&Wt(_0x97e14c['emulatorConfig']['host'])&&(_0x49e1db['credentials']='include'),va['fetch']()(_0x56f5f0,_0x49e1db);});return{'accessToken':_0x30ff29['access_token'],'expiresIn':_0x30ff29['expires_in'],'refreshToken':_0x30ff29['refresh_token']};}async function vf(_0x225857,_0x5396d1){return Ae(_0x225857,'POST','/v2/accounts:revokeToken',Re(_0x225857,_0x5396d1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x31608b){m(_0x31608b['idToken'],'internal-error'),m(typeof _0x31608b['idToken']<'u','internal-error'),m(typeof _0x31608b['refreshToken']<'u','internal-error');const _0x80a092='expiresIn'in _0x31608b&&typeof _0x31608b['expiresIn']<'u'?Number(_0x31608b['expiresIn']):Er(_0x31608b['idToken']);this['updateTokensAndExpiration'](_0x31608b['idToken'],_0x31608b['refreshToken'],_0x80a092);}['updateFromIdToken'](_0x21e1e5){m(_0x21e1e5['length']!==0x0,'internal-error');const _0x4dac42=Er(_0x21e1e5);this['updateTokensAndExpiration'](_0x21e1e5,null,_0x4dac42);}async['getToken'](_0x203b61,_0x495eeb=!0x1){return!_0x495eeb&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x203b61,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x203b61,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x32d2a4,_0x3e78b0){const {accessToken:_0x384509,refreshToken:_0x4333fa,expiresIn:_0x526b96}=await yf(_0x32d2a4,_0x3e78b0);this['updateTokensAndExpiration'](_0x384509,_0x4333fa,Number(_0x526b96));}['updateTokensAndExpiration'](_0xe383e1,_0xba05e4,_0x45c949){this['refreshToken']=_0xba05e4||null,this['accessToken']=_0xe383e1||null,this['expirationTime']=Date['now']()+_0x45c949*0x3e8;}static['fromJSON'](_0x5acea1,_0x3f6ac0){const {refreshToken:_0x38c43b,accessToken:_0x1a3a9c,expirationTime:_0x3ad9da}=_0x3f6ac0,_0x5571e6=new Je();return _0x38c43b&&(m(typeof _0x38c43b=='string','internal-error',{'appName':_0x5acea1}),_0x5571e6['refreshToken']=_0x38c43b),_0x1a3a9c&&(m(typeof _0x1a3a9c=='string','internal-error',{'appName':_0x5acea1}),_0x5571e6['accessToken']=_0x1a3a9c),_0x3ad9da&&(m(typeof _0x3ad9da=='number','internal-error',{'appName':_0x5acea1}),_0x5571e6['expirationTime']=_0x3ad9da),_0x5571e6;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1fc18d){this['accessToken']=_0x1fc18d['accessToken'],this['refreshToken']=_0x1fc18d['refreshToken'],this['expirationTime']=_0x1fc18d['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x54901a,_0x51e722){m(typeof _0x54901a=='string'||typeof _0x54901a>'u','internal-error',{'appName':_0x51e722});}class z{constructor({uid:_0x3c4cb5,auth:_0x4e66e3,stsTokenManager:_0x50a56d,..._0x361a0f}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3c4cb5,this['auth']=_0x4e66e3,this['stsTokenManager']=_0x50a56d,this['accessToken']=_0x50a56d['accessToken'],this['displayName']=_0x361a0f['displayName']||null,this['email']=_0x361a0f['email']||null,this['emailVerified']=_0x361a0f['emailVerified']||!0x1,this['phoneNumber']=_0x361a0f['phoneNumber']||null,this['photoURL']=_0x361a0f['photoURL']||null,this['isAnonymous']=_0x361a0f['isAnonymous']||!0x1,this['tenantId']=_0x361a0f['tenantId']||null,this['providerData']=_0x361a0f['providerData']?[..._0x361a0f['providerData']]:[],this['metadata']=new Pi(_0x361a0f['createdAt']||void 0x0,_0x361a0f['lastLoginAt']||void 0x0);}async['getIdToken'](_0x15a191){const _0x1c0a09=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x15a191));return m(_0x1c0a09,this['auth'],'internal-error'),this['accessToken']!==_0x1c0a09&&(this['accessToken']=_0x1c0a09,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1c0a09;}['getIdTokenResult'](_0x20ec7d){return ff(this,_0x20ec7d);}['reload'](){return gf(this);}['_assign'](_0x4e5e5b){this!==_0x4e5e5b&&(m(this['uid']===_0x4e5e5b['uid'],this['auth'],'internal-error'),this['displayName']=_0x4e5e5b['displayName'],this['photoURL']=_0x4e5e5b['photoURL'],this['email']=_0x4e5e5b['email'],this['emailVerified']=_0x4e5e5b['emailVerified'],this['phoneNumber']=_0x4e5e5b['phoneNumber'],this['isAnonymous']=_0x4e5e5b['isAnonymous'],this['tenantId']=_0x4e5e5b['tenantId'],this['providerData']=_0x4e5e5b['providerData']['map'](_0x1543fb=>({..._0x1543fb})),this['metadata']['_copy'](_0x4e5e5b['metadata']),this['stsTokenManager']['_assign'](_0x4e5e5b['stsTokenManager']));}['_clone'](_0x1b10d2){const _0x2c9381=new z({...this,'auth':_0x1b10d2,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x2c9381['metadata']['_copy'](this['metadata']),_0x2c9381;}['_onReload'](_0x1915fb){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1915fb,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x5537e2){this['reloadListener']?this['reloadListener'](_0x5537e2):this['reloadUserInfo']=_0x5537e2;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x3e1b05,_0x3328c6=!0x1){let _0x1fec13=!0x1;_0x3e1b05['idToken']&&_0x3e1b05['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x3e1b05),_0x1fec13=!0x0),_0x3328c6&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1fec13&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x5b42d7=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x5b42d7})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x246315=>({..._0x246315})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x26e26f,_0x453e7f){const _0x4ee668=_0x453e7f['displayName']??void 0x0,_0x13d52c=_0x453e7f['email']??void 0x0,_0x37d44d=_0x453e7f['phoneNumber']??void 0x0,_0x443821=_0x453e7f['photoURL']??void 0x0,_0x1bde0f=_0x453e7f['tenantId']??void 0x0,_0x2cdf0b=_0x453e7f['_redirectEventId']??void 0x0,_0x4001ba=_0x453e7f['createdAt']??void 0x0,_0x3f6a94=_0x453e7f['lastLoginAt']??void 0x0,{uid:_0x3c8247,emailVerified:_0x42a552,isAnonymous:_0x109b68,providerData:_0x308b67,stsTokenManager:_0x5d8e04}=_0x453e7f;m(_0x3c8247&&_0x5d8e04,_0x26e26f,'internal-error');const _0x5f827=Je['fromJSON'](this['name'],_0x5d8e04);m(typeof _0x3c8247=='string',_0x26e26f,'internal-error'),ce(_0x4ee668,_0x26e26f['name']),ce(_0x13d52c,_0x26e26f['name']),m(typeof _0x42a552=='boolean',_0x26e26f,'internal-error'),m(typeof _0x109b68=='boolean',_0x26e26f,'internal-error'),ce(_0x37d44d,_0x26e26f['name']),ce(_0x443821,_0x26e26f['name']),ce(_0x1bde0f,_0x26e26f['name']),ce(_0x2cdf0b,_0x26e26f['name']),ce(_0x4001ba,_0x26e26f['name']),ce(_0x3f6a94,_0x26e26f['name']);const _0x4a3e94=new z({'uid':_0x3c8247,'auth':_0x26e26f,'email':_0x13d52c,'emailVerified':_0x42a552,'displayName':_0x4ee668,'isAnonymous':_0x109b68,'photoURL':_0x443821,'phoneNumber':_0x37d44d,'tenantId':_0x1bde0f,'stsTokenManager':_0x5f827,'createdAt':_0x4001ba,'lastLoginAt':_0x3f6a94});return _0x308b67&&Array['isArray'](_0x308b67)&&(_0x4a3e94['providerData']=_0x308b67['map'](_0x268836=>({..._0x268836}))),_0x2cdf0b&&(_0x4a3e94['_redirectEventId']=_0x2cdf0b),_0x4a3e94;}static async['_fromIdTokenResponse'](_0x42b9cc,_0x449855,_0x5ac09c=!0x1){const _0xc01d0c=new Je();_0xc01d0c['updateFromServerResponse'](_0x449855);const _0xda4021=new z({'uid':_0x449855['localId'],'auth':_0x42b9cc,'stsTokenManager':_0xc01d0c,'isAnonymous':_0x5ac09c});return await bn(_0xda4021),_0xda4021;}static async['_fromGetAccountInfoResponse'](_0xf41515,_0x2625cb,_0x5e2533){const _0x16df90=_0x2625cb['users'][0x0];m(_0x16df90['localId']!==void 0x0,'internal-error');const _0x58394a=_0x16df90['providerUserInfo']!==void 0x0?wa(_0x16df90['providerUserInfo']):[],_0x44d757=!(_0x16df90['email']&&_0x16df90['passwordHash'])&&!(_0x58394a!=null&&_0x58394a['length']),_0x54911c=new Je();_0x54911c['updateFromIdToken'](_0x5e2533);const _0x7f7938=new z({'uid':_0x16df90['localId'],'auth':_0xf41515,'stsTokenManager':_0x54911c,'isAnonymous':_0x44d757}),_0x475d5d={'uid':_0x16df90['localId'],'displayName':_0x16df90['displayName']||null,'photoURL':_0x16df90['photoUrl']||null,'email':_0x16df90['email']||null,'emailVerified':_0x16df90['emailVerified']||!0x1,'phoneNumber':_0x16df90['phoneNumber']||null,'tenantId':_0x16df90['tenantId']||null,'providerData':_0x58394a,'metadata':new Pi(_0x16df90['createdAt'],_0x16df90['lastLoginAt']),'isAnonymous':!(_0x16df90['email']&&_0x16df90['passwordHash'])&&!(_0x58394a!=null&&_0x58394a['length'])};return Object['assign'](_0x7f7938,_0x475d5d),_0x7f7938;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x25fd49){ae(_0x25fd49 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x883c3=Ir['get'](_0x25fd49);return _0x883c3?(ae(_0x883c3 instanceof _0x25fd49,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x883c3):(_0x883c3=new _0x25fd49(),Ir['set'](_0x25fd49,_0x883c3),_0x883c3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x320800,_0x1751d9){this['storage'][_0x320800]=_0x1751d9;}async['_get'](_0x4f5c77){const _0x128fe5=this['storage'][_0x4f5c77];return _0x128fe5===void 0x0?null:_0x128fe5;}async['_remove'](_0x19f490){delete this['storage'][_0x19f490];}['_addListener'](_0x46fb24,_0x30b1e4){}['_removeListener'](_0x19a191,_0x2461c5){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x106022,_0x3bff7f,_0x29eef9){return'firebase:'+_0x106022+':'+_0x3bff7f+':'+_0x29eef9;}class Xe{constructor(_0x15527a,_0x9dce75,_0x20ca7e){this['persistence']=_0x15527a,this['auth']=_0x9dce75,this['userKey']=_0x20ca7e;const {config:_0x329b55,name:_0x4c5869}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x329b55['apiKey'],_0x4c5869),this['fullPersistenceKey']=sn('persistence',_0x329b55['apiKey'],_0x4c5869),this['boundEventHandler']=_0x9dce75['_onStorageEvent']['bind'](_0x9dce75),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x57ec08){return this['persistence']['_set'](this['fullUserKey'],_0x57ec08['toJSON']());}async['getCurrentUser'](){const _0x51dbc5=await this['persistence']['_get'](this['fullUserKey']);if(!_0x51dbc5)return null;if(typeof _0x51dbc5=='string'){const _0x37c425=await Sn(this['auth'],{'idToken':_0x51dbc5})['catch'](()=>{});return _0x37c425?z['_fromGetAccountInfoResponse'](this['auth'],_0x37c425,_0x51dbc5):null;}return z['_fromJSON'](this['auth'],_0x51dbc5);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x4cdf18){if(this['persistence']===_0x4cdf18)return;const _0x37116b=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x4cdf18,_0x37116b)return this['setCurrentUser'](_0x37116b);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x757db1,_0x607487,_0xb7d3a3='authUser'){if(!_0x607487['length'])return new Xe(ne(wr),_0x757db1,_0xb7d3a3);const _0xae52a2=(await Promise['all'](_0x607487['map'](async _0x2967fd=>{if(await _0x2967fd['_isAvailable']())return _0x2967fd;})))['filter'](_0x379b7b=>_0x379b7b);let _0x121c69=_0xae52a2[0x0]||ne(wr);const _0xfdc50c=sn(_0xb7d3a3,_0x757db1['config']['apiKey'],_0x757db1['name']);let _0x83f368=null;for(const _0xf6167f of _0x607487)try{const _0x2f5f47=await _0xf6167f['_get'](_0xfdc50c);if(_0x2f5f47){let _0x1dccc3;if(typeof _0x2f5f47=='string'){const _0x432076=await Sn(_0x757db1,{'idToken':_0x2f5f47})['catch'](()=>{});if(!_0x432076)break;_0x1dccc3=await z['_fromGetAccountInfoResponse'](_0x757db1,_0x432076,_0x2f5f47);}else _0x1dccc3=z['_fromJSON'](_0x757db1,_0x2f5f47);_0xf6167f!==_0x121c69&&(_0x83f368=_0x1dccc3),_0x121c69=_0xf6167f;break;}}catch{}const _0x361a5e=_0xae52a2['filter'](_0x4aa381=>_0x4aa381['_shouldAllowMigration']);return!_0x121c69['_shouldAllowMigration']||!_0x361a5e['length']?new Xe(_0x121c69,_0x757db1,_0xb7d3a3):(_0x121c69=_0x361a5e[0x0],_0x83f368&&await _0x121c69['_set'](_0xfdc50c,_0x83f368['toJSON']()),await Promise['all'](_0x607487['map'](async _0x4cd0b4=>{if(_0x4cd0b4!==_0x121c69)try{await _0x4cd0b4['_remove'](_0xfdc50c);}catch{}})),new Xe(_0x121c69,_0x757db1,_0xb7d3a3));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x2f3412){const _0xfab2cd=_0x2f3412['toLowerCase']();if(_0xfab2cd['includes']('opera/')||_0xfab2cd['includes']('opr/')||_0xfab2cd['includes']('opios/'))return'Opera';if(Ra(_0xfab2cd))return'IEMobile';if(_0xfab2cd['includes']('msie')||_0xfab2cd['includes']('trident/'))return'IE';if(_0xfab2cd['includes']('edge/'))return'Edge';if(Ta(_0xfab2cd))return'Firefox';if(_0xfab2cd['includes']('silk/'))return'Silk';if(ka(_0xfab2cd))return'Blackberry';if(Na(_0xfab2cd))return'Webos';if(Sa(_0xfab2cd))return'Safari';if((_0xfab2cd['includes']('chrome/')||ba(_0xfab2cd))&&!_0xfab2cd['includes']('edge/'))return'Chrome';if(Aa(_0xfab2cd))return'Android';{const _0x3787b8=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4fcc1a=_0x2f3412['match'](_0x3787b8);if((_0x4fcc1a==null?void 0x0:_0x4fcc1a['length'])===0x2)return _0x4fcc1a[0x1];}return'Other';}function Ta(_0x440312=W()){return/firefox\//i['test'](_0x440312);}function Sa(_0x3eb2c7=W()){const _0x2c6d8c=_0x3eb2c7['toLowerCase']();return _0x2c6d8c['includes']('safari/')&&!_0x2c6d8c['includes']('chrome/')&&!_0x2c6d8c['includes']('crios/')&&!_0x2c6d8c['includes']('android');}function ba(_0x1c48a7=W()){return/crios\//i['test'](_0x1c48a7);}function Ra(_0x5b7279=W()){return/iemobile/i['test'](_0x5b7279);}function Aa(_0x149988=W()){return/android/i['test'](_0x149988);}function ka(_0x23aafc=W()){return/blackberry/i['test'](_0x23aafc);}function Na(_0xe8ad11=W()){return/webos/i['test'](_0xe8ad11);}function Cs(_0x29b3de=W()){return/iphone|ipad|ipod/i['test'](_0x29b3de)||/macintosh/i['test'](_0x29b3de)&&/mobile/i['test'](_0x29b3de);}function Ef(_0x103511=W()){var _0x3097b2;return Cs(_0x103511)&&!!((_0x3097b2=window['navigator'])!=null&&_0x3097b2['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x4cf32b=W()){return Cs(_0x4cf32b)||Aa(_0x4cf32b)||Na(_0x4cf32b)||ka(_0x4cf32b)||/windows phone/i['test'](_0x4cf32b)||Ra(_0x4cf32b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x428214,_0x50a096=[]){let _0x28cdbf;switch(_0x428214){case'Browser':_0x28cdbf=Cr(W());break;case'Worker':_0x28cdbf=Cr(W())+'-'+_0x428214;break;default:_0x28cdbf=_0x428214;}const _0x569701=_0x50a096['length']?_0x50a096['join'](','):'FirebaseCore-web';return _0x28cdbf+'/JsCore/'+ct+'/'+_0x569701;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x232e81){this['auth']=_0x232e81,this['queue']=[];}['pushCallback'](_0x41a4f9,_0x417f26){const _0xf2e157=_0x291aad=>new Promise((_0x5926a8,_0x5bae45)=>{try{const _0x4dab0c=_0x41a4f9(_0x291aad);_0x5926a8(_0x4dab0c);}catch(_0x5ce514){_0x5bae45(_0x5ce514);}});_0xf2e157['onAbort']=_0x417f26,this['queue']['push'](_0xf2e157);const _0x153fba=this['queue']['length']-0x1;return()=>{this['queue'][_0x153fba]=()=>Promise['resolve']();};}async['runMiddleware'](_0x367773){if(this['auth']['currentUser']===_0x367773)return;const _0x54609e=[];try{for(const _0x2ae7ea of this['queue'])await _0x2ae7ea(_0x367773),_0x2ae7ea['onAbort']&&_0x54609e['push'](_0x2ae7ea['onAbort']);}catch(_0x5ebff2){_0x54609e['reverse']();for(const _0xd16926 of _0x54609e)try{_0xd16926();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x5ebff2==null?void 0x0:_0x5ebff2['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x7215a6,_0x670315={}){return Ae(_0x7215a6,'GET','/v2/passwordPolicy',Re(_0x7215a6,_0x670315));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x5cde7f){var _0x24a59b;const _0x4c5c0c=_0x5cde7f['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4c5c0c['minPasswordLength']??Tf,_0x4c5c0c['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4c5c0c['maxPasswordLength']),_0x4c5c0c['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4c5c0c['containsLowercaseCharacter']),_0x4c5c0c['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4c5c0c['containsUppercaseCharacter']),_0x4c5c0c['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4c5c0c['containsNumericCharacter']),_0x4c5c0c['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4c5c0c['containsNonAlphanumericCharacter']),this['enforcementState']=_0x5cde7f['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x24a59b=_0x5cde7f['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x24a59b['join'](''))??'',this['forceUpgradeOnSignin']=_0x5cde7f['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x5cde7f['schemaVersion'];}['validatePassword'](_0x313b5f){const _0xa53595={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x313b5f,_0xa53595),this['validatePasswordCharacterOptions'](_0x313b5f,_0xa53595),_0xa53595['isValid']&&(_0xa53595['isValid']=_0xa53595['meetsMinPasswordLength']??!0x0),_0xa53595['isValid']&&(_0xa53595['isValid']=_0xa53595['meetsMaxPasswordLength']??!0x0),_0xa53595['isValid']&&(_0xa53595['isValid']=_0xa53595['containsLowercaseLetter']??!0x0),_0xa53595['isValid']&&(_0xa53595['isValid']=_0xa53595['containsUppercaseLetter']??!0x0),_0xa53595['isValid']&&(_0xa53595['isValid']=_0xa53595['containsNumericCharacter']??!0x0),_0xa53595['isValid']&&(_0xa53595['isValid']=_0xa53595['containsNonAlphanumericCharacter']??!0x0),_0xa53595;}['validatePasswordLengthOptions'](_0x100159,_0x657047){const _0x120635=this['customStrengthOptions']['minPasswordLength'],_0x4b0e03=this['customStrengthOptions']['maxPasswordLength'];_0x120635&&(_0x657047['meetsMinPasswordLength']=_0x100159['length']>=_0x120635),_0x4b0e03&&(_0x657047['meetsMaxPasswordLength']=_0x100159['length']<=_0x4b0e03);}['validatePasswordCharacterOptions'](_0xd1dd13,_0x35a74d){this['updatePasswordCharacterOptionsStatuses'](_0x35a74d,!0x1,!0x1,!0x1,!0x1);let _0x3dfcf0;for(let _0x47b17f=0x0;_0x47b17f<_0xd1dd13['length'];_0x47b17f++)_0x3dfcf0=_0xd1dd13['charAt'](_0x47b17f),this['updatePasswordCharacterOptionsStatuses'](_0x35a74d,_0x3dfcf0>='a'&&_0x3dfcf0<='z',_0x3dfcf0>='A'&&_0x3dfcf0<='Z',_0x3dfcf0>='0'&&_0x3dfcf0<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3dfcf0));}['updatePasswordCharacterOptionsStatuses'](_0x359d96,_0x4c6bb4,_0x5ef457,_0x1bef99,_0x18a20a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x359d96['containsLowercaseLetter']||(_0x359d96['containsLowercaseLetter']=_0x4c6bb4)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x359d96['containsUppercaseLetter']||(_0x359d96['containsUppercaseLetter']=_0x5ef457)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x359d96['containsNumericCharacter']||(_0x359d96['containsNumericCharacter']=_0x1bef99)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x359d96['containsNonAlphanumericCharacter']||(_0x359d96['containsNonAlphanumericCharacter']=_0x18a20a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x324ac6,_0x4415de,_0x480f4e,_0x2d38e0){this['app']=_0x324ac6,this['heartbeatServiceProvider']=_0x4415de,this['appCheckServiceProvider']=_0x480f4e,this['config']=_0x2d38e0,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x324ac6['name'],this['clientVersion']=_0x2d38e0['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xc23f7b=>this['_resolvePersistenceManagerAvailable']=_0xc23f7b);}['_initializeWithPersistence'](_0x2126f7,_0x173ec2){return _0x173ec2&&(this['_popupRedirectResolver']=ne(_0x173ec2)),this['_initializationPromise']=this['queue'](async()=>{var _0x3b71b6,_0x5e929a,_0xe295ce;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x2126f7),(_0x3b71b6=this['_resolvePersistenceManagerAvailable'])==null||_0x3b71b6['call'](this),!this['_deleted'])){if((_0x5e929a=this['_popupRedirectResolver'])!=null&&_0x5e929a['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x173ec2),this['lastNotifiedUid']=((_0xe295ce=this['currentUser'])==null?void 0x0:_0xe295ce['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x538072=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x538072)){if(this['currentUser']&&_0x538072&&this['currentUser']['uid']===_0x538072['uid']){this['_currentUser']['_assign'](_0x538072),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x538072,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x308b6d){try{const _0x17081b=await Sn(this,{'idToken':_0x308b6d}),_0x3ea687=await z['_fromGetAccountInfoResponse'](this,_0x17081b,_0x308b6d);await this['directlySetCurrentUser'](_0x3ea687);}catch(_0x1207a6){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1207a6),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x19b7c4){var _0x29960f;if(H(this['app'])){const _0x1a1ef0=this['app']['settings']['authIdToken'];return _0x1a1ef0?new Promise(_0x4dbaaf=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x1a1ef0)['then'](_0x4dbaaf,_0x4dbaaf));}):this['directlySetCurrentUser'](null);}const _0x8f2b2c=await this['assertedPersistence']['getCurrentUser']();let _0x5e4ae8=_0x8f2b2c,_0x3fc9a9=!0x1;if(_0x19b7c4&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2f0f09=(_0x29960f=this['redirectUser'])==null?void 0x0:_0x29960f['_redirectEventId'],_0x1a2c47=_0x5e4ae8==null?void 0x0:_0x5e4ae8['_redirectEventId'],_0x203483=await this['tryRedirectSignIn'](_0x19b7c4);(!_0x2f0f09||_0x2f0f09===_0x1a2c47)&&(_0x203483!=null&&_0x203483['user'])&&(_0x5e4ae8=_0x203483['user'],_0x3fc9a9=!0x0);}if(!_0x5e4ae8)return this['directlySetCurrentUser'](null);if(!_0x5e4ae8['_redirectEventId']){if(_0x3fc9a9)try{await this['beforeStateQueue']['runMiddleware'](_0x5e4ae8);}catch(_0x188bf8){_0x5e4ae8=_0x8f2b2c,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x188bf8));}return _0x5e4ae8?this['reloadAndSetCurrentUserOrClear'](_0x5e4ae8):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5e4ae8['_redirectEventId']?this['directlySetCurrentUser'](_0x5e4ae8):this['reloadAndSetCurrentUserOrClear'](_0x5e4ae8);}async['tryRedirectSignIn'](_0x4d81fd){let _0x31b18c=null;try{_0x31b18c=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4d81fd,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x31b18c;}async['reloadAndSetCurrentUserOrClear'](_0x33bef3){try{await bn(_0x33bef3);}catch(_0xf4f320){if((_0xf4f320==null?void 0x0:_0xf4f320['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x33bef3);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x47ad76){if(H(this['app']))return Promise['reject'](se(this));const _0x2aa48d=_0x47ad76?k(_0x47ad76):null;return _0x2aa48d&&m(_0x2aa48d['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2aa48d&&_0x2aa48d['_clone'](this));}async['_updateCurrentUser'](_0x208088,_0xf229a3=!0x1){if(!this['_deleted'])return _0x208088&&m(this['tenantId']===_0x208088['tenantId'],this,'tenant-id-mismatch'),_0xf229a3||await this['beforeStateQueue']['runMiddleware'](_0x208088),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x208088),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x38a944){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x38a944));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1f9f1b){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3dd8d0=this['_getPasswordPolicyInternal']();return _0x3dd8d0['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3dd8d0['validatePassword'](_0x1f9f1b);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x25b061=await Cf(this),_0x51b2f9=new Sf(_0x25b061);this['tenantId']===null?this['_projectPasswordPolicy']=_0x51b2f9:this['_tenantPasswordPolicies'][this['tenantId']]=_0x51b2f9;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x390733){this['_errorFactory']=new Ut('auth','Firebase',_0x390733());}['onAuthStateChanged'](_0x104b7d,_0x4f2987,_0x1f6407){return this['registerStateListener'](this['authStateSubscription'],_0x104b7d,_0x4f2987,_0x1f6407);}['beforeAuthStateChanged'](_0x198ffc,_0x1b0307){return this['beforeStateQueue']['pushCallback'](_0x198ffc,_0x1b0307);}['onIdTokenChanged'](_0x117262,_0x5340e7,_0x36b0c4){return this['registerStateListener'](this['idTokenSubscription'],_0x117262,_0x5340e7,_0x36b0c4);}['authStateReady'](){return new Promise((_0x58fae4,_0x20e5b7)=>{if(this['currentUser'])_0x58fae4();else{const _0xab3227=this['onAuthStateChanged'](()=>{_0xab3227(),_0x58fae4();},_0x20e5b7);}});}async['revokeAccessToken'](_0x425d27){if(this['currentUser']){const _0x3fa935=await this['currentUser']['getIdToken'](),_0x1416f7={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x425d27,'idToken':_0x3fa935};this['tenantId']!=null&&(_0x1416f7['tenantId']=this['tenantId']),await vf(this,_0x1416f7);}}['toJSON'](){var _0x1d354f;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x1d354f=this['_currentUser'])==null?void 0x0:_0x1d354f['toJSON']()};}async['_setRedirectUser'](_0x5989fa,_0x25c2a1){const _0x3ca314=await this['getOrInitRedirectPersistenceManager'](_0x25c2a1);return _0x5989fa===null?_0x3ca314['removeCurrentUser']():_0x3ca314['setCurrentUser'](_0x5989fa);}async['getOrInitRedirectPersistenceManager'](_0x3f6a59){if(!this['redirectPersistenceManager']){const _0x52796e=_0x3f6a59&&ne(_0x3f6a59)||this['_popupRedirectResolver'];m(_0x52796e,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x52796e['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x5a90c0){var _0xcc1f30,_0xa9a253;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0xcc1f30=this['_currentUser'])==null?void 0x0:_0xcc1f30['_redirectEventId'])===_0x5a90c0?this['_currentUser']:((_0xa9a253=this['redirectUser'])==null?void 0x0:_0xa9a253['_redirectEventId'])===_0x5a90c0?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2ed291){if(_0x2ed291===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2ed291));}['_notifyListenersIfCurrent'](_0x3a3d69){_0x3a3d69===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x51bd06;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x276410=((_0x51bd06=this['currentUser'])==null?void 0x0:_0x51bd06['uid'])??null;this['lastNotifiedUid']!==_0x276410&&(this['lastNotifiedUid']=_0x276410,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x280256,_0x3acfa6,_0x14b49e,_0x91770b){if(this['_deleted'])return()=>{};const _0x3441e7=typeof _0x3acfa6=='function'?_0x3acfa6:_0x3acfa6['next']['bind'](_0x3acfa6);let _0xdd975a=!0x1;const _0x4cc768=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4cc768,this,'internal-error'),_0x4cc768['then'](()=>{_0xdd975a||_0x3441e7(this['currentUser']);}),typeof _0x3acfa6=='function'){const _0x56f07d=_0x280256['addObserver'](_0x3acfa6,_0x14b49e,_0x91770b);return()=>{_0xdd975a=!0x0,_0x56f07d();};}else{const _0x1b395f=_0x280256['addObserver'](_0x3acfa6);return()=>{_0xdd975a=!0x0,_0x1b395f();};}}async['directlySetCurrentUser'](_0xd35a65){this['currentUser']&&this['currentUser']!==_0xd35a65&&this['_currentUser']['_stopProactiveRefresh'](),_0xd35a65&&this['isProactiveRefreshEnabled']&&_0xd35a65['_startProactiveRefresh'](),this['currentUser']=_0xd35a65,_0xd35a65?await this['assertedPersistence']['setCurrentUser'](_0xd35a65):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1cdf04){return this['operations']=this['operations']['then'](_0x1cdf04,_0x1cdf04),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x40cf12){!_0x40cf12||this['frameworks']['includes'](_0x40cf12)||(this['frameworks']['push'](_0x40cf12),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x39f422;const _0x41fa6e={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x41fa6e['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x2f1132=await((_0x39f422=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x39f422['getHeartbeatsHeader']());_0x2f1132&&(_0x41fa6e['X-Firebase-Client']=_0x2f1132);const _0x31494a=await this['_getAppCheckToken']();return _0x31494a&&(_0x41fa6e['X-Firebase-AppCheck']=_0x31494a),_0x41fa6e;}async['_getAppCheckToken'](){var _0x204679;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1e4b0c=await((_0x204679=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x204679['getToken']());return _0x1e4b0c!=null&&_0x1e4b0c['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1e4b0c['error']),_0x1e4b0c==null?void 0x0:_0x1e4b0c['token'];}}function qe(_0xb019d5){return k(_0xb019d5);}class Tr{constructor(_0xb47ab2){this['auth']=_0xb47ab2,this['observer']=null,this['addObserver']=Ic(_0x2c5fc1=>this['observer']=_0x2c5fc1);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0xb083ed){zn=_0xb083ed;}function Da(_0x4ee1dc){return zn['loadJS'](_0x4ee1dc);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x23f653){return'__'+_0x23f653+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x29c7c0){_0x29c7c0();}['execute'](_0x5ef65b,_0x4fd056){return Promise['resolve']('token');}['render'](_0x39271c,_0x12bb03){return'';}}class Of{['ready'](_0x4390c3){_0x4390c3();}['execute'](_0x3639f3,_0x429382){return Promise['resolve']('token');}['render'](_0x2efafd,_0x4ce228){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x4d70f4){this['type']=Df,this['auth']=qe(_0x4d70f4);}async['verify'](_0x3043ba='verify',_0x255c5f=!0x1){async function _0x4a6e41(_0x5c071d){if(!_0x255c5f){if(_0x5c071d['tenantId']==null&&_0x5c071d['_agentRecaptchaConfig']!=null)return _0x5c071d['_agentRecaptchaConfig']['siteKey'];if(_0x5c071d['tenantId']!=null&&_0x5c071d['_tenantRecaptchaConfigs'][_0x5c071d['tenantId']]!==void 0x0)return _0x5c071d['_tenantRecaptchaConfigs'][_0x5c071d['tenantId']]['siteKey'];}return new Promise(async(_0x29deae,_0x3333fe)=>{uf(_0x5c071d,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x138616=>{if(_0x138616['recaptchaKey']===void 0x0)_0x3333fe(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x59cff7=new hf(_0x138616);return _0x5c071d['tenantId']==null?_0x5c071d['_agentRecaptchaConfig']=_0x59cff7:_0x5c071d['_tenantRecaptchaConfigs'][_0x5c071d['tenantId']]=_0x59cff7,_0x29deae(_0x59cff7['siteKey']);}})['catch'](_0x35aed4=>{_0x3333fe(_0x35aed4);});});}function _0x659eba(_0x3c3804,_0x26f1a3,_0x2ab338){const _0x19b92c=window['grecaptcha'];vr(_0x19b92c)?_0x19b92c['enterprise']['ready'](()=>{_0x19b92c['enterprise']['execute'](_0x3c3804,{'action':_0x3043ba})['then'](_0x3c404a=>{_0x26f1a3(_0x3c404a);})['catch'](()=>{_0x26f1a3(Ma);});}):_0x2ab338(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x406406,_0x31a436)=>{_0x4a6e41(this['auth'])['then'](async _0x21eb70=>{if(!_0x255c5f&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x659eba(_0x21eb70,_0x406406,_0x31a436);else{if(typeof window>'u'){_0x31a436(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5870cd=Af();_0x5870cd['length']!==0x0&&(_0x5870cd+=_0x21eb70+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x45c168;(_0x45c168=le['scriptInjectionDeferred'])==null||_0x45c168['resolve']();},Da(_0x5870cd)['then'](()=>{var _0x265c86;return(_0x265c86=le['scriptInjectionDeferred'])==null?void 0x0:_0x265c86['promise'];})['then'](()=>{_0x659eba(_0x21eb70,_0x406406,_0x31a436);})['catch'](_0xca27e9=>{_0x31a436(_0xca27e9);});}})['catch'](_0x24e005=>{_0x31a436(_0x24e005);});});}}le['scriptInjectionDeferred']=null;async function br(_0x28593c,_0xe84543,_0x3c6de8,_0x220261=!0x1,_0x290b8d=!0x1){const _0x1a1009=new le(_0x28593c);let _0x2212b5;if(_0x290b8d)_0x2212b5=Ma;else try{_0x2212b5=await _0x1a1009['verify'](_0x3c6de8);}catch{_0x2212b5=await _0x1a1009['verify'](_0x3c6de8,!0x0);}const _0x3e7d95={..._0xe84543};if(_0x3c6de8==='mfaSmsEnrollment'||_0x3c6de8==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3e7d95){const _0x2018eb=_0x3e7d95['phoneEnrollmentInfo']['phoneNumber'],_0x771e62=_0x3e7d95['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3e7d95,{'phoneEnrollmentInfo':{'phoneNumber':_0x2018eb,'recaptchaToken':_0x771e62,'captchaResponse':_0x2212b5,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3e7d95){const _0x2ca07a=_0x3e7d95['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3e7d95,{'phoneSignInInfo':{'recaptchaToken':_0x2ca07a,'captchaResponse':_0x2212b5,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3e7d95;}return _0x220261?Object['assign'](_0x3e7d95,{'captchaResp':_0x2212b5}):Object['assign'](_0x3e7d95,{'captchaResponse':_0x2212b5}),Object['assign'](_0x3e7d95,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3e7d95,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3e7d95;}async function Oi(_0xaab9d9,_0x1dbe4c,_0x5369da,_0x53f020,_0x26af44){var _0x3ed9c7;if((_0x3ed9c7=_0xaab9d9['_getRecaptchaConfig']())!=null&&_0x3ed9c7['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3831ab=await br(_0xaab9d9,_0x1dbe4c,_0x5369da,_0x5369da==='getOobCode');return _0x53f020(_0xaab9d9,_0x3831ab);}else return _0x53f020(_0xaab9d9,_0x1dbe4c)['catch'](async _0x170994=>{if(_0x170994['code']==='auth/missing-recaptcha-token'){console['log'](_0x5369da+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x488f20=await br(_0xaab9d9,_0x1dbe4c,_0x5369da,_0x5369da==='getOobCode');return _0x53f020(_0xaab9d9,_0x488f20);}else return Promise['reject'](_0x170994);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x7389c4,_0x3d0da7){const _0x527522=Ui(_0x7389c4,'auth');if(_0x527522['isInitialized']()){const _0x8c5c84=_0x527522['getImmediate'](),_0x4c1ded=_0x527522['getOptions']();if(De(_0x4c1ded,_0x3d0da7??{}))return _0x8c5c84;K(_0x8c5c84,'already-initialized');}return _0x527522['initialize']({'options':_0x3d0da7});}function Lf(_0x574718,_0x1607be){const _0x295145=(_0x1607be==null?void 0x0:_0x1607be['persistence'])||[],_0x3f3e01=(Array['isArray'](_0x295145)?_0x295145:[_0x295145])['map'](ne);_0x1607be!=null&&_0x1607be['errorMap']&&_0x574718['_updateErrorMap'](_0x1607be['errorMap']),_0x574718['_initializeWithPersistence'](_0x3f3e01,_0x1607be==null?void 0x0:_0x1607be['popupRedirectResolver']);}function xf(_0x31b581,_0x5acbd1,_0x2ebcdf){const _0x4ea74c=qe(_0x31b581);m(/^https?:\/\//['test'](_0x5acbd1),_0x4ea74c,'invalid-emulator-scheme');const _0x4f0361=!0x1,_0x21b435=La(_0x5acbd1),{host:_0x504365,port:_0x3c0a41}=Ff(_0x5acbd1),_0x3bd9e4=_0x3c0a41===null?'':':'+_0x3c0a41,_0x25e41e={'url':_0x21b435+'//'+_0x504365+_0x3bd9e4+'/'},_0x3be8bf=Object['freeze']({'host':_0x504365,'port':_0x3c0a41,'protocol':_0x21b435['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4f0361})});if(!_0x4ea74c['_canInitEmulator']){m(_0x4ea74c['config']['emulator']&&_0x4ea74c['emulatorConfig'],_0x4ea74c,'emulator-config-failed'),m(De(_0x25e41e,_0x4ea74c['config']['emulator'])&&De(_0x3be8bf,_0x4ea74c['emulatorConfig']),_0x4ea74c,'emulator-config-failed');return;}_0x4ea74c['config']['emulator']=_0x25e41e,_0x4ea74c['emulatorConfig']=_0x3be8bf,_0x4ea74c['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x504365)?jr(_0x21b435+'//'+_0x504365+_0x3bd9e4):Uf();}function La(_0x10ea33){const _0x5d2a09=_0x10ea33['indexOf'](':');return _0x5d2a09<0x0?'':_0x10ea33['substr'](0x0,_0x5d2a09+0x1);}function Ff(_0x2de1b6){const _0x4f0be5=La(_0x2de1b6),_0x303670=/(\/\/)?([^?#/]+)/['exec'](_0x2de1b6['substr'](_0x4f0be5['length']));if(!_0x303670)return{'host':'','port':null};const _0x41546e=_0x303670[0x2]['split']('@')['pop']()||'',_0x872d2a=/^(\[[^\]]+\])(:|$)/['exec'](_0x41546e);if(_0x872d2a){const _0x27a144=_0x872d2a[0x1];return{'host':_0x27a144,'port':Rr(_0x41546e['substr'](_0x27a144['length']+0x1))};}else{const [_0xf07bd2,_0xa675de]=_0x41546e['split'](':');return{'host':_0xf07bd2,'port':Rr(_0xa675de)};}}function Rr(_0xb6239f){if(!_0xb6239f)return null;const _0x3d01aa=Number(_0xb6239f);return isNaN(_0x3d01aa)?null:_0x3d01aa;}function Uf(){function _0x44d3e7(){const _0x39d753=document['createElement']('p'),_0xee53a5=_0x39d753['style'];_0x39d753['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xee53a5['position']='fixed',_0xee53a5['width']='100%',_0xee53a5['backgroundColor']='#ffffff',_0xee53a5['border']='.1em\x20solid\x20#000000',_0xee53a5['color']='#b50000',_0xee53a5['bottom']='0px',_0xee53a5['left']='0px',_0xee53a5['margin']='0px',_0xee53a5['zIndex']='10000',_0xee53a5['textAlign']='center',_0x39d753['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x39d753);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x44d3e7):_0x44d3e7());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x1fbfce,_0x42a700){this['providerId']=_0x1fbfce,this['signInMethod']=_0x42a700;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x3b8098){return te('not\x20implemented');}['_linkToIdToken'](_0x43e661,_0x83f82d){return te('not\x20implemented');}['_getReauthenticationResolver'](_0xc17ea3){return te('not\x20implemented');}}async function Wf(_0x507182,_0xc94709){return Ae(_0x507182,'POST','/v1/accounts:signUp',_0xc94709);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x5cbcaf,_0x5c8271){return Yt(_0x5cbcaf,'POST','/v1/accounts:signInWithPassword',Re(_0x5cbcaf,_0x5c8271));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x5077d3,_0x369518){return Yt(_0x5077d3,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5077d3,_0x369518));}async function Hf(_0x19a805,_0x18aaa3){return Yt(_0x19a805,'POST','/v1/accounts:signInWithEmailLink',Re(_0x19a805,_0x18aaa3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x404fa7,_0xfef6cc,_0x29cec1,_0x3264d1=null){super('password',_0x29cec1),this['_email']=_0x404fa7,this['_password']=_0xfef6cc,this['_tenantId']=_0x3264d1;}static['_fromEmailAndPassword'](_0x1a4c5c,_0x4d7403){return new Ft(_0x1a4c5c,_0x4d7403,'password');}static['_fromEmailAndCode'](_0x2878b6,_0x12b648,_0xa1030f=null){return new Ft(_0x2878b6,_0x12b648,'emailLink',_0xa1030f);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x429b92){const _0x7cf172=typeof _0x429b92=='string'?JSON['parse'](_0x429b92):_0x429b92;if(_0x7cf172!=null&&_0x7cf172['email']&&(_0x7cf172!=null&&_0x7cf172['password'])){if(_0x7cf172['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x7cf172['email'],_0x7cf172['password']);if(_0x7cf172['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x7cf172['email'],_0x7cf172['password'],_0x7cf172['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3e4049){switch(this['signInMethod']){case'password':const _0x3069c0={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x3e4049,_0x3069c0,'signInWithPassword',Bf);case'emailLink':return Vf(_0x3e4049,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x3e4049,'internal-error');}}async['_linkToIdToken'](_0x10e76c,_0x52b3be){switch(this['signInMethod']){case'password':const _0x4c9011={'idToken':_0x52b3be,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x10e76c,_0x4c9011,'signUpPassword',Wf);case'emailLink':return Hf(_0x10e76c,{'idToken':_0x52b3be,'email':this['_email'],'oobCode':this['_password']});default:K(_0x10e76c,'internal-error');}}['_getReauthenticationResolver'](_0x27765c){return this['_getIdTokenResponse'](_0x27765c);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x19871f,_0x1e770a){return Yt(_0x19871f,'POST','/v1/accounts:signInWithIdp',Re(_0x19871f,_0x1e770a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x540cb1){const _0xf1eb69=new We(_0x540cb1['providerId'],_0x540cb1['signInMethod']);return _0x540cb1['idToken']||_0x540cb1['accessToken']?(_0x540cb1['idToken']&&(_0xf1eb69['idToken']=_0x540cb1['idToken']),_0x540cb1['accessToken']&&(_0xf1eb69['accessToken']=_0x540cb1['accessToken']),_0x540cb1['nonce']&&!_0x540cb1['pendingToken']&&(_0xf1eb69['nonce']=_0x540cb1['nonce']),_0x540cb1['pendingToken']&&(_0xf1eb69['pendingToken']=_0x540cb1['pendingToken'])):_0x540cb1['oauthToken']&&_0x540cb1['oauthTokenSecret']?(_0xf1eb69['accessToken']=_0x540cb1['oauthToken'],_0xf1eb69['secret']=_0x540cb1['oauthTokenSecret']):K('argument-error'),_0xf1eb69;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x11af9e){const _0x3c69fd=typeof _0x11af9e=='string'?JSON['parse'](_0x11af9e):_0x11af9e,{providerId:_0x18823d,signInMethod:_0x446c63,..._0x30a88c}=_0x3c69fd;if(!_0x18823d||!_0x446c63)return null;const _0x4cd63e=new We(_0x18823d,_0x446c63);return _0x4cd63e['idToken']=_0x30a88c['idToken']||void 0x0,_0x4cd63e['accessToken']=_0x30a88c['accessToken']||void 0x0,_0x4cd63e['secret']=_0x30a88c['secret'],_0x4cd63e['nonce']=_0x30a88c['nonce'],_0x4cd63e['pendingToken']=_0x30a88c['pendingToken']||null,_0x4cd63e;}['_getIdTokenResponse'](_0x1f5b18){const _0xf0b826=this['buildRequest']();return Ze(_0x1f5b18,_0xf0b826);}['_linkToIdToken'](_0x3894ca,_0x5b1208){const _0x187114=this['buildRequest']();return _0x187114['idToken']=_0x5b1208,Ze(_0x3894ca,_0x187114);}['_getReauthenticationResolver'](_0x5e8574){const _0x4f5e26=this['buildRequest']();return _0x4f5e26['autoCreate']=!0x1,Ze(_0x5e8574,_0x4f5e26);}['buildRequest'](){const _0x215704={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x215704['pendingToken']=this['pendingToken'];else{const _0x471641={};this['idToken']&&(_0x471641['id_token']=this['idToken']),this['accessToken']&&(_0x471641['access_token']=this['accessToken']),this['secret']&&(_0x471641['oauth_token_secret']=this['secret']),_0x471641['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x471641['nonce']=this['nonce']),_0x215704['postBody']=at(_0x471641);}return _0x215704;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x229271){switch(_0x229271){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x491591){const _0x5b806d=yt(vt(_0x491591))['link'],_0x5f0d04=_0x5b806d?yt(vt(_0x5b806d))['deep_link_id']:null,_0x4f50c0=yt(vt(_0x491591))['deep_link_id'];return(_0x4f50c0?yt(vt(_0x4f50c0))['link']:null)||_0x4f50c0||_0x5f0d04||_0x5b806d||_0x491591;}class Ss{constructor(_0x7650d3){const _0x143467=yt(vt(_0x7650d3)),_0x4dc040=_0x143467['apiKey']??null,_0x4d3cf0=_0x143467['oobCode']??null,_0x476370=Gf(_0x143467['mode']??null);m(_0x4dc040&&_0x4d3cf0&&_0x476370,'argument-error'),this['apiKey']=_0x4dc040,this['operation']=_0x476370,this['code']=_0x4d3cf0,this['continueUrl']=_0x143467['continueUrl']??null,this['languageCode']=_0x143467['lang']??null,this['tenantId']=_0x143467['tenantId']??null;}static['parseLink'](_0x183079){const _0xc44a4b=qf(_0x183079);try{return new Ss(_0xc44a4b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x1c1811,_0x1c8551){return Ft['_fromEmailAndPassword'](_0x1c1811,_0x1c8551);}static['credentialWithLink'](_0x8a6c8e,_0x3217aa){const _0x51e802=Ss['parseLink'](_0x3217aa);return m(_0x51e802,'argument-error'),Ft['_fromEmailAndCode'](_0x8a6c8e,_0x51e802['code'],_0x51e802['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x40d2c1){this['providerId']=_0x40d2c1,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x47f3cc){this['defaultLanguageCode']=_0x47f3cc;}['setCustomParameters'](_0xb1f7f8){return this['customParameters']=_0xb1f7f8,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1fee3f){return this['scopes']['includes'](_0x1fee3f)||this['scopes']['push'](_0x1fee3f),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x150219){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x150219});}static['credentialFromResult'](_0x12c58a){return he['credentialFromTaggedObject'](_0x12c58a);}static['credentialFromError'](_0x464484){return he['credentialFromTaggedObject'](_0x464484['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2c906b}){if(!_0x2c906b||!('oauthAccessToken'in _0x2c906b)||!_0x2c906b['oauthAccessToken'])return null;try{return he['credential'](_0x2c906b['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xd8333c,_0xf8e2c6){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xd8333c,'accessToken':_0xf8e2c6});}static['credentialFromResult'](_0x728734){return ue['credentialFromTaggedObject'](_0x728734);}static['credentialFromError'](_0x49bdf6){return ue['credentialFromTaggedObject'](_0x49bdf6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x407e2e}){if(!_0x407e2e)return null;const {oauthIdToken:_0x1a72a6,oauthAccessToken:_0x32e930}=_0x407e2e;if(!_0x1a72a6&&!_0x32e930)return null;try{return ue['credential'](_0x1a72a6,_0x32e930);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x138410){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x138410});}static['credentialFromResult'](_0x4ae5e4){return de['credentialFromTaggedObject'](_0x4ae5e4);}static['credentialFromError'](_0x12037a){return de['credentialFromTaggedObject'](_0x12037a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5d207d}){if(!_0x5d207d||!('oauthAccessToken'in _0x5d207d)||!_0x5d207d['oauthAccessToken'])return null;try{return de['credential'](_0x5d207d['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x29dc21,_0x457525){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x29dc21,'oauthTokenSecret':_0x457525});}static['credentialFromResult'](_0x1e7119){return fe['credentialFromTaggedObject'](_0x1e7119);}static['credentialFromError'](_0x2feba8){return fe['credentialFromTaggedObject'](_0x2feba8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x36df8f}){if(!_0x36df8f)return null;const {oauthAccessToken:_0x1bfca2,oauthTokenSecret:_0x1c13b4}=_0x36df8f;if(!_0x1bfca2||!_0x1c13b4)return null;try{return fe['credential'](_0x1bfca2,_0x1c13b4);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x21ac44,_0x5e85f7){return Yt(_0x21ac44,'POST','/v1/accounts:signUp',Re(_0x21ac44,_0x5e85f7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x3e24c3){this['user']=_0x3e24c3['user'],this['providerId']=_0x3e24c3['providerId'],this['_tokenResponse']=_0x3e24c3['_tokenResponse'],this['operationType']=_0x3e24c3['operationType'];}static async['_fromIdTokenResponse'](_0x42c53a,_0x3f0bc0,_0x7cdcd6,_0x4a820f=!0x1){const _0x50f8e2=await z['_fromIdTokenResponse'](_0x42c53a,_0x7cdcd6,_0x4a820f),_0x1264a1=Ar(_0x7cdcd6);return new Be({'user':_0x50f8e2,'providerId':_0x1264a1,'_tokenResponse':_0x7cdcd6,'operationType':_0x3f0bc0});}static async['_forOperation'](_0x11d13a,_0x30da70,_0xa1b5a4){await _0x11d13a['_updateTokensIfNecessary'](_0xa1b5a4,!0x0);const _0xfe5d1a=Ar(_0xa1b5a4);return new Be({'user':_0x11d13a,'providerId':_0xfe5d1a,'_tokenResponse':_0xa1b5a4,'operationType':_0x30da70});}}function Ar(_0x2e13bb){return _0x2e13bb['providerId']?_0x2e13bb['providerId']:'phoneNumber'in _0x2e13bb?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x44c61a,_0x2da8a7,_0x3e3f32,_0x45fd63){super(_0x2da8a7['code'],_0x2da8a7['message']),this['operationType']=_0x3e3f32,this['user']=_0x45fd63,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x44c61a['name'],'tenantId':_0x44c61a['tenantId']??void 0x0,'_serverResponse':_0x2da8a7['customData']['_serverResponse'],'operationType':_0x3e3f32};}static['_fromErrorAndOperation'](_0x554e77,_0x4ccad1,_0x4ad9e3,_0xb983bd){return new Rn(_0x554e77,_0x4ccad1,_0x4ad9e3,_0xb983bd);}}function Fa(_0x16ad35,_0x153181,_0x52e975,_0xa90872){return(_0x153181==='reauthenticate'?_0x52e975['_getReauthenticationResolver'](_0x16ad35):_0x52e975['_getIdTokenResponse'](_0x16ad35))['catch'](_0x36c323=>{throw _0x36c323['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x16ad35,_0x36c323,_0x153181,_0xa90872):_0x36c323;});}async function jf(_0x5a1e17,_0x243036,_0x108464=!0x1){const _0x56042d=await xt(_0x5a1e17,_0x243036['_linkToIdToken'](_0x5a1e17['auth'],await _0x5a1e17['getIdToken']()),_0x108464);return Be['_forOperation'](_0x5a1e17,'link',_0x56042d);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x4e6654,_0x15dcd4,_0x4f5d5f=!0x1){const {auth:_0x498bf3}=_0x4e6654;if(H(_0x498bf3['app']))return Promise['reject'](se(_0x498bf3));const _0x2bdfa6='reauthenticate';try{const _0x2e2668=await xt(_0x4e6654,Fa(_0x498bf3,_0x2bdfa6,_0x15dcd4,_0x4e6654),_0x4f5d5f);m(_0x2e2668['idToken'],_0x498bf3,'internal-error');const _0x595125=ws(_0x2e2668['idToken']);m(_0x595125,_0x498bf3,'internal-error');const {sub:_0x1d2fc6}=_0x595125;return m(_0x4e6654['uid']===_0x1d2fc6,_0x498bf3,'user-mismatch'),Be['_forOperation'](_0x4e6654,_0x2bdfa6,_0x2e2668);}catch(_0xa37cbb){throw(_0xa37cbb==null?void 0x0:_0xa37cbb['code'])==='auth/user-not-found'&&K(_0x498bf3,'user-mismatch'),_0xa37cbb;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x49b352,_0x794019,_0x5953ed=!0x1){if(H(_0x49b352['app']))return Promise['reject'](se(_0x49b352));const _0x3d16f2='signIn',_0x16b19a=await Fa(_0x49b352,_0x3d16f2,_0x794019),_0x7ace24=await Be['_fromIdTokenResponse'](_0x49b352,_0x3d16f2,_0x16b19a);return _0x5953ed||await _0x49b352['_updateCurrentUser'](_0x7ace24['user']),_0x7ace24;}async function Yf(_0x419383,_0x291dd4){return Ua(qe(_0x419383),_0x291dd4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x3a13b0){const _0x30a516=qe(_0x3a13b0);_0x30a516['_getPasswordPolicyInternal']()&&await _0x30a516['_updatePasswordPolicy']();}async function R_(_0x9ac538,_0x38a0ae,_0x36ad56){if(H(_0x9ac538['app']))return Promise['reject'](se(_0x9ac538));const _0x3af204=qe(_0x9ac538),_0x4a4dd4=await Oi(_0x3af204,{'returnSecureToken':!0x0,'email':_0x38a0ae,'password':_0x36ad56,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x1a8774=>{throw _0x1a8774['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x9ac538),_0x1a8774;}),_0x28bd23=await Be['_fromIdTokenResponse'](_0x3af204,'signIn',_0x4a4dd4);return await _0x3af204['_updateCurrentUser'](_0x28bd23['user']),_0x28bd23;}function A_(_0x39a4ef,_0x2d0cc4,_0x58c67a){return H(_0x39a4ef['app'])?Promise['reject'](se(_0x39a4ef)):Yf(k(_0x39a4ef),ft['credential'](_0x2d0cc4,_0x58c67a))['catch'](async _0x519255=>{throw _0x519255['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x39a4ef),_0x519255;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x10d876,_0x16e178){return k(_0x10d876)['setPersistence'](_0x16e178);}function Qf(_0x1ac6c2,_0x32f3e9,_0x572037,_0x3f2d67){return k(_0x1ac6c2)['onIdTokenChanged'](_0x32f3e9,_0x572037,_0x3f2d67);}function Jf(_0x24c49b,_0x5d3e68,_0x4429ab){return k(_0x24c49b)['beforeAuthStateChanged'](_0x5d3e68,_0x4429ab);}function N_(_0x3d684b,_0x5ec812,_0xf4100b,_0x5969e7){return k(_0x3d684b)['onAuthStateChanged'](_0x5ec812,_0xf4100b,_0x5969e7);}function P_(_0x3902be){return k(_0x3902be)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x49d180,_0x47ffb3){this['storageRetriever']=_0x49d180,this['type']=_0x47ffb3;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x22a542,_0x1830fe){return this['storage']['setItem'](_0x22a542,JSON['stringify'](_0x1830fe)),Promise['resolve']();}['_get'](_0x558438){const _0x11a31e=this['storage']['getItem'](_0x558438);return Promise['resolve'](_0x11a31e?JSON['parse'](_0x11a31e):null);}['_remove'](_0xd212da){return this['storage']['removeItem'](_0xd212da),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3772e5,_0x33a171)=>this['onStorageEvent'](_0x3772e5,_0x33a171),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x25763f){for(const _0x18bf97 of Object['keys'](this['listeners'])){const _0x282a24=this['storage']['getItem'](_0x18bf97),_0x563e58=this['localCache'][_0x18bf97];_0x282a24!==_0x563e58&&_0x25763f(_0x18bf97,_0x563e58,_0x282a24);}}['onStorageEvent'](_0x269982,_0x1130a3=!0x1){if(!_0x269982['key']){this['forAllChangedKeys']((_0x51cf95,_0x1b8b15,_0x5022be)=>{this['notifyListeners'](_0x51cf95,_0x5022be);});return;}const _0x2294c3=_0x269982['key'];_0x1130a3?this['detachListener']():this['stopPolling']();const _0x34ea2f=()=>{const _0x278fc5=this['storage']['getItem'](_0x2294c3);!_0x1130a3&&this['localCache'][_0x2294c3]===_0x278fc5||this['notifyListeners'](_0x2294c3,_0x278fc5);},_0x33f5ef=this['storage']['getItem'](_0x2294c3);If()&&_0x33f5ef!==_0x269982['newValue']&&_0x269982['newValue']!==_0x269982['oldValue']?setTimeout(_0x34ea2f,Zf):_0x34ea2f();}['notifyListeners'](_0x42b570,_0x588f86){this['localCache'][_0x42b570]=_0x588f86;const _0x32e0f6=this['listeners'][_0x42b570];if(_0x32e0f6){for(const _0xaa5578 of Array['from'](_0x32e0f6))_0xaa5578(_0x588f86&&JSON['parse'](_0x588f86));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x814916,_0x4b1357,_0x5c6196)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x814916,'oldValue':_0x4b1357,'newValue':_0x5c6196}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x9f0dec,_0x69f430){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x9f0dec]||(this['listeners'][_0x9f0dec]=new Set(),this['localCache'][_0x9f0dec]=this['storage']['getItem'](_0x9f0dec)),this['listeners'][_0x9f0dec]['add'](_0x69f430);}['_removeListener'](_0x3da8b6,_0x337ebe){this['listeners'][_0x3da8b6]&&(this['listeners'][_0x3da8b6]['delete'](_0x337ebe),this['listeners'][_0x3da8b6]['size']===0x0&&delete this['listeners'][_0x3da8b6]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3346e5,_0x4467b2){await super['_set'](_0x3346e5,_0x4467b2),this['localCache'][_0x3346e5]=JSON['stringify'](_0x4467b2);}async['_get'](_0xcacea){const _0x3d416a=await super['_get'](_0xcacea);return this['localCache'][_0xcacea]=JSON['stringify'](_0x3d416a),_0x3d416a;}async['_remove'](_0x153977){await super['_remove'](_0x153977),delete this['localCache'][_0x153977];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x23d1b4,_0x263869){}['_removeListener'](_0x4b62c3,_0x238543){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x38213d){return Promise['all'](_0x38213d['map'](async _0x569919=>{try{return{'fulfilled':!0x0,'value':await _0x569919};}catch(_0x3ef937){return{'fulfilled':!0x1,'reason':_0x3ef937};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x38149a){this['eventTarget']=_0x38149a,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x30b9ce){const _0x1e20a0=this['receivers']['find'](_0x4cebf2=>_0x4cebf2['isListeningto'](_0x30b9ce));if(_0x1e20a0)return _0x1e20a0;const _0x5c0eba=new jn(_0x30b9ce);return this['receivers']['push'](_0x5c0eba),_0x5c0eba;}['isListeningto'](_0x400398){return this['eventTarget']===_0x400398;}async['handleEvent'](_0x370a0f){const _0x5aba34=_0x370a0f,{eventId:_0x5b5d90,eventType:_0x4fb2a0,data:_0x421d65}=_0x5aba34['data'],_0x14546a=this['handlersMap'][_0x4fb2a0];if(!(_0x14546a!=null&&_0x14546a['size']))return;_0x5aba34['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x5b5d90,'eventType':_0x4fb2a0});const _0x1d5bc2=Array['from'](_0x14546a)['map'](async _0x1a6a75=>_0x1a6a75(_0x5aba34['origin'],_0x421d65)),_0x2c51ab=await tp(_0x1d5bc2);_0x5aba34['ports'][0x0]['postMessage']({'status':'done','eventId':_0x5b5d90,'eventType':_0x4fb2a0,'response':_0x2c51ab});}['_subscribe'](_0x3954ec,_0x1620f3){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3954ec]||(this['handlersMap'][_0x3954ec]=new Set()),this['handlersMap'][_0x3954ec]['add'](_0x1620f3);}['_unsubscribe'](_0x3db443,_0x45735d){this['handlersMap'][_0x3db443]&&_0x45735d&&this['handlersMap'][_0x3db443]['delete'](_0x45735d),(!_0x45735d||this['handlersMap'][_0x3db443]['size']===0x0)&&delete this['handlersMap'][_0x3db443],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x761e99='',_0x3fabac=0xa){let _0x3aca3d='';for(let _0x34ce07=0x0;_0x34ce07<_0x3fabac;_0x34ce07++)_0x3aca3d+=Math['floor'](Math['random']()*0xa);return _0x761e99+_0x3aca3d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x24cdb3){this['target']=_0x24cdb3,this['handlers']=new Set();}['removeMessageHandler'](_0x414b57){_0x414b57['messageChannel']&&(_0x414b57['messageChannel']['port1']['removeEventListener']('message',_0x414b57['onMessage']),_0x414b57['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x414b57);}async['_send'](_0x5130d,_0x1e9d28,_0x3c7b88=0x32){const _0x25eba7=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x25eba7)throw new Error('connection_unavailable');let _0x419fc2,_0xd0fe14;return new Promise((_0x3541d9,_0x468182)=>{const _0x4ab004=bs('',0x14);_0x25eba7['port1']['start']();const _0x49c793=setTimeout(()=>{_0x468182(new Error('unsupported_event'));},_0x3c7b88);_0xd0fe14={'messageChannel':_0x25eba7,'onMessage'(_0x29acb9){const _0x1b3550=_0x29acb9;if(_0x1b3550['data']['eventId']===_0x4ab004)switch(_0x1b3550['data']['status']){case'ack':clearTimeout(_0x49c793),_0x419fc2=setTimeout(()=>{_0x468182(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x419fc2),_0x3541d9(_0x1b3550['data']['response']);break;default:clearTimeout(_0x49c793),clearTimeout(_0x419fc2),_0x468182(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xd0fe14),_0x25eba7['port1']['addEventListener']('message',_0xd0fe14['onMessage']),this['target']['postMessage']({'eventType':_0x5130d,'eventId':_0x4ab004,'data':_0x1e9d28},[_0x25eba7['port2']]);})['finally'](()=>{_0xd0fe14&&this['removeMessageHandler'](_0xd0fe14);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x4532ce){X()['location']['href']=_0x4532ce;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x3df4ec;return((_0x3df4ec=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3df4ec['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x213904){this['request']=_0x213904;}['toPromise'](){return new Promise((_0x2048a8,_0xb2b017)=>{this['request']['addEventListener']('success',()=>{_0x2048a8(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xb2b017(this['request']['error']);});});}}function Kn(_0x49971b,_0x2ee449){return _0x49971b['transaction']([kn],_0x2ee449?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x4b285c=indexedDB['deleteDatabase'](qa);return new Jt(_0x4b285c)['toPromise']();}function ja(){const _0x317acf=indexedDB['open'](qa,ap);return new Promise((_0x51435c,_0x5ceeea)=>{_0x317acf['addEventListener']('error',()=>{_0x5ceeea(_0x317acf['error']);}),_0x317acf['addEventListener']('upgradeneeded',()=>{const _0xf4461d=_0x317acf['result'];try{_0xf4461d['createObjectStore'](kn,{'keyPath':za});}catch(_0x178922){_0x5ceeea(_0x178922);}}),_0x317acf['addEventListener']('success',async()=>{const _0x30f6e3=_0x317acf['result'];_0x30f6e3['objectStoreNames']['contains'](kn)?_0x51435c(_0x30f6e3):(_0x30f6e3['close'](),await cp(),_0x51435c(await ja()));});});}async function kr(_0xbb42b5,_0x1f05f9,_0x1d8733){const _0x223dc4=Kn(_0xbb42b5,!0x0)['put']({[za]:_0x1f05f9,'value':_0x1d8733});return new Jt(_0x223dc4)['toPromise']();}async function lp(_0x44aa7b,_0x34dd93){const _0x1cb021=Kn(_0x44aa7b,!0x1)['get'](_0x34dd93),_0x4d6752=await new Jt(_0x1cb021)['toPromise']();return _0x4d6752===void 0x0?null:_0x4d6752['value'];}function Nr(_0x5cab6b,_0x248ffa){const _0x1358ef=Kn(_0x5cab6b,!0x0)['delete'](_0x248ffa);return new Jt(_0x1358ef)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x23c262){let _0x117cb5=0x0;for(;;)try{const _0x3de3a9=await this['_openDb']();return await _0x23c262(_0x3de3a9);}catch(_0x17d52a){if(_0x117cb5++>up)throw _0x17d52a;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x3481e6,_0x1e6447)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1e6447['key'])})),this['receiver']['_subscribe']('ping',async(_0x3a0568,_0x42f748)=>['keyChanged']);}async['initializeSender'](){var _0x468f30,_0x292a0c;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x23c27b=await this['sender']['_send']('ping',{},0x320);_0x23c27b&&(_0x468f30=_0x23c27b[0x0])!=null&&_0x468f30['fulfilled']&&(_0x292a0c=_0x23c27b[0x0])!=null&&_0x292a0c['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4c42e4){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4c42e4},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5ca486=>{await kr(_0x5ca486,An,'1'),await Nr(_0x5ca486,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x416bb0){this['pendingWrites']++;try{await _0x416bb0();}finally{this['pendingWrites']--;}}async['_set'](_0x4ff50b,_0x5575d0){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x37209f=>kr(_0x37209f,_0x4ff50b,_0x5575d0)),this['localCache'][_0x4ff50b]=_0x5575d0,this['notifyServiceWorker'](_0x4ff50b)));}async['_get'](_0x2a1993){const _0x373622=await this['_withRetries'](_0xf7d6a1=>lp(_0xf7d6a1,_0x2a1993));return this['localCache'][_0x2a1993]=_0x373622,_0x373622;}async['_remove'](_0x1dacdf){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x39495c=>Nr(_0x39495c,_0x1dacdf)),delete this['localCache'][_0x1dacdf],this['notifyServiceWorker'](_0x1dacdf)));}async['_poll'](){const _0x21635e=await this['_withRetries'](_0x433ee4=>{const _0x1a5d3e=Kn(_0x433ee4,!0x1)['getAll']();return new Jt(_0x1a5d3e)['toPromise']();});if(!_0x21635e)return[];if(this['pendingWrites']!==0x0)return[];const _0x2ccc72=[],_0x440594=new Set();if(_0x21635e['length']!==0x0){for(const {fbase_key:_0x36a035,value:_0x4db487}of _0x21635e)_0x440594['add'](_0x36a035),JSON['stringify'](this['localCache'][_0x36a035])!==JSON['stringify'](_0x4db487)&&(this['notifyListeners'](_0x36a035,_0x4db487),_0x2ccc72['push'](_0x36a035));}for(const _0x56424b of Object['keys'](this['localCache']))this['localCache'][_0x56424b]&&!_0x440594['has'](_0x56424b)&&(this['notifyListeners'](_0x56424b,null),_0x2ccc72['push'](_0x56424b));return _0x2ccc72;}['notifyListeners'](_0x5a88d9,_0x51ed28){this['localCache'][_0x5a88d9]=_0x51ed28;const _0x1de46d=this['listeners'][_0x5a88d9];if(_0x1de46d){for(const _0x3c91a0 of Array['from'](_0x1de46d))_0x3c91a0(_0x51ed28);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x355dc7,_0x44e082){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x355dc7]||(this['listeners'][_0x355dc7]=new Set(),this['_get'](_0x355dc7)),this['listeners'][_0x355dc7]['add'](_0x44e082);}['_removeListener'](_0x531447,_0xad6c28){this['listeners'][_0x531447]&&(this['listeners'][_0x531447]['delete'](_0xad6c28),this['listeners'][_0x531447]['size']===0x0&&delete this['listeners'][_0x531447]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x51b154,_0x2813cf){return _0x2813cf?ne(_0x2813cf):(m(_0x51b154['_popupRedirectResolver'],_0x51b154,'argument-error'),_0x51b154['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x4e22e4){super('custom','custom'),this['params']=_0x4e22e4;}['_getIdTokenResponse'](_0x2cb6c2){return Ze(_0x2cb6c2,this['_buildIdpRequest']());}['_linkToIdToken'](_0x27704e,_0x24d78c){return Ze(_0x27704e,this['_buildIdpRequest'](_0x24d78c));}['_getReauthenticationResolver'](_0x270d93){return Ze(_0x270d93,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x5395cd){const _0x556d5a={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x5395cd&&(_0x556d5a['idToken']=_0x5395cd),_0x556d5a;}}function pp(_0x76980d){return Ua(_0x76980d['auth'],new Rs(_0x76980d),_0x76980d['bypassAuthState']);}function _p(_0xda890a){const {auth:_0x482a1c,user:_0x5df609}=_0xda890a;return m(_0x5df609,_0x482a1c,'internal-error'),Kf(_0x5df609,new Rs(_0xda890a),_0xda890a['bypassAuthState']);}async function gp(_0x24adde){const {auth:_0x777053,user:_0x2d34d5}=_0x24adde;return m(_0x2d34d5,_0x777053,'internal-error'),jf(_0x2d34d5,new Rs(_0x24adde),_0x24adde['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x272477,_0x3f8bec,_0x5024ef,_0x18a2c5,_0x4351eb=!0x1){this['auth']=_0x272477,this['resolver']=_0x5024ef,this['user']=_0x18a2c5,this['bypassAuthState']=_0x4351eb,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3f8bec)?_0x3f8bec:[_0x3f8bec];}['execute'](){return new Promise(async(_0x4c5d1b,_0x2221d9)=>{this['pendingPromise']={'resolve':_0x4c5d1b,'reject':_0x2221d9};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x10651e){this['reject'](_0x10651e);}});}async['onAuthEvent'](_0x553f8b){const {urlResponse:_0x57ab20,sessionId:_0xe24228,postBody:_0x3f601c,tenantId:_0x3f86e1,error:_0x2a76a4,type:_0x57210a}=_0x553f8b;if(_0x2a76a4){this['reject'](_0x2a76a4);return;}const _0x2ece05={'auth':this['auth'],'requestUri':_0x57ab20,'sessionId':_0xe24228,'tenantId':_0x3f86e1||void 0x0,'postBody':_0x3f601c||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x57210a)(_0x2ece05));}catch(_0x132ccc){this['reject'](_0x132ccc);}}['onError'](_0x202d7a){this['reject'](_0x202d7a);}['getIdpTask'](_0xc8af76){switch(_0xc8af76){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x48bbd8){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x48bbd8),this['unregisterAndCleanUp']();}['reject'](_0x245a95){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x245a95),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x4b0117,_0x2300d8,_0xd9ccdb,_0x552f6f,_0x33233c){super(_0x4b0117,_0x2300d8,_0x552f6f,_0x33233c),this['provider']=_0xd9ccdb,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x54ac3d=await this['execute']();return m(_0x54ac3d,this['auth'],'internal-error'),_0x54ac3d;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x516ff7=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x516ff7),this['authWindow']['associatedEvent']=_0x516ff7,this['resolver']['_originValidation'](this['auth'])['catch'](_0x25d410=>{this['reject'](_0x25d410);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x2ceca6=>{_0x2ceca6||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x25f43b;return((_0x25f43b=this['authWindow'])==null?void 0x0:_0x25f43b['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x46194c=()=>{var _0x252bca,_0x46f3a7;if((_0x46f3a7=(_0x252bca=this['authWindow'])==null?void 0x0:_0x252bca['window'])!=null&&_0x46f3a7['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x46194c,mp['get']());};_0x46194c();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x55da68,_0x1118b7,_0x25d4d5=!0x1){super(_0x55da68,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x1118b7,void 0x0,_0x25d4d5),this['eventId']=null;}async['execute'](){let _0x24b7d2=rn['get'](this['auth']['_key']());if(!_0x24b7d2){try{const _0x5c3461=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x24b7d2=()=>Promise['resolve'](_0x5c3461);}catch(_0x4c67be){_0x24b7d2=()=>Promise['reject'](_0x4c67be);}rn['set'](this['auth']['_key'](),_0x24b7d2);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x24b7d2();}async['onAuthEvent'](_0xee46e1){if(_0xee46e1['type']==='signInViaRedirect')return super['onAuthEvent'](_0xee46e1);if(_0xee46e1['type']==='unknown'){this['resolve'](null);return;}if(_0xee46e1['eventId']){const _0x169117=await this['auth']['_redirectUserForId'](_0xee46e1['eventId']);if(_0x169117)return this['user']=_0x169117,super['onAuthEvent'](_0xee46e1);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x2ce706,_0xe56f8a){const _0xb138c=Cp(_0xe56f8a),_0x27a49f=wp(_0x2ce706);if(!await _0x27a49f['_isAvailable']())return!0x1;const _0x541765=await _0x27a49f['_get'](_0xb138c)==='true';return await _0x27a49f['_remove'](_0xb138c),_0x541765;}function Ip(_0x486008,_0x4b9fe5){rn['set'](_0x486008['_key'](),_0x4b9fe5);}function wp(_0xedba24){return ne(_0xedba24['_redirectPersistence']);}function Cp(_0x5b8dfe){return sn(yp,_0x5b8dfe['config']['apiKey'],_0x5b8dfe['name']);}async function Tp(_0x57a62a,_0x253d47,_0x2c46d7=!0x1){if(H(_0x57a62a['app']))return Promise['reject'](se(_0x57a62a));const _0x26a7b3=qe(_0x57a62a),_0x4517f1=fp(_0x26a7b3,_0x253d47),_0x43c87b=await new vp(_0x26a7b3,_0x4517f1,_0x2c46d7)['execute']();return _0x43c87b&&!_0x2c46d7&&(delete _0x43c87b['user']['_redirectEventId'],await _0x26a7b3['_persistUserIfCurrent'](_0x43c87b['user']),await _0x26a7b3['_setRedirectUser'](null,_0x253d47)),_0x43c87b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x29a92e){this['auth']=_0x29a92e,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1054b1){this['consumers']['add'](_0x1054b1),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1054b1)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1054b1),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x10689d){this['consumers']['delete'](_0x10689d);}['onEvent'](_0x4dd0af){if(this['hasEventBeenHandled'](_0x4dd0af))return!0x1;let _0x39c50a=!0x1;return this['consumers']['forEach'](_0x162951=>{this['isEventForConsumer'](_0x4dd0af,_0x162951)&&(_0x39c50a=!0x0,this['sendToConsumer'](_0x4dd0af,_0x162951),this['saveEventToCache'](_0x4dd0af));}),this['hasHandledPotentialRedirect']||!Rp(_0x4dd0af)||(this['hasHandledPotentialRedirect']=!0x0,_0x39c50a||(this['queuedRedirectEvent']=_0x4dd0af,_0x39c50a=!0x0)),_0x39c50a;}['sendToConsumer'](_0x345564,_0x278393){var _0x583345;if(_0x345564['error']&&!Qa(_0x345564)){const _0x330285=((_0x583345=_0x345564['error']['code'])==null?void 0x0:_0x583345['split']('auth/')[0x1])||'internal-error';_0x278393['onError'](J(this['auth'],_0x330285));}else _0x278393['onAuthEvent'](_0x345564);}['isEventForConsumer'](_0x377cee,_0x3288ef){const _0x46c67f=_0x3288ef['eventId']===null||!!_0x377cee['eventId']&&_0x377cee['eventId']===_0x3288ef['eventId'];return _0x3288ef['filter']['includes'](_0x377cee['type'])&&_0x46c67f;}['hasEventBeenHandled'](_0x5bdbcf){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x5bdbcf));}['saveEventToCache'](_0x375411){this['cachedEventUids']['add'](Pr(_0x375411)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x5d4d4d){return[_0x5d4d4d['type'],_0x5d4d4d['eventId'],_0x5d4d4d['sessionId'],_0x5d4d4d['tenantId']]['filter'](_0x5b706b=>_0x5b706b)['join']('-');}function Qa({type:_0x5874ba,error:_0x370eb2}){return _0x5874ba==='unknown'&&(_0x370eb2==null?void 0x0:_0x370eb2['code'])==='auth/no-auth-event';}function Rp(_0x2ceaab){switch(_0x2ceaab['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x2ceaab);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x34a78a,_0x4dc6a8={}){return Ae(_0x34a78a,'GET','/v1/projects',_0x4dc6a8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x5ca916){if(_0x5ca916['config']['emulator'])return;const {authorizedDomains:_0x31c850}=await Ap(_0x5ca916);for(const _0x45779d of _0x31c850)try{if(Op(_0x45779d))return;}catch{}K(_0x5ca916,'unauthorized-domain');}function Op(_0x233502){const _0x351e72=Ni(),{protocol:_0x24250e,hostname:_0x5955dc}=new URL(_0x351e72);if(_0x233502['startsWith']('chrome-extension://')){const _0x5abe2b=new URL(_0x233502);return _0x5abe2b['hostname']===''&&_0x5955dc===''?_0x24250e==='chrome-extension:'&&_0x233502['replace']('chrome-extension://','')===_0x351e72['replace']('chrome-extension://',''):_0x24250e==='chrome-extension:'&&_0x5abe2b['hostname']===_0x5955dc;}if(!Np['test'](_0x24250e))return!0x1;if(kp['test'](_0x233502))return _0x5955dc===_0x233502;const _0x1cf724=_0x233502['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x1cf724+'|'+_0x1cf724+')$','i')['test'](_0x5955dc);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x53fe6d=X()['___jsl'];if(_0x53fe6d!=null&&_0x53fe6d['H']){for(const _0x211ca8 of Object['keys'](_0x53fe6d['H']))if(_0x53fe6d['H'][_0x211ca8]['r']=_0x53fe6d['H'][_0x211ca8]['r']||[],_0x53fe6d['H'][_0x211ca8]['L']=_0x53fe6d['H'][_0x211ca8]['L']||[],_0x53fe6d['H'][_0x211ca8]['r']=[..._0x53fe6d['H'][_0x211ca8]['L']],_0x53fe6d['CP']){for(let _0x4f5d28=0x0;_0x4f5d28<_0x53fe6d['CP']['length'];_0x4f5d28++)_0x53fe6d['CP'][_0x4f5d28]=null;}}}function Mp(_0x2fd480){return new Promise((_0x48e450,_0x9e0462)=>{var _0x2a177e,_0x1a5716,_0x44e361;function _0x122eaa(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x48e450(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x9e0462(J(_0x2fd480,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x1a5716=(_0x2a177e=X()['gapi'])==null?void 0x0:_0x2a177e['iframes'])!=null&&_0x1a5716['Iframe'])_0x48e450(gapi['iframes']['getContext']());else{if((_0x44e361=X()['gapi'])!=null&&_0x44e361['load'])_0x122eaa();else{const _0x2b4214=Nf('iframefcb');return X()[_0x2b4214]=()=>{gapi['load']?_0x122eaa():_0x9e0462(J(_0x2fd480,'network-request-failed'));},Da(kf()+'?onload='+_0x2b4214)['catch'](_0x38e170=>_0x9e0462(_0x38e170));}}})['catch'](_0x1dc393=>{throw on=null,_0x1dc393;});}let on=null;function Lp(_0x33c611){return on=on||Mp(_0x33c611),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x47eaa9){const _0x1f44e2=_0x47eaa9['config'];m(_0x1f44e2['authDomain'],_0x47eaa9,'auth-domain-config-required');const _0x3d0fc3=_0x1f44e2['emulator']?Is(_0x1f44e2,Up):'https://'+_0x47eaa9['config']['authDomain']+'/'+Fp,_0x4998c6={'apiKey':_0x1f44e2['apiKey'],'appName':_0x47eaa9['name'],'v':ct},_0x545776=Bp['get'](_0x47eaa9['config']['apiHost']);_0x545776&&(_0x4998c6['eid']=_0x545776);const _0x37ac06=_0x47eaa9['_getFrameworks']();return _0x37ac06['length']&&(_0x4998c6['fw']=_0x37ac06['join'](',')),_0x3d0fc3+'?'+at(_0x4998c6)['slice'](0x1);}async function Hp(_0x3ab969){const _0xb46bf2=await Lp(_0x3ab969),_0x11ced0=X()['gapi'];return m(_0x11ced0,_0x3ab969,'internal-error'),_0xb46bf2['open']({'where':document['body'],'url':Vp(_0x3ab969),'messageHandlersFilter':_0x11ced0['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x3b0361=>new Promise(async(_0x2c88c5,_0x787af)=>{await _0x3b0361['restyle']({'setHideOnLeave':!0x1});const _0x10b46c=J(_0x3ab969,'network-request-failed'),_0x355999=X()['setTimeout'](()=>{_0x787af(_0x10b46c);},xp['get']());function _0x2b3060(){X()['clearTimeout'](_0x355999),_0x2c88c5(_0x3b0361);}_0x3b0361['ping'](_0x2b3060)['then'](_0x2b3060,()=>{_0x787af(_0x10b46c);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x4f4c0c){this['window']=_0x4f4c0c,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x92ba28,_0x2ac01c,_0x19b349,_0x1b91e1=Gp,_0x25ea01=qp){const _0x4d8a54=Math['max']((window['screen']['availHeight']-_0x25ea01)/0x2,0x0)['toString'](),_0x7dd4a5=Math['max']((window['screen']['availWidth']-_0x1b91e1)/0x2,0x0)['toString']();let _0x2b4112='';const _0x56f34d={...$p,'width':_0x1b91e1['toString'](),'height':_0x25ea01['toString'](),'top':_0x4d8a54,'left':_0x7dd4a5},_0x365131=W()['toLowerCase']();_0x19b349&&(_0x2b4112=ba(_0x365131)?zp:_0x19b349),Ta(_0x365131)&&(_0x2ac01c=_0x2ac01c||jp,_0x56f34d['scrollbars']='yes');const _0x221482=Object['entries'](_0x56f34d)['reduce']((_0x234018,[_0x4b2c2c,_0x204c0a])=>''+_0x234018+_0x4b2c2c+'='+_0x204c0a+',','');if(Ef(_0x365131)&&_0x2b4112!=='_self')return Yp(_0x2ac01c||'',_0x2b4112),new Dr(null);const _0x5c4192=window['open'](_0x2ac01c||'',_0x2b4112,_0x221482);m(_0x5c4192,_0x92ba28,'popup-blocked');try{_0x5c4192['focus']();}catch{}return new Dr(_0x5c4192);}function Yp(_0x1288a0,_0x128702){const _0x589ed9=document['createElement']('a');_0x589ed9['href']=_0x1288a0,_0x589ed9['target']=_0x128702;const _0x1ba955=document['createEvent']('MouseEvent');_0x1ba955['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x589ed9['dispatchEvent'](_0x1ba955);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x2060b1,_0x17844a,_0x6ffec9,_0x38082a,_0x4c7f8e,_0xfd8fe5){m(_0x2060b1['config']['authDomain'],_0x2060b1,'auth-domain-config-required'),m(_0x2060b1['config']['apiKey'],_0x2060b1,'invalid-api-key');const _0x267ffe={'apiKey':_0x2060b1['config']['apiKey'],'appName':_0x2060b1['name'],'authType':_0x6ffec9,'redirectUrl':_0x38082a,'v':ct,'eventId':_0x4c7f8e};if(_0x17844a instanceof xa){_0x17844a['setDefaultLanguage'](_0x2060b1['languageCode']),_0x267ffe['providerId']=_0x17844a['providerId']||'',hi(_0x17844a['getCustomParameters']())||(_0x267ffe['customParameters']=JSON['stringify'](_0x17844a['getCustomParameters']()));for(const [_0x363840,_0x38c405]of Object['entries']({}))_0x267ffe[_0x363840]=_0x38c405;}if(_0x17844a instanceof Qt){const _0x4613b6=_0x17844a['getScopes']()['filter'](_0x386939=>_0x386939!=='');_0x4613b6['length']>0x0&&(_0x267ffe['scopes']=_0x4613b6['join'](','));}_0x2060b1['tenantId']&&(_0x267ffe['tid']=_0x2060b1['tenantId']);const _0x3cd0f9=_0x267ffe;for(const _0x3125ad of Object['keys'](_0x3cd0f9))_0x3cd0f9[_0x3125ad]===void 0x0&&delete _0x3cd0f9[_0x3125ad];const _0x318b1e=await _0x2060b1['_getAppCheckToken'](),_0x42bcb4=_0x318b1e?'#'+Xp+'='+encodeURIComponent(_0x318b1e):'';return Zp(_0x2060b1)+'?'+at(_0x3cd0f9)['slice'](0x1)+_0x42bcb4;}function Zp({config:_0x5a252f}){return _0x5a252f['emulator']?Is(_0x5a252f,Jp):'https://'+_0x5a252f['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0xb7d575,_0xf30f08,_0x4c2bee,_0x1f99df){var _0x4d8161;ae((_0x4d8161=this['eventManagers'][_0xb7d575['_key']()])==null?void 0x0:_0x4d8161['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3596ad=await Mr(_0xb7d575,_0xf30f08,_0x4c2bee,Ni(),_0x1f99df);return Kp(_0xb7d575,_0x3596ad,bs());}async['_openRedirect'](_0x49388e,_0x589edf,_0x3a8766,_0x35a06d){await this['_originValidation'](_0x49388e);const _0x4b3b6f=await Mr(_0x49388e,_0x589edf,_0x3a8766,Ni(),_0x35a06d);return ip(_0x4b3b6f),new Promise(()=>{});}['_initialize'](_0x513161){const _0xf158ce=_0x513161['_key']();if(this['eventManagers'][_0xf158ce]){const {manager:_0x50b92a,promise:_0x2a5a01}=this['eventManagers'][_0xf158ce];return _0x50b92a?Promise['resolve'](_0x50b92a):(ae(_0x2a5a01,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2a5a01);}const _0x3d3254=this['initAndGetManager'](_0x513161);return this['eventManagers'][_0xf158ce]={'promise':_0x3d3254},_0x3d3254['catch'](()=>{delete this['eventManagers'][_0xf158ce];}),_0x3d3254;}async['initAndGetManager'](_0x1d681d){const _0x36a2f6=await Hp(_0x1d681d),_0x414af5=new bp(_0x1d681d);return _0x36a2f6['register']('authEvent',_0x4ea698=>(m(_0x4ea698==null?void 0x0:_0x4ea698['authEvent'],_0x1d681d,'invalid-auth-event'),{'status':_0x414af5['onEvent'](_0x4ea698['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1d681d['_key']()]={'manager':_0x414af5},this['iframes'][_0x1d681d['_key']()]=_0x36a2f6,_0x414af5;}['_isIframeWebStorageSupported'](_0x29d3ee,_0x576c61){this['iframes'][_0x29d3ee['_key']()]['send'](li,{'type':li},_0x2261b2=>{var _0x1c68fd;const _0x4175db=(_0x1c68fd=_0x2261b2==null?void 0x0:_0x2261b2[0x0])==null?void 0x0:_0x1c68fd[li];_0x4175db!==void 0x0&&_0x576c61(!!_0x4175db),K(_0x29d3ee,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x59eee0){const _0x4b2415=_0x59eee0['_key']();return this['originValidationPromises'][_0x4b2415]||(this['originValidationPromises'][_0x4b2415]=Pp(_0x59eee0)),this['originValidationPromises'][_0x4b2415];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x2d4703){this['auth']=_0x2d4703,this['internalListeners']=new Map();}['getUid'](){var _0x3cd18a;return this['assertAuthConfigured'](),((_0x3cd18a=this['auth']['currentUser'])==null?void 0x0:_0x3cd18a['uid'])||null;}async['getToken'](_0x329cac){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x329cac)}:null;}['addAuthTokenListener'](_0x4f8d22){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4f8d22))return;const _0x564b01=this['auth']['onIdTokenChanged'](_0x57c346=>{_0x4f8d22((_0x57c346==null?void 0x0:_0x57c346['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4f8d22,_0x564b01),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x288ca6){this['assertAuthConfigured']();const _0x4aaee5=this['internalListeners']['get'](_0x288ca6);_0x4aaee5&&(this['internalListeners']['delete'](_0x288ca6),_0x4aaee5(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x181634){switch(_0x181634){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x3ba299){et(new Me('auth',(_0x1b965e,{options:_0x352ad2})=>{const _0x22faf1=_0x1b965e['getProvider']('app')['getImmediate'](),_0x12c5a0=_0x1b965e['getProvider']('heartbeat'),_0x22bc7b=_0x1b965e['getProvider']('app-check-internal'),{apiKey:_0x3684a4,authDomain:_0x201f45}=_0x22faf1['options'];m(_0x3684a4&&!_0x3684a4['includes'](':'),'invalid-api-key',{'appName':_0x22faf1['name']});const _0xff7e0e={'apiKey':_0x3684a4,'authDomain':_0x201f45,'clientPlatform':_0x3ba299,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x3ba299)},_0x21dbff=new bf(_0x22faf1,_0x12c5a0,_0x22bc7b,_0xff7e0e);return Lf(_0x21dbff,_0x352ad2),_0x21dbff;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x42d37f,_0x22ae33,_0x4b6b50)=>{_0x42d37f['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x46f63a=>{const _0x87bf8f=qe(_0x46f63a['getProvider']('auth')['getImmediate']());return(_0x5aaf3b=>new n_(_0x5aaf3b))(_0x87bf8f);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x3ba299)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x4d401c=>async _0x28275d=>{const _0x5b456f=_0x28275d&&await _0x28275d['getIdTokenResult'](),_0x5baba0=_0x5b456f&&(new Date()['getTime']()-Date['parse'](_0x5b456f['issuedAtTime']))/0x3e8;if(_0x5baba0&&_0x5baba0>o_)return;const _0x2ca5a9=_0x5b456f==null?void 0x0:_0x5b456f['token'];Fr!==_0x2ca5a9&&(Fr=_0x2ca5a9,await fetch(_0x4d401c,{'method':_0x2ca5a9?'POST':'DELETE','headers':_0x2ca5a9?{'Authorization':'Bearer\x20'+_0x2ca5a9}:{}}));};function O_(_0x42a6b6=Qr()){const _0x60c27e=Ui(_0x42a6b6,'auth');if(_0x60c27e['isInitialized']())return _0x60c27e['getImmediate']();const _0x5a44fd=Mf(_0x42a6b6,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x594909=Gr('authTokenSyncURL');if(_0x594909&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x14e5e2=new URL(_0x594909,location['origin']);if(location['origin']===_0x14e5e2['origin']){const _0x4ca0ca=a_(_0x14e5e2['toString']());Jf(_0x5a44fd,_0x4ca0ca,()=>_0x4ca0ca(_0x5a44fd['currentUser'])),Qf(_0x5a44fd,_0xfbbcd8=>_0x4ca0ca(_0xfbbcd8));}}const _0x4353f8=Hr('auth');return _0x4353f8&&xf(_0x5a44fd,'http://'+_0x4353f8),_0x5a44fd;}function c_(){var _0x158494;return((_0x158494=document['getElementsByTagName']('head'))==null?void 0x0:_0x158494[0x0])??document;}Rf({'loadJS'(_0x3b6c0d){return new Promise((_0x1abf74,_0x4d7068)=>{const _0x5cc62b=document['createElement']('script');_0x5cc62b['setAttribute']('src',_0x3b6c0d),_0x5cc62b['onload']=_0x1abf74,_0x5cc62b['onerror']=_0x34f52d=>{const _0x548607=J('internal-error');_0x548607['customData']=_0x34f52d,_0x4d7068(_0x548607);},_0x5cc62b['type']='text/javascript',_0x5cc62b['charset']='UTF-8',c_()['appendChild'](_0x5cc62b);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};