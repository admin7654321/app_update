const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3a0bba,_0x3b02c5){if(!_0x3a0bba)throw ot(_0x3b02c5);},ot=function(_0x3aeca3){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3aeca3);},Wr=function(_0x38a4e9){const _0xd8bd21=[];let _0x429f46=0x0;for(let _0x2dc544=0x0;_0x2dc544<_0x38a4e9['length'];_0x2dc544++){let _0x10470c=_0x38a4e9['charCodeAt'](_0x2dc544);_0x10470c<0x80?_0xd8bd21[_0x429f46++]=_0x10470c:_0x10470c<0x800?(_0xd8bd21[_0x429f46++]=_0x10470c>>0x6|0xc0,_0xd8bd21[_0x429f46++]=_0x10470c&0x3f|0x80):(_0x10470c&0xfc00)===0xd800&&_0x2dc544+0x1<_0x38a4e9['length']&&(_0x38a4e9['charCodeAt'](_0x2dc544+0x1)&0xfc00)===0xdc00?(_0x10470c=0x10000+((_0x10470c&0x3ff)<<0xa)+(_0x38a4e9['charCodeAt'](++_0x2dc544)&0x3ff),_0xd8bd21[_0x429f46++]=_0x10470c>>0x12|0xf0,_0xd8bd21[_0x429f46++]=_0x10470c>>0xc&0x3f|0x80,_0xd8bd21[_0x429f46++]=_0x10470c>>0x6&0x3f|0x80,_0xd8bd21[_0x429f46++]=_0x10470c&0x3f|0x80):(_0xd8bd21[_0x429f46++]=_0x10470c>>0xc|0xe0,_0xd8bd21[_0x429f46++]=_0x10470c>>0x6&0x3f|0x80,_0xd8bd21[_0x429f46++]=_0x10470c&0x3f|0x80);}return _0xd8bd21;},Za=function(_0x29ea01){const _0x3f1fc1=[];let _0x4a1b92=0x0,_0x2701a7=0x0;for(;_0x4a1b92<_0x29ea01['length'];){const _0x1ab59d=_0x29ea01[_0x4a1b92++];if(_0x1ab59d<0x80)_0x3f1fc1[_0x2701a7++]=String['fromCharCode'](_0x1ab59d);else{if(_0x1ab59d>0xbf&&_0x1ab59d<0xe0){const _0x29d915=_0x29ea01[_0x4a1b92++];_0x3f1fc1[_0x2701a7++]=String['fromCharCode']((_0x1ab59d&0x1f)<<0x6|_0x29d915&0x3f);}else{if(_0x1ab59d>0xef&&_0x1ab59d<0x16d){const _0x26b8aa=_0x29ea01[_0x4a1b92++],_0x3590f4=_0x29ea01[_0x4a1b92++],_0x5c4a81=_0x29ea01[_0x4a1b92++],_0x130933=((_0x1ab59d&0x7)<<0x12|(_0x26b8aa&0x3f)<<0xc|(_0x3590f4&0x3f)<<0x6|_0x5c4a81&0x3f)-0x10000;_0x3f1fc1[_0x2701a7++]=String['fromCharCode'](0xd800+(_0x130933>>0xa)),_0x3f1fc1[_0x2701a7++]=String['fromCharCode'](0xdc00+(_0x130933&0x3ff));}else{const _0x31aa4e=_0x29ea01[_0x4a1b92++],_0x1dc488=_0x29ea01[_0x4a1b92++];_0x3f1fc1[_0x2701a7++]=String['fromCharCode']((_0x1ab59d&0xf)<<0xc|(_0x31aa4e&0x3f)<<0x6|_0x1dc488&0x3f);}}}}return _0x3f1fc1['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4d2e38,_0x46d239){if(!Array['isArray'](_0x4d2e38))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2e0bab=_0x46d239?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x78b4e2=[];for(let _0x248dbd=0x0;_0x248dbd<_0x4d2e38['length'];_0x248dbd+=0x3){const _0x16b439=_0x4d2e38[_0x248dbd],_0x18a39d=_0x248dbd+0x1<_0x4d2e38['length'],_0x331073=_0x18a39d?_0x4d2e38[_0x248dbd+0x1]:0x0,_0x5799fa=_0x248dbd+0x2<_0x4d2e38['length'],_0x85e8d=_0x5799fa?_0x4d2e38[_0x248dbd+0x2]:0x0,_0x24909f=_0x16b439>>0x2,_0x46b47f=(_0x16b439&0x3)<<0x4|_0x331073>>0x4;let _0x2db997=(_0x331073&0xf)<<0x2|_0x85e8d>>0x6,_0x36b2bf=_0x85e8d&0x3f;_0x5799fa||(_0x36b2bf=0x40,_0x18a39d||(_0x2db997=0x40)),_0x78b4e2['push'](_0x2e0bab[_0x24909f],_0x2e0bab[_0x46b47f],_0x2e0bab[_0x2db997],_0x2e0bab[_0x36b2bf]);}return _0x78b4e2['join']('');},'encodeString'(_0x47e1a7,_0x4d3ddf){return this['HAS_NATIVE_SUPPORT']&&!_0x4d3ddf?btoa(_0x47e1a7):this['encodeByteArray'](Wr(_0x47e1a7),_0x4d3ddf);},'decodeString'(_0x450119,_0x34b351){return this['HAS_NATIVE_SUPPORT']&&!_0x34b351?atob(_0x450119):Za(this['decodeStringToByteArray'](_0x450119,_0x34b351));},'decodeStringToByteArray'(_0x269a15,_0x23c284){this['init_']();const _0x38bde8=_0x23c284?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x1eb154=[];for(let _0x35f812=0x0;_0x35f812<_0x269a15['length'];){const _0x5b9b87=_0x38bde8[_0x269a15['charAt'](_0x35f812++)],_0x170b80=_0x35f812<_0x269a15['length']?_0x38bde8[_0x269a15['charAt'](_0x35f812)]:0x0;++_0x35f812;const _0x587ac9=_0x35f812<_0x269a15['length']?_0x38bde8[_0x269a15['charAt'](_0x35f812)]:0x40;++_0x35f812;const _0x198f26=_0x35f812<_0x269a15['length']?_0x38bde8[_0x269a15['charAt'](_0x35f812)]:0x40;if(++_0x35f812,_0x5b9b87==null||_0x170b80==null||_0x587ac9==null||_0x198f26==null)throw new ec();const _0x397195=_0x5b9b87<<0x2|_0x170b80>>0x4;if(_0x1eb154['push'](_0x397195),_0x587ac9!==0x40){const _0xddd198=_0x170b80<<0x4&0xf0|_0x587ac9>>0x2;if(_0x1eb154['push'](_0xddd198),_0x198f26!==0x40){const _0x1ea963=_0x587ac9<<0x6&0xc0|_0x198f26;_0x1eb154['push'](_0x1ea963);}}}return _0x1eb154;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x12ee38=0x0;_0x12ee38<this['ENCODED_VALS']['length'];_0x12ee38++)this['byteToCharMap_'][_0x12ee38]=this['ENCODED_VALS']['charAt'](_0x12ee38),this['charToByteMap_'][this['byteToCharMap_'][_0x12ee38]]=_0x12ee38,this['byteToCharMapWebSafe_'][_0x12ee38]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x12ee38),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x12ee38]]=_0x12ee38,_0x12ee38>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x12ee38)]=_0x12ee38,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x12ee38)]=_0x12ee38);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x136e48){const _0x36e412=Wr(_0x136e48);return Di['encodeByteArray'](_0x36e412,!0x0);},an=function(_0x5d8622){return Br(_0x5d8622)['replace'](/\./g,'');},cn=function(_0x428504){try{return Di['decodeString'](_0x428504,!0x0);}catch(_0x3fe9de){console['error']('base64Decode\x20failed:\x20',_0x3fe9de);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x264e62){return Vr(void 0x0,_0x264e62);}function Vr(_0x5a53d7,_0x528b55){if(!(_0x528b55 instanceof Object))return _0x528b55;switch(_0x528b55['constructor']){case Date:const _0xf5912a=_0x528b55;return new Date(_0xf5912a['getTime']());case Object:_0x5a53d7===void 0x0&&(_0x5a53d7={});break;case Array:_0x5a53d7=[];break;default:return _0x528b55;}for(const _0x35bb71 in _0x528b55)!_0x528b55['hasOwnProperty'](_0x35bb71)||!nc(_0x35bb71)||(_0x5a53d7[_0x35bb71]=Vr(_0x5a53d7[_0x35bb71],_0x528b55[_0x35bb71]));return _0x5a53d7;}function nc(_0x2b61eb){return _0x2b61eb!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0xb98981=As['__FIREBASE_DEFAULTS__'];if(_0xb98981)return JSON['parse'](_0xb98981);},oc=()=>{if(typeof document>'u')return;let _0x4af9a5;try{_0x4af9a5=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xd32967=_0x4af9a5&&cn(_0x4af9a5[0x1]);return _0xd32967&&JSON['parse'](_0xd32967);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x55585b){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x55585b);return;}},Hr=_0x305380=>{var _0x35a7bc,_0xf6e494;return(_0xf6e494=(_0x35a7bc=Mi())==null?void 0x0:_0x35a7bc['emulatorHosts'])==null?void 0x0:_0xf6e494[_0x305380];},ac=_0x27f5a5=>{const _0x34fc7c=Hr(_0x27f5a5);if(!_0x34fc7c)return;const _0x5337bd=_0x34fc7c['lastIndexOf'](':');if(_0x5337bd<=0x0||_0x5337bd+0x1===_0x34fc7c['length'])throw new Error('Invalid\x20host\x20'+_0x34fc7c+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2a51ef=parseInt(_0x34fc7c['substring'](_0x5337bd+0x1),0xa);return _0x34fc7c[0x0]==='['?[_0x34fc7c['substring'](0x1,_0x5337bd-0x1),_0x2a51ef]:[_0x34fc7c['substring'](0x0,_0x5337bd),_0x2a51ef];},$r=()=>{var _0x1a32f2;return(_0x1a32f2=Mi())==null?void 0x0:_0x1a32f2['config'];},Gr=_0x495d72=>{var _0x227726;return(_0x227726=Mi())==null?void 0x0:_0x227726['_'+_0x495d72];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x6203d1,_0x4cfb3d)=>{this['resolve']=_0x6203d1,this['reject']=_0x4cfb3d;});}['wrapCallback'](_0x11b677){return(_0x230cca,_0x16d630)=>{_0x230cca?this['reject'](_0x230cca):this['resolve'](_0x16d630),typeof _0x11b677=='function'&&(this['promise']['catch'](()=>{}),_0x11b677['length']===0x1?_0x11b677(_0x230cca):_0x11b677(_0x230cca,_0x16d630));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x2f2109,_0x4f45bb){if(_0x2f2109['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x33ab98={'alg':'none','type':'JWT'},_0x11207b=_0x4f45bb||'demo-project',_0x1c7f4a=_0x2f2109['iat']||0x0,_0x3723f6=_0x2f2109['sub']||_0x2f2109['user_id'];if(!_0x3723f6)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x301e85={'iss':'https://securetoken.google.com/'+_0x11207b,'aud':_0x11207b,'iat':_0x1c7f4a,'exp':_0x1c7f4a+0xe10,'auth_time':_0x1c7f4a,'sub':_0x3723f6,'user_id':_0x3723f6,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x2f2109};return[an(JSON['stringify'](_0x33ab98)),an(JSON['stringify'](_0x301e85)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x6d37e0=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x6d37e0=='object'&&_0x6d37e0['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x1b4fe5=W();return _0x1b4fe5['indexOf']('MSIE\x20')>=0x0||_0x1b4fe5['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x5aaa86,_0x582815)=>{try{let _0x4613fe=!0x0;const _0x5cde6f='validate-browser-context-for-indexeddb-analytics-module',_0x345792=self['indexedDB']['open'](_0x5cde6f);_0x345792['onsuccess']=()=>{_0x345792['result']['close'](),_0x4613fe||self['indexedDB']['deleteDatabase'](_0x5cde6f),_0x5aaa86(!0x0);},_0x345792['onupgradeneeded']=()=>{_0x4613fe=!0x1;},_0x345792['onerror']=()=>{var _0x1b09df;_0x582815(((_0x1b09df=_0x345792['error'])==null?void 0x0:_0x1b09df['message'])||'');};}catch(_0x386932){_0x582815(_0x386932);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x247920,_0x5a5430,_0x2059b2){super(_0x5a5430),this['code']=_0x247920,this['customData']=_0x2059b2,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x4c66d5,_0x496bb3,_0x35eb76){this['service']=_0x4c66d5,this['serviceName']=_0x496bb3,this['errors']=_0x35eb76;}['create'](_0x4f1e53,..._0x502b45){const _0x4051ad=_0x502b45[0x0]||{},_0x3fedb7=this['service']+'/'+_0x4f1e53,_0x5bf5d6=this['errors'][_0x4f1e53],_0x22eb7d=_0x5bf5d6?gc(_0x5bf5d6,_0x4051ad):'Error',_0x18af53=this['serviceName']+':\x20'+_0x22eb7d+'\x20('+_0x3fedb7+').';return new Se(_0x3fedb7,_0x18af53,_0x4051ad);}}function gc(_0x37020e,_0x11e0c8){return _0x37020e['replace'](mc,(_0x15b54a,_0x4511c5)=>{const _0x3559a6=_0x11e0c8[_0x4511c5];return _0x3559a6!=null?String(_0x3559a6):'<'+_0x4511c5+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x14f413){return JSON['parse'](_0x14f413);}function O(_0x22b692){return JSON['stringify'](_0x22b692);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x5ee2da){let _0x2dfd3a={},_0x20264a={},_0x3cd3a8={},_0x12d6ee='';try{const _0x387da1=_0x5ee2da['split']('.');_0x2dfd3a=bt(cn(_0x387da1[0x0])||''),_0x20264a=bt(cn(_0x387da1[0x1])||''),_0x12d6ee=_0x387da1[0x2],_0x3cd3a8=_0x20264a['d']||{},delete _0x20264a['d'];}catch{}return{'header':_0x2dfd3a,'claims':_0x20264a,'data':_0x3cd3a8,'signature':_0x12d6ee};},yc=function(_0x29e274){const _0x78f2d=zr(_0x29e274),_0x20447e=_0x78f2d['claims'];return!!_0x20447e&&typeof _0x20447e=='object'&&_0x20447e['hasOwnProperty']('iat');},vc=function(_0x5e5f3e){const _0x68cf17=zr(_0x5e5f3e)['claims'];return typeof _0x68cf17=='object'&&_0x68cf17['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3f9198,_0x3adb7f){return Object['prototype']['hasOwnProperty']['call'](_0x3f9198,_0x3adb7f);}function Oe(_0x4f431f,_0x157220){if(Object['prototype']['hasOwnProperty']['call'](_0x4f431f,_0x157220))return _0x4f431f[_0x157220];}function hi(_0x5d514d){for(const _0x5ecdb8 in _0x5d514d)if(Object['prototype']['hasOwnProperty']['call'](_0x5d514d,_0x5ecdb8))return!0x1;return!0x0;}function ln(_0x189e01,_0x3abade,_0x453d38){const _0x1e238a={};for(const _0x10c08d in _0x189e01)Object['prototype']['hasOwnProperty']['call'](_0x189e01,_0x10c08d)&&(_0x1e238a[_0x10c08d]=_0x3abade['call'](_0x453d38,_0x189e01[_0x10c08d],_0x10c08d,_0x189e01));return _0x1e238a;}function De(_0x33ad69,_0x4487bd){if(_0x33ad69===_0x4487bd)return!0x0;const _0x255206=Object['keys'](_0x33ad69),_0xb489c8=Object['keys'](_0x4487bd);for(const _0x5ade99 of _0x255206){if(!_0xb489c8['includes'](_0x5ade99))return!0x1;const _0x18b585=_0x33ad69[_0x5ade99],_0xfe13b=_0x4487bd[_0x5ade99];if(ks(_0x18b585)&&ks(_0xfe13b)){if(!De(_0x18b585,_0xfe13b))return!0x1;}else{if(_0x18b585!==_0xfe13b)return!0x1;}}for(const _0x1f0124 of _0xb489c8)if(!_0x255206['includes'](_0x1f0124))return!0x1;return!0x0;}function ks(_0x2f895a){return _0x2f895a!==null&&typeof _0x2f895a=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x1ab77d){const _0x10b8f2=[];for(const [_0x2e689e,_0x7babb7]of Object['entries'](_0x1ab77d))Array['isArray'](_0x7babb7)?_0x7babb7['forEach'](_0x1afbb9=>{_0x10b8f2['push'](encodeURIComponent(_0x2e689e)+'='+encodeURIComponent(_0x1afbb9));}):_0x10b8f2['push'](encodeURIComponent(_0x2e689e)+'='+encodeURIComponent(_0x7babb7));return _0x10b8f2['length']?'&'+_0x10b8f2['join']('&'):'';}function yt(_0x200e0c){const _0xcc9de8={};return _0x200e0c['replace'](/^\?/,'')['split']('&')['forEach'](_0x1a27eb=>{if(_0x1a27eb){const [_0x5b3609,_0x171246]=_0x1a27eb['split']('=');_0xcc9de8[decodeURIComponent(_0x5b3609)]=decodeURIComponent(_0x171246);}}),_0xcc9de8;}function vt(_0x50a426){const _0x251c40=_0x50a426['indexOf']('?');if(!_0x251c40)return'';const _0x23e630=_0x50a426['indexOf']('#',_0x251c40);return _0x50a426['substring'](_0x251c40,_0x23e630>0x0?_0x23e630:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3f11a7=0x1;_0x3f11a7<this['blockSize'];++_0x3f11a7)this['pad_'][_0x3f11a7]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x2801f4,_0x45c3f2){_0x45c3f2||(_0x45c3f2=0x0);const _0x54fd3a=this['W_'];if(typeof _0x2801f4=='string'){for(let _0x49de4a=0x0;_0x49de4a<0x10;_0x49de4a++)_0x54fd3a[_0x49de4a]=_0x2801f4['charCodeAt'](_0x45c3f2)<<0x18|_0x2801f4['charCodeAt'](_0x45c3f2+0x1)<<0x10|_0x2801f4['charCodeAt'](_0x45c3f2+0x2)<<0x8|_0x2801f4['charCodeAt'](_0x45c3f2+0x3),_0x45c3f2+=0x4;}else{for(let _0x67ca30=0x0;_0x67ca30<0x10;_0x67ca30++)_0x54fd3a[_0x67ca30]=_0x2801f4[_0x45c3f2]<<0x18|_0x2801f4[_0x45c3f2+0x1]<<0x10|_0x2801f4[_0x45c3f2+0x2]<<0x8|_0x2801f4[_0x45c3f2+0x3],_0x45c3f2+=0x4;}for(let _0x243b84=0x10;_0x243b84<0x50;_0x243b84++){const _0x23e288=_0x54fd3a[_0x243b84-0x3]^_0x54fd3a[_0x243b84-0x8]^_0x54fd3a[_0x243b84-0xe]^_0x54fd3a[_0x243b84-0x10];_0x54fd3a[_0x243b84]=(_0x23e288<<0x1|_0x23e288>>>0x1f)&0xffffffff;}let _0x3c2b78=this['chain_'][0x0],_0x2da6cf=this['chain_'][0x1],_0x179013=this['chain_'][0x2],_0x4949e5=this['chain_'][0x3],_0x5b286e=this['chain_'][0x4],_0x8407a4,_0x2c31d5;for(let _0x2b491c=0x0;_0x2b491c<0x50;_0x2b491c++){_0x2b491c<0x28?_0x2b491c<0x14?(_0x8407a4=_0x4949e5^_0x2da6cf&(_0x179013^_0x4949e5),_0x2c31d5=0x5a827999):(_0x8407a4=_0x2da6cf^_0x179013^_0x4949e5,_0x2c31d5=0x6ed9eba1):_0x2b491c<0x3c?(_0x8407a4=_0x2da6cf&_0x179013|_0x4949e5&(_0x2da6cf|_0x179013),_0x2c31d5=0x8f1bbcdc):(_0x8407a4=_0x2da6cf^_0x179013^_0x4949e5,_0x2c31d5=0xca62c1d6);const _0x59bd4f=(_0x3c2b78<<0x5|_0x3c2b78>>>0x1b)+_0x8407a4+_0x5b286e+_0x2c31d5+_0x54fd3a[_0x2b491c]&0xffffffff;_0x5b286e=_0x4949e5,_0x4949e5=_0x179013,_0x179013=(_0x2da6cf<<0x1e|_0x2da6cf>>>0x2)&0xffffffff,_0x2da6cf=_0x3c2b78,_0x3c2b78=_0x59bd4f;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3c2b78&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2da6cf&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x179013&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4949e5&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5b286e&0xffffffff;}['update'](_0x4d297b,_0x20e663){if(_0x4d297b==null)return;_0x20e663===void 0x0&&(_0x20e663=_0x4d297b['length']);const _0x231d46=_0x20e663-this['blockSize'];let _0x457ada=0x0;const _0x146d10=this['buf_'];let _0x1cabd9=this['inbuf_'];for(;_0x457ada<_0x20e663;){if(_0x1cabd9===0x0){for(;_0x457ada<=_0x231d46;)this['compress_'](_0x4d297b,_0x457ada),_0x457ada+=this['blockSize'];}if(typeof _0x4d297b=='string'){for(;_0x457ada<_0x20e663;)if(_0x146d10[_0x1cabd9]=_0x4d297b['charCodeAt'](_0x457ada),++_0x1cabd9,++_0x457ada,_0x1cabd9===this['blockSize']){this['compress_'](_0x146d10),_0x1cabd9=0x0;break;}}else{for(;_0x457ada<_0x20e663;)if(_0x146d10[_0x1cabd9]=_0x4d297b[_0x457ada],++_0x1cabd9,++_0x457ada,_0x1cabd9===this['blockSize']){this['compress_'](_0x146d10),_0x1cabd9=0x0;break;}}}this['inbuf_']=_0x1cabd9,this['total_']+=_0x20e663;}['digest'](){const _0x46dee2=[];let _0x3829ef=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x17afa7=this['blockSize']-0x1;_0x17afa7>=0x38;_0x17afa7--)this['buf_'][_0x17afa7]=_0x3829ef&0xff,_0x3829ef/=0x100;this['compress_'](this['buf_']);let _0x30f4ff=0x0;for(let _0x5726f5=0x0;_0x5726f5<0x5;_0x5726f5++)for(let _0x12c326=0x18;_0x12c326>=0x0;_0x12c326-=0x8)_0x46dee2[_0x30f4ff]=this['chain_'][_0x5726f5]>>_0x12c326&0xff,++_0x30f4ff;return _0x46dee2;}}function Ic(_0x45bf62,_0x3591ed){const _0x2bcf6a=new wc(_0x45bf62,_0x3591ed);return _0x2bcf6a['subscribe']['bind'](_0x2bcf6a);}class wc{constructor(_0x102900,_0x1da512){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x1da512,this['task']['then'](()=>{_0x102900(this);})['catch'](_0x23db21=>{this['error'](_0x23db21);});}['next'](_0x2b3dfb){this['forEachObserver'](_0x363f1b=>{_0x363f1b['next'](_0x2b3dfb);});}['error'](_0x5eaf2a){this['forEachObserver'](_0x53f381=>{_0x53f381['error'](_0x5eaf2a);}),this['close'](_0x5eaf2a);}['complete'](){this['forEachObserver'](_0xbac540=>{_0xbac540['complete']();}),this['close']();}['subscribe'](_0x31de5a,_0x5c44b8,_0x4287b9){let _0x188a35;if(_0x31de5a===void 0x0&&_0x5c44b8===void 0x0&&_0x4287b9===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x31de5a,['next','error','complete'])?_0x188a35=_0x31de5a:_0x188a35={'next':_0x31de5a,'error':_0x5c44b8,'complete':_0x4287b9},_0x188a35['next']===void 0x0&&(_0x188a35['next']=Qn),_0x188a35['error']===void 0x0&&(_0x188a35['error']=Qn),_0x188a35['complete']===void 0x0&&(_0x188a35['complete']=Qn);const _0x2f5b18=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x188a35['error'](this['finalError']):_0x188a35['complete']();}catch{}}),this['observers']['push'](_0x188a35),_0x2f5b18;}['unsubscribeOne'](_0x1d6189){this['observers']===void 0x0||this['observers'][_0x1d6189]===void 0x0||(delete this['observers'][_0x1d6189],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1ddd26){if(!this['finalized']){for(let _0x6b65cd=0x0;_0x6b65cd<this['observers']['length'];_0x6b65cd++)this['sendOne'](_0x6b65cd,_0x1ddd26);}}['sendOne'](_0x2b621a,_0x422ccf){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2b621a]!==void 0x0)try{_0x422ccf(this['observers'][_0x2b621a]);}catch(_0x802b09){typeof console<'u'&&console['error']&&console['error'](_0x802b09);}});}['close'](_0x379759){this['finalized']||(this['finalized']=!0x0,_0x379759!==void 0x0&&(this['finalError']=_0x379759),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x15c37a,_0x43c309){if(typeof _0x15c37a!='object'||_0x15c37a===null)return!0x1;for(const _0x13b4ac of _0x43c309)if(_0x13b4ac in _0x15c37a&&typeof _0x15c37a[_0x13b4ac]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x328c24,_0x39944a){return _0x328c24+'\x20failed:\x20'+_0x39944a+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x2b05ea){const _0x27ef2a=[];let _0x14225f=0x0;for(let _0x1e515b=0x0;_0x1e515b<_0x2b05ea['length'];_0x1e515b++){let _0x2b121d=_0x2b05ea['charCodeAt'](_0x1e515b);if(_0x2b121d>=0xd800&&_0x2b121d<=0xdbff){const _0x562405=_0x2b121d-0xd800;_0x1e515b++,f(_0x1e515b<_0x2b05ea['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5b563a=_0x2b05ea['charCodeAt'](_0x1e515b)-0xdc00;_0x2b121d=0x10000+(_0x562405<<0xa)+_0x5b563a;}_0x2b121d<0x80?_0x27ef2a[_0x14225f++]=_0x2b121d:_0x2b121d<0x800?(_0x27ef2a[_0x14225f++]=_0x2b121d>>0x6|0xc0,_0x27ef2a[_0x14225f++]=_0x2b121d&0x3f|0x80):_0x2b121d<0x10000?(_0x27ef2a[_0x14225f++]=_0x2b121d>>0xc|0xe0,_0x27ef2a[_0x14225f++]=_0x2b121d>>0x6&0x3f|0x80,_0x27ef2a[_0x14225f++]=_0x2b121d&0x3f|0x80):(_0x27ef2a[_0x14225f++]=_0x2b121d>>0x12|0xf0,_0x27ef2a[_0x14225f++]=_0x2b121d>>0xc&0x3f|0x80,_0x27ef2a[_0x14225f++]=_0x2b121d>>0x6&0x3f|0x80,_0x27ef2a[_0x14225f++]=_0x2b121d&0x3f|0x80);}return _0x27ef2a;},Pn=function(_0x30e8e8){let _0x431b6c=0x0;for(let _0x43b4c9=0x0;_0x43b4c9<_0x30e8e8['length'];_0x43b4c9++){const _0x20bfca=_0x30e8e8['charCodeAt'](_0x43b4c9);_0x20bfca<0x80?_0x431b6c++:_0x20bfca<0x800?_0x431b6c+=0x2:_0x20bfca>=0xd800&&_0x20bfca<=0xdbff?(_0x431b6c+=0x4,_0x43b4c9++):_0x431b6c+=0x3;}return _0x431b6c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0xfff2a5){return _0xfff2a5&&_0xfff2a5['_delegate']?_0xfff2a5['_delegate']:_0xfff2a5;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x943d09){try{return(_0x943d09['startsWith']('http://')||_0x943d09['startsWith']('https://')?new URL(_0x943d09)['hostname']:_0x943d09)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x29b76e){return(await fetch(_0x29b76e,{'credentials':'include'}))['ok'];}class Me{constructor(_0x84684b,_0x4586e3,_0x2c01ba){this['name']=_0x84684b,this['instanceFactory']=_0x4586e3,this['type']=_0x2c01ba,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1f60b3){return this['instantiationMode']=_0x1f60b3,this;}['setMultipleInstances'](_0x57c1c9){return this['multipleInstances']=_0x57c1c9,this;}['setServiceProps'](_0x27d5bc){return this['serviceProps']=_0x27d5bc,this;}['setInstanceCreatedCallback'](_0x34fe93){return this['onInstanceCreated']=_0x34fe93,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x4c7eba,_0xdde85){this['name']=_0x4c7eba,this['container']=_0xdde85,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5d07c5){const _0x311be2=this['normalizeInstanceIdentifier'](_0x5d07c5);if(!this['instancesDeferred']['has'](_0x311be2)){const _0x26819f=new Ve();if(this['instancesDeferred']['set'](_0x311be2,_0x26819f),this['isInitialized'](_0x311be2)||this['shouldAutoInitialize']())try{const _0x2942e1=this['getOrInitializeService']({'instanceIdentifier':_0x311be2});_0x2942e1&&_0x26819f['resolve'](_0x2942e1);}catch{}}return this['instancesDeferred']['get'](_0x311be2)['promise'];}['getImmediate'](_0x29a818){const _0x3dc412=this['normalizeInstanceIdentifier'](_0x29a818==null?void 0x0:_0x29a818['identifier']),_0x242285=(_0x29a818==null?void 0x0:_0x29a818['optional'])??!0x1;if(this['isInitialized'](_0x3dc412)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x3dc412});}catch(_0xcad13b){if(_0x242285)return null;throw _0xcad13b;}else{if(_0x242285)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x44dcc9){if(_0x44dcc9['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x44dcc9['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x44dcc9,!!this['shouldAutoInitialize']()){if(Rc(_0x44dcc9))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x36c034,_0x2b35a9]of this['instancesDeferred']['entries']()){const _0x144e31=this['normalizeInstanceIdentifier'](_0x36c034);try{const _0x1c69ba=this['getOrInitializeService']({'instanceIdentifier':_0x144e31});_0x2b35a9['resolve'](_0x1c69ba);}catch{}}}}['clearInstance'](_0x223e64=ke){this['instancesDeferred']['delete'](_0x223e64),this['instancesOptions']['delete'](_0x223e64),this['instances']['delete'](_0x223e64);}async['delete'](){const _0x24bcf4=Array['from'](this['instances']['values']());await Promise['all']([..._0x24bcf4['filter'](_0x241c84=>'INTERNAL'in _0x241c84)['map'](_0x4ccfe6=>_0x4ccfe6['INTERNAL']['delete']()),..._0x24bcf4['filter'](_0x589f20=>'_delete'in _0x589f20)['map'](_0xbbb67e=>_0xbbb67e['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x164721=ke){return this['instances']['has'](_0x164721);}['getOptions'](_0x1823f5=ke){return this['instancesOptions']['get'](_0x1823f5)||{};}['initialize'](_0x537cb6={}){const {options:_0x3d7d78={}}=_0x537cb6,_0x59917d=this['normalizeInstanceIdentifier'](_0x537cb6['instanceIdentifier']);if(this['isInitialized'](_0x59917d))throw Error(this['name']+'('+_0x59917d+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1f18d3=this['getOrInitializeService']({'instanceIdentifier':_0x59917d,'options':_0x3d7d78});for(const [_0x1d2644,_0x2dadc6]of this['instancesDeferred']['entries']()){const _0x1250a8=this['normalizeInstanceIdentifier'](_0x1d2644);_0x59917d===_0x1250a8&&_0x2dadc6['resolve'](_0x1f18d3);}return _0x1f18d3;}['onInit'](_0x39a679,_0x17e765){const _0x29e9be=this['normalizeInstanceIdentifier'](_0x17e765),_0x3f0dfe=this['onInitCallbacks']['get'](_0x29e9be)??new Set();_0x3f0dfe['add'](_0x39a679),this['onInitCallbacks']['set'](_0x29e9be,_0x3f0dfe);const _0x1a8514=this['instances']['get'](_0x29e9be);return _0x1a8514&&_0x39a679(_0x1a8514,_0x29e9be),()=>{_0x3f0dfe['delete'](_0x39a679);};}['invokeOnInitCallbacks'](_0x40a6ff,_0x478274){const _0x5dd441=this['onInitCallbacks']['get'](_0x478274);if(_0x5dd441){for(const _0x5f2458 of _0x5dd441)try{_0x5f2458(_0x40a6ff,_0x478274);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x104d2b,options:_0xe0ab58={}}){let _0xb20be5=this['instances']['get'](_0x104d2b);if(!_0xb20be5&&this['component']&&(_0xb20be5=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x104d2b),'options':_0xe0ab58}),this['instances']['set'](_0x104d2b,_0xb20be5),this['instancesOptions']['set'](_0x104d2b,_0xe0ab58),this['invokeOnInitCallbacks'](_0xb20be5,_0x104d2b),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x104d2b,_0xb20be5);}catch{}return _0xb20be5||null;}['normalizeInstanceIdentifier'](_0x35cde1=ke){return this['component']?this['component']['multipleInstances']?_0x35cde1:ke:_0x35cde1;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x3e2e2e){return _0x3e2e2e===ke?void 0x0:_0x3e2e2e;}function Rc(_0x28bdb8){return _0x28bdb8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4b2d59){this['name']=_0x4b2d59,this['providers']=new Map();}['addComponent'](_0x416519){const _0x2b8c82=this['getProvider'](_0x416519['name']);if(_0x2b8c82['isComponentSet']())throw new Error('Component\x20'+_0x416519['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x2b8c82['setComponent'](_0x416519);}['addOrOverwriteComponent'](_0x249041){this['getProvider'](_0x249041['name'])['isComponentSet']()&&this['providers']['delete'](_0x249041['name']),this['addComponent'](_0x249041);}['getProvider'](_0x34a2fc){if(this['providers']['has'](_0x34a2fc))return this['providers']['get'](_0x34a2fc);const _0x1c091d=new Sc(_0x34a2fc,this);return this['providers']['set'](_0x34a2fc,_0x1c091d),_0x1c091d;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x12cc49){_0x12cc49[_0x12cc49['DEBUG']=0x0]='DEBUG',_0x12cc49[_0x12cc49['VERBOSE']=0x1]='VERBOSE',_0x12cc49[_0x12cc49['INFO']=0x2]='INFO',_0x12cc49[_0x12cc49['WARN']=0x3]='WARN',_0x12cc49[_0x12cc49['ERROR']=0x4]='ERROR',_0x12cc49[_0x12cc49['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x2fdc5d,_0x5b0840,..._0x4703c4)=>{if(_0x5b0840<_0x2fdc5d['logLevel'])return;const _0x5d6ea9=new Date()['toISOString'](),_0x164209=Pc[_0x5b0840];if(_0x164209)console[_0x164209]('['+_0x5d6ea9+']\x20\x20'+_0x2fdc5d['name']+':',..._0x4703c4);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x5b0840+')');};class xi{constructor(_0x4b5750){this['name']=_0x4b5750,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x1521fb){if(!(_0x1521fb in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x1521fb+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x1521fb;}['setLogLevel'](_0x501a93){this['_logLevel']=typeof _0x501a93=='string'?kc[_0x501a93]:_0x501a93;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4038e8){if(typeof _0x4038e8!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4038e8;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2da4b4){this['_userLogHandler']=_0x2da4b4;}['debug'](..._0x170c8c){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x170c8c),this['_logHandler'](this,T['DEBUG'],..._0x170c8c);}['log'](..._0x1e3178){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1e3178),this['_logHandler'](this,T['VERBOSE'],..._0x1e3178);}['info'](..._0x52b7ef){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x52b7ef),this['_logHandler'](this,T['INFO'],..._0x52b7ef);}['warn'](..._0x102c80){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x102c80),this['_logHandler'](this,T['WARN'],..._0x102c80);}['error'](..._0x318806){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x318806),this['_logHandler'](this,T['ERROR'],..._0x318806);}}const Dc=(_0x4b76cc,_0x5a6e10)=>_0x5a6e10['some'](_0x27e9b2=>_0x4b76cc instanceof _0x27e9b2);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x12467d){const _0x46899b=new Promise((_0x8434ed,_0x29bc61)=>{const _0x2ea095=()=>{_0x12467d['removeEventListener']('success',_0x10a5b1),_0x12467d['removeEventListener']('error',_0x5628a0);},_0x10a5b1=()=>{_0x8434ed(_e(_0x12467d['result'])),_0x2ea095();},_0x5628a0=()=>{_0x29bc61(_0x12467d['error']),_0x2ea095();};_0x12467d['addEventListener']('success',_0x10a5b1),_0x12467d['addEventListener']('error',_0x5628a0);});return _0x46899b['then'](_0x5460d7=>{_0x5460d7 instanceof IDBCursor&&Kr['set'](_0x5460d7,_0x12467d);})['catch'](()=>{}),Fi['set'](_0x46899b,_0x12467d),_0x46899b;}function Fc(_0x1700ce){if(ui['has'](_0x1700ce))return;const _0x3871c7=new Promise((_0x1f9397,_0x468a52)=>{const _0x237944=()=>{_0x1700ce['removeEventListener']('complete',_0x56f626),_0x1700ce['removeEventListener']('error',_0x5072d4),_0x1700ce['removeEventListener']('abort',_0x5072d4);},_0x56f626=()=>{_0x1f9397(),_0x237944();},_0x5072d4=()=>{_0x468a52(_0x1700ce['error']||new DOMException('AbortError','AbortError')),_0x237944();};_0x1700ce['addEventListener']('complete',_0x56f626),_0x1700ce['addEventListener']('error',_0x5072d4),_0x1700ce['addEventListener']('abort',_0x5072d4);});ui['set'](_0x1700ce,_0x3871c7);}let di={'get'(_0x7dca24,_0x32cb28,_0x2f85cb){if(_0x7dca24 instanceof IDBTransaction){if(_0x32cb28==='done')return ui['get'](_0x7dca24);if(_0x32cb28==='objectStoreNames')return _0x7dca24['objectStoreNames']||Yr['get'](_0x7dca24);if(_0x32cb28==='store')return _0x2f85cb['objectStoreNames'][0x1]?void 0x0:_0x2f85cb['objectStore'](_0x2f85cb['objectStoreNames'][0x0]);}return _e(_0x7dca24[_0x32cb28]);},'set'(_0x5d40dd,_0x599654,_0x2af8a0){return _0x5d40dd[_0x599654]=_0x2af8a0,!0x0;},'has'(_0x2cd0f0,_0x41ca26){return _0x2cd0f0 instanceof IDBTransaction&&(_0x41ca26==='done'||_0x41ca26==='store')?!0x0:_0x41ca26 in _0x2cd0f0;}};function Uc(_0x5d749b){di=_0x5d749b(di);}function Wc(_0x5ca468){return _0x5ca468===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2a0ce5,..._0x2ff2b2){const _0x365c5a=_0x5ca468['call'](Xn(this),_0x2a0ce5,..._0x2ff2b2);return Yr['set'](_0x365c5a,_0x2a0ce5['sort']?_0x2a0ce5['sort']():[_0x2a0ce5]),_e(_0x365c5a);}:Lc()['includes'](_0x5ca468)?function(..._0x49a299){return _0x5ca468['apply'](Xn(this),_0x49a299),_e(Kr['get'](this));}:function(..._0x66a928){return _e(_0x5ca468['apply'](Xn(this),_0x66a928));};}function Bc(_0x3ce111){return typeof _0x3ce111=='function'?Wc(_0x3ce111):(_0x3ce111 instanceof IDBTransaction&&Fc(_0x3ce111),Dc(_0x3ce111,Mc())?new Proxy(_0x3ce111,di):_0x3ce111);}function _e(_0x51eae9){if(_0x51eae9 instanceof IDBRequest)return xc(_0x51eae9);if(Jn['has'](_0x51eae9))return Jn['get'](_0x51eae9);const _0x332cba=Bc(_0x51eae9);return _0x332cba!==_0x51eae9&&(Jn['set'](_0x51eae9,_0x332cba),Fi['set'](_0x332cba,_0x51eae9)),_0x332cba;}const Xn=_0x4b94a9=>Fi['get'](_0x4b94a9);function Vc(_0x3314bc,_0x277334,{blocked:_0x233637,upgrade:_0x4ecab9,blocking:_0x17e2f6,terminated:_0x4275ad}={}){const _0x231281=indexedDB['open'](_0x3314bc,_0x277334),_0x3b7254=_e(_0x231281);return _0x4ecab9&&_0x231281['addEventListener']('upgradeneeded',_0x1fc1e9=>{_0x4ecab9(_e(_0x231281['result']),_0x1fc1e9['oldVersion'],_0x1fc1e9['newVersion'],_e(_0x231281['transaction']),_0x1fc1e9);}),_0x233637&&_0x231281['addEventListener']('blocked',_0x5b124b=>_0x233637(_0x5b124b['oldVersion'],_0x5b124b['newVersion'],_0x5b124b)),_0x3b7254['then'](_0x4181b5=>{_0x4275ad&&_0x4181b5['addEventListener']('close',()=>_0x4275ad()),_0x17e2f6&&_0x4181b5['addEventListener']('versionchange',_0x257532=>_0x17e2f6(_0x257532['oldVersion'],_0x257532['newVersion'],_0x257532));})['catch'](()=>{}),_0x3b7254;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x5b9d76,_0x1587de){if(!(_0x5b9d76 instanceof IDBDatabase&&!(_0x1587de in _0x5b9d76)&&typeof _0x1587de=='string'))return;if(Zn['get'](_0x1587de))return Zn['get'](_0x1587de);const _0x23260c=_0x1587de['replace'](/FromIndex$/,''),_0x43858b=_0x1587de!==_0x23260c,_0x526fca=$c['includes'](_0x23260c);if(!(_0x23260c in(_0x43858b?IDBIndex:IDBObjectStore)['prototype'])||!(_0x526fca||Hc['includes'](_0x23260c)))return;const _0x267152=async function(_0x5f145b,..._0x434246){const _0x18e8bd=this['transaction'](_0x5f145b,_0x526fca?'readwrite':'readonly');let _0x14b53f=_0x18e8bd['store'];return _0x43858b&&(_0x14b53f=_0x14b53f['index'](_0x434246['shift']())),(await Promise['all']([_0x14b53f[_0x23260c](..._0x434246),_0x526fca&&_0x18e8bd['done']]))[0x0];};return Zn['set'](_0x1587de,_0x267152),_0x267152;}Uc(_0x2ca1f2=>({..._0x2ca1f2,'get':(_0x2361e5,_0x1894d1,_0x3b6444)=>Os(_0x2361e5,_0x1894d1)||_0x2ca1f2['get'](_0x2361e5,_0x1894d1,_0x3b6444),'has':(_0x2ba0c8,_0x51a677)=>!!Os(_0x2ba0c8,_0x51a677)||_0x2ca1f2['has'](_0x2ba0c8,_0x51a677)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x55c445){this['container']=_0x55c445;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x251df2=>{if(qc(_0x251df2)){const _0x141604=_0x251df2['getImmediate']();return _0x141604['library']+'/'+_0x141604['version'];}else return null;})['filter'](_0xcb019f=>_0xcb019f)['join']('\x20');}}function qc(_0x49f671){const _0x299e74=_0x49f671['getComponent']();return(_0x299e74==null?void 0x0:_0x299e74['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x303886,_0x4aea8b){try{_0x303886['container']['addComponent'](_0x4aea8b);}catch(_0x3e40a7){re['debug']('Component\x20'+_0x4aea8b['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x303886['name'],_0x3e40a7);}}function et(_0x35eeed){const _0x332f01=_0x35eeed['name'];if(gi['has'](_0x332f01))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x332f01+'.'),!0x1;gi['set'](_0x332f01,_0x35eeed);for(const _0x1343d6 of Le['values']())Ms(_0x1343d6,_0x35eeed);for(const _0x7f684a of _i['values']())Ms(_0x7f684a,_0x35eeed);return!0x0;}function Ui(_0x2ec441,_0x243883){const _0x371a48=_0x2ec441['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x371a48&&_0x371a48['triggerHeartbeat'](),_0x2ec441['container']['getProvider'](_0x243883);}function H(_0x1349ee){return _0x1349ee==null?!0x1:_0x1349ee['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x4586a4,_0x12f49b,_0xa11bd5){this['_isDeleted']=!0x1,this['_options']={..._0x4586a4},this['_config']={..._0x12f49b},this['_name']=_0x12f49b['name'],this['_automaticDataCollectionEnabled']=_0x12f49b['automaticDataCollectionEnabled'],this['_container']=_0xa11bd5,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3ee2f8){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3ee2f8;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x4a69ad){this['_isDeleted']=_0x4a69ad;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x57a144,_0x36164b={}){let _0x5e09d8=_0x57a144;typeof _0x36164b!='object'&&(_0x36164b={'name':_0x36164b});const _0x38cc90={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x36164b},_0x237f1e=_0x38cc90['name'];if(typeof _0x237f1e!='string'||!_0x237f1e)throw ge['create']('bad-app-name',{'appName':String(_0x237f1e)});if(_0x5e09d8||(_0x5e09d8=$r()),!_0x5e09d8)throw ge['create']('no-options');const _0x5d2a77=Le['get'](_0x237f1e);if(_0x5d2a77){if(De(_0x5e09d8,_0x5d2a77['options'])&&De(_0x38cc90,_0x5d2a77['config']))return _0x5d2a77;throw ge['create']('duplicate-app',{'appName':_0x237f1e});}const _0x5cfe9a=new Ac(_0x237f1e);for(const _0x27526d of gi['values']())_0x5cfe9a['addComponent'](_0x27526d);const _0x4f98ac=new Il(_0x5e09d8,_0x38cc90,_0x5cfe9a);return Le['set'](_0x237f1e,_0x4f98ac),_0x4f98ac;}function Qr(_0x4b6a38=pi){const _0x1567fb=Le['get'](_0x4b6a38);if(!_0x1567fb&&_0x4b6a38===pi&&$r())return wl();if(!_0x1567fb)throw ge['create']('no-app',{'appName':_0x4b6a38});return _0x1567fb;}function l_(){return Array['from'](Le['values']());}async function h_(_0x5b05f4){let _0x1044ed=!0x1;const _0xdd5749=_0x5b05f4['name'];Le['has'](_0xdd5749)?(_0x1044ed=!0x0,Le['delete'](_0xdd5749)):_i['has'](_0xdd5749)&&_0x5b05f4['decRefCount']()<=0x0&&(_i['delete'](_0xdd5749),_0x1044ed=!0x0),_0x1044ed&&(await Promise['all'](_0x5b05f4['container']['getProviders']()['map'](_0x590534=>_0x590534['delete']())),_0x5b05f4['isDeleted']=!0x0);}function me(_0x9ef3f9,_0x117d2c,_0x316fd7){let _0x3e5450=vl[_0x9ef3f9]??_0x9ef3f9;_0x316fd7&&(_0x3e5450+='-'+_0x316fd7);const _0x3def92=_0x3e5450['match'](/\s|\//),_0x47c1e5=_0x117d2c['match'](/\s|\//);if(_0x3def92||_0x47c1e5){const _0x4c3e95=['Unable\x20to\x20register\x20library\x20\x22'+_0x3e5450+'\x22\x20with\x20version\x20\x22'+_0x117d2c+'\x22:'];_0x3def92&&_0x4c3e95['push']('library\x20name\x20\x22'+_0x3e5450+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3def92&&_0x47c1e5&&_0x4c3e95['push']('and'),_0x47c1e5&&_0x4c3e95['push']('version\x20name\x20\x22'+_0x117d2c+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x4c3e95['join']('\x20'));return;}et(new Me(_0x3e5450+'-version',()=>({'library':_0x3e5450,'version':_0x117d2c}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x2c7fa5,_0x5cf808)=>{switch(_0x5cf808){case 0x0:try{_0x2c7fa5['createObjectStore'](Rt);}catch(_0x30f09b){console['warn'](_0x30f09b);}}}})['catch'](_0x375826=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x375826['message']});})),ei;}async function Sl(_0x5a6396){try{const _0x3bf7b8=(await Jr())['transaction'](Rt),_0x447607=await _0x3bf7b8['objectStore'](Rt)['get'](Xr(_0x5a6396));return await _0x3bf7b8['done'],_0x447607;}catch(_0x2792cf){if(_0x2792cf instanceof Se)re['warn'](_0x2792cf['message']);else{const _0x2ed42f=ge['create']('idb-get',{'originalErrorMessage':_0x2792cf==null?void 0x0:_0x2792cf['message']});re['warn'](_0x2ed42f['message']);}}}async function Ls(_0x2c5ed3,_0x4fa570){try{const _0x7a6652=(await Jr())['transaction'](Rt,'readwrite');await _0x7a6652['objectStore'](Rt)['put'](_0x4fa570,Xr(_0x2c5ed3)),await _0x7a6652['done'];}catch(_0x3022a4){if(_0x3022a4 instanceof Se)re['warn'](_0x3022a4['message']);else{const _0xe6bdd9=ge['create']('idb-set',{'originalErrorMessage':_0x3022a4==null?void 0x0:_0x3022a4['message']});re['warn'](_0xe6bdd9['message']);}}}function Xr(_0x518582){return _0x518582['name']+'!'+_0x518582['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x6f2a7c){this['container']=_0x6f2a7c,this['_heartbeatsCache']=null;const _0x336f46=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x336f46),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x20fc6c=>(this['_heartbeatsCache']=_0x20fc6c,_0x20fc6c));}async['triggerHeartbeat'](){var _0x1159b9,_0x5d8dc4;try{const _0x5c97f6=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x41b9d9=xs();if(((_0x1159b9=this['_heartbeatsCache'])==null?void 0x0:_0x1159b9['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5d8dc4=this['_heartbeatsCache'])==null?void 0x0:_0x5d8dc4['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x41b9d9||this['_heartbeatsCache']['heartbeats']['some'](_0x536064=>_0x536064['date']===_0x41b9d9))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x41b9d9,'agent':_0x5c97f6}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x3711d5=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3711d5,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0xc325dd){re['warn'](_0xc325dd);}}async['getHeartbeatsHeader'](){var _0x357e4b;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x357e4b=this['_heartbeatsCache'])==null?void 0x0:_0x357e4b['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x30e7ca=xs(),{heartbeatsToSend:_0x21baba,unsentEntries:_0x1ece56}=kl(this['_heartbeatsCache']['heartbeats']),_0x4f91f4=an(JSON['stringify']({'version':0x2,'heartbeats':_0x21baba}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x30e7ca,_0x1ece56['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x1ece56,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4f91f4;}catch(_0x4ffa1f){return re['warn'](_0x4ffa1f),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x56e3ed,_0x39f948=bl){const _0x120325=[];let _0x179995=_0x56e3ed['slice']();for(const _0x4fa0ce of _0x56e3ed){const _0xa6c545=_0x120325['find'](_0x4b40af=>_0x4b40af['agent']===_0x4fa0ce['agent']);if(_0xa6c545){if(_0xa6c545['dates']['push'](_0x4fa0ce['date']),Fs(_0x120325)>_0x39f948){_0xa6c545['dates']['pop']();break;}}else{if(_0x120325['push']({'agent':_0x4fa0ce['agent'],'dates':[_0x4fa0ce['date']]}),Fs(_0x120325)>_0x39f948){_0x120325['pop']();break;}}_0x179995=_0x179995['slice'](0x1);}return{'heartbeatsToSend':_0x120325,'unsentEntries':_0x179995};}class Nl{constructor(_0x4843fb){this['app']=_0x4843fb,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2c6701=await Sl(this['app']);return _0x2c6701!=null&&_0x2c6701['heartbeats']?_0x2c6701:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3ea394){if(await this['_canUseIndexedDBPromise']){const _0x3bdafb=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x3ea394['lastSentHeartbeatDate']??_0x3bdafb['lastSentHeartbeatDate'],'heartbeats':_0x3ea394['heartbeats']});}else return;}async['add'](_0xce6748){if(await this['_canUseIndexedDBPromise']){const _0x5ecba0=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0xce6748['lastSentHeartbeatDate']??_0x5ecba0['lastSentHeartbeatDate'],'heartbeats':[..._0x5ecba0['heartbeats'],..._0xce6748['heartbeats']]});}else return;}}function Fs(_0x324252){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x324252}))['length'];}function Pl(_0x8e3417){if(_0x8e3417['length']===0x0)return-0x1;let _0x526583=0x0,_0x21a6c8=_0x8e3417[0x0]['date'];for(let _0x1abf6a=0x1;_0x1abf6a<_0x8e3417['length'];_0x1abf6a++)_0x8e3417[_0x1abf6a]['date']<_0x21a6c8&&(_0x21a6c8=_0x8e3417[_0x1abf6a]['date'],_0x526583=_0x1abf6a);return _0x526583;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x3216a8){et(new Me('platform-logger',_0x352831=>new Gc(_0x352831),'PRIVATE')),et(new Me('heartbeat',_0x183390=>new Al(_0x183390),'PRIVATE')),me(fi,Ds,_0x3216a8),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x377242){Zr=_0x377242;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x6e4cc7){this['domStorage_']=_0x6e4cc7,this['prefix_']='firebase:';}['set'](_0x5ec03b,_0x37f61c){_0x37f61c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5ec03b)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5ec03b),O(_0x37f61c));}['get'](_0x1e6f29){const _0x4f9856=this['domStorage_']['getItem'](this['prefixedName_'](_0x1e6f29));return _0x4f9856==null?null:bt(_0x4f9856);}['remove'](_0x4dccbe){this['domStorage_']['removeItem'](this['prefixedName_'](_0x4dccbe));}['prefixedName_'](_0x33f3f2){return this['prefix_']+_0x33f3f2;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5cf890,_0x1bea6f){_0x1bea6f==null?delete this['cache_'][_0x5cf890]:this['cache_'][_0x5cf890]=_0x1bea6f;}['get'](_0x3b22f8){return Y(this['cache_'],_0x3b22f8)?this['cache_'][_0x3b22f8]:null;}['remove'](_0x48f309){delete this['cache_'][_0x48f309];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x5cb1ae){try{if(typeof window<'u'&&typeof window[_0x5cb1ae]<'u'){const _0x263451=window[_0x5cb1ae];return _0x263451['setItem']('firebase:sentinel','cache'),_0x263451['removeItem']('firebase:sentinel'),new xl(_0x263451);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x96c5d0=0x1;return function(){return _0x96c5d0++;};}()),no=function(_0x4b5600){const _0x46d9dc=Tc(_0x4b5600),_0x3c4b3b=new Ec();_0x3c4b3b['update'](_0x46d9dc);const _0x1d0ad7=_0x3c4b3b['digest']();return Di['encodeByteArray'](_0x1d0ad7);},Bt=function(..._0x9d513b){let _0x44b7f5='';for(let _0x3ec732=0x0;_0x3ec732<_0x9d513b['length'];_0x3ec732++){const _0x32d8b9=_0x9d513b[_0x3ec732];Array['isArray'](_0x32d8b9)||_0x32d8b9&&typeof _0x32d8b9=='object'&&typeof _0x32d8b9['length']=='number'?_0x44b7f5+=Bt['apply'](null,_0x32d8b9):typeof _0x32d8b9=='object'?_0x44b7f5+=O(_0x32d8b9):_0x44b7f5+=_0x32d8b9,_0x44b7f5+='\x20';}return _0x44b7f5;};let Et=null,Vs=!0x0;const Wl=function(_0x3ed471,_0x4c728a){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x4b8876){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x19cf21=Bt['apply'](null,_0x4b8876);Et(_0x19cf21);}},Vt=function(_0x4f31f8){return function(..._0x26b688){L(_0x4f31f8,..._0x26b688);};},mi=function(..._0x14ee5c){const _0x33b741='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x14ee5c);Qe['error'](_0x33b741);},oe=function(..._0x2d11cc){const _0x48c6a2='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x2d11cc);throw Qe['error'](_0x48c6a2),new Error(_0x48c6a2);},U=function(..._0x3f6cc0){const _0x845af8='FIREBASE\x20WARNING:\x20'+Bt(..._0x3f6cc0);Qe['warn'](_0x845af8);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x32fe2f){return typeof _0x32fe2f=='number'&&(_0x32fe2f!==_0x32fe2f||_0x32fe2f===Number['POSITIVE_INFINITY']||_0x32fe2f===Number['NEGATIVE_INFINITY']);},Vl=function(_0x56ba4f){if(document['readyState']==='complete')_0x56ba4f();else{let _0x2550b8=!0x1;const _0xc4b420=function(){if(!document['body']){setTimeout(_0xc4b420,Math['floor'](0xa));return;}_0x2550b8||(_0x2550b8=!0x0,_0x56ba4f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0xc4b420,!0x1),window['addEventListener']('load',_0xc4b420,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0xc4b420();}),window['attachEvent']('onload',_0xc4b420));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0xa2775e,_0x52b482){if(_0xa2775e===_0x52b482)return 0x0;if(_0xa2775e===xe||_0x52b482===Ie)return-0x1;if(_0x52b482===xe||_0xa2775e===Ie)return 0x1;{const _0x39f783=Hs(_0xa2775e),_0x221182=Hs(_0x52b482);return _0x39f783!==null?_0x221182!==null?_0x39f783-_0x221182===0x0?_0xa2775e['length']-_0x52b482['length']:_0x39f783-_0x221182:-0x1:_0x221182!==null?0x1:_0xa2775e<_0x52b482?-0x1:0x1;}},Hl=function(_0x3e8faf,_0x33660f){return _0x3e8faf===_0x33660f?0x0:_0x3e8faf<_0x33660f?-0x1:0x1;},pt=function(_0x7c9d8c,_0x18308d){if(_0x18308d&&_0x7c9d8c in _0x18308d)return _0x18308d[_0x7c9d8c];throw new Error('Missing\x20required\x20key\x20('+_0x7c9d8c+')\x20in\x20object:\x20'+O(_0x18308d));},Bi=function(_0x296316){if(typeof _0x296316!='object'||_0x296316===null)return O(_0x296316);const _0x2d45ca=[];for(const _0x402a2a in _0x296316)_0x2d45ca['push'](_0x402a2a);_0x2d45ca['sort']();let _0x293a91='{';for(let _0x3d1f44=0x0;_0x3d1f44<_0x2d45ca['length'];_0x3d1f44++)_0x3d1f44!==0x0&&(_0x293a91+=','),_0x293a91+=O(_0x2d45ca[_0x3d1f44]),_0x293a91+=':',_0x293a91+=Bi(_0x296316[_0x2d45ca[_0x3d1f44]]);return _0x293a91+='}',_0x293a91;},io=function(_0x3a7b6b,_0x4f326f){const _0x5eb9c5=_0x3a7b6b['length'];if(_0x5eb9c5<=_0x4f326f)return[_0x3a7b6b];const _0x4eed1f=[];for(let _0x2fe31d=0x0;_0x2fe31d<_0x5eb9c5;_0x2fe31d+=_0x4f326f)_0x2fe31d+_0x4f326f>_0x5eb9c5?_0x4eed1f['push'](_0x3a7b6b['substring'](_0x2fe31d,_0x5eb9c5)):_0x4eed1f['push'](_0x3a7b6b['substring'](_0x2fe31d,_0x2fe31d+_0x4f326f));return _0x4eed1f;};function x(_0x17e6e0,_0x3e9129){for(const _0x488246 in _0x17e6e0)_0x17e6e0['hasOwnProperty'](_0x488246)&&_0x3e9129(_0x488246,_0x17e6e0[_0x488246]);}const so=function(_0x2e79f8){f(!Wi(_0x2e79f8),'Invalid\x20JSON\x20number');const _0x1fac28=0xb,_0x38a518=0x34,_0x1a0ab2=(0x1<<_0x1fac28-0x1)-0x1;let _0x30a44c,_0x2b9fdd,_0x86884c,_0x145a12,_0x3b511b;_0x2e79f8===0x0?(_0x2b9fdd=0x0,_0x86884c=0x0,_0x30a44c=0x1/_0x2e79f8===-0x1/0x0?0x1:0x0):(_0x30a44c=_0x2e79f8<0x0,_0x2e79f8=Math['abs'](_0x2e79f8),_0x2e79f8>=Math['pow'](0x2,0x1-_0x1a0ab2)?(_0x145a12=Math['min'](Math['floor'](Math['log'](_0x2e79f8)/Math['LN2']),_0x1a0ab2),_0x2b9fdd=_0x145a12+_0x1a0ab2,_0x86884c=Math['round'](_0x2e79f8*Math['pow'](0x2,_0x38a518-_0x145a12)-Math['pow'](0x2,_0x38a518))):(_0x2b9fdd=0x0,_0x86884c=Math['round'](_0x2e79f8/Math['pow'](0x2,0x1-_0x1a0ab2-_0x38a518))));const _0x2f3226=[];for(_0x3b511b=_0x38a518;_0x3b511b;_0x3b511b-=0x1)_0x2f3226['push'](_0x86884c%0x2?0x1:0x0),_0x86884c=Math['floor'](_0x86884c/0x2);for(_0x3b511b=_0x1fac28;_0x3b511b;_0x3b511b-=0x1)_0x2f3226['push'](_0x2b9fdd%0x2?0x1:0x0),_0x2b9fdd=Math['floor'](_0x2b9fdd/0x2);_0x2f3226['push'](_0x30a44c?0x1:0x0),_0x2f3226['reverse']();const _0x3ef04d=_0x2f3226['join']('');let _0x3fec31='';for(_0x3b511b=0x0;_0x3b511b<0x40;_0x3b511b+=0x8){let _0x507b0b=parseInt(_0x3ef04d['substr'](_0x3b511b,0x8),0x2)['toString'](0x10);_0x507b0b['length']===0x1&&(_0x507b0b='0'+_0x507b0b),_0x3fec31=_0x3fec31+_0x507b0b;}return _0x3fec31['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x1da07e,_0x319059){let _0x6b93bb='Unknown\x20Error';_0x1da07e==='too_big'?_0x6b93bb='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1da07e==='permission_denied'?_0x6b93bb='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1da07e==='unavailable'&&(_0x6b93bb='The\x20service\x20is\x20unavailable');const _0x4ca487=new Error(_0x1da07e+'\x20at\x20'+_0x319059['_path']['toString']()+':\x20'+_0x6b93bb);return _0x4ca487['code']=_0x1da07e['toUpperCase'](),_0x4ca487;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x411491){if(zl['test'](_0x411491)){const _0x2f5fc5=Number(_0x411491);if(_0x2f5fc5>=jl&&_0x2f5fc5<=Kl)return _0x2f5fc5;}return null;},lt=function(_0x4fa2f1){try{_0x4fa2f1();}catch(_0xfede12){setTimeout(()=>{const _0x10135d=_0xfede12['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x10135d),_0xfede12;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x4f4dcc,_0x648407){const _0x2a4392=setTimeout(_0x4f4dcc,_0x648407);return typeof _0x2a4392=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2a4392):typeof _0x2a4392=='object'&&_0x2a4392['unref']&&_0x2a4392['unref'](),_0x2a4392;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x56440a,_0x2dc0db){this['appCheckProvider']=_0x2dc0db,this['appName']=_0x56440a['name'],H(_0x56440a)&&_0x56440a['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x56440a['settings']['appCheckToken']),this['appCheck']=_0x2dc0db==null?void 0x0:_0x2dc0db['getImmediate']({'optional':!0x0}),this['appCheck']||_0x2dc0db==null||_0x2dc0db['get']()['then'](_0x483462=>this['appCheck']=_0x483462);}['getToken'](_0x2e1e72){if(this['serverAppAppCheckToken']){if(_0x2e1e72)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2e1e72):new Promise((_0x45fd04,_0x319b21)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2e1e72)['then'](_0x45fd04,_0x319b21):_0x45fd04(null);},0x0);});}['addTokenChangeListener'](_0x83477a){var _0x2f14a0;(_0x2f14a0=this['appCheckProvider'])==null||_0x2f14a0['get']()['then'](_0x16d0de=>_0x16d0de['addTokenListener'](_0x83477a));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x1a7b41,_0x25e70c,_0x269656){this['appName_']=_0x1a7b41,this['firebaseOptions_']=_0x25e70c,this['authProvider_']=_0x269656,this['auth_']=null,this['auth_']=_0x269656['getImmediate']({'optional':!0x0}),this['auth_']||_0x269656['onInit'](_0x4b3865=>this['auth_']=_0x4b3865);}['getToken'](_0x365a7e){return this['auth_']?this['auth_']['getToken'](_0x365a7e)['catch'](_0x1dba51=>_0x1dba51&&_0x1dba51['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1dba51)):new Promise((_0x1a0155,_0x45bef1)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x365a7e)['then'](_0x1a0155,_0x45bef1):_0x1a0155(null);},0x0);});}['addTokenChangeListener'](_0x1ea22c){this['auth_']?this['auth_']['addAuthTokenListener'](_0x1ea22c):this['authProvider_']['get']()['then'](_0x594195=>_0x594195['addAuthTokenListener'](_0x1ea22c));}['removeTokenChangeListener'](_0x531269){this['authProvider_']['get']()['then'](_0x204ed5=>_0x204ed5['removeAuthTokenListener'](_0x531269));}['notifyForInvalidToken'](){let _0x1621d8='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1621d8+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1621d8+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1621d8+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1621d8);}}class tn{constructor(_0x445bfe){this['accessToken']=_0x445bfe;}['getToken'](_0x516dd3){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x44adbd){_0x44adbd(this['accessToken']);}['removeTokenChangeListener'](_0x2f6e7a){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x1f62ee,_0x1641d7,_0x510a76,_0x36a9c6,_0x1b8fd4=!0x1,_0xe463d7='',_0x303883=!0x1,_0x4a6e12=!0x1,_0x69e4c2=null){this['secure']=_0x1641d7,this['namespace']=_0x510a76,this['webSocketOnly']=_0x36a9c6,this['nodeAdmin']=_0x1b8fd4,this['persistenceKey']=_0xe463d7,this['includeNamespaceInQueryParams']=_0x303883,this['isUsingEmulator']=_0x4a6e12,this['emulatorOptions']=_0x69e4c2,this['_host']=_0x1f62ee['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x1f62ee)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2b73e5){_0x2b73e5!==this['internalHost']&&(this['internalHost']=_0x2b73e5,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x453045=this['toURLString']();return this['persistenceKey']&&(_0x453045+='<'+this['persistenceKey']+'>'),_0x453045;}['toURLString'](){const _0x4828d6=this['secure']?'https://':'http://',_0x31207e=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4828d6+this['host']+'/'+_0x31207e;}}function Xl(_0x51af7e){return _0x51af7e['host']!==_0x51af7e['internalHost']||_0x51af7e['isCustomHost']()||_0x51af7e['includeNamespaceInQueryParams'];}function go(_0x3c40d2,_0x566a59,_0x33d389){f(typeof _0x566a59=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x33d389=='object','typeof\x20params\x20must\x20==\x20object');let _0x3ab22e;if(_0x566a59===fo)_0x3ab22e=(_0x3c40d2['secure']?'wss://':'ws://')+_0x3c40d2['internalHost']+'/.ws?';else{if(_0x566a59===po)_0x3ab22e=(_0x3c40d2['secure']?'https://':'http://')+_0x3c40d2['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x566a59);}Xl(_0x3c40d2)&&(_0x33d389['ns']=_0x3c40d2['namespace']);const _0x449b50=[];return x(_0x33d389,(_0x2ff715,_0x2c1a95)=>{_0x449b50['push'](_0x2ff715+'='+_0x2c1a95);}),_0x3ab22e+_0x449b50['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x21e0df,_0x51e509=0x1){Y(this['counters_'],_0x21e0df)||(this['counters_'][_0x21e0df]=0x0),this['counters_'][_0x21e0df]+=_0x51e509;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x23d969){const _0x56828c=_0x23d969['toString']();return ti[_0x56828c]||(ti[_0x56828c]=new Zl()),ti[_0x56828c];}function eh(_0x3dde1b,_0xbe4962){const _0xca8277=_0x3dde1b['toString']();return ni[_0xca8277]||(ni[_0xca8277]=_0xbe4962()),ni[_0xca8277];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x57e73e){this['onMessage_']=_0x57e73e,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x1026a6,_0x32a206){this['closeAfterResponse']=_0x1026a6,this['onClose']=_0x32a206,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x6ed68a,_0x55b78d){for(this['pendingResponses'][_0x6ed68a]=_0x55b78d;this['pendingResponses'][this['currentResponseNum']];){const _0xab4d8e=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x347770=0x0;_0x347770<_0xab4d8e['length'];++_0x347770)_0xab4d8e[_0x347770]&&lt(()=>{this['onMessage_'](_0xab4d8e[_0x347770]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x3818f3,_0x22cbbd,_0x1b3408,_0x146c23,_0x59fb2f,_0x5537e0,_0x189f1b){this['connId']=_0x3818f3,this['repoInfo']=_0x22cbbd,this['applicationId']=_0x1b3408,this['appCheckToken']=_0x146c23,this['authToken']=_0x59fb2f,this['transportSessionId']=_0x5537e0,this['lastSessionId']=_0x189f1b,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x3818f3),this['stats_']=Hi(_0x22cbbd),this['urlFn']=_0x1f7b26=>(this['appCheckToken']&&(_0x1f7b26[yi]=this['appCheckToken']),go(_0x22cbbd,po,_0x1f7b26));}['open'](_0x1f3092,_0x13151e){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x13151e,this['myPacketOrderer']=new th(_0x1f3092),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x3f0596)=>{const [_0x578cd1,_0x1eec0d,_0x40e290,_0x189e5e,_0x2b8bac]=_0x3f0596;if(this['incrementIncomingBytes_'](_0x3f0596),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x578cd1===$s)this['id']=_0x1eec0d,this['password']=_0x40e290;else{if(_0x578cd1===nh)_0x1eec0d?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1eec0d,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x578cd1);}}},(..._0x5c8b0e)=>{const [_0x11148f,_0x1b96e5]=_0x5c8b0e;this['incrementIncomingBytes_'](_0x5c8b0e),this['myPacketOrderer']['handleResponse'](_0x11148f,_0x1b96e5);},()=>{this['onClosed_']();},this['urlFn']);const _0x3fb301={};_0x3fb301[$s]='t',_0x3fb301[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3fb301[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3fb301[ro]=Vi,this['transportSessionId']&&(_0x3fb301[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x3fb301[ho]=this['lastSessionId']),this['applicationId']&&(_0x3fb301[uo]=this['applicationId']),this['appCheckToken']&&(_0x3fb301[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3fb301[ao]=co);const _0x55a543=this['urlFn'](_0x3fb301);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x55a543),this['scriptTagHolder']['addTag'](_0x55a543,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x530ad2){const _0x57f5ab=O(_0x530ad2);this['bytesSent']+=_0x57f5ab['length'],this['stats_']['incrementCounter']('bytes_sent',_0x57f5ab['length']);const _0x5913ab=Br(_0x57f5ab),_0xb467c4=io(_0x5913ab,hh);for(let _0x3ec661=0x0;_0x3ec661<_0xb467c4['length'];_0x3ec661++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xb467c4['length'],_0xb467c4[_0x3ec661]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4fa9da,_0x1fc74e){this['myDisconnFrame']=document['createElement']('iframe');const _0xefaee1={};_0xefaee1[lh]='t',_0xefaee1[mo]=_0x4fa9da,_0xefaee1[yo]=_0x1fc74e,this['myDisconnFrame']['src']=this['urlFn'](_0xefaee1),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x58f62d){const _0x481b8b=O(_0x58f62d)['length'];this['bytesReceived']+=_0x481b8b,this['stats_']['incrementCounter']('bytes_received',_0x481b8b);}}class $i{constructor(_0x57a0c3,_0x40fcc3,_0x5f1a85,_0x12ff8f){this['onDisconnect']=_0x5f1a85,this['urlFn']=_0x12ff8f,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x57a0c3,window[sh+this['uniqueCallbackIdentifier']]=_0x40fcc3,this['myIFrame']=$i['createIFrame_']();let _0x22b20b='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x22b20b='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x574b50='<html><body>'+_0x22b20b+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x574b50),this['myIFrame']['doc']['close']();}catch(_0x3071c2){L('frame\x20writing\x20exception'),_0x3071c2['stack']&&L(_0x3071c2['stack']),L(_0x3071c2);}}}static['createIFrame_'](){const _0x1da3a5=document['createElement']('iframe');if(_0x1da3a5['style']['display']='none',document['body']){document['body']['appendChild'](_0x1da3a5);try{_0x1da3a5['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2f1033=document['domain'];_0x1da3a5['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2f1033+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1da3a5['contentDocument']?_0x1da3a5['doc']=_0x1da3a5['contentDocument']:_0x1da3a5['contentWindow']?_0x1da3a5['doc']=_0x1da3a5['contentWindow']['document']:_0x1da3a5['document']&&(_0x1da3a5['doc']=_0x1da3a5['document']),_0x1da3a5;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x479f10=this['onDisconnect'];_0x479f10&&(this['onDisconnect']=null,_0x479f10());}['startLongPoll'](_0x2a9134,_0x58d08b){for(this['myID']=_0x2a9134,this['myPW']=_0x58d08b,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2c9d66={};_0x2c9d66[mo]=this['myID'],_0x2c9d66[yo]=this['myPW'],_0x2c9d66[vo]=this['currentSerial'];let _0x29f299=this['urlFn'](_0x2c9d66),_0x580309='',_0x55f398=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x580309['length']<=Eo;){const _0x3a85c9=this['pendingSegs']['shift']();_0x580309=_0x580309+'&'+oh+_0x55f398+'='+_0x3a85c9['seg']+'&'+ah+_0x55f398+'='+_0x3a85c9['ts']+'&'+ch+_0x55f398+'='+_0x3a85c9['d'],_0x55f398++;}return _0x29f299=_0x29f299+_0x580309,this['addLongPollTag_'](_0x29f299,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x15f332,_0x2fb5ee,_0x1e9319){this['pendingSegs']['push']({'seg':_0x15f332,'ts':_0x2fb5ee,'d':_0x1e9319}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5d9486,_0x59715a){this['outstandingRequests']['add'](_0x59715a);const _0x3fcb58=()=>{this['outstandingRequests']['delete'](_0x59715a),this['newRequest_']();},_0x3dc03b=setTimeout(_0x3fcb58,Math['floor'](uh)),_0x42242f=()=>{clearTimeout(_0x3dc03b),_0x3fcb58();};this['addTag'](_0x5d9486,_0x42242f);}['addTag'](_0x392b9e,_0x47d480){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x1e6c4b=this['myIFrame']['doc']['createElement']('script');_0x1e6c4b['type']='text/javascript',_0x1e6c4b['async']=!0x0,_0x1e6c4b['src']=_0x392b9e,_0x1e6c4b['onload']=_0x1e6c4b['onreadystatechange']=function(){const _0x2bbd4a=_0x1e6c4b['readyState'];(!_0x2bbd4a||_0x2bbd4a==='loaded'||_0x2bbd4a==='complete')&&(_0x1e6c4b['onload']=_0x1e6c4b['onreadystatechange']=null,_0x1e6c4b['parentNode']&&_0x1e6c4b['parentNode']['removeChild'](_0x1e6c4b),_0x47d480());},_0x1e6c4b['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x392b9e),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x1e6c4b);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x19ae80,_0x950128,_0x2f0c3b,_0xab4ba8,_0x5df2d1,_0x13ec7d,_0x388e29){this['connId']=_0x19ae80,this['applicationId']=_0x2f0c3b,this['appCheckToken']=_0xab4ba8,this['authToken']=_0x5df2d1,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x950128),this['connURL']=G['connectionURL_'](_0x950128,_0x13ec7d,_0x388e29,_0xab4ba8,_0x2f0c3b),this['nodeAdmin']=_0x950128['nodeAdmin'];}static['connectionURL_'](_0x205243,_0xfedcc5,_0x54fb46,_0x57f775,_0x4f7815){const _0x3bdf19={};return _0x3bdf19[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3bdf19[ao]=co),_0xfedcc5&&(_0x3bdf19[oo]=_0xfedcc5),_0x54fb46&&(_0x3bdf19[ho]=_0x54fb46),_0x57f775&&(_0x3bdf19[yi]=_0x57f775),_0x4f7815&&(_0x3bdf19[uo]=_0x4f7815),go(_0x205243,fo,_0x3bdf19);}['open'](_0xfa7bd7,_0x2de5f4){this['onDisconnect']=_0x2de5f4,this['onMessage']=_0xfa7bd7,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x1b72df;dc(),this['mySock']=new hn(this['connURL'],[],_0x1b72df);}catch(_0x227697){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x58512a=_0x227697['message']||_0x227697['data'];_0x58512a&&this['log_'](_0x58512a),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x235e5a=>{this['handleIncomingFrame'](_0x235e5a);},this['mySock']['onerror']=_0x275ea2=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5df203=_0x275ea2['message']||_0x275ea2['data'];_0x5df203&&this['log_'](_0x5df203),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x472a8f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3fdb3b=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2e1d6b=navigator['userAgent']['match'](_0x3fdb3b);_0x2e1d6b&&_0x2e1d6b['length']>0x1&&parseFloat(_0x2e1d6b[0x1])<4.4&&(_0x472a8f=!0x0);}return!_0x472a8f&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x1467f3){if(this['frames']['push'](_0x1467f3),this['frames']['length']===this['totalFrames']){const _0x5ce6cd=this['frames']['join']('');this['frames']=null;const _0x3bc18e=bt(_0x5ce6cd);this['onMessage'](_0x3bc18e);}}['handleNewFrameCount_'](_0x26ed62){this['totalFrames']=_0x26ed62,this['frames']=[];}['extractFrameCount_'](_0x522c62){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x522c62['length']<=0x6){const _0x320762=Number(_0x522c62);if(!isNaN(_0x320762))return this['handleNewFrameCount_'](_0x320762),null;}return this['handleNewFrameCount_'](0x1),_0x522c62;}['handleIncomingFrame'](_0x58fadd){if(this['mySock']===null)return;const _0xd11a18=_0x58fadd['data'];if(this['bytesReceived']+=_0xd11a18['length'],this['stats_']['incrementCounter']('bytes_received',_0xd11a18['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0xd11a18);else{const _0x22de12=this['extractFrameCount_'](_0xd11a18);_0x22de12!==null&&this['appendFrame_'](_0x22de12);}}['send'](_0x497cdd){this['resetKeepAlive']();const _0x4e851=O(_0x497cdd);this['bytesSent']+=_0x4e851['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4e851['length']);const _0x3fc88e=io(_0x4e851,fh);_0x3fc88e['length']>0x1&&this['sendString_'](String(_0x3fc88e['length']));for(let _0x1e0818=0x0;_0x1e0818<_0x3fc88e['length'];_0x1e0818++)this['sendString_'](_0x3fc88e[_0x1e0818]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0xe7b9b5){try{this['mySock']['send'](_0xe7b9b5);}catch(_0x4c2fe5){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4c2fe5['message']||_0x4c2fe5['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x188bb2){this['initTransports_'](_0x188bb2);}['initTransports_'](_0x322554){const _0x1b7bb1=G&&G['isAvailable']();let _0x215602=_0x1b7bb1&&!G['previouslyFailed']();if(_0x322554['webSocketOnly']&&(_0x1b7bb1||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x215602=!0x0),_0x215602)this['transports_']=[G];else{const _0x3f3284=this['transports_']=[];for(const _0x4777e0 of At['ALL_TRANSPORTS'])_0x4777e0&&_0x4777e0['isAvailable']()&&_0x3f3284['push'](_0x4777e0);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x262fcd,_0x5ac058,_0xd281b2,_0x3803b6,_0x2f9df0,_0x33f68d,_0xf8bfca,_0x2f0798,_0x507d92,_0x427983){this['id']=_0x262fcd,this['repoInfo_']=_0x5ac058,this['applicationId_']=_0xd281b2,this['appCheckToken_']=_0x3803b6,this['authToken_']=_0x2f9df0,this['onMessage_']=_0x33f68d,this['onReady_']=_0xf8bfca,this['onDisconnect_']=_0x2f0798,this['onKill_']=_0x507d92,this['lastSessionId']=_0x427983,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x5ac058),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x3bb8d1=this['transportManager_']['initialTransport']();this['conn_']=new _0x3bb8d1(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x3bb8d1['responsesRequiredToBeHealthy']||0x0;const _0x491769=this['connReceiver_'](this['conn_']),_0x4e2c0f=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x491769,_0x4e2c0f);},Math['floor'](0x0));const _0x5ca950=_0x3bb8d1['healthyTimeout']||0x0;_0x5ca950>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5ca950)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0xc6eaef){return _0x34e26d=>{_0xc6eaef===this['conn_']?this['onConnectionLost_'](_0x34e26d):_0xc6eaef===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x407c31){return _0x138c3d=>{this['state_']!==0x2&&(_0x407c31===this['rx_']?this['onPrimaryMessageReceived_'](_0x138c3d):_0x407c31===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x138c3d):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x58c6bf){const _0x3fdc21={'t':'d','d':_0x58c6bf};this['sendData_'](_0x3fdc21);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4087d8){if(ii in _0x4087d8){const _0x509df6=_0x4087d8[ii];_0x509df6===js?this['upgradeIfSecondaryHealthy_']():_0x509df6===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x509df6===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x472271){const _0x43bb52=pt('t',_0x472271),_0x2bd18c=pt('d',_0x472271);if(_0x43bb52==='c')this['onSecondaryControl_'](_0x2bd18c);else{if(_0x43bb52==='d')this['pendingDataMessages']['push'](_0x2bd18c);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x43bb52);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xe9c932){const _0x43f6fa=pt('t',_0xe9c932),_0x2ca55f=pt('d',_0xe9c932);_0x43f6fa==='c'?this['onControl_'](_0x2ca55f):_0x43f6fa==='d'&&this['onDataMessage_'](_0x2ca55f);}['onDataMessage_'](_0x28a89b){this['onPrimaryResponse_'](),this['onMessage_'](_0x28a89b);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2598f3){const _0x51fd64=pt(ii,_0x2598f3);if(Gs in _0x2598f3){const _0x410646=_0x2598f3[Gs];if(_0x51fd64===Ih){const _0xf15b02={..._0x410646};this['repoInfo_']['isUsingEmulator']&&(_0xf15b02['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xf15b02);}else{if(_0x51fd64===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2cc204=0x0;_0x2cc204<this['pendingDataMessages']['length'];++_0x2cc204)this['onDataMessage_'](this['pendingDataMessages'][_0x2cc204]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x51fd64===vh?this['onConnectionShutdown_'](_0x410646):_0x51fd64===qs?this['onReset_'](_0x410646):_0x51fd64===Eh?mi('Server\x20Error:\x20'+_0x410646):_0x51fd64===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x51fd64);}}}['onHandshake_'](_0x259d2f){const _0xd6fa13=_0x259d2f['ts'],_0x188d8c=_0x259d2f['v'],_0x6f8d14=_0x259d2f['h'];this['sessionId']=_0x259d2f['s'],this['repoInfo_']['host']=_0x6f8d14,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xd6fa13),Vi!==_0x188d8c&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2ae08f=this['transportManager_']['upgradeTransport']();_0x2ae08f&&this['startUpgrade_'](_0x2ae08f);}['startUpgrade_'](_0x521511){this['secondaryConn_']=new _0x521511(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x521511['responsesRequiredToBeHealthy']||0x0;const _0x3dff17=this['connReceiver_'](this['secondaryConn_']),_0x479120=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3dff17,_0x479120),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x26f6bd){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x26f6bd),this['repoInfo_']['host']=_0x26f6bd,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1845f4,_0x5f5744){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1845f4,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x5f5744,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3bb864=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3bb864||this['rx_']===_0x3bb864)&&this['close']();}['onConnectionLost_'](_0x3ed545){this['conn_']=null,!_0x3ed545&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x484c28){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x484c28),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1ee664){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1ee664);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x5f3b7b,_0x28b96a,_0x1cd569,_0x1e9cb4){}['merge'](_0x3c04e1,_0x2d04a6,_0x144aa1,_0x3fdee7){}['refreshAuthToken'](_0xabb278){}['refreshAppCheckToken'](_0x10a4dc){}['onDisconnectPut'](_0x212c7e,_0x1428c7,_0x58ee69){}['onDisconnectMerge'](_0x26d843,_0x239030,_0x3e476f){}['onDisconnectCancel'](_0x2b6202,_0x59abc5){}['reportStats'](_0x53bf53){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x4a7b73){this['allowedEvents_']=_0x4a7b73,this['listeners_']={},f(Array['isArray'](_0x4a7b73)&&_0x4a7b73['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x456380,..._0x441e78){if(Array['isArray'](this['listeners_'][_0x456380])){const _0x4dba80=[...this['listeners_'][_0x456380]];for(let _0x59eac7=0x0;_0x59eac7<_0x4dba80['length'];_0x59eac7++)_0x4dba80[_0x59eac7]['callback']['apply'](_0x4dba80[_0x59eac7]['context'],_0x441e78);}}['on'](_0x5036dc,_0x14163d,_0x24c58e){this['validateEventType_'](_0x5036dc),this['listeners_'][_0x5036dc]=this['listeners_'][_0x5036dc]||[],this['listeners_'][_0x5036dc]['push']({'callback':_0x14163d,'context':_0x24c58e});const _0x3ee1e1=this['getInitialEvent'](_0x5036dc);_0x3ee1e1&&_0x14163d['apply'](_0x24c58e,_0x3ee1e1);}['off'](_0x13bca7,_0x5756bc,_0x349b54){this['validateEventType_'](_0x13bca7);const _0x5249a1=this['listeners_'][_0x13bca7]||[];for(let _0xa765bf=0x0;_0xa765bf<_0x5249a1['length'];_0xa765bf++)if(_0x5249a1[_0xa765bf]['callback']===_0x5756bc&&(!_0x349b54||_0x349b54===_0x5249a1[_0xa765bf]['context'])){_0x5249a1['splice'](_0xa765bf,0x1);return;}}['validateEventType_'](_0x485cf1){f(this['allowedEvents_']['find'](_0x1cdecc=>_0x1cdecc===_0x485cf1),'Unknown\x20event:\x20'+_0x485cf1);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x18c4ec){return f(_0x18c4ec==='online','Unknown\x20event\x20type:\x20'+_0x18c4ec),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x3a2636,_0x3c071f){if(_0x3c071f===void 0x0){this['pieces_']=_0x3a2636['split']('/');let _0x2d07b9=0x0;for(let _0x25dfc5=0x0;_0x25dfc5<this['pieces_']['length'];_0x25dfc5++)this['pieces_'][_0x25dfc5]['length']>0x0&&(this['pieces_'][_0x2d07b9]=this['pieces_'][_0x25dfc5],_0x2d07b9++);this['pieces_']['length']=_0x2d07b9,this['pieceNum_']=0x0;}else this['pieces_']=_0x3a2636,this['pieceNum_']=_0x3c071f;}['toString'](){let _0x5d974d='';for(let _0x374058=this['pieceNum_'];_0x374058<this['pieces_']['length'];_0x374058++)this['pieces_'][_0x374058]!==''&&(_0x5d974d+='/'+this['pieces_'][_0x374058]);return _0x5d974d||'/';}}function w(){return new C('');}function y(_0x14b1de){return _0x14b1de['pieceNum_']>=_0x14b1de['pieces_']['length']?null:_0x14b1de['pieces_'][_0x14b1de['pieceNum_']];}function we(_0x4e06d8){return _0x4e06d8['pieces_']['length']-_0x4e06d8['pieceNum_'];}function b(_0x229cb6){let _0x34c87e=_0x229cb6['pieceNum_'];return _0x34c87e<_0x229cb6['pieces_']['length']&&_0x34c87e++,new C(_0x229cb6['pieces_'],_0x34c87e);}function Gi(_0x42075f){return _0x42075f['pieceNum_']<_0x42075f['pieces_']['length']?_0x42075f['pieces_'][_0x42075f['pieces_']['length']-0x1]:null;}function Ch(_0x128e3a){let _0x82f3a4='';for(let _0x209177=_0x128e3a['pieceNum_'];_0x209177<_0x128e3a['pieces_']['length'];_0x209177++)_0x128e3a['pieces_'][_0x209177]!==''&&(_0x82f3a4+='/'+encodeURIComponent(String(_0x128e3a['pieces_'][_0x209177])));return _0x82f3a4||'/';}function kt(_0x5d3ab5,_0x56c099=0x0){return _0x5d3ab5['pieces_']['slice'](_0x5d3ab5['pieceNum_']+_0x56c099);}function To(_0x35984e){if(_0x35984e['pieceNum_']>=_0x35984e['pieces_']['length'])return null;const _0x54fb13=[];for(let _0x3af8a3=_0x35984e['pieceNum_'];_0x3af8a3<_0x35984e['pieces_']['length']-0x1;_0x3af8a3++)_0x54fb13['push'](_0x35984e['pieces_'][_0x3af8a3]);return new C(_0x54fb13,0x0);}function A(_0x59c22f,_0xa61566){const _0x64d855=[];for(let _0xd97b72=_0x59c22f['pieceNum_'];_0xd97b72<_0x59c22f['pieces_']['length'];_0xd97b72++)_0x64d855['push'](_0x59c22f['pieces_'][_0xd97b72]);if(_0xa61566 instanceof C){for(let _0x3b0831=_0xa61566['pieceNum_'];_0x3b0831<_0xa61566['pieces_']['length'];_0x3b0831++)_0x64d855['push'](_0xa61566['pieces_'][_0x3b0831]);}else{const _0x1c6df4=_0xa61566['split']('/');for(let _0x5c696c=0x0;_0x5c696c<_0x1c6df4['length'];_0x5c696c++)_0x1c6df4[_0x5c696c]['length']>0x0&&_0x64d855['push'](_0x1c6df4[_0x5c696c]);}return new C(_0x64d855,0x0);}function v(_0x5f1fe3){return _0x5f1fe3['pieceNum_']>=_0x5f1fe3['pieces_']['length'];}function F(_0x13d0fb,_0x2c6ca6){const _0x893c2b=y(_0x13d0fb),_0x473eba=y(_0x2c6ca6);if(_0x893c2b===null)return _0x2c6ca6;if(_0x893c2b===_0x473eba)return F(b(_0x13d0fb),b(_0x2c6ca6));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2c6ca6+')\x20is\x20not\x20within\x20outerPath\x20('+_0x13d0fb+')');}function Th(_0x1571d6,_0x3d63c6){const _0x2a5335=kt(_0x1571d6,0x0),_0x44c1e8=kt(_0x3d63c6,0x0);for(let _0x27a42e=0x0;_0x27a42e<_0x2a5335['length']&&_0x27a42e<_0x44c1e8['length'];_0x27a42e++){const _0x1c6c5b=He(_0x2a5335[_0x27a42e],_0x44c1e8[_0x27a42e]);if(_0x1c6c5b!==0x0)return _0x1c6c5b;}return _0x2a5335['length']===_0x44c1e8['length']?0x0:_0x2a5335['length']<_0x44c1e8['length']?-0x1:0x1;}function qi(_0x2d3a92,_0x1e2d3e){if(we(_0x2d3a92)!==we(_0x1e2d3e))return!0x1;for(let _0x133da9=_0x2d3a92['pieceNum_'],_0x4ed2b3=_0x1e2d3e['pieceNum_'];_0x133da9<=_0x2d3a92['pieces_']['length'];_0x133da9++,_0x4ed2b3++)if(_0x2d3a92['pieces_'][_0x133da9]!==_0x1e2d3e['pieces_'][_0x4ed2b3])return!0x1;return!0x0;}function $(_0x373b9b,_0x7d98e3){let _0x2c5499=_0x373b9b['pieceNum_'],_0x4cc901=_0x7d98e3['pieceNum_'];if(we(_0x373b9b)>we(_0x7d98e3))return!0x1;for(;_0x2c5499<_0x373b9b['pieces_']['length'];){if(_0x373b9b['pieces_'][_0x2c5499]!==_0x7d98e3['pieces_'][_0x4cc901])return!0x1;++_0x2c5499,++_0x4cc901;}return!0x0;}class Sh{constructor(_0xd5a21e,_0x1a1a93){this['errorPrefix_']=_0x1a1a93,this['parts_']=kt(_0xd5a21e,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3f1bed=0x0;_0x3f1bed<this['parts_']['length'];_0x3f1bed++)this['byteLength_']+=Pn(this['parts_'][_0x3f1bed]);So(this);}}function bh(_0x24bec6,_0x512783){_0x24bec6['parts_']['length']>0x0&&(_0x24bec6['byteLength_']+=0x1),_0x24bec6['parts_']['push'](_0x512783),_0x24bec6['byteLength_']+=Pn(_0x512783),So(_0x24bec6);}function Rh(_0xe11aff){const _0x5b01d1=_0xe11aff['parts_']['pop']();_0xe11aff['byteLength_']-=Pn(_0x5b01d1),_0xe11aff['parts_']['length']>0x0&&(_0xe11aff['byteLength_']-=0x1);}function So(_0x337dc9){if(_0x337dc9['byteLength_']>Js)throw new Error(_0x337dc9['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x337dc9['byteLength_']+').');if(_0x337dc9['parts_']['length']>Qs)throw new Error(_0x337dc9['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x337dc9));}function Ne(_0x3ac779){return _0x3ac779['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3ac779['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x3a5ab2,_0x228719;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x228719='visibilitychange',_0x3a5ab2='hidden'):typeof document['mozHidden']<'u'?(_0x228719='mozvisibilitychange',_0x3a5ab2='mozHidden'):typeof document['msHidden']<'u'?(_0x228719='msvisibilitychange',_0x3a5ab2='msHidden'):typeof document['webkitHidden']<'u'&&(_0x228719='webkitvisibilitychange',_0x3a5ab2='webkitHidden')),this['visible_']=!0x0,_0x228719&&document['addEventListener'](_0x228719,()=>{const _0x4d808e=!document[_0x3a5ab2];_0x4d808e!==this['visible_']&&(this['visible_']=_0x4d808e,this['trigger']('visible',_0x4d808e));},!0x1);}['getInitialEvent'](_0x5622c9){return f(_0x5622c9==='visible','Unknown\x20event\x20type:\x20'+_0x5622c9),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x310913,_0x1a8ec9,_0x5dd2b5,_0x342532,_0x172bf3,_0x2b764d,_0x7ed3d3,_0x39219b){if(super(),this['repoInfo_']=_0x310913,this['applicationId_']=_0x1a8ec9,this['onDataUpdate_']=_0x5dd2b5,this['onConnectStatus_']=_0x342532,this['onServerInfoUpdate_']=_0x172bf3,this['authTokenProvider_']=_0x2b764d,this['appCheckTokenProvider_']=_0x7ed3d3,this['authOverride_']=_0x39219b,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x39219b)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x310913['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x244282,_0xe45cd1,_0xce29a6){const _0x4a1e3a=++this['requestNumber_'],_0x3c06ca={'r':_0x4a1e3a,'a':_0x244282,'b':_0xe45cd1};this['log_'](O(_0x3c06ca)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3c06ca),_0xce29a6&&(this['requestCBHash_'][_0x4a1e3a]=_0xce29a6);}['get'](_0x15bbb4){this['initConnection_']();const _0x5f55da=new Ve(),_0x36cab0={'action':'g','request':{'p':_0x15bbb4['_path']['toString'](),'q':_0x15bbb4['_queryObject']},'onComplete':_0x19316d=>{const _0x3441fc=_0x19316d['d'];_0x19316d['s']==='ok'?_0x5f55da['resolve'](_0x3441fc):_0x5f55da['reject'](_0x3441fc);}};this['outstandingGets_']['push'](_0x36cab0),this['outstandingGetCount_']++;const _0x11dedc=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x11dedc),_0x5f55da['promise'];}['listen'](_0x5c2d3f,_0x47d3b9,_0x190e9f,_0x15457b){this['initConnection_']();const _0x1b4220=_0x5c2d3f['_queryIdentifier'],_0x2950cc=_0x5c2d3f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2950cc+'\x20'+_0x1b4220),this['listens']['has'](_0x2950cc)||this['listens']['set'](_0x2950cc,new Map()),f(_0x5c2d3f['_queryParams']['isDefault']()||!_0x5c2d3f['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2950cc)['has'](_0x1b4220),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4584fd={'onComplete':_0x15457b,'hashFn':_0x47d3b9,'query':_0x5c2d3f,'tag':_0x190e9f};this['listens']['get'](_0x2950cc)['set'](_0x1b4220,_0x4584fd),this['connected_']&&this['sendListen_'](_0x4584fd);}['sendGet_'](_0x474f0c){const _0x1d81ba=this['outstandingGets_'][_0x474f0c];this['sendRequest']('g',_0x1d81ba['request'],_0x36df2b=>{delete this['outstandingGets_'][_0x474f0c],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1d81ba['onComplete']&&_0x1d81ba['onComplete'](_0x36df2b);});}['sendListen_'](_0x44339b){const _0x47fca1=_0x44339b['query'],_0x5b6624=_0x47fca1['_path']['toString'](),_0x267904=_0x47fca1['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5b6624+'\x20for\x20'+_0x267904);const _0x33d9f0={'p':_0x5b6624},_0xfd4c8d='q';_0x44339b['tag']&&(_0x33d9f0['q']=_0x47fca1['_queryObject'],_0x33d9f0['t']=_0x44339b['tag']),_0x33d9f0['h']=_0x44339b['hashFn'](),this['sendRequest'](_0xfd4c8d,_0x33d9f0,_0x1b81a7=>{const _0x1180ac=_0x1b81a7['d'],_0x5072c7=_0x1b81a7['s'];ie['warnOnListenWarnings_'](_0x1180ac,_0x47fca1),(this['listens']['get'](_0x5b6624)&&this['listens']['get'](_0x5b6624)['get'](_0x267904))===_0x44339b&&(this['log_']('listen\x20response',_0x1b81a7),_0x5072c7!=='ok'&&this['removeListen_'](_0x5b6624,_0x267904),_0x44339b['onComplete']&&_0x44339b['onComplete'](_0x5072c7,_0x1180ac));});}static['warnOnListenWarnings_'](_0x56b6a6,_0x911088){if(_0x56b6a6&&typeof _0x56b6a6=='object'&&Y(_0x56b6a6,'w')){const _0x36dda8=Oe(_0x56b6a6,'w');if(Array['isArray'](_0x36dda8)&&~_0x36dda8['indexOf']('no_index')){const _0x59f814='\x22.indexOn\x22:\x20\x22'+_0x911088['_queryParams']['getIndex']()['toString']()+'\x22',_0x1183f8=_0x911088['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x59f814+'\x20at\x20'+_0x1183f8+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1f110e){this['authToken_']=_0x1f110e,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1f110e);}['reduceReconnectDelayIfAdminCredential_'](_0x13520a){(_0x13520a&&_0x13520a['length']===0x28||vc(_0x13520a))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x4aafe9){this['appCheckToken_']=_0x4aafe9,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x309be9=this['authToken_'],_0x260607=yc(_0x309be9)?'auth':'gauth',_0x38750a={'cred':_0x309be9};this['authOverride_']===null?_0x38750a['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x38750a['authvar']=this['authOverride_']),this['sendRequest'](_0x260607,_0x38750a,_0x55241b=>{const _0x3c0ac9=_0x55241b['s'],_0x29b293=_0x55241b['d']||'error';this['authToken_']===_0x309be9&&(_0x3c0ac9==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3c0ac9,_0x29b293));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x382a6d=>{const _0x344794=_0x382a6d['s'],_0x3754de=_0x382a6d['d']||'error';_0x344794==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x344794,_0x3754de);});}['unlisten'](_0x3649b0,_0x39a8cf){const _0xcbd84f=_0x3649b0['_path']['toString'](),_0x520d72=_0x3649b0['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0xcbd84f+'\x20'+_0x520d72),f(_0x3649b0['_queryParams']['isDefault']()||!_0x3649b0['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0xcbd84f,_0x520d72)&&this['connected_']&&this['sendUnlisten_'](_0xcbd84f,_0x520d72,_0x3649b0['_queryObject'],_0x39a8cf);}['sendUnlisten_'](_0x4c9054,_0x4a8d9f,_0x56bf71,_0x41ee5e){this['log_']('Unlisten\x20on\x20'+_0x4c9054+'\x20for\x20'+_0x4a8d9f);const _0x24aa67={'p':_0x4c9054},_0x1c7c15='n';_0x41ee5e&&(_0x24aa67['q']=_0x56bf71,_0x24aa67['t']=_0x41ee5e),this['sendRequest'](_0x1c7c15,_0x24aa67);}['onDisconnectPut'](_0x51be90,_0x3704fb,_0x247837){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x51be90,_0x3704fb,_0x247837):this['onDisconnectRequestQueue_']['push']({'pathString':_0x51be90,'action':'o','data':_0x3704fb,'onComplete':_0x247837});}['onDisconnectMerge'](_0x221882,_0x1f9db2,_0x324692){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x221882,_0x1f9db2,_0x324692):this['onDisconnectRequestQueue_']['push']({'pathString':_0x221882,'action':'om','data':_0x1f9db2,'onComplete':_0x324692});}['onDisconnectCancel'](_0x3e9c1e,_0x13aeb8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3e9c1e,null,_0x13aeb8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3e9c1e,'action':'oc','data':null,'onComplete':_0x13aeb8});}['sendOnDisconnect_'](_0x2890a1,_0x1bd216,_0x3ef635,_0x4a7c14){const _0xe24a91={'p':_0x1bd216,'d':_0x3ef635};this['log_']('onDisconnect\x20'+_0x2890a1,_0xe24a91),this['sendRequest'](_0x2890a1,_0xe24a91,_0x2fa3d0=>{_0x4a7c14&&setTimeout(()=>{_0x4a7c14(_0x2fa3d0['s'],_0x2fa3d0['d']);},Math['floor'](0x0));});}['put'](_0x2d324f,_0xa0ed3a,_0x1191a2,_0x3e7add){this['putInternal']('p',_0x2d324f,_0xa0ed3a,_0x1191a2,_0x3e7add);}['merge'](_0x4fb4e5,_0x24bf41,_0x4bd788,_0x47782f){this['putInternal']('m',_0x4fb4e5,_0x24bf41,_0x4bd788,_0x47782f);}['putInternal'](_0x6e81b2,_0x32e34d,_0x2e32da,_0x4a4bd3,_0x20124e){this['initConnection_']();const _0xf462a1={'p':_0x32e34d,'d':_0x2e32da};_0x20124e!==void 0x0&&(_0xf462a1['h']=_0x20124e),this['outstandingPuts_']['push']({'action':_0x6e81b2,'request':_0xf462a1,'onComplete':_0x4a4bd3}),this['outstandingPutCount_']++;const _0x3c72aa=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3c72aa):this['log_']('Buffering\x20put:\x20'+_0x32e34d);}['sendPut_'](_0x21766e){const _0x46270f=this['outstandingPuts_'][_0x21766e]['action'],_0x54c940=this['outstandingPuts_'][_0x21766e]['request'],_0x103c39=this['outstandingPuts_'][_0x21766e]['onComplete'];this['outstandingPuts_'][_0x21766e]['queued']=this['connected_'],this['sendRequest'](_0x46270f,_0x54c940,_0x174cec=>{this['log_'](_0x46270f+'\x20response',_0x174cec),delete this['outstandingPuts_'][_0x21766e],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x103c39&&_0x103c39(_0x174cec['s'],_0x174cec['d']);});}['reportStats'](_0x2f0ea9){if(this['connected_']){const _0x3a0b34={'c':_0x2f0ea9};this['log_']('reportStats',_0x3a0b34),this['sendRequest']('s',_0x3a0b34,_0x3dc9b1=>{if(_0x3dc9b1['s']!=='ok'){const _0x5b778a=_0x3dc9b1['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5b778a);}});}}['onDataMessage_'](_0x32a9d1){if('r'in _0x32a9d1){this['log_']('from\x20server:\x20'+O(_0x32a9d1));const _0x5246b8=_0x32a9d1['r'],_0x4d4c42=this['requestCBHash_'][_0x5246b8];_0x4d4c42&&(delete this['requestCBHash_'][_0x5246b8],_0x4d4c42(_0x32a9d1['b']));}else{if('error'in _0x32a9d1)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x32a9d1['error'];'a'in _0x32a9d1&&this['onDataPush_'](_0x32a9d1['a'],_0x32a9d1['b']);}}['onDataPush_'](_0x28fef3,_0x37614a){this['log_']('handleServerMessage',_0x28fef3,_0x37614a),_0x28fef3==='d'?this['onDataUpdate_'](_0x37614a['p'],_0x37614a['d'],!0x1,_0x37614a['t']):_0x28fef3==='m'?this['onDataUpdate_'](_0x37614a['p'],_0x37614a['d'],!0x0,_0x37614a['t']):_0x28fef3==='c'?this['onListenRevoked_'](_0x37614a['p'],_0x37614a['q']):_0x28fef3==='ac'?this['onAuthRevoked_'](_0x37614a['s'],_0x37614a['d']):_0x28fef3==='apc'?this['onAppCheckRevoked_'](_0x37614a['s'],_0x37614a['d']):_0x28fef3==='sd'?this['onSecurityDebugPacket_'](_0x37614a):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x28fef3)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4ea045,_0x5f3001){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4ea045),this['lastSessionId']=_0x5f3001,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4fb0b5){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4fb0b5));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x8b04c5){_0x8b04c5&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x8b04c5;}['onOnline_'](_0x5e7296){_0x5e7296?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4be1cb=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x4f0d53=Math['max'](0x0,this['reconnectDelay_']-_0x4be1cb);_0x4f0d53=Math['random']()*_0x4f0d53,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x4f0d53+'ms'),this['scheduleConnect_'](_0x4f0d53),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1cbd39=this['onDataMessage_']['bind'](this),_0x5f3e0c=this['onReady_']['bind'](this),_0x5eb537=this['onRealtimeDisconnect_']['bind'](this),_0x68971f=this['id']+':'+ie['nextConnectionId_']++,_0x37b4fd=this['lastSessionId'];let _0x3b6856=!0x1,_0x215411=null;const _0x463efc=function(){_0x215411?_0x215411['close']():(_0x3b6856=!0x0,_0x5eb537());},_0x2de944=function(_0x33e9e5){f(_0x215411,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x215411['sendRequest'](_0x33e9e5);};this['realtime_']={'close':_0x463efc,'sendRequest':_0x2de944};const _0x4a98ee=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5d61f0,_0x36d424]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4a98ee),this['appCheckTokenProvider_']['getToken'](_0x4a98ee)]);_0x3b6856?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5d61f0&&_0x5d61f0['accessToken'],this['appCheckToken_']=_0x36d424&&_0x36d424['token'],_0x215411=new wh(_0x68971f,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1cbd39,_0x5f3e0c,_0x5eb537,_0x5dc280=>{U(_0x5dc280+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x37b4fd));}catch(_0xcba4fd){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0xcba4fd),_0x3b6856||(this['repoInfo_']['nodeAdmin']&&U(_0xcba4fd),_0x463efc());}}}['interrupt'](_0x274bba){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x274bba),this['interruptReasons_'][_0x274bba]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x3f9d54){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x3f9d54),delete this['interruptReasons_'][_0x3f9d54],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1eed7a){const _0x314c53=_0x1eed7a-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x314c53});}['cancelSentTransactions_'](){for(let _0xcb6424=0x0;_0xcb6424<this['outstandingPuts_']['length'];_0xcb6424++){const _0x35fe76=this['outstandingPuts_'][_0xcb6424];_0x35fe76&&'h'in _0x35fe76['request']&&_0x35fe76['queued']&&(_0x35fe76['onComplete']&&_0x35fe76['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xcb6424],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x4ae118,_0x17eb91){let _0xffa4c2;_0x17eb91?_0xffa4c2=_0x17eb91['map'](_0x2fbe48=>Bi(_0x2fbe48))['join']('$'):_0xffa4c2='default';const _0x111056=this['removeListen_'](_0x4ae118,_0xffa4c2);_0x111056&&_0x111056['onComplete']&&_0x111056['onComplete']('permission_denied');}['removeListen_'](_0x4375ce,_0x2736bc){const _0x313b52=new C(_0x4375ce)['toString']();let _0x4b4891;if(this['listens']['has'](_0x313b52)){const _0x490b06=this['listens']['get'](_0x313b52);_0x4b4891=_0x490b06['get'](_0x2736bc),_0x490b06['delete'](_0x2736bc),_0x490b06['size']===0x0&&this['listens']['delete'](_0x313b52);}else _0x4b4891=void 0x0;return _0x4b4891;}['onAuthRevoked_'](_0x5773b2,_0x22984f){L('Auth\x20token\x20revoked:\x20'+_0x5773b2+'/'+_0x22984f),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5773b2==='invalid_token'||_0x5773b2==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x544cac,_0x3855f0){L('App\x20check\x20token\x20revoked:\x20'+_0x544cac+'/'+_0x3855f0),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x544cac==='invalid_token'||_0x544cac==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1d20c8){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1d20c8):'msg'in _0x1d20c8&&console['log']('FIREBASE:\x20'+_0x1d20c8['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1be675 of this['listens']['values']())for(const _0x12ecf8 of _0x1be675['values']())this['sendListen_'](_0x12ecf8);for(let _0x41a938=0x0;_0x41a938<this['outstandingPuts_']['length'];_0x41a938++)this['outstandingPuts_'][_0x41a938]&&this['sendPut_'](_0x41a938);for(;this['onDisconnectRequestQueue_']['length'];){const _0x5c7e99=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x5c7e99['action'],_0x5c7e99['pathString'],_0x5c7e99['data'],_0x5c7e99['onComplete']);}for(let _0x5f1e4f=0x0;_0x5f1e4f<this['outstandingGets_']['length'];_0x5f1e4f++)this['outstandingGets_'][_0x5f1e4f]&&this['sendGet_'](_0x5f1e4f);}['sendConnectStats_'](){const _0x2eecb0={};let _0xffb2dd='js';_0x2eecb0['sdk.'+_0xffb2dd+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x2eecb0['framework.cordova']=0x1:qr()&&(_0x2eecb0['framework.reactnative']=0x1),this['reportStats'](_0x2eecb0);}['shouldReconnect_'](){const _0x59f3cf=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x59f3cf;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x22045f,_0x1c2fa8){this['name']=_0x22045f,this['node']=_0x1c2fa8;}static['Wrap'](_0x19c93f,_0x27f738){return new E(_0x19c93f,_0x27f738);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x287dc3,_0x26eae9){const _0x3b1f11=new E(xe,_0x287dc3),_0x17465b=new E(xe,_0x26eae9);return this['compare'](_0x3b1f11,_0x17465b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x4b5401){Xt=_0x4b5401;}['compare'](_0x45667f,_0x25bd6b){return He(_0x45667f['name'],_0x25bd6b['name']);}['isDefinedOn'](_0x2aee72){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x57070a,_0x151045){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x4167ee,_0x46408f){return f(typeof _0x4167ee=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4167ee,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x272df1,_0x3a978e,_0x513afd,_0x234ea0,_0x103fa9=null){this['isReverse_']=_0x234ea0,this['resultGenerator_']=_0x103fa9,this['nodeStack_']=[];let _0x397cfe=0x1;for(;!_0x272df1['isEmpty']();)if(_0x272df1=_0x272df1,_0x397cfe=_0x3a978e?_0x513afd(_0x272df1['key'],_0x3a978e):0x1,_0x234ea0&&(_0x397cfe*=-0x1),_0x397cfe<0x0)this['isReverse_']?_0x272df1=_0x272df1['left']:_0x272df1=_0x272df1['right'];else{if(_0x397cfe===0x0){this['nodeStack_']['push'](_0x272df1);break;}else this['nodeStack_']['push'](_0x272df1),this['isReverse_']?_0x272df1=_0x272df1['right']:_0x272df1=_0x272df1['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3ff914=this['nodeStack_']['pop'](),_0x13fb2a;if(this['resultGenerator_']?_0x13fb2a=this['resultGenerator_'](_0x3ff914['key'],_0x3ff914['value']):_0x13fb2a={'key':_0x3ff914['key'],'value':_0x3ff914['value']},this['isReverse_']){for(_0x3ff914=_0x3ff914['left'];!_0x3ff914['isEmpty']();)this['nodeStack_']['push'](_0x3ff914),_0x3ff914=_0x3ff914['right'];}else{for(_0x3ff914=_0x3ff914['right'];!_0x3ff914['isEmpty']();)this['nodeStack_']['push'](_0x3ff914),_0x3ff914=_0x3ff914['left'];}return _0x13fb2a;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x840051=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x840051['key'],_0x840051['value']):{'key':_0x840051['key'],'value':_0x840051['value']};}}class M{constructor(_0x5bea09,_0x24f9e7,_0x542bf5,_0x2f7779,_0x4d182b){this['key']=_0x5bea09,this['value']=_0x24f9e7,this['color']=_0x542bf5??M['RED'],this['left']=_0x2f7779??B['EMPTY_NODE'],this['right']=_0x4d182b??B['EMPTY_NODE'];}['copy'](_0xc9e57,_0x4f74ce,_0x5eff40,_0x2d122e,_0x4db308){return new M(_0xc9e57??this['key'],_0x4f74ce??this['value'],_0x5eff40??this['color'],_0x2d122e??this['left'],_0x4db308??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x212bd1){return this['left']['inorderTraversal'](_0x212bd1)||!!_0x212bd1(this['key'],this['value'])||this['right']['inorderTraversal'](_0x212bd1);}['reverseTraversal'](_0x21d339){return this['right']['reverseTraversal'](_0x21d339)||_0x21d339(this['key'],this['value'])||this['left']['reverseTraversal'](_0x21d339);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3c10d0,_0x4d3a60,_0x16a04a){let _0x597c37=this;const _0x49aff2=_0x16a04a(_0x3c10d0,_0x597c37['key']);return _0x49aff2<0x0?_0x597c37=_0x597c37['copy'](null,null,null,_0x597c37['left']['insert'](_0x3c10d0,_0x4d3a60,_0x16a04a),null):_0x49aff2===0x0?_0x597c37=_0x597c37['copy'](null,_0x4d3a60,null,null,null):_0x597c37=_0x597c37['copy'](null,null,null,null,_0x597c37['right']['insert'](_0x3c10d0,_0x4d3a60,_0x16a04a)),_0x597c37['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x335b82=this;return!_0x335b82['left']['isRed_']()&&!_0x335b82['left']['left']['isRed_']()&&(_0x335b82=_0x335b82['moveRedLeft_']()),_0x335b82=_0x335b82['copy'](null,null,null,_0x335b82['left']['removeMin_'](),null),_0x335b82['fixUp_']();}['remove'](_0x3d9743,_0x179f0e){let _0xfa7f5b,_0x3b9a92;if(_0xfa7f5b=this,_0x179f0e(_0x3d9743,_0xfa7f5b['key'])<0x0)!_0xfa7f5b['left']['isEmpty']()&&!_0xfa7f5b['left']['isRed_']()&&!_0xfa7f5b['left']['left']['isRed_']()&&(_0xfa7f5b=_0xfa7f5b['moveRedLeft_']()),_0xfa7f5b=_0xfa7f5b['copy'](null,null,null,_0xfa7f5b['left']['remove'](_0x3d9743,_0x179f0e),null);else{if(_0xfa7f5b['left']['isRed_']()&&(_0xfa7f5b=_0xfa7f5b['rotateRight_']()),!_0xfa7f5b['right']['isEmpty']()&&!_0xfa7f5b['right']['isRed_']()&&!_0xfa7f5b['right']['left']['isRed_']()&&(_0xfa7f5b=_0xfa7f5b['moveRedRight_']()),_0x179f0e(_0x3d9743,_0xfa7f5b['key'])===0x0){if(_0xfa7f5b['right']['isEmpty']())return B['EMPTY_NODE'];_0x3b9a92=_0xfa7f5b['right']['min_'](),_0xfa7f5b=_0xfa7f5b['copy'](_0x3b9a92['key'],_0x3b9a92['value'],null,null,_0xfa7f5b['right']['removeMin_']());}_0xfa7f5b=_0xfa7f5b['copy'](null,null,null,null,_0xfa7f5b['right']['remove'](_0x3d9743,_0x179f0e));}return _0xfa7f5b['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2c3052=this;return _0x2c3052['right']['isRed_']()&&!_0x2c3052['left']['isRed_']()&&(_0x2c3052=_0x2c3052['rotateLeft_']()),_0x2c3052['left']['isRed_']()&&_0x2c3052['left']['left']['isRed_']()&&(_0x2c3052=_0x2c3052['rotateRight_']()),_0x2c3052['left']['isRed_']()&&_0x2c3052['right']['isRed_']()&&(_0x2c3052=_0x2c3052['colorFlip_']()),_0x2c3052;}['moveRedLeft_'](){let _0x36dbd4=this['colorFlip_']();return _0x36dbd4['right']['left']['isRed_']()&&(_0x36dbd4=_0x36dbd4['copy'](null,null,null,null,_0x36dbd4['right']['rotateRight_']()),_0x36dbd4=_0x36dbd4['rotateLeft_'](),_0x36dbd4=_0x36dbd4['colorFlip_']()),_0x36dbd4;}['moveRedRight_'](){let _0x584e62=this['colorFlip_']();return _0x584e62['left']['left']['isRed_']()&&(_0x584e62=_0x584e62['rotateRight_'](),_0x584e62=_0x584e62['colorFlip_']()),_0x584e62;}['rotateLeft_'](){const _0x4adbe3=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4adbe3,null);}['rotateRight_'](){const _0x3027ce=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x3027ce);}['colorFlip_'](){const _0x5cc9f6=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x26fa85=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5cc9f6,_0x26fa85);}['checkMaxDepth_'](){const _0x15f64d=this['check_']();return Math['pow'](0x2,_0x15f64d)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1d2631=this['left']['check_']();if(_0x1d2631!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1d2631+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x22b695,_0x509e99,_0x50b799,_0x5e9865,_0x1fb01d){return this;}['insert'](_0x1fcb02,_0x81145f,_0x2aa7ab){return new M(_0x1fcb02,_0x81145f,null);}['remove'](_0x531169,_0x54b4c0){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5d67e8){return!0x1;}['reverseTraversal'](_0x27206b){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1b6e17,_0x5b5f49=B['EMPTY_NODE']){this['comparator_']=_0x1b6e17,this['root_']=_0x5b5f49;}['insert'](_0x14584f,_0x3f10ae){return new B(this['comparator_'],this['root_']['insert'](_0x14584f,_0x3f10ae,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x14ecb2){return new B(this['comparator_'],this['root_']['remove'](_0x14ecb2,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x19f98a){let _0x5343ed,_0x510277=this['root_'];for(;!_0x510277['isEmpty']();){if(_0x5343ed=this['comparator_'](_0x19f98a,_0x510277['key']),_0x5343ed===0x0)return _0x510277['value'];_0x5343ed<0x0?_0x510277=_0x510277['left']:_0x5343ed>0x0&&(_0x510277=_0x510277['right']);}return null;}['getPredecessorKey'](_0x4f1101){let _0x592119,_0x1a4a78=this['root_'],_0x2f6fea=null;for(;!_0x1a4a78['isEmpty']();)if(_0x592119=this['comparator_'](_0x4f1101,_0x1a4a78['key']),_0x592119===0x0){if(_0x1a4a78['left']['isEmpty']())return _0x2f6fea?_0x2f6fea['key']:null;for(_0x1a4a78=_0x1a4a78['left'];!_0x1a4a78['right']['isEmpty']();)_0x1a4a78=_0x1a4a78['right'];return _0x1a4a78['key'];}else _0x592119<0x0?_0x1a4a78=_0x1a4a78['left']:_0x592119>0x0&&(_0x2f6fea=_0x1a4a78,_0x1a4a78=_0x1a4a78['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1fc7f7){return this['root_']['inorderTraversal'](_0x1fc7f7);}['reverseTraversal'](_0x46970f){return this['root_']['reverseTraversal'](_0x46970f);}['getIterator'](_0x19eb09){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x19eb09);}['getIteratorFrom'](_0xf60573,_0x534148){return new Zt(this['root_'],_0xf60573,this['comparator_'],!0x1,_0x534148);}['getReverseIteratorFrom'](_0x54b7af,_0x3890d7){return new Zt(this['root_'],_0x54b7af,this['comparator_'],!0x0,_0x3890d7);}['getReverseIterator'](_0xda635d){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0xda635d);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0xe4f893,_0x356213){return He(_0xe4f893['name'],_0x356213['name']);}function ji(_0x1a7111,_0x178a9c){return He(_0x1a7111,_0x178a9c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x13fb73){vi=_0x13fb73;}const Ro=function(_0x49dba8){return typeof _0x49dba8=='number'?'number:'+so(_0x49dba8):'string:'+_0x49dba8;},Ao=function(_0x43cb13){if(_0x43cb13['isLeafNode']()){const _0x4949c8=_0x43cb13['val']();f(typeof _0x4949c8=='string'||typeof _0x4949c8=='number'||typeof _0x4949c8=='object'&&Y(_0x4949c8,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x43cb13===vi||_0x43cb13['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x43cb13===vi||_0x43cb13['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x540200){er=_0x540200;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x20f062,_0x512bb5=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x20f062,this['priorityNode_']=_0x512bb5,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4a1e09){return new D(this['value_'],_0x4a1e09);}['getImmediateChild'](_0x470e53){return _0x470e53==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x40923c){return v(_0x40923c)?this:y(_0x40923c)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3f6be1,_0x164233){return null;}['updateImmediateChild'](_0x53af84,_0x12788c){return _0x53af84==='.priority'?this['updatePriority'](_0x12788c):_0x12788c['isEmpty']()&&_0x53af84!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x53af84,_0x12788c)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x31dd1c,_0x38a198){const _0x20976b=y(_0x31dd1c);return _0x20976b===null?_0x38a198:_0x38a198['isEmpty']()&&_0x20976b!=='.priority'?this:(f(_0x20976b!=='.priority'||we(_0x31dd1c)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x20976b,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x31dd1c),_0x38a198)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x205033,_0x51191a){return!0x1;}['val'](_0x482b76){return _0x482b76&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x228e84='';this['priorityNode_']['isEmpty']()||(_0x228e84+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x1d285c=typeof this['value_'];_0x228e84+=_0x1d285c+':',_0x1d285c==='number'?_0x228e84+=so(this['value_']):_0x228e84+=this['value_'],this['lazyHash_']=no(_0x228e84);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x46918a){return _0x46918a===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x46918a instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x46918a['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x46918a));}['compareToLeafNode_'](_0x58d660){const _0x5d21d4=typeof _0x58d660['value_'],_0xfaa258=typeof this['value_'],_0xf552ce=D['VALUE_TYPE_ORDER']['indexOf'](_0x5d21d4),_0x576abc=D['VALUE_TYPE_ORDER']['indexOf'](_0xfaa258);return f(_0xf552ce>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5d21d4),f(_0x576abc>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xfaa258),_0xf552ce===_0x576abc?_0xfaa258==='object'?0x0:this['value_']<_0x58d660['value_']?-0x1:this['value_']===_0x58d660['value_']?0x0:0x1:_0x576abc-_0xf552ce;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5739db){if(_0x5739db===this)return!0x0;if(_0x5739db['isLeafNode']()){const _0x413813=_0x5739db;return this['value_']===_0x413813['value_']&&this['priorityNode_']['equals'](_0x413813['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x4fc008){ko=_0x4fc008;}function xh(_0xac4992){No=_0xac4992;}class Fh extends On{['compare'](_0x517160,_0x3bb2be){const _0x158290=_0x517160['node']['getPriority'](),_0x469bac=_0x3bb2be['node']['getPriority'](),_0x506e52=_0x158290['compareTo'](_0x469bac);return _0x506e52===0x0?He(_0x517160['name'],_0x3bb2be['name']):_0x506e52;}['isDefinedOn'](_0x41fe4e){return!_0x41fe4e['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x418062,_0x22918b){return!_0x418062['getPriority']()['equals'](_0x22918b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x13cb67,_0x7e5955){const _0x691cfb=ko(_0x13cb67);return new E(_0x7e5955,new D('[PRIORITY-POST]',_0x691cfb));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x205b21){const _0x51219b=_0x2e242c=>parseInt(Math['log'](_0x2e242c)/Uh,0xa),_0x4cb462=_0x4309f1=>parseInt(Array(_0x4309f1+0x1)['join']('1'),0x2);this['count']=_0x51219b(_0x205b21+0x1),this['current_']=this['count']-0x1;const _0x507344=_0x4cb462(this['count']);this['bits_']=_0x205b21+0x1&_0x507344;}['nextBitIsOne'](){const _0x3c9fdb=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3c9fdb;}}const dn=function(_0x2c7b72,_0xd9a022,_0x182253,_0x57be94){_0x2c7b72['sort'](_0xd9a022);const _0x72d911=function(_0x267388,_0x78a28b){const _0x127604=_0x78a28b-_0x267388;let _0x4e6418,_0x3b31f1;if(_0x127604===0x0)return null;if(_0x127604===0x1)return _0x4e6418=_0x2c7b72[_0x267388],_0x3b31f1=_0x182253?_0x182253(_0x4e6418):_0x4e6418,new M(_0x3b31f1,_0x4e6418['node'],M['BLACK'],null,null);{const _0x1c328e=parseInt(_0x127604/0x2,0xa)+_0x267388,_0x3f26d4=_0x72d911(_0x267388,_0x1c328e),_0x4e24c0=_0x72d911(_0x1c328e+0x1,_0x78a28b);return _0x4e6418=_0x2c7b72[_0x1c328e],_0x3b31f1=_0x182253?_0x182253(_0x4e6418):_0x4e6418,new M(_0x3b31f1,_0x4e6418['node'],M['BLACK'],_0x3f26d4,_0x4e24c0);}},_0x28a044=function(_0x4b96e2){let _0x236768=null,_0xb997af=null,_0x58348a=_0x2c7b72['length'];const _0x2bef0d=function(_0x2dfe5d,_0x48ef1a){const _0x29576b=_0x58348a-_0x2dfe5d,_0x26d432=_0x58348a;_0x58348a-=_0x2dfe5d;const _0x367b3e=_0x72d911(_0x29576b+0x1,_0x26d432),_0x56952c=_0x2c7b72[_0x29576b],_0x249502=_0x182253?_0x182253(_0x56952c):_0x56952c;_0x129bcc(new M(_0x249502,_0x56952c['node'],_0x48ef1a,null,_0x367b3e));},_0x129bcc=function(_0x4aaae4){_0x236768?(_0x236768['left']=_0x4aaae4,_0x236768=_0x4aaae4):(_0xb997af=_0x4aaae4,_0x236768=_0x4aaae4);};for(let _0x49e69d=0x0;_0x49e69d<_0x4b96e2['count'];++_0x49e69d){const _0x5eedfa=_0x4b96e2['nextBitIsOne'](),_0x281499=Math['pow'](0x2,_0x4b96e2['count']-(_0x49e69d+0x1));_0x5eedfa?_0x2bef0d(_0x281499,M['BLACK']):(_0x2bef0d(_0x281499,M['BLACK']),_0x2bef0d(_0x281499,M['RED']));}return _0xb997af;},_0x344b81=new Wh(_0x2c7b72['length']),_0x5820e0=_0x28a044(_0x344b81);return new B(_0x57be94||_0xd9a022,_0x5820e0);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0xb293dc,_0x985843){this['indexes_']=_0xb293dc,this['indexSet_']=_0x985843;}['get'](_0xac1b2b){const _0x1910d5=Oe(this['indexes_'],_0xac1b2b);if(!_0x1910d5)throw new Error('No\x20index\x20defined\x20for\x20'+_0xac1b2b);return _0x1910d5 instanceof B?_0x1910d5:null;}['hasIndex'](_0x4f8d4d){return Y(this['indexSet_'],_0x4f8d4d['toString']());}['addIndex'](_0x3bff65,_0x68f6aa){f(_0x3bff65!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2a2177=[];let _0x3d3487=!0x1;const _0x2a38da=_0x68f6aa['getIterator'](E['Wrap']);let _0x796ebd=_0x2a38da['getNext']();for(;_0x796ebd;)_0x3d3487=_0x3d3487||_0x3bff65['isDefinedOn'](_0x796ebd['node']),_0x2a2177['push'](_0x796ebd),_0x796ebd=_0x2a38da['getNext']();let _0x56ddd6;_0x3d3487?_0x56ddd6=dn(_0x2a2177,_0x3bff65['getCompare']()):_0x56ddd6=je;const _0x3fefd4=_0x3bff65['toString'](),_0x210d48={...this['indexSet_']};_0x210d48[_0x3fefd4]=_0x3bff65;const _0x3e2221={...this['indexes_']};return _0x3e2221[_0x3fefd4]=_0x56ddd6,new ee(_0x3e2221,_0x210d48);}['addToIndexes'](_0x5f4f8a,_0x19d644){const _0x23bf5c=ln(this['indexes_'],(_0x358c17,_0x341a70)=>{const _0x272a23=Oe(this['indexSet_'],_0x341a70);if(f(_0x272a23,'Missing\x20index\x20implementation\x20for\x20'+_0x341a70),_0x358c17===je){if(_0x272a23['isDefinedOn'](_0x5f4f8a['node'])){const _0x2367dc=[],_0x44ad7c=_0x19d644['getIterator'](E['Wrap']);let _0x5cecb1=_0x44ad7c['getNext']();for(;_0x5cecb1;)_0x5cecb1['name']!==_0x5f4f8a['name']&&_0x2367dc['push'](_0x5cecb1),_0x5cecb1=_0x44ad7c['getNext']();return _0x2367dc['push'](_0x5f4f8a),dn(_0x2367dc,_0x272a23['getCompare']());}else return je;}else{const _0x2d4b53=_0x19d644['get'](_0x5f4f8a['name']);let _0x880a0e=_0x358c17;return _0x2d4b53&&(_0x880a0e=_0x880a0e['remove'](new E(_0x5f4f8a['name'],_0x2d4b53))),_0x880a0e['insert'](_0x5f4f8a,_0x5f4f8a['node']);}});return new ee(_0x23bf5c,this['indexSet_']);}['removeFromIndexes'](_0x3ab90c,_0x1ad830){const _0x3e08d0=ln(this['indexes_'],_0x45e779=>{if(_0x45e779===je)return _0x45e779;{const _0x3eac68=_0x1ad830['get'](_0x3ab90c['name']);return _0x3eac68?_0x45e779['remove'](new E(_0x3ab90c['name'],_0x3eac68)):_0x45e779;}});return new ee(_0x3e08d0,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x3bf45f,_0x26ad35,_0x18a406){this['children_']=_0x3bf45f,this['priorityNode_']=_0x26ad35,this['indexMap_']=_0x18a406,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x1f5f9b){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1f5f9b,this['indexMap_']);}['getImmediateChild'](_0x592826){if(_0x592826==='.priority')return this['getPriority']();{const _0x3b4aa7=this['children_']['get'](_0x592826);return _0x3b4aa7===null?gt:_0x3b4aa7;}}['getChild'](_0x842bac){const _0x43b29d=y(_0x842bac);return _0x43b29d===null?this:this['getImmediateChild'](_0x43b29d)['getChild'](b(_0x842bac));}['hasChild'](_0x29efad){return this['children_']['get'](_0x29efad)!==null;}['updateImmediateChild'](_0x327d58,_0x2fa361){if(f(_0x2fa361,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x327d58==='.priority')return this['updatePriority'](_0x2fa361);{const _0x28d6a7=new E(_0x327d58,_0x2fa361);let _0x56767c,_0x2cba1a;_0x2fa361['isEmpty']()?(_0x56767c=this['children_']['remove'](_0x327d58),_0x2cba1a=this['indexMap_']['removeFromIndexes'](_0x28d6a7,this['children_'])):(_0x56767c=this['children_']['insert'](_0x327d58,_0x2fa361),_0x2cba1a=this['indexMap_']['addToIndexes'](_0x28d6a7,this['children_']));const _0x185f6c=_0x56767c['isEmpty']()?gt:this['priorityNode_'];return new g(_0x56767c,_0x185f6c,_0x2cba1a);}}['updateChild'](_0x18ce65,_0x2d84e3){const _0x29ba9a=y(_0x18ce65);if(_0x29ba9a===null)return _0x2d84e3;{f(y(_0x18ce65)!=='.priority'||we(_0x18ce65)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x39f310=this['getImmediateChild'](_0x29ba9a)['updateChild'](b(_0x18ce65),_0x2d84e3);return this['updateImmediateChild'](_0x29ba9a,_0x39f310);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1b9815){if(this['isEmpty']())return null;const _0x394627={};let _0x5c47fc=0x0,_0xaf910=0x0,_0x22fbaf=!0x0;if(this['forEachChild'](R,(_0x4f48ad,_0x124db8)=>{_0x394627[_0x4f48ad]=_0x124db8['val'](_0x1b9815),_0x5c47fc++,_0x22fbaf&&g['INTEGER_REGEXP_']['test'](_0x4f48ad)?_0xaf910=Math['max'](_0xaf910,Number(_0x4f48ad)):_0x22fbaf=!0x1;}),!_0x1b9815&&_0x22fbaf&&_0xaf910<0x2*_0x5c47fc){const _0x572686=[];for(const _0x48a1a0 in _0x394627)_0x572686[_0x48a1a0]=_0x394627[_0x48a1a0];return _0x572686;}else return _0x1b9815&&!this['getPriority']()['isEmpty']()&&(_0x394627['.priority']=this['getPriority']()['val']()),_0x394627;}['hash'](){if(this['lazyHash_']===null){let _0x1f74db='';this['getPriority']()['isEmpty']()||(_0x1f74db+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xb107ee,_0x188a7b)=>{const _0x4d52a6=_0x188a7b['hash']();_0x4d52a6!==''&&(_0x1f74db+=':'+_0xb107ee+':'+_0x4d52a6);}),this['lazyHash_']=_0x1f74db===''?'':no(_0x1f74db);}return this['lazyHash_'];}['getPredecessorChildName'](_0x59d8d2,_0x5ec63f,_0x480842){const _0x303439=this['resolveIndex_'](_0x480842);if(_0x303439){const _0x419cb9=_0x303439['getPredecessorKey'](new E(_0x59d8d2,_0x5ec63f));return _0x419cb9?_0x419cb9['name']:null;}else return this['children_']['getPredecessorKey'](_0x59d8d2);}['getFirstChildName'](_0xa8cf2c){const _0x408d53=this['resolveIndex_'](_0xa8cf2c);if(_0x408d53){const _0x41629e=_0x408d53['minKey']();return _0x41629e&&_0x41629e['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x4af1c6){const _0x2b3a67=this['getFirstChildName'](_0x4af1c6);return _0x2b3a67?new E(_0x2b3a67,this['children_']['get'](_0x2b3a67)):null;}['getLastChildName'](_0x1e5720){const _0x2f7511=this['resolveIndex_'](_0x1e5720);if(_0x2f7511){const _0x5c48c9=_0x2f7511['maxKey']();return _0x5c48c9&&_0x5c48c9['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x300505){const _0x303655=this['getLastChildName'](_0x300505);return _0x303655?new E(_0x303655,this['children_']['get'](_0x303655)):null;}['forEachChild'](_0xefd9b8,_0x3358ba){const _0x442c1d=this['resolveIndex_'](_0xefd9b8);return _0x442c1d?_0x442c1d['inorderTraversal'](_0x5e0d6c=>_0x3358ba(_0x5e0d6c['name'],_0x5e0d6c['node'])):this['children_']['inorderTraversal'](_0x3358ba);}['getIterator'](_0x2edac7){return this['getIteratorFrom'](_0x2edac7['minPost'](),_0x2edac7);}['getIteratorFrom'](_0x141e4b,_0x5babeb){const _0x170c02=this['resolveIndex_'](_0x5babeb);if(_0x170c02)return _0x170c02['getIteratorFrom'](_0x141e4b,_0x31654c=>_0x31654c);{const _0x24818e=this['children_']['getIteratorFrom'](_0x141e4b['name'],E['Wrap']);let _0x402746=_0x24818e['peek']();for(;_0x402746!=null&&_0x5babeb['compare'](_0x402746,_0x141e4b)<0x0;)_0x24818e['getNext'](),_0x402746=_0x24818e['peek']();return _0x24818e;}}['getReverseIterator'](_0x52b9ce){return this['getReverseIteratorFrom'](_0x52b9ce['maxPost'](),_0x52b9ce);}['getReverseIteratorFrom'](_0x82805c,_0x4851ff){const _0x53d241=this['resolveIndex_'](_0x4851ff);if(_0x53d241)return _0x53d241['getReverseIteratorFrom'](_0x82805c,_0x59a346=>_0x59a346);{const _0x1c1a31=this['children_']['getReverseIteratorFrom'](_0x82805c['name'],E['Wrap']);let _0x12d890=_0x1c1a31['peek']();for(;_0x12d890!=null&&_0x4851ff['compare'](_0x12d890,_0x82805c)>0x0;)_0x1c1a31['getNext'](),_0x12d890=_0x1c1a31['peek']();return _0x1c1a31;}}['compareTo'](_0x4a02cc){return this['isEmpty']()?_0x4a02cc['isEmpty']()?0x0:-0x1:_0x4a02cc['isLeafNode']()||_0x4a02cc['isEmpty']()?0x1:_0x4a02cc===Ht?-0x1:0x0;}['withIndex'](_0x4656df){if(_0x4656df===ye||this['indexMap_']['hasIndex'](_0x4656df))return this;{const _0x1d1452=this['indexMap_']['addIndex'](_0x4656df,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1d1452);}}['isIndexed'](_0x435700){return _0x435700===ye||this['indexMap_']['hasIndex'](_0x435700);}['equals'](_0x482a7a){if(_0x482a7a===this)return!0x0;if(_0x482a7a['isLeafNode']())return!0x1;{const _0x3ac81a=_0x482a7a;if(this['getPriority']()['equals'](_0x3ac81a['getPriority']())){if(this['children_']['count']()===_0x3ac81a['children_']['count']()){const _0x17a735=this['getIterator'](R),_0x14781f=_0x3ac81a['getIterator'](R);let _0xcc10b0=_0x17a735['getNext'](),_0x2ac420=_0x14781f['getNext']();for(;_0xcc10b0&&_0x2ac420;){if(_0xcc10b0['name']!==_0x2ac420['name']||!_0xcc10b0['node']['equals'](_0x2ac420['node']))return!0x1;_0xcc10b0=_0x17a735['getNext'](),_0x2ac420=_0x14781f['getNext']();}return _0xcc10b0===null&&_0x2ac420===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xf90c3e){return _0xf90c3e===ye?null:this['indexMap_']['get'](_0xf90c3e['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x2368e8){return _0x2368e8===this?0x0:0x1;}['equals'](_0x3469f1){return _0x3469f1===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1b1bfb){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x54de1b,_0x88a35e=null){if(_0x54de1b===null)return g['EMPTY_NODE'];if(typeof _0x54de1b=='object'&&'.priority'in _0x54de1b&&(_0x88a35e=_0x54de1b['.priority']),f(_0x88a35e===null||typeof _0x88a35e=='string'||typeof _0x88a35e=='number'||typeof _0x88a35e=='object'&&'.sv'in _0x88a35e,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x88a35e),typeof _0x54de1b=='object'&&'.value'in _0x54de1b&&_0x54de1b['.value']!==null&&(_0x54de1b=_0x54de1b['.value']),typeof _0x54de1b!='object'||'.sv'in _0x54de1b){const _0x107b82=_0x54de1b;return new D(_0x107b82,N(_0x88a35e));}if(!(_0x54de1b instanceof Array)&&Vh){const _0x2d87b5=[];let _0x570806=!0x1;if(x(_0x54de1b,(_0xf6a4b9,_0x191719)=>{if(_0xf6a4b9['substring'](0x0,0x1)!=='.'){const _0x294d4e=N(_0x191719);_0x294d4e['isEmpty']()||(_0x570806=_0x570806||!_0x294d4e['getPriority']()['isEmpty'](),_0x2d87b5['push'](new E(_0xf6a4b9,_0x294d4e)));}}),_0x2d87b5['length']===0x0)return g['EMPTY_NODE'];const _0x3967b2=dn(_0x2d87b5,Dh,_0xfea5d=>_0xfea5d['name'],ji);if(_0x570806){const _0x4aa253=dn(_0x2d87b5,R['getCompare']());return new g(_0x3967b2,N(_0x88a35e),new ee({'.priority':_0x4aa253},{'.priority':R}));}else return new g(_0x3967b2,N(_0x88a35e),ee['Default']);}else{let _0x45778b=g['EMPTY_NODE'];return x(_0x54de1b,(_0x42024b,_0x564c2d)=>{if(Y(_0x54de1b,_0x42024b)&&_0x42024b['substring'](0x0,0x1)!=='.'){const _0x482df8=N(_0x564c2d);(_0x482df8['isLeafNode']()||!_0x482df8['isEmpty']())&&(_0x45778b=_0x45778b['updateImmediateChild'](_0x42024b,_0x482df8));}}),_0x45778b['updatePriority'](N(_0x88a35e));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x178574){super(),this['indexPath_']=_0x178574,f(!v(_0x178574)&&y(_0x178574)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x23025a){return _0x23025a['getChild'](this['indexPath_']);}['isDefinedOn'](_0x591351){return!_0x591351['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x1f1042,_0x166dab){const _0x4a9d17=this['extractChild'](_0x1f1042['node']),_0xd9f28a=this['extractChild'](_0x166dab['node']),_0x2704a4=_0x4a9d17['compareTo'](_0xd9f28a);return _0x2704a4===0x0?He(_0x1f1042['name'],_0x166dab['name']):_0x2704a4;}['makePost'](_0x550b,_0x44910b){const _0x59fa2b=N(_0x550b),_0x31b171=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x59fa2b);return new E(_0x44910b,_0x31b171);}['maxPost'](){const _0x458923=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x458923);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x54f609,_0x49686c){const _0x204e13=_0x54f609['node']['compareTo'](_0x49686c['node']);return _0x204e13===0x0?He(_0x54f609['name'],_0x49686c['name']):_0x204e13;}['isDefinedOn'](_0x285f9a){return!0x0;}['indexedValueChanged'](_0x340a5b,_0x222f67){return!_0x340a5b['equals'](_0x222f67);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3cf854,_0xbff221){const _0x45db1d=N(_0x3cf854);return new E(_0xbff221,_0x45db1d);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x511031){return{'type':'value','snapshotNode':_0x511031};}function tt(_0x2bda72,_0x422f79){return{'type':'child_added','snapshotNode':_0x422f79,'childName':_0x2bda72};}function Nt(_0x203701,_0x56218e){return{'type':'child_removed','snapshotNode':_0x56218e,'childName':_0x203701};}function Pt(_0xfc8b72,_0x2b05e7,_0x406724){return{'type':'child_changed','snapshotNode':_0x2b05e7,'childName':_0xfc8b72,'oldSnap':_0x406724};}function $h(_0xefe1a9,_0x129441){return{'type':'child_moved','snapshotNode':_0x129441,'childName':_0xefe1a9};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x2f4074){this['index_']=_0x2f4074;}['updateChild'](_0x49db97,_0x3278e9,_0x30aeee,_0x2934b6,_0xd1de54,_0x59c368){f(_0x49db97['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x51f15d=_0x49db97['getImmediateChild'](_0x3278e9);return _0x51f15d['getChild'](_0x2934b6)['equals'](_0x30aeee['getChild'](_0x2934b6))&&_0x51f15d['isEmpty']()===_0x30aeee['isEmpty']()||(_0x59c368!=null&&(_0x30aeee['isEmpty']()?_0x49db97['hasChild'](_0x3278e9)?_0x59c368['trackChildChange'](Nt(_0x3278e9,_0x51f15d)):f(_0x49db97['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x51f15d['isEmpty']()?_0x59c368['trackChildChange'](tt(_0x3278e9,_0x30aeee)):_0x59c368['trackChildChange'](Pt(_0x3278e9,_0x30aeee,_0x51f15d))),_0x49db97['isLeafNode']()&&_0x30aeee['isEmpty']())?_0x49db97:_0x49db97['updateImmediateChild'](_0x3278e9,_0x30aeee)['withIndex'](this['index_']);}['updateFullNode'](_0xaca86c,_0x4ed872,_0x4ef361){return _0x4ef361!=null&&(_0xaca86c['isLeafNode']()||_0xaca86c['forEachChild'](R,(_0x46e61a,_0x204297)=>{_0x4ed872['hasChild'](_0x46e61a)||_0x4ef361['trackChildChange'](Nt(_0x46e61a,_0x204297));}),_0x4ed872['isLeafNode']()||_0x4ed872['forEachChild'](R,(_0x3670cd,_0x32e780)=>{if(_0xaca86c['hasChild'](_0x3670cd)){const _0x4d9bbc=_0xaca86c['getImmediateChild'](_0x3670cd);_0x4d9bbc['equals'](_0x32e780)||_0x4ef361['trackChildChange'](Pt(_0x3670cd,_0x32e780,_0x4d9bbc));}else _0x4ef361['trackChildChange'](tt(_0x3670cd,_0x32e780));})),_0x4ed872['withIndex'](this['index_']);}['updatePriority'](_0x38daac,_0x4eb229){return _0x38daac['isEmpty']()?g['EMPTY_NODE']:_0x38daac['updatePriority'](_0x4eb229);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x1e7f32){this['indexedFilter_']=new Yi(_0x1e7f32['getIndex']()),this['index_']=_0x1e7f32['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x1e7f32),this['endPost_']=Ot['getEndPost_'](_0x1e7f32),this['startIsInclusive_']=!_0x1e7f32['startAfterSet_'],this['endIsInclusive_']=!_0x1e7f32['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5150a8){const _0x211685=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5150a8)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5150a8)<0x0,_0x1fef6b=this['endIsInclusive_']?this['index_']['compare'](_0x5150a8,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5150a8,this['getEndPost']())<0x0;return _0x211685&&_0x1fef6b;}['updateChild'](_0x472554,_0x35d94f,_0x1868bd,_0x1e0eb8,_0x48ec36,_0x5f1844){return this['matches'](new E(_0x35d94f,_0x1868bd))||(_0x1868bd=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x472554,_0x35d94f,_0x1868bd,_0x1e0eb8,_0x48ec36,_0x5f1844);}['updateFullNode'](_0x4d44ad,_0xafb2be,_0x4f6d65){_0xafb2be['isLeafNode']()&&(_0xafb2be=g['EMPTY_NODE']);let _0x380f71=_0xafb2be['withIndex'](this['index_']);_0x380f71=_0x380f71['updatePriority'](g['EMPTY_NODE']);const _0x26f9e4=this;return _0xafb2be['forEachChild'](R,(_0x1442db,_0xf99046)=>{_0x26f9e4['matches'](new E(_0x1442db,_0xf99046))||(_0x380f71=_0x380f71['updateImmediateChild'](_0x1442db,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x4d44ad,_0x380f71,_0x4f6d65);}['updatePriority'](_0x5b8d5e,_0x35e024){return _0x5b8d5e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x55efac){if(_0x55efac['hasStart']()){const _0x1b2a66=_0x55efac['getIndexStartName']();return _0x55efac['getIndex']()['makePost'](_0x55efac['getIndexStartValue'](),_0x1b2a66);}else return _0x55efac['getIndex']()['minPost']();}static['getEndPost_'](_0x77ccd6){if(_0x77ccd6['hasEnd']()){const _0x19e07b=_0x77ccd6['getIndexEndName']();return _0x77ccd6['getIndex']()['makePost'](_0x77ccd6['getIndexEndValue'](),_0x19e07b);}else return _0x77ccd6['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x2b64e9){this['withinDirectionalStart']=_0x5b1ef7=>this['reverse_']?this['withinEndPost'](_0x5b1ef7):this['withinStartPost'](_0x5b1ef7),this['withinDirectionalEnd']=_0x1f556b=>this['reverse_']?this['withinStartPost'](_0x1f556b):this['withinEndPost'](_0x1f556b),this['withinStartPost']=_0x3058d8=>{const _0x30b09f=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x3058d8);return this['startIsInclusive_']?_0x30b09f<=0x0:_0x30b09f<0x0;},this['withinEndPost']=_0x1ba18d=>{const _0x557fc5=this['index_']['compare'](_0x1ba18d,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x557fc5<=0x0:_0x557fc5<0x0;},this['rangedFilter_']=new Ot(_0x2b64e9),this['index_']=_0x2b64e9['getIndex'](),this['limit_']=_0x2b64e9['getLimit'](),this['reverse_']=!_0x2b64e9['isViewFromLeft'](),this['startIsInclusive_']=!_0x2b64e9['startAfterSet_'],this['endIsInclusive_']=!_0x2b64e9['endBeforeSet_'];}['updateChild'](_0x51c73f,_0x355141,_0x7e9233,_0x519501,_0x35f8ec,_0x2587df){return this['rangedFilter_']['matches'](new E(_0x355141,_0x7e9233))||(_0x7e9233=g['EMPTY_NODE']),_0x51c73f['getImmediateChild'](_0x355141)['equals'](_0x7e9233)?_0x51c73f:_0x51c73f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x51c73f,_0x355141,_0x7e9233,_0x519501,_0x35f8ec,_0x2587df):this['fullLimitUpdateChild_'](_0x51c73f,_0x355141,_0x7e9233,_0x35f8ec,_0x2587df);}['updateFullNode'](_0x308c24,_0x451be3,_0x5667eb){let _0x8e10e6;if(_0x451be3['isLeafNode']()||_0x451be3['isEmpty']())_0x8e10e6=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x451be3['numChildren']()&&_0x451be3['isIndexed'](this['index_'])){_0x8e10e6=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4b346a;this['reverse_']?_0x4b346a=_0x451be3['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4b346a=_0x451be3['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x39c477=0x0;for(;_0x4b346a['hasNext']()&&_0x39c477<this['limit_'];){const _0x22133e=_0x4b346a['getNext']();if(this['withinDirectionalStart'](_0x22133e)){if(this['withinDirectionalEnd'](_0x22133e))_0x8e10e6=_0x8e10e6['updateImmediateChild'](_0x22133e['name'],_0x22133e['node']),_0x39c477++;else break;}else continue;}}else{_0x8e10e6=_0x451be3['withIndex'](this['index_']),_0x8e10e6=_0x8e10e6['updatePriority'](g['EMPTY_NODE']);let _0x54a276;this['reverse_']?_0x54a276=_0x8e10e6['getReverseIterator'](this['index_']):_0x54a276=_0x8e10e6['getIterator'](this['index_']);let _0x5d6e7b=0x0;for(;_0x54a276['hasNext']();){const _0x489adb=_0x54a276['getNext']();_0x5d6e7b<this['limit_']&&this['withinDirectionalStart'](_0x489adb)&&this['withinDirectionalEnd'](_0x489adb)?_0x5d6e7b++:_0x8e10e6=_0x8e10e6['updateImmediateChild'](_0x489adb['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x308c24,_0x8e10e6,_0x5667eb);}['updatePriority'](_0x23466d,_0x4c853c){return _0x23466d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2b2834,_0x4d26dd,_0x292184,_0x78d765,_0x4451ff){let _0x15e733;if(this['reverse_']){const _0x38d0ca=this['index_']['getCompare']();_0x15e733=(_0x4d9405,_0x206d30)=>_0x38d0ca(_0x206d30,_0x4d9405);}else _0x15e733=this['index_']['getCompare']();const _0x722c51=_0x2b2834;f(_0x722c51['numChildren']()===this['limit_'],'');const _0x5b5e27=new E(_0x4d26dd,_0x292184),_0x32fc00=this['reverse_']?_0x722c51['getFirstChild'](this['index_']):_0x722c51['getLastChild'](this['index_']),_0x6500c8=this['rangedFilter_']['matches'](_0x5b5e27);if(_0x722c51['hasChild'](_0x4d26dd)){const _0x51e658=_0x722c51['getImmediateChild'](_0x4d26dd);let _0x23aa7e=_0x78d765['getChildAfterChild'](this['index_'],_0x32fc00,this['reverse_']);for(;_0x23aa7e!=null&&(_0x23aa7e['name']===_0x4d26dd||_0x722c51['hasChild'](_0x23aa7e['name']));)_0x23aa7e=_0x78d765['getChildAfterChild'](this['index_'],_0x23aa7e,this['reverse_']);const _0x9e170b=_0x23aa7e==null?0x1:_0x15e733(_0x23aa7e,_0x5b5e27);if(_0x6500c8&&!_0x292184['isEmpty']()&&_0x9e170b>=0x0)return _0x4451ff!=null&&_0x4451ff['trackChildChange'](Pt(_0x4d26dd,_0x292184,_0x51e658)),_0x722c51['updateImmediateChild'](_0x4d26dd,_0x292184);{_0x4451ff!=null&&_0x4451ff['trackChildChange'](Nt(_0x4d26dd,_0x51e658));const _0x370503=_0x722c51['updateImmediateChild'](_0x4d26dd,g['EMPTY_NODE']);return _0x23aa7e!=null&&this['rangedFilter_']['matches'](_0x23aa7e)?(_0x4451ff!=null&&_0x4451ff['trackChildChange'](tt(_0x23aa7e['name'],_0x23aa7e['node'])),_0x370503['updateImmediateChild'](_0x23aa7e['name'],_0x23aa7e['node'])):_0x370503;}}else return _0x292184['isEmpty']()?_0x2b2834:_0x6500c8&&_0x15e733(_0x32fc00,_0x5b5e27)>=0x0?(_0x4451ff!=null&&(_0x4451ff['trackChildChange'](Nt(_0x32fc00['name'],_0x32fc00['node'])),_0x4451ff['trackChildChange'](tt(_0x4d26dd,_0x292184))),_0x722c51['updateImmediateChild'](_0x4d26dd,_0x292184)['updateImmediateChild'](_0x32fc00['name'],g['EMPTY_NODE'])):_0x2b2834;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x48bc76=new Qi();return _0x48bc76['limitSet_']=this['limitSet_'],_0x48bc76['limit_']=this['limit_'],_0x48bc76['startSet_']=this['startSet_'],_0x48bc76['startAfterSet_']=this['startAfterSet_'],_0x48bc76['indexStartValue_']=this['indexStartValue_'],_0x48bc76['startNameSet_']=this['startNameSet_'],_0x48bc76['indexStartName_']=this['indexStartName_'],_0x48bc76['endSet_']=this['endSet_'],_0x48bc76['endBeforeSet_']=this['endBeforeSet_'],_0x48bc76['indexEndValue_']=this['indexEndValue_'],_0x48bc76['endNameSet_']=this['endNameSet_'],_0x48bc76['indexEndName_']=this['indexEndName_'],_0x48bc76['index_']=this['index_'],_0x48bc76['viewFrom_']=this['viewFrom_'],_0x48bc76;}}function qh(_0x5182ce){return _0x5182ce['loadsAllData']()?new Yi(_0x5182ce['getIndex']()):_0x5182ce['hasLimit']()?new Gh(_0x5182ce):new Ot(_0x5182ce);}function zh(_0x35b126,_0xf308d6){const _0x589640=_0x35b126['copy']();return _0x589640['limitSet_']=!0x0,_0x589640['limit_']=_0xf308d6,_0x589640['viewFrom_']='l',_0x589640;}function jh(_0x5080e2,_0x5a3f17,_0x5ede46){const _0x59c519=_0x5080e2['copy']();return _0x59c519['startSet_']=!0x0,_0x5a3f17===void 0x0&&(_0x5a3f17=null),_0x59c519['indexStartValue_']=_0x5a3f17,_0x5ede46!=null?(_0x59c519['startNameSet_']=!0x0,_0x59c519['indexStartName_']=_0x5ede46):(_0x59c519['startNameSet_']=!0x1,_0x59c519['indexStartName_']=''),_0x59c519;}function Kh(_0x1a3515,_0x45e803,_0x326ab3){const _0x187836=_0x1a3515['copy']();return _0x187836['endSet_']=!0x0,_0x45e803===void 0x0&&(_0x45e803=null),_0x187836['indexEndValue_']=_0x45e803,_0x326ab3!==void 0x0?(_0x187836['endNameSet_']=!0x0,_0x187836['indexEndName_']=_0x326ab3):(_0x187836['endNameSet_']=!0x1,_0x187836['indexEndName_']=''),_0x187836;}function Do(_0x5d1475,_0x42cb45){const _0x1d8306=_0x5d1475['copy']();return _0x1d8306['index_']=_0x42cb45,_0x1d8306;}function tr(_0x135db7){const _0x1cd5a0={};if(_0x135db7['isDefault']())return _0x1cd5a0;let _0x541a6e;if(_0x135db7['index_']===R?_0x541a6e='$priority':_0x135db7['index_']===Po?_0x541a6e='$value':_0x135db7['index_']===ye?_0x541a6e='$key':(f(_0x135db7['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x541a6e=_0x135db7['index_']['toString']()),_0x1cd5a0['orderBy']=O(_0x541a6e),_0x135db7['startSet_']){const _0x544f99=_0x135db7['startAfterSet_']?'startAfter':'startAt';_0x1cd5a0[_0x544f99]=O(_0x135db7['indexStartValue_']),_0x135db7['startNameSet_']&&(_0x1cd5a0[_0x544f99]+=','+O(_0x135db7['indexStartName_']));}if(_0x135db7['endSet_']){const _0x49cb02=_0x135db7['endBeforeSet_']?'endBefore':'endAt';_0x1cd5a0[_0x49cb02]=O(_0x135db7['indexEndValue_']),_0x135db7['endNameSet_']&&(_0x1cd5a0[_0x49cb02]+=','+O(_0x135db7['indexEndName_']));}return _0x135db7['limitSet_']&&(_0x135db7['isViewFromLeft']()?_0x1cd5a0['limitToFirst']=_0x135db7['limit_']:_0x1cd5a0['limitToLast']=_0x135db7['limit_']),_0x1cd5a0;}function nr(_0x5a8925){const _0x2656e6={};if(_0x5a8925['startSet_']&&(_0x2656e6['sp']=_0x5a8925['indexStartValue_'],_0x5a8925['startNameSet_']&&(_0x2656e6['sn']=_0x5a8925['indexStartName_']),_0x2656e6['sin']=!_0x5a8925['startAfterSet_']),_0x5a8925['endSet_']&&(_0x2656e6['ep']=_0x5a8925['indexEndValue_'],_0x5a8925['endNameSet_']&&(_0x2656e6['en']=_0x5a8925['indexEndName_']),_0x2656e6['ein']=!_0x5a8925['endBeforeSet_']),_0x5a8925['limitSet_']){_0x2656e6['l']=_0x5a8925['limit_'];let _0x9c5a1d=_0x5a8925['viewFrom_'];_0x9c5a1d===''&&(_0x5a8925['isViewFromLeft']()?_0x9c5a1d='l':_0x9c5a1d='r'),_0x2656e6['vf']=_0x9c5a1d;}return _0x5a8925['index_']!==R&&(_0x2656e6['i']=_0x5a8925['index_']['toString']()),_0x2656e6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0xa99a88){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x7ecd08,_0x385756){return _0x385756!==void 0x0?'tag$'+_0x385756:(f(_0x7ecd08['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x7ecd08['_path']['toString']());}constructor(_0x140160,_0x2d11ea,_0x19c5da,_0x57cd96){super(),this['repoInfo_']=_0x140160,this['onDataUpdate_']=_0x2d11ea,this['authTokenProvider_']=_0x19c5da,this['appCheckTokenProvider_']=_0x57cd96,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x5ce3c6,_0x3e45af,_0x11ecc5,_0x22b130){const _0x1485be=_0x5ce3c6['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1485be+'\x20'+_0x5ce3c6['_queryIdentifier']);const _0x28bbe1=fn['getListenId_'](_0x5ce3c6,_0x11ecc5),_0x3cc865={};this['listens_'][_0x28bbe1]=_0x3cc865;const _0x4da542=tr(_0x5ce3c6['_queryParams']);this['restRequest_'](_0x1485be+'.json',_0x4da542,(_0x583278,_0x8ac94d)=>{let _0x362371=_0x8ac94d;if(_0x583278===0x194&&(_0x362371=null,_0x583278=null),_0x583278===null&&this['onDataUpdate_'](_0x1485be,_0x362371,!0x1,_0x11ecc5),Oe(this['listens_'],_0x28bbe1)===_0x3cc865){let _0x22af7b;_0x583278?_0x583278===0x191?_0x22af7b='permission_denied':_0x22af7b='rest_error:'+_0x583278:_0x22af7b='ok',_0x22b130(_0x22af7b,null);}});}['unlisten'](_0x93e3ac,_0xc9f710){const _0x507b99=fn['getListenId_'](_0x93e3ac,_0xc9f710);delete this['listens_'][_0x507b99];}['get'](_0x34b5b9){const _0x9a7bf9=tr(_0x34b5b9['_queryParams']),_0x1ba938=_0x34b5b9['_path']['toString'](),_0x21aa4d=new Ve();return this['restRequest_'](_0x1ba938+'.json',_0x9a7bf9,(_0x2544d1,_0x96454a)=>{let _0xae33b1=_0x96454a;_0x2544d1===0x194&&(_0xae33b1=null,_0x2544d1=null),_0x2544d1===null?(this['onDataUpdate_'](_0x1ba938,_0xae33b1,!0x1,null),_0x21aa4d['resolve'](_0xae33b1)):_0x21aa4d['reject'](new Error(_0xae33b1));}),_0x21aa4d['promise'];}['refreshAuthToken'](_0x4333f6){}['restRequest_'](_0x9d722a,_0x3a94d2={},_0x3d117a){return _0x3a94d2['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x13e884,_0x5bee47])=>{_0x13e884&&_0x13e884['accessToken']&&(_0x3a94d2['auth']=_0x13e884['accessToken']),_0x5bee47&&_0x5bee47['token']&&(_0x3a94d2['ac']=_0x5bee47['token']);const _0xa2215a=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x9d722a+'?ns='+this['repoInfo_']['namespace']+at(_0x3a94d2);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xa2215a);const _0x55c8f1=new XMLHttpRequest();_0x55c8f1['onreadystatechange']=()=>{if(_0x3d117a&&_0x55c8f1['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xa2215a+'\x20received.\x20status:',_0x55c8f1['status'],'response:',_0x55c8f1['responseText']);let _0x233146=null;if(_0x55c8f1['status']>=0xc8&&_0x55c8f1['status']<0x12c){try{_0x233146=bt(_0x55c8f1['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xa2215a+':\x20'+_0x55c8f1['responseText']);}_0x3d117a(null,_0x233146);}else _0x55c8f1['status']!==0x191&&_0x55c8f1['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xa2215a+'\x20Status:\x20'+_0x55c8f1['status']),_0x3d117a(_0x55c8f1['status']);_0x3d117a=null;}},_0x55c8f1['open']('GET',_0xa2215a,!0x0),_0x55c8f1['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0xda9da6){return this['rootNode_']['getChild'](_0xda9da6);}['updateSnapshot'](_0x42d4e5,_0x3ab9ce){this['rootNode_']=this['rootNode_']['updateChild'](_0x42d4e5,_0x3ab9ce);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x183481,_0x2b611a,_0xede9d6){if(v(_0x2b611a))_0x183481['value']=_0xede9d6,_0x183481['children']['clear']();else{if(_0x183481['value']!==null)_0x183481['value']=_0x183481['value']['updateChild'](_0x2b611a,_0xede9d6);else{const _0x51dbea=y(_0x2b611a);_0x183481['children']['has'](_0x51dbea)||_0x183481['children']['set'](_0x51dbea,pn());const _0x376f2e=_0x183481['children']['get'](_0x51dbea);_0x2b611a=b(_0x2b611a),Mo(_0x376f2e,_0x2b611a,_0xede9d6);}}}function Ei(_0x2b46d9,_0x142f11,_0xc52621){_0x2b46d9['value']!==null?_0xc52621(_0x142f11,_0x2b46d9['value']):Qh(_0x2b46d9,(_0x57f5a2,_0x1ca0d7)=>{const _0x2fc867=new C(_0x142f11['toString']()+'/'+_0x57f5a2);Ei(_0x1ca0d7,_0x2fc867,_0xc52621);});}function Qh(_0x2a9ade,_0x2cf3be){_0x2a9ade['children']['forEach']((_0x39a019,_0x3628d8)=>{_0x2cf3be(_0x3628d8,_0x39a019);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x21e625){this['collection_']=_0x21e625,this['last_']=null;}['get'](){const _0xeb9468=this['collection_']['get'](),_0x5184e6={..._0xeb9468};return this['last_']&&x(this['last_'],(_0x16ce6e,_0x80dbb6)=>{_0x5184e6[_0x16ce6e]=_0x5184e6[_0x16ce6e]-_0x80dbb6;}),this['last_']=_0xeb9468,_0x5184e6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x5a0b6c,_0x33bbbc){this['server_']=_0x33bbbc,this['statsToReport_']={},this['statsListener_']=new Jh(_0x5a0b6c);const _0x7868db=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x7868db));}['reportStats_'](){const _0x3cd9aa=this['statsListener_']['get'](),_0x3bbdda={};let _0xfd1136=!0x1;x(_0x3cd9aa,(_0x56f7a5,_0x56c9c5)=>{_0x56c9c5>0x0&&Y(this['statsToReport_'],_0x56f7a5)&&(_0x3bbdda[_0x56f7a5]=_0x56c9c5,_0xfd1136=!0x0);}),_0xfd1136&&this['server_']['reportStats'](_0x3bbdda),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x37051b){_0x37051b[_0x37051b['OVERWRITE']=0x0]='OVERWRITE',_0x37051b[_0x37051b['MERGE']=0x1]='MERGE',_0x37051b[_0x37051b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x37051b[_0x37051b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x4d471f){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4d471f,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x96d645,_0xf37d79,_0x43fdf2){this['path']=_0x96d645,this['affectedTree']=_0xf37d79,this['revert']=_0x43fdf2,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0xed3e5c){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x50ed39=this['affectedTree']['subtree'](new C(_0xed3e5c));return new _n(w(),_0x50ed39,this['revert']);}}else return f(y(this['path'])===_0xed3e5c,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x3c0146,_0x26686c){this['source']=_0x3c0146,this['path']=_0x26686c,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x5483b1){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x17aad1,_0x39fb49,_0x40d680){this['source']=_0x17aad1,this['path']=_0x39fb49,this['snap']=_0x40d680,this['type']=q['OVERWRITE'];}['operationForChild'](_0x484d76){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x484d76)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0xe47850,_0x5f52c9,_0x1d990f){this['source']=_0xe47850,this['path']=_0x5f52c9,this['children']=_0x1d990f,this['type']=q['MERGE'];}['operationForChild'](_0xfbbc48){if(v(this['path'])){const _0xe2070a=this['children']['subtree'](new C(_0xfbbc48));return _0xe2070a['isEmpty']()?null:_0xe2070a['value']?new Fe(this['source'],w(),_0xe2070a['value']):new nt(this['source'],w(),_0xe2070a);}else return f(y(this['path'])===_0xfbbc48,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0xb994bd,_0x397cf4,_0x32a2af){this['node_']=_0xb994bd,this['fullyInitialized_']=_0x397cf4,this['filtered_']=_0x32a2af;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x5f7bb8){if(v(_0x5f7bb8))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3f2960=y(_0x5f7bb8);return this['isCompleteForChild'](_0x3f2960);}['isCompleteForChild'](_0x3c98a7){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3c98a7);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0xcc0cec){this['query_']=_0xcc0cec,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x4897c2,_0x45d304,_0x5836f4,_0x117903){const _0x41bfcd=[],_0x3e37b0=[];return _0x45d304['forEach'](_0x25ea65=>{_0x25ea65['type']==='child_changed'&&_0x4897c2['index_']['indexedValueChanged'](_0x25ea65['oldSnap'],_0x25ea65['snapshotNode'])&&_0x3e37b0['push']($h(_0x25ea65['childName'],_0x25ea65['snapshotNode']));}),mt(_0x4897c2,_0x41bfcd,'child_removed',_0x45d304,_0x117903,_0x5836f4),mt(_0x4897c2,_0x41bfcd,'child_added',_0x45d304,_0x117903,_0x5836f4),mt(_0x4897c2,_0x41bfcd,'child_moved',_0x3e37b0,_0x117903,_0x5836f4),mt(_0x4897c2,_0x41bfcd,'child_changed',_0x45d304,_0x117903,_0x5836f4),mt(_0x4897c2,_0x41bfcd,'value',_0x45d304,_0x117903,_0x5836f4),_0x41bfcd;}function mt(_0x694ef4,_0x4d688f,_0x35d0d7,_0x5a9891,_0x57a8d9,_0x5a62eb){const _0x3ff6b9=_0x5a9891['filter'](_0x4c80de=>_0x4c80de['type']===_0x35d0d7);_0x3ff6b9['sort']((_0x3b7b9e,_0x3a1053)=>su(_0x694ef4,_0x3b7b9e,_0x3a1053)),_0x3ff6b9['forEach'](_0x5e9628=>{const _0x3341f0=iu(_0x694ef4,_0x5e9628,_0x5a62eb);_0x57a8d9['forEach'](_0x553f46=>{_0x553f46['respondsTo'](_0x5e9628['type'])&&_0x4d688f['push'](_0x553f46['createEvent'](_0x3341f0,_0x694ef4['query_']));});});}function iu(_0x3c3146,_0x47beaf,_0x4d9e11){return _0x47beaf['type']==='value'||_0x47beaf['type']==='child_removed'||(_0x47beaf['prevName']=_0x4d9e11['getPredecessorChildName'](_0x47beaf['childName'],_0x47beaf['snapshotNode'],_0x3c3146['index_'])),_0x47beaf;}function su(_0x74dd12,_0x3f1081,_0x3cf065){if(_0x3f1081['childName']==null||_0x3cf065['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x3f62a0=new E(_0x3f1081['childName'],_0x3f1081['snapshotNode']),_0x5aeee6=new E(_0x3cf065['childName'],_0x3cf065['snapshotNode']);return _0x74dd12['index_']['compare'](_0x3f62a0,_0x5aeee6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x25e7ed,_0x481eda){return{'eventCache':_0x25e7ed,'serverCache':_0x481eda};}function wt(_0x19f698,_0x16ba99,_0x4f3832,_0x5be80f){return Dn(new Ce(_0x16ba99,_0x4f3832,_0x5be80f),_0x19f698['serverCache']);}function Lo(_0x11b314,_0x3abae4,_0x3a1498,_0xd218d1){return Dn(_0x11b314['eventCache'],new Ce(_0x3abae4,_0x3a1498,_0xd218d1));}function gn(_0x1f0c5a){return _0x1f0c5a['eventCache']['isFullyInitialized']()?_0x1f0c5a['eventCache']['getNode']():null;}function Ue(_0x469d09){return _0x469d09['serverCache']['isFullyInitialized']()?_0x469d09['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x18688b){let _0x428de5=new S(null);return x(_0x18688b,(_0x2c3b9c,_0x1e08d6)=>{_0x428de5=_0x428de5['set'](new C(_0x2c3b9c),_0x1e08d6);}),_0x428de5;}constructor(_0x291609,_0x3e8122=ru()){this['value']=_0x291609,this['children']=_0x3e8122;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x55ea3f,_0x282005){if(this['value']!=null&&_0x282005(this['value']))return{'path':w(),'value':this['value']};if(v(_0x55ea3f))return null;{const _0xf880bf=y(_0x55ea3f),_0x589937=this['children']['get'](_0xf880bf);if(_0x589937!==null){const _0x2c1607=_0x589937['findRootMostMatchingPathAndValue'](b(_0x55ea3f),_0x282005);return _0x2c1607!=null?{'path':A(new C(_0xf880bf),_0x2c1607['path']),'value':_0x2c1607['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x235191){return this['findRootMostMatchingPathAndValue'](_0x235191,()=>!0x0);}['subtree'](_0x475e68){if(v(_0x475e68))return this;{const _0x23d6db=y(_0x475e68),_0x2010c8=this['children']['get'](_0x23d6db);return _0x2010c8!==null?_0x2010c8['subtree'](b(_0x475e68)):new S(null);}}['set'](_0x13f2fe,_0x1c4de4){if(v(_0x13f2fe))return new S(_0x1c4de4,this['children']);{const _0x4e9f19=y(_0x13f2fe),_0x33025d=(this['children']['get'](_0x4e9f19)||new S(null))['set'](b(_0x13f2fe),_0x1c4de4),_0x39ec34=this['children']['insert'](_0x4e9f19,_0x33025d);return new S(this['value'],_0x39ec34);}}['remove'](_0x488c07){if(v(_0x488c07))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0xaa6535=y(_0x488c07),_0x2f7460=this['children']['get'](_0xaa6535);if(_0x2f7460){const _0x3d1bbf=_0x2f7460['remove'](b(_0x488c07));let _0xe33a86;return _0x3d1bbf['isEmpty']()?_0xe33a86=this['children']['remove'](_0xaa6535):_0xe33a86=this['children']['insert'](_0xaa6535,_0x3d1bbf),this['value']===null&&_0xe33a86['isEmpty']()?new S(null):new S(this['value'],_0xe33a86);}else return this;}}['get'](_0x4cb7ca){if(v(_0x4cb7ca))return this['value'];{const _0x2a34a7=y(_0x4cb7ca),_0x5db248=this['children']['get'](_0x2a34a7);return _0x5db248?_0x5db248['get'](b(_0x4cb7ca)):null;}}['setTree'](_0x266703,_0x30da8e){if(v(_0x266703))return _0x30da8e;{const _0x31b8ff=y(_0x266703),_0x29b97b=(this['children']['get'](_0x31b8ff)||new S(null))['setTree'](b(_0x266703),_0x30da8e);let _0xe47882;return _0x29b97b['isEmpty']()?_0xe47882=this['children']['remove'](_0x31b8ff):_0xe47882=this['children']['insert'](_0x31b8ff,_0x29b97b),new S(this['value'],_0xe47882);}}['fold'](_0x12ecca){return this['fold_'](w(),_0x12ecca);}['fold_'](_0x5d1347,_0x4728d0){const _0x4ddfb1={};return this['children']['inorderTraversal']((_0x5dd63b,_0x29cc9f)=>{_0x4ddfb1[_0x5dd63b]=_0x29cc9f['fold_'](A(_0x5d1347,_0x5dd63b),_0x4728d0);}),_0x4728d0(_0x5d1347,this['value'],_0x4ddfb1);}['findOnPath'](_0x52dfdc,_0x125330){return this['findOnPath_'](_0x52dfdc,w(),_0x125330);}['findOnPath_'](_0x44498c,_0x2640a2,_0x48f3dd){const _0x51d7ba=this['value']?_0x48f3dd(_0x2640a2,this['value']):!0x1;if(_0x51d7ba)return _0x51d7ba;if(v(_0x44498c))return null;{const _0x544fcf=y(_0x44498c),_0x107192=this['children']['get'](_0x544fcf);return _0x107192?_0x107192['findOnPath_'](b(_0x44498c),A(_0x2640a2,_0x544fcf),_0x48f3dd):null;}}['foreachOnPath'](_0x20f1d8,_0x246bec){return this['foreachOnPath_'](_0x20f1d8,w(),_0x246bec);}['foreachOnPath_'](_0x121025,_0x37cda4,_0x1a80ff){if(v(_0x121025))return this;{this['value']&&_0x1a80ff(_0x37cda4,this['value']);const _0x1404a8=y(_0x121025),_0x4814a0=this['children']['get'](_0x1404a8);return _0x4814a0?_0x4814a0['foreachOnPath_'](b(_0x121025),A(_0x37cda4,_0x1404a8),_0x1a80ff):new S(null);}}['foreach'](_0x19352a){this['foreach_'](w(),_0x19352a);}['foreach_'](_0x3a23a3,_0x38172d){this['children']['inorderTraversal']((_0xb57ad8,_0x16e070)=>{_0x16e070['foreach_'](A(_0x3a23a3,_0xb57ad8),_0x38172d);}),this['value']&&_0x38172d(_0x3a23a3,this['value']);}['foreachChild'](_0x45c6a7){this['children']['inorderTraversal']((_0x153acc,_0x2c7e9b)=>{_0x2c7e9b['value']&&_0x45c6a7(_0x153acc,_0x2c7e9b['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x326a3f){this['writeTree_']=_0x326a3f;}static['empty'](){return new j(new S(null));}}function Ct(_0x3d8ad4,_0x4416c2,_0x327ac1){if(v(_0x4416c2))return new j(new S(_0x327ac1));{const _0x3eb1a4=_0x3d8ad4['writeTree_']['findRootMostValueAndPath'](_0x4416c2);if(_0x3eb1a4!=null){const _0x54c72b=_0x3eb1a4['path'];let _0x2c31f6=_0x3eb1a4['value'];const _0xf1ffaf=F(_0x54c72b,_0x4416c2);return _0x2c31f6=_0x2c31f6['updateChild'](_0xf1ffaf,_0x327ac1),new j(_0x3d8ad4['writeTree_']['set'](_0x54c72b,_0x2c31f6));}else{const _0x142f3b=new S(_0x327ac1),_0xb736ca=_0x3d8ad4['writeTree_']['setTree'](_0x4416c2,_0x142f3b);return new j(_0xb736ca);}}}function Ii(_0x522646,_0x2b1d47,_0x32313a){let _0x5aa754=_0x522646;return x(_0x32313a,(_0x1e766d,_0x128b7d)=>{_0x5aa754=Ct(_0x5aa754,A(_0x2b1d47,_0x1e766d),_0x128b7d);}),_0x5aa754;}function sr(_0x354209,_0x46f01f){if(v(_0x46f01f))return j['empty']();{const _0x402583=_0x354209['writeTree_']['setTree'](_0x46f01f,new S(null));return new j(_0x402583);}}function wi(_0x493671,_0x50a920){return $e(_0x493671,_0x50a920)!=null;}function $e(_0x465cbc,_0x278ba0){const _0x411c1b=_0x465cbc['writeTree_']['findRootMostValueAndPath'](_0x278ba0);return _0x411c1b!=null?_0x465cbc['writeTree_']['get'](_0x411c1b['path'])['getChild'](F(_0x411c1b['path'],_0x278ba0)):null;}function rr(_0x1a8c0c){const _0x3c6251=[],_0x554262=_0x1a8c0c['writeTree_']['value'];return _0x554262!=null?_0x554262['isLeafNode']()||_0x554262['forEachChild'](R,(_0x226280,_0x51560e)=>{_0x3c6251['push'](new E(_0x226280,_0x51560e));}):_0x1a8c0c['writeTree_']['children']['inorderTraversal']((_0x49dcbc,_0x347969)=>{_0x347969['value']!=null&&_0x3c6251['push'](new E(_0x49dcbc,_0x347969['value']));}),_0x3c6251;}function ve(_0x5c947a,_0x1eb5bc){if(v(_0x1eb5bc))return _0x5c947a;{const _0x578994=$e(_0x5c947a,_0x1eb5bc);return _0x578994!=null?new j(new S(_0x578994)):new j(_0x5c947a['writeTree_']['subtree'](_0x1eb5bc));}}function Ci(_0x5c3550){return _0x5c3550['writeTree_']['isEmpty']();}function it(_0xfd9d22,_0x46a78d){return xo(w(),_0xfd9d22['writeTree_'],_0x46a78d);}function xo(_0x5bcfd5,_0xd028d1,_0x346ee2){if(_0xd028d1['value']!=null)return _0x346ee2['updateChild'](_0x5bcfd5,_0xd028d1['value']);{let _0x1536d4=null;return _0xd028d1['children']['inorderTraversal']((_0x47d213,_0xbf42f8)=>{_0x47d213==='.priority'?(f(_0xbf42f8['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x1536d4=_0xbf42f8['value']):_0x346ee2=xo(A(_0x5bcfd5,_0x47d213),_0xbf42f8,_0x346ee2);}),!_0x346ee2['getChild'](_0x5bcfd5)['isEmpty']()&&_0x1536d4!==null&&(_0x346ee2=_0x346ee2['updateChild'](A(_0x5bcfd5,'.priority'),_0x1536d4)),_0x346ee2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x12dd0e,_0x3471d0){return Bo(_0x3471d0,_0x12dd0e);}function ou(_0x5b4bfa,_0x56066c,_0x3b729e,_0x3a11ce,_0x1380d3){f(_0x3a11ce>_0x5b4bfa['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1380d3===void 0x0&&(_0x1380d3=!0x0),_0x5b4bfa['allWrites']['push']({'path':_0x56066c,'snap':_0x3b729e,'writeId':_0x3a11ce,'visible':_0x1380d3}),_0x1380d3&&(_0x5b4bfa['visibleWrites']=Ct(_0x5b4bfa['visibleWrites'],_0x56066c,_0x3b729e)),_0x5b4bfa['lastWriteId']=_0x3a11ce;}function au(_0x250aba,_0x3550db,_0x26d308,_0x2ae128){f(_0x2ae128>_0x250aba['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x250aba['allWrites']['push']({'path':_0x3550db,'children':_0x26d308,'writeId':_0x2ae128,'visible':!0x0}),_0x250aba['visibleWrites']=Ii(_0x250aba['visibleWrites'],_0x3550db,_0x26d308),_0x250aba['lastWriteId']=_0x2ae128;}function cu(_0x2a4874,_0x57097a){for(let _0x16de1f=0x0;_0x16de1f<_0x2a4874['allWrites']['length'];_0x16de1f++){const _0x9be377=_0x2a4874['allWrites'][_0x16de1f];if(_0x9be377['writeId']===_0x57097a)return _0x9be377;}return null;}function lu(_0x9cec80,_0x5c5309){const _0x5f16c7=_0x9cec80['allWrites']['findIndex'](_0x356a80=>_0x356a80['writeId']===_0x5c5309);f(_0x5f16c7>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x356aef=_0x9cec80['allWrites'][_0x5f16c7];_0x9cec80['allWrites']['splice'](_0x5f16c7,0x1);let _0x176738=_0x356aef['visible'],_0x139042=!0x1,_0x68456e=_0x9cec80['allWrites']['length']-0x1;for(;_0x176738&&_0x68456e>=0x0;){const _0x16f4b5=_0x9cec80['allWrites'][_0x68456e];_0x16f4b5['visible']&&(_0x68456e>=_0x5f16c7&&hu(_0x16f4b5,_0x356aef['path'])?_0x176738=!0x1:$(_0x356aef['path'],_0x16f4b5['path'])&&(_0x139042=!0x0)),_0x68456e--;}if(_0x176738){if(_0x139042)return uu(_0x9cec80),!0x0;if(_0x356aef['snap'])_0x9cec80['visibleWrites']=sr(_0x9cec80['visibleWrites'],_0x356aef['path']);else{const _0x5bc800=_0x356aef['children'];x(_0x5bc800,_0x3c56d6=>{_0x9cec80['visibleWrites']=sr(_0x9cec80['visibleWrites'],A(_0x356aef['path'],_0x3c56d6));});}return!0x0;}else return!0x1;}function hu(_0x59b36d,_0x18ceae){if(_0x59b36d['snap'])return $(_0x59b36d['path'],_0x18ceae);for(const _0x2e8c58 in _0x59b36d['children'])if(_0x59b36d['children']['hasOwnProperty'](_0x2e8c58)&&$(A(_0x59b36d['path'],_0x2e8c58),_0x18ceae))return!0x0;return!0x1;}function uu(_0x39a5fd){_0x39a5fd['visibleWrites']=Fo(_0x39a5fd['allWrites'],du,w()),_0x39a5fd['allWrites']['length']>0x0?_0x39a5fd['lastWriteId']=_0x39a5fd['allWrites'][_0x39a5fd['allWrites']['length']-0x1]['writeId']:_0x39a5fd['lastWriteId']=-0x1;}function du(_0x133d6){return _0x133d6['visible'];}function Fo(_0x17721a,_0x5d5331,_0x4381c8){let _0x32cb7a=j['empty']();for(let _0x177b20=0x0;_0x177b20<_0x17721a['length'];++_0x177b20){const _0x510806=_0x17721a[_0x177b20];if(_0x5d5331(_0x510806)){const _0x42da32=_0x510806['path'];let _0x11d350;if(_0x510806['snap'])$(_0x4381c8,_0x42da32)?(_0x11d350=F(_0x4381c8,_0x42da32),_0x32cb7a=Ct(_0x32cb7a,_0x11d350,_0x510806['snap'])):$(_0x42da32,_0x4381c8)&&(_0x11d350=F(_0x42da32,_0x4381c8),_0x32cb7a=Ct(_0x32cb7a,w(),_0x510806['snap']['getChild'](_0x11d350)));else{if(_0x510806['children']){if($(_0x4381c8,_0x42da32))_0x11d350=F(_0x4381c8,_0x42da32),_0x32cb7a=Ii(_0x32cb7a,_0x11d350,_0x510806['children']);else{if($(_0x42da32,_0x4381c8)){if(_0x11d350=F(_0x42da32,_0x4381c8),v(_0x11d350))_0x32cb7a=Ii(_0x32cb7a,w(),_0x510806['children']);else{const _0xc3e7a7=Oe(_0x510806['children'],y(_0x11d350));if(_0xc3e7a7){const _0x546f11=_0xc3e7a7['getChild'](b(_0x11d350));_0x32cb7a=Ct(_0x32cb7a,w(),_0x546f11);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x32cb7a;}function Uo(_0x59b4d2,_0x715310,_0x5371ce,_0x5a3d8b,_0x5cc6b2){if(!_0x5a3d8b&&!_0x5cc6b2){const _0x4e4c7e=$e(_0x59b4d2['visibleWrites'],_0x715310);if(_0x4e4c7e!=null)return _0x4e4c7e;{const _0x54c434=ve(_0x59b4d2['visibleWrites'],_0x715310);if(Ci(_0x54c434))return _0x5371ce;if(_0x5371ce==null&&!wi(_0x54c434,w()))return null;{const _0x48c852=_0x5371ce||g['EMPTY_NODE'];return it(_0x54c434,_0x48c852);}}}else{const _0x346f65=ve(_0x59b4d2['visibleWrites'],_0x715310);if(!_0x5cc6b2&&Ci(_0x346f65))return _0x5371ce;if(!_0x5cc6b2&&_0x5371ce==null&&!wi(_0x346f65,w()))return null;{const _0x33aa64=function(_0x531e74){return(_0x531e74['visible']||_0x5cc6b2)&&(!_0x5a3d8b||!~_0x5a3d8b['indexOf'](_0x531e74['writeId']))&&($(_0x531e74['path'],_0x715310)||$(_0x715310,_0x531e74['path']));},_0xd01551=Fo(_0x59b4d2['allWrites'],_0x33aa64,_0x715310),_0x3a0c45=_0x5371ce||g['EMPTY_NODE'];return it(_0xd01551,_0x3a0c45);}}}function fu(_0x8276d3,_0x4b911d,_0x5bb846){let _0x50fd70=g['EMPTY_NODE'];const _0xbd9cb8=$e(_0x8276d3['visibleWrites'],_0x4b911d);if(_0xbd9cb8)return _0xbd9cb8['isLeafNode']()||_0xbd9cb8['forEachChild'](R,(_0x15aadf,_0x3c0b5d)=>{_0x50fd70=_0x50fd70['updateImmediateChild'](_0x15aadf,_0x3c0b5d);}),_0x50fd70;if(_0x5bb846){const _0x2db41c=ve(_0x8276d3['visibleWrites'],_0x4b911d);return _0x5bb846['forEachChild'](R,(_0x94fb5,_0xe27dee)=>{const _0x254a02=it(ve(_0x2db41c,new C(_0x94fb5)),_0xe27dee);_0x50fd70=_0x50fd70['updateImmediateChild'](_0x94fb5,_0x254a02);}),rr(_0x2db41c)['forEach'](_0x186299=>{_0x50fd70=_0x50fd70['updateImmediateChild'](_0x186299['name'],_0x186299['node']);}),_0x50fd70;}else{const _0x49e736=ve(_0x8276d3['visibleWrites'],_0x4b911d);return rr(_0x49e736)['forEach'](_0x2eab37=>{_0x50fd70=_0x50fd70['updateImmediateChild'](_0x2eab37['name'],_0x2eab37['node']);}),_0x50fd70;}}function pu(_0x2b34c5,_0x230462,_0x2ab8f5,_0x577371,_0x3a2aec){f(_0x577371||_0x3a2aec,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x532a90=A(_0x230462,_0x2ab8f5);if(wi(_0x2b34c5['visibleWrites'],_0x532a90))return null;{const _0x51b3f0=ve(_0x2b34c5['visibleWrites'],_0x532a90);return Ci(_0x51b3f0)?_0x3a2aec['getChild'](_0x2ab8f5):it(_0x51b3f0,_0x3a2aec['getChild'](_0x2ab8f5));}}function _u(_0x183ad5,_0x5344eb,_0x2d8bb7,_0xd8eedf){const _0x578759=A(_0x5344eb,_0x2d8bb7),_0x545bf7=$e(_0x183ad5['visibleWrites'],_0x578759);if(_0x545bf7!=null)return _0x545bf7;if(_0xd8eedf['isCompleteForChild'](_0x2d8bb7)){const _0x3fc575=ve(_0x183ad5['visibleWrites'],_0x578759);return it(_0x3fc575,_0xd8eedf['getNode']()['getImmediateChild'](_0x2d8bb7));}else return null;}function gu(_0x1c2989,_0x1ff26f){return $e(_0x1c2989['visibleWrites'],_0x1ff26f);}function mu(_0x33afec,_0x5cdc93,_0x16418c,_0x27c8c3,_0x537be7,_0x3a19e9,_0x33bd4b){let _0x4294f6;const _0x3c50f4=ve(_0x33afec['visibleWrites'],_0x5cdc93),_0x3d25a9=$e(_0x3c50f4,w());if(_0x3d25a9!=null)_0x4294f6=_0x3d25a9;else{if(_0x16418c!=null)_0x4294f6=it(_0x3c50f4,_0x16418c);else return[];}if(_0x4294f6=_0x4294f6['withIndex'](_0x33bd4b),!_0x4294f6['isEmpty']()&&!_0x4294f6['isLeafNode']()){const _0x5b8b3c=[],_0x1c84b9=_0x33bd4b['getCompare'](),_0x93f5ac=_0x3a19e9?_0x4294f6['getReverseIteratorFrom'](_0x27c8c3,_0x33bd4b):_0x4294f6['getIteratorFrom'](_0x27c8c3,_0x33bd4b);let _0xe0c15c=_0x93f5ac['getNext']();for(;_0xe0c15c&&_0x5b8b3c['length']<_0x537be7;)_0x1c84b9(_0xe0c15c,_0x27c8c3)!==0x0&&_0x5b8b3c['push'](_0xe0c15c),_0xe0c15c=_0x93f5ac['getNext']();return _0x5b8b3c;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0xaa9ae6,_0x3510a9,_0x6bb4a2,_0x2240db){return Uo(_0xaa9ae6['writeTree'],_0xaa9ae6['treePath'],_0x3510a9,_0x6bb4a2,_0x2240db);}function es(_0x4446e2,_0x45315f){return fu(_0x4446e2['writeTree'],_0x4446e2['treePath'],_0x45315f);}function or(_0x5a4259,_0x264090,_0x3a2b2d,_0x482088){return pu(_0x5a4259['writeTree'],_0x5a4259['treePath'],_0x264090,_0x3a2b2d,_0x482088);}function yn(_0x567441,_0x55d0f4){return gu(_0x567441['writeTree'],A(_0x567441['treePath'],_0x55d0f4));}function vu(_0x4d16e3,_0x30def0,_0x450482,_0x33bfdc,_0x482f68,_0x471524){return mu(_0x4d16e3['writeTree'],_0x4d16e3['treePath'],_0x30def0,_0x450482,_0x33bfdc,_0x482f68,_0x471524);}function ts(_0x1e8e5c,_0x2e12d5,_0x2551b9){return _u(_0x1e8e5c['writeTree'],_0x1e8e5c['treePath'],_0x2e12d5,_0x2551b9);}function Wo(_0x219674,_0x31bf6c){return Bo(A(_0x219674['treePath'],_0x31bf6c),_0x219674['writeTree']);}function Bo(_0x3e9842,_0x221a85){return{'treePath':_0x3e9842,'writeTree':_0x221a85};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x10588d){const _0x2ace26=_0x10588d['type'],_0x2700a6=_0x10588d['childName'];f(_0x2ace26==='child_added'||_0x2ace26==='child_changed'||_0x2ace26==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2700a6!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2d92ed=this['changeMap']['get'](_0x2700a6);if(_0x2d92ed){const _0x55a247=_0x2d92ed['type'];if(_0x2ace26==='child_added'&&_0x55a247==='child_removed')this['changeMap']['set'](_0x2700a6,Pt(_0x2700a6,_0x10588d['snapshotNode'],_0x2d92ed['snapshotNode']));else{if(_0x2ace26==='child_removed'&&_0x55a247==='child_added')this['changeMap']['delete'](_0x2700a6);else{if(_0x2ace26==='child_removed'&&_0x55a247==='child_changed')this['changeMap']['set'](_0x2700a6,Nt(_0x2700a6,_0x2d92ed['oldSnap']));else{if(_0x2ace26==='child_changed'&&_0x55a247==='child_added')this['changeMap']['set'](_0x2700a6,tt(_0x2700a6,_0x10588d['snapshotNode']));else{if(_0x2ace26==='child_changed'&&_0x55a247==='child_changed')this['changeMap']['set'](_0x2700a6,Pt(_0x2700a6,_0x10588d['snapshotNode'],_0x2d92ed['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x10588d+'\x20occurred\x20after\x20'+_0x2d92ed);}}}}}else this['changeMap']['set'](_0x2700a6,_0x10588d);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x129215){return null;}['getChildAfterChild'](_0x115484,_0x2e4fea,_0x524899){return null;}}const Vo=new Iu();class ns{constructor(_0x4363ab,_0x33fe59,_0x5ad7f1=null){this['writes_']=_0x4363ab,this['viewCache_']=_0x33fe59,this['optCompleteServerCache_']=_0x5ad7f1;}['getCompleteChild'](_0x21fac8){const _0x52f7b1=this['viewCache_']['eventCache'];if(_0x52f7b1['isCompleteForChild'](_0x21fac8))return _0x52f7b1['getNode']()['getImmediateChild'](_0x21fac8);{const _0x5c0d2f=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x21fac8,_0x5c0d2f);}}['getChildAfterChild'](_0x1d7397,_0x5b42e2,_0x329493){const _0x4a46da=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x1b51f8=vu(this['writes_'],_0x4a46da,_0x5b42e2,0x1,_0x329493,_0x1d7397);return _0x1b51f8['length']===0x0?null:_0x1b51f8[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x1db4a6){return{'filter':_0x1db4a6};}function Cu(_0x5ae860,_0x35aaa8){f(_0x35aaa8['eventCache']['getNode']()['isIndexed'](_0x5ae860['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x35aaa8['serverCache']['getNode']()['isIndexed'](_0x5ae860['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x2a44df,_0x171c27,_0x219268,_0x43736b,_0x27e627){const _0x5707cd=new Eu();let _0x1b6da4,_0x1272c5;if(_0x219268['type']===q['OVERWRITE']){const _0x704b54=_0x219268;_0x704b54['source']['fromUser']?_0x1b6da4=Ti(_0x2a44df,_0x171c27,_0x704b54['path'],_0x704b54['snap'],_0x43736b,_0x27e627,_0x5707cd):(f(_0x704b54['source']['fromServer'],'Unknown\x20source.'),_0x1272c5=_0x704b54['source']['tagged']||_0x171c27['serverCache']['isFiltered']()&&!v(_0x704b54['path']),_0x1b6da4=vn(_0x2a44df,_0x171c27,_0x704b54['path'],_0x704b54['snap'],_0x43736b,_0x27e627,_0x1272c5,_0x5707cd));}else{if(_0x219268['type']===q['MERGE']){const _0x55a76e=_0x219268;_0x55a76e['source']['fromUser']?_0x1b6da4=bu(_0x2a44df,_0x171c27,_0x55a76e['path'],_0x55a76e['children'],_0x43736b,_0x27e627,_0x5707cd):(f(_0x55a76e['source']['fromServer'],'Unknown\x20source.'),_0x1272c5=_0x55a76e['source']['tagged']||_0x171c27['serverCache']['isFiltered'](),_0x1b6da4=Si(_0x2a44df,_0x171c27,_0x55a76e['path'],_0x55a76e['children'],_0x43736b,_0x27e627,_0x1272c5,_0x5707cd));}else{if(_0x219268['type']===q['ACK_USER_WRITE']){const _0x531dc2=_0x219268;_0x531dc2['revert']?_0x1b6da4=ku(_0x2a44df,_0x171c27,_0x531dc2['path'],_0x43736b,_0x27e627,_0x5707cd):_0x1b6da4=Ru(_0x2a44df,_0x171c27,_0x531dc2['path'],_0x531dc2['affectedTree'],_0x43736b,_0x27e627,_0x5707cd);}else{if(_0x219268['type']===q['LISTEN_COMPLETE'])_0x1b6da4=Au(_0x2a44df,_0x171c27,_0x219268['path'],_0x43736b,_0x5707cd);else throw ot('Unknown\x20operation\x20type:\x20'+_0x219268['type']);}}}const _0x5590fd=_0x5707cd['getChanges']();return Su(_0x171c27,_0x1b6da4,_0x5590fd),{'viewCache':_0x1b6da4,'changes':_0x5590fd};}function Su(_0x35885a,_0x26d9ff,_0x4ca9b4){const _0x38f31c=_0x26d9ff['eventCache'];if(_0x38f31c['isFullyInitialized']()){const _0x5a845b=_0x38f31c['getNode']()['isLeafNode']()||_0x38f31c['getNode']()['isEmpty'](),_0x501cb1=gn(_0x35885a);(_0x4ca9b4['length']>0x0||!_0x35885a['eventCache']['isFullyInitialized']()||_0x5a845b&&!_0x38f31c['getNode']()['equals'](_0x501cb1)||!_0x38f31c['getNode']()['getPriority']()['equals'](_0x501cb1['getPriority']()))&&_0x4ca9b4['push'](Oo(gn(_0x26d9ff)));}}function Ho(_0x32a588,_0xc9b135,_0x166b28,_0x24a9b2,_0xae21e0,_0x36ec1b){const _0x4a8748=_0xc9b135['eventCache'];if(yn(_0x24a9b2,_0x166b28)!=null)return _0xc9b135;{let _0x2af1be,_0x5a044e;if(v(_0x166b28)){if(f(_0xc9b135['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xc9b135['serverCache']['isFiltered']()){const _0x2c3f31=Ue(_0xc9b135),_0x16c69c=_0x2c3f31 instanceof g?_0x2c3f31:g['EMPTY_NODE'],_0xfbaf79=es(_0x24a9b2,_0x16c69c);_0x2af1be=_0x32a588['filter']['updateFullNode'](_0xc9b135['eventCache']['getNode'](),_0xfbaf79,_0x36ec1b);}else{const _0x22f653=mn(_0x24a9b2,Ue(_0xc9b135));_0x2af1be=_0x32a588['filter']['updateFullNode'](_0xc9b135['eventCache']['getNode'](),_0x22f653,_0x36ec1b);}}else{const _0x447087=y(_0x166b28);if(_0x447087==='.priority'){f(we(_0x166b28)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x355de9=_0x4a8748['getNode']();_0x5a044e=_0xc9b135['serverCache']['getNode']();const _0x6a943d=or(_0x24a9b2,_0x166b28,_0x355de9,_0x5a044e);_0x6a943d!=null?_0x2af1be=_0x32a588['filter']['updatePriority'](_0x355de9,_0x6a943d):_0x2af1be=_0x4a8748['getNode']();}else{const _0x3177a7=b(_0x166b28);let _0x3a0e4d;if(_0x4a8748['isCompleteForChild'](_0x447087)){_0x5a044e=_0xc9b135['serverCache']['getNode']();const _0x4f5691=or(_0x24a9b2,_0x166b28,_0x4a8748['getNode'](),_0x5a044e);_0x4f5691!=null?_0x3a0e4d=_0x4a8748['getNode']()['getImmediateChild'](_0x447087)['updateChild'](_0x3177a7,_0x4f5691):_0x3a0e4d=_0x4a8748['getNode']()['getImmediateChild'](_0x447087);}else _0x3a0e4d=ts(_0x24a9b2,_0x447087,_0xc9b135['serverCache']);_0x3a0e4d!=null?_0x2af1be=_0x32a588['filter']['updateChild'](_0x4a8748['getNode'](),_0x447087,_0x3a0e4d,_0x3177a7,_0xae21e0,_0x36ec1b):_0x2af1be=_0x4a8748['getNode']();}}return wt(_0xc9b135,_0x2af1be,_0x4a8748['isFullyInitialized']()||v(_0x166b28),_0x32a588['filter']['filtersNodes']());}}function vn(_0x4d1874,_0x4682a5,_0x47292a,_0xd31506,_0x2b7fc4,_0x2fbefa,_0x435565,_0x3fd880){const _0x29cb76=_0x4682a5['serverCache'];let _0x33127e;const _0x5ad382=_0x435565?_0x4d1874['filter']:_0x4d1874['filter']['getIndexedFilter']();if(v(_0x47292a))_0x33127e=_0x5ad382['updateFullNode'](_0x29cb76['getNode'](),_0xd31506,null);else{if(_0x5ad382['filtersNodes']()&&!_0x29cb76['isFiltered']()){const _0x551e4c=_0x29cb76['getNode']()['updateChild'](_0x47292a,_0xd31506);_0x33127e=_0x5ad382['updateFullNode'](_0x29cb76['getNode'](),_0x551e4c,null);}else{const _0x419a74=y(_0x47292a);if(!_0x29cb76['isCompleteForPath'](_0x47292a)&&we(_0x47292a)>0x1)return _0x4682a5;const _0x3d746d=b(_0x47292a),_0x57b7db=_0x29cb76['getNode']()['getImmediateChild'](_0x419a74)['updateChild'](_0x3d746d,_0xd31506);_0x419a74==='.priority'?_0x33127e=_0x5ad382['updatePriority'](_0x29cb76['getNode'](),_0x57b7db):_0x33127e=_0x5ad382['updateChild'](_0x29cb76['getNode'](),_0x419a74,_0x57b7db,_0x3d746d,Vo,null);}}const _0x418f28=Lo(_0x4682a5,_0x33127e,_0x29cb76['isFullyInitialized']()||v(_0x47292a),_0x5ad382['filtersNodes']()),_0x224253=new ns(_0x2b7fc4,_0x418f28,_0x2fbefa);return Ho(_0x4d1874,_0x418f28,_0x47292a,_0x2b7fc4,_0x224253,_0x3fd880);}function Ti(_0x31b8cd,_0x29c047,_0x399fcf,_0xa51d55,_0x71fd91,_0x251c69,_0x46bfef){const _0x31af85=_0x29c047['eventCache'];let _0x59a1f7,_0x16ca5b;const _0x429ecc=new ns(_0x71fd91,_0x29c047,_0x251c69);if(v(_0x399fcf))_0x16ca5b=_0x31b8cd['filter']['updateFullNode'](_0x29c047['eventCache']['getNode'](),_0xa51d55,_0x46bfef),_0x59a1f7=wt(_0x29c047,_0x16ca5b,!0x0,_0x31b8cd['filter']['filtersNodes']());else{const _0x115a5e=y(_0x399fcf);if(_0x115a5e==='.priority')_0x16ca5b=_0x31b8cd['filter']['updatePriority'](_0x29c047['eventCache']['getNode'](),_0xa51d55),_0x59a1f7=wt(_0x29c047,_0x16ca5b,_0x31af85['isFullyInitialized'](),_0x31af85['isFiltered']());else{const _0x2c7aee=b(_0x399fcf),_0x5e07bb=_0x31af85['getNode']()['getImmediateChild'](_0x115a5e);let _0x46ea8c;if(v(_0x2c7aee))_0x46ea8c=_0xa51d55;else{const _0x9e75e6=_0x429ecc['getCompleteChild'](_0x115a5e);_0x9e75e6!=null?Gi(_0x2c7aee)==='.priority'&&_0x9e75e6['getChild'](To(_0x2c7aee))['isEmpty']()?_0x46ea8c=_0x9e75e6:_0x46ea8c=_0x9e75e6['updateChild'](_0x2c7aee,_0xa51d55):_0x46ea8c=g['EMPTY_NODE'];}if(_0x5e07bb['equals'](_0x46ea8c))_0x59a1f7=_0x29c047;else{const _0x7a4fc7=_0x31b8cd['filter']['updateChild'](_0x31af85['getNode'](),_0x115a5e,_0x46ea8c,_0x2c7aee,_0x429ecc,_0x46bfef);_0x59a1f7=wt(_0x29c047,_0x7a4fc7,_0x31af85['isFullyInitialized'](),_0x31b8cd['filter']['filtersNodes']());}}}return _0x59a1f7;}function ar(_0x5cd9eb,_0x2ace9d){return _0x5cd9eb['eventCache']['isCompleteForChild'](_0x2ace9d);}function bu(_0x4b7ccc,_0x49146e,_0x3082c4,_0x44d1f9,_0x49e576,_0x8c30a3,_0x4d3f81){let _0x160572=_0x49146e;return _0x44d1f9['foreach']((_0x43f529,_0x1b4b77)=>{const _0x56efd5=A(_0x3082c4,_0x43f529);ar(_0x49146e,y(_0x56efd5))&&(_0x160572=Ti(_0x4b7ccc,_0x160572,_0x56efd5,_0x1b4b77,_0x49e576,_0x8c30a3,_0x4d3f81));}),_0x44d1f9['foreach']((_0x35ba99,_0x21076b)=>{const _0x486532=A(_0x3082c4,_0x35ba99);ar(_0x49146e,y(_0x486532))||(_0x160572=Ti(_0x4b7ccc,_0x160572,_0x486532,_0x21076b,_0x49e576,_0x8c30a3,_0x4d3f81));}),_0x160572;}function cr(_0x5028df,_0x2c307e,_0x5b66ed){return _0x5b66ed['foreach']((_0x20dd9f,_0x52d4b8)=>{_0x2c307e=_0x2c307e['updateChild'](_0x20dd9f,_0x52d4b8);}),_0x2c307e;}function Si(_0x8c3e6f,_0x586622,_0x35d1cd,_0x3f0c8b,_0x3849f9,_0x885a20,_0x4fdb97,_0xfe6ab4){if(_0x586622['serverCache']['getNode']()['isEmpty']()&&!_0x586622['serverCache']['isFullyInitialized']())return _0x586622;let _0x337969=_0x586622,_0x55fd2a;v(_0x35d1cd)?_0x55fd2a=_0x3f0c8b:_0x55fd2a=new S(null)['setTree'](_0x35d1cd,_0x3f0c8b);const _0x41948a=_0x586622['serverCache']['getNode']();return _0x55fd2a['children']['inorderTraversal']((_0x3f95fc,_0x3b285d)=>{if(_0x41948a['hasChild'](_0x3f95fc)){const _0x5d8fa2=_0x586622['serverCache']['getNode']()['getImmediateChild'](_0x3f95fc),_0x1d316f=cr(_0x8c3e6f,_0x5d8fa2,_0x3b285d);_0x337969=vn(_0x8c3e6f,_0x337969,new C(_0x3f95fc),_0x1d316f,_0x3849f9,_0x885a20,_0x4fdb97,_0xfe6ab4);}}),_0x55fd2a['children']['inorderTraversal']((_0x2b7445,_0x5e4340)=>{const _0x5462e1=!_0x586622['serverCache']['isCompleteForChild'](_0x2b7445)&&_0x5e4340['value']===null;if(!_0x41948a['hasChild'](_0x2b7445)&&!_0x5462e1){const _0x4ad02e=_0x586622['serverCache']['getNode']()['getImmediateChild'](_0x2b7445),_0x27be5a=cr(_0x8c3e6f,_0x4ad02e,_0x5e4340);_0x337969=vn(_0x8c3e6f,_0x337969,new C(_0x2b7445),_0x27be5a,_0x3849f9,_0x885a20,_0x4fdb97,_0xfe6ab4);}}),_0x337969;}function Ru(_0xc46b4,_0x5ecd05,_0x4d7ca9,_0x1addca,_0x1216a9,_0x50b3fb,_0x1d5a7a){if(yn(_0x1216a9,_0x4d7ca9)!=null)return _0x5ecd05;const _0x21bbb8=_0x5ecd05['serverCache']['isFiltered'](),_0xe98eb1=_0x5ecd05['serverCache'];if(_0x1addca['value']!=null){if(v(_0x4d7ca9)&&_0xe98eb1['isFullyInitialized']()||_0xe98eb1['isCompleteForPath'](_0x4d7ca9))return vn(_0xc46b4,_0x5ecd05,_0x4d7ca9,_0xe98eb1['getNode']()['getChild'](_0x4d7ca9),_0x1216a9,_0x50b3fb,_0x21bbb8,_0x1d5a7a);if(v(_0x4d7ca9)){let _0xb4f219=new S(null);return _0xe98eb1['getNode']()['forEachChild'](ye,(_0x1cfcdf,_0x2425a4)=>{_0xb4f219=_0xb4f219['set'](new C(_0x1cfcdf),_0x2425a4);}),Si(_0xc46b4,_0x5ecd05,_0x4d7ca9,_0xb4f219,_0x1216a9,_0x50b3fb,_0x21bbb8,_0x1d5a7a);}else return _0x5ecd05;}else{let _0x10938e=new S(null);return _0x1addca['foreach']((_0x52abc9,_0x28601e)=>{const _0x4da608=A(_0x4d7ca9,_0x52abc9);_0xe98eb1['isCompleteForPath'](_0x4da608)&&(_0x10938e=_0x10938e['set'](_0x52abc9,_0xe98eb1['getNode']()['getChild'](_0x4da608)));}),Si(_0xc46b4,_0x5ecd05,_0x4d7ca9,_0x10938e,_0x1216a9,_0x50b3fb,_0x21bbb8,_0x1d5a7a);}}function Au(_0x30931f,_0x5efb4b,_0x326871,_0x1cf43d,_0x46a6e1){const _0x4b3cf1=_0x5efb4b['serverCache'],_0x1a9312=Lo(_0x5efb4b,_0x4b3cf1['getNode'](),_0x4b3cf1['isFullyInitialized']()||v(_0x326871),_0x4b3cf1['isFiltered']());return Ho(_0x30931f,_0x1a9312,_0x326871,_0x1cf43d,Vo,_0x46a6e1);}function ku(_0x1a6f3e,_0x371c8f,_0x587b4c,_0x157187,_0x10937e,_0x2d4ccc){let _0x100a00;if(yn(_0x157187,_0x587b4c)!=null)return _0x371c8f;{const _0x25f84f=new ns(_0x157187,_0x371c8f,_0x10937e),_0x18feb4=_0x371c8f['eventCache']['getNode']();let _0x1602eb;if(v(_0x587b4c)||y(_0x587b4c)==='.priority'){let _0x3a2989;if(_0x371c8f['serverCache']['isFullyInitialized']())_0x3a2989=mn(_0x157187,Ue(_0x371c8f));else{const _0x2beb51=_0x371c8f['serverCache']['getNode']();f(_0x2beb51 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3a2989=es(_0x157187,_0x2beb51);}_0x3a2989=_0x3a2989,_0x1602eb=_0x1a6f3e['filter']['updateFullNode'](_0x18feb4,_0x3a2989,_0x2d4ccc);}else{const _0x5967e0=y(_0x587b4c);let _0x4452cd=ts(_0x157187,_0x5967e0,_0x371c8f['serverCache']);_0x4452cd==null&&_0x371c8f['serverCache']['isCompleteForChild'](_0x5967e0)&&(_0x4452cd=_0x18feb4['getImmediateChild'](_0x5967e0)),_0x4452cd!=null?_0x1602eb=_0x1a6f3e['filter']['updateChild'](_0x18feb4,_0x5967e0,_0x4452cd,b(_0x587b4c),_0x25f84f,_0x2d4ccc):_0x371c8f['eventCache']['getNode']()['hasChild'](_0x5967e0)?_0x1602eb=_0x1a6f3e['filter']['updateChild'](_0x18feb4,_0x5967e0,g['EMPTY_NODE'],b(_0x587b4c),_0x25f84f,_0x2d4ccc):_0x1602eb=_0x18feb4,_0x1602eb['isEmpty']()&&_0x371c8f['serverCache']['isFullyInitialized']()&&(_0x100a00=mn(_0x157187,Ue(_0x371c8f)),_0x100a00['isLeafNode']()&&(_0x1602eb=_0x1a6f3e['filter']['updateFullNode'](_0x1602eb,_0x100a00,_0x2d4ccc)));}return _0x100a00=_0x371c8f['serverCache']['isFullyInitialized']()||yn(_0x157187,w())!=null,wt(_0x371c8f,_0x1602eb,_0x100a00,_0x1a6f3e['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x5a0d97,_0x59a24b){this['query_']=_0x5a0d97,this['eventRegistrations_']=[];const _0x261441=this['query_']['_queryParams'],_0x55477c=new Yi(_0x261441['getIndex']()),_0x1ab22e=qh(_0x261441);this['processor_']=wu(_0x1ab22e);const _0x5e7d11=_0x59a24b['serverCache'],_0x7e4534=_0x59a24b['eventCache'],_0x48304c=_0x55477c['updateFullNode'](g['EMPTY_NODE'],_0x5e7d11['getNode'](),null),_0x4c5c45=_0x1ab22e['updateFullNode'](g['EMPTY_NODE'],_0x7e4534['getNode'](),null),_0x301f66=new Ce(_0x48304c,_0x5e7d11['isFullyInitialized'](),_0x55477c['filtersNodes']()),_0x16444d=new Ce(_0x4c5c45,_0x7e4534['isFullyInitialized'](),_0x1ab22e['filtersNodes']());this['viewCache_']=Dn(_0x16444d,_0x301f66),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x3c86f0){return _0x3c86f0['viewCache_']['serverCache']['getNode']();}function Ou(_0x40edc5){return gn(_0x40edc5['viewCache_']);}function Du(_0x16607e,_0x970b20){const _0x32e563=Ue(_0x16607e['viewCache_']);return _0x32e563&&(_0x16607e['query']['_queryParams']['loadsAllData']()||!v(_0x970b20)&&!_0x32e563['getImmediateChild'](y(_0x970b20))['isEmpty']())?_0x32e563['getChild'](_0x970b20):null;}function lr(_0x287d43){return _0x287d43['eventRegistrations_']['length']===0x0;}function Mu(_0x381716,_0x4f2639){_0x381716['eventRegistrations_']['push'](_0x4f2639);}function hr(_0x41470c,_0x584fd5,_0xd323bb){const _0xde8ccc=[];if(_0xd323bb){f(_0x584fd5==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2987be=_0x41470c['query']['_path'];_0x41470c['eventRegistrations_']['forEach'](_0x42ee52=>{const _0x25e9ca=_0x42ee52['createCancelEvent'](_0xd323bb,_0x2987be);_0x25e9ca&&_0xde8ccc['push'](_0x25e9ca);});}if(_0x584fd5){let _0x41a4ad=[];for(let _0x3da88e=0x0;_0x3da88e<_0x41470c['eventRegistrations_']['length'];++_0x3da88e){const _0x2ca639=_0x41470c['eventRegistrations_'][_0x3da88e];if(!_0x2ca639['matches'](_0x584fd5))_0x41a4ad['push'](_0x2ca639);else{if(_0x584fd5['hasAnyCallback']()){_0x41a4ad=_0x41a4ad['concat'](_0x41470c['eventRegistrations_']['slice'](_0x3da88e+0x1));break;}}}_0x41470c['eventRegistrations_']=_0x41a4ad;}else _0x41470c['eventRegistrations_']=[];return _0xde8ccc;}function ur(_0x4c1920,_0xf65105,_0x2ca9ca,_0x11ecef){_0xf65105['type']===q['MERGE']&&_0xf65105['source']['queryId']!==null&&(f(Ue(_0x4c1920['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x4c1920['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0xef5a0d=_0x4c1920['viewCache_'],_0x15a90d=Tu(_0x4c1920['processor_'],_0xef5a0d,_0xf65105,_0x2ca9ca,_0x11ecef);return Cu(_0x4c1920['processor_'],_0x15a90d['viewCache']),f(_0x15a90d['viewCache']['serverCache']['isFullyInitialized']()||!_0xef5a0d['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4c1920['viewCache_']=_0x15a90d['viewCache'],$o(_0x4c1920,_0x15a90d['changes'],_0x15a90d['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x1cdfb0,_0x1c10e2){const _0xa10df=_0x1cdfb0['viewCache_']['eventCache'],_0x517731=[];return _0xa10df['getNode']()['isLeafNode']()||_0xa10df['getNode']()['forEachChild'](R,(_0x5a866a,_0x58a220)=>{_0x517731['push'](tt(_0x5a866a,_0x58a220));}),_0xa10df['isFullyInitialized']()&&_0x517731['push'](Oo(_0xa10df['getNode']())),$o(_0x1cdfb0,_0x517731,_0xa10df['getNode'](),_0x1c10e2);}function $o(_0xe3cbb9,_0x418bd6,_0x1442e1,_0x4c4945){const _0x46c24f=_0x4c4945?[_0x4c4945]:_0xe3cbb9['eventRegistrations_'];return nu(_0xe3cbb9['eventGenerator_'],_0x418bd6,_0x1442e1,_0x46c24f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x37e1ee){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x37e1ee;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x564058){return _0x564058['views']['size']===0x0;}function is(_0x47e7ed,_0x5551c4,_0x454e14,_0x42dd37){const _0x1aba60=_0x5551c4['source']['queryId'];if(_0x1aba60!==null){const _0x511597=_0x47e7ed['views']['get'](_0x1aba60);return f(_0x511597!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x511597,_0x5551c4,_0x454e14,_0x42dd37);}else{let _0x4eb5b7=[];for(const _0x1f36f3 of _0x47e7ed['views']['values']())_0x4eb5b7=_0x4eb5b7['concat'](ur(_0x1f36f3,_0x5551c4,_0x454e14,_0x42dd37));return _0x4eb5b7;}}function qo(_0x485f58,_0x109434,_0x521168,_0x25b7e0,_0x19a974){const _0x4837d1=_0x109434['_queryIdentifier'],_0x544518=_0x485f58['views']['get'](_0x4837d1);if(!_0x544518){let _0x509673=mn(_0x521168,_0x19a974?_0x25b7e0:null),_0x490ded=!0x1;_0x509673?_0x490ded=!0x0:_0x25b7e0 instanceof g?(_0x509673=es(_0x521168,_0x25b7e0),_0x490ded=!0x1):(_0x509673=g['EMPTY_NODE'],_0x490ded=!0x1);const _0x2ca9bf=Dn(new Ce(_0x509673,_0x490ded,!0x1),new Ce(_0x25b7e0,_0x19a974,!0x1));return new Nu(_0x109434,_0x2ca9bf);}return _0x544518;}function Wu(_0x562f1d,_0x28913b,_0x15f03e,_0x1c3199,_0x18f34b,_0x478a87){const _0x445f25=qo(_0x562f1d,_0x28913b,_0x1c3199,_0x18f34b,_0x478a87);return _0x562f1d['views']['has'](_0x28913b['_queryIdentifier'])||_0x562f1d['views']['set'](_0x28913b['_queryIdentifier'],_0x445f25),Mu(_0x445f25,_0x15f03e),Lu(_0x445f25,_0x15f03e);}function Bu(_0x449436,_0x3345ba,_0x3df56b,_0x2e84b7){const _0x336e57=_0x3345ba['_queryIdentifier'],_0x5347ae=[];let _0x5e9499=[];const _0x54193e=Te(_0x449436);if(_0x336e57==='default'){for(const [_0x1c1c44,_0x2055d3]of _0x449436['views']['entries']())_0x5e9499=_0x5e9499['concat'](hr(_0x2055d3,_0x3df56b,_0x2e84b7)),lr(_0x2055d3)&&(_0x449436['views']['delete'](_0x1c1c44),_0x2055d3['query']['_queryParams']['loadsAllData']()||_0x5347ae['push'](_0x2055d3['query']));}else{const _0x27aea4=_0x449436['views']['get'](_0x336e57);_0x27aea4&&(_0x5e9499=_0x5e9499['concat'](hr(_0x27aea4,_0x3df56b,_0x2e84b7)),lr(_0x27aea4)&&(_0x449436['views']['delete'](_0x336e57),_0x27aea4['query']['_queryParams']['loadsAllData']()||_0x5347ae['push'](_0x27aea4['query'])));}return _0x54193e&&!Te(_0x449436)&&_0x5347ae['push'](new(Fu())(_0x3345ba['_repo'],_0x3345ba['_path'])),{'removed':_0x5347ae,'events':_0x5e9499};}function zo(_0x3a89ac){const _0x12b73a=[];for(const _0x18b5fd of _0x3a89ac['views']['values']())_0x18b5fd['query']['_queryParams']['loadsAllData']()||_0x12b73a['push'](_0x18b5fd);return _0x12b73a;}function Ee(_0x188b82,_0x78aa49){let _0x221552=null;for(const _0x2c3923 of _0x188b82['views']['values']())_0x221552=_0x221552||Du(_0x2c3923,_0x78aa49);return _0x221552;}function jo(_0x1ad7da,_0x3d84fc){if(_0x3d84fc['_queryParams']['loadsAllData']())return Ln(_0x1ad7da);{const _0x130ed8=_0x3d84fc['_queryIdentifier'];return _0x1ad7da['views']['get'](_0x130ed8);}}function Ko(_0x24ecd3,_0x44782d){return jo(_0x24ecd3,_0x44782d)!=null;}function Te(_0x341c0d){return Ln(_0x341c0d)!=null;}function Ln(_0x56f21b){for(const _0x96ed1e of _0x56f21b['views']['values']())if(_0x96ed1e['query']['_queryParams']['loadsAllData']())return _0x96ed1e;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x5c65b7){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x5c65b7;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x23a608){this['listenProvider_']=_0x23a608,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0xcfe1a4,_0x2132bf,_0x216e6e,_0x273345,_0x44a70e){return ou(_0xcfe1a4['pendingWriteTree_'],_0x2132bf,_0x216e6e,_0x273345,_0x44a70e),_0x44a70e?ht(_0xcfe1a4,new Fe(Ji(),_0x2132bf,_0x216e6e)):[];}function Gu(_0x38cdbf,_0x18ac19,_0x5370ea,_0x3c6d1c){au(_0x38cdbf['pendingWriteTree_'],_0x18ac19,_0x5370ea,_0x3c6d1c);const _0x5c3a85=S['fromObject'](_0x5370ea);return ht(_0x38cdbf,new nt(Ji(),_0x18ac19,_0x5c3a85));}function pe(_0x52d021,_0x27c100,_0x1fe2f8=!0x1){const _0x2d6fd1=cu(_0x52d021['pendingWriteTree_'],_0x27c100);if(lu(_0x52d021['pendingWriteTree_'],_0x27c100)){let _0xce4b18=new S(null);return _0x2d6fd1['snap']!=null?_0xce4b18=_0xce4b18['set'](w(),!0x0):x(_0x2d6fd1['children'],_0x399285=>{_0xce4b18=_0xce4b18['set'](new C(_0x399285),!0x0);}),ht(_0x52d021,new _n(_0x2d6fd1['path'],_0xce4b18,_0x1fe2f8));}else return[];}function $t(_0x1817a3,_0x46b1ae,_0x513802){return ht(_0x1817a3,new Fe(Xi(),_0x46b1ae,_0x513802));}function qu(_0x5ca152,_0x519e7d,_0x5ee50f){const _0x2059c5=S['fromObject'](_0x5ee50f);return ht(_0x5ca152,new nt(Xi(),_0x519e7d,_0x2059c5));}function zu(_0x5ce24f,_0x5da719){return ht(_0x5ce24f,new Dt(Xi(),_0x5da719));}function ju(_0x28e019,_0x51499e,_0x4f04cb){const _0x1df4cd=rs(_0x28e019,_0x4f04cb);if(_0x1df4cd){const _0x4c9a3b=os(_0x1df4cd),_0x5825f8=_0x4c9a3b['path'],_0x3cc3cc=_0x4c9a3b['queryId'],_0x11eef8=F(_0x5825f8,_0x51499e),_0x160205=new Dt(Zi(_0x3cc3cc),_0x11eef8);return as(_0x28e019,_0x5825f8,_0x160205);}else return[];}function wn(_0x402f15,_0x124b81,_0x213b09,_0x3c5e5e,_0x5bec05=!0x1){const _0x46a8ed=_0x124b81['_path'],_0x14c3eb=_0x402f15['syncPointTree_']['get'](_0x46a8ed);let _0x35c92d=[];if(_0x14c3eb&&(_0x124b81['_queryIdentifier']==='default'||Ko(_0x14c3eb,_0x124b81))){const _0x4d14bd=Bu(_0x14c3eb,_0x124b81,_0x213b09,_0x3c5e5e);Uu(_0x14c3eb)&&(_0x402f15['syncPointTree_']=_0x402f15['syncPointTree_']['remove'](_0x46a8ed));const _0x25a9b0=_0x4d14bd['removed'];if(_0x35c92d=_0x4d14bd['events'],!_0x5bec05){const _0x54e392=_0x25a9b0['findIndex'](_0x34aba0=>_0x34aba0['_queryParams']['loadsAllData']())!==-0x1,_0xdfe50b=_0x402f15['syncPointTree_']['findOnPath'](_0x46a8ed,(_0x5dac70,_0x4cff22)=>Te(_0x4cff22));if(_0x54e392&&!_0xdfe50b){const _0x41c559=_0x402f15['syncPointTree_']['subtree'](_0x46a8ed);if(!_0x41c559['isEmpty']()){const _0xb4ea51=Qu(_0x41c559);for(let _0x5e5111=0x0;_0x5e5111<_0xb4ea51['length'];++_0x5e5111){const _0x4ac0e3=_0xb4ea51[_0x5e5111],_0xaa5040=_0x4ac0e3['query'],_0x3c0f19=Xo(_0x402f15,_0x4ac0e3);_0x402f15['listenProvider_']['startListening'](Tt(_0xaa5040),Mt(_0x402f15,_0xaa5040),_0x3c0f19['hashFn'],_0x3c0f19['onComplete']);}}}!_0xdfe50b&&_0x25a9b0['length']>0x0&&!_0x3c5e5e&&(_0x54e392?_0x402f15['listenProvider_']['stopListening'](Tt(_0x124b81),null):_0x25a9b0['forEach'](_0x45dd59=>{const _0x5f5314=_0x402f15['queryToTagMap']['get'](Fn(_0x45dd59));_0x402f15['listenProvider_']['stopListening'](Tt(_0x45dd59),_0x5f5314);}));}Ju(_0x402f15,_0x25a9b0);}return _0x35c92d;}function Yo(_0x176759,_0x59b5f9,_0x58a80b,_0x3b31e8){const _0x2b7ed8=rs(_0x176759,_0x3b31e8);if(_0x2b7ed8!=null){const _0x3a434b=os(_0x2b7ed8),_0x13696e=_0x3a434b['path'],_0x4e8e82=_0x3a434b['queryId'],_0x3ef3f6=F(_0x13696e,_0x59b5f9),_0x4d38d8=new Fe(Zi(_0x4e8e82),_0x3ef3f6,_0x58a80b);return as(_0x176759,_0x13696e,_0x4d38d8);}else return[];}function Ku(_0x54cd0d,_0x5c48ec,_0xc98e54,_0x2dbf83){const _0x4b1a67=rs(_0x54cd0d,_0x2dbf83);if(_0x4b1a67){const _0x45ab39=os(_0x4b1a67),_0x4fa4c7=_0x45ab39['path'],_0x228a8e=_0x45ab39['queryId'],_0x18e4ba=F(_0x4fa4c7,_0x5c48ec),_0x3768b6=S['fromObject'](_0xc98e54),_0x3a0046=new nt(Zi(_0x228a8e),_0x18e4ba,_0x3768b6);return as(_0x54cd0d,_0x4fa4c7,_0x3a0046);}else return[];}function bi(_0x466a0f,_0x944196,_0xfbfc5f,_0x33c4b7=!0x1){const _0x11113e=_0x944196['_path'];let _0x3bb7de=null,_0x312a54=!0x1;_0x466a0f['syncPointTree_']['foreachOnPath'](_0x11113e,(_0x32c987,_0x16c296)=>{const _0x3bf4a6=F(_0x32c987,_0x11113e);_0x3bb7de=_0x3bb7de||Ee(_0x16c296,_0x3bf4a6),_0x312a54=_0x312a54||Te(_0x16c296);});let _0x5733a6=_0x466a0f['syncPointTree_']['get'](_0x11113e);_0x5733a6?(_0x312a54=_0x312a54||Te(_0x5733a6),_0x3bb7de=_0x3bb7de||Ee(_0x5733a6,w())):(_0x5733a6=new Go(),_0x466a0f['syncPointTree_']=_0x466a0f['syncPointTree_']['set'](_0x11113e,_0x5733a6));let _0x5caa59;_0x3bb7de!=null?_0x5caa59=!0x0:(_0x5caa59=!0x1,_0x3bb7de=g['EMPTY_NODE'],_0x466a0f['syncPointTree_']['subtree'](_0x11113e)['foreachChild']((_0x2daa8c,_0x299116)=>{const _0x156438=Ee(_0x299116,w());_0x156438&&(_0x3bb7de=_0x3bb7de['updateImmediateChild'](_0x2daa8c,_0x156438));}));const _0xd45746=Ko(_0x5733a6,_0x944196);if(!_0xd45746&&!_0x944196['_queryParams']['loadsAllData']()){const _0x2b1e20=Fn(_0x944196);f(!_0x466a0f['queryToTagMap']['has'](_0x2b1e20),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x59a04e=Xu();_0x466a0f['queryToTagMap']['set'](_0x2b1e20,_0x59a04e),_0x466a0f['tagToQueryMap']['set'](_0x59a04e,_0x2b1e20);}const _0xf89c7a=Mn(_0x466a0f['pendingWriteTree_'],_0x11113e);let _0x57a027=Wu(_0x5733a6,_0x944196,_0xfbfc5f,_0xf89c7a,_0x3bb7de,_0x5caa59);if(!_0xd45746&&!_0x312a54&&!_0x33c4b7){const _0x108804=jo(_0x5733a6,_0x944196);_0x57a027=_0x57a027['concat'](Zu(_0x466a0f,_0x944196,_0x108804));}return _0x57a027;}function xn(_0x3c0ba7,_0x4fc488,_0x32ea75){const _0x234fa6=_0x3c0ba7['pendingWriteTree_'],_0x31127f=_0x3c0ba7['syncPointTree_']['findOnPath'](_0x4fc488,(_0x18da02,_0x1513bd)=>{const _0x2450c6=F(_0x18da02,_0x4fc488),_0x8e1df6=Ee(_0x1513bd,_0x2450c6);if(_0x8e1df6)return _0x8e1df6;});return Uo(_0x234fa6,_0x4fc488,_0x31127f,_0x32ea75,!0x0);}function Yu(_0x560f0a,_0x31de73){const _0x558eca=_0x31de73['_path'];let _0x352edf=null;_0x560f0a['syncPointTree_']['foreachOnPath'](_0x558eca,(_0x50b629,_0x527b34)=>{const _0x47eee1=F(_0x50b629,_0x558eca);_0x352edf=_0x352edf||Ee(_0x527b34,_0x47eee1);});let _0x2bb717=_0x560f0a['syncPointTree_']['get'](_0x558eca);_0x2bb717?_0x352edf=_0x352edf||Ee(_0x2bb717,w()):(_0x2bb717=new Go(),_0x560f0a['syncPointTree_']=_0x560f0a['syncPointTree_']['set'](_0x558eca,_0x2bb717));const _0xe62659=_0x352edf!=null,_0x579658=_0xe62659?new Ce(_0x352edf,!0x0,!0x1):null,_0x3ed708=Mn(_0x560f0a['pendingWriteTree_'],_0x31de73['_path']),_0x55ce2e=qo(_0x2bb717,_0x31de73,_0x3ed708,_0xe62659?_0x579658['getNode']():g['EMPTY_NODE'],_0xe62659);return Ou(_0x55ce2e);}function ht(_0x4ac89f,_0x1af857){return Qo(_0x1af857,_0x4ac89f['syncPointTree_'],null,Mn(_0x4ac89f['pendingWriteTree_'],w()));}function Qo(_0x890ce4,_0x1f83a9,_0x47b4e4,_0x50f168){if(v(_0x890ce4['path']))return Jo(_0x890ce4,_0x1f83a9,_0x47b4e4,_0x50f168);{const _0x4b59ec=_0x1f83a9['get'](w());_0x47b4e4==null&&_0x4b59ec!=null&&(_0x47b4e4=Ee(_0x4b59ec,w()));let _0x489f45=[];const _0x1fd4ad=y(_0x890ce4['path']),_0x4f344c=_0x890ce4['operationForChild'](_0x1fd4ad),_0x3fae5f=_0x1f83a9['children']['get'](_0x1fd4ad);if(_0x3fae5f&&_0x4f344c){const _0x2ccbac=_0x47b4e4?_0x47b4e4['getImmediateChild'](_0x1fd4ad):null,_0x408970=Wo(_0x50f168,_0x1fd4ad);_0x489f45=_0x489f45['concat'](Qo(_0x4f344c,_0x3fae5f,_0x2ccbac,_0x408970));}return _0x4b59ec&&(_0x489f45=_0x489f45['concat'](is(_0x4b59ec,_0x890ce4,_0x50f168,_0x47b4e4))),_0x489f45;}}function Jo(_0x4cea91,_0x3cb445,_0x2e12b2,_0x1dba02){const _0x53c775=_0x3cb445['get'](w());_0x2e12b2==null&&_0x53c775!=null&&(_0x2e12b2=Ee(_0x53c775,w()));let _0x4043b3=[];return _0x3cb445['children']['inorderTraversal']((_0x128669,_0x3ac78c)=>{const _0x334445=_0x2e12b2?_0x2e12b2['getImmediateChild'](_0x128669):null,_0x1e141c=Wo(_0x1dba02,_0x128669),_0x211baf=_0x4cea91['operationForChild'](_0x128669);_0x211baf&&(_0x4043b3=_0x4043b3['concat'](Jo(_0x211baf,_0x3ac78c,_0x334445,_0x1e141c)));}),_0x53c775&&(_0x4043b3=_0x4043b3['concat'](is(_0x53c775,_0x4cea91,_0x1dba02,_0x2e12b2))),_0x4043b3;}function Xo(_0x27e8c5,_0x33ef31){const _0x4a56b8=_0x33ef31['query'],_0xb15374=Mt(_0x27e8c5,_0x4a56b8);return{'hashFn':()=>(Pu(_0x33ef31)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x274795=>{if(_0x274795==='ok')return _0xb15374?ju(_0x27e8c5,_0x4a56b8['_path'],_0xb15374):zu(_0x27e8c5,_0x4a56b8['_path']);{const _0x1b09d8=ql(_0x274795,_0x4a56b8);return wn(_0x27e8c5,_0x4a56b8,null,_0x1b09d8);}}};}function Mt(_0x2e1fc7,_0x1c0f4e){const _0x3c60f5=Fn(_0x1c0f4e);return _0x2e1fc7['queryToTagMap']['get'](_0x3c60f5);}function Fn(_0x1cdb56){return _0x1cdb56['_path']['toString']()+'$'+_0x1cdb56['_queryIdentifier'];}function rs(_0x488423,_0x52f6ac){return _0x488423['tagToQueryMap']['get'](_0x52f6ac);}function os(_0x30da6c){const _0x403d4a=_0x30da6c['indexOf']('$');return f(_0x403d4a!==-0x1&&_0x403d4a<_0x30da6c['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x30da6c['substr'](_0x403d4a+0x1),'path':new C(_0x30da6c['substr'](0x0,_0x403d4a))};}function as(_0x15d983,_0x20c9c7,_0x286a86){const _0x138abc=_0x15d983['syncPointTree_']['get'](_0x20c9c7);f(_0x138abc,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4adcac=Mn(_0x15d983['pendingWriteTree_'],_0x20c9c7);return is(_0x138abc,_0x286a86,_0x4adcac,null);}function Qu(_0x24da1d){return _0x24da1d['fold']((_0xe4fdd8,_0x3a430e,_0x18d05e)=>{if(_0x3a430e&&Te(_0x3a430e))return[Ln(_0x3a430e)];{let _0x5d6f74=[];return _0x3a430e&&(_0x5d6f74=zo(_0x3a430e)),x(_0x18d05e,(_0x1717be,_0x1ea1a4)=>{_0x5d6f74=_0x5d6f74['concat'](_0x1ea1a4);}),_0x5d6f74;}});}function Tt(_0x103330){return _0x103330['_queryParams']['loadsAllData']()&&!_0x103330['_queryParams']['isDefault']()?new(Hu())(_0x103330['_repo'],_0x103330['_path']):_0x103330;}function Ju(_0x16e282,_0x484b67){for(let _0x3f7b43=0x0;_0x3f7b43<_0x484b67['length'];++_0x3f7b43){const _0x3c4c84=_0x484b67[_0x3f7b43];if(!_0x3c4c84['_queryParams']['loadsAllData']()){const _0x43db53=Fn(_0x3c4c84),_0x2ca00b=_0x16e282['queryToTagMap']['get'](_0x43db53);_0x16e282['queryToTagMap']['delete'](_0x43db53),_0x16e282['tagToQueryMap']['delete'](_0x2ca00b);}}}function Xu(){return $u++;}function Zu(_0x344150,_0x18a265,_0x16cebd){const _0x1c0f3e=_0x18a265['_path'],_0x147611=Mt(_0x344150,_0x18a265),_0x4de8fc=Xo(_0x344150,_0x16cebd),_0x43ceb6=_0x344150['listenProvider_']['startListening'](Tt(_0x18a265),_0x147611,_0x4de8fc['hashFn'],_0x4de8fc['onComplete']),_0x1da070=_0x344150['syncPointTree_']['subtree'](_0x1c0f3e);if(_0x147611)f(!Te(_0x1da070['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x64f10a=_0x1da070['fold']((_0x3898a5,_0x2f0e0e,_0x2c6160)=>{if(!v(_0x3898a5)&&_0x2f0e0e&&Te(_0x2f0e0e))return[Ln(_0x2f0e0e)['query']];{let _0x167eb2=[];return _0x2f0e0e&&(_0x167eb2=_0x167eb2['concat'](zo(_0x2f0e0e)['map'](_0x16f366=>_0x16f366['query']))),x(_0x2c6160,(_0x4f17c1,_0x54b13b)=>{_0x167eb2=_0x167eb2['concat'](_0x54b13b);}),_0x167eb2;}});for(let _0x49fb0c=0x0;_0x49fb0c<_0x64f10a['length'];++_0x49fb0c){const _0x3caade=_0x64f10a[_0x49fb0c];_0x344150['listenProvider_']['stopListening'](Tt(_0x3caade),Mt(_0x344150,_0x3caade));}}return _0x43ceb6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x5c0c59){this['node_']=_0x5c0c59;}['getImmediateChild'](_0x1e3aba){const _0x591b6f=this['node_']['getImmediateChild'](_0x1e3aba);return new cs(_0x591b6f);}['node'](){return this['node_'];}}class ls{constructor(_0xf4dc1a,_0x280ec3){this['syncTree_']=_0xf4dc1a,this['path_']=_0x280ec3;}['getImmediateChild'](_0x4d6c97){const _0x3c179e=A(this['path_'],_0x4d6c97);return new ls(this['syncTree_'],_0x3c179e);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0xb0723c){return _0xb0723c=_0xb0723c||{},_0xb0723c['timestamp']=_0xb0723c['timestamp']||new Date()['getTime'](),_0xb0723c;},fr=function(_0x18374c,_0x20bf1b,_0x238227){if(!_0x18374c||typeof _0x18374c!='object')return _0x18374c;if(f('.sv'in _0x18374c,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x18374c['.sv']=='string')return td(_0x18374c['.sv'],_0x20bf1b,_0x238227);if(typeof _0x18374c['.sv']=='object')return nd(_0x18374c['.sv'],_0x20bf1b);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x18374c,null,0x2));},td=function(_0x29870a,_0x36ea1f,_0x4b08c3){switch(_0x29870a){case'timestamp':return _0x4b08c3['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x29870a);}},nd=function(_0x47176d,_0x2d0d05,_0x7a2673){_0x47176d['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x47176d,null,0x2));const _0x447c80=_0x47176d['increment'];typeof _0x447c80!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x447c80);const _0x96ae=_0x2d0d05['node']();if(f(_0x96ae!==null&&typeof _0x96ae<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x96ae['isLeafNode']())return _0x447c80;const _0x43a02a=_0x96ae['getValue']();return typeof _0x43a02a!='number'?_0x447c80:_0x43a02a+_0x447c80;},Zo=function(_0x3c73a5,_0x1646b5,_0x1ff34f,_0x17d3cb){return us(_0x1646b5,new ls(_0x1ff34f,_0x3c73a5),_0x17d3cb);},hs=function(_0x13a8db,_0x44ffea,_0x2be096){return us(_0x13a8db,new cs(_0x44ffea),_0x2be096);};function us(_0x3dbe7e,_0x18a63c,_0x1a8dc5){const _0x14a288=_0x3dbe7e['getPriority']()['val'](),_0x7a90f1=fr(_0x14a288,_0x18a63c['getImmediateChild']('.priority'),_0x1a8dc5);let _0x2a1d6f;if(_0x3dbe7e['isLeafNode']()){const _0x4b202a=_0x3dbe7e,_0x5cfe34=fr(_0x4b202a['getValue'](),_0x18a63c,_0x1a8dc5);return _0x5cfe34!==_0x4b202a['getValue']()||_0x7a90f1!==_0x4b202a['getPriority']()['val']()?new D(_0x5cfe34,N(_0x7a90f1)):_0x3dbe7e;}else{const _0x4c9ffd=_0x3dbe7e;return _0x2a1d6f=_0x4c9ffd,_0x7a90f1!==_0x4c9ffd['getPriority']()['val']()&&(_0x2a1d6f=_0x2a1d6f['updatePriority'](new D(_0x7a90f1))),_0x4c9ffd['forEachChild'](R,(_0x288e38,_0x43cef1)=>{const _0x2925fd=us(_0x43cef1,_0x18a63c['getImmediateChild'](_0x288e38),_0x1a8dc5);_0x2925fd!==_0x43cef1&&(_0x2a1d6f=_0x2a1d6f['updateImmediateChild'](_0x288e38,_0x2925fd));}),_0x2a1d6f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x570d44='',_0x1fcb8d=null,_0x25cce8={'children':{},'childCount':0x0}){this['name']=_0x570d44,this['parent']=_0x1fcb8d,this['node']=_0x25cce8;}}function Un(_0xef1e62,_0x2d22ea){let _0x425271=_0x2d22ea instanceof C?_0x2d22ea:new C(_0x2d22ea),_0x562754=_0xef1e62,_0x390d8f=y(_0x425271);for(;_0x390d8f!==null;){const _0x2f58df=Oe(_0x562754['node']['children'],_0x390d8f)||{'children':{},'childCount':0x0};_0x562754=new ds(_0x390d8f,_0x562754,_0x2f58df),_0x425271=b(_0x425271),_0x390d8f=y(_0x425271);}return _0x562754;}function Ge(_0x2e53b7){return _0x2e53b7['node']['value'];}function fs(_0x31c1f2,_0x2ffbb0){_0x31c1f2['node']['value']=_0x2ffbb0,Ri(_0x31c1f2);}function ea(_0x468cab){return _0x468cab['node']['childCount']>0x0;}function id(_0x1e80c0){return Ge(_0x1e80c0)===void 0x0&&!ea(_0x1e80c0);}function Wn(_0x51d8d8,_0x7fd2a1){x(_0x51d8d8['node']['children'],(_0x11a1c5,_0x1ea8cc)=>{_0x7fd2a1(new ds(_0x11a1c5,_0x51d8d8,_0x1ea8cc));});}function ta(_0x54b0c5,_0x42765f,_0x406380,_0x22cea4){_0x406380&&_0x42765f(_0x54b0c5),Wn(_0x54b0c5,_0x557737=>{ta(_0x557737,_0x42765f,!0x0);});}function sd(_0x32f97d,_0xb5a1c8,_0x560aed){let _0x11280f=_0x32f97d['parent'];for(;_0x11280f!==null;){if(_0xb5a1c8(_0x11280f))return!0x0;_0x11280f=_0x11280f['parent'];}return!0x1;}function Gt(_0x34b029){return new C(_0x34b029['parent']===null?_0x34b029['name']:Gt(_0x34b029['parent'])+'/'+_0x34b029['name']);}function Ri(_0x4cde3d){_0x4cde3d['parent']!==null&&rd(_0x4cde3d['parent'],_0x4cde3d['name'],_0x4cde3d);}function rd(_0xb365c3,_0x414ce0,_0x4b85f7){const _0x41d31c=id(_0x4b85f7),_0x5018e7=Y(_0xb365c3['node']['children'],_0x414ce0);_0x41d31c&&_0x5018e7?(delete _0xb365c3['node']['children'][_0x414ce0],_0xb365c3['node']['childCount']--,Ri(_0xb365c3)):!_0x41d31c&&!_0x5018e7&&(_0xb365c3['node']['children'][_0x414ce0]=_0x4b85f7['node'],_0xb365c3['node']['childCount']++,Ri(_0xb365c3));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x44e45f){return typeof _0x44e45f=='string'&&_0x44e45f['length']!==0x0&&!od['test'](_0x44e45f);},na=function(_0x49632d){return typeof _0x49632d=='string'&&_0x49632d['length']!==0x0&&!ad['test'](_0x49632d);},cd=function(_0x54c7ef){return _0x54c7ef&&(_0x54c7ef=_0x54c7ef['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x54c7ef);},Cn=function(_0x365cb4){return _0x365cb4===null||typeof _0x365cb4=='string'||typeof _0x365cb4=='number'&&!Wi(_0x365cb4)||_0x365cb4&&typeof _0x365cb4=='object'&&Y(_0x365cb4,'.sv');},qt=function(_0x4d769b,_0x13960,_0x21c6f5,_0x3dd1fc){_0x3dd1fc&&_0x13960===void 0x0||zt(Nn(_0x4d769b,'value'),_0x13960,_0x21c6f5);},zt=function(_0x47b275,_0x4e2b56,_0xdfb9b1){const _0x4d4548=_0xdfb9b1 instanceof C?new Sh(_0xdfb9b1,_0x47b275):_0xdfb9b1;if(_0x4e2b56===void 0x0)throw new Error(_0x47b275+'contains\x20undefined\x20'+Ne(_0x4d4548));if(typeof _0x4e2b56=='function')throw new Error(_0x47b275+'contains\x20a\x20function\x20'+Ne(_0x4d4548)+'\x20with\x20contents\x20=\x20'+_0x4e2b56['toString']());if(Wi(_0x4e2b56))throw new Error(_0x47b275+'contains\x20'+_0x4e2b56['toString']()+'\x20'+Ne(_0x4d4548));if(typeof _0x4e2b56=='string'&&_0x4e2b56['length']>oi/0x3&&Pn(_0x4e2b56)>oi)throw new Error(_0x47b275+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x4d4548)+'\x20(\x27'+_0x4e2b56['substring'](0x0,0x32)+'...\x27)');if(_0x4e2b56&&typeof _0x4e2b56=='object'){let _0x2a9f1c=!0x1,_0x2bb56a=!0x1;if(x(_0x4e2b56,(_0x5be8f5,_0x68b591)=>{if(_0x5be8f5==='.value')_0x2a9f1c=!0x0;else{if(_0x5be8f5!=='.priority'&&_0x5be8f5!=='.sv'&&(_0x2bb56a=!0x0,!ps(_0x5be8f5)))throw new Error(_0x47b275+'\x20contains\x20an\x20invalid\x20key\x20('+_0x5be8f5+')\x20'+Ne(_0x4d4548)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x4d4548,_0x5be8f5),zt(_0x47b275,_0x68b591,_0x4d4548),Rh(_0x4d4548);}),_0x2a9f1c&&_0x2bb56a)throw new Error(_0x47b275+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x4d4548)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x30c48c,_0x317188){let _0x510569,_0x13775e;for(_0x510569=0x0;_0x510569<_0x317188['length'];_0x510569++){_0x13775e=_0x317188[_0x510569];const _0x3506b1=kt(_0x13775e);for(let _0x10c17c=0x0;_0x10c17c<_0x3506b1['length'];_0x10c17c++)if(!(_0x3506b1[_0x10c17c]==='.priority'&&_0x10c17c===_0x3506b1['length']-0x1)){if(!ps(_0x3506b1[_0x10c17c]))throw new Error(_0x30c48c+'contains\x20an\x20invalid\x20key\x20('+_0x3506b1[_0x10c17c]+')\x20in\x20path\x20'+_0x13775e['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x317188['sort'](Th);let _0x54c5b2=null;for(_0x510569=0x0;_0x510569<_0x317188['length'];_0x510569++){if(_0x13775e=_0x317188[_0x510569],_0x54c5b2!==null&&$(_0x54c5b2,_0x13775e))throw new Error(_0x30c48c+'contains\x20a\x20path\x20'+_0x54c5b2['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x13775e['toString']());_0x54c5b2=_0x13775e;}},hd=function(_0x3dc6ff,_0x2b28d1,_0x1428e0,_0x3b5d81){const _0x44936f=Nn(_0x3dc6ff,'values');if(!(_0x2b28d1&&typeof _0x2b28d1=='object')||Array['isArray'](_0x2b28d1))throw new Error(_0x44936f+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1a5b01=[];x(_0x2b28d1,(_0x39161d,_0x1c953f)=>{const _0x448d50=new C(_0x39161d);if(zt(_0x44936f,_0x1c953f,A(_0x1428e0,_0x448d50)),Gi(_0x448d50)==='.priority'&&!Cn(_0x1c953f))throw new Error(_0x44936f+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x448d50['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1a5b01['push'](_0x448d50);}),ld(_0x44936f,_0x1a5b01);},_s=function(_0x244ccf,_0x1898e8,_0x4f3696,_0x11d47c){if(!na(_0x4f3696))throw new Error(Nn(_0x244ccf,_0x1898e8)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4f3696+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x13f4ac,_0x34a062,_0x91d2b7,_0xe3ff29){_0x91d2b7&&(_0x91d2b7=_0x91d2b7['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x13f4ac,_0x34a062,_0x91d2b7);},gs=function(_0x25fb37,_0x4de246){if(y(_0x4de246)==='.info')throw new Error(_0x25fb37+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x5f0f05,_0x41be94){const _0x1db263=_0x41be94['path']['toString']();if(typeof _0x41be94['repoInfo']['host']!='string'||_0x41be94['repoInfo']['host']['length']===0x0||!ps(_0x41be94['repoInfo']['namespace'])&&_0x41be94['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1db263['length']!==0x0&&!cd(_0x1db263))throw new Error(Nn(_0x5f0f05,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x4f4131,_0x1412e5){let _0x18e64d=null;for(let _0x511b51=0x0;_0x511b51<_0x1412e5['length'];_0x511b51++){const _0x58a792=_0x1412e5[_0x511b51],_0x5f5720=_0x58a792['getPath']();_0x18e64d!==null&&!qi(_0x5f5720,_0x18e64d['path'])&&(_0x4f4131['eventLists_']['push'](_0x18e64d),_0x18e64d=null),_0x18e64d===null&&(_0x18e64d={'events':[],'path':_0x5f5720}),_0x18e64d['events']['push'](_0x58a792);}_0x18e64d&&_0x4f4131['eventLists_']['push'](_0x18e64d);}function ia(_0x3c36e6,_0x54505c,_0x4b6e1c){Bn(_0x3c36e6,_0x4b6e1c),sa(_0x3c36e6,_0x164791=>qi(_0x164791,_0x54505c));}function V(_0x3a2570,_0x45df6e,_0x1342bb){Bn(_0x3a2570,_0x1342bb),sa(_0x3a2570,_0xf2522e=>$(_0xf2522e,_0x45df6e)||$(_0x45df6e,_0xf2522e));}function sa(_0x2723c5,_0x18be55){_0x2723c5['recursionDepth_']++;let _0x3ed772=!0x0;for(let _0x54423d=0x0;_0x54423d<_0x2723c5['eventLists_']['length'];_0x54423d++){const _0x1bd526=_0x2723c5['eventLists_'][_0x54423d];if(_0x1bd526){const _0x3a2e2c=_0x1bd526['path'];_0x18be55(_0x3a2e2c)?(pd(_0x2723c5['eventLists_'][_0x54423d]),_0x2723c5['eventLists_'][_0x54423d]=null):_0x3ed772=!0x1;}}_0x3ed772&&(_0x2723c5['eventLists_']=[]),_0x2723c5['recursionDepth_']--;}function pd(_0x52ad84){for(let _0x1d29a8=0x0;_0x1d29a8<_0x52ad84['events']['length'];_0x1d29a8++){const _0x256579=_0x52ad84['events'][_0x1d29a8];if(_0x256579!==null){_0x52ad84['events'][_0x1d29a8]=null;const _0x1f33c2=_0x256579['getEventRunner']();Et&&L('event:\x20'+_0x256579['toString']()),lt(_0x1f33c2);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x28eda3,_0x3e6b4d,_0x27b3e0,_0x1741c4){this['repoInfo_']=_0x28eda3,this['forceRestClient_']=_0x3e6b4d,this['authTokenProvider_']=_0x27b3e0,this['appCheckProvider_']=_0x1741c4,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x3a18e3,_0x293110,_0x19a334){if(_0x3a18e3['stats_']=Hi(_0x3a18e3['repoInfo_']),_0x3a18e3['forceRestClient_']||Yl())_0x3a18e3['server_']=new fn(_0x3a18e3['repoInfo_'],(_0x1b35f4,_0x563285,_0x57d0a4,_0x1dbc76)=>{pr(_0x3a18e3,_0x1b35f4,_0x563285,_0x57d0a4,_0x1dbc76);},_0x3a18e3['authTokenProvider_'],_0x3a18e3['appCheckProvider_']),setTimeout(()=>_r(_0x3a18e3,!0x0),0x0);else{if(typeof _0x19a334<'u'&&_0x19a334!==null){if(typeof _0x19a334!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x19a334);}catch(_0x5c4d15){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5c4d15);}}_0x3a18e3['persistentConnection_']=new ie(_0x3a18e3['repoInfo_'],_0x293110,(_0x443d07,_0x504b2c,_0x3d08c,_0x50a201)=>{pr(_0x3a18e3,_0x443d07,_0x504b2c,_0x3d08c,_0x50a201);},_0x58fca7=>{_r(_0x3a18e3,_0x58fca7);},_0x2feecd=>{yd(_0x3a18e3,_0x2feecd);},_0x3a18e3['authTokenProvider_'],_0x3a18e3['appCheckProvider_'],_0x19a334),_0x3a18e3['server_']=_0x3a18e3['persistentConnection_'];}_0x3a18e3['authTokenProvider_']['addTokenChangeListener'](_0x2ab63f=>{_0x3a18e3['server_']['refreshAuthToken'](_0x2ab63f);}),_0x3a18e3['appCheckProvider_']['addTokenChangeListener'](_0xf6b8da=>{_0x3a18e3['server_']['refreshAppCheckToken'](_0xf6b8da['token']);}),_0x3a18e3['statsReporter_']=eh(_0x3a18e3['repoInfo_'],()=>new eu(_0x3a18e3['stats_'],_0x3a18e3['server_'])),_0x3a18e3['infoData_']=new Yh(),_0x3a18e3['infoSyncTree_']=new dr({'startListening':(_0x3e79db,_0x1cdc13,_0x3b0736,_0x2b2a0b)=>{let _0x230661=[];const _0x5bcae9=_0x3a18e3['infoData_']['getNode'](_0x3e79db['_path']);return _0x5bcae9['isEmpty']()||(_0x230661=$t(_0x3a18e3['infoSyncTree_'],_0x3e79db['_path'],_0x5bcae9),setTimeout(()=>{_0x2b2a0b('ok');},0x0)),_0x230661;},'stopListening':()=>{}}),ms(_0x3a18e3,'connected',!0x1),_0x3a18e3['serverSyncTree_']=new dr({'startListening':(_0x3ca1e7,_0x47efa1,_0x30c870,_0x59ec96)=>(_0x3a18e3['server_']['listen'](_0x3ca1e7,_0x30c870,_0x47efa1,(_0x403e8e,_0xa7f71)=>{const _0x349b42=_0x59ec96(_0x403e8e,_0xa7f71);V(_0x3a18e3['eventQueue_'],_0x3ca1e7['_path'],_0x349b42);}),[]),'stopListening':(_0x4e973f,_0x238ba3)=>{_0x3a18e3['server_']['unlisten'](_0x4e973f,_0x238ba3);}});}function oa(_0x2c89a6){const _0x13a6db=_0x2c89a6['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x13a6db;}function jt(_0x1a38dd){return ed({'timestamp':oa(_0x1a38dd)});}function pr(_0x5ef280,_0x1650b0,_0x53d8d7,_0x4b819c,_0x2b27c9){_0x5ef280['dataUpdateCount']++;const _0x243d41=new C(_0x1650b0);_0x53d8d7=_0x5ef280['interceptServerDataCallback_']?_0x5ef280['interceptServerDataCallback_'](_0x1650b0,_0x53d8d7):_0x53d8d7;let _0xde7725=[];if(_0x2b27c9){if(_0x4b819c){const _0x58668c=ln(_0x53d8d7,_0x23970c=>N(_0x23970c));_0xde7725=Ku(_0x5ef280['serverSyncTree_'],_0x243d41,_0x58668c,_0x2b27c9);}else{const _0x50f936=N(_0x53d8d7);_0xde7725=Yo(_0x5ef280['serverSyncTree_'],_0x243d41,_0x50f936,_0x2b27c9);}}else{if(_0x4b819c){const _0x421b98=ln(_0x53d8d7,_0x2da8aa=>N(_0x2da8aa));_0xde7725=qu(_0x5ef280['serverSyncTree_'],_0x243d41,_0x421b98);}else{const _0x590785=N(_0x53d8d7);_0xde7725=$t(_0x5ef280['serverSyncTree_'],_0x243d41,_0x590785);}}let _0x4ab1c5=_0x243d41;_0xde7725['length']>0x0&&(_0x4ab1c5=st(_0x5ef280,_0x243d41)),V(_0x5ef280['eventQueue_'],_0x4ab1c5,_0xde7725);}function _r(_0x284a46,_0xeb3a8f){ms(_0x284a46,'connected',_0xeb3a8f),_0xeb3a8f===!0x1&&wd(_0x284a46);}function yd(_0x567053,_0x5c1bbb){x(_0x5c1bbb,(_0x46586a,_0x16d982)=>{ms(_0x567053,_0x46586a,_0x16d982);});}function ms(_0x2d63ce,_0x40bdfa,_0x5dcd01){const _0x130f0c=new C('/.info/'+_0x40bdfa),_0x2c83b9=N(_0x5dcd01);_0x2d63ce['infoData_']['updateSnapshot'](_0x130f0c,_0x2c83b9);const _0x4d4bd6=$t(_0x2d63ce['infoSyncTree_'],_0x130f0c,_0x2c83b9);V(_0x2d63ce['eventQueue_'],_0x130f0c,_0x4d4bd6);}function Vn(_0x3afcc2){return _0x3afcc2['nextWriteId_']++;}function vd(_0x36d7aa,_0x3171cc,_0x3cf24d){const _0x51979a=Yu(_0x36d7aa['serverSyncTree_'],_0x3171cc);return _0x51979a!=null?Promise['resolve'](_0x51979a):_0x36d7aa['server_']['get'](_0x3171cc)['then'](_0xc01eb9=>{const _0x4d3bb0=N(_0xc01eb9)['withIndex'](_0x3171cc['_queryParams']['getIndex']());bi(_0x36d7aa['serverSyncTree_'],_0x3171cc,_0x3cf24d,!0x0);let _0x44a136;if(_0x3171cc['_queryParams']['loadsAllData']())_0x44a136=$t(_0x36d7aa['serverSyncTree_'],_0x3171cc['_path'],_0x4d3bb0);else{const _0x36d7d6=Mt(_0x36d7aa['serverSyncTree_'],_0x3171cc);_0x44a136=Yo(_0x36d7aa['serverSyncTree_'],_0x3171cc['_path'],_0x4d3bb0,_0x36d7d6);}return V(_0x36d7aa['eventQueue_'],_0x3171cc['_path'],_0x44a136),wn(_0x36d7aa['serverSyncTree_'],_0x3171cc,_0x3cf24d,null,!0x0),_0x4d3bb0;},_0x563b2c=>(ut(_0x36d7aa,'get\x20for\x20query\x20'+O(_0x3171cc)+'\x20failed:\x20'+_0x563b2c),Promise['reject'](new Error(_0x563b2c))));}function Ed(_0x3e746b,_0x292dab,_0x4a3dc8,_0x4b997e,_0x228e6c){ut(_0x3e746b,'set',{'path':_0x292dab['toString'](),'value':_0x4a3dc8,'priority':_0x4b997e});const _0x37803d=jt(_0x3e746b),_0x5b2874=N(_0x4a3dc8,_0x4b997e),_0x3f85bc=xn(_0x3e746b['serverSyncTree_'],_0x292dab),_0x281a59=hs(_0x5b2874,_0x3f85bc,_0x37803d),_0x1a9b5f=Vn(_0x3e746b),_0x2bfe2e=ss(_0x3e746b['serverSyncTree_'],_0x292dab,_0x281a59,_0x1a9b5f,!0x0);Bn(_0x3e746b['eventQueue_'],_0x2bfe2e),_0x3e746b['server_']['put'](_0x292dab['toString'](),_0x5b2874['val'](!0x0),(_0xedb40e,_0xc33937)=>{const _0x52d79a=_0xedb40e==='ok';_0x52d79a||U('set\x20at\x20'+_0x292dab+'\x20failed:\x20'+_0xedb40e);const _0x5e751f=pe(_0x3e746b['serverSyncTree_'],_0x1a9b5f,!_0x52d79a);V(_0x3e746b['eventQueue_'],_0x292dab,_0x5e751f),Ai(_0x3e746b,_0x228e6c,_0xedb40e,_0xc33937);});const _0x30d7a3=vs(_0x3e746b,_0x292dab);st(_0x3e746b,_0x30d7a3),V(_0x3e746b['eventQueue_'],_0x30d7a3,[]);}function Id(_0x1e14e9,_0x3ebbba,_0x32f75e,_0x5d8cb7){ut(_0x1e14e9,'update',{'path':_0x3ebbba['toString'](),'value':_0x32f75e});let _0xda972b=!0x0;const _0x4bc641=jt(_0x1e14e9),_0xf13855={};if(x(_0x32f75e,(_0x41a5d0,_0x3426e5)=>{_0xda972b=!0x1,_0xf13855[_0x41a5d0]=Zo(A(_0x3ebbba,_0x41a5d0),N(_0x3426e5),_0x1e14e9['serverSyncTree_'],_0x4bc641);}),_0xda972b)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x1e14e9,_0x5d8cb7,'ok',void 0x0);else{const _0x2c98fc=Vn(_0x1e14e9),_0x230ac7=Gu(_0x1e14e9['serverSyncTree_'],_0x3ebbba,_0xf13855,_0x2c98fc);Bn(_0x1e14e9['eventQueue_'],_0x230ac7),_0x1e14e9['server_']['merge'](_0x3ebbba['toString'](),_0x32f75e,(_0xf5d867,_0x258b40)=>{const _0xa51943=_0xf5d867==='ok';_0xa51943||U('update\x20at\x20'+_0x3ebbba+'\x20failed:\x20'+_0xf5d867);const _0x3edf00=pe(_0x1e14e9['serverSyncTree_'],_0x2c98fc,!_0xa51943),_0x2995ca=_0x3edf00['length']>0x0?st(_0x1e14e9,_0x3ebbba):_0x3ebbba;V(_0x1e14e9['eventQueue_'],_0x2995ca,_0x3edf00),Ai(_0x1e14e9,_0x5d8cb7,_0xf5d867,_0x258b40);}),x(_0x32f75e,_0x561eb5=>{const _0x28aab0=vs(_0x1e14e9,A(_0x3ebbba,_0x561eb5));st(_0x1e14e9,_0x28aab0);}),V(_0x1e14e9['eventQueue_'],_0x3ebbba,[]);}}function wd(_0x477123){ut(_0x477123,'onDisconnectEvents');const _0xd9487=jt(_0x477123),_0x4022f2=pn();Ei(_0x477123['onDisconnect_'],w(),(_0x86e47c,_0x4c15e3)=>{const _0x2dc4c0=Zo(_0x86e47c,_0x4c15e3,_0x477123['serverSyncTree_'],_0xd9487);Mo(_0x4022f2,_0x86e47c,_0x2dc4c0);});let _0x25c299=[];Ei(_0x4022f2,w(),(_0x4ad517,_0x603e4c)=>{_0x25c299=_0x25c299['concat']($t(_0x477123['serverSyncTree_'],_0x4ad517,_0x603e4c));const _0x45db63=vs(_0x477123,_0x4ad517);st(_0x477123,_0x45db63);}),_0x477123['onDisconnect_']=pn(),V(_0x477123['eventQueue_'],w(),_0x25c299);}function Cd(_0x263403,_0x2d6872,_0x340f87){let _0x191e9f;y(_0x2d6872['_path'])==='.info'?_0x191e9f=bi(_0x263403['infoSyncTree_'],_0x2d6872,_0x340f87):_0x191e9f=bi(_0x263403['serverSyncTree_'],_0x2d6872,_0x340f87),ia(_0x263403['eventQueue_'],_0x2d6872['_path'],_0x191e9f);}function Td(_0x1a653f,_0x15554b,_0xf76e99){let _0xdd8a1a;y(_0x15554b['_path'])==='.info'?_0xdd8a1a=wn(_0x1a653f['infoSyncTree_'],_0x15554b,_0xf76e99):_0xdd8a1a=wn(_0x1a653f['serverSyncTree_'],_0x15554b,_0xf76e99),ia(_0x1a653f['eventQueue_'],_0x15554b['_path'],_0xdd8a1a);}function aa(_0x5bc0f5){_0x5bc0f5['persistentConnection_']&&_0x5bc0f5['persistentConnection_']['interrupt'](ra);}function Sd(_0x49ba11){_0x49ba11['persistentConnection_']&&_0x49ba11['persistentConnection_']['resume'](ra);}function ut(_0x8c3ac0,..._0x305717){let _0x17d2f0='';_0x8c3ac0['persistentConnection_']&&(_0x17d2f0=_0x8c3ac0['persistentConnection_']['id']+':'),L(_0x17d2f0,..._0x305717);}function Ai(_0x78efbd,_0x19bb4c,_0xc154ec,_0x5c8e0b){_0x19bb4c&&lt(()=>{if(_0xc154ec==='ok')_0x19bb4c(null);else{const _0x48f86b=(_0xc154ec||'error')['toUpperCase']();let _0x45caeb=_0x48f86b;_0x5c8e0b&&(_0x45caeb+=':\x20'+_0x5c8e0b);const _0x5f5c0b=new Error(_0x45caeb);_0x5f5c0b['code']=_0x48f86b,_0x19bb4c(_0x5f5c0b);}});}function bd(_0x52f381,_0x4a8751,_0xcab878,_0x4b77e3,_0x142c23,_0xbca7d0){ut(_0x52f381,'transaction\x20on\x20'+_0x4a8751);const _0x40e9ae={'path':_0x4a8751,'update':_0xcab878,'onComplete':_0x4b77e3,'status':null,'order':to(),'applyLocally':_0xbca7d0,'retryCount':0x0,'unwatcher':_0x142c23,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x1f6630=ys(_0x52f381,_0x4a8751,void 0x0);_0x40e9ae['currentInputSnapshot']=_0x1f6630;const _0x284e5b=_0x40e9ae['update'](_0x1f6630['val']());if(_0x284e5b===void 0x0)_0x40e9ae['unwatcher'](),_0x40e9ae['currentOutputSnapshotRaw']=null,_0x40e9ae['currentOutputSnapshotResolved']=null,_0x40e9ae['onComplete']&&_0x40e9ae['onComplete'](null,!0x1,_0x40e9ae['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x284e5b,_0x40e9ae['path']),_0x40e9ae['status']=0x0;const _0x5c9464=Un(_0x52f381['transactionQueueTree_'],_0x4a8751),_0x222fbf=Ge(_0x5c9464)||[];_0x222fbf['push'](_0x40e9ae),fs(_0x5c9464,_0x222fbf);let _0x3f9143;typeof _0x284e5b=='object'&&_0x284e5b!==null&&Y(_0x284e5b,'.priority')?(_0x3f9143=Oe(_0x284e5b,'.priority'),f(Cn(_0x3f9143),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3f9143=(xn(_0x52f381['serverSyncTree_'],_0x4a8751)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x420bdc=jt(_0x52f381),_0xd0afdb=N(_0x284e5b,_0x3f9143),_0x324a5c=hs(_0xd0afdb,_0x1f6630,_0x420bdc);_0x40e9ae['currentOutputSnapshotRaw']=_0xd0afdb,_0x40e9ae['currentOutputSnapshotResolved']=_0x324a5c,_0x40e9ae['currentWriteId']=Vn(_0x52f381);const _0x13e9f4=ss(_0x52f381['serverSyncTree_'],_0x4a8751,_0x324a5c,_0x40e9ae['currentWriteId'],_0x40e9ae['applyLocally']);V(_0x52f381['eventQueue_'],_0x4a8751,_0x13e9f4),Hn(_0x52f381,_0x52f381['transactionQueueTree_']);}}function ys(_0x36a90d,_0x5dca0e,_0x3994f9){return xn(_0x36a90d['serverSyncTree_'],_0x5dca0e,_0x3994f9)||g['EMPTY_NODE'];}function Hn(_0xfb9b4b,_0x57f4bb=_0xfb9b4b['transactionQueueTree_']){if(_0x57f4bb||$n(_0xfb9b4b,_0x57f4bb),Ge(_0x57f4bb)){const _0x57fc44=la(_0xfb9b4b,_0x57f4bb);f(_0x57fc44['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x57fc44['every'](_0x25bbb1=>_0x25bbb1['status']===0x0)&&Rd(_0xfb9b4b,Gt(_0x57f4bb),_0x57fc44);}else ea(_0x57f4bb)&&Wn(_0x57f4bb,_0x595a05=>{Hn(_0xfb9b4b,_0x595a05);});}function Rd(_0x5e7456,_0x23679f,_0x2f0013){const _0x1ac8dd=_0x2f0013['map'](_0x5be3eb=>_0x5be3eb['currentWriteId']),_0x48a8aa=ys(_0x5e7456,_0x23679f,_0x1ac8dd);let _0x25a740=_0x48a8aa;const _0x274c14=_0x48a8aa['hash']();for(let _0x4430b2=0x0;_0x4430b2<_0x2f0013['length'];_0x4430b2++){const _0xc87e=_0x2f0013[_0x4430b2];f(_0xc87e['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0xc87e['status']=0x1,_0xc87e['retryCount']++;const _0x459f78=F(_0x23679f,_0xc87e['path']);_0x25a740=_0x25a740['updateChild'](_0x459f78,_0xc87e['currentOutputSnapshotRaw']);}const _0x2dfec2=_0x25a740['val'](!0x0),_0x972a92=_0x23679f;_0x5e7456['server_']['put'](_0x972a92['toString'](),_0x2dfec2,_0x3c78a5=>{ut(_0x5e7456,'transaction\x20put\x20response',{'path':_0x972a92['toString'](),'status':_0x3c78a5});let _0x5998b2=[];if(_0x3c78a5==='ok'){const _0x1dd05a=[];for(let _0x5dd5bc=0x0;_0x5dd5bc<_0x2f0013['length'];_0x5dd5bc++)_0x2f0013[_0x5dd5bc]['status']=0x2,_0x5998b2=_0x5998b2['concat'](pe(_0x5e7456['serverSyncTree_'],_0x2f0013[_0x5dd5bc]['currentWriteId'])),_0x2f0013[_0x5dd5bc]['onComplete']&&_0x1dd05a['push'](()=>_0x2f0013[_0x5dd5bc]['onComplete'](null,!0x0,_0x2f0013[_0x5dd5bc]['currentOutputSnapshotResolved'])),_0x2f0013[_0x5dd5bc]['unwatcher']();$n(_0x5e7456,Un(_0x5e7456['transactionQueueTree_'],_0x23679f)),Hn(_0x5e7456,_0x5e7456['transactionQueueTree_']),V(_0x5e7456['eventQueue_'],_0x23679f,_0x5998b2);for(let _0x4b6a04=0x0;_0x4b6a04<_0x1dd05a['length'];_0x4b6a04++)lt(_0x1dd05a[_0x4b6a04]);}else{if(_0x3c78a5==='datastale'){for(let _0x11785a=0x0;_0x11785a<_0x2f0013['length'];_0x11785a++)_0x2f0013[_0x11785a]['status']===0x3?_0x2f0013[_0x11785a]['status']=0x4:_0x2f0013[_0x11785a]['status']=0x0;}else{U('transaction\x20at\x20'+_0x972a92['toString']()+'\x20failed:\x20'+_0x3c78a5);for(let _0x26dbeb=0x0;_0x26dbeb<_0x2f0013['length'];_0x26dbeb++)_0x2f0013[_0x26dbeb]['status']=0x4,_0x2f0013[_0x26dbeb]['abortReason']=_0x3c78a5;}st(_0x5e7456,_0x23679f);}},_0x274c14);}function st(_0x4e9d11,_0x1338d0){const _0x1dce9d=ca(_0x4e9d11,_0x1338d0),_0x3bd3ff=Gt(_0x1dce9d),_0x4ca542=la(_0x4e9d11,_0x1dce9d);return Ad(_0x4e9d11,_0x4ca542,_0x3bd3ff),_0x3bd3ff;}function Ad(_0x4c9a85,_0x41df1f,_0x54de6e){if(_0x41df1f['length']===0x0)return;const _0x1387fa=[];let _0x5c2aa9=[];const _0x2d360d=_0x41df1f['filter'](_0x5c68cc=>_0x5c68cc['status']===0x0)['map'](_0x30a68c=>_0x30a68c['currentWriteId']);for(let _0x4a5a17=0x0;_0x4a5a17<_0x41df1f['length'];_0x4a5a17++){const _0x2686b0=_0x41df1f[_0x4a5a17],_0x24b24d=F(_0x54de6e,_0x2686b0['path']);let _0x5d8ec1=!0x1,_0x49f6e9;if(f(_0x24b24d!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2686b0['status']===0x4)_0x5d8ec1=!0x0,_0x49f6e9=_0x2686b0['abortReason'],_0x5c2aa9=_0x5c2aa9['concat'](pe(_0x4c9a85['serverSyncTree_'],_0x2686b0['currentWriteId'],!0x0));else{if(_0x2686b0['status']===0x0){if(_0x2686b0['retryCount']>=_d)_0x5d8ec1=!0x0,_0x49f6e9='maxretry',_0x5c2aa9=_0x5c2aa9['concat'](pe(_0x4c9a85['serverSyncTree_'],_0x2686b0['currentWriteId'],!0x0));else{const _0x49b709=ys(_0x4c9a85,_0x2686b0['path'],_0x2d360d);_0x2686b0['currentInputSnapshot']=_0x49b709;const _0x18d97d=_0x41df1f[_0x4a5a17]['update'](_0x49b709['val']());if(_0x18d97d!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x18d97d,_0x2686b0['path']);let _0x53bd67=N(_0x18d97d);typeof _0x18d97d=='object'&&_0x18d97d!=null&&Y(_0x18d97d,'.priority')||(_0x53bd67=_0x53bd67['updatePriority'](_0x49b709['getPriority']()));const _0xc7d8d=_0x2686b0['currentWriteId'],_0x3c8453=jt(_0x4c9a85),_0x475fd0=hs(_0x53bd67,_0x49b709,_0x3c8453);_0x2686b0['currentOutputSnapshotRaw']=_0x53bd67,_0x2686b0['currentOutputSnapshotResolved']=_0x475fd0,_0x2686b0['currentWriteId']=Vn(_0x4c9a85),_0x2d360d['splice'](_0x2d360d['indexOf'](_0xc7d8d),0x1),_0x5c2aa9=_0x5c2aa9['concat'](ss(_0x4c9a85['serverSyncTree_'],_0x2686b0['path'],_0x475fd0,_0x2686b0['currentWriteId'],_0x2686b0['applyLocally'])),_0x5c2aa9=_0x5c2aa9['concat'](pe(_0x4c9a85['serverSyncTree_'],_0xc7d8d,!0x0));}else _0x5d8ec1=!0x0,_0x49f6e9='nodata',_0x5c2aa9=_0x5c2aa9['concat'](pe(_0x4c9a85['serverSyncTree_'],_0x2686b0['currentWriteId'],!0x0));}}}V(_0x4c9a85['eventQueue_'],_0x54de6e,_0x5c2aa9),_0x5c2aa9=[],_0x5d8ec1&&(_0x41df1f[_0x4a5a17]['status']=0x2,function(_0x5ebe24){setTimeout(_0x5ebe24,Math['floor'](0x0));}(_0x41df1f[_0x4a5a17]['unwatcher']),_0x41df1f[_0x4a5a17]['onComplete']&&(_0x49f6e9==='nodata'?_0x1387fa['push'](()=>_0x41df1f[_0x4a5a17]['onComplete'](null,!0x1,_0x41df1f[_0x4a5a17]['currentInputSnapshot'])):_0x1387fa['push'](()=>_0x41df1f[_0x4a5a17]['onComplete'](new Error(_0x49f6e9),!0x1,null))));}$n(_0x4c9a85,_0x4c9a85['transactionQueueTree_']);for(let _0x70810c=0x0;_0x70810c<_0x1387fa['length'];_0x70810c++)lt(_0x1387fa[_0x70810c]);Hn(_0x4c9a85,_0x4c9a85['transactionQueueTree_']);}function ca(_0xfceb49,_0x64d206){let _0x5546d1,_0x4fe246=_0xfceb49['transactionQueueTree_'];for(_0x5546d1=y(_0x64d206);_0x5546d1!==null&&Ge(_0x4fe246)===void 0x0;)_0x4fe246=Un(_0x4fe246,_0x5546d1),_0x64d206=b(_0x64d206),_0x5546d1=y(_0x64d206);return _0x4fe246;}function la(_0x5f48a0,_0x3d44fc){const _0x2cc333=[];return ha(_0x5f48a0,_0x3d44fc,_0x2cc333),_0x2cc333['sort']((_0x3c39f4,_0x16f305)=>_0x3c39f4['order']-_0x16f305['order']),_0x2cc333;}function ha(_0x4f64de,_0x84b25c,_0x11f3ec){const _0x34bb3c=Ge(_0x84b25c);if(_0x34bb3c){for(let _0x48482f=0x0;_0x48482f<_0x34bb3c['length'];_0x48482f++)_0x11f3ec['push'](_0x34bb3c[_0x48482f]);}Wn(_0x84b25c,_0xd414d1=>{ha(_0x4f64de,_0xd414d1,_0x11f3ec);});}function $n(_0x309d7a,_0x496193){const _0x9bade5=Ge(_0x496193);if(_0x9bade5){let _0x46c1dd=0x0;for(let _0x23827b=0x0;_0x23827b<_0x9bade5['length'];_0x23827b++)_0x9bade5[_0x23827b]['status']!==0x2&&(_0x9bade5[_0x46c1dd]=_0x9bade5[_0x23827b],_0x46c1dd++);_0x9bade5['length']=_0x46c1dd,fs(_0x496193,_0x9bade5['length']>0x0?_0x9bade5:void 0x0);}Wn(_0x496193,_0x57aacb=>{$n(_0x309d7a,_0x57aacb);});}function vs(_0x457334,_0x44b174){const _0xbdc696=Gt(ca(_0x457334,_0x44b174)),_0x5d5ae5=Un(_0x457334['transactionQueueTree_'],_0x44b174);return sd(_0x5d5ae5,_0x4ab5a5=>{ai(_0x457334,_0x4ab5a5);}),ai(_0x457334,_0x5d5ae5),ta(_0x5d5ae5,_0x33ae37=>{ai(_0x457334,_0x33ae37);}),_0xbdc696;}function ai(_0x5dce09,_0x3bfe3c){const _0x43013a=Ge(_0x3bfe3c);if(_0x43013a){const _0x33e1c0=[];let _0x4f68ec=[],_0x447e51=-0x1;for(let _0x6300da=0x0;_0x6300da<_0x43013a['length'];_0x6300da++)_0x43013a[_0x6300da]['status']===0x3||(_0x43013a[_0x6300da]['status']===0x1?(f(_0x447e51===_0x6300da-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x447e51=_0x6300da,_0x43013a[_0x6300da]['status']=0x3,_0x43013a[_0x6300da]['abortReason']='set'):(f(_0x43013a[_0x6300da]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x43013a[_0x6300da]['unwatcher'](),_0x4f68ec=_0x4f68ec['concat'](pe(_0x5dce09['serverSyncTree_'],_0x43013a[_0x6300da]['currentWriteId'],!0x0)),_0x43013a[_0x6300da]['onComplete']&&_0x33e1c0['push'](_0x43013a[_0x6300da]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x447e51===-0x1?fs(_0x3bfe3c,void 0x0):_0x43013a['length']=_0x447e51+0x1,V(_0x5dce09['eventQueue_'],Gt(_0x3bfe3c),_0x4f68ec);for(let _0x852e3f=0x0;_0x852e3f<_0x33e1c0['length'];_0x852e3f++)lt(_0x33e1c0[_0x852e3f]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x350350){let _0xb8c0e7='';const _0x494da9=_0x350350['split']('/');for(let _0x328621=0x0;_0x328621<_0x494da9['length'];_0x328621++)if(_0x494da9[_0x328621]['length']>0x0){let _0x1f573c=_0x494da9[_0x328621];try{_0x1f573c=decodeURIComponent(_0x1f573c['replace'](/\+/g,'\x20'));}catch{}_0xb8c0e7+='/'+_0x1f573c;}return _0xb8c0e7;}function Nd(_0x487760){const _0x920021={};_0x487760['charAt'](0x0)==='?'&&(_0x487760=_0x487760['substring'](0x1));for(const _0xac3540 of _0x487760['split']('&')){if(_0xac3540['length']===0x0)continue;const _0x10def5=_0xac3540['split']('=');_0x10def5['length']===0x2?_0x920021[decodeURIComponent(_0x10def5[0x0])]=decodeURIComponent(_0x10def5[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0xac3540+'\x27\x20in\x20query\x20\x27'+_0x487760+'\x27');}return _0x920021;}const gr=function(_0xeaee89,_0x363a05){const _0x1e8468=Pd(_0xeaee89),_0x178fe2=_0x1e8468['namespace'];_0x1e8468['domain']==='firebase.com'&&oe(_0x1e8468['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x178fe2||_0x178fe2==='undefined')&&_0x1e8468['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1e8468['secure']||Bl();const _0x221eda=_0x1e8468['scheme']==='ws'||_0x1e8468['scheme']==='wss';return{'repoInfo':new _o(_0x1e8468['host'],_0x1e8468['secure'],_0x178fe2,_0x221eda,_0x363a05,'',_0x178fe2!==_0x1e8468['subdomain']),'path':new C(_0x1e8468['pathString'])};},Pd=function(_0x42e1c7){let _0x1010f8='',_0x298666='',_0x2c2afa='',_0x4fa558='',_0x58b29d='',_0x178adc=!0x0,_0x1a83ce='https',_0x1c3598=0x1bb;if(typeof _0x42e1c7=='string'){let _0x44a472=_0x42e1c7['indexOf']('//');_0x44a472>=0x0&&(_0x1a83ce=_0x42e1c7['substring'](0x0,_0x44a472-0x1),_0x42e1c7=_0x42e1c7['substring'](_0x44a472+0x2));let _0x3ca2f3=_0x42e1c7['indexOf']('/');_0x3ca2f3===-0x1&&(_0x3ca2f3=_0x42e1c7['length']);let _0x1750a4=_0x42e1c7['indexOf']('?');_0x1750a4===-0x1&&(_0x1750a4=_0x42e1c7['length']),_0x1010f8=_0x42e1c7['substring'](0x0,Math['min'](_0x3ca2f3,_0x1750a4)),_0x3ca2f3<_0x1750a4&&(_0x4fa558=kd(_0x42e1c7['substring'](_0x3ca2f3,_0x1750a4)));const _0x1894d0=Nd(_0x42e1c7['substring'](Math['min'](_0x42e1c7['length'],_0x1750a4)));_0x44a472=_0x1010f8['indexOf'](':'),_0x44a472>=0x0?(_0x178adc=_0x1a83ce==='https'||_0x1a83ce==='wss',_0x1c3598=parseInt(_0x1010f8['substring'](_0x44a472+0x1),0xa)):_0x44a472=_0x1010f8['length'];const _0x157d86=_0x1010f8['slice'](0x0,_0x44a472);if(_0x157d86['toLowerCase']()==='localhost')_0x298666='localhost';else{if(_0x157d86['split']('.')['length']<=0x2)_0x298666=_0x157d86;else{const _0x187015=_0x1010f8['indexOf']('.');_0x2c2afa=_0x1010f8['substring'](0x0,_0x187015)['toLowerCase'](),_0x298666=_0x1010f8['substring'](_0x187015+0x1),_0x58b29d=_0x2c2afa;}}'ns'in _0x1894d0&&(_0x58b29d=_0x1894d0['ns']);}return{'host':_0x1010f8,'port':_0x1c3598,'domain':_0x298666,'subdomain':_0x2c2afa,'secure':_0x178adc,'scheme':_0x1a83ce,'pathString':_0x4fa558,'namespace':_0x58b29d};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x5f3939=0x0;const _0x404f59=[];return function(_0x316d3c){const _0x2a0ad7=_0x316d3c===_0x5f3939;_0x5f3939=_0x316d3c;let _0xb594e6;const _0xd5c393=new Array(0x8);for(_0xb594e6=0x7;_0xb594e6>=0x0;_0xb594e6--)_0xd5c393[_0xb594e6]=mr['charAt'](_0x316d3c%0x40),_0x316d3c=Math['floor'](_0x316d3c/0x40);f(_0x316d3c===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x46986d=_0xd5c393['join']('');if(_0x2a0ad7){for(_0xb594e6=0xb;_0xb594e6>=0x0&&_0x404f59[_0xb594e6]===0x3f;_0xb594e6--)_0x404f59[_0xb594e6]=0x0;_0x404f59[_0xb594e6]++;}else{for(_0xb594e6=0x0;_0xb594e6<0xc;_0xb594e6++)_0x404f59[_0xb594e6]=Math['floor'](Math['random']()*0x40);}for(_0xb594e6=0x0;_0xb594e6<0xc;_0xb594e6++)_0x46986d+=mr['charAt'](_0x404f59[_0xb594e6]);return f(_0x46986d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x46986d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x38a37b,_0x3f8e7f,_0xb85080,_0x50f75c){this['eventType']=_0x38a37b,this['eventRegistration']=_0x3f8e7f,this['snapshot']=_0xb85080,this['prevName']=_0x50f75c;}['getPath'](){const _0x5b9687=this['snapshot']['ref'];return this['eventType']==='value'?_0x5b9687['_path']:_0x5b9687['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x1d8195,_0x5b7c5f,_0x1c6934){this['eventRegistration']=_0x1d8195,this['error']=_0x5b7c5f,this['path']=_0x1c6934;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x33d1b8,_0xb7a1fc){this['snapshotCallback']=_0x33d1b8,this['cancelCallback']=_0xb7a1fc;}['onValue'](_0x3387df,_0x439c0e){this['snapshotCallback']['call'](null,_0x3387df,_0x439c0e);}['onCancel'](_0x2de344){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2de344);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x42f86e){return this['snapshotCallback']===_0x42f86e['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x42f86e['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x42f86e['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x56d975,_0x3f670b,_0x5cff1b,_0x1e56da){this['_repo']=_0x56d975,this['_path']=_0x3f670b,this['_queryParams']=_0x5cff1b,this['_orderByCalled']=_0x1e56da;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x573357=nr(this['_queryParams']),_0x55cba6=Bi(_0x573357);return _0x55cba6==='{}'?'default':_0x55cba6;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x472003){if(_0x472003=k(_0x472003),!(_0x472003 instanceof be))return!0x1;const _0x3dcc81=this['_repo']===_0x472003['_repo'],_0x484018=qi(this['_path'],_0x472003['_path']),_0x44b012=this['_queryIdentifier']===_0x472003['_queryIdentifier'];return _0x3dcc81&&_0x484018&&_0x44b012;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x329d95,_0x559651){if(_0x329d95['_orderByCalled']===!0x0)throw new Error(_0x559651+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x434f59){let _0x3b1230=null,_0x52d008=null;if(_0x434f59['hasStart']()&&(_0x3b1230=_0x434f59['getIndexStartValue']()),_0x434f59['hasEnd']()&&(_0x52d008=_0x434f59['getIndexEndValue']()),_0x434f59['getIndex']()===ye){const _0x36ae12='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4cdde5='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x434f59['hasStart']()){if(_0x434f59['getIndexStartName']()!==xe)throw new Error(_0x36ae12);if(typeof _0x3b1230!='string')throw new Error(_0x4cdde5);}if(_0x434f59['hasEnd']()){if(_0x434f59['getIndexEndName']()!==Ie)throw new Error(_0x36ae12);if(typeof _0x52d008!='string')throw new Error(_0x4cdde5);}}else{if(_0x434f59['getIndex']()===R){if(_0x3b1230!=null&&!Cn(_0x3b1230)||_0x52d008!=null&&!Cn(_0x52d008))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x434f59['getIndex']()instanceof Ki||_0x434f59['getIndex']()===Po,'unknown\x20index\x20type.'),_0x3b1230!=null&&typeof _0x3b1230=='object'||_0x52d008!=null&&typeof _0x52d008=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x5da629){if(_0x5da629['hasStart']()&&_0x5da629['hasEnd']()&&_0x5da629['hasLimit']()&&!_0x5da629['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x2c3f2c,_0x30102c){super(_0x2c3f2c,_0x30102c,new Qi(),!0x1);}get['parent'](){const _0x347997=To(this['_path']);return _0x347997===null?null:new Z(this['_repo'],_0x347997);}get['root'](){let _0x521368=this;for(;_0x521368['parent']!==null;)_0x521368=_0x521368['parent'];return _0x521368;}}class rt{constructor(_0x364a46,_0x50d14c,_0x28f958){this['_node']=_0x364a46,this['ref']=_0x50d14c,this['_index']=_0x28f958;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x534aa1){const _0x11325d=new C(_0x534aa1),_0x2e15f3=Lt(this['ref'],_0x534aa1);return new rt(this['_node']['getChild'](_0x11325d),_0x2e15f3,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1712a2){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x38d7b8,_0x219f89)=>_0x1712a2(new rt(_0x219f89,Lt(this['ref'],_0x38d7b8),R)));}['hasChild'](_0x373f8a){const _0x3d1a9d=new C(_0x373f8a);return!this['_node']['getChild'](_0x3d1a9d)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x53ce57,_0x2b3ec9){return _0x53ce57=k(_0x53ce57),_0x53ce57['_checkNotDeleted']('ref'),_0x2b3ec9!==void 0x0?Lt(_0x53ce57['_root'],_0x2b3ec9):_0x53ce57['_root'];}function Lt(_0x4f26ce,_0xf57377){return _0x4f26ce=k(_0x4f26ce),y(_0x4f26ce['_path'])===null?ud('child','path',_0xf57377):_s('child','path',_0xf57377),new Z(_0x4f26ce['_repo'],A(_0x4f26ce['_path'],_0xf57377));}function d_(_0x70db0b,_0x311899){_0x70db0b=k(_0x70db0b),gs('push',_0x70db0b['_path']),qt('push',_0x311899,_0x70db0b['_path'],!0x0);const _0x19cb1d=oa(_0x70db0b['_repo']),_0x2842b1=Od(_0x19cb1d),_0x2ef155=Lt(_0x70db0b,_0x2842b1),_0x1e8225=Lt(_0x70db0b,_0x2842b1);let _0x1c0602;return _0x311899!=null?_0x1c0602=Ld(_0x1e8225,_0x311899)['then'](()=>_0x1e8225):_0x1c0602=Promise['resolve'](_0x1e8225),_0x2ef155['then']=_0x1c0602['then']['bind'](_0x1c0602),_0x2ef155['catch']=_0x1c0602['then']['bind'](_0x1c0602,void 0x0),_0x2ef155;}function Ld(_0x197c28,_0x54d609){_0x197c28=k(_0x197c28),gs('set',_0x197c28['_path']),qt('set',_0x54d609,_0x197c28['_path'],!0x1);const _0x160feb=new Ve();return Ed(_0x197c28['_repo'],_0x197c28['_path'],_0x54d609,null,_0x160feb['wrapCallback'](()=>{})),_0x160feb['promise'];}function f_(_0x4e382c,_0x399306){hd('update',_0x399306,_0x4e382c['_path']);const _0x4c3cf0=new Ve();return Id(_0x4e382c['_repo'],_0x4e382c['_path'],_0x399306,_0x4c3cf0['wrapCallback'](()=>{})),_0x4c3cf0['promise'];}function p_(_0xd872c3){_0xd872c3=k(_0xd872c3);const _0x23dcbd=new ua(()=>{}),_0x26b93c=new qn(_0x23dcbd);return vd(_0xd872c3['_repo'],_0xd872c3,_0x26b93c)['then'](_0x54d7bd=>new rt(_0x54d7bd,new Z(_0xd872c3['_repo'],_0xd872c3['_path']),_0xd872c3['_queryParams']['getIndex']()));}class qn{constructor(_0x4c3522){this['callbackContext']=_0x4c3522;}['respondsTo'](_0xf1f19f){return _0xf1f19f==='value';}['createEvent'](_0x17428b,_0x4d5ddb){const _0x4adea8=_0x4d5ddb['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x17428b['snapshotNode'],new Z(_0x4d5ddb['_repo'],_0x4d5ddb['_path']),_0x4adea8));}['getEventRunner'](_0xc17489){return _0xc17489['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0xc17489['error']):()=>this['callbackContext']['onValue'](_0xc17489['snapshot'],null);}['createCancelEvent'](_0x33dae7,_0x1803ba){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x33dae7,_0x1803ba):null;}['matches'](_0x5e7cc9){return _0x5e7cc9 instanceof qn?!_0x5e7cc9['callbackContext']||!this['callbackContext']?!0x0:_0x5e7cc9['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x2db508,_0x1b745f,_0x49d9b7,_0x5f5582,_0x10a645){const _0x46bbdd=new ua(_0x49d9b7,void 0x0),_0x237bec=new qn(_0x46bbdd);return Cd(_0x2db508['_repo'],_0x2db508,_0x237bec),()=>Td(_0x2db508['_repo'],_0x2db508,_0x237bec);}function Fd(_0x1c5b33,_0x8d816a,_0x25879e,_0x4933b8){return xd(_0x1c5b33,'value',_0x8d816a);}class dt{}class pa extends dt{constructor(_0x2d1dac,_0x29c938){super(),this['_value']=_0x2d1dac,this['_key']=_0x29c938,this['type']='endAt';}['_apply'](_0x10b6f2){qt('endAt',this['_value'],_0x10b6f2['_path'],!0x0);const _0x3a833e=Kh(_0x10b6f2['_queryParams'],this['_value'],this['_key']);if(fa(_0x3a833e),Gn(_0x3a833e),_0x10b6f2['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x10b6f2['_repo'],_0x10b6f2['_path'],_0x3a833e,_0x10b6f2['_orderByCalled']);}}function __(_0x2a0c02,_0x31526b){return new pa(_0x2a0c02,_0x31526b);}class _a extends dt{constructor(_0x4f38b6,_0x3fd872){super(),this['_value']=_0x4f38b6,this['_key']=_0x3fd872,this['type']='startAt';}['_apply'](_0x2217af){qt('startAt',this['_value'],_0x2217af['_path'],!0x0);const _0x123f31=jh(_0x2217af['_queryParams'],this['_value'],this['_key']);if(fa(_0x123f31),Gn(_0x123f31),_0x2217af['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x2217af['_repo'],_0x2217af['_path'],_0x123f31,_0x2217af['_orderByCalled']);}}function g_(_0x1e382c=null,_0x1a6b1d){return new _a(_0x1e382c,_0x1a6b1d);}class Ud extends dt{constructor(_0xb23ec3){super(),this['_limit']=_0xb23ec3,this['type']='limitToFirst';}['_apply'](_0xa981d3){if(_0xa981d3['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0xa981d3['_repo'],_0xa981d3['_path'],zh(_0xa981d3['_queryParams'],this['_limit']),_0xa981d3['_orderByCalled']);}}function m_(_0x1dcc82){if(Math['floor'](_0x1dcc82)!==_0x1dcc82||_0x1dcc82<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x1dcc82);}class Wd extends dt{constructor(_0x57f603){super(),this['_path']=_0x57f603,this['type']='orderByChild';}['_apply'](_0x4ea228){da(_0x4ea228,'orderByChild');const _0x59c819=new C(this['_path']);if(v(_0x59c819))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x377700=new Ki(_0x59c819),_0x1a7d95=Do(_0x4ea228['_queryParams'],_0x377700);return Gn(_0x1a7d95),new be(_0x4ea228['_repo'],_0x4ea228['_path'],_0x1a7d95,!0x0);}}function y_(_0x35335f){if(_0x35335f==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x35335f==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x35335f==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x35335f),new Wd(_0x35335f);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5901ab){da(_0x5901ab,'orderByKey');const _0x1fbfe8=Do(_0x5901ab['_queryParams'],ye);return Gn(_0x1fbfe8),new be(_0x5901ab['_repo'],_0x5901ab['_path'],_0x1fbfe8,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x88856f,_0x33759d){super(),this['_value']=_0x88856f,this['_key']=_0x33759d,this['type']='equalTo';}['_apply'](_0x31d675){if(qt('equalTo',this['_value'],_0x31d675['_path'],!0x1),_0x31d675['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x31d675['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x31d675));}}function E_(_0x1b6da7,_0x1f3fbe){return new Vd(_0x1b6da7,_0x1f3fbe);}function I_(_0x1f9f45,..._0x1ea6b5){let _0x40f608=k(_0x1f9f45);for(const _0xe4a464 of _0x1ea6b5)_0x40f608=_0xe4a464['_apply'](_0x40f608);return _0x40f608;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x90a499,_0xc6afd3,_0x3f5a04,_0x254176){const _0x2215e7=_0xc6afd3['lastIndexOf'](':'),_0x39ff17=_0xc6afd3['substring'](0x0,_0x2215e7),_0x7657ed=Wt(_0x39ff17);_0x90a499['repoInfo_']=new _o(_0xc6afd3,_0x7657ed,_0x90a499['repoInfo_']['namespace'],_0x90a499['repoInfo_']['webSocketOnly'],_0x90a499['repoInfo_']['nodeAdmin'],_0x90a499['repoInfo_']['persistenceKey'],_0x90a499['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x3f5a04),_0x254176&&(_0x90a499['authTokenProvider_']=_0x254176);}function qd(_0x5c33b7,_0x35026a,_0x14e056,_0x4f3a83,_0x2c571e){let _0x5d2846=_0x4f3a83||_0x5c33b7['options']['databaseURL'];_0x5d2846===void 0x0&&(_0x5c33b7['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5c33b7['options']['projectId']),_0x5d2846=_0x5c33b7['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x13cb07=gr(_0x5d2846,_0x2c571e),_0x38cf17=_0x13cb07['repoInfo'],_0x9c2105;typeof process<'u'&&Us&&(_0x9c2105=Us[Hd]),_0x9c2105?(_0x5d2846='http://'+_0x9c2105+'?ns='+_0x38cf17['namespace'],_0x13cb07=gr(_0x5d2846,_0x2c571e),_0x38cf17=_0x13cb07['repoInfo']):_0x13cb07['repoInfo']['secure'];const _0x9be8c3=new Jl(_0x5c33b7['name'],_0x5c33b7['options'],_0x35026a);dd('Invalid\x20Firebase\x20Database\x20URL',_0x13cb07),v(_0x13cb07['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x101b63=jd(_0x38cf17,_0x5c33b7,_0x9be8c3,new Ql(_0x5c33b7,_0x14e056));return new Kd(_0x101b63,_0x5c33b7);}function zd(_0x4db841,_0x24ee43){const _0x2719ff=ki[_0x24ee43];(!_0x2719ff||_0x2719ff[_0x4db841['key']]!==_0x4db841)&&oe('Database\x20'+_0x24ee43+'('+_0x4db841['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x4db841),delete _0x2719ff[_0x4db841['key']];}function jd(_0x478dcf,_0x42b390,_0x63379c,_0x1465a4){let _0x649865=ki[_0x42b390['name']];_0x649865||(_0x649865={},ki[_0x42b390['name']]=_0x649865);let _0x24dde2=_0x649865[_0x478dcf['toURLString']()];return _0x24dde2&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x24dde2=new gd(_0x478dcf,$d,_0x63379c,_0x1465a4),_0x649865[_0x478dcf['toURLString']()]=_0x24dde2,_0x24dde2;}class Kd{constructor(_0x451233,_0x4b1328){this['_repoInternal']=_0x451233,this['app']=_0x4b1328,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x2870e4){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x2870e4+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x258b19=Qr(),_0x528d77){const _0x450d45=Ui(_0x258b19,'database')['getImmediate']({'identifier':_0x528d77});if(!_0x450d45['_instanceStarted']){const _0x2bcb0e=ac('database');_0x2bcb0e&&Yd(_0x450d45,..._0x2bcb0e);}return _0x450d45;}function Yd(_0x382a86,_0x16bce8,_0x665be7,_0x2f78f8={}){_0x382a86=k(_0x382a86),_0x382a86['_checkNotDeleted']('useEmulator');const _0x364cb8=_0x16bce8+':'+_0x665be7,_0x25ddd2=_0x382a86['_repoInternal'];if(_0x382a86['_instanceStarted']){if(_0x364cb8===_0x382a86['_repoInternal']['repoInfo_']['host']&&De(_0x2f78f8,_0x25ddd2['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3b7438;if(_0x25ddd2['repoInfo_']['nodeAdmin'])_0x2f78f8['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3b7438=new tn(tn['OWNER']);else{if(_0x2f78f8['mockUserToken']){const _0x260850=typeof _0x2f78f8['mockUserToken']=='string'?_0x2f78f8['mockUserToken']:cc(_0x2f78f8['mockUserToken'],_0x382a86['app']['options']['projectId']);_0x3b7438=new tn(_0x260850);}}Wt(_0x16bce8)&&jr(_0x16bce8),Gd(_0x25ddd2,_0x364cb8,_0x2f78f8,_0x3b7438);}function C_(_0x27029e){_0x27029e=k(_0x27029e),_0x27029e['_checkNotDeleted']('goOffline'),aa(_0x27029e['_repo']);}function T_(_0x19be93){_0x19be93=k(_0x19be93),_0x19be93['_checkNotDeleted']('goOnline'),Sd(_0x19be93['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x19124c){Ll(ct),et(new Me('database',(_0x23e68d,{instanceIdentifier:_0x2c79ab})=>{const _0x89536a=_0x23e68d['getProvider']('app')['getImmediate'](),_0xb11f83=_0x23e68d['getProvider']('auth-internal'),_0x16eb38=_0x23e68d['getProvider']('app-check-internal');return qd(_0x89536a,_0xb11f83,_0x16eb38,_0x2c79ab);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x19124c),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0xf1fb2a,_0x40c5f7){this['committed']=_0xf1fb2a,this['snapshot']=_0x40c5f7;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x2cb79a,_0x51a57a,_0x1551d4){if(_0x2cb79a=k(_0x2cb79a),gs('Reference.transaction',_0x2cb79a['_path']),_0x2cb79a['key']==='.length'||_0x2cb79a['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x2cb79a['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3353d6=!0x0,_0x2c4f34=new Ve(),_0x3299d1=(_0x3ad9da,_0x2438d5,_0x186471)=>{let _0x15b6e9=null;_0x3ad9da?_0x2c4f34['reject'](_0x3ad9da):(_0x15b6e9=new rt(_0x186471,new Z(_0x2cb79a['_repo'],_0x2cb79a['_path']),R),_0x2c4f34['resolve'](new Xd(_0x2438d5,_0x15b6e9)));},_0x7320f6=Fd(_0x2cb79a,()=>{});return bd(_0x2cb79a['_repo'],_0x2cb79a['_path'],_0x51a57a,_0x3299d1,_0x7320f6,_0x3353d6),_0x2c4f34['promise'];}ie['prototype']['simpleListen']=function(_0x35d97b,_0x163623){this['sendRequest']('q',{'p':_0x35d97b},_0x163623);},ie['prototype']['echo']=function(_0x3f344d,_0x349f1b){this['sendRequest']('echo',{'d':_0x3f344d},_0x349f1b);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x248ca1,..._0x30a75c){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x248ca1,..._0x30a75c);}function nn(_0x24e49d,..._0x43154f){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x24e49d,..._0x43154f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x5a34e0,..._0x2e0e92){throw Es(_0x5a34e0,..._0x2e0e92);}function J(_0x2e66fc,..._0x3f6809){return Es(_0x2e66fc,..._0x3f6809);}function ya(_0x153c23,_0x2e4b44,_0x4f6cf4){const _0x2251ae={...Zd(),[_0x2e4b44]:_0x4f6cf4};return new Ut('auth','Firebase',_0x2251ae)['create'](_0x2e4b44,{'appName':_0x153c23['name']});}function se(_0x29b752){return ya(_0x29b752,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x122e57,..._0x46b0b4){if(typeof _0x122e57!='string'){const _0x155376=_0x46b0b4[0x0],_0x2e9746=[..._0x46b0b4['slice'](0x1)];return _0x2e9746[0x0]&&(_0x2e9746[0x0]['appName']=_0x122e57['name']),_0x122e57['_errorFactory']['create'](_0x155376,..._0x2e9746);}return ma['create'](_0x122e57,..._0x46b0b4);}function m(_0x1c61ef,_0x167e7b,..._0x123066){if(!_0x1c61ef)throw Es(_0x167e7b,..._0x123066);}function te(_0x58d51e){const _0x6d70b2='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x58d51e;throw nn(_0x6d70b2),new Error(_0x6d70b2);}function ae(_0x4f066a,_0xe67181){_0x4f066a||te(_0xe67181);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x1102f4;return typeof self<'u'&&((_0x1102f4=self['location'])==null?void 0x0:_0x1102f4['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x5f5026;return typeof self<'u'&&((_0x5f5026=self['location'])==null?void 0x0:_0x5f5026['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x36b380=navigator;return _0x36b380['languages']&&_0x36b380['languages'][0x0]||_0x36b380['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0xdef7dd,_0x556453){this['shortDelay']=_0xdef7dd,this['longDelay']=_0x556453,ae(_0x556453>_0xdef7dd,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x1a0077,_0x10fd89){ae(_0x1a0077['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x4fa5e8}=_0x1a0077['emulator'];return _0x10fd89?''+_0x4fa5e8+(_0x10fd89['startsWith']('/')?_0x10fd89['slice'](0x1):_0x10fd89):_0x4fa5e8;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x3c600e,_0x449c77,_0x1be8a2){this['fetchImpl']=_0x3c600e,_0x449c77&&(this['headersImpl']=_0x449c77),_0x1be8a2&&(this['responseImpl']=_0x1be8a2);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x4531b1,_0x2f5781){return _0x4531b1['tenantId']&&!_0x2f5781['tenantId']?{..._0x2f5781,'tenantId':_0x4531b1['tenantId']}:_0x2f5781;}async function Ae(_0x22d2f0,_0x36241f,_0x2e6f87,_0xacd0c4,_0x1b3e5d={}){return Ea(_0x22d2f0,_0x1b3e5d,async()=>{let _0x3d93cc={},_0x5b89db={};_0xacd0c4&&(_0x36241f==='GET'?_0x5b89db=_0xacd0c4:_0x3d93cc={'body':JSON['stringify'](_0xacd0c4)});const _0xe4cb51=at({..._0x5b89db,'key':_0x22d2f0['config']['apiKey']})['slice'](0x1),_0x10ad39=await _0x22d2f0['_getAdditionalHeaders']();_0x10ad39['Content-Type']='application/json',_0x22d2f0['languageCode']&&(_0x10ad39['X-Firebase-Locale']=_0x22d2f0['languageCode']);const _0xe62977={'method':_0x36241f,'headers':_0x10ad39,..._0x3d93cc};return lc()||(_0xe62977['referrerPolicy']='strict-origin-when-cross-origin'),_0x22d2f0['emulatorConfig']&&Wt(_0x22d2f0['emulatorConfig']['host'])&&(_0xe62977['credentials']='include'),va['fetch']()(await Ia(_0x22d2f0,_0x22d2f0['config']['apiHost'],_0x2e6f87,_0xe4cb51),_0xe62977);});}async function Ea(_0x5edad4,_0x4264b6,_0x40ef1c){_0x5edad4['_canInitEmulator']=!0x1;const _0x31e2c0={...rf,..._0x4264b6};try{const _0x4d24be=new lf(_0x5edad4),_0x420917=await Promise['race']([_0x40ef1c(),_0x4d24be['promise']]);_0x4d24be['clearNetworkTimeout']();const _0x2e2c22=await _0x420917['json']();if('needConfirmation'in _0x2e2c22)throw en(_0x5edad4,'account-exists-with-different-credential',_0x2e2c22);if(_0x420917['ok']&&!('errorMessage'in _0x2e2c22))return _0x2e2c22;{const _0x3c8f9a=_0x420917['ok']?_0x2e2c22['errorMessage']:_0x2e2c22['error']['message'],[_0x18958a,_0x27da7c]=_0x3c8f9a['split']('\x20:\x20');if(_0x18958a==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x5edad4,'credential-already-in-use',_0x2e2c22);if(_0x18958a==='EMAIL_EXISTS')throw en(_0x5edad4,'email-already-in-use',_0x2e2c22);if(_0x18958a==='USER_DISABLED')throw en(_0x5edad4,'user-disabled',_0x2e2c22);const _0xe69739=_0x31e2c0[_0x18958a]||_0x18958a['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x27da7c)throw ya(_0x5edad4,_0xe69739,_0x27da7c);K(_0x5edad4,_0xe69739);}}catch(_0x472af2){if(_0x472af2 instanceof Se)throw _0x472af2;K(_0x5edad4,'network-request-failed',{'message':String(_0x472af2)});}}async function Yt(_0x2f8197,_0x5aeb0d,_0x2a8b67,_0x58cd12,_0x576fe6={}){const _0x5cd5cf=await Ae(_0x2f8197,_0x5aeb0d,_0x2a8b67,_0x58cd12,_0x576fe6);return'mfaPendingCredential'in _0x5cd5cf&&K(_0x2f8197,'multi-factor-auth-required',{'_serverResponse':_0x5cd5cf}),_0x5cd5cf;}async function Ia(_0x40181d,_0xcd9d2e,_0x16badd,_0x111063){const _0xc544c6=''+_0xcd9d2e+_0x16badd+'?'+_0x111063,_0x4eb3c4=_0x40181d,_0x3d4efc=_0x4eb3c4['config']['emulator']?Is(_0x40181d['config'],_0xc544c6):_0x40181d['config']['apiScheme']+'://'+_0xc544c6;return of['includes'](_0x16badd)&&(await _0x4eb3c4['_persistenceManagerAvailable'],_0x4eb3c4['_getPersistenceType']()==='COOKIE')?_0x4eb3c4['_getPersistence']()['_getFinalTarget'](_0x3d4efc)['toString']():_0x3d4efc;}function cf(_0x59a559){switch(_0x59a559){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x385aef){this['auth']=_0x385aef,this['timer']=null,this['promise']=new Promise((_0x2b4e0a,_0x18a565)=>{this['timer']=setTimeout(()=>_0x18a565(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x210bdd,_0x5c0eb9,_0x241976){const _0x4de08d={'appName':_0x210bdd['name']};_0x241976['email']&&(_0x4de08d['email']=_0x241976['email']),_0x241976['phoneNumber']&&(_0x4de08d['phoneNumber']=_0x241976['phoneNumber']);const _0x33a1fe=J(_0x210bdd,_0x5c0eb9,_0x4de08d);return _0x33a1fe['customData']['_tokenResponse']=_0x241976,_0x33a1fe;}function vr(_0x57c026){return _0x57c026!==void 0x0&&_0x57c026['enterprise']!==void 0x0;}class hf{constructor(_0x5f2807){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5f2807['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5f2807['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5f2807['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x34e9d7){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5dda0d of this['recaptchaEnforcementState'])if(_0x5dda0d['provider']&&_0x5dda0d['provider']===_0x34e9d7)return cf(_0x5dda0d['enforcementState']);return null;}['isProviderEnabled'](_0xa557c1){return this['getProviderEnforcementState'](_0xa557c1)==='ENFORCE'||this['getProviderEnforcementState'](_0xa557c1)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x7ac082,_0x152aed){return Ae(_0x7ac082,'GET','/v2/recaptchaConfig',Re(_0x7ac082,_0x152aed));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x3400f1,_0x475575){return Ae(_0x3400f1,'POST','/v1/accounts:delete',_0x475575);}async function Sn(_0x4e6318,_0x34ca5b){return Ae(_0x4e6318,'POST','/v1/accounts:lookup',_0x34ca5b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x31541a){if(_0x31541a)try{const _0xe43fd9=new Date(Number(_0x31541a));if(!isNaN(_0xe43fd9['getTime']()))return _0xe43fd9['toUTCString']();}catch{}}async function ff(_0x496f0d,_0x2600eb=!0x1){const _0x5bafbc=k(_0x496f0d),_0x2df5d6=await _0x5bafbc['getIdToken'](_0x2600eb),_0x3cc9ab=ws(_0x2df5d6);m(_0x3cc9ab&&_0x3cc9ab['exp']&&_0x3cc9ab['auth_time']&&_0x3cc9ab['iat'],_0x5bafbc['auth'],'internal-error');const _0x218e93=typeof _0x3cc9ab['firebase']=='object'?_0x3cc9ab['firebase']:void 0x0,_0x3d371b=_0x218e93==null?void 0x0:_0x218e93['sign_in_provider'];return{'claims':_0x3cc9ab,'token':_0x2df5d6,'authTime':St(ci(_0x3cc9ab['auth_time'])),'issuedAtTime':St(ci(_0x3cc9ab['iat'])),'expirationTime':St(ci(_0x3cc9ab['exp'])),'signInProvider':_0x3d371b||null,'signInSecondFactor':(_0x218e93==null?void 0x0:_0x218e93['sign_in_second_factor'])||null};}function ci(_0x3abf5e){return Number(_0x3abf5e)*0x3e8;}function ws(_0x4be387){const [_0x31a247,_0x3802b0,_0x432cfa]=_0x4be387['split']('.');if(_0x31a247===void 0x0||_0x3802b0===void 0x0||_0x432cfa===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x7ff4e9=cn(_0x3802b0);return _0x7ff4e9?JSON['parse'](_0x7ff4e9):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x32ca31){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x32ca31==null?void 0x0:_0x32ca31['toString']()),null;}}function Er(_0x5972a0){const _0x1c4cb3=ws(_0x5972a0);return m(_0x1c4cb3,'internal-error'),m(typeof _0x1c4cb3['exp']<'u','internal-error'),m(typeof _0x1c4cb3['iat']<'u','internal-error'),Number(_0x1c4cb3['exp'])-Number(_0x1c4cb3['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x197b34,_0x3d8bf3,_0x31cf76=!0x1){if(_0x31cf76)return _0x3d8bf3;try{return await _0x3d8bf3;}catch(_0x64e8e0){throw _0x64e8e0 instanceof Se&&pf(_0x64e8e0)&&_0x197b34['auth']['currentUser']===_0x197b34&&await _0x197b34['auth']['signOut'](),_0x64e8e0;}}function pf({code:_0x141f9a}){return _0x141f9a==='auth/user-disabled'||_0x141f9a==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0xd431c1){this['user']=_0xd431c1,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x25d3b3){if(_0x25d3b3){const _0x3d272a=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x3d272a;}else{this['errorBackoff']=0x7530;const _0x39de13=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x39de13);}}['schedule'](_0x29b4f5=!0x1){if(!this['isRunning'])return;const _0x5d87e6=this['getInterval'](_0x29b4f5);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5d87e6);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x4d285d){(_0x4d285d==null?void 0x0:_0x4d285d['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x22ba3b,_0x37d538){this['createdAt']=_0x22ba3b,this['lastLoginAt']=_0x37d538,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x219ce2){this['createdAt']=_0x219ce2['createdAt'],this['lastLoginAt']=_0x219ce2['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x4ee216){var _0x225c9d;const _0x53115f=_0x4ee216['auth'],_0x11824f=await _0x4ee216['getIdToken'](),_0x35e6ed=await xt(_0x4ee216,Sn(_0x53115f,{'idToken':_0x11824f}));m(_0x35e6ed==null?void 0x0:_0x35e6ed['users']['length'],_0x53115f,'internal-error');const _0xac1627=_0x35e6ed['users'][0x0];_0x4ee216['_notifyReloadListener'](_0xac1627);const _0x1fd5d5=(_0x225c9d=_0xac1627['providerUserInfo'])!=null&&_0x225c9d['length']?wa(_0xac1627['providerUserInfo']):[],_0x39cda0=mf(_0x4ee216['providerData'],_0x1fd5d5),_0x4efa40=_0x4ee216['isAnonymous'],_0x5f4df8=!(_0x4ee216['email']&&_0xac1627['passwordHash'])&&!(_0x39cda0!=null&&_0x39cda0['length']),_0x4460e1=_0x4efa40?_0x5f4df8:!0x1,_0x51cb56={'uid':_0xac1627['localId'],'displayName':_0xac1627['displayName']||null,'photoURL':_0xac1627['photoUrl']||null,'email':_0xac1627['email']||null,'emailVerified':_0xac1627['emailVerified']||!0x1,'phoneNumber':_0xac1627['phoneNumber']||null,'tenantId':_0xac1627['tenantId']||null,'providerData':_0x39cda0,'metadata':new Pi(_0xac1627['createdAt'],_0xac1627['lastLoginAt']),'isAnonymous':_0x4460e1};Object['assign'](_0x4ee216,_0x51cb56);}async function gf(_0x3f7ea4){const _0x439ccb=k(_0x3f7ea4);await bn(_0x439ccb),await _0x439ccb['auth']['_persistUserIfCurrent'](_0x439ccb),_0x439ccb['auth']['_notifyListenersIfCurrent'](_0x439ccb);}function mf(_0x192a1c,_0x272765){return[..._0x192a1c['filter'](_0x447ef1=>!_0x272765['some'](_0x3a7e97=>_0x3a7e97['providerId']===_0x447ef1['providerId'])),..._0x272765];}function wa(_0x5de445){return _0x5de445['map'](({providerId:_0x1a9dff,..._0xbd0488})=>({'providerId':_0x1a9dff,'uid':_0xbd0488['rawId']||'','displayName':_0xbd0488['displayName']||null,'email':_0xbd0488['email']||null,'phoneNumber':_0xbd0488['phoneNumber']||null,'photoURL':_0xbd0488['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x33dfb6,_0x1e4579){const _0x3b43ec=await Ea(_0x33dfb6,{},async()=>{const _0x33c6ca=at({'grant_type':'refresh_token','refresh_token':_0x1e4579})['slice'](0x1),{tokenApiHost:_0x46f4e5,apiKey:_0x582650}=_0x33dfb6['config'],_0x4a25c3=await Ia(_0x33dfb6,_0x46f4e5,'/v1/token','key='+_0x582650),_0xf22a83=await _0x33dfb6['_getAdditionalHeaders']();_0xf22a83['Content-Type']='application/x-www-form-urlencoded';const _0x30c671={'method':'POST','headers':_0xf22a83,'body':_0x33c6ca};return _0x33dfb6['emulatorConfig']&&Wt(_0x33dfb6['emulatorConfig']['host'])&&(_0x30c671['credentials']='include'),va['fetch']()(_0x4a25c3,_0x30c671);});return{'accessToken':_0x3b43ec['access_token'],'expiresIn':_0x3b43ec['expires_in'],'refreshToken':_0x3b43ec['refresh_token']};}async function vf(_0x44c866,_0x2b256f){return Ae(_0x44c866,'POST','/v2/accounts:revokeToken',Re(_0x44c866,_0x2b256f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5c5eca){m(_0x5c5eca['idToken'],'internal-error'),m(typeof _0x5c5eca['idToken']<'u','internal-error'),m(typeof _0x5c5eca['refreshToken']<'u','internal-error');const _0x2fd6c8='expiresIn'in _0x5c5eca&&typeof _0x5c5eca['expiresIn']<'u'?Number(_0x5c5eca['expiresIn']):Er(_0x5c5eca['idToken']);this['updateTokensAndExpiration'](_0x5c5eca['idToken'],_0x5c5eca['refreshToken'],_0x2fd6c8);}['updateFromIdToken'](_0x13bbf1){m(_0x13bbf1['length']!==0x0,'internal-error');const _0x4dbe3e=Er(_0x13bbf1);this['updateTokensAndExpiration'](_0x13bbf1,null,_0x4dbe3e);}async['getToken'](_0x47f201,_0x60855a=!0x1){return!_0x60855a&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x47f201,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x47f201,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0xc2f852,_0x3f26e9){const {accessToken:_0x15d092,refreshToken:_0x77e98e,expiresIn:_0x11194f}=await yf(_0xc2f852,_0x3f26e9);this['updateTokensAndExpiration'](_0x15d092,_0x77e98e,Number(_0x11194f));}['updateTokensAndExpiration'](_0x2889a6,_0x50c454,_0x109e67){this['refreshToken']=_0x50c454||null,this['accessToken']=_0x2889a6||null,this['expirationTime']=Date['now']()+_0x109e67*0x3e8;}static['fromJSON'](_0x182d5b,_0x3346e4){const {refreshToken:_0x22094d,accessToken:_0x339bb3,expirationTime:_0x24d825}=_0x3346e4,_0x126038=new Je();return _0x22094d&&(m(typeof _0x22094d=='string','internal-error',{'appName':_0x182d5b}),_0x126038['refreshToken']=_0x22094d),_0x339bb3&&(m(typeof _0x339bb3=='string','internal-error',{'appName':_0x182d5b}),_0x126038['accessToken']=_0x339bb3),_0x24d825&&(m(typeof _0x24d825=='number','internal-error',{'appName':_0x182d5b}),_0x126038['expirationTime']=_0x24d825),_0x126038;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x461e03){this['accessToken']=_0x461e03['accessToken'],this['refreshToken']=_0x461e03['refreshToken'],this['expirationTime']=_0x461e03['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x5e3afe,_0x856c1b){m(typeof _0x5e3afe=='string'||typeof _0x5e3afe>'u','internal-error',{'appName':_0x856c1b});}class z{constructor({uid:_0x5f4def,auth:_0x51d40e,stsTokenManager:_0x38351e,..._0x15aa79}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5f4def,this['auth']=_0x51d40e,this['stsTokenManager']=_0x38351e,this['accessToken']=_0x38351e['accessToken'],this['displayName']=_0x15aa79['displayName']||null,this['email']=_0x15aa79['email']||null,this['emailVerified']=_0x15aa79['emailVerified']||!0x1,this['phoneNumber']=_0x15aa79['phoneNumber']||null,this['photoURL']=_0x15aa79['photoURL']||null,this['isAnonymous']=_0x15aa79['isAnonymous']||!0x1,this['tenantId']=_0x15aa79['tenantId']||null,this['providerData']=_0x15aa79['providerData']?[..._0x15aa79['providerData']]:[],this['metadata']=new Pi(_0x15aa79['createdAt']||void 0x0,_0x15aa79['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1e5145){const _0xcf3c20=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x1e5145));return m(_0xcf3c20,this['auth'],'internal-error'),this['accessToken']!==_0xcf3c20&&(this['accessToken']=_0xcf3c20,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0xcf3c20;}['getIdTokenResult'](_0x287881){return ff(this,_0x287881);}['reload'](){return gf(this);}['_assign'](_0x4958cd){this!==_0x4958cd&&(m(this['uid']===_0x4958cd['uid'],this['auth'],'internal-error'),this['displayName']=_0x4958cd['displayName'],this['photoURL']=_0x4958cd['photoURL'],this['email']=_0x4958cd['email'],this['emailVerified']=_0x4958cd['emailVerified'],this['phoneNumber']=_0x4958cd['phoneNumber'],this['isAnonymous']=_0x4958cd['isAnonymous'],this['tenantId']=_0x4958cd['tenantId'],this['providerData']=_0x4958cd['providerData']['map'](_0x3e89ff=>({..._0x3e89ff})),this['metadata']['_copy'](_0x4958cd['metadata']),this['stsTokenManager']['_assign'](_0x4958cd['stsTokenManager']));}['_clone'](_0x47acda){const _0x336561=new z({...this,'auth':_0x47acda,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x336561['metadata']['_copy'](this['metadata']),_0x336561;}['_onReload'](_0x2f6be9){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2f6be9,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3ee221){this['reloadListener']?this['reloadListener'](_0x3ee221):this['reloadUserInfo']=_0x3ee221;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x8ee00f,_0x270884=!0x1){let _0x83ac9a=!0x1;_0x8ee00f['idToken']&&_0x8ee00f['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x8ee00f),_0x83ac9a=!0x0),_0x270884&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x83ac9a&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x40b5dc=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x40b5dc})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x28dd6d=>({..._0x28dd6d})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x49bd86,_0x41a9db){const _0x59fa99=_0x41a9db['displayName']??void 0x0,_0x45240f=_0x41a9db['email']??void 0x0,_0x19769c=_0x41a9db['phoneNumber']??void 0x0,_0x44c0b8=_0x41a9db['photoURL']??void 0x0,_0x343fc7=_0x41a9db['tenantId']??void 0x0,_0x38be01=_0x41a9db['_redirectEventId']??void 0x0,_0x59efde=_0x41a9db['createdAt']??void 0x0,_0x2a6465=_0x41a9db['lastLoginAt']??void 0x0,{uid:_0x4149ff,emailVerified:_0x20ac5b,isAnonymous:_0x4ba945,providerData:_0x444309,stsTokenManager:_0x145e37}=_0x41a9db;m(_0x4149ff&&_0x145e37,_0x49bd86,'internal-error');const _0x1ab7b9=Je['fromJSON'](this['name'],_0x145e37);m(typeof _0x4149ff=='string',_0x49bd86,'internal-error'),ce(_0x59fa99,_0x49bd86['name']),ce(_0x45240f,_0x49bd86['name']),m(typeof _0x20ac5b=='boolean',_0x49bd86,'internal-error'),m(typeof _0x4ba945=='boolean',_0x49bd86,'internal-error'),ce(_0x19769c,_0x49bd86['name']),ce(_0x44c0b8,_0x49bd86['name']),ce(_0x343fc7,_0x49bd86['name']),ce(_0x38be01,_0x49bd86['name']),ce(_0x59efde,_0x49bd86['name']),ce(_0x2a6465,_0x49bd86['name']);const _0x4e6118=new z({'uid':_0x4149ff,'auth':_0x49bd86,'email':_0x45240f,'emailVerified':_0x20ac5b,'displayName':_0x59fa99,'isAnonymous':_0x4ba945,'photoURL':_0x44c0b8,'phoneNumber':_0x19769c,'tenantId':_0x343fc7,'stsTokenManager':_0x1ab7b9,'createdAt':_0x59efde,'lastLoginAt':_0x2a6465});return _0x444309&&Array['isArray'](_0x444309)&&(_0x4e6118['providerData']=_0x444309['map'](_0x3e4e9d=>({..._0x3e4e9d}))),_0x38be01&&(_0x4e6118['_redirectEventId']=_0x38be01),_0x4e6118;}static async['_fromIdTokenResponse'](_0x23b497,_0x29d9a7,_0x5a3424=!0x1){const _0xcc323e=new Je();_0xcc323e['updateFromServerResponse'](_0x29d9a7);const _0x373a89=new z({'uid':_0x29d9a7['localId'],'auth':_0x23b497,'stsTokenManager':_0xcc323e,'isAnonymous':_0x5a3424});return await bn(_0x373a89),_0x373a89;}static async['_fromGetAccountInfoResponse'](_0x3c3be4,_0x32dc50,_0x3d5276){const _0x5b5ce5=_0x32dc50['users'][0x0];m(_0x5b5ce5['localId']!==void 0x0,'internal-error');const _0x58f351=_0x5b5ce5['providerUserInfo']!==void 0x0?wa(_0x5b5ce5['providerUserInfo']):[],_0x50c0d7=!(_0x5b5ce5['email']&&_0x5b5ce5['passwordHash'])&&!(_0x58f351!=null&&_0x58f351['length']),_0x1e338c=new Je();_0x1e338c['updateFromIdToken'](_0x3d5276);const _0x3a69a7=new z({'uid':_0x5b5ce5['localId'],'auth':_0x3c3be4,'stsTokenManager':_0x1e338c,'isAnonymous':_0x50c0d7}),_0x292567={'uid':_0x5b5ce5['localId'],'displayName':_0x5b5ce5['displayName']||null,'photoURL':_0x5b5ce5['photoUrl']||null,'email':_0x5b5ce5['email']||null,'emailVerified':_0x5b5ce5['emailVerified']||!0x1,'phoneNumber':_0x5b5ce5['phoneNumber']||null,'tenantId':_0x5b5ce5['tenantId']||null,'providerData':_0x58f351,'metadata':new Pi(_0x5b5ce5['createdAt'],_0x5b5ce5['lastLoginAt']),'isAnonymous':!(_0x5b5ce5['email']&&_0x5b5ce5['passwordHash'])&&!(_0x58f351!=null&&_0x58f351['length'])};return Object['assign'](_0x3a69a7,_0x292567),_0x3a69a7;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x25d817){ae(_0x25d817 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3f6a08=Ir['get'](_0x25d817);return _0x3f6a08?(ae(_0x3f6a08 instanceof _0x25d817,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3f6a08):(_0x3f6a08=new _0x25d817(),Ir['set'](_0x25d817,_0x3f6a08),_0x3f6a08);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0xfb640c,_0x3d6bb2){this['storage'][_0xfb640c]=_0x3d6bb2;}async['_get'](_0x5b245f){const _0x4348e1=this['storage'][_0x5b245f];return _0x4348e1===void 0x0?null:_0x4348e1;}async['_remove'](_0x355728){delete this['storage'][_0x355728];}['_addListener'](_0x1fd993,_0x58bae4){}['_removeListener'](_0x1682f6,_0x24ed0e){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x13ca56,_0x57215d,_0x54a2bb){return'firebase:'+_0x13ca56+':'+_0x57215d+':'+_0x54a2bb;}class Xe{constructor(_0x52b7d4,_0x20d72a,_0x3d5be2){this['persistence']=_0x52b7d4,this['auth']=_0x20d72a,this['userKey']=_0x3d5be2;const {config:_0x43894d,name:_0x489508}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x43894d['apiKey'],_0x489508),this['fullPersistenceKey']=sn('persistence',_0x43894d['apiKey'],_0x489508),this['boundEventHandler']=_0x20d72a['_onStorageEvent']['bind'](_0x20d72a),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x2d138e){return this['persistence']['_set'](this['fullUserKey'],_0x2d138e['toJSON']());}async['getCurrentUser'](){const _0xedd8f9=await this['persistence']['_get'](this['fullUserKey']);if(!_0xedd8f9)return null;if(typeof _0xedd8f9=='string'){const _0x3c59ad=await Sn(this['auth'],{'idToken':_0xedd8f9})['catch'](()=>{});return _0x3c59ad?z['_fromGetAccountInfoResponse'](this['auth'],_0x3c59ad,_0xedd8f9):null;}return z['_fromJSON'](this['auth'],_0xedd8f9);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3c8c54){if(this['persistence']===_0x3c8c54)return;const _0x2d85df=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3c8c54,_0x2d85df)return this['setCurrentUser'](_0x2d85df);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x54779e,_0x185b3a,_0x36cd8e='authUser'){if(!_0x185b3a['length'])return new Xe(ne(wr),_0x54779e,_0x36cd8e);const _0x248843=(await Promise['all'](_0x185b3a['map'](async _0x26220e=>{if(await _0x26220e['_isAvailable']())return _0x26220e;})))['filter'](_0x455a55=>_0x455a55);let _0x3dc41b=_0x248843[0x0]||ne(wr);const _0x4fc0e2=sn(_0x36cd8e,_0x54779e['config']['apiKey'],_0x54779e['name']);let _0x2b9680=null;for(const _0x28063e of _0x185b3a)try{const _0x381ec6=await _0x28063e['_get'](_0x4fc0e2);if(_0x381ec6){let _0x2a6fcc;if(typeof _0x381ec6=='string'){const _0x19bc19=await Sn(_0x54779e,{'idToken':_0x381ec6})['catch'](()=>{});if(!_0x19bc19)break;_0x2a6fcc=await z['_fromGetAccountInfoResponse'](_0x54779e,_0x19bc19,_0x381ec6);}else _0x2a6fcc=z['_fromJSON'](_0x54779e,_0x381ec6);_0x28063e!==_0x3dc41b&&(_0x2b9680=_0x2a6fcc),_0x3dc41b=_0x28063e;break;}}catch{}const _0x8d8101=_0x248843['filter'](_0x561c47=>_0x561c47['_shouldAllowMigration']);return!_0x3dc41b['_shouldAllowMigration']||!_0x8d8101['length']?new Xe(_0x3dc41b,_0x54779e,_0x36cd8e):(_0x3dc41b=_0x8d8101[0x0],_0x2b9680&&await _0x3dc41b['_set'](_0x4fc0e2,_0x2b9680['toJSON']()),await Promise['all'](_0x185b3a['map'](async _0x4bbf84=>{if(_0x4bbf84!==_0x3dc41b)try{await _0x4bbf84['_remove'](_0x4fc0e2);}catch{}})),new Xe(_0x3dc41b,_0x54779e,_0x36cd8e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x2741cb){const _0x74f8fd=_0x2741cb['toLowerCase']();if(_0x74f8fd['includes']('opera/')||_0x74f8fd['includes']('opr/')||_0x74f8fd['includes']('opios/'))return'Opera';if(Ra(_0x74f8fd))return'IEMobile';if(_0x74f8fd['includes']('msie')||_0x74f8fd['includes']('trident/'))return'IE';if(_0x74f8fd['includes']('edge/'))return'Edge';if(Ta(_0x74f8fd))return'Firefox';if(_0x74f8fd['includes']('silk/'))return'Silk';if(ka(_0x74f8fd))return'Blackberry';if(Na(_0x74f8fd))return'Webos';if(Sa(_0x74f8fd))return'Safari';if((_0x74f8fd['includes']('chrome/')||ba(_0x74f8fd))&&!_0x74f8fd['includes']('edge/'))return'Chrome';if(Aa(_0x74f8fd))return'Android';{const _0x465635=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3f6b71=_0x2741cb['match'](_0x465635);if((_0x3f6b71==null?void 0x0:_0x3f6b71['length'])===0x2)return _0x3f6b71[0x1];}return'Other';}function Ta(_0x47bd4=W()){return/firefox\//i['test'](_0x47bd4);}function Sa(_0x1603ec=W()){const _0x5d5930=_0x1603ec['toLowerCase']();return _0x5d5930['includes']('safari/')&&!_0x5d5930['includes']('chrome/')&&!_0x5d5930['includes']('crios/')&&!_0x5d5930['includes']('android');}function ba(_0x3c7fc3=W()){return/crios\//i['test'](_0x3c7fc3);}function Ra(_0x52d156=W()){return/iemobile/i['test'](_0x52d156);}function Aa(_0x509df5=W()){return/android/i['test'](_0x509df5);}function ka(_0x5e0c85=W()){return/blackberry/i['test'](_0x5e0c85);}function Na(_0x254ae4=W()){return/webos/i['test'](_0x254ae4);}function Cs(_0x23e94d=W()){return/iphone|ipad|ipod/i['test'](_0x23e94d)||/macintosh/i['test'](_0x23e94d)&&/mobile/i['test'](_0x23e94d);}function Ef(_0x28a007=W()){var _0x18d6d7;return Cs(_0x28a007)&&!!((_0x18d6d7=window['navigator'])!=null&&_0x18d6d7['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x3e2f1a=W()){return Cs(_0x3e2f1a)||Aa(_0x3e2f1a)||Na(_0x3e2f1a)||ka(_0x3e2f1a)||/windows phone/i['test'](_0x3e2f1a)||Ra(_0x3e2f1a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x93deb8,_0x24edc6=[]){let _0x328c42;switch(_0x93deb8){case'Browser':_0x328c42=Cr(W());break;case'Worker':_0x328c42=Cr(W())+'-'+_0x93deb8;break;default:_0x328c42=_0x93deb8;}const _0x24f652=_0x24edc6['length']?_0x24edc6['join'](','):'FirebaseCore-web';return _0x328c42+'/JsCore/'+ct+'/'+_0x24f652;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x1c84d5){this['auth']=_0x1c84d5,this['queue']=[];}['pushCallback'](_0x159aa6,_0x1a9d51){const _0x5b4752=_0x5ab6f8=>new Promise((_0x2cb9e8,_0x5b3964)=>{try{const _0x3e0ae0=_0x159aa6(_0x5ab6f8);_0x2cb9e8(_0x3e0ae0);}catch(_0x48e561){_0x5b3964(_0x48e561);}});_0x5b4752['onAbort']=_0x1a9d51,this['queue']['push'](_0x5b4752);const _0x70f6ab=this['queue']['length']-0x1;return()=>{this['queue'][_0x70f6ab]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5345f8){if(this['auth']['currentUser']===_0x5345f8)return;const _0x516678=[];try{for(const _0x28ad6a of this['queue'])await _0x28ad6a(_0x5345f8),_0x28ad6a['onAbort']&&_0x516678['push'](_0x28ad6a['onAbort']);}catch(_0x514b37){_0x516678['reverse']();for(const _0x52dc29 of _0x516678)try{_0x52dc29();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x514b37==null?void 0x0:_0x514b37['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x270183,_0x45dcf8={}){return Ae(_0x270183,'GET','/v2/passwordPolicy',Re(_0x270183,_0x45dcf8));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x47130f){var _0x21188e;const _0x4ed910=_0x47130f['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4ed910['minPasswordLength']??Tf,_0x4ed910['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4ed910['maxPasswordLength']),_0x4ed910['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4ed910['containsLowercaseCharacter']),_0x4ed910['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4ed910['containsUppercaseCharacter']),_0x4ed910['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4ed910['containsNumericCharacter']),_0x4ed910['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4ed910['containsNonAlphanumericCharacter']),this['enforcementState']=_0x47130f['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x21188e=_0x47130f['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x21188e['join'](''))??'',this['forceUpgradeOnSignin']=_0x47130f['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x47130f['schemaVersion'];}['validatePassword'](_0x59fbd5){const _0x4c98b4={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x59fbd5,_0x4c98b4),this['validatePasswordCharacterOptions'](_0x59fbd5,_0x4c98b4),_0x4c98b4['isValid']&&(_0x4c98b4['isValid']=_0x4c98b4['meetsMinPasswordLength']??!0x0),_0x4c98b4['isValid']&&(_0x4c98b4['isValid']=_0x4c98b4['meetsMaxPasswordLength']??!0x0),_0x4c98b4['isValid']&&(_0x4c98b4['isValid']=_0x4c98b4['containsLowercaseLetter']??!0x0),_0x4c98b4['isValid']&&(_0x4c98b4['isValid']=_0x4c98b4['containsUppercaseLetter']??!0x0),_0x4c98b4['isValid']&&(_0x4c98b4['isValid']=_0x4c98b4['containsNumericCharacter']??!0x0),_0x4c98b4['isValid']&&(_0x4c98b4['isValid']=_0x4c98b4['containsNonAlphanumericCharacter']??!0x0),_0x4c98b4;}['validatePasswordLengthOptions'](_0x1a00c8,_0x215d26){const _0x184dcb=this['customStrengthOptions']['minPasswordLength'],_0x48ff1b=this['customStrengthOptions']['maxPasswordLength'];_0x184dcb&&(_0x215d26['meetsMinPasswordLength']=_0x1a00c8['length']>=_0x184dcb),_0x48ff1b&&(_0x215d26['meetsMaxPasswordLength']=_0x1a00c8['length']<=_0x48ff1b);}['validatePasswordCharacterOptions'](_0x3ae140,_0x2c5851){this['updatePasswordCharacterOptionsStatuses'](_0x2c5851,!0x1,!0x1,!0x1,!0x1);let _0x44adae;for(let _0x16ece9=0x0;_0x16ece9<_0x3ae140['length'];_0x16ece9++)_0x44adae=_0x3ae140['charAt'](_0x16ece9),this['updatePasswordCharacterOptionsStatuses'](_0x2c5851,_0x44adae>='a'&&_0x44adae<='z',_0x44adae>='A'&&_0x44adae<='Z',_0x44adae>='0'&&_0x44adae<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x44adae));}['updatePasswordCharacterOptionsStatuses'](_0x5dfc75,_0x2859b6,_0x5c98d2,_0x1af56b,_0x2c2724){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5dfc75['containsLowercaseLetter']||(_0x5dfc75['containsLowercaseLetter']=_0x2859b6)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5dfc75['containsUppercaseLetter']||(_0x5dfc75['containsUppercaseLetter']=_0x5c98d2)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5dfc75['containsNumericCharacter']||(_0x5dfc75['containsNumericCharacter']=_0x1af56b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5dfc75['containsNonAlphanumericCharacter']||(_0x5dfc75['containsNonAlphanumericCharacter']=_0x2c2724));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x469d15,_0x4ba597,_0x1f4ee8,_0x3cb549){this['app']=_0x469d15,this['heartbeatServiceProvider']=_0x4ba597,this['appCheckServiceProvider']=_0x1f4ee8,this['config']=_0x3cb549,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x469d15['name'],this['clientVersion']=_0x3cb549['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x53abb4=>this['_resolvePersistenceManagerAvailable']=_0x53abb4);}['_initializeWithPersistence'](_0x473c18,_0x441d6a){return _0x441d6a&&(this['_popupRedirectResolver']=ne(_0x441d6a)),this['_initializationPromise']=this['queue'](async()=>{var _0x561967,_0x4e5ba8,_0x18b1c5;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x473c18),(_0x561967=this['_resolvePersistenceManagerAvailable'])==null||_0x561967['call'](this),!this['_deleted'])){if((_0x4e5ba8=this['_popupRedirectResolver'])!=null&&_0x4e5ba8['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x441d6a),this['lastNotifiedUid']=((_0x18b1c5=this['currentUser'])==null?void 0x0:_0x18b1c5['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x365590=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x365590)){if(this['currentUser']&&_0x365590&&this['currentUser']['uid']===_0x365590['uid']){this['_currentUser']['_assign'](_0x365590),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x365590,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2ffd72){try{const _0x54ad92=await Sn(this,{'idToken':_0x2ffd72}),_0x424bf2=await z['_fromGetAccountInfoResponse'](this,_0x54ad92,_0x2ffd72);await this['directlySetCurrentUser'](_0x424bf2);}catch(_0x2e9f1d){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2e9f1d),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5b0fc8){var _0x5fded9;if(H(this['app'])){const _0x515679=this['app']['settings']['authIdToken'];return _0x515679?new Promise(_0x5bfb8f=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x515679)['then'](_0x5bfb8f,_0x5bfb8f));}):this['directlySetCurrentUser'](null);}const _0x200e91=await this['assertedPersistence']['getCurrentUser']();let _0x48c1bc=_0x200e91,_0x4f0e80=!0x1;if(_0x5b0fc8&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x26a9b3=(_0x5fded9=this['redirectUser'])==null?void 0x0:_0x5fded9['_redirectEventId'],_0x232a82=_0x48c1bc==null?void 0x0:_0x48c1bc['_redirectEventId'],_0x16404b=await this['tryRedirectSignIn'](_0x5b0fc8);(!_0x26a9b3||_0x26a9b3===_0x232a82)&&(_0x16404b!=null&&_0x16404b['user'])&&(_0x48c1bc=_0x16404b['user'],_0x4f0e80=!0x0);}if(!_0x48c1bc)return this['directlySetCurrentUser'](null);if(!_0x48c1bc['_redirectEventId']){if(_0x4f0e80)try{await this['beforeStateQueue']['runMiddleware'](_0x48c1bc);}catch(_0x45e4a9){_0x48c1bc=_0x200e91,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x45e4a9));}return _0x48c1bc?this['reloadAndSetCurrentUserOrClear'](_0x48c1bc):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x48c1bc['_redirectEventId']?this['directlySetCurrentUser'](_0x48c1bc):this['reloadAndSetCurrentUserOrClear'](_0x48c1bc);}async['tryRedirectSignIn'](_0x2cc041){let _0x1b9ec5=null;try{_0x1b9ec5=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2cc041,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1b9ec5;}async['reloadAndSetCurrentUserOrClear'](_0x349c55){try{await bn(_0x349c55);}catch(_0x4ed047){if((_0x4ed047==null?void 0x0:_0x4ed047['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x349c55);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2607eb){if(H(this['app']))return Promise['reject'](se(this));const _0x294f22=_0x2607eb?k(_0x2607eb):null;return _0x294f22&&m(_0x294f22['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x294f22&&_0x294f22['_clone'](this));}async['_updateCurrentUser'](_0x13ae59,_0x18d8ef=!0x1){if(!this['_deleted'])return _0x13ae59&&m(this['tenantId']===_0x13ae59['tenantId'],this,'tenant-id-mismatch'),_0x18d8ef||await this['beforeStateQueue']['runMiddleware'](_0x13ae59),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x13ae59),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1c6164){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x1c6164));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x373bcf){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4d5c4f=this['_getPasswordPolicyInternal']();return _0x4d5c4f['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4d5c4f['validatePassword'](_0x373bcf);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2c046f=await Cf(this),_0x3e2580=new Sf(_0x2c046f);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3e2580:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3e2580;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x1e4bc0){this['_errorFactory']=new Ut('auth','Firebase',_0x1e4bc0());}['onAuthStateChanged'](_0x592abd,_0x5ca18a,_0x58fb21){return this['registerStateListener'](this['authStateSubscription'],_0x592abd,_0x5ca18a,_0x58fb21);}['beforeAuthStateChanged'](_0x318d38,_0x1aa11a){return this['beforeStateQueue']['pushCallback'](_0x318d38,_0x1aa11a);}['onIdTokenChanged'](_0x29da44,_0x3b4a10,_0x136055){return this['registerStateListener'](this['idTokenSubscription'],_0x29da44,_0x3b4a10,_0x136055);}['authStateReady'](){return new Promise((_0x1eb90d,_0x48490b)=>{if(this['currentUser'])_0x1eb90d();else{const _0x428224=this['onAuthStateChanged'](()=>{_0x428224(),_0x1eb90d();},_0x48490b);}});}async['revokeAccessToken'](_0x35d6){if(this['currentUser']){const _0x12c5be=await this['currentUser']['getIdToken'](),_0x4bbe6e={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x35d6,'idToken':_0x12c5be};this['tenantId']!=null&&(_0x4bbe6e['tenantId']=this['tenantId']),await vf(this,_0x4bbe6e);}}['toJSON'](){var _0x17eb34;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x17eb34=this['_currentUser'])==null?void 0x0:_0x17eb34['toJSON']()};}async['_setRedirectUser'](_0x3b3bc7,_0x34ad74){const _0x23c6f3=await this['getOrInitRedirectPersistenceManager'](_0x34ad74);return _0x3b3bc7===null?_0x23c6f3['removeCurrentUser']():_0x23c6f3['setCurrentUser'](_0x3b3bc7);}async['getOrInitRedirectPersistenceManager'](_0x45becd){if(!this['redirectPersistenceManager']){const _0x3ddf2e=_0x45becd&&ne(_0x45becd)||this['_popupRedirectResolver'];m(_0x3ddf2e,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x3ddf2e['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x25707){var _0x16740c,_0x15f17e;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x16740c=this['_currentUser'])==null?void 0x0:_0x16740c['_redirectEventId'])===_0x25707?this['_currentUser']:((_0x15f17e=this['redirectUser'])==null?void 0x0:_0x15f17e['_redirectEventId'])===_0x25707?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x481719){if(_0x481719===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x481719));}['_notifyListenersIfCurrent'](_0x1dea0a){_0x1dea0a===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x47e4a1;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x29dcf3=((_0x47e4a1=this['currentUser'])==null?void 0x0:_0x47e4a1['uid'])??null;this['lastNotifiedUid']!==_0x29dcf3&&(this['lastNotifiedUid']=_0x29dcf3,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2cac40,_0x26196a,_0x28815f,_0x1646ab){if(this['_deleted'])return()=>{};const _0x4b5160=typeof _0x26196a=='function'?_0x26196a:_0x26196a['next']['bind'](_0x26196a);let _0x33bcbe=!0x1;const _0x1b5f03=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x1b5f03,this,'internal-error'),_0x1b5f03['then'](()=>{_0x33bcbe||_0x4b5160(this['currentUser']);}),typeof _0x26196a=='function'){const _0x12ff08=_0x2cac40['addObserver'](_0x26196a,_0x28815f,_0x1646ab);return()=>{_0x33bcbe=!0x0,_0x12ff08();};}else{const _0x263b55=_0x2cac40['addObserver'](_0x26196a);return()=>{_0x33bcbe=!0x0,_0x263b55();};}}async['directlySetCurrentUser'](_0x125932){this['currentUser']&&this['currentUser']!==_0x125932&&this['_currentUser']['_stopProactiveRefresh'](),_0x125932&&this['isProactiveRefreshEnabled']&&_0x125932['_startProactiveRefresh'](),this['currentUser']=_0x125932,_0x125932?await this['assertedPersistence']['setCurrentUser'](_0x125932):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4cb7d6){return this['operations']=this['operations']['then'](_0x4cb7d6,_0x4cb7d6),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x587aa6){!_0x587aa6||this['frameworks']['includes'](_0x587aa6)||(this['frameworks']['push'](_0x587aa6),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x26bfd3;const _0x5d1644={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x5d1644['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x51e26b=await((_0x26bfd3=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x26bfd3['getHeartbeatsHeader']());_0x51e26b&&(_0x5d1644['X-Firebase-Client']=_0x51e26b);const _0x428a45=await this['_getAppCheckToken']();return _0x428a45&&(_0x5d1644['X-Firebase-AppCheck']=_0x428a45),_0x5d1644;}async['_getAppCheckToken'](){var _0x7628c5;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x35d312=await((_0x7628c5=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x7628c5['getToken']());return _0x35d312!=null&&_0x35d312['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x35d312['error']),_0x35d312==null?void 0x0:_0x35d312['token'];}}function qe(_0x1577fc){return k(_0x1577fc);}class Tr{constructor(_0x3fa1c7){this['auth']=_0x3fa1c7,this['observer']=null,this['addObserver']=Ic(_0x47b29e=>this['observer']=_0x47b29e);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x1051ee){zn=_0x1051ee;}function Da(_0x25d50d){return zn['loadJS'](_0x25d50d);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x701f18){return'__'+_0x701f18+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x4c0d93){_0x4c0d93();}['execute'](_0x4594d7,_0x3d5f25){return Promise['resolve']('token');}['render'](_0x11485d,_0x39ae09){return'';}}class Of{['ready'](_0xc34782){_0xc34782();}['execute'](_0x3162ac,_0x55826e){return Promise['resolve']('token');}['render'](_0x2e2c57,_0x35e1f9){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x599c66){this['type']=Df,this['auth']=qe(_0x599c66);}async['verify'](_0x2a9794='verify',_0xb79dfa=!0x1){async function _0x58b2bb(_0x2fccff){if(!_0xb79dfa){if(_0x2fccff['tenantId']==null&&_0x2fccff['_agentRecaptchaConfig']!=null)return _0x2fccff['_agentRecaptchaConfig']['siteKey'];if(_0x2fccff['tenantId']!=null&&_0x2fccff['_tenantRecaptchaConfigs'][_0x2fccff['tenantId']]!==void 0x0)return _0x2fccff['_tenantRecaptchaConfigs'][_0x2fccff['tenantId']]['siteKey'];}return new Promise(async(_0x5785d2,_0x488bc3)=>{uf(_0x2fccff,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x6e5f00=>{if(_0x6e5f00['recaptchaKey']===void 0x0)_0x488bc3(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5d81e7=new hf(_0x6e5f00);return _0x2fccff['tenantId']==null?_0x2fccff['_agentRecaptchaConfig']=_0x5d81e7:_0x2fccff['_tenantRecaptchaConfigs'][_0x2fccff['tenantId']]=_0x5d81e7,_0x5785d2(_0x5d81e7['siteKey']);}})['catch'](_0x37e335=>{_0x488bc3(_0x37e335);});});}function _0xeee7c8(_0x314d7d,_0x3dd102,_0x7605b0){const _0x1b10ca=window['grecaptcha'];vr(_0x1b10ca)?_0x1b10ca['enterprise']['ready'](()=>{_0x1b10ca['enterprise']['execute'](_0x314d7d,{'action':_0x2a9794})['then'](_0x326cfe=>{_0x3dd102(_0x326cfe);})['catch'](()=>{_0x3dd102(Ma);});}):_0x7605b0(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x5b5a71,_0x848a50)=>{_0x58b2bb(this['auth'])['then'](async _0x5073af=>{if(!_0xb79dfa&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0xeee7c8(_0x5073af,_0x5b5a71,_0x848a50);else{if(typeof window>'u'){_0x848a50(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x20ffae=Af();_0x20ffae['length']!==0x0&&(_0x20ffae+=_0x5073af+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x519bf0;(_0x519bf0=le['scriptInjectionDeferred'])==null||_0x519bf0['resolve']();},Da(_0x20ffae)['then'](()=>{var _0xb11d3c;return(_0xb11d3c=le['scriptInjectionDeferred'])==null?void 0x0:_0xb11d3c['promise'];})['then'](()=>{_0xeee7c8(_0x5073af,_0x5b5a71,_0x848a50);})['catch'](_0x5f32a9=>{_0x848a50(_0x5f32a9);});}})['catch'](_0x1b745e=>{_0x848a50(_0x1b745e);});});}}le['scriptInjectionDeferred']=null;async function br(_0x95138,_0x2e9795,_0x303d7b,_0x75e554=!0x1,_0x951c66=!0x1){const _0x2d8492=new le(_0x95138);let _0x27a73d;if(_0x951c66)_0x27a73d=Ma;else try{_0x27a73d=await _0x2d8492['verify'](_0x303d7b);}catch{_0x27a73d=await _0x2d8492['verify'](_0x303d7b,!0x0);}const _0x3ef06c={..._0x2e9795};if(_0x303d7b==='mfaSmsEnrollment'||_0x303d7b==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3ef06c){const _0x56803f=_0x3ef06c['phoneEnrollmentInfo']['phoneNumber'],_0x3e2ccd=_0x3ef06c['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3ef06c,{'phoneEnrollmentInfo':{'phoneNumber':_0x56803f,'recaptchaToken':_0x3e2ccd,'captchaResponse':_0x27a73d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3ef06c){const _0x4c150f=_0x3ef06c['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3ef06c,{'phoneSignInInfo':{'recaptchaToken':_0x4c150f,'captchaResponse':_0x27a73d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3ef06c;}return _0x75e554?Object['assign'](_0x3ef06c,{'captchaResp':_0x27a73d}):Object['assign'](_0x3ef06c,{'captchaResponse':_0x27a73d}),Object['assign'](_0x3ef06c,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3ef06c,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3ef06c;}async function Oi(_0x3a5fdc,_0x218b18,_0x4e2ef7,_0x417894,_0x31308e){var _0x2351ab;if((_0x2351ab=_0x3a5fdc['_getRecaptchaConfig']())!=null&&_0x2351ab['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x2ea0c3=await br(_0x3a5fdc,_0x218b18,_0x4e2ef7,_0x4e2ef7==='getOobCode');return _0x417894(_0x3a5fdc,_0x2ea0c3);}else return _0x417894(_0x3a5fdc,_0x218b18)['catch'](async _0x2d2767=>{if(_0x2d2767['code']==='auth/missing-recaptcha-token'){console['log'](_0x4e2ef7+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x28c7e1=await br(_0x3a5fdc,_0x218b18,_0x4e2ef7,_0x4e2ef7==='getOobCode');return _0x417894(_0x3a5fdc,_0x28c7e1);}else return Promise['reject'](_0x2d2767);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x41324c,_0x3adef9){const _0x5af3db=Ui(_0x41324c,'auth');if(_0x5af3db['isInitialized']()){const _0x25127c=_0x5af3db['getImmediate'](),_0x3efabb=_0x5af3db['getOptions']();if(De(_0x3efabb,_0x3adef9??{}))return _0x25127c;K(_0x25127c,'already-initialized');}return _0x5af3db['initialize']({'options':_0x3adef9});}function Lf(_0x23d167,_0x1292a6){const _0x275dcc=(_0x1292a6==null?void 0x0:_0x1292a6['persistence'])||[],_0x51653f=(Array['isArray'](_0x275dcc)?_0x275dcc:[_0x275dcc])['map'](ne);_0x1292a6!=null&&_0x1292a6['errorMap']&&_0x23d167['_updateErrorMap'](_0x1292a6['errorMap']),_0x23d167['_initializeWithPersistence'](_0x51653f,_0x1292a6==null?void 0x0:_0x1292a6['popupRedirectResolver']);}function xf(_0xaef2c5,_0xd06e7,_0x5f33f7){const _0x2b219c=qe(_0xaef2c5);m(/^https?:\/\//['test'](_0xd06e7),_0x2b219c,'invalid-emulator-scheme');const _0x5a5309=!0x1,_0x69722d=La(_0xd06e7),{host:_0x581808,port:_0x93f329}=Ff(_0xd06e7),_0x539b21=_0x93f329===null?'':':'+_0x93f329,_0xa3dad5={'url':_0x69722d+'//'+_0x581808+_0x539b21+'/'},_0x56b2a5=Object['freeze']({'host':_0x581808,'port':_0x93f329,'protocol':_0x69722d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5a5309})});if(!_0x2b219c['_canInitEmulator']){m(_0x2b219c['config']['emulator']&&_0x2b219c['emulatorConfig'],_0x2b219c,'emulator-config-failed'),m(De(_0xa3dad5,_0x2b219c['config']['emulator'])&&De(_0x56b2a5,_0x2b219c['emulatorConfig']),_0x2b219c,'emulator-config-failed');return;}_0x2b219c['config']['emulator']=_0xa3dad5,_0x2b219c['emulatorConfig']=_0x56b2a5,_0x2b219c['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x581808)?jr(_0x69722d+'//'+_0x581808+_0x539b21):Uf();}function La(_0x26677f){const _0x1e6f80=_0x26677f['indexOf'](':');return _0x1e6f80<0x0?'':_0x26677f['substr'](0x0,_0x1e6f80+0x1);}function Ff(_0x5ddcf4){const _0x4cfe00=La(_0x5ddcf4),_0x2a1fe4=/(\/\/)?([^?#/]+)/['exec'](_0x5ddcf4['substr'](_0x4cfe00['length']));if(!_0x2a1fe4)return{'host':'','port':null};const _0x25454e=_0x2a1fe4[0x2]['split']('@')['pop']()||'',_0x23c182=/^(\[[^\]]+\])(:|$)/['exec'](_0x25454e);if(_0x23c182){const _0x164e32=_0x23c182[0x1];return{'host':_0x164e32,'port':Rr(_0x25454e['substr'](_0x164e32['length']+0x1))};}else{const [_0x31c036,_0x42aad6]=_0x25454e['split'](':');return{'host':_0x31c036,'port':Rr(_0x42aad6)};}}function Rr(_0x1fff77){if(!_0x1fff77)return null;const _0x4cda11=Number(_0x1fff77);return isNaN(_0x4cda11)?null:_0x4cda11;}function Uf(){function _0x39c50f(){const _0x1b407a=document['createElement']('p'),_0x262b91=_0x1b407a['style'];_0x1b407a['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x262b91['position']='fixed',_0x262b91['width']='100%',_0x262b91['backgroundColor']='#ffffff',_0x262b91['border']='.1em\x20solid\x20#000000',_0x262b91['color']='#b50000',_0x262b91['bottom']='0px',_0x262b91['left']='0px',_0x262b91['margin']='0px',_0x262b91['zIndex']='10000',_0x262b91['textAlign']='center',_0x1b407a['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x1b407a);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x39c50f):_0x39c50f());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x4340d8,_0xc8ef90){this['providerId']=_0x4340d8,this['signInMethod']=_0xc8ef90;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0xb7c28e){return te('not\x20implemented');}['_linkToIdToken'](_0x1eae55,_0x3f06ff){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x15cd59){return te('not\x20implemented');}}async function Wf(_0xd2fb8e,_0x2f3719){return Ae(_0xd2fb8e,'POST','/v1/accounts:signUp',_0x2f3719);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x5190e5,_0x25d1ee){return Yt(_0x5190e5,'POST','/v1/accounts:signInWithPassword',Re(_0x5190e5,_0x25d1ee));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x79dbcf,_0x3a636b){return Yt(_0x79dbcf,'POST','/v1/accounts:signInWithEmailLink',Re(_0x79dbcf,_0x3a636b));}async function Hf(_0x5903c3,_0x45cfd4){return Yt(_0x5903c3,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5903c3,_0x45cfd4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x42ae94,_0x3d2056,_0x53000c,_0x13bfda=null){super('password',_0x53000c),this['_email']=_0x42ae94,this['_password']=_0x3d2056,this['_tenantId']=_0x13bfda;}static['_fromEmailAndPassword'](_0x2d565b,_0x10e7eb){return new Ft(_0x2d565b,_0x10e7eb,'password');}static['_fromEmailAndCode'](_0x405684,_0x57193f,_0x259b2a=null){return new Ft(_0x405684,_0x57193f,'emailLink',_0x259b2a);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x4722a7){const _0x18d1a7=typeof _0x4722a7=='string'?JSON['parse'](_0x4722a7):_0x4722a7;if(_0x18d1a7!=null&&_0x18d1a7['email']&&(_0x18d1a7!=null&&_0x18d1a7['password'])){if(_0x18d1a7['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x18d1a7['email'],_0x18d1a7['password']);if(_0x18d1a7['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x18d1a7['email'],_0x18d1a7['password'],_0x18d1a7['tenantId']);}return null;}async['_getIdTokenResponse'](_0x44fd7b){switch(this['signInMethod']){case'password':const _0x522285={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x44fd7b,_0x522285,'signInWithPassword',Bf);case'emailLink':return Vf(_0x44fd7b,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x44fd7b,'internal-error');}}async['_linkToIdToken'](_0x13ee8c,_0x2ab718){switch(this['signInMethod']){case'password':const _0x5b9545={'idToken':_0x2ab718,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x13ee8c,_0x5b9545,'signUpPassword',Wf);case'emailLink':return Hf(_0x13ee8c,{'idToken':_0x2ab718,'email':this['_email'],'oobCode':this['_password']});default:K(_0x13ee8c,'internal-error');}}['_getReauthenticationResolver'](_0x5b5a22){return this['_getIdTokenResponse'](_0x5b5a22);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x22d0d1,_0x1d525c){return Yt(_0x22d0d1,'POST','/v1/accounts:signInWithIdp',Re(_0x22d0d1,_0x1d525c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x35db43){const _0xfa0456=new We(_0x35db43['providerId'],_0x35db43['signInMethod']);return _0x35db43['idToken']||_0x35db43['accessToken']?(_0x35db43['idToken']&&(_0xfa0456['idToken']=_0x35db43['idToken']),_0x35db43['accessToken']&&(_0xfa0456['accessToken']=_0x35db43['accessToken']),_0x35db43['nonce']&&!_0x35db43['pendingToken']&&(_0xfa0456['nonce']=_0x35db43['nonce']),_0x35db43['pendingToken']&&(_0xfa0456['pendingToken']=_0x35db43['pendingToken'])):_0x35db43['oauthToken']&&_0x35db43['oauthTokenSecret']?(_0xfa0456['accessToken']=_0x35db43['oauthToken'],_0xfa0456['secret']=_0x35db43['oauthTokenSecret']):K('argument-error'),_0xfa0456;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x46a2ba){const _0x596bee=typeof _0x46a2ba=='string'?JSON['parse'](_0x46a2ba):_0x46a2ba,{providerId:_0x18c283,signInMethod:_0x2764ca,..._0x362c90}=_0x596bee;if(!_0x18c283||!_0x2764ca)return null;const _0x3acc32=new We(_0x18c283,_0x2764ca);return _0x3acc32['idToken']=_0x362c90['idToken']||void 0x0,_0x3acc32['accessToken']=_0x362c90['accessToken']||void 0x0,_0x3acc32['secret']=_0x362c90['secret'],_0x3acc32['nonce']=_0x362c90['nonce'],_0x3acc32['pendingToken']=_0x362c90['pendingToken']||null,_0x3acc32;}['_getIdTokenResponse'](_0xdb76e1){const _0x14a425=this['buildRequest']();return Ze(_0xdb76e1,_0x14a425);}['_linkToIdToken'](_0x1f7d66,_0x25537a){const _0x22f3e2=this['buildRequest']();return _0x22f3e2['idToken']=_0x25537a,Ze(_0x1f7d66,_0x22f3e2);}['_getReauthenticationResolver'](_0x106a79){const _0x3ecd0c=this['buildRequest']();return _0x3ecd0c['autoCreate']=!0x1,Ze(_0x106a79,_0x3ecd0c);}['buildRequest'](){const _0x198788={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x198788['pendingToken']=this['pendingToken'];else{const _0x4507f5={};this['idToken']&&(_0x4507f5['id_token']=this['idToken']),this['accessToken']&&(_0x4507f5['access_token']=this['accessToken']),this['secret']&&(_0x4507f5['oauth_token_secret']=this['secret']),_0x4507f5['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4507f5['nonce']=this['nonce']),_0x198788['postBody']=at(_0x4507f5);}return _0x198788;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x460017){switch(_0x460017){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x212959){const _0x2a6ed8=yt(vt(_0x212959))['link'],_0x5b2e14=_0x2a6ed8?yt(vt(_0x2a6ed8))['deep_link_id']:null,_0x91fc84=yt(vt(_0x212959))['deep_link_id'];return(_0x91fc84?yt(vt(_0x91fc84))['link']:null)||_0x91fc84||_0x5b2e14||_0x2a6ed8||_0x212959;}class Ss{constructor(_0x19222e){const _0x27a21c=yt(vt(_0x19222e)),_0x4dfa1c=_0x27a21c['apiKey']??null,_0x4d7c63=_0x27a21c['oobCode']??null,_0x859d7d=Gf(_0x27a21c['mode']??null);m(_0x4dfa1c&&_0x4d7c63&&_0x859d7d,'argument-error'),this['apiKey']=_0x4dfa1c,this['operation']=_0x859d7d,this['code']=_0x4d7c63,this['continueUrl']=_0x27a21c['continueUrl']??null,this['languageCode']=_0x27a21c['lang']??null,this['tenantId']=_0x27a21c['tenantId']??null;}static['parseLink'](_0x1aed8c){const _0x1546c7=qf(_0x1aed8c);try{return new Ss(_0x1546c7);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x2b991e,_0x1a7491){return Ft['_fromEmailAndPassword'](_0x2b991e,_0x1a7491);}static['credentialWithLink'](_0x1a984e,_0x2da2a2){const _0x322de5=Ss['parseLink'](_0x2da2a2);return m(_0x322de5,'argument-error'),Ft['_fromEmailAndCode'](_0x1a984e,_0x322de5['code'],_0x322de5['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x4eb2e5){this['providerId']=_0x4eb2e5,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4679bf){this['defaultLanguageCode']=_0x4679bf;}['setCustomParameters'](_0x14dd79){return this['customParameters']=_0x14dd79,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x374d69){return this['scopes']['includes'](_0x374d69)||this['scopes']['push'](_0x374d69),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x79ec77){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x79ec77});}static['credentialFromResult'](_0x174485){return he['credentialFromTaggedObject'](_0x174485);}static['credentialFromError'](_0x10cde4){return he['credentialFromTaggedObject'](_0x10cde4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5d2704}){if(!_0x5d2704||!('oauthAccessToken'in _0x5d2704)||!_0x5d2704['oauthAccessToken'])return null;try{return he['credential'](_0x5d2704['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3e3e9c,_0x30eee5){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3e3e9c,'accessToken':_0x30eee5});}static['credentialFromResult'](_0x2bdeae){return ue['credentialFromTaggedObject'](_0x2bdeae);}static['credentialFromError'](_0x122421){return ue['credentialFromTaggedObject'](_0x122421['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x387232}){if(!_0x387232)return null;const {oauthIdToken:_0x5da8f9,oauthAccessToken:_0xd8aff9}=_0x387232;if(!_0x5da8f9&&!_0xd8aff9)return null;try{return ue['credential'](_0x5da8f9,_0xd8aff9);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x2cc99b){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x2cc99b});}static['credentialFromResult'](_0x413b7c){return de['credentialFromTaggedObject'](_0x413b7c);}static['credentialFromError'](_0x39be2d){return de['credentialFromTaggedObject'](_0x39be2d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x29a2fa}){if(!_0x29a2fa||!('oauthAccessToken'in _0x29a2fa)||!_0x29a2fa['oauthAccessToken'])return null;try{return de['credential'](_0x29a2fa['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x2efdf4,_0x246736){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2efdf4,'oauthTokenSecret':_0x246736});}static['credentialFromResult'](_0x27585b){return fe['credentialFromTaggedObject'](_0x27585b);}static['credentialFromError'](_0x2aea55){return fe['credentialFromTaggedObject'](_0x2aea55['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xd9c66a}){if(!_0xd9c66a)return null;const {oauthAccessToken:_0x551a67,oauthTokenSecret:_0x128a5e}=_0xd9c66a;if(!_0x551a67||!_0x128a5e)return null;try{return fe['credential'](_0x551a67,_0x128a5e);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x28bfd2,_0x3df4ce){return Yt(_0x28bfd2,'POST','/v1/accounts:signUp',Re(_0x28bfd2,_0x3df4ce));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x23ec88){this['user']=_0x23ec88['user'],this['providerId']=_0x23ec88['providerId'],this['_tokenResponse']=_0x23ec88['_tokenResponse'],this['operationType']=_0x23ec88['operationType'];}static async['_fromIdTokenResponse'](_0x20d52e,_0xf69acd,_0x39032b,_0x270b96=!0x1){const _0x40ada3=await z['_fromIdTokenResponse'](_0x20d52e,_0x39032b,_0x270b96),_0x3d7f05=Ar(_0x39032b);return new Be({'user':_0x40ada3,'providerId':_0x3d7f05,'_tokenResponse':_0x39032b,'operationType':_0xf69acd});}static async['_forOperation'](_0x359014,_0x42bd4f,_0x26c107){await _0x359014['_updateTokensIfNecessary'](_0x26c107,!0x0);const _0x21ea8c=Ar(_0x26c107);return new Be({'user':_0x359014,'providerId':_0x21ea8c,'_tokenResponse':_0x26c107,'operationType':_0x42bd4f});}}function Ar(_0x57dad8){return _0x57dad8['providerId']?_0x57dad8['providerId']:'phoneNumber'in _0x57dad8?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0xbbc1c9,_0x34fa39,_0x4052a6,_0x23727e){super(_0x34fa39['code'],_0x34fa39['message']),this['operationType']=_0x4052a6,this['user']=_0x23727e,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0xbbc1c9['name'],'tenantId':_0xbbc1c9['tenantId']??void 0x0,'_serverResponse':_0x34fa39['customData']['_serverResponse'],'operationType':_0x4052a6};}static['_fromErrorAndOperation'](_0xba9a58,_0xb68050,_0x411533,_0x5c2703){return new Rn(_0xba9a58,_0xb68050,_0x411533,_0x5c2703);}}function Fa(_0x8cdda9,_0x105ccf,_0x2269a3,_0x2653ab){return(_0x105ccf==='reauthenticate'?_0x2269a3['_getReauthenticationResolver'](_0x8cdda9):_0x2269a3['_getIdTokenResponse'](_0x8cdda9))['catch'](_0x321766=>{throw _0x321766['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x8cdda9,_0x321766,_0x105ccf,_0x2653ab):_0x321766;});}async function jf(_0x2317f7,_0xd931c2,_0x1efb1e=!0x1){const _0x150808=await xt(_0x2317f7,_0xd931c2['_linkToIdToken'](_0x2317f7['auth'],await _0x2317f7['getIdToken']()),_0x1efb1e);return Be['_forOperation'](_0x2317f7,'link',_0x150808);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x41956e,_0x1bab61,_0x497a03=!0x1){const {auth:_0x10177b}=_0x41956e;if(H(_0x10177b['app']))return Promise['reject'](se(_0x10177b));const _0x42d63b='reauthenticate';try{const _0xb65a8b=await xt(_0x41956e,Fa(_0x10177b,_0x42d63b,_0x1bab61,_0x41956e),_0x497a03);m(_0xb65a8b['idToken'],_0x10177b,'internal-error');const _0x2373d1=ws(_0xb65a8b['idToken']);m(_0x2373d1,_0x10177b,'internal-error');const {sub:_0x5f4a23}=_0x2373d1;return m(_0x41956e['uid']===_0x5f4a23,_0x10177b,'user-mismatch'),Be['_forOperation'](_0x41956e,_0x42d63b,_0xb65a8b);}catch(_0x194233){throw(_0x194233==null?void 0x0:_0x194233['code'])==='auth/user-not-found'&&K(_0x10177b,'user-mismatch'),_0x194233;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x2d4c0b,_0x25e8dd,_0x28286e=!0x1){if(H(_0x2d4c0b['app']))return Promise['reject'](se(_0x2d4c0b));const _0x2217bd='signIn',_0x3747d0=await Fa(_0x2d4c0b,_0x2217bd,_0x25e8dd),_0xa2b72=await Be['_fromIdTokenResponse'](_0x2d4c0b,_0x2217bd,_0x3747d0);return _0x28286e||await _0x2d4c0b['_updateCurrentUser'](_0xa2b72['user']),_0xa2b72;}async function Yf(_0x28401a,_0x547df5){return Ua(qe(_0x28401a),_0x547df5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x451ba7){const _0x5b118c=qe(_0x451ba7);_0x5b118c['_getPasswordPolicyInternal']()&&await _0x5b118c['_updatePasswordPolicy']();}async function R_(_0x6cd6f8,_0x52bf58,_0x49b9ee){if(H(_0x6cd6f8['app']))return Promise['reject'](se(_0x6cd6f8));const _0x3bc686=qe(_0x6cd6f8),_0x1efa31=await Oi(_0x3bc686,{'returnSecureToken':!0x0,'email':_0x52bf58,'password':_0x49b9ee,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x3d1d23=>{throw _0x3d1d23['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x6cd6f8),_0x3d1d23;}),_0x451fb8=await Be['_fromIdTokenResponse'](_0x3bc686,'signIn',_0x1efa31);return await _0x3bc686['_updateCurrentUser'](_0x451fb8['user']),_0x451fb8;}function A_(_0x4320dd,_0x2af744,_0x27b4d5){return H(_0x4320dd['app'])?Promise['reject'](se(_0x4320dd)):Yf(k(_0x4320dd),ft['credential'](_0x2af744,_0x27b4d5))['catch'](async _0x3d6013=>{throw _0x3d6013['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4320dd),_0x3d6013;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x275a26,_0x515986){return k(_0x275a26)['setPersistence'](_0x515986);}function Qf(_0x46bd42,_0x2fe4ae,_0x55bb1f,_0xc601ea){return k(_0x46bd42)['onIdTokenChanged'](_0x2fe4ae,_0x55bb1f,_0xc601ea);}function Jf(_0x224ea4,_0xdb078,_0x593c7d){return k(_0x224ea4)['beforeAuthStateChanged'](_0xdb078,_0x593c7d);}function N_(_0x321a32,_0x3cd9ea,_0x4a918a,_0x8f2bf7){return k(_0x321a32)['onAuthStateChanged'](_0x3cd9ea,_0x4a918a,_0x8f2bf7);}function P_(_0xc215b3){return k(_0xc215b3)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x1fd8ab,_0x289ec0){this['storageRetriever']=_0x1fd8ab,this['type']=_0x289ec0;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5bf3fe,_0x2024a3){return this['storage']['setItem'](_0x5bf3fe,JSON['stringify'](_0x2024a3)),Promise['resolve']();}['_get'](_0x11e43c){const _0x2504c1=this['storage']['getItem'](_0x11e43c);return Promise['resolve'](_0x2504c1?JSON['parse'](_0x2504c1):null);}['_remove'](_0x1bf064){return this['storage']['removeItem'](_0x1bf064),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x10c4fc,_0x2253fc)=>this['onStorageEvent'](_0x10c4fc,_0x2253fc),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2a4d82){for(const _0x2d138a of Object['keys'](this['listeners'])){const _0x27e9eb=this['storage']['getItem'](_0x2d138a),_0x42b04e=this['localCache'][_0x2d138a];_0x27e9eb!==_0x42b04e&&_0x2a4d82(_0x2d138a,_0x42b04e,_0x27e9eb);}}['onStorageEvent'](_0x28ef02,_0x426469=!0x1){if(!_0x28ef02['key']){this['forAllChangedKeys']((_0x3d172b,_0x58a166,_0x8adde7)=>{this['notifyListeners'](_0x3d172b,_0x8adde7);});return;}const _0x3fa3af=_0x28ef02['key'];_0x426469?this['detachListener']():this['stopPolling']();const _0x37dbb1=()=>{const _0x170eb1=this['storage']['getItem'](_0x3fa3af);!_0x426469&&this['localCache'][_0x3fa3af]===_0x170eb1||this['notifyListeners'](_0x3fa3af,_0x170eb1);},_0x1f78f1=this['storage']['getItem'](_0x3fa3af);If()&&_0x1f78f1!==_0x28ef02['newValue']&&_0x28ef02['newValue']!==_0x28ef02['oldValue']?setTimeout(_0x37dbb1,Zf):_0x37dbb1();}['notifyListeners'](_0x1cf520,_0x36239f){this['localCache'][_0x1cf520]=_0x36239f;const _0x3e776e=this['listeners'][_0x1cf520];if(_0x3e776e){for(const _0x12368e of Array['from'](_0x3e776e))_0x12368e(_0x36239f&&JSON['parse'](_0x36239f));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1d79ac,_0xf70882,_0x5efa52)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1d79ac,'oldValue':_0xf70882,'newValue':_0x5efa52}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x34079a,_0x3979fb){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x34079a]||(this['listeners'][_0x34079a]=new Set(),this['localCache'][_0x34079a]=this['storage']['getItem'](_0x34079a)),this['listeners'][_0x34079a]['add'](_0x3979fb);}['_removeListener'](_0x49654b,_0x5420b1){this['listeners'][_0x49654b]&&(this['listeners'][_0x49654b]['delete'](_0x5420b1),this['listeners'][_0x49654b]['size']===0x0&&delete this['listeners'][_0x49654b]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x12312b,_0x5c43ca){await super['_set'](_0x12312b,_0x5c43ca),this['localCache'][_0x12312b]=JSON['stringify'](_0x5c43ca);}async['_get'](_0x12aca0){const _0x3044cd=await super['_get'](_0x12aca0);return this['localCache'][_0x12aca0]=JSON['stringify'](_0x3044cd),_0x3044cd;}async['_remove'](_0x3f8794){await super['_remove'](_0x3f8794),delete this['localCache'][_0x3f8794];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3e2a83,_0x5522ff){}['_removeListener'](_0x1afebe,_0x21761a){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x1949c0){return Promise['all'](_0x1949c0['map'](async _0x576d21=>{try{return{'fulfilled':!0x0,'value':await _0x576d21};}catch(_0x1d9917){return{'fulfilled':!0x1,'reason':_0x1d9917};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x52ee02){this['eventTarget']=_0x52ee02,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3258d4){const _0x2a1e85=this['receivers']['find'](_0x376416=>_0x376416['isListeningto'](_0x3258d4));if(_0x2a1e85)return _0x2a1e85;const _0x506fca=new jn(_0x3258d4);return this['receivers']['push'](_0x506fca),_0x506fca;}['isListeningto'](_0x333a98){return this['eventTarget']===_0x333a98;}async['handleEvent'](_0x299aa9){const _0x1f1474=_0x299aa9,{eventId:_0x3cdb66,eventType:_0x1b86cd,data:_0x22a7af}=_0x1f1474['data'],_0x357e49=this['handlersMap'][_0x1b86cd];if(!(_0x357e49!=null&&_0x357e49['size']))return;_0x1f1474['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3cdb66,'eventType':_0x1b86cd});const _0x1dbb02=Array['from'](_0x357e49)['map'](async _0x190c46=>_0x190c46(_0x1f1474['origin'],_0x22a7af)),_0x535b01=await tp(_0x1dbb02);_0x1f1474['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3cdb66,'eventType':_0x1b86cd,'response':_0x535b01});}['_subscribe'](_0x41535a,_0x31d14b){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x41535a]||(this['handlersMap'][_0x41535a]=new Set()),this['handlersMap'][_0x41535a]['add'](_0x31d14b);}['_unsubscribe'](_0x3e60a8,_0x557351){this['handlersMap'][_0x3e60a8]&&_0x557351&&this['handlersMap'][_0x3e60a8]['delete'](_0x557351),(!_0x557351||this['handlersMap'][_0x3e60a8]['size']===0x0)&&delete this['handlersMap'][_0x3e60a8],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x3877d3='',_0x5ab164=0xa){let _0x33ddb6='';for(let _0x2828c0=0x0;_0x2828c0<_0x5ab164;_0x2828c0++)_0x33ddb6+=Math['floor'](Math['random']()*0xa);return _0x3877d3+_0x33ddb6;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x5b5b5c){this['target']=_0x5b5b5c,this['handlers']=new Set();}['removeMessageHandler'](_0x21d2d8){_0x21d2d8['messageChannel']&&(_0x21d2d8['messageChannel']['port1']['removeEventListener']('message',_0x21d2d8['onMessage']),_0x21d2d8['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x21d2d8);}async['_send'](_0x1a3dcc,_0x1bdefa,_0x38cb5a=0x32){const _0xac6da6=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xac6da6)throw new Error('connection_unavailable');let _0x550c15,_0x48bf49;return new Promise((_0x335972,_0x4e117b)=>{const _0x53d13e=bs('',0x14);_0xac6da6['port1']['start']();const _0x599c8b=setTimeout(()=>{_0x4e117b(new Error('unsupported_event'));},_0x38cb5a);_0x48bf49={'messageChannel':_0xac6da6,'onMessage'(_0x2f50fb){const _0x15695e=_0x2f50fb;if(_0x15695e['data']['eventId']===_0x53d13e)switch(_0x15695e['data']['status']){case'ack':clearTimeout(_0x599c8b),_0x550c15=setTimeout(()=>{_0x4e117b(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x550c15),_0x335972(_0x15695e['data']['response']);break;default:clearTimeout(_0x599c8b),clearTimeout(_0x550c15),_0x4e117b(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x48bf49),_0xac6da6['port1']['addEventListener']('message',_0x48bf49['onMessage']),this['target']['postMessage']({'eventType':_0x1a3dcc,'eventId':_0x53d13e,'data':_0x1bdefa},[_0xac6da6['port2']]);})['finally'](()=>{_0x48bf49&&this['removeMessageHandler'](_0x48bf49);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x46d7c0){X()['location']['href']=_0x46d7c0;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x518cf6;return((_0x518cf6=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x518cf6['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0xee9fd5){this['request']=_0xee9fd5;}['toPromise'](){return new Promise((_0x53b656,_0x553cc2)=>{this['request']['addEventListener']('success',()=>{_0x53b656(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x553cc2(this['request']['error']);});});}}function Kn(_0x3f4545,_0x4ee5f3){return _0x3f4545['transaction']([kn],_0x4ee5f3?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x25ccaa=indexedDB['deleteDatabase'](qa);return new Jt(_0x25ccaa)['toPromise']();}function ja(){const _0x3b2839=indexedDB['open'](qa,ap);return new Promise((_0x499fc3,_0x5d222f)=>{_0x3b2839['addEventListener']('error',()=>{_0x5d222f(_0x3b2839['error']);}),_0x3b2839['addEventListener']('upgradeneeded',()=>{const _0x5a20c0=_0x3b2839['result'];try{_0x5a20c0['createObjectStore'](kn,{'keyPath':za});}catch(_0x3cda09){_0x5d222f(_0x3cda09);}}),_0x3b2839['addEventListener']('success',async()=>{const _0x48d6f3=_0x3b2839['result'];_0x48d6f3['objectStoreNames']['contains'](kn)?_0x499fc3(_0x48d6f3):(_0x48d6f3['close'](),await cp(),_0x499fc3(await ja()));});});}async function kr(_0x547aeb,_0x37dab7,_0x358918){const _0x248afc=Kn(_0x547aeb,!0x0)['put']({[za]:_0x37dab7,'value':_0x358918});return new Jt(_0x248afc)['toPromise']();}async function lp(_0x181791,_0x7366f9){const _0xd12da9=Kn(_0x181791,!0x1)['get'](_0x7366f9),_0x527c6f=await new Jt(_0xd12da9)['toPromise']();return _0x527c6f===void 0x0?null:_0x527c6f['value'];}function Nr(_0x358119,_0x330e54){const _0x32f6e9=Kn(_0x358119,!0x0)['delete'](_0x330e54);return new Jt(_0x32f6e9)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x426a2f){let _0x204cd2=0x0;for(;;)try{const _0x37c505=await this['_openDb']();return await _0x426a2f(_0x37c505);}catch(_0x17febf){if(_0x204cd2++>up)throw _0x17febf;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x13042e,_0x1937ff)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1937ff['key'])})),this['receiver']['_subscribe']('ping',async(_0x32d063,_0x51f595)=>['keyChanged']);}async['initializeSender'](){var _0x20cbad,_0x1cc342;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x39991b=await this['sender']['_send']('ping',{},0x320);_0x39991b&&(_0x20cbad=_0x39991b[0x0])!=null&&_0x20cbad['fulfilled']&&(_0x1cc342=_0x39991b[0x0])!=null&&_0x1cc342['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x1b8b52){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x1b8b52},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x14958b=>{await kr(_0x14958b,An,'1'),await Nr(_0x14958b,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x238304){this['pendingWrites']++;try{await _0x238304();}finally{this['pendingWrites']--;}}async['_set'](_0x43a77e,_0x2659c5){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5ab036=>kr(_0x5ab036,_0x43a77e,_0x2659c5)),this['localCache'][_0x43a77e]=_0x2659c5,this['notifyServiceWorker'](_0x43a77e)));}async['_get'](_0x56136b){const _0x26a344=await this['_withRetries'](_0x292c87=>lp(_0x292c87,_0x56136b));return this['localCache'][_0x56136b]=_0x26a344,_0x26a344;}async['_remove'](_0x4c4d4a){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2ebf0c=>Nr(_0x2ebf0c,_0x4c4d4a)),delete this['localCache'][_0x4c4d4a],this['notifyServiceWorker'](_0x4c4d4a)));}async['_poll'](){const _0x6b5831=await this['_withRetries'](_0x20f16a=>{const _0x27bfb4=Kn(_0x20f16a,!0x1)['getAll']();return new Jt(_0x27bfb4)['toPromise']();});if(!_0x6b5831)return[];if(this['pendingWrites']!==0x0)return[];const _0x4d42d1=[],_0x31263f=new Set();if(_0x6b5831['length']!==0x0){for(const {fbase_key:_0x4b3b8b,value:_0x49ec14}of _0x6b5831)_0x31263f['add'](_0x4b3b8b),JSON['stringify'](this['localCache'][_0x4b3b8b])!==JSON['stringify'](_0x49ec14)&&(this['notifyListeners'](_0x4b3b8b,_0x49ec14),_0x4d42d1['push'](_0x4b3b8b));}for(const _0x2a0f95 of Object['keys'](this['localCache']))this['localCache'][_0x2a0f95]&&!_0x31263f['has'](_0x2a0f95)&&(this['notifyListeners'](_0x2a0f95,null),_0x4d42d1['push'](_0x2a0f95));return _0x4d42d1;}['notifyListeners'](_0x56abf6,_0x453c03){this['localCache'][_0x56abf6]=_0x453c03;const _0x144880=this['listeners'][_0x56abf6];if(_0x144880){for(const _0x11118f of Array['from'](_0x144880))_0x11118f(_0x453c03);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3dfd41,_0x22179f){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3dfd41]||(this['listeners'][_0x3dfd41]=new Set(),this['_get'](_0x3dfd41)),this['listeners'][_0x3dfd41]['add'](_0x22179f);}['_removeListener'](_0xbf477b,_0x3a5128){this['listeners'][_0xbf477b]&&(this['listeners'][_0xbf477b]['delete'](_0x3a5128),this['listeners'][_0xbf477b]['size']===0x0&&delete this['listeners'][_0xbf477b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x37e9c7,_0x3a2e7f){return _0x3a2e7f?ne(_0x3a2e7f):(m(_0x37e9c7['_popupRedirectResolver'],_0x37e9c7,'argument-error'),_0x37e9c7['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x3ceb23){super('custom','custom'),this['params']=_0x3ceb23;}['_getIdTokenResponse'](_0x4400e9){return Ze(_0x4400e9,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1dba46,_0x516df3){return Ze(_0x1dba46,this['_buildIdpRequest'](_0x516df3));}['_getReauthenticationResolver'](_0x12de74){return Ze(_0x12de74,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x12c393){const _0x4f3708={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x12c393&&(_0x4f3708['idToken']=_0x12c393),_0x4f3708;}}function pp(_0x546ae3){return Ua(_0x546ae3['auth'],new Rs(_0x546ae3),_0x546ae3['bypassAuthState']);}function _p(_0x1e23ab){const {auth:_0x40bf59,user:_0x181058}=_0x1e23ab;return m(_0x181058,_0x40bf59,'internal-error'),Kf(_0x181058,new Rs(_0x1e23ab),_0x1e23ab['bypassAuthState']);}async function gp(_0x379df3){const {auth:_0x1c79e6,user:_0x3dbd39}=_0x379df3;return m(_0x3dbd39,_0x1c79e6,'internal-error'),jf(_0x3dbd39,new Rs(_0x379df3),_0x379df3['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x31b9c7,_0x5ba6d1,_0x48f492,_0x44a10b,_0xe7e0c7=!0x1){this['auth']=_0x31b9c7,this['resolver']=_0x48f492,this['user']=_0x44a10b,this['bypassAuthState']=_0xe7e0c7,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5ba6d1)?_0x5ba6d1:[_0x5ba6d1];}['execute'](){return new Promise(async(_0x2056e3,_0xb0a0bf)=>{this['pendingPromise']={'resolve':_0x2056e3,'reject':_0xb0a0bf};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x6dba5d){this['reject'](_0x6dba5d);}});}async['onAuthEvent'](_0x4c634c){const {urlResponse:_0x5712b8,sessionId:_0x5f403a,postBody:_0xdc94c6,tenantId:_0x14f50a,error:_0x2d3247,type:_0x2b5441}=_0x4c634c;if(_0x2d3247){this['reject'](_0x2d3247);return;}const _0x447116={'auth':this['auth'],'requestUri':_0x5712b8,'sessionId':_0x5f403a,'tenantId':_0x14f50a||void 0x0,'postBody':_0xdc94c6||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2b5441)(_0x447116));}catch(_0x30bcba){this['reject'](_0x30bcba);}}['onError'](_0x51fafb){this['reject'](_0x51fafb);}['getIdpTask'](_0x4cb033){switch(_0x4cb033){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x1ccc1a){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1ccc1a),this['unregisterAndCleanUp']();}['reject'](_0x14144d){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x14144d),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x3534c9,_0xa29b34,_0x171d12,_0x30a96d,_0x1096d8){super(_0x3534c9,_0xa29b34,_0x30a96d,_0x1096d8),this['provider']=_0x171d12,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x1d244a=await this['execute']();return m(_0x1d244a,this['auth'],'internal-error'),_0x1d244a;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5f1e7e=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5f1e7e),this['authWindow']['associatedEvent']=_0x5f1e7e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2f0e16=>{this['reject'](_0x2f0e16);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1a9675=>{_0x1a9675||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x151c41;return((_0x151c41=this['authWindow'])==null?void 0x0:_0x151c41['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1cef3a=()=>{var _0x1e8475,_0x37e45a;if((_0x37e45a=(_0x1e8475=this['authWindow'])==null?void 0x0:_0x1e8475['window'])!=null&&_0x37e45a['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1cef3a,mp['get']());};_0x1cef3a();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x117f88,_0x3948d7,_0x14e30c=!0x1){super(_0x117f88,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3948d7,void 0x0,_0x14e30c),this['eventId']=null;}async['execute'](){let _0x1b0055=rn['get'](this['auth']['_key']());if(!_0x1b0055){try{const _0x4d9237=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x1b0055=()=>Promise['resolve'](_0x4d9237);}catch(_0x5f0d49){_0x1b0055=()=>Promise['reject'](_0x5f0d49);}rn['set'](this['auth']['_key'](),_0x1b0055);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x1b0055();}async['onAuthEvent'](_0x33f094){if(_0x33f094['type']==='signInViaRedirect')return super['onAuthEvent'](_0x33f094);if(_0x33f094['type']==='unknown'){this['resolve'](null);return;}if(_0x33f094['eventId']){const _0x657656=await this['auth']['_redirectUserForId'](_0x33f094['eventId']);if(_0x657656)return this['user']=_0x657656,super['onAuthEvent'](_0x33f094);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x3856f2,_0x342a2a){const _0x12491a=Cp(_0x342a2a),_0x229463=wp(_0x3856f2);if(!await _0x229463['_isAvailable']())return!0x1;const _0x254ea3=await _0x229463['_get'](_0x12491a)==='true';return await _0x229463['_remove'](_0x12491a),_0x254ea3;}function Ip(_0x39954e,_0x34e1d7){rn['set'](_0x39954e['_key'](),_0x34e1d7);}function wp(_0x2117d3){return ne(_0x2117d3['_redirectPersistence']);}function Cp(_0xa9ebaf){return sn(yp,_0xa9ebaf['config']['apiKey'],_0xa9ebaf['name']);}async function Tp(_0x5a5ab0,_0x55ba85,_0x981ece=!0x1){if(H(_0x5a5ab0['app']))return Promise['reject'](se(_0x5a5ab0));const _0x54943c=qe(_0x5a5ab0),_0x24bb41=fp(_0x54943c,_0x55ba85),_0xa58a75=await new vp(_0x54943c,_0x24bb41,_0x981ece)['execute']();return _0xa58a75&&!_0x981ece&&(delete _0xa58a75['user']['_redirectEventId'],await _0x54943c['_persistUserIfCurrent'](_0xa58a75['user']),await _0x54943c['_setRedirectUser'](null,_0x55ba85)),_0xa58a75;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x2dacdf){this['auth']=_0x2dacdf,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xc5aa9d){this['consumers']['add'](_0xc5aa9d),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xc5aa9d)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xc5aa9d),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5656aa){this['consumers']['delete'](_0x5656aa);}['onEvent'](_0x284463){if(this['hasEventBeenHandled'](_0x284463))return!0x1;let _0x5ee9a3=!0x1;return this['consumers']['forEach'](_0x499a9a=>{this['isEventForConsumer'](_0x284463,_0x499a9a)&&(_0x5ee9a3=!0x0,this['sendToConsumer'](_0x284463,_0x499a9a),this['saveEventToCache'](_0x284463));}),this['hasHandledPotentialRedirect']||!Rp(_0x284463)||(this['hasHandledPotentialRedirect']=!0x0,_0x5ee9a3||(this['queuedRedirectEvent']=_0x284463,_0x5ee9a3=!0x0)),_0x5ee9a3;}['sendToConsumer'](_0x1333ef,_0x152c3a){var _0x26a8b7;if(_0x1333ef['error']&&!Qa(_0x1333ef)){const _0x1fa92d=((_0x26a8b7=_0x1333ef['error']['code'])==null?void 0x0:_0x26a8b7['split']('auth/')[0x1])||'internal-error';_0x152c3a['onError'](J(this['auth'],_0x1fa92d));}else _0x152c3a['onAuthEvent'](_0x1333ef);}['isEventForConsumer'](_0x50719a,_0x247dd6){const _0x6c77b9=_0x247dd6['eventId']===null||!!_0x50719a['eventId']&&_0x50719a['eventId']===_0x247dd6['eventId'];return _0x247dd6['filter']['includes'](_0x50719a['type'])&&_0x6c77b9;}['hasEventBeenHandled'](_0x290c7f){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x290c7f));}['saveEventToCache'](_0x182174){this['cachedEventUids']['add'](Pr(_0x182174)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x577ebf){return[_0x577ebf['type'],_0x577ebf['eventId'],_0x577ebf['sessionId'],_0x577ebf['tenantId']]['filter'](_0x32e0d7=>_0x32e0d7)['join']('-');}function Qa({type:_0x46a333,error:_0x2f809a}){return _0x46a333==='unknown'&&(_0x2f809a==null?void 0x0:_0x2f809a['code'])==='auth/no-auth-event';}function Rp(_0x1085e2){switch(_0x1085e2['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x1085e2);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x3811f8,_0x6f81fd={}){return Ae(_0x3811f8,'GET','/v1/projects',_0x6f81fd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x433aca){if(_0x433aca['config']['emulator'])return;const {authorizedDomains:_0x133871}=await Ap(_0x433aca);for(const _0x4a98c2 of _0x133871)try{if(Op(_0x4a98c2))return;}catch{}K(_0x433aca,'unauthorized-domain');}function Op(_0x882ba){const _0x3c21c1=Ni(),{protocol:_0x437c27,hostname:_0x5ea61f}=new URL(_0x3c21c1);if(_0x882ba['startsWith']('chrome-extension://')){const _0x56d8c1=new URL(_0x882ba);return _0x56d8c1['hostname']===''&&_0x5ea61f===''?_0x437c27==='chrome-extension:'&&_0x882ba['replace']('chrome-extension://','')===_0x3c21c1['replace']('chrome-extension://',''):_0x437c27==='chrome-extension:'&&_0x56d8c1['hostname']===_0x5ea61f;}if(!Np['test'](_0x437c27))return!0x1;if(kp['test'](_0x882ba))return _0x5ea61f===_0x882ba;const _0x394556=_0x882ba['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x394556+'|'+_0x394556+')$','i')['test'](_0x5ea61f);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x3c2a57=X()['___jsl'];if(_0x3c2a57!=null&&_0x3c2a57['H']){for(const _0x452460 of Object['keys'](_0x3c2a57['H']))if(_0x3c2a57['H'][_0x452460]['r']=_0x3c2a57['H'][_0x452460]['r']||[],_0x3c2a57['H'][_0x452460]['L']=_0x3c2a57['H'][_0x452460]['L']||[],_0x3c2a57['H'][_0x452460]['r']=[..._0x3c2a57['H'][_0x452460]['L']],_0x3c2a57['CP']){for(let _0x3d9769=0x0;_0x3d9769<_0x3c2a57['CP']['length'];_0x3d9769++)_0x3c2a57['CP'][_0x3d9769]=null;}}}function Mp(_0x404808){return new Promise((_0xbd97d3,_0x531ccd)=>{var _0x505297,_0x25d741,_0x17bfa9;function _0x2dd31f(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0xbd97d3(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x531ccd(J(_0x404808,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x25d741=(_0x505297=X()['gapi'])==null?void 0x0:_0x505297['iframes'])!=null&&_0x25d741['Iframe'])_0xbd97d3(gapi['iframes']['getContext']());else{if((_0x17bfa9=X()['gapi'])!=null&&_0x17bfa9['load'])_0x2dd31f();else{const _0x3571ea=Nf('iframefcb');return X()[_0x3571ea]=()=>{gapi['load']?_0x2dd31f():_0x531ccd(J(_0x404808,'network-request-failed'));},Da(kf()+'?onload='+_0x3571ea)['catch'](_0x56b9b7=>_0x531ccd(_0x56b9b7));}}})['catch'](_0x1fb6d7=>{throw on=null,_0x1fb6d7;});}let on=null;function Lp(_0x57fecd){return on=on||Mp(_0x57fecd),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x7762f0){const _0x3782f3=_0x7762f0['config'];m(_0x3782f3['authDomain'],_0x7762f0,'auth-domain-config-required');const _0x2579f3=_0x3782f3['emulator']?Is(_0x3782f3,Up):'https://'+_0x7762f0['config']['authDomain']+'/'+Fp,_0x2052a3={'apiKey':_0x3782f3['apiKey'],'appName':_0x7762f0['name'],'v':ct},_0x6e865d=Bp['get'](_0x7762f0['config']['apiHost']);_0x6e865d&&(_0x2052a3['eid']=_0x6e865d);const _0x3a4769=_0x7762f0['_getFrameworks']();return _0x3a4769['length']&&(_0x2052a3['fw']=_0x3a4769['join'](',')),_0x2579f3+'?'+at(_0x2052a3)['slice'](0x1);}async function Hp(_0xc54fe2){const _0xe39794=await Lp(_0xc54fe2),_0x4c591e=X()['gapi'];return m(_0x4c591e,_0xc54fe2,'internal-error'),_0xe39794['open']({'where':document['body'],'url':Vp(_0xc54fe2),'messageHandlersFilter':_0x4c591e['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x5187bf=>new Promise(async(_0x305b63,_0x8e926e)=>{await _0x5187bf['restyle']({'setHideOnLeave':!0x1});const _0x2d8f28=J(_0xc54fe2,'network-request-failed'),_0x3a8824=X()['setTimeout'](()=>{_0x8e926e(_0x2d8f28);},xp['get']());function _0x28776f(){X()['clearTimeout'](_0x3a8824),_0x305b63(_0x5187bf);}_0x5187bf['ping'](_0x28776f)['then'](_0x28776f,()=>{_0x8e926e(_0x2d8f28);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x1fc3cc){this['window']=_0x1fc3cc,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x29e62d,_0x387022,_0x154a8a,_0x3a1c8f=Gp,_0x10bb65=qp){const _0xe3e367=Math['max']((window['screen']['availHeight']-_0x10bb65)/0x2,0x0)['toString'](),_0x3041f8=Math['max']((window['screen']['availWidth']-_0x3a1c8f)/0x2,0x0)['toString']();let _0x1b2ffd='';const _0x1a80d9={...$p,'width':_0x3a1c8f['toString'](),'height':_0x10bb65['toString'](),'top':_0xe3e367,'left':_0x3041f8},_0x40c650=W()['toLowerCase']();_0x154a8a&&(_0x1b2ffd=ba(_0x40c650)?zp:_0x154a8a),Ta(_0x40c650)&&(_0x387022=_0x387022||jp,_0x1a80d9['scrollbars']='yes');const _0x4a36c9=Object['entries'](_0x1a80d9)['reduce']((_0x232ac1,[_0x5846d6,_0x4ea0c4])=>''+_0x232ac1+_0x5846d6+'='+_0x4ea0c4+',','');if(Ef(_0x40c650)&&_0x1b2ffd!=='_self')return Yp(_0x387022||'',_0x1b2ffd),new Dr(null);const _0x115c6e=window['open'](_0x387022||'',_0x1b2ffd,_0x4a36c9);m(_0x115c6e,_0x29e62d,'popup-blocked');try{_0x115c6e['focus']();}catch{}return new Dr(_0x115c6e);}function Yp(_0x5c34c6,_0x2e4468){const _0x49e65a=document['createElement']('a');_0x49e65a['href']=_0x5c34c6,_0x49e65a['target']=_0x2e4468;const _0x26741e=document['createEvent']('MouseEvent');_0x26741e['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x49e65a['dispatchEvent'](_0x26741e);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x3b3e38,_0x2d0678,_0x21644d,_0x343821,_0x22c125,_0xcd1b50){m(_0x3b3e38['config']['authDomain'],_0x3b3e38,'auth-domain-config-required'),m(_0x3b3e38['config']['apiKey'],_0x3b3e38,'invalid-api-key');const _0x1c61e0={'apiKey':_0x3b3e38['config']['apiKey'],'appName':_0x3b3e38['name'],'authType':_0x21644d,'redirectUrl':_0x343821,'v':ct,'eventId':_0x22c125};if(_0x2d0678 instanceof xa){_0x2d0678['setDefaultLanguage'](_0x3b3e38['languageCode']),_0x1c61e0['providerId']=_0x2d0678['providerId']||'',hi(_0x2d0678['getCustomParameters']())||(_0x1c61e0['customParameters']=JSON['stringify'](_0x2d0678['getCustomParameters']()));for(const [_0x4ad146,_0xdaf42c]of Object['entries']({}))_0x1c61e0[_0x4ad146]=_0xdaf42c;}if(_0x2d0678 instanceof Qt){const _0x559487=_0x2d0678['getScopes']()['filter'](_0x121853=>_0x121853!=='');_0x559487['length']>0x0&&(_0x1c61e0['scopes']=_0x559487['join'](','));}_0x3b3e38['tenantId']&&(_0x1c61e0['tid']=_0x3b3e38['tenantId']);const _0x1d7f1f=_0x1c61e0;for(const _0x14fba5 of Object['keys'](_0x1d7f1f))_0x1d7f1f[_0x14fba5]===void 0x0&&delete _0x1d7f1f[_0x14fba5];const _0x43e60d=await _0x3b3e38['_getAppCheckToken'](),_0x336c83=_0x43e60d?'#'+Xp+'='+encodeURIComponent(_0x43e60d):'';return Zp(_0x3b3e38)+'?'+at(_0x1d7f1f)['slice'](0x1)+_0x336c83;}function Zp({config:_0x51da31}){return _0x51da31['emulator']?Is(_0x51da31,Jp):'https://'+_0x51da31['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x25be29,_0x148e36,_0x5609cf,_0x427f46){var _0x3e72f6;ae((_0x3e72f6=this['eventManagers'][_0x25be29['_key']()])==null?void 0x0:_0x3e72f6['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x20e6fa=await Mr(_0x25be29,_0x148e36,_0x5609cf,Ni(),_0x427f46);return Kp(_0x25be29,_0x20e6fa,bs());}async['_openRedirect'](_0x5567c3,_0xd14118,_0x4cda24,_0x8d3956){await this['_originValidation'](_0x5567c3);const _0x49c44c=await Mr(_0x5567c3,_0xd14118,_0x4cda24,Ni(),_0x8d3956);return ip(_0x49c44c),new Promise(()=>{});}['_initialize'](_0x14a530){const _0x35ba0b=_0x14a530['_key']();if(this['eventManagers'][_0x35ba0b]){const {manager:_0x466727,promise:_0x3bd211}=this['eventManagers'][_0x35ba0b];return _0x466727?Promise['resolve'](_0x466727):(ae(_0x3bd211,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3bd211);}const _0x1c5ad0=this['initAndGetManager'](_0x14a530);return this['eventManagers'][_0x35ba0b]={'promise':_0x1c5ad0},_0x1c5ad0['catch'](()=>{delete this['eventManagers'][_0x35ba0b];}),_0x1c5ad0;}async['initAndGetManager'](_0x308761){const _0x560971=await Hp(_0x308761),_0x56ac0e=new bp(_0x308761);return _0x560971['register']('authEvent',_0x4d1382=>(m(_0x4d1382==null?void 0x0:_0x4d1382['authEvent'],_0x308761,'invalid-auth-event'),{'status':_0x56ac0e['onEvent'](_0x4d1382['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x308761['_key']()]={'manager':_0x56ac0e},this['iframes'][_0x308761['_key']()]=_0x560971,_0x56ac0e;}['_isIframeWebStorageSupported'](_0x1f1fef,_0x2f5bc3){this['iframes'][_0x1f1fef['_key']()]['send'](li,{'type':li},_0x51b851=>{var _0x3dfb6e;const _0xa300c=(_0x3dfb6e=_0x51b851==null?void 0x0:_0x51b851[0x0])==null?void 0x0:_0x3dfb6e[li];_0xa300c!==void 0x0&&_0x2f5bc3(!!_0xa300c),K(_0x1f1fef,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x153f49){const _0x56eeb9=_0x153f49['_key']();return this['originValidationPromises'][_0x56eeb9]||(this['originValidationPromises'][_0x56eeb9]=Pp(_0x153f49)),this['originValidationPromises'][_0x56eeb9];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x573a5b){this['auth']=_0x573a5b,this['internalListeners']=new Map();}['getUid'](){var _0xc1b6a0;return this['assertAuthConfigured'](),((_0xc1b6a0=this['auth']['currentUser'])==null?void 0x0:_0xc1b6a0['uid'])||null;}async['getToken'](_0x2dcf22){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2dcf22)}:null;}['addAuthTokenListener'](_0x20060c){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x20060c))return;const _0x30b84e=this['auth']['onIdTokenChanged'](_0x20ef71=>{_0x20060c((_0x20ef71==null?void 0x0:_0x20ef71['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x20060c,_0x30b84e),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3861b5){this['assertAuthConfigured']();const _0x227384=this['internalListeners']['get'](_0x3861b5);_0x227384&&(this['internalListeners']['delete'](_0x3861b5),_0x227384(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x2476e8){switch(_0x2476e8){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x2b6e3f){et(new Me('auth',(_0x2678d8,{options:_0x16937a})=>{const _0x55d42e=_0x2678d8['getProvider']('app')['getImmediate'](),_0x2b416d=_0x2678d8['getProvider']('heartbeat'),_0x54013a=_0x2678d8['getProvider']('app-check-internal'),{apiKey:_0x5294c1,authDomain:_0x4dc4ac}=_0x55d42e['options'];m(_0x5294c1&&!_0x5294c1['includes'](':'),'invalid-api-key',{'appName':_0x55d42e['name']});const _0x42f67f={'apiKey':_0x5294c1,'authDomain':_0x4dc4ac,'clientPlatform':_0x2b6e3f,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x2b6e3f)},_0x4c78a8=new bf(_0x55d42e,_0x2b416d,_0x54013a,_0x42f67f);return Lf(_0x4c78a8,_0x16937a),_0x4c78a8;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x484e21,_0x4f8735,_0x92d226)=>{_0x484e21['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x3beb4b=>{const _0x403cb1=qe(_0x3beb4b['getProvider']('auth')['getImmediate']());return(_0x1c22c7=>new n_(_0x1c22c7))(_0x403cb1);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x2b6e3f)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0xaa8c2f=>async _0x18008d=>{const _0xb144b8=_0x18008d&&await _0x18008d['getIdTokenResult'](),_0x5bd1c2=_0xb144b8&&(new Date()['getTime']()-Date['parse'](_0xb144b8['issuedAtTime']))/0x3e8;if(_0x5bd1c2&&_0x5bd1c2>o_)return;const _0x86f6fd=_0xb144b8==null?void 0x0:_0xb144b8['token'];Fr!==_0x86f6fd&&(Fr=_0x86f6fd,await fetch(_0xaa8c2f,{'method':_0x86f6fd?'POST':'DELETE','headers':_0x86f6fd?{'Authorization':'Bearer\x20'+_0x86f6fd}:{}}));};function O_(_0x847211=Qr()){const _0x369082=Ui(_0x847211,'auth');if(_0x369082['isInitialized']())return _0x369082['getImmediate']();const _0x51a938=Mf(_0x847211,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x2d54a9=Gr('authTokenSyncURL');if(_0x2d54a9&&typeof isSecureContext=='boolean'&&isSecureContext){const _0xe51e09=new URL(_0x2d54a9,location['origin']);if(location['origin']===_0xe51e09['origin']){const _0x2b22e7=a_(_0xe51e09['toString']());Jf(_0x51a938,_0x2b22e7,()=>_0x2b22e7(_0x51a938['currentUser'])),Qf(_0x51a938,_0x195db3=>_0x2b22e7(_0x195db3));}}const _0x2c4627=Hr('auth');return _0x2c4627&&xf(_0x51a938,'http://'+_0x2c4627),_0x51a938;}function c_(){var _0x4d9cee;return((_0x4d9cee=document['getElementsByTagName']('head'))==null?void 0x0:_0x4d9cee[0x0])??document;}Rf({'loadJS'(_0x5d46e2){return new Promise((_0x4c1687,_0x26990e)=>{const _0x3478cb=document['createElement']('script');_0x3478cb['setAttribute']('src',_0x5d46e2),_0x3478cb['onload']=_0x4c1687,_0x3478cb['onerror']=_0x13ba2c=>{const _0x10cf11=J('internal-error');_0x10cf11['customData']=_0x13ba2c,_0x26990e(_0x10cf11);},_0x3478cb['type']='text/javascript',_0x3478cb['charset']='UTF-8',c_()['appendChild'](_0x3478cb);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};