const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x43a93b,_0x3efb7b){if(!_0x43a93b)throw ot(_0x3efb7b);},ot=function(_0x2527c4){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2527c4);},Wr=function(_0x4953b4){const _0x5a5ff9=[];let _0x5b2f6a=0x0;for(let _0x3bee06=0x0;_0x3bee06<_0x4953b4['length'];_0x3bee06++){let _0x475dc4=_0x4953b4['charCodeAt'](_0x3bee06);_0x475dc4<0x80?_0x5a5ff9[_0x5b2f6a++]=_0x475dc4:_0x475dc4<0x800?(_0x5a5ff9[_0x5b2f6a++]=_0x475dc4>>0x6|0xc0,_0x5a5ff9[_0x5b2f6a++]=_0x475dc4&0x3f|0x80):(_0x475dc4&0xfc00)===0xd800&&_0x3bee06+0x1<_0x4953b4['length']&&(_0x4953b4['charCodeAt'](_0x3bee06+0x1)&0xfc00)===0xdc00?(_0x475dc4=0x10000+((_0x475dc4&0x3ff)<<0xa)+(_0x4953b4['charCodeAt'](++_0x3bee06)&0x3ff),_0x5a5ff9[_0x5b2f6a++]=_0x475dc4>>0x12|0xf0,_0x5a5ff9[_0x5b2f6a++]=_0x475dc4>>0xc&0x3f|0x80,_0x5a5ff9[_0x5b2f6a++]=_0x475dc4>>0x6&0x3f|0x80,_0x5a5ff9[_0x5b2f6a++]=_0x475dc4&0x3f|0x80):(_0x5a5ff9[_0x5b2f6a++]=_0x475dc4>>0xc|0xe0,_0x5a5ff9[_0x5b2f6a++]=_0x475dc4>>0x6&0x3f|0x80,_0x5a5ff9[_0x5b2f6a++]=_0x475dc4&0x3f|0x80);}return _0x5a5ff9;},Za=function(_0x855064){const _0x36e816=[];let _0x1b81bc=0x0,_0x4065d5=0x0;for(;_0x1b81bc<_0x855064['length'];){const _0x2bae72=_0x855064[_0x1b81bc++];if(_0x2bae72<0x80)_0x36e816[_0x4065d5++]=String['fromCharCode'](_0x2bae72);else{if(_0x2bae72>0xbf&&_0x2bae72<0xe0){const _0x5ddaef=_0x855064[_0x1b81bc++];_0x36e816[_0x4065d5++]=String['fromCharCode']((_0x2bae72&0x1f)<<0x6|_0x5ddaef&0x3f);}else{if(_0x2bae72>0xef&&_0x2bae72<0x16d){const _0x51ff57=_0x855064[_0x1b81bc++],_0x1e0dc9=_0x855064[_0x1b81bc++],_0x4e65c3=_0x855064[_0x1b81bc++],_0x5f1aef=((_0x2bae72&0x7)<<0x12|(_0x51ff57&0x3f)<<0xc|(_0x1e0dc9&0x3f)<<0x6|_0x4e65c3&0x3f)-0x10000;_0x36e816[_0x4065d5++]=String['fromCharCode'](0xd800+(_0x5f1aef>>0xa)),_0x36e816[_0x4065d5++]=String['fromCharCode'](0xdc00+(_0x5f1aef&0x3ff));}else{const _0x3042d0=_0x855064[_0x1b81bc++],_0x108db7=_0x855064[_0x1b81bc++];_0x36e816[_0x4065d5++]=String['fromCharCode']((_0x2bae72&0xf)<<0xc|(_0x3042d0&0x3f)<<0x6|_0x108db7&0x3f);}}}}return _0x36e816['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x1045e2,_0x276858){if(!Array['isArray'](_0x1045e2))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x5d6bef=_0x276858?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3d3211=[];for(let _0x1e1644=0x0;_0x1e1644<_0x1045e2['length'];_0x1e1644+=0x3){const _0x1335af=_0x1045e2[_0x1e1644],_0x77bfd3=_0x1e1644+0x1<_0x1045e2['length'],_0x2af329=_0x77bfd3?_0x1045e2[_0x1e1644+0x1]:0x0,_0x39fffc=_0x1e1644+0x2<_0x1045e2['length'],_0x226402=_0x39fffc?_0x1045e2[_0x1e1644+0x2]:0x0,_0x442828=_0x1335af>>0x2,_0x5e0ed6=(_0x1335af&0x3)<<0x4|_0x2af329>>0x4;let _0x2dd25a=(_0x2af329&0xf)<<0x2|_0x226402>>0x6,_0x32c290=_0x226402&0x3f;_0x39fffc||(_0x32c290=0x40,_0x77bfd3||(_0x2dd25a=0x40)),_0x3d3211['push'](_0x5d6bef[_0x442828],_0x5d6bef[_0x5e0ed6],_0x5d6bef[_0x2dd25a],_0x5d6bef[_0x32c290]);}return _0x3d3211['join']('');},'encodeString'(_0x2b4039,_0x321c05){return this['HAS_NATIVE_SUPPORT']&&!_0x321c05?btoa(_0x2b4039):this['encodeByteArray'](Wr(_0x2b4039),_0x321c05);},'decodeString'(_0x394eb7,_0x1af9e9){return this['HAS_NATIVE_SUPPORT']&&!_0x1af9e9?atob(_0x394eb7):Za(this['decodeStringToByteArray'](_0x394eb7,_0x1af9e9));},'decodeStringToByteArray'(_0x38e2d3,_0x3665a3){this['init_']();const _0x4a6547=_0x3665a3?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4efbc1=[];for(let _0x317776=0x0;_0x317776<_0x38e2d3['length'];){const _0x15a004=_0x4a6547[_0x38e2d3['charAt'](_0x317776++)],_0x3f2640=_0x317776<_0x38e2d3['length']?_0x4a6547[_0x38e2d3['charAt'](_0x317776)]:0x0;++_0x317776;const _0x5ab4ec=_0x317776<_0x38e2d3['length']?_0x4a6547[_0x38e2d3['charAt'](_0x317776)]:0x40;++_0x317776;const _0x344633=_0x317776<_0x38e2d3['length']?_0x4a6547[_0x38e2d3['charAt'](_0x317776)]:0x40;if(++_0x317776,_0x15a004==null||_0x3f2640==null||_0x5ab4ec==null||_0x344633==null)throw new ec();const _0x29b4c3=_0x15a004<<0x2|_0x3f2640>>0x4;if(_0x4efbc1['push'](_0x29b4c3),_0x5ab4ec!==0x40){const _0x2dc69d=_0x3f2640<<0x4&0xf0|_0x5ab4ec>>0x2;if(_0x4efbc1['push'](_0x2dc69d),_0x344633!==0x40){const _0x1cec63=_0x5ab4ec<<0x6&0xc0|_0x344633;_0x4efbc1['push'](_0x1cec63);}}}return _0x4efbc1;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xa926e4=0x0;_0xa926e4<this['ENCODED_VALS']['length'];_0xa926e4++)this['byteToCharMap_'][_0xa926e4]=this['ENCODED_VALS']['charAt'](_0xa926e4),this['charToByteMap_'][this['byteToCharMap_'][_0xa926e4]]=_0xa926e4,this['byteToCharMapWebSafe_'][_0xa926e4]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xa926e4),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xa926e4]]=_0xa926e4,_0xa926e4>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xa926e4)]=_0xa926e4,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xa926e4)]=_0xa926e4);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x4bd83d){const _0x3de2e5=Wr(_0x4bd83d);return Di['encodeByteArray'](_0x3de2e5,!0x0);},an=function(_0x3d8150){return Br(_0x3d8150)['replace'](/\./g,'');},cn=function(_0x47f021){try{return Di['decodeString'](_0x47f021,!0x0);}catch(_0x39ec4d){console['error']('base64Decode\x20failed:\x20',_0x39ec4d);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x40f8cb){return Vr(void 0x0,_0x40f8cb);}function Vr(_0x33ab6d,_0x604672){if(!(_0x604672 instanceof Object))return _0x604672;switch(_0x604672['constructor']){case Date:const _0x2ab8e7=_0x604672;return new Date(_0x2ab8e7['getTime']());case Object:_0x33ab6d===void 0x0&&(_0x33ab6d={});break;case Array:_0x33ab6d=[];break;default:return _0x604672;}for(const _0x157f48 in _0x604672)!_0x604672['hasOwnProperty'](_0x157f48)||!nc(_0x157f48)||(_0x33ab6d[_0x157f48]=Vr(_0x33ab6d[_0x157f48],_0x604672[_0x157f48]));return _0x33ab6d;}function nc(_0x2ae6a7){return _0x2ae6a7!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x2943ee=As['__FIREBASE_DEFAULTS__'];if(_0x2943ee)return JSON['parse'](_0x2943ee);},oc=()=>{if(typeof document>'u')return;let _0x2ed50f;try{_0x2ed50f=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x39eeb5=_0x2ed50f&&cn(_0x2ed50f[0x1]);return _0x39eeb5&&JSON['parse'](_0x39eeb5);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x22099d){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x22099d);return;}},Hr=_0x4a7bd8=>{var _0x5c48c5,_0x2aeabd;return(_0x2aeabd=(_0x5c48c5=Mi())==null?void 0x0:_0x5c48c5['emulatorHosts'])==null?void 0x0:_0x2aeabd[_0x4a7bd8];},ac=_0x310b0a=>{const _0x4f6e30=Hr(_0x310b0a);if(!_0x4f6e30)return;const _0x41e02f=_0x4f6e30['lastIndexOf'](':');if(_0x41e02f<=0x0||_0x41e02f+0x1===_0x4f6e30['length'])throw new Error('Invalid\x20host\x20'+_0x4f6e30+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x285766=parseInt(_0x4f6e30['substring'](_0x41e02f+0x1),0xa);return _0x4f6e30[0x0]==='['?[_0x4f6e30['substring'](0x1,_0x41e02f-0x1),_0x285766]:[_0x4f6e30['substring'](0x0,_0x41e02f),_0x285766];},$r=()=>{var _0x5b694e;return(_0x5b694e=Mi())==null?void 0x0:_0x5b694e['config'];},Gr=_0x45e129=>{var _0x5a93a2;return(_0x5a93a2=Mi())==null?void 0x0:_0x5a93a2['_'+_0x45e129];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x347c3e,_0x279770)=>{this['resolve']=_0x347c3e,this['reject']=_0x279770;});}['wrapCallback'](_0x2c1c49){return(_0x38a8b8,_0x4e601f)=>{_0x38a8b8?this['reject'](_0x38a8b8):this['resolve'](_0x4e601f),typeof _0x2c1c49=='function'&&(this['promise']['catch'](()=>{}),_0x2c1c49['length']===0x1?_0x2c1c49(_0x38a8b8):_0x2c1c49(_0x38a8b8,_0x4e601f));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x53fff0,_0x533c8b){if(_0x53fff0['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x531b2a={'alg':'none','type':'JWT'},_0x328c95=_0x533c8b||'demo-project',_0x10378f=_0x53fff0['iat']||0x0,_0x27d5da=_0x53fff0['sub']||_0x53fff0['user_id'];if(!_0x27d5da)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1e8bfc={'iss':'https://securetoken.google.com/'+_0x328c95,'aud':_0x328c95,'iat':_0x10378f,'exp':_0x10378f+0xe10,'auth_time':_0x10378f,'sub':_0x27d5da,'user_id':_0x27d5da,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x53fff0};return[an(JSON['stringify'](_0x531b2a)),an(JSON['stringify'](_0x1e8bfc)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x57f1c6=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x57f1c6=='object'&&_0x57f1c6['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x7e3684=W();return _0x7e3684['indexOf']('MSIE\x20')>=0x0||_0x7e3684['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x388c52,_0x104fc5)=>{try{let _0x5c3e9e=!0x0;const _0x118640='validate-browser-context-for-indexeddb-analytics-module',_0x3ac7a5=self['indexedDB']['open'](_0x118640);_0x3ac7a5['onsuccess']=()=>{_0x3ac7a5['result']['close'](),_0x5c3e9e||self['indexedDB']['deleteDatabase'](_0x118640),_0x388c52(!0x0);},_0x3ac7a5['onupgradeneeded']=()=>{_0x5c3e9e=!0x1;},_0x3ac7a5['onerror']=()=>{var _0xd43b6f;_0x104fc5(((_0xd43b6f=_0x3ac7a5['error'])==null?void 0x0:_0xd43b6f['message'])||'');};}catch(_0x87e6bb){_0x104fc5(_0x87e6bb);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0xd2aae5,_0x149eca,_0x28ea1e){super(_0x149eca),this['code']=_0xd2aae5,this['customData']=_0x28ea1e,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x518888,_0xaa4821,_0x48ff49){this['service']=_0x518888,this['serviceName']=_0xaa4821,this['errors']=_0x48ff49;}['create'](_0x4aeb8a,..._0x3eed65){const _0x64ba31=_0x3eed65[0x0]||{},_0x595d17=this['service']+'/'+_0x4aeb8a,_0x27ebb5=this['errors'][_0x4aeb8a],_0x281563=_0x27ebb5?gc(_0x27ebb5,_0x64ba31):'Error',_0x5b1d4c=this['serviceName']+':\x20'+_0x281563+'\x20('+_0x595d17+').';return new Se(_0x595d17,_0x5b1d4c,_0x64ba31);}}function gc(_0x4fa2bc,_0x5e0ea2){return _0x4fa2bc['replace'](mc,(_0x505982,_0x2c7a81)=>{const _0x5d118a=_0x5e0ea2[_0x2c7a81];return _0x5d118a!=null?String(_0x5d118a):'<'+_0x2c7a81+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x590f90){return JSON['parse'](_0x590f90);}function O(_0x22a94b){return JSON['stringify'](_0x22a94b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x14eb80){let _0x5c8c0e={},_0x272038={},_0x55c409={},_0xa0d904='';try{const _0x5443c8=_0x14eb80['split']('.');_0x5c8c0e=bt(cn(_0x5443c8[0x0])||''),_0x272038=bt(cn(_0x5443c8[0x1])||''),_0xa0d904=_0x5443c8[0x2],_0x55c409=_0x272038['d']||{},delete _0x272038['d'];}catch{}return{'header':_0x5c8c0e,'claims':_0x272038,'data':_0x55c409,'signature':_0xa0d904};},yc=function(_0x1014a9){const _0x58c6af=zr(_0x1014a9),_0x1c5a94=_0x58c6af['claims'];return!!_0x1c5a94&&typeof _0x1c5a94=='object'&&_0x1c5a94['hasOwnProperty']('iat');},vc=function(_0x4a5703){const _0x2d7aac=zr(_0x4a5703)['claims'];return typeof _0x2d7aac=='object'&&_0x2d7aac['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x8a6345,_0x43ecf8){return Object['prototype']['hasOwnProperty']['call'](_0x8a6345,_0x43ecf8);}function Oe(_0x448523,_0x8ce880){if(Object['prototype']['hasOwnProperty']['call'](_0x448523,_0x8ce880))return _0x448523[_0x8ce880];}function hi(_0x5c82c8){for(const _0x82b264 in _0x5c82c8)if(Object['prototype']['hasOwnProperty']['call'](_0x5c82c8,_0x82b264))return!0x1;return!0x0;}function ln(_0x585e89,_0x545706,_0x9dd734){const _0x536e35={};for(const _0x25b40e in _0x585e89)Object['prototype']['hasOwnProperty']['call'](_0x585e89,_0x25b40e)&&(_0x536e35[_0x25b40e]=_0x545706['call'](_0x9dd734,_0x585e89[_0x25b40e],_0x25b40e,_0x585e89));return _0x536e35;}function De(_0x3f3b29,_0x3e114f){if(_0x3f3b29===_0x3e114f)return!0x0;const _0x283a1b=Object['keys'](_0x3f3b29),_0x78a516=Object['keys'](_0x3e114f);for(const _0x1494b8 of _0x283a1b){if(!_0x78a516['includes'](_0x1494b8))return!0x1;const _0x2a9070=_0x3f3b29[_0x1494b8],_0x52b720=_0x3e114f[_0x1494b8];if(ks(_0x2a9070)&&ks(_0x52b720)){if(!De(_0x2a9070,_0x52b720))return!0x1;}else{if(_0x2a9070!==_0x52b720)return!0x1;}}for(const _0x1a0549 of _0x78a516)if(!_0x283a1b['includes'](_0x1a0549))return!0x1;return!0x0;}function ks(_0x21ef3c){return _0x21ef3c!==null&&typeof _0x21ef3c=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x538190){const _0x151ed3=[];for(const [_0x48e299,_0x304d7d]of Object['entries'](_0x538190))Array['isArray'](_0x304d7d)?_0x304d7d['forEach'](_0x30ef87=>{_0x151ed3['push'](encodeURIComponent(_0x48e299)+'='+encodeURIComponent(_0x30ef87));}):_0x151ed3['push'](encodeURIComponent(_0x48e299)+'='+encodeURIComponent(_0x304d7d));return _0x151ed3['length']?'&'+_0x151ed3['join']('&'):'';}function yt(_0x369cdf){const _0xce024f={};return _0x369cdf['replace'](/^\?/,'')['split']('&')['forEach'](_0x43025e=>{if(_0x43025e){const [_0x109bdf,_0xa5c107]=_0x43025e['split']('=');_0xce024f[decodeURIComponent(_0x109bdf)]=decodeURIComponent(_0xa5c107);}}),_0xce024f;}function vt(_0x343b28){const _0x2a8bfa=_0x343b28['indexOf']('?');if(!_0x2a8bfa)return'';const _0x653d83=_0x343b28['indexOf']('#',_0x2a8bfa);return _0x343b28['substring'](_0x2a8bfa,_0x653d83>0x0?_0x653d83:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xa58b30=0x1;_0xa58b30<this['blockSize'];++_0xa58b30)this['pad_'][_0xa58b30]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5c81ef,_0x185a75){_0x185a75||(_0x185a75=0x0);const _0x3869ab=this['W_'];if(typeof _0x5c81ef=='string'){for(let _0x323fd4=0x0;_0x323fd4<0x10;_0x323fd4++)_0x3869ab[_0x323fd4]=_0x5c81ef['charCodeAt'](_0x185a75)<<0x18|_0x5c81ef['charCodeAt'](_0x185a75+0x1)<<0x10|_0x5c81ef['charCodeAt'](_0x185a75+0x2)<<0x8|_0x5c81ef['charCodeAt'](_0x185a75+0x3),_0x185a75+=0x4;}else{for(let _0x44bd36=0x0;_0x44bd36<0x10;_0x44bd36++)_0x3869ab[_0x44bd36]=_0x5c81ef[_0x185a75]<<0x18|_0x5c81ef[_0x185a75+0x1]<<0x10|_0x5c81ef[_0x185a75+0x2]<<0x8|_0x5c81ef[_0x185a75+0x3],_0x185a75+=0x4;}for(let _0x156255=0x10;_0x156255<0x50;_0x156255++){const _0x54807b=_0x3869ab[_0x156255-0x3]^_0x3869ab[_0x156255-0x8]^_0x3869ab[_0x156255-0xe]^_0x3869ab[_0x156255-0x10];_0x3869ab[_0x156255]=(_0x54807b<<0x1|_0x54807b>>>0x1f)&0xffffffff;}let _0x2a59d9=this['chain_'][0x0],_0x2089fb=this['chain_'][0x1],_0x501550=this['chain_'][0x2],_0x45d3b5=this['chain_'][0x3],_0x173fd8=this['chain_'][0x4],_0x8d02b,_0x30baa8;for(let _0x52611a=0x0;_0x52611a<0x50;_0x52611a++){_0x52611a<0x28?_0x52611a<0x14?(_0x8d02b=_0x45d3b5^_0x2089fb&(_0x501550^_0x45d3b5),_0x30baa8=0x5a827999):(_0x8d02b=_0x2089fb^_0x501550^_0x45d3b5,_0x30baa8=0x6ed9eba1):_0x52611a<0x3c?(_0x8d02b=_0x2089fb&_0x501550|_0x45d3b5&(_0x2089fb|_0x501550),_0x30baa8=0x8f1bbcdc):(_0x8d02b=_0x2089fb^_0x501550^_0x45d3b5,_0x30baa8=0xca62c1d6);const _0x362a0e=(_0x2a59d9<<0x5|_0x2a59d9>>>0x1b)+_0x8d02b+_0x173fd8+_0x30baa8+_0x3869ab[_0x52611a]&0xffffffff;_0x173fd8=_0x45d3b5,_0x45d3b5=_0x501550,_0x501550=(_0x2089fb<<0x1e|_0x2089fb>>>0x2)&0xffffffff,_0x2089fb=_0x2a59d9,_0x2a59d9=_0x362a0e;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2a59d9&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2089fb&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x501550&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x45d3b5&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x173fd8&0xffffffff;}['update'](_0x24980c,_0x17cbe4){if(_0x24980c==null)return;_0x17cbe4===void 0x0&&(_0x17cbe4=_0x24980c['length']);const _0x57b32a=_0x17cbe4-this['blockSize'];let _0x5f749b=0x0;const _0x241e30=this['buf_'];let _0x3fcc11=this['inbuf_'];for(;_0x5f749b<_0x17cbe4;){if(_0x3fcc11===0x0){for(;_0x5f749b<=_0x57b32a;)this['compress_'](_0x24980c,_0x5f749b),_0x5f749b+=this['blockSize'];}if(typeof _0x24980c=='string'){for(;_0x5f749b<_0x17cbe4;)if(_0x241e30[_0x3fcc11]=_0x24980c['charCodeAt'](_0x5f749b),++_0x3fcc11,++_0x5f749b,_0x3fcc11===this['blockSize']){this['compress_'](_0x241e30),_0x3fcc11=0x0;break;}}else{for(;_0x5f749b<_0x17cbe4;)if(_0x241e30[_0x3fcc11]=_0x24980c[_0x5f749b],++_0x3fcc11,++_0x5f749b,_0x3fcc11===this['blockSize']){this['compress_'](_0x241e30),_0x3fcc11=0x0;break;}}}this['inbuf_']=_0x3fcc11,this['total_']+=_0x17cbe4;}['digest'](){const _0x1937e5=[];let _0x2a3e20=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x30dbae=this['blockSize']-0x1;_0x30dbae>=0x38;_0x30dbae--)this['buf_'][_0x30dbae]=_0x2a3e20&0xff,_0x2a3e20/=0x100;this['compress_'](this['buf_']);let _0x4cbbc0=0x0;for(let _0x3d6a44=0x0;_0x3d6a44<0x5;_0x3d6a44++)for(let _0x4c22b4=0x18;_0x4c22b4>=0x0;_0x4c22b4-=0x8)_0x1937e5[_0x4cbbc0]=this['chain_'][_0x3d6a44]>>_0x4c22b4&0xff,++_0x4cbbc0;return _0x1937e5;}}function Ic(_0x4b8bcb,_0x1e9216){const _0x3a0e70=new wc(_0x4b8bcb,_0x1e9216);return _0x3a0e70['subscribe']['bind'](_0x3a0e70);}class wc{constructor(_0x5e647e,_0x5c4ca7){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x5c4ca7,this['task']['then'](()=>{_0x5e647e(this);})['catch'](_0x123711=>{this['error'](_0x123711);});}['next'](_0x3b5a90){this['forEachObserver'](_0x248f05=>{_0x248f05['next'](_0x3b5a90);});}['error'](_0x117996){this['forEachObserver'](_0x350506=>{_0x350506['error'](_0x117996);}),this['close'](_0x117996);}['complete'](){this['forEachObserver'](_0x1e0afe=>{_0x1e0afe['complete']();}),this['close']();}['subscribe'](_0x9bfee2,_0x5c049f,_0xf4eb43){let _0x215028;if(_0x9bfee2===void 0x0&&_0x5c049f===void 0x0&&_0xf4eb43===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x9bfee2,['next','error','complete'])?_0x215028=_0x9bfee2:_0x215028={'next':_0x9bfee2,'error':_0x5c049f,'complete':_0xf4eb43},_0x215028['next']===void 0x0&&(_0x215028['next']=Qn),_0x215028['error']===void 0x0&&(_0x215028['error']=Qn),_0x215028['complete']===void 0x0&&(_0x215028['complete']=Qn);const _0x338bcf=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x215028['error'](this['finalError']):_0x215028['complete']();}catch{}}),this['observers']['push'](_0x215028),_0x338bcf;}['unsubscribeOne'](_0x220a9f){this['observers']===void 0x0||this['observers'][_0x220a9f]===void 0x0||(delete this['observers'][_0x220a9f],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4373e4){if(!this['finalized']){for(let _0x5b7ea7=0x0;_0x5b7ea7<this['observers']['length'];_0x5b7ea7++)this['sendOne'](_0x5b7ea7,_0x4373e4);}}['sendOne'](_0xe27af3,_0x3c7a1d){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xe27af3]!==void 0x0)try{_0x3c7a1d(this['observers'][_0xe27af3]);}catch(_0x11ef27){typeof console<'u'&&console['error']&&console['error'](_0x11ef27);}});}['close'](_0x4f96fd){this['finalized']||(this['finalized']=!0x0,_0x4f96fd!==void 0x0&&(this['finalError']=_0x4f96fd),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0xc1f3ea,_0x46a638){if(typeof _0xc1f3ea!='object'||_0xc1f3ea===null)return!0x1;for(const _0x2c7cc9 of _0x46a638)if(_0x2c7cc9 in _0xc1f3ea&&typeof _0xc1f3ea[_0x2c7cc9]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x12c7cf,_0x22060f){return _0x12c7cf+'\x20failed:\x20'+_0x22060f+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x434a25){const _0x467868=[];let _0x49c867=0x0;for(let _0x140b80=0x0;_0x140b80<_0x434a25['length'];_0x140b80++){let _0x5271ba=_0x434a25['charCodeAt'](_0x140b80);if(_0x5271ba>=0xd800&&_0x5271ba<=0xdbff){const _0xd68e75=_0x5271ba-0xd800;_0x140b80++,f(_0x140b80<_0x434a25['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x12d040=_0x434a25['charCodeAt'](_0x140b80)-0xdc00;_0x5271ba=0x10000+(_0xd68e75<<0xa)+_0x12d040;}_0x5271ba<0x80?_0x467868[_0x49c867++]=_0x5271ba:_0x5271ba<0x800?(_0x467868[_0x49c867++]=_0x5271ba>>0x6|0xc0,_0x467868[_0x49c867++]=_0x5271ba&0x3f|0x80):_0x5271ba<0x10000?(_0x467868[_0x49c867++]=_0x5271ba>>0xc|0xe0,_0x467868[_0x49c867++]=_0x5271ba>>0x6&0x3f|0x80,_0x467868[_0x49c867++]=_0x5271ba&0x3f|0x80):(_0x467868[_0x49c867++]=_0x5271ba>>0x12|0xf0,_0x467868[_0x49c867++]=_0x5271ba>>0xc&0x3f|0x80,_0x467868[_0x49c867++]=_0x5271ba>>0x6&0x3f|0x80,_0x467868[_0x49c867++]=_0x5271ba&0x3f|0x80);}return _0x467868;},Pn=function(_0x363bd1){let _0x5c099c=0x0;for(let _0x303ce1=0x0;_0x303ce1<_0x363bd1['length'];_0x303ce1++){const _0x578553=_0x363bd1['charCodeAt'](_0x303ce1);_0x578553<0x80?_0x5c099c++:_0x578553<0x800?_0x5c099c+=0x2:_0x578553>=0xd800&&_0x578553<=0xdbff?(_0x5c099c+=0x4,_0x303ce1++):_0x5c099c+=0x3;}return _0x5c099c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x253b9e){return _0x253b9e&&_0x253b9e['_delegate']?_0x253b9e['_delegate']:_0x253b9e;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x1a301d){try{return(_0x1a301d['startsWith']('http://')||_0x1a301d['startsWith']('https://')?new URL(_0x1a301d)['hostname']:_0x1a301d)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x3b867d){return(await fetch(_0x3b867d,{'credentials':'include'}))['ok'];}class Me{constructor(_0x508db6,_0x13e07a,_0x4b672c){this['name']=_0x508db6,this['instanceFactory']=_0x13e07a,this['type']=_0x4b672c,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x47cdde){return this['instantiationMode']=_0x47cdde,this;}['setMultipleInstances'](_0x612b4d){return this['multipleInstances']=_0x612b4d,this;}['setServiceProps'](_0x3c3128){return this['serviceProps']=_0x3c3128,this;}['setInstanceCreatedCallback'](_0x45762b){return this['onInstanceCreated']=_0x45762b,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0xebbda,_0x3a82bf){this['name']=_0xebbda,this['container']=_0x3a82bf,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x59fc5c){const _0x19ace9=this['normalizeInstanceIdentifier'](_0x59fc5c);if(!this['instancesDeferred']['has'](_0x19ace9)){const _0x55c1fb=new Ve();if(this['instancesDeferred']['set'](_0x19ace9,_0x55c1fb),this['isInitialized'](_0x19ace9)||this['shouldAutoInitialize']())try{const _0xf40317=this['getOrInitializeService']({'instanceIdentifier':_0x19ace9});_0xf40317&&_0x55c1fb['resolve'](_0xf40317);}catch{}}return this['instancesDeferred']['get'](_0x19ace9)['promise'];}['getImmediate'](_0x4d7364){const _0x5c92a0=this['normalizeInstanceIdentifier'](_0x4d7364==null?void 0x0:_0x4d7364['identifier']),_0x45678c=(_0x4d7364==null?void 0x0:_0x4d7364['optional'])??!0x1;if(this['isInitialized'](_0x5c92a0)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x5c92a0});}catch(_0x5417c0){if(_0x45678c)return null;throw _0x5417c0;}else{if(_0x45678c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x497c3e){if(_0x497c3e['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x497c3e['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x497c3e,!!this['shouldAutoInitialize']()){if(Rc(_0x497c3e))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x5c70b2,_0x34081f]of this['instancesDeferred']['entries']()){const _0x158aa9=this['normalizeInstanceIdentifier'](_0x5c70b2);try{const _0x5139a3=this['getOrInitializeService']({'instanceIdentifier':_0x158aa9});_0x34081f['resolve'](_0x5139a3);}catch{}}}}['clearInstance'](_0x5cf48a=ke){this['instancesDeferred']['delete'](_0x5cf48a),this['instancesOptions']['delete'](_0x5cf48a),this['instances']['delete'](_0x5cf48a);}async['delete'](){const _0x2dfea5=Array['from'](this['instances']['values']());await Promise['all']([..._0x2dfea5['filter'](_0x1e4deb=>'INTERNAL'in _0x1e4deb)['map'](_0x436dec=>_0x436dec['INTERNAL']['delete']()),..._0x2dfea5['filter'](_0x66118d=>'_delete'in _0x66118d)['map'](_0x33e39b=>_0x33e39b['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x324036=ke){return this['instances']['has'](_0x324036);}['getOptions'](_0x1afd59=ke){return this['instancesOptions']['get'](_0x1afd59)||{};}['initialize'](_0x1867ee={}){const {options:_0x3a5d01={}}=_0x1867ee,_0x400875=this['normalizeInstanceIdentifier'](_0x1867ee['instanceIdentifier']);if(this['isInitialized'](_0x400875))throw Error(this['name']+'('+_0x400875+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1a777b=this['getOrInitializeService']({'instanceIdentifier':_0x400875,'options':_0x3a5d01});for(const [_0x15aa16,_0x2895bf]of this['instancesDeferred']['entries']()){const _0x183df6=this['normalizeInstanceIdentifier'](_0x15aa16);_0x400875===_0x183df6&&_0x2895bf['resolve'](_0x1a777b);}return _0x1a777b;}['onInit'](_0x593871,_0x192411){const _0x4cc610=this['normalizeInstanceIdentifier'](_0x192411),_0x35d779=this['onInitCallbacks']['get'](_0x4cc610)??new Set();_0x35d779['add'](_0x593871),this['onInitCallbacks']['set'](_0x4cc610,_0x35d779);const _0x5cb31b=this['instances']['get'](_0x4cc610);return _0x5cb31b&&_0x593871(_0x5cb31b,_0x4cc610),()=>{_0x35d779['delete'](_0x593871);};}['invokeOnInitCallbacks'](_0x207939,_0x4ab699){const _0x1a4fa6=this['onInitCallbacks']['get'](_0x4ab699);if(_0x1a4fa6){for(const _0x279ae0 of _0x1a4fa6)try{_0x279ae0(_0x207939,_0x4ab699);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2dc61e,options:_0x24df53={}}){let _0x525c93=this['instances']['get'](_0x2dc61e);if(!_0x525c93&&this['component']&&(_0x525c93=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x2dc61e),'options':_0x24df53}),this['instances']['set'](_0x2dc61e,_0x525c93),this['instancesOptions']['set'](_0x2dc61e,_0x24df53),this['invokeOnInitCallbacks'](_0x525c93,_0x2dc61e),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2dc61e,_0x525c93);}catch{}return _0x525c93||null;}['normalizeInstanceIdentifier'](_0x489b7b=ke){return this['component']?this['component']['multipleInstances']?_0x489b7b:ke:_0x489b7b;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x20e97e){return _0x20e97e===ke?void 0x0:_0x20e97e;}function Rc(_0x2a0bb6){return _0x2a0bb6['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4bebaf){this['name']=_0x4bebaf,this['providers']=new Map();}['addComponent'](_0x4d76e0){const _0x45d25c=this['getProvider'](_0x4d76e0['name']);if(_0x45d25c['isComponentSet']())throw new Error('Component\x20'+_0x4d76e0['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x45d25c['setComponent'](_0x4d76e0);}['addOrOverwriteComponent'](_0x42bfe6){this['getProvider'](_0x42bfe6['name'])['isComponentSet']()&&this['providers']['delete'](_0x42bfe6['name']),this['addComponent'](_0x42bfe6);}['getProvider'](_0x40c141){if(this['providers']['has'](_0x40c141))return this['providers']['get'](_0x40c141);const _0x265f62=new Sc(_0x40c141,this);return this['providers']['set'](_0x40c141,_0x265f62),_0x265f62;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x450b56){_0x450b56[_0x450b56['DEBUG']=0x0]='DEBUG',_0x450b56[_0x450b56['VERBOSE']=0x1]='VERBOSE',_0x450b56[_0x450b56['INFO']=0x2]='INFO',_0x450b56[_0x450b56['WARN']=0x3]='WARN',_0x450b56[_0x450b56['ERROR']=0x4]='ERROR',_0x450b56[_0x450b56['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x399640,_0x4486db,..._0x151f02)=>{if(_0x4486db<_0x399640['logLevel'])return;const _0x440c0b=new Date()['toISOString'](),_0x8d9b1c=Pc[_0x4486db];if(_0x8d9b1c)console[_0x8d9b1c]('['+_0x440c0b+']\x20\x20'+_0x399640['name']+':',..._0x151f02);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x4486db+')');};class xi{constructor(_0x13300c){this['name']=_0x13300c,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4e5877){if(!(_0x4e5877 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4e5877+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4e5877;}['setLogLevel'](_0x44d0c7){this['_logLevel']=typeof _0x44d0c7=='string'?kc[_0x44d0c7]:_0x44d0c7;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x299b26){if(typeof _0x299b26!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x299b26;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0xaa197c){this['_userLogHandler']=_0xaa197c;}['debug'](..._0xbbef0f){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0xbbef0f),this['_logHandler'](this,T['DEBUG'],..._0xbbef0f);}['log'](..._0x56ad2e){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x56ad2e),this['_logHandler'](this,T['VERBOSE'],..._0x56ad2e);}['info'](..._0x1f657f){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1f657f),this['_logHandler'](this,T['INFO'],..._0x1f657f);}['warn'](..._0x4ea14f){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4ea14f),this['_logHandler'](this,T['WARN'],..._0x4ea14f);}['error'](..._0x1b5707){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1b5707),this['_logHandler'](this,T['ERROR'],..._0x1b5707);}}const Dc=(_0x592131,_0x3db261)=>_0x3db261['some'](_0x575f95=>_0x592131 instanceof _0x575f95);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0xe2fc5a){const _0x5af311=new Promise((_0x56025f,_0x4cc247)=>{const _0x314132=()=>{_0xe2fc5a['removeEventListener']('success',_0x23df62),_0xe2fc5a['removeEventListener']('error',_0x1a6d30);},_0x23df62=()=>{_0x56025f(_e(_0xe2fc5a['result'])),_0x314132();},_0x1a6d30=()=>{_0x4cc247(_0xe2fc5a['error']),_0x314132();};_0xe2fc5a['addEventListener']('success',_0x23df62),_0xe2fc5a['addEventListener']('error',_0x1a6d30);});return _0x5af311['then'](_0x2aa0cd=>{_0x2aa0cd instanceof IDBCursor&&Kr['set'](_0x2aa0cd,_0xe2fc5a);})['catch'](()=>{}),Fi['set'](_0x5af311,_0xe2fc5a),_0x5af311;}function Fc(_0x396224){if(ui['has'](_0x396224))return;const _0x41588b=new Promise((_0x17e3d1,_0x2625ca)=>{const _0x1025d2=()=>{_0x396224['removeEventListener']('complete',_0x2fc409),_0x396224['removeEventListener']('error',_0x21133b),_0x396224['removeEventListener']('abort',_0x21133b);},_0x2fc409=()=>{_0x17e3d1(),_0x1025d2();},_0x21133b=()=>{_0x2625ca(_0x396224['error']||new DOMException('AbortError','AbortError')),_0x1025d2();};_0x396224['addEventListener']('complete',_0x2fc409),_0x396224['addEventListener']('error',_0x21133b),_0x396224['addEventListener']('abort',_0x21133b);});ui['set'](_0x396224,_0x41588b);}let di={'get'(_0x3f85c5,_0x3963e7,_0x509e5b){if(_0x3f85c5 instanceof IDBTransaction){if(_0x3963e7==='done')return ui['get'](_0x3f85c5);if(_0x3963e7==='objectStoreNames')return _0x3f85c5['objectStoreNames']||Yr['get'](_0x3f85c5);if(_0x3963e7==='store')return _0x509e5b['objectStoreNames'][0x1]?void 0x0:_0x509e5b['objectStore'](_0x509e5b['objectStoreNames'][0x0]);}return _e(_0x3f85c5[_0x3963e7]);},'set'(_0x351293,_0x58697d,_0x166756){return _0x351293[_0x58697d]=_0x166756,!0x0;},'has'(_0x7dd370,_0x4d619d){return _0x7dd370 instanceof IDBTransaction&&(_0x4d619d==='done'||_0x4d619d==='store')?!0x0:_0x4d619d in _0x7dd370;}};function Uc(_0x1e5bbc){di=_0x1e5bbc(di);}function Wc(_0x231002){return _0x231002===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x407ded,..._0x2d2821){const _0xeff33e=_0x231002['call'](Xn(this),_0x407ded,..._0x2d2821);return Yr['set'](_0xeff33e,_0x407ded['sort']?_0x407ded['sort']():[_0x407ded]),_e(_0xeff33e);}:Lc()['includes'](_0x231002)?function(..._0x39678d){return _0x231002['apply'](Xn(this),_0x39678d),_e(Kr['get'](this));}:function(..._0x2fb189){return _e(_0x231002['apply'](Xn(this),_0x2fb189));};}function Bc(_0x7792f9){return typeof _0x7792f9=='function'?Wc(_0x7792f9):(_0x7792f9 instanceof IDBTransaction&&Fc(_0x7792f9),Dc(_0x7792f9,Mc())?new Proxy(_0x7792f9,di):_0x7792f9);}function _e(_0x453e36){if(_0x453e36 instanceof IDBRequest)return xc(_0x453e36);if(Jn['has'](_0x453e36))return Jn['get'](_0x453e36);const _0x1db092=Bc(_0x453e36);return _0x1db092!==_0x453e36&&(Jn['set'](_0x453e36,_0x1db092),Fi['set'](_0x1db092,_0x453e36)),_0x1db092;}const Xn=_0x193580=>Fi['get'](_0x193580);function Vc(_0x20f678,_0x171c16,{blocked:_0x357482,upgrade:_0x55d440,blocking:_0x2fe7f8,terminated:_0x42fdd4}={}){const _0x5e4dbf=indexedDB['open'](_0x20f678,_0x171c16),_0x58831d=_e(_0x5e4dbf);return _0x55d440&&_0x5e4dbf['addEventListener']('upgradeneeded',_0x1dac29=>{_0x55d440(_e(_0x5e4dbf['result']),_0x1dac29['oldVersion'],_0x1dac29['newVersion'],_e(_0x5e4dbf['transaction']),_0x1dac29);}),_0x357482&&_0x5e4dbf['addEventListener']('blocked',_0xd567a7=>_0x357482(_0xd567a7['oldVersion'],_0xd567a7['newVersion'],_0xd567a7)),_0x58831d['then'](_0x5924cc=>{_0x42fdd4&&_0x5924cc['addEventListener']('close',()=>_0x42fdd4()),_0x2fe7f8&&_0x5924cc['addEventListener']('versionchange',_0x48134d=>_0x2fe7f8(_0x48134d['oldVersion'],_0x48134d['newVersion'],_0x48134d));})['catch'](()=>{}),_0x58831d;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x347bcd,_0x206cb5){if(!(_0x347bcd instanceof IDBDatabase&&!(_0x206cb5 in _0x347bcd)&&typeof _0x206cb5=='string'))return;if(Zn['get'](_0x206cb5))return Zn['get'](_0x206cb5);const _0x59941f=_0x206cb5['replace'](/FromIndex$/,''),_0xdd801b=_0x206cb5!==_0x59941f,_0x474657=$c['includes'](_0x59941f);if(!(_0x59941f in(_0xdd801b?IDBIndex:IDBObjectStore)['prototype'])||!(_0x474657||Hc['includes'](_0x59941f)))return;const _0x1240cf=async function(_0x2bcf7a,..._0x57ca5a){const _0x147afb=this['transaction'](_0x2bcf7a,_0x474657?'readwrite':'readonly');let _0x4abbc5=_0x147afb['store'];return _0xdd801b&&(_0x4abbc5=_0x4abbc5['index'](_0x57ca5a['shift']())),(await Promise['all']([_0x4abbc5[_0x59941f](..._0x57ca5a),_0x474657&&_0x147afb['done']]))[0x0];};return Zn['set'](_0x206cb5,_0x1240cf),_0x1240cf;}Uc(_0x5aac22=>({..._0x5aac22,'get':(_0x435a4b,_0xe7398e,_0x31518a)=>Os(_0x435a4b,_0xe7398e)||_0x5aac22['get'](_0x435a4b,_0xe7398e,_0x31518a),'has':(_0x123fda,_0x1cecf3)=>!!Os(_0x123fda,_0x1cecf3)||_0x5aac22['has'](_0x123fda,_0x1cecf3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x35a896){this['container']=_0x35a896;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1b2e0a=>{if(qc(_0x1b2e0a)){const _0x260bc2=_0x1b2e0a['getImmediate']();return _0x260bc2['library']+'/'+_0x260bc2['version'];}else return null;})['filter'](_0x44a971=>_0x44a971)['join']('\x20');}}function qc(_0x203fcd){const _0x564d07=_0x203fcd['getComponent']();return(_0x564d07==null?void 0x0:_0x564d07['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x2ee97c,_0x5e1bea){try{_0x2ee97c['container']['addComponent'](_0x5e1bea);}catch(_0x2861fb){re['debug']('Component\x20'+_0x5e1bea['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2ee97c['name'],_0x2861fb);}}function et(_0x33026b){const _0x5c1ad4=_0x33026b['name'];if(gi['has'](_0x5c1ad4))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5c1ad4+'.'),!0x1;gi['set'](_0x5c1ad4,_0x33026b);for(const _0x555efc of Le['values']())Ms(_0x555efc,_0x33026b);for(const _0x4e842d of _i['values']())Ms(_0x4e842d,_0x33026b);return!0x0;}function Ui(_0x1c7a1f,_0x5aba35){const _0x159f04=_0x1c7a1f['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x159f04&&_0x159f04['triggerHeartbeat'](),_0x1c7a1f['container']['getProvider'](_0x5aba35);}function H(_0x4ca11a){return _0x4ca11a==null?!0x1:_0x4ca11a['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x20c5a6,_0x7c4268,_0x4e5c4c){this['_isDeleted']=!0x1,this['_options']={..._0x20c5a6},this['_config']={..._0x7c4268},this['_name']=_0x7c4268['name'],this['_automaticDataCollectionEnabled']=_0x7c4268['automaticDataCollectionEnabled'],this['_container']=_0x4e5c4c,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0xc4c65b){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0xc4c65b;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x388554){this['_isDeleted']=_0x388554;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0xd3372,_0x5a0b67={}){let _0x509e8a=_0xd3372;typeof _0x5a0b67!='object'&&(_0x5a0b67={'name':_0x5a0b67});const _0x199d7d={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x5a0b67},_0x354e9b=_0x199d7d['name'];if(typeof _0x354e9b!='string'||!_0x354e9b)throw ge['create']('bad-app-name',{'appName':String(_0x354e9b)});if(_0x509e8a||(_0x509e8a=$r()),!_0x509e8a)throw ge['create']('no-options');const _0x50ac6c=Le['get'](_0x354e9b);if(_0x50ac6c){if(De(_0x509e8a,_0x50ac6c['options'])&&De(_0x199d7d,_0x50ac6c['config']))return _0x50ac6c;throw ge['create']('duplicate-app',{'appName':_0x354e9b});}const _0x137dc6=new Ac(_0x354e9b);for(const _0x18b52d of gi['values']())_0x137dc6['addComponent'](_0x18b52d);const _0x125d55=new Il(_0x509e8a,_0x199d7d,_0x137dc6);return Le['set'](_0x354e9b,_0x125d55),_0x125d55;}function Qr(_0x4a5ccd=pi){const _0x29610d=Le['get'](_0x4a5ccd);if(!_0x29610d&&_0x4a5ccd===pi&&$r())return wl();if(!_0x29610d)throw ge['create']('no-app',{'appName':_0x4a5ccd});return _0x29610d;}function l_(){return Array['from'](Le['values']());}async function h_(_0x529125){let _0x57b475=!0x1;const _0x334035=_0x529125['name'];Le['has'](_0x334035)?(_0x57b475=!0x0,Le['delete'](_0x334035)):_i['has'](_0x334035)&&_0x529125['decRefCount']()<=0x0&&(_i['delete'](_0x334035),_0x57b475=!0x0),_0x57b475&&(await Promise['all'](_0x529125['container']['getProviders']()['map'](_0x43dd28=>_0x43dd28['delete']())),_0x529125['isDeleted']=!0x0);}function me(_0x25ecc4,_0x3de6e6,_0x4e1abc){let _0x534140=vl[_0x25ecc4]??_0x25ecc4;_0x4e1abc&&(_0x534140+='-'+_0x4e1abc);const _0x1bd922=_0x534140['match'](/\s|\//),_0x4b8c36=_0x3de6e6['match'](/\s|\//);if(_0x1bd922||_0x4b8c36){const _0x4b0a30=['Unable\x20to\x20register\x20library\x20\x22'+_0x534140+'\x22\x20with\x20version\x20\x22'+_0x3de6e6+'\x22:'];_0x1bd922&&_0x4b0a30['push']('library\x20name\x20\x22'+_0x534140+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1bd922&&_0x4b8c36&&_0x4b0a30['push']('and'),_0x4b8c36&&_0x4b0a30['push']('version\x20name\x20\x22'+_0x3de6e6+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x4b0a30['join']('\x20'));return;}et(new Me(_0x534140+'-version',()=>({'library':_0x534140,'version':_0x3de6e6}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x2a80c0,_0x4748da)=>{switch(_0x4748da){case 0x0:try{_0x2a80c0['createObjectStore'](Rt);}catch(_0x2fd12d){console['warn'](_0x2fd12d);}}}})['catch'](_0x1f7b90=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x1f7b90['message']});})),ei;}async function Sl(_0x29da7c){try{const _0x55fa95=(await Jr())['transaction'](Rt),_0x34e33c=await _0x55fa95['objectStore'](Rt)['get'](Xr(_0x29da7c));return await _0x55fa95['done'],_0x34e33c;}catch(_0x39eea1){if(_0x39eea1 instanceof Se)re['warn'](_0x39eea1['message']);else{const _0x382a48=ge['create']('idb-get',{'originalErrorMessage':_0x39eea1==null?void 0x0:_0x39eea1['message']});re['warn'](_0x382a48['message']);}}}async function Ls(_0x53ed11,_0x4e646b){try{const _0x5f54ba=(await Jr())['transaction'](Rt,'readwrite');await _0x5f54ba['objectStore'](Rt)['put'](_0x4e646b,Xr(_0x53ed11)),await _0x5f54ba['done'];}catch(_0x23b2d9){if(_0x23b2d9 instanceof Se)re['warn'](_0x23b2d9['message']);else{const _0x1268c0=ge['create']('idb-set',{'originalErrorMessage':_0x23b2d9==null?void 0x0:_0x23b2d9['message']});re['warn'](_0x1268c0['message']);}}}function Xr(_0xae11cb){return _0xae11cb['name']+'!'+_0xae11cb['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x250546){this['container']=_0x250546,this['_heartbeatsCache']=null;const _0x2036b0=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x2036b0),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x5780c8=>(this['_heartbeatsCache']=_0x5780c8,_0x5780c8));}async['triggerHeartbeat'](){var _0x4cc1c6,_0x1f38f6;try{const _0x43a619=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x40ac3b=xs();if(((_0x4cc1c6=this['_heartbeatsCache'])==null?void 0x0:_0x4cc1c6['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x1f38f6=this['_heartbeatsCache'])==null?void 0x0:_0x1f38f6['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x40ac3b||this['_heartbeatsCache']['heartbeats']['some'](_0x5722c7=>_0x5722c7['date']===_0x40ac3b))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x40ac3b,'agent':_0x43a619}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x28c9c4=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x28c9c4,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x9c103a){re['warn'](_0x9c103a);}}async['getHeartbeatsHeader'](){var _0x84e4af;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x84e4af=this['_heartbeatsCache'])==null?void 0x0:_0x84e4af['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x836ff4=xs(),{heartbeatsToSend:_0x401259,unsentEntries:_0x5ea103}=kl(this['_heartbeatsCache']['heartbeats']),_0x1fc293=an(JSON['stringify']({'version':0x2,'heartbeats':_0x401259}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x836ff4,_0x5ea103['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x5ea103,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1fc293;}catch(_0xc8c115){return re['warn'](_0xc8c115),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x4f0613,_0xd45450=bl){const _0x2ff1bf=[];let _0x3a8cfe=_0x4f0613['slice']();for(const _0x1af4e3 of _0x4f0613){const _0x4efd4a=_0x2ff1bf['find'](_0x552d95=>_0x552d95['agent']===_0x1af4e3['agent']);if(_0x4efd4a){if(_0x4efd4a['dates']['push'](_0x1af4e3['date']),Fs(_0x2ff1bf)>_0xd45450){_0x4efd4a['dates']['pop']();break;}}else{if(_0x2ff1bf['push']({'agent':_0x1af4e3['agent'],'dates':[_0x1af4e3['date']]}),Fs(_0x2ff1bf)>_0xd45450){_0x2ff1bf['pop']();break;}}_0x3a8cfe=_0x3a8cfe['slice'](0x1);}return{'heartbeatsToSend':_0x2ff1bf,'unsentEntries':_0x3a8cfe};}class Nl{constructor(_0x401cb8){this['app']=_0x401cb8,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x49e7f5=await Sl(this['app']);return _0x49e7f5!=null&&_0x49e7f5['heartbeats']?_0x49e7f5:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0xf941ed){if(await this['_canUseIndexedDBPromise']){const _0x3d3d6f=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0xf941ed['lastSentHeartbeatDate']??_0x3d3d6f['lastSentHeartbeatDate'],'heartbeats':_0xf941ed['heartbeats']});}else return;}async['add'](_0x12acc6){if(await this['_canUseIndexedDBPromise']){const _0x578d50=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x12acc6['lastSentHeartbeatDate']??_0x578d50['lastSentHeartbeatDate'],'heartbeats':[..._0x578d50['heartbeats'],..._0x12acc6['heartbeats']]});}else return;}}function Fs(_0xe4d457){return an(JSON['stringify']({'version':0x2,'heartbeats':_0xe4d457}))['length'];}function Pl(_0x4159c7){if(_0x4159c7['length']===0x0)return-0x1;let _0x3fe98f=0x0,_0x2ca5f8=_0x4159c7[0x0]['date'];for(let _0x4a45c2=0x1;_0x4a45c2<_0x4159c7['length'];_0x4a45c2++)_0x4159c7[_0x4a45c2]['date']<_0x2ca5f8&&(_0x2ca5f8=_0x4159c7[_0x4a45c2]['date'],_0x3fe98f=_0x4a45c2);return _0x3fe98f;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x16abc7){et(new Me('platform-logger',_0x21eb52=>new Gc(_0x21eb52),'PRIVATE')),et(new Me('heartbeat',_0x54aaec=>new Al(_0x54aaec),'PRIVATE')),me(fi,Ds,_0x16abc7),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x586e6b){Zr=_0x586e6b;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x52e83c){this['domStorage_']=_0x52e83c,this['prefix_']='firebase:';}['set'](_0x1aa8ee,_0xfad891){_0xfad891==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1aa8ee)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1aa8ee),O(_0xfad891));}['get'](_0x51c0c0){const _0x4b2613=this['domStorage_']['getItem'](this['prefixedName_'](_0x51c0c0));return _0x4b2613==null?null:bt(_0x4b2613);}['remove'](_0x573958){this['domStorage_']['removeItem'](this['prefixedName_'](_0x573958));}['prefixedName_'](_0x5896a1){return this['prefix_']+_0x5896a1;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5db7ef,_0x5d15a6){_0x5d15a6==null?delete this['cache_'][_0x5db7ef]:this['cache_'][_0x5db7ef]=_0x5d15a6;}['get'](_0x53ff39){return Y(this['cache_'],_0x53ff39)?this['cache_'][_0x53ff39]:null;}['remove'](_0x158f2e){delete this['cache_'][_0x158f2e];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x31cac7){try{if(typeof window<'u'&&typeof window[_0x31cac7]<'u'){const _0x416e3c=window[_0x31cac7];return _0x416e3c['setItem']('firebase:sentinel','cache'),_0x416e3c['removeItem']('firebase:sentinel'),new xl(_0x416e3c);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x43b271=0x1;return function(){return _0x43b271++;};}()),no=function(_0x14452d){const _0x5e43b3=Tc(_0x14452d),_0x589c58=new Ec();_0x589c58['update'](_0x5e43b3);const _0xd25931=_0x589c58['digest']();return Di['encodeByteArray'](_0xd25931);},Bt=function(..._0x4286d7){let _0x3ea15c='';for(let _0x2c3efe=0x0;_0x2c3efe<_0x4286d7['length'];_0x2c3efe++){const _0x27da95=_0x4286d7[_0x2c3efe];Array['isArray'](_0x27da95)||_0x27da95&&typeof _0x27da95=='object'&&typeof _0x27da95['length']=='number'?_0x3ea15c+=Bt['apply'](null,_0x27da95):typeof _0x27da95=='object'?_0x3ea15c+=O(_0x27da95):_0x3ea15c+=_0x27da95,_0x3ea15c+='\x20';}return _0x3ea15c;};let Et=null,Vs=!0x0;const Wl=function(_0x26aa10,_0x4ebd93){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x46cf05){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x12e2f3=Bt['apply'](null,_0x46cf05);Et(_0x12e2f3);}},Vt=function(_0xb1ba43){return function(..._0x4698b3){L(_0xb1ba43,..._0x4698b3);};},mi=function(..._0x2cb905){const _0x176fa5='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x2cb905);Qe['error'](_0x176fa5);},oe=function(..._0x25e6e7){const _0x371044='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x25e6e7);throw Qe['error'](_0x371044),new Error(_0x371044);},U=function(..._0x587442){const _0x4c542b='FIREBASE\x20WARNING:\x20'+Bt(..._0x587442);Qe['warn'](_0x4c542b);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x3b8fcb){return typeof _0x3b8fcb=='number'&&(_0x3b8fcb!==_0x3b8fcb||_0x3b8fcb===Number['POSITIVE_INFINITY']||_0x3b8fcb===Number['NEGATIVE_INFINITY']);},Vl=function(_0x39381d){if(document['readyState']==='complete')_0x39381d();else{let _0x1b2f14=!0x1;const _0x32dfef=function(){if(!document['body']){setTimeout(_0x32dfef,Math['floor'](0xa));return;}_0x1b2f14||(_0x1b2f14=!0x0,_0x39381d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x32dfef,!0x1),window['addEventListener']('load',_0x32dfef,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x32dfef();}),window['attachEvent']('onload',_0x32dfef));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x59b7ed,_0x43d64b){if(_0x59b7ed===_0x43d64b)return 0x0;if(_0x59b7ed===xe||_0x43d64b===Ie)return-0x1;if(_0x43d64b===xe||_0x59b7ed===Ie)return 0x1;{const _0x281e51=Hs(_0x59b7ed),_0x354b47=Hs(_0x43d64b);return _0x281e51!==null?_0x354b47!==null?_0x281e51-_0x354b47===0x0?_0x59b7ed['length']-_0x43d64b['length']:_0x281e51-_0x354b47:-0x1:_0x354b47!==null?0x1:_0x59b7ed<_0x43d64b?-0x1:0x1;}},Hl=function(_0x4bb88e,_0x471a52){return _0x4bb88e===_0x471a52?0x0:_0x4bb88e<_0x471a52?-0x1:0x1;},pt=function(_0x5d6e6a,_0x152428){if(_0x152428&&_0x5d6e6a in _0x152428)return _0x152428[_0x5d6e6a];throw new Error('Missing\x20required\x20key\x20('+_0x5d6e6a+')\x20in\x20object:\x20'+O(_0x152428));},Bi=function(_0xcdec82){if(typeof _0xcdec82!='object'||_0xcdec82===null)return O(_0xcdec82);const _0x20b698=[];for(const _0x176574 in _0xcdec82)_0x20b698['push'](_0x176574);_0x20b698['sort']();let _0x31b570='{';for(let _0x308c9b=0x0;_0x308c9b<_0x20b698['length'];_0x308c9b++)_0x308c9b!==0x0&&(_0x31b570+=','),_0x31b570+=O(_0x20b698[_0x308c9b]),_0x31b570+=':',_0x31b570+=Bi(_0xcdec82[_0x20b698[_0x308c9b]]);return _0x31b570+='}',_0x31b570;},io=function(_0x239b2a,_0x56a3d8){const _0x1a79e9=_0x239b2a['length'];if(_0x1a79e9<=_0x56a3d8)return[_0x239b2a];const _0x1fccfe=[];for(let _0x855963=0x0;_0x855963<_0x1a79e9;_0x855963+=_0x56a3d8)_0x855963+_0x56a3d8>_0x1a79e9?_0x1fccfe['push'](_0x239b2a['substring'](_0x855963,_0x1a79e9)):_0x1fccfe['push'](_0x239b2a['substring'](_0x855963,_0x855963+_0x56a3d8));return _0x1fccfe;};function x(_0xa5399d,_0xf23400){for(const _0x5865a3 in _0xa5399d)_0xa5399d['hasOwnProperty'](_0x5865a3)&&_0xf23400(_0x5865a3,_0xa5399d[_0x5865a3]);}const so=function(_0x290633){f(!Wi(_0x290633),'Invalid\x20JSON\x20number');const _0x491ed6=0xb,_0x135aab=0x34,_0x117054=(0x1<<_0x491ed6-0x1)-0x1;let _0x509050,_0x34e482,_0x2873f5,_0x29e050,_0x40787d;_0x290633===0x0?(_0x34e482=0x0,_0x2873f5=0x0,_0x509050=0x1/_0x290633===-0x1/0x0?0x1:0x0):(_0x509050=_0x290633<0x0,_0x290633=Math['abs'](_0x290633),_0x290633>=Math['pow'](0x2,0x1-_0x117054)?(_0x29e050=Math['min'](Math['floor'](Math['log'](_0x290633)/Math['LN2']),_0x117054),_0x34e482=_0x29e050+_0x117054,_0x2873f5=Math['round'](_0x290633*Math['pow'](0x2,_0x135aab-_0x29e050)-Math['pow'](0x2,_0x135aab))):(_0x34e482=0x0,_0x2873f5=Math['round'](_0x290633/Math['pow'](0x2,0x1-_0x117054-_0x135aab))));const _0x714209=[];for(_0x40787d=_0x135aab;_0x40787d;_0x40787d-=0x1)_0x714209['push'](_0x2873f5%0x2?0x1:0x0),_0x2873f5=Math['floor'](_0x2873f5/0x2);for(_0x40787d=_0x491ed6;_0x40787d;_0x40787d-=0x1)_0x714209['push'](_0x34e482%0x2?0x1:0x0),_0x34e482=Math['floor'](_0x34e482/0x2);_0x714209['push'](_0x509050?0x1:0x0),_0x714209['reverse']();const _0x2dd754=_0x714209['join']('');let _0xd2a3b0='';for(_0x40787d=0x0;_0x40787d<0x40;_0x40787d+=0x8){let _0x38a162=parseInt(_0x2dd754['substr'](_0x40787d,0x8),0x2)['toString'](0x10);_0x38a162['length']===0x1&&(_0x38a162='0'+_0x38a162),_0xd2a3b0=_0xd2a3b0+_0x38a162;}return _0xd2a3b0['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x11b913,_0x27b32a){let _0x1b4c2a='Unknown\x20Error';_0x11b913==='too_big'?_0x1b4c2a='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x11b913==='permission_denied'?_0x1b4c2a='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x11b913==='unavailable'&&(_0x1b4c2a='The\x20service\x20is\x20unavailable');const _0x4ee2e0=new Error(_0x11b913+'\x20at\x20'+_0x27b32a['_path']['toString']()+':\x20'+_0x1b4c2a);return _0x4ee2e0['code']=_0x11b913['toUpperCase'](),_0x4ee2e0;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x4121c2){if(zl['test'](_0x4121c2)){const _0x592128=Number(_0x4121c2);if(_0x592128>=jl&&_0x592128<=Kl)return _0x592128;}return null;},lt=function(_0x330bfa){try{_0x330bfa();}catch(_0x8648d1){setTimeout(()=>{const _0x2b3608=_0x8648d1['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x2b3608),_0x8648d1;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x5a5bc2,_0x3ef15a){const _0x4df7f0=setTimeout(_0x5a5bc2,_0x3ef15a);return typeof _0x4df7f0=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4df7f0):typeof _0x4df7f0=='object'&&_0x4df7f0['unref']&&_0x4df7f0['unref'](),_0x4df7f0;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x119b34,_0x4a249f){this['appCheckProvider']=_0x4a249f,this['appName']=_0x119b34['name'],H(_0x119b34)&&_0x119b34['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x119b34['settings']['appCheckToken']),this['appCheck']=_0x4a249f==null?void 0x0:_0x4a249f['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4a249f==null||_0x4a249f['get']()['then'](_0x205273=>this['appCheck']=_0x205273);}['getToken'](_0x527ca0){if(this['serverAppAppCheckToken']){if(_0x527ca0)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x527ca0):new Promise((_0xd1a53f,_0x1f1d26)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x527ca0)['then'](_0xd1a53f,_0x1f1d26):_0xd1a53f(null);},0x0);});}['addTokenChangeListener'](_0x321edd){var _0x534fc1;(_0x534fc1=this['appCheckProvider'])==null||_0x534fc1['get']()['then'](_0x1ea135=>_0x1ea135['addTokenListener'](_0x321edd));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x5dc476,_0x110fb5,_0xc4aa3c){this['appName_']=_0x5dc476,this['firebaseOptions_']=_0x110fb5,this['authProvider_']=_0xc4aa3c,this['auth_']=null,this['auth_']=_0xc4aa3c['getImmediate']({'optional':!0x0}),this['auth_']||_0xc4aa3c['onInit'](_0x67a6d7=>this['auth_']=_0x67a6d7);}['getToken'](_0x54bdbc){return this['auth_']?this['auth_']['getToken'](_0x54bdbc)['catch'](_0x2b10b1=>_0x2b10b1&&_0x2b10b1['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2b10b1)):new Promise((_0x2f5e2c,_0x26dfcb)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x54bdbc)['then'](_0x2f5e2c,_0x26dfcb):_0x2f5e2c(null);},0x0);});}['addTokenChangeListener'](_0x171d46){this['auth_']?this['auth_']['addAuthTokenListener'](_0x171d46):this['authProvider_']['get']()['then'](_0x1b408a=>_0x1b408a['addAuthTokenListener'](_0x171d46));}['removeTokenChangeListener'](_0x1a7579){this['authProvider_']['get']()['then'](_0xd32d73=>_0xd32d73['removeAuthTokenListener'](_0x1a7579));}['notifyForInvalidToken'](){let _0x3ecd20='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3ecd20+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3ecd20+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3ecd20+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3ecd20);}}class tn{constructor(_0x367439){this['accessToken']=_0x367439;}['getToken'](_0x4d2334){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x19ea82){_0x19ea82(this['accessToken']);}['removeTokenChangeListener'](_0x559fa9){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x470b5e,_0x144d69,_0x57148c,_0x4c086a,_0x404726=!0x1,_0x5b9a0b='',_0x5b5c3d=!0x1,_0x474f26=!0x1,_0x355758=null){this['secure']=_0x144d69,this['namespace']=_0x57148c,this['webSocketOnly']=_0x4c086a,this['nodeAdmin']=_0x404726,this['persistenceKey']=_0x5b9a0b,this['includeNamespaceInQueryParams']=_0x5b5c3d,this['isUsingEmulator']=_0x474f26,this['emulatorOptions']=_0x355758,this['_host']=_0x470b5e['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x470b5e)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0xcd4d6e){_0xcd4d6e!==this['internalHost']&&(this['internalHost']=_0xcd4d6e,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x35492c=this['toURLString']();return this['persistenceKey']&&(_0x35492c+='<'+this['persistenceKey']+'>'),_0x35492c;}['toURLString'](){const _0x125d35=this['secure']?'https://':'http://',_0x5b1c6c=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x125d35+this['host']+'/'+_0x5b1c6c;}}function Xl(_0x4964c5){return _0x4964c5['host']!==_0x4964c5['internalHost']||_0x4964c5['isCustomHost']()||_0x4964c5['includeNamespaceInQueryParams'];}function go(_0x8fe148,_0x7e0e9f,_0x465e8f){f(typeof _0x7e0e9f=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x465e8f=='object','typeof\x20params\x20must\x20==\x20object');let _0x5e1347;if(_0x7e0e9f===fo)_0x5e1347=(_0x8fe148['secure']?'wss://':'ws://')+_0x8fe148['internalHost']+'/.ws?';else{if(_0x7e0e9f===po)_0x5e1347=(_0x8fe148['secure']?'https://':'http://')+_0x8fe148['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x7e0e9f);}Xl(_0x8fe148)&&(_0x465e8f['ns']=_0x8fe148['namespace']);const _0x31458b=[];return x(_0x465e8f,(_0x2bdfad,_0x5322f7)=>{_0x31458b['push'](_0x2bdfad+'='+_0x5322f7);}),_0x5e1347+_0x31458b['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x5d1c54,_0x1ebe5a=0x1){Y(this['counters_'],_0x5d1c54)||(this['counters_'][_0x5d1c54]=0x0),this['counters_'][_0x5d1c54]+=_0x1ebe5a;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x4523a4){const _0x35a23e=_0x4523a4['toString']();return ti[_0x35a23e]||(ti[_0x35a23e]=new Zl()),ti[_0x35a23e];}function eh(_0x564a0a,_0x2040a9){const _0x432999=_0x564a0a['toString']();return ni[_0x432999]||(ni[_0x432999]=_0x2040a9()),ni[_0x432999];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x25af59){this['onMessage_']=_0x25af59,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3d19b0,_0x10892a){this['closeAfterResponse']=_0x3d19b0,this['onClose']=_0x10892a,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xe31231,_0x3f1f99){for(this['pendingResponses'][_0xe31231]=_0x3f1f99;this['pendingResponses'][this['currentResponseNum']];){const _0x59cf43=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x2654d8=0x0;_0x2654d8<_0x59cf43['length'];++_0x2654d8)_0x59cf43[_0x2654d8]&&lt(()=>{this['onMessage_'](_0x59cf43[_0x2654d8]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x3dd0fc,_0x23de9a,_0x1c8c50,_0x2bdfc8,_0x5a0fdd,_0x2462ee,_0x5d4ea5){this['connId']=_0x3dd0fc,this['repoInfo']=_0x23de9a,this['applicationId']=_0x1c8c50,this['appCheckToken']=_0x2bdfc8,this['authToken']=_0x5a0fdd,this['transportSessionId']=_0x2462ee,this['lastSessionId']=_0x5d4ea5,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x3dd0fc),this['stats_']=Hi(_0x23de9a),this['urlFn']=_0x37c590=>(this['appCheckToken']&&(_0x37c590[yi]=this['appCheckToken']),go(_0x23de9a,po,_0x37c590));}['open'](_0x31305e,_0x36d817){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x36d817,this['myPacketOrderer']=new th(_0x31305e),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x2be986)=>{const [_0x20db1c,_0x3a8a2a,_0x2e0ed9,_0x363143,_0xde6b20]=_0x2be986;if(this['incrementIncomingBytes_'](_0x2be986),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x20db1c===$s)this['id']=_0x3a8a2a,this['password']=_0x2e0ed9;else{if(_0x20db1c===nh)_0x3a8a2a?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3a8a2a,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x20db1c);}}},(..._0x98688d)=>{const [_0x4f1cc2,_0x5885e8]=_0x98688d;this['incrementIncomingBytes_'](_0x98688d),this['myPacketOrderer']['handleResponse'](_0x4f1cc2,_0x5885e8);},()=>{this['onClosed_']();},this['urlFn']);const _0x31c9b2={};_0x31c9b2[$s]='t',_0x31c9b2[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x31c9b2[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x31c9b2[ro]=Vi,this['transportSessionId']&&(_0x31c9b2[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x31c9b2[ho]=this['lastSessionId']),this['applicationId']&&(_0x31c9b2[uo]=this['applicationId']),this['appCheckToken']&&(_0x31c9b2[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x31c9b2[ao]=co);const _0x30810d=this['urlFn'](_0x31c9b2);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x30810d),this['scriptTagHolder']['addTag'](_0x30810d,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4f9b9b){const _0x1dfa70=O(_0x4f9b9b);this['bytesSent']+=_0x1dfa70['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1dfa70['length']);const _0x4d14ae=Br(_0x1dfa70),_0x41b7bc=io(_0x4d14ae,hh);for(let _0x1224c2=0x0;_0x1224c2<_0x41b7bc['length'];_0x1224c2++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x41b7bc['length'],_0x41b7bc[_0x1224c2]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x59dc4f,_0x515a72){this['myDisconnFrame']=document['createElement']('iframe');const _0x1ba237={};_0x1ba237[lh]='t',_0x1ba237[mo]=_0x59dc4f,_0x1ba237[yo]=_0x515a72,this['myDisconnFrame']['src']=this['urlFn'](_0x1ba237),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1117e1){const _0x1e3988=O(_0x1117e1)['length'];this['bytesReceived']+=_0x1e3988,this['stats_']['incrementCounter']('bytes_received',_0x1e3988);}}class $i{constructor(_0x153192,_0x569d8e,_0x492f86,_0x201d8d){this['onDisconnect']=_0x492f86,this['urlFn']=_0x201d8d,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x153192,window[sh+this['uniqueCallbackIdentifier']]=_0x569d8e,this['myIFrame']=$i['createIFrame_']();let _0x108e7f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x108e7f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x142e6b='<html><body>'+_0x108e7f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x142e6b),this['myIFrame']['doc']['close']();}catch(_0x55a3a8){L('frame\x20writing\x20exception'),_0x55a3a8['stack']&&L(_0x55a3a8['stack']),L(_0x55a3a8);}}}static['createIFrame_'](){const _0x513386=document['createElement']('iframe');if(_0x513386['style']['display']='none',document['body']){document['body']['appendChild'](_0x513386);try{_0x513386['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x57bd42=document['domain'];_0x513386['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x57bd42+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x513386['contentDocument']?_0x513386['doc']=_0x513386['contentDocument']:_0x513386['contentWindow']?_0x513386['doc']=_0x513386['contentWindow']['document']:_0x513386['document']&&(_0x513386['doc']=_0x513386['document']),_0x513386;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x593099=this['onDisconnect'];_0x593099&&(this['onDisconnect']=null,_0x593099());}['startLongPoll'](_0x339e2d,_0x499f54){for(this['myID']=_0x339e2d,this['myPW']=_0x499f54,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x28cdbd={};_0x28cdbd[mo]=this['myID'],_0x28cdbd[yo]=this['myPW'],_0x28cdbd[vo]=this['currentSerial'];let _0x43cdbb=this['urlFn'](_0x28cdbd),_0x39b91f='',_0x1a37f6=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x39b91f['length']<=Eo;){const _0x4b088a=this['pendingSegs']['shift']();_0x39b91f=_0x39b91f+'&'+oh+_0x1a37f6+'='+_0x4b088a['seg']+'&'+ah+_0x1a37f6+'='+_0x4b088a['ts']+'&'+ch+_0x1a37f6+'='+_0x4b088a['d'],_0x1a37f6++;}return _0x43cdbb=_0x43cdbb+_0x39b91f,this['addLongPollTag_'](_0x43cdbb,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x371c73,_0x748c9c,_0xebd065){this['pendingSegs']['push']({'seg':_0x371c73,'ts':_0x748c9c,'d':_0xebd065}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xfd01c0,_0x368b89){this['outstandingRequests']['add'](_0x368b89);const _0x12e584=()=>{this['outstandingRequests']['delete'](_0x368b89),this['newRequest_']();},_0x13e81b=setTimeout(_0x12e584,Math['floor'](uh)),_0x506456=()=>{clearTimeout(_0x13e81b),_0x12e584();};this['addTag'](_0xfd01c0,_0x506456);}['addTag'](_0x294104,_0x54ccc3){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x58539c=this['myIFrame']['doc']['createElement']('script');_0x58539c['type']='text/javascript',_0x58539c['async']=!0x0,_0x58539c['src']=_0x294104,_0x58539c['onload']=_0x58539c['onreadystatechange']=function(){const _0xf704a7=_0x58539c['readyState'];(!_0xf704a7||_0xf704a7==='loaded'||_0xf704a7==='complete')&&(_0x58539c['onload']=_0x58539c['onreadystatechange']=null,_0x58539c['parentNode']&&_0x58539c['parentNode']['removeChild'](_0x58539c),_0x54ccc3());},_0x58539c['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x294104),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x58539c);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x300482,_0x5b904b,_0x5a78c6,_0x5d6971,_0xfcee9c,_0x5e4d63,_0x4fdf28){this['connId']=_0x300482,this['applicationId']=_0x5a78c6,this['appCheckToken']=_0x5d6971,this['authToken']=_0xfcee9c,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x5b904b),this['connURL']=G['connectionURL_'](_0x5b904b,_0x5e4d63,_0x4fdf28,_0x5d6971,_0x5a78c6),this['nodeAdmin']=_0x5b904b['nodeAdmin'];}static['connectionURL_'](_0x494b9a,_0x32180c,_0xc3953f,_0x389b5a,_0x56ce5b){const _0x14b917={};return _0x14b917[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x14b917[ao]=co),_0x32180c&&(_0x14b917[oo]=_0x32180c),_0xc3953f&&(_0x14b917[ho]=_0xc3953f),_0x389b5a&&(_0x14b917[yi]=_0x389b5a),_0x56ce5b&&(_0x14b917[uo]=_0x56ce5b),go(_0x494b9a,fo,_0x14b917);}['open'](_0x3a6af4,_0x3e4456){this['onDisconnect']=_0x3e4456,this['onMessage']=_0x3a6af4,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x27b7df;dc(),this['mySock']=new hn(this['connURL'],[],_0x27b7df);}catch(_0xcd99c2){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x34c7f1=_0xcd99c2['message']||_0xcd99c2['data'];_0x34c7f1&&this['log_'](_0x34c7f1),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x283126=>{this['handleIncomingFrame'](_0x283126);},this['mySock']['onerror']=_0x4b6a8c=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3eddb7=_0x4b6a8c['message']||_0x4b6a8c['data'];_0x3eddb7&&this['log_'](_0x3eddb7),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x47a345=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x33481a=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3b83b7=navigator['userAgent']['match'](_0x33481a);_0x3b83b7&&_0x3b83b7['length']>0x1&&parseFloat(_0x3b83b7[0x1])<4.4&&(_0x47a345=!0x0);}return!_0x47a345&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x16c18c){if(this['frames']['push'](_0x16c18c),this['frames']['length']===this['totalFrames']){const _0x52e152=this['frames']['join']('');this['frames']=null;const _0x5020d9=bt(_0x52e152);this['onMessage'](_0x5020d9);}}['handleNewFrameCount_'](_0x3d184a){this['totalFrames']=_0x3d184a,this['frames']=[];}['extractFrameCount_'](_0x163776){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x163776['length']<=0x6){const _0x5ceac1=Number(_0x163776);if(!isNaN(_0x5ceac1))return this['handleNewFrameCount_'](_0x5ceac1),null;}return this['handleNewFrameCount_'](0x1),_0x163776;}['handleIncomingFrame'](_0xc718b1){if(this['mySock']===null)return;const _0x5663f4=_0xc718b1['data'];if(this['bytesReceived']+=_0x5663f4['length'],this['stats_']['incrementCounter']('bytes_received',_0x5663f4['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x5663f4);else{const _0x231b88=this['extractFrameCount_'](_0x5663f4);_0x231b88!==null&&this['appendFrame_'](_0x231b88);}}['send'](_0x409d1b){this['resetKeepAlive']();const _0x5ce4a3=O(_0x409d1b);this['bytesSent']+=_0x5ce4a3['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5ce4a3['length']);const _0x588ef3=io(_0x5ce4a3,fh);_0x588ef3['length']>0x1&&this['sendString_'](String(_0x588ef3['length']));for(let _0x3f9526=0x0;_0x3f9526<_0x588ef3['length'];_0x3f9526++)this['sendString_'](_0x588ef3[_0x3f9526]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x2f11f1){try{this['mySock']['send'](_0x2f11f1);}catch(_0x56d807){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x56d807['message']||_0x56d807['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x29e679){this['initTransports_'](_0x29e679);}['initTransports_'](_0xf1b225){const _0x4dd288=G&&G['isAvailable']();let _0x495f3d=_0x4dd288&&!G['previouslyFailed']();if(_0xf1b225['webSocketOnly']&&(_0x4dd288||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x495f3d=!0x0),_0x495f3d)this['transports_']=[G];else{const _0x20326a=this['transports_']=[];for(const _0xfae7c4 of At['ALL_TRANSPORTS'])_0xfae7c4&&_0xfae7c4['isAvailable']()&&_0x20326a['push'](_0xfae7c4);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x29e493,_0x4ac7ea,_0x2a199e,_0x2bb603,_0x274994,_0x15d165,_0xfa39b,_0x1a4a31,_0x2e6f9c,_0x3b760e){this['id']=_0x29e493,this['repoInfo_']=_0x4ac7ea,this['applicationId_']=_0x2a199e,this['appCheckToken_']=_0x2bb603,this['authToken_']=_0x274994,this['onMessage_']=_0x15d165,this['onReady_']=_0xfa39b,this['onDisconnect_']=_0x1a4a31,this['onKill_']=_0x2e6f9c,this['lastSessionId']=_0x3b760e,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x4ac7ea),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1a781e=this['transportManager_']['initialTransport']();this['conn_']=new _0x1a781e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1a781e['responsesRequiredToBeHealthy']||0x0;const _0x49e9e7=this['connReceiver_'](this['conn_']),_0x4b79bd=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x49e9e7,_0x4b79bd);},Math['floor'](0x0));const _0x1f8d90=_0x1a781e['healthyTimeout']||0x0;_0x1f8d90>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x1f8d90)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0xfa4fd4){return _0xceec14=>{_0xfa4fd4===this['conn_']?this['onConnectionLost_'](_0xceec14):_0xfa4fd4===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x4ee434){return _0x43f61f=>{this['state_']!==0x2&&(_0x4ee434===this['rx_']?this['onPrimaryMessageReceived_'](_0x43f61f):_0x4ee434===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x43f61f):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x248c03){const _0x36fac2={'t':'d','d':_0x248c03};this['sendData_'](_0x36fac2);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x30e5cd){if(ii in _0x30e5cd){const _0x1878e3=_0x30e5cd[ii];_0x1878e3===js?this['upgradeIfSecondaryHealthy_']():_0x1878e3===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1878e3===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x25da41){const _0x114ca9=pt('t',_0x25da41),_0x30d1f5=pt('d',_0x25da41);if(_0x114ca9==='c')this['onSecondaryControl_'](_0x30d1f5);else{if(_0x114ca9==='d')this['pendingDataMessages']['push'](_0x30d1f5);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x114ca9);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x38ea49){const _0x22f265=pt('t',_0x38ea49),_0x58c8a9=pt('d',_0x38ea49);_0x22f265==='c'?this['onControl_'](_0x58c8a9):_0x22f265==='d'&&this['onDataMessage_'](_0x58c8a9);}['onDataMessage_'](_0x300bec){this['onPrimaryResponse_'](),this['onMessage_'](_0x300bec);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x37446f){const _0x351764=pt(ii,_0x37446f);if(Gs in _0x37446f){const _0x3dc040=_0x37446f[Gs];if(_0x351764===Ih){const _0xa170eb={..._0x3dc040};this['repoInfo_']['isUsingEmulator']&&(_0xa170eb['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xa170eb);}else{if(_0x351764===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4900d9=0x0;_0x4900d9<this['pendingDataMessages']['length'];++_0x4900d9)this['onDataMessage_'](this['pendingDataMessages'][_0x4900d9]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x351764===vh?this['onConnectionShutdown_'](_0x3dc040):_0x351764===qs?this['onReset_'](_0x3dc040):_0x351764===Eh?mi('Server\x20Error:\x20'+_0x3dc040):_0x351764===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x351764);}}}['onHandshake_'](_0x5a8e16){const _0x59dd25=_0x5a8e16['ts'],_0x285c74=_0x5a8e16['v'],_0x153dd9=_0x5a8e16['h'];this['sessionId']=_0x5a8e16['s'],this['repoInfo_']['host']=_0x153dd9,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x59dd25),Vi!==_0x285c74&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1668e2=this['transportManager_']['upgradeTransport']();_0x1668e2&&this['startUpgrade_'](_0x1668e2);}['startUpgrade_'](_0x2c145f){this['secondaryConn_']=new _0x2c145f(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x2c145f['responsesRequiredToBeHealthy']||0x0;const _0xcaabe0=this['connReceiver_'](this['secondaryConn_']),_0x280eb5=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0xcaabe0,_0x280eb5),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0xd4ad22){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xd4ad22),this['repoInfo_']['host']=_0xd4ad22,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x52cc1c,_0x55534f){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x52cc1c,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x55534f,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x312a43=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x312a43||this['rx_']===_0x312a43)&&this['close']();}['onConnectionLost_'](_0x1caf25){this['conn_']=null,!_0x1caf25&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x24c8bb){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x24c8bb),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5c57f1){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5c57f1);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x4f3131,_0x3d7ed7,_0x36b77c,_0x3781a0){}['merge'](_0x967787,_0x2f07bd,_0x2655d1,_0x4cddd0){}['refreshAuthToken'](_0x368937){}['refreshAppCheckToken'](_0x57ffbc){}['onDisconnectPut'](_0x480cd3,_0x32d916,_0x3dfabf){}['onDisconnectMerge'](_0x587c5f,_0x435343,_0x2574c0){}['onDisconnectCancel'](_0x17c866,_0x89ed3f){}['reportStats'](_0x328861){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x4c1a33){this['allowedEvents_']=_0x4c1a33,this['listeners_']={},f(Array['isArray'](_0x4c1a33)&&_0x4c1a33['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x35cbe2,..._0x4bdf3f){if(Array['isArray'](this['listeners_'][_0x35cbe2])){const _0x47b945=[...this['listeners_'][_0x35cbe2]];for(let _0x1439fd=0x0;_0x1439fd<_0x47b945['length'];_0x1439fd++)_0x47b945[_0x1439fd]['callback']['apply'](_0x47b945[_0x1439fd]['context'],_0x4bdf3f);}}['on'](_0x5d567d,_0x5bc1ba,_0x1ae683){this['validateEventType_'](_0x5d567d),this['listeners_'][_0x5d567d]=this['listeners_'][_0x5d567d]||[],this['listeners_'][_0x5d567d]['push']({'callback':_0x5bc1ba,'context':_0x1ae683});const _0x12c1e0=this['getInitialEvent'](_0x5d567d);_0x12c1e0&&_0x5bc1ba['apply'](_0x1ae683,_0x12c1e0);}['off'](_0x47295e,_0x1e769a,_0x3da3fc){this['validateEventType_'](_0x47295e);const _0x38d1af=this['listeners_'][_0x47295e]||[];for(let _0x30979e=0x0;_0x30979e<_0x38d1af['length'];_0x30979e++)if(_0x38d1af[_0x30979e]['callback']===_0x1e769a&&(!_0x3da3fc||_0x3da3fc===_0x38d1af[_0x30979e]['context'])){_0x38d1af['splice'](_0x30979e,0x1);return;}}['validateEventType_'](_0x40b8a7){f(this['allowedEvents_']['find'](_0xf66273=>_0xf66273===_0x40b8a7),'Unknown\x20event:\x20'+_0x40b8a7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0xf5eba9){return f(_0xf5eba9==='online','Unknown\x20event\x20type:\x20'+_0xf5eba9),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x257818,_0x1ed50d){if(_0x1ed50d===void 0x0){this['pieces_']=_0x257818['split']('/');let _0x223f88=0x0;for(let _0x1cbc17=0x0;_0x1cbc17<this['pieces_']['length'];_0x1cbc17++)this['pieces_'][_0x1cbc17]['length']>0x0&&(this['pieces_'][_0x223f88]=this['pieces_'][_0x1cbc17],_0x223f88++);this['pieces_']['length']=_0x223f88,this['pieceNum_']=0x0;}else this['pieces_']=_0x257818,this['pieceNum_']=_0x1ed50d;}['toString'](){let _0x5e0665='';for(let _0x30f5f6=this['pieceNum_'];_0x30f5f6<this['pieces_']['length'];_0x30f5f6++)this['pieces_'][_0x30f5f6]!==''&&(_0x5e0665+='/'+this['pieces_'][_0x30f5f6]);return _0x5e0665||'/';}}function w(){return new C('');}function y(_0x159de0){return _0x159de0['pieceNum_']>=_0x159de0['pieces_']['length']?null:_0x159de0['pieces_'][_0x159de0['pieceNum_']];}function we(_0x5dea85){return _0x5dea85['pieces_']['length']-_0x5dea85['pieceNum_'];}function b(_0x2d7143){let _0x5a5250=_0x2d7143['pieceNum_'];return _0x5a5250<_0x2d7143['pieces_']['length']&&_0x5a5250++,new C(_0x2d7143['pieces_'],_0x5a5250);}function Gi(_0x523b4a){return _0x523b4a['pieceNum_']<_0x523b4a['pieces_']['length']?_0x523b4a['pieces_'][_0x523b4a['pieces_']['length']-0x1]:null;}function Ch(_0x17d461){let _0x1edd9b='';for(let _0x25ce65=_0x17d461['pieceNum_'];_0x25ce65<_0x17d461['pieces_']['length'];_0x25ce65++)_0x17d461['pieces_'][_0x25ce65]!==''&&(_0x1edd9b+='/'+encodeURIComponent(String(_0x17d461['pieces_'][_0x25ce65])));return _0x1edd9b||'/';}function kt(_0x3113ae,_0xc7a74e=0x0){return _0x3113ae['pieces_']['slice'](_0x3113ae['pieceNum_']+_0xc7a74e);}function To(_0x40dddd){if(_0x40dddd['pieceNum_']>=_0x40dddd['pieces_']['length'])return null;const _0x4461a1=[];for(let _0x461715=_0x40dddd['pieceNum_'];_0x461715<_0x40dddd['pieces_']['length']-0x1;_0x461715++)_0x4461a1['push'](_0x40dddd['pieces_'][_0x461715]);return new C(_0x4461a1,0x0);}function A(_0x43897e,_0x3ff805){const _0x89c9fa=[];for(let _0x2d79b7=_0x43897e['pieceNum_'];_0x2d79b7<_0x43897e['pieces_']['length'];_0x2d79b7++)_0x89c9fa['push'](_0x43897e['pieces_'][_0x2d79b7]);if(_0x3ff805 instanceof C){for(let _0x24fec0=_0x3ff805['pieceNum_'];_0x24fec0<_0x3ff805['pieces_']['length'];_0x24fec0++)_0x89c9fa['push'](_0x3ff805['pieces_'][_0x24fec0]);}else{const _0x43531b=_0x3ff805['split']('/');for(let _0xa10622=0x0;_0xa10622<_0x43531b['length'];_0xa10622++)_0x43531b[_0xa10622]['length']>0x0&&_0x89c9fa['push'](_0x43531b[_0xa10622]);}return new C(_0x89c9fa,0x0);}function v(_0x28e819){return _0x28e819['pieceNum_']>=_0x28e819['pieces_']['length'];}function F(_0x20356d,_0x3cf8dd){const _0x293ed4=y(_0x20356d),_0x35839a=y(_0x3cf8dd);if(_0x293ed4===null)return _0x3cf8dd;if(_0x293ed4===_0x35839a)return F(b(_0x20356d),b(_0x3cf8dd));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3cf8dd+')\x20is\x20not\x20within\x20outerPath\x20('+_0x20356d+')');}function Th(_0x2aabef,_0x10c4bf){const _0x5a9439=kt(_0x2aabef,0x0),_0x5cdc09=kt(_0x10c4bf,0x0);for(let _0x49d697=0x0;_0x49d697<_0x5a9439['length']&&_0x49d697<_0x5cdc09['length'];_0x49d697++){const _0x2a3e58=He(_0x5a9439[_0x49d697],_0x5cdc09[_0x49d697]);if(_0x2a3e58!==0x0)return _0x2a3e58;}return _0x5a9439['length']===_0x5cdc09['length']?0x0:_0x5a9439['length']<_0x5cdc09['length']?-0x1:0x1;}function qi(_0x295e07,_0x5f117d){if(we(_0x295e07)!==we(_0x5f117d))return!0x1;for(let _0x28afa2=_0x295e07['pieceNum_'],_0x278bb1=_0x5f117d['pieceNum_'];_0x28afa2<=_0x295e07['pieces_']['length'];_0x28afa2++,_0x278bb1++)if(_0x295e07['pieces_'][_0x28afa2]!==_0x5f117d['pieces_'][_0x278bb1])return!0x1;return!0x0;}function $(_0xaef9ce,_0x2c506c){let _0x3b3bb8=_0xaef9ce['pieceNum_'],_0x921ea0=_0x2c506c['pieceNum_'];if(we(_0xaef9ce)>we(_0x2c506c))return!0x1;for(;_0x3b3bb8<_0xaef9ce['pieces_']['length'];){if(_0xaef9ce['pieces_'][_0x3b3bb8]!==_0x2c506c['pieces_'][_0x921ea0])return!0x1;++_0x3b3bb8,++_0x921ea0;}return!0x0;}class Sh{constructor(_0x2d81eb,_0x57ca6e){this['errorPrefix_']=_0x57ca6e,this['parts_']=kt(_0x2d81eb,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x10c3fc=0x0;_0x10c3fc<this['parts_']['length'];_0x10c3fc++)this['byteLength_']+=Pn(this['parts_'][_0x10c3fc]);So(this);}}function bh(_0x14aff9,_0x5c992d){_0x14aff9['parts_']['length']>0x0&&(_0x14aff9['byteLength_']+=0x1),_0x14aff9['parts_']['push'](_0x5c992d),_0x14aff9['byteLength_']+=Pn(_0x5c992d),So(_0x14aff9);}function Rh(_0x4f2c30){const _0x2f2547=_0x4f2c30['parts_']['pop']();_0x4f2c30['byteLength_']-=Pn(_0x2f2547),_0x4f2c30['parts_']['length']>0x0&&(_0x4f2c30['byteLength_']-=0x1);}function So(_0x187370){if(_0x187370['byteLength_']>Js)throw new Error(_0x187370['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x187370['byteLength_']+').');if(_0x187370['parts_']['length']>Qs)throw new Error(_0x187370['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x187370));}function Ne(_0x33395e){return _0x33395e['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x33395e['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x15b76a,_0x476bc6;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x476bc6='visibilitychange',_0x15b76a='hidden'):typeof document['mozHidden']<'u'?(_0x476bc6='mozvisibilitychange',_0x15b76a='mozHidden'):typeof document['msHidden']<'u'?(_0x476bc6='msvisibilitychange',_0x15b76a='msHidden'):typeof document['webkitHidden']<'u'&&(_0x476bc6='webkitvisibilitychange',_0x15b76a='webkitHidden')),this['visible_']=!0x0,_0x476bc6&&document['addEventListener'](_0x476bc6,()=>{const _0x3a327b=!document[_0x15b76a];_0x3a327b!==this['visible_']&&(this['visible_']=_0x3a327b,this['trigger']('visible',_0x3a327b));},!0x1);}['getInitialEvent'](_0x3d570a){return f(_0x3d570a==='visible','Unknown\x20event\x20type:\x20'+_0x3d570a),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x25f70d,_0x1ab3f6,_0x8a6272,_0x4647f6,_0x12ab88,_0x515330,_0x51b2fe,_0x542742){if(super(),this['repoInfo_']=_0x25f70d,this['applicationId_']=_0x1ab3f6,this['onDataUpdate_']=_0x8a6272,this['onConnectStatus_']=_0x4647f6,this['onServerInfoUpdate_']=_0x12ab88,this['authTokenProvider_']=_0x515330,this['appCheckTokenProvider_']=_0x51b2fe,this['authOverride_']=_0x542742,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x542742)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x25f70d['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x253d86,_0xc47d78,_0x1512f0){const _0x45f563=++this['requestNumber_'],_0x4cd606={'r':_0x45f563,'a':_0x253d86,'b':_0xc47d78};this['log_'](O(_0x4cd606)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4cd606),_0x1512f0&&(this['requestCBHash_'][_0x45f563]=_0x1512f0);}['get'](_0x312249){this['initConnection_']();const _0xc1046c=new Ve(),_0x2e8697={'action':'g','request':{'p':_0x312249['_path']['toString'](),'q':_0x312249['_queryObject']},'onComplete':_0x2b09f7=>{const _0x53a652=_0x2b09f7['d'];_0x2b09f7['s']==='ok'?_0xc1046c['resolve'](_0x53a652):_0xc1046c['reject'](_0x53a652);}};this['outstandingGets_']['push'](_0x2e8697),this['outstandingGetCount_']++;const _0x3062b3=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3062b3),_0xc1046c['promise'];}['listen'](_0x12c517,_0x477e1e,_0x17ce52,_0x561c69){this['initConnection_']();const _0x45b502=_0x12c517['_queryIdentifier'],_0x5357e3=_0x12c517['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5357e3+'\x20'+_0x45b502),this['listens']['has'](_0x5357e3)||this['listens']['set'](_0x5357e3,new Map()),f(_0x12c517['_queryParams']['isDefault']()||!_0x12c517['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x5357e3)['has'](_0x45b502),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0xc7dcf6={'onComplete':_0x561c69,'hashFn':_0x477e1e,'query':_0x12c517,'tag':_0x17ce52};this['listens']['get'](_0x5357e3)['set'](_0x45b502,_0xc7dcf6),this['connected_']&&this['sendListen_'](_0xc7dcf6);}['sendGet_'](_0x250e42){const _0x20c724=this['outstandingGets_'][_0x250e42];this['sendRequest']('g',_0x20c724['request'],_0x3d25ca=>{delete this['outstandingGets_'][_0x250e42],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x20c724['onComplete']&&_0x20c724['onComplete'](_0x3d25ca);});}['sendListen_'](_0x5215db){const _0x212444=_0x5215db['query'],_0xae4904=_0x212444['_path']['toString'](),_0x2cd885=_0x212444['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0xae4904+'\x20for\x20'+_0x2cd885);const _0x2e0796={'p':_0xae4904},_0x4e8218='q';_0x5215db['tag']&&(_0x2e0796['q']=_0x212444['_queryObject'],_0x2e0796['t']=_0x5215db['tag']),_0x2e0796['h']=_0x5215db['hashFn'](),this['sendRequest'](_0x4e8218,_0x2e0796,_0x30c033=>{const _0x2fe5dd=_0x30c033['d'],_0x1f5a1d=_0x30c033['s'];ie['warnOnListenWarnings_'](_0x2fe5dd,_0x212444),(this['listens']['get'](_0xae4904)&&this['listens']['get'](_0xae4904)['get'](_0x2cd885))===_0x5215db&&(this['log_']('listen\x20response',_0x30c033),_0x1f5a1d!=='ok'&&this['removeListen_'](_0xae4904,_0x2cd885),_0x5215db['onComplete']&&_0x5215db['onComplete'](_0x1f5a1d,_0x2fe5dd));});}static['warnOnListenWarnings_'](_0x2b1801,_0x538c98){if(_0x2b1801&&typeof _0x2b1801=='object'&&Y(_0x2b1801,'w')){const _0x4c37aa=Oe(_0x2b1801,'w');if(Array['isArray'](_0x4c37aa)&&~_0x4c37aa['indexOf']('no_index')){const _0x442986='\x22.indexOn\x22:\x20\x22'+_0x538c98['_queryParams']['getIndex']()['toString']()+'\x22',_0x1cca51=_0x538c98['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x442986+'\x20at\x20'+_0x1cca51+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1dbdca){this['authToken_']=_0x1dbdca,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1dbdca);}['reduceReconnectDelayIfAdminCredential_'](_0x3e012b){(_0x3e012b&&_0x3e012b['length']===0x28||vc(_0x3e012b))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x5193b5){this['appCheckToken_']=_0x5193b5,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x1ccee3=this['authToken_'],_0x5d9d2a=yc(_0x1ccee3)?'auth':'gauth',_0x3dc84b={'cred':_0x1ccee3};this['authOverride_']===null?_0x3dc84b['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x3dc84b['authvar']=this['authOverride_']),this['sendRequest'](_0x5d9d2a,_0x3dc84b,_0x284f02=>{const _0x485dde=_0x284f02['s'],_0x4808bf=_0x284f02['d']||'error';this['authToken_']===_0x1ccee3&&(_0x485dde==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x485dde,_0x4808bf));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1bafc5=>{const _0x3f9932=_0x1bafc5['s'],_0x5b919a=_0x1bafc5['d']||'error';_0x3f9932==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x3f9932,_0x5b919a);});}['unlisten'](_0x516957,_0x3d01fe){const _0x5596ec=_0x516957['_path']['toString'](),_0x528d56=_0x516957['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5596ec+'\x20'+_0x528d56),f(_0x516957['_queryParams']['isDefault']()||!_0x516957['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5596ec,_0x528d56)&&this['connected_']&&this['sendUnlisten_'](_0x5596ec,_0x528d56,_0x516957['_queryObject'],_0x3d01fe);}['sendUnlisten_'](_0x1cd530,_0x52dcf3,_0x22f234,_0xd9def){this['log_']('Unlisten\x20on\x20'+_0x1cd530+'\x20for\x20'+_0x52dcf3);const _0x43a2c8={'p':_0x1cd530},_0x24ca09='n';_0xd9def&&(_0x43a2c8['q']=_0x22f234,_0x43a2c8['t']=_0xd9def),this['sendRequest'](_0x24ca09,_0x43a2c8);}['onDisconnectPut'](_0x5bb929,_0x57faa8,_0x4291e0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5bb929,_0x57faa8,_0x4291e0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5bb929,'action':'o','data':_0x57faa8,'onComplete':_0x4291e0});}['onDisconnectMerge'](_0x402fc6,_0x3717ea,_0x337c27){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x402fc6,_0x3717ea,_0x337c27):this['onDisconnectRequestQueue_']['push']({'pathString':_0x402fc6,'action':'om','data':_0x3717ea,'onComplete':_0x337c27});}['onDisconnectCancel'](_0x490944,_0x332b58){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x490944,null,_0x332b58):this['onDisconnectRequestQueue_']['push']({'pathString':_0x490944,'action':'oc','data':null,'onComplete':_0x332b58});}['sendOnDisconnect_'](_0x373f28,_0x46a521,_0xd1dc22,_0x4fe85f){const _0x1b195a={'p':_0x46a521,'d':_0xd1dc22};this['log_']('onDisconnect\x20'+_0x373f28,_0x1b195a),this['sendRequest'](_0x373f28,_0x1b195a,_0x431fb6=>{_0x4fe85f&&setTimeout(()=>{_0x4fe85f(_0x431fb6['s'],_0x431fb6['d']);},Math['floor'](0x0));});}['put'](_0x31cf8f,_0x54ba4d,_0x3b634c,_0x72075a){this['putInternal']('p',_0x31cf8f,_0x54ba4d,_0x3b634c,_0x72075a);}['merge'](_0x142754,_0x37d433,_0x1315fe,_0x4bef4a){this['putInternal']('m',_0x142754,_0x37d433,_0x1315fe,_0x4bef4a);}['putInternal'](_0x473ef5,_0x5f1f47,_0x14c300,_0x4239cb,_0x3e7682){this['initConnection_']();const _0x5ee213={'p':_0x5f1f47,'d':_0x14c300};_0x3e7682!==void 0x0&&(_0x5ee213['h']=_0x3e7682),this['outstandingPuts_']['push']({'action':_0x473ef5,'request':_0x5ee213,'onComplete':_0x4239cb}),this['outstandingPutCount_']++;const _0x248394=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x248394):this['log_']('Buffering\x20put:\x20'+_0x5f1f47);}['sendPut_'](_0x34a550){const _0x3044be=this['outstandingPuts_'][_0x34a550]['action'],_0x45839b=this['outstandingPuts_'][_0x34a550]['request'],_0x329b9e=this['outstandingPuts_'][_0x34a550]['onComplete'];this['outstandingPuts_'][_0x34a550]['queued']=this['connected_'],this['sendRequest'](_0x3044be,_0x45839b,_0x10a248=>{this['log_'](_0x3044be+'\x20response',_0x10a248),delete this['outstandingPuts_'][_0x34a550],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x329b9e&&_0x329b9e(_0x10a248['s'],_0x10a248['d']);});}['reportStats'](_0xeb0545){if(this['connected_']){const _0xa3b41f={'c':_0xeb0545};this['log_']('reportStats',_0xa3b41f),this['sendRequest']('s',_0xa3b41f,_0x42f0ef=>{if(_0x42f0ef['s']!=='ok'){const _0x49b5ae=_0x42f0ef['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x49b5ae);}});}}['onDataMessage_'](_0x58a93f){if('r'in _0x58a93f){this['log_']('from\x20server:\x20'+O(_0x58a93f));const _0x426f89=_0x58a93f['r'],_0x1eb40c=this['requestCBHash_'][_0x426f89];_0x1eb40c&&(delete this['requestCBHash_'][_0x426f89],_0x1eb40c(_0x58a93f['b']));}else{if('error'in _0x58a93f)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x58a93f['error'];'a'in _0x58a93f&&this['onDataPush_'](_0x58a93f['a'],_0x58a93f['b']);}}['onDataPush_'](_0x224431,_0x4bc936){this['log_']('handleServerMessage',_0x224431,_0x4bc936),_0x224431==='d'?this['onDataUpdate_'](_0x4bc936['p'],_0x4bc936['d'],!0x1,_0x4bc936['t']):_0x224431==='m'?this['onDataUpdate_'](_0x4bc936['p'],_0x4bc936['d'],!0x0,_0x4bc936['t']):_0x224431==='c'?this['onListenRevoked_'](_0x4bc936['p'],_0x4bc936['q']):_0x224431==='ac'?this['onAuthRevoked_'](_0x4bc936['s'],_0x4bc936['d']):_0x224431==='apc'?this['onAppCheckRevoked_'](_0x4bc936['s'],_0x4bc936['d']):_0x224431==='sd'?this['onSecurityDebugPacket_'](_0x4bc936):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x224431)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2ad901,_0x3375dd){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2ad901),this['lastSessionId']=_0x3375dd,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3c0571){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3c0571));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x144a92){_0x144a92&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x144a92;}['onOnline_'](_0x36dbf7){_0x36dbf7?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x50e775=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3c4b1f=Math['max'](0x0,this['reconnectDelay_']-_0x50e775);_0x3c4b1f=Math['random']()*_0x3c4b1f,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3c4b1f+'ms'),this['scheduleConnect_'](_0x3c4b1f),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x39d8be=this['onDataMessage_']['bind'](this),_0x40f2eb=this['onReady_']['bind'](this),_0x1a1650=this['onRealtimeDisconnect_']['bind'](this),_0x16bca1=this['id']+':'+ie['nextConnectionId_']++,_0x380d22=this['lastSessionId'];let _0x196515=!0x1,_0x28110d=null;const _0x1f9de9=function(){_0x28110d?_0x28110d['close']():(_0x196515=!0x0,_0x1a1650());},_0x13941d=function(_0x3cfeb1){f(_0x28110d,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x28110d['sendRequest'](_0x3cfeb1);};this['realtime_']={'close':_0x1f9de9,'sendRequest':_0x13941d};const _0x39b4e7=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x126620,_0x4014bf]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x39b4e7),this['appCheckTokenProvider_']['getToken'](_0x39b4e7)]);_0x196515?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x126620&&_0x126620['accessToken'],this['appCheckToken_']=_0x4014bf&&_0x4014bf['token'],_0x28110d=new wh(_0x16bca1,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x39d8be,_0x40f2eb,_0x1a1650,_0x40f943=>{U(_0x40f943+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x380d22));}catch(_0x90a692){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x90a692),_0x196515||(this['repoInfo_']['nodeAdmin']&&U(_0x90a692),_0x1f9de9());}}}['interrupt'](_0xba99d0){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0xba99d0),this['interruptReasons_'][_0xba99d0]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x6553b7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x6553b7),delete this['interruptReasons_'][_0x6553b7],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x316d68){const _0x2e7589=_0x316d68-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2e7589});}['cancelSentTransactions_'](){for(let _0x2e7bed=0x0;_0x2e7bed<this['outstandingPuts_']['length'];_0x2e7bed++){const _0x3828b9=this['outstandingPuts_'][_0x2e7bed];_0x3828b9&&'h'in _0x3828b9['request']&&_0x3828b9['queued']&&(_0x3828b9['onComplete']&&_0x3828b9['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2e7bed],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xeb1820,_0x1df775){let _0x4a3fd0;_0x1df775?_0x4a3fd0=_0x1df775['map'](_0x3e8dbc=>Bi(_0x3e8dbc))['join']('$'):_0x4a3fd0='default';const _0x41147d=this['removeListen_'](_0xeb1820,_0x4a3fd0);_0x41147d&&_0x41147d['onComplete']&&_0x41147d['onComplete']('permission_denied');}['removeListen_'](_0x1f9870,_0x3ee289){const _0x2c09df=new C(_0x1f9870)['toString']();let _0x4528fb;if(this['listens']['has'](_0x2c09df)){const _0x2415d4=this['listens']['get'](_0x2c09df);_0x4528fb=_0x2415d4['get'](_0x3ee289),_0x2415d4['delete'](_0x3ee289),_0x2415d4['size']===0x0&&this['listens']['delete'](_0x2c09df);}else _0x4528fb=void 0x0;return _0x4528fb;}['onAuthRevoked_'](_0x3a488b,_0x37cf2a){L('Auth\x20token\x20revoked:\x20'+_0x3a488b+'/'+_0x37cf2a),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3a488b==='invalid_token'||_0x3a488b==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x940685,_0xbaf1a4){L('App\x20check\x20token\x20revoked:\x20'+_0x940685+'/'+_0xbaf1a4),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x940685==='invalid_token'||_0x940685==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2d7df1){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2d7df1):'msg'in _0x2d7df1&&console['log']('FIREBASE:\x20'+_0x2d7df1['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5a1baa of this['listens']['values']())for(const _0x3040e9 of _0x5a1baa['values']())this['sendListen_'](_0x3040e9);for(let _0x1bb421=0x0;_0x1bb421<this['outstandingPuts_']['length'];_0x1bb421++)this['outstandingPuts_'][_0x1bb421]&&this['sendPut_'](_0x1bb421);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2259aa=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2259aa['action'],_0x2259aa['pathString'],_0x2259aa['data'],_0x2259aa['onComplete']);}for(let _0xbc46e0=0x0;_0xbc46e0<this['outstandingGets_']['length'];_0xbc46e0++)this['outstandingGets_'][_0xbc46e0]&&this['sendGet_'](_0xbc46e0);}['sendConnectStats_'](){const _0x1c0430={};let _0x5f23f3='js';_0x1c0430['sdk.'+_0x5f23f3+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x1c0430['framework.cordova']=0x1:qr()&&(_0x1c0430['framework.reactnative']=0x1),this['reportStats'](_0x1c0430);}['shouldReconnect_'](){const _0x6149d7=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x6149d7;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4e3d67,_0x422e0e){this['name']=_0x4e3d67,this['node']=_0x422e0e;}static['Wrap'](_0x5e1957,_0x1090c8){return new E(_0x5e1957,_0x1090c8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x4fe586,_0x486a25){const _0x2281d9=new E(xe,_0x4fe586),_0x575e1c=new E(xe,_0x486a25);return this['compare'](_0x2281d9,_0x575e1c)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x3bbdd1){Xt=_0x3bbdd1;}['compare'](_0x1cc295,_0x232d16){return He(_0x1cc295['name'],_0x232d16['name']);}['isDefinedOn'](_0x22294d){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x748ba,_0x49cb9c){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x5514bb,_0x4d0464){return f(typeof _0x5514bb=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x5514bb,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x9f8087,_0x409235,_0x3eb672,_0x2cbb32,_0xee34bf=null){this['isReverse_']=_0x2cbb32,this['resultGenerator_']=_0xee34bf,this['nodeStack_']=[];let _0x1f083e=0x1;for(;!_0x9f8087['isEmpty']();)if(_0x9f8087=_0x9f8087,_0x1f083e=_0x409235?_0x3eb672(_0x9f8087['key'],_0x409235):0x1,_0x2cbb32&&(_0x1f083e*=-0x1),_0x1f083e<0x0)this['isReverse_']?_0x9f8087=_0x9f8087['left']:_0x9f8087=_0x9f8087['right'];else{if(_0x1f083e===0x0){this['nodeStack_']['push'](_0x9f8087);break;}else this['nodeStack_']['push'](_0x9f8087),this['isReverse_']?_0x9f8087=_0x9f8087['right']:_0x9f8087=_0x9f8087['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x30f941=this['nodeStack_']['pop'](),_0x1d80a0;if(this['resultGenerator_']?_0x1d80a0=this['resultGenerator_'](_0x30f941['key'],_0x30f941['value']):_0x1d80a0={'key':_0x30f941['key'],'value':_0x30f941['value']},this['isReverse_']){for(_0x30f941=_0x30f941['left'];!_0x30f941['isEmpty']();)this['nodeStack_']['push'](_0x30f941),_0x30f941=_0x30f941['right'];}else{for(_0x30f941=_0x30f941['right'];!_0x30f941['isEmpty']();)this['nodeStack_']['push'](_0x30f941),_0x30f941=_0x30f941['left'];}return _0x1d80a0;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x3dbf43=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x3dbf43['key'],_0x3dbf43['value']):{'key':_0x3dbf43['key'],'value':_0x3dbf43['value']};}}class M{constructor(_0x12528a,_0x532faf,_0x155518,_0x10cee3,_0x145a7f){this['key']=_0x12528a,this['value']=_0x532faf,this['color']=_0x155518??M['RED'],this['left']=_0x10cee3??B['EMPTY_NODE'],this['right']=_0x145a7f??B['EMPTY_NODE'];}['copy'](_0x312226,_0xc2fcfe,_0x1998b0,_0x1257b4,_0x338c15){return new M(_0x312226??this['key'],_0xc2fcfe??this['value'],_0x1998b0??this['color'],_0x1257b4??this['left'],_0x338c15??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4af5ca){return this['left']['inorderTraversal'](_0x4af5ca)||!!_0x4af5ca(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4af5ca);}['reverseTraversal'](_0x4a32d5){return this['right']['reverseTraversal'](_0x4a32d5)||_0x4a32d5(this['key'],this['value'])||this['left']['reverseTraversal'](_0x4a32d5);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x595675,_0x3b8159,_0x9988d0){let _0x21fec2=this;const _0x17169e=_0x9988d0(_0x595675,_0x21fec2['key']);return _0x17169e<0x0?_0x21fec2=_0x21fec2['copy'](null,null,null,_0x21fec2['left']['insert'](_0x595675,_0x3b8159,_0x9988d0),null):_0x17169e===0x0?_0x21fec2=_0x21fec2['copy'](null,_0x3b8159,null,null,null):_0x21fec2=_0x21fec2['copy'](null,null,null,null,_0x21fec2['right']['insert'](_0x595675,_0x3b8159,_0x9988d0)),_0x21fec2['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x122c18=this;return!_0x122c18['left']['isRed_']()&&!_0x122c18['left']['left']['isRed_']()&&(_0x122c18=_0x122c18['moveRedLeft_']()),_0x122c18=_0x122c18['copy'](null,null,null,_0x122c18['left']['removeMin_'](),null),_0x122c18['fixUp_']();}['remove'](_0x23a6a6,_0x3c9a17){let _0x3e0033,_0x4635f2;if(_0x3e0033=this,_0x3c9a17(_0x23a6a6,_0x3e0033['key'])<0x0)!_0x3e0033['left']['isEmpty']()&&!_0x3e0033['left']['isRed_']()&&!_0x3e0033['left']['left']['isRed_']()&&(_0x3e0033=_0x3e0033['moveRedLeft_']()),_0x3e0033=_0x3e0033['copy'](null,null,null,_0x3e0033['left']['remove'](_0x23a6a6,_0x3c9a17),null);else{if(_0x3e0033['left']['isRed_']()&&(_0x3e0033=_0x3e0033['rotateRight_']()),!_0x3e0033['right']['isEmpty']()&&!_0x3e0033['right']['isRed_']()&&!_0x3e0033['right']['left']['isRed_']()&&(_0x3e0033=_0x3e0033['moveRedRight_']()),_0x3c9a17(_0x23a6a6,_0x3e0033['key'])===0x0){if(_0x3e0033['right']['isEmpty']())return B['EMPTY_NODE'];_0x4635f2=_0x3e0033['right']['min_'](),_0x3e0033=_0x3e0033['copy'](_0x4635f2['key'],_0x4635f2['value'],null,null,_0x3e0033['right']['removeMin_']());}_0x3e0033=_0x3e0033['copy'](null,null,null,null,_0x3e0033['right']['remove'](_0x23a6a6,_0x3c9a17));}return _0x3e0033['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x5da3fc=this;return _0x5da3fc['right']['isRed_']()&&!_0x5da3fc['left']['isRed_']()&&(_0x5da3fc=_0x5da3fc['rotateLeft_']()),_0x5da3fc['left']['isRed_']()&&_0x5da3fc['left']['left']['isRed_']()&&(_0x5da3fc=_0x5da3fc['rotateRight_']()),_0x5da3fc['left']['isRed_']()&&_0x5da3fc['right']['isRed_']()&&(_0x5da3fc=_0x5da3fc['colorFlip_']()),_0x5da3fc;}['moveRedLeft_'](){let _0x4bda51=this['colorFlip_']();return _0x4bda51['right']['left']['isRed_']()&&(_0x4bda51=_0x4bda51['copy'](null,null,null,null,_0x4bda51['right']['rotateRight_']()),_0x4bda51=_0x4bda51['rotateLeft_'](),_0x4bda51=_0x4bda51['colorFlip_']()),_0x4bda51;}['moveRedRight_'](){let _0x159798=this['colorFlip_']();return _0x159798['left']['left']['isRed_']()&&(_0x159798=_0x159798['rotateRight_'](),_0x159798=_0x159798['colorFlip_']()),_0x159798;}['rotateLeft_'](){const _0x2f0ace=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2f0ace,null);}['rotateRight_'](){const _0x3dd4c7=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x3dd4c7);}['colorFlip_'](){const _0x34efe4=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3dafab=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x34efe4,_0x3dafab);}['checkMaxDepth_'](){const _0x14da6a=this['check_']();return Math['pow'](0x2,_0x14da6a)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1942ae=this['left']['check_']();if(_0x1942ae!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1942ae+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x94d0e5,_0x9e66d5,_0x47ef9f,_0x33af24,_0x20126a){return this;}['insert'](_0x5ae7f3,_0x16d23d,_0x3d2ccf){return new M(_0x5ae7f3,_0x16d23d,null);}['remove'](_0x58eff5,_0x411db2){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x10e0da){return!0x1;}['reverseTraversal'](_0x47d7fa){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0xefdba0,_0x3edba2=B['EMPTY_NODE']){this['comparator_']=_0xefdba0,this['root_']=_0x3edba2;}['insert'](_0x590da9,_0x2fb2d8){return new B(this['comparator_'],this['root_']['insert'](_0x590da9,_0x2fb2d8,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x23e52d){return new B(this['comparator_'],this['root_']['remove'](_0x23e52d,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1a8489){let _0x31e978,_0x49b12c=this['root_'];for(;!_0x49b12c['isEmpty']();){if(_0x31e978=this['comparator_'](_0x1a8489,_0x49b12c['key']),_0x31e978===0x0)return _0x49b12c['value'];_0x31e978<0x0?_0x49b12c=_0x49b12c['left']:_0x31e978>0x0&&(_0x49b12c=_0x49b12c['right']);}return null;}['getPredecessorKey'](_0x391bc2){let _0x5e5570,_0x2c5927=this['root_'],_0x1e24b0=null;for(;!_0x2c5927['isEmpty']();)if(_0x5e5570=this['comparator_'](_0x391bc2,_0x2c5927['key']),_0x5e5570===0x0){if(_0x2c5927['left']['isEmpty']())return _0x1e24b0?_0x1e24b0['key']:null;for(_0x2c5927=_0x2c5927['left'];!_0x2c5927['right']['isEmpty']();)_0x2c5927=_0x2c5927['right'];return _0x2c5927['key'];}else _0x5e5570<0x0?_0x2c5927=_0x2c5927['left']:_0x5e5570>0x0&&(_0x1e24b0=_0x2c5927,_0x2c5927=_0x2c5927['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5da43f){return this['root_']['inorderTraversal'](_0x5da43f);}['reverseTraversal'](_0x6bfd09){return this['root_']['reverseTraversal'](_0x6bfd09);}['getIterator'](_0x1f5f9f){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x1f5f9f);}['getIteratorFrom'](_0x368b34,_0x213e35){return new Zt(this['root_'],_0x368b34,this['comparator_'],!0x1,_0x213e35);}['getReverseIteratorFrom'](_0x3b692d,_0x518de5){return new Zt(this['root_'],_0x3b692d,this['comparator_'],!0x0,_0x518de5);}['getReverseIterator'](_0x4e68fb){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x4e68fb);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x16e55b,_0x2d7486){return He(_0x16e55b['name'],_0x2d7486['name']);}function ji(_0x684ea,_0x1d3b97){return He(_0x684ea,_0x1d3b97);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x5785f8){vi=_0x5785f8;}const Ro=function(_0x52063e){return typeof _0x52063e=='number'?'number:'+so(_0x52063e):'string:'+_0x52063e;},Ao=function(_0x4cd874){if(_0x4cd874['isLeafNode']()){const _0x12fd3f=_0x4cd874['val']();f(typeof _0x12fd3f=='string'||typeof _0x12fd3f=='number'||typeof _0x12fd3f=='object'&&Y(_0x12fd3f,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4cd874===vi||_0x4cd874['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4cd874===vi||_0x4cd874['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x1ef107){er=_0x1ef107;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x127b19,_0x2a0a4e=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x127b19,this['priorityNode_']=_0x2a0a4e,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5a81e9){return new D(this['value_'],_0x5a81e9);}['getImmediateChild'](_0x921a9f){return _0x921a9f==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x2887cf){return v(_0x2887cf)?this:y(_0x2887cf)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4d589e,_0x5a76b1){return null;}['updateImmediateChild'](_0x56a774,_0x52702a){return _0x56a774==='.priority'?this['updatePriority'](_0x52702a):_0x52702a['isEmpty']()&&_0x56a774!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x56a774,_0x52702a)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x591e6f,_0x390a7e){const _0x593656=y(_0x591e6f);return _0x593656===null?_0x390a7e:_0x390a7e['isEmpty']()&&_0x593656!=='.priority'?this:(f(_0x593656!=='.priority'||we(_0x591e6f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x593656,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x591e6f),_0x390a7e)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x476aee,_0x955a4){return!0x1;}['val'](_0x25dfa9){return _0x25dfa9&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x50cd62='';this['priorityNode_']['isEmpty']()||(_0x50cd62+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x59334c=typeof this['value_'];_0x50cd62+=_0x59334c+':',_0x59334c==='number'?_0x50cd62+=so(this['value_']):_0x50cd62+=this['value_'],this['lazyHash_']=no(_0x50cd62);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1b3536){return _0x1b3536===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1b3536 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1b3536['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1b3536));}['compareToLeafNode_'](_0x4a7377){const _0x452abf=typeof _0x4a7377['value_'],_0x2c7b35=typeof this['value_'],_0x126291=D['VALUE_TYPE_ORDER']['indexOf'](_0x452abf),_0x1a6c31=D['VALUE_TYPE_ORDER']['indexOf'](_0x2c7b35);return f(_0x126291>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x452abf),f(_0x1a6c31>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2c7b35),_0x126291===_0x1a6c31?_0x2c7b35==='object'?0x0:this['value_']<_0x4a7377['value_']?-0x1:this['value_']===_0x4a7377['value_']?0x0:0x1:_0x1a6c31-_0x126291;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x147b5c){if(_0x147b5c===this)return!0x0;if(_0x147b5c['isLeafNode']()){const _0x255bca=_0x147b5c;return this['value_']===_0x255bca['value_']&&this['priorityNode_']['equals'](_0x255bca['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x1e2da5){ko=_0x1e2da5;}function xh(_0x3c202a){No=_0x3c202a;}class Fh extends On{['compare'](_0x3c0cb9,_0x12d2f2){const _0x11003d=_0x3c0cb9['node']['getPriority'](),_0x270232=_0x12d2f2['node']['getPriority'](),_0x34958c=_0x11003d['compareTo'](_0x270232);return _0x34958c===0x0?He(_0x3c0cb9['name'],_0x12d2f2['name']):_0x34958c;}['isDefinedOn'](_0x217ee1){return!_0x217ee1['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x598eb7,_0x47ebbf){return!_0x598eb7['getPriority']()['equals'](_0x47ebbf['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x2f08e0,_0x2e325a){const _0x436f49=ko(_0x2f08e0);return new E(_0x2e325a,new D('[PRIORITY-POST]',_0x436f49));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x468153){const _0x5ae504=_0x48b29c=>parseInt(Math['log'](_0x48b29c)/Uh,0xa),_0x5de174=_0x588c29=>parseInt(Array(_0x588c29+0x1)['join']('1'),0x2);this['count']=_0x5ae504(_0x468153+0x1),this['current_']=this['count']-0x1;const _0x280fe6=_0x5de174(this['count']);this['bits_']=_0x468153+0x1&_0x280fe6;}['nextBitIsOne'](){const _0x4e2050=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4e2050;}}const dn=function(_0x1de19c,_0xb4e0b8,_0x19d06e,_0x3f9c4c){_0x1de19c['sort'](_0xb4e0b8);const _0x26ed95=function(_0x37d485,_0x418ec8){const _0x261c80=_0x418ec8-_0x37d485;let _0x662240,_0x4b3941;if(_0x261c80===0x0)return null;if(_0x261c80===0x1)return _0x662240=_0x1de19c[_0x37d485],_0x4b3941=_0x19d06e?_0x19d06e(_0x662240):_0x662240,new M(_0x4b3941,_0x662240['node'],M['BLACK'],null,null);{const _0x1d4bdb=parseInt(_0x261c80/0x2,0xa)+_0x37d485,_0x5b3cc4=_0x26ed95(_0x37d485,_0x1d4bdb),_0x8c2cf1=_0x26ed95(_0x1d4bdb+0x1,_0x418ec8);return _0x662240=_0x1de19c[_0x1d4bdb],_0x4b3941=_0x19d06e?_0x19d06e(_0x662240):_0x662240,new M(_0x4b3941,_0x662240['node'],M['BLACK'],_0x5b3cc4,_0x8c2cf1);}},_0xaf21bc=function(_0xef9d62){let _0x49ab70=null,_0x4dce5e=null,_0x5b0bcf=_0x1de19c['length'];const _0x154418=function(_0x1f2e97,_0x20fa54){const _0xc8760e=_0x5b0bcf-_0x1f2e97,_0x3d0b1b=_0x5b0bcf;_0x5b0bcf-=_0x1f2e97;const _0xba4a=_0x26ed95(_0xc8760e+0x1,_0x3d0b1b),_0x4a530c=_0x1de19c[_0xc8760e],_0x378e18=_0x19d06e?_0x19d06e(_0x4a530c):_0x4a530c;_0x59c4f5(new M(_0x378e18,_0x4a530c['node'],_0x20fa54,null,_0xba4a));},_0x59c4f5=function(_0x2d1a9d){_0x49ab70?(_0x49ab70['left']=_0x2d1a9d,_0x49ab70=_0x2d1a9d):(_0x4dce5e=_0x2d1a9d,_0x49ab70=_0x2d1a9d);};for(let _0x2e4a73=0x0;_0x2e4a73<_0xef9d62['count'];++_0x2e4a73){const _0x41cb9f=_0xef9d62['nextBitIsOne'](),_0x353003=Math['pow'](0x2,_0xef9d62['count']-(_0x2e4a73+0x1));_0x41cb9f?_0x154418(_0x353003,M['BLACK']):(_0x154418(_0x353003,M['BLACK']),_0x154418(_0x353003,M['RED']));}return _0x4dce5e;},_0x125cbf=new Wh(_0x1de19c['length']),_0x58219f=_0xaf21bc(_0x125cbf);return new B(_0x3f9c4c||_0xb4e0b8,_0x58219f);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x18628e,_0x33091a){this['indexes_']=_0x18628e,this['indexSet_']=_0x33091a;}['get'](_0x1f2866){const _0x20f18d=Oe(this['indexes_'],_0x1f2866);if(!_0x20f18d)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1f2866);return _0x20f18d instanceof B?_0x20f18d:null;}['hasIndex'](_0x1d8b9d){return Y(this['indexSet_'],_0x1d8b9d['toString']());}['addIndex'](_0x28e769,_0x1d5e9a){f(_0x28e769!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x390a64=[];let _0x459d6b=!0x1;const _0x58a6d9=_0x1d5e9a['getIterator'](E['Wrap']);let _0x54ac2f=_0x58a6d9['getNext']();for(;_0x54ac2f;)_0x459d6b=_0x459d6b||_0x28e769['isDefinedOn'](_0x54ac2f['node']),_0x390a64['push'](_0x54ac2f),_0x54ac2f=_0x58a6d9['getNext']();let _0x5a4289;_0x459d6b?_0x5a4289=dn(_0x390a64,_0x28e769['getCompare']()):_0x5a4289=je;const _0x20aa2c=_0x28e769['toString'](),_0x374def={...this['indexSet_']};_0x374def[_0x20aa2c]=_0x28e769;const _0x53f208={...this['indexes_']};return _0x53f208[_0x20aa2c]=_0x5a4289,new ee(_0x53f208,_0x374def);}['addToIndexes'](_0x3352fb,_0x50e755){const _0x4fb268=ln(this['indexes_'],(_0x3049b6,_0x4a1589)=>{const _0x1dd602=Oe(this['indexSet_'],_0x4a1589);if(f(_0x1dd602,'Missing\x20index\x20implementation\x20for\x20'+_0x4a1589),_0x3049b6===je){if(_0x1dd602['isDefinedOn'](_0x3352fb['node'])){const _0x22561d=[],_0x41d2d7=_0x50e755['getIterator'](E['Wrap']);let _0x26aaf2=_0x41d2d7['getNext']();for(;_0x26aaf2;)_0x26aaf2['name']!==_0x3352fb['name']&&_0x22561d['push'](_0x26aaf2),_0x26aaf2=_0x41d2d7['getNext']();return _0x22561d['push'](_0x3352fb),dn(_0x22561d,_0x1dd602['getCompare']());}else return je;}else{const _0x58002b=_0x50e755['get'](_0x3352fb['name']);let _0x1b753c=_0x3049b6;return _0x58002b&&(_0x1b753c=_0x1b753c['remove'](new E(_0x3352fb['name'],_0x58002b))),_0x1b753c['insert'](_0x3352fb,_0x3352fb['node']);}});return new ee(_0x4fb268,this['indexSet_']);}['removeFromIndexes'](_0x155e33,_0x2958a2){const _0xb346bf=ln(this['indexes_'],_0x585bff=>{if(_0x585bff===je)return _0x585bff;{const _0x50cfea=_0x2958a2['get'](_0x155e33['name']);return _0x50cfea?_0x585bff['remove'](new E(_0x155e33['name'],_0x50cfea)):_0x585bff;}});return new ee(_0xb346bf,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x22df86,_0x352a88,_0x51745d){this['children_']=_0x22df86,this['priorityNode_']=_0x352a88,this['indexMap_']=_0x51745d,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x742d9e){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x742d9e,this['indexMap_']);}['getImmediateChild'](_0x4fbfa2){if(_0x4fbfa2==='.priority')return this['getPriority']();{const _0x3fc4c0=this['children_']['get'](_0x4fbfa2);return _0x3fc4c0===null?gt:_0x3fc4c0;}}['getChild'](_0x323052){const _0x16938e=y(_0x323052);return _0x16938e===null?this:this['getImmediateChild'](_0x16938e)['getChild'](b(_0x323052));}['hasChild'](_0x3ec152){return this['children_']['get'](_0x3ec152)!==null;}['updateImmediateChild'](_0x1f075f,_0x4747dc){if(f(_0x4747dc,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1f075f==='.priority')return this['updatePriority'](_0x4747dc);{const _0x547dc9=new E(_0x1f075f,_0x4747dc);let _0x259c81,_0x46e933;_0x4747dc['isEmpty']()?(_0x259c81=this['children_']['remove'](_0x1f075f),_0x46e933=this['indexMap_']['removeFromIndexes'](_0x547dc9,this['children_'])):(_0x259c81=this['children_']['insert'](_0x1f075f,_0x4747dc),_0x46e933=this['indexMap_']['addToIndexes'](_0x547dc9,this['children_']));const _0x56fae6=_0x259c81['isEmpty']()?gt:this['priorityNode_'];return new g(_0x259c81,_0x56fae6,_0x46e933);}}['updateChild'](_0x1aae3f,_0x463bf9){const _0xd1f4ec=y(_0x1aae3f);if(_0xd1f4ec===null)return _0x463bf9;{f(y(_0x1aae3f)!=='.priority'||we(_0x1aae3f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2a30bf=this['getImmediateChild'](_0xd1f4ec)['updateChild'](b(_0x1aae3f),_0x463bf9);return this['updateImmediateChild'](_0xd1f4ec,_0x2a30bf);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2c98bf){if(this['isEmpty']())return null;const _0x1cd539={};let _0x32b096=0x0,_0x2985ee=0x0,_0x41f05f=!0x0;if(this['forEachChild'](R,(_0x10144c,_0x47c38c)=>{_0x1cd539[_0x10144c]=_0x47c38c['val'](_0x2c98bf),_0x32b096++,_0x41f05f&&g['INTEGER_REGEXP_']['test'](_0x10144c)?_0x2985ee=Math['max'](_0x2985ee,Number(_0x10144c)):_0x41f05f=!0x1;}),!_0x2c98bf&&_0x41f05f&&_0x2985ee<0x2*_0x32b096){const _0xee1a29=[];for(const _0x2a7fbf in _0x1cd539)_0xee1a29[_0x2a7fbf]=_0x1cd539[_0x2a7fbf];return _0xee1a29;}else return _0x2c98bf&&!this['getPriority']()['isEmpty']()&&(_0x1cd539['.priority']=this['getPriority']()['val']()),_0x1cd539;}['hash'](){if(this['lazyHash_']===null){let _0x29d395='';this['getPriority']()['isEmpty']()||(_0x29d395+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x45465a,_0x28c855)=>{const _0x54be82=_0x28c855['hash']();_0x54be82!==''&&(_0x29d395+=':'+_0x45465a+':'+_0x54be82);}),this['lazyHash_']=_0x29d395===''?'':no(_0x29d395);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1e3de6,_0x526443,_0x51a966){const _0x6bcda3=this['resolveIndex_'](_0x51a966);if(_0x6bcda3){const _0x23a069=_0x6bcda3['getPredecessorKey'](new E(_0x1e3de6,_0x526443));return _0x23a069?_0x23a069['name']:null;}else return this['children_']['getPredecessorKey'](_0x1e3de6);}['getFirstChildName'](_0x4f47a0){const _0x17b104=this['resolveIndex_'](_0x4f47a0);if(_0x17b104){const _0x1ceeed=_0x17b104['minKey']();return _0x1ceeed&&_0x1ceeed['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x5e2bed){const _0x37bb08=this['getFirstChildName'](_0x5e2bed);return _0x37bb08?new E(_0x37bb08,this['children_']['get'](_0x37bb08)):null;}['getLastChildName'](_0x17e08c){const _0x436358=this['resolveIndex_'](_0x17e08c);if(_0x436358){const _0x1f7c21=_0x436358['maxKey']();return _0x1f7c21&&_0x1f7c21['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1da95b){const _0x1e717b=this['getLastChildName'](_0x1da95b);return _0x1e717b?new E(_0x1e717b,this['children_']['get'](_0x1e717b)):null;}['forEachChild'](_0x47c8f7,_0x210035){const _0x2bf5e1=this['resolveIndex_'](_0x47c8f7);return _0x2bf5e1?_0x2bf5e1['inorderTraversal'](_0x59262d=>_0x210035(_0x59262d['name'],_0x59262d['node'])):this['children_']['inorderTraversal'](_0x210035);}['getIterator'](_0x16d651){return this['getIteratorFrom'](_0x16d651['minPost'](),_0x16d651);}['getIteratorFrom'](_0x5de976,_0x184dd6){const _0x544ba2=this['resolveIndex_'](_0x184dd6);if(_0x544ba2)return _0x544ba2['getIteratorFrom'](_0x5de976,_0x3fe751=>_0x3fe751);{const _0x5560d9=this['children_']['getIteratorFrom'](_0x5de976['name'],E['Wrap']);let _0xf4caef=_0x5560d9['peek']();for(;_0xf4caef!=null&&_0x184dd6['compare'](_0xf4caef,_0x5de976)<0x0;)_0x5560d9['getNext'](),_0xf4caef=_0x5560d9['peek']();return _0x5560d9;}}['getReverseIterator'](_0x2dd7d1){return this['getReverseIteratorFrom'](_0x2dd7d1['maxPost'](),_0x2dd7d1);}['getReverseIteratorFrom'](_0x3b8cc2,_0x2e2ed3){const _0x3ebb06=this['resolveIndex_'](_0x2e2ed3);if(_0x3ebb06)return _0x3ebb06['getReverseIteratorFrom'](_0x3b8cc2,_0x2d665a=>_0x2d665a);{const _0x595c9f=this['children_']['getReverseIteratorFrom'](_0x3b8cc2['name'],E['Wrap']);let _0x26369f=_0x595c9f['peek']();for(;_0x26369f!=null&&_0x2e2ed3['compare'](_0x26369f,_0x3b8cc2)>0x0;)_0x595c9f['getNext'](),_0x26369f=_0x595c9f['peek']();return _0x595c9f;}}['compareTo'](_0x32d66b){return this['isEmpty']()?_0x32d66b['isEmpty']()?0x0:-0x1:_0x32d66b['isLeafNode']()||_0x32d66b['isEmpty']()?0x1:_0x32d66b===Ht?-0x1:0x0;}['withIndex'](_0x4017b1){if(_0x4017b1===ye||this['indexMap_']['hasIndex'](_0x4017b1))return this;{const _0x14a708=this['indexMap_']['addIndex'](_0x4017b1,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x14a708);}}['isIndexed'](_0x58987b){return _0x58987b===ye||this['indexMap_']['hasIndex'](_0x58987b);}['equals'](_0x496641){if(_0x496641===this)return!0x0;if(_0x496641['isLeafNode']())return!0x1;{const _0x3b2fb8=_0x496641;if(this['getPriority']()['equals'](_0x3b2fb8['getPriority']())){if(this['children_']['count']()===_0x3b2fb8['children_']['count']()){const _0xac50c3=this['getIterator'](R),_0x270a0c=_0x3b2fb8['getIterator'](R);let _0x34b349=_0xac50c3['getNext'](),_0x57f165=_0x270a0c['getNext']();for(;_0x34b349&&_0x57f165;){if(_0x34b349['name']!==_0x57f165['name']||!_0x34b349['node']['equals'](_0x57f165['node']))return!0x1;_0x34b349=_0xac50c3['getNext'](),_0x57f165=_0x270a0c['getNext']();}return _0x34b349===null&&_0x57f165===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x1c9804){return _0x1c9804===ye?null:this['indexMap_']['get'](_0x1c9804['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x25e952){return _0x25e952===this?0x0:0x1;}['equals'](_0x4b07f7){return _0x4b07f7===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4be66f){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x3e70b8,_0x3b6287=null){if(_0x3e70b8===null)return g['EMPTY_NODE'];if(typeof _0x3e70b8=='object'&&'.priority'in _0x3e70b8&&(_0x3b6287=_0x3e70b8['.priority']),f(_0x3b6287===null||typeof _0x3b6287=='string'||typeof _0x3b6287=='number'||typeof _0x3b6287=='object'&&'.sv'in _0x3b6287,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3b6287),typeof _0x3e70b8=='object'&&'.value'in _0x3e70b8&&_0x3e70b8['.value']!==null&&(_0x3e70b8=_0x3e70b8['.value']),typeof _0x3e70b8!='object'||'.sv'in _0x3e70b8){const _0x41b1c3=_0x3e70b8;return new D(_0x41b1c3,N(_0x3b6287));}if(!(_0x3e70b8 instanceof Array)&&Vh){const _0x14748a=[];let _0x23c7e8=!0x1;if(x(_0x3e70b8,(_0x2f30f1,_0x1af60d)=>{if(_0x2f30f1['substring'](0x0,0x1)!=='.'){const _0x2bcd01=N(_0x1af60d);_0x2bcd01['isEmpty']()||(_0x23c7e8=_0x23c7e8||!_0x2bcd01['getPriority']()['isEmpty'](),_0x14748a['push'](new E(_0x2f30f1,_0x2bcd01)));}}),_0x14748a['length']===0x0)return g['EMPTY_NODE'];const _0x5a11cb=dn(_0x14748a,Dh,_0x260c02=>_0x260c02['name'],ji);if(_0x23c7e8){const _0x54ceb8=dn(_0x14748a,R['getCompare']());return new g(_0x5a11cb,N(_0x3b6287),new ee({'.priority':_0x54ceb8},{'.priority':R}));}else return new g(_0x5a11cb,N(_0x3b6287),ee['Default']);}else{let _0x3a3237=g['EMPTY_NODE'];return x(_0x3e70b8,(_0x45e3e3,_0x1e4631)=>{if(Y(_0x3e70b8,_0x45e3e3)&&_0x45e3e3['substring'](0x0,0x1)!=='.'){const _0x111774=N(_0x1e4631);(_0x111774['isLeafNode']()||!_0x111774['isEmpty']())&&(_0x3a3237=_0x3a3237['updateImmediateChild'](_0x45e3e3,_0x111774));}}),_0x3a3237['updatePriority'](N(_0x3b6287));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x507e11){super(),this['indexPath_']=_0x507e11,f(!v(_0x507e11)&&y(_0x507e11)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x37b317){return _0x37b317['getChild'](this['indexPath_']);}['isDefinedOn'](_0x34dab4){return!_0x34dab4['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4e6298,_0x1e31bb){const _0x19fa58=this['extractChild'](_0x4e6298['node']),_0x2c24e5=this['extractChild'](_0x1e31bb['node']),_0x34558c=_0x19fa58['compareTo'](_0x2c24e5);return _0x34558c===0x0?He(_0x4e6298['name'],_0x1e31bb['name']):_0x34558c;}['makePost'](_0x53aedb,_0x294f43){const _0x50a15d=N(_0x53aedb),_0x50d328=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x50a15d);return new E(_0x294f43,_0x50d328);}['maxPost'](){const _0x4d6911=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x4d6911);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x1ee1f5,_0x25ca23){const _0x27a788=_0x1ee1f5['node']['compareTo'](_0x25ca23['node']);return _0x27a788===0x0?He(_0x1ee1f5['name'],_0x25ca23['name']):_0x27a788;}['isDefinedOn'](_0x3a36a6){return!0x0;}['indexedValueChanged'](_0x1b391d,_0x437442){return!_0x1b391d['equals'](_0x437442);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5413c0,_0x24790c){const _0x200fe6=N(_0x5413c0);return new E(_0x24790c,_0x200fe6);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x524af5){return{'type':'value','snapshotNode':_0x524af5};}function tt(_0x318a41,_0x10a3ad){return{'type':'child_added','snapshotNode':_0x10a3ad,'childName':_0x318a41};}function Nt(_0x20376b,_0x1acc46){return{'type':'child_removed','snapshotNode':_0x1acc46,'childName':_0x20376b};}function Pt(_0x237970,_0x5c9785,_0x431537){return{'type':'child_changed','snapshotNode':_0x5c9785,'childName':_0x237970,'oldSnap':_0x431537};}function $h(_0x4bfa86,_0xf45a3c){return{'type':'child_moved','snapshotNode':_0xf45a3c,'childName':_0x4bfa86};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x32db60){this['index_']=_0x32db60;}['updateChild'](_0x4ccc69,_0x38a04e,_0x4f33c0,_0x3ccf29,_0x349ce9,_0x571df2){f(_0x4ccc69['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x40a84b=_0x4ccc69['getImmediateChild'](_0x38a04e);return _0x40a84b['getChild'](_0x3ccf29)['equals'](_0x4f33c0['getChild'](_0x3ccf29))&&_0x40a84b['isEmpty']()===_0x4f33c0['isEmpty']()||(_0x571df2!=null&&(_0x4f33c0['isEmpty']()?_0x4ccc69['hasChild'](_0x38a04e)?_0x571df2['trackChildChange'](Nt(_0x38a04e,_0x40a84b)):f(_0x4ccc69['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x40a84b['isEmpty']()?_0x571df2['trackChildChange'](tt(_0x38a04e,_0x4f33c0)):_0x571df2['trackChildChange'](Pt(_0x38a04e,_0x4f33c0,_0x40a84b))),_0x4ccc69['isLeafNode']()&&_0x4f33c0['isEmpty']())?_0x4ccc69:_0x4ccc69['updateImmediateChild'](_0x38a04e,_0x4f33c0)['withIndex'](this['index_']);}['updateFullNode'](_0x49ef7d,_0xa1db77,_0x235257){return _0x235257!=null&&(_0x49ef7d['isLeafNode']()||_0x49ef7d['forEachChild'](R,(_0x284fcd,_0x2106a1)=>{_0xa1db77['hasChild'](_0x284fcd)||_0x235257['trackChildChange'](Nt(_0x284fcd,_0x2106a1));}),_0xa1db77['isLeafNode']()||_0xa1db77['forEachChild'](R,(_0x41fa9e,_0x2c8a36)=>{if(_0x49ef7d['hasChild'](_0x41fa9e)){const _0x5ea4c9=_0x49ef7d['getImmediateChild'](_0x41fa9e);_0x5ea4c9['equals'](_0x2c8a36)||_0x235257['trackChildChange'](Pt(_0x41fa9e,_0x2c8a36,_0x5ea4c9));}else _0x235257['trackChildChange'](tt(_0x41fa9e,_0x2c8a36));})),_0xa1db77['withIndex'](this['index_']);}['updatePriority'](_0x89b512,_0xa7d1a9){return _0x89b512['isEmpty']()?g['EMPTY_NODE']:_0x89b512['updatePriority'](_0xa7d1a9);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x604b54){this['indexedFilter_']=new Yi(_0x604b54['getIndex']()),this['index_']=_0x604b54['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x604b54),this['endPost_']=Ot['getEndPost_'](_0x604b54),this['startIsInclusive_']=!_0x604b54['startAfterSet_'],this['endIsInclusive_']=!_0x604b54['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x482e6f){const _0x3257ea=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x482e6f)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x482e6f)<0x0,_0x12ae40=this['endIsInclusive_']?this['index_']['compare'](_0x482e6f,this['getEndPost']())<=0x0:this['index_']['compare'](_0x482e6f,this['getEndPost']())<0x0;return _0x3257ea&&_0x12ae40;}['updateChild'](_0x2eae84,_0x482382,_0x3c3b68,_0x328161,_0x4db419,_0x50f97b){return this['matches'](new E(_0x482382,_0x3c3b68))||(_0x3c3b68=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2eae84,_0x482382,_0x3c3b68,_0x328161,_0x4db419,_0x50f97b);}['updateFullNode'](_0x1e04b0,_0x569112,_0x1fa5ec){_0x569112['isLeafNode']()&&(_0x569112=g['EMPTY_NODE']);let _0x3b85aa=_0x569112['withIndex'](this['index_']);_0x3b85aa=_0x3b85aa['updatePriority'](g['EMPTY_NODE']);const _0x13091b=this;return _0x569112['forEachChild'](R,(_0x550490,_0x269813)=>{_0x13091b['matches'](new E(_0x550490,_0x269813))||(_0x3b85aa=_0x3b85aa['updateImmediateChild'](_0x550490,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1e04b0,_0x3b85aa,_0x1fa5ec);}['updatePriority'](_0x306301,_0x566667){return _0x306301;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x386a2d){if(_0x386a2d['hasStart']()){const _0x34958e=_0x386a2d['getIndexStartName']();return _0x386a2d['getIndex']()['makePost'](_0x386a2d['getIndexStartValue'](),_0x34958e);}else return _0x386a2d['getIndex']()['minPost']();}static['getEndPost_'](_0xb181ce){if(_0xb181ce['hasEnd']()){const _0x9dbc5b=_0xb181ce['getIndexEndName']();return _0xb181ce['getIndex']()['makePost'](_0xb181ce['getIndexEndValue'](),_0x9dbc5b);}else return _0xb181ce['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0xd1ae4e){this['withinDirectionalStart']=_0x5bc585=>this['reverse_']?this['withinEndPost'](_0x5bc585):this['withinStartPost'](_0x5bc585),this['withinDirectionalEnd']=_0x6f03e4=>this['reverse_']?this['withinStartPost'](_0x6f03e4):this['withinEndPost'](_0x6f03e4),this['withinStartPost']=_0x220217=>{const _0x143722=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x220217);return this['startIsInclusive_']?_0x143722<=0x0:_0x143722<0x0;},this['withinEndPost']=_0xbac2d8=>{const _0x1b8abb=this['index_']['compare'](_0xbac2d8,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1b8abb<=0x0:_0x1b8abb<0x0;},this['rangedFilter_']=new Ot(_0xd1ae4e),this['index_']=_0xd1ae4e['getIndex'](),this['limit_']=_0xd1ae4e['getLimit'](),this['reverse_']=!_0xd1ae4e['isViewFromLeft'](),this['startIsInclusive_']=!_0xd1ae4e['startAfterSet_'],this['endIsInclusive_']=!_0xd1ae4e['endBeforeSet_'];}['updateChild'](_0x2243fe,_0x3a422b,_0x56e131,_0x4664de,_0x23da3c,_0x2622b6){return this['rangedFilter_']['matches'](new E(_0x3a422b,_0x56e131))||(_0x56e131=g['EMPTY_NODE']),_0x2243fe['getImmediateChild'](_0x3a422b)['equals'](_0x56e131)?_0x2243fe:_0x2243fe['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2243fe,_0x3a422b,_0x56e131,_0x4664de,_0x23da3c,_0x2622b6):this['fullLimitUpdateChild_'](_0x2243fe,_0x3a422b,_0x56e131,_0x23da3c,_0x2622b6);}['updateFullNode'](_0x44c2a8,_0x2ad91b,_0x105a90){let _0x4009ab;if(_0x2ad91b['isLeafNode']()||_0x2ad91b['isEmpty']())_0x4009ab=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2ad91b['numChildren']()&&_0x2ad91b['isIndexed'](this['index_'])){_0x4009ab=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4a31c6;this['reverse_']?_0x4a31c6=_0x2ad91b['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4a31c6=_0x2ad91b['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x45a459=0x0;for(;_0x4a31c6['hasNext']()&&_0x45a459<this['limit_'];){const _0x17f7d7=_0x4a31c6['getNext']();if(this['withinDirectionalStart'](_0x17f7d7)){if(this['withinDirectionalEnd'](_0x17f7d7))_0x4009ab=_0x4009ab['updateImmediateChild'](_0x17f7d7['name'],_0x17f7d7['node']),_0x45a459++;else break;}else continue;}}else{_0x4009ab=_0x2ad91b['withIndex'](this['index_']),_0x4009ab=_0x4009ab['updatePriority'](g['EMPTY_NODE']);let _0x4b4258;this['reverse_']?_0x4b4258=_0x4009ab['getReverseIterator'](this['index_']):_0x4b4258=_0x4009ab['getIterator'](this['index_']);let _0x28fd5c=0x0;for(;_0x4b4258['hasNext']();){const _0x1fca72=_0x4b4258['getNext']();_0x28fd5c<this['limit_']&&this['withinDirectionalStart'](_0x1fca72)&&this['withinDirectionalEnd'](_0x1fca72)?_0x28fd5c++:_0x4009ab=_0x4009ab['updateImmediateChild'](_0x1fca72['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x44c2a8,_0x4009ab,_0x105a90);}['updatePriority'](_0x131dc0,_0x50db02){return _0x131dc0;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x28c7b7,_0x25543d,_0x4736ca,_0x3f4de7,_0x4e2e82){let _0x329361;if(this['reverse_']){const _0x321355=this['index_']['getCompare']();_0x329361=(_0x3cbc06,_0x253ff7)=>_0x321355(_0x253ff7,_0x3cbc06);}else _0x329361=this['index_']['getCompare']();const _0x56bf41=_0x28c7b7;f(_0x56bf41['numChildren']()===this['limit_'],'');const _0x190567=new E(_0x25543d,_0x4736ca),_0x5bb55e=this['reverse_']?_0x56bf41['getFirstChild'](this['index_']):_0x56bf41['getLastChild'](this['index_']),_0x8d429c=this['rangedFilter_']['matches'](_0x190567);if(_0x56bf41['hasChild'](_0x25543d)){const _0x552a0d=_0x56bf41['getImmediateChild'](_0x25543d);let _0x4dd286=_0x3f4de7['getChildAfterChild'](this['index_'],_0x5bb55e,this['reverse_']);for(;_0x4dd286!=null&&(_0x4dd286['name']===_0x25543d||_0x56bf41['hasChild'](_0x4dd286['name']));)_0x4dd286=_0x3f4de7['getChildAfterChild'](this['index_'],_0x4dd286,this['reverse_']);const _0x3e4e30=_0x4dd286==null?0x1:_0x329361(_0x4dd286,_0x190567);if(_0x8d429c&&!_0x4736ca['isEmpty']()&&_0x3e4e30>=0x0)return _0x4e2e82!=null&&_0x4e2e82['trackChildChange'](Pt(_0x25543d,_0x4736ca,_0x552a0d)),_0x56bf41['updateImmediateChild'](_0x25543d,_0x4736ca);{_0x4e2e82!=null&&_0x4e2e82['trackChildChange'](Nt(_0x25543d,_0x552a0d));const _0x39ee80=_0x56bf41['updateImmediateChild'](_0x25543d,g['EMPTY_NODE']);return _0x4dd286!=null&&this['rangedFilter_']['matches'](_0x4dd286)?(_0x4e2e82!=null&&_0x4e2e82['trackChildChange'](tt(_0x4dd286['name'],_0x4dd286['node'])),_0x39ee80['updateImmediateChild'](_0x4dd286['name'],_0x4dd286['node'])):_0x39ee80;}}else return _0x4736ca['isEmpty']()?_0x28c7b7:_0x8d429c&&_0x329361(_0x5bb55e,_0x190567)>=0x0?(_0x4e2e82!=null&&(_0x4e2e82['trackChildChange'](Nt(_0x5bb55e['name'],_0x5bb55e['node'])),_0x4e2e82['trackChildChange'](tt(_0x25543d,_0x4736ca))),_0x56bf41['updateImmediateChild'](_0x25543d,_0x4736ca)['updateImmediateChild'](_0x5bb55e['name'],g['EMPTY_NODE'])):_0x28c7b7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4448f6=new Qi();return _0x4448f6['limitSet_']=this['limitSet_'],_0x4448f6['limit_']=this['limit_'],_0x4448f6['startSet_']=this['startSet_'],_0x4448f6['startAfterSet_']=this['startAfterSet_'],_0x4448f6['indexStartValue_']=this['indexStartValue_'],_0x4448f6['startNameSet_']=this['startNameSet_'],_0x4448f6['indexStartName_']=this['indexStartName_'],_0x4448f6['endSet_']=this['endSet_'],_0x4448f6['endBeforeSet_']=this['endBeforeSet_'],_0x4448f6['indexEndValue_']=this['indexEndValue_'],_0x4448f6['endNameSet_']=this['endNameSet_'],_0x4448f6['indexEndName_']=this['indexEndName_'],_0x4448f6['index_']=this['index_'],_0x4448f6['viewFrom_']=this['viewFrom_'],_0x4448f6;}}function qh(_0xc31503){return _0xc31503['loadsAllData']()?new Yi(_0xc31503['getIndex']()):_0xc31503['hasLimit']()?new Gh(_0xc31503):new Ot(_0xc31503);}function zh(_0x4acf0d,_0x2f42ee){const _0x1bd9ab=_0x4acf0d['copy']();return _0x1bd9ab['limitSet_']=!0x0,_0x1bd9ab['limit_']=_0x2f42ee,_0x1bd9ab['viewFrom_']='l',_0x1bd9ab;}function jh(_0x24a930,_0x4f8a6e,_0x1f3b5e){const _0xd7c0ad=_0x24a930['copy']();return _0xd7c0ad['startSet_']=!0x0,_0x4f8a6e===void 0x0&&(_0x4f8a6e=null),_0xd7c0ad['indexStartValue_']=_0x4f8a6e,_0x1f3b5e!=null?(_0xd7c0ad['startNameSet_']=!0x0,_0xd7c0ad['indexStartName_']=_0x1f3b5e):(_0xd7c0ad['startNameSet_']=!0x1,_0xd7c0ad['indexStartName_']=''),_0xd7c0ad;}function Kh(_0x220216,_0x518d4e,_0x2826ea){const _0xf22bfb=_0x220216['copy']();return _0xf22bfb['endSet_']=!0x0,_0x518d4e===void 0x0&&(_0x518d4e=null),_0xf22bfb['indexEndValue_']=_0x518d4e,_0x2826ea!==void 0x0?(_0xf22bfb['endNameSet_']=!0x0,_0xf22bfb['indexEndName_']=_0x2826ea):(_0xf22bfb['endNameSet_']=!0x1,_0xf22bfb['indexEndName_']=''),_0xf22bfb;}function Do(_0x402088,_0x530f47){const _0x3b1b67=_0x402088['copy']();return _0x3b1b67['index_']=_0x530f47,_0x3b1b67;}function tr(_0x4da4de){const _0x1bdd7f={};if(_0x4da4de['isDefault']())return _0x1bdd7f;let _0x212625;if(_0x4da4de['index_']===R?_0x212625='$priority':_0x4da4de['index_']===Po?_0x212625='$value':_0x4da4de['index_']===ye?_0x212625='$key':(f(_0x4da4de['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x212625=_0x4da4de['index_']['toString']()),_0x1bdd7f['orderBy']=O(_0x212625),_0x4da4de['startSet_']){const _0x1b6f09=_0x4da4de['startAfterSet_']?'startAfter':'startAt';_0x1bdd7f[_0x1b6f09]=O(_0x4da4de['indexStartValue_']),_0x4da4de['startNameSet_']&&(_0x1bdd7f[_0x1b6f09]+=','+O(_0x4da4de['indexStartName_']));}if(_0x4da4de['endSet_']){const _0x352ede=_0x4da4de['endBeforeSet_']?'endBefore':'endAt';_0x1bdd7f[_0x352ede]=O(_0x4da4de['indexEndValue_']),_0x4da4de['endNameSet_']&&(_0x1bdd7f[_0x352ede]+=','+O(_0x4da4de['indexEndName_']));}return _0x4da4de['limitSet_']&&(_0x4da4de['isViewFromLeft']()?_0x1bdd7f['limitToFirst']=_0x4da4de['limit_']:_0x1bdd7f['limitToLast']=_0x4da4de['limit_']),_0x1bdd7f;}function nr(_0x19efbb){const _0x47e78c={};if(_0x19efbb['startSet_']&&(_0x47e78c['sp']=_0x19efbb['indexStartValue_'],_0x19efbb['startNameSet_']&&(_0x47e78c['sn']=_0x19efbb['indexStartName_']),_0x47e78c['sin']=!_0x19efbb['startAfterSet_']),_0x19efbb['endSet_']&&(_0x47e78c['ep']=_0x19efbb['indexEndValue_'],_0x19efbb['endNameSet_']&&(_0x47e78c['en']=_0x19efbb['indexEndName_']),_0x47e78c['ein']=!_0x19efbb['endBeforeSet_']),_0x19efbb['limitSet_']){_0x47e78c['l']=_0x19efbb['limit_'];let _0x504740=_0x19efbb['viewFrom_'];_0x504740===''&&(_0x19efbb['isViewFromLeft']()?_0x504740='l':_0x504740='r'),_0x47e78c['vf']=_0x504740;}return _0x19efbb['index_']!==R&&(_0x47e78c['i']=_0x19efbb['index_']['toString']()),_0x47e78c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x2a7a1f){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5d1e0d,_0x19536e){return _0x19536e!==void 0x0?'tag$'+_0x19536e:(f(_0x5d1e0d['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5d1e0d['_path']['toString']());}constructor(_0x1051ee,_0x12e684,_0x2cb6c2,_0x5c5546){super(),this['repoInfo_']=_0x1051ee,this['onDataUpdate_']=_0x12e684,this['authTokenProvider_']=_0x2cb6c2,this['appCheckTokenProvider_']=_0x5c5546,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x663b21,_0x5625ad,_0x2705dc,_0x367b4a){const _0x5b86e1=_0x663b21['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5b86e1+'\x20'+_0x663b21['_queryIdentifier']);const _0x1dbe19=fn['getListenId_'](_0x663b21,_0x2705dc),_0x4269e7={};this['listens_'][_0x1dbe19]=_0x4269e7;const _0x105785=tr(_0x663b21['_queryParams']);this['restRequest_'](_0x5b86e1+'.json',_0x105785,(_0x2a37d8,_0x1cceae)=>{let _0x673b0d=_0x1cceae;if(_0x2a37d8===0x194&&(_0x673b0d=null,_0x2a37d8=null),_0x2a37d8===null&&this['onDataUpdate_'](_0x5b86e1,_0x673b0d,!0x1,_0x2705dc),Oe(this['listens_'],_0x1dbe19)===_0x4269e7){let _0xf95a2e;_0x2a37d8?_0x2a37d8===0x191?_0xf95a2e='permission_denied':_0xf95a2e='rest_error:'+_0x2a37d8:_0xf95a2e='ok',_0x367b4a(_0xf95a2e,null);}});}['unlisten'](_0x4e08c5,_0x5c48a8){const _0x1e77d4=fn['getListenId_'](_0x4e08c5,_0x5c48a8);delete this['listens_'][_0x1e77d4];}['get'](_0x270b32){const _0x262fa8=tr(_0x270b32['_queryParams']),_0x7dc093=_0x270b32['_path']['toString'](),_0x10abc1=new Ve();return this['restRequest_'](_0x7dc093+'.json',_0x262fa8,(_0x4a1d9b,_0x5f3072)=>{let _0x39d1bf=_0x5f3072;_0x4a1d9b===0x194&&(_0x39d1bf=null,_0x4a1d9b=null),_0x4a1d9b===null?(this['onDataUpdate_'](_0x7dc093,_0x39d1bf,!0x1,null),_0x10abc1['resolve'](_0x39d1bf)):_0x10abc1['reject'](new Error(_0x39d1bf));}),_0x10abc1['promise'];}['refreshAuthToken'](_0x201a60){}['restRequest_'](_0x59b123,_0x3ae2bd={},_0x2f41b6){return _0x3ae2bd['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3c7a2c,_0x261f34])=>{_0x3c7a2c&&_0x3c7a2c['accessToken']&&(_0x3ae2bd['auth']=_0x3c7a2c['accessToken']),_0x261f34&&_0x261f34['token']&&(_0x3ae2bd['ac']=_0x261f34['token']);const _0xa8eea5=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x59b123+'?ns='+this['repoInfo_']['namespace']+at(_0x3ae2bd);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xa8eea5);const _0x24b7e8=new XMLHttpRequest();_0x24b7e8['onreadystatechange']=()=>{if(_0x2f41b6&&_0x24b7e8['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xa8eea5+'\x20received.\x20status:',_0x24b7e8['status'],'response:',_0x24b7e8['responseText']);let _0xc7f09b=null;if(_0x24b7e8['status']>=0xc8&&_0x24b7e8['status']<0x12c){try{_0xc7f09b=bt(_0x24b7e8['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xa8eea5+':\x20'+_0x24b7e8['responseText']);}_0x2f41b6(null,_0xc7f09b);}else _0x24b7e8['status']!==0x191&&_0x24b7e8['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xa8eea5+'\x20Status:\x20'+_0x24b7e8['status']),_0x2f41b6(_0x24b7e8['status']);_0x2f41b6=null;}},_0x24b7e8['open']('GET',_0xa8eea5,!0x0),_0x24b7e8['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3ae3f7){return this['rootNode_']['getChild'](_0x3ae3f7);}['updateSnapshot'](_0x565be0,_0x5dd474){this['rootNode_']=this['rootNode_']['updateChild'](_0x565be0,_0x5dd474);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0xd0159c,_0x5079db,_0x16a220){if(v(_0x5079db))_0xd0159c['value']=_0x16a220,_0xd0159c['children']['clear']();else{if(_0xd0159c['value']!==null)_0xd0159c['value']=_0xd0159c['value']['updateChild'](_0x5079db,_0x16a220);else{const _0x37ce6d=y(_0x5079db);_0xd0159c['children']['has'](_0x37ce6d)||_0xd0159c['children']['set'](_0x37ce6d,pn());const _0x7cc9cf=_0xd0159c['children']['get'](_0x37ce6d);_0x5079db=b(_0x5079db),Mo(_0x7cc9cf,_0x5079db,_0x16a220);}}}function Ei(_0xec4a25,_0x4af08f,_0x192fef){_0xec4a25['value']!==null?_0x192fef(_0x4af08f,_0xec4a25['value']):Qh(_0xec4a25,(_0x1feb74,_0xb8ba1b)=>{const _0x3c93dc=new C(_0x4af08f['toString']()+'/'+_0x1feb74);Ei(_0xb8ba1b,_0x3c93dc,_0x192fef);});}function Qh(_0x379db3,_0x5edc00){_0x379db3['children']['forEach']((_0x4e5a06,_0x555f28)=>{_0x5edc00(_0x555f28,_0x4e5a06);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x2921f7){this['collection_']=_0x2921f7,this['last_']=null;}['get'](){const _0x4c3ab4=this['collection_']['get'](),_0x48a23a={..._0x4c3ab4};return this['last_']&&x(this['last_'],(_0x3b2bfd,_0x1f54b8)=>{_0x48a23a[_0x3b2bfd]=_0x48a23a[_0x3b2bfd]-_0x1f54b8;}),this['last_']=_0x4c3ab4,_0x48a23a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x15d33c,_0x1d7b48){this['server_']=_0x1d7b48,this['statsToReport_']={},this['statsListener_']=new Jh(_0x15d33c);const _0x34d8a7=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x34d8a7));}['reportStats_'](){const _0x216aac=this['statsListener_']['get'](),_0x1e9f56={};let _0x311bbc=!0x1;x(_0x216aac,(_0x4a311f,_0x6b2c1)=>{_0x6b2c1>0x0&&Y(this['statsToReport_'],_0x4a311f)&&(_0x1e9f56[_0x4a311f]=_0x6b2c1,_0x311bbc=!0x0);}),_0x311bbc&&this['server_']['reportStats'](_0x1e9f56),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x3c001d){_0x3c001d[_0x3c001d['OVERWRITE']=0x0]='OVERWRITE',_0x3c001d[_0x3c001d['MERGE']=0x1]='MERGE',_0x3c001d[_0x3c001d['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x3c001d[_0x3c001d['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x2a7786){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2a7786,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x11f52a,_0x50faea,_0x7fa083){this['path']=_0x11f52a,this['affectedTree']=_0x50faea,this['revert']=_0x7fa083,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x34b8d0){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x61c3a0=this['affectedTree']['subtree'](new C(_0x34b8d0));return new _n(w(),_0x61c3a0,this['revert']);}}else return f(y(this['path'])===_0x34b8d0,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x286f08,_0x358e47){this['source']=_0x286f08,this['path']=_0x358e47,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x36e33c){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x446d1,_0x513513,_0x19ada1){this['source']=_0x446d1,this['path']=_0x513513,this['snap']=_0x19ada1,this['type']=q['OVERWRITE'];}['operationForChild'](_0x3656bc){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x3656bc)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x400a7c,_0x404caa,_0x2a9534){this['source']=_0x400a7c,this['path']=_0x404caa,this['children']=_0x2a9534,this['type']=q['MERGE'];}['operationForChild'](_0x268bc8){if(v(this['path'])){const _0x394162=this['children']['subtree'](new C(_0x268bc8));return _0x394162['isEmpty']()?null:_0x394162['value']?new Fe(this['source'],w(),_0x394162['value']):new nt(this['source'],w(),_0x394162);}else return f(y(this['path'])===_0x268bc8,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x10db0b,_0x4dfd4d,_0xba3577){this['node_']=_0x10db0b,this['fullyInitialized_']=_0x4dfd4d,this['filtered_']=_0xba3577;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xb49bec){if(v(_0xb49bec))return this['isFullyInitialized']()&&!this['filtered_'];const _0x2854c9=y(_0xb49bec);return this['isCompleteForChild'](_0x2854c9);}['isCompleteForChild'](_0x198de5){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x198de5);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x597276){this['query_']=_0x597276,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x22a6df,_0x33c8db,_0x4ecd90,_0x1840ee){const _0x5c814a=[],_0x1b90bf=[];return _0x33c8db['forEach'](_0xb7f747=>{_0xb7f747['type']==='child_changed'&&_0x22a6df['index_']['indexedValueChanged'](_0xb7f747['oldSnap'],_0xb7f747['snapshotNode'])&&_0x1b90bf['push']($h(_0xb7f747['childName'],_0xb7f747['snapshotNode']));}),mt(_0x22a6df,_0x5c814a,'child_removed',_0x33c8db,_0x1840ee,_0x4ecd90),mt(_0x22a6df,_0x5c814a,'child_added',_0x33c8db,_0x1840ee,_0x4ecd90),mt(_0x22a6df,_0x5c814a,'child_moved',_0x1b90bf,_0x1840ee,_0x4ecd90),mt(_0x22a6df,_0x5c814a,'child_changed',_0x33c8db,_0x1840ee,_0x4ecd90),mt(_0x22a6df,_0x5c814a,'value',_0x33c8db,_0x1840ee,_0x4ecd90),_0x5c814a;}function mt(_0x21f993,_0x1a2623,_0x41d783,_0x1e1b0d,_0x50e288,_0x452e58){const _0x415417=_0x1e1b0d['filter'](_0x471355=>_0x471355['type']===_0x41d783);_0x415417['sort']((_0x957f25,_0x25c01f)=>su(_0x21f993,_0x957f25,_0x25c01f)),_0x415417['forEach'](_0xcff555=>{const _0x4dc750=iu(_0x21f993,_0xcff555,_0x452e58);_0x50e288['forEach'](_0x19e21b=>{_0x19e21b['respondsTo'](_0xcff555['type'])&&_0x1a2623['push'](_0x19e21b['createEvent'](_0x4dc750,_0x21f993['query_']));});});}function iu(_0x251e49,_0x4012e2,_0x32fb1a){return _0x4012e2['type']==='value'||_0x4012e2['type']==='child_removed'||(_0x4012e2['prevName']=_0x32fb1a['getPredecessorChildName'](_0x4012e2['childName'],_0x4012e2['snapshotNode'],_0x251e49['index_'])),_0x4012e2;}function su(_0x7885a,_0x23e45c,_0x4b1e03){if(_0x23e45c['childName']==null||_0x4b1e03['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x90e65d=new E(_0x23e45c['childName'],_0x23e45c['snapshotNode']),_0x386efc=new E(_0x4b1e03['childName'],_0x4b1e03['snapshotNode']);return _0x7885a['index_']['compare'](_0x90e65d,_0x386efc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x521d0e,_0x43b688){return{'eventCache':_0x521d0e,'serverCache':_0x43b688};}function wt(_0x2a9ef2,_0x34d58a,_0x1af5c8,_0x195a05){return Dn(new Ce(_0x34d58a,_0x1af5c8,_0x195a05),_0x2a9ef2['serverCache']);}function Lo(_0x371715,_0x46b239,_0x149208,_0x38b680){return Dn(_0x371715['eventCache'],new Ce(_0x46b239,_0x149208,_0x38b680));}function gn(_0x5c6daa){return _0x5c6daa['eventCache']['isFullyInitialized']()?_0x5c6daa['eventCache']['getNode']():null;}function Ue(_0x1d84e7){return _0x1d84e7['serverCache']['isFullyInitialized']()?_0x1d84e7['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x4ac8a4){let _0x592f5e=new S(null);return x(_0x4ac8a4,(_0x46ac66,_0x31868e)=>{_0x592f5e=_0x592f5e['set'](new C(_0x46ac66),_0x31868e);}),_0x592f5e;}constructor(_0x50e7d6,_0x5d84f2=ru()){this['value']=_0x50e7d6,this['children']=_0x5d84f2;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x4f2f72,_0x8bcec5){if(this['value']!=null&&_0x8bcec5(this['value']))return{'path':w(),'value':this['value']};if(v(_0x4f2f72))return null;{const _0x19f7d6=y(_0x4f2f72),_0xbdd213=this['children']['get'](_0x19f7d6);if(_0xbdd213!==null){const _0x679458=_0xbdd213['findRootMostMatchingPathAndValue'](b(_0x4f2f72),_0x8bcec5);return _0x679458!=null?{'path':A(new C(_0x19f7d6),_0x679458['path']),'value':_0x679458['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4d91a4){return this['findRootMostMatchingPathAndValue'](_0x4d91a4,()=>!0x0);}['subtree'](_0xce372f){if(v(_0xce372f))return this;{const _0x5c4574=y(_0xce372f),_0x4440bf=this['children']['get'](_0x5c4574);return _0x4440bf!==null?_0x4440bf['subtree'](b(_0xce372f)):new S(null);}}['set'](_0x1778f7,_0x74bdc2){if(v(_0x1778f7))return new S(_0x74bdc2,this['children']);{const _0x37623c=y(_0x1778f7),_0x2c1fb1=(this['children']['get'](_0x37623c)||new S(null))['set'](b(_0x1778f7),_0x74bdc2),_0x45bd53=this['children']['insert'](_0x37623c,_0x2c1fb1);return new S(this['value'],_0x45bd53);}}['remove'](_0x2b8b81){if(v(_0x2b8b81))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x28a342=y(_0x2b8b81),_0x6632d0=this['children']['get'](_0x28a342);if(_0x6632d0){const _0x4ccd1a=_0x6632d0['remove'](b(_0x2b8b81));let _0x455d82;return _0x4ccd1a['isEmpty']()?_0x455d82=this['children']['remove'](_0x28a342):_0x455d82=this['children']['insert'](_0x28a342,_0x4ccd1a),this['value']===null&&_0x455d82['isEmpty']()?new S(null):new S(this['value'],_0x455d82);}else return this;}}['get'](_0x2ad3aa){if(v(_0x2ad3aa))return this['value'];{const _0x4ab5e3=y(_0x2ad3aa),_0x407148=this['children']['get'](_0x4ab5e3);return _0x407148?_0x407148['get'](b(_0x2ad3aa)):null;}}['setTree'](_0x321b0b,_0x190ae8){if(v(_0x321b0b))return _0x190ae8;{const _0x35c0fa=y(_0x321b0b),_0x367973=(this['children']['get'](_0x35c0fa)||new S(null))['setTree'](b(_0x321b0b),_0x190ae8);let _0x2271ca;return _0x367973['isEmpty']()?_0x2271ca=this['children']['remove'](_0x35c0fa):_0x2271ca=this['children']['insert'](_0x35c0fa,_0x367973),new S(this['value'],_0x2271ca);}}['fold'](_0x263d24){return this['fold_'](w(),_0x263d24);}['fold_'](_0x143c11,_0x95c8aa){const _0x5e521f={};return this['children']['inorderTraversal']((_0x346c21,_0xfb0a57)=>{_0x5e521f[_0x346c21]=_0xfb0a57['fold_'](A(_0x143c11,_0x346c21),_0x95c8aa);}),_0x95c8aa(_0x143c11,this['value'],_0x5e521f);}['findOnPath'](_0x16f8e0,_0xd0678a){return this['findOnPath_'](_0x16f8e0,w(),_0xd0678a);}['findOnPath_'](_0x51dd43,_0xea5e09,_0x530e52){const _0x2b50c7=this['value']?_0x530e52(_0xea5e09,this['value']):!0x1;if(_0x2b50c7)return _0x2b50c7;if(v(_0x51dd43))return null;{const _0x39f163=y(_0x51dd43),_0xff6991=this['children']['get'](_0x39f163);return _0xff6991?_0xff6991['findOnPath_'](b(_0x51dd43),A(_0xea5e09,_0x39f163),_0x530e52):null;}}['foreachOnPath'](_0x2cb5fd,_0x2f2483){return this['foreachOnPath_'](_0x2cb5fd,w(),_0x2f2483);}['foreachOnPath_'](_0x3bc1d8,_0x32acdc,_0x15b3b2){if(v(_0x3bc1d8))return this;{this['value']&&_0x15b3b2(_0x32acdc,this['value']);const _0x9e1753=y(_0x3bc1d8),_0x5b3928=this['children']['get'](_0x9e1753);return _0x5b3928?_0x5b3928['foreachOnPath_'](b(_0x3bc1d8),A(_0x32acdc,_0x9e1753),_0x15b3b2):new S(null);}}['foreach'](_0x1f5643){this['foreach_'](w(),_0x1f5643);}['foreach_'](_0x558f23,_0x1ba9a5){this['children']['inorderTraversal']((_0x27865a,_0x35e8d1)=>{_0x35e8d1['foreach_'](A(_0x558f23,_0x27865a),_0x1ba9a5);}),this['value']&&_0x1ba9a5(_0x558f23,this['value']);}['foreachChild'](_0x465fae){this['children']['inorderTraversal']((_0x966fb9,_0x285598)=>{_0x285598['value']&&_0x465fae(_0x966fb9,_0x285598['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x437ef3){this['writeTree_']=_0x437ef3;}static['empty'](){return new j(new S(null));}}function Ct(_0xa9b98,_0x8b853d,_0x3ff7ac){if(v(_0x8b853d))return new j(new S(_0x3ff7ac));{const _0x3c9989=_0xa9b98['writeTree_']['findRootMostValueAndPath'](_0x8b853d);if(_0x3c9989!=null){const _0xd8ee05=_0x3c9989['path'];let _0x5ecee0=_0x3c9989['value'];const _0x370634=F(_0xd8ee05,_0x8b853d);return _0x5ecee0=_0x5ecee0['updateChild'](_0x370634,_0x3ff7ac),new j(_0xa9b98['writeTree_']['set'](_0xd8ee05,_0x5ecee0));}else{const _0x4b2eaa=new S(_0x3ff7ac),_0x147750=_0xa9b98['writeTree_']['setTree'](_0x8b853d,_0x4b2eaa);return new j(_0x147750);}}}function Ii(_0x3d42f6,_0x165581,_0x397118){let _0x387105=_0x3d42f6;return x(_0x397118,(_0x3c2cb9,_0x274b16)=>{_0x387105=Ct(_0x387105,A(_0x165581,_0x3c2cb9),_0x274b16);}),_0x387105;}function sr(_0x2812db,_0x39e9c8){if(v(_0x39e9c8))return j['empty']();{const _0x5cea98=_0x2812db['writeTree_']['setTree'](_0x39e9c8,new S(null));return new j(_0x5cea98);}}function wi(_0x5a8025,_0x4d56c4){return $e(_0x5a8025,_0x4d56c4)!=null;}function $e(_0x26c4f7,_0x4aeb2b){const _0x5b427b=_0x26c4f7['writeTree_']['findRootMostValueAndPath'](_0x4aeb2b);return _0x5b427b!=null?_0x26c4f7['writeTree_']['get'](_0x5b427b['path'])['getChild'](F(_0x5b427b['path'],_0x4aeb2b)):null;}function rr(_0x38abfe){const _0x24819e=[],_0xa55242=_0x38abfe['writeTree_']['value'];return _0xa55242!=null?_0xa55242['isLeafNode']()||_0xa55242['forEachChild'](R,(_0x3f6970,_0x25a593)=>{_0x24819e['push'](new E(_0x3f6970,_0x25a593));}):_0x38abfe['writeTree_']['children']['inorderTraversal']((_0x192484,_0x365ff8)=>{_0x365ff8['value']!=null&&_0x24819e['push'](new E(_0x192484,_0x365ff8['value']));}),_0x24819e;}function ve(_0x1e0e1a,_0xe227b){if(v(_0xe227b))return _0x1e0e1a;{const _0x193a28=$e(_0x1e0e1a,_0xe227b);return _0x193a28!=null?new j(new S(_0x193a28)):new j(_0x1e0e1a['writeTree_']['subtree'](_0xe227b));}}function Ci(_0x4bb5f8){return _0x4bb5f8['writeTree_']['isEmpty']();}function it(_0x9b69d7,_0x181c16){return xo(w(),_0x9b69d7['writeTree_'],_0x181c16);}function xo(_0x22193f,_0x55c9ad,_0x38a292){if(_0x55c9ad['value']!=null)return _0x38a292['updateChild'](_0x22193f,_0x55c9ad['value']);{let _0x3ed3f6=null;return _0x55c9ad['children']['inorderTraversal']((_0x4b75f5,_0x536e26)=>{_0x4b75f5==='.priority'?(f(_0x536e26['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3ed3f6=_0x536e26['value']):_0x38a292=xo(A(_0x22193f,_0x4b75f5),_0x536e26,_0x38a292);}),!_0x38a292['getChild'](_0x22193f)['isEmpty']()&&_0x3ed3f6!==null&&(_0x38a292=_0x38a292['updateChild'](A(_0x22193f,'.priority'),_0x3ed3f6)),_0x38a292;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x5d5192,_0xbbb66){return Bo(_0xbbb66,_0x5d5192);}function ou(_0x327d17,_0x2fdee4,_0x3515ce,_0x2487fd,_0x1bc320){f(_0x2487fd>_0x327d17['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1bc320===void 0x0&&(_0x1bc320=!0x0),_0x327d17['allWrites']['push']({'path':_0x2fdee4,'snap':_0x3515ce,'writeId':_0x2487fd,'visible':_0x1bc320}),_0x1bc320&&(_0x327d17['visibleWrites']=Ct(_0x327d17['visibleWrites'],_0x2fdee4,_0x3515ce)),_0x327d17['lastWriteId']=_0x2487fd;}function au(_0x17c3b0,_0x3fe0e0,_0x5d3ee3,_0x16867d){f(_0x16867d>_0x17c3b0['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x17c3b0['allWrites']['push']({'path':_0x3fe0e0,'children':_0x5d3ee3,'writeId':_0x16867d,'visible':!0x0}),_0x17c3b0['visibleWrites']=Ii(_0x17c3b0['visibleWrites'],_0x3fe0e0,_0x5d3ee3),_0x17c3b0['lastWriteId']=_0x16867d;}function cu(_0x5e9483,_0xd29e6c){for(let _0x386e5d=0x0;_0x386e5d<_0x5e9483['allWrites']['length'];_0x386e5d++){const _0xa193e1=_0x5e9483['allWrites'][_0x386e5d];if(_0xa193e1['writeId']===_0xd29e6c)return _0xa193e1;}return null;}function lu(_0x3d04e8,_0x4544fd){const _0x2dbc90=_0x3d04e8['allWrites']['findIndex'](_0x21d8f2=>_0x21d8f2['writeId']===_0x4544fd);f(_0x2dbc90>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x748512=_0x3d04e8['allWrites'][_0x2dbc90];_0x3d04e8['allWrites']['splice'](_0x2dbc90,0x1);let _0x4e917c=_0x748512['visible'],_0xdfe4d9=!0x1,_0x3a63e3=_0x3d04e8['allWrites']['length']-0x1;for(;_0x4e917c&&_0x3a63e3>=0x0;){const _0x3179d5=_0x3d04e8['allWrites'][_0x3a63e3];_0x3179d5['visible']&&(_0x3a63e3>=_0x2dbc90&&hu(_0x3179d5,_0x748512['path'])?_0x4e917c=!0x1:$(_0x748512['path'],_0x3179d5['path'])&&(_0xdfe4d9=!0x0)),_0x3a63e3--;}if(_0x4e917c){if(_0xdfe4d9)return uu(_0x3d04e8),!0x0;if(_0x748512['snap'])_0x3d04e8['visibleWrites']=sr(_0x3d04e8['visibleWrites'],_0x748512['path']);else{const _0x470ccd=_0x748512['children'];x(_0x470ccd,_0x3b75de=>{_0x3d04e8['visibleWrites']=sr(_0x3d04e8['visibleWrites'],A(_0x748512['path'],_0x3b75de));});}return!0x0;}else return!0x1;}function hu(_0x414469,_0x24e394){if(_0x414469['snap'])return $(_0x414469['path'],_0x24e394);for(const _0x5ca979 in _0x414469['children'])if(_0x414469['children']['hasOwnProperty'](_0x5ca979)&&$(A(_0x414469['path'],_0x5ca979),_0x24e394))return!0x0;return!0x1;}function uu(_0x3a5caa){_0x3a5caa['visibleWrites']=Fo(_0x3a5caa['allWrites'],du,w()),_0x3a5caa['allWrites']['length']>0x0?_0x3a5caa['lastWriteId']=_0x3a5caa['allWrites'][_0x3a5caa['allWrites']['length']-0x1]['writeId']:_0x3a5caa['lastWriteId']=-0x1;}function du(_0x4ddd60){return _0x4ddd60['visible'];}function Fo(_0x172e80,_0x40641c,_0x4ad729){let _0x2c716f=j['empty']();for(let _0x4ef517=0x0;_0x4ef517<_0x172e80['length'];++_0x4ef517){const _0x5a1480=_0x172e80[_0x4ef517];if(_0x40641c(_0x5a1480)){const _0x1e3650=_0x5a1480['path'];let _0x514ecb;if(_0x5a1480['snap'])$(_0x4ad729,_0x1e3650)?(_0x514ecb=F(_0x4ad729,_0x1e3650),_0x2c716f=Ct(_0x2c716f,_0x514ecb,_0x5a1480['snap'])):$(_0x1e3650,_0x4ad729)&&(_0x514ecb=F(_0x1e3650,_0x4ad729),_0x2c716f=Ct(_0x2c716f,w(),_0x5a1480['snap']['getChild'](_0x514ecb)));else{if(_0x5a1480['children']){if($(_0x4ad729,_0x1e3650))_0x514ecb=F(_0x4ad729,_0x1e3650),_0x2c716f=Ii(_0x2c716f,_0x514ecb,_0x5a1480['children']);else{if($(_0x1e3650,_0x4ad729)){if(_0x514ecb=F(_0x1e3650,_0x4ad729),v(_0x514ecb))_0x2c716f=Ii(_0x2c716f,w(),_0x5a1480['children']);else{const _0x25a255=Oe(_0x5a1480['children'],y(_0x514ecb));if(_0x25a255){const _0x58adc4=_0x25a255['getChild'](b(_0x514ecb));_0x2c716f=Ct(_0x2c716f,w(),_0x58adc4);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x2c716f;}function Uo(_0x4bef2a,_0x45ebff,_0x3662ac,_0x1ae745,_0xaa9be3){if(!_0x1ae745&&!_0xaa9be3){const _0x2d3336=$e(_0x4bef2a['visibleWrites'],_0x45ebff);if(_0x2d3336!=null)return _0x2d3336;{const _0x44c746=ve(_0x4bef2a['visibleWrites'],_0x45ebff);if(Ci(_0x44c746))return _0x3662ac;if(_0x3662ac==null&&!wi(_0x44c746,w()))return null;{const _0x25c190=_0x3662ac||g['EMPTY_NODE'];return it(_0x44c746,_0x25c190);}}}else{const _0x22b91a=ve(_0x4bef2a['visibleWrites'],_0x45ebff);if(!_0xaa9be3&&Ci(_0x22b91a))return _0x3662ac;if(!_0xaa9be3&&_0x3662ac==null&&!wi(_0x22b91a,w()))return null;{const _0x5411eb=function(_0x1c2bbf){return(_0x1c2bbf['visible']||_0xaa9be3)&&(!_0x1ae745||!~_0x1ae745['indexOf'](_0x1c2bbf['writeId']))&&($(_0x1c2bbf['path'],_0x45ebff)||$(_0x45ebff,_0x1c2bbf['path']));},_0x20b76b=Fo(_0x4bef2a['allWrites'],_0x5411eb,_0x45ebff),_0x174f85=_0x3662ac||g['EMPTY_NODE'];return it(_0x20b76b,_0x174f85);}}}function fu(_0x31f848,_0x195fc0,_0x1516a7){let _0x35a008=g['EMPTY_NODE'];const _0x3e2db0=$e(_0x31f848['visibleWrites'],_0x195fc0);if(_0x3e2db0)return _0x3e2db0['isLeafNode']()||_0x3e2db0['forEachChild'](R,(_0x41a381,_0x42572b)=>{_0x35a008=_0x35a008['updateImmediateChild'](_0x41a381,_0x42572b);}),_0x35a008;if(_0x1516a7){const _0x5a3bbe=ve(_0x31f848['visibleWrites'],_0x195fc0);return _0x1516a7['forEachChild'](R,(_0x178a86,_0x45a6b0)=>{const _0x278247=it(ve(_0x5a3bbe,new C(_0x178a86)),_0x45a6b0);_0x35a008=_0x35a008['updateImmediateChild'](_0x178a86,_0x278247);}),rr(_0x5a3bbe)['forEach'](_0x2b514=>{_0x35a008=_0x35a008['updateImmediateChild'](_0x2b514['name'],_0x2b514['node']);}),_0x35a008;}else{const _0x453732=ve(_0x31f848['visibleWrites'],_0x195fc0);return rr(_0x453732)['forEach'](_0x2dda51=>{_0x35a008=_0x35a008['updateImmediateChild'](_0x2dda51['name'],_0x2dda51['node']);}),_0x35a008;}}function pu(_0x39a98f,_0x1c7a8f,_0x4101e1,_0x29caed,_0x263718){f(_0x29caed||_0x263718,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x302704=A(_0x1c7a8f,_0x4101e1);if(wi(_0x39a98f['visibleWrites'],_0x302704))return null;{const _0x5739d7=ve(_0x39a98f['visibleWrites'],_0x302704);return Ci(_0x5739d7)?_0x263718['getChild'](_0x4101e1):it(_0x5739d7,_0x263718['getChild'](_0x4101e1));}}function _u(_0x131d2d,_0xb64cf5,_0x2aedb4,_0x457891){const _0x433f68=A(_0xb64cf5,_0x2aedb4),_0x11533b=$e(_0x131d2d['visibleWrites'],_0x433f68);if(_0x11533b!=null)return _0x11533b;if(_0x457891['isCompleteForChild'](_0x2aedb4)){const _0x1e91ba=ve(_0x131d2d['visibleWrites'],_0x433f68);return it(_0x1e91ba,_0x457891['getNode']()['getImmediateChild'](_0x2aedb4));}else return null;}function gu(_0x512c5f,_0x92debf){return $e(_0x512c5f['visibleWrites'],_0x92debf);}function mu(_0x502a40,_0xa480e0,_0x2a5834,_0x1a8995,_0x50db4a,_0x4424ce,_0x13cb76){let _0x532847;const _0xa9da39=ve(_0x502a40['visibleWrites'],_0xa480e0),_0x1b8b0c=$e(_0xa9da39,w());if(_0x1b8b0c!=null)_0x532847=_0x1b8b0c;else{if(_0x2a5834!=null)_0x532847=it(_0xa9da39,_0x2a5834);else return[];}if(_0x532847=_0x532847['withIndex'](_0x13cb76),!_0x532847['isEmpty']()&&!_0x532847['isLeafNode']()){const _0x1727c0=[],_0x49a787=_0x13cb76['getCompare'](),_0x40bb15=_0x4424ce?_0x532847['getReverseIteratorFrom'](_0x1a8995,_0x13cb76):_0x532847['getIteratorFrom'](_0x1a8995,_0x13cb76);let _0x35be56=_0x40bb15['getNext']();for(;_0x35be56&&_0x1727c0['length']<_0x50db4a;)_0x49a787(_0x35be56,_0x1a8995)!==0x0&&_0x1727c0['push'](_0x35be56),_0x35be56=_0x40bb15['getNext']();return _0x1727c0;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x205958,_0x2553fa,_0x2195ac,_0x49b813){return Uo(_0x205958['writeTree'],_0x205958['treePath'],_0x2553fa,_0x2195ac,_0x49b813);}function es(_0x20f974,_0x48fbf3){return fu(_0x20f974['writeTree'],_0x20f974['treePath'],_0x48fbf3);}function or(_0x597bac,_0x2c5cc0,_0x7aa561,_0x74f987){return pu(_0x597bac['writeTree'],_0x597bac['treePath'],_0x2c5cc0,_0x7aa561,_0x74f987);}function yn(_0x1f3f92,_0x3b8bc2){return gu(_0x1f3f92['writeTree'],A(_0x1f3f92['treePath'],_0x3b8bc2));}function vu(_0x495811,_0x64aa2e,_0x14e024,_0x1c8ffa,_0x4d536c,_0x189bd8){return mu(_0x495811['writeTree'],_0x495811['treePath'],_0x64aa2e,_0x14e024,_0x1c8ffa,_0x4d536c,_0x189bd8);}function ts(_0x4852f6,_0x448bcb,_0x85903d){return _u(_0x4852f6['writeTree'],_0x4852f6['treePath'],_0x448bcb,_0x85903d);}function Wo(_0x5a4d0c,_0x13a928){return Bo(A(_0x5a4d0c['treePath'],_0x13a928),_0x5a4d0c['writeTree']);}function Bo(_0x1cdd06,_0x47c8d6){return{'treePath':_0x1cdd06,'writeTree':_0x47c8d6};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x59c2f6){const _0x266de3=_0x59c2f6['type'],_0x268af5=_0x59c2f6['childName'];f(_0x266de3==='child_added'||_0x266de3==='child_changed'||_0x266de3==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x268af5!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2c141f=this['changeMap']['get'](_0x268af5);if(_0x2c141f){const _0x6a5a03=_0x2c141f['type'];if(_0x266de3==='child_added'&&_0x6a5a03==='child_removed')this['changeMap']['set'](_0x268af5,Pt(_0x268af5,_0x59c2f6['snapshotNode'],_0x2c141f['snapshotNode']));else{if(_0x266de3==='child_removed'&&_0x6a5a03==='child_added')this['changeMap']['delete'](_0x268af5);else{if(_0x266de3==='child_removed'&&_0x6a5a03==='child_changed')this['changeMap']['set'](_0x268af5,Nt(_0x268af5,_0x2c141f['oldSnap']));else{if(_0x266de3==='child_changed'&&_0x6a5a03==='child_added')this['changeMap']['set'](_0x268af5,tt(_0x268af5,_0x59c2f6['snapshotNode']));else{if(_0x266de3==='child_changed'&&_0x6a5a03==='child_changed')this['changeMap']['set'](_0x268af5,Pt(_0x268af5,_0x59c2f6['snapshotNode'],_0x2c141f['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x59c2f6+'\x20occurred\x20after\x20'+_0x2c141f);}}}}}else this['changeMap']['set'](_0x268af5,_0x59c2f6);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x4143e0){return null;}['getChildAfterChild'](_0xf8b451,_0x27ee63,_0x31c4e7){return null;}}const Vo=new Iu();class ns{constructor(_0x45729e,_0x4369c2,_0x435f70=null){this['writes_']=_0x45729e,this['viewCache_']=_0x4369c2,this['optCompleteServerCache_']=_0x435f70;}['getCompleteChild'](_0x1acd11){const _0x9fa9eb=this['viewCache_']['eventCache'];if(_0x9fa9eb['isCompleteForChild'](_0x1acd11))return _0x9fa9eb['getNode']()['getImmediateChild'](_0x1acd11);{const _0x2df1b9=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x1acd11,_0x2df1b9);}}['getChildAfterChild'](_0x2da884,_0x2fea70,_0x185a63){const _0x46ce42=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x569088=vu(this['writes_'],_0x46ce42,_0x2fea70,0x1,_0x185a63,_0x2da884);return _0x569088['length']===0x0?null:_0x569088[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0xa9378e){return{'filter':_0xa9378e};}function Cu(_0x40f788,_0x5a60f0){f(_0x5a60f0['eventCache']['getNode']()['isIndexed'](_0x40f788['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5a60f0['serverCache']['getNode']()['isIndexed'](_0x40f788['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x49e959,_0x2d3ec1,_0xc3c100,_0xc84879,_0x583b0a){const _0xe26fca=new Eu();let _0x3a6aab,_0xd4a0af;if(_0xc3c100['type']===q['OVERWRITE']){const _0x1ffd34=_0xc3c100;_0x1ffd34['source']['fromUser']?_0x3a6aab=Ti(_0x49e959,_0x2d3ec1,_0x1ffd34['path'],_0x1ffd34['snap'],_0xc84879,_0x583b0a,_0xe26fca):(f(_0x1ffd34['source']['fromServer'],'Unknown\x20source.'),_0xd4a0af=_0x1ffd34['source']['tagged']||_0x2d3ec1['serverCache']['isFiltered']()&&!v(_0x1ffd34['path']),_0x3a6aab=vn(_0x49e959,_0x2d3ec1,_0x1ffd34['path'],_0x1ffd34['snap'],_0xc84879,_0x583b0a,_0xd4a0af,_0xe26fca));}else{if(_0xc3c100['type']===q['MERGE']){const _0x15503b=_0xc3c100;_0x15503b['source']['fromUser']?_0x3a6aab=bu(_0x49e959,_0x2d3ec1,_0x15503b['path'],_0x15503b['children'],_0xc84879,_0x583b0a,_0xe26fca):(f(_0x15503b['source']['fromServer'],'Unknown\x20source.'),_0xd4a0af=_0x15503b['source']['tagged']||_0x2d3ec1['serverCache']['isFiltered'](),_0x3a6aab=Si(_0x49e959,_0x2d3ec1,_0x15503b['path'],_0x15503b['children'],_0xc84879,_0x583b0a,_0xd4a0af,_0xe26fca));}else{if(_0xc3c100['type']===q['ACK_USER_WRITE']){const _0x3a79a7=_0xc3c100;_0x3a79a7['revert']?_0x3a6aab=ku(_0x49e959,_0x2d3ec1,_0x3a79a7['path'],_0xc84879,_0x583b0a,_0xe26fca):_0x3a6aab=Ru(_0x49e959,_0x2d3ec1,_0x3a79a7['path'],_0x3a79a7['affectedTree'],_0xc84879,_0x583b0a,_0xe26fca);}else{if(_0xc3c100['type']===q['LISTEN_COMPLETE'])_0x3a6aab=Au(_0x49e959,_0x2d3ec1,_0xc3c100['path'],_0xc84879,_0xe26fca);else throw ot('Unknown\x20operation\x20type:\x20'+_0xc3c100['type']);}}}const _0x180150=_0xe26fca['getChanges']();return Su(_0x2d3ec1,_0x3a6aab,_0x180150),{'viewCache':_0x3a6aab,'changes':_0x180150};}function Su(_0x5bd040,_0x8af745,_0x569abd){const _0x63a697=_0x8af745['eventCache'];if(_0x63a697['isFullyInitialized']()){const _0x3e463c=_0x63a697['getNode']()['isLeafNode']()||_0x63a697['getNode']()['isEmpty'](),_0x2b1781=gn(_0x5bd040);(_0x569abd['length']>0x0||!_0x5bd040['eventCache']['isFullyInitialized']()||_0x3e463c&&!_0x63a697['getNode']()['equals'](_0x2b1781)||!_0x63a697['getNode']()['getPriority']()['equals'](_0x2b1781['getPriority']()))&&_0x569abd['push'](Oo(gn(_0x8af745)));}}function Ho(_0x43f4af,_0xe3de63,_0x411d29,_0x460195,_0x29173d,_0x4d129a){const _0x12a001=_0xe3de63['eventCache'];if(yn(_0x460195,_0x411d29)!=null)return _0xe3de63;{let _0x1f07f3,_0x50d662;if(v(_0x411d29)){if(f(_0xe3de63['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xe3de63['serverCache']['isFiltered']()){const _0x56ed10=Ue(_0xe3de63),_0x113e66=_0x56ed10 instanceof g?_0x56ed10:g['EMPTY_NODE'],_0x130426=es(_0x460195,_0x113e66);_0x1f07f3=_0x43f4af['filter']['updateFullNode'](_0xe3de63['eventCache']['getNode'](),_0x130426,_0x4d129a);}else{const _0xcdb688=mn(_0x460195,Ue(_0xe3de63));_0x1f07f3=_0x43f4af['filter']['updateFullNode'](_0xe3de63['eventCache']['getNode'](),_0xcdb688,_0x4d129a);}}else{const _0x2280b2=y(_0x411d29);if(_0x2280b2==='.priority'){f(we(_0x411d29)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4a3da3=_0x12a001['getNode']();_0x50d662=_0xe3de63['serverCache']['getNode']();const _0x6db493=or(_0x460195,_0x411d29,_0x4a3da3,_0x50d662);_0x6db493!=null?_0x1f07f3=_0x43f4af['filter']['updatePriority'](_0x4a3da3,_0x6db493):_0x1f07f3=_0x12a001['getNode']();}else{const _0x171b33=b(_0x411d29);let _0x425baa;if(_0x12a001['isCompleteForChild'](_0x2280b2)){_0x50d662=_0xe3de63['serverCache']['getNode']();const _0x470325=or(_0x460195,_0x411d29,_0x12a001['getNode'](),_0x50d662);_0x470325!=null?_0x425baa=_0x12a001['getNode']()['getImmediateChild'](_0x2280b2)['updateChild'](_0x171b33,_0x470325):_0x425baa=_0x12a001['getNode']()['getImmediateChild'](_0x2280b2);}else _0x425baa=ts(_0x460195,_0x2280b2,_0xe3de63['serverCache']);_0x425baa!=null?_0x1f07f3=_0x43f4af['filter']['updateChild'](_0x12a001['getNode'](),_0x2280b2,_0x425baa,_0x171b33,_0x29173d,_0x4d129a):_0x1f07f3=_0x12a001['getNode']();}}return wt(_0xe3de63,_0x1f07f3,_0x12a001['isFullyInitialized']()||v(_0x411d29),_0x43f4af['filter']['filtersNodes']());}}function vn(_0x5b0f4e,_0x41f1c5,_0x4dd3bf,_0x5e0371,_0x5e1b6f,_0x33bd9f,_0x24747d,_0x388d81){const _0x431044=_0x41f1c5['serverCache'];let _0x343b5c;const _0xf5cb6c=_0x24747d?_0x5b0f4e['filter']:_0x5b0f4e['filter']['getIndexedFilter']();if(v(_0x4dd3bf))_0x343b5c=_0xf5cb6c['updateFullNode'](_0x431044['getNode'](),_0x5e0371,null);else{if(_0xf5cb6c['filtersNodes']()&&!_0x431044['isFiltered']()){const _0x5c271b=_0x431044['getNode']()['updateChild'](_0x4dd3bf,_0x5e0371);_0x343b5c=_0xf5cb6c['updateFullNode'](_0x431044['getNode'](),_0x5c271b,null);}else{const _0x11008e=y(_0x4dd3bf);if(!_0x431044['isCompleteForPath'](_0x4dd3bf)&&we(_0x4dd3bf)>0x1)return _0x41f1c5;const _0x5c33d5=b(_0x4dd3bf),_0x145d2d=_0x431044['getNode']()['getImmediateChild'](_0x11008e)['updateChild'](_0x5c33d5,_0x5e0371);_0x11008e==='.priority'?_0x343b5c=_0xf5cb6c['updatePriority'](_0x431044['getNode'](),_0x145d2d):_0x343b5c=_0xf5cb6c['updateChild'](_0x431044['getNode'](),_0x11008e,_0x145d2d,_0x5c33d5,Vo,null);}}const _0x97d4ad=Lo(_0x41f1c5,_0x343b5c,_0x431044['isFullyInitialized']()||v(_0x4dd3bf),_0xf5cb6c['filtersNodes']()),_0x4e13ee=new ns(_0x5e1b6f,_0x97d4ad,_0x33bd9f);return Ho(_0x5b0f4e,_0x97d4ad,_0x4dd3bf,_0x5e1b6f,_0x4e13ee,_0x388d81);}function Ti(_0x2d9268,_0x1b0967,_0x5119fa,_0x5addce,_0x49a647,_0x1bea42,_0x3393bb){const _0x3c28a6=_0x1b0967['eventCache'];let _0x430397,_0x1af606;const _0x2f3fa1=new ns(_0x49a647,_0x1b0967,_0x1bea42);if(v(_0x5119fa))_0x1af606=_0x2d9268['filter']['updateFullNode'](_0x1b0967['eventCache']['getNode'](),_0x5addce,_0x3393bb),_0x430397=wt(_0x1b0967,_0x1af606,!0x0,_0x2d9268['filter']['filtersNodes']());else{const _0x68735c=y(_0x5119fa);if(_0x68735c==='.priority')_0x1af606=_0x2d9268['filter']['updatePriority'](_0x1b0967['eventCache']['getNode'](),_0x5addce),_0x430397=wt(_0x1b0967,_0x1af606,_0x3c28a6['isFullyInitialized'](),_0x3c28a6['isFiltered']());else{const _0x1eeeb3=b(_0x5119fa),_0x3b89dd=_0x3c28a6['getNode']()['getImmediateChild'](_0x68735c);let _0x5418d8;if(v(_0x1eeeb3))_0x5418d8=_0x5addce;else{const _0xbc9d62=_0x2f3fa1['getCompleteChild'](_0x68735c);_0xbc9d62!=null?Gi(_0x1eeeb3)==='.priority'&&_0xbc9d62['getChild'](To(_0x1eeeb3))['isEmpty']()?_0x5418d8=_0xbc9d62:_0x5418d8=_0xbc9d62['updateChild'](_0x1eeeb3,_0x5addce):_0x5418d8=g['EMPTY_NODE'];}if(_0x3b89dd['equals'](_0x5418d8))_0x430397=_0x1b0967;else{const _0x35a679=_0x2d9268['filter']['updateChild'](_0x3c28a6['getNode'](),_0x68735c,_0x5418d8,_0x1eeeb3,_0x2f3fa1,_0x3393bb);_0x430397=wt(_0x1b0967,_0x35a679,_0x3c28a6['isFullyInitialized'](),_0x2d9268['filter']['filtersNodes']());}}}return _0x430397;}function ar(_0x381465,_0x51f4e3){return _0x381465['eventCache']['isCompleteForChild'](_0x51f4e3);}function bu(_0xdf28b9,_0x2b5b84,_0x28c4fa,_0x208801,_0x2fda5f,_0x3dc6ac,_0x334023){let _0x1d3370=_0x2b5b84;return _0x208801['foreach']((_0x3d0377,_0xb7179d)=>{const _0x47d10d=A(_0x28c4fa,_0x3d0377);ar(_0x2b5b84,y(_0x47d10d))&&(_0x1d3370=Ti(_0xdf28b9,_0x1d3370,_0x47d10d,_0xb7179d,_0x2fda5f,_0x3dc6ac,_0x334023));}),_0x208801['foreach']((_0x6a276,_0x55bcf)=>{const _0x4e4495=A(_0x28c4fa,_0x6a276);ar(_0x2b5b84,y(_0x4e4495))||(_0x1d3370=Ti(_0xdf28b9,_0x1d3370,_0x4e4495,_0x55bcf,_0x2fda5f,_0x3dc6ac,_0x334023));}),_0x1d3370;}function cr(_0x4ffda5,_0x1a5e56,_0xaeb234){return _0xaeb234['foreach']((_0x237bdb,_0x5c8c6b)=>{_0x1a5e56=_0x1a5e56['updateChild'](_0x237bdb,_0x5c8c6b);}),_0x1a5e56;}function Si(_0x281743,_0x125c50,_0x117343,_0x2f5189,_0x297a44,_0x394dda,_0x3c7486,_0x1e20b3){if(_0x125c50['serverCache']['getNode']()['isEmpty']()&&!_0x125c50['serverCache']['isFullyInitialized']())return _0x125c50;let _0x3e9e27=_0x125c50,_0x54a8fa;v(_0x117343)?_0x54a8fa=_0x2f5189:_0x54a8fa=new S(null)['setTree'](_0x117343,_0x2f5189);const _0xb23100=_0x125c50['serverCache']['getNode']();return _0x54a8fa['children']['inorderTraversal']((_0x18f55d,_0x516b66)=>{if(_0xb23100['hasChild'](_0x18f55d)){const _0x17bb24=_0x125c50['serverCache']['getNode']()['getImmediateChild'](_0x18f55d),_0x4f690b=cr(_0x281743,_0x17bb24,_0x516b66);_0x3e9e27=vn(_0x281743,_0x3e9e27,new C(_0x18f55d),_0x4f690b,_0x297a44,_0x394dda,_0x3c7486,_0x1e20b3);}}),_0x54a8fa['children']['inorderTraversal']((_0x5ecaaa,_0x4ff38b)=>{const _0x5da855=!_0x125c50['serverCache']['isCompleteForChild'](_0x5ecaaa)&&_0x4ff38b['value']===null;if(!_0xb23100['hasChild'](_0x5ecaaa)&&!_0x5da855){const _0x1c2b20=_0x125c50['serverCache']['getNode']()['getImmediateChild'](_0x5ecaaa),_0x481430=cr(_0x281743,_0x1c2b20,_0x4ff38b);_0x3e9e27=vn(_0x281743,_0x3e9e27,new C(_0x5ecaaa),_0x481430,_0x297a44,_0x394dda,_0x3c7486,_0x1e20b3);}}),_0x3e9e27;}function Ru(_0x10ddbf,_0x214d7a,_0x4a32f5,_0x1829ec,_0x5258f4,_0x4591a2,_0x31ac38){if(yn(_0x5258f4,_0x4a32f5)!=null)return _0x214d7a;const _0x604fb7=_0x214d7a['serverCache']['isFiltered'](),_0x485f76=_0x214d7a['serverCache'];if(_0x1829ec['value']!=null){if(v(_0x4a32f5)&&_0x485f76['isFullyInitialized']()||_0x485f76['isCompleteForPath'](_0x4a32f5))return vn(_0x10ddbf,_0x214d7a,_0x4a32f5,_0x485f76['getNode']()['getChild'](_0x4a32f5),_0x5258f4,_0x4591a2,_0x604fb7,_0x31ac38);if(v(_0x4a32f5)){let _0x4e9d3b=new S(null);return _0x485f76['getNode']()['forEachChild'](ye,(_0x5549b4,_0x46003b)=>{_0x4e9d3b=_0x4e9d3b['set'](new C(_0x5549b4),_0x46003b);}),Si(_0x10ddbf,_0x214d7a,_0x4a32f5,_0x4e9d3b,_0x5258f4,_0x4591a2,_0x604fb7,_0x31ac38);}else return _0x214d7a;}else{let _0x3b5316=new S(null);return _0x1829ec['foreach']((_0x5d8ab4,_0x5c532c)=>{const _0x3bfcb3=A(_0x4a32f5,_0x5d8ab4);_0x485f76['isCompleteForPath'](_0x3bfcb3)&&(_0x3b5316=_0x3b5316['set'](_0x5d8ab4,_0x485f76['getNode']()['getChild'](_0x3bfcb3)));}),Si(_0x10ddbf,_0x214d7a,_0x4a32f5,_0x3b5316,_0x5258f4,_0x4591a2,_0x604fb7,_0x31ac38);}}function Au(_0x2f81d5,_0x4f4447,_0x347b42,_0x44315a,_0x55d8c8){const _0x587b21=_0x4f4447['serverCache'],_0x11269b=Lo(_0x4f4447,_0x587b21['getNode'](),_0x587b21['isFullyInitialized']()||v(_0x347b42),_0x587b21['isFiltered']());return Ho(_0x2f81d5,_0x11269b,_0x347b42,_0x44315a,Vo,_0x55d8c8);}function ku(_0x5cf0d0,_0x2584a6,_0x3537f8,_0x1d6521,_0x52bbae,_0x443618){let _0x4bc582;if(yn(_0x1d6521,_0x3537f8)!=null)return _0x2584a6;{const _0x4bcfc0=new ns(_0x1d6521,_0x2584a6,_0x52bbae),_0x3e3077=_0x2584a6['eventCache']['getNode']();let _0x2d5518;if(v(_0x3537f8)||y(_0x3537f8)==='.priority'){let _0x165029;if(_0x2584a6['serverCache']['isFullyInitialized']())_0x165029=mn(_0x1d6521,Ue(_0x2584a6));else{const _0x3d41cd=_0x2584a6['serverCache']['getNode']();f(_0x3d41cd instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x165029=es(_0x1d6521,_0x3d41cd);}_0x165029=_0x165029,_0x2d5518=_0x5cf0d0['filter']['updateFullNode'](_0x3e3077,_0x165029,_0x443618);}else{const _0x2b102d=y(_0x3537f8);let _0x3f1873=ts(_0x1d6521,_0x2b102d,_0x2584a6['serverCache']);_0x3f1873==null&&_0x2584a6['serverCache']['isCompleteForChild'](_0x2b102d)&&(_0x3f1873=_0x3e3077['getImmediateChild'](_0x2b102d)),_0x3f1873!=null?_0x2d5518=_0x5cf0d0['filter']['updateChild'](_0x3e3077,_0x2b102d,_0x3f1873,b(_0x3537f8),_0x4bcfc0,_0x443618):_0x2584a6['eventCache']['getNode']()['hasChild'](_0x2b102d)?_0x2d5518=_0x5cf0d0['filter']['updateChild'](_0x3e3077,_0x2b102d,g['EMPTY_NODE'],b(_0x3537f8),_0x4bcfc0,_0x443618):_0x2d5518=_0x3e3077,_0x2d5518['isEmpty']()&&_0x2584a6['serverCache']['isFullyInitialized']()&&(_0x4bc582=mn(_0x1d6521,Ue(_0x2584a6)),_0x4bc582['isLeafNode']()&&(_0x2d5518=_0x5cf0d0['filter']['updateFullNode'](_0x2d5518,_0x4bc582,_0x443618)));}return _0x4bc582=_0x2584a6['serverCache']['isFullyInitialized']()||yn(_0x1d6521,w())!=null,wt(_0x2584a6,_0x2d5518,_0x4bc582,_0x5cf0d0['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x52d5e9,_0x4c3736){this['query_']=_0x52d5e9,this['eventRegistrations_']=[];const _0x2ef2a2=this['query_']['_queryParams'],_0x37ac50=new Yi(_0x2ef2a2['getIndex']()),_0xcac356=qh(_0x2ef2a2);this['processor_']=wu(_0xcac356);const _0x27d165=_0x4c3736['serverCache'],_0x2c61c3=_0x4c3736['eventCache'],_0xd3a6d4=_0x37ac50['updateFullNode'](g['EMPTY_NODE'],_0x27d165['getNode'](),null),_0x1396dc=_0xcac356['updateFullNode'](g['EMPTY_NODE'],_0x2c61c3['getNode'](),null),_0x2ead9c=new Ce(_0xd3a6d4,_0x27d165['isFullyInitialized'](),_0x37ac50['filtersNodes']()),_0x466428=new Ce(_0x1396dc,_0x2c61c3['isFullyInitialized'](),_0xcac356['filtersNodes']());this['viewCache_']=Dn(_0x466428,_0x2ead9c),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x496f7d){return _0x496f7d['viewCache_']['serverCache']['getNode']();}function Ou(_0x3edd68){return gn(_0x3edd68['viewCache_']);}function Du(_0x4c79cd,_0x296e45){const _0x32d815=Ue(_0x4c79cd['viewCache_']);return _0x32d815&&(_0x4c79cd['query']['_queryParams']['loadsAllData']()||!v(_0x296e45)&&!_0x32d815['getImmediateChild'](y(_0x296e45))['isEmpty']())?_0x32d815['getChild'](_0x296e45):null;}function lr(_0x35eece){return _0x35eece['eventRegistrations_']['length']===0x0;}function Mu(_0x2054ed,_0x618072){_0x2054ed['eventRegistrations_']['push'](_0x618072);}function hr(_0x468a88,_0x4f40fd,_0x2b3709){const _0x13a50c=[];if(_0x2b3709){f(_0x4f40fd==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1edd7d=_0x468a88['query']['_path'];_0x468a88['eventRegistrations_']['forEach'](_0x421eef=>{const _0x56fd78=_0x421eef['createCancelEvent'](_0x2b3709,_0x1edd7d);_0x56fd78&&_0x13a50c['push'](_0x56fd78);});}if(_0x4f40fd){let _0x274b48=[];for(let _0x6f7f55=0x0;_0x6f7f55<_0x468a88['eventRegistrations_']['length'];++_0x6f7f55){const _0x5055b6=_0x468a88['eventRegistrations_'][_0x6f7f55];if(!_0x5055b6['matches'](_0x4f40fd))_0x274b48['push'](_0x5055b6);else{if(_0x4f40fd['hasAnyCallback']()){_0x274b48=_0x274b48['concat'](_0x468a88['eventRegistrations_']['slice'](_0x6f7f55+0x1));break;}}}_0x468a88['eventRegistrations_']=_0x274b48;}else _0x468a88['eventRegistrations_']=[];return _0x13a50c;}function ur(_0x1921fe,_0x538615,_0x4d1d18,_0x37b392){_0x538615['type']===q['MERGE']&&_0x538615['source']['queryId']!==null&&(f(Ue(_0x1921fe['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x1921fe['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x22e15b=_0x1921fe['viewCache_'],_0x1f7e35=Tu(_0x1921fe['processor_'],_0x22e15b,_0x538615,_0x4d1d18,_0x37b392);return Cu(_0x1921fe['processor_'],_0x1f7e35['viewCache']),f(_0x1f7e35['viewCache']['serverCache']['isFullyInitialized']()||!_0x22e15b['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1921fe['viewCache_']=_0x1f7e35['viewCache'],$o(_0x1921fe,_0x1f7e35['changes'],_0x1f7e35['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x4e7bc7,_0x488fbe){const _0x25334e=_0x4e7bc7['viewCache_']['eventCache'],_0x2888d3=[];return _0x25334e['getNode']()['isLeafNode']()||_0x25334e['getNode']()['forEachChild'](R,(_0x4171d5,_0x4de6bd)=>{_0x2888d3['push'](tt(_0x4171d5,_0x4de6bd));}),_0x25334e['isFullyInitialized']()&&_0x2888d3['push'](Oo(_0x25334e['getNode']())),$o(_0x4e7bc7,_0x2888d3,_0x25334e['getNode'](),_0x488fbe);}function $o(_0x2f7711,_0xa323d0,_0x19e012,_0x1b20e2){const _0x3365ad=_0x1b20e2?[_0x1b20e2]:_0x2f7711['eventRegistrations_'];return nu(_0x2f7711['eventGenerator_'],_0xa323d0,_0x19e012,_0x3365ad);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x2a67ef){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x2a67ef;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x5c3bb9){return _0x5c3bb9['views']['size']===0x0;}function is(_0x338ed2,_0x32131f,_0x5a78ff,_0x1c8b7c){const _0x20985e=_0x32131f['source']['queryId'];if(_0x20985e!==null){const _0x5d6d87=_0x338ed2['views']['get'](_0x20985e);return f(_0x5d6d87!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x5d6d87,_0x32131f,_0x5a78ff,_0x1c8b7c);}else{let _0x1434d2=[];for(const _0x142322 of _0x338ed2['views']['values']())_0x1434d2=_0x1434d2['concat'](ur(_0x142322,_0x32131f,_0x5a78ff,_0x1c8b7c));return _0x1434d2;}}function qo(_0x391284,_0x40b9ea,_0x9e3fe8,_0x561199,_0x18f7fc){const _0x4fe68d=_0x40b9ea['_queryIdentifier'],_0x3e8f4b=_0x391284['views']['get'](_0x4fe68d);if(!_0x3e8f4b){let _0x5cdb0d=mn(_0x9e3fe8,_0x18f7fc?_0x561199:null),_0x390785=!0x1;_0x5cdb0d?_0x390785=!0x0:_0x561199 instanceof g?(_0x5cdb0d=es(_0x9e3fe8,_0x561199),_0x390785=!0x1):(_0x5cdb0d=g['EMPTY_NODE'],_0x390785=!0x1);const _0xcf37e1=Dn(new Ce(_0x5cdb0d,_0x390785,!0x1),new Ce(_0x561199,_0x18f7fc,!0x1));return new Nu(_0x40b9ea,_0xcf37e1);}return _0x3e8f4b;}function Wu(_0x49e8fd,_0x450478,_0x5853ee,_0x181a2a,_0x743d71,_0x2914bd){const _0x1d581a=qo(_0x49e8fd,_0x450478,_0x181a2a,_0x743d71,_0x2914bd);return _0x49e8fd['views']['has'](_0x450478['_queryIdentifier'])||_0x49e8fd['views']['set'](_0x450478['_queryIdentifier'],_0x1d581a),Mu(_0x1d581a,_0x5853ee),Lu(_0x1d581a,_0x5853ee);}function Bu(_0x436982,_0x120e5d,_0xb3c4ec,_0x2f617a){const _0x478f7e=_0x120e5d['_queryIdentifier'],_0x3bfab4=[];let _0x21fe4e=[];const _0x3c922c=Te(_0x436982);if(_0x478f7e==='default'){for(const [_0x1098ca,_0x4a90eb]of _0x436982['views']['entries']())_0x21fe4e=_0x21fe4e['concat'](hr(_0x4a90eb,_0xb3c4ec,_0x2f617a)),lr(_0x4a90eb)&&(_0x436982['views']['delete'](_0x1098ca),_0x4a90eb['query']['_queryParams']['loadsAllData']()||_0x3bfab4['push'](_0x4a90eb['query']));}else{const _0x2cfb87=_0x436982['views']['get'](_0x478f7e);_0x2cfb87&&(_0x21fe4e=_0x21fe4e['concat'](hr(_0x2cfb87,_0xb3c4ec,_0x2f617a)),lr(_0x2cfb87)&&(_0x436982['views']['delete'](_0x478f7e),_0x2cfb87['query']['_queryParams']['loadsAllData']()||_0x3bfab4['push'](_0x2cfb87['query'])));}return _0x3c922c&&!Te(_0x436982)&&_0x3bfab4['push'](new(Fu())(_0x120e5d['_repo'],_0x120e5d['_path'])),{'removed':_0x3bfab4,'events':_0x21fe4e};}function zo(_0x271876){const _0x19303c=[];for(const _0x497b82 of _0x271876['views']['values']())_0x497b82['query']['_queryParams']['loadsAllData']()||_0x19303c['push'](_0x497b82);return _0x19303c;}function Ee(_0x207674,_0xf6e611){let _0x1c4875=null;for(const _0x37d6e3 of _0x207674['views']['values']())_0x1c4875=_0x1c4875||Du(_0x37d6e3,_0xf6e611);return _0x1c4875;}function jo(_0x75147c,_0x160138){if(_0x160138['_queryParams']['loadsAllData']())return Ln(_0x75147c);{const _0x45fa4d=_0x160138['_queryIdentifier'];return _0x75147c['views']['get'](_0x45fa4d);}}function Ko(_0x46ac11,_0x5d3b1c){return jo(_0x46ac11,_0x5d3b1c)!=null;}function Te(_0x560fa0){return Ln(_0x560fa0)!=null;}function Ln(_0x5eb79d){for(const _0xcc9025 of _0x5eb79d['views']['values']())if(_0xcc9025['query']['_queryParams']['loadsAllData']())return _0xcc9025;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x355293){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x355293;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x2c999d){this['listenProvider_']=_0x2c999d,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x7559c7,_0x5c8e5b,_0x3e96ba,_0x5b6b39,_0x531146){return ou(_0x7559c7['pendingWriteTree_'],_0x5c8e5b,_0x3e96ba,_0x5b6b39,_0x531146),_0x531146?ht(_0x7559c7,new Fe(Ji(),_0x5c8e5b,_0x3e96ba)):[];}function Gu(_0x3fc01f,_0x259f42,_0x5e0711,_0x4e3b17){au(_0x3fc01f['pendingWriteTree_'],_0x259f42,_0x5e0711,_0x4e3b17);const _0x510874=S['fromObject'](_0x5e0711);return ht(_0x3fc01f,new nt(Ji(),_0x259f42,_0x510874));}function pe(_0x29eb8e,_0x12f01,_0xde550b=!0x1){const _0x585626=cu(_0x29eb8e['pendingWriteTree_'],_0x12f01);if(lu(_0x29eb8e['pendingWriteTree_'],_0x12f01)){let _0x4082ef=new S(null);return _0x585626['snap']!=null?_0x4082ef=_0x4082ef['set'](w(),!0x0):x(_0x585626['children'],_0xbcb8fd=>{_0x4082ef=_0x4082ef['set'](new C(_0xbcb8fd),!0x0);}),ht(_0x29eb8e,new _n(_0x585626['path'],_0x4082ef,_0xde550b));}else return[];}function $t(_0x27c488,_0x2f4d27,_0xdcbcc){return ht(_0x27c488,new Fe(Xi(),_0x2f4d27,_0xdcbcc));}function qu(_0x5954fa,_0x6d20f0,_0x51d819){const _0x186c04=S['fromObject'](_0x51d819);return ht(_0x5954fa,new nt(Xi(),_0x6d20f0,_0x186c04));}function zu(_0x3ad9b4,_0x2cf017){return ht(_0x3ad9b4,new Dt(Xi(),_0x2cf017));}function ju(_0x3b70aa,_0x5508f9,_0x1797e9){const _0x555409=rs(_0x3b70aa,_0x1797e9);if(_0x555409){const _0x1cee08=os(_0x555409),_0xaae8e6=_0x1cee08['path'],_0x179936=_0x1cee08['queryId'],_0x3c6171=F(_0xaae8e6,_0x5508f9),_0x1454c5=new Dt(Zi(_0x179936),_0x3c6171);return as(_0x3b70aa,_0xaae8e6,_0x1454c5);}else return[];}function wn(_0x3b70a3,_0x34f80e,_0x2a14c1,_0x3742d0,_0x24291c=!0x1){const _0xefd239=_0x34f80e['_path'],_0x417263=_0x3b70a3['syncPointTree_']['get'](_0xefd239);let _0x5d8c5a=[];if(_0x417263&&(_0x34f80e['_queryIdentifier']==='default'||Ko(_0x417263,_0x34f80e))){const _0x4fe25d=Bu(_0x417263,_0x34f80e,_0x2a14c1,_0x3742d0);Uu(_0x417263)&&(_0x3b70a3['syncPointTree_']=_0x3b70a3['syncPointTree_']['remove'](_0xefd239));const _0x473d43=_0x4fe25d['removed'];if(_0x5d8c5a=_0x4fe25d['events'],!_0x24291c){const _0x3abf5d=_0x473d43['findIndex'](_0x2e0a65=>_0x2e0a65['_queryParams']['loadsAllData']())!==-0x1,_0x416157=_0x3b70a3['syncPointTree_']['findOnPath'](_0xefd239,(_0x121adc,_0x4fdaec)=>Te(_0x4fdaec));if(_0x3abf5d&&!_0x416157){const _0x5c423e=_0x3b70a3['syncPointTree_']['subtree'](_0xefd239);if(!_0x5c423e['isEmpty']()){const _0x3eb874=Qu(_0x5c423e);for(let _0xe8334b=0x0;_0xe8334b<_0x3eb874['length'];++_0xe8334b){const _0x10c85b=_0x3eb874[_0xe8334b],_0x558036=_0x10c85b['query'],_0x54e2e9=Xo(_0x3b70a3,_0x10c85b);_0x3b70a3['listenProvider_']['startListening'](Tt(_0x558036),Mt(_0x3b70a3,_0x558036),_0x54e2e9['hashFn'],_0x54e2e9['onComplete']);}}}!_0x416157&&_0x473d43['length']>0x0&&!_0x3742d0&&(_0x3abf5d?_0x3b70a3['listenProvider_']['stopListening'](Tt(_0x34f80e),null):_0x473d43['forEach'](_0x2fa458=>{const _0x27594a=_0x3b70a3['queryToTagMap']['get'](Fn(_0x2fa458));_0x3b70a3['listenProvider_']['stopListening'](Tt(_0x2fa458),_0x27594a);}));}Ju(_0x3b70a3,_0x473d43);}return _0x5d8c5a;}function Yo(_0x4ac94a,_0x164049,_0x15bf0a,_0x5b1d9e){const _0x1bce42=rs(_0x4ac94a,_0x5b1d9e);if(_0x1bce42!=null){const _0x34b289=os(_0x1bce42),_0x419558=_0x34b289['path'],_0x4c6b7b=_0x34b289['queryId'],_0x4a8a2e=F(_0x419558,_0x164049),_0x5ae0f5=new Fe(Zi(_0x4c6b7b),_0x4a8a2e,_0x15bf0a);return as(_0x4ac94a,_0x419558,_0x5ae0f5);}else return[];}function Ku(_0x107e38,_0x64b7b7,_0x4fa572,_0x2d44bc){const _0x10e16f=rs(_0x107e38,_0x2d44bc);if(_0x10e16f){const _0x3ce256=os(_0x10e16f),_0x5c7fb4=_0x3ce256['path'],_0x2916b7=_0x3ce256['queryId'],_0x58d7fd=F(_0x5c7fb4,_0x64b7b7),_0xa0b5e5=S['fromObject'](_0x4fa572),_0x28daaf=new nt(Zi(_0x2916b7),_0x58d7fd,_0xa0b5e5);return as(_0x107e38,_0x5c7fb4,_0x28daaf);}else return[];}function bi(_0x4d0b5e,_0x3b93ac,_0x5b6382,_0x2b2382=!0x1){const _0x109be6=_0x3b93ac['_path'];let _0x2e7620=null,_0x2162af=!0x1;_0x4d0b5e['syncPointTree_']['foreachOnPath'](_0x109be6,(_0x265327,_0x2f5de8)=>{const _0x10e1bb=F(_0x265327,_0x109be6);_0x2e7620=_0x2e7620||Ee(_0x2f5de8,_0x10e1bb),_0x2162af=_0x2162af||Te(_0x2f5de8);});let _0x223b39=_0x4d0b5e['syncPointTree_']['get'](_0x109be6);_0x223b39?(_0x2162af=_0x2162af||Te(_0x223b39),_0x2e7620=_0x2e7620||Ee(_0x223b39,w())):(_0x223b39=new Go(),_0x4d0b5e['syncPointTree_']=_0x4d0b5e['syncPointTree_']['set'](_0x109be6,_0x223b39));let _0x193dea;_0x2e7620!=null?_0x193dea=!0x0:(_0x193dea=!0x1,_0x2e7620=g['EMPTY_NODE'],_0x4d0b5e['syncPointTree_']['subtree'](_0x109be6)['foreachChild']((_0x2ab070,_0x2c1d3d)=>{const _0x49c3b0=Ee(_0x2c1d3d,w());_0x49c3b0&&(_0x2e7620=_0x2e7620['updateImmediateChild'](_0x2ab070,_0x49c3b0));}));const _0x2df6e4=Ko(_0x223b39,_0x3b93ac);if(!_0x2df6e4&&!_0x3b93ac['_queryParams']['loadsAllData']()){const _0x5b6865=Fn(_0x3b93ac);f(!_0x4d0b5e['queryToTagMap']['has'](_0x5b6865),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x28b5fe=Xu();_0x4d0b5e['queryToTagMap']['set'](_0x5b6865,_0x28b5fe),_0x4d0b5e['tagToQueryMap']['set'](_0x28b5fe,_0x5b6865);}const _0x43144b=Mn(_0x4d0b5e['pendingWriteTree_'],_0x109be6);let _0x312332=Wu(_0x223b39,_0x3b93ac,_0x5b6382,_0x43144b,_0x2e7620,_0x193dea);if(!_0x2df6e4&&!_0x2162af&&!_0x2b2382){const _0x234488=jo(_0x223b39,_0x3b93ac);_0x312332=_0x312332['concat'](Zu(_0x4d0b5e,_0x3b93ac,_0x234488));}return _0x312332;}function xn(_0x4e2f0f,_0x46ec40,_0x19b6a7){const _0x2f0e8b=_0x4e2f0f['pendingWriteTree_'],_0x5ed369=_0x4e2f0f['syncPointTree_']['findOnPath'](_0x46ec40,(_0x1184d7,_0x557de6)=>{const _0x545476=F(_0x1184d7,_0x46ec40),_0x2cbeb3=Ee(_0x557de6,_0x545476);if(_0x2cbeb3)return _0x2cbeb3;});return Uo(_0x2f0e8b,_0x46ec40,_0x5ed369,_0x19b6a7,!0x0);}function Yu(_0x48a4b7,_0x36427f){const _0x1590b3=_0x36427f['_path'];let _0x3f2899=null;_0x48a4b7['syncPointTree_']['foreachOnPath'](_0x1590b3,(_0x12b5b4,_0x5609f5)=>{const _0x24d7e9=F(_0x12b5b4,_0x1590b3);_0x3f2899=_0x3f2899||Ee(_0x5609f5,_0x24d7e9);});let _0x4a585b=_0x48a4b7['syncPointTree_']['get'](_0x1590b3);_0x4a585b?_0x3f2899=_0x3f2899||Ee(_0x4a585b,w()):(_0x4a585b=new Go(),_0x48a4b7['syncPointTree_']=_0x48a4b7['syncPointTree_']['set'](_0x1590b3,_0x4a585b));const _0x104c4a=_0x3f2899!=null,_0x1ff619=_0x104c4a?new Ce(_0x3f2899,!0x0,!0x1):null,_0x3a5cb9=Mn(_0x48a4b7['pendingWriteTree_'],_0x36427f['_path']),_0x2f1065=qo(_0x4a585b,_0x36427f,_0x3a5cb9,_0x104c4a?_0x1ff619['getNode']():g['EMPTY_NODE'],_0x104c4a);return Ou(_0x2f1065);}function ht(_0x1a39c6,_0x5a101f){return Qo(_0x5a101f,_0x1a39c6['syncPointTree_'],null,Mn(_0x1a39c6['pendingWriteTree_'],w()));}function Qo(_0x4e0c8d,_0x47f136,_0xf0d6b4,_0x1bfb44){if(v(_0x4e0c8d['path']))return Jo(_0x4e0c8d,_0x47f136,_0xf0d6b4,_0x1bfb44);{const _0x3dd188=_0x47f136['get'](w());_0xf0d6b4==null&&_0x3dd188!=null&&(_0xf0d6b4=Ee(_0x3dd188,w()));let _0x465e44=[];const _0x587bba=y(_0x4e0c8d['path']),_0x5e861a=_0x4e0c8d['operationForChild'](_0x587bba),_0x11c8e0=_0x47f136['children']['get'](_0x587bba);if(_0x11c8e0&&_0x5e861a){const _0x5c6580=_0xf0d6b4?_0xf0d6b4['getImmediateChild'](_0x587bba):null,_0x37725b=Wo(_0x1bfb44,_0x587bba);_0x465e44=_0x465e44['concat'](Qo(_0x5e861a,_0x11c8e0,_0x5c6580,_0x37725b));}return _0x3dd188&&(_0x465e44=_0x465e44['concat'](is(_0x3dd188,_0x4e0c8d,_0x1bfb44,_0xf0d6b4))),_0x465e44;}}function Jo(_0xe58189,_0x542f3c,_0x37fed6,_0xd8f3ce){const _0x13771b=_0x542f3c['get'](w());_0x37fed6==null&&_0x13771b!=null&&(_0x37fed6=Ee(_0x13771b,w()));let _0x220ce3=[];return _0x542f3c['children']['inorderTraversal']((_0x2e2a2b,_0x51ff95)=>{const _0x5bf0da=_0x37fed6?_0x37fed6['getImmediateChild'](_0x2e2a2b):null,_0x517083=Wo(_0xd8f3ce,_0x2e2a2b),_0x5c4e41=_0xe58189['operationForChild'](_0x2e2a2b);_0x5c4e41&&(_0x220ce3=_0x220ce3['concat'](Jo(_0x5c4e41,_0x51ff95,_0x5bf0da,_0x517083)));}),_0x13771b&&(_0x220ce3=_0x220ce3['concat'](is(_0x13771b,_0xe58189,_0xd8f3ce,_0x37fed6))),_0x220ce3;}function Xo(_0x269e0e,_0x436c2d){const _0x2a10f6=_0x436c2d['query'],_0x509a06=Mt(_0x269e0e,_0x2a10f6);return{'hashFn':()=>(Pu(_0x436c2d)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2b0cb2=>{if(_0x2b0cb2==='ok')return _0x509a06?ju(_0x269e0e,_0x2a10f6['_path'],_0x509a06):zu(_0x269e0e,_0x2a10f6['_path']);{const _0x3c8e41=ql(_0x2b0cb2,_0x2a10f6);return wn(_0x269e0e,_0x2a10f6,null,_0x3c8e41);}}};}function Mt(_0x19b8c8,_0x933e55){const _0x2bbe6c=Fn(_0x933e55);return _0x19b8c8['queryToTagMap']['get'](_0x2bbe6c);}function Fn(_0x2810a3){return _0x2810a3['_path']['toString']()+'$'+_0x2810a3['_queryIdentifier'];}function rs(_0x3f509f,_0x151d7c){return _0x3f509f['tagToQueryMap']['get'](_0x151d7c);}function os(_0x5dff3d){const _0x286f07=_0x5dff3d['indexOf']('$');return f(_0x286f07!==-0x1&&_0x286f07<_0x5dff3d['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5dff3d['substr'](_0x286f07+0x1),'path':new C(_0x5dff3d['substr'](0x0,_0x286f07))};}function as(_0x5aecf2,_0x5ea9cc,_0x57f489){const _0x354d84=_0x5aecf2['syncPointTree_']['get'](_0x5ea9cc);f(_0x354d84,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1e6109=Mn(_0x5aecf2['pendingWriteTree_'],_0x5ea9cc);return is(_0x354d84,_0x57f489,_0x1e6109,null);}function Qu(_0x2dca4e){return _0x2dca4e['fold']((_0x4c5afc,_0xe62e5d,_0x1c26a7)=>{if(_0xe62e5d&&Te(_0xe62e5d))return[Ln(_0xe62e5d)];{let _0x558343=[];return _0xe62e5d&&(_0x558343=zo(_0xe62e5d)),x(_0x1c26a7,(_0x3f6c97,_0xc42d7c)=>{_0x558343=_0x558343['concat'](_0xc42d7c);}),_0x558343;}});}function Tt(_0x252690){return _0x252690['_queryParams']['loadsAllData']()&&!_0x252690['_queryParams']['isDefault']()?new(Hu())(_0x252690['_repo'],_0x252690['_path']):_0x252690;}function Ju(_0x2f0c9a,_0x43297a){for(let _0x5ed49e=0x0;_0x5ed49e<_0x43297a['length'];++_0x5ed49e){const _0x40a64b=_0x43297a[_0x5ed49e];if(!_0x40a64b['_queryParams']['loadsAllData']()){const _0xe9d561=Fn(_0x40a64b),_0x179c13=_0x2f0c9a['queryToTagMap']['get'](_0xe9d561);_0x2f0c9a['queryToTagMap']['delete'](_0xe9d561),_0x2f0c9a['tagToQueryMap']['delete'](_0x179c13);}}}function Xu(){return $u++;}function Zu(_0x1c7308,_0x510ac3,_0x31ac52){const _0xe90b09=_0x510ac3['_path'],_0x5ea252=Mt(_0x1c7308,_0x510ac3),_0x3175f7=Xo(_0x1c7308,_0x31ac52),_0x5cdc0c=_0x1c7308['listenProvider_']['startListening'](Tt(_0x510ac3),_0x5ea252,_0x3175f7['hashFn'],_0x3175f7['onComplete']),_0x445405=_0x1c7308['syncPointTree_']['subtree'](_0xe90b09);if(_0x5ea252)f(!Te(_0x445405['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x4acfbf=_0x445405['fold']((_0x4dfda9,_0x5b817f,_0x1dcd11)=>{if(!v(_0x4dfda9)&&_0x5b817f&&Te(_0x5b817f))return[Ln(_0x5b817f)['query']];{let _0x28a7f4=[];return _0x5b817f&&(_0x28a7f4=_0x28a7f4['concat'](zo(_0x5b817f)['map'](_0x140d2c=>_0x140d2c['query']))),x(_0x1dcd11,(_0x58cc7e,_0x4a7e72)=>{_0x28a7f4=_0x28a7f4['concat'](_0x4a7e72);}),_0x28a7f4;}});for(let _0x589ca1=0x0;_0x589ca1<_0x4acfbf['length'];++_0x589ca1){const _0x3ef9a0=_0x4acfbf[_0x589ca1];_0x1c7308['listenProvider_']['stopListening'](Tt(_0x3ef9a0),Mt(_0x1c7308,_0x3ef9a0));}}return _0x5cdc0c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x311c51){this['node_']=_0x311c51;}['getImmediateChild'](_0xe371b7){const _0x5ba33c=this['node_']['getImmediateChild'](_0xe371b7);return new cs(_0x5ba33c);}['node'](){return this['node_'];}}class ls{constructor(_0x41db7c,_0x1c96e6){this['syncTree_']=_0x41db7c,this['path_']=_0x1c96e6;}['getImmediateChild'](_0x5c1790){const _0x53f874=A(this['path_'],_0x5c1790);return new ls(this['syncTree_'],_0x53f874);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x33880d){return _0x33880d=_0x33880d||{},_0x33880d['timestamp']=_0x33880d['timestamp']||new Date()['getTime'](),_0x33880d;},fr=function(_0x5bdf45,_0x157034,_0x44a0e0){if(!_0x5bdf45||typeof _0x5bdf45!='object')return _0x5bdf45;if(f('.sv'in _0x5bdf45,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5bdf45['.sv']=='string')return td(_0x5bdf45['.sv'],_0x157034,_0x44a0e0);if(typeof _0x5bdf45['.sv']=='object')return nd(_0x5bdf45['.sv'],_0x157034);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5bdf45,null,0x2));},td=function(_0x1f7ac7,_0x4d14d1,_0xec1f09){switch(_0x1f7ac7){case'timestamp':return _0xec1f09['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1f7ac7);}},nd=function(_0x50c2af,_0x1f930f,_0x4e5666){_0x50c2af['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x50c2af,null,0x2));const _0x50d8c7=_0x50c2af['increment'];typeof _0x50d8c7!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x50d8c7);const _0x21b420=_0x1f930f['node']();if(f(_0x21b420!==null&&typeof _0x21b420<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x21b420['isLeafNode']())return _0x50d8c7;const _0x22bb62=_0x21b420['getValue']();return typeof _0x22bb62!='number'?_0x50d8c7:_0x22bb62+_0x50d8c7;},Zo=function(_0x29acd6,_0x4a3114,_0x41bf00,_0x3501a1){return us(_0x4a3114,new ls(_0x41bf00,_0x29acd6),_0x3501a1);},hs=function(_0xd8a787,_0x1fc139,_0x334830){return us(_0xd8a787,new cs(_0x1fc139),_0x334830);};function us(_0x146f75,_0x178840,_0x21ef8a){const _0x34c051=_0x146f75['getPriority']()['val'](),_0x12d83c=fr(_0x34c051,_0x178840['getImmediateChild']('.priority'),_0x21ef8a);let _0x292521;if(_0x146f75['isLeafNode']()){const _0x2da7ae=_0x146f75,_0xbc4f8c=fr(_0x2da7ae['getValue'](),_0x178840,_0x21ef8a);return _0xbc4f8c!==_0x2da7ae['getValue']()||_0x12d83c!==_0x2da7ae['getPriority']()['val']()?new D(_0xbc4f8c,N(_0x12d83c)):_0x146f75;}else{const _0x4fa251=_0x146f75;return _0x292521=_0x4fa251,_0x12d83c!==_0x4fa251['getPriority']()['val']()&&(_0x292521=_0x292521['updatePriority'](new D(_0x12d83c))),_0x4fa251['forEachChild'](R,(_0x2adcc0,_0x432b08)=>{const _0x1d357d=us(_0x432b08,_0x178840['getImmediateChild'](_0x2adcc0),_0x21ef8a);_0x1d357d!==_0x432b08&&(_0x292521=_0x292521['updateImmediateChild'](_0x2adcc0,_0x1d357d));}),_0x292521;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x30aacd='',_0x41bb99=null,_0x425746={'children':{},'childCount':0x0}){this['name']=_0x30aacd,this['parent']=_0x41bb99,this['node']=_0x425746;}}function Un(_0x5aaa07,_0x1ad42d){let _0x2309a7=_0x1ad42d instanceof C?_0x1ad42d:new C(_0x1ad42d),_0x1f2662=_0x5aaa07,_0x56abdc=y(_0x2309a7);for(;_0x56abdc!==null;){const _0x28353d=Oe(_0x1f2662['node']['children'],_0x56abdc)||{'children':{},'childCount':0x0};_0x1f2662=new ds(_0x56abdc,_0x1f2662,_0x28353d),_0x2309a7=b(_0x2309a7),_0x56abdc=y(_0x2309a7);}return _0x1f2662;}function Ge(_0x22c562){return _0x22c562['node']['value'];}function fs(_0x1a786c,_0x7b4cf7){_0x1a786c['node']['value']=_0x7b4cf7,Ri(_0x1a786c);}function ea(_0x16f8fa){return _0x16f8fa['node']['childCount']>0x0;}function id(_0xdf8d19){return Ge(_0xdf8d19)===void 0x0&&!ea(_0xdf8d19);}function Wn(_0x306bae,_0x170fb9){x(_0x306bae['node']['children'],(_0x35b6a2,_0x1ab255)=>{_0x170fb9(new ds(_0x35b6a2,_0x306bae,_0x1ab255));});}function ta(_0x4a6e6d,_0x23e768,_0x4e97de,_0x2ea643){_0x4e97de&&_0x23e768(_0x4a6e6d),Wn(_0x4a6e6d,_0x49ad13=>{ta(_0x49ad13,_0x23e768,!0x0);});}function sd(_0x173cc6,_0x383922,_0x57896f){let _0x4d69e4=_0x173cc6['parent'];for(;_0x4d69e4!==null;){if(_0x383922(_0x4d69e4))return!0x0;_0x4d69e4=_0x4d69e4['parent'];}return!0x1;}function Gt(_0x54b9ec){return new C(_0x54b9ec['parent']===null?_0x54b9ec['name']:Gt(_0x54b9ec['parent'])+'/'+_0x54b9ec['name']);}function Ri(_0x3ef669){_0x3ef669['parent']!==null&&rd(_0x3ef669['parent'],_0x3ef669['name'],_0x3ef669);}function rd(_0x29b5d8,_0x385302,_0x305af6){const _0x16e3d3=id(_0x305af6),_0x596791=Y(_0x29b5d8['node']['children'],_0x385302);_0x16e3d3&&_0x596791?(delete _0x29b5d8['node']['children'][_0x385302],_0x29b5d8['node']['childCount']--,Ri(_0x29b5d8)):!_0x16e3d3&&!_0x596791&&(_0x29b5d8['node']['children'][_0x385302]=_0x305af6['node'],_0x29b5d8['node']['childCount']++,Ri(_0x29b5d8));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x8f105a){return typeof _0x8f105a=='string'&&_0x8f105a['length']!==0x0&&!od['test'](_0x8f105a);},na=function(_0x4d22ea){return typeof _0x4d22ea=='string'&&_0x4d22ea['length']!==0x0&&!ad['test'](_0x4d22ea);},cd=function(_0x1991ad){return _0x1991ad&&(_0x1991ad=_0x1991ad['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x1991ad);},Cn=function(_0x5104c0){return _0x5104c0===null||typeof _0x5104c0=='string'||typeof _0x5104c0=='number'&&!Wi(_0x5104c0)||_0x5104c0&&typeof _0x5104c0=='object'&&Y(_0x5104c0,'.sv');},qt=function(_0x29f6b9,_0x3edba6,_0x4fc265,_0x5c6e92){_0x5c6e92&&_0x3edba6===void 0x0||zt(Nn(_0x29f6b9,'value'),_0x3edba6,_0x4fc265);},zt=function(_0x4efe80,_0x5d0c3a,_0x25cbe4){const _0xb94945=_0x25cbe4 instanceof C?new Sh(_0x25cbe4,_0x4efe80):_0x25cbe4;if(_0x5d0c3a===void 0x0)throw new Error(_0x4efe80+'contains\x20undefined\x20'+Ne(_0xb94945));if(typeof _0x5d0c3a=='function')throw new Error(_0x4efe80+'contains\x20a\x20function\x20'+Ne(_0xb94945)+'\x20with\x20contents\x20=\x20'+_0x5d0c3a['toString']());if(Wi(_0x5d0c3a))throw new Error(_0x4efe80+'contains\x20'+_0x5d0c3a['toString']()+'\x20'+Ne(_0xb94945));if(typeof _0x5d0c3a=='string'&&_0x5d0c3a['length']>oi/0x3&&Pn(_0x5d0c3a)>oi)throw new Error(_0x4efe80+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0xb94945)+'\x20(\x27'+_0x5d0c3a['substring'](0x0,0x32)+'...\x27)');if(_0x5d0c3a&&typeof _0x5d0c3a=='object'){let _0x1a11ca=!0x1,_0x394c7b=!0x1;if(x(_0x5d0c3a,(_0x29a7a4,_0x327f17)=>{if(_0x29a7a4==='.value')_0x1a11ca=!0x0;else{if(_0x29a7a4!=='.priority'&&_0x29a7a4!=='.sv'&&(_0x394c7b=!0x0,!ps(_0x29a7a4)))throw new Error(_0x4efe80+'\x20contains\x20an\x20invalid\x20key\x20('+_0x29a7a4+')\x20'+Ne(_0xb94945)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0xb94945,_0x29a7a4),zt(_0x4efe80,_0x327f17,_0xb94945),Rh(_0xb94945);}),_0x1a11ca&&_0x394c7b)throw new Error(_0x4efe80+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0xb94945)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x5f5620,_0x2f7f6e){let _0x4c95be,_0x5725ef;for(_0x4c95be=0x0;_0x4c95be<_0x2f7f6e['length'];_0x4c95be++){_0x5725ef=_0x2f7f6e[_0x4c95be];const _0x2ae522=kt(_0x5725ef);for(let _0x83f3f0=0x0;_0x83f3f0<_0x2ae522['length'];_0x83f3f0++)if(!(_0x2ae522[_0x83f3f0]==='.priority'&&_0x83f3f0===_0x2ae522['length']-0x1)){if(!ps(_0x2ae522[_0x83f3f0]))throw new Error(_0x5f5620+'contains\x20an\x20invalid\x20key\x20('+_0x2ae522[_0x83f3f0]+')\x20in\x20path\x20'+_0x5725ef['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x2f7f6e['sort'](Th);let _0x246c75=null;for(_0x4c95be=0x0;_0x4c95be<_0x2f7f6e['length'];_0x4c95be++){if(_0x5725ef=_0x2f7f6e[_0x4c95be],_0x246c75!==null&&$(_0x246c75,_0x5725ef))throw new Error(_0x5f5620+'contains\x20a\x20path\x20'+_0x246c75['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5725ef['toString']());_0x246c75=_0x5725ef;}},hd=function(_0x4232f7,_0x45a27a,_0x35de44,_0x548d80){const _0x2e8350=Nn(_0x4232f7,'values');if(!(_0x45a27a&&typeof _0x45a27a=='object')||Array['isArray'](_0x45a27a))throw new Error(_0x2e8350+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5c8a66=[];x(_0x45a27a,(_0x22c425,_0x3e89f2)=>{const _0x19a8aa=new C(_0x22c425);if(zt(_0x2e8350,_0x3e89f2,A(_0x35de44,_0x19a8aa)),Gi(_0x19a8aa)==='.priority'&&!Cn(_0x3e89f2))throw new Error(_0x2e8350+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x19a8aa['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5c8a66['push'](_0x19a8aa);}),ld(_0x2e8350,_0x5c8a66);},_s=function(_0x3f487b,_0x2ddf6b,_0x4e1942,_0x2378f3){if(!na(_0x4e1942))throw new Error(Nn(_0x3f487b,_0x2ddf6b)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4e1942+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x3ded81,_0x5ba00a,_0x31a865,_0x2d6834){_0x31a865&&(_0x31a865=_0x31a865['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x3ded81,_0x5ba00a,_0x31a865);},gs=function(_0x8226c3,_0x15c74d){if(y(_0x15c74d)==='.info')throw new Error(_0x8226c3+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x3dcfab,_0x5c19a0){const _0x4ea2d5=_0x5c19a0['path']['toString']();if(typeof _0x5c19a0['repoInfo']['host']!='string'||_0x5c19a0['repoInfo']['host']['length']===0x0||!ps(_0x5c19a0['repoInfo']['namespace'])&&_0x5c19a0['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4ea2d5['length']!==0x0&&!cd(_0x4ea2d5))throw new Error(Nn(_0x3dcfab,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x1e43af,_0x1f370d){let _0x89e7b7=null;for(let _0x2661a6=0x0;_0x2661a6<_0x1f370d['length'];_0x2661a6++){const _0x58b36b=_0x1f370d[_0x2661a6],_0x87e5c0=_0x58b36b['getPath']();_0x89e7b7!==null&&!qi(_0x87e5c0,_0x89e7b7['path'])&&(_0x1e43af['eventLists_']['push'](_0x89e7b7),_0x89e7b7=null),_0x89e7b7===null&&(_0x89e7b7={'events':[],'path':_0x87e5c0}),_0x89e7b7['events']['push'](_0x58b36b);}_0x89e7b7&&_0x1e43af['eventLists_']['push'](_0x89e7b7);}function ia(_0x17e860,_0x310229,_0x168940){Bn(_0x17e860,_0x168940),sa(_0x17e860,_0x3dd9c1=>qi(_0x3dd9c1,_0x310229));}function V(_0x456f49,_0x6101a4,_0x485f10){Bn(_0x456f49,_0x485f10),sa(_0x456f49,_0x493db3=>$(_0x493db3,_0x6101a4)||$(_0x6101a4,_0x493db3));}function sa(_0x426dd3,_0x29f8f0){_0x426dd3['recursionDepth_']++;let _0x218d4f=!0x0;for(let _0x270814=0x0;_0x270814<_0x426dd3['eventLists_']['length'];_0x270814++){const _0x20f1b6=_0x426dd3['eventLists_'][_0x270814];if(_0x20f1b6){const _0x52b2df=_0x20f1b6['path'];_0x29f8f0(_0x52b2df)?(pd(_0x426dd3['eventLists_'][_0x270814]),_0x426dd3['eventLists_'][_0x270814]=null):_0x218d4f=!0x1;}}_0x218d4f&&(_0x426dd3['eventLists_']=[]),_0x426dd3['recursionDepth_']--;}function pd(_0x5b42f3){for(let _0x24e90c=0x0;_0x24e90c<_0x5b42f3['events']['length'];_0x24e90c++){const _0x2a4043=_0x5b42f3['events'][_0x24e90c];if(_0x2a4043!==null){_0x5b42f3['events'][_0x24e90c]=null;const _0x2d8484=_0x2a4043['getEventRunner']();Et&&L('event:\x20'+_0x2a4043['toString']()),lt(_0x2d8484);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x1e9f9d,_0x5372b3,_0x40ea1e,_0x203017){this['repoInfo_']=_0x1e9f9d,this['forceRestClient_']=_0x5372b3,this['authTokenProvider_']=_0x40ea1e,this['appCheckProvider_']=_0x203017,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x307041,_0x1554cc,_0x3b881b){if(_0x307041['stats_']=Hi(_0x307041['repoInfo_']),_0x307041['forceRestClient_']||Yl())_0x307041['server_']=new fn(_0x307041['repoInfo_'],(_0x5da82f,_0xe0c20,_0x23b301,_0x24b350)=>{pr(_0x307041,_0x5da82f,_0xe0c20,_0x23b301,_0x24b350);},_0x307041['authTokenProvider_'],_0x307041['appCheckProvider_']),setTimeout(()=>_r(_0x307041,!0x0),0x0);else{if(typeof _0x3b881b<'u'&&_0x3b881b!==null){if(typeof _0x3b881b!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x3b881b);}catch(_0x102001){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x102001);}}_0x307041['persistentConnection_']=new ie(_0x307041['repoInfo_'],_0x1554cc,(_0x28cfbc,_0x444a98,_0x36e8dc,_0x2c7e00)=>{pr(_0x307041,_0x28cfbc,_0x444a98,_0x36e8dc,_0x2c7e00);},_0x217c72=>{_r(_0x307041,_0x217c72);},_0x5a6532=>{yd(_0x307041,_0x5a6532);},_0x307041['authTokenProvider_'],_0x307041['appCheckProvider_'],_0x3b881b),_0x307041['server_']=_0x307041['persistentConnection_'];}_0x307041['authTokenProvider_']['addTokenChangeListener'](_0x55ed0c=>{_0x307041['server_']['refreshAuthToken'](_0x55ed0c);}),_0x307041['appCheckProvider_']['addTokenChangeListener'](_0x35e070=>{_0x307041['server_']['refreshAppCheckToken'](_0x35e070['token']);}),_0x307041['statsReporter_']=eh(_0x307041['repoInfo_'],()=>new eu(_0x307041['stats_'],_0x307041['server_'])),_0x307041['infoData_']=new Yh(),_0x307041['infoSyncTree_']=new dr({'startListening':(_0x316753,_0x159025,_0x3de9ec,_0x5c288c)=>{let _0x15ad28=[];const _0x207d06=_0x307041['infoData_']['getNode'](_0x316753['_path']);return _0x207d06['isEmpty']()||(_0x15ad28=$t(_0x307041['infoSyncTree_'],_0x316753['_path'],_0x207d06),setTimeout(()=>{_0x5c288c('ok');},0x0)),_0x15ad28;},'stopListening':()=>{}}),ms(_0x307041,'connected',!0x1),_0x307041['serverSyncTree_']=new dr({'startListening':(_0x5f0a49,_0x4c7885,_0x5809f2,_0x1bbb93)=>(_0x307041['server_']['listen'](_0x5f0a49,_0x5809f2,_0x4c7885,(_0x5490f8,_0x278eb8)=>{const _0xbc3de7=_0x1bbb93(_0x5490f8,_0x278eb8);V(_0x307041['eventQueue_'],_0x5f0a49['_path'],_0xbc3de7);}),[]),'stopListening':(_0x5b5c11,_0x8c0acd)=>{_0x307041['server_']['unlisten'](_0x5b5c11,_0x8c0acd);}});}function oa(_0x3a747c){const _0x26b468=_0x3a747c['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x26b468;}function jt(_0xc64578){return ed({'timestamp':oa(_0xc64578)});}function pr(_0x36814b,_0xfc373f,_0x157354,_0x3150e2,_0x5d3692){_0x36814b['dataUpdateCount']++;const _0x6f2b09=new C(_0xfc373f);_0x157354=_0x36814b['interceptServerDataCallback_']?_0x36814b['interceptServerDataCallback_'](_0xfc373f,_0x157354):_0x157354;let _0x402bb1=[];if(_0x5d3692){if(_0x3150e2){const _0x4b4671=ln(_0x157354,_0x627a78=>N(_0x627a78));_0x402bb1=Ku(_0x36814b['serverSyncTree_'],_0x6f2b09,_0x4b4671,_0x5d3692);}else{const _0x577602=N(_0x157354);_0x402bb1=Yo(_0x36814b['serverSyncTree_'],_0x6f2b09,_0x577602,_0x5d3692);}}else{if(_0x3150e2){const _0x18176b=ln(_0x157354,_0x59e728=>N(_0x59e728));_0x402bb1=qu(_0x36814b['serverSyncTree_'],_0x6f2b09,_0x18176b);}else{const _0x2f63e7=N(_0x157354);_0x402bb1=$t(_0x36814b['serverSyncTree_'],_0x6f2b09,_0x2f63e7);}}let _0x1bf1eb=_0x6f2b09;_0x402bb1['length']>0x0&&(_0x1bf1eb=st(_0x36814b,_0x6f2b09)),V(_0x36814b['eventQueue_'],_0x1bf1eb,_0x402bb1);}function _r(_0x4a5c27,_0x57050f){ms(_0x4a5c27,'connected',_0x57050f),_0x57050f===!0x1&&wd(_0x4a5c27);}function yd(_0x419529,_0xce778a){x(_0xce778a,(_0x2a6d90,_0x590614)=>{ms(_0x419529,_0x2a6d90,_0x590614);});}function ms(_0x4dfbab,_0x338be9,_0x1f0fca){const _0x3ae84e=new C('/.info/'+_0x338be9),_0x48819b=N(_0x1f0fca);_0x4dfbab['infoData_']['updateSnapshot'](_0x3ae84e,_0x48819b);const _0x10a946=$t(_0x4dfbab['infoSyncTree_'],_0x3ae84e,_0x48819b);V(_0x4dfbab['eventQueue_'],_0x3ae84e,_0x10a946);}function Vn(_0x41684f){return _0x41684f['nextWriteId_']++;}function vd(_0x314f74,_0x188076,_0x5ad615){const _0x38b4de=Yu(_0x314f74['serverSyncTree_'],_0x188076);return _0x38b4de!=null?Promise['resolve'](_0x38b4de):_0x314f74['server_']['get'](_0x188076)['then'](_0x4974c8=>{const _0x477712=N(_0x4974c8)['withIndex'](_0x188076['_queryParams']['getIndex']());bi(_0x314f74['serverSyncTree_'],_0x188076,_0x5ad615,!0x0);let _0x547568;if(_0x188076['_queryParams']['loadsAllData']())_0x547568=$t(_0x314f74['serverSyncTree_'],_0x188076['_path'],_0x477712);else{const _0xe72315=Mt(_0x314f74['serverSyncTree_'],_0x188076);_0x547568=Yo(_0x314f74['serverSyncTree_'],_0x188076['_path'],_0x477712,_0xe72315);}return V(_0x314f74['eventQueue_'],_0x188076['_path'],_0x547568),wn(_0x314f74['serverSyncTree_'],_0x188076,_0x5ad615,null,!0x0),_0x477712;},_0x524461=>(ut(_0x314f74,'get\x20for\x20query\x20'+O(_0x188076)+'\x20failed:\x20'+_0x524461),Promise['reject'](new Error(_0x524461))));}function Ed(_0x33e445,_0x40aadf,_0x29f88f,_0x4a45c7,_0x580442){ut(_0x33e445,'set',{'path':_0x40aadf['toString'](),'value':_0x29f88f,'priority':_0x4a45c7});const _0x516bec=jt(_0x33e445),_0x19aa27=N(_0x29f88f,_0x4a45c7),_0x3cd84b=xn(_0x33e445['serverSyncTree_'],_0x40aadf),_0x8a3b9e=hs(_0x19aa27,_0x3cd84b,_0x516bec),_0x159b9c=Vn(_0x33e445),_0x1d0aa2=ss(_0x33e445['serverSyncTree_'],_0x40aadf,_0x8a3b9e,_0x159b9c,!0x0);Bn(_0x33e445['eventQueue_'],_0x1d0aa2),_0x33e445['server_']['put'](_0x40aadf['toString'](),_0x19aa27['val'](!0x0),(_0x42cdb1,_0x5679d6)=>{const _0x467a2b=_0x42cdb1==='ok';_0x467a2b||U('set\x20at\x20'+_0x40aadf+'\x20failed:\x20'+_0x42cdb1);const _0x12d5d8=pe(_0x33e445['serverSyncTree_'],_0x159b9c,!_0x467a2b);V(_0x33e445['eventQueue_'],_0x40aadf,_0x12d5d8),Ai(_0x33e445,_0x580442,_0x42cdb1,_0x5679d6);});const _0x351e80=vs(_0x33e445,_0x40aadf);st(_0x33e445,_0x351e80),V(_0x33e445['eventQueue_'],_0x351e80,[]);}function Id(_0x27fbf2,_0x7e46ac,_0x46d0f2,_0x116491){ut(_0x27fbf2,'update',{'path':_0x7e46ac['toString'](),'value':_0x46d0f2});let _0x342f28=!0x0;const _0x1561cd=jt(_0x27fbf2),_0xb8bd32={};if(x(_0x46d0f2,(_0x6ec5d,_0x403468)=>{_0x342f28=!0x1,_0xb8bd32[_0x6ec5d]=Zo(A(_0x7e46ac,_0x6ec5d),N(_0x403468),_0x27fbf2['serverSyncTree_'],_0x1561cd);}),_0x342f28)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x27fbf2,_0x116491,'ok',void 0x0);else{const _0x450ab1=Vn(_0x27fbf2),_0x5d21bf=Gu(_0x27fbf2['serverSyncTree_'],_0x7e46ac,_0xb8bd32,_0x450ab1);Bn(_0x27fbf2['eventQueue_'],_0x5d21bf),_0x27fbf2['server_']['merge'](_0x7e46ac['toString'](),_0x46d0f2,(_0x3c37ad,_0x34e1b3)=>{const _0x38a6e3=_0x3c37ad==='ok';_0x38a6e3||U('update\x20at\x20'+_0x7e46ac+'\x20failed:\x20'+_0x3c37ad);const _0x3ab5b1=pe(_0x27fbf2['serverSyncTree_'],_0x450ab1,!_0x38a6e3),_0x560cc7=_0x3ab5b1['length']>0x0?st(_0x27fbf2,_0x7e46ac):_0x7e46ac;V(_0x27fbf2['eventQueue_'],_0x560cc7,_0x3ab5b1),Ai(_0x27fbf2,_0x116491,_0x3c37ad,_0x34e1b3);}),x(_0x46d0f2,_0x3dbbe6=>{const _0x11561d=vs(_0x27fbf2,A(_0x7e46ac,_0x3dbbe6));st(_0x27fbf2,_0x11561d);}),V(_0x27fbf2['eventQueue_'],_0x7e46ac,[]);}}function wd(_0x3b5081){ut(_0x3b5081,'onDisconnectEvents');const _0x151ab3=jt(_0x3b5081),_0x375f38=pn();Ei(_0x3b5081['onDisconnect_'],w(),(_0x23504f,_0x16a3eb)=>{const _0x39267d=Zo(_0x23504f,_0x16a3eb,_0x3b5081['serverSyncTree_'],_0x151ab3);Mo(_0x375f38,_0x23504f,_0x39267d);});let _0x2bc569=[];Ei(_0x375f38,w(),(_0x248381,_0x2f4d49)=>{_0x2bc569=_0x2bc569['concat']($t(_0x3b5081['serverSyncTree_'],_0x248381,_0x2f4d49));const _0x1c1cb9=vs(_0x3b5081,_0x248381);st(_0x3b5081,_0x1c1cb9);}),_0x3b5081['onDisconnect_']=pn(),V(_0x3b5081['eventQueue_'],w(),_0x2bc569);}function Cd(_0x532663,_0x330a6e,_0x3214e3){let _0x5d61eb;y(_0x330a6e['_path'])==='.info'?_0x5d61eb=bi(_0x532663['infoSyncTree_'],_0x330a6e,_0x3214e3):_0x5d61eb=bi(_0x532663['serverSyncTree_'],_0x330a6e,_0x3214e3),ia(_0x532663['eventQueue_'],_0x330a6e['_path'],_0x5d61eb);}function Td(_0x2a5e29,_0x1780f2,_0x14af81){let _0x522b85;y(_0x1780f2['_path'])==='.info'?_0x522b85=wn(_0x2a5e29['infoSyncTree_'],_0x1780f2,_0x14af81):_0x522b85=wn(_0x2a5e29['serverSyncTree_'],_0x1780f2,_0x14af81),ia(_0x2a5e29['eventQueue_'],_0x1780f2['_path'],_0x522b85);}function aa(_0x12f417){_0x12f417['persistentConnection_']&&_0x12f417['persistentConnection_']['interrupt'](ra);}function Sd(_0x17fce4){_0x17fce4['persistentConnection_']&&_0x17fce4['persistentConnection_']['resume'](ra);}function ut(_0x2d8094,..._0x63d7e7){let _0x2e3b03='';_0x2d8094['persistentConnection_']&&(_0x2e3b03=_0x2d8094['persistentConnection_']['id']+':'),L(_0x2e3b03,..._0x63d7e7);}function Ai(_0x4875f6,_0x2d5d13,_0x27539f,_0x5ace4b){_0x2d5d13&&lt(()=>{if(_0x27539f==='ok')_0x2d5d13(null);else{const _0x459af2=(_0x27539f||'error')['toUpperCase']();let _0x38496e=_0x459af2;_0x5ace4b&&(_0x38496e+=':\x20'+_0x5ace4b);const _0x556067=new Error(_0x38496e);_0x556067['code']=_0x459af2,_0x2d5d13(_0x556067);}});}function bd(_0x31c0aa,_0x3c0a4f,_0x1324b7,_0x51861e,_0x56334c,_0x2da54b){ut(_0x31c0aa,'transaction\x20on\x20'+_0x3c0a4f);const _0x593821={'path':_0x3c0a4f,'update':_0x1324b7,'onComplete':_0x51861e,'status':null,'order':to(),'applyLocally':_0x2da54b,'retryCount':0x0,'unwatcher':_0x56334c,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x4708f2=ys(_0x31c0aa,_0x3c0a4f,void 0x0);_0x593821['currentInputSnapshot']=_0x4708f2;const _0xeda1c6=_0x593821['update'](_0x4708f2['val']());if(_0xeda1c6===void 0x0)_0x593821['unwatcher'](),_0x593821['currentOutputSnapshotRaw']=null,_0x593821['currentOutputSnapshotResolved']=null,_0x593821['onComplete']&&_0x593821['onComplete'](null,!0x1,_0x593821['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0xeda1c6,_0x593821['path']),_0x593821['status']=0x0;const _0x5240f9=Un(_0x31c0aa['transactionQueueTree_'],_0x3c0a4f),_0xf0fbe6=Ge(_0x5240f9)||[];_0xf0fbe6['push'](_0x593821),fs(_0x5240f9,_0xf0fbe6);let _0x56fa50;typeof _0xeda1c6=='object'&&_0xeda1c6!==null&&Y(_0xeda1c6,'.priority')?(_0x56fa50=Oe(_0xeda1c6,'.priority'),f(Cn(_0x56fa50),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x56fa50=(xn(_0x31c0aa['serverSyncTree_'],_0x3c0a4f)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x241c46=jt(_0x31c0aa),_0x21b8c0=N(_0xeda1c6,_0x56fa50),_0x13268a=hs(_0x21b8c0,_0x4708f2,_0x241c46);_0x593821['currentOutputSnapshotRaw']=_0x21b8c0,_0x593821['currentOutputSnapshotResolved']=_0x13268a,_0x593821['currentWriteId']=Vn(_0x31c0aa);const _0x1df70c=ss(_0x31c0aa['serverSyncTree_'],_0x3c0a4f,_0x13268a,_0x593821['currentWriteId'],_0x593821['applyLocally']);V(_0x31c0aa['eventQueue_'],_0x3c0a4f,_0x1df70c),Hn(_0x31c0aa,_0x31c0aa['transactionQueueTree_']);}}function ys(_0x42eb2c,_0x43c65a,_0x396af6){return xn(_0x42eb2c['serverSyncTree_'],_0x43c65a,_0x396af6)||g['EMPTY_NODE'];}function Hn(_0x4b98f1,_0x5d0002=_0x4b98f1['transactionQueueTree_']){if(_0x5d0002||$n(_0x4b98f1,_0x5d0002),Ge(_0x5d0002)){const _0x5e2e65=la(_0x4b98f1,_0x5d0002);f(_0x5e2e65['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5e2e65['every'](_0x5c791d=>_0x5c791d['status']===0x0)&&Rd(_0x4b98f1,Gt(_0x5d0002),_0x5e2e65);}else ea(_0x5d0002)&&Wn(_0x5d0002,_0x1b223d=>{Hn(_0x4b98f1,_0x1b223d);});}function Rd(_0x51986d,_0x3bea35,_0x31076c){const _0x4e188b=_0x31076c['map'](_0x341e24=>_0x341e24['currentWriteId']),_0x19ae57=ys(_0x51986d,_0x3bea35,_0x4e188b);let _0x395e36=_0x19ae57;const _0x51aa99=_0x19ae57['hash']();for(let _0x4d6f4a=0x0;_0x4d6f4a<_0x31076c['length'];_0x4d6f4a++){const _0x2e7d4c=_0x31076c[_0x4d6f4a];f(_0x2e7d4c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2e7d4c['status']=0x1,_0x2e7d4c['retryCount']++;const _0x3293a1=F(_0x3bea35,_0x2e7d4c['path']);_0x395e36=_0x395e36['updateChild'](_0x3293a1,_0x2e7d4c['currentOutputSnapshotRaw']);}const _0x58af72=_0x395e36['val'](!0x0),_0x164541=_0x3bea35;_0x51986d['server_']['put'](_0x164541['toString'](),_0x58af72,_0x215349=>{ut(_0x51986d,'transaction\x20put\x20response',{'path':_0x164541['toString'](),'status':_0x215349});let _0x1a30c5=[];if(_0x215349==='ok'){const _0x40dbcb=[];for(let _0x3a2995=0x0;_0x3a2995<_0x31076c['length'];_0x3a2995++)_0x31076c[_0x3a2995]['status']=0x2,_0x1a30c5=_0x1a30c5['concat'](pe(_0x51986d['serverSyncTree_'],_0x31076c[_0x3a2995]['currentWriteId'])),_0x31076c[_0x3a2995]['onComplete']&&_0x40dbcb['push'](()=>_0x31076c[_0x3a2995]['onComplete'](null,!0x0,_0x31076c[_0x3a2995]['currentOutputSnapshotResolved'])),_0x31076c[_0x3a2995]['unwatcher']();$n(_0x51986d,Un(_0x51986d['transactionQueueTree_'],_0x3bea35)),Hn(_0x51986d,_0x51986d['transactionQueueTree_']),V(_0x51986d['eventQueue_'],_0x3bea35,_0x1a30c5);for(let _0x26e861=0x0;_0x26e861<_0x40dbcb['length'];_0x26e861++)lt(_0x40dbcb[_0x26e861]);}else{if(_0x215349==='datastale'){for(let _0x5c7dd8=0x0;_0x5c7dd8<_0x31076c['length'];_0x5c7dd8++)_0x31076c[_0x5c7dd8]['status']===0x3?_0x31076c[_0x5c7dd8]['status']=0x4:_0x31076c[_0x5c7dd8]['status']=0x0;}else{U('transaction\x20at\x20'+_0x164541['toString']()+'\x20failed:\x20'+_0x215349);for(let _0x5885bf=0x0;_0x5885bf<_0x31076c['length'];_0x5885bf++)_0x31076c[_0x5885bf]['status']=0x4,_0x31076c[_0x5885bf]['abortReason']=_0x215349;}st(_0x51986d,_0x3bea35);}},_0x51aa99);}function st(_0x503d7c,_0x289dc5){const _0x1c198b=ca(_0x503d7c,_0x289dc5),_0x49c2f6=Gt(_0x1c198b),_0x2571f4=la(_0x503d7c,_0x1c198b);return Ad(_0x503d7c,_0x2571f4,_0x49c2f6),_0x49c2f6;}function Ad(_0x2b15f1,_0x2b74b4,_0x3df3e2){if(_0x2b74b4['length']===0x0)return;const _0x3bc6d0=[];let _0x1e1fef=[];const _0x420008=_0x2b74b4['filter'](_0x5d4cce=>_0x5d4cce['status']===0x0)['map'](_0x26228a=>_0x26228a['currentWriteId']);for(let _0x5e9e2c=0x0;_0x5e9e2c<_0x2b74b4['length'];_0x5e9e2c++){const _0x332276=_0x2b74b4[_0x5e9e2c],_0x255840=F(_0x3df3e2,_0x332276['path']);let _0x246b72=!0x1,_0x2aa7c7;if(f(_0x255840!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x332276['status']===0x4)_0x246b72=!0x0,_0x2aa7c7=_0x332276['abortReason'],_0x1e1fef=_0x1e1fef['concat'](pe(_0x2b15f1['serverSyncTree_'],_0x332276['currentWriteId'],!0x0));else{if(_0x332276['status']===0x0){if(_0x332276['retryCount']>=_d)_0x246b72=!0x0,_0x2aa7c7='maxretry',_0x1e1fef=_0x1e1fef['concat'](pe(_0x2b15f1['serverSyncTree_'],_0x332276['currentWriteId'],!0x0));else{const _0x1eae68=ys(_0x2b15f1,_0x332276['path'],_0x420008);_0x332276['currentInputSnapshot']=_0x1eae68;const _0x820f10=_0x2b74b4[_0x5e9e2c]['update'](_0x1eae68['val']());if(_0x820f10!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x820f10,_0x332276['path']);let _0x12e707=N(_0x820f10);typeof _0x820f10=='object'&&_0x820f10!=null&&Y(_0x820f10,'.priority')||(_0x12e707=_0x12e707['updatePriority'](_0x1eae68['getPriority']()));const _0x186732=_0x332276['currentWriteId'],_0x8a0952=jt(_0x2b15f1),_0x2f1b9e=hs(_0x12e707,_0x1eae68,_0x8a0952);_0x332276['currentOutputSnapshotRaw']=_0x12e707,_0x332276['currentOutputSnapshotResolved']=_0x2f1b9e,_0x332276['currentWriteId']=Vn(_0x2b15f1),_0x420008['splice'](_0x420008['indexOf'](_0x186732),0x1),_0x1e1fef=_0x1e1fef['concat'](ss(_0x2b15f1['serverSyncTree_'],_0x332276['path'],_0x2f1b9e,_0x332276['currentWriteId'],_0x332276['applyLocally'])),_0x1e1fef=_0x1e1fef['concat'](pe(_0x2b15f1['serverSyncTree_'],_0x186732,!0x0));}else _0x246b72=!0x0,_0x2aa7c7='nodata',_0x1e1fef=_0x1e1fef['concat'](pe(_0x2b15f1['serverSyncTree_'],_0x332276['currentWriteId'],!0x0));}}}V(_0x2b15f1['eventQueue_'],_0x3df3e2,_0x1e1fef),_0x1e1fef=[],_0x246b72&&(_0x2b74b4[_0x5e9e2c]['status']=0x2,function(_0x163490){setTimeout(_0x163490,Math['floor'](0x0));}(_0x2b74b4[_0x5e9e2c]['unwatcher']),_0x2b74b4[_0x5e9e2c]['onComplete']&&(_0x2aa7c7==='nodata'?_0x3bc6d0['push'](()=>_0x2b74b4[_0x5e9e2c]['onComplete'](null,!0x1,_0x2b74b4[_0x5e9e2c]['currentInputSnapshot'])):_0x3bc6d0['push'](()=>_0x2b74b4[_0x5e9e2c]['onComplete'](new Error(_0x2aa7c7),!0x1,null))));}$n(_0x2b15f1,_0x2b15f1['transactionQueueTree_']);for(let _0x252ef0=0x0;_0x252ef0<_0x3bc6d0['length'];_0x252ef0++)lt(_0x3bc6d0[_0x252ef0]);Hn(_0x2b15f1,_0x2b15f1['transactionQueueTree_']);}function ca(_0x641aae,_0x347c0c){let _0x19a5d4,_0x81be1c=_0x641aae['transactionQueueTree_'];for(_0x19a5d4=y(_0x347c0c);_0x19a5d4!==null&&Ge(_0x81be1c)===void 0x0;)_0x81be1c=Un(_0x81be1c,_0x19a5d4),_0x347c0c=b(_0x347c0c),_0x19a5d4=y(_0x347c0c);return _0x81be1c;}function la(_0x5df636,_0x3053d3){const _0x408f0d=[];return ha(_0x5df636,_0x3053d3,_0x408f0d),_0x408f0d['sort']((_0x57479b,_0x4a66c5)=>_0x57479b['order']-_0x4a66c5['order']),_0x408f0d;}function ha(_0xeb95ac,_0x558626,_0x1caaa4){const _0x13c604=Ge(_0x558626);if(_0x13c604){for(let _0x24058f=0x0;_0x24058f<_0x13c604['length'];_0x24058f++)_0x1caaa4['push'](_0x13c604[_0x24058f]);}Wn(_0x558626,_0x46f418=>{ha(_0xeb95ac,_0x46f418,_0x1caaa4);});}function $n(_0xd0e2e0,_0x2c11e7){const _0x21e74a=Ge(_0x2c11e7);if(_0x21e74a){let _0x379c36=0x0;for(let _0x191d1c=0x0;_0x191d1c<_0x21e74a['length'];_0x191d1c++)_0x21e74a[_0x191d1c]['status']!==0x2&&(_0x21e74a[_0x379c36]=_0x21e74a[_0x191d1c],_0x379c36++);_0x21e74a['length']=_0x379c36,fs(_0x2c11e7,_0x21e74a['length']>0x0?_0x21e74a:void 0x0);}Wn(_0x2c11e7,_0x1a0b3a=>{$n(_0xd0e2e0,_0x1a0b3a);});}function vs(_0x493e99,_0x51f58f){const _0x5e9424=Gt(ca(_0x493e99,_0x51f58f)),_0x2adca=Un(_0x493e99['transactionQueueTree_'],_0x51f58f);return sd(_0x2adca,_0x400c3c=>{ai(_0x493e99,_0x400c3c);}),ai(_0x493e99,_0x2adca),ta(_0x2adca,_0x4c392d=>{ai(_0x493e99,_0x4c392d);}),_0x5e9424;}function ai(_0x2e0183,_0x58c8c4){const _0x5b9968=Ge(_0x58c8c4);if(_0x5b9968){const _0x4c7723=[];let _0x3e5e74=[],_0x2a49c7=-0x1;for(let _0x468361=0x0;_0x468361<_0x5b9968['length'];_0x468361++)_0x5b9968[_0x468361]['status']===0x3||(_0x5b9968[_0x468361]['status']===0x1?(f(_0x2a49c7===_0x468361-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2a49c7=_0x468361,_0x5b9968[_0x468361]['status']=0x3,_0x5b9968[_0x468361]['abortReason']='set'):(f(_0x5b9968[_0x468361]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5b9968[_0x468361]['unwatcher'](),_0x3e5e74=_0x3e5e74['concat'](pe(_0x2e0183['serverSyncTree_'],_0x5b9968[_0x468361]['currentWriteId'],!0x0)),_0x5b9968[_0x468361]['onComplete']&&_0x4c7723['push'](_0x5b9968[_0x468361]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2a49c7===-0x1?fs(_0x58c8c4,void 0x0):_0x5b9968['length']=_0x2a49c7+0x1,V(_0x2e0183['eventQueue_'],Gt(_0x58c8c4),_0x3e5e74);for(let _0x547c1d=0x0;_0x547c1d<_0x4c7723['length'];_0x547c1d++)lt(_0x4c7723[_0x547c1d]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x34d0d9){let _0x299ef4='';const _0x260248=_0x34d0d9['split']('/');for(let _0x4b562d=0x0;_0x4b562d<_0x260248['length'];_0x4b562d++)if(_0x260248[_0x4b562d]['length']>0x0){let _0x5122e0=_0x260248[_0x4b562d];try{_0x5122e0=decodeURIComponent(_0x5122e0['replace'](/\+/g,'\x20'));}catch{}_0x299ef4+='/'+_0x5122e0;}return _0x299ef4;}function Nd(_0x176755){const _0x3149b1={};_0x176755['charAt'](0x0)==='?'&&(_0x176755=_0x176755['substring'](0x1));for(const _0x2ff9fd of _0x176755['split']('&')){if(_0x2ff9fd['length']===0x0)continue;const _0x4465c1=_0x2ff9fd['split']('=');_0x4465c1['length']===0x2?_0x3149b1[decodeURIComponent(_0x4465c1[0x0])]=decodeURIComponent(_0x4465c1[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x2ff9fd+'\x27\x20in\x20query\x20\x27'+_0x176755+'\x27');}return _0x3149b1;}const gr=function(_0x4f8956,_0x38c126){const _0x4bf344=Pd(_0x4f8956),_0x19efc6=_0x4bf344['namespace'];_0x4bf344['domain']==='firebase.com'&&oe(_0x4bf344['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x19efc6||_0x19efc6==='undefined')&&_0x4bf344['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4bf344['secure']||Bl();const _0x517211=_0x4bf344['scheme']==='ws'||_0x4bf344['scheme']==='wss';return{'repoInfo':new _o(_0x4bf344['host'],_0x4bf344['secure'],_0x19efc6,_0x517211,_0x38c126,'',_0x19efc6!==_0x4bf344['subdomain']),'path':new C(_0x4bf344['pathString'])};},Pd=function(_0x20cccc){let _0x34cc14='',_0x43967='',_0x1dd5c0='',_0x14c5c7='',_0xad8d9e='',_0x558fce=!0x0,_0x50573c='https',_0x327ea7=0x1bb;if(typeof _0x20cccc=='string'){let _0x5cf1a3=_0x20cccc['indexOf']('//');_0x5cf1a3>=0x0&&(_0x50573c=_0x20cccc['substring'](0x0,_0x5cf1a3-0x1),_0x20cccc=_0x20cccc['substring'](_0x5cf1a3+0x2));let _0x281519=_0x20cccc['indexOf']('/');_0x281519===-0x1&&(_0x281519=_0x20cccc['length']);let _0x2bd2da=_0x20cccc['indexOf']('?');_0x2bd2da===-0x1&&(_0x2bd2da=_0x20cccc['length']),_0x34cc14=_0x20cccc['substring'](0x0,Math['min'](_0x281519,_0x2bd2da)),_0x281519<_0x2bd2da&&(_0x14c5c7=kd(_0x20cccc['substring'](_0x281519,_0x2bd2da)));const _0xb74fa8=Nd(_0x20cccc['substring'](Math['min'](_0x20cccc['length'],_0x2bd2da)));_0x5cf1a3=_0x34cc14['indexOf'](':'),_0x5cf1a3>=0x0?(_0x558fce=_0x50573c==='https'||_0x50573c==='wss',_0x327ea7=parseInt(_0x34cc14['substring'](_0x5cf1a3+0x1),0xa)):_0x5cf1a3=_0x34cc14['length'];const _0x5edf63=_0x34cc14['slice'](0x0,_0x5cf1a3);if(_0x5edf63['toLowerCase']()==='localhost')_0x43967='localhost';else{if(_0x5edf63['split']('.')['length']<=0x2)_0x43967=_0x5edf63;else{const _0x40cfaa=_0x34cc14['indexOf']('.');_0x1dd5c0=_0x34cc14['substring'](0x0,_0x40cfaa)['toLowerCase'](),_0x43967=_0x34cc14['substring'](_0x40cfaa+0x1),_0xad8d9e=_0x1dd5c0;}}'ns'in _0xb74fa8&&(_0xad8d9e=_0xb74fa8['ns']);}return{'host':_0x34cc14,'port':_0x327ea7,'domain':_0x43967,'subdomain':_0x1dd5c0,'secure':_0x558fce,'scheme':_0x50573c,'pathString':_0x14c5c7,'namespace':_0xad8d9e};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0xade5bd=0x0;const _0x5f0b2a=[];return function(_0xacb6aa){const _0x55400f=_0xacb6aa===_0xade5bd;_0xade5bd=_0xacb6aa;let _0x22640e;const _0x4f79a8=new Array(0x8);for(_0x22640e=0x7;_0x22640e>=0x0;_0x22640e--)_0x4f79a8[_0x22640e]=mr['charAt'](_0xacb6aa%0x40),_0xacb6aa=Math['floor'](_0xacb6aa/0x40);f(_0xacb6aa===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x2953ab=_0x4f79a8['join']('');if(_0x55400f){for(_0x22640e=0xb;_0x22640e>=0x0&&_0x5f0b2a[_0x22640e]===0x3f;_0x22640e--)_0x5f0b2a[_0x22640e]=0x0;_0x5f0b2a[_0x22640e]++;}else{for(_0x22640e=0x0;_0x22640e<0xc;_0x22640e++)_0x5f0b2a[_0x22640e]=Math['floor'](Math['random']()*0x40);}for(_0x22640e=0x0;_0x22640e<0xc;_0x22640e++)_0x2953ab+=mr['charAt'](_0x5f0b2a[_0x22640e]);return f(_0x2953ab['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x2953ab;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x452014,_0x41bd29,_0x305b9c,_0x1c58cc){this['eventType']=_0x452014,this['eventRegistration']=_0x41bd29,this['snapshot']=_0x305b9c,this['prevName']=_0x1c58cc;}['getPath'](){const _0xd89339=this['snapshot']['ref'];return this['eventType']==='value'?_0xd89339['_path']:_0xd89339['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x544916,_0x18ed9d,_0x887b07){this['eventRegistration']=_0x544916,this['error']=_0x18ed9d,this['path']=_0x887b07;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x264924,_0x36823d){this['snapshotCallback']=_0x264924,this['cancelCallback']=_0x36823d;}['onValue'](_0x35b5d9,_0x2a08f4){this['snapshotCallback']['call'](null,_0x35b5d9,_0x2a08f4);}['onCancel'](_0x17a66f){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x17a66f);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x3bb04f){return this['snapshotCallback']===_0x3bb04f['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x3bb04f['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x3bb04f['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x36cd18,_0x3a1ac5,_0xbc4704,_0x5e6cdc){this['_repo']=_0x36cd18,this['_path']=_0x3a1ac5,this['_queryParams']=_0xbc4704,this['_orderByCalled']=_0x5e6cdc;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x16bf7f=nr(this['_queryParams']),_0x3c2e1f=Bi(_0x16bf7f);return _0x3c2e1f==='{}'?'default':_0x3c2e1f;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x4f89c8){if(_0x4f89c8=k(_0x4f89c8),!(_0x4f89c8 instanceof be))return!0x1;const _0x30b70c=this['_repo']===_0x4f89c8['_repo'],_0x2c7b59=qi(this['_path'],_0x4f89c8['_path']),_0x55810c=this['_queryIdentifier']===_0x4f89c8['_queryIdentifier'];return _0x30b70c&&_0x2c7b59&&_0x55810c;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x2781ec,_0x9510d3){if(_0x2781ec['_orderByCalled']===!0x0)throw new Error(_0x9510d3+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x393706){let _0x52423a=null,_0x8c9ff7=null;if(_0x393706['hasStart']()&&(_0x52423a=_0x393706['getIndexStartValue']()),_0x393706['hasEnd']()&&(_0x8c9ff7=_0x393706['getIndexEndValue']()),_0x393706['getIndex']()===ye){const _0x5aa42f='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x334f0d='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x393706['hasStart']()){if(_0x393706['getIndexStartName']()!==xe)throw new Error(_0x5aa42f);if(typeof _0x52423a!='string')throw new Error(_0x334f0d);}if(_0x393706['hasEnd']()){if(_0x393706['getIndexEndName']()!==Ie)throw new Error(_0x5aa42f);if(typeof _0x8c9ff7!='string')throw new Error(_0x334f0d);}}else{if(_0x393706['getIndex']()===R){if(_0x52423a!=null&&!Cn(_0x52423a)||_0x8c9ff7!=null&&!Cn(_0x8c9ff7))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x393706['getIndex']()instanceof Ki||_0x393706['getIndex']()===Po,'unknown\x20index\x20type.'),_0x52423a!=null&&typeof _0x52423a=='object'||_0x8c9ff7!=null&&typeof _0x8c9ff7=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x215094){if(_0x215094['hasStart']()&&_0x215094['hasEnd']()&&_0x215094['hasLimit']()&&!_0x215094['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x5e8c1d,_0x103099){super(_0x5e8c1d,_0x103099,new Qi(),!0x1);}get['parent'](){const _0x471241=To(this['_path']);return _0x471241===null?null:new Z(this['_repo'],_0x471241);}get['root'](){let _0x5c821b=this;for(;_0x5c821b['parent']!==null;)_0x5c821b=_0x5c821b['parent'];return _0x5c821b;}}class rt{constructor(_0x2479f4,_0x5a79f3,_0x3953b6){this['_node']=_0x2479f4,this['ref']=_0x5a79f3,this['_index']=_0x3953b6;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x1c7344){const _0x34deee=new C(_0x1c7344),_0x17f8db=Lt(this['ref'],_0x1c7344);return new rt(this['_node']['getChild'](_0x34deee),_0x17f8db,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5df247){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x55092d,_0x42fe0b)=>_0x5df247(new rt(_0x42fe0b,Lt(this['ref'],_0x55092d),R)));}['hasChild'](_0x3fb343){const _0x30a86a=new C(_0x3fb343);return!this['_node']['getChild'](_0x30a86a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x24d8e6,_0x226b08){return _0x24d8e6=k(_0x24d8e6),_0x24d8e6['_checkNotDeleted']('ref'),_0x226b08!==void 0x0?Lt(_0x24d8e6['_root'],_0x226b08):_0x24d8e6['_root'];}function Lt(_0x5291c4,_0x2df3b5){return _0x5291c4=k(_0x5291c4),y(_0x5291c4['_path'])===null?ud('child','path',_0x2df3b5):_s('child','path',_0x2df3b5),new Z(_0x5291c4['_repo'],A(_0x5291c4['_path'],_0x2df3b5));}function d_(_0x368197,_0x1ce80f){_0x368197=k(_0x368197),gs('push',_0x368197['_path']),qt('push',_0x1ce80f,_0x368197['_path'],!0x0);const _0x2cda47=oa(_0x368197['_repo']),_0x362926=Od(_0x2cda47),_0x469807=Lt(_0x368197,_0x362926),_0x219831=Lt(_0x368197,_0x362926);let _0x350bf5;return _0x1ce80f!=null?_0x350bf5=Ld(_0x219831,_0x1ce80f)['then'](()=>_0x219831):_0x350bf5=Promise['resolve'](_0x219831),_0x469807['then']=_0x350bf5['then']['bind'](_0x350bf5),_0x469807['catch']=_0x350bf5['then']['bind'](_0x350bf5,void 0x0),_0x469807;}function Ld(_0x320df3,_0x35d03c){_0x320df3=k(_0x320df3),gs('set',_0x320df3['_path']),qt('set',_0x35d03c,_0x320df3['_path'],!0x1);const _0x52f555=new Ve();return Ed(_0x320df3['_repo'],_0x320df3['_path'],_0x35d03c,null,_0x52f555['wrapCallback'](()=>{})),_0x52f555['promise'];}function f_(_0x2a2bed,_0xc6896c){hd('update',_0xc6896c,_0x2a2bed['_path']);const _0x133e1b=new Ve();return Id(_0x2a2bed['_repo'],_0x2a2bed['_path'],_0xc6896c,_0x133e1b['wrapCallback'](()=>{})),_0x133e1b['promise'];}function p_(_0x4bb3c7){_0x4bb3c7=k(_0x4bb3c7);const _0x541e0e=new ua(()=>{}),_0xcef0ae=new qn(_0x541e0e);return vd(_0x4bb3c7['_repo'],_0x4bb3c7,_0xcef0ae)['then'](_0x26f66e=>new rt(_0x26f66e,new Z(_0x4bb3c7['_repo'],_0x4bb3c7['_path']),_0x4bb3c7['_queryParams']['getIndex']()));}class qn{constructor(_0x426ad3){this['callbackContext']=_0x426ad3;}['respondsTo'](_0x40366e){return _0x40366e==='value';}['createEvent'](_0x1c46c1,_0xad4288){const _0x2b20a9=_0xad4288['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x1c46c1['snapshotNode'],new Z(_0xad4288['_repo'],_0xad4288['_path']),_0x2b20a9));}['getEventRunner'](_0x4b8916){return _0x4b8916['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x4b8916['error']):()=>this['callbackContext']['onValue'](_0x4b8916['snapshot'],null);}['createCancelEvent'](_0x41bda5,_0x43a842){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x41bda5,_0x43a842):null;}['matches'](_0x3218af){return _0x3218af instanceof qn?!_0x3218af['callbackContext']||!this['callbackContext']?!0x0:_0x3218af['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x161bf9,_0x473bbd,_0x32134b,_0x5a1fc9,_0xfe9208){const _0x59f4cd=new ua(_0x32134b,void 0x0),_0x42b1eb=new qn(_0x59f4cd);return Cd(_0x161bf9['_repo'],_0x161bf9,_0x42b1eb),()=>Td(_0x161bf9['_repo'],_0x161bf9,_0x42b1eb);}function Fd(_0x543800,_0xb9b943,_0x4ac77f,_0x41140d){return xd(_0x543800,'value',_0xb9b943);}class dt{}class pa extends dt{constructor(_0x5ebbd2,_0x2d7728){super(),this['_value']=_0x5ebbd2,this['_key']=_0x2d7728,this['type']='endAt';}['_apply'](_0x267218){qt('endAt',this['_value'],_0x267218['_path'],!0x0);const _0x475c19=Kh(_0x267218['_queryParams'],this['_value'],this['_key']);if(fa(_0x475c19),Gn(_0x475c19),_0x267218['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x267218['_repo'],_0x267218['_path'],_0x475c19,_0x267218['_orderByCalled']);}}function __(_0x139c34,_0xbf3851){return new pa(_0x139c34,_0xbf3851);}class _a extends dt{constructor(_0x1fd1b8,_0x2f4b38){super(),this['_value']=_0x1fd1b8,this['_key']=_0x2f4b38,this['type']='startAt';}['_apply'](_0x4a6ed6){qt('startAt',this['_value'],_0x4a6ed6['_path'],!0x0);const _0x21304a=jh(_0x4a6ed6['_queryParams'],this['_value'],this['_key']);if(fa(_0x21304a),Gn(_0x21304a),_0x4a6ed6['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x4a6ed6['_repo'],_0x4a6ed6['_path'],_0x21304a,_0x4a6ed6['_orderByCalled']);}}function g_(_0x9bcf8e=null,_0x15b4bf){return new _a(_0x9bcf8e,_0x15b4bf);}class Ud extends dt{constructor(_0x4f6118){super(),this['_limit']=_0x4f6118,this['type']='limitToFirst';}['_apply'](_0x22e30e){if(_0x22e30e['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x22e30e['_repo'],_0x22e30e['_path'],zh(_0x22e30e['_queryParams'],this['_limit']),_0x22e30e['_orderByCalled']);}}function m_(_0x305ec4){if(Math['floor'](_0x305ec4)!==_0x305ec4||_0x305ec4<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x305ec4);}class Wd extends dt{constructor(_0x3c88a0){super(),this['_path']=_0x3c88a0,this['type']='orderByChild';}['_apply'](_0x86e4da){da(_0x86e4da,'orderByChild');const _0x625c8e=new C(this['_path']);if(v(_0x625c8e))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xe23e83=new Ki(_0x625c8e),_0x391816=Do(_0x86e4da['_queryParams'],_0xe23e83);return Gn(_0x391816),new be(_0x86e4da['_repo'],_0x86e4da['_path'],_0x391816,!0x0);}}function y_(_0x33c125){if(_0x33c125==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x33c125==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x33c125==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x33c125),new Wd(_0x33c125);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3197fe){da(_0x3197fe,'orderByKey');const _0xaaf291=Do(_0x3197fe['_queryParams'],ye);return Gn(_0xaaf291),new be(_0x3197fe['_repo'],_0x3197fe['_path'],_0xaaf291,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x516282,_0x320167){super(),this['_value']=_0x516282,this['_key']=_0x320167,this['type']='equalTo';}['_apply'](_0x121d1f){if(qt('equalTo',this['_value'],_0x121d1f['_path'],!0x1),_0x121d1f['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x121d1f['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x121d1f));}}function E_(_0x3b997b,_0x3f2984){return new Vd(_0x3b997b,_0x3f2984);}function I_(_0x20cb2b,..._0x31c908){let _0x2b0bd6=k(_0x20cb2b);for(const _0xcd542b of _0x31c908)_0x2b0bd6=_0xcd542b['_apply'](_0x2b0bd6);return _0x2b0bd6;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x54df46,_0x40a1c5,_0x5c7b85,_0xba5a89){const _0x1d93e4=_0x40a1c5['lastIndexOf'](':'),_0x396880=_0x40a1c5['substring'](0x0,_0x1d93e4),_0x59d502=Wt(_0x396880);_0x54df46['repoInfo_']=new _o(_0x40a1c5,_0x59d502,_0x54df46['repoInfo_']['namespace'],_0x54df46['repoInfo_']['webSocketOnly'],_0x54df46['repoInfo_']['nodeAdmin'],_0x54df46['repoInfo_']['persistenceKey'],_0x54df46['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x5c7b85),_0xba5a89&&(_0x54df46['authTokenProvider_']=_0xba5a89);}function qd(_0x2238f9,_0x20c9a1,_0x4569a0,_0x28bbe6,_0x2e79c8){let _0x127061=_0x28bbe6||_0x2238f9['options']['databaseURL'];_0x127061===void 0x0&&(_0x2238f9['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2238f9['options']['projectId']),_0x127061=_0x2238f9['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x46d420=gr(_0x127061,_0x2e79c8),_0x30bb84=_0x46d420['repoInfo'],_0x7964d6;typeof process<'u'&&Us&&(_0x7964d6=Us[Hd]),_0x7964d6?(_0x127061='http://'+_0x7964d6+'?ns='+_0x30bb84['namespace'],_0x46d420=gr(_0x127061,_0x2e79c8),_0x30bb84=_0x46d420['repoInfo']):_0x46d420['repoInfo']['secure'];const _0xca7cfd=new Jl(_0x2238f9['name'],_0x2238f9['options'],_0x20c9a1);dd('Invalid\x20Firebase\x20Database\x20URL',_0x46d420),v(_0x46d420['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x20fe75=jd(_0x30bb84,_0x2238f9,_0xca7cfd,new Ql(_0x2238f9,_0x4569a0));return new Kd(_0x20fe75,_0x2238f9);}function zd(_0xfba434,_0xc9e869){const _0x5d7df8=ki[_0xc9e869];(!_0x5d7df8||_0x5d7df8[_0xfba434['key']]!==_0xfba434)&&oe('Database\x20'+_0xc9e869+'('+_0xfba434['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0xfba434),delete _0x5d7df8[_0xfba434['key']];}function jd(_0x252875,_0xcc91f5,_0x53a410,_0x3aea90){let _0x126241=ki[_0xcc91f5['name']];_0x126241||(_0x126241={},ki[_0xcc91f5['name']]=_0x126241);let _0x33ea6e=_0x126241[_0x252875['toURLString']()];return _0x33ea6e&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x33ea6e=new gd(_0x252875,$d,_0x53a410,_0x3aea90),_0x126241[_0x252875['toURLString']()]=_0x33ea6e,_0x33ea6e;}class Kd{constructor(_0x5d76fc,_0x48696b){this['_repoInternal']=_0x5d76fc,this['app']=_0x48696b,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x54f2ee){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x54f2ee+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x7bdb61=Qr(),_0x2fdd51){const _0x1b568e=Ui(_0x7bdb61,'database')['getImmediate']({'identifier':_0x2fdd51});if(!_0x1b568e['_instanceStarted']){const _0x406420=ac('database');_0x406420&&Yd(_0x1b568e,..._0x406420);}return _0x1b568e;}function Yd(_0x152a87,_0x174587,_0x4bb8aa,_0x178ff8={}){_0x152a87=k(_0x152a87),_0x152a87['_checkNotDeleted']('useEmulator');const _0x2054ca=_0x174587+':'+_0x4bb8aa,_0xe5d74=_0x152a87['_repoInternal'];if(_0x152a87['_instanceStarted']){if(_0x2054ca===_0x152a87['_repoInternal']['repoInfo_']['host']&&De(_0x178ff8,_0xe5d74['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x65c034;if(_0xe5d74['repoInfo_']['nodeAdmin'])_0x178ff8['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x65c034=new tn(tn['OWNER']);else{if(_0x178ff8['mockUserToken']){const _0x29ce72=typeof _0x178ff8['mockUserToken']=='string'?_0x178ff8['mockUserToken']:cc(_0x178ff8['mockUserToken'],_0x152a87['app']['options']['projectId']);_0x65c034=new tn(_0x29ce72);}}Wt(_0x174587)&&jr(_0x174587),Gd(_0xe5d74,_0x2054ca,_0x178ff8,_0x65c034);}function C_(_0x357a0a){_0x357a0a=k(_0x357a0a),_0x357a0a['_checkNotDeleted']('goOffline'),aa(_0x357a0a['_repo']);}function T_(_0x2a4782){_0x2a4782=k(_0x2a4782),_0x2a4782['_checkNotDeleted']('goOnline'),Sd(_0x2a4782['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x250287){Ll(ct),et(new Me('database',(_0x56ce0e,{instanceIdentifier:_0x23b7b6})=>{const _0x3f68dc=_0x56ce0e['getProvider']('app')['getImmediate'](),_0x4dacc7=_0x56ce0e['getProvider']('auth-internal'),_0x488480=_0x56ce0e['getProvider']('app-check-internal');return qd(_0x3f68dc,_0x4dacc7,_0x488480,_0x23b7b6);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x250287),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0xf34d2,_0x416da4){this['committed']=_0xf34d2,this['snapshot']=_0x416da4;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x5bc385,_0x558ae8,_0x336ee7){if(_0x5bc385=k(_0x5bc385),gs('Reference.transaction',_0x5bc385['_path']),_0x5bc385['key']==='.length'||_0x5bc385['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5bc385['key']+'\x20is\x20a\x20read-only\x20object.';const _0x28d995=!0x0,_0x125e68=new Ve(),_0x2900bf=(_0x74944e,_0x7d284b,_0xb92a61)=>{let _0x392aaa=null;_0x74944e?_0x125e68['reject'](_0x74944e):(_0x392aaa=new rt(_0xb92a61,new Z(_0x5bc385['_repo'],_0x5bc385['_path']),R),_0x125e68['resolve'](new Xd(_0x7d284b,_0x392aaa)));},_0x91c159=Fd(_0x5bc385,()=>{});return bd(_0x5bc385['_repo'],_0x5bc385['_path'],_0x558ae8,_0x2900bf,_0x91c159,_0x28d995),_0x125e68['promise'];}ie['prototype']['simpleListen']=function(_0x25a003,_0x5bbe9f){this['sendRequest']('q',{'p':_0x25a003},_0x5bbe9f);},ie['prototype']['echo']=function(_0x53d431,_0x5e5651){this['sendRequest']('echo',{'d':_0x53d431},_0x5e5651);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x26b12e,..._0x2480bc){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x26b12e,..._0x2480bc);}function nn(_0x4fa360,..._0x3e1a87){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x4fa360,..._0x3e1a87);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x41d622,..._0x41f869){throw Es(_0x41d622,..._0x41f869);}function J(_0x9813e1,..._0x4d1931){return Es(_0x9813e1,..._0x4d1931);}function ya(_0x5683a7,_0x38dfa0,_0x448d95){const _0x1c1f4e={...Zd(),[_0x38dfa0]:_0x448d95};return new Ut('auth','Firebase',_0x1c1f4e)['create'](_0x38dfa0,{'appName':_0x5683a7['name']});}function se(_0x3e7209){return ya(_0x3e7209,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x1d6bfe,..._0x115725){if(typeof _0x1d6bfe!='string'){const _0x52b28d=_0x115725[0x0],_0x416bbe=[..._0x115725['slice'](0x1)];return _0x416bbe[0x0]&&(_0x416bbe[0x0]['appName']=_0x1d6bfe['name']),_0x1d6bfe['_errorFactory']['create'](_0x52b28d,..._0x416bbe);}return ma['create'](_0x1d6bfe,..._0x115725);}function m(_0x2b141f,_0x256f01,..._0x244c87){if(!_0x2b141f)throw Es(_0x256f01,..._0x244c87);}function te(_0x3ad01b){const _0x2592a8='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3ad01b;throw nn(_0x2592a8),new Error(_0x2592a8);}function ae(_0x31d80f,_0x358dd2){_0x31d80f||te(_0x358dd2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x392c2a;return typeof self<'u'&&((_0x392c2a=self['location'])==null?void 0x0:_0x392c2a['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x4be2fd;return typeof self<'u'&&((_0x4be2fd=self['location'])==null?void 0x0:_0x4be2fd['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x39ddf2=navigator;return _0x39ddf2['languages']&&_0x39ddf2['languages'][0x0]||_0x39ddf2['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x698f3a,_0x106b62){this['shortDelay']=_0x698f3a,this['longDelay']=_0x106b62,ae(_0x106b62>_0x698f3a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x3b0c35,_0xcedc3d){ae(_0x3b0c35['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5cd200}=_0x3b0c35['emulator'];return _0xcedc3d?''+_0x5cd200+(_0xcedc3d['startsWith']('/')?_0xcedc3d['slice'](0x1):_0xcedc3d):_0x5cd200;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x43466f,_0x129771,_0x57fb1e){this['fetchImpl']=_0x43466f,_0x129771&&(this['headersImpl']=_0x129771),_0x57fb1e&&(this['responseImpl']=_0x57fb1e);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x532bc6,_0x984326){return _0x532bc6['tenantId']&&!_0x984326['tenantId']?{..._0x984326,'tenantId':_0x532bc6['tenantId']}:_0x984326;}async function Ae(_0x3c53d9,_0x3a6a85,_0xf97455,_0x1e911b,_0xa9b6ce={}){return Ea(_0x3c53d9,_0xa9b6ce,async()=>{let _0x3693c2={},_0x6a65ec={};_0x1e911b&&(_0x3a6a85==='GET'?_0x6a65ec=_0x1e911b:_0x3693c2={'body':JSON['stringify'](_0x1e911b)});const _0x1aa224=at({..._0x6a65ec,'key':_0x3c53d9['config']['apiKey']})['slice'](0x1),_0x3cb1e7=await _0x3c53d9['_getAdditionalHeaders']();_0x3cb1e7['Content-Type']='application/json',_0x3c53d9['languageCode']&&(_0x3cb1e7['X-Firebase-Locale']=_0x3c53d9['languageCode']);const _0xd2b4dd={'method':_0x3a6a85,'headers':_0x3cb1e7,..._0x3693c2};return lc()||(_0xd2b4dd['referrerPolicy']='strict-origin-when-cross-origin'),_0x3c53d9['emulatorConfig']&&Wt(_0x3c53d9['emulatorConfig']['host'])&&(_0xd2b4dd['credentials']='include'),va['fetch']()(await Ia(_0x3c53d9,_0x3c53d9['config']['apiHost'],_0xf97455,_0x1aa224),_0xd2b4dd);});}async function Ea(_0x27d77b,_0x34a2b2,_0x541e9a){_0x27d77b['_canInitEmulator']=!0x1;const _0x35a689={...rf,..._0x34a2b2};try{const _0x4a0adb=new lf(_0x27d77b),_0x3ce921=await Promise['race']([_0x541e9a(),_0x4a0adb['promise']]);_0x4a0adb['clearNetworkTimeout']();const _0x23d60c=await _0x3ce921['json']();if('needConfirmation'in _0x23d60c)throw en(_0x27d77b,'account-exists-with-different-credential',_0x23d60c);if(_0x3ce921['ok']&&!('errorMessage'in _0x23d60c))return _0x23d60c;{const _0x532f6f=_0x3ce921['ok']?_0x23d60c['errorMessage']:_0x23d60c['error']['message'],[_0xe821d5,_0x555070]=_0x532f6f['split']('\x20:\x20');if(_0xe821d5==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x27d77b,'credential-already-in-use',_0x23d60c);if(_0xe821d5==='EMAIL_EXISTS')throw en(_0x27d77b,'email-already-in-use',_0x23d60c);if(_0xe821d5==='USER_DISABLED')throw en(_0x27d77b,'user-disabled',_0x23d60c);const _0x1105bf=_0x35a689[_0xe821d5]||_0xe821d5['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x555070)throw ya(_0x27d77b,_0x1105bf,_0x555070);K(_0x27d77b,_0x1105bf);}}catch(_0x1b1eb6){if(_0x1b1eb6 instanceof Se)throw _0x1b1eb6;K(_0x27d77b,'network-request-failed',{'message':String(_0x1b1eb6)});}}async function Yt(_0x53ef18,_0x4f65e8,_0x2054f6,_0x40fc6f,_0x490168={}){const _0x3fb897=await Ae(_0x53ef18,_0x4f65e8,_0x2054f6,_0x40fc6f,_0x490168);return'mfaPendingCredential'in _0x3fb897&&K(_0x53ef18,'multi-factor-auth-required',{'_serverResponse':_0x3fb897}),_0x3fb897;}async function Ia(_0x4188d0,_0x322291,_0x14e69b,_0x2d3982){const _0x5e456a=''+_0x322291+_0x14e69b+'?'+_0x2d3982,_0x72ec23=_0x4188d0,_0x5d27c4=_0x72ec23['config']['emulator']?Is(_0x4188d0['config'],_0x5e456a):_0x4188d0['config']['apiScheme']+'://'+_0x5e456a;return of['includes'](_0x14e69b)&&(await _0x72ec23['_persistenceManagerAvailable'],_0x72ec23['_getPersistenceType']()==='COOKIE')?_0x72ec23['_getPersistence']()['_getFinalTarget'](_0x5d27c4)['toString']():_0x5d27c4;}function cf(_0x55f7f9){switch(_0x55f7f9){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x8636b8){this['auth']=_0x8636b8,this['timer']=null,this['promise']=new Promise((_0x19af91,_0x27d0d7)=>{this['timer']=setTimeout(()=>_0x27d0d7(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x2cc2d0,_0x53e04d,_0xfc18ed){const _0x5504e2={'appName':_0x2cc2d0['name']};_0xfc18ed['email']&&(_0x5504e2['email']=_0xfc18ed['email']),_0xfc18ed['phoneNumber']&&(_0x5504e2['phoneNumber']=_0xfc18ed['phoneNumber']);const _0x3b39b1=J(_0x2cc2d0,_0x53e04d,_0x5504e2);return _0x3b39b1['customData']['_tokenResponse']=_0xfc18ed,_0x3b39b1;}function vr(_0x308be3){return _0x308be3!==void 0x0&&_0x308be3['enterprise']!==void 0x0;}class hf{constructor(_0x341c19){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x341c19['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x341c19['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x341c19['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x5b917){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x457863 of this['recaptchaEnforcementState'])if(_0x457863['provider']&&_0x457863['provider']===_0x5b917)return cf(_0x457863['enforcementState']);return null;}['isProviderEnabled'](_0x323936){return this['getProviderEnforcementState'](_0x323936)==='ENFORCE'||this['getProviderEnforcementState'](_0x323936)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x17bb71,_0xb01e78){return Ae(_0x17bb71,'GET','/v2/recaptchaConfig',Re(_0x17bb71,_0xb01e78));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x598287,_0x2e1e0f){return Ae(_0x598287,'POST','/v1/accounts:delete',_0x2e1e0f);}async function Sn(_0x4f7d7c,_0x20ff94){return Ae(_0x4f7d7c,'POST','/v1/accounts:lookup',_0x20ff94);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x18233b){if(_0x18233b)try{const _0x57bf11=new Date(Number(_0x18233b));if(!isNaN(_0x57bf11['getTime']()))return _0x57bf11['toUTCString']();}catch{}}async function ff(_0x2c7d58,_0x466386=!0x1){const _0x391e50=k(_0x2c7d58),_0x1f3456=await _0x391e50['getIdToken'](_0x466386),_0x2befee=ws(_0x1f3456);m(_0x2befee&&_0x2befee['exp']&&_0x2befee['auth_time']&&_0x2befee['iat'],_0x391e50['auth'],'internal-error');const _0x18c8a7=typeof _0x2befee['firebase']=='object'?_0x2befee['firebase']:void 0x0,_0x442975=_0x18c8a7==null?void 0x0:_0x18c8a7['sign_in_provider'];return{'claims':_0x2befee,'token':_0x1f3456,'authTime':St(ci(_0x2befee['auth_time'])),'issuedAtTime':St(ci(_0x2befee['iat'])),'expirationTime':St(ci(_0x2befee['exp'])),'signInProvider':_0x442975||null,'signInSecondFactor':(_0x18c8a7==null?void 0x0:_0x18c8a7['sign_in_second_factor'])||null};}function ci(_0x5c7d76){return Number(_0x5c7d76)*0x3e8;}function ws(_0x26f52a){const [_0x219ed4,_0x35fb11,_0x2bff0a]=_0x26f52a['split']('.');if(_0x219ed4===void 0x0||_0x35fb11===void 0x0||_0x2bff0a===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2afbad=cn(_0x35fb11);return _0x2afbad?JSON['parse'](_0x2afbad):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x38c502){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x38c502==null?void 0x0:_0x38c502['toString']()),null;}}function Er(_0x22d2e8){const _0x2b3c3a=ws(_0x22d2e8);return m(_0x2b3c3a,'internal-error'),m(typeof _0x2b3c3a['exp']<'u','internal-error'),m(typeof _0x2b3c3a['iat']<'u','internal-error'),Number(_0x2b3c3a['exp'])-Number(_0x2b3c3a['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x1473f9,_0x72ddf9,_0x3e4fde=!0x1){if(_0x3e4fde)return _0x72ddf9;try{return await _0x72ddf9;}catch(_0x3090b1){throw _0x3090b1 instanceof Se&&pf(_0x3090b1)&&_0x1473f9['auth']['currentUser']===_0x1473f9&&await _0x1473f9['auth']['signOut'](),_0x3090b1;}}function pf({code:_0x3adac1}){return _0x3adac1==='auth/user-disabled'||_0x3adac1==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x1c2364){this['user']=_0x1c2364,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x4e717b){if(_0x4e717b){const _0x59cb26=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x59cb26;}else{this['errorBackoff']=0x7530;const _0x3b1d8b=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3b1d8b);}}['schedule'](_0x3385e4=!0x1){if(!this['isRunning'])return;const _0x2900d7=this['getInterval'](_0x3385e4);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x2900d7);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x443dc1){(_0x443dc1==null?void 0x0:_0x443dc1['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x447cb1,_0x4d6dc5){this['createdAt']=_0x447cb1,this['lastLoginAt']=_0x4d6dc5,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x45bf5f){this['createdAt']=_0x45bf5f['createdAt'],this['lastLoginAt']=_0x45bf5f['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x6edc05){var _0x41bd7e;const _0x4187a4=_0x6edc05['auth'],_0x4be932=await _0x6edc05['getIdToken'](),_0xe42142=await xt(_0x6edc05,Sn(_0x4187a4,{'idToken':_0x4be932}));m(_0xe42142==null?void 0x0:_0xe42142['users']['length'],_0x4187a4,'internal-error');const _0x19121b=_0xe42142['users'][0x0];_0x6edc05['_notifyReloadListener'](_0x19121b);const _0x4111fe=(_0x41bd7e=_0x19121b['providerUserInfo'])!=null&&_0x41bd7e['length']?wa(_0x19121b['providerUserInfo']):[],_0x1b476e=mf(_0x6edc05['providerData'],_0x4111fe),_0x16638a=_0x6edc05['isAnonymous'],_0x15be52=!(_0x6edc05['email']&&_0x19121b['passwordHash'])&&!(_0x1b476e!=null&&_0x1b476e['length']),_0x68267c=_0x16638a?_0x15be52:!0x1,_0x4e8f0a={'uid':_0x19121b['localId'],'displayName':_0x19121b['displayName']||null,'photoURL':_0x19121b['photoUrl']||null,'email':_0x19121b['email']||null,'emailVerified':_0x19121b['emailVerified']||!0x1,'phoneNumber':_0x19121b['phoneNumber']||null,'tenantId':_0x19121b['tenantId']||null,'providerData':_0x1b476e,'metadata':new Pi(_0x19121b['createdAt'],_0x19121b['lastLoginAt']),'isAnonymous':_0x68267c};Object['assign'](_0x6edc05,_0x4e8f0a);}async function gf(_0x490060){const _0x3cf809=k(_0x490060);await bn(_0x3cf809),await _0x3cf809['auth']['_persistUserIfCurrent'](_0x3cf809),_0x3cf809['auth']['_notifyListenersIfCurrent'](_0x3cf809);}function mf(_0x20e52e,_0x381ed3){return[..._0x20e52e['filter'](_0x374172=>!_0x381ed3['some'](_0x2ebc30=>_0x2ebc30['providerId']===_0x374172['providerId'])),..._0x381ed3];}function wa(_0x1e4da2){return _0x1e4da2['map'](({providerId:_0x57c29b,..._0x50c4d7})=>({'providerId':_0x57c29b,'uid':_0x50c4d7['rawId']||'','displayName':_0x50c4d7['displayName']||null,'email':_0x50c4d7['email']||null,'phoneNumber':_0x50c4d7['phoneNumber']||null,'photoURL':_0x50c4d7['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x2d0fb0,_0x21fa00){const _0x32aae7=await Ea(_0x2d0fb0,{},async()=>{const _0x57a31a=at({'grant_type':'refresh_token','refresh_token':_0x21fa00})['slice'](0x1),{tokenApiHost:_0x463c53,apiKey:_0x15e043}=_0x2d0fb0['config'],_0x45ea64=await Ia(_0x2d0fb0,_0x463c53,'/v1/token','key='+_0x15e043),_0x2f090f=await _0x2d0fb0['_getAdditionalHeaders']();_0x2f090f['Content-Type']='application/x-www-form-urlencoded';const _0x558c68={'method':'POST','headers':_0x2f090f,'body':_0x57a31a};return _0x2d0fb0['emulatorConfig']&&Wt(_0x2d0fb0['emulatorConfig']['host'])&&(_0x558c68['credentials']='include'),va['fetch']()(_0x45ea64,_0x558c68);});return{'accessToken':_0x32aae7['access_token'],'expiresIn':_0x32aae7['expires_in'],'refreshToken':_0x32aae7['refresh_token']};}async function vf(_0x4959f7,_0x9af924){return Ae(_0x4959f7,'POST','/v2/accounts:revokeToken',Re(_0x4959f7,_0x9af924));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x1cd50d){m(_0x1cd50d['idToken'],'internal-error'),m(typeof _0x1cd50d['idToken']<'u','internal-error'),m(typeof _0x1cd50d['refreshToken']<'u','internal-error');const _0x5212a1='expiresIn'in _0x1cd50d&&typeof _0x1cd50d['expiresIn']<'u'?Number(_0x1cd50d['expiresIn']):Er(_0x1cd50d['idToken']);this['updateTokensAndExpiration'](_0x1cd50d['idToken'],_0x1cd50d['refreshToken'],_0x5212a1);}['updateFromIdToken'](_0x4c4feb){m(_0x4c4feb['length']!==0x0,'internal-error');const _0x32cc14=Er(_0x4c4feb);this['updateTokensAndExpiration'](_0x4c4feb,null,_0x32cc14);}async['getToken'](_0x3f8685,_0x4297ed=!0x1){return!_0x4297ed&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3f8685,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3f8685,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0xf80e19,_0xb9ac65){const {accessToken:_0x43004b,refreshToken:_0x460af0,expiresIn:_0x3b725e}=await yf(_0xf80e19,_0xb9ac65);this['updateTokensAndExpiration'](_0x43004b,_0x460af0,Number(_0x3b725e));}['updateTokensAndExpiration'](_0x8edcda,_0x417800,_0x34c695){this['refreshToken']=_0x417800||null,this['accessToken']=_0x8edcda||null,this['expirationTime']=Date['now']()+_0x34c695*0x3e8;}static['fromJSON'](_0xdb3e81,_0x259998){const {refreshToken:_0x3b5e29,accessToken:_0xa6ea1d,expirationTime:_0x10f9d4}=_0x259998,_0x56d145=new Je();return _0x3b5e29&&(m(typeof _0x3b5e29=='string','internal-error',{'appName':_0xdb3e81}),_0x56d145['refreshToken']=_0x3b5e29),_0xa6ea1d&&(m(typeof _0xa6ea1d=='string','internal-error',{'appName':_0xdb3e81}),_0x56d145['accessToken']=_0xa6ea1d),_0x10f9d4&&(m(typeof _0x10f9d4=='number','internal-error',{'appName':_0xdb3e81}),_0x56d145['expirationTime']=_0x10f9d4),_0x56d145;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x15a8d3){this['accessToken']=_0x15a8d3['accessToken'],this['refreshToken']=_0x15a8d3['refreshToken'],this['expirationTime']=_0x15a8d3['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x296bd5,_0x52980b){m(typeof _0x296bd5=='string'||typeof _0x296bd5>'u','internal-error',{'appName':_0x52980b});}class z{constructor({uid:_0x795350,auth:_0x40eaca,stsTokenManager:_0x4ed3b7,..._0x431c87}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x795350,this['auth']=_0x40eaca,this['stsTokenManager']=_0x4ed3b7,this['accessToken']=_0x4ed3b7['accessToken'],this['displayName']=_0x431c87['displayName']||null,this['email']=_0x431c87['email']||null,this['emailVerified']=_0x431c87['emailVerified']||!0x1,this['phoneNumber']=_0x431c87['phoneNumber']||null,this['photoURL']=_0x431c87['photoURL']||null,this['isAnonymous']=_0x431c87['isAnonymous']||!0x1,this['tenantId']=_0x431c87['tenantId']||null,this['providerData']=_0x431c87['providerData']?[..._0x431c87['providerData']]:[],this['metadata']=new Pi(_0x431c87['createdAt']||void 0x0,_0x431c87['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4c14bf){const _0x25a291=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x4c14bf));return m(_0x25a291,this['auth'],'internal-error'),this['accessToken']!==_0x25a291&&(this['accessToken']=_0x25a291,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x25a291;}['getIdTokenResult'](_0x13313f){return ff(this,_0x13313f);}['reload'](){return gf(this);}['_assign'](_0x477d09){this!==_0x477d09&&(m(this['uid']===_0x477d09['uid'],this['auth'],'internal-error'),this['displayName']=_0x477d09['displayName'],this['photoURL']=_0x477d09['photoURL'],this['email']=_0x477d09['email'],this['emailVerified']=_0x477d09['emailVerified'],this['phoneNumber']=_0x477d09['phoneNumber'],this['isAnonymous']=_0x477d09['isAnonymous'],this['tenantId']=_0x477d09['tenantId'],this['providerData']=_0x477d09['providerData']['map'](_0x8ba378=>({..._0x8ba378})),this['metadata']['_copy'](_0x477d09['metadata']),this['stsTokenManager']['_assign'](_0x477d09['stsTokenManager']));}['_clone'](_0x3865a1){const _0x3ec8d9=new z({...this,'auth':_0x3865a1,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3ec8d9['metadata']['_copy'](this['metadata']),_0x3ec8d9;}['_onReload'](_0x18fd14){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x18fd14,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x5f3103){this['reloadListener']?this['reloadListener'](_0x5f3103):this['reloadUserInfo']=_0x5f3103;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x59cd1f,_0x22d859=!0x1){let _0x15aa5d=!0x1;_0x59cd1f['idToken']&&_0x59cd1f['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x59cd1f),_0x15aa5d=!0x0),_0x22d859&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x15aa5d&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x78b86e=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x78b86e})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x5dabb2=>({..._0x5dabb2})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5f389f,_0xd0775c){const _0x3b0199=_0xd0775c['displayName']??void 0x0,_0x44ef17=_0xd0775c['email']??void 0x0,_0x33aabd=_0xd0775c['phoneNumber']??void 0x0,_0x3cd3dd=_0xd0775c['photoURL']??void 0x0,_0x3d3979=_0xd0775c['tenantId']??void 0x0,_0x48c477=_0xd0775c['_redirectEventId']??void 0x0,_0x283616=_0xd0775c['createdAt']??void 0x0,_0x406512=_0xd0775c['lastLoginAt']??void 0x0,{uid:_0x46c3fd,emailVerified:_0x48b9ac,isAnonymous:_0x22caf1,providerData:_0x15f360,stsTokenManager:_0x94a386}=_0xd0775c;m(_0x46c3fd&&_0x94a386,_0x5f389f,'internal-error');const _0x3f724a=Je['fromJSON'](this['name'],_0x94a386);m(typeof _0x46c3fd=='string',_0x5f389f,'internal-error'),ce(_0x3b0199,_0x5f389f['name']),ce(_0x44ef17,_0x5f389f['name']),m(typeof _0x48b9ac=='boolean',_0x5f389f,'internal-error'),m(typeof _0x22caf1=='boolean',_0x5f389f,'internal-error'),ce(_0x33aabd,_0x5f389f['name']),ce(_0x3cd3dd,_0x5f389f['name']),ce(_0x3d3979,_0x5f389f['name']),ce(_0x48c477,_0x5f389f['name']),ce(_0x283616,_0x5f389f['name']),ce(_0x406512,_0x5f389f['name']);const _0xe54be1=new z({'uid':_0x46c3fd,'auth':_0x5f389f,'email':_0x44ef17,'emailVerified':_0x48b9ac,'displayName':_0x3b0199,'isAnonymous':_0x22caf1,'photoURL':_0x3cd3dd,'phoneNumber':_0x33aabd,'tenantId':_0x3d3979,'stsTokenManager':_0x3f724a,'createdAt':_0x283616,'lastLoginAt':_0x406512});return _0x15f360&&Array['isArray'](_0x15f360)&&(_0xe54be1['providerData']=_0x15f360['map'](_0x135036=>({..._0x135036}))),_0x48c477&&(_0xe54be1['_redirectEventId']=_0x48c477),_0xe54be1;}static async['_fromIdTokenResponse'](_0x4b1c60,_0x23c050,_0x2b858c=!0x1){const _0x2ed4d8=new Je();_0x2ed4d8['updateFromServerResponse'](_0x23c050);const _0x52408d=new z({'uid':_0x23c050['localId'],'auth':_0x4b1c60,'stsTokenManager':_0x2ed4d8,'isAnonymous':_0x2b858c});return await bn(_0x52408d),_0x52408d;}static async['_fromGetAccountInfoResponse'](_0x2581bf,_0x2717d5,_0x346495){const _0x2eb2f8=_0x2717d5['users'][0x0];m(_0x2eb2f8['localId']!==void 0x0,'internal-error');const _0x3df54e=_0x2eb2f8['providerUserInfo']!==void 0x0?wa(_0x2eb2f8['providerUserInfo']):[],_0x229f68=!(_0x2eb2f8['email']&&_0x2eb2f8['passwordHash'])&&!(_0x3df54e!=null&&_0x3df54e['length']),_0x3b40e8=new Je();_0x3b40e8['updateFromIdToken'](_0x346495);const _0x27d127=new z({'uid':_0x2eb2f8['localId'],'auth':_0x2581bf,'stsTokenManager':_0x3b40e8,'isAnonymous':_0x229f68}),_0x42bd3e={'uid':_0x2eb2f8['localId'],'displayName':_0x2eb2f8['displayName']||null,'photoURL':_0x2eb2f8['photoUrl']||null,'email':_0x2eb2f8['email']||null,'emailVerified':_0x2eb2f8['emailVerified']||!0x1,'phoneNumber':_0x2eb2f8['phoneNumber']||null,'tenantId':_0x2eb2f8['tenantId']||null,'providerData':_0x3df54e,'metadata':new Pi(_0x2eb2f8['createdAt'],_0x2eb2f8['lastLoginAt']),'isAnonymous':!(_0x2eb2f8['email']&&_0x2eb2f8['passwordHash'])&&!(_0x3df54e!=null&&_0x3df54e['length'])};return Object['assign'](_0x27d127,_0x42bd3e),_0x27d127;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x465eb6){ae(_0x465eb6 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x26cd88=Ir['get'](_0x465eb6);return _0x26cd88?(ae(_0x26cd88 instanceof _0x465eb6,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x26cd88):(_0x26cd88=new _0x465eb6(),Ir['set'](_0x465eb6,_0x26cd88),_0x26cd88);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x33f5e5,_0x2ee691){this['storage'][_0x33f5e5]=_0x2ee691;}async['_get'](_0x325de9){const _0x539652=this['storage'][_0x325de9];return _0x539652===void 0x0?null:_0x539652;}async['_remove'](_0x18dfcc){delete this['storage'][_0x18dfcc];}['_addListener'](_0x41d949,_0x49329a){}['_removeListener'](_0x59e92e,_0x33716d){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x2448f6,_0x3faec0,_0x244aa0){return'firebase:'+_0x2448f6+':'+_0x3faec0+':'+_0x244aa0;}class Xe{constructor(_0x1b69bf,_0x10407a,_0x32aa0d){this['persistence']=_0x1b69bf,this['auth']=_0x10407a,this['userKey']=_0x32aa0d;const {config:_0x39e756,name:_0x21c606}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x39e756['apiKey'],_0x21c606),this['fullPersistenceKey']=sn('persistence',_0x39e756['apiKey'],_0x21c606),this['boundEventHandler']=_0x10407a['_onStorageEvent']['bind'](_0x10407a),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3cccda){return this['persistence']['_set'](this['fullUserKey'],_0x3cccda['toJSON']());}async['getCurrentUser'](){const _0x2a5015=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2a5015)return null;if(typeof _0x2a5015=='string'){const _0x1f3736=await Sn(this['auth'],{'idToken':_0x2a5015})['catch'](()=>{});return _0x1f3736?z['_fromGetAccountInfoResponse'](this['auth'],_0x1f3736,_0x2a5015):null;}return z['_fromJSON'](this['auth'],_0x2a5015);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3fe25b){if(this['persistence']===_0x3fe25b)return;const _0x1ec2e8=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3fe25b,_0x1ec2e8)return this['setCurrentUser'](_0x1ec2e8);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4387f1,_0x3fcf13,_0x522a5d='authUser'){if(!_0x3fcf13['length'])return new Xe(ne(wr),_0x4387f1,_0x522a5d);const _0x3585a1=(await Promise['all'](_0x3fcf13['map'](async _0x1500b8=>{if(await _0x1500b8['_isAvailable']())return _0x1500b8;})))['filter'](_0x550fec=>_0x550fec);let _0x72b399=_0x3585a1[0x0]||ne(wr);const _0x397e04=sn(_0x522a5d,_0x4387f1['config']['apiKey'],_0x4387f1['name']);let _0x37a33f=null;for(const _0x465d46 of _0x3fcf13)try{const _0x4ac2af=await _0x465d46['_get'](_0x397e04);if(_0x4ac2af){let _0x55bc20;if(typeof _0x4ac2af=='string'){const _0x1499c0=await Sn(_0x4387f1,{'idToken':_0x4ac2af})['catch'](()=>{});if(!_0x1499c0)break;_0x55bc20=await z['_fromGetAccountInfoResponse'](_0x4387f1,_0x1499c0,_0x4ac2af);}else _0x55bc20=z['_fromJSON'](_0x4387f1,_0x4ac2af);_0x465d46!==_0x72b399&&(_0x37a33f=_0x55bc20),_0x72b399=_0x465d46;break;}}catch{}const _0xce9739=_0x3585a1['filter'](_0x1cc638=>_0x1cc638['_shouldAllowMigration']);return!_0x72b399['_shouldAllowMigration']||!_0xce9739['length']?new Xe(_0x72b399,_0x4387f1,_0x522a5d):(_0x72b399=_0xce9739[0x0],_0x37a33f&&await _0x72b399['_set'](_0x397e04,_0x37a33f['toJSON']()),await Promise['all'](_0x3fcf13['map'](async _0x28229a=>{if(_0x28229a!==_0x72b399)try{await _0x28229a['_remove'](_0x397e04);}catch{}})),new Xe(_0x72b399,_0x4387f1,_0x522a5d));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x4cbbf6){const _0x19a817=_0x4cbbf6['toLowerCase']();if(_0x19a817['includes']('opera/')||_0x19a817['includes']('opr/')||_0x19a817['includes']('opios/'))return'Opera';if(Ra(_0x19a817))return'IEMobile';if(_0x19a817['includes']('msie')||_0x19a817['includes']('trident/'))return'IE';if(_0x19a817['includes']('edge/'))return'Edge';if(Ta(_0x19a817))return'Firefox';if(_0x19a817['includes']('silk/'))return'Silk';if(ka(_0x19a817))return'Blackberry';if(Na(_0x19a817))return'Webos';if(Sa(_0x19a817))return'Safari';if((_0x19a817['includes']('chrome/')||ba(_0x19a817))&&!_0x19a817['includes']('edge/'))return'Chrome';if(Aa(_0x19a817))return'Android';{const _0x3200c9=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x45cc8d=_0x4cbbf6['match'](_0x3200c9);if((_0x45cc8d==null?void 0x0:_0x45cc8d['length'])===0x2)return _0x45cc8d[0x1];}return'Other';}function Ta(_0x3895c8=W()){return/firefox\//i['test'](_0x3895c8);}function Sa(_0x1905aa=W()){const _0x475f9d=_0x1905aa['toLowerCase']();return _0x475f9d['includes']('safari/')&&!_0x475f9d['includes']('chrome/')&&!_0x475f9d['includes']('crios/')&&!_0x475f9d['includes']('android');}function ba(_0x101a5e=W()){return/crios\//i['test'](_0x101a5e);}function Ra(_0x4450a3=W()){return/iemobile/i['test'](_0x4450a3);}function Aa(_0x51b43e=W()){return/android/i['test'](_0x51b43e);}function ka(_0xfef9f0=W()){return/blackberry/i['test'](_0xfef9f0);}function Na(_0x49727a=W()){return/webos/i['test'](_0x49727a);}function Cs(_0x3b525d=W()){return/iphone|ipad|ipod/i['test'](_0x3b525d)||/macintosh/i['test'](_0x3b525d)&&/mobile/i['test'](_0x3b525d);}function Ef(_0x244b10=W()){var _0x7a1849;return Cs(_0x244b10)&&!!((_0x7a1849=window['navigator'])!=null&&_0x7a1849['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x498a19=W()){return Cs(_0x498a19)||Aa(_0x498a19)||Na(_0x498a19)||ka(_0x498a19)||/windows phone/i['test'](_0x498a19)||Ra(_0x498a19);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x487723,_0x2476b6=[]){let _0x264363;switch(_0x487723){case'Browser':_0x264363=Cr(W());break;case'Worker':_0x264363=Cr(W())+'-'+_0x487723;break;default:_0x264363=_0x487723;}const _0x56ae92=_0x2476b6['length']?_0x2476b6['join'](','):'FirebaseCore-web';return _0x264363+'/JsCore/'+ct+'/'+_0x56ae92;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x233e03){this['auth']=_0x233e03,this['queue']=[];}['pushCallback'](_0x14468c,_0x464e43){const _0x5d0135=_0x1f5723=>new Promise((_0x258acb,_0x42856b)=>{try{const _0x163e58=_0x14468c(_0x1f5723);_0x258acb(_0x163e58);}catch(_0x532455){_0x42856b(_0x532455);}});_0x5d0135['onAbort']=_0x464e43,this['queue']['push'](_0x5d0135);const _0x5f3657=this['queue']['length']-0x1;return()=>{this['queue'][_0x5f3657]=()=>Promise['resolve']();};}async['runMiddleware'](_0x427105){if(this['auth']['currentUser']===_0x427105)return;const _0x2044b5=[];try{for(const _0x237f4b of this['queue'])await _0x237f4b(_0x427105),_0x237f4b['onAbort']&&_0x2044b5['push'](_0x237f4b['onAbort']);}catch(_0x1b6942){_0x2044b5['reverse']();for(const _0x2c6138 of _0x2044b5)try{_0x2c6138();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x1b6942==null?void 0x0:_0x1b6942['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x550c14,_0x20f525={}){return Ae(_0x550c14,'GET','/v2/passwordPolicy',Re(_0x550c14,_0x20f525));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x202d12){var _0x9bf429;const _0x27bcdc=_0x202d12['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x27bcdc['minPasswordLength']??Tf,_0x27bcdc['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x27bcdc['maxPasswordLength']),_0x27bcdc['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x27bcdc['containsLowercaseCharacter']),_0x27bcdc['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x27bcdc['containsUppercaseCharacter']),_0x27bcdc['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x27bcdc['containsNumericCharacter']),_0x27bcdc['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x27bcdc['containsNonAlphanumericCharacter']),this['enforcementState']=_0x202d12['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x9bf429=_0x202d12['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x9bf429['join'](''))??'',this['forceUpgradeOnSignin']=_0x202d12['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x202d12['schemaVersion'];}['validatePassword'](_0x25ff9c){const _0x1cefdc={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x25ff9c,_0x1cefdc),this['validatePasswordCharacterOptions'](_0x25ff9c,_0x1cefdc),_0x1cefdc['isValid']&&(_0x1cefdc['isValid']=_0x1cefdc['meetsMinPasswordLength']??!0x0),_0x1cefdc['isValid']&&(_0x1cefdc['isValid']=_0x1cefdc['meetsMaxPasswordLength']??!0x0),_0x1cefdc['isValid']&&(_0x1cefdc['isValid']=_0x1cefdc['containsLowercaseLetter']??!0x0),_0x1cefdc['isValid']&&(_0x1cefdc['isValid']=_0x1cefdc['containsUppercaseLetter']??!0x0),_0x1cefdc['isValid']&&(_0x1cefdc['isValid']=_0x1cefdc['containsNumericCharacter']??!0x0),_0x1cefdc['isValid']&&(_0x1cefdc['isValid']=_0x1cefdc['containsNonAlphanumericCharacter']??!0x0),_0x1cefdc;}['validatePasswordLengthOptions'](_0x3cd202,_0x263837){const _0x4275f5=this['customStrengthOptions']['minPasswordLength'],_0x442fdd=this['customStrengthOptions']['maxPasswordLength'];_0x4275f5&&(_0x263837['meetsMinPasswordLength']=_0x3cd202['length']>=_0x4275f5),_0x442fdd&&(_0x263837['meetsMaxPasswordLength']=_0x3cd202['length']<=_0x442fdd);}['validatePasswordCharacterOptions'](_0x5efcf8,_0x50ae30){this['updatePasswordCharacterOptionsStatuses'](_0x50ae30,!0x1,!0x1,!0x1,!0x1);let _0x527327;for(let _0x4c6b0a=0x0;_0x4c6b0a<_0x5efcf8['length'];_0x4c6b0a++)_0x527327=_0x5efcf8['charAt'](_0x4c6b0a),this['updatePasswordCharacterOptionsStatuses'](_0x50ae30,_0x527327>='a'&&_0x527327<='z',_0x527327>='A'&&_0x527327<='Z',_0x527327>='0'&&_0x527327<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x527327));}['updatePasswordCharacterOptionsStatuses'](_0x2d20c8,_0x5ed334,_0x3efc80,_0x1a214e,_0x55d487){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2d20c8['containsLowercaseLetter']||(_0x2d20c8['containsLowercaseLetter']=_0x5ed334)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2d20c8['containsUppercaseLetter']||(_0x2d20c8['containsUppercaseLetter']=_0x3efc80)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2d20c8['containsNumericCharacter']||(_0x2d20c8['containsNumericCharacter']=_0x1a214e)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2d20c8['containsNonAlphanumericCharacter']||(_0x2d20c8['containsNonAlphanumericCharacter']=_0x55d487));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x3be5f9,_0x21b4e4,_0x377045,_0x550d7f){this['app']=_0x3be5f9,this['heartbeatServiceProvider']=_0x21b4e4,this['appCheckServiceProvider']=_0x377045,this['config']=_0x550d7f,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3be5f9['name'],this['clientVersion']=_0x550d7f['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x33e92c=>this['_resolvePersistenceManagerAvailable']=_0x33e92c);}['_initializeWithPersistence'](_0x5af3e3,_0x142f25){return _0x142f25&&(this['_popupRedirectResolver']=ne(_0x142f25)),this['_initializationPromise']=this['queue'](async()=>{var _0x2c7063,_0x2927be,_0xd4b360;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x5af3e3),(_0x2c7063=this['_resolvePersistenceManagerAvailable'])==null||_0x2c7063['call'](this),!this['_deleted'])){if((_0x2927be=this['_popupRedirectResolver'])!=null&&_0x2927be['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x142f25),this['lastNotifiedUid']=((_0xd4b360=this['currentUser'])==null?void 0x0:_0xd4b360['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x403041=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x403041)){if(this['currentUser']&&_0x403041&&this['currentUser']['uid']===_0x403041['uid']){this['_currentUser']['_assign'](_0x403041),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x403041,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5718d6){try{const _0x1c5cc8=await Sn(this,{'idToken':_0x5718d6}),_0x42e3ad=await z['_fromGetAccountInfoResponse'](this,_0x1c5cc8,_0x5718d6);await this['directlySetCurrentUser'](_0x42e3ad);}catch(_0x45aeb1){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x45aeb1),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x222132){var _0x11e67c;if(H(this['app'])){const _0x2f6e95=this['app']['settings']['authIdToken'];return _0x2f6e95?new Promise(_0x19cdc7=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2f6e95)['then'](_0x19cdc7,_0x19cdc7));}):this['directlySetCurrentUser'](null);}const _0x2e896b=await this['assertedPersistence']['getCurrentUser']();let _0x4c9288=_0x2e896b,_0xfc4e59=!0x1;if(_0x222132&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3ad297=(_0x11e67c=this['redirectUser'])==null?void 0x0:_0x11e67c['_redirectEventId'],_0x145644=_0x4c9288==null?void 0x0:_0x4c9288['_redirectEventId'],_0x49e2a7=await this['tryRedirectSignIn'](_0x222132);(!_0x3ad297||_0x3ad297===_0x145644)&&(_0x49e2a7!=null&&_0x49e2a7['user'])&&(_0x4c9288=_0x49e2a7['user'],_0xfc4e59=!0x0);}if(!_0x4c9288)return this['directlySetCurrentUser'](null);if(!_0x4c9288['_redirectEventId']){if(_0xfc4e59)try{await this['beforeStateQueue']['runMiddleware'](_0x4c9288);}catch(_0x2d2d43){_0x4c9288=_0x2e896b,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2d2d43));}return _0x4c9288?this['reloadAndSetCurrentUserOrClear'](_0x4c9288):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4c9288['_redirectEventId']?this['directlySetCurrentUser'](_0x4c9288):this['reloadAndSetCurrentUserOrClear'](_0x4c9288);}async['tryRedirectSignIn'](_0x1ab10e){let _0x375602=null;try{_0x375602=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1ab10e,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x375602;}async['reloadAndSetCurrentUserOrClear'](_0x5bd457){try{await bn(_0x5bd457);}catch(_0x37c5c1){if((_0x37c5c1==null?void 0x0:_0x37c5c1['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5bd457);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2b4225){if(H(this['app']))return Promise['reject'](se(this));const _0x32e556=_0x2b4225?k(_0x2b4225):null;return _0x32e556&&m(_0x32e556['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x32e556&&_0x32e556['_clone'](this));}async['_updateCurrentUser'](_0x56ebab,_0x5b70cf=!0x1){if(!this['_deleted'])return _0x56ebab&&m(this['tenantId']===_0x56ebab['tenantId'],this,'tenant-id-mismatch'),_0x5b70cf||await this['beforeStateQueue']['runMiddleware'](_0x56ebab),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x56ebab),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2b5aaf){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x2b5aaf));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xa3c349){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4285f5=this['_getPasswordPolicyInternal']();return _0x4285f5['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4285f5['validatePassword'](_0xa3c349);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x5c42bb=await Cf(this),_0x15391e=new Sf(_0x5c42bb);this['tenantId']===null?this['_projectPasswordPolicy']=_0x15391e:this['_tenantPasswordPolicies'][this['tenantId']]=_0x15391e;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x3c41d6){this['_errorFactory']=new Ut('auth','Firebase',_0x3c41d6());}['onAuthStateChanged'](_0x1e2628,_0x253285,_0x5ba910){return this['registerStateListener'](this['authStateSubscription'],_0x1e2628,_0x253285,_0x5ba910);}['beforeAuthStateChanged'](_0x10acb3,_0x2bf33d){return this['beforeStateQueue']['pushCallback'](_0x10acb3,_0x2bf33d);}['onIdTokenChanged'](_0x5d2678,_0x317c82,_0x593c0a){return this['registerStateListener'](this['idTokenSubscription'],_0x5d2678,_0x317c82,_0x593c0a);}['authStateReady'](){return new Promise((_0x4dbac0,_0x48f622)=>{if(this['currentUser'])_0x4dbac0();else{const _0x21720a=this['onAuthStateChanged'](()=>{_0x21720a(),_0x4dbac0();},_0x48f622);}});}async['revokeAccessToken'](_0x26fb4a){if(this['currentUser']){const _0x2e7311=await this['currentUser']['getIdToken'](),_0x475ebe={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x26fb4a,'idToken':_0x2e7311};this['tenantId']!=null&&(_0x475ebe['tenantId']=this['tenantId']),await vf(this,_0x475ebe);}}['toJSON'](){var _0x233305;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x233305=this['_currentUser'])==null?void 0x0:_0x233305['toJSON']()};}async['_setRedirectUser'](_0x215481,_0x19e038){const _0x40a81f=await this['getOrInitRedirectPersistenceManager'](_0x19e038);return _0x215481===null?_0x40a81f['removeCurrentUser']():_0x40a81f['setCurrentUser'](_0x215481);}async['getOrInitRedirectPersistenceManager'](_0x32722e){if(!this['redirectPersistenceManager']){const _0x45e505=_0x32722e&&ne(_0x32722e)||this['_popupRedirectResolver'];m(_0x45e505,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x45e505['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x4bf28a){var _0x23d640,_0x2b02c8;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x23d640=this['_currentUser'])==null?void 0x0:_0x23d640['_redirectEventId'])===_0x4bf28a?this['_currentUser']:((_0x2b02c8=this['redirectUser'])==null?void 0x0:_0x2b02c8['_redirectEventId'])===_0x4bf28a?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5fee1d){if(_0x5fee1d===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5fee1d));}['_notifyListenersIfCurrent'](_0x76b109){_0x76b109===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1db1db;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x338f95=((_0x1db1db=this['currentUser'])==null?void 0x0:_0x1db1db['uid'])??null;this['lastNotifiedUid']!==_0x338f95&&(this['lastNotifiedUid']=_0x338f95,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3fa217,_0x342868,_0x389336,_0x4125c1){if(this['_deleted'])return()=>{};const _0x411c51=typeof _0x342868=='function'?_0x342868:_0x342868['next']['bind'](_0x342868);let _0x4f40a9=!0x1;const _0x57b90d=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x57b90d,this,'internal-error'),_0x57b90d['then'](()=>{_0x4f40a9||_0x411c51(this['currentUser']);}),typeof _0x342868=='function'){const _0x5dde3e=_0x3fa217['addObserver'](_0x342868,_0x389336,_0x4125c1);return()=>{_0x4f40a9=!0x0,_0x5dde3e();};}else{const _0x5dc62c=_0x3fa217['addObserver'](_0x342868);return()=>{_0x4f40a9=!0x0,_0x5dc62c();};}}async['directlySetCurrentUser'](_0x1982a3){this['currentUser']&&this['currentUser']!==_0x1982a3&&this['_currentUser']['_stopProactiveRefresh'](),_0x1982a3&&this['isProactiveRefreshEnabled']&&_0x1982a3['_startProactiveRefresh'](),this['currentUser']=_0x1982a3,_0x1982a3?await this['assertedPersistence']['setCurrentUser'](_0x1982a3):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0xdd3345){return this['operations']=this['operations']['then'](_0xdd3345,_0xdd3345),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1d4571){!_0x1d4571||this['frameworks']['includes'](_0x1d4571)||(this['frameworks']['push'](_0x1d4571),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x6068ca;const _0x4b98c1={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4b98c1['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x5f48fe=await((_0x6068ca=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x6068ca['getHeartbeatsHeader']());_0x5f48fe&&(_0x4b98c1['X-Firebase-Client']=_0x5f48fe);const _0x49d8f8=await this['_getAppCheckToken']();return _0x49d8f8&&(_0x4b98c1['X-Firebase-AppCheck']=_0x49d8f8),_0x4b98c1;}async['_getAppCheckToken'](){var _0x21c4cf;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x59ad7c=await((_0x21c4cf=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x21c4cf['getToken']());return _0x59ad7c!=null&&_0x59ad7c['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x59ad7c['error']),_0x59ad7c==null?void 0x0:_0x59ad7c['token'];}}function qe(_0xe5484a){return k(_0xe5484a);}class Tr{constructor(_0x4bdc94){this['auth']=_0x4bdc94,this['observer']=null,this['addObserver']=Ic(_0x4e9a4e=>this['observer']=_0x4e9a4e);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x44f89e){zn=_0x44f89e;}function Da(_0x52b68c){return zn['loadJS'](_0x52b68c);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x2719d7){return'__'+_0x2719d7+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x46ed6b){_0x46ed6b();}['execute'](_0x1c9482,_0x230379){return Promise['resolve']('token');}['render'](_0x5e27f6,_0x166197){return'';}}class Of{['ready'](_0x613ea){_0x613ea();}['execute'](_0x2777ae,_0x426d41){return Promise['resolve']('token');}['render'](_0x365bf1,_0x69b846){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x8826dc){this['type']=Df,this['auth']=qe(_0x8826dc);}async['verify'](_0x500385='verify',_0x226cdb=!0x1){async function _0x24431b(_0x2f7a91){if(!_0x226cdb){if(_0x2f7a91['tenantId']==null&&_0x2f7a91['_agentRecaptchaConfig']!=null)return _0x2f7a91['_agentRecaptchaConfig']['siteKey'];if(_0x2f7a91['tenantId']!=null&&_0x2f7a91['_tenantRecaptchaConfigs'][_0x2f7a91['tenantId']]!==void 0x0)return _0x2f7a91['_tenantRecaptchaConfigs'][_0x2f7a91['tenantId']]['siteKey'];}return new Promise(async(_0x1dc8a9,_0x4b9e79)=>{uf(_0x2f7a91,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2777de=>{if(_0x2777de['recaptchaKey']===void 0x0)_0x4b9e79(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5d7aa6=new hf(_0x2777de);return _0x2f7a91['tenantId']==null?_0x2f7a91['_agentRecaptchaConfig']=_0x5d7aa6:_0x2f7a91['_tenantRecaptchaConfigs'][_0x2f7a91['tenantId']]=_0x5d7aa6,_0x1dc8a9(_0x5d7aa6['siteKey']);}})['catch'](_0x1440b1=>{_0x4b9e79(_0x1440b1);});});}function _0x15a8d7(_0x523d76,_0x586777,_0x49ff07){const _0x37245b=window['grecaptcha'];vr(_0x37245b)?_0x37245b['enterprise']['ready'](()=>{_0x37245b['enterprise']['execute'](_0x523d76,{'action':_0x500385})['then'](_0xdbda6f=>{_0x586777(_0xdbda6f);})['catch'](()=>{_0x586777(Ma);});}):_0x49ff07(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x53a68c,_0x1c3628)=>{_0x24431b(this['auth'])['then'](async _0x5b5558=>{if(!_0x226cdb&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x15a8d7(_0x5b5558,_0x53a68c,_0x1c3628);else{if(typeof window>'u'){_0x1c3628(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x346d7e=Af();_0x346d7e['length']!==0x0&&(_0x346d7e+=_0x5b5558+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x1fa852;(_0x1fa852=le['scriptInjectionDeferred'])==null||_0x1fa852['resolve']();},Da(_0x346d7e)['then'](()=>{var _0x25cf70;return(_0x25cf70=le['scriptInjectionDeferred'])==null?void 0x0:_0x25cf70['promise'];})['then'](()=>{_0x15a8d7(_0x5b5558,_0x53a68c,_0x1c3628);})['catch'](_0x5c4c83=>{_0x1c3628(_0x5c4c83);});}})['catch'](_0x37df25=>{_0x1c3628(_0x37df25);});});}}le['scriptInjectionDeferred']=null;async function br(_0x1c4e7e,_0xca4c6f,_0x17d9f0,_0x168392=!0x1,_0x10f8bc=!0x1){const _0xc5ae39=new le(_0x1c4e7e);let _0x30252d;if(_0x10f8bc)_0x30252d=Ma;else try{_0x30252d=await _0xc5ae39['verify'](_0x17d9f0);}catch{_0x30252d=await _0xc5ae39['verify'](_0x17d9f0,!0x0);}const _0x7c7cee={..._0xca4c6f};if(_0x17d9f0==='mfaSmsEnrollment'||_0x17d9f0==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x7c7cee){const _0x2ccf0c=_0x7c7cee['phoneEnrollmentInfo']['phoneNumber'],_0x5bd81f=_0x7c7cee['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x7c7cee,{'phoneEnrollmentInfo':{'phoneNumber':_0x2ccf0c,'recaptchaToken':_0x5bd81f,'captchaResponse':_0x30252d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x7c7cee){const _0x540980=_0x7c7cee['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x7c7cee,{'phoneSignInInfo':{'recaptchaToken':_0x540980,'captchaResponse':_0x30252d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x7c7cee;}return _0x168392?Object['assign'](_0x7c7cee,{'captchaResp':_0x30252d}):Object['assign'](_0x7c7cee,{'captchaResponse':_0x30252d}),Object['assign'](_0x7c7cee,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x7c7cee,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x7c7cee;}async function Oi(_0x52834d,_0x2d4880,_0x2481c4,_0xdf8f4f,_0x387337){var _0xe3498b;if((_0xe3498b=_0x52834d['_getRecaptchaConfig']())!=null&&_0xe3498b['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xf889f6=await br(_0x52834d,_0x2d4880,_0x2481c4,_0x2481c4==='getOobCode');return _0xdf8f4f(_0x52834d,_0xf889f6);}else return _0xdf8f4f(_0x52834d,_0x2d4880)['catch'](async _0x5921f2=>{if(_0x5921f2['code']==='auth/missing-recaptcha-token'){console['log'](_0x2481c4+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x29b057=await br(_0x52834d,_0x2d4880,_0x2481c4,_0x2481c4==='getOobCode');return _0xdf8f4f(_0x52834d,_0x29b057);}else return Promise['reject'](_0x5921f2);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x54caea,_0x438f65){const _0x251b5e=Ui(_0x54caea,'auth');if(_0x251b5e['isInitialized']()){const _0x4832c0=_0x251b5e['getImmediate'](),_0x21a2c8=_0x251b5e['getOptions']();if(De(_0x21a2c8,_0x438f65??{}))return _0x4832c0;K(_0x4832c0,'already-initialized');}return _0x251b5e['initialize']({'options':_0x438f65});}function Lf(_0x5fd351,_0x5d243d){const _0x236325=(_0x5d243d==null?void 0x0:_0x5d243d['persistence'])||[],_0x1b0ef3=(Array['isArray'](_0x236325)?_0x236325:[_0x236325])['map'](ne);_0x5d243d!=null&&_0x5d243d['errorMap']&&_0x5fd351['_updateErrorMap'](_0x5d243d['errorMap']),_0x5fd351['_initializeWithPersistence'](_0x1b0ef3,_0x5d243d==null?void 0x0:_0x5d243d['popupRedirectResolver']);}function xf(_0x209907,_0x197f27,_0x5c25c7){const _0x56f951=qe(_0x209907);m(/^https?:\/\//['test'](_0x197f27),_0x56f951,'invalid-emulator-scheme');const _0x57bd3f=!0x1,_0x273a3f=La(_0x197f27),{host:_0xc33b4c,port:_0xad6257}=Ff(_0x197f27),_0x2be476=_0xad6257===null?'':':'+_0xad6257,_0x5cd794={'url':_0x273a3f+'//'+_0xc33b4c+_0x2be476+'/'},_0x1afe43=Object['freeze']({'host':_0xc33b4c,'port':_0xad6257,'protocol':_0x273a3f['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x57bd3f})});if(!_0x56f951['_canInitEmulator']){m(_0x56f951['config']['emulator']&&_0x56f951['emulatorConfig'],_0x56f951,'emulator-config-failed'),m(De(_0x5cd794,_0x56f951['config']['emulator'])&&De(_0x1afe43,_0x56f951['emulatorConfig']),_0x56f951,'emulator-config-failed');return;}_0x56f951['config']['emulator']=_0x5cd794,_0x56f951['emulatorConfig']=_0x1afe43,_0x56f951['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0xc33b4c)?jr(_0x273a3f+'//'+_0xc33b4c+_0x2be476):Uf();}function La(_0x3a29ec){const _0x2b20fd=_0x3a29ec['indexOf'](':');return _0x2b20fd<0x0?'':_0x3a29ec['substr'](0x0,_0x2b20fd+0x1);}function Ff(_0x30934e){const _0x4104d2=La(_0x30934e),_0x27e589=/(\/\/)?([^?#/]+)/['exec'](_0x30934e['substr'](_0x4104d2['length']));if(!_0x27e589)return{'host':'','port':null};const _0x4733c3=_0x27e589[0x2]['split']('@')['pop']()||'',_0x2164c6=/^(\[[^\]]+\])(:|$)/['exec'](_0x4733c3);if(_0x2164c6){const _0x232697=_0x2164c6[0x1];return{'host':_0x232697,'port':Rr(_0x4733c3['substr'](_0x232697['length']+0x1))};}else{const [_0x364e27,_0x3fa939]=_0x4733c3['split'](':');return{'host':_0x364e27,'port':Rr(_0x3fa939)};}}function Rr(_0x3a66b9){if(!_0x3a66b9)return null;const _0x56ebeb=Number(_0x3a66b9);return isNaN(_0x56ebeb)?null:_0x56ebeb;}function Uf(){function _0x43db45(){const _0xc6f94f=document['createElement']('p'),_0x2a2934=_0xc6f94f['style'];_0xc6f94f['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2a2934['position']='fixed',_0x2a2934['width']='100%',_0x2a2934['backgroundColor']='#ffffff',_0x2a2934['border']='.1em\x20solid\x20#000000',_0x2a2934['color']='#b50000',_0x2a2934['bottom']='0px',_0x2a2934['left']='0px',_0x2a2934['margin']='0px',_0x2a2934['zIndex']='10000',_0x2a2934['textAlign']='center',_0xc6f94f['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xc6f94f);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x43db45):_0x43db45());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x21a714,_0x895599){this['providerId']=_0x21a714,this['signInMethod']=_0x895599;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x4eac58){return te('not\x20implemented');}['_linkToIdToken'](_0x37e015,_0xcfba58){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x3999c7){return te('not\x20implemented');}}async function Wf(_0x40a58e,_0x1f3dfc){return Ae(_0x40a58e,'POST','/v1/accounts:signUp',_0x1f3dfc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x498fc,_0x1dc537){return Yt(_0x498fc,'POST','/v1/accounts:signInWithPassword',Re(_0x498fc,_0x1dc537));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x1e520b,_0xa5859c){return Yt(_0x1e520b,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1e520b,_0xa5859c));}async function Hf(_0x182af4,_0xe1ed4d){return Yt(_0x182af4,'POST','/v1/accounts:signInWithEmailLink',Re(_0x182af4,_0xe1ed4d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0xf93638,_0x1af2e4,_0x12d6d1,_0x2e94f3=null){super('password',_0x12d6d1),this['_email']=_0xf93638,this['_password']=_0x1af2e4,this['_tenantId']=_0x2e94f3;}static['_fromEmailAndPassword'](_0x413c4a,_0x47cb62){return new Ft(_0x413c4a,_0x47cb62,'password');}static['_fromEmailAndCode'](_0x18b169,_0x30bd8f,_0x5e50b1=null){return new Ft(_0x18b169,_0x30bd8f,'emailLink',_0x5e50b1);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x133567){const _0x1a021f=typeof _0x133567=='string'?JSON['parse'](_0x133567):_0x133567;if(_0x1a021f!=null&&_0x1a021f['email']&&(_0x1a021f!=null&&_0x1a021f['password'])){if(_0x1a021f['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1a021f['email'],_0x1a021f['password']);if(_0x1a021f['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1a021f['email'],_0x1a021f['password'],_0x1a021f['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4610c2){switch(this['signInMethod']){case'password':const _0x141712={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x4610c2,_0x141712,'signInWithPassword',Bf);case'emailLink':return Vf(_0x4610c2,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x4610c2,'internal-error');}}async['_linkToIdToken'](_0x37971a,_0x35a4eb){switch(this['signInMethod']){case'password':const _0x240b1a={'idToken':_0x35a4eb,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x37971a,_0x240b1a,'signUpPassword',Wf);case'emailLink':return Hf(_0x37971a,{'idToken':_0x35a4eb,'email':this['_email'],'oobCode':this['_password']});default:K(_0x37971a,'internal-error');}}['_getReauthenticationResolver'](_0x3e3f0d){return this['_getIdTokenResponse'](_0x3e3f0d);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x5163f4,_0x57b1d7){return Yt(_0x5163f4,'POST','/v1/accounts:signInWithIdp',Re(_0x5163f4,_0x57b1d7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x90a650){const _0x15daeb=new We(_0x90a650['providerId'],_0x90a650['signInMethod']);return _0x90a650['idToken']||_0x90a650['accessToken']?(_0x90a650['idToken']&&(_0x15daeb['idToken']=_0x90a650['idToken']),_0x90a650['accessToken']&&(_0x15daeb['accessToken']=_0x90a650['accessToken']),_0x90a650['nonce']&&!_0x90a650['pendingToken']&&(_0x15daeb['nonce']=_0x90a650['nonce']),_0x90a650['pendingToken']&&(_0x15daeb['pendingToken']=_0x90a650['pendingToken'])):_0x90a650['oauthToken']&&_0x90a650['oauthTokenSecret']?(_0x15daeb['accessToken']=_0x90a650['oauthToken'],_0x15daeb['secret']=_0x90a650['oauthTokenSecret']):K('argument-error'),_0x15daeb;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5c04d7){const _0x385920=typeof _0x5c04d7=='string'?JSON['parse'](_0x5c04d7):_0x5c04d7,{providerId:_0xd54821,signInMethod:_0x1f72e7,..._0x5d5bfc}=_0x385920;if(!_0xd54821||!_0x1f72e7)return null;const _0x5f0151=new We(_0xd54821,_0x1f72e7);return _0x5f0151['idToken']=_0x5d5bfc['idToken']||void 0x0,_0x5f0151['accessToken']=_0x5d5bfc['accessToken']||void 0x0,_0x5f0151['secret']=_0x5d5bfc['secret'],_0x5f0151['nonce']=_0x5d5bfc['nonce'],_0x5f0151['pendingToken']=_0x5d5bfc['pendingToken']||null,_0x5f0151;}['_getIdTokenResponse'](_0x5f0230){const _0x3d7538=this['buildRequest']();return Ze(_0x5f0230,_0x3d7538);}['_linkToIdToken'](_0x3f3faf,_0x222570){const _0x4bbee6=this['buildRequest']();return _0x4bbee6['idToken']=_0x222570,Ze(_0x3f3faf,_0x4bbee6);}['_getReauthenticationResolver'](_0x4f60dd){const _0x166638=this['buildRequest']();return _0x166638['autoCreate']=!0x1,Ze(_0x4f60dd,_0x166638);}['buildRequest'](){const _0x116f93={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x116f93['pendingToken']=this['pendingToken'];else{const _0x1aa623={};this['idToken']&&(_0x1aa623['id_token']=this['idToken']),this['accessToken']&&(_0x1aa623['access_token']=this['accessToken']),this['secret']&&(_0x1aa623['oauth_token_secret']=this['secret']),_0x1aa623['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x1aa623['nonce']=this['nonce']),_0x116f93['postBody']=at(_0x1aa623);}return _0x116f93;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x91733){switch(_0x91733){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x5d87cf){const _0x4431de=yt(vt(_0x5d87cf))['link'],_0x5b758c=_0x4431de?yt(vt(_0x4431de))['deep_link_id']:null,_0x40269f=yt(vt(_0x5d87cf))['deep_link_id'];return(_0x40269f?yt(vt(_0x40269f))['link']:null)||_0x40269f||_0x5b758c||_0x4431de||_0x5d87cf;}class Ss{constructor(_0x423c13){const _0x1e7980=yt(vt(_0x423c13)),_0x2781b9=_0x1e7980['apiKey']??null,_0x437e9c=_0x1e7980['oobCode']??null,_0x38d659=Gf(_0x1e7980['mode']??null);m(_0x2781b9&&_0x437e9c&&_0x38d659,'argument-error'),this['apiKey']=_0x2781b9,this['operation']=_0x38d659,this['code']=_0x437e9c,this['continueUrl']=_0x1e7980['continueUrl']??null,this['languageCode']=_0x1e7980['lang']??null,this['tenantId']=_0x1e7980['tenantId']??null;}static['parseLink'](_0x457af5){const _0x1ff403=qf(_0x457af5);try{return new Ss(_0x1ff403);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x237021,_0x5441a5){return Ft['_fromEmailAndPassword'](_0x237021,_0x5441a5);}static['credentialWithLink'](_0xa3c273,_0x5583d6){const _0x13a3c0=Ss['parseLink'](_0x5583d6);return m(_0x13a3c0,'argument-error'),Ft['_fromEmailAndCode'](_0xa3c273,_0x13a3c0['code'],_0x13a3c0['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x31bf17){this['providerId']=_0x31bf17,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x50df26){this['defaultLanguageCode']=_0x50df26;}['setCustomParameters'](_0x4d1b28){return this['customParameters']=_0x4d1b28,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3a3ee3){return this['scopes']['includes'](_0x3a3ee3)||this['scopes']['push'](_0x3a3ee3),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x3d573a){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3d573a});}static['credentialFromResult'](_0x3d3ce2){return he['credentialFromTaggedObject'](_0x3d3ce2);}static['credentialFromError'](_0x418cd8){return he['credentialFromTaggedObject'](_0x418cd8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3844a2}){if(!_0x3844a2||!('oauthAccessToken'in _0x3844a2)||!_0x3844a2['oauthAccessToken'])return null;try{return he['credential'](_0x3844a2['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x311b15,_0x497807){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x311b15,'accessToken':_0x497807});}static['credentialFromResult'](_0x340f7a){return ue['credentialFromTaggedObject'](_0x340f7a);}static['credentialFromError'](_0x4569dc){return ue['credentialFromTaggedObject'](_0x4569dc['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5da53a}){if(!_0x5da53a)return null;const {oauthIdToken:_0x43a5e5,oauthAccessToken:_0x1d4d27}=_0x5da53a;if(!_0x43a5e5&&!_0x1d4d27)return null;try{return ue['credential'](_0x43a5e5,_0x1d4d27);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x5a5580){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5a5580});}static['credentialFromResult'](_0x2e116d){return de['credentialFromTaggedObject'](_0x2e116d);}static['credentialFromError'](_0x591c21){return de['credentialFromTaggedObject'](_0x591c21['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x56edec}){if(!_0x56edec||!('oauthAccessToken'in _0x56edec)||!_0x56edec['oauthAccessToken'])return null;try{return de['credential'](_0x56edec['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x17c962,_0x2f61af){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x17c962,'oauthTokenSecret':_0x2f61af});}static['credentialFromResult'](_0x4a7fcd){return fe['credentialFromTaggedObject'](_0x4a7fcd);}static['credentialFromError'](_0x5927dd){return fe['credentialFromTaggedObject'](_0x5927dd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xba2b79}){if(!_0xba2b79)return null;const {oauthAccessToken:_0x4c7914,oauthTokenSecret:_0x518d51}=_0xba2b79;if(!_0x4c7914||!_0x518d51)return null;try{return fe['credential'](_0x4c7914,_0x518d51);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x278b95,_0x384f80){return Yt(_0x278b95,'POST','/v1/accounts:signUp',Re(_0x278b95,_0x384f80));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xba96d7){this['user']=_0xba96d7['user'],this['providerId']=_0xba96d7['providerId'],this['_tokenResponse']=_0xba96d7['_tokenResponse'],this['operationType']=_0xba96d7['operationType'];}static async['_fromIdTokenResponse'](_0x58ce8f,_0x6b5b69,_0x301a9f,_0x219a5b=!0x1){const _0x3cfaea=await z['_fromIdTokenResponse'](_0x58ce8f,_0x301a9f,_0x219a5b),_0x329fe6=Ar(_0x301a9f);return new Be({'user':_0x3cfaea,'providerId':_0x329fe6,'_tokenResponse':_0x301a9f,'operationType':_0x6b5b69});}static async['_forOperation'](_0x1aa624,_0x5cf7fc,_0xea23ff){await _0x1aa624['_updateTokensIfNecessary'](_0xea23ff,!0x0);const _0x31adbe=Ar(_0xea23ff);return new Be({'user':_0x1aa624,'providerId':_0x31adbe,'_tokenResponse':_0xea23ff,'operationType':_0x5cf7fc});}}function Ar(_0x5bd8dc){return _0x5bd8dc['providerId']?_0x5bd8dc['providerId']:'phoneNumber'in _0x5bd8dc?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x407bdc,_0x177e1d,_0x333778,_0x3ef006){super(_0x177e1d['code'],_0x177e1d['message']),this['operationType']=_0x333778,this['user']=_0x3ef006,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x407bdc['name'],'tenantId':_0x407bdc['tenantId']??void 0x0,'_serverResponse':_0x177e1d['customData']['_serverResponse'],'operationType':_0x333778};}static['_fromErrorAndOperation'](_0x2aedc8,_0x1ccde3,_0x3d6499,_0x11ce0d){return new Rn(_0x2aedc8,_0x1ccde3,_0x3d6499,_0x11ce0d);}}function Fa(_0x22335a,_0x38726e,_0x5780f0,_0x5d3f12){return(_0x38726e==='reauthenticate'?_0x5780f0['_getReauthenticationResolver'](_0x22335a):_0x5780f0['_getIdTokenResponse'](_0x22335a))['catch'](_0x907182=>{throw _0x907182['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x22335a,_0x907182,_0x38726e,_0x5d3f12):_0x907182;});}async function jf(_0x3191af,_0x6da67e,_0x218224=!0x1){const _0x358862=await xt(_0x3191af,_0x6da67e['_linkToIdToken'](_0x3191af['auth'],await _0x3191af['getIdToken']()),_0x218224);return Be['_forOperation'](_0x3191af,'link',_0x358862);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x8dbf3,_0x19bab9,_0x563c9b=!0x1){const {auth:_0x260e5b}=_0x8dbf3;if(H(_0x260e5b['app']))return Promise['reject'](se(_0x260e5b));const _0x5be483='reauthenticate';try{const _0x2160e0=await xt(_0x8dbf3,Fa(_0x260e5b,_0x5be483,_0x19bab9,_0x8dbf3),_0x563c9b);m(_0x2160e0['idToken'],_0x260e5b,'internal-error');const _0x4a1125=ws(_0x2160e0['idToken']);m(_0x4a1125,_0x260e5b,'internal-error');const {sub:_0x2bd842}=_0x4a1125;return m(_0x8dbf3['uid']===_0x2bd842,_0x260e5b,'user-mismatch'),Be['_forOperation'](_0x8dbf3,_0x5be483,_0x2160e0);}catch(_0x3c0d3d){throw(_0x3c0d3d==null?void 0x0:_0x3c0d3d['code'])==='auth/user-not-found'&&K(_0x260e5b,'user-mismatch'),_0x3c0d3d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x508cae,_0x5bda9b,_0x44af1b=!0x1){if(H(_0x508cae['app']))return Promise['reject'](se(_0x508cae));const _0x4c4696='signIn',_0x5c6edd=await Fa(_0x508cae,_0x4c4696,_0x5bda9b),_0x52487a=await Be['_fromIdTokenResponse'](_0x508cae,_0x4c4696,_0x5c6edd);return _0x44af1b||await _0x508cae['_updateCurrentUser'](_0x52487a['user']),_0x52487a;}async function Yf(_0x244955,_0x3ae489){return Ua(qe(_0x244955),_0x3ae489);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x3152e7){const _0x5bb726=qe(_0x3152e7);_0x5bb726['_getPasswordPolicyInternal']()&&await _0x5bb726['_updatePasswordPolicy']();}async function R_(_0xdf1c15,_0x2a99ab,_0xb4ba57){if(H(_0xdf1c15['app']))return Promise['reject'](se(_0xdf1c15));const _0x5842d3=qe(_0xdf1c15),_0x196f49=await Oi(_0x5842d3,{'returnSecureToken':!0x0,'email':_0x2a99ab,'password':_0xb4ba57,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0xec693=>{throw _0xec693['code']==='auth/password-does-not-meet-requirements'&&Wa(_0xdf1c15),_0xec693;}),_0x3dbbf3=await Be['_fromIdTokenResponse'](_0x5842d3,'signIn',_0x196f49);return await _0x5842d3['_updateCurrentUser'](_0x3dbbf3['user']),_0x3dbbf3;}function A_(_0xeb6991,_0x8f1039,_0x1515f1){return H(_0xeb6991['app'])?Promise['reject'](se(_0xeb6991)):Yf(k(_0xeb6991),ft['credential'](_0x8f1039,_0x1515f1))['catch'](async _0x38a5ef=>{throw _0x38a5ef['code']==='auth/password-does-not-meet-requirements'&&Wa(_0xeb6991),_0x38a5ef;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x3f721b,_0x1a182c){return k(_0x3f721b)['setPersistence'](_0x1a182c);}function Qf(_0x34c233,_0xf4ad11,_0x647553,_0x4ff330){return k(_0x34c233)['onIdTokenChanged'](_0xf4ad11,_0x647553,_0x4ff330);}function Jf(_0x55a6ac,_0x48b60e,_0x20e264){return k(_0x55a6ac)['beforeAuthStateChanged'](_0x48b60e,_0x20e264);}function N_(_0x524c89,_0x48d81b,_0x584e94,_0x6a8a1c){return k(_0x524c89)['onAuthStateChanged'](_0x48d81b,_0x584e94,_0x6a8a1c);}function P_(_0x39c168){return k(_0x39c168)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x273ba0,_0x23a978){this['storageRetriever']=_0x273ba0,this['type']=_0x23a978;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x171fef,_0x48ea93){return this['storage']['setItem'](_0x171fef,JSON['stringify'](_0x48ea93)),Promise['resolve']();}['_get'](_0x2d5672){const _0x5d0fa7=this['storage']['getItem'](_0x2d5672);return Promise['resolve'](_0x5d0fa7?JSON['parse'](_0x5d0fa7):null);}['_remove'](_0x50171f){return this['storage']['removeItem'](_0x50171f),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2fc1f6,_0x7e0deb)=>this['onStorageEvent'](_0x2fc1f6,_0x7e0deb),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2425f1){for(const _0x3130cb of Object['keys'](this['listeners'])){const _0x5ace77=this['storage']['getItem'](_0x3130cb),_0x417515=this['localCache'][_0x3130cb];_0x5ace77!==_0x417515&&_0x2425f1(_0x3130cb,_0x417515,_0x5ace77);}}['onStorageEvent'](_0x1aea74,_0x830494=!0x1){if(!_0x1aea74['key']){this['forAllChangedKeys']((_0x4dd0b1,_0x3ace55,_0x13694e)=>{this['notifyListeners'](_0x4dd0b1,_0x13694e);});return;}const _0x5d522c=_0x1aea74['key'];_0x830494?this['detachListener']():this['stopPolling']();const _0x5a895b=()=>{const _0xf1431c=this['storage']['getItem'](_0x5d522c);!_0x830494&&this['localCache'][_0x5d522c]===_0xf1431c||this['notifyListeners'](_0x5d522c,_0xf1431c);},_0x3f9d04=this['storage']['getItem'](_0x5d522c);If()&&_0x3f9d04!==_0x1aea74['newValue']&&_0x1aea74['newValue']!==_0x1aea74['oldValue']?setTimeout(_0x5a895b,Zf):_0x5a895b();}['notifyListeners'](_0x4bab0b,_0x5a51b9){this['localCache'][_0x4bab0b]=_0x5a51b9;const _0x9afdde=this['listeners'][_0x4bab0b];if(_0x9afdde){for(const _0x22a8c9 of Array['from'](_0x9afdde))_0x22a8c9(_0x5a51b9&&JSON['parse'](_0x5a51b9));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x23e07f,_0x247120,_0x397984)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x23e07f,'oldValue':_0x247120,'newValue':_0x397984}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x577b50,_0x2013d4){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x577b50]||(this['listeners'][_0x577b50]=new Set(),this['localCache'][_0x577b50]=this['storage']['getItem'](_0x577b50)),this['listeners'][_0x577b50]['add'](_0x2013d4);}['_removeListener'](_0x257eb9,_0x51dfef){this['listeners'][_0x257eb9]&&(this['listeners'][_0x257eb9]['delete'](_0x51dfef),this['listeners'][_0x257eb9]['size']===0x0&&delete this['listeners'][_0x257eb9]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3b4a03,_0x608052){await super['_set'](_0x3b4a03,_0x608052),this['localCache'][_0x3b4a03]=JSON['stringify'](_0x608052);}async['_get'](_0xc53ae){const _0xfd708e=await super['_get'](_0xc53ae);return this['localCache'][_0xc53ae]=JSON['stringify'](_0xfd708e),_0xfd708e;}async['_remove'](_0x542941){await super['_remove'](_0x542941),delete this['localCache'][_0x542941];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x5acb75,_0x4c23bf){}['_removeListener'](_0x5f29a9,_0x977e11){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x529c90){return Promise['all'](_0x529c90['map'](async _0x3b7adf=>{try{return{'fulfilled':!0x0,'value':await _0x3b7adf};}catch(_0x2021c0){return{'fulfilled':!0x1,'reason':_0x2021c0};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x1c895e){this['eventTarget']=_0x1c895e,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x138e36){const _0x3b3fea=this['receivers']['find'](_0x219e7f=>_0x219e7f['isListeningto'](_0x138e36));if(_0x3b3fea)return _0x3b3fea;const _0x312c9d=new jn(_0x138e36);return this['receivers']['push'](_0x312c9d),_0x312c9d;}['isListeningto'](_0x3ece79){return this['eventTarget']===_0x3ece79;}async['handleEvent'](_0x2f8bc9){const _0x163f9b=_0x2f8bc9,{eventId:_0x21b868,eventType:_0x34b895,data:_0x48dbca}=_0x163f9b['data'],_0x282b4e=this['handlersMap'][_0x34b895];if(!(_0x282b4e!=null&&_0x282b4e['size']))return;_0x163f9b['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x21b868,'eventType':_0x34b895});const _0x441c36=Array['from'](_0x282b4e)['map'](async _0x32c945=>_0x32c945(_0x163f9b['origin'],_0x48dbca)),_0x4de6cc=await tp(_0x441c36);_0x163f9b['ports'][0x0]['postMessage']({'status':'done','eventId':_0x21b868,'eventType':_0x34b895,'response':_0x4de6cc});}['_subscribe'](_0x3f47d5,_0x5cb53b){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3f47d5]||(this['handlersMap'][_0x3f47d5]=new Set()),this['handlersMap'][_0x3f47d5]['add'](_0x5cb53b);}['_unsubscribe'](_0x3ff9e0,_0x10dbb3){this['handlersMap'][_0x3ff9e0]&&_0x10dbb3&&this['handlersMap'][_0x3ff9e0]['delete'](_0x10dbb3),(!_0x10dbb3||this['handlersMap'][_0x3ff9e0]['size']===0x0)&&delete this['handlersMap'][_0x3ff9e0],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x375008='',_0x911722=0xa){let _0x34b065='';for(let _0xd1c1c0=0x0;_0xd1c1c0<_0x911722;_0xd1c1c0++)_0x34b065+=Math['floor'](Math['random']()*0xa);return _0x375008+_0x34b065;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x2f5aed){this['target']=_0x2f5aed,this['handlers']=new Set();}['removeMessageHandler'](_0x29dd85){_0x29dd85['messageChannel']&&(_0x29dd85['messageChannel']['port1']['removeEventListener']('message',_0x29dd85['onMessage']),_0x29dd85['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x29dd85);}async['_send'](_0x497066,_0x361ca6,_0x155bcb=0x32){const _0x40bad1=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x40bad1)throw new Error('connection_unavailable');let _0x4faec5,_0x3eaf3f;return new Promise((_0x25c4e9,_0x27b1ff)=>{const _0x2f1ba6=bs('',0x14);_0x40bad1['port1']['start']();const _0x4daf12=setTimeout(()=>{_0x27b1ff(new Error('unsupported_event'));},_0x155bcb);_0x3eaf3f={'messageChannel':_0x40bad1,'onMessage'(_0x31e09a){const _0x1b063a=_0x31e09a;if(_0x1b063a['data']['eventId']===_0x2f1ba6)switch(_0x1b063a['data']['status']){case'ack':clearTimeout(_0x4daf12),_0x4faec5=setTimeout(()=>{_0x27b1ff(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4faec5),_0x25c4e9(_0x1b063a['data']['response']);break;default:clearTimeout(_0x4daf12),clearTimeout(_0x4faec5),_0x27b1ff(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3eaf3f),_0x40bad1['port1']['addEventListener']('message',_0x3eaf3f['onMessage']),this['target']['postMessage']({'eventType':_0x497066,'eventId':_0x2f1ba6,'data':_0x361ca6},[_0x40bad1['port2']]);})['finally'](()=>{_0x3eaf3f&&this['removeMessageHandler'](_0x3eaf3f);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x33ceaf){X()['location']['href']=_0x33ceaf;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x4fdc84;return((_0x4fdc84=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4fdc84['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x5dd26b){this['request']=_0x5dd26b;}['toPromise'](){return new Promise((_0x39ef1d,_0x3c6457)=>{this['request']['addEventListener']('success',()=>{_0x39ef1d(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3c6457(this['request']['error']);});});}}function Kn(_0xd2c4f4,_0x310718){return _0xd2c4f4['transaction']([kn],_0x310718?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x5df043=indexedDB['deleteDatabase'](qa);return new Jt(_0x5df043)['toPromise']();}function ja(){const _0x5e7e81=indexedDB['open'](qa,ap);return new Promise((_0x272a6c,_0x2ae500)=>{_0x5e7e81['addEventListener']('error',()=>{_0x2ae500(_0x5e7e81['error']);}),_0x5e7e81['addEventListener']('upgradeneeded',()=>{const _0x4cedf7=_0x5e7e81['result'];try{_0x4cedf7['createObjectStore'](kn,{'keyPath':za});}catch(_0x10a449){_0x2ae500(_0x10a449);}}),_0x5e7e81['addEventListener']('success',async()=>{const _0x3cdf45=_0x5e7e81['result'];_0x3cdf45['objectStoreNames']['contains'](kn)?_0x272a6c(_0x3cdf45):(_0x3cdf45['close'](),await cp(),_0x272a6c(await ja()));});});}async function kr(_0x3b098b,_0x5ad8c7,_0x2cd965){const _0x2b8947=Kn(_0x3b098b,!0x0)['put']({[za]:_0x5ad8c7,'value':_0x2cd965});return new Jt(_0x2b8947)['toPromise']();}async function lp(_0x196f9b,_0x57f825){const _0x17e1f4=Kn(_0x196f9b,!0x1)['get'](_0x57f825),_0x232152=await new Jt(_0x17e1f4)['toPromise']();return _0x232152===void 0x0?null:_0x232152['value'];}function Nr(_0x136602,_0x503670){const _0x486a54=Kn(_0x136602,!0x0)['delete'](_0x503670);return new Jt(_0x486a54)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x18778d){let _0x2bd1fb=0x0;for(;;)try{const _0x28ade1=await this['_openDb']();return await _0x18778d(_0x28ade1);}catch(_0x3c75f5){if(_0x2bd1fb++>up)throw _0x3c75f5;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x227e6f,_0x156db1)=>({'keyProcessed':(await this['_poll']())['includes'](_0x156db1['key'])})),this['receiver']['_subscribe']('ping',async(_0x4ac490,_0x2bb728)=>['keyChanged']);}async['initializeSender'](){var _0x1bbda5,_0xd335be;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x18dfe9=await this['sender']['_send']('ping',{},0x320);_0x18dfe9&&(_0x1bbda5=_0x18dfe9[0x0])!=null&&_0x1bbda5['fulfilled']&&(_0xd335be=_0x18dfe9[0x0])!=null&&_0xd335be['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x91370){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x91370},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xd521c2=>{await kr(_0xd521c2,An,'1'),await Nr(_0xd521c2,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x308a66){this['pendingWrites']++;try{await _0x308a66();}finally{this['pendingWrites']--;}}async['_set'](_0x117718,_0x2841b8){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2cdb47=>kr(_0x2cdb47,_0x117718,_0x2841b8)),this['localCache'][_0x117718]=_0x2841b8,this['notifyServiceWorker'](_0x117718)));}async['_get'](_0x2ca440){const _0x2a2970=await this['_withRetries'](_0x4cdf16=>lp(_0x4cdf16,_0x2ca440));return this['localCache'][_0x2ca440]=_0x2a2970,_0x2a2970;}async['_remove'](_0x23fc1e){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4432de=>Nr(_0x4432de,_0x23fc1e)),delete this['localCache'][_0x23fc1e],this['notifyServiceWorker'](_0x23fc1e)));}async['_poll'](){const _0x463588=await this['_withRetries'](_0x14c9bd=>{const _0xdb983c=Kn(_0x14c9bd,!0x1)['getAll']();return new Jt(_0xdb983c)['toPromise']();});if(!_0x463588)return[];if(this['pendingWrites']!==0x0)return[];const _0x4fa880=[],_0x524506=new Set();if(_0x463588['length']!==0x0){for(const {fbase_key:_0x2576f3,value:_0x58de38}of _0x463588)_0x524506['add'](_0x2576f3),JSON['stringify'](this['localCache'][_0x2576f3])!==JSON['stringify'](_0x58de38)&&(this['notifyListeners'](_0x2576f3,_0x58de38),_0x4fa880['push'](_0x2576f3));}for(const _0x29d170 of Object['keys'](this['localCache']))this['localCache'][_0x29d170]&&!_0x524506['has'](_0x29d170)&&(this['notifyListeners'](_0x29d170,null),_0x4fa880['push'](_0x29d170));return _0x4fa880;}['notifyListeners'](_0x1eecb1,_0x5dfa0c){this['localCache'][_0x1eecb1]=_0x5dfa0c;const _0x48a2e7=this['listeners'][_0x1eecb1];if(_0x48a2e7){for(const _0x51015e of Array['from'](_0x48a2e7))_0x51015e(_0x5dfa0c);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x91d87f,_0x1e4071){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x91d87f]||(this['listeners'][_0x91d87f]=new Set(),this['_get'](_0x91d87f)),this['listeners'][_0x91d87f]['add'](_0x1e4071);}['_removeListener'](_0x1b047b,_0x593105){this['listeners'][_0x1b047b]&&(this['listeners'][_0x1b047b]['delete'](_0x593105),this['listeners'][_0x1b047b]['size']===0x0&&delete this['listeners'][_0x1b047b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x30812e,_0x31093a){return _0x31093a?ne(_0x31093a):(m(_0x30812e['_popupRedirectResolver'],_0x30812e,'argument-error'),_0x30812e['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x2f2b0c){super('custom','custom'),this['params']=_0x2f2b0c;}['_getIdTokenResponse'](_0x2ba880){return Ze(_0x2ba880,this['_buildIdpRequest']());}['_linkToIdToken'](_0x7c7da1,_0x11427b){return Ze(_0x7c7da1,this['_buildIdpRequest'](_0x11427b));}['_getReauthenticationResolver'](_0x50563b){return Ze(_0x50563b,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1af8f8){const _0xfd5a3d={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1af8f8&&(_0xfd5a3d['idToken']=_0x1af8f8),_0xfd5a3d;}}function pp(_0x50de77){return Ua(_0x50de77['auth'],new Rs(_0x50de77),_0x50de77['bypassAuthState']);}function _p(_0xb2a781){const {auth:_0x511529,user:_0x5abf44}=_0xb2a781;return m(_0x5abf44,_0x511529,'internal-error'),Kf(_0x5abf44,new Rs(_0xb2a781),_0xb2a781['bypassAuthState']);}async function gp(_0x2ac5f1){const {auth:_0x49dc46,user:_0x48cfc2}=_0x2ac5f1;return m(_0x48cfc2,_0x49dc46,'internal-error'),jf(_0x48cfc2,new Rs(_0x2ac5f1),_0x2ac5f1['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x5a569c,_0x2493b4,_0x4eb32f,_0x8f8a6e,_0x3bc4d8=!0x1){this['auth']=_0x5a569c,this['resolver']=_0x4eb32f,this['user']=_0x8f8a6e,this['bypassAuthState']=_0x3bc4d8,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2493b4)?_0x2493b4:[_0x2493b4];}['execute'](){return new Promise(async(_0x92bf1,_0x2327ea)=>{this['pendingPromise']={'resolve':_0x92bf1,'reject':_0x2327ea};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x616935){this['reject'](_0x616935);}});}async['onAuthEvent'](_0x18af7a){const {urlResponse:_0x3a5376,sessionId:_0x286dd8,postBody:_0xcdad2b,tenantId:_0x5ca1f9,error:_0xe3148f,type:_0x4bf69d}=_0x18af7a;if(_0xe3148f){this['reject'](_0xe3148f);return;}const _0x303477={'auth':this['auth'],'requestUri':_0x3a5376,'sessionId':_0x286dd8,'tenantId':_0x5ca1f9||void 0x0,'postBody':_0xcdad2b||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4bf69d)(_0x303477));}catch(_0x2f3fe0){this['reject'](_0x2f3fe0);}}['onError'](_0xbf69a9){this['reject'](_0xbf69a9);}['getIdpTask'](_0x31f7c4){switch(_0x31f7c4){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x51e33c){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x51e33c),this['unregisterAndCleanUp']();}['reject'](_0x5f1481){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5f1481),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x570450,_0x1bbecc,_0x5cea03,_0x1e9869,_0x53db4a){super(_0x570450,_0x1bbecc,_0x1e9869,_0x53db4a),this['provider']=_0x5cea03,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x35878b=await this['execute']();return m(_0x35878b,this['auth'],'internal-error'),_0x35878b;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x21c216=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x21c216),this['authWindow']['associatedEvent']=_0x21c216,this['resolver']['_originValidation'](this['auth'])['catch'](_0x463908=>{this['reject'](_0x463908);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x4034c7=>{_0x4034c7||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x14ec40;return((_0x14ec40=this['authWindow'])==null?void 0x0:_0x14ec40['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1d7c6b=()=>{var _0x4d40ab,_0xce100c;if((_0xce100c=(_0x4d40ab=this['authWindow'])==null?void 0x0:_0x4d40ab['window'])!=null&&_0xce100c['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1d7c6b,mp['get']());};_0x1d7c6b();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x39be09,_0x31d0b8,_0x5ecac5=!0x1){super(_0x39be09,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x31d0b8,void 0x0,_0x5ecac5),this['eventId']=null;}async['execute'](){let _0x5984f4=rn['get'](this['auth']['_key']());if(!_0x5984f4){try{const _0x3039af=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x5984f4=()=>Promise['resolve'](_0x3039af);}catch(_0x1f01ed){_0x5984f4=()=>Promise['reject'](_0x1f01ed);}rn['set'](this['auth']['_key'](),_0x5984f4);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5984f4();}async['onAuthEvent'](_0x3bf7fc){if(_0x3bf7fc['type']==='signInViaRedirect')return super['onAuthEvent'](_0x3bf7fc);if(_0x3bf7fc['type']==='unknown'){this['resolve'](null);return;}if(_0x3bf7fc['eventId']){const _0x1a5dec=await this['auth']['_redirectUserForId'](_0x3bf7fc['eventId']);if(_0x1a5dec)return this['user']=_0x1a5dec,super['onAuthEvent'](_0x3bf7fc);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x58da0e,_0x5f5df1){const _0x20128f=Cp(_0x5f5df1),_0x559c04=wp(_0x58da0e);if(!await _0x559c04['_isAvailable']())return!0x1;const _0x226819=await _0x559c04['_get'](_0x20128f)==='true';return await _0x559c04['_remove'](_0x20128f),_0x226819;}function Ip(_0xe7c814,_0x3e1198){rn['set'](_0xe7c814['_key'](),_0x3e1198);}function wp(_0x402106){return ne(_0x402106['_redirectPersistence']);}function Cp(_0x2684f5){return sn(yp,_0x2684f5['config']['apiKey'],_0x2684f5['name']);}async function Tp(_0x6754cd,_0x30ab59,_0x2a0ba2=!0x1){if(H(_0x6754cd['app']))return Promise['reject'](se(_0x6754cd));const _0x5dba7=qe(_0x6754cd),_0x59f6bb=fp(_0x5dba7,_0x30ab59),_0x5b1fa8=await new vp(_0x5dba7,_0x59f6bb,_0x2a0ba2)['execute']();return _0x5b1fa8&&!_0x2a0ba2&&(delete _0x5b1fa8['user']['_redirectEventId'],await _0x5dba7['_persistUserIfCurrent'](_0x5b1fa8['user']),await _0x5dba7['_setRedirectUser'](null,_0x30ab59)),_0x5b1fa8;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x5b017a){this['auth']=_0x5b017a,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x43c1a3){this['consumers']['add'](_0x43c1a3),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x43c1a3)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x43c1a3),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1d9580){this['consumers']['delete'](_0x1d9580);}['onEvent'](_0xf22b54){if(this['hasEventBeenHandled'](_0xf22b54))return!0x1;let _0x49f795=!0x1;return this['consumers']['forEach'](_0x147101=>{this['isEventForConsumer'](_0xf22b54,_0x147101)&&(_0x49f795=!0x0,this['sendToConsumer'](_0xf22b54,_0x147101),this['saveEventToCache'](_0xf22b54));}),this['hasHandledPotentialRedirect']||!Rp(_0xf22b54)||(this['hasHandledPotentialRedirect']=!0x0,_0x49f795||(this['queuedRedirectEvent']=_0xf22b54,_0x49f795=!0x0)),_0x49f795;}['sendToConsumer'](_0x109d5c,_0x5df7c4){var _0x8116e9;if(_0x109d5c['error']&&!Qa(_0x109d5c)){const _0x44643a=((_0x8116e9=_0x109d5c['error']['code'])==null?void 0x0:_0x8116e9['split']('auth/')[0x1])||'internal-error';_0x5df7c4['onError'](J(this['auth'],_0x44643a));}else _0x5df7c4['onAuthEvent'](_0x109d5c);}['isEventForConsumer'](_0x520445,_0x351a37){const _0x5e6c58=_0x351a37['eventId']===null||!!_0x520445['eventId']&&_0x520445['eventId']===_0x351a37['eventId'];return _0x351a37['filter']['includes'](_0x520445['type'])&&_0x5e6c58;}['hasEventBeenHandled'](_0x2cc697){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x2cc697));}['saveEventToCache'](_0x726771){this['cachedEventUids']['add'](Pr(_0x726771)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x4442ca){return[_0x4442ca['type'],_0x4442ca['eventId'],_0x4442ca['sessionId'],_0x4442ca['tenantId']]['filter'](_0x1e3608=>_0x1e3608)['join']('-');}function Qa({type:_0x17506d,error:_0x464cd5}){return _0x17506d==='unknown'&&(_0x464cd5==null?void 0x0:_0x464cd5['code'])==='auth/no-auth-event';}function Rp(_0x2e92ae){switch(_0x2e92ae['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x2e92ae);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x3a7e22,_0x5ab901={}){return Ae(_0x3a7e22,'GET','/v1/projects',_0x5ab901);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x2ba9f6){if(_0x2ba9f6['config']['emulator'])return;const {authorizedDomains:_0x158fe5}=await Ap(_0x2ba9f6);for(const _0x335491 of _0x158fe5)try{if(Op(_0x335491))return;}catch{}K(_0x2ba9f6,'unauthorized-domain');}function Op(_0x3ec7f4){const _0x4be538=Ni(),{protocol:_0x60fc44,hostname:_0xeabfbe}=new URL(_0x4be538);if(_0x3ec7f4['startsWith']('chrome-extension://')){const _0x465312=new URL(_0x3ec7f4);return _0x465312['hostname']===''&&_0xeabfbe===''?_0x60fc44==='chrome-extension:'&&_0x3ec7f4['replace']('chrome-extension://','')===_0x4be538['replace']('chrome-extension://',''):_0x60fc44==='chrome-extension:'&&_0x465312['hostname']===_0xeabfbe;}if(!Np['test'](_0x60fc44))return!0x1;if(kp['test'](_0x3ec7f4))return _0xeabfbe===_0x3ec7f4;const _0x501086=_0x3ec7f4['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x501086+'|'+_0x501086+')$','i')['test'](_0xeabfbe);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x500ccd=X()['___jsl'];if(_0x500ccd!=null&&_0x500ccd['H']){for(const _0x4e86f7 of Object['keys'](_0x500ccd['H']))if(_0x500ccd['H'][_0x4e86f7]['r']=_0x500ccd['H'][_0x4e86f7]['r']||[],_0x500ccd['H'][_0x4e86f7]['L']=_0x500ccd['H'][_0x4e86f7]['L']||[],_0x500ccd['H'][_0x4e86f7]['r']=[..._0x500ccd['H'][_0x4e86f7]['L']],_0x500ccd['CP']){for(let _0x3bc210=0x0;_0x3bc210<_0x500ccd['CP']['length'];_0x3bc210++)_0x500ccd['CP'][_0x3bc210]=null;}}}function Mp(_0x5b4c10){return new Promise((_0x3ca2bd,_0x680812)=>{var _0x4a8852,_0x3fe1f3,_0x10cf34;function _0x316069(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3ca2bd(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x680812(J(_0x5b4c10,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x3fe1f3=(_0x4a8852=X()['gapi'])==null?void 0x0:_0x4a8852['iframes'])!=null&&_0x3fe1f3['Iframe'])_0x3ca2bd(gapi['iframes']['getContext']());else{if((_0x10cf34=X()['gapi'])!=null&&_0x10cf34['load'])_0x316069();else{const _0x14d25=Nf('iframefcb');return X()[_0x14d25]=()=>{gapi['load']?_0x316069():_0x680812(J(_0x5b4c10,'network-request-failed'));},Da(kf()+'?onload='+_0x14d25)['catch'](_0x42579b=>_0x680812(_0x42579b));}}})['catch'](_0x265595=>{throw on=null,_0x265595;});}let on=null;function Lp(_0x3a7186){return on=on||Mp(_0x3a7186),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x311a7c){const _0x56c358=_0x311a7c['config'];m(_0x56c358['authDomain'],_0x311a7c,'auth-domain-config-required');const _0x1fa369=_0x56c358['emulator']?Is(_0x56c358,Up):'https://'+_0x311a7c['config']['authDomain']+'/'+Fp,_0x533b8f={'apiKey':_0x56c358['apiKey'],'appName':_0x311a7c['name'],'v':ct},_0x31433f=Bp['get'](_0x311a7c['config']['apiHost']);_0x31433f&&(_0x533b8f['eid']=_0x31433f);const _0x1747e4=_0x311a7c['_getFrameworks']();return _0x1747e4['length']&&(_0x533b8f['fw']=_0x1747e4['join'](',')),_0x1fa369+'?'+at(_0x533b8f)['slice'](0x1);}async function Hp(_0x3be72c){const _0x398926=await Lp(_0x3be72c),_0x2ee300=X()['gapi'];return m(_0x2ee300,_0x3be72c,'internal-error'),_0x398926['open']({'where':document['body'],'url':Vp(_0x3be72c),'messageHandlersFilter':_0x2ee300['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x5c155d=>new Promise(async(_0x46a424,_0x5951cd)=>{await _0x5c155d['restyle']({'setHideOnLeave':!0x1});const _0x31d8b5=J(_0x3be72c,'network-request-failed'),_0x3d27d9=X()['setTimeout'](()=>{_0x5951cd(_0x31d8b5);},xp['get']());function _0x224047(){X()['clearTimeout'](_0x3d27d9),_0x46a424(_0x5c155d);}_0x5c155d['ping'](_0x224047)['then'](_0x224047,()=>{_0x5951cd(_0x31d8b5);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x922866){this['window']=_0x922866,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x3e3c5a,_0x12fba7,_0x52cef9,_0x18788f=Gp,_0x46f763=qp){const _0x3b979a=Math['max']((window['screen']['availHeight']-_0x46f763)/0x2,0x0)['toString'](),_0x57a056=Math['max']((window['screen']['availWidth']-_0x18788f)/0x2,0x0)['toString']();let _0x2f2546='';const _0x55dc1e={...$p,'width':_0x18788f['toString'](),'height':_0x46f763['toString'](),'top':_0x3b979a,'left':_0x57a056},_0x5566cb=W()['toLowerCase']();_0x52cef9&&(_0x2f2546=ba(_0x5566cb)?zp:_0x52cef9),Ta(_0x5566cb)&&(_0x12fba7=_0x12fba7||jp,_0x55dc1e['scrollbars']='yes');const _0x4fe84d=Object['entries'](_0x55dc1e)['reduce']((_0x3baaed,[_0x3a8269,_0x120155])=>''+_0x3baaed+_0x3a8269+'='+_0x120155+',','');if(Ef(_0x5566cb)&&_0x2f2546!=='_self')return Yp(_0x12fba7||'',_0x2f2546),new Dr(null);const _0x3b5a93=window['open'](_0x12fba7||'',_0x2f2546,_0x4fe84d);m(_0x3b5a93,_0x3e3c5a,'popup-blocked');try{_0x3b5a93['focus']();}catch{}return new Dr(_0x3b5a93);}function Yp(_0x1e6c00,_0x2dcb50){const _0x3bf020=document['createElement']('a');_0x3bf020['href']=_0x1e6c00,_0x3bf020['target']=_0x2dcb50;const _0x57e495=document['createEvent']('MouseEvent');_0x57e495['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x3bf020['dispatchEvent'](_0x57e495);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x1bbf43,_0x314c50,_0x79b445,_0x3ae52b,_0xd5a01e,_0x1c6d91){m(_0x1bbf43['config']['authDomain'],_0x1bbf43,'auth-domain-config-required'),m(_0x1bbf43['config']['apiKey'],_0x1bbf43,'invalid-api-key');const _0x46762e={'apiKey':_0x1bbf43['config']['apiKey'],'appName':_0x1bbf43['name'],'authType':_0x79b445,'redirectUrl':_0x3ae52b,'v':ct,'eventId':_0xd5a01e};if(_0x314c50 instanceof xa){_0x314c50['setDefaultLanguage'](_0x1bbf43['languageCode']),_0x46762e['providerId']=_0x314c50['providerId']||'',hi(_0x314c50['getCustomParameters']())||(_0x46762e['customParameters']=JSON['stringify'](_0x314c50['getCustomParameters']()));for(const [_0x4134f4,_0x4f05c0]of Object['entries']({}))_0x46762e[_0x4134f4]=_0x4f05c0;}if(_0x314c50 instanceof Qt){const _0x56ebb8=_0x314c50['getScopes']()['filter'](_0x1d5345=>_0x1d5345!=='');_0x56ebb8['length']>0x0&&(_0x46762e['scopes']=_0x56ebb8['join'](','));}_0x1bbf43['tenantId']&&(_0x46762e['tid']=_0x1bbf43['tenantId']);const _0x17e907=_0x46762e;for(const _0x481ef7 of Object['keys'](_0x17e907))_0x17e907[_0x481ef7]===void 0x0&&delete _0x17e907[_0x481ef7];const _0x1bdb2f=await _0x1bbf43['_getAppCheckToken'](),_0x393edf=_0x1bdb2f?'#'+Xp+'='+encodeURIComponent(_0x1bdb2f):'';return Zp(_0x1bbf43)+'?'+at(_0x17e907)['slice'](0x1)+_0x393edf;}function Zp({config:_0x46af7e}){return _0x46af7e['emulator']?Is(_0x46af7e,Jp):'https://'+_0x46af7e['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x437895,_0x304829,_0x13fb0f,_0x5c0f0b){var _0x1f76bc;ae((_0x1f76bc=this['eventManagers'][_0x437895['_key']()])==null?void 0x0:_0x1f76bc['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0xea09be=await Mr(_0x437895,_0x304829,_0x13fb0f,Ni(),_0x5c0f0b);return Kp(_0x437895,_0xea09be,bs());}async['_openRedirect'](_0x3aae17,_0x27755b,_0x20ac1f,_0x24f402){await this['_originValidation'](_0x3aae17);const _0x4503c6=await Mr(_0x3aae17,_0x27755b,_0x20ac1f,Ni(),_0x24f402);return ip(_0x4503c6),new Promise(()=>{});}['_initialize'](_0x483788){const _0x4f1ab3=_0x483788['_key']();if(this['eventManagers'][_0x4f1ab3]){const {manager:_0x2876d0,promise:_0x9bb7b3}=this['eventManagers'][_0x4f1ab3];return _0x2876d0?Promise['resolve'](_0x2876d0):(ae(_0x9bb7b3,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x9bb7b3);}const _0x82233f=this['initAndGetManager'](_0x483788);return this['eventManagers'][_0x4f1ab3]={'promise':_0x82233f},_0x82233f['catch'](()=>{delete this['eventManagers'][_0x4f1ab3];}),_0x82233f;}async['initAndGetManager'](_0x7e5a44){const _0x31462c=await Hp(_0x7e5a44),_0x1ea05e=new bp(_0x7e5a44);return _0x31462c['register']('authEvent',_0x1a4706=>(m(_0x1a4706==null?void 0x0:_0x1a4706['authEvent'],_0x7e5a44,'invalid-auth-event'),{'status':_0x1ea05e['onEvent'](_0x1a4706['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x7e5a44['_key']()]={'manager':_0x1ea05e},this['iframes'][_0x7e5a44['_key']()]=_0x31462c,_0x1ea05e;}['_isIframeWebStorageSupported'](_0x4098b8,_0x4035c4){this['iframes'][_0x4098b8['_key']()]['send'](li,{'type':li},_0x1c7923=>{var _0x3003d3;const _0x165ae2=(_0x3003d3=_0x1c7923==null?void 0x0:_0x1c7923[0x0])==null?void 0x0:_0x3003d3[li];_0x165ae2!==void 0x0&&_0x4035c4(!!_0x165ae2),K(_0x4098b8,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x564c48){const _0x295f01=_0x564c48['_key']();return this['originValidationPromises'][_0x295f01]||(this['originValidationPromises'][_0x295f01]=Pp(_0x564c48)),this['originValidationPromises'][_0x295f01];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x1add5a){this['auth']=_0x1add5a,this['internalListeners']=new Map();}['getUid'](){var _0x716246;return this['assertAuthConfigured'](),((_0x716246=this['auth']['currentUser'])==null?void 0x0:_0x716246['uid'])||null;}async['getToken'](_0xfd0dd){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xfd0dd)}:null;}['addAuthTokenListener'](_0x5a52db){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5a52db))return;const _0x205029=this['auth']['onIdTokenChanged'](_0x37a829=>{_0x5a52db((_0x37a829==null?void 0x0:_0x37a829['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5a52db,_0x205029),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xd766e7){this['assertAuthConfigured']();const _0x41e0c4=this['internalListeners']['get'](_0xd766e7);_0x41e0c4&&(this['internalListeners']['delete'](_0xd766e7),_0x41e0c4(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x250d13){switch(_0x250d13){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x248636){et(new Me('auth',(_0x1d1d3a,{options:_0xdd6c67})=>{const _0x2d4209=_0x1d1d3a['getProvider']('app')['getImmediate'](),_0x10dac6=_0x1d1d3a['getProvider']('heartbeat'),_0x3f0f7a=_0x1d1d3a['getProvider']('app-check-internal'),{apiKey:_0x1e1a8d,authDomain:_0xbd45f9}=_0x2d4209['options'];m(_0x1e1a8d&&!_0x1e1a8d['includes'](':'),'invalid-api-key',{'appName':_0x2d4209['name']});const _0x4fe4d={'apiKey':_0x1e1a8d,'authDomain':_0xbd45f9,'clientPlatform':_0x248636,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x248636)},_0x46f692=new bf(_0x2d4209,_0x10dac6,_0x3f0f7a,_0x4fe4d);return Lf(_0x46f692,_0xdd6c67),_0x46f692;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x34b6bb,_0x4a1a49,_0x3e2a75)=>{_0x34b6bb['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x16bb04=>{const _0x3229b8=qe(_0x16bb04['getProvider']('auth')['getImmediate']());return(_0x35929e=>new n_(_0x35929e))(_0x3229b8);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x248636)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x3cf11b=>async _0x176526=>{const _0x3959f8=_0x176526&&await _0x176526['getIdTokenResult'](),_0x54bcb2=_0x3959f8&&(new Date()['getTime']()-Date['parse'](_0x3959f8['issuedAtTime']))/0x3e8;if(_0x54bcb2&&_0x54bcb2>o_)return;const _0x2e0fc2=_0x3959f8==null?void 0x0:_0x3959f8['token'];Fr!==_0x2e0fc2&&(Fr=_0x2e0fc2,await fetch(_0x3cf11b,{'method':_0x2e0fc2?'POST':'DELETE','headers':_0x2e0fc2?{'Authorization':'Bearer\x20'+_0x2e0fc2}:{}}));};function O_(_0xed5af3=Qr()){const _0x368d8c=Ui(_0xed5af3,'auth');if(_0x368d8c['isInitialized']())return _0x368d8c['getImmediate']();const _0x1f9396=Mf(_0xed5af3,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x586bdf=Gr('authTokenSyncURL');if(_0x586bdf&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3e69f6=new URL(_0x586bdf,location['origin']);if(location['origin']===_0x3e69f6['origin']){const _0x44d073=a_(_0x3e69f6['toString']());Jf(_0x1f9396,_0x44d073,()=>_0x44d073(_0x1f9396['currentUser'])),Qf(_0x1f9396,_0x2576a9=>_0x44d073(_0x2576a9));}}const _0x1d59f9=Hr('auth');return _0x1d59f9&&xf(_0x1f9396,'http://'+_0x1d59f9),_0x1f9396;}function c_(){var _0x5d3259;return((_0x5d3259=document['getElementsByTagName']('head'))==null?void 0x0:_0x5d3259[0x0])??document;}Rf({'loadJS'(_0x1ea03e){return new Promise((_0x3ca109,_0x2f33e3)=>{const _0x323e3f=document['createElement']('script');_0x323e3f['setAttribute']('src',_0x1ea03e),_0x323e3f['onload']=_0x3ca109,_0x323e3f['onerror']=_0x16ee22=>{const _0x2aadd9=J('internal-error');_0x2aadd9['customData']=_0x16ee22,_0x2f33e3(_0x2aadd9);},_0x323e3f['type']='text/javascript',_0x323e3f['charset']='UTF-8',c_()['appendChild'](_0x323e3f);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};