const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x23bd29,_0x5907dd){if(!_0x23bd29)throw ot(_0x5907dd);},ot=function(_0x27adb3){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x27adb3);},Wr=function(_0x3bc4b0){const _0x4e7e80=[];let _0x183af4=0x0;for(let _0x28a8da=0x0;_0x28a8da<_0x3bc4b0['length'];_0x28a8da++){let _0x36fc9b=_0x3bc4b0['charCodeAt'](_0x28a8da);_0x36fc9b<0x80?_0x4e7e80[_0x183af4++]=_0x36fc9b:_0x36fc9b<0x800?(_0x4e7e80[_0x183af4++]=_0x36fc9b>>0x6|0xc0,_0x4e7e80[_0x183af4++]=_0x36fc9b&0x3f|0x80):(_0x36fc9b&0xfc00)===0xd800&&_0x28a8da+0x1<_0x3bc4b0['length']&&(_0x3bc4b0['charCodeAt'](_0x28a8da+0x1)&0xfc00)===0xdc00?(_0x36fc9b=0x10000+((_0x36fc9b&0x3ff)<<0xa)+(_0x3bc4b0['charCodeAt'](++_0x28a8da)&0x3ff),_0x4e7e80[_0x183af4++]=_0x36fc9b>>0x12|0xf0,_0x4e7e80[_0x183af4++]=_0x36fc9b>>0xc&0x3f|0x80,_0x4e7e80[_0x183af4++]=_0x36fc9b>>0x6&0x3f|0x80,_0x4e7e80[_0x183af4++]=_0x36fc9b&0x3f|0x80):(_0x4e7e80[_0x183af4++]=_0x36fc9b>>0xc|0xe0,_0x4e7e80[_0x183af4++]=_0x36fc9b>>0x6&0x3f|0x80,_0x4e7e80[_0x183af4++]=_0x36fc9b&0x3f|0x80);}return _0x4e7e80;},Za=function(_0x42dff1){const _0x572d37=[];let _0x63f68f=0x0,_0x279d51=0x0;for(;_0x63f68f<_0x42dff1['length'];){const _0x54a087=_0x42dff1[_0x63f68f++];if(_0x54a087<0x80)_0x572d37[_0x279d51++]=String['fromCharCode'](_0x54a087);else{if(_0x54a087>0xbf&&_0x54a087<0xe0){const _0x2b50d9=_0x42dff1[_0x63f68f++];_0x572d37[_0x279d51++]=String['fromCharCode']((_0x54a087&0x1f)<<0x6|_0x2b50d9&0x3f);}else{if(_0x54a087>0xef&&_0x54a087<0x16d){const _0x73d5f9=_0x42dff1[_0x63f68f++],_0x2f0c75=_0x42dff1[_0x63f68f++],_0x229ecb=_0x42dff1[_0x63f68f++],_0x961585=((_0x54a087&0x7)<<0x12|(_0x73d5f9&0x3f)<<0xc|(_0x2f0c75&0x3f)<<0x6|_0x229ecb&0x3f)-0x10000;_0x572d37[_0x279d51++]=String['fromCharCode'](0xd800+(_0x961585>>0xa)),_0x572d37[_0x279d51++]=String['fromCharCode'](0xdc00+(_0x961585&0x3ff));}else{const _0x53c378=_0x42dff1[_0x63f68f++],_0xfacb02=_0x42dff1[_0x63f68f++];_0x572d37[_0x279d51++]=String['fromCharCode']((_0x54a087&0xf)<<0xc|(_0x53c378&0x3f)<<0x6|_0xfacb02&0x3f);}}}}return _0x572d37['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x486dd6,_0x266fa8){if(!Array['isArray'](_0x486dd6))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x46ce72=_0x266fa8?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x11b3ac=[];for(let _0x21db66=0x0;_0x21db66<_0x486dd6['length'];_0x21db66+=0x3){const _0x2a4bf0=_0x486dd6[_0x21db66],_0x38b692=_0x21db66+0x1<_0x486dd6['length'],_0x5d6152=_0x38b692?_0x486dd6[_0x21db66+0x1]:0x0,_0x4457ec=_0x21db66+0x2<_0x486dd6['length'],_0xdbadaa=_0x4457ec?_0x486dd6[_0x21db66+0x2]:0x0,_0x5d990a=_0x2a4bf0>>0x2,_0x42b676=(_0x2a4bf0&0x3)<<0x4|_0x5d6152>>0x4;let _0x5ba37d=(_0x5d6152&0xf)<<0x2|_0xdbadaa>>0x6,_0x418931=_0xdbadaa&0x3f;_0x4457ec||(_0x418931=0x40,_0x38b692||(_0x5ba37d=0x40)),_0x11b3ac['push'](_0x46ce72[_0x5d990a],_0x46ce72[_0x42b676],_0x46ce72[_0x5ba37d],_0x46ce72[_0x418931]);}return _0x11b3ac['join']('');},'encodeString'(_0xc91623,_0x3b1501){return this['HAS_NATIVE_SUPPORT']&&!_0x3b1501?btoa(_0xc91623):this['encodeByteArray'](Wr(_0xc91623),_0x3b1501);},'decodeString'(_0x232e4c,_0x5752eb){return this['HAS_NATIVE_SUPPORT']&&!_0x5752eb?atob(_0x232e4c):Za(this['decodeStringToByteArray'](_0x232e4c,_0x5752eb));},'decodeStringToByteArray'(_0x268414,_0x3dd0d7){this['init_']();const _0x450d96=_0x3dd0d7?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x366b23=[];for(let _0x1c98f3=0x0;_0x1c98f3<_0x268414['length'];){const _0xb4b030=_0x450d96[_0x268414['charAt'](_0x1c98f3++)],_0x7dcdad=_0x1c98f3<_0x268414['length']?_0x450d96[_0x268414['charAt'](_0x1c98f3)]:0x0;++_0x1c98f3;const _0x2e4a4e=_0x1c98f3<_0x268414['length']?_0x450d96[_0x268414['charAt'](_0x1c98f3)]:0x40;++_0x1c98f3;const _0x45ec4a=_0x1c98f3<_0x268414['length']?_0x450d96[_0x268414['charAt'](_0x1c98f3)]:0x40;if(++_0x1c98f3,_0xb4b030==null||_0x7dcdad==null||_0x2e4a4e==null||_0x45ec4a==null)throw new ec();const _0x1fb9a0=_0xb4b030<<0x2|_0x7dcdad>>0x4;if(_0x366b23['push'](_0x1fb9a0),_0x2e4a4e!==0x40){const _0x23bee3=_0x7dcdad<<0x4&0xf0|_0x2e4a4e>>0x2;if(_0x366b23['push'](_0x23bee3),_0x45ec4a!==0x40){const _0x50480b=_0x2e4a4e<<0x6&0xc0|_0x45ec4a;_0x366b23['push'](_0x50480b);}}}return _0x366b23;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x450d5e=0x0;_0x450d5e<this['ENCODED_VALS']['length'];_0x450d5e++)this['byteToCharMap_'][_0x450d5e]=this['ENCODED_VALS']['charAt'](_0x450d5e),this['charToByteMap_'][this['byteToCharMap_'][_0x450d5e]]=_0x450d5e,this['byteToCharMapWebSafe_'][_0x450d5e]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x450d5e),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x450d5e]]=_0x450d5e,_0x450d5e>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x450d5e)]=_0x450d5e,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x450d5e)]=_0x450d5e);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x16f8f5){const _0x548888=Wr(_0x16f8f5);return Di['encodeByteArray'](_0x548888,!0x0);},an=function(_0x28bf62){return Br(_0x28bf62)['replace'](/\./g,'');},cn=function(_0x3e6520){try{return Di['decodeString'](_0x3e6520,!0x0);}catch(_0x3c1bfd){console['error']('base64Decode\x20failed:\x20',_0x3c1bfd);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x2186ab){return Vr(void 0x0,_0x2186ab);}function Vr(_0x442321,_0x79a6a0){if(!(_0x79a6a0 instanceof Object))return _0x79a6a0;switch(_0x79a6a0['constructor']){case Date:const _0x509f62=_0x79a6a0;return new Date(_0x509f62['getTime']());case Object:_0x442321===void 0x0&&(_0x442321={});break;case Array:_0x442321=[];break;default:return _0x79a6a0;}for(const _0x4b1436 in _0x79a6a0)!_0x79a6a0['hasOwnProperty'](_0x4b1436)||!nc(_0x4b1436)||(_0x442321[_0x4b1436]=Vr(_0x442321[_0x4b1436],_0x79a6a0[_0x4b1436]));return _0x442321;}function nc(_0x5bccdf){return _0x5bccdf!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0xef4d1d=As['__FIREBASE_DEFAULTS__'];if(_0xef4d1d)return JSON['parse'](_0xef4d1d);},oc=()=>{if(typeof document>'u')return;let _0x3f2ef1;try{_0x3f2ef1=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x558c4a=_0x3f2ef1&&cn(_0x3f2ef1[0x1]);return _0x558c4a&&JSON['parse'](_0x558c4a);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4706f1){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4706f1);return;}},Hr=_0x6dd7b6=>{var _0x89757f,_0x1b2b99;return(_0x1b2b99=(_0x89757f=Mi())==null?void 0x0:_0x89757f['emulatorHosts'])==null?void 0x0:_0x1b2b99[_0x6dd7b6];},ac=_0x20d879=>{const _0x24da15=Hr(_0x20d879);if(!_0x24da15)return;const _0x4ab234=_0x24da15['lastIndexOf'](':');if(_0x4ab234<=0x0||_0x4ab234+0x1===_0x24da15['length'])throw new Error('Invalid\x20host\x20'+_0x24da15+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x55d843=parseInt(_0x24da15['substring'](_0x4ab234+0x1),0xa);return _0x24da15[0x0]==='['?[_0x24da15['substring'](0x1,_0x4ab234-0x1),_0x55d843]:[_0x24da15['substring'](0x0,_0x4ab234),_0x55d843];},$r=()=>{var _0x5c13f1;return(_0x5c13f1=Mi())==null?void 0x0:_0x5c13f1['config'];},Gr=_0x15ada6=>{var _0x4656a9;return(_0x4656a9=Mi())==null?void 0x0:_0x4656a9['_'+_0x15ada6];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1e3130,_0x12f3bc)=>{this['resolve']=_0x1e3130,this['reject']=_0x12f3bc;});}['wrapCallback'](_0x2954df){return(_0x4c77a2,_0x73aeed)=>{_0x4c77a2?this['reject'](_0x4c77a2):this['resolve'](_0x73aeed),typeof _0x2954df=='function'&&(this['promise']['catch'](()=>{}),_0x2954df['length']===0x1?_0x2954df(_0x4c77a2):_0x2954df(_0x4c77a2,_0x73aeed));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x5bb4a7,_0x1a4d6c){if(_0x5bb4a7['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x2ffaf9={'alg':'none','type':'JWT'},_0x5eb2a2=_0x1a4d6c||'demo-project',_0x30f14a=_0x5bb4a7['iat']||0x0,_0x14b375=_0x5bb4a7['sub']||_0x5bb4a7['user_id'];if(!_0x14b375)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x102cd0={'iss':'https://securetoken.google.com/'+_0x5eb2a2,'aud':_0x5eb2a2,'iat':_0x30f14a,'exp':_0x30f14a+0xe10,'auth_time':_0x30f14a,'sub':_0x14b375,'user_id':_0x14b375,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5bb4a7};return[an(JSON['stringify'](_0x2ffaf9)),an(JSON['stringify'](_0x102cd0)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x1aade9=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x1aade9=='object'&&_0x1aade9['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x2bbb01=W();return _0x2bbb01['indexOf']('MSIE\x20')>=0x0||_0x2bbb01['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x4639a0,_0x18e88a)=>{try{let _0x4efd08=!0x0;const _0x3b6bd4='validate-browser-context-for-indexeddb-analytics-module',_0x39649c=self['indexedDB']['open'](_0x3b6bd4);_0x39649c['onsuccess']=()=>{_0x39649c['result']['close'](),_0x4efd08||self['indexedDB']['deleteDatabase'](_0x3b6bd4),_0x4639a0(!0x0);},_0x39649c['onupgradeneeded']=()=>{_0x4efd08=!0x1;},_0x39649c['onerror']=()=>{var _0x1f1c1f;_0x18e88a(((_0x1f1c1f=_0x39649c['error'])==null?void 0x0:_0x1f1c1f['message'])||'');};}catch(_0x2c5897){_0x18e88a(_0x2c5897);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x493b49,_0x46af0a,_0x10cc63){super(_0x46af0a),this['code']=_0x493b49,this['customData']=_0x10cc63,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x2eb19f,_0x47babd,_0x5335b5){this['service']=_0x2eb19f,this['serviceName']=_0x47babd,this['errors']=_0x5335b5;}['create'](_0x9e6419,..._0x201eb0){const _0x2a90e7=_0x201eb0[0x0]||{},_0x108542=this['service']+'/'+_0x9e6419,_0x4ba671=this['errors'][_0x9e6419],_0x2e9bd4=_0x4ba671?gc(_0x4ba671,_0x2a90e7):'Error',_0x2abbb=this['serviceName']+':\x20'+_0x2e9bd4+'\x20('+_0x108542+').';return new Se(_0x108542,_0x2abbb,_0x2a90e7);}}function gc(_0x36f1b5,_0x449b83){return _0x36f1b5['replace'](mc,(_0x3fbb79,_0x2f3b4a)=>{const _0x20b2d2=_0x449b83[_0x2f3b4a];return _0x20b2d2!=null?String(_0x20b2d2):'<'+_0x2f3b4a+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x4f6206){return JSON['parse'](_0x4f6206);}function O(_0x2c9e91){return JSON['stringify'](_0x2c9e91);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x5d3451){let _0x265cf7={},_0x2a0dfb={},_0x2da64c={},_0x660c3c='';try{const _0x1b0e92=_0x5d3451['split']('.');_0x265cf7=bt(cn(_0x1b0e92[0x0])||''),_0x2a0dfb=bt(cn(_0x1b0e92[0x1])||''),_0x660c3c=_0x1b0e92[0x2],_0x2da64c=_0x2a0dfb['d']||{},delete _0x2a0dfb['d'];}catch{}return{'header':_0x265cf7,'claims':_0x2a0dfb,'data':_0x2da64c,'signature':_0x660c3c};},yc=function(_0x11d947){const _0x299840=zr(_0x11d947),_0x41301a=_0x299840['claims'];return!!_0x41301a&&typeof _0x41301a=='object'&&_0x41301a['hasOwnProperty']('iat');},vc=function(_0x5c5464){const _0x4b874e=zr(_0x5c5464)['claims'];return typeof _0x4b874e=='object'&&_0x4b874e['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x33b157,_0x47f278){return Object['prototype']['hasOwnProperty']['call'](_0x33b157,_0x47f278);}function Oe(_0x4c0272,_0x479a61){if(Object['prototype']['hasOwnProperty']['call'](_0x4c0272,_0x479a61))return _0x4c0272[_0x479a61];}function hi(_0x1bb724){for(const _0x1fa81f in _0x1bb724)if(Object['prototype']['hasOwnProperty']['call'](_0x1bb724,_0x1fa81f))return!0x1;return!0x0;}function ln(_0x16b7e2,_0x4585a0,_0x17b468){const _0x351b65={};for(const _0xf6d337 in _0x16b7e2)Object['prototype']['hasOwnProperty']['call'](_0x16b7e2,_0xf6d337)&&(_0x351b65[_0xf6d337]=_0x4585a0['call'](_0x17b468,_0x16b7e2[_0xf6d337],_0xf6d337,_0x16b7e2));return _0x351b65;}function De(_0x52626b,_0x220a14){if(_0x52626b===_0x220a14)return!0x0;const _0x61407d=Object['keys'](_0x52626b),_0x45e717=Object['keys'](_0x220a14);for(const _0x595ad8 of _0x61407d){if(!_0x45e717['includes'](_0x595ad8))return!0x1;const _0xd6ea43=_0x52626b[_0x595ad8],_0x23c65c=_0x220a14[_0x595ad8];if(ks(_0xd6ea43)&&ks(_0x23c65c)){if(!De(_0xd6ea43,_0x23c65c))return!0x1;}else{if(_0xd6ea43!==_0x23c65c)return!0x1;}}for(const _0x3ee60a of _0x45e717)if(!_0x61407d['includes'](_0x3ee60a))return!0x1;return!0x0;}function ks(_0x5de2bd){return _0x5de2bd!==null&&typeof _0x5de2bd=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x21390d){const _0x3dbb26=[];for(const [_0xcfa39f,_0x2efcd0]of Object['entries'](_0x21390d))Array['isArray'](_0x2efcd0)?_0x2efcd0['forEach'](_0x3fca3f=>{_0x3dbb26['push'](encodeURIComponent(_0xcfa39f)+'='+encodeURIComponent(_0x3fca3f));}):_0x3dbb26['push'](encodeURIComponent(_0xcfa39f)+'='+encodeURIComponent(_0x2efcd0));return _0x3dbb26['length']?'&'+_0x3dbb26['join']('&'):'';}function yt(_0x51df38){const _0x38ccfe={};return _0x51df38['replace'](/^\?/,'')['split']('&')['forEach'](_0x1fe5c9=>{if(_0x1fe5c9){const [_0xefef29,_0x48931a]=_0x1fe5c9['split']('=');_0x38ccfe[decodeURIComponent(_0xefef29)]=decodeURIComponent(_0x48931a);}}),_0x38ccfe;}function vt(_0x562214){const _0x58e222=_0x562214['indexOf']('?');if(!_0x58e222)return'';const _0x37735f=_0x562214['indexOf']('#',_0x58e222);return _0x562214['substring'](_0x58e222,_0x37735f>0x0?_0x37735f:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2a58f4=0x1;_0x2a58f4<this['blockSize'];++_0x2a58f4)this['pad_'][_0x2a58f4]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x414e89,_0x1800c6){_0x1800c6||(_0x1800c6=0x0);const _0x310043=this['W_'];if(typeof _0x414e89=='string'){for(let _0x58662e=0x0;_0x58662e<0x10;_0x58662e++)_0x310043[_0x58662e]=_0x414e89['charCodeAt'](_0x1800c6)<<0x18|_0x414e89['charCodeAt'](_0x1800c6+0x1)<<0x10|_0x414e89['charCodeAt'](_0x1800c6+0x2)<<0x8|_0x414e89['charCodeAt'](_0x1800c6+0x3),_0x1800c6+=0x4;}else{for(let _0x4e9dac=0x0;_0x4e9dac<0x10;_0x4e9dac++)_0x310043[_0x4e9dac]=_0x414e89[_0x1800c6]<<0x18|_0x414e89[_0x1800c6+0x1]<<0x10|_0x414e89[_0x1800c6+0x2]<<0x8|_0x414e89[_0x1800c6+0x3],_0x1800c6+=0x4;}for(let _0x7c0bf5=0x10;_0x7c0bf5<0x50;_0x7c0bf5++){const _0x2d5fa0=_0x310043[_0x7c0bf5-0x3]^_0x310043[_0x7c0bf5-0x8]^_0x310043[_0x7c0bf5-0xe]^_0x310043[_0x7c0bf5-0x10];_0x310043[_0x7c0bf5]=(_0x2d5fa0<<0x1|_0x2d5fa0>>>0x1f)&0xffffffff;}let _0xb38e76=this['chain_'][0x0],_0x2cafac=this['chain_'][0x1],_0x5f236a=this['chain_'][0x2],_0x34a4ac=this['chain_'][0x3],_0x2029f7=this['chain_'][0x4],_0x439d66,_0x2ab415;for(let _0xc84151=0x0;_0xc84151<0x50;_0xc84151++){_0xc84151<0x28?_0xc84151<0x14?(_0x439d66=_0x34a4ac^_0x2cafac&(_0x5f236a^_0x34a4ac),_0x2ab415=0x5a827999):(_0x439d66=_0x2cafac^_0x5f236a^_0x34a4ac,_0x2ab415=0x6ed9eba1):_0xc84151<0x3c?(_0x439d66=_0x2cafac&_0x5f236a|_0x34a4ac&(_0x2cafac|_0x5f236a),_0x2ab415=0x8f1bbcdc):(_0x439d66=_0x2cafac^_0x5f236a^_0x34a4ac,_0x2ab415=0xca62c1d6);const _0x2bb0e6=(_0xb38e76<<0x5|_0xb38e76>>>0x1b)+_0x439d66+_0x2029f7+_0x2ab415+_0x310043[_0xc84151]&0xffffffff;_0x2029f7=_0x34a4ac,_0x34a4ac=_0x5f236a,_0x5f236a=(_0x2cafac<<0x1e|_0x2cafac>>>0x2)&0xffffffff,_0x2cafac=_0xb38e76,_0xb38e76=_0x2bb0e6;}this['chain_'][0x0]=this['chain_'][0x0]+_0xb38e76&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2cafac&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x5f236a&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x34a4ac&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2029f7&0xffffffff;}['update'](_0x299518,_0xfa3630){if(_0x299518==null)return;_0xfa3630===void 0x0&&(_0xfa3630=_0x299518['length']);const _0x47acdc=_0xfa3630-this['blockSize'];let _0x5be2d2=0x0;const _0x57a200=this['buf_'];let _0x4d65c8=this['inbuf_'];for(;_0x5be2d2<_0xfa3630;){if(_0x4d65c8===0x0){for(;_0x5be2d2<=_0x47acdc;)this['compress_'](_0x299518,_0x5be2d2),_0x5be2d2+=this['blockSize'];}if(typeof _0x299518=='string'){for(;_0x5be2d2<_0xfa3630;)if(_0x57a200[_0x4d65c8]=_0x299518['charCodeAt'](_0x5be2d2),++_0x4d65c8,++_0x5be2d2,_0x4d65c8===this['blockSize']){this['compress_'](_0x57a200),_0x4d65c8=0x0;break;}}else{for(;_0x5be2d2<_0xfa3630;)if(_0x57a200[_0x4d65c8]=_0x299518[_0x5be2d2],++_0x4d65c8,++_0x5be2d2,_0x4d65c8===this['blockSize']){this['compress_'](_0x57a200),_0x4d65c8=0x0;break;}}}this['inbuf_']=_0x4d65c8,this['total_']+=_0xfa3630;}['digest'](){const _0x4dfafb=[];let _0x30f192=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4e7a43=this['blockSize']-0x1;_0x4e7a43>=0x38;_0x4e7a43--)this['buf_'][_0x4e7a43]=_0x30f192&0xff,_0x30f192/=0x100;this['compress_'](this['buf_']);let _0x15f4e1=0x0;for(let _0x9fe12f=0x0;_0x9fe12f<0x5;_0x9fe12f++)for(let _0x333e96=0x18;_0x333e96>=0x0;_0x333e96-=0x8)_0x4dfafb[_0x15f4e1]=this['chain_'][_0x9fe12f]>>_0x333e96&0xff,++_0x15f4e1;return _0x4dfafb;}}function Ic(_0xe8ad0c,_0x35f070){const _0x5ab3a9=new wc(_0xe8ad0c,_0x35f070);return _0x5ab3a9['subscribe']['bind'](_0x5ab3a9);}class wc{constructor(_0x4eb725,_0x1e1f1c){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x1e1f1c,this['task']['then'](()=>{_0x4eb725(this);})['catch'](_0x384520=>{this['error'](_0x384520);});}['next'](_0x554000){this['forEachObserver'](_0x5d8970=>{_0x5d8970['next'](_0x554000);});}['error'](_0x5b886b){this['forEachObserver'](_0x3d388c=>{_0x3d388c['error'](_0x5b886b);}),this['close'](_0x5b886b);}['complete'](){this['forEachObserver'](_0x2af09e=>{_0x2af09e['complete']();}),this['close']();}['subscribe'](_0x4b3167,_0x70a227,_0x57613d){let _0x5de22d;if(_0x4b3167===void 0x0&&_0x70a227===void 0x0&&_0x57613d===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x4b3167,['next','error','complete'])?_0x5de22d=_0x4b3167:_0x5de22d={'next':_0x4b3167,'error':_0x70a227,'complete':_0x57613d},_0x5de22d['next']===void 0x0&&(_0x5de22d['next']=Qn),_0x5de22d['error']===void 0x0&&(_0x5de22d['error']=Qn),_0x5de22d['complete']===void 0x0&&(_0x5de22d['complete']=Qn);const _0x58cf23=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5de22d['error'](this['finalError']):_0x5de22d['complete']();}catch{}}),this['observers']['push'](_0x5de22d),_0x58cf23;}['unsubscribeOne'](_0x12f3ff){this['observers']===void 0x0||this['observers'][_0x12f3ff]===void 0x0||(delete this['observers'][_0x12f3ff],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x38d4a1){if(!this['finalized']){for(let _0x58dbeb=0x0;_0x58dbeb<this['observers']['length'];_0x58dbeb++)this['sendOne'](_0x58dbeb,_0x38d4a1);}}['sendOne'](_0x4b43c8,_0x20b0b4){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4b43c8]!==void 0x0)try{_0x20b0b4(this['observers'][_0x4b43c8]);}catch(_0x4257da){typeof console<'u'&&console['error']&&console['error'](_0x4257da);}});}['close'](_0x1230d1){this['finalized']||(this['finalized']=!0x0,_0x1230d1!==void 0x0&&(this['finalError']=_0x1230d1),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x1a210a,_0x516003){if(typeof _0x1a210a!='object'||_0x1a210a===null)return!0x1;for(const _0x333f61 of _0x516003)if(_0x333f61 in _0x1a210a&&typeof _0x1a210a[_0x333f61]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x497d45,_0x10e224){return _0x497d45+'\x20failed:\x20'+_0x10e224+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x50e7c5){const _0x35f65c=[];let _0x1c1eab=0x0;for(let _0x52fcd7=0x0;_0x52fcd7<_0x50e7c5['length'];_0x52fcd7++){let _0x1f1e07=_0x50e7c5['charCodeAt'](_0x52fcd7);if(_0x1f1e07>=0xd800&&_0x1f1e07<=0xdbff){const _0x1026c9=_0x1f1e07-0xd800;_0x52fcd7++,f(_0x52fcd7<_0x50e7c5['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x541792=_0x50e7c5['charCodeAt'](_0x52fcd7)-0xdc00;_0x1f1e07=0x10000+(_0x1026c9<<0xa)+_0x541792;}_0x1f1e07<0x80?_0x35f65c[_0x1c1eab++]=_0x1f1e07:_0x1f1e07<0x800?(_0x35f65c[_0x1c1eab++]=_0x1f1e07>>0x6|0xc0,_0x35f65c[_0x1c1eab++]=_0x1f1e07&0x3f|0x80):_0x1f1e07<0x10000?(_0x35f65c[_0x1c1eab++]=_0x1f1e07>>0xc|0xe0,_0x35f65c[_0x1c1eab++]=_0x1f1e07>>0x6&0x3f|0x80,_0x35f65c[_0x1c1eab++]=_0x1f1e07&0x3f|0x80):(_0x35f65c[_0x1c1eab++]=_0x1f1e07>>0x12|0xf0,_0x35f65c[_0x1c1eab++]=_0x1f1e07>>0xc&0x3f|0x80,_0x35f65c[_0x1c1eab++]=_0x1f1e07>>0x6&0x3f|0x80,_0x35f65c[_0x1c1eab++]=_0x1f1e07&0x3f|0x80);}return _0x35f65c;},Pn=function(_0x370cff){let _0x284f22=0x0;for(let _0x4c610f=0x0;_0x4c610f<_0x370cff['length'];_0x4c610f++){const _0x718e4b=_0x370cff['charCodeAt'](_0x4c610f);_0x718e4b<0x80?_0x284f22++:_0x718e4b<0x800?_0x284f22+=0x2:_0x718e4b>=0xd800&&_0x718e4b<=0xdbff?(_0x284f22+=0x4,_0x4c610f++):_0x284f22+=0x3;}return _0x284f22;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x2244f5){return _0x2244f5&&_0x2244f5['_delegate']?_0x2244f5['_delegate']:_0x2244f5;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x2db9e6){try{return(_0x2db9e6['startsWith']('http://')||_0x2db9e6['startsWith']('https://')?new URL(_0x2db9e6)['hostname']:_0x2db9e6)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x2f1006){return(await fetch(_0x2f1006,{'credentials':'include'}))['ok'];}class Me{constructor(_0x3b43f8,_0x3116c4,_0x2bc3a4){this['name']=_0x3b43f8,this['instanceFactory']=_0x3116c4,this['type']=_0x2bc3a4,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4296a9){return this['instantiationMode']=_0x4296a9,this;}['setMultipleInstances'](_0x5881aa){return this['multipleInstances']=_0x5881aa,this;}['setServiceProps'](_0x3437d2){return this['serviceProps']=_0x3437d2,this;}['setInstanceCreatedCallback'](_0x4775bb){return this['onInstanceCreated']=_0x4775bb,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x5d532f,_0x52f378){this['name']=_0x5d532f,this['container']=_0x52f378,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x595451){const _0x2dc8fe=this['normalizeInstanceIdentifier'](_0x595451);if(!this['instancesDeferred']['has'](_0x2dc8fe)){const _0x323034=new Ve();if(this['instancesDeferred']['set'](_0x2dc8fe,_0x323034),this['isInitialized'](_0x2dc8fe)||this['shouldAutoInitialize']())try{const _0x4250b0=this['getOrInitializeService']({'instanceIdentifier':_0x2dc8fe});_0x4250b0&&_0x323034['resolve'](_0x4250b0);}catch{}}return this['instancesDeferred']['get'](_0x2dc8fe)['promise'];}['getImmediate'](_0xffc46c){const _0x25f194=this['normalizeInstanceIdentifier'](_0xffc46c==null?void 0x0:_0xffc46c['identifier']),_0x1b937f=(_0xffc46c==null?void 0x0:_0xffc46c['optional'])??!0x1;if(this['isInitialized'](_0x25f194)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x25f194});}catch(_0x24c6f6){if(_0x1b937f)return null;throw _0x24c6f6;}else{if(_0x1b937f)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x30f375){if(_0x30f375['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x30f375['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x30f375,!!this['shouldAutoInitialize']()){if(Rc(_0x30f375))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x15feca,_0x124c8a]of this['instancesDeferred']['entries']()){const _0x9bc13c=this['normalizeInstanceIdentifier'](_0x15feca);try{const _0x46e68c=this['getOrInitializeService']({'instanceIdentifier':_0x9bc13c});_0x124c8a['resolve'](_0x46e68c);}catch{}}}}['clearInstance'](_0x578d06=ke){this['instancesDeferred']['delete'](_0x578d06),this['instancesOptions']['delete'](_0x578d06),this['instances']['delete'](_0x578d06);}async['delete'](){const _0x736a19=Array['from'](this['instances']['values']());await Promise['all']([..._0x736a19['filter'](_0x49513e=>'INTERNAL'in _0x49513e)['map'](_0x258eb7=>_0x258eb7['INTERNAL']['delete']()),..._0x736a19['filter'](_0x496f51=>'_delete'in _0x496f51)['map'](_0x53713d=>_0x53713d['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0xa99c38=ke){return this['instances']['has'](_0xa99c38);}['getOptions'](_0x5bac39=ke){return this['instancesOptions']['get'](_0x5bac39)||{};}['initialize'](_0x39e5f8={}){const {options:_0x4dbbb2={}}=_0x39e5f8,_0x1f821a=this['normalizeInstanceIdentifier'](_0x39e5f8['instanceIdentifier']);if(this['isInitialized'](_0x1f821a))throw Error(this['name']+'('+_0x1f821a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5c29ed=this['getOrInitializeService']({'instanceIdentifier':_0x1f821a,'options':_0x4dbbb2});for(const [_0x2e90ed,_0x1978f7]of this['instancesDeferred']['entries']()){const _0x10a93e=this['normalizeInstanceIdentifier'](_0x2e90ed);_0x1f821a===_0x10a93e&&_0x1978f7['resolve'](_0x5c29ed);}return _0x5c29ed;}['onInit'](_0x20f9ff,_0x5e380d){const _0x166488=this['normalizeInstanceIdentifier'](_0x5e380d),_0x20de08=this['onInitCallbacks']['get'](_0x166488)??new Set();_0x20de08['add'](_0x20f9ff),this['onInitCallbacks']['set'](_0x166488,_0x20de08);const _0x113852=this['instances']['get'](_0x166488);return _0x113852&&_0x20f9ff(_0x113852,_0x166488),()=>{_0x20de08['delete'](_0x20f9ff);};}['invokeOnInitCallbacks'](_0x4c992e,_0x72d6f0){const _0x1697f3=this['onInitCallbacks']['get'](_0x72d6f0);if(_0x1697f3){for(const _0xc2c268 of _0x1697f3)try{_0xc2c268(_0x4c992e,_0x72d6f0);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x599fc3,options:_0x1ee810={}}){let _0x8bf40d=this['instances']['get'](_0x599fc3);if(!_0x8bf40d&&this['component']&&(_0x8bf40d=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x599fc3),'options':_0x1ee810}),this['instances']['set'](_0x599fc3,_0x8bf40d),this['instancesOptions']['set'](_0x599fc3,_0x1ee810),this['invokeOnInitCallbacks'](_0x8bf40d,_0x599fc3),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x599fc3,_0x8bf40d);}catch{}return _0x8bf40d||null;}['normalizeInstanceIdentifier'](_0x89ed89=ke){return this['component']?this['component']['multipleInstances']?_0x89ed89:ke:_0x89ed89;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x32027e){return _0x32027e===ke?void 0x0:_0x32027e;}function Rc(_0x54f4ed){return _0x54f4ed['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x23b6e3){this['name']=_0x23b6e3,this['providers']=new Map();}['addComponent'](_0x2ac444){const _0x59bdd3=this['getProvider'](_0x2ac444['name']);if(_0x59bdd3['isComponentSet']())throw new Error('Component\x20'+_0x2ac444['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x59bdd3['setComponent'](_0x2ac444);}['addOrOverwriteComponent'](_0x288fc7){this['getProvider'](_0x288fc7['name'])['isComponentSet']()&&this['providers']['delete'](_0x288fc7['name']),this['addComponent'](_0x288fc7);}['getProvider'](_0x25086e){if(this['providers']['has'](_0x25086e))return this['providers']['get'](_0x25086e);const _0x3299da=new Sc(_0x25086e,this);return this['providers']['set'](_0x25086e,_0x3299da),_0x3299da;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x631b58){_0x631b58[_0x631b58['DEBUG']=0x0]='DEBUG',_0x631b58[_0x631b58['VERBOSE']=0x1]='VERBOSE',_0x631b58[_0x631b58['INFO']=0x2]='INFO',_0x631b58[_0x631b58['WARN']=0x3]='WARN',_0x631b58[_0x631b58['ERROR']=0x4]='ERROR',_0x631b58[_0x631b58['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x4e3514,_0x1358b7,..._0x3521c3)=>{if(_0x1358b7<_0x4e3514['logLevel'])return;const _0x432c62=new Date()['toISOString'](),_0x47a133=Pc[_0x1358b7];if(_0x47a133)console[_0x47a133]('['+_0x432c62+']\x20\x20'+_0x4e3514['name']+':',..._0x3521c3);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1358b7+')');};class xi{constructor(_0x325050){this['name']=_0x325050,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x438511){if(!(_0x438511 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x438511+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x438511;}['setLogLevel'](_0x46ac61){this['_logLevel']=typeof _0x46ac61=='string'?kc[_0x46ac61]:_0x46ac61;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x8c9bbe){if(typeof _0x8c9bbe!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x8c9bbe;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x570d72){this['_userLogHandler']=_0x570d72;}['debug'](..._0xc766a3){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0xc766a3),this['_logHandler'](this,T['DEBUG'],..._0xc766a3);}['log'](..._0x2d9e40){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2d9e40),this['_logHandler'](this,T['VERBOSE'],..._0x2d9e40);}['info'](..._0x1686ac){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1686ac),this['_logHandler'](this,T['INFO'],..._0x1686ac);}['warn'](..._0xbd6d3a){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0xbd6d3a),this['_logHandler'](this,T['WARN'],..._0xbd6d3a);}['error'](..._0x5d8841){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5d8841),this['_logHandler'](this,T['ERROR'],..._0x5d8841);}}const Dc=(_0x4b7fd0,_0xd59352)=>_0xd59352['some'](_0x34ee11=>_0x4b7fd0 instanceof _0x34ee11);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x2cec74){const _0x1b02da=new Promise((_0x2d4775,_0x253695)=>{const _0x45507=()=>{_0x2cec74['removeEventListener']('success',_0x1b80af),_0x2cec74['removeEventListener']('error',_0x2caf62);},_0x1b80af=()=>{_0x2d4775(_e(_0x2cec74['result'])),_0x45507();},_0x2caf62=()=>{_0x253695(_0x2cec74['error']),_0x45507();};_0x2cec74['addEventListener']('success',_0x1b80af),_0x2cec74['addEventListener']('error',_0x2caf62);});return _0x1b02da['then'](_0x5efc72=>{_0x5efc72 instanceof IDBCursor&&Kr['set'](_0x5efc72,_0x2cec74);})['catch'](()=>{}),Fi['set'](_0x1b02da,_0x2cec74),_0x1b02da;}function Fc(_0x4b308f){if(ui['has'](_0x4b308f))return;const _0x295cbf=new Promise((_0x2afd39,_0x3a0bda)=>{const _0x12d2ca=()=>{_0x4b308f['removeEventListener']('complete',_0x5bb4a0),_0x4b308f['removeEventListener']('error',_0x518589),_0x4b308f['removeEventListener']('abort',_0x518589);},_0x5bb4a0=()=>{_0x2afd39(),_0x12d2ca();},_0x518589=()=>{_0x3a0bda(_0x4b308f['error']||new DOMException('AbortError','AbortError')),_0x12d2ca();};_0x4b308f['addEventListener']('complete',_0x5bb4a0),_0x4b308f['addEventListener']('error',_0x518589),_0x4b308f['addEventListener']('abort',_0x518589);});ui['set'](_0x4b308f,_0x295cbf);}let di={'get'(_0x33fe88,_0x3dd42f,_0x18b859){if(_0x33fe88 instanceof IDBTransaction){if(_0x3dd42f==='done')return ui['get'](_0x33fe88);if(_0x3dd42f==='objectStoreNames')return _0x33fe88['objectStoreNames']||Yr['get'](_0x33fe88);if(_0x3dd42f==='store')return _0x18b859['objectStoreNames'][0x1]?void 0x0:_0x18b859['objectStore'](_0x18b859['objectStoreNames'][0x0]);}return _e(_0x33fe88[_0x3dd42f]);},'set'(_0x206ed7,_0x320b1e,_0x4612ff){return _0x206ed7[_0x320b1e]=_0x4612ff,!0x0;},'has'(_0x2b3eb2,_0x416195){return _0x2b3eb2 instanceof IDBTransaction&&(_0x416195==='done'||_0x416195==='store')?!0x0:_0x416195 in _0x2b3eb2;}};function Uc(_0x15411f){di=_0x15411f(di);}function Wc(_0x4ad9c1){return _0x4ad9c1===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x413e00,..._0x34161e){const _0x59c926=_0x4ad9c1['call'](Xn(this),_0x413e00,..._0x34161e);return Yr['set'](_0x59c926,_0x413e00['sort']?_0x413e00['sort']():[_0x413e00]),_e(_0x59c926);}:Lc()['includes'](_0x4ad9c1)?function(..._0x2b07c6){return _0x4ad9c1['apply'](Xn(this),_0x2b07c6),_e(Kr['get'](this));}:function(..._0x2a2e7d){return _e(_0x4ad9c1['apply'](Xn(this),_0x2a2e7d));};}function Bc(_0x99ae41){return typeof _0x99ae41=='function'?Wc(_0x99ae41):(_0x99ae41 instanceof IDBTransaction&&Fc(_0x99ae41),Dc(_0x99ae41,Mc())?new Proxy(_0x99ae41,di):_0x99ae41);}function _e(_0x355658){if(_0x355658 instanceof IDBRequest)return xc(_0x355658);if(Jn['has'](_0x355658))return Jn['get'](_0x355658);const _0xa50940=Bc(_0x355658);return _0xa50940!==_0x355658&&(Jn['set'](_0x355658,_0xa50940),Fi['set'](_0xa50940,_0x355658)),_0xa50940;}const Xn=_0x12dc1a=>Fi['get'](_0x12dc1a);function Vc(_0x249136,_0xd506a5,{blocked:_0x1b44f2,upgrade:_0x42395c,blocking:_0xb863c9,terminated:_0x519446}={}){const _0x267d10=indexedDB['open'](_0x249136,_0xd506a5),_0x50db3f=_e(_0x267d10);return _0x42395c&&_0x267d10['addEventListener']('upgradeneeded',_0x2bdaf9=>{_0x42395c(_e(_0x267d10['result']),_0x2bdaf9['oldVersion'],_0x2bdaf9['newVersion'],_e(_0x267d10['transaction']),_0x2bdaf9);}),_0x1b44f2&&_0x267d10['addEventListener']('blocked',_0x278806=>_0x1b44f2(_0x278806['oldVersion'],_0x278806['newVersion'],_0x278806)),_0x50db3f['then'](_0x58f424=>{_0x519446&&_0x58f424['addEventListener']('close',()=>_0x519446()),_0xb863c9&&_0x58f424['addEventListener']('versionchange',_0x435d35=>_0xb863c9(_0x435d35['oldVersion'],_0x435d35['newVersion'],_0x435d35));})['catch'](()=>{}),_0x50db3f;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x461017,_0x29d72c){if(!(_0x461017 instanceof IDBDatabase&&!(_0x29d72c in _0x461017)&&typeof _0x29d72c=='string'))return;if(Zn['get'](_0x29d72c))return Zn['get'](_0x29d72c);const _0x38f94e=_0x29d72c['replace'](/FromIndex$/,''),_0x5e8c98=_0x29d72c!==_0x38f94e,_0x3c5e47=$c['includes'](_0x38f94e);if(!(_0x38f94e in(_0x5e8c98?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3c5e47||Hc['includes'](_0x38f94e)))return;const _0x224f26=async function(_0x2c272b,..._0x363132){const _0x5c4c85=this['transaction'](_0x2c272b,_0x3c5e47?'readwrite':'readonly');let _0x274609=_0x5c4c85['store'];return _0x5e8c98&&(_0x274609=_0x274609['index'](_0x363132['shift']())),(await Promise['all']([_0x274609[_0x38f94e](..._0x363132),_0x3c5e47&&_0x5c4c85['done']]))[0x0];};return Zn['set'](_0x29d72c,_0x224f26),_0x224f26;}Uc(_0x49409a=>({..._0x49409a,'get':(_0x572272,_0x4036b3,_0x7abf76)=>Os(_0x572272,_0x4036b3)||_0x49409a['get'](_0x572272,_0x4036b3,_0x7abf76),'has':(_0x396d11,_0x447eb7)=>!!Os(_0x396d11,_0x447eb7)||_0x49409a['has'](_0x396d11,_0x447eb7)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x228628){this['container']=_0x228628;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x349319=>{if(qc(_0x349319)){const _0x4c90ec=_0x349319['getImmediate']();return _0x4c90ec['library']+'/'+_0x4c90ec['version'];}else return null;})['filter'](_0x4b152e=>_0x4b152e)['join']('\x20');}}function qc(_0xd99b0f){const _0x87d7fb=_0xd99b0f['getComponent']();return(_0x87d7fb==null?void 0x0:_0x87d7fb['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x1fb19a,_0x148714){try{_0x1fb19a['container']['addComponent'](_0x148714);}catch(_0x5440d2){re['debug']('Component\x20'+_0x148714['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1fb19a['name'],_0x5440d2);}}function et(_0x123901){const _0x56a483=_0x123901['name'];if(gi['has'](_0x56a483))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x56a483+'.'),!0x1;gi['set'](_0x56a483,_0x123901);for(const _0x17e660 of Le['values']())Ms(_0x17e660,_0x123901);for(const _0xccbeb7 of _i['values']())Ms(_0xccbeb7,_0x123901);return!0x0;}function Ui(_0x3db27d,_0x121cf5){const _0x5b9965=_0x3db27d['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x5b9965&&_0x5b9965['triggerHeartbeat'](),_0x3db27d['container']['getProvider'](_0x121cf5);}function H(_0x2bf4e){return _0x2bf4e==null?!0x1:_0x2bf4e['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x2a1343,_0x1dfd60,_0x2510e9){this['_isDeleted']=!0x1,this['_options']={..._0x2a1343},this['_config']={..._0x1dfd60},this['_name']=_0x1dfd60['name'],this['_automaticDataCollectionEnabled']=_0x1dfd60['automaticDataCollectionEnabled'],this['_container']=_0x2510e9,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x23f4a3){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x23f4a3;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x282c39){this['_isDeleted']=_0x282c39;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x4f067b,_0x58f943={}){let _0x58c7cd=_0x4f067b;typeof _0x58f943!='object'&&(_0x58f943={'name':_0x58f943});const _0x11118f={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x58f943},_0x324c69=_0x11118f['name'];if(typeof _0x324c69!='string'||!_0x324c69)throw ge['create']('bad-app-name',{'appName':String(_0x324c69)});if(_0x58c7cd||(_0x58c7cd=$r()),!_0x58c7cd)throw ge['create']('no-options');const _0x1fe250=Le['get'](_0x324c69);if(_0x1fe250){if(De(_0x58c7cd,_0x1fe250['options'])&&De(_0x11118f,_0x1fe250['config']))return _0x1fe250;throw ge['create']('duplicate-app',{'appName':_0x324c69});}const _0xe2bdeb=new Ac(_0x324c69);for(const _0x465d8d of gi['values']())_0xe2bdeb['addComponent'](_0x465d8d);const _0x1fbc7b=new Il(_0x58c7cd,_0x11118f,_0xe2bdeb);return Le['set'](_0x324c69,_0x1fbc7b),_0x1fbc7b;}function Qr(_0x3e3fda=pi){const _0x19f4d1=Le['get'](_0x3e3fda);if(!_0x19f4d1&&_0x3e3fda===pi&&$r())return wl();if(!_0x19f4d1)throw ge['create']('no-app',{'appName':_0x3e3fda});return _0x19f4d1;}function l_(){return Array['from'](Le['values']());}async function h_(_0x496a69){let _0x329c79=!0x1;const _0x308521=_0x496a69['name'];Le['has'](_0x308521)?(_0x329c79=!0x0,Le['delete'](_0x308521)):_i['has'](_0x308521)&&_0x496a69['decRefCount']()<=0x0&&(_i['delete'](_0x308521),_0x329c79=!0x0),_0x329c79&&(await Promise['all'](_0x496a69['container']['getProviders']()['map'](_0x32c331=>_0x32c331['delete']())),_0x496a69['isDeleted']=!0x0);}function me(_0xd868f7,_0x542131,_0x2e65e6){let _0x2285a3=vl[_0xd868f7]??_0xd868f7;_0x2e65e6&&(_0x2285a3+='-'+_0x2e65e6);const _0x478f5a=_0x2285a3['match'](/\s|\//),_0x591c7e=_0x542131['match'](/\s|\//);if(_0x478f5a||_0x591c7e){const _0x3ffda7=['Unable\x20to\x20register\x20library\x20\x22'+_0x2285a3+'\x22\x20with\x20version\x20\x22'+_0x542131+'\x22:'];_0x478f5a&&_0x3ffda7['push']('library\x20name\x20\x22'+_0x2285a3+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x478f5a&&_0x591c7e&&_0x3ffda7['push']('and'),_0x591c7e&&_0x3ffda7['push']('version\x20name\x20\x22'+_0x542131+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3ffda7['join']('\x20'));return;}et(new Me(_0x2285a3+'-version',()=>({'library':_0x2285a3,'version':_0x542131}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0xa43d0d,_0x36ae2e)=>{switch(_0x36ae2e){case 0x0:try{_0xa43d0d['createObjectStore'](Rt);}catch(_0x1a4b0a){console['warn'](_0x1a4b0a);}}}})['catch'](_0x5ce798=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x5ce798['message']});})),ei;}async function Sl(_0x4b0dfd){try{const _0x34c3a8=(await Jr())['transaction'](Rt),_0x4aa33f=await _0x34c3a8['objectStore'](Rt)['get'](Xr(_0x4b0dfd));return await _0x34c3a8['done'],_0x4aa33f;}catch(_0x11461c){if(_0x11461c instanceof Se)re['warn'](_0x11461c['message']);else{const _0x21210a=ge['create']('idb-get',{'originalErrorMessage':_0x11461c==null?void 0x0:_0x11461c['message']});re['warn'](_0x21210a['message']);}}}async function Ls(_0x2de9ad,_0x5c11b1){try{const _0x1b3cda=(await Jr())['transaction'](Rt,'readwrite');await _0x1b3cda['objectStore'](Rt)['put'](_0x5c11b1,Xr(_0x2de9ad)),await _0x1b3cda['done'];}catch(_0x4b0a51){if(_0x4b0a51 instanceof Se)re['warn'](_0x4b0a51['message']);else{const _0x5336aa=ge['create']('idb-set',{'originalErrorMessage':_0x4b0a51==null?void 0x0:_0x4b0a51['message']});re['warn'](_0x5336aa['message']);}}}function Xr(_0x5577b7){return _0x5577b7['name']+'!'+_0x5577b7['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x14807f){this['container']=_0x14807f,this['_heartbeatsCache']=null;const _0x4a4fa3=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x4a4fa3),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x32d4d5=>(this['_heartbeatsCache']=_0x32d4d5,_0x32d4d5));}async['triggerHeartbeat'](){var _0x23cce7,_0x447aea;try{const _0x2b29ec=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2e444c=xs();if(((_0x23cce7=this['_heartbeatsCache'])==null?void 0x0:_0x23cce7['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x447aea=this['_heartbeatsCache'])==null?void 0x0:_0x447aea['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2e444c||this['_heartbeatsCache']['heartbeats']['some'](_0x36d781=>_0x36d781['date']===_0x2e444c))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2e444c,'agent':_0x2b29ec}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x49a25f=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x49a25f,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5576b1){re['warn'](_0x5576b1);}}async['getHeartbeatsHeader'](){var _0x689d21;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x689d21=this['_heartbeatsCache'])==null?void 0x0:_0x689d21['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5cf846=xs(),{heartbeatsToSend:_0x17d77e,unsentEntries:_0x2191ee}=kl(this['_heartbeatsCache']['heartbeats']),_0x57c862=an(JSON['stringify']({'version':0x2,'heartbeats':_0x17d77e}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5cf846,_0x2191ee['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2191ee,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x57c862;}catch(_0x5c3475){return re['warn'](_0x5c3475),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x33e226,_0xd5ff80=bl){const _0x512818=[];let _0xa25dfa=_0x33e226['slice']();for(const _0x30e6fe of _0x33e226){const _0x5d6449=_0x512818['find'](_0x6f574b=>_0x6f574b['agent']===_0x30e6fe['agent']);if(_0x5d6449){if(_0x5d6449['dates']['push'](_0x30e6fe['date']),Fs(_0x512818)>_0xd5ff80){_0x5d6449['dates']['pop']();break;}}else{if(_0x512818['push']({'agent':_0x30e6fe['agent'],'dates':[_0x30e6fe['date']]}),Fs(_0x512818)>_0xd5ff80){_0x512818['pop']();break;}}_0xa25dfa=_0xa25dfa['slice'](0x1);}return{'heartbeatsToSend':_0x512818,'unsentEntries':_0xa25dfa};}class Nl{constructor(_0x20ad7a){this['app']=_0x20ad7a,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5bd60d=await Sl(this['app']);return _0x5bd60d!=null&&_0x5bd60d['heartbeats']?_0x5bd60d:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x42c9fb){if(await this['_canUseIndexedDBPromise']){const _0x28ffa7=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x42c9fb['lastSentHeartbeatDate']??_0x28ffa7['lastSentHeartbeatDate'],'heartbeats':_0x42c9fb['heartbeats']});}else return;}async['add'](_0x3cf644){if(await this['_canUseIndexedDBPromise']){const _0x546cc6=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x3cf644['lastSentHeartbeatDate']??_0x546cc6['lastSentHeartbeatDate'],'heartbeats':[..._0x546cc6['heartbeats'],..._0x3cf644['heartbeats']]});}else return;}}function Fs(_0x420554){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x420554}))['length'];}function Pl(_0x30df24){if(_0x30df24['length']===0x0)return-0x1;let _0x4a1550=0x0,_0x16a211=_0x30df24[0x0]['date'];for(let _0x41bc7f=0x1;_0x41bc7f<_0x30df24['length'];_0x41bc7f++)_0x30df24[_0x41bc7f]['date']<_0x16a211&&(_0x16a211=_0x30df24[_0x41bc7f]['date'],_0x4a1550=_0x41bc7f);return _0x4a1550;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x395722){et(new Me('platform-logger',_0x36f0cf=>new Gc(_0x36f0cf),'PRIVATE')),et(new Me('heartbeat',_0x14203c=>new Al(_0x14203c),'PRIVATE')),me(fi,Ds,_0x395722),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x16d2b3){Zr=_0x16d2b3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x167b80){this['domStorage_']=_0x167b80,this['prefix_']='firebase:';}['set'](_0x3c3ad4,_0x31e7da){_0x31e7da==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3c3ad4)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3c3ad4),O(_0x31e7da));}['get'](_0x32ad93){const _0x117c56=this['domStorage_']['getItem'](this['prefixedName_'](_0x32ad93));return _0x117c56==null?null:bt(_0x117c56);}['remove'](_0x554f67){this['domStorage_']['removeItem'](this['prefixedName_'](_0x554f67));}['prefixedName_'](_0x36caee){return this['prefix_']+_0x36caee;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4f85da,_0x2b4bed){_0x2b4bed==null?delete this['cache_'][_0x4f85da]:this['cache_'][_0x4f85da]=_0x2b4bed;}['get'](_0x436178){return Y(this['cache_'],_0x436178)?this['cache_'][_0x436178]:null;}['remove'](_0x226d17){delete this['cache_'][_0x226d17];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x44b341){try{if(typeof window<'u'&&typeof window[_0x44b341]<'u'){const _0x483bbf=window[_0x44b341];return _0x483bbf['setItem']('firebase:sentinel','cache'),_0x483bbf['removeItem']('firebase:sentinel'),new xl(_0x483bbf);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x4a4567=0x1;return function(){return _0x4a4567++;};}()),no=function(_0x4f5135){const _0x28187f=Tc(_0x4f5135),_0x9ec594=new Ec();_0x9ec594['update'](_0x28187f);const _0x18cb16=_0x9ec594['digest']();return Di['encodeByteArray'](_0x18cb16);},Bt=function(..._0x5e5ee8){let _0x5475d7='';for(let _0x152e93=0x0;_0x152e93<_0x5e5ee8['length'];_0x152e93++){const _0x4e7fa6=_0x5e5ee8[_0x152e93];Array['isArray'](_0x4e7fa6)||_0x4e7fa6&&typeof _0x4e7fa6=='object'&&typeof _0x4e7fa6['length']=='number'?_0x5475d7+=Bt['apply'](null,_0x4e7fa6):typeof _0x4e7fa6=='object'?_0x5475d7+=O(_0x4e7fa6):_0x5475d7+=_0x4e7fa6,_0x5475d7+='\x20';}return _0x5475d7;};let Et=null,Vs=!0x0;const Wl=function(_0x2713df,_0x47d1cb){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x17d607){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x1dc6bf=Bt['apply'](null,_0x17d607);Et(_0x1dc6bf);}},Vt=function(_0x405d2c){return function(..._0x315459){L(_0x405d2c,..._0x315459);};},mi=function(..._0x33c56a){const _0x131c90='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x33c56a);Qe['error'](_0x131c90);},oe=function(..._0x4e181d){const _0x482465='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x4e181d);throw Qe['error'](_0x482465),new Error(_0x482465);},U=function(..._0x3f4de7){const _0x25b19e='FIREBASE\x20WARNING:\x20'+Bt(..._0x3f4de7);Qe['warn'](_0x25b19e);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x34a22a){return typeof _0x34a22a=='number'&&(_0x34a22a!==_0x34a22a||_0x34a22a===Number['POSITIVE_INFINITY']||_0x34a22a===Number['NEGATIVE_INFINITY']);},Vl=function(_0x43166d){if(document['readyState']==='complete')_0x43166d();else{let _0x3ad997=!0x1;const _0x429757=function(){if(!document['body']){setTimeout(_0x429757,Math['floor'](0xa));return;}_0x3ad997||(_0x3ad997=!0x0,_0x43166d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x429757,!0x1),window['addEventListener']('load',_0x429757,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x429757();}),window['attachEvent']('onload',_0x429757));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x3188ce,_0x4fa1d5){if(_0x3188ce===_0x4fa1d5)return 0x0;if(_0x3188ce===xe||_0x4fa1d5===Ie)return-0x1;if(_0x4fa1d5===xe||_0x3188ce===Ie)return 0x1;{const _0x20cf03=Hs(_0x3188ce),_0x2357a0=Hs(_0x4fa1d5);return _0x20cf03!==null?_0x2357a0!==null?_0x20cf03-_0x2357a0===0x0?_0x3188ce['length']-_0x4fa1d5['length']:_0x20cf03-_0x2357a0:-0x1:_0x2357a0!==null?0x1:_0x3188ce<_0x4fa1d5?-0x1:0x1;}},Hl=function(_0x4ecdfc,_0x516942){return _0x4ecdfc===_0x516942?0x0:_0x4ecdfc<_0x516942?-0x1:0x1;},pt=function(_0x23d64c,_0x1dc4fc){if(_0x1dc4fc&&_0x23d64c in _0x1dc4fc)return _0x1dc4fc[_0x23d64c];throw new Error('Missing\x20required\x20key\x20('+_0x23d64c+')\x20in\x20object:\x20'+O(_0x1dc4fc));},Bi=function(_0x56f4ea){if(typeof _0x56f4ea!='object'||_0x56f4ea===null)return O(_0x56f4ea);const _0x3b9eeb=[];for(const _0x42da28 in _0x56f4ea)_0x3b9eeb['push'](_0x42da28);_0x3b9eeb['sort']();let _0xf8ef57='{';for(let _0x4486fd=0x0;_0x4486fd<_0x3b9eeb['length'];_0x4486fd++)_0x4486fd!==0x0&&(_0xf8ef57+=','),_0xf8ef57+=O(_0x3b9eeb[_0x4486fd]),_0xf8ef57+=':',_0xf8ef57+=Bi(_0x56f4ea[_0x3b9eeb[_0x4486fd]]);return _0xf8ef57+='}',_0xf8ef57;},io=function(_0x420a2c,_0x5056ff){const _0x13e88e=_0x420a2c['length'];if(_0x13e88e<=_0x5056ff)return[_0x420a2c];const _0x42397e=[];for(let _0x423351=0x0;_0x423351<_0x13e88e;_0x423351+=_0x5056ff)_0x423351+_0x5056ff>_0x13e88e?_0x42397e['push'](_0x420a2c['substring'](_0x423351,_0x13e88e)):_0x42397e['push'](_0x420a2c['substring'](_0x423351,_0x423351+_0x5056ff));return _0x42397e;};function x(_0x1610cd,_0x356ae8){for(const _0x4d0c3b in _0x1610cd)_0x1610cd['hasOwnProperty'](_0x4d0c3b)&&_0x356ae8(_0x4d0c3b,_0x1610cd[_0x4d0c3b]);}const so=function(_0x2d9be7){f(!Wi(_0x2d9be7),'Invalid\x20JSON\x20number');const _0x170681=0xb,_0x41e0bc=0x34,_0x5490b7=(0x1<<_0x170681-0x1)-0x1;let _0x4c293a,_0x37f2bc,_0x46587b,_0x1a77e7,_0x271a6a;_0x2d9be7===0x0?(_0x37f2bc=0x0,_0x46587b=0x0,_0x4c293a=0x1/_0x2d9be7===-0x1/0x0?0x1:0x0):(_0x4c293a=_0x2d9be7<0x0,_0x2d9be7=Math['abs'](_0x2d9be7),_0x2d9be7>=Math['pow'](0x2,0x1-_0x5490b7)?(_0x1a77e7=Math['min'](Math['floor'](Math['log'](_0x2d9be7)/Math['LN2']),_0x5490b7),_0x37f2bc=_0x1a77e7+_0x5490b7,_0x46587b=Math['round'](_0x2d9be7*Math['pow'](0x2,_0x41e0bc-_0x1a77e7)-Math['pow'](0x2,_0x41e0bc))):(_0x37f2bc=0x0,_0x46587b=Math['round'](_0x2d9be7/Math['pow'](0x2,0x1-_0x5490b7-_0x41e0bc))));const _0xad0ea7=[];for(_0x271a6a=_0x41e0bc;_0x271a6a;_0x271a6a-=0x1)_0xad0ea7['push'](_0x46587b%0x2?0x1:0x0),_0x46587b=Math['floor'](_0x46587b/0x2);for(_0x271a6a=_0x170681;_0x271a6a;_0x271a6a-=0x1)_0xad0ea7['push'](_0x37f2bc%0x2?0x1:0x0),_0x37f2bc=Math['floor'](_0x37f2bc/0x2);_0xad0ea7['push'](_0x4c293a?0x1:0x0),_0xad0ea7['reverse']();const _0x2ecbfa=_0xad0ea7['join']('');let _0x4c9bbc='';for(_0x271a6a=0x0;_0x271a6a<0x40;_0x271a6a+=0x8){let _0x4b0bfc=parseInt(_0x2ecbfa['substr'](_0x271a6a,0x8),0x2)['toString'](0x10);_0x4b0bfc['length']===0x1&&(_0x4b0bfc='0'+_0x4b0bfc),_0x4c9bbc=_0x4c9bbc+_0x4b0bfc;}return _0x4c9bbc['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x446c5a,_0x1341f5){let _0x3543c9='Unknown\x20Error';_0x446c5a==='too_big'?_0x3543c9='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x446c5a==='permission_denied'?_0x3543c9='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x446c5a==='unavailable'&&(_0x3543c9='The\x20service\x20is\x20unavailable');const _0x2c3f5d=new Error(_0x446c5a+'\x20at\x20'+_0x1341f5['_path']['toString']()+':\x20'+_0x3543c9);return _0x2c3f5d['code']=_0x446c5a['toUpperCase'](),_0x2c3f5d;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x17d91c){if(zl['test'](_0x17d91c)){const _0x30f207=Number(_0x17d91c);if(_0x30f207>=jl&&_0x30f207<=Kl)return _0x30f207;}return null;},lt=function(_0x6e5c15){try{_0x6e5c15();}catch(_0x179a19){setTimeout(()=>{const _0x82ccab=_0x179a19['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x82ccab),_0x179a19;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x57b956,_0x329343){const _0x57a0cf=setTimeout(_0x57b956,_0x329343);return typeof _0x57a0cf=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x57a0cf):typeof _0x57a0cf=='object'&&_0x57a0cf['unref']&&_0x57a0cf['unref'](),_0x57a0cf;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x47db2f,_0x4a38db){this['appCheckProvider']=_0x4a38db,this['appName']=_0x47db2f['name'],H(_0x47db2f)&&_0x47db2f['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x47db2f['settings']['appCheckToken']),this['appCheck']=_0x4a38db==null?void 0x0:_0x4a38db['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4a38db==null||_0x4a38db['get']()['then'](_0x8cf4d5=>this['appCheck']=_0x8cf4d5);}['getToken'](_0x23f5fc){if(this['serverAppAppCheckToken']){if(_0x23f5fc)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x23f5fc):new Promise((_0x29bf0e,_0x425cf6)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x23f5fc)['then'](_0x29bf0e,_0x425cf6):_0x29bf0e(null);},0x0);});}['addTokenChangeListener'](_0x59fae9){var _0x1deac6;(_0x1deac6=this['appCheckProvider'])==null||_0x1deac6['get']()['then'](_0x3bcf94=>_0x3bcf94['addTokenListener'](_0x59fae9));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x7ccc39,_0x2a0e67,_0x233afc){this['appName_']=_0x7ccc39,this['firebaseOptions_']=_0x2a0e67,this['authProvider_']=_0x233afc,this['auth_']=null,this['auth_']=_0x233afc['getImmediate']({'optional':!0x0}),this['auth_']||_0x233afc['onInit'](_0x3452c9=>this['auth_']=_0x3452c9);}['getToken'](_0x94d537){return this['auth_']?this['auth_']['getToken'](_0x94d537)['catch'](_0x5d0a42=>_0x5d0a42&&_0x5d0a42['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5d0a42)):new Promise((_0x2c2db0,_0x1d58bf)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x94d537)['then'](_0x2c2db0,_0x1d58bf):_0x2c2db0(null);},0x0);});}['addTokenChangeListener'](_0x26bfeb){this['auth_']?this['auth_']['addAuthTokenListener'](_0x26bfeb):this['authProvider_']['get']()['then'](_0x43f435=>_0x43f435['addAuthTokenListener'](_0x26bfeb));}['removeTokenChangeListener'](_0x1b8097){this['authProvider_']['get']()['then'](_0x524edc=>_0x524edc['removeAuthTokenListener'](_0x1b8097));}['notifyForInvalidToken'](){let _0x328dee='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x328dee+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x328dee+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x328dee+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x328dee);}}class tn{constructor(_0x54e554){this['accessToken']=_0x54e554;}['getToken'](_0x2db7fc){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2df271){_0x2df271(this['accessToken']);}['removeTokenChangeListener'](_0x4dc8ee){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x1ad833,_0x5e5aac,_0x13480f,_0x3f6ab8,_0x1a90d3=!0x1,_0x324f21='',_0x3c7eea=!0x1,_0x1c9a00=!0x1,_0x12a9e9=null){this['secure']=_0x5e5aac,this['namespace']=_0x13480f,this['webSocketOnly']=_0x3f6ab8,this['nodeAdmin']=_0x1a90d3,this['persistenceKey']=_0x324f21,this['includeNamespaceInQueryParams']=_0x3c7eea,this['isUsingEmulator']=_0x1c9a00,this['emulatorOptions']=_0x12a9e9,this['_host']=_0x1ad833['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x1ad833)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x307fb2){_0x307fb2!==this['internalHost']&&(this['internalHost']=_0x307fb2,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x523c83=this['toURLString']();return this['persistenceKey']&&(_0x523c83+='<'+this['persistenceKey']+'>'),_0x523c83;}['toURLString'](){const _0x19f8f0=this['secure']?'https://':'http://',_0x1564f1=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x19f8f0+this['host']+'/'+_0x1564f1;}}function Xl(_0x147f7f){return _0x147f7f['host']!==_0x147f7f['internalHost']||_0x147f7f['isCustomHost']()||_0x147f7f['includeNamespaceInQueryParams'];}function go(_0x118b98,_0x10234e,_0x42ae84){f(typeof _0x10234e=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x42ae84=='object','typeof\x20params\x20must\x20==\x20object');let _0x17ba20;if(_0x10234e===fo)_0x17ba20=(_0x118b98['secure']?'wss://':'ws://')+_0x118b98['internalHost']+'/.ws?';else{if(_0x10234e===po)_0x17ba20=(_0x118b98['secure']?'https://':'http://')+_0x118b98['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x10234e);}Xl(_0x118b98)&&(_0x42ae84['ns']=_0x118b98['namespace']);const _0x24cdf4=[];return x(_0x42ae84,(_0x5694db,_0x2a14d8)=>{_0x24cdf4['push'](_0x5694db+'='+_0x2a14d8);}),_0x17ba20+_0x24cdf4['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x2e1d1e,_0x3316b1=0x1){Y(this['counters_'],_0x2e1d1e)||(this['counters_'][_0x2e1d1e]=0x0),this['counters_'][_0x2e1d1e]+=_0x3316b1;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x375317){const _0x97d7d3=_0x375317['toString']();return ti[_0x97d7d3]||(ti[_0x97d7d3]=new Zl()),ti[_0x97d7d3];}function eh(_0x1fb5f8,_0x45af19){const _0x5b2635=_0x1fb5f8['toString']();return ni[_0x5b2635]||(ni[_0x5b2635]=_0x45af19()),ni[_0x5b2635];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x4f1a0e){this['onMessage_']=_0x4f1a0e,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x11cbf5,_0x3894f6){this['closeAfterResponse']=_0x11cbf5,this['onClose']=_0x3894f6,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x184d82,_0x1e1172){for(this['pendingResponses'][_0x184d82]=_0x1e1172;this['pendingResponses'][this['currentResponseNum']];){const _0x1acd63=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3c50f3=0x0;_0x3c50f3<_0x1acd63['length'];++_0x3c50f3)_0x1acd63[_0x3c50f3]&&lt(()=>{this['onMessage_'](_0x1acd63[_0x3c50f3]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x2ccf64,_0x79e377,_0x260ea1,_0xa69852,_0x235dbc,_0xb423fb,_0x26f312){this['connId']=_0x2ccf64,this['repoInfo']=_0x79e377,this['applicationId']=_0x260ea1,this['appCheckToken']=_0xa69852,this['authToken']=_0x235dbc,this['transportSessionId']=_0xb423fb,this['lastSessionId']=_0x26f312,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x2ccf64),this['stats_']=Hi(_0x79e377),this['urlFn']=_0x4c37d3=>(this['appCheckToken']&&(_0x4c37d3[yi]=this['appCheckToken']),go(_0x79e377,po,_0x4c37d3));}['open'](_0x3a9e1d,_0x2313c5){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2313c5,this['myPacketOrderer']=new th(_0x3a9e1d),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x6f1eb8)=>{const [_0x4b9bd0,_0x2f1a73,_0x47225c,_0x38035d,_0x58a98c]=_0x6f1eb8;if(this['incrementIncomingBytes_'](_0x6f1eb8),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4b9bd0===$s)this['id']=_0x2f1a73,this['password']=_0x47225c;else{if(_0x4b9bd0===nh)_0x2f1a73?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2f1a73,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4b9bd0);}}},(..._0x18ceb9)=>{const [_0x3c6f42,_0x529aa3]=_0x18ceb9;this['incrementIncomingBytes_'](_0x18ceb9),this['myPacketOrderer']['handleResponse'](_0x3c6f42,_0x529aa3);},()=>{this['onClosed_']();},this['urlFn']);const _0x484fed={};_0x484fed[$s]='t',_0x484fed[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x484fed[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x484fed[ro]=Vi,this['transportSessionId']&&(_0x484fed[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x484fed[ho]=this['lastSessionId']),this['applicationId']&&(_0x484fed[uo]=this['applicationId']),this['appCheckToken']&&(_0x484fed[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x484fed[ao]=co);const _0x351280=this['urlFn'](_0x484fed);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x351280),this['scriptTagHolder']['addTag'](_0x351280,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x3f9b54){const _0x428b98=O(_0x3f9b54);this['bytesSent']+=_0x428b98['length'],this['stats_']['incrementCounter']('bytes_sent',_0x428b98['length']);const _0x16af5c=Br(_0x428b98),_0x1a3402=io(_0x16af5c,hh);for(let _0x2dba29=0x0;_0x2dba29<_0x1a3402['length'];_0x2dba29++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1a3402['length'],_0x1a3402[_0x2dba29]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x260923,_0x3ae2fd){this['myDisconnFrame']=document['createElement']('iframe');const _0x64d30={};_0x64d30[lh]='t',_0x64d30[mo]=_0x260923,_0x64d30[yo]=_0x3ae2fd,this['myDisconnFrame']['src']=this['urlFn'](_0x64d30),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xe10b23){const _0x2172ba=O(_0xe10b23)['length'];this['bytesReceived']+=_0x2172ba,this['stats_']['incrementCounter']('bytes_received',_0x2172ba);}}class $i{constructor(_0x24b49c,_0x105092,_0x4d083f,_0x146615){this['onDisconnect']=_0x4d083f,this['urlFn']=_0x146615,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x24b49c,window[sh+this['uniqueCallbackIdentifier']]=_0x105092,this['myIFrame']=$i['createIFrame_']();let _0x250114='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x250114='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3589d6='<html><body>'+_0x250114+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3589d6),this['myIFrame']['doc']['close']();}catch(_0x1a4f52){L('frame\x20writing\x20exception'),_0x1a4f52['stack']&&L(_0x1a4f52['stack']),L(_0x1a4f52);}}}static['createIFrame_'](){const _0x2441f7=document['createElement']('iframe');if(_0x2441f7['style']['display']='none',document['body']){document['body']['appendChild'](_0x2441f7);try{_0x2441f7['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1ad5e6=document['domain'];_0x2441f7['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1ad5e6+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2441f7['contentDocument']?_0x2441f7['doc']=_0x2441f7['contentDocument']:_0x2441f7['contentWindow']?_0x2441f7['doc']=_0x2441f7['contentWindow']['document']:_0x2441f7['document']&&(_0x2441f7['doc']=_0x2441f7['document']),_0x2441f7;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x2ed5de=this['onDisconnect'];_0x2ed5de&&(this['onDisconnect']=null,_0x2ed5de());}['startLongPoll'](_0x5a7cd1,_0x29b6fe){for(this['myID']=_0x5a7cd1,this['myPW']=_0x29b6fe,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x169069={};_0x169069[mo]=this['myID'],_0x169069[yo]=this['myPW'],_0x169069[vo]=this['currentSerial'];let _0x2f7555=this['urlFn'](_0x169069),_0x273758='',_0x3dc05f=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x273758['length']<=Eo;){const _0xdaac97=this['pendingSegs']['shift']();_0x273758=_0x273758+'&'+oh+_0x3dc05f+'='+_0xdaac97['seg']+'&'+ah+_0x3dc05f+'='+_0xdaac97['ts']+'&'+ch+_0x3dc05f+'='+_0xdaac97['d'],_0x3dc05f++;}return _0x2f7555=_0x2f7555+_0x273758,this['addLongPollTag_'](_0x2f7555,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x214027,_0x481fad,_0x3b5c72){this['pendingSegs']['push']({'seg':_0x214027,'ts':_0x481fad,'d':_0x3b5c72}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x95951a,_0x4bbe91){this['outstandingRequests']['add'](_0x4bbe91);const _0x955b5e=()=>{this['outstandingRequests']['delete'](_0x4bbe91),this['newRequest_']();},_0x5c5cfb=setTimeout(_0x955b5e,Math['floor'](uh)),_0x57df16=()=>{clearTimeout(_0x5c5cfb),_0x955b5e();};this['addTag'](_0x95951a,_0x57df16);}['addTag'](_0x592695,_0x1c3f97){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x718965=this['myIFrame']['doc']['createElement']('script');_0x718965['type']='text/javascript',_0x718965['async']=!0x0,_0x718965['src']=_0x592695,_0x718965['onload']=_0x718965['onreadystatechange']=function(){const _0x44396e=_0x718965['readyState'];(!_0x44396e||_0x44396e==='loaded'||_0x44396e==='complete')&&(_0x718965['onload']=_0x718965['onreadystatechange']=null,_0x718965['parentNode']&&_0x718965['parentNode']['removeChild'](_0x718965),_0x1c3f97());},_0x718965['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x592695),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x718965);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x26ff2d,_0x2b589f,_0x59a0f3,_0x45344c,_0x2df96f,_0x4a27a3,_0x26e18f){this['connId']=_0x26ff2d,this['applicationId']=_0x59a0f3,this['appCheckToken']=_0x45344c,this['authToken']=_0x2df96f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x2b589f),this['connURL']=G['connectionURL_'](_0x2b589f,_0x4a27a3,_0x26e18f,_0x45344c,_0x59a0f3),this['nodeAdmin']=_0x2b589f['nodeAdmin'];}static['connectionURL_'](_0x314ae8,_0x2ba1e3,_0x4d6992,_0x1dab71,_0x3c06d6){const _0x3680ca={};return _0x3680ca[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3680ca[ao]=co),_0x2ba1e3&&(_0x3680ca[oo]=_0x2ba1e3),_0x4d6992&&(_0x3680ca[ho]=_0x4d6992),_0x1dab71&&(_0x3680ca[yi]=_0x1dab71),_0x3c06d6&&(_0x3680ca[uo]=_0x3c06d6),go(_0x314ae8,fo,_0x3680ca);}['open'](_0x49239f,_0x46af37){this['onDisconnect']=_0x46af37,this['onMessage']=_0x49239f,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x5ec16e;dc(),this['mySock']=new hn(this['connURL'],[],_0x5ec16e);}catch(_0x231e9e){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2b3ef9=_0x231e9e['message']||_0x231e9e['data'];_0x2b3ef9&&this['log_'](_0x2b3ef9),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xbea213=>{this['handleIncomingFrame'](_0xbea213);},this['mySock']['onerror']=_0x546903=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x9ee095=_0x546903['message']||_0x546903['data'];_0x9ee095&&this['log_'](_0x9ee095),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x30102f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4b9873=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x53346a=navigator['userAgent']['match'](_0x4b9873);_0x53346a&&_0x53346a['length']>0x1&&parseFloat(_0x53346a[0x1])<4.4&&(_0x30102f=!0x0);}return!_0x30102f&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x39c1ac){if(this['frames']['push'](_0x39c1ac),this['frames']['length']===this['totalFrames']){const _0x3d5263=this['frames']['join']('');this['frames']=null;const _0x21a995=bt(_0x3d5263);this['onMessage'](_0x21a995);}}['handleNewFrameCount_'](_0x8fdd7){this['totalFrames']=_0x8fdd7,this['frames']=[];}['extractFrameCount_'](_0x5b2c76){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x5b2c76['length']<=0x6){const _0x5eb798=Number(_0x5b2c76);if(!isNaN(_0x5eb798))return this['handleNewFrameCount_'](_0x5eb798),null;}return this['handleNewFrameCount_'](0x1),_0x5b2c76;}['handleIncomingFrame'](_0xd20102){if(this['mySock']===null)return;const _0xcc2fe4=_0xd20102['data'];if(this['bytesReceived']+=_0xcc2fe4['length'],this['stats_']['incrementCounter']('bytes_received',_0xcc2fe4['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0xcc2fe4);else{const _0x501b98=this['extractFrameCount_'](_0xcc2fe4);_0x501b98!==null&&this['appendFrame_'](_0x501b98);}}['send'](_0x5c5bea){this['resetKeepAlive']();const _0x1fbb3b=O(_0x5c5bea);this['bytesSent']+=_0x1fbb3b['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1fbb3b['length']);const _0x122283=io(_0x1fbb3b,fh);_0x122283['length']>0x1&&this['sendString_'](String(_0x122283['length']));for(let _0x439780=0x0;_0x439780<_0x122283['length'];_0x439780++)this['sendString_'](_0x122283[_0x439780]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x58219c){try{this['mySock']['send'](_0x58219c);}catch(_0x514003){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x514003['message']||_0x514003['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x29657f){this['initTransports_'](_0x29657f);}['initTransports_'](_0x3890c6){const _0x2be678=G&&G['isAvailable']();let _0x344ab7=_0x2be678&&!G['previouslyFailed']();if(_0x3890c6['webSocketOnly']&&(_0x2be678||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x344ab7=!0x0),_0x344ab7)this['transports_']=[G];else{const _0x1b1b6e=this['transports_']=[];for(const _0x56a0d6 of At['ALL_TRANSPORTS'])_0x56a0d6&&_0x56a0d6['isAvailable']()&&_0x1b1b6e['push'](_0x56a0d6);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x46a683,_0x46f557,_0x4c9306,_0x5d331e,_0x210f01,_0xd8d27,_0x5d1bae,_0x2e7ffb,_0x15738f,_0x278df9){this['id']=_0x46a683,this['repoInfo_']=_0x46f557,this['applicationId_']=_0x4c9306,this['appCheckToken_']=_0x5d331e,this['authToken_']=_0x210f01,this['onMessage_']=_0xd8d27,this['onReady_']=_0x5d1bae,this['onDisconnect_']=_0x2e7ffb,this['onKill_']=_0x15738f,this['lastSessionId']=_0x278df9,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x46f557),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2be2d5=this['transportManager_']['initialTransport']();this['conn_']=new _0x2be2d5(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2be2d5['responsesRequiredToBeHealthy']||0x0;const _0x3a3ad5=this['connReceiver_'](this['conn_']),_0x279abd=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3a3ad5,_0x279abd);},Math['floor'](0x0));const _0x206e7a=_0x2be2d5['healthyTimeout']||0x0;_0x206e7a>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x206e7a)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4194f9){return _0x2fe92f=>{_0x4194f9===this['conn_']?this['onConnectionLost_'](_0x2fe92f):_0x4194f9===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2ad9bc){return _0x458ac=>{this['state_']!==0x2&&(_0x2ad9bc===this['rx_']?this['onPrimaryMessageReceived_'](_0x458ac):_0x2ad9bc===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x458ac):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x25931e){const _0x288a7a={'t':'d','d':_0x25931e};this['sendData_'](_0x288a7a);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x163842){if(ii in _0x163842){const _0x4f0433=_0x163842[ii];_0x4f0433===js?this['upgradeIfSecondaryHealthy_']():_0x4f0433===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4f0433===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x238d2e){const _0xcdfc76=pt('t',_0x238d2e),_0xb2464e=pt('d',_0x238d2e);if(_0xcdfc76==='c')this['onSecondaryControl_'](_0xb2464e);else{if(_0xcdfc76==='d')this['pendingDataMessages']['push'](_0xb2464e);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0xcdfc76);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x525428){const _0x3ce46a=pt('t',_0x525428),_0x477427=pt('d',_0x525428);_0x3ce46a==='c'?this['onControl_'](_0x477427):_0x3ce46a==='d'&&this['onDataMessage_'](_0x477427);}['onDataMessage_'](_0x5bd402){this['onPrimaryResponse_'](),this['onMessage_'](_0x5bd402);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x393723){const _0x582246=pt(ii,_0x393723);if(Gs in _0x393723){const _0x17e4fb=_0x393723[Gs];if(_0x582246===Ih){const _0xee2eac={..._0x17e4fb};this['repoInfo_']['isUsingEmulator']&&(_0xee2eac['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xee2eac);}else{if(_0x582246===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x16d50b=0x0;_0x16d50b<this['pendingDataMessages']['length'];++_0x16d50b)this['onDataMessage_'](this['pendingDataMessages'][_0x16d50b]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x582246===vh?this['onConnectionShutdown_'](_0x17e4fb):_0x582246===qs?this['onReset_'](_0x17e4fb):_0x582246===Eh?mi('Server\x20Error:\x20'+_0x17e4fb):_0x582246===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x582246);}}}['onHandshake_'](_0x21749c){const _0xeba089=_0x21749c['ts'],_0x5ec4bb=_0x21749c['v'],_0x133b1d=_0x21749c['h'];this['sessionId']=_0x21749c['s'],this['repoInfo_']['host']=_0x133b1d,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xeba089),Vi!==_0x5ec4bb&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x727483=this['transportManager_']['upgradeTransport']();_0x727483&&this['startUpgrade_'](_0x727483);}['startUpgrade_'](_0x260bad){this['secondaryConn_']=new _0x260bad(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x260bad['responsesRequiredToBeHealthy']||0x0;const _0x59c578=this['connReceiver_'](this['secondaryConn_']),_0x28f31c=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x59c578,_0x28f31c),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x346d43){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x346d43),this['repoInfo_']['host']=_0x346d43,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x2a88be,_0x2f7f96){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x2a88be,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2f7f96,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4395d7=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4395d7||this['rx_']===_0x4395d7)&&this['close']();}['onConnectionLost_'](_0x1037f6){this['conn_']=null,!_0x1037f6&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4d0744){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4d0744),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5301d7){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5301d7);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x410bc,_0xc6d66c,_0x175492,_0x27ba39){}['merge'](_0x259788,_0x5a078c,_0x340d13,_0x263fa0){}['refreshAuthToken'](_0x34a286){}['refreshAppCheckToken'](_0x522111){}['onDisconnectPut'](_0x2c04e1,_0x1dd796,_0x2d686f){}['onDisconnectMerge'](_0x3bb071,_0xd8f05e,_0x1ff3e6){}['onDisconnectCancel'](_0x434d8c,_0x31fce2){}['reportStats'](_0x2a1e1a){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x385cf7){this['allowedEvents_']=_0x385cf7,this['listeners_']={},f(Array['isArray'](_0x385cf7)&&_0x385cf7['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x9ac931,..._0x100ecc){if(Array['isArray'](this['listeners_'][_0x9ac931])){const _0x3d5a27=[...this['listeners_'][_0x9ac931]];for(let _0x4ebef3=0x0;_0x4ebef3<_0x3d5a27['length'];_0x4ebef3++)_0x3d5a27[_0x4ebef3]['callback']['apply'](_0x3d5a27[_0x4ebef3]['context'],_0x100ecc);}}['on'](_0x2843e0,_0x18c66b,_0x56876b){this['validateEventType_'](_0x2843e0),this['listeners_'][_0x2843e0]=this['listeners_'][_0x2843e0]||[],this['listeners_'][_0x2843e0]['push']({'callback':_0x18c66b,'context':_0x56876b});const _0x525fb5=this['getInitialEvent'](_0x2843e0);_0x525fb5&&_0x18c66b['apply'](_0x56876b,_0x525fb5);}['off'](_0x5a3e61,_0x2db11c,_0x5700e8){this['validateEventType_'](_0x5a3e61);const _0x22c019=this['listeners_'][_0x5a3e61]||[];for(let _0x807592=0x0;_0x807592<_0x22c019['length'];_0x807592++)if(_0x22c019[_0x807592]['callback']===_0x2db11c&&(!_0x5700e8||_0x5700e8===_0x22c019[_0x807592]['context'])){_0x22c019['splice'](_0x807592,0x1);return;}}['validateEventType_'](_0x383167){f(this['allowedEvents_']['find'](_0x50692a=>_0x50692a===_0x383167),'Unknown\x20event:\x20'+_0x383167);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x48cb83){return f(_0x48cb83==='online','Unknown\x20event\x20type:\x20'+_0x48cb83),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0xc4a6f2,_0x16b264){if(_0x16b264===void 0x0){this['pieces_']=_0xc4a6f2['split']('/');let _0x57f917=0x0;for(let _0x333260=0x0;_0x333260<this['pieces_']['length'];_0x333260++)this['pieces_'][_0x333260]['length']>0x0&&(this['pieces_'][_0x57f917]=this['pieces_'][_0x333260],_0x57f917++);this['pieces_']['length']=_0x57f917,this['pieceNum_']=0x0;}else this['pieces_']=_0xc4a6f2,this['pieceNum_']=_0x16b264;}['toString'](){let _0x1f7f5b='';for(let _0x33c5e6=this['pieceNum_'];_0x33c5e6<this['pieces_']['length'];_0x33c5e6++)this['pieces_'][_0x33c5e6]!==''&&(_0x1f7f5b+='/'+this['pieces_'][_0x33c5e6]);return _0x1f7f5b||'/';}}function w(){return new C('');}function y(_0x41ced3){return _0x41ced3['pieceNum_']>=_0x41ced3['pieces_']['length']?null:_0x41ced3['pieces_'][_0x41ced3['pieceNum_']];}function we(_0x299b82){return _0x299b82['pieces_']['length']-_0x299b82['pieceNum_'];}function b(_0x595c19){let _0x20863b=_0x595c19['pieceNum_'];return _0x20863b<_0x595c19['pieces_']['length']&&_0x20863b++,new C(_0x595c19['pieces_'],_0x20863b);}function Gi(_0xd87e43){return _0xd87e43['pieceNum_']<_0xd87e43['pieces_']['length']?_0xd87e43['pieces_'][_0xd87e43['pieces_']['length']-0x1]:null;}function Ch(_0x443503){let _0x3e1533='';for(let _0x456e6a=_0x443503['pieceNum_'];_0x456e6a<_0x443503['pieces_']['length'];_0x456e6a++)_0x443503['pieces_'][_0x456e6a]!==''&&(_0x3e1533+='/'+encodeURIComponent(String(_0x443503['pieces_'][_0x456e6a])));return _0x3e1533||'/';}function kt(_0x46654f,_0x2ee182=0x0){return _0x46654f['pieces_']['slice'](_0x46654f['pieceNum_']+_0x2ee182);}function To(_0x1488d8){if(_0x1488d8['pieceNum_']>=_0x1488d8['pieces_']['length'])return null;const _0x3402fc=[];for(let _0x5262b1=_0x1488d8['pieceNum_'];_0x5262b1<_0x1488d8['pieces_']['length']-0x1;_0x5262b1++)_0x3402fc['push'](_0x1488d8['pieces_'][_0x5262b1]);return new C(_0x3402fc,0x0);}function A(_0x52b10e,_0x578383){const _0x6d1a2d=[];for(let _0x5a07dd=_0x52b10e['pieceNum_'];_0x5a07dd<_0x52b10e['pieces_']['length'];_0x5a07dd++)_0x6d1a2d['push'](_0x52b10e['pieces_'][_0x5a07dd]);if(_0x578383 instanceof C){for(let _0x1fedd9=_0x578383['pieceNum_'];_0x1fedd9<_0x578383['pieces_']['length'];_0x1fedd9++)_0x6d1a2d['push'](_0x578383['pieces_'][_0x1fedd9]);}else{const _0xed2ddb=_0x578383['split']('/');for(let _0x29009b=0x0;_0x29009b<_0xed2ddb['length'];_0x29009b++)_0xed2ddb[_0x29009b]['length']>0x0&&_0x6d1a2d['push'](_0xed2ddb[_0x29009b]);}return new C(_0x6d1a2d,0x0);}function v(_0x4da551){return _0x4da551['pieceNum_']>=_0x4da551['pieces_']['length'];}function F(_0x2199d5,_0x24f21f){const _0x3c1178=y(_0x2199d5),_0x45c9e7=y(_0x24f21f);if(_0x3c1178===null)return _0x24f21f;if(_0x3c1178===_0x45c9e7)return F(b(_0x2199d5),b(_0x24f21f));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x24f21f+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2199d5+')');}function Th(_0x21e1db,_0x2005b4){const _0x4c0b31=kt(_0x21e1db,0x0),_0xddc8a4=kt(_0x2005b4,0x0);for(let _0xcd0267=0x0;_0xcd0267<_0x4c0b31['length']&&_0xcd0267<_0xddc8a4['length'];_0xcd0267++){const _0x1b5574=He(_0x4c0b31[_0xcd0267],_0xddc8a4[_0xcd0267]);if(_0x1b5574!==0x0)return _0x1b5574;}return _0x4c0b31['length']===_0xddc8a4['length']?0x0:_0x4c0b31['length']<_0xddc8a4['length']?-0x1:0x1;}function qi(_0x3084bb,_0x2b0a4c){if(we(_0x3084bb)!==we(_0x2b0a4c))return!0x1;for(let _0x340fa4=_0x3084bb['pieceNum_'],_0x4ea390=_0x2b0a4c['pieceNum_'];_0x340fa4<=_0x3084bb['pieces_']['length'];_0x340fa4++,_0x4ea390++)if(_0x3084bb['pieces_'][_0x340fa4]!==_0x2b0a4c['pieces_'][_0x4ea390])return!0x1;return!0x0;}function $(_0x40302c,_0x59b515){let _0x184835=_0x40302c['pieceNum_'],_0x3fd305=_0x59b515['pieceNum_'];if(we(_0x40302c)>we(_0x59b515))return!0x1;for(;_0x184835<_0x40302c['pieces_']['length'];){if(_0x40302c['pieces_'][_0x184835]!==_0x59b515['pieces_'][_0x3fd305])return!0x1;++_0x184835,++_0x3fd305;}return!0x0;}class Sh{constructor(_0x33674f,_0x1a91d1){this['errorPrefix_']=_0x1a91d1,this['parts_']=kt(_0x33674f,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x108101=0x0;_0x108101<this['parts_']['length'];_0x108101++)this['byteLength_']+=Pn(this['parts_'][_0x108101]);So(this);}}function bh(_0x5a4ef4,_0x2a6aca){_0x5a4ef4['parts_']['length']>0x0&&(_0x5a4ef4['byteLength_']+=0x1),_0x5a4ef4['parts_']['push'](_0x2a6aca),_0x5a4ef4['byteLength_']+=Pn(_0x2a6aca),So(_0x5a4ef4);}function Rh(_0x583727){const _0x4f760d=_0x583727['parts_']['pop']();_0x583727['byteLength_']-=Pn(_0x4f760d),_0x583727['parts_']['length']>0x0&&(_0x583727['byteLength_']-=0x1);}function So(_0x337807){if(_0x337807['byteLength_']>Js)throw new Error(_0x337807['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x337807['byteLength_']+').');if(_0x337807['parts_']['length']>Qs)throw new Error(_0x337807['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x337807));}function Ne(_0xa5da95){return _0xa5da95['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0xa5da95['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x153726,_0x5ff899;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5ff899='visibilitychange',_0x153726='hidden'):typeof document['mozHidden']<'u'?(_0x5ff899='mozvisibilitychange',_0x153726='mozHidden'):typeof document['msHidden']<'u'?(_0x5ff899='msvisibilitychange',_0x153726='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5ff899='webkitvisibilitychange',_0x153726='webkitHidden')),this['visible_']=!0x0,_0x5ff899&&document['addEventListener'](_0x5ff899,()=>{const _0x4265de=!document[_0x153726];_0x4265de!==this['visible_']&&(this['visible_']=_0x4265de,this['trigger']('visible',_0x4265de));},!0x1);}['getInitialEvent'](_0x2cf1ae){return f(_0x2cf1ae==='visible','Unknown\x20event\x20type:\x20'+_0x2cf1ae),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0xd0c8c7,_0x967a5f,_0x257281,_0x1648b1,_0x204ec5,_0x5ae7ed,_0x2ed6d8,_0x4f3aac){if(super(),this['repoInfo_']=_0xd0c8c7,this['applicationId_']=_0x967a5f,this['onDataUpdate_']=_0x257281,this['onConnectStatus_']=_0x1648b1,this['onServerInfoUpdate_']=_0x204ec5,this['authTokenProvider_']=_0x5ae7ed,this['appCheckTokenProvider_']=_0x2ed6d8,this['authOverride_']=_0x4f3aac,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4f3aac)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0xd0c8c7['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x72a68,_0x35379f,_0x23d5d8){const _0x11a5a1=++this['requestNumber_'],_0x5e42a6={'r':_0x11a5a1,'a':_0x72a68,'b':_0x35379f};this['log_'](O(_0x5e42a6)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5e42a6),_0x23d5d8&&(this['requestCBHash_'][_0x11a5a1]=_0x23d5d8);}['get'](_0x51a95d){this['initConnection_']();const _0x1d66a9=new Ve(),_0x4194c3={'action':'g','request':{'p':_0x51a95d['_path']['toString'](),'q':_0x51a95d['_queryObject']},'onComplete':_0x4d7c2d=>{const _0x2d26c4=_0x4d7c2d['d'];_0x4d7c2d['s']==='ok'?_0x1d66a9['resolve'](_0x2d26c4):_0x1d66a9['reject'](_0x2d26c4);}};this['outstandingGets_']['push'](_0x4194c3),this['outstandingGetCount_']++;const _0x195b55=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x195b55),_0x1d66a9['promise'];}['listen'](_0x434f77,_0x43a7c4,_0x3c4fc0,_0x181d9b){this['initConnection_']();const _0x2dcce6=_0x434f77['_queryIdentifier'],_0x2e2c94=_0x434f77['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2e2c94+'\x20'+_0x2dcce6),this['listens']['has'](_0x2e2c94)||this['listens']['set'](_0x2e2c94,new Map()),f(_0x434f77['_queryParams']['isDefault']()||!_0x434f77['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2e2c94)['has'](_0x2dcce6),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1244b7={'onComplete':_0x181d9b,'hashFn':_0x43a7c4,'query':_0x434f77,'tag':_0x3c4fc0};this['listens']['get'](_0x2e2c94)['set'](_0x2dcce6,_0x1244b7),this['connected_']&&this['sendListen_'](_0x1244b7);}['sendGet_'](_0x3e8a6c){const _0x30e5ce=this['outstandingGets_'][_0x3e8a6c];this['sendRequest']('g',_0x30e5ce['request'],_0x596b26=>{delete this['outstandingGets_'][_0x3e8a6c],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x30e5ce['onComplete']&&_0x30e5ce['onComplete'](_0x596b26);});}['sendListen_'](_0x455c4d){const _0x39d224=_0x455c4d['query'],_0x233132=_0x39d224['_path']['toString'](),_0x2d87dd=_0x39d224['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x233132+'\x20for\x20'+_0x2d87dd);const _0x37c8cc={'p':_0x233132},_0xb55f9e='q';_0x455c4d['tag']&&(_0x37c8cc['q']=_0x39d224['_queryObject'],_0x37c8cc['t']=_0x455c4d['tag']),_0x37c8cc['h']=_0x455c4d['hashFn'](),this['sendRequest'](_0xb55f9e,_0x37c8cc,_0x589695=>{const _0x2ab18b=_0x589695['d'],_0x2ae496=_0x589695['s'];ie['warnOnListenWarnings_'](_0x2ab18b,_0x39d224),(this['listens']['get'](_0x233132)&&this['listens']['get'](_0x233132)['get'](_0x2d87dd))===_0x455c4d&&(this['log_']('listen\x20response',_0x589695),_0x2ae496!=='ok'&&this['removeListen_'](_0x233132,_0x2d87dd),_0x455c4d['onComplete']&&_0x455c4d['onComplete'](_0x2ae496,_0x2ab18b));});}static['warnOnListenWarnings_'](_0x2732d7,_0x3a0ba5){if(_0x2732d7&&typeof _0x2732d7=='object'&&Y(_0x2732d7,'w')){const _0x1973c2=Oe(_0x2732d7,'w');if(Array['isArray'](_0x1973c2)&&~_0x1973c2['indexOf']('no_index')){const _0x30ef69='\x22.indexOn\x22:\x20\x22'+_0x3a0ba5['_queryParams']['getIndex']()['toString']()+'\x22',_0x55bb97=_0x3a0ba5['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x30ef69+'\x20at\x20'+_0x55bb97+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1d5c7d){this['authToken_']=_0x1d5c7d,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1d5c7d);}['reduceReconnectDelayIfAdminCredential_'](_0x53d5bc){(_0x53d5bc&&_0x53d5bc['length']===0x28||vc(_0x53d5bc))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x264f57){this['appCheckToken_']=_0x264f57,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x1b8779=this['authToken_'],_0xbe8d00=yc(_0x1b8779)?'auth':'gauth',_0x312f88={'cred':_0x1b8779};this['authOverride_']===null?_0x312f88['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x312f88['authvar']=this['authOverride_']),this['sendRequest'](_0xbe8d00,_0x312f88,_0x4d2ceb=>{const _0x475362=_0x4d2ceb['s'],_0x2828e8=_0x4d2ceb['d']||'error';this['authToken_']===_0x1b8779&&(_0x475362==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x475362,_0x2828e8));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x29656f=>{const _0x27e4da=_0x29656f['s'],_0x4d21e6=_0x29656f['d']||'error';_0x27e4da==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x27e4da,_0x4d21e6);});}['unlisten'](_0x3596ad,_0x4b7d1e){const _0x18e18b=_0x3596ad['_path']['toString'](),_0x17de7b=_0x3596ad['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x18e18b+'\x20'+_0x17de7b),f(_0x3596ad['_queryParams']['isDefault']()||!_0x3596ad['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x18e18b,_0x17de7b)&&this['connected_']&&this['sendUnlisten_'](_0x18e18b,_0x17de7b,_0x3596ad['_queryObject'],_0x4b7d1e);}['sendUnlisten_'](_0x13ef03,_0x1c6525,_0x2c10f6,_0x477527){this['log_']('Unlisten\x20on\x20'+_0x13ef03+'\x20for\x20'+_0x1c6525);const _0x562144={'p':_0x13ef03},_0x48000e='n';_0x477527&&(_0x562144['q']=_0x2c10f6,_0x562144['t']=_0x477527),this['sendRequest'](_0x48000e,_0x562144);}['onDisconnectPut'](_0x1c3a40,_0x1abfc8,_0x1b6b4f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1c3a40,_0x1abfc8,_0x1b6b4f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1c3a40,'action':'o','data':_0x1abfc8,'onComplete':_0x1b6b4f});}['onDisconnectMerge'](_0x488298,_0x11b23b,_0x40a36c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x488298,_0x11b23b,_0x40a36c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x488298,'action':'om','data':_0x11b23b,'onComplete':_0x40a36c});}['onDisconnectCancel'](_0x3f1a06,_0x1024a9){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3f1a06,null,_0x1024a9):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3f1a06,'action':'oc','data':null,'onComplete':_0x1024a9});}['sendOnDisconnect_'](_0x462982,_0x209cdf,_0x229742,_0x2cc068){const _0x2d2849={'p':_0x209cdf,'d':_0x229742};this['log_']('onDisconnect\x20'+_0x462982,_0x2d2849),this['sendRequest'](_0x462982,_0x2d2849,_0x267296=>{_0x2cc068&&setTimeout(()=>{_0x2cc068(_0x267296['s'],_0x267296['d']);},Math['floor'](0x0));});}['put'](_0x27b188,_0x38d6df,_0x5b84d0,_0x2d0ff6){this['putInternal']('p',_0x27b188,_0x38d6df,_0x5b84d0,_0x2d0ff6);}['merge'](_0x24f7b1,_0x4e6feb,_0x2f548b,_0x2bd8cf){this['putInternal']('m',_0x24f7b1,_0x4e6feb,_0x2f548b,_0x2bd8cf);}['putInternal'](_0xddd59f,_0x4fbbfe,_0x2219db,_0x14fe48,_0x30b803){this['initConnection_']();const _0x435b88={'p':_0x4fbbfe,'d':_0x2219db};_0x30b803!==void 0x0&&(_0x435b88['h']=_0x30b803),this['outstandingPuts_']['push']({'action':_0xddd59f,'request':_0x435b88,'onComplete':_0x14fe48}),this['outstandingPutCount_']++;const _0x33f935=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x33f935):this['log_']('Buffering\x20put:\x20'+_0x4fbbfe);}['sendPut_'](_0x4fcf41){const _0x2e771b=this['outstandingPuts_'][_0x4fcf41]['action'],_0x18034a=this['outstandingPuts_'][_0x4fcf41]['request'],_0x32471d=this['outstandingPuts_'][_0x4fcf41]['onComplete'];this['outstandingPuts_'][_0x4fcf41]['queued']=this['connected_'],this['sendRequest'](_0x2e771b,_0x18034a,_0x23e931=>{this['log_'](_0x2e771b+'\x20response',_0x23e931),delete this['outstandingPuts_'][_0x4fcf41],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x32471d&&_0x32471d(_0x23e931['s'],_0x23e931['d']);});}['reportStats'](_0x5ea201){if(this['connected_']){const _0x4428f0={'c':_0x5ea201};this['log_']('reportStats',_0x4428f0),this['sendRequest']('s',_0x4428f0,_0x38de72=>{if(_0x38de72['s']!=='ok'){const _0x345ccf=_0x38de72['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x345ccf);}});}}['onDataMessage_'](_0x5e671a){if('r'in _0x5e671a){this['log_']('from\x20server:\x20'+O(_0x5e671a));const _0x1225a9=_0x5e671a['r'],_0x1ad709=this['requestCBHash_'][_0x1225a9];_0x1ad709&&(delete this['requestCBHash_'][_0x1225a9],_0x1ad709(_0x5e671a['b']));}else{if('error'in _0x5e671a)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5e671a['error'];'a'in _0x5e671a&&this['onDataPush_'](_0x5e671a['a'],_0x5e671a['b']);}}['onDataPush_'](_0x1b23dc,_0x22cece){this['log_']('handleServerMessage',_0x1b23dc,_0x22cece),_0x1b23dc==='d'?this['onDataUpdate_'](_0x22cece['p'],_0x22cece['d'],!0x1,_0x22cece['t']):_0x1b23dc==='m'?this['onDataUpdate_'](_0x22cece['p'],_0x22cece['d'],!0x0,_0x22cece['t']):_0x1b23dc==='c'?this['onListenRevoked_'](_0x22cece['p'],_0x22cece['q']):_0x1b23dc==='ac'?this['onAuthRevoked_'](_0x22cece['s'],_0x22cece['d']):_0x1b23dc==='apc'?this['onAppCheckRevoked_'](_0x22cece['s'],_0x22cece['d']):_0x1b23dc==='sd'?this['onSecurityDebugPacket_'](_0x22cece):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x1b23dc)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4c959b,_0x18fa4c){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4c959b),this['lastSessionId']=_0x18fa4c,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x511d71){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x511d71));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5d528a){_0x5d528a&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5d528a;}['onOnline_'](_0x450a4a){_0x450a4a?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x57b7b9=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x1de32e=Math['max'](0x0,this['reconnectDelay_']-_0x57b7b9);_0x1de32e=Math['random']()*_0x1de32e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x1de32e+'ms'),this['scheduleConnect_'](_0x1de32e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x184dbd=this['onDataMessage_']['bind'](this),_0x2f69a1=this['onReady_']['bind'](this),_0x390e44=this['onRealtimeDisconnect_']['bind'](this),_0x333d28=this['id']+':'+ie['nextConnectionId_']++,_0x35ff33=this['lastSessionId'];let _0x5c027c=!0x1,_0x3c2001=null;const _0x233f22=function(){_0x3c2001?_0x3c2001['close']():(_0x5c027c=!0x0,_0x390e44());},_0x3a2f35=function(_0x2910a8){f(_0x3c2001,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3c2001['sendRequest'](_0x2910a8);};this['realtime_']={'close':_0x233f22,'sendRequest':_0x3a2f35};const _0x640738=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x26f938,_0x18515d]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x640738),this['appCheckTokenProvider_']['getToken'](_0x640738)]);_0x5c027c?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x26f938&&_0x26f938['accessToken'],this['appCheckToken_']=_0x18515d&&_0x18515d['token'],_0x3c2001=new wh(_0x333d28,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x184dbd,_0x2f69a1,_0x390e44,_0x511fa2=>{U(_0x511fa2+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x35ff33));}catch(_0x22a373){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x22a373),_0x5c027c||(this['repoInfo_']['nodeAdmin']&&U(_0x22a373),_0x233f22());}}}['interrupt'](_0x5a468e){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x5a468e),this['interruptReasons_'][_0x5a468e]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x3348b6){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x3348b6),delete this['interruptReasons_'][_0x3348b6],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x584e1f){const _0x45cc35=_0x584e1f-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x45cc35});}['cancelSentTransactions_'](){for(let _0x12d5a7=0x0;_0x12d5a7<this['outstandingPuts_']['length'];_0x12d5a7++){const _0x4af1f2=this['outstandingPuts_'][_0x12d5a7];_0x4af1f2&&'h'in _0x4af1f2['request']&&_0x4af1f2['queued']&&(_0x4af1f2['onComplete']&&_0x4af1f2['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x12d5a7],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x10c819,_0x2a50a5){let _0x1d0e30;_0x2a50a5?_0x1d0e30=_0x2a50a5['map'](_0x10da07=>Bi(_0x10da07))['join']('$'):_0x1d0e30='default';const _0x276b56=this['removeListen_'](_0x10c819,_0x1d0e30);_0x276b56&&_0x276b56['onComplete']&&_0x276b56['onComplete']('permission_denied');}['removeListen_'](_0x2b03a8,_0x286970){const _0x562721=new C(_0x2b03a8)['toString']();let _0x5fba0a;if(this['listens']['has'](_0x562721)){const _0x5281b3=this['listens']['get'](_0x562721);_0x5fba0a=_0x5281b3['get'](_0x286970),_0x5281b3['delete'](_0x286970),_0x5281b3['size']===0x0&&this['listens']['delete'](_0x562721);}else _0x5fba0a=void 0x0;return _0x5fba0a;}['onAuthRevoked_'](_0x25d254,_0x1f6a1c){L('Auth\x20token\x20revoked:\x20'+_0x25d254+'/'+_0x1f6a1c),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x25d254==='invalid_token'||_0x25d254==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1842d4,_0x1353e7){L('App\x20check\x20token\x20revoked:\x20'+_0x1842d4+'/'+_0x1353e7),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1842d4==='invalid_token'||_0x1842d4==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x48322e){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x48322e):'msg'in _0x48322e&&console['log']('FIREBASE:\x20'+_0x48322e['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x515b15 of this['listens']['values']())for(const _0x35e419 of _0x515b15['values']())this['sendListen_'](_0x35e419);for(let _0x5a9e86=0x0;_0x5a9e86<this['outstandingPuts_']['length'];_0x5a9e86++)this['outstandingPuts_'][_0x5a9e86]&&this['sendPut_'](_0x5a9e86);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2b0398=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2b0398['action'],_0x2b0398['pathString'],_0x2b0398['data'],_0x2b0398['onComplete']);}for(let _0x4c2fdc=0x0;_0x4c2fdc<this['outstandingGets_']['length'];_0x4c2fdc++)this['outstandingGets_'][_0x4c2fdc]&&this['sendGet_'](_0x4c2fdc);}['sendConnectStats_'](){const _0x34adf5={};let _0x15bcd4='js';_0x34adf5['sdk.'+_0x15bcd4+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x34adf5['framework.cordova']=0x1:qr()&&(_0x34adf5['framework.reactnative']=0x1),this['reportStats'](_0x34adf5);}['shouldReconnect_'](){const _0x2d10cc=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x2d10cc;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5c868b,_0xfda42f){this['name']=_0x5c868b,this['node']=_0xfda42f;}static['Wrap'](_0x3d0416,_0x27eca0){return new E(_0x3d0416,_0x27eca0);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x24a087,_0x56ecd0){const _0x2613f8=new E(xe,_0x24a087),_0x125625=new E(xe,_0x56ecd0);return this['compare'](_0x2613f8,_0x125625)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0xd84f4b){Xt=_0xd84f4b;}['compare'](_0x50138e,_0x5401bc){return He(_0x50138e['name'],_0x5401bc['name']);}['isDefinedOn'](_0x2aca43){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4e0fbd,_0xa9a362){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x5f8523,_0x1a6887){return f(typeof _0x5f8523=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x5f8523,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4249ff,_0x215d32,_0x43bc49,_0x1143bc,_0x3142dc=null){this['isReverse_']=_0x1143bc,this['resultGenerator_']=_0x3142dc,this['nodeStack_']=[];let _0x481578=0x1;for(;!_0x4249ff['isEmpty']();)if(_0x4249ff=_0x4249ff,_0x481578=_0x215d32?_0x43bc49(_0x4249ff['key'],_0x215d32):0x1,_0x1143bc&&(_0x481578*=-0x1),_0x481578<0x0)this['isReverse_']?_0x4249ff=_0x4249ff['left']:_0x4249ff=_0x4249ff['right'];else{if(_0x481578===0x0){this['nodeStack_']['push'](_0x4249ff);break;}else this['nodeStack_']['push'](_0x4249ff),this['isReverse_']?_0x4249ff=_0x4249ff['right']:_0x4249ff=_0x4249ff['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x27e572=this['nodeStack_']['pop'](),_0x1a484b;if(this['resultGenerator_']?_0x1a484b=this['resultGenerator_'](_0x27e572['key'],_0x27e572['value']):_0x1a484b={'key':_0x27e572['key'],'value':_0x27e572['value']},this['isReverse_']){for(_0x27e572=_0x27e572['left'];!_0x27e572['isEmpty']();)this['nodeStack_']['push'](_0x27e572),_0x27e572=_0x27e572['right'];}else{for(_0x27e572=_0x27e572['right'];!_0x27e572['isEmpty']();)this['nodeStack_']['push'](_0x27e572),_0x27e572=_0x27e572['left'];}return _0x1a484b;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x477b9c=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x477b9c['key'],_0x477b9c['value']):{'key':_0x477b9c['key'],'value':_0x477b9c['value']};}}class M{constructor(_0x196d56,_0x343b7a,_0x4861f8,_0x203f49,_0x45d4dc){this['key']=_0x196d56,this['value']=_0x343b7a,this['color']=_0x4861f8??M['RED'],this['left']=_0x203f49??B['EMPTY_NODE'],this['right']=_0x45d4dc??B['EMPTY_NODE'];}['copy'](_0x5b4d50,_0x27aa1a,_0x351c15,_0x492cef,_0x1ed2fa){return new M(_0x5b4d50??this['key'],_0x27aa1a??this['value'],_0x351c15??this['color'],_0x492cef??this['left'],_0x1ed2fa??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x54b56b){return this['left']['inorderTraversal'](_0x54b56b)||!!_0x54b56b(this['key'],this['value'])||this['right']['inorderTraversal'](_0x54b56b);}['reverseTraversal'](_0x20ca63){return this['right']['reverseTraversal'](_0x20ca63)||_0x20ca63(this['key'],this['value'])||this['left']['reverseTraversal'](_0x20ca63);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x26abe3,_0x5efd9f,_0x2bb9c6){let _0x1d5716=this;const _0x24c54f=_0x2bb9c6(_0x26abe3,_0x1d5716['key']);return _0x24c54f<0x0?_0x1d5716=_0x1d5716['copy'](null,null,null,_0x1d5716['left']['insert'](_0x26abe3,_0x5efd9f,_0x2bb9c6),null):_0x24c54f===0x0?_0x1d5716=_0x1d5716['copy'](null,_0x5efd9f,null,null,null):_0x1d5716=_0x1d5716['copy'](null,null,null,null,_0x1d5716['right']['insert'](_0x26abe3,_0x5efd9f,_0x2bb9c6)),_0x1d5716['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x49c878=this;return!_0x49c878['left']['isRed_']()&&!_0x49c878['left']['left']['isRed_']()&&(_0x49c878=_0x49c878['moveRedLeft_']()),_0x49c878=_0x49c878['copy'](null,null,null,_0x49c878['left']['removeMin_'](),null),_0x49c878['fixUp_']();}['remove'](_0x43fac9,_0xda1890){let _0x49128f,_0x23c766;if(_0x49128f=this,_0xda1890(_0x43fac9,_0x49128f['key'])<0x0)!_0x49128f['left']['isEmpty']()&&!_0x49128f['left']['isRed_']()&&!_0x49128f['left']['left']['isRed_']()&&(_0x49128f=_0x49128f['moveRedLeft_']()),_0x49128f=_0x49128f['copy'](null,null,null,_0x49128f['left']['remove'](_0x43fac9,_0xda1890),null);else{if(_0x49128f['left']['isRed_']()&&(_0x49128f=_0x49128f['rotateRight_']()),!_0x49128f['right']['isEmpty']()&&!_0x49128f['right']['isRed_']()&&!_0x49128f['right']['left']['isRed_']()&&(_0x49128f=_0x49128f['moveRedRight_']()),_0xda1890(_0x43fac9,_0x49128f['key'])===0x0){if(_0x49128f['right']['isEmpty']())return B['EMPTY_NODE'];_0x23c766=_0x49128f['right']['min_'](),_0x49128f=_0x49128f['copy'](_0x23c766['key'],_0x23c766['value'],null,null,_0x49128f['right']['removeMin_']());}_0x49128f=_0x49128f['copy'](null,null,null,null,_0x49128f['right']['remove'](_0x43fac9,_0xda1890));}return _0x49128f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x37643d=this;return _0x37643d['right']['isRed_']()&&!_0x37643d['left']['isRed_']()&&(_0x37643d=_0x37643d['rotateLeft_']()),_0x37643d['left']['isRed_']()&&_0x37643d['left']['left']['isRed_']()&&(_0x37643d=_0x37643d['rotateRight_']()),_0x37643d['left']['isRed_']()&&_0x37643d['right']['isRed_']()&&(_0x37643d=_0x37643d['colorFlip_']()),_0x37643d;}['moveRedLeft_'](){let _0x278627=this['colorFlip_']();return _0x278627['right']['left']['isRed_']()&&(_0x278627=_0x278627['copy'](null,null,null,null,_0x278627['right']['rotateRight_']()),_0x278627=_0x278627['rotateLeft_'](),_0x278627=_0x278627['colorFlip_']()),_0x278627;}['moveRedRight_'](){let _0x40773e=this['colorFlip_']();return _0x40773e['left']['left']['isRed_']()&&(_0x40773e=_0x40773e['rotateRight_'](),_0x40773e=_0x40773e['colorFlip_']()),_0x40773e;}['rotateLeft_'](){const _0xfc4ecb=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0xfc4ecb,null);}['rotateRight_'](){const _0x4adec9=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4adec9);}['colorFlip_'](){const _0x130ee3=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x1ee14e=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x130ee3,_0x1ee14e);}['checkMaxDepth_'](){const _0x18f891=this['check_']();return Math['pow'](0x2,_0x18f891)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x11f33a=this['left']['check_']();if(_0x11f33a!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x11f33a+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x5b98d3,_0xb8c450,_0x54aa32,_0x5ba0bc,_0x1fa6ee){return this;}['insert'](_0x402dd5,_0x10a549,_0x53ff91){return new M(_0x402dd5,_0x10a549,null);}['remove'](_0x3ffc5b,_0xcd4aec){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x488113){return!0x1;}['reverseTraversal'](_0x8d059){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2849c8,_0x18f65f=B['EMPTY_NODE']){this['comparator_']=_0x2849c8,this['root_']=_0x18f65f;}['insert'](_0x40b7e1,_0x344ca9){return new B(this['comparator_'],this['root_']['insert'](_0x40b7e1,_0x344ca9,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x2779c5){return new B(this['comparator_'],this['root_']['remove'](_0x2779c5,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1309b7){let _0x329938,_0xa7c933=this['root_'];for(;!_0xa7c933['isEmpty']();){if(_0x329938=this['comparator_'](_0x1309b7,_0xa7c933['key']),_0x329938===0x0)return _0xa7c933['value'];_0x329938<0x0?_0xa7c933=_0xa7c933['left']:_0x329938>0x0&&(_0xa7c933=_0xa7c933['right']);}return null;}['getPredecessorKey'](_0x415c5e){let _0x37f9a1,_0x23a40d=this['root_'],_0x300878=null;for(;!_0x23a40d['isEmpty']();)if(_0x37f9a1=this['comparator_'](_0x415c5e,_0x23a40d['key']),_0x37f9a1===0x0){if(_0x23a40d['left']['isEmpty']())return _0x300878?_0x300878['key']:null;for(_0x23a40d=_0x23a40d['left'];!_0x23a40d['right']['isEmpty']();)_0x23a40d=_0x23a40d['right'];return _0x23a40d['key'];}else _0x37f9a1<0x0?_0x23a40d=_0x23a40d['left']:_0x37f9a1>0x0&&(_0x300878=_0x23a40d,_0x23a40d=_0x23a40d['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x112206){return this['root_']['inorderTraversal'](_0x112206);}['reverseTraversal'](_0x287046){return this['root_']['reverseTraversal'](_0x287046);}['getIterator'](_0x1c58d2){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x1c58d2);}['getIteratorFrom'](_0x344a3f,_0x564c2b){return new Zt(this['root_'],_0x344a3f,this['comparator_'],!0x1,_0x564c2b);}['getReverseIteratorFrom'](_0x557f17,_0x513e58){return new Zt(this['root_'],_0x557f17,this['comparator_'],!0x0,_0x513e58);}['getReverseIterator'](_0x51e798){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x51e798);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x41bc38,_0x12de90){return He(_0x41bc38['name'],_0x12de90['name']);}function ji(_0x41cc5f,_0x12dfec){return He(_0x41cc5f,_0x12dfec);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x228ecf){vi=_0x228ecf;}const Ro=function(_0x11d74e){return typeof _0x11d74e=='number'?'number:'+so(_0x11d74e):'string:'+_0x11d74e;},Ao=function(_0x408f2e){if(_0x408f2e['isLeafNode']()){const _0x534098=_0x408f2e['val']();f(typeof _0x534098=='string'||typeof _0x534098=='number'||typeof _0x534098=='object'&&Y(_0x534098,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x408f2e===vi||_0x408f2e['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x408f2e===vi||_0x408f2e['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x512ecf){er=_0x512ecf;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x412f6e,_0x5c0a06=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x412f6e,this['priorityNode_']=_0x5c0a06,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x2433a6){return new D(this['value_'],_0x2433a6);}['getImmediateChild'](_0x25a0d8){return _0x25a0d8==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x299600){return v(_0x299600)?this:y(_0x299600)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5d13a8,_0x2f451a){return null;}['updateImmediateChild'](_0x4a8f80,_0x3163e8){return _0x4a8f80==='.priority'?this['updatePriority'](_0x3163e8):_0x3163e8['isEmpty']()&&_0x4a8f80!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x4a8f80,_0x3163e8)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x19fe64,_0x52a5ff){const _0x4f66b2=y(_0x19fe64);return _0x4f66b2===null?_0x52a5ff:_0x52a5ff['isEmpty']()&&_0x4f66b2!=='.priority'?this:(f(_0x4f66b2!=='.priority'||we(_0x19fe64)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4f66b2,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x19fe64),_0x52a5ff)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1ac43f,_0x5e4436){return!0x1;}['val'](_0x3a2bd8){return _0x3a2bd8&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3cf27d='';this['priorityNode_']['isEmpty']()||(_0x3cf27d+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x52a781=typeof this['value_'];_0x3cf27d+=_0x52a781+':',_0x52a781==='number'?_0x3cf27d+=so(this['value_']):_0x3cf27d+=this['value_'],this['lazyHash_']=no(_0x3cf27d);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x974797){return _0x974797===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x974797 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x974797['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x974797));}['compareToLeafNode_'](_0x32e656){const _0x2c3080=typeof _0x32e656['value_'],_0x25ed40=typeof this['value_'],_0x29c8c9=D['VALUE_TYPE_ORDER']['indexOf'](_0x2c3080),_0x134b68=D['VALUE_TYPE_ORDER']['indexOf'](_0x25ed40);return f(_0x29c8c9>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2c3080),f(_0x134b68>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x25ed40),_0x29c8c9===_0x134b68?_0x25ed40==='object'?0x0:this['value_']<_0x32e656['value_']?-0x1:this['value_']===_0x32e656['value_']?0x0:0x1:_0x134b68-_0x29c8c9;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x521da9){if(_0x521da9===this)return!0x0;if(_0x521da9['isLeafNode']()){const _0x17b4d6=_0x521da9;return this['value_']===_0x17b4d6['value_']&&this['priorityNode_']['equals'](_0x17b4d6['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x1f59ff){ko=_0x1f59ff;}function xh(_0x1e87ec){No=_0x1e87ec;}class Fh extends On{['compare'](_0x16d44f,_0x3b05b7){const _0x2c23ad=_0x16d44f['node']['getPriority'](),_0x3196d7=_0x3b05b7['node']['getPriority'](),_0x589a33=_0x2c23ad['compareTo'](_0x3196d7);return _0x589a33===0x0?He(_0x16d44f['name'],_0x3b05b7['name']):_0x589a33;}['isDefinedOn'](_0x46a07a){return!_0x46a07a['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x214f9d,_0x59c2bf){return!_0x214f9d['getPriority']()['equals'](_0x59c2bf['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x1100d6,_0x6f804e){const _0x20521c=ko(_0x1100d6);return new E(_0x6f804e,new D('[PRIORITY-POST]',_0x20521c));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x4cffa9){const _0x4c805f=_0x13a7d6=>parseInt(Math['log'](_0x13a7d6)/Uh,0xa),_0x9dd3e9=_0x259574=>parseInt(Array(_0x259574+0x1)['join']('1'),0x2);this['count']=_0x4c805f(_0x4cffa9+0x1),this['current_']=this['count']-0x1;const _0x36d75d=_0x9dd3e9(this['count']);this['bits_']=_0x4cffa9+0x1&_0x36d75d;}['nextBitIsOne'](){const _0x33f58f=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x33f58f;}}const dn=function(_0x415ef7,_0x45631f,_0x4faab7,_0x29bf86){_0x415ef7['sort'](_0x45631f);const _0x2a1ffd=function(_0x57287d,_0xfb9c0f){const _0x4f5561=_0xfb9c0f-_0x57287d;let _0x588137,_0x3f7a91;if(_0x4f5561===0x0)return null;if(_0x4f5561===0x1)return _0x588137=_0x415ef7[_0x57287d],_0x3f7a91=_0x4faab7?_0x4faab7(_0x588137):_0x588137,new M(_0x3f7a91,_0x588137['node'],M['BLACK'],null,null);{const _0x49c1f8=parseInt(_0x4f5561/0x2,0xa)+_0x57287d,_0x53dd9b=_0x2a1ffd(_0x57287d,_0x49c1f8),_0x5a30a4=_0x2a1ffd(_0x49c1f8+0x1,_0xfb9c0f);return _0x588137=_0x415ef7[_0x49c1f8],_0x3f7a91=_0x4faab7?_0x4faab7(_0x588137):_0x588137,new M(_0x3f7a91,_0x588137['node'],M['BLACK'],_0x53dd9b,_0x5a30a4);}},_0x56a90b=function(_0x3b14cf){let _0x150570=null,_0x49d1a7=null,_0x81862=_0x415ef7['length'];const _0x260632=function(_0xdf41f0,_0x2f933a){const _0x2ddcbb=_0x81862-_0xdf41f0,_0x40297b=_0x81862;_0x81862-=_0xdf41f0;const _0x39b926=_0x2a1ffd(_0x2ddcbb+0x1,_0x40297b),_0xabd755=_0x415ef7[_0x2ddcbb],_0x14b82d=_0x4faab7?_0x4faab7(_0xabd755):_0xabd755;_0x29050f(new M(_0x14b82d,_0xabd755['node'],_0x2f933a,null,_0x39b926));},_0x29050f=function(_0x2eca85){_0x150570?(_0x150570['left']=_0x2eca85,_0x150570=_0x2eca85):(_0x49d1a7=_0x2eca85,_0x150570=_0x2eca85);};for(let _0x194320=0x0;_0x194320<_0x3b14cf['count'];++_0x194320){const _0x2289c8=_0x3b14cf['nextBitIsOne'](),_0x1c00f2=Math['pow'](0x2,_0x3b14cf['count']-(_0x194320+0x1));_0x2289c8?_0x260632(_0x1c00f2,M['BLACK']):(_0x260632(_0x1c00f2,M['BLACK']),_0x260632(_0x1c00f2,M['RED']));}return _0x49d1a7;},_0x408eeb=new Wh(_0x415ef7['length']),_0x1324fa=_0x56a90b(_0x408eeb);return new B(_0x29bf86||_0x45631f,_0x1324fa);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x46dec5,_0x4e9d89){this['indexes_']=_0x46dec5,this['indexSet_']=_0x4e9d89;}['get'](_0x23ee2f){const _0x1c7665=Oe(this['indexes_'],_0x23ee2f);if(!_0x1c7665)throw new Error('No\x20index\x20defined\x20for\x20'+_0x23ee2f);return _0x1c7665 instanceof B?_0x1c7665:null;}['hasIndex'](_0x30871b){return Y(this['indexSet_'],_0x30871b['toString']());}['addIndex'](_0x54f137,_0xbe906b){f(_0x54f137!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x3af3d3=[];let _0x1f5432=!0x1;const _0x46d139=_0xbe906b['getIterator'](E['Wrap']);let _0x3b8597=_0x46d139['getNext']();for(;_0x3b8597;)_0x1f5432=_0x1f5432||_0x54f137['isDefinedOn'](_0x3b8597['node']),_0x3af3d3['push'](_0x3b8597),_0x3b8597=_0x46d139['getNext']();let _0x20f7f5;_0x1f5432?_0x20f7f5=dn(_0x3af3d3,_0x54f137['getCompare']()):_0x20f7f5=je;const _0x4040e0=_0x54f137['toString'](),_0x11ecfb={...this['indexSet_']};_0x11ecfb[_0x4040e0]=_0x54f137;const _0x2e9652={...this['indexes_']};return _0x2e9652[_0x4040e0]=_0x20f7f5,new ee(_0x2e9652,_0x11ecfb);}['addToIndexes'](_0x20cce3,_0x2f4059){const _0x2cd099=ln(this['indexes_'],(_0x185e16,_0x8984e7)=>{const _0x2c4135=Oe(this['indexSet_'],_0x8984e7);if(f(_0x2c4135,'Missing\x20index\x20implementation\x20for\x20'+_0x8984e7),_0x185e16===je){if(_0x2c4135['isDefinedOn'](_0x20cce3['node'])){const _0x536d1d=[],_0x3ee15f=_0x2f4059['getIterator'](E['Wrap']);let _0x3d3db=_0x3ee15f['getNext']();for(;_0x3d3db;)_0x3d3db['name']!==_0x20cce3['name']&&_0x536d1d['push'](_0x3d3db),_0x3d3db=_0x3ee15f['getNext']();return _0x536d1d['push'](_0x20cce3),dn(_0x536d1d,_0x2c4135['getCompare']());}else return je;}else{const _0x3ace59=_0x2f4059['get'](_0x20cce3['name']);let _0x3c77d6=_0x185e16;return _0x3ace59&&(_0x3c77d6=_0x3c77d6['remove'](new E(_0x20cce3['name'],_0x3ace59))),_0x3c77d6['insert'](_0x20cce3,_0x20cce3['node']);}});return new ee(_0x2cd099,this['indexSet_']);}['removeFromIndexes'](_0x1d892d,_0x30e456){const _0x3cc06b=ln(this['indexes_'],_0x52295f=>{if(_0x52295f===je)return _0x52295f;{const _0x17252f=_0x30e456['get'](_0x1d892d['name']);return _0x17252f?_0x52295f['remove'](new E(_0x1d892d['name'],_0x17252f)):_0x52295f;}});return new ee(_0x3cc06b,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x181bfb,_0x3fd24d,_0x158c3a){this['children_']=_0x181bfb,this['priorityNode_']=_0x3fd24d,this['indexMap_']=_0x158c3a,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0xe7ee83){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xe7ee83,this['indexMap_']);}['getImmediateChild'](_0x69991){if(_0x69991==='.priority')return this['getPriority']();{const _0x39a5c2=this['children_']['get'](_0x69991);return _0x39a5c2===null?gt:_0x39a5c2;}}['getChild'](_0x3f0c8d){const _0x30f78e=y(_0x3f0c8d);return _0x30f78e===null?this:this['getImmediateChild'](_0x30f78e)['getChild'](b(_0x3f0c8d));}['hasChild'](_0x2dcbef){return this['children_']['get'](_0x2dcbef)!==null;}['updateImmediateChild'](_0x5f0702,_0x132035){if(f(_0x132035,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5f0702==='.priority')return this['updatePriority'](_0x132035);{const _0xcd14a0=new E(_0x5f0702,_0x132035);let _0x936155,_0x1e787e;_0x132035['isEmpty']()?(_0x936155=this['children_']['remove'](_0x5f0702),_0x1e787e=this['indexMap_']['removeFromIndexes'](_0xcd14a0,this['children_'])):(_0x936155=this['children_']['insert'](_0x5f0702,_0x132035),_0x1e787e=this['indexMap_']['addToIndexes'](_0xcd14a0,this['children_']));const _0x52321b=_0x936155['isEmpty']()?gt:this['priorityNode_'];return new g(_0x936155,_0x52321b,_0x1e787e);}}['updateChild'](_0x1025fb,_0x1fba58){const _0x58d5b2=y(_0x1025fb);if(_0x58d5b2===null)return _0x1fba58;{f(y(_0x1025fb)!=='.priority'||we(_0x1025fb)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x41b400=this['getImmediateChild'](_0x58d5b2)['updateChild'](b(_0x1025fb),_0x1fba58);return this['updateImmediateChild'](_0x58d5b2,_0x41b400);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1410a8){if(this['isEmpty']())return null;const _0x47ed40={};let _0x216bfc=0x0,_0xa117c0=0x0,_0x30d3cd=!0x0;if(this['forEachChild'](R,(_0x41bfba,_0x40c77b)=>{_0x47ed40[_0x41bfba]=_0x40c77b['val'](_0x1410a8),_0x216bfc++,_0x30d3cd&&g['INTEGER_REGEXP_']['test'](_0x41bfba)?_0xa117c0=Math['max'](_0xa117c0,Number(_0x41bfba)):_0x30d3cd=!0x1;}),!_0x1410a8&&_0x30d3cd&&_0xa117c0<0x2*_0x216bfc){const _0xf8d57f=[];for(const _0x4f394b in _0x47ed40)_0xf8d57f[_0x4f394b]=_0x47ed40[_0x4f394b];return _0xf8d57f;}else return _0x1410a8&&!this['getPriority']()['isEmpty']()&&(_0x47ed40['.priority']=this['getPriority']()['val']()),_0x47ed40;}['hash'](){if(this['lazyHash_']===null){let _0xc1382e='';this['getPriority']()['isEmpty']()||(_0xc1382e+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x522c74,_0x37939f)=>{const _0x297db1=_0x37939f['hash']();_0x297db1!==''&&(_0xc1382e+=':'+_0x522c74+':'+_0x297db1);}),this['lazyHash_']=_0xc1382e===''?'':no(_0xc1382e);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4494a8,_0x2d7e5f,_0x3eb2d1){const _0xfc2c7e=this['resolveIndex_'](_0x3eb2d1);if(_0xfc2c7e){const _0x17dee7=_0xfc2c7e['getPredecessorKey'](new E(_0x4494a8,_0x2d7e5f));return _0x17dee7?_0x17dee7['name']:null;}else return this['children_']['getPredecessorKey'](_0x4494a8);}['getFirstChildName'](_0x3b2010){const _0x5af4e4=this['resolveIndex_'](_0x3b2010);if(_0x5af4e4){const _0x1ae0b9=_0x5af4e4['minKey']();return _0x1ae0b9&&_0x1ae0b9['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0xe74f79){const _0x4c6ec5=this['getFirstChildName'](_0xe74f79);return _0x4c6ec5?new E(_0x4c6ec5,this['children_']['get'](_0x4c6ec5)):null;}['getLastChildName'](_0x16c4fb){const _0x6bed41=this['resolveIndex_'](_0x16c4fb);if(_0x6bed41){const _0x59049e=_0x6bed41['maxKey']();return _0x59049e&&_0x59049e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x351bd7){const _0x2e1a97=this['getLastChildName'](_0x351bd7);return _0x2e1a97?new E(_0x2e1a97,this['children_']['get'](_0x2e1a97)):null;}['forEachChild'](_0x5d46b8,_0x1fe232){const _0x5095b7=this['resolveIndex_'](_0x5d46b8);return _0x5095b7?_0x5095b7['inorderTraversal'](_0x2dec81=>_0x1fe232(_0x2dec81['name'],_0x2dec81['node'])):this['children_']['inorderTraversal'](_0x1fe232);}['getIterator'](_0x50c5ea){return this['getIteratorFrom'](_0x50c5ea['minPost'](),_0x50c5ea);}['getIteratorFrom'](_0x4b893f,_0x1bacaa){const _0x3dc57e=this['resolveIndex_'](_0x1bacaa);if(_0x3dc57e)return _0x3dc57e['getIteratorFrom'](_0x4b893f,_0x4cbe01=>_0x4cbe01);{const _0x4258db=this['children_']['getIteratorFrom'](_0x4b893f['name'],E['Wrap']);let _0x594995=_0x4258db['peek']();for(;_0x594995!=null&&_0x1bacaa['compare'](_0x594995,_0x4b893f)<0x0;)_0x4258db['getNext'](),_0x594995=_0x4258db['peek']();return _0x4258db;}}['getReverseIterator'](_0x4b6bab){return this['getReverseIteratorFrom'](_0x4b6bab['maxPost'](),_0x4b6bab);}['getReverseIteratorFrom'](_0x4d97f0,_0x4cecb2){const _0x35fc4b=this['resolveIndex_'](_0x4cecb2);if(_0x35fc4b)return _0x35fc4b['getReverseIteratorFrom'](_0x4d97f0,_0x3adf0d=>_0x3adf0d);{const _0x466db5=this['children_']['getReverseIteratorFrom'](_0x4d97f0['name'],E['Wrap']);let _0x30e8af=_0x466db5['peek']();for(;_0x30e8af!=null&&_0x4cecb2['compare'](_0x30e8af,_0x4d97f0)>0x0;)_0x466db5['getNext'](),_0x30e8af=_0x466db5['peek']();return _0x466db5;}}['compareTo'](_0x5b5b0c){return this['isEmpty']()?_0x5b5b0c['isEmpty']()?0x0:-0x1:_0x5b5b0c['isLeafNode']()||_0x5b5b0c['isEmpty']()?0x1:_0x5b5b0c===Ht?-0x1:0x0;}['withIndex'](_0x16fbe7){if(_0x16fbe7===ye||this['indexMap_']['hasIndex'](_0x16fbe7))return this;{const _0x2d5759=this['indexMap_']['addIndex'](_0x16fbe7,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2d5759);}}['isIndexed'](_0x572e6a){return _0x572e6a===ye||this['indexMap_']['hasIndex'](_0x572e6a);}['equals'](_0x13c637){if(_0x13c637===this)return!0x0;if(_0x13c637['isLeafNode']())return!0x1;{const _0x569d49=_0x13c637;if(this['getPriority']()['equals'](_0x569d49['getPriority']())){if(this['children_']['count']()===_0x569d49['children_']['count']()){const _0x3ebdb1=this['getIterator'](R),_0x12086f=_0x569d49['getIterator'](R);let _0x46a714=_0x3ebdb1['getNext'](),_0x4a9010=_0x12086f['getNext']();for(;_0x46a714&&_0x4a9010;){if(_0x46a714['name']!==_0x4a9010['name']||!_0x46a714['node']['equals'](_0x4a9010['node']))return!0x1;_0x46a714=_0x3ebdb1['getNext'](),_0x4a9010=_0x12086f['getNext']();}return _0x46a714===null&&_0x4a9010===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5ce654){return _0x5ce654===ye?null:this['indexMap_']['get'](_0x5ce654['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x203129){return _0x203129===this?0x0:0x1;}['equals'](_0xf4c927){return _0xf4c927===this;}['getPriority'](){return this;}['getImmediateChild'](_0x13f866){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x2d0bd0,_0x5176a5=null){if(_0x2d0bd0===null)return g['EMPTY_NODE'];if(typeof _0x2d0bd0=='object'&&'.priority'in _0x2d0bd0&&(_0x5176a5=_0x2d0bd0['.priority']),f(_0x5176a5===null||typeof _0x5176a5=='string'||typeof _0x5176a5=='number'||typeof _0x5176a5=='object'&&'.sv'in _0x5176a5,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5176a5),typeof _0x2d0bd0=='object'&&'.value'in _0x2d0bd0&&_0x2d0bd0['.value']!==null&&(_0x2d0bd0=_0x2d0bd0['.value']),typeof _0x2d0bd0!='object'||'.sv'in _0x2d0bd0){const _0x157f82=_0x2d0bd0;return new D(_0x157f82,N(_0x5176a5));}if(!(_0x2d0bd0 instanceof Array)&&Vh){const _0x47e601=[];let _0x348cab=!0x1;if(x(_0x2d0bd0,(_0x4bf856,_0x1fccd2)=>{if(_0x4bf856['substring'](0x0,0x1)!=='.'){const _0x4fc24e=N(_0x1fccd2);_0x4fc24e['isEmpty']()||(_0x348cab=_0x348cab||!_0x4fc24e['getPriority']()['isEmpty'](),_0x47e601['push'](new E(_0x4bf856,_0x4fc24e)));}}),_0x47e601['length']===0x0)return g['EMPTY_NODE'];const _0x1a6463=dn(_0x47e601,Dh,_0x20d668=>_0x20d668['name'],ji);if(_0x348cab){const _0x44e73f=dn(_0x47e601,R['getCompare']());return new g(_0x1a6463,N(_0x5176a5),new ee({'.priority':_0x44e73f},{'.priority':R}));}else return new g(_0x1a6463,N(_0x5176a5),ee['Default']);}else{let _0x106817=g['EMPTY_NODE'];return x(_0x2d0bd0,(_0x2df0af,_0x59a945)=>{if(Y(_0x2d0bd0,_0x2df0af)&&_0x2df0af['substring'](0x0,0x1)!=='.'){const _0x3479fc=N(_0x59a945);(_0x3479fc['isLeafNode']()||!_0x3479fc['isEmpty']())&&(_0x106817=_0x106817['updateImmediateChild'](_0x2df0af,_0x3479fc));}}),_0x106817['updatePriority'](N(_0x5176a5));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x2e571c){super(),this['indexPath_']=_0x2e571c,f(!v(_0x2e571c)&&y(_0x2e571c)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x377d39){return _0x377d39['getChild'](this['indexPath_']);}['isDefinedOn'](_0x5218dc){return!_0x5218dc['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3fa970,_0x5c0a26){const _0x1c4f00=this['extractChild'](_0x3fa970['node']),_0x1cb70d=this['extractChild'](_0x5c0a26['node']),_0x155fa6=_0x1c4f00['compareTo'](_0x1cb70d);return _0x155fa6===0x0?He(_0x3fa970['name'],_0x5c0a26['name']):_0x155fa6;}['makePost'](_0x57b7ac,_0x855ae4){const _0x314fad=N(_0x57b7ac),_0xf4c77=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x314fad);return new E(_0x855ae4,_0xf4c77);}['maxPost'](){const _0x1f3631=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x1f3631);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x2189fa,_0x450a2b){const _0x16d165=_0x2189fa['node']['compareTo'](_0x450a2b['node']);return _0x16d165===0x0?He(_0x2189fa['name'],_0x450a2b['name']):_0x16d165;}['isDefinedOn'](_0x303d66){return!0x0;}['indexedValueChanged'](_0x19e0b8,_0x27ca74){return!_0x19e0b8['equals'](_0x27ca74);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0xbd88d1,_0x46348a){const _0x23a393=N(_0xbd88d1);return new E(_0x46348a,_0x23a393);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x46a2e6){return{'type':'value','snapshotNode':_0x46a2e6};}function tt(_0xac2f90,_0x38cf56){return{'type':'child_added','snapshotNode':_0x38cf56,'childName':_0xac2f90};}function Nt(_0x156759,_0x584e1e){return{'type':'child_removed','snapshotNode':_0x584e1e,'childName':_0x156759};}function Pt(_0x521ef2,_0x18cf23,_0x406adf){return{'type':'child_changed','snapshotNode':_0x18cf23,'childName':_0x521ef2,'oldSnap':_0x406adf};}function $h(_0x27d6c7,_0x571b65){return{'type':'child_moved','snapshotNode':_0x571b65,'childName':_0x27d6c7};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x35ddc3){this['index_']=_0x35ddc3;}['updateChild'](_0x566655,_0x449488,_0x5cb343,_0x1fb6f5,_0x33ceb9,_0x1e67bf){f(_0x566655['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x36b68a=_0x566655['getImmediateChild'](_0x449488);return _0x36b68a['getChild'](_0x1fb6f5)['equals'](_0x5cb343['getChild'](_0x1fb6f5))&&_0x36b68a['isEmpty']()===_0x5cb343['isEmpty']()||(_0x1e67bf!=null&&(_0x5cb343['isEmpty']()?_0x566655['hasChild'](_0x449488)?_0x1e67bf['trackChildChange'](Nt(_0x449488,_0x36b68a)):f(_0x566655['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x36b68a['isEmpty']()?_0x1e67bf['trackChildChange'](tt(_0x449488,_0x5cb343)):_0x1e67bf['trackChildChange'](Pt(_0x449488,_0x5cb343,_0x36b68a))),_0x566655['isLeafNode']()&&_0x5cb343['isEmpty']())?_0x566655:_0x566655['updateImmediateChild'](_0x449488,_0x5cb343)['withIndex'](this['index_']);}['updateFullNode'](_0x411d2c,_0x4c3ea3,_0x59211d){return _0x59211d!=null&&(_0x411d2c['isLeafNode']()||_0x411d2c['forEachChild'](R,(_0x43b21f,_0x8fdfb2)=>{_0x4c3ea3['hasChild'](_0x43b21f)||_0x59211d['trackChildChange'](Nt(_0x43b21f,_0x8fdfb2));}),_0x4c3ea3['isLeafNode']()||_0x4c3ea3['forEachChild'](R,(_0x13f9ed,_0x1f433f)=>{if(_0x411d2c['hasChild'](_0x13f9ed)){const _0x3d3203=_0x411d2c['getImmediateChild'](_0x13f9ed);_0x3d3203['equals'](_0x1f433f)||_0x59211d['trackChildChange'](Pt(_0x13f9ed,_0x1f433f,_0x3d3203));}else _0x59211d['trackChildChange'](tt(_0x13f9ed,_0x1f433f));})),_0x4c3ea3['withIndex'](this['index_']);}['updatePriority'](_0x4bc3cd,_0x390775){return _0x4bc3cd['isEmpty']()?g['EMPTY_NODE']:_0x4bc3cd['updatePriority'](_0x390775);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x13ebaa){this['indexedFilter_']=new Yi(_0x13ebaa['getIndex']()),this['index_']=_0x13ebaa['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x13ebaa),this['endPost_']=Ot['getEndPost_'](_0x13ebaa),this['startIsInclusive_']=!_0x13ebaa['startAfterSet_'],this['endIsInclusive_']=!_0x13ebaa['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x450c23){const _0x42f2e6=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x450c23)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x450c23)<0x0,_0x119821=this['endIsInclusive_']?this['index_']['compare'](_0x450c23,this['getEndPost']())<=0x0:this['index_']['compare'](_0x450c23,this['getEndPost']())<0x0;return _0x42f2e6&&_0x119821;}['updateChild'](_0x49490d,_0x1988e8,_0x3b9db9,_0xe168fe,_0x5f26a3,_0x5200f5){return this['matches'](new E(_0x1988e8,_0x3b9db9))||(_0x3b9db9=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x49490d,_0x1988e8,_0x3b9db9,_0xe168fe,_0x5f26a3,_0x5200f5);}['updateFullNode'](_0x3b68d0,_0x5e36f9,_0x3ca8bb){_0x5e36f9['isLeafNode']()&&(_0x5e36f9=g['EMPTY_NODE']);let _0x4246d0=_0x5e36f9['withIndex'](this['index_']);_0x4246d0=_0x4246d0['updatePriority'](g['EMPTY_NODE']);const _0x238e24=this;return _0x5e36f9['forEachChild'](R,(_0x11d06b,_0x292c44)=>{_0x238e24['matches'](new E(_0x11d06b,_0x292c44))||(_0x4246d0=_0x4246d0['updateImmediateChild'](_0x11d06b,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3b68d0,_0x4246d0,_0x3ca8bb);}['updatePriority'](_0x50c706,_0x249932){return _0x50c706;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x1fbfaf){if(_0x1fbfaf['hasStart']()){const _0x4872ec=_0x1fbfaf['getIndexStartName']();return _0x1fbfaf['getIndex']()['makePost'](_0x1fbfaf['getIndexStartValue'](),_0x4872ec);}else return _0x1fbfaf['getIndex']()['minPost']();}static['getEndPost_'](_0x6cc209){if(_0x6cc209['hasEnd']()){const _0x21741e=_0x6cc209['getIndexEndName']();return _0x6cc209['getIndex']()['makePost'](_0x6cc209['getIndexEndValue'](),_0x21741e);}else return _0x6cc209['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x55d41b){this['withinDirectionalStart']=_0x1d06c7=>this['reverse_']?this['withinEndPost'](_0x1d06c7):this['withinStartPost'](_0x1d06c7),this['withinDirectionalEnd']=_0x285ad0=>this['reverse_']?this['withinStartPost'](_0x285ad0):this['withinEndPost'](_0x285ad0),this['withinStartPost']=_0x31acb3=>{const _0x99d52a=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x31acb3);return this['startIsInclusive_']?_0x99d52a<=0x0:_0x99d52a<0x0;},this['withinEndPost']=_0x3b937a=>{const _0x499692=this['index_']['compare'](_0x3b937a,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x499692<=0x0:_0x499692<0x0;},this['rangedFilter_']=new Ot(_0x55d41b),this['index_']=_0x55d41b['getIndex'](),this['limit_']=_0x55d41b['getLimit'](),this['reverse_']=!_0x55d41b['isViewFromLeft'](),this['startIsInclusive_']=!_0x55d41b['startAfterSet_'],this['endIsInclusive_']=!_0x55d41b['endBeforeSet_'];}['updateChild'](_0x2b12a1,_0x3da0bd,_0x4ce85f,_0x321f4b,_0x2a5782,_0x3dde4f){return this['rangedFilter_']['matches'](new E(_0x3da0bd,_0x4ce85f))||(_0x4ce85f=g['EMPTY_NODE']),_0x2b12a1['getImmediateChild'](_0x3da0bd)['equals'](_0x4ce85f)?_0x2b12a1:_0x2b12a1['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2b12a1,_0x3da0bd,_0x4ce85f,_0x321f4b,_0x2a5782,_0x3dde4f):this['fullLimitUpdateChild_'](_0x2b12a1,_0x3da0bd,_0x4ce85f,_0x2a5782,_0x3dde4f);}['updateFullNode'](_0x53cb4f,_0x2997b2,_0x164d04){let _0x356be4;if(_0x2997b2['isLeafNode']()||_0x2997b2['isEmpty']())_0x356be4=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2997b2['numChildren']()&&_0x2997b2['isIndexed'](this['index_'])){_0x356be4=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x35b341;this['reverse_']?_0x35b341=_0x2997b2['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x35b341=_0x2997b2['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x32a0a0=0x0;for(;_0x35b341['hasNext']()&&_0x32a0a0<this['limit_'];){const _0x1f73a0=_0x35b341['getNext']();if(this['withinDirectionalStart'](_0x1f73a0)){if(this['withinDirectionalEnd'](_0x1f73a0))_0x356be4=_0x356be4['updateImmediateChild'](_0x1f73a0['name'],_0x1f73a0['node']),_0x32a0a0++;else break;}else continue;}}else{_0x356be4=_0x2997b2['withIndex'](this['index_']),_0x356be4=_0x356be4['updatePriority'](g['EMPTY_NODE']);let _0x281829;this['reverse_']?_0x281829=_0x356be4['getReverseIterator'](this['index_']):_0x281829=_0x356be4['getIterator'](this['index_']);let _0x34eb70=0x0;for(;_0x281829['hasNext']();){const _0x4c1a74=_0x281829['getNext']();_0x34eb70<this['limit_']&&this['withinDirectionalStart'](_0x4c1a74)&&this['withinDirectionalEnd'](_0x4c1a74)?_0x34eb70++:_0x356be4=_0x356be4['updateImmediateChild'](_0x4c1a74['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x53cb4f,_0x356be4,_0x164d04);}['updatePriority'](_0x532aec,_0x27b52a){return _0x532aec;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x228983,_0x107680,_0xb03f65,_0x5889be,_0x339752){let _0xfcd0a8;if(this['reverse_']){const _0x128990=this['index_']['getCompare']();_0xfcd0a8=(_0x52e3bd,_0x54907f)=>_0x128990(_0x54907f,_0x52e3bd);}else _0xfcd0a8=this['index_']['getCompare']();const _0x25aa58=_0x228983;f(_0x25aa58['numChildren']()===this['limit_'],'');const _0x4dfc1e=new E(_0x107680,_0xb03f65),_0x2aa339=this['reverse_']?_0x25aa58['getFirstChild'](this['index_']):_0x25aa58['getLastChild'](this['index_']),_0x4a748b=this['rangedFilter_']['matches'](_0x4dfc1e);if(_0x25aa58['hasChild'](_0x107680)){const _0xb9b229=_0x25aa58['getImmediateChild'](_0x107680);let _0x4746bd=_0x5889be['getChildAfterChild'](this['index_'],_0x2aa339,this['reverse_']);for(;_0x4746bd!=null&&(_0x4746bd['name']===_0x107680||_0x25aa58['hasChild'](_0x4746bd['name']));)_0x4746bd=_0x5889be['getChildAfterChild'](this['index_'],_0x4746bd,this['reverse_']);const _0x33ee1b=_0x4746bd==null?0x1:_0xfcd0a8(_0x4746bd,_0x4dfc1e);if(_0x4a748b&&!_0xb03f65['isEmpty']()&&_0x33ee1b>=0x0)return _0x339752!=null&&_0x339752['trackChildChange'](Pt(_0x107680,_0xb03f65,_0xb9b229)),_0x25aa58['updateImmediateChild'](_0x107680,_0xb03f65);{_0x339752!=null&&_0x339752['trackChildChange'](Nt(_0x107680,_0xb9b229));const _0x3c3ee0=_0x25aa58['updateImmediateChild'](_0x107680,g['EMPTY_NODE']);return _0x4746bd!=null&&this['rangedFilter_']['matches'](_0x4746bd)?(_0x339752!=null&&_0x339752['trackChildChange'](tt(_0x4746bd['name'],_0x4746bd['node'])),_0x3c3ee0['updateImmediateChild'](_0x4746bd['name'],_0x4746bd['node'])):_0x3c3ee0;}}else return _0xb03f65['isEmpty']()?_0x228983:_0x4a748b&&_0xfcd0a8(_0x2aa339,_0x4dfc1e)>=0x0?(_0x339752!=null&&(_0x339752['trackChildChange'](Nt(_0x2aa339['name'],_0x2aa339['node'])),_0x339752['trackChildChange'](tt(_0x107680,_0xb03f65))),_0x25aa58['updateImmediateChild'](_0x107680,_0xb03f65)['updateImmediateChild'](_0x2aa339['name'],g['EMPTY_NODE'])):_0x228983;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x505a91=new Qi();return _0x505a91['limitSet_']=this['limitSet_'],_0x505a91['limit_']=this['limit_'],_0x505a91['startSet_']=this['startSet_'],_0x505a91['startAfterSet_']=this['startAfterSet_'],_0x505a91['indexStartValue_']=this['indexStartValue_'],_0x505a91['startNameSet_']=this['startNameSet_'],_0x505a91['indexStartName_']=this['indexStartName_'],_0x505a91['endSet_']=this['endSet_'],_0x505a91['endBeforeSet_']=this['endBeforeSet_'],_0x505a91['indexEndValue_']=this['indexEndValue_'],_0x505a91['endNameSet_']=this['endNameSet_'],_0x505a91['indexEndName_']=this['indexEndName_'],_0x505a91['index_']=this['index_'],_0x505a91['viewFrom_']=this['viewFrom_'],_0x505a91;}}function qh(_0xfdad86){return _0xfdad86['loadsAllData']()?new Yi(_0xfdad86['getIndex']()):_0xfdad86['hasLimit']()?new Gh(_0xfdad86):new Ot(_0xfdad86);}function zh(_0x42785e,_0x272815){const _0x1761a7=_0x42785e['copy']();return _0x1761a7['limitSet_']=!0x0,_0x1761a7['limit_']=_0x272815,_0x1761a7['viewFrom_']='l',_0x1761a7;}function jh(_0x49bca6,_0x698dae,_0x4b6683){const _0x115475=_0x49bca6['copy']();return _0x115475['startSet_']=!0x0,_0x698dae===void 0x0&&(_0x698dae=null),_0x115475['indexStartValue_']=_0x698dae,_0x4b6683!=null?(_0x115475['startNameSet_']=!0x0,_0x115475['indexStartName_']=_0x4b6683):(_0x115475['startNameSet_']=!0x1,_0x115475['indexStartName_']=''),_0x115475;}function Kh(_0x5b6658,_0x42a4d0,_0x41e71b){const _0x5cbb29=_0x5b6658['copy']();return _0x5cbb29['endSet_']=!0x0,_0x42a4d0===void 0x0&&(_0x42a4d0=null),_0x5cbb29['indexEndValue_']=_0x42a4d0,_0x41e71b!==void 0x0?(_0x5cbb29['endNameSet_']=!0x0,_0x5cbb29['indexEndName_']=_0x41e71b):(_0x5cbb29['endNameSet_']=!0x1,_0x5cbb29['indexEndName_']=''),_0x5cbb29;}function Do(_0x450f5d,_0x9bdcb5){const _0x3fbb78=_0x450f5d['copy']();return _0x3fbb78['index_']=_0x9bdcb5,_0x3fbb78;}function tr(_0x31bd22){const _0x7d06f={};if(_0x31bd22['isDefault']())return _0x7d06f;let _0x24ef26;if(_0x31bd22['index_']===R?_0x24ef26='$priority':_0x31bd22['index_']===Po?_0x24ef26='$value':_0x31bd22['index_']===ye?_0x24ef26='$key':(f(_0x31bd22['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x24ef26=_0x31bd22['index_']['toString']()),_0x7d06f['orderBy']=O(_0x24ef26),_0x31bd22['startSet_']){const _0x9c95f5=_0x31bd22['startAfterSet_']?'startAfter':'startAt';_0x7d06f[_0x9c95f5]=O(_0x31bd22['indexStartValue_']),_0x31bd22['startNameSet_']&&(_0x7d06f[_0x9c95f5]+=','+O(_0x31bd22['indexStartName_']));}if(_0x31bd22['endSet_']){const _0xd6ff56=_0x31bd22['endBeforeSet_']?'endBefore':'endAt';_0x7d06f[_0xd6ff56]=O(_0x31bd22['indexEndValue_']),_0x31bd22['endNameSet_']&&(_0x7d06f[_0xd6ff56]+=','+O(_0x31bd22['indexEndName_']));}return _0x31bd22['limitSet_']&&(_0x31bd22['isViewFromLeft']()?_0x7d06f['limitToFirst']=_0x31bd22['limit_']:_0x7d06f['limitToLast']=_0x31bd22['limit_']),_0x7d06f;}function nr(_0x5421c0){const _0x4a2e67={};if(_0x5421c0['startSet_']&&(_0x4a2e67['sp']=_0x5421c0['indexStartValue_'],_0x5421c0['startNameSet_']&&(_0x4a2e67['sn']=_0x5421c0['indexStartName_']),_0x4a2e67['sin']=!_0x5421c0['startAfterSet_']),_0x5421c0['endSet_']&&(_0x4a2e67['ep']=_0x5421c0['indexEndValue_'],_0x5421c0['endNameSet_']&&(_0x4a2e67['en']=_0x5421c0['indexEndName_']),_0x4a2e67['ein']=!_0x5421c0['endBeforeSet_']),_0x5421c0['limitSet_']){_0x4a2e67['l']=_0x5421c0['limit_'];let _0x4db52f=_0x5421c0['viewFrom_'];_0x4db52f===''&&(_0x5421c0['isViewFromLeft']()?_0x4db52f='l':_0x4db52f='r'),_0x4a2e67['vf']=_0x4db52f;}return _0x5421c0['index_']!==R&&(_0x4a2e67['i']=_0x5421c0['index_']['toString']()),_0x4a2e67;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x2933b2){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x407d19,_0x314770){return _0x314770!==void 0x0?'tag$'+_0x314770:(f(_0x407d19['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x407d19['_path']['toString']());}constructor(_0x2fbc38,_0xbfbc81,_0x241feb,_0x19f527){super(),this['repoInfo_']=_0x2fbc38,this['onDataUpdate_']=_0xbfbc81,this['authTokenProvider_']=_0x241feb,this['appCheckTokenProvider_']=_0x19f527,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x264662,_0x564f89,_0x4f4276,_0x3067b0){const _0x374bc4=_0x264662['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x374bc4+'\x20'+_0x264662['_queryIdentifier']);const _0x597e6e=fn['getListenId_'](_0x264662,_0x4f4276),_0x25b551={};this['listens_'][_0x597e6e]=_0x25b551;const _0x354158=tr(_0x264662['_queryParams']);this['restRequest_'](_0x374bc4+'.json',_0x354158,(_0x5e86ff,_0x38a0f9)=>{let _0x32c56e=_0x38a0f9;if(_0x5e86ff===0x194&&(_0x32c56e=null,_0x5e86ff=null),_0x5e86ff===null&&this['onDataUpdate_'](_0x374bc4,_0x32c56e,!0x1,_0x4f4276),Oe(this['listens_'],_0x597e6e)===_0x25b551){let _0x48931f;_0x5e86ff?_0x5e86ff===0x191?_0x48931f='permission_denied':_0x48931f='rest_error:'+_0x5e86ff:_0x48931f='ok',_0x3067b0(_0x48931f,null);}});}['unlisten'](_0x88b896,_0x43daa4){const _0x34e7d9=fn['getListenId_'](_0x88b896,_0x43daa4);delete this['listens_'][_0x34e7d9];}['get'](_0x3d704f){const _0x4d0a79=tr(_0x3d704f['_queryParams']),_0x39fbbc=_0x3d704f['_path']['toString'](),_0x13c76a=new Ve();return this['restRequest_'](_0x39fbbc+'.json',_0x4d0a79,(_0x247d18,_0x16deb0)=>{let _0xedb4c3=_0x16deb0;_0x247d18===0x194&&(_0xedb4c3=null,_0x247d18=null),_0x247d18===null?(this['onDataUpdate_'](_0x39fbbc,_0xedb4c3,!0x1,null),_0x13c76a['resolve'](_0xedb4c3)):_0x13c76a['reject'](new Error(_0xedb4c3));}),_0x13c76a['promise'];}['refreshAuthToken'](_0x43eb9e){}['restRequest_'](_0xccb36,_0x2a439a={},_0x2875f4){return _0x2a439a['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x8a20c7,_0x29d5b3])=>{_0x8a20c7&&_0x8a20c7['accessToken']&&(_0x2a439a['auth']=_0x8a20c7['accessToken']),_0x29d5b3&&_0x29d5b3['token']&&(_0x2a439a['ac']=_0x29d5b3['token']);const _0x55b754=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0xccb36+'?ns='+this['repoInfo_']['namespace']+at(_0x2a439a);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x55b754);const _0x2ab287=new XMLHttpRequest();_0x2ab287['onreadystatechange']=()=>{if(_0x2875f4&&_0x2ab287['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x55b754+'\x20received.\x20status:',_0x2ab287['status'],'response:',_0x2ab287['responseText']);let _0x3d196a=null;if(_0x2ab287['status']>=0xc8&&_0x2ab287['status']<0x12c){try{_0x3d196a=bt(_0x2ab287['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x55b754+':\x20'+_0x2ab287['responseText']);}_0x2875f4(null,_0x3d196a);}else _0x2ab287['status']!==0x191&&_0x2ab287['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x55b754+'\x20Status:\x20'+_0x2ab287['status']),_0x2875f4(_0x2ab287['status']);_0x2875f4=null;}},_0x2ab287['open']('GET',_0x55b754,!0x0),_0x2ab287['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5f473a){return this['rootNode_']['getChild'](_0x5f473a);}['updateSnapshot'](_0xbe25b3,_0x2280b4){this['rootNode_']=this['rootNode_']['updateChild'](_0xbe25b3,_0x2280b4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x1fc3a5,_0x1962f5,_0x29fac8){if(v(_0x1962f5))_0x1fc3a5['value']=_0x29fac8,_0x1fc3a5['children']['clear']();else{if(_0x1fc3a5['value']!==null)_0x1fc3a5['value']=_0x1fc3a5['value']['updateChild'](_0x1962f5,_0x29fac8);else{const _0x42b6c5=y(_0x1962f5);_0x1fc3a5['children']['has'](_0x42b6c5)||_0x1fc3a5['children']['set'](_0x42b6c5,pn());const _0x3a44c5=_0x1fc3a5['children']['get'](_0x42b6c5);_0x1962f5=b(_0x1962f5),Mo(_0x3a44c5,_0x1962f5,_0x29fac8);}}}function Ei(_0x3fe205,_0x377f7b,_0x463996){_0x3fe205['value']!==null?_0x463996(_0x377f7b,_0x3fe205['value']):Qh(_0x3fe205,(_0x315b6b,_0xb6845d)=>{const _0x2c8218=new C(_0x377f7b['toString']()+'/'+_0x315b6b);Ei(_0xb6845d,_0x2c8218,_0x463996);});}function Qh(_0x59ae66,_0x23af93){_0x59ae66['children']['forEach']((_0x17b033,_0x2e1fe3)=>{_0x23af93(_0x2e1fe3,_0x17b033);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x22de22){this['collection_']=_0x22de22,this['last_']=null;}['get'](){const _0x743f8f=this['collection_']['get'](),_0xa53002={..._0x743f8f};return this['last_']&&x(this['last_'],(_0x20d7fc,_0x1b7beb)=>{_0xa53002[_0x20d7fc]=_0xa53002[_0x20d7fc]-_0x1b7beb;}),this['last_']=_0x743f8f,_0xa53002;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x3c49e1,_0x291dc2){this['server_']=_0x291dc2,this['statsToReport_']={},this['statsListener_']=new Jh(_0x3c49e1);const _0x410818=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x410818));}['reportStats_'](){const _0x2cdf4f=this['statsListener_']['get'](),_0x2e8ee8={};let _0x4ddc58=!0x1;x(_0x2cdf4f,(_0x46dd5b,_0x61e7b1)=>{_0x61e7b1>0x0&&Y(this['statsToReport_'],_0x46dd5b)&&(_0x2e8ee8[_0x46dd5b]=_0x61e7b1,_0x4ddc58=!0x0);}),_0x4ddc58&&this['server_']['reportStats'](_0x2e8ee8),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x317988){_0x317988[_0x317988['OVERWRITE']=0x0]='OVERWRITE',_0x317988[_0x317988['MERGE']=0x1]='MERGE',_0x317988[_0x317988['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x317988[_0x317988['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x2c5189){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2c5189,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x1b31dd,_0x13bc1a,_0x173f38){this['path']=_0x1b31dd,this['affectedTree']=_0x13bc1a,this['revert']=_0x173f38,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x4998e2){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x55e12b=this['affectedTree']['subtree'](new C(_0x4998e2));return new _n(w(),_0x55e12b,this['revert']);}}else return f(y(this['path'])===_0x4998e2,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x1f0322,_0x187d96){this['source']=_0x1f0322,this['path']=_0x187d96,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x3640a7){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x290e42,_0x12c753,_0x4a8871){this['source']=_0x290e42,this['path']=_0x12c753,this['snap']=_0x4a8871,this['type']=q['OVERWRITE'];}['operationForChild'](_0x4d43be){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x4d43be)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x3ca9a6,_0x2dc823,_0x1e394e){this['source']=_0x3ca9a6,this['path']=_0x2dc823,this['children']=_0x1e394e,this['type']=q['MERGE'];}['operationForChild'](_0x2e7da1){if(v(this['path'])){const _0xa2d337=this['children']['subtree'](new C(_0x2e7da1));return _0xa2d337['isEmpty']()?null:_0xa2d337['value']?new Fe(this['source'],w(),_0xa2d337['value']):new nt(this['source'],w(),_0xa2d337);}else return f(y(this['path'])===_0x2e7da1,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x45d7bc,_0x29089a,_0x1f12a7){this['node_']=_0x45d7bc,this['fullyInitialized_']=_0x29089a,this['filtered_']=_0x1f12a7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xc1fb26){if(v(_0xc1fb26))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5efa00=y(_0xc1fb26);return this['isCompleteForChild'](_0x5efa00);}['isCompleteForChild'](_0x175927){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x175927);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x2e3f7c){this['query_']=_0x2e3f7c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x476f1b,_0x47bab6,_0x3a28b5,_0x3eec4f){const _0x3ef30f=[],_0x588cd7=[];return _0x47bab6['forEach'](_0x44ce33=>{_0x44ce33['type']==='child_changed'&&_0x476f1b['index_']['indexedValueChanged'](_0x44ce33['oldSnap'],_0x44ce33['snapshotNode'])&&_0x588cd7['push']($h(_0x44ce33['childName'],_0x44ce33['snapshotNode']));}),mt(_0x476f1b,_0x3ef30f,'child_removed',_0x47bab6,_0x3eec4f,_0x3a28b5),mt(_0x476f1b,_0x3ef30f,'child_added',_0x47bab6,_0x3eec4f,_0x3a28b5),mt(_0x476f1b,_0x3ef30f,'child_moved',_0x588cd7,_0x3eec4f,_0x3a28b5),mt(_0x476f1b,_0x3ef30f,'child_changed',_0x47bab6,_0x3eec4f,_0x3a28b5),mt(_0x476f1b,_0x3ef30f,'value',_0x47bab6,_0x3eec4f,_0x3a28b5),_0x3ef30f;}function mt(_0x152935,_0xac1947,_0x2d3303,_0x35f8a,_0x4ecc4e,_0x38ce02){const _0x45a338=_0x35f8a['filter'](_0x4bc038=>_0x4bc038['type']===_0x2d3303);_0x45a338['sort']((_0x252058,_0x1c9c84)=>su(_0x152935,_0x252058,_0x1c9c84)),_0x45a338['forEach'](_0x27b04f=>{const _0x3c6f04=iu(_0x152935,_0x27b04f,_0x38ce02);_0x4ecc4e['forEach'](_0xb52a30=>{_0xb52a30['respondsTo'](_0x27b04f['type'])&&_0xac1947['push'](_0xb52a30['createEvent'](_0x3c6f04,_0x152935['query_']));});});}function iu(_0x1fd864,_0x2bf623,_0x326350){return _0x2bf623['type']==='value'||_0x2bf623['type']==='child_removed'||(_0x2bf623['prevName']=_0x326350['getPredecessorChildName'](_0x2bf623['childName'],_0x2bf623['snapshotNode'],_0x1fd864['index_'])),_0x2bf623;}function su(_0x262613,_0x3a8810,_0x11128f){if(_0x3a8810['childName']==null||_0x11128f['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x13d78e=new E(_0x3a8810['childName'],_0x3a8810['snapshotNode']),_0x64bd88=new E(_0x11128f['childName'],_0x11128f['snapshotNode']);return _0x262613['index_']['compare'](_0x13d78e,_0x64bd88);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x1081ff,_0x2a34a6){return{'eventCache':_0x1081ff,'serverCache':_0x2a34a6};}function wt(_0x2a0546,_0x425ac7,_0x1e136f,_0x331e06){return Dn(new Ce(_0x425ac7,_0x1e136f,_0x331e06),_0x2a0546['serverCache']);}function Lo(_0x57edde,_0x5b5b0b,_0x10fd0b,_0x38154e){return Dn(_0x57edde['eventCache'],new Ce(_0x5b5b0b,_0x10fd0b,_0x38154e));}function gn(_0x548804){return _0x548804['eventCache']['isFullyInitialized']()?_0x548804['eventCache']['getNode']():null;}function Ue(_0x3b7656){return _0x3b7656['serverCache']['isFullyInitialized']()?_0x3b7656['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x2e97ef){let _0x112b00=new S(null);return x(_0x2e97ef,(_0x13c557,_0x40113b)=>{_0x112b00=_0x112b00['set'](new C(_0x13c557),_0x40113b);}),_0x112b00;}constructor(_0x23d385,_0x5ac209=ru()){this['value']=_0x23d385,this['children']=_0x5ac209;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xa33d7b,_0x1bce64){if(this['value']!=null&&_0x1bce64(this['value']))return{'path':w(),'value':this['value']};if(v(_0xa33d7b))return null;{const _0x226c13=y(_0xa33d7b),_0x3f6b89=this['children']['get'](_0x226c13);if(_0x3f6b89!==null){const _0x15e397=_0x3f6b89['findRootMostMatchingPathAndValue'](b(_0xa33d7b),_0x1bce64);return _0x15e397!=null?{'path':A(new C(_0x226c13),_0x15e397['path']),'value':_0x15e397['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x2a5a55){return this['findRootMostMatchingPathAndValue'](_0x2a5a55,()=>!0x0);}['subtree'](_0x1f2e3e){if(v(_0x1f2e3e))return this;{const _0x2edc4e=y(_0x1f2e3e),_0x232e94=this['children']['get'](_0x2edc4e);return _0x232e94!==null?_0x232e94['subtree'](b(_0x1f2e3e)):new S(null);}}['set'](_0x3a24e2,_0x381bf3){if(v(_0x3a24e2))return new S(_0x381bf3,this['children']);{const _0x1cf4ff=y(_0x3a24e2),_0x4c45ee=(this['children']['get'](_0x1cf4ff)||new S(null))['set'](b(_0x3a24e2),_0x381bf3),_0x3d12f1=this['children']['insert'](_0x1cf4ff,_0x4c45ee);return new S(this['value'],_0x3d12f1);}}['remove'](_0x1882bc){if(v(_0x1882bc))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x1ebdb8=y(_0x1882bc),_0x28b924=this['children']['get'](_0x1ebdb8);if(_0x28b924){const _0x29aae6=_0x28b924['remove'](b(_0x1882bc));let _0x49528a;return _0x29aae6['isEmpty']()?_0x49528a=this['children']['remove'](_0x1ebdb8):_0x49528a=this['children']['insert'](_0x1ebdb8,_0x29aae6),this['value']===null&&_0x49528a['isEmpty']()?new S(null):new S(this['value'],_0x49528a);}else return this;}}['get'](_0x4bd123){if(v(_0x4bd123))return this['value'];{const _0x1a14b9=y(_0x4bd123),_0x4f6548=this['children']['get'](_0x1a14b9);return _0x4f6548?_0x4f6548['get'](b(_0x4bd123)):null;}}['setTree'](_0x12dd41,_0x39f3a4){if(v(_0x12dd41))return _0x39f3a4;{const _0x153ff2=y(_0x12dd41),_0xe33cf3=(this['children']['get'](_0x153ff2)||new S(null))['setTree'](b(_0x12dd41),_0x39f3a4);let _0x10e7ac;return _0xe33cf3['isEmpty']()?_0x10e7ac=this['children']['remove'](_0x153ff2):_0x10e7ac=this['children']['insert'](_0x153ff2,_0xe33cf3),new S(this['value'],_0x10e7ac);}}['fold'](_0x1d6596){return this['fold_'](w(),_0x1d6596);}['fold_'](_0x2dbd25,_0x2a1f94){const _0x2f27e2={};return this['children']['inorderTraversal']((_0x51d9bf,_0x1326c7)=>{_0x2f27e2[_0x51d9bf]=_0x1326c7['fold_'](A(_0x2dbd25,_0x51d9bf),_0x2a1f94);}),_0x2a1f94(_0x2dbd25,this['value'],_0x2f27e2);}['findOnPath'](_0x5beadc,_0x3810d0){return this['findOnPath_'](_0x5beadc,w(),_0x3810d0);}['findOnPath_'](_0x2339bb,_0x1066d2,_0x538620){const _0x6cad58=this['value']?_0x538620(_0x1066d2,this['value']):!0x1;if(_0x6cad58)return _0x6cad58;if(v(_0x2339bb))return null;{const _0x162995=y(_0x2339bb),_0x535278=this['children']['get'](_0x162995);return _0x535278?_0x535278['findOnPath_'](b(_0x2339bb),A(_0x1066d2,_0x162995),_0x538620):null;}}['foreachOnPath'](_0x50b7c2,_0x240323){return this['foreachOnPath_'](_0x50b7c2,w(),_0x240323);}['foreachOnPath_'](_0x4189f4,_0x23a370,_0x5b0851){if(v(_0x4189f4))return this;{this['value']&&_0x5b0851(_0x23a370,this['value']);const _0x494605=y(_0x4189f4),_0x205221=this['children']['get'](_0x494605);return _0x205221?_0x205221['foreachOnPath_'](b(_0x4189f4),A(_0x23a370,_0x494605),_0x5b0851):new S(null);}}['foreach'](_0x1f5d1f){this['foreach_'](w(),_0x1f5d1f);}['foreach_'](_0x40fd82,_0x349af3){this['children']['inorderTraversal']((_0x5dc70f,_0x57ee86)=>{_0x57ee86['foreach_'](A(_0x40fd82,_0x5dc70f),_0x349af3);}),this['value']&&_0x349af3(_0x40fd82,this['value']);}['foreachChild'](_0x58c84e){this['children']['inorderTraversal']((_0x3d45bd,_0x2da547)=>{_0x2da547['value']&&_0x58c84e(_0x3d45bd,_0x2da547['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x43a0e5){this['writeTree_']=_0x43a0e5;}static['empty'](){return new j(new S(null));}}function Ct(_0x562401,_0x47226d,_0x50c1ed){if(v(_0x47226d))return new j(new S(_0x50c1ed));{const _0x1e5da8=_0x562401['writeTree_']['findRootMostValueAndPath'](_0x47226d);if(_0x1e5da8!=null){const _0x1bcad3=_0x1e5da8['path'];let _0xfb4624=_0x1e5da8['value'];const _0x3c93fe=F(_0x1bcad3,_0x47226d);return _0xfb4624=_0xfb4624['updateChild'](_0x3c93fe,_0x50c1ed),new j(_0x562401['writeTree_']['set'](_0x1bcad3,_0xfb4624));}else{const _0x1bd686=new S(_0x50c1ed),_0x3d4bea=_0x562401['writeTree_']['setTree'](_0x47226d,_0x1bd686);return new j(_0x3d4bea);}}}function Ii(_0x2f3d78,_0x4751e0,_0x1cb44f){let _0xd4c309=_0x2f3d78;return x(_0x1cb44f,(_0x14ddb8,_0x31e42f)=>{_0xd4c309=Ct(_0xd4c309,A(_0x4751e0,_0x14ddb8),_0x31e42f);}),_0xd4c309;}function sr(_0x5ab501,_0x40063b){if(v(_0x40063b))return j['empty']();{const _0x25537e=_0x5ab501['writeTree_']['setTree'](_0x40063b,new S(null));return new j(_0x25537e);}}function wi(_0x5eb0fb,_0x5ccb45){return $e(_0x5eb0fb,_0x5ccb45)!=null;}function $e(_0x3d443d,_0x15dbe2){const _0x543198=_0x3d443d['writeTree_']['findRootMostValueAndPath'](_0x15dbe2);return _0x543198!=null?_0x3d443d['writeTree_']['get'](_0x543198['path'])['getChild'](F(_0x543198['path'],_0x15dbe2)):null;}function rr(_0x485f6e){const _0x161f84=[],_0x3330b9=_0x485f6e['writeTree_']['value'];return _0x3330b9!=null?_0x3330b9['isLeafNode']()||_0x3330b9['forEachChild'](R,(_0x4628b8,_0x12b871)=>{_0x161f84['push'](new E(_0x4628b8,_0x12b871));}):_0x485f6e['writeTree_']['children']['inorderTraversal']((_0x1a1079,_0x3d6625)=>{_0x3d6625['value']!=null&&_0x161f84['push'](new E(_0x1a1079,_0x3d6625['value']));}),_0x161f84;}function ve(_0x84bff7,_0x2efa06){if(v(_0x2efa06))return _0x84bff7;{const _0x40183=$e(_0x84bff7,_0x2efa06);return _0x40183!=null?new j(new S(_0x40183)):new j(_0x84bff7['writeTree_']['subtree'](_0x2efa06));}}function Ci(_0x27bc04){return _0x27bc04['writeTree_']['isEmpty']();}function it(_0x14dc14,_0x588f59){return xo(w(),_0x14dc14['writeTree_'],_0x588f59);}function xo(_0x7e83a6,_0x439dd9,_0x6203c3){if(_0x439dd9['value']!=null)return _0x6203c3['updateChild'](_0x7e83a6,_0x439dd9['value']);{let _0x482581=null;return _0x439dd9['children']['inorderTraversal']((_0x26d9ba,_0xa0a841)=>{_0x26d9ba==='.priority'?(f(_0xa0a841['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x482581=_0xa0a841['value']):_0x6203c3=xo(A(_0x7e83a6,_0x26d9ba),_0xa0a841,_0x6203c3);}),!_0x6203c3['getChild'](_0x7e83a6)['isEmpty']()&&_0x482581!==null&&(_0x6203c3=_0x6203c3['updateChild'](A(_0x7e83a6,'.priority'),_0x482581)),_0x6203c3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x4f4eeb,_0x4bab1b){return Bo(_0x4bab1b,_0x4f4eeb);}function ou(_0x2aa81e,_0x2c3275,_0x1a68c7,_0x5057ab,_0x2d0f7c){f(_0x5057ab>_0x2aa81e['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x2d0f7c===void 0x0&&(_0x2d0f7c=!0x0),_0x2aa81e['allWrites']['push']({'path':_0x2c3275,'snap':_0x1a68c7,'writeId':_0x5057ab,'visible':_0x2d0f7c}),_0x2d0f7c&&(_0x2aa81e['visibleWrites']=Ct(_0x2aa81e['visibleWrites'],_0x2c3275,_0x1a68c7)),_0x2aa81e['lastWriteId']=_0x5057ab;}function au(_0x4be6c2,_0x2c2bc0,_0x3d479d,_0x20a4d6){f(_0x20a4d6>_0x4be6c2['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4be6c2['allWrites']['push']({'path':_0x2c2bc0,'children':_0x3d479d,'writeId':_0x20a4d6,'visible':!0x0}),_0x4be6c2['visibleWrites']=Ii(_0x4be6c2['visibleWrites'],_0x2c2bc0,_0x3d479d),_0x4be6c2['lastWriteId']=_0x20a4d6;}function cu(_0x407bf0,_0x294b03){for(let _0x53b855=0x0;_0x53b855<_0x407bf0['allWrites']['length'];_0x53b855++){const _0x59b058=_0x407bf0['allWrites'][_0x53b855];if(_0x59b058['writeId']===_0x294b03)return _0x59b058;}return null;}function lu(_0x59bd24,_0x49d49b){const _0x56824e=_0x59bd24['allWrites']['findIndex'](_0x216791=>_0x216791['writeId']===_0x49d49b);f(_0x56824e>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x56ec1b=_0x59bd24['allWrites'][_0x56824e];_0x59bd24['allWrites']['splice'](_0x56824e,0x1);let _0x57f0a8=_0x56ec1b['visible'],_0x197c4e=!0x1,_0xcaf370=_0x59bd24['allWrites']['length']-0x1;for(;_0x57f0a8&&_0xcaf370>=0x0;){const _0x468d37=_0x59bd24['allWrites'][_0xcaf370];_0x468d37['visible']&&(_0xcaf370>=_0x56824e&&hu(_0x468d37,_0x56ec1b['path'])?_0x57f0a8=!0x1:$(_0x56ec1b['path'],_0x468d37['path'])&&(_0x197c4e=!0x0)),_0xcaf370--;}if(_0x57f0a8){if(_0x197c4e)return uu(_0x59bd24),!0x0;if(_0x56ec1b['snap'])_0x59bd24['visibleWrites']=sr(_0x59bd24['visibleWrites'],_0x56ec1b['path']);else{const _0x5aa339=_0x56ec1b['children'];x(_0x5aa339,_0x15d596=>{_0x59bd24['visibleWrites']=sr(_0x59bd24['visibleWrites'],A(_0x56ec1b['path'],_0x15d596));});}return!0x0;}else return!0x1;}function hu(_0x46d371,_0x1395df){if(_0x46d371['snap'])return $(_0x46d371['path'],_0x1395df);for(const _0x490b9d in _0x46d371['children'])if(_0x46d371['children']['hasOwnProperty'](_0x490b9d)&&$(A(_0x46d371['path'],_0x490b9d),_0x1395df))return!0x0;return!0x1;}function uu(_0x16d85c){_0x16d85c['visibleWrites']=Fo(_0x16d85c['allWrites'],du,w()),_0x16d85c['allWrites']['length']>0x0?_0x16d85c['lastWriteId']=_0x16d85c['allWrites'][_0x16d85c['allWrites']['length']-0x1]['writeId']:_0x16d85c['lastWriteId']=-0x1;}function du(_0x435db0){return _0x435db0['visible'];}function Fo(_0x36f2bc,_0x1cd085,_0xebee50){let _0x79e5=j['empty']();for(let _0x2b1006=0x0;_0x2b1006<_0x36f2bc['length'];++_0x2b1006){const _0x3e524a=_0x36f2bc[_0x2b1006];if(_0x1cd085(_0x3e524a)){const _0x6b7db6=_0x3e524a['path'];let _0x4f86e5;if(_0x3e524a['snap'])$(_0xebee50,_0x6b7db6)?(_0x4f86e5=F(_0xebee50,_0x6b7db6),_0x79e5=Ct(_0x79e5,_0x4f86e5,_0x3e524a['snap'])):$(_0x6b7db6,_0xebee50)&&(_0x4f86e5=F(_0x6b7db6,_0xebee50),_0x79e5=Ct(_0x79e5,w(),_0x3e524a['snap']['getChild'](_0x4f86e5)));else{if(_0x3e524a['children']){if($(_0xebee50,_0x6b7db6))_0x4f86e5=F(_0xebee50,_0x6b7db6),_0x79e5=Ii(_0x79e5,_0x4f86e5,_0x3e524a['children']);else{if($(_0x6b7db6,_0xebee50)){if(_0x4f86e5=F(_0x6b7db6,_0xebee50),v(_0x4f86e5))_0x79e5=Ii(_0x79e5,w(),_0x3e524a['children']);else{const _0x1c5f07=Oe(_0x3e524a['children'],y(_0x4f86e5));if(_0x1c5f07){const _0x95a5df=_0x1c5f07['getChild'](b(_0x4f86e5));_0x79e5=Ct(_0x79e5,w(),_0x95a5df);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x79e5;}function Uo(_0x397beb,_0x3c0703,_0x45f38b,_0x4f2fd9,_0x454a80){if(!_0x4f2fd9&&!_0x454a80){const _0x4438c4=$e(_0x397beb['visibleWrites'],_0x3c0703);if(_0x4438c4!=null)return _0x4438c4;{const _0x280c20=ve(_0x397beb['visibleWrites'],_0x3c0703);if(Ci(_0x280c20))return _0x45f38b;if(_0x45f38b==null&&!wi(_0x280c20,w()))return null;{const _0x5e42c3=_0x45f38b||g['EMPTY_NODE'];return it(_0x280c20,_0x5e42c3);}}}else{const _0x32618f=ve(_0x397beb['visibleWrites'],_0x3c0703);if(!_0x454a80&&Ci(_0x32618f))return _0x45f38b;if(!_0x454a80&&_0x45f38b==null&&!wi(_0x32618f,w()))return null;{const _0x1f00b9=function(_0x54152c){return(_0x54152c['visible']||_0x454a80)&&(!_0x4f2fd9||!~_0x4f2fd9['indexOf'](_0x54152c['writeId']))&&($(_0x54152c['path'],_0x3c0703)||$(_0x3c0703,_0x54152c['path']));},_0xb6bfe7=Fo(_0x397beb['allWrites'],_0x1f00b9,_0x3c0703),_0x58bbaf=_0x45f38b||g['EMPTY_NODE'];return it(_0xb6bfe7,_0x58bbaf);}}}function fu(_0x2ab3e4,_0x5a0e23,_0x280582){let _0x5d589e=g['EMPTY_NODE'];const _0xa72004=$e(_0x2ab3e4['visibleWrites'],_0x5a0e23);if(_0xa72004)return _0xa72004['isLeafNode']()||_0xa72004['forEachChild'](R,(_0x52668a,_0x57d83b)=>{_0x5d589e=_0x5d589e['updateImmediateChild'](_0x52668a,_0x57d83b);}),_0x5d589e;if(_0x280582){const _0x19cf39=ve(_0x2ab3e4['visibleWrites'],_0x5a0e23);return _0x280582['forEachChild'](R,(_0x4d418f,_0x3070fc)=>{const _0x260f22=it(ve(_0x19cf39,new C(_0x4d418f)),_0x3070fc);_0x5d589e=_0x5d589e['updateImmediateChild'](_0x4d418f,_0x260f22);}),rr(_0x19cf39)['forEach'](_0x54f4bd=>{_0x5d589e=_0x5d589e['updateImmediateChild'](_0x54f4bd['name'],_0x54f4bd['node']);}),_0x5d589e;}else{const _0x1777d9=ve(_0x2ab3e4['visibleWrites'],_0x5a0e23);return rr(_0x1777d9)['forEach'](_0x5c0f38=>{_0x5d589e=_0x5d589e['updateImmediateChild'](_0x5c0f38['name'],_0x5c0f38['node']);}),_0x5d589e;}}function pu(_0x1d490a,_0x91fceb,_0x32a632,_0x3e4750,_0x24aa04){f(_0x3e4750||_0x24aa04,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4c9a31=A(_0x91fceb,_0x32a632);if(wi(_0x1d490a['visibleWrites'],_0x4c9a31))return null;{const _0x2fa96d=ve(_0x1d490a['visibleWrites'],_0x4c9a31);return Ci(_0x2fa96d)?_0x24aa04['getChild'](_0x32a632):it(_0x2fa96d,_0x24aa04['getChild'](_0x32a632));}}function _u(_0x164344,_0x5a34ce,_0x135bbb,_0x4e4520){const _0x4a2bd0=A(_0x5a34ce,_0x135bbb),_0xc76aa4=$e(_0x164344['visibleWrites'],_0x4a2bd0);if(_0xc76aa4!=null)return _0xc76aa4;if(_0x4e4520['isCompleteForChild'](_0x135bbb)){const _0x57f6a6=ve(_0x164344['visibleWrites'],_0x4a2bd0);return it(_0x57f6a6,_0x4e4520['getNode']()['getImmediateChild'](_0x135bbb));}else return null;}function gu(_0x474543,_0x3b7f56){return $e(_0x474543['visibleWrites'],_0x3b7f56);}function mu(_0x45d603,_0xa7bc3,_0x118fed,_0x3f56f3,_0x1f646e,_0x473e7c,_0x30bf72){let _0x24effc;const _0x3984b7=ve(_0x45d603['visibleWrites'],_0xa7bc3),_0x2c2585=$e(_0x3984b7,w());if(_0x2c2585!=null)_0x24effc=_0x2c2585;else{if(_0x118fed!=null)_0x24effc=it(_0x3984b7,_0x118fed);else return[];}if(_0x24effc=_0x24effc['withIndex'](_0x30bf72),!_0x24effc['isEmpty']()&&!_0x24effc['isLeafNode']()){const _0x73126a=[],_0x420058=_0x30bf72['getCompare'](),_0x9163a5=_0x473e7c?_0x24effc['getReverseIteratorFrom'](_0x3f56f3,_0x30bf72):_0x24effc['getIteratorFrom'](_0x3f56f3,_0x30bf72);let _0x2b712b=_0x9163a5['getNext']();for(;_0x2b712b&&_0x73126a['length']<_0x1f646e;)_0x420058(_0x2b712b,_0x3f56f3)!==0x0&&_0x73126a['push'](_0x2b712b),_0x2b712b=_0x9163a5['getNext']();return _0x73126a;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x1c0d4d,_0x43c3dc,_0x2b125d,_0x38621c){return Uo(_0x1c0d4d['writeTree'],_0x1c0d4d['treePath'],_0x43c3dc,_0x2b125d,_0x38621c);}function es(_0x4923ae,_0x271789){return fu(_0x4923ae['writeTree'],_0x4923ae['treePath'],_0x271789);}function or(_0x59528b,_0x5169fe,_0x2dd9a2,_0x2fcc3a){return pu(_0x59528b['writeTree'],_0x59528b['treePath'],_0x5169fe,_0x2dd9a2,_0x2fcc3a);}function yn(_0x458d5a,_0x57458b){return gu(_0x458d5a['writeTree'],A(_0x458d5a['treePath'],_0x57458b));}function vu(_0x38502c,_0x5e12e2,_0x1736bb,_0x5a87fe,_0x1bc92f,_0x29db96){return mu(_0x38502c['writeTree'],_0x38502c['treePath'],_0x5e12e2,_0x1736bb,_0x5a87fe,_0x1bc92f,_0x29db96);}function ts(_0x18d7b9,_0x13133f,_0x509cf6){return _u(_0x18d7b9['writeTree'],_0x18d7b9['treePath'],_0x13133f,_0x509cf6);}function Wo(_0x39d6a1,_0x5cacdb){return Bo(A(_0x39d6a1['treePath'],_0x5cacdb),_0x39d6a1['writeTree']);}function Bo(_0x385559,_0x48f792){return{'treePath':_0x385559,'writeTree':_0x48f792};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xdd8fe4){const _0x321f49=_0xdd8fe4['type'],_0x49c030=_0xdd8fe4['childName'];f(_0x321f49==='child_added'||_0x321f49==='child_changed'||_0x321f49==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x49c030!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1e0514=this['changeMap']['get'](_0x49c030);if(_0x1e0514){const _0x5063ba=_0x1e0514['type'];if(_0x321f49==='child_added'&&_0x5063ba==='child_removed')this['changeMap']['set'](_0x49c030,Pt(_0x49c030,_0xdd8fe4['snapshotNode'],_0x1e0514['snapshotNode']));else{if(_0x321f49==='child_removed'&&_0x5063ba==='child_added')this['changeMap']['delete'](_0x49c030);else{if(_0x321f49==='child_removed'&&_0x5063ba==='child_changed')this['changeMap']['set'](_0x49c030,Nt(_0x49c030,_0x1e0514['oldSnap']));else{if(_0x321f49==='child_changed'&&_0x5063ba==='child_added')this['changeMap']['set'](_0x49c030,tt(_0x49c030,_0xdd8fe4['snapshotNode']));else{if(_0x321f49==='child_changed'&&_0x5063ba==='child_changed')this['changeMap']['set'](_0x49c030,Pt(_0x49c030,_0xdd8fe4['snapshotNode'],_0x1e0514['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0xdd8fe4+'\x20occurred\x20after\x20'+_0x1e0514);}}}}}else this['changeMap']['set'](_0x49c030,_0xdd8fe4);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0xbd6aef){return null;}['getChildAfterChild'](_0xaaed06,_0x2881c2,_0x32de44){return null;}}const Vo=new Iu();class ns{constructor(_0x3bffd8,_0x2f66f8,_0x29ed74=null){this['writes_']=_0x3bffd8,this['viewCache_']=_0x2f66f8,this['optCompleteServerCache_']=_0x29ed74;}['getCompleteChild'](_0x27d8f7){const _0x4e3a0e=this['viewCache_']['eventCache'];if(_0x4e3a0e['isCompleteForChild'](_0x27d8f7))return _0x4e3a0e['getNode']()['getImmediateChild'](_0x27d8f7);{const _0x1c1eb0=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x27d8f7,_0x1c1eb0);}}['getChildAfterChild'](_0x1b7318,_0x3764e8,_0x18e023){const _0x569a0c=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x42a290=vu(this['writes_'],_0x569a0c,_0x3764e8,0x1,_0x18e023,_0x1b7318);return _0x42a290['length']===0x0?null:_0x42a290[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x4930ed){return{'filter':_0x4930ed};}function Cu(_0xd49e95,_0xea384b){f(_0xea384b['eventCache']['getNode']()['isIndexed'](_0xd49e95['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xea384b['serverCache']['getNode']()['isIndexed'](_0xd49e95['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x1c7be7,_0x599255,_0x36ed0a,_0x237452,_0x419d08){const _0x548642=new Eu();let _0x3d6177,_0x21b4ae;if(_0x36ed0a['type']===q['OVERWRITE']){const _0x427cd1=_0x36ed0a;_0x427cd1['source']['fromUser']?_0x3d6177=Ti(_0x1c7be7,_0x599255,_0x427cd1['path'],_0x427cd1['snap'],_0x237452,_0x419d08,_0x548642):(f(_0x427cd1['source']['fromServer'],'Unknown\x20source.'),_0x21b4ae=_0x427cd1['source']['tagged']||_0x599255['serverCache']['isFiltered']()&&!v(_0x427cd1['path']),_0x3d6177=vn(_0x1c7be7,_0x599255,_0x427cd1['path'],_0x427cd1['snap'],_0x237452,_0x419d08,_0x21b4ae,_0x548642));}else{if(_0x36ed0a['type']===q['MERGE']){const _0x44ac7a=_0x36ed0a;_0x44ac7a['source']['fromUser']?_0x3d6177=bu(_0x1c7be7,_0x599255,_0x44ac7a['path'],_0x44ac7a['children'],_0x237452,_0x419d08,_0x548642):(f(_0x44ac7a['source']['fromServer'],'Unknown\x20source.'),_0x21b4ae=_0x44ac7a['source']['tagged']||_0x599255['serverCache']['isFiltered'](),_0x3d6177=Si(_0x1c7be7,_0x599255,_0x44ac7a['path'],_0x44ac7a['children'],_0x237452,_0x419d08,_0x21b4ae,_0x548642));}else{if(_0x36ed0a['type']===q['ACK_USER_WRITE']){const _0x4eabd5=_0x36ed0a;_0x4eabd5['revert']?_0x3d6177=ku(_0x1c7be7,_0x599255,_0x4eabd5['path'],_0x237452,_0x419d08,_0x548642):_0x3d6177=Ru(_0x1c7be7,_0x599255,_0x4eabd5['path'],_0x4eabd5['affectedTree'],_0x237452,_0x419d08,_0x548642);}else{if(_0x36ed0a['type']===q['LISTEN_COMPLETE'])_0x3d6177=Au(_0x1c7be7,_0x599255,_0x36ed0a['path'],_0x237452,_0x548642);else throw ot('Unknown\x20operation\x20type:\x20'+_0x36ed0a['type']);}}}const _0x3e9aea=_0x548642['getChanges']();return Su(_0x599255,_0x3d6177,_0x3e9aea),{'viewCache':_0x3d6177,'changes':_0x3e9aea};}function Su(_0x1430b6,_0x17b794,_0x40aa2){const _0x437c5c=_0x17b794['eventCache'];if(_0x437c5c['isFullyInitialized']()){const _0x42fbba=_0x437c5c['getNode']()['isLeafNode']()||_0x437c5c['getNode']()['isEmpty'](),_0x1e1815=gn(_0x1430b6);(_0x40aa2['length']>0x0||!_0x1430b6['eventCache']['isFullyInitialized']()||_0x42fbba&&!_0x437c5c['getNode']()['equals'](_0x1e1815)||!_0x437c5c['getNode']()['getPriority']()['equals'](_0x1e1815['getPriority']()))&&_0x40aa2['push'](Oo(gn(_0x17b794)));}}function Ho(_0x381cba,_0x22085b,_0x4a2cec,_0x228b17,_0x5004fe,_0x3a1457){const _0x27801b=_0x22085b['eventCache'];if(yn(_0x228b17,_0x4a2cec)!=null)return _0x22085b;{let _0x370d2a,_0x37102f;if(v(_0x4a2cec)){if(f(_0x22085b['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x22085b['serverCache']['isFiltered']()){const _0x58ccdb=Ue(_0x22085b),_0xb5e8ec=_0x58ccdb instanceof g?_0x58ccdb:g['EMPTY_NODE'],_0x4a543a=es(_0x228b17,_0xb5e8ec);_0x370d2a=_0x381cba['filter']['updateFullNode'](_0x22085b['eventCache']['getNode'](),_0x4a543a,_0x3a1457);}else{const _0x567052=mn(_0x228b17,Ue(_0x22085b));_0x370d2a=_0x381cba['filter']['updateFullNode'](_0x22085b['eventCache']['getNode'](),_0x567052,_0x3a1457);}}else{const _0x50e97c=y(_0x4a2cec);if(_0x50e97c==='.priority'){f(we(_0x4a2cec)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4bdfbb=_0x27801b['getNode']();_0x37102f=_0x22085b['serverCache']['getNode']();const _0x1219bc=or(_0x228b17,_0x4a2cec,_0x4bdfbb,_0x37102f);_0x1219bc!=null?_0x370d2a=_0x381cba['filter']['updatePriority'](_0x4bdfbb,_0x1219bc):_0x370d2a=_0x27801b['getNode']();}else{const _0x15d110=b(_0x4a2cec);let _0x4d605;if(_0x27801b['isCompleteForChild'](_0x50e97c)){_0x37102f=_0x22085b['serverCache']['getNode']();const _0xbc71b8=or(_0x228b17,_0x4a2cec,_0x27801b['getNode'](),_0x37102f);_0xbc71b8!=null?_0x4d605=_0x27801b['getNode']()['getImmediateChild'](_0x50e97c)['updateChild'](_0x15d110,_0xbc71b8):_0x4d605=_0x27801b['getNode']()['getImmediateChild'](_0x50e97c);}else _0x4d605=ts(_0x228b17,_0x50e97c,_0x22085b['serverCache']);_0x4d605!=null?_0x370d2a=_0x381cba['filter']['updateChild'](_0x27801b['getNode'](),_0x50e97c,_0x4d605,_0x15d110,_0x5004fe,_0x3a1457):_0x370d2a=_0x27801b['getNode']();}}return wt(_0x22085b,_0x370d2a,_0x27801b['isFullyInitialized']()||v(_0x4a2cec),_0x381cba['filter']['filtersNodes']());}}function vn(_0x35fa4a,_0x17cf55,_0x41698c,_0x38b366,_0x3f6b7c,_0x54ec22,_0x1e7a3d,_0xbc3b6a){const _0x255240=_0x17cf55['serverCache'];let _0x3282fc;const _0x91e4fc=_0x1e7a3d?_0x35fa4a['filter']:_0x35fa4a['filter']['getIndexedFilter']();if(v(_0x41698c))_0x3282fc=_0x91e4fc['updateFullNode'](_0x255240['getNode'](),_0x38b366,null);else{if(_0x91e4fc['filtersNodes']()&&!_0x255240['isFiltered']()){const _0x3ea8b3=_0x255240['getNode']()['updateChild'](_0x41698c,_0x38b366);_0x3282fc=_0x91e4fc['updateFullNode'](_0x255240['getNode'](),_0x3ea8b3,null);}else{const _0x30c962=y(_0x41698c);if(!_0x255240['isCompleteForPath'](_0x41698c)&&we(_0x41698c)>0x1)return _0x17cf55;const _0x302e2a=b(_0x41698c),_0x53e74b=_0x255240['getNode']()['getImmediateChild'](_0x30c962)['updateChild'](_0x302e2a,_0x38b366);_0x30c962==='.priority'?_0x3282fc=_0x91e4fc['updatePriority'](_0x255240['getNode'](),_0x53e74b):_0x3282fc=_0x91e4fc['updateChild'](_0x255240['getNode'](),_0x30c962,_0x53e74b,_0x302e2a,Vo,null);}}const _0x25e6b3=Lo(_0x17cf55,_0x3282fc,_0x255240['isFullyInitialized']()||v(_0x41698c),_0x91e4fc['filtersNodes']()),_0x260c9d=new ns(_0x3f6b7c,_0x25e6b3,_0x54ec22);return Ho(_0x35fa4a,_0x25e6b3,_0x41698c,_0x3f6b7c,_0x260c9d,_0xbc3b6a);}function Ti(_0x356c7d,_0x391d60,_0x35bec0,_0x3b7f77,_0x5e704a,_0x129b5a,_0x374c3e){const _0x516d7=_0x391d60['eventCache'];let _0x3b179a,_0x597963;const _0x4a4ac0=new ns(_0x5e704a,_0x391d60,_0x129b5a);if(v(_0x35bec0))_0x597963=_0x356c7d['filter']['updateFullNode'](_0x391d60['eventCache']['getNode'](),_0x3b7f77,_0x374c3e),_0x3b179a=wt(_0x391d60,_0x597963,!0x0,_0x356c7d['filter']['filtersNodes']());else{const _0x5e401c=y(_0x35bec0);if(_0x5e401c==='.priority')_0x597963=_0x356c7d['filter']['updatePriority'](_0x391d60['eventCache']['getNode'](),_0x3b7f77),_0x3b179a=wt(_0x391d60,_0x597963,_0x516d7['isFullyInitialized'](),_0x516d7['isFiltered']());else{const _0x58f39d=b(_0x35bec0),_0x427edf=_0x516d7['getNode']()['getImmediateChild'](_0x5e401c);let _0x1c23ae;if(v(_0x58f39d))_0x1c23ae=_0x3b7f77;else{const _0x31c499=_0x4a4ac0['getCompleteChild'](_0x5e401c);_0x31c499!=null?Gi(_0x58f39d)==='.priority'&&_0x31c499['getChild'](To(_0x58f39d))['isEmpty']()?_0x1c23ae=_0x31c499:_0x1c23ae=_0x31c499['updateChild'](_0x58f39d,_0x3b7f77):_0x1c23ae=g['EMPTY_NODE'];}if(_0x427edf['equals'](_0x1c23ae))_0x3b179a=_0x391d60;else{const _0x29ccf9=_0x356c7d['filter']['updateChild'](_0x516d7['getNode'](),_0x5e401c,_0x1c23ae,_0x58f39d,_0x4a4ac0,_0x374c3e);_0x3b179a=wt(_0x391d60,_0x29ccf9,_0x516d7['isFullyInitialized'](),_0x356c7d['filter']['filtersNodes']());}}}return _0x3b179a;}function ar(_0x364129,_0x338bb2){return _0x364129['eventCache']['isCompleteForChild'](_0x338bb2);}function bu(_0x25e9a3,_0x2e448a,_0x1c6922,_0x5b6ffe,_0x3b84af,_0x384150,_0x320870){let _0x5463d8=_0x2e448a;return _0x5b6ffe['foreach']((_0x114b76,_0x4cb41c)=>{const _0x3093d5=A(_0x1c6922,_0x114b76);ar(_0x2e448a,y(_0x3093d5))&&(_0x5463d8=Ti(_0x25e9a3,_0x5463d8,_0x3093d5,_0x4cb41c,_0x3b84af,_0x384150,_0x320870));}),_0x5b6ffe['foreach']((_0x4383ee,_0x5795e8)=>{const _0x481b2f=A(_0x1c6922,_0x4383ee);ar(_0x2e448a,y(_0x481b2f))||(_0x5463d8=Ti(_0x25e9a3,_0x5463d8,_0x481b2f,_0x5795e8,_0x3b84af,_0x384150,_0x320870));}),_0x5463d8;}function cr(_0x1addda,_0x49f517,_0x424ea1){return _0x424ea1['foreach']((_0x3e67e5,_0xe80d71)=>{_0x49f517=_0x49f517['updateChild'](_0x3e67e5,_0xe80d71);}),_0x49f517;}function Si(_0xb1107d,_0x44a309,_0x5e636b,_0x3d9205,_0x185a73,_0x3bc5c0,_0x143f7f,_0x241c52){if(_0x44a309['serverCache']['getNode']()['isEmpty']()&&!_0x44a309['serverCache']['isFullyInitialized']())return _0x44a309;let _0x5d7f55=_0x44a309,_0x945f67;v(_0x5e636b)?_0x945f67=_0x3d9205:_0x945f67=new S(null)['setTree'](_0x5e636b,_0x3d9205);const _0x590d3c=_0x44a309['serverCache']['getNode']();return _0x945f67['children']['inorderTraversal']((_0x36f688,_0x28c864)=>{if(_0x590d3c['hasChild'](_0x36f688)){const _0x387be5=_0x44a309['serverCache']['getNode']()['getImmediateChild'](_0x36f688),_0x7a4851=cr(_0xb1107d,_0x387be5,_0x28c864);_0x5d7f55=vn(_0xb1107d,_0x5d7f55,new C(_0x36f688),_0x7a4851,_0x185a73,_0x3bc5c0,_0x143f7f,_0x241c52);}}),_0x945f67['children']['inorderTraversal']((_0x42c06a,_0x140dd8)=>{const _0x570f6a=!_0x44a309['serverCache']['isCompleteForChild'](_0x42c06a)&&_0x140dd8['value']===null;if(!_0x590d3c['hasChild'](_0x42c06a)&&!_0x570f6a){const _0x45f79f=_0x44a309['serverCache']['getNode']()['getImmediateChild'](_0x42c06a),_0x584a54=cr(_0xb1107d,_0x45f79f,_0x140dd8);_0x5d7f55=vn(_0xb1107d,_0x5d7f55,new C(_0x42c06a),_0x584a54,_0x185a73,_0x3bc5c0,_0x143f7f,_0x241c52);}}),_0x5d7f55;}function Ru(_0x1376c2,_0x4e6329,_0x129842,_0x4ee1cb,_0x2e8920,_0x2ae47f,_0x4705bf){if(yn(_0x2e8920,_0x129842)!=null)return _0x4e6329;const _0x1729f0=_0x4e6329['serverCache']['isFiltered'](),_0x4a899e=_0x4e6329['serverCache'];if(_0x4ee1cb['value']!=null){if(v(_0x129842)&&_0x4a899e['isFullyInitialized']()||_0x4a899e['isCompleteForPath'](_0x129842))return vn(_0x1376c2,_0x4e6329,_0x129842,_0x4a899e['getNode']()['getChild'](_0x129842),_0x2e8920,_0x2ae47f,_0x1729f0,_0x4705bf);if(v(_0x129842)){let _0x29014e=new S(null);return _0x4a899e['getNode']()['forEachChild'](ye,(_0x51312a,_0x135592)=>{_0x29014e=_0x29014e['set'](new C(_0x51312a),_0x135592);}),Si(_0x1376c2,_0x4e6329,_0x129842,_0x29014e,_0x2e8920,_0x2ae47f,_0x1729f0,_0x4705bf);}else return _0x4e6329;}else{let _0x2447c1=new S(null);return _0x4ee1cb['foreach']((_0x36d320,_0x553588)=>{const _0x465adf=A(_0x129842,_0x36d320);_0x4a899e['isCompleteForPath'](_0x465adf)&&(_0x2447c1=_0x2447c1['set'](_0x36d320,_0x4a899e['getNode']()['getChild'](_0x465adf)));}),Si(_0x1376c2,_0x4e6329,_0x129842,_0x2447c1,_0x2e8920,_0x2ae47f,_0x1729f0,_0x4705bf);}}function Au(_0x4da0eb,_0x2c04ee,_0x379b27,_0x2d07b1,_0x3257d1){const _0x235e4d=_0x2c04ee['serverCache'],_0x338162=Lo(_0x2c04ee,_0x235e4d['getNode'](),_0x235e4d['isFullyInitialized']()||v(_0x379b27),_0x235e4d['isFiltered']());return Ho(_0x4da0eb,_0x338162,_0x379b27,_0x2d07b1,Vo,_0x3257d1);}function ku(_0xe9228b,_0x65776,_0x5693f0,_0x606d3a,_0x196174,_0x1f0369){let _0x3f3e89;if(yn(_0x606d3a,_0x5693f0)!=null)return _0x65776;{const _0x3ccede=new ns(_0x606d3a,_0x65776,_0x196174),_0x3446d7=_0x65776['eventCache']['getNode']();let _0x1cb55f;if(v(_0x5693f0)||y(_0x5693f0)==='.priority'){let _0x43ea8c;if(_0x65776['serverCache']['isFullyInitialized']())_0x43ea8c=mn(_0x606d3a,Ue(_0x65776));else{const _0x2d668f=_0x65776['serverCache']['getNode']();f(_0x2d668f instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x43ea8c=es(_0x606d3a,_0x2d668f);}_0x43ea8c=_0x43ea8c,_0x1cb55f=_0xe9228b['filter']['updateFullNode'](_0x3446d7,_0x43ea8c,_0x1f0369);}else{const _0x486008=y(_0x5693f0);let _0x4e56f6=ts(_0x606d3a,_0x486008,_0x65776['serverCache']);_0x4e56f6==null&&_0x65776['serverCache']['isCompleteForChild'](_0x486008)&&(_0x4e56f6=_0x3446d7['getImmediateChild'](_0x486008)),_0x4e56f6!=null?_0x1cb55f=_0xe9228b['filter']['updateChild'](_0x3446d7,_0x486008,_0x4e56f6,b(_0x5693f0),_0x3ccede,_0x1f0369):_0x65776['eventCache']['getNode']()['hasChild'](_0x486008)?_0x1cb55f=_0xe9228b['filter']['updateChild'](_0x3446d7,_0x486008,g['EMPTY_NODE'],b(_0x5693f0),_0x3ccede,_0x1f0369):_0x1cb55f=_0x3446d7,_0x1cb55f['isEmpty']()&&_0x65776['serverCache']['isFullyInitialized']()&&(_0x3f3e89=mn(_0x606d3a,Ue(_0x65776)),_0x3f3e89['isLeafNode']()&&(_0x1cb55f=_0xe9228b['filter']['updateFullNode'](_0x1cb55f,_0x3f3e89,_0x1f0369)));}return _0x3f3e89=_0x65776['serverCache']['isFullyInitialized']()||yn(_0x606d3a,w())!=null,wt(_0x65776,_0x1cb55f,_0x3f3e89,_0xe9228b['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x2ab22f,_0x55b66a){this['query_']=_0x2ab22f,this['eventRegistrations_']=[];const _0x44243f=this['query_']['_queryParams'],_0x3c0584=new Yi(_0x44243f['getIndex']()),_0x3450a0=qh(_0x44243f);this['processor_']=wu(_0x3450a0);const _0x4ef32d=_0x55b66a['serverCache'],_0x4d6926=_0x55b66a['eventCache'],_0x1141d6=_0x3c0584['updateFullNode'](g['EMPTY_NODE'],_0x4ef32d['getNode'](),null),_0x5278df=_0x3450a0['updateFullNode'](g['EMPTY_NODE'],_0x4d6926['getNode'](),null),_0x590ab5=new Ce(_0x1141d6,_0x4ef32d['isFullyInitialized'](),_0x3c0584['filtersNodes']()),_0xbe2c78=new Ce(_0x5278df,_0x4d6926['isFullyInitialized'](),_0x3450a0['filtersNodes']());this['viewCache_']=Dn(_0xbe2c78,_0x590ab5),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x102173){return _0x102173['viewCache_']['serverCache']['getNode']();}function Ou(_0x467642){return gn(_0x467642['viewCache_']);}function Du(_0x132684,_0x43472a){const _0x3b54d2=Ue(_0x132684['viewCache_']);return _0x3b54d2&&(_0x132684['query']['_queryParams']['loadsAllData']()||!v(_0x43472a)&&!_0x3b54d2['getImmediateChild'](y(_0x43472a))['isEmpty']())?_0x3b54d2['getChild'](_0x43472a):null;}function lr(_0x137828){return _0x137828['eventRegistrations_']['length']===0x0;}function Mu(_0x7addcb,_0x4b8d13){_0x7addcb['eventRegistrations_']['push'](_0x4b8d13);}function hr(_0x4561e9,_0x3e2376,_0xf5aec9){const _0x132255=[];if(_0xf5aec9){f(_0x3e2376==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x9283f3=_0x4561e9['query']['_path'];_0x4561e9['eventRegistrations_']['forEach'](_0x5dedf1=>{const _0x5035f5=_0x5dedf1['createCancelEvent'](_0xf5aec9,_0x9283f3);_0x5035f5&&_0x132255['push'](_0x5035f5);});}if(_0x3e2376){let _0x5cf347=[];for(let _0x2d3d22=0x0;_0x2d3d22<_0x4561e9['eventRegistrations_']['length'];++_0x2d3d22){const _0x2fe242=_0x4561e9['eventRegistrations_'][_0x2d3d22];if(!_0x2fe242['matches'](_0x3e2376))_0x5cf347['push'](_0x2fe242);else{if(_0x3e2376['hasAnyCallback']()){_0x5cf347=_0x5cf347['concat'](_0x4561e9['eventRegistrations_']['slice'](_0x2d3d22+0x1));break;}}}_0x4561e9['eventRegistrations_']=_0x5cf347;}else _0x4561e9['eventRegistrations_']=[];return _0x132255;}function ur(_0x5a6bbb,_0x58c377,_0x13322a,_0x478579){_0x58c377['type']===q['MERGE']&&_0x58c377['source']['queryId']!==null&&(f(Ue(_0x5a6bbb['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x5a6bbb['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2210e5=_0x5a6bbb['viewCache_'],_0x4f6c47=Tu(_0x5a6bbb['processor_'],_0x2210e5,_0x58c377,_0x13322a,_0x478579);return Cu(_0x5a6bbb['processor_'],_0x4f6c47['viewCache']),f(_0x4f6c47['viewCache']['serverCache']['isFullyInitialized']()||!_0x2210e5['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5a6bbb['viewCache_']=_0x4f6c47['viewCache'],$o(_0x5a6bbb,_0x4f6c47['changes'],_0x4f6c47['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x5e008d,_0x4490a1){const _0x4cda96=_0x5e008d['viewCache_']['eventCache'],_0x14c6df=[];return _0x4cda96['getNode']()['isLeafNode']()||_0x4cda96['getNode']()['forEachChild'](R,(_0xdeb787,_0x5011e7)=>{_0x14c6df['push'](tt(_0xdeb787,_0x5011e7));}),_0x4cda96['isFullyInitialized']()&&_0x14c6df['push'](Oo(_0x4cda96['getNode']())),$o(_0x5e008d,_0x14c6df,_0x4cda96['getNode'](),_0x4490a1);}function $o(_0x494b13,_0x12562b,_0x3fd951,_0x1dca31){const _0x5449e3=_0x1dca31?[_0x1dca31]:_0x494b13['eventRegistrations_'];return nu(_0x494b13['eventGenerator_'],_0x12562b,_0x3fd951,_0x5449e3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x94bade){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x94bade;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x516b3c){return _0x516b3c['views']['size']===0x0;}function is(_0x866229,_0x254704,_0x1e0957,_0x40885b){const _0x11b2f6=_0x254704['source']['queryId'];if(_0x11b2f6!==null){const _0x4ee82b=_0x866229['views']['get'](_0x11b2f6);return f(_0x4ee82b!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x4ee82b,_0x254704,_0x1e0957,_0x40885b);}else{let _0x57fcc2=[];for(const _0x2df349 of _0x866229['views']['values']())_0x57fcc2=_0x57fcc2['concat'](ur(_0x2df349,_0x254704,_0x1e0957,_0x40885b));return _0x57fcc2;}}function qo(_0x41623b,_0x3c1063,_0x3d4b09,_0x40c636,_0x55d58d){const _0x4d3ab8=_0x3c1063['_queryIdentifier'],_0x1ddb0f=_0x41623b['views']['get'](_0x4d3ab8);if(!_0x1ddb0f){let _0x4a40d3=mn(_0x3d4b09,_0x55d58d?_0x40c636:null),_0x2c1b2a=!0x1;_0x4a40d3?_0x2c1b2a=!0x0:_0x40c636 instanceof g?(_0x4a40d3=es(_0x3d4b09,_0x40c636),_0x2c1b2a=!0x1):(_0x4a40d3=g['EMPTY_NODE'],_0x2c1b2a=!0x1);const _0x364760=Dn(new Ce(_0x4a40d3,_0x2c1b2a,!0x1),new Ce(_0x40c636,_0x55d58d,!0x1));return new Nu(_0x3c1063,_0x364760);}return _0x1ddb0f;}function Wu(_0x5c2e09,_0x284f26,_0x3d1974,_0x20757d,_0x49951f,_0x304f04){const _0x127748=qo(_0x5c2e09,_0x284f26,_0x20757d,_0x49951f,_0x304f04);return _0x5c2e09['views']['has'](_0x284f26['_queryIdentifier'])||_0x5c2e09['views']['set'](_0x284f26['_queryIdentifier'],_0x127748),Mu(_0x127748,_0x3d1974),Lu(_0x127748,_0x3d1974);}function Bu(_0x59825d,_0x22fb52,_0x50afb7,_0x54baf8){const _0x3c4844=_0x22fb52['_queryIdentifier'],_0x49018a=[];let _0x28e870=[];const _0x287602=Te(_0x59825d);if(_0x3c4844==='default'){for(const [_0x523267,_0x39c355]of _0x59825d['views']['entries']())_0x28e870=_0x28e870['concat'](hr(_0x39c355,_0x50afb7,_0x54baf8)),lr(_0x39c355)&&(_0x59825d['views']['delete'](_0x523267),_0x39c355['query']['_queryParams']['loadsAllData']()||_0x49018a['push'](_0x39c355['query']));}else{const _0x5cb1d7=_0x59825d['views']['get'](_0x3c4844);_0x5cb1d7&&(_0x28e870=_0x28e870['concat'](hr(_0x5cb1d7,_0x50afb7,_0x54baf8)),lr(_0x5cb1d7)&&(_0x59825d['views']['delete'](_0x3c4844),_0x5cb1d7['query']['_queryParams']['loadsAllData']()||_0x49018a['push'](_0x5cb1d7['query'])));}return _0x287602&&!Te(_0x59825d)&&_0x49018a['push'](new(Fu())(_0x22fb52['_repo'],_0x22fb52['_path'])),{'removed':_0x49018a,'events':_0x28e870};}function zo(_0x5c1d63){const _0x4bd972=[];for(const _0x3d8958 of _0x5c1d63['views']['values']())_0x3d8958['query']['_queryParams']['loadsAllData']()||_0x4bd972['push'](_0x3d8958);return _0x4bd972;}function Ee(_0x4771e4,_0x2b59bc){let _0x3ca81d=null;for(const _0x381829 of _0x4771e4['views']['values']())_0x3ca81d=_0x3ca81d||Du(_0x381829,_0x2b59bc);return _0x3ca81d;}function jo(_0x23c0b4,_0x2c7f83){if(_0x2c7f83['_queryParams']['loadsAllData']())return Ln(_0x23c0b4);{const _0x4fa2bf=_0x2c7f83['_queryIdentifier'];return _0x23c0b4['views']['get'](_0x4fa2bf);}}function Ko(_0x3ebb93,_0x2fa58a){return jo(_0x3ebb93,_0x2fa58a)!=null;}function Te(_0xbc4d56){return Ln(_0xbc4d56)!=null;}function Ln(_0x5ab957){for(const _0x4726a7 of _0x5ab957['views']['values']())if(_0x4726a7['query']['_queryParams']['loadsAllData']())return _0x4726a7;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x35864f){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x35864f;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x1aa073){this['listenProvider_']=_0x1aa073,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x2052ae,_0x480637,_0x4344d9,_0x596b84,_0x429863){return ou(_0x2052ae['pendingWriteTree_'],_0x480637,_0x4344d9,_0x596b84,_0x429863),_0x429863?ht(_0x2052ae,new Fe(Ji(),_0x480637,_0x4344d9)):[];}function Gu(_0x38b87e,_0x35f41a,_0x5425ca,_0x19e645){au(_0x38b87e['pendingWriteTree_'],_0x35f41a,_0x5425ca,_0x19e645);const _0x308120=S['fromObject'](_0x5425ca);return ht(_0x38b87e,new nt(Ji(),_0x35f41a,_0x308120));}function pe(_0x181cef,_0x53e13e,_0x1fc22a=!0x1){const _0x130809=cu(_0x181cef['pendingWriteTree_'],_0x53e13e);if(lu(_0x181cef['pendingWriteTree_'],_0x53e13e)){let _0x1be0c4=new S(null);return _0x130809['snap']!=null?_0x1be0c4=_0x1be0c4['set'](w(),!0x0):x(_0x130809['children'],_0x4dd9f5=>{_0x1be0c4=_0x1be0c4['set'](new C(_0x4dd9f5),!0x0);}),ht(_0x181cef,new _n(_0x130809['path'],_0x1be0c4,_0x1fc22a));}else return[];}function $t(_0x41af9b,_0x15e398,_0x2a57b){return ht(_0x41af9b,new Fe(Xi(),_0x15e398,_0x2a57b));}function qu(_0x113d2c,_0x21ca7d,_0x327b36){const _0x1bbd0f=S['fromObject'](_0x327b36);return ht(_0x113d2c,new nt(Xi(),_0x21ca7d,_0x1bbd0f));}function zu(_0x398ff3,_0x3d309b){return ht(_0x398ff3,new Dt(Xi(),_0x3d309b));}function ju(_0x48e963,_0x4caf1e,_0xa6acfc){const _0x5bcd66=rs(_0x48e963,_0xa6acfc);if(_0x5bcd66){const _0x3ab97f=os(_0x5bcd66),_0x5b8be6=_0x3ab97f['path'],_0x33f8a1=_0x3ab97f['queryId'],_0x1076a2=F(_0x5b8be6,_0x4caf1e),_0x3f8864=new Dt(Zi(_0x33f8a1),_0x1076a2);return as(_0x48e963,_0x5b8be6,_0x3f8864);}else return[];}function wn(_0x3838fb,_0x2750c5,_0x3d6e50,_0x533117,_0x32dbb1=!0x1){const _0x47cf71=_0x2750c5['_path'],_0x1e0573=_0x3838fb['syncPointTree_']['get'](_0x47cf71);let _0x218623=[];if(_0x1e0573&&(_0x2750c5['_queryIdentifier']==='default'||Ko(_0x1e0573,_0x2750c5))){const _0x461491=Bu(_0x1e0573,_0x2750c5,_0x3d6e50,_0x533117);Uu(_0x1e0573)&&(_0x3838fb['syncPointTree_']=_0x3838fb['syncPointTree_']['remove'](_0x47cf71));const _0x19ee31=_0x461491['removed'];if(_0x218623=_0x461491['events'],!_0x32dbb1){const _0x58ac15=_0x19ee31['findIndex'](_0x164697=>_0x164697['_queryParams']['loadsAllData']())!==-0x1,_0x18758d=_0x3838fb['syncPointTree_']['findOnPath'](_0x47cf71,(_0x15ead5,_0xe7ae85)=>Te(_0xe7ae85));if(_0x58ac15&&!_0x18758d){const _0x22faa9=_0x3838fb['syncPointTree_']['subtree'](_0x47cf71);if(!_0x22faa9['isEmpty']()){const _0x532a9d=Qu(_0x22faa9);for(let _0x374b8e=0x0;_0x374b8e<_0x532a9d['length'];++_0x374b8e){const _0x485a87=_0x532a9d[_0x374b8e],_0x55b5ce=_0x485a87['query'],_0x5dfcef=Xo(_0x3838fb,_0x485a87);_0x3838fb['listenProvider_']['startListening'](Tt(_0x55b5ce),Mt(_0x3838fb,_0x55b5ce),_0x5dfcef['hashFn'],_0x5dfcef['onComplete']);}}}!_0x18758d&&_0x19ee31['length']>0x0&&!_0x533117&&(_0x58ac15?_0x3838fb['listenProvider_']['stopListening'](Tt(_0x2750c5),null):_0x19ee31['forEach'](_0x1b91f9=>{const _0x34a61a=_0x3838fb['queryToTagMap']['get'](Fn(_0x1b91f9));_0x3838fb['listenProvider_']['stopListening'](Tt(_0x1b91f9),_0x34a61a);}));}Ju(_0x3838fb,_0x19ee31);}return _0x218623;}function Yo(_0x59821a,_0x212a42,_0x2c1d60,_0x3808db){const _0x1448c0=rs(_0x59821a,_0x3808db);if(_0x1448c0!=null){const _0x4042cf=os(_0x1448c0),_0x2a22a2=_0x4042cf['path'],_0x1191b5=_0x4042cf['queryId'],_0x32177a=F(_0x2a22a2,_0x212a42),_0x4edbda=new Fe(Zi(_0x1191b5),_0x32177a,_0x2c1d60);return as(_0x59821a,_0x2a22a2,_0x4edbda);}else return[];}function Ku(_0x4759c5,_0x6a77ce,_0x44b9ae,_0x5f4ec4){const _0x32d572=rs(_0x4759c5,_0x5f4ec4);if(_0x32d572){const _0x5c4523=os(_0x32d572),_0x38bc3b=_0x5c4523['path'],_0x183af2=_0x5c4523['queryId'],_0x5091e8=F(_0x38bc3b,_0x6a77ce),_0x18853e=S['fromObject'](_0x44b9ae),_0x308597=new nt(Zi(_0x183af2),_0x5091e8,_0x18853e);return as(_0x4759c5,_0x38bc3b,_0x308597);}else return[];}function bi(_0x5aba40,_0x307f2a,_0x4d23ec,_0x1121ec=!0x1){const _0x31ae7d=_0x307f2a['_path'];let _0x36321f=null,_0x39348b=!0x1;_0x5aba40['syncPointTree_']['foreachOnPath'](_0x31ae7d,(_0x52c3e6,_0x492648)=>{const _0x2bfc11=F(_0x52c3e6,_0x31ae7d);_0x36321f=_0x36321f||Ee(_0x492648,_0x2bfc11),_0x39348b=_0x39348b||Te(_0x492648);});let _0x4bfad2=_0x5aba40['syncPointTree_']['get'](_0x31ae7d);_0x4bfad2?(_0x39348b=_0x39348b||Te(_0x4bfad2),_0x36321f=_0x36321f||Ee(_0x4bfad2,w())):(_0x4bfad2=new Go(),_0x5aba40['syncPointTree_']=_0x5aba40['syncPointTree_']['set'](_0x31ae7d,_0x4bfad2));let _0x1ff0dd;_0x36321f!=null?_0x1ff0dd=!0x0:(_0x1ff0dd=!0x1,_0x36321f=g['EMPTY_NODE'],_0x5aba40['syncPointTree_']['subtree'](_0x31ae7d)['foreachChild']((_0xd32ad1,_0x33a947)=>{const _0x1c0fcb=Ee(_0x33a947,w());_0x1c0fcb&&(_0x36321f=_0x36321f['updateImmediateChild'](_0xd32ad1,_0x1c0fcb));}));const _0x23cc29=Ko(_0x4bfad2,_0x307f2a);if(!_0x23cc29&&!_0x307f2a['_queryParams']['loadsAllData']()){const _0x16802c=Fn(_0x307f2a);f(!_0x5aba40['queryToTagMap']['has'](_0x16802c),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x32a509=Xu();_0x5aba40['queryToTagMap']['set'](_0x16802c,_0x32a509),_0x5aba40['tagToQueryMap']['set'](_0x32a509,_0x16802c);}const _0x2b1893=Mn(_0x5aba40['pendingWriteTree_'],_0x31ae7d);let _0x2441a3=Wu(_0x4bfad2,_0x307f2a,_0x4d23ec,_0x2b1893,_0x36321f,_0x1ff0dd);if(!_0x23cc29&&!_0x39348b&&!_0x1121ec){const _0xe83a1a=jo(_0x4bfad2,_0x307f2a);_0x2441a3=_0x2441a3['concat'](Zu(_0x5aba40,_0x307f2a,_0xe83a1a));}return _0x2441a3;}function xn(_0x3943b4,_0x4ac892,_0x58f427){const _0x14ae8a=_0x3943b4['pendingWriteTree_'],_0x1f5d04=_0x3943b4['syncPointTree_']['findOnPath'](_0x4ac892,(_0x1b18c5,_0x1fffbf)=>{const _0x48b06e=F(_0x1b18c5,_0x4ac892),_0x2d9dfe=Ee(_0x1fffbf,_0x48b06e);if(_0x2d9dfe)return _0x2d9dfe;});return Uo(_0x14ae8a,_0x4ac892,_0x1f5d04,_0x58f427,!0x0);}function Yu(_0x491a3c,_0x4bff7c){const _0x1e567d=_0x4bff7c['_path'];let _0x559528=null;_0x491a3c['syncPointTree_']['foreachOnPath'](_0x1e567d,(_0x55600d,_0x2a7411)=>{const _0x4b4c02=F(_0x55600d,_0x1e567d);_0x559528=_0x559528||Ee(_0x2a7411,_0x4b4c02);});let _0x5a38c1=_0x491a3c['syncPointTree_']['get'](_0x1e567d);_0x5a38c1?_0x559528=_0x559528||Ee(_0x5a38c1,w()):(_0x5a38c1=new Go(),_0x491a3c['syncPointTree_']=_0x491a3c['syncPointTree_']['set'](_0x1e567d,_0x5a38c1));const _0x16a694=_0x559528!=null,_0x616fdd=_0x16a694?new Ce(_0x559528,!0x0,!0x1):null,_0x2c0bc4=Mn(_0x491a3c['pendingWriteTree_'],_0x4bff7c['_path']),_0x461d8b=qo(_0x5a38c1,_0x4bff7c,_0x2c0bc4,_0x16a694?_0x616fdd['getNode']():g['EMPTY_NODE'],_0x16a694);return Ou(_0x461d8b);}function ht(_0x5b7d36,_0x571ba1){return Qo(_0x571ba1,_0x5b7d36['syncPointTree_'],null,Mn(_0x5b7d36['pendingWriteTree_'],w()));}function Qo(_0x5381e6,_0x19466d,_0xe9337f,_0x4d6c5d){if(v(_0x5381e6['path']))return Jo(_0x5381e6,_0x19466d,_0xe9337f,_0x4d6c5d);{const _0x8fc59a=_0x19466d['get'](w());_0xe9337f==null&&_0x8fc59a!=null&&(_0xe9337f=Ee(_0x8fc59a,w()));let _0x112ce7=[];const _0x1e0fd8=y(_0x5381e6['path']),_0x223871=_0x5381e6['operationForChild'](_0x1e0fd8),_0x8fe99b=_0x19466d['children']['get'](_0x1e0fd8);if(_0x8fe99b&&_0x223871){const _0x4d3fce=_0xe9337f?_0xe9337f['getImmediateChild'](_0x1e0fd8):null,_0x143129=Wo(_0x4d6c5d,_0x1e0fd8);_0x112ce7=_0x112ce7['concat'](Qo(_0x223871,_0x8fe99b,_0x4d3fce,_0x143129));}return _0x8fc59a&&(_0x112ce7=_0x112ce7['concat'](is(_0x8fc59a,_0x5381e6,_0x4d6c5d,_0xe9337f))),_0x112ce7;}}function Jo(_0x2e7ad1,_0x1fb4b,_0x5c0be4,_0x4e8a38){const _0x2273a3=_0x1fb4b['get'](w());_0x5c0be4==null&&_0x2273a3!=null&&(_0x5c0be4=Ee(_0x2273a3,w()));let _0x4436c3=[];return _0x1fb4b['children']['inorderTraversal']((_0xce768,_0x34db9a)=>{const _0x208758=_0x5c0be4?_0x5c0be4['getImmediateChild'](_0xce768):null,_0x22f33c=Wo(_0x4e8a38,_0xce768),_0xd4615b=_0x2e7ad1['operationForChild'](_0xce768);_0xd4615b&&(_0x4436c3=_0x4436c3['concat'](Jo(_0xd4615b,_0x34db9a,_0x208758,_0x22f33c)));}),_0x2273a3&&(_0x4436c3=_0x4436c3['concat'](is(_0x2273a3,_0x2e7ad1,_0x4e8a38,_0x5c0be4))),_0x4436c3;}function Xo(_0x391cf0,_0x77842a){const _0x408efd=_0x77842a['query'],_0x47a241=Mt(_0x391cf0,_0x408efd);return{'hashFn':()=>(Pu(_0x77842a)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x4bfc3e=>{if(_0x4bfc3e==='ok')return _0x47a241?ju(_0x391cf0,_0x408efd['_path'],_0x47a241):zu(_0x391cf0,_0x408efd['_path']);{const _0x187e81=ql(_0x4bfc3e,_0x408efd);return wn(_0x391cf0,_0x408efd,null,_0x187e81);}}};}function Mt(_0x3985ac,_0x15900d){const _0xe9c6e2=Fn(_0x15900d);return _0x3985ac['queryToTagMap']['get'](_0xe9c6e2);}function Fn(_0x4bbd63){return _0x4bbd63['_path']['toString']()+'$'+_0x4bbd63['_queryIdentifier'];}function rs(_0x55a23b,_0x161933){return _0x55a23b['tagToQueryMap']['get'](_0x161933);}function os(_0x1c7763){const _0x210029=_0x1c7763['indexOf']('$');return f(_0x210029!==-0x1&&_0x210029<_0x1c7763['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1c7763['substr'](_0x210029+0x1),'path':new C(_0x1c7763['substr'](0x0,_0x210029))};}function as(_0x44a081,_0x505c30,_0x59e08c){const _0x91fb7b=_0x44a081['syncPointTree_']['get'](_0x505c30);f(_0x91fb7b,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x476ff4=Mn(_0x44a081['pendingWriteTree_'],_0x505c30);return is(_0x91fb7b,_0x59e08c,_0x476ff4,null);}function Qu(_0x485097){return _0x485097['fold']((_0x235464,_0x5920f8,_0xa36ae9)=>{if(_0x5920f8&&Te(_0x5920f8))return[Ln(_0x5920f8)];{let _0x4f947f=[];return _0x5920f8&&(_0x4f947f=zo(_0x5920f8)),x(_0xa36ae9,(_0x749c72,_0x337266)=>{_0x4f947f=_0x4f947f['concat'](_0x337266);}),_0x4f947f;}});}function Tt(_0x340444){return _0x340444['_queryParams']['loadsAllData']()&&!_0x340444['_queryParams']['isDefault']()?new(Hu())(_0x340444['_repo'],_0x340444['_path']):_0x340444;}function Ju(_0x720c92,_0x315957){for(let _0x23c326=0x0;_0x23c326<_0x315957['length'];++_0x23c326){const _0x1d8af3=_0x315957[_0x23c326];if(!_0x1d8af3['_queryParams']['loadsAllData']()){const _0x5b7116=Fn(_0x1d8af3),_0xd3c31d=_0x720c92['queryToTagMap']['get'](_0x5b7116);_0x720c92['queryToTagMap']['delete'](_0x5b7116),_0x720c92['tagToQueryMap']['delete'](_0xd3c31d);}}}function Xu(){return $u++;}function Zu(_0x3734de,_0x3d0532,_0x482382){const _0x4beb2b=_0x3d0532['_path'],_0xbb59d1=Mt(_0x3734de,_0x3d0532),_0x1c5310=Xo(_0x3734de,_0x482382),_0x2cdc27=_0x3734de['listenProvider_']['startListening'](Tt(_0x3d0532),_0xbb59d1,_0x1c5310['hashFn'],_0x1c5310['onComplete']),_0x45eb4f=_0x3734de['syncPointTree_']['subtree'](_0x4beb2b);if(_0xbb59d1)f(!Te(_0x45eb4f['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3ddd64=_0x45eb4f['fold']((_0x25cfb6,_0x23f7b7,_0xbee5c1)=>{if(!v(_0x25cfb6)&&_0x23f7b7&&Te(_0x23f7b7))return[Ln(_0x23f7b7)['query']];{let _0x2eef99=[];return _0x23f7b7&&(_0x2eef99=_0x2eef99['concat'](zo(_0x23f7b7)['map'](_0xd95cc0=>_0xd95cc0['query']))),x(_0xbee5c1,(_0x32878d,_0x2c10a1)=>{_0x2eef99=_0x2eef99['concat'](_0x2c10a1);}),_0x2eef99;}});for(let _0x257ca3=0x0;_0x257ca3<_0x3ddd64['length'];++_0x257ca3){const _0x10a66f=_0x3ddd64[_0x257ca3];_0x3734de['listenProvider_']['stopListening'](Tt(_0x10a66f),Mt(_0x3734de,_0x10a66f));}}return _0x2cdc27;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x1873a5){this['node_']=_0x1873a5;}['getImmediateChild'](_0x4f48ba){const _0x48f294=this['node_']['getImmediateChild'](_0x4f48ba);return new cs(_0x48f294);}['node'](){return this['node_'];}}class ls{constructor(_0x3d3319,_0x5d3539){this['syncTree_']=_0x3d3319,this['path_']=_0x5d3539;}['getImmediateChild'](_0x1f69d8){const _0x33c61d=A(this['path_'],_0x1f69d8);return new ls(this['syncTree_'],_0x33c61d);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x5d8e1d){return _0x5d8e1d=_0x5d8e1d||{},_0x5d8e1d['timestamp']=_0x5d8e1d['timestamp']||new Date()['getTime'](),_0x5d8e1d;},fr=function(_0x1efc97,_0x3ff769,_0x26b106){if(!_0x1efc97||typeof _0x1efc97!='object')return _0x1efc97;if(f('.sv'in _0x1efc97,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1efc97['.sv']=='string')return td(_0x1efc97['.sv'],_0x3ff769,_0x26b106);if(typeof _0x1efc97['.sv']=='object')return nd(_0x1efc97['.sv'],_0x3ff769);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1efc97,null,0x2));},td=function(_0x4991cf,_0x52341a,_0x2b01d9){switch(_0x4991cf){case'timestamp':return _0x2b01d9['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x4991cf);}},nd=function(_0x18f53b,_0x3990c5,_0x16c382){_0x18f53b['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x18f53b,null,0x2));const _0x779091=_0x18f53b['increment'];typeof _0x779091!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x779091);const _0x5308ab=_0x3990c5['node']();if(f(_0x5308ab!==null&&typeof _0x5308ab<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5308ab['isLeafNode']())return _0x779091;const _0x4c5626=_0x5308ab['getValue']();return typeof _0x4c5626!='number'?_0x779091:_0x4c5626+_0x779091;},Zo=function(_0xf92eba,_0x1f9521,_0x227c8e,_0x21b25f){return us(_0x1f9521,new ls(_0x227c8e,_0xf92eba),_0x21b25f);},hs=function(_0x46e082,_0x39c4f9,_0x52fba8){return us(_0x46e082,new cs(_0x39c4f9),_0x52fba8);};function us(_0x1cbd88,_0x5d5582,_0x4c5ef8){const _0x3d48e1=_0x1cbd88['getPriority']()['val'](),_0xe5fd7a=fr(_0x3d48e1,_0x5d5582['getImmediateChild']('.priority'),_0x4c5ef8);let _0x349018;if(_0x1cbd88['isLeafNode']()){const _0x53d994=_0x1cbd88,_0x54008d=fr(_0x53d994['getValue'](),_0x5d5582,_0x4c5ef8);return _0x54008d!==_0x53d994['getValue']()||_0xe5fd7a!==_0x53d994['getPriority']()['val']()?new D(_0x54008d,N(_0xe5fd7a)):_0x1cbd88;}else{const _0x404536=_0x1cbd88;return _0x349018=_0x404536,_0xe5fd7a!==_0x404536['getPriority']()['val']()&&(_0x349018=_0x349018['updatePriority'](new D(_0xe5fd7a))),_0x404536['forEachChild'](R,(_0x5f3515,_0x560205)=>{const _0x5c6292=us(_0x560205,_0x5d5582['getImmediateChild'](_0x5f3515),_0x4c5ef8);_0x5c6292!==_0x560205&&(_0x349018=_0x349018['updateImmediateChild'](_0x5f3515,_0x5c6292));}),_0x349018;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x16ade1='',_0x112d1d=null,_0x186cdd={'children':{},'childCount':0x0}){this['name']=_0x16ade1,this['parent']=_0x112d1d,this['node']=_0x186cdd;}}function Un(_0x151588,_0xa3a6a0){let _0x4f2573=_0xa3a6a0 instanceof C?_0xa3a6a0:new C(_0xa3a6a0),_0x14d5d8=_0x151588,_0x3be06a=y(_0x4f2573);for(;_0x3be06a!==null;){const _0x1f79b0=Oe(_0x14d5d8['node']['children'],_0x3be06a)||{'children':{},'childCount':0x0};_0x14d5d8=new ds(_0x3be06a,_0x14d5d8,_0x1f79b0),_0x4f2573=b(_0x4f2573),_0x3be06a=y(_0x4f2573);}return _0x14d5d8;}function Ge(_0x3685ae){return _0x3685ae['node']['value'];}function fs(_0x261410,_0x29c95a){_0x261410['node']['value']=_0x29c95a,Ri(_0x261410);}function ea(_0x4084a5){return _0x4084a5['node']['childCount']>0x0;}function id(_0x58ba64){return Ge(_0x58ba64)===void 0x0&&!ea(_0x58ba64);}function Wn(_0x26cf99,_0x58b289){x(_0x26cf99['node']['children'],(_0x4265d1,_0x140fba)=>{_0x58b289(new ds(_0x4265d1,_0x26cf99,_0x140fba));});}function ta(_0x52d41b,_0x3bb1ea,_0x308774,_0x1fa152){_0x308774&&_0x3bb1ea(_0x52d41b),Wn(_0x52d41b,_0x57d009=>{ta(_0x57d009,_0x3bb1ea,!0x0);});}function sd(_0xb7725e,_0x51d4b4,_0x4e9c08){let _0x28e681=_0xb7725e['parent'];for(;_0x28e681!==null;){if(_0x51d4b4(_0x28e681))return!0x0;_0x28e681=_0x28e681['parent'];}return!0x1;}function Gt(_0x5b4fa2){return new C(_0x5b4fa2['parent']===null?_0x5b4fa2['name']:Gt(_0x5b4fa2['parent'])+'/'+_0x5b4fa2['name']);}function Ri(_0x4fd9c0){_0x4fd9c0['parent']!==null&&rd(_0x4fd9c0['parent'],_0x4fd9c0['name'],_0x4fd9c0);}function rd(_0x43c224,_0x21a24f,_0x2c4ef3){const _0x4ea7df=id(_0x2c4ef3),_0x3f159c=Y(_0x43c224['node']['children'],_0x21a24f);_0x4ea7df&&_0x3f159c?(delete _0x43c224['node']['children'][_0x21a24f],_0x43c224['node']['childCount']--,Ri(_0x43c224)):!_0x4ea7df&&!_0x3f159c&&(_0x43c224['node']['children'][_0x21a24f]=_0x2c4ef3['node'],_0x43c224['node']['childCount']++,Ri(_0x43c224));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x15b9b4){return typeof _0x15b9b4=='string'&&_0x15b9b4['length']!==0x0&&!od['test'](_0x15b9b4);},na=function(_0x46aff2){return typeof _0x46aff2=='string'&&_0x46aff2['length']!==0x0&&!ad['test'](_0x46aff2);},cd=function(_0x39cd96){return _0x39cd96&&(_0x39cd96=_0x39cd96['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x39cd96);},Cn=function(_0xe53a1f){return _0xe53a1f===null||typeof _0xe53a1f=='string'||typeof _0xe53a1f=='number'&&!Wi(_0xe53a1f)||_0xe53a1f&&typeof _0xe53a1f=='object'&&Y(_0xe53a1f,'.sv');},qt=function(_0x1d2fec,_0x12bd64,_0x5de901,_0x8f9cec){_0x8f9cec&&_0x12bd64===void 0x0||zt(Nn(_0x1d2fec,'value'),_0x12bd64,_0x5de901);},zt=function(_0x1a0aed,_0x58c96d,_0x1d140f){const _0x9bcb98=_0x1d140f instanceof C?new Sh(_0x1d140f,_0x1a0aed):_0x1d140f;if(_0x58c96d===void 0x0)throw new Error(_0x1a0aed+'contains\x20undefined\x20'+Ne(_0x9bcb98));if(typeof _0x58c96d=='function')throw new Error(_0x1a0aed+'contains\x20a\x20function\x20'+Ne(_0x9bcb98)+'\x20with\x20contents\x20=\x20'+_0x58c96d['toString']());if(Wi(_0x58c96d))throw new Error(_0x1a0aed+'contains\x20'+_0x58c96d['toString']()+'\x20'+Ne(_0x9bcb98));if(typeof _0x58c96d=='string'&&_0x58c96d['length']>oi/0x3&&Pn(_0x58c96d)>oi)throw new Error(_0x1a0aed+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x9bcb98)+'\x20(\x27'+_0x58c96d['substring'](0x0,0x32)+'...\x27)');if(_0x58c96d&&typeof _0x58c96d=='object'){let _0x20bc07=!0x1,_0x2c13c5=!0x1;if(x(_0x58c96d,(_0x578f91,_0x3c4934)=>{if(_0x578f91==='.value')_0x20bc07=!0x0;else{if(_0x578f91!=='.priority'&&_0x578f91!=='.sv'&&(_0x2c13c5=!0x0,!ps(_0x578f91)))throw new Error(_0x1a0aed+'\x20contains\x20an\x20invalid\x20key\x20('+_0x578f91+')\x20'+Ne(_0x9bcb98)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x9bcb98,_0x578f91),zt(_0x1a0aed,_0x3c4934,_0x9bcb98),Rh(_0x9bcb98);}),_0x20bc07&&_0x2c13c5)throw new Error(_0x1a0aed+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x9bcb98)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x20d26a,_0x57760d){let _0x1dc788,_0x33fbd6;for(_0x1dc788=0x0;_0x1dc788<_0x57760d['length'];_0x1dc788++){_0x33fbd6=_0x57760d[_0x1dc788];const _0x3fb968=kt(_0x33fbd6);for(let _0x486500=0x0;_0x486500<_0x3fb968['length'];_0x486500++)if(!(_0x3fb968[_0x486500]==='.priority'&&_0x486500===_0x3fb968['length']-0x1)){if(!ps(_0x3fb968[_0x486500]))throw new Error(_0x20d26a+'contains\x20an\x20invalid\x20key\x20('+_0x3fb968[_0x486500]+')\x20in\x20path\x20'+_0x33fbd6['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x57760d['sort'](Th);let _0x5c6ccf=null;for(_0x1dc788=0x0;_0x1dc788<_0x57760d['length'];_0x1dc788++){if(_0x33fbd6=_0x57760d[_0x1dc788],_0x5c6ccf!==null&&$(_0x5c6ccf,_0x33fbd6))throw new Error(_0x20d26a+'contains\x20a\x20path\x20'+_0x5c6ccf['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x33fbd6['toString']());_0x5c6ccf=_0x33fbd6;}},hd=function(_0x5883c6,_0x2ac090,_0xb61a6a,_0xd0011e){const _0x45336f=Nn(_0x5883c6,'values');if(!(_0x2ac090&&typeof _0x2ac090=='object')||Array['isArray'](_0x2ac090))throw new Error(_0x45336f+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x18a889=[];x(_0x2ac090,(_0x8a8488,_0x1c1538)=>{const _0x1080d1=new C(_0x8a8488);if(zt(_0x45336f,_0x1c1538,A(_0xb61a6a,_0x1080d1)),Gi(_0x1080d1)==='.priority'&&!Cn(_0x1c1538))throw new Error(_0x45336f+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x1080d1['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x18a889['push'](_0x1080d1);}),ld(_0x45336f,_0x18a889);},_s=function(_0xde7113,_0x349499,_0x1056c6,_0x2ea159){if(!na(_0x1056c6))throw new Error(Nn(_0xde7113,_0x349499)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1056c6+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x322942,_0x185e1e,_0x155649,_0x2c32cd){_0x155649&&(_0x155649=_0x155649['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x322942,_0x185e1e,_0x155649);},gs=function(_0x486ad5,_0x4bc6a1){if(y(_0x4bc6a1)==='.info')throw new Error(_0x486ad5+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x1452da,_0x2389f6){const _0x5188b1=_0x2389f6['path']['toString']();if(typeof _0x2389f6['repoInfo']['host']!='string'||_0x2389f6['repoInfo']['host']['length']===0x0||!ps(_0x2389f6['repoInfo']['namespace'])&&_0x2389f6['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x5188b1['length']!==0x0&&!cd(_0x5188b1))throw new Error(Nn(_0x1452da,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x368820,_0x7c02bc){let _0x1619af=null;for(let _0x316dcc=0x0;_0x316dcc<_0x7c02bc['length'];_0x316dcc++){const _0x285589=_0x7c02bc[_0x316dcc],_0x193ca5=_0x285589['getPath']();_0x1619af!==null&&!qi(_0x193ca5,_0x1619af['path'])&&(_0x368820['eventLists_']['push'](_0x1619af),_0x1619af=null),_0x1619af===null&&(_0x1619af={'events':[],'path':_0x193ca5}),_0x1619af['events']['push'](_0x285589);}_0x1619af&&_0x368820['eventLists_']['push'](_0x1619af);}function ia(_0x482df4,_0x19147d,_0x48d7eb){Bn(_0x482df4,_0x48d7eb),sa(_0x482df4,_0x159010=>qi(_0x159010,_0x19147d));}function V(_0x1317fa,_0x9cb55f,_0x338bb7){Bn(_0x1317fa,_0x338bb7),sa(_0x1317fa,_0x2cab61=>$(_0x2cab61,_0x9cb55f)||$(_0x9cb55f,_0x2cab61));}function sa(_0x2bf0ad,_0x285c87){_0x2bf0ad['recursionDepth_']++;let _0x42f06a=!0x0;for(let _0x27b62c=0x0;_0x27b62c<_0x2bf0ad['eventLists_']['length'];_0x27b62c++){const _0x155e17=_0x2bf0ad['eventLists_'][_0x27b62c];if(_0x155e17){const _0x564c1f=_0x155e17['path'];_0x285c87(_0x564c1f)?(pd(_0x2bf0ad['eventLists_'][_0x27b62c]),_0x2bf0ad['eventLists_'][_0x27b62c]=null):_0x42f06a=!0x1;}}_0x42f06a&&(_0x2bf0ad['eventLists_']=[]),_0x2bf0ad['recursionDepth_']--;}function pd(_0xa3f3c){for(let _0x3bd564=0x0;_0x3bd564<_0xa3f3c['events']['length'];_0x3bd564++){const _0x23a6b7=_0xa3f3c['events'][_0x3bd564];if(_0x23a6b7!==null){_0xa3f3c['events'][_0x3bd564]=null;const _0x335374=_0x23a6b7['getEventRunner']();Et&&L('event:\x20'+_0x23a6b7['toString']()),lt(_0x335374);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x16b5ae,_0x2bc00b,_0x25cdcc,_0x6de5f){this['repoInfo_']=_0x16b5ae,this['forceRestClient_']=_0x2bc00b,this['authTokenProvider_']=_0x25cdcc,this['appCheckProvider_']=_0x6de5f,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x8df95f,_0x114cfa,_0x8f6d2f){if(_0x8df95f['stats_']=Hi(_0x8df95f['repoInfo_']),_0x8df95f['forceRestClient_']||Yl())_0x8df95f['server_']=new fn(_0x8df95f['repoInfo_'],(_0x1f1ab2,_0xe86160,_0x21940c,_0xedebee)=>{pr(_0x8df95f,_0x1f1ab2,_0xe86160,_0x21940c,_0xedebee);},_0x8df95f['authTokenProvider_'],_0x8df95f['appCheckProvider_']),setTimeout(()=>_r(_0x8df95f,!0x0),0x0);else{if(typeof _0x8f6d2f<'u'&&_0x8f6d2f!==null){if(typeof _0x8f6d2f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x8f6d2f);}catch(_0x1ce81f){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1ce81f);}}_0x8df95f['persistentConnection_']=new ie(_0x8df95f['repoInfo_'],_0x114cfa,(_0x1a8eee,_0x1c8007,_0x291fa5,_0x3fa310)=>{pr(_0x8df95f,_0x1a8eee,_0x1c8007,_0x291fa5,_0x3fa310);},_0x25f148=>{_r(_0x8df95f,_0x25f148);},_0x304956=>{yd(_0x8df95f,_0x304956);},_0x8df95f['authTokenProvider_'],_0x8df95f['appCheckProvider_'],_0x8f6d2f),_0x8df95f['server_']=_0x8df95f['persistentConnection_'];}_0x8df95f['authTokenProvider_']['addTokenChangeListener'](_0x2906af=>{_0x8df95f['server_']['refreshAuthToken'](_0x2906af);}),_0x8df95f['appCheckProvider_']['addTokenChangeListener'](_0x8611d9=>{_0x8df95f['server_']['refreshAppCheckToken'](_0x8611d9['token']);}),_0x8df95f['statsReporter_']=eh(_0x8df95f['repoInfo_'],()=>new eu(_0x8df95f['stats_'],_0x8df95f['server_'])),_0x8df95f['infoData_']=new Yh(),_0x8df95f['infoSyncTree_']=new dr({'startListening':(_0xa2d866,_0x40bd3b,_0x56033b,_0x33ac42)=>{let _0x1d2b02=[];const _0x26ad97=_0x8df95f['infoData_']['getNode'](_0xa2d866['_path']);return _0x26ad97['isEmpty']()||(_0x1d2b02=$t(_0x8df95f['infoSyncTree_'],_0xa2d866['_path'],_0x26ad97),setTimeout(()=>{_0x33ac42('ok');},0x0)),_0x1d2b02;},'stopListening':()=>{}}),ms(_0x8df95f,'connected',!0x1),_0x8df95f['serverSyncTree_']=new dr({'startListening':(_0x2de99d,_0x4fccc6,_0xc944e6,_0x3407f0)=>(_0x8df95f['server_']['listen'](_0x2de99d,_0xc944e6,_0x4fccc6,(_0x49f05d,_0x368b70)=>{const _0x498414=_0x3407f0(_0x49f05d,_0x368b70);V(_0x8df95f['eventQueue_'],_0x2de99d['_path'],_0x498414);}),[]),'stopListening':(_0x36f32d,_0x2c574c)=>{_0x8df95f['server_']['unlisten'](_0x36f32d,_0x2c574c);}});}function oa(_0x473e55){const _0x13ca66=_0x473e55['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x13ca66;}function jt(_0x2836e1){return ed({'timestamp':oa(_0x2836e1)});}function pr(_0x354749,_0x1fdd40,_0x6e4228,_0x3a6a31,_0x12218a){_0x354749['dataUpdateCount']++;const _0x13dd7e=new C(_0x1fdd40);_0x6e4228=_0x354749['interceptServerDataCallback_']?_0x354749['interceptServerDataCallback_'](_0x1fdd40,_0x6e4228):_0x6e4228;let _0x283b9b=[];if(_0x12218a){if(_0x3a6a31){const _0x25a1d9=ln(_0x6e4228,_0x368bf7=>N(_0x368bf7));_0x283b9b=Ku(_0x354749['serverSyncTree_'],_0x13dd7e,_0x25a1d9,_0x12218a);}else{const _0x1292d9=N(_0x6e4228);_0x283b9b=Yo(_0x354749['serverSyncTree_'],_0x13dd7e,_0x1292d9,_0x12218a);}}else{if(_0x3a6a31){const _0x2274a4=ln(_0x6e4228,_0x5bf951=>N(_0x5bf951));_0x283b9b=qu(_0x354749['serverSyncTree_'],_0x13dd7e,_0x2274a4);}else{const _0x58ae76=N(_0x6e4228);_0x283b9b=$t(_0x354749['serverSyncTree_'],_0x13dd7e,_0x58ae76);}}let _0x143e43=_0x13dd7e;_0x283b9b['length']>0x0&&(_0x143e43=st(_0x354749,_0x13dd7e)),V(_0x354749['eventQueue_'],_0x143e43,_0x283b9b);}function _r(_0x15b6d2,_0x1b35bc){ms(_0x15b6d2,'connected',_0x1b35bc),_0x1b35bc===!0x1&&wd(_0x15b6d2);}function yd(_0x385bf1,_0x504b9e){x(_0x504b9e,(_0x14e532,_0x150a4b)=>{ms(_0x385bf1,_0x14e532,_0x150a4b);});}function ms(_0x5b2343,_0x664910,_0x125cd5){const _0x7eddd3=new C('/.info/'+_0x664910),_0x5c9832=N(_0x125cd5);_0x5b2343['infoData_']['updateSnapshot'](_0x7eddd3,_0x5c9832);const _0x5921da=$t(_0x5b2343['infoSyncTree_'],_0x7eddd3,_0x5c9832);V(_0x5b2343['eventQueue_'],_0x7eddd3,_0x5921da);}function Vn(_0x40a711){return _0x40a711['nextWriteId_']++;}function vd(_0x304a4d,_0x4fcd06,_0x1dddfe){const _0x4e22b5=Yu(_0x304a4d['serverSyncTree_'],_0x4fcd06);return _0x4e22b5!=null?Promise['resolve'](_0x4e22b5):_0x304a4d['server_']['get'](_0x4fcd06)['then'](_0x373208=>{const _0x32f879=N(_0x373208)['withIndex'](_0x4fcd06['_queryParams']['getIndex']());bi(_0x304a4d['serverSyncTree_'],_0x4fcd06,_0x1dddfe,!0x0);let _0x47710f;if(_0x4fcd06['_queryParams']['loadsAllData']())_0x47710f=$t(_0x304a4d['serverSyncTree_'],_0x4fcd06['_path'],_0x32f879);else{const _0x558d2d=Mt(_0x304a4d['serverSyncTree_'],_0x4fcd06);_0x47710f=Yo(_0x304a4d['serverSyncTree_'],_0x4fcd06['_path'],_0x32f879,_0x558d2d);}return V(_0x304a4d['eventQueue_'],_0x4fcd06['_path'],_0x47710f),wn(_0x304a4d['serverSyncTree_'],_0x4fcd06,_0x1dddfe,null,!0x0),_0x32f879;},_0x48a88f=>(ut(_0x304a4d,'get\x20for\x20query\x20'+O(_0x4fcd06)+'\x20failed:\x20'+_0x48a88f),Promise['reject'](new Error(_0x48a88f))));}function Ed(_0xc56b6b,_0xe24aa5,_0x11aeca,_0x8ca9db,_0x172183){ut(_0xc56b6b,'set',{'path':_0xe24aa5['toString'](),'value':_0x11aeca,'priority':_0x8ca9db});const _0x169154=jt(_0xc56b6b),_0x3a95d9=N(_0x11aeca,_0x8ca9db),_0x289f0f=xn(_0xc56b6b['serverSyncTree_'],_0xe24aa5),_0xf753de=hs(_0x3a95d9,_0x289f0f,_0x169154),_0xb12c5a=Vn(_0xc56b6b),_0x1fb395=ss(_0xc56b6b['serverSyncTree_'],_0xe24aa5,_0xf753de,_0xb12c5a,!0x0);Bn(_0xc56b6b['eventQueue_'],_0x1fb395),_0xc56b6b['server_']['put'](_0xe24aa5['toString'](),_0x3a95d9['val'](!0x0),(_0x4c7c0b,_0x36a8fe)=>{const _0x2ec8f9=_0x4c7c0b==='ok';_0x2ec8f9||U('set\x20at\x20'+_0xe24aa5+'\x20failed:\x20'+_0x4c7c0b);const _0x4e3d0f=pe(_0xc56b6b['serverSyncTree_'],_0xb12c5a,!_0x2ec8f9);V(_0xc56b6b['eventQueue_'],_0xe24aa5,_0x4e3d0f),Ai(_0xc56b6b,_0x172183,_0x4c7c0b,_0x36a8fe);});const _0x5a7912=vs(_0xc56b6b,_0xe24aa5);st(_0xc56b6b,_0x5a7912),V(_0xc56b6b['eventQueue_'],_0x5a7912,[]);}function Id(_0x4a54a6,_0x258fff,_0x3150a7,_0x4d6be1){ut(_0x4a54a6,'update',{'path':_0x258fff['toString'](),'value':_0x3150a7});let _0x3a605c=!0x0;const _0x1ec7dd=jt(_0x4a54a6),_0x20b94b={};if(x(_0x3150a7,(_0x20c186,_0x2f698f)=>{_0x3a605c=!0x1,_0x20b94b[_0x20c186]=Zo(A(_0x258fff,_0x20c186),N(_0x2f698f),_0x4a54a6['serverSyncTree_'],_0x1ec7dd);}),_0x3a605c)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x4a54a6,_0x4d6be1,'ok',void 0x0);else{const _0x4305d4=Vn(_0x4a54a6),_0x54eb99=Gu(_0x4a54a6['serverSyncTree_'],_0x258fff,_0x20b94b,_0x4305d4);Bn(_0x4a54a6['eventQueue_'],_0x54eb99),_0x4a54a6['server_']['merge'](_0x258fff['toString'](),_0x3150a7,(_0x56ebb1,_0x259632)=>{const _0x1c436c=_0x56ebb1==='ok';_0x1c436c||U('update\x20at\x20'+_0x258fff+'\x20failed:\x20'+_0x56ebb1);const _0xe7150b=pe(_0x4a54a6['serverSyncTree_'],_0x4305d4,!_0x1c436c),_0x201b48=_0xe7150b['length']>0x0?st(_0x4a54a6,_0x258fff):_0x258fff;V(_0x4a54a6['eventQueue_'],_0x201b48,_0xe7150b),Ai(_0x4a54a6,_0x4d6be1,_0x56ebb1,_0x259632);}),x(_0x3150a7,_0x4ecbd2=>{const _0x2f1727=vs(_0x4a54a6,A(_0x258fff,_0x4ecbd2));st(_0x4a54a6,_0x2f1727);}),V(_0x4a54a6['eventQueue_'],_0x258fff,[]);}}function wd(_0x1105e2){ut(_0x1105e2,'onDisconnectEvents');const _0x275c41=jt(_0x1105e2),_0xeafd9c=pn();Ei(_0x1105e2['onDisconnect_'],w(),(_0x254c56,_0x29d0ff)=>{const _0x5b433f=Zo(_0x254c56,_0x29d0ff,_0x1105e2['serverSyncTree_'],_0x275c41);Mo(_0xeafd9c,_0x254c56,_0x5b433f);});let _0x282d51=[];Ei(_0xeafd9c,w(),(_0x1a44c1,_0x26097e)=>{_0x282d51=_0x282d51['concat']($t(_0x1105e2['serverSyncTree_'],_0x1a44c1,_0x26097e));const _0x261155=vs(_0x1105e2,_0x1a44c1);st(_0x1105e2,_0x261155);}),_0x1105e2['onDisconnect_']=pn(),V(_0x1105e2['eventQueue_'],w(),_0x282d51);}function Cd(_0x1522ed,_0x2377f2,_0x4e9dda){let _0x216066;y(_0x2377f2['_path'])==='.info'?_0x216066=bi(_0x1522ed['infoSyncTree_'],_0x2377f2,_0x4e9dda):_0x216066=bi(_0x1522ed['serverSyncTree_'],_0x2377f2,_0x4e9dda),ia(_0x1522ed['eventQueue_'],_0x2377f2['_path'],_0x216066);}function Td(_0x1f8af3,_0x1076c1,_0x4e55d2){let _0x1eef97;y(_0x1076c1['_path'])==='.info'?_0x1eef97=wn(_0x1f8af3['infoSyncTree_'],_0x1076c1,_0x4e55d2):_0x1eef97=wn(_0x1f8af3['serverSyncTree_'],_0x1076c1,_0x4e55d2),ia(_0x1f8af3['eventQueue_'],_0x1076c1['_path'],_0x1eef97);}function aa(_0x15980a){_0x15980a['persistentConnection_']&&_0x15980a['persistentConnection_']['interrupt'](ra);}function Sd(_0x5d17aa){_0x5d17aa['persistentConnection_']&&_0x5d17aa['persistentConnection_']['resume'](ra);}function ut(_0x579300,..._0x2bb234){let _0xa2641d='';_0x579300['persistentConnection_']&&(_0xa2641d=_0x579300['persistentConnection_']['id']+':'),L(_0xa2641d,..._0x2bb234);}function Ai(_0x39082b,_0x1fb07b,_0x1a9590,_0x297472){_0x1fb07b&&lt(()=>{if(_0x1a9590==='ok')_0x1fb07b(null);else{const _0x13cd31=(_0x1a9590||'error')['toUpperCase']();let _0x499ee1=_0x13cd31;_0x297472&&(_0x499ee1+=':\x20'+_0x297472);const _0x17eff3=new Error(_0x499ee1);_0x17eff3['code']=_0x13cd31,_0x1fb07b(_0x17eff3);}});}function bd(_0x5da1b0,_0x45bd77,_0x375221,_0x7d77b8,_0x3e5ccc,_0x483dd4){ut(_0x5da1b0,'transaction\x20on\x20'+_0x45bd77);const _0x34d7f8={'path':_0x45bd77,'update':_0x375221,'onComplete':_0x7d77b8,'status':null,'order':to(),'applyLocally':_0x483dd4,'retryCount':0x0,'unwatcher':_0x3e5ccc,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5e6c17=ys(_0x5da1b0,_0x45bd77,void 0x0);_0x34d7f8['currentInputSnapshot']=_0x5e6c17;const _0x275d54=_0x34d7f8['update'](_0x5e6c17['val']());if(_0x275d54===void 0x0)_0x34d7f8['unwatcher'](),_0x34d7f8['currentOutputSnapshotRaw']=null,_0x34d7f8['currentOutputSnapshotResolved']=null,_0x34d7f8['onComplete']&&_0x34d7f8['onComplete'](null,!0x1,_0x34d7f8['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x275d54,_0x34d7f8['path']),_0x34d7f8['status']=0x0;const _0x472db2=Un(_0x5da1b0['transactionQueueTree_'],_0x45bd77),_0x5ec832=Ge(_0x472db2)||[];_0x5ec832['push'](_0x34d7f8),fs(_0x472db2,_0x5ec832);let _0x14cab7;typeof _0x275d54=='object'&&_0x275d54!==null&&Y(_0x275d54,'.priority')?(_0x14cab7=Oe(_0x275d54,'.priority'),f(Cn(_0x14cab7),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x14cab7=(xn(_0x5da1b0['serverSyncTree_'],_0x45bd77)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x212ac6=jt(_0x5da1b0),_0xad691b=N(_0x275d54,_0x14cab7),_0x538c30=hs(_0xad691b,_0x5e6c17,_0x212ac6);_0x34d7f8['currentOutputSnapshotRaw']=_0xad691b,_0x34d7f8['currentOutputSnapshotResolved']=_0x538c30,_0x34d7f8['currentWriteId']=Vn(_0x5da1b0);const _0x122cfb=ss(_0x5da1b0['serverSyncTree_'],_0x45bd77,_0x538c30,_0x34d7f8['currentWriteId'],_0x34d7f8['applyLocally']);V(_0x5da1b0['eventQueue_'],_0x45bd77,_0x122cfb),Hn(_0x5da1b0,_0x5da1b0['transactionQueueTree_']);}}function ys(_0x50169a,_0x277629,_0x7f49d6){return xn(_0x50169a['serverSyncTree_'],_0x277629,_0x7f49d6)||g['EMPTY_NODE'];}function Hn(_0x2aa445,_0x391381=_0x2aa445['transactionQueueTree_']){if(_0x391381||$n(_0x2aa445,_0x391381),Ge(_0x391381)){const _0x5de3b6=la(_0x2aa445,_0x391381);f(_0x5de3b6['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5de3b6['every'](_0x19f361=>_0x19f361['status']===0x0)&&Rd(_0x2aa445,Gt(_0x391381),_0x5de3b6);}else ea(_0x391381)&&Wn(_0x391381,_0x873f58=>{Hn(_0x2aa445,_0x873f58);});}function Rd(_0x23f82d,_0x4f444f,_0x54aa2d){const _0x291d9c=_0x54aa2d['map'](_0x89a9df=>_0x89a9df['currentWriteId']),_0x4a2a91=ys(_0x23f82d,_0x4f444f,_0x291d9c);let _0x4682e6=_0x4a2a91;const _0x2258ad=_0x4a2a91['hash']();for(let _0x47f38a=0x0;_0x47f38a<_0x54aa2d['length'];_0x47f38a++){const _0x3989b8=_0x54aa2d[_0x47f38a];f(_0x3989b8['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x3989b8['status']=0x1,_0x3989b8['retryCount']++;const _0x3f6167=F(_0x4f444f,_0x3989b8['path']);_0x4682e6=_0x4682e6['updateChild'](_0x3f6167,_0x3989b8['currentOutputSnapshotRaw']);}const _0x501b19=_0x4682e6['val'](!0x0),_0x1828ee=_0x4f444f;_0x23f82d['server_']['put'](_0x1828ee['toString'](),_0x501b19,_0x4eb188=>{ut(_0x23f82d,'transaction\x20put\x20response',{'path':_0x1828ee['toString'](),'status':_0x4eb188});let _0x1d87de=[];if(_0x4eb188==='ok'){const _0x56ed65=[];for(let _0x4200dd=0x0;_0x4200dd<_0x54aa2d['length'];_0x4200dd++)_0x54aa2d[_0x4200dd]['status']=0x2,_0x1d87de=_0x1d87de['concat'](pe(_0x23f82d['serverSyncTree_'],_0x54aa2d[_0x4200dd]['currentWriteId'])),_0x54aa2d[_0x4200dd]['onComplete']&&_0x56ed65['push'](()=>_0x54aa2d[_0x4200dd]['onComplete'](null,!0x0,_0x54aa2d[_0x4200dd]['currentOutputSnapshotResolved'])),_0x54aa2d[_0x4200dd]['unwatcher']();$n(_0x23f82d,Un(_0x23f82d['transactionQueueTree_'],_0x4f444f)),Hn(_0x23f82d,_0x23f82d['transactionQueueTree_']),V(_0x23f82d['eventQueue_'],_0x4f444f,_0x1d87de);for(let _0x5cc675=0x0;_0x5cc675<_0x56ed65['length'];_0x5cc675++)lt(_0x56ed65[_0x5cc675]);}else{if(_0x4eb188==='datastale'){for(let _0x518ada=0x0;_0x518ada<_0x54aa2d['length'];_0x518ada++)_0x54aa2d[_0x518ada]['status']===0x3?_0x54aa2d[_0x518ada]['status']=0x4:_0x54aa2d[_0x518ada]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1828ee['toString']()+'\x20failed:\x20'+_0x4eb188);for(let _0x548792=0x0;_0x548792<_0x54aa2d['length'];_0x548792++)_0x54aa2d[_0x548792]['status']=0x4,_0x54aa2d[_0x548792]['abortReason']=_0x4eb188;}st(_0x23f82d,_0x4f444f);}},_0x2258ad);}function st(_0x1e2c10,_0x39b962){const _0x3642af=ca(_0x1e2c10,_0x39b962),_0x14840a=Gt(_0x3642af),_0x4441c5=la(_0x1e2c10,_0x3642af);return Ad(_0x1e2c10,_0x4441c5,_0x14840a),_0x14840a;}function Ad(_0x369af1,_0x399534,_0x496492){if(_0x399534['length']===0x0)return;const _0x16a027=[];let _0x1aa2f8=[];const _0x35ab6e=_0x399534['filter'](_0x5c772f=>_0x5c772f['status']===0x0)['map'](_0x55294e=>_0x55294e['currentWriteId']);for(let _0x309cea=0x0;_0x309cea<_0x399534['length'];_0x309cea++){const _0x3e63fe=_0x399534[_0x309cea],_0x1cec24=F(_0x496492,_0x3e63fe['path']);let _0x348716=!0x1,_0x301ddd;if(f(_0x1cec24!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3e63fe['status']===0x4)_0x348716=!0x0,_0x301ddd=_0x3e63fe['abortReason'],_0x1aa2f8=_0x1aa2f8['concat'](pe(_0x369af1['serverSyncTree_'],_0x3e63fe['currentWriteId'],!0x0));else{if(_0x3e63fe['status']===0x0){if(_0x3e63fe['retryCount']>=_d)_0x348716=!0x0,_0x301ddd='maxretry',_0x1aa2f8=_0x1aa2f8['concat'](pe(_0x369af1['serverSyncTree_'],_0x3e63fe['currentWriteId'],!0x0));else{const _0x22744b=ys(_0x369af1,_0x3e63fe['path'],_0x35ab6e);_0x3e63fe['currentInputSnapshot']=_0x22744b;const _0x119f5f=_0x399534[_0x309cea]['update'](_0x22744b['val']());if(_0x119f5f!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x119f5f,_0x3e63fe['path']);let _0x9b1d86=N(_0x119f5f);typeof _0x119f5f=='object'&&_0x119f5f!=null&&Y(_0x119f5f,'.priority')||(_0x9b1d86=_0x9b1d86['updatePriority'](_0x22744b['getPriority']()));const _0x546c7e=_0x3e63fe['currentWriteId'],_0x32ab83=jt(_0x369af1),_0x525abe=hs(_0x9b1d86,_0x22744b,_0x32ab83);_0x3e63fe['currentOutputSnapshotRaw']=_0x9b1d86,_0x3e63fe['currentOutputSnapshotResolved']=_0x525abe,_0x3e63fe['currentWriteId']=Vn(_0x369af1),_0x35ab6e['splice'](_0x35ab6e['indexOf'](_0x546c7e),0x1),_0x1aa2f8=_0x1aa2f8['concat'](ss(_0x369af1['serverSyncTree_'],_0x3e63fe['path'],_0x525abe,_0x3e63fe['currentWriteId'],_0x3e63fe['applyLocally'])),_0x1aa2f8=_0x1aa2f8['concat'](pe(_0x369af1['serverSyncTree_'],_0x546c7e,!0x0));}else _0x348716=!0x0,_0x301ddd='nodata',_0x1aa2f8=_0x1aa2f8['concat'](pe(_0x369af1['serverSyncTree_'],_0x3e63fe['currentWriteId'],!0x0));}}}V(_0x369af1['eventQueue_'],_0x496492,_0x1aa2f8),_0x1aa2f8=[],_0x348716&&(_0x399534[_0x309cea]['status']=0x2,function(_0x3d7ced){setTimeout(_0x3d7ced,Math['floor'](0x0));}(_0x399534[_0x309cea]['unwatcher']),_0x399534[_0x309cea]['onComplete']&&(_0x301ddd==='nodata'?_0x16a027['push'](()=>_0x399534[_0x309cea]['onComplete'](null,!0x1,_0x399534[_0x309cea]['currentInputSnapshot'])):_0x16a027['push'](()=>_0x399534[_0x309cea]['onComplete'](new Error(_0x301ddd),!0x1,null))));}$n(_0x369af1,_0x369af1['transactionQueueTree_']);for(let _0x2c1de9=0x0;_0x2c1de9<_0x16a027['length'];_0x2c1de9++)lt(_0x16a027[_0x2c1de9]);Hn(_0x369af1,_0x369af1['transactionQueueTree_']);}function ca(_0x5b4e65,_0x2f2ed1){let _0x4eff85,_0x6a8655=_0x5b4e65['transactionQueueTree_'];for(_0x4eff85=y(_0x2f2ed1);_0x4eff85!==null&&Ge(_0x6a8655)===void 0x0;)_0x6a8655=Un(_0x6a8655,_0x4eff85),_0x2f2ed1=b(_0x2f2ed1),_0x4eff85=y(_0x2f2ed1);return _0x6a8655;}function la(_0x11aa96,_0xbc1d07){const _0x58d927=[];return ha(_0x11aa96,_0xbc1d07,_0x58d927),_0x58d927['sort']((_0x4e2467,_0x1dca54)=>_0x4e2467['order']-_0x1dca54['order']),_0x58d927;}function ha(_0x56a6f2,_0x122053,_0x538ee3){const _0x4893c6=Ge(_0x122053);if(_0x4893c6){for(let _0x1504c3=0x0;_0x1504c3<_0x4893c6['length'];_0x1504c3++)_0x538ee3['push'](_0x4893c6[_0x1504c3]);}Wn(_0x122053,_0x4de9ce=>{ha(_0x56a6f2,_0x4de9ce,_0x538ee3);});}function $n(_0x102c5b,_0x50bef9){const _0x462519=Ge(_0x50bef9);if(_0x462519){let _0x235ed0=0x0;for(let _0x378968=0x0;_0x378968<_0x462519['length'];_0x378968++)_0x462519[_0x378968]['status']!==0x2&&(_0x462519[_0x235ed0]=_0x462519[_0x378968],_0x235ed0++);_0x462519['length']=_0x235ed0,fs(_0x50bef9,_0x462519['length']>0x0?_0x462519:void 0x0);}Wn(_0x50bef9,_0xfa8c20=>{$n(_0x102c5b,_0xfa8c20);});}function vs(_0x1a3d56,_0x3032fa){const _0x421663=Gt(ca(_0x1a3d56,_0x3032fa)),_0x149505=Un(_0x1a3d56['transactionQueueTree_'],_0x3032fa);return sd(_0x149505,_0x314f8a=>{ai(_0x1a3d56,_0x314f8a);}),ai(_0x1a3d56,_0x149505),ta(_0x149505,_0x48b19d=>{ai(_0x1a3d56,_0x48b19d);}),_0x421663;}function ai(_0x46b033,_0x4f1f34){const _0x25d386=Ge(_0x4f1f34);if(_0x25d386){const _0x20fdba=[];let _0x3df218=[],_0x26a06f=-0x1;for(let _0x2a9ac4=0x0;_0x2a9ac4<_0x25d386['length'];_0x2a9ac4++)_0x25d386[_0x2a9ac4]['status']===0x3||(_0x25d386[_0x2a9ac4]['status']===0x1?(f(_0x26a06f===_0x2a9ac4-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x26a06f=_0x2a9ac4,_0x25d386[_0x2a9ac4]['status']=0x3,_0x25d386[_0x2a9ac4]['abortReason']='set'):(f(_0x25d386[_0x2a9ac4]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x25d386[_0x2a9ac4]['unwatcher'](),_0x3df218=_0x3df218['concat'](pe(_0x46b033['serverSyncTree_'],_0x25d386[_0x2a9ac4]['currentWriteId'],!0x0)),_0x25d386[_0x2a9ac4]['onComplete']&&_0x20fdba['push'](_0x25d386[_0x2a9ac4]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x26a06f===-0x1?fs(_0x4f1f34,void 0x0):_0x25d386['length']=_0x26a06f+0x1,V(_0x46b033['eventQueue_'],Gt(_0x4f1f34),_0x3df218);for(let _0x5c97ac=0x0;_0x5c97ac<_0x20fdba['length'];_0x5c97ac++)lt(_0x20fdba[_0x5c97ac]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x2f1f30){let _0x372f17='';const _0x1efd48=_0x2f1f30['split']('/');for(let _0x2b9216=0x0;_0x2b9216<_0x1efd48['length'];_0x2b9216++)if(_0x1efd48[_0x2b9216]['length']>0x0){let _0x1ca92d=_0x1efd48[_0x2b9216];try{_0x1ca92d=decodeURIComponent(_0x1ca92d['replace'](/\+/g,'\x20'));}catch{}_0x372f17+='/'+_0x1ca92d;}return _0x372f17;}function Nd(_0x1a1503){const _0x514120={};_0x1a1503['charAt'](0x0)==='?'&&(_0x1a1503=_0x1a1503['substring'](0x1));for(const _0x47a2a4 of _0x1a1503['split']('&')){if(_0x47a2a4['length']===0x0)continue;const _0x2ecddc=_0x47a2a4['split']('=');_0x2ecddc['length']===0x2?_0x514120[decodeURIComponent(_0x2ecddc[0x0])]=decodeURIComponent(_0x2ecddc[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x47a2a4+'\x27\x20in\x20query\x20\x27'+_0x1a1503+'\x27');}return _0x514120;}const gr=function(_0x4794e0,_0x5aeb0a){const _0x15b4b1=Pd(_0x4794e0),_0x1e4e67=_0x15b4b1['namespace'];_0x15b4b1['domain']==='firebase.com'&&oe(_0x15b4b1['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x1e4e67||_0x1e4e67==='undefined')&&_0x15b4b1['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x15b4b1['secure']||Bl();const _0x247bc4=_0x15b4b1['scheme']==='ws'||_0x15b4b1['scheme']==='wss';return{'repoInfo':new _o(_0x15b4b1['host'],_0x15b4b1['secure'],_0x1e4e67,_0x247bc4,_0x5aeb0a,'',_0x1e4e67!==_0x15b4b1['subdomain']),'path':new C(_0x15b4b1['pathString'])};},Pd=function(_0xe6b208){let _0xe02bc7='',_0x2c1fa4='',_0x4fc85f='',_0x363c09='',_0x299c75='',_0x2f0e58=!0x0,_0x23e23b='https',_0x959032=0x1bb;if(typeof _0xe6b208=='string'){let _0x39fb39=_0xe6b208['indexOf']('//');_0x39fb39>=0x0&&(_0x23e23b=_0xe6b208['substring'](0x0,_0x39fb39-0x1),_0xe6b208=_0xe6b208['substring'](_0x39fb39+0x2));let _0x358d17=_0xe6b208['indexOf']('/');_0x358d17===-0x1&&(_0x358d17=_0xe6b208['length']);let _0x179fc3=_0xe6b208['indexOf']('?');_0x179fc3===-0x1&&(_0x179fc3=_0xe6b208['length']),_0xe02bc7=_0xe6b208['substring'](0x0,Math['min'](_0x358d17,_0x179fc3)),_0x358d17<_0x179fc3&&(_0x363c09=kd(_0xe6b208['substring'](_0x358d17,_0x179fc3)));const _0x3bdc03=Nd(_0xe6b208['substring'](Math['min'](_0xe6b208['length'],_0x179fc3)));_0x39fb39=_0xe02bc7['indexOf'](':'),_0x39fb39>=0x0?(_0x2f0e58=_0x23e23b==='https'||_0x23e23b==='wss',_0x959032=parseInt(_0xe02bc7['substring'](_0x39fb39+0x1),0xa)):_0x39fb39=_0xe02bc7['length'];const _0x6ff192=_0xe02bc7['slice'](0x0,_0x39fb39);if(_0x6ff192['toLowerCase']()==='localhost')_0x2c1fa4='localhost';else{if(_0x6ff192['split']('.')['length']<=0x2)_0x2c1fa4=_0x6ff192;else{const _0x26c276=_0xe02bc7['indexOf']('.');_0x4fc85f=_0xe02bc7['substring'](0x0,_0x26c276)['toLowerCase'](),_0x2c1fa4=_0xe02bc7['substring'](_0x26c276+0x1),_0x299c75=_0x4fc85f;}}'ns'in _0x3bdc03&&(_0x299c75=_0x3bdc03['ns']);}return{'host':_0xe02bc7,'port':_0x959032,'domain':_0x2c1fa4,'subdomain':_0x4fc85f,'secure':_0x2f0e58,'scheme':_0x23e23b,'pathString':_0x363c09,'namespace':_0x299c75};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x4f348d=0x0;const _0xa0b703=[];return function(_0x5e51a5){const _0x40306f=_0x5e51a5===_0x4f348d;_0x4f348d=_0x5e51a5;let _0x3cf1b1;const _0x2130ac=new Array(0x8);for(_0x3cf1b1=0x7;_0x3cf1b1>=0x0;_0x3cf1b1--)_0x2130ac[_0x3cf1b1]=mr['charAt'](_0x5e51a5%0x40),_0x5e51a5=Math['floor'](_0x5e51a5/0x40);f(_0x5e51a5===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1b048f=_0x2130ac['join']('');if(_0x40306f){for(_0x3cf1b1=0xb;_0x3cf1b1>=0x0&&_0xa0b703[_0x3cf1b1]===0x3f;_0x3cf1b1--)_0xa0b703[_0x3cf1b1]=0x0;_0xa0b703[_0x3cf1b1]++;}else{for(_0x3cf1b1=0x0;_0x3cf1b1<0xc;_0x3cf1b1++)_0xa0b703[_0x3cf1b1]=Math['floor'](Math['random']()*0x40);}for(_0x3cf1b1=0x0;_0x3cf1b1<0xc;_0x3cf1b1++)_0x1b048f+=mr['charAt'](_0xa0b703[_0x3cf1b1]);return f(_0x1b048f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1b048f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x29982f,_0x3d9e35,_0xc949db,_0xae7eeb){this['eventType']=_0x29982f,this['eventRegistration']=_0x3d9e35,this['snapshot']=_0xc949db,this['prevName']=_0xae7eeb;}['getPath'](){const _0x14e13f=this['snapshot']['ref'];return this['eventType']==='value'?_0x14e13f['_path']:_0x14e13f['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x1bad90,_0x1279d7,_0x5ae3de){this['eventRegistration']=_0x1bad90,this['error']=_0x1279d7,this['path']=_0x5ae3de;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x12c9d5,_0x5c82cf){this['snapshotCallback']=_0x12c9d5,this['cancelCallback']=_0x5c82cf;}['onValue'](_0x4d7697,_0xb72956){this['snapshotCallback']['call'](null,_0x4d7697,_0xb72956);}['onCancel'](_0x41efa9){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x41efa9);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x123245){return this['snapshotCallback']===_0x123245['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x123245['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x123245['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x44f7c4,_0x3a1e2f,_0x569181,_0x88a0bf){this['_repo']=_0x44f7c4,this['_path']=_0x3a1e2f,this['_queryParams']=_0x569181,this['_orderByCalled']=_0x88a0bf;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2dd6e5=nr(this['_queryParams']),_0x2b4656=Bi(_0x2dd6e5);return _0x2b4656==='{}'?'default':_0x2b4656;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x5bca34){if(_0x5bca34=k(_0x5bca34),!(_0x5bca34 instanceof be))return!0x1;const _0x299178=this['_repo']===_0x5bca34['_repo'],_0x50ecfa=qi(this['_path'],_0x5bca34['_path']),_0x53c443=this['_queryIdentifier']===_0x5bca34['_queryIdentifier'];return _0x299178&&_0x50ecfa&&_0x53c443;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x69002e,_0x58f28d){if(_0x69002e['_orderByCalled']===!0x0)throw new Error(_0x58f28d+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x2a722f){let _0x12cb48=null,_0x4c661e=null;if(_0x2a722f['hasStart']()&&(_0x12cb48=_0x2a722f['getIndexStartValue']()),_0x2a722f['hasEnd']()&&(_0x4c661e=_0x2a722f['getIndexEndValue']()),_0x2a722f['getIndex']()===ye){const _0x6f228b='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1f92ee='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2a722f['hasStart']()){if(_0x2a722f['getIndexStartName']()!==xe)throw new Error(_0x6f228b);if(typeof _0x12cb48!='string')throw new Error(_0x1f92ee);}if(_0x2a722f['hasEnd']()){if(_0x2a722f['getIndexEndName']()!==Ie)throw new Error(_0x6f228b);if(typeof _0x4c661e!='string')throw new Error(_0x1f92ee);}}else{if(_0x2a722f['getIndex']()===R){if(_0x12cb48!=null&&!Cn(_0x12cb48)||_0x4c661e!=null&&!Cn(_0x4c661e))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2a722f['getIndex']()instanceof Ki||_0x2a722f['getIndex']()===Po,'unknown\x20index\x20type.'),_0x12cb48!=null&&typeof _0x12cb48=='object'||_0x4c661e!=null&&typeof _0x4c661e=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2fadfa){if(_0x2fadfa['hasStart']()&&_0x2fadfa['hasEnd']()&&_0x2fadfa['hasLimit']()&&!_0x2fadfa['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x316124,_0x49ede7){super(_0x316124,_0x49ede7,new Qi(),!0x1);}get['parent'](){const _0x37201b=To(this['_path']);return _0x37201b===null?null:new Z(this['_repo'],_0x37201b);}get['root'](){let _0x50a48c=this;for(;_0x50a48c['parent']!==null;)_0x50a48c=_0x50a48c['parent'];return _0x50a48c;}}class rt{constructor(_0x45d613,_0x547015,_0x8df889){this['_node']=_0x45d613,this['ref']=_0x547015,this['_index']=_0x8df889;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5340c7){const _0xd780b2=new C(_0x5340c7),_0x3042ef=Lt(this['ref'],_0x5340c7);return new rt(this['_node']['getChild'](_0xd780b2),_0x3042ef,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x178a9d){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5c3bad,_0x3c6df8)=>_0x178a9d(new rt(_0x3c6df8,Lt(this['ref'],_0x5c3bad),R)));}['hasChild'](_0xd1c0f9){const _0x3f319e=new C(_0xd1c0f9);return!this['_node']['getChild'](_0x3f319e)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x5e1f53,_0x471c7e){return _0x5e1f53=k(_0x5e1f53),_0x5e1f53['_checkNotDeleted']('ref'),_0x471c7e!==void 0x0?Lt(_0x5e1f53['_root'],_0x471c7e):_0x5e1f53['_root'];}function Lt(_0x3709f1,_0x20be28){return _0x3709f1=k(_0x3709f1),y(_0x3709f1['_path'])===null?ud('child','path',_0x20be28):_s('child','path',_0x20be28),new Z(_0x3709f1['_repo'],A(_0x3709f1['_path'],_0x20be28));}function d_(_0x268d92,_0x5cde25){_0x268d92=k(_0x268d92),gs('push',_0x268d92['_path']),qt('push',_0x5cde25,_0x268d92['_path'],!0x0);const _0x3262f7=oa(_0x268d92['_repo']),_0x81eb95=Od(_0x3262f7),_0x44d062=Lt(_0x268d92,_0x81eb95),_0x15028e=Lt(_0x268d92,_0x81eb95);let _0x1908cf;return _0x5cde25!=null?_0x1908cf=Ld(_0x15028e,_0x5cde25)['then'](()=>_0x15028e):_0x1908cf=Promise['resolve'](_0x15028e),_0x44d062['then']=_0x1908cf['then']['bind'](_0x1908cf),_0x44d062['catch']=_0x1908cf['then']['bind'](_0x1908cf,void 0x0),_0x44d062;}function Ld(_0x40569b,_0xf75ad9){_0x40569b=k(_0x40569b),gs('set',_0x40569b['_path']),qt('set',_0xf75ad9,_0x40569b['_path'],!0x1);const _0x354b61=new Ve();return Ed(_0x40569b['_repo'],_0x40569b['_path'],_0xf75ad9,null,_0x354b61['wrapCallback'](()=>{})),_0x354b61['promise'];}function f_(_0x5124da,_0x397c0d){hd('update',_0x397c0d,_0x5124da['_path']);const _0x50b1f6=new Ve();return Id(_0x5124da['_repo'],_0x5124da['_path'],_0x397c0d,_0x50b1f6['wrapCallback'](()=>{})),_0x50b1f6['promise'];}function p_(_0x47f2f7){_0x47f2f7=k(_0x47f2f7);const _0x5bb497=new ua(()=>{}),_0x180bed=new qn(_0x5bb497);return vd(_0x47f2f7['_repo'],_0x47f2f7,_0x180bed)['then'](_0x46f543=>new rt(_0x46f543,new Z(_0x47f2f7['_repo'],_0x47f2f7['_path']),_0x47f2f7['_queryParams']['getIndex']()));}class qn{constructor(_0x312150){this['callbackContext']=_0x312150;}['respondsTo'](_0xdddb98){return _0xdddb98==='value';}['createEvent'](_0xde2654,_0x5b67c1){const _0x2bf8a3=_0x5b67c1['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0xde2654['snapshotNode'],new Z(_0x5b67c1['_repo'],_0x5b67c1['_path']),_0x2bf8a3));}['getEventRunner'](_0x33907c){return _0x33907c['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x33907c['error']):()=>this['callbackContext']['onValue'](_0x33907c['snapshot'],null);}['createCancelEvent'](_0x350807,_0x2373cf){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x350807,_0x2373cf):null;}['matches'](_0x2e0ff0){return _0x2e0ff0 instanceof qn?!_0x2e0ff0['callbackContext']||!this['callbackContext']?!0x0:_0x2e0ff0['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x2788d9,_0x95d42a,_0x81b5f8,_0x367608,_0x39188d){const _0x14bfcd=new ua(_0x81b5f8,void 0x0),_0x20368a=new qn(_0x14bfcd);return Cd(_0x2788d9['_repo'],_0x2788d9,_0x20368a),()=>Td(_0x2788d9['_repo'],_0x2788d9,_0x20368a);}function Fd(_0x53d022,_0x3a107a,_0x3cc7fa,_0x372ee3){return xd(_0x53d022,'value',_0x3a107a);}class dt{}class pa extends dt{constructor(_0x1fec62,_0x465756){super(),this['_value']=_0x1fec62,this['_key']=_0x465756,this['type']='endAt';}['_apply'](_0x21c3b9){qt('endAt',this['_value'],_0x21c3b9['_path'],!0x0);const _0x5a76bf=Kh(_0x21c3b9['_queryParams'],this['_value'],this['_key']);if(fa(_0x5a76bf),Gn(_0x5a76bf),_0x21c3b9['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x21c3b9['_repo'],_0x21c3b9['_path'],_0x5a76bf,_0x21c3b9['_orderByCalled']);}}function __(_0x1050a0,_0x514e77){return new pa(_0x1050a0,_0x514e77);}class _a extends dt{constructor(_0x4f66d5,_0x3a64d4){super(),this['_value']=_0x4f66d5,this['_key']=_0x3a64d4,this['type']='startAt';}['_apply'](_0x1e46ad){qt('startAt',this['_value'],_0x1e46ad['_path'],!0x0);const _0x2f58b5=jh(_0x1e46ad['_queryParams'],this['_value'],this['_key']);if(fa(_0x2f58b5),Gn(_0x2f58b5),_0x1e46ad['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x1e46ad['_repo'],_0x1e46ad['_path'],_0x2f58b5,_0x1e46ad['_orderByCalled']);}}function g_(_0xe3795e=null,_0x402fd1){return new _a(_0xe3795e,_0x402fd1);}class Ud extends dt{constructor(_0x322599){super(),this['_limit']=_0x322599,this['type']='limitToFirst';}['_apply'](_0x5e2683){if(_0x5e2683['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x5e2683['_repo'],_0x5e2683['_path'],zh(_0x5e2683['_queryParams'],this['_limit']),_0x5e2683['_orderByCalled']);}}function m_(_0x5b470e){if(Math['floor'](_0x5b470e)!==_0x5b470e||_0x5b470e<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x5b470e);}class Wd extends dt{constructor(_0xb07091){super(),this['_path']=_0xb07091,this['type']='orderByChild';}['_apply'](_0x5e741d){da(_0x5e741d,'orderByChild');const _0x116ea2=new C(this['_path']);if(v(_0x116ea2))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x10556f=new Ki(_0x116ea2),_0x3efa49=Do(_0x5e741d['_queryParams'],_0x10556f);return Gn(_0x3efa49),new be(_0x5e741d['_repo'],_0x5e741d['_path'],_0x3efa49,!0x0);}}function y_(_0x317b3f){if(_0x317b3f==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x317b3f==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x317b3f==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x317b3f),new Wd(_0x317b3f);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2f3d58){da(_0x2f3d58,'orderByKey');const _0x276069=Do(_0x2f3d58['_queryParams'],ye);return Gn(_0x276069),new be(_0x2f3d58['_repo'],_0x2f3d58['_path'],_0x276069,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x1eda1f,_0x3f421a){super(),this['_value']=_0x1eda1f,this['_key']=_0x3f421a,this['type']='equalTo';}['_apply'](_0x2d281b){if(qt('equalTo',this['_value'],_0x2d281b['_path'],!0x1),_0x2d281b['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2d281b['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x2d281b));}}function E_(_0x3dd703,_0x588b25){return new Vd(_0x3dd703,_0x588b25);}function I_(_0x4f0f9c,..._0x1354c7){let _0x18a740=k(_0x4f0f9c);for(const _0x4981f1 of _0x1354c7)_0x18a740=_0x4981f1['_apply'](_0x18a740);return _0x18a740;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x38fe7c,_0x37ddd3,_0x561e05,_0x3401e2){const _0x4e8f55=_0x37ddd3['lastIndexOf'](':'),_0x4aacfc=_0x37ddd3['substring'](0x0,_0x4e8f55),_0x594c24=Wt(_0x4aacfc);_0x38fe7c['repoInfo_']=new _o(_0x37ddd3,_0x594c24,_0x38fe7c['repoInfo_']['namespace'],_0x38fe7c['repoInfo_']['webSocketOnly'],_0x38fe7c['repoInfo_']['nodeAdmin'],_0x38fe7c['repoInfo_']['persistenceKey'],_0x38fe7c['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x561e05),_0x3401e2&&(_0x38fe7c['authTokenProvider_']=_0x3401e2);}function qd(_0x1c1c64,_0x1f9351,_0x2b566e,_0x18f6c4,_0x4eb8a0){let _0x4b41e4=_0x18f6c4||_0x1c1c64['options']['databaseURL'];_0x4b41e4===void 0x0&&(_0x1c1c64['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x1c1c64['options']['projectId']),_0x4b41e4=_0x1c1c64['options']['projectId']+'-default-rtdb.firebaseio.com');let _0xe9a64f=gr(_0x4b41e4,_0x4eb8a0),_0x6e7e8a=_0xe9a64f['repoInfo'],_0x38587b;typeof process<'u'&&Us&&(_0x38587b=Us[Hd]),_0x38587b?(_0x4b41e4='http://'+_0x38587b+'?ns='+_0x6e7e8a['namespace'],_0xe9a64f=gr(_0x4b41e4,_0x4eb8a0),_0x6e7e8a=_0xe9a64f['repoInfo']):_0xe9a64f['repoInfo']['secure'];const _0x3aa770=new Jl(_0x1c1c64['name'],_0x1c1c64['options'],_0x1f9351);dd('Invalid\x20Firebase\x20Database\x20URL',_0xe9a64f),v(_0xe9a64f['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3d4f40=jd(_0x6e7e8a,_0x1c1c64,_0x3aa770,new Ql(_0x1c1c64,_0x2b566e));return new Kd(_0x3d4f40,_0x1c1c64);}function zd(_0x20f110,_0x45d8b5){const _0x349516=ki[_0x45d8b5];(!_0x349516||_0x349516[_0x20f110['key']]!==_0x20f110)&&oe('Database\x20'+_0x45d8b5+'('+_0x20f110['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x20f110),delete _0x349516[_0x20f110['key']];}function jd(_0x95fd42,_0x4228f4,_0x133562,_0x3de0aa){let _0x4af483=ki[_0x4228f4['name']];_0x4af483||(_0x4af483={},ki[_0x4228f4['name']]=_0x4af483);let _0x5f4c7d=_0x4af483[_0x95fd42['toURLString']()];return _0x5f4c7d&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x5f4c7d=new gd(_0x95fd42,$d,_0x133562,_0x3de0aa),_0x4af483[_0x95fd42['toURLString']()]=_0x5f4c7d,_0x5f4c7d;}class Kd{constructor(_0x5e207c,_0x4d9d9b){this['_repoInternal']=_0x5e207c,this['app']=_0x4d9d9b,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x2da487){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x2da487+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x50f7de=Qr(),_0x18b1c5){const _0x5b9b76=Ui(_0x50f7de,'database')['getImmediate']({'identifier':_0x18b1c5});if(!_0x5b9b76['_instanceStarted']){const _0x5b2681=ac('database');_0x5b2681&&Yd(_0x5b9b76,..._0x5b2681);}return _0x5b9b76;}function Yd(_0x19056d,_0x53a9c5,_0x438565,_0x2fac3b={}){_0x19056d=k(_0x19056d),_0x19056d['_checkNotDeleted']('useEmulator');const _0x2aaac6=_0x53a9c5+':'+_0x438565,_0x2675a1=_0x19056d['_repoInternal'];if(_0x19056d['_instanceStarted']){if(_0x2aaac6===_0x19056d['_repoInternal']['repoInfo_']['host']&&De(_0x2fac3b,_0x2675a1['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x54310e;if(_0x2675a1['repoInfo_']['nodeAdmin'])_0x2fac3b['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x54310e=new tn(tn['OWNER']);else{if(_0x2fac3b['mockUserToken']){const _0x2f223c=typeof _0x2fac3b['mockUserToken']=='string'?_0x2fac3b['mockUserToken']:cc(_0x2fac3b['mockUserToken'],_0x19056d['app']['options']['projectId']);_0x54310e=new tn(_0x2f223c);}}Wt(_0x53a9c5)&&jr(_0x53a9c5),Gd(_0x2675a1,_0x2aaac6,_0x2fac3b,_0x54310e);}function C_(_0x1c9bf8){_0x1c9bf8=k(_0x1c9bf8),_0x1c9bf8['_checkNotDeleted']('goOffline'),aa(_0x1c9bf8['_repo']);}function T_(_0x4427c5){_0x4427c5=k(_0x4427c5),_0x4427c5['_checkNotDeleted']('goOnline'),Sd(_0x4427c5['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x1f6ad5){Ll(ct),et(new Me('database',(_0x5db628,{instanceIdentifier:_0x56bb26})=>{const _0x336eeb=_0x5db628['getProvider']('app')['getImmediate'](),_0x33a8e6=_0x5db628['getProvider']('auth-internal'),_0x4fb046=_0x5db628['getProvider']('app-check-internal');return qd(_0x336eeb,_0x33a8e6,_0x4fb046,_0x56bb26);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x1f6ad5),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x412fc2,_0x24c32f){this['committed']=_0x412fc2,this['snapshot']=_0x24c32f;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x33ad29,_0x1e64ea,_0x254356){if(_0x33ad29=k(_0x33ad29),gs('Reference.transaction',_0x33ad29['_path']),_0x33ad29['key']==='.length'||_0x33ad29['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x33ad29['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3542b0=!0x0,_0x387da8=new Ve(),_0x530160=(_0x24e3b8,_0x44937b,_0x128501)=>{let _0x17c559=null;_0x24e3b8?_0x387da8['reject'](_0x24e3b8):(_0x17c559=new rt(_0x128501,new Z(_0x33ad29['_repo'],_0x33ad29['_path']),R),_0x387da8['resolve'](new Xd(_0x44937b,_0x17c559)));},_0x86c7d8=Fd(_0x33ad29,()=>{});return bd(_0x33ad29['_repo'],_0x33ad29['_path'],_0x1e64ea,_0x530160,_0x86c7d8,_0x3542b0),_0x387da8['promise'];}ie['prototype']['simpleListen']=function(_0x2f17b3,_0x4dc2a5){this['sendRequest']('q',{'p':_0x2f17b3},_0x4dc2a5);},ie['prototype']['echo']=function(_0x161cc8,_0x9a7931){this['sendRequest']('echo',{'d':_0x161cc8},_0x9a7931);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x5e0542,..._0x1ae25e){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x5e0542,..._0x1ae25e);}function nn(_0x5c5842,..._0x2b3f74){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x5c5842,..._0x2b3f74);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0xe1e90e,..._0x54ba52){throw Es(_0xe1e90e,..._0x54ba52);}function J(_0xd413f6,..._0x2db415){return Es(_0xd413f6,..._0x2db415);}function ya(_0x14f9a7,_0x2e2800,_0x52f3d3){const _0x5631a9={...Zd(),[_0x2e2800]:_0x52f3d3};return new Ut('auth','Firebase',_0x5631a9)['create'](_0x2e2800,{'appName':_0x14f9a7['name']});}function se(_0x8ee78d){return ya(_0x8ee78d,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x18f619,..._0x1d4175){if(typeof _0x18f619!='string'){const _0xd4ad72=_0x1d4175[0x0],_0x116fa5=[..._0x1d4175['slice'](0x1)];return _0x116fa5[0x0]&&(_0x116fa5[0x0]['appName']=_0x18f619['name']),_0x18f619['_errorFactory']['create'](_0xd4ad72,..._0x116fa5);}return ma['create'](_0x18f619,..._0x1d4175);}function m(_0x5b4a0e,_0x47dfd1,..._0x23ec43){if(!_0x5b4a0e)throw Es(_0x47dfd1,..._0x23ec43);}function te(_0x1e791b){const _0x50ed31='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1e791b;throw nn(_0x50ed31),new Error(_0x50ed31);}function ae(_0x2a47c6,_0x79a765){_0x2a47c6||te(_0x79a765);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0xf167c1;return typeof self<'u'&&((_0xf167c1=self['location'])==null?void 0x0:_0xf167c1['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x56b80c;return typeof self<'u'&&((_0x56b80c=self['location'])==null?void 0x0:_0x56b80c['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x50988e=navigator;return _0x50988e['languages']&&_0x50988e['languages'][0x0]||_0x50988e['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x2d71e8,_0x502ef9){this['shortDelay']=_0x2d71e8,this['longDelay']=_0x502ef9,ae(_0x502ef9>_0x2d71e8,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x541e60,_0x1d2f0a){ae(_0x541e60['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x40a409}=_0x541e60['emulator'];return _0x1d2f0a?''+_0x40a409+(_0x1d2f0a['startsWith']('/')?_0x1d2f0a['slice'](0x1):_0x1d2f0a):_0x40a409;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x5cd951,_0x5e3ec,_0x5e70ac){this['fetchImpl']=_0x5cd951,_0x5e3ec&&(this['headersImpl']=_0x5e3ec),_0x5e70ac&&(this['responseImpl']=_0x5e70ac);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x16a97a,_0x53288f){return _0x16a97a['tenantId']&&!_0x53288f['tenantId']?{..._0x53288f,'tenantId':_0x16a97a['tenantId']}:_0x53288f;}async function Ae(_0x166e9d,_0x4c16c3,_0x2d6e82,_0x2ac65c,_0x3c14cd={}){return Ea(_0x166e9d,_0x3c14cd,async()=>{let _0x16caed={},_0x2cf09f={};_0x2ac65c&&(_0x4c16c3==='GET'?_0x2cf09f=_0x2ac65c:_0x16caed={'body':JSON['stringify'](_0x2ac65c)});const _0x4e3153=at({..._0x2cf09f,'key':_0x166e9d['config']['apiKey']})['slice'](0x1),_0x347376=await _0x166e9d['_getAdditionalHeaders']();_0x347376['Content-Type']='application/json',_0x166e9d['languageCode']&&(_0x347376['X-Firebase-Locale']=_0x166e9d['languageCode']);const _0x5548d3={'method':_0x4c16c3,'headers':_0x347376,..._0x16caed};return lc()||(_0x5548d3['referrerPolicy']='strict-origin-when-cross-origin'),_0x166e9d['emulatorConfig']&&Wt(_0x166e9d['emulatorConfig']['host'])&&(_0x5548d3['credentials']='include'),va['fetch']()(await Ia(_0x166e9d,_0x166e9d['config']['apiHost'],_0x2d6e82,_0x4e3153),_0x5548d3);});}async function Ea(_0xa3d276,_0x70b13a,_0xbcc284){_0xa3d276['_canInitEmulator']=!0x1;const _0x12a3c2={...rf,..._0x70b13a};try{const _0x411ca7=new lf(_0xa3d276),_0x30ef31=await Promise['race']([_0xbcc284(),_0x411ca7['promise']]);_0x411ca7['clearNetworkTimeout']();const _0x5cb314=await _0x30ef31['json']();if('needConfirmation'in _0x5cb314)throw en(_0xa3d276,'account-exists-with-different-credential',_0x5cb314);if(_0x30ef31['ok']&&!('errorMessage'in _0x5cb314))return _0x5cb314;{const _0x278d73=_0x30ef31['ok']?_0x5cb314['errorMessage']:_0x5cb314['error']['message'],[_0xd5a9bf,_0x334dba]=_0x278d73['split']('\x20:\x20');if(_0xd5a9bf==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0xa3d276,'credential-already-in-use',_0x5cb314);if(_0xd5a9bf==='EMAIL_EXISTS')throw en(_0xa3d276,'email-already-in-use',_0x5cb314);if(_0xd5a9bf==='USER_DISABLED')throw en(_0xa3d276,'user-disabled',_0x5cb314);const _0x282ea6=_0x12a3c2[_0xd5a9bf]||_0xd5a9bf['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x334dba)throw ya(_0xa3d276,_0x282ea6,_0x334dba);K(_0xa3d276,_0x282ea6);}}catch(_0x1d5f83){if(_0x1d5f83 instanceof Se)throw _0x1d5f83;K(_0xa3d276,'network-request-failed',{'message':String(_0x1d5f83)});}}async function Yt(_0x55396d,_0x147225,_0x78128e,_0x51d876,_0x19fc8a={}){const _0x45891c=await Ae(_0x55396d,_0x147225,_0x78128e,_0x51d876,_0x19fc8a);return'mfaPendingCredential'in _0x45891c&&K(_0x55396d,'multi-factor-auth-required',{'_serverResponse':_0x45891c}),_0x45891c;}async function Ia(_0x442273,_0x42fef2,_0x54ada,_0x4c1b4e){const _0x5278eb=''+_0x42fef2+_0x54ada+'?'+_0x4c1b4e,_0x472045=_0x442273,_0x523383=_0x472045['config']['emulator']?Is(_0x442273['config'],_0x5278eb):_0x442273['config']['apiScheme']+'://'+_0x5278eb;return of['includes'](_0x54ada)&&(await _0x472045['_persistenceManagerAvailable'],_0x472045['_getPersistenceType']()==='COOKIE')?_0x472045['_getPersistence']()['_getFinalTarget'](_0x523383)['toString']():_0x523383;}function cf(_0xa1854a){switch(_0xa1854a){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x27ffc8){this['auth']=_0x27ffc8,this['timer']=null,this['promise']=new Promise((_0x3fbd3f,_0x32314a)=>{this['timer']=setTimeout(()=>_0x32314a(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x3c6dc3,_0x1a6f24,_0x184770){const _0xfaa42a={'appName':_0x3c6dc3['name']};_0x184770['email']&&(_0xfaa42a['email']=_0x184770['email']),_0x184770['phoneNumber']&&(_0xfaa42a['phoneNumber']=_0x184770['phoneNumber']);const _0xc65884=J(_0x3c6dc3,_0x1a6f24,_0xfaa42a);return _0xc65884['customData']['_tokenResponse']=_0x184770,_0xc65884;}function vr(_0x1602ce){return _0x1602ce!==void 0x0&&_0x1602ce['enterprise']!==void 0x0;}class hf{constructor(_0x1d5c21){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x1d5c21['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x1d5c21['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x1d5c21['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x71ab84){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x182bf2 of this['recaptchaEnforcementState'])if(_0x182bf2['provider']&&_0x182bf2['provider']===_0x71ab84)return cf(_0x182bf2['enforcementState']);return null;}['isProviderEnabled'](_0xb146be){return this['getProviderEnforcementState'](_0xb146be)==='ENFORCE'||this['getProviderEnforcementState'](_0xb146be)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x270b60,_0x5e2430){return Ae(_0x270b60,'GET','/v2/recaptchaConfig',Re(_0x270b60,_0x5e2430));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x3affb4,_0x4afbdd){return Ae(_0x3affb4,'POST','/v1/accounts:delete',_0x4afbdd);}async function Sn(_0x1c6b7c,_0x3b16bb){return Ae(_0x1c6b7c,'POST','/v1/accounts:lookup',_0x3b16bb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x312e8b){if(_0x312e8b)try{const _0x676e18=new Date(Number(_0x312e8b));if(!isNaN(_0x676e18['getTime']()))return _0x676e18['toUTCString']();}catch{}}async function ff(_0x32771a,_0x1d9000=!0x1){const _0x530d2b=k(_0x32771a),_0x53e7a4=await _0x530d2b['getIdToken'](_0x1d9000),_0x12c66d=ws(_0x53e7a4);m(_0x12c66d&&_0x12c66d['exp']&&_0x12c66d['auth_time']&&_0x12c66d['iat'],_0x530d2b['auth'],'internal-error');const _0x12cd1e=typeof _0x12c66d['firebase']=='object'?_0x12c66d['firebase']:void 0x0,_0x177fd5=_0x12cd1e==null?void 0x0:_0x12cd1e['sign_in_provider'];return{'claims':_0x12c66d,'token':_0x53e7a4,'authTime':St(ci(_0x12c66d['auth_time'])),'issuedAtTime':St(ci(_0x12c66d['iat'])),'expirationTime':St(ci(_0x12c66d['exp'])),'signInProvider':_0x177fd5||null,'signInSecondFactor':(_0x12cd1e==null?void 0x0:_0x12cd1e['sign_in_second_factor'])||null};}function ci(_0x63fc93){return Number(_0x63fc93)*0x3e8;}function ws(_0x4ade5c){const [_0x8aaa10,_0x3a4bb5,_0x5ea55a]=_0x4ade5c['split']('.');if(_0x8aaa10===void 0x0||_0x3a4bb5===void 0x0||_0x5ea55a===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x1c7bb8=cn(_0x3a4bb5);return _0x1c7bb8?JSON['parse'](_0x1c7bb8):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x127961){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x127961==null?void 0x0:_0x127961['toString']()),null;}}function Er(_0x555119){const _0x40bf72=ws(_0x555119);return m(_0x40bf72,'internal-error'),m(typeof _0x40bf72['exp']<'u','internal-error'),m(typeof _0x40bf72['iat']<'u','internal-error'),Number(_0x40bf72['exp'])-Number(_0x40bf72['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x3c0c06,_0x404b8a,_0x394a42=!0x1){if(_0x394a42)return _0x404b8a;try{return await _0x404b8a;}catch(_0x4fed2f){throw _0x4fed2f instanceof Se&&pf(_0x4fed2f)&&_0x3c0c06['auth']['currentUser']===_0x3c0c06&&await _0x3c0c06['auth']['signOut'](),_0x4fed2f;}}function pf({code:_0x1a4fba}){return _0x1a4fba==='auth/user-disabled'||_0x1a4fba==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x5df9c1){this['user']=_0x5df9c1,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x1d0ea9){if(_0x1d0ea9){const _0x288af2=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x288af2;}else{this['errorBackoff']=0x7530;const _0x44a909=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x44a909);}}['schedule'](_0x141b96=!0x1){if(!this['isRunning'])return;const _0x1e0020=this['getInterval'](_0x141b96);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1e0020);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2ed6f7){(_0x2ed6f7==null?void 0x0:_0x2ed6f7['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5022da,_0x4aa9c9){this['createdAt']=_0x5022da,this['lastLoginAt']=_0x4aa9c9,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x4643dc){this['createdAt']=_0x4643dc['createdAt'],this['lastLoginAt']=_0x4643dc['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x285a0e){var _0x5c38b1;const _0x2249b0=_0x285a0e['auth'],_0x3fd3c7=await _0x285a0e['getIdToken'](),_0x4aa76b=await xt(_0x285a0e,Sn(_0x2249b0,{'idToken':_0x3fd3c7}));m(_0x4aa76b==null?void 0x0:_0x4aa76b['users']['length'],_0x2249b0,'internal-error');const _0x1a6072=_0x4aa76b['users'][0x0];_0x285a0e['_notifyReloadListener'](_0x1a6072);const _0x5ed302=(_0x5c38b1=_0x1a6072['providerUserInfo'])!=null&&_0x5c38b1['length']?wa(_0x1a6072['providerUserInfo']):[],_0x362193=mf(_0x285a0e['providerData'],_0x5ed302),_0x1c5459=_0x285a0e['isAnonymous'],_0x1dcd6f=!(_0x285a0e['email']&&_0x1a6072['passwordHash'])&&!(_0x362193!=null&&_0x362193['length']),_0x5abf7a=_0x1c5459?_0x1dcd6f:!0x1,_0x3ee8d4={'uid':_0x1a6072['localId'],'displayName':_0x1a6072['displayName']||null,'photoURL':_0x1a6072['photoUrl']||null,'email':_0x1a6072['email']||null,'emailVerified':_0x1a6072['emailVerified']||!0x1,'phoneNumber':_0x1a6072['phoneNumber']||null,'tenantId':_0x1a6072['tenantId']||null,'providerData':_0x362193,'metadata':new Pi(_0x1a6072['createdAt'],_0x1a6072['lastLoginAt']),'isAnonymous':_0x5abf7a};Object['assign'](_0x285a0e,_0x3ee8d4);}async function gf(_0x322186){const _0x5f4b62=k(_0x322186);await bn(_0x5f4b62),await _0x5f4b62['auth']['_persistUserIfCurrent'](_0x5f4b62),_0x5f4b62['auth']['_notifyListenersIfCurrent'](_0x5f4b62);}function mf(_0x45f98b,_0x4dc331){return[..._0x45f98b['filter'](_0x32b3e2=>!_0x4dc331['some'](_0x3ef5b1=>_0x3ef5b1['providerId']===_0x32b3e2['providerId'])),..._0x4dc331];}function wa(_0x5cbc6f){return _0x5cbc6f['map'](({providerId:_0x2ad75f,..._0x43b3b6})=>({'providerId':_0x2ad75f,'uid':_0x43b3b6['rawId']||'','displayName':_0x43b3b6['displayName']||null,'email':_0x43b3b6['email']||null,'phoneNumber':_0x43b3b6['phoneNumber']||null,'photoURL':_0x43b3b6['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x3a3a1c,_0x276f5e){const _0x420b7f=await Ea(_0x3a3a1c,{},async()=>{const _0x5eee45=at({'grant_type':'refresh_token','refresh_token':_0x276f5e})['slice'](0x1),{tokenApiHost:_0x2f14bc,apiKey:_0x4c0518}=_0x3a3a1c['config'],_0x590f66=await Ia(_0x3a3a1c,_0x2f14bc,'/v1/token','key='+_0x4c0518),_0xdb0464=await _0x3a3a1c['_getAdditionalHeaders']();_0xdb0464['Content-Type']='application/x-www-form-urlencoded';const _0x1bcfac={'method':'POST','headers':_0xdb0464,'body':_0x5eee45};return _0x3a3a1c['emulatorConfig']&&Wt(_0x3a3a1c['emulatorConfig']['host'])&&(_0x1bcfac['credentials']='include'),va['fetch']()(_0x590f66,_0x1bcfac);});return{'accessToken':_0x420b7f['access_token'],'expiresIn':_0x420b7f['expires_in'],'refreshToken':_0x420b7f['refresh_token']};}async function vf(_0x55300d,_0xdef36){return Ae(_0x55300d,'POST','/v2/accounts:revokeToken',Re(_0x55300d,_0xdef36));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4fbaba){m(_0x4fbaba['idToken'],'internal-error'),m(typeof _0x4fbaba['idToken']<'u','internal-error'),m(typeof _0x4fbaba['refreshToken']<'u','internal-error');const _0x308b28='expiresIn'in _0x4fbaba&&typeof _0x4fbaba['expiresIn']<'u'?Number(_0x4fbaba['expiresIn']):Er(_0x4fbaba['idToken']);this['updateTokensAndExpiration'](_0x4fbaba['idToken'],_0x4fbaba['refreshToken'],_0x308b28);}['updateFromIdToken'](_0x36e984){m(_0x36e984['length']!==0x0,'internal-error');const _0x57b43b=Er(_0x36e984);this['updateTokensAndExpiration'](_0x36e984,null,_0x57b43b);}async['getToken'](_0x263338,_0x395238=!0x1){return!_0x395238&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x263338,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x263338,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2774a2,_0x1f22a1){const {accessToken:_0x50830d,refreshToken:_0x26e15f,expiresIn:_0xbec4a7}=await yf(_0x2774a2,_0x1f22a1);this['updateTokensAndExpiration'](_0x50830d,_0x26e15f,Number(_0xbec4a7));}['updateTokensAndExpiration'](_0xea101f,_0x3dffef,_0x3020ac){this['refreshToken']=_0x3dffef||null,this['accessToken']=_0xea101f||null,this['expirationTime']=Date['now']()+_0x3020ac*0x3e8;}static['fromJSON'](_0x5d7501,_0x17012d){const {refreshToken:_0xab6ff0,accessToken:_0x2e678e,expirationTime:_0x492607}=_0x17012d,_0x3d6391=new Je();return _0xab6ff0&&(m(typeof _0xab6ff0=='string','internal-error',{'appName':_0x5d7501}),_0x3d6391['refreshToken']=_0xab6ff0),_0x2e678e&&(m(typeof _0x2e678e=='string','internal-error',{'appName':_0x5d7501}),_0x3d6391['accessToken']=_0x2e678e),_0x492607&&(m(typeof _0x492607=='number','internal-error',{'appName':_0x5d7501}),_0x3d6391['expirationTime']=_0x492607),_0x3d6391;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x46840b){this['accessToken']=_0x46840b['accessToken'],this['refreshToken']=_0x46840b['refreshToken'],this['expirationTime']=_0x46840b['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x33cf2f,_0x38503c){m(typeof _0x33cf2f=='string'||typeof _0x33cf2f>'u','internal-error',{'appName':_0x38503c});}class z{constructor({uid:_0x29f869,auth:_0x5e696e,stsTokenManager:_0x5c76eb,..._0x2f5d06}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x29f869,this['auth']=_0x5e696e,this['stsTokenManager']=_0x5c76eb,this['accessToken']=_0x5c76eb['accessToken'],this['displayName']=_0x2f5d06['displayName']||null,this['email']=_0x2f5d06['email']||null,this['emailVerified']=_0x2f5d06['emailVerified']||!0x1,this['phoneNumber']=_0x2f5d06['phoneNumber']||null,this['photoURL']=_0x2f5d06['photoURL']||null,this['isAnonymous']=_0x2f5d06['isAnonymous']||!0x1,this['tenantId']=_0x2f5d06['tenantId']||null,this['providerData']=_0x2f5d06['providerData']?[..._0x2f5d06['providerData']]:[],this['metadata']=new Pi(_0x2f5d06['createdAt']||void 0x0,_0x2f5d06['lastLoginAt']||void 0x0);}async['getIdToken'](_0x215012){const _0xc67804=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x215012));return m(_0xc67804,this['auth'],'internal-error'),this['accessToken']!==_0xc67804&&(this['accessToken']=_0xc67804,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0xc67804;}['getIdTokenResult'](_0x2f0892){return ff(this,_0x2f0892);}['reload'](){return gf(this);}['_assign'](_0x210d43){this!==_0x210d43&&(m(this['uid']===_0x210d43['uid'],this['auth'],'internal-error'),this['displayName']=_0x210d43['displayName'],this['photoURL']=_0x210d43['photoURL'],this['email']=_0x210d43['email'],this['emailVerified']=_0x210d43['emailVerified'],this['phoneNumber']=_0x210d43['phoneNumber'],this['isAnonymous']=_0x210d43['isAnonymous'],this['tenantId']=_0x210d43['tenantId'],this['providerData']=_0x210d43['providerData']['map'](_0x5a0c3f=>({..._0x5a0c3f})),this['metadata']['_copy'](_0x210d43['metadata']),this['stsTokenManager']['_assign'](_0x210d43['stsTokenManager']));}['_clone'](_0xc1f2c5){const _0x187b0b=new z({...this,'auth':_0xc1f2c5,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x187b0b['metadata']['_copy'](this['metadata']),_0x187b0b;}['_onReload'](_0x1c10c8){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1c10c8,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x328997){this['reloadListener']?this['reloadListener'](_0x328997):this['reloadUserInfo']=_0x328997;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xe5d1cc,_0x5d3a24=!0x1){let _0x3f9bd9=!0x1;_0xe5d1cc['idToken']&&_0xe5d1cc['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xe5d1cc),_0x3f9bd9=!0x0),_0x5d3a24&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3f9bd9&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x1bf62e=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x1bf62e})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x530272=>({..._0x530272})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x10fb04,_0x14beec){const _0x2a790a=_0x14beec['displayName']??void 0x0,_0x1166f2=_0x14beec['email']??void 0x0,_0x3268c3=_0x14beec['phoneNumber']??void 0x0,_0x3526f0=_0x14beec['photoURL']??void 0x0,_0x5df3dc=_0x14beec['tenantId']??void 0x0,_0x50840c=_0x14beec['_redirectEventId']??void 0x0,_0xfe55e0=_0x14beec['createdAt']??void 0x0,_0x50266d=_0x14beec['lastLoginAt']??void 0x0,{uid:_0x179b07,emailVerified:_0x1a326d,isAnonymous:_0x581fbf,providerData:_0x4abebd,stsTokenManager:_0x172e13}=_0x14beec;m(_0x179b07&&_0x172e13,_0x10fb04,'internal-error');const _0x531fa7=Je['fromJSON'](this['name'],_0x172e13);m(typeof _0x179b07=='string',_0x10fb04,'internal-error'),ce(_0x2a790a,_0x10fb04['name']),ce(_0x1166f2,_0x10fb04['name']),m(typeof _0x1a326d=='boolean',_0x10fb04,'internal-error'),m(typeof _0x581fbf=='boolean',_0x10fb04,'internal-error'),ce(_0x3268c3,_0x10fb04['name']),ce(_0x3526f0,_0x10fb04['name']),ce(_0x5df3dc,_0x10fb04['name']),ce(_0x50840c,_0x10fb04['name']),ce(_0xfe55e0,_0x10fb04['name']),ce(_0x50266d,_0x10fb04['name']);const _0x220d64=new z({'uid':_0x179b07,'auth':_0x10fb04,'email':_0x1166f2,'emailVerified':_0x1a326d,'displayName':_0x2a790a,'isAnonymous':_0x581fbf,'photoURL':_0x3526f0,'phoneNumber':_0x3268c3,'tenantId':_0x5df3dc,'stsTokenManager':_0x531fa7,'createdAt':_0xfe55e0,'lastLoginAt':_0x50266d});return _0x4abebd&&Array['isArray'](_0x4abebd)&&(_0x220d64['providerData']=_0x4abebd['map'](_0x1be041=>({..._0x1be041}))),_0x50840c&&(_0x220d64['_redirectEventId']=_0x50840c),_0x220d64;}static async['_fromIdTokenResponse'](_0x49b2f0,_0x1f8f8f,_0x4559b0=!0x1){const _0x5936a8=new Je();_0x5936a8['updateFromServerResponse'](_0x1f8f8f);const _0x49dfd2=new z({'uid':_0x1f8f8f['localId'],'auth':_0x49b2f0,'stsTokenManager':_0x5936a8,'isAnonymous':_0x4559b0});return await bn(_0x49dfd2),_0x49dfd2;}static async['_fromGetAccountInfoResponse'](_0x121edb,_0x57c1f3,_0x4ab4ae){const _0x4bd7a8=_0x57c1f3['users'][0x0];m(_0x4bd7a8['localId']!==void 0x0,'internal-error');const _0x39f0d4=_0x4bd7a8['providerUserInfo']!==void 0x0?wa(_0x4bd7a8['providerUserInfo']):[],_0x4667f8=!(_0x4bd7a8['email']&&_0x4bd7a8['passwordHash'])&&!(_0x39f0d4!=null&&_0x39f0d4['length']),_0x5688bd=new Je();_0x5688bd['updateFromIdToken'](_0x4ab4ae);const _0x17b18c=new z({'uid':_0x4bd7a8['localId'],'auth':_0x121edb,'stsTokenManager':_0x5688bd,'isAnonymous':_0x4667f8}),_0x9a8b89={'uid':_0x4bd7a8['localId'],'displayName':_0x4bd7a8['displayName']||null,'photoURL':_0x4bd7a8['photoUrl']||null,'email':_0x4bd7a8['email']||null,'emailVerified':_0x4bd7a8['emailVerified']||!0x1,'phoneNumber':_0x4bd7a8['phoneNumber']||null,'tenantId':_0x4bd7a8['tenantId']||null,'providerData':_0x39f0d4,'metadata':new Pi(_0x4bd7a8['createdAt'],_0x4bd7a8['lastLoginAt']),'isAnonymous':!(_0x4bd7a8['email']&&_0x4bd7a8['passwordHash'])&&!(_0x39f0d4!=null&&_0x39f0d4['length'])};return Object['assign'](_0x17b18c,_0x9a8b89),_0x17b18c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x2da729){ae(_0x2da729 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x494f9d=Ir['get'](_0x2da729);return _0x494f9d?(ae(_0x494f9d instanceof _0x2da729,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x494f9d):(_0x494f9d=new _0x2da729(),Ir['set'](_0x2da729,_0x494f9d),_0x494f9d);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x520d03,_0x2bdfa6){this['storage'][_0x520d03]=_0x2bdfa6;}async['_get'](_0x305097){const _0x861d78=this['storage'][_0x305097];return _0x861d78===void 0x0?null:_0x861d78;}async['_remove'](_0x164464){delete this['storage'][_0x164464];}['_addListener'](_0x4847a0,_0x1d7e3b){}['_removeListener'](_0x110f92,_0x5e5e49){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x1203e4,_0x4cf18d,_0x1a93d3){return'firebase:'+_0x1203e4+':'+_0x4cf18d+':'+_0x1a93d3;}class Xe{constructor(_0x4b340e,_0x4fae2a,_0x56036d){this['persistence']=_0x4b340e,this['auth']=_0x4fae2a,this['userKey']=_0x56036d;const {config:_0x3012d4,name:_0x5a2a1a}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x3012d4['apiKey'],_0x5a2a1a),this['fullPersistenceKey']=sn('persistence',_0x3012d4['apiKey'],_0x5a2a1a),this['boundEventHandler']=_0x4fae2a['_onStorageEvent']['bind'](_0x4fae2a),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x20f5c5){return this['persistence']['_set'](this['fullUserKey'],_0x20f5c5['toJSON']());}async['getCurrentUser'](){const _0x5badc3=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5badc3)return null;if(typeof _0x5badc3=='string'){const _0x40b4d9=await Sn(this['auth'],{'idToken':_0x5badc3})['catch'](()=>{});return _0x40b4d9?z['_fromGetAccountInfoResponse'](this['auth'],_0x40b4d9,_0x5badc3):null;}return z['_fromJSON'](this['auth'],_0x5badc3);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x2152ed){if(this['persistence']===_0x2152ed)return;const _0x50eac1=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x2152ed,_0x50eac1)return this['setCurrentUser'](_0x50eac1);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1d2f0c,_0x382317,_0x3c00cc='authUser'){if(!_0x382317['length'])return new Xe(ne(wr),_0x1d2f0c,_0x3c00cc);const _0x45be4d=(await Promise['all'](_0x382317['map'](async _0x4e440b=>{if(await _0x4e440b['_isAvailable']())return _0x4e440b;})))['filter'](_0x28f045=>_0x28f045);let _0x582a76=_0x45be4d[0x0]||ne(wr);const _0x8a2d8e=sn(_0x3c00cc,_0x1d2f0c['config']['apiKey'],_0x1d2f0c['name']);let _0x2ad482=null;for(const _0x3a715c of _0x382317)try{const _0x540f3f=await _0x3a715c['_get'](_0x8a2d8e);if(_0x540f3f){let _0xd02b3a;if(typeof _0x540f3f=='string'){const _0x186d2f=await Sn(_0x1d2f0c,{'idToken':_0x540f3f})['catch'](()=>{});if(!_0x186d2f)break;_0xd02b3a=await z['_fromGetAccountInfoResponse'](_0x1d2f0c,_0x186d2f,_0x540f3f);}else _0xd02b3a=z['_fromJSON'](_0x1d2f0c,_0x540f3f);_0x3a715c!==_0x582a76&&(_0x2ad482=_0xd02b3a),_0x582a76=_0x3a715c;break;}}catch{}const _0x1c44f4=_0x45be4d['filter'](_0x552599=>_0x552599['_shouldAllowMigration']);return!_0x582a76['_shouldAllowMigration']||!_0x1c44f4['length']?new Xe(_0x582a76,_0x1d2f0c,_0x3c00cc):(_0x582a76=_0x1c44f4[0x0],_0x2ad482&&await _0x582a76['_set'](_0x8a2d8e,_0x2ad482['toJSON']()),await Promise['all'](_0x382317['map'](async _0x32cd10=>{if(_0x32cd10!==_0x582a76)try{await _0x32cd10['_remove'](_0x8a2d8e);}catch{}})),new Xe(_0x582a76,_0x1d2f0c,_0x3c00cc));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x33cb3d){const _0x176eaa=_0x33cb3d['toLowerCase']();if(_0x176eaa['includes']('opera/')||_0x176eaa['includes']('opr/')||_0x176eaa['includes']('opios/'))return'Opera';if(Ra(_0x176eaa))return'IEMobile';if(_0x176eaa['includes']('msie')||_0x176eaa['includes']('trident/'))return'IE';if(_0x176eaa['includes']('edge/'))return'Edge';if(Ta(_0x176eaa))return'Firefox';if(_0x176eaa['includes']('silk/'))return'Silk';if(ka(_0x176eaa))return'Blackberry';if(Na(_0x176eaa))return'Webos';if(Sa(_0x176eaa))return'Safari';if((_0x176eaa['includes']('chrome/')||ba(_0x176eaa))&&!_0x176eaa['includes']('edge/'))return'Chrome';if(Aa(_0x176eaa))return'Android';{const _0x345e2e=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x783d0c=_0x33cb3d['match'](_0x345e2e);if((_0x783d0c==null?void 0x0:_0x783d0c['length'])===0x2)return _0x783d0c[0x1];}return'Other';}function Ta(_0x572790=W()){return/firefox\//i['test'](_0x572790);}function Sa(_0x332bf6=W()){const _0x1861ff=_0x332bf6['toLowerCase']();return _0x1861ff['includes']('safari/')&&!_0x1861ff['includes']('chrome/')&&!_0x1861ff['includes']('crios/')&&!_0x1861ff['includes']('android');}function ba(_0xbaf65c=W()){return/crios\//i['test'](_0xbaf65c);}function Ra(_0x3061be=W()){return/iemobile/i['test'](_0x3061be);}function Aa(_0x39c94f=W()){return/android/i['test'](_0x39c94f);}function ka(_0x326f0a=W()){return/blackberry/i['test'](_0x326f0a);}function Na(_0x5b2aa6=W()){return/webos/i['test'](_0x5b2aa6);}function Cs(_0x1458c6=W()){return/iphone|ipad|ipod/i['test'](_0x1458c6)||/macintosh/i['test'](_0x1458c6)&&/mobile/i['test'](_0x1458c6);}function Ef(_0x29f79a=W()){var _0x154e07;return Cs(_0x29f79a)&&!!((_0x154e07=window['navigator'])!=null&&_0x154e07['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x102ad8=W()){return Cs(_0x102ad8)||Aa(_0x102ad8)||Na(_0x102ad8)||ka(_0x102ad8)||/windows phone/i['test'](_0x102ad8)||Ra(_0x102ad8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x51edfb,_0x52b4ae=[]){let _0x991956;switch(_0x51edfb){case'Browser':_0x991956=Cr(W());break;case'Worker':_0x991956=Cr(W())+'-'+_0x51edfb;break;default:_0x991956=_0x51edfb;}const _0x4f5cdc=_0x52b4ae['length']?_0x52b4ae['join'](','):'FirebaseCore-web';return _0x991956+'/JsCore/'+ct+'/'+_0x4f5cdc;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x585234){this['auth']=_0x585234,this['queue']=[];}['pushCallback'](_0x5dcf24,_0x2efa36){const _0x219fa8=_0x4317fd=>new Promise((_0x427dc3,_0x254594)=>{try{const _0x5356ba=_0x5dcf24(_0x4317fd);_0x427dc3(_0x5356ba);}catch(_0x321c7c){_0x254594(_0x321c7c);}});_0x219fa8['onAbort']=_0x2efa36,this['queue']['push'](_0x219fa8);const _0x51ab93=this['queue']['length']-0x1;return()=>{this['queue'][_0x51ab93]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3a1c5b){if(this['auth']['currentUser']===_0x3a1c5b)return;const _0xa9bc07=[];try{for(const _0x2c1569 of this['queue'])await _0x2c1569(_0x3a1c5b),_0x2c1569['onAbort']&&_0xa9bc07['push'](_0x2c1569['onAbort']);}catch(_0x175b55){_0xa9bc07['reverse']();for(const _0x36408e of _0xa9bc07)try{_0x36408e();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x175b55==null?void 0x0:_0x175b55['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x34377d,_0x7c95c0={}){return Ae(_0x34377d,'GET','/v2/passwordPolicy',Re(_0x34377d,_0x7c95c0));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x3409c7){var _0x54da3a;const _0x44ea9d=_0x3409c7['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x44ea9d['minPasswordLength']??Tf,_0x44ea9d['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x44ea9d['maxPasswordLength']),_0x44ea9d['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x44ea9d['containsLowercaseCharacter']),_0x44ea9d['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x44ea9d['containsUppercaseCharacter']),_0x44ea9d['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x44ea9d['containsNumericCharacter']),_0x44ea9d['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x44ea9d['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3409c7['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x54da3a=_0x3409c7['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x54da3a['join'](''))??'',this['forceUpgradeOnSignin']=_0x3409c7['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3409c7['schemaVersion'];}['validatePassword'](_0x27286a){const _0x43eb01={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x27286a,_0x43eb01),this['validatePasswordCharacterOptions'](_0x27286a,_0x43eb01),_0x43eb01['isValid']&&(_0x43eb01['isValid']=_0x43eb01['meetsMinPasswordLength']??!0x0),_0x43eb01['isValid']&&(_0x43eb01['isValid']=_0x43eb01['meetsMaxPasswordLength']??!0x0),_0x43eb01['isValid']&&(_0x43eb01['isValid']=_0x43eb01['containsLowercaseLetter']??!0x0),_0x43eb01['isValid']&&(_0x43eb01['isValid']=_0x43eb01['containsUppercaseLetter']??!0x0),_0x43eb01['isValid']&&(_0x43eb01['isValid']=_0x43eb01['containsNumericCharacter']??!0x0),_0x43eb01['isValid']&&(_0x43eb01['isValid']=_0x43eb01['containsNonAlphanumericCharacter']??!0x0),_0x43eb01;}['validatePasswordLengthOptions'](_0x76fb63,_0x54fb3a){const _0x209da3=this['customStrengthOptions']['minPasswordLength'],_0x25cd09=this['customStrengthOptions']['maxPasswordLength'];_0x209da3&&(_0x54fb3a['meetsMinPasswordLength']=_0x76fb63['length']>=_0x209da3),_0x25cd09&&(_0x54fb3a['meetsMaxPasswordLength']=_0x76fb63['length']<=_0x25cd09);}['validatePasswordCharacterOptions'](_0x40edf1,_0x29ea22){this['updatePasswordCharacterOptionsStatuses'](_0x29ea22,!0x1,!0x1,!0x1,!0x1);let _0x3aa175;for(let _0x54dd8f=0x0;_0x54dd8f<_0x40edf1['length'];_0x54dd8f++)_0x3aa175=_0x40edf1['charAt'](_0x54dd8f),this['updatePasswordCharacterOptionsStatuses'](_0x29ea22,_0x3aa175>='a'&&_0x3aa175<='z',_0x3aa175>='A'&&_0x3aa175<='Z',_0x3aa175>='0'&&_0x3aa175<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3aa175));}['updatePasswordCharacterOptionsStatuses'](_0x322040,_0x73c837,_0x4baf63,_0x59a13b,_0x18dd49){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x322040['containsLowercaseLetter']||(_0x322040['containsLowercaseLetter']=_0x73c837)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x322040['containsUppercaseLetter']||(_0x322040['containsUppercaseLetter']=_0x4baf63)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x322040['containsNumericCharacter']||(_0x322040['containsNumericCharacter']=_0x59a13b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x322040['containsNonAlphanumericCharacter']||(_0x322040['containsNonAlphanumericCharacter']=_0x18dd49));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x401446,_0x48cc19,_0x238bf7,_0x3b41c3){this['app']=_0x401446,this['heartbeatServiceProvider']=_0x48cc19,this['appCheckServiceProvider']=_0x238bf7,this['config']=_0x3b41c3,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x401446['name'],this['clientVersion']=_0x3b41c3['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x33cd69=>this['_resolvePersistenceManagerAvailable']=_0x33cd69);}['_initializeWithPersistence'](_0x5cf943,_0x2017b8){return _0x2017b8&&(this['_popupRedirectResolver']=ne(_0x2017b8)),this['_initializationPromise']=this['queue'](async()=>{var _0x2eb0f7,_0x16f12a,_0x3e1b3f;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x5cf943),(_0x2eb0f7=this['_resolvePersistenceManagerAvailable'])==null||_0x2eb0f7['call'](this),!this['_deleted'])){if((_0x16f12a=this['_popupRedirectResolver'])!=null&&_0x16f12a['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2017b8),this['lastNotifiedUid']=((_0x3e1b3f=this['currentUser'])==null?void 0x0:_0x3e1b3f['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x4abc1a=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x4abc1a)){if(this['currentUser']&&_0x4abc1a&&this['currentUser']['uid']===_0x4abc1a['uid']){this['_currentUser']['_assign'](_0x4abc1a),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x4abc1a,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x45baa2){try{const _0x325dcc=await Sn(this,{'idToken':_0x45baa2}),_0x4ac52a=await z['_fromGetAccountInfoResponse'](this,_0x325dcc,_0x45baa2);await this['directlySetCurrentUser'](_0x4ac52a);}catch(_0x38ba75){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x38ba75),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x1b5a03){var _0x2fd7ce;if(H(this['app'])){const _0x3fe6c5=this['app']['settings']['authIdToken'];return _0x3fe6c5?new Promise(_0x2cd2f8=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3fe6c5)['then'](_0x2cd2f8,_0x2cd2f8));}):this['directlySetCurrentUser'](null);}const _0x2c9d2d=await this['assertedPersistence']['getCurrentUser']();let _0x59bfcf=_0x2c9d2d,_0x502ce4=!0x1;if(_0x1b5a03&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1ef9d2=(_0x2fd7ce=this['redirectUser'])==null?void 0x0:_0x2fd7ce['_redirectEventId'],_0x5f3ec7=_0x59bfcf==null?void 0x0:_0x59bfcf['_redirectEventId'],_0x3c102f=await this['tryRedirectSignIn'](_0x1b5a03);(!_0x1ef9d2||_0x1ef9d2===_0x5f3ec7)&&(_0x3c102f!=null&&_0x3c102f['user'])&&(_0x59bfcf=_0x3c102f['user'],_0x502ce4=!0x0);}if(!_0x59bfcf)return this['directlySetCurrentUser'](null);if(!_0x59bfcf['_redirectEventId']){if(_0x502ce4)try{await this['beforeStateQueue']['runMiddleware'](_0x59bfcf);}catch(_0x3e01f7){_0x59bfcf=_0x2c9d2d,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3e01f7));}return _0x59bfcf?this['reloadAndSetCurrentUserOrClear'](_0x59bfcf):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x59bfcf['_redirectEventId']?this['directlySetCurrentUser'](_0x59bfcf):this['reloadAndSetCurrentUserOrClear'](_0x59bfcf);}async['tryRedirectSignIn'](_0x3b4f82){let _0x5aaf62=null;try{_0x5aaf62=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3b4f82,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5aaf62;}async['reloadAndSetCurrentUserOrClear'](_0x39f0e2){try{await bn(_0x39f0e2);}catch(_0x48546b){if((_0x48546b==null?void 0x0:_0x48546b['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x39f0e2);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x139074){if(H(this['app']))return Promise['reject'](se(this));const _0x272449=_0x139074?k(_0x139074):null;return _0x272449&&m(_0x272449['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x272449&&_0x272449['_clone'](this));}async['_updateCurrentUser'](_0x21601e,_0x1f75ab=!0x1){if(!this['_deleted'])return _0x21601e&&m(this['tenantId']===_0x21601e['tenantId'],this,'tenant-id-mismatch'),_0x1f75ab||await this['beforeStateQueue']['runMiddleware'](_0x21601e),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x21601e),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3e5ad8){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x3e5ad8));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x920ca0){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1bd89e=this['_getPasswordPolicyInternal']();return _0x1bd89e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1bd89e['validatePassword'](_0x920ca0);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x18fbaa=await Cf(this),_0x4da753=new Sf(_0x18fbaa);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4da753:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4da753;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2fa751){this['_errorFactory']=new Ut('auth','Firebase',_0x2fa751());}['onAuthStateChanged'](_0x4e0273,_0x21fc47,_0x3e0f5f){return this['registerStateListener'](this['authStateSubscription'],_0x4e0273,_0x21fc47,_0x3e0f5f);}['beforeAuthStateChanged'](_0x479e86,_0x5016b4){return this['beforeStateQueue']['pushCallback'](_0x479e86,_0x5016b4);}['onIdTokenChanged'](_0x4d5479,_0x9dc585,_0xe9b577){return this['registerStateListener'](this['idTokenSubscription'],_0x4d5479,_0x9dc585,_0xe9b577);}['authStateReady'](){return new Promise((_0x49cea6,_0xc2228)=>{if(this['currentUser'])_0x49cea6();else{const _0x4c348b=this['onAuthStateChanged'](()=>{_0x4c348b(),_0x49cea6();},_0xc2228);}});}async['revokeAccessToken'](_0x5f6f19){if(this['currentUser']){const _0x36c7c9=await this['currentUser']['getIdToken'](),_0x22cf44={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x5f6f19,'idToken':_0x36c7c9};this['tenantId']!=null&&(_0x22cf44['tenantId']=this['tenantId']),await vf(this,_0x22cf44);}}['toJSON'](){var _0x1922f6;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x1922f6=this['_currentUser'])==null?void 0x0:_0x1922f6['toJSON']()};}async['_setRedirectUser'](_0x2b1c50,_0x914817){const _0x9267cd=await this['getOrInitRedirectPersistenceManager'](_0x914817);return _0x2b1c50===null?_0x9267cd['removeCurrentUser']():_0x9267cd['setCurrentUser'](_0x2b1c50);}async['getOrInitRedirectPersistenceManager'](_0x11cc17){if(!this['redirectPersistenceManager']){const _0x4c7f82=_0x11cc17&&ne(_0x11cc17)||this['_popupRedirectResolver'];m(_0x4c7f82,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x4c7f82['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2e2bd9){var _0x2b3f38,_0x5f574d;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2b3f38=this['_currentUser'])==null?void 0x0:_0x2b3f38['_redirectEventId'])===_0x2e2bd9?this['_currentUser']:((_0x5f574d=this['redirectUser'])==null?void 0x0:_0x5f574d['_redirectEventId'])===_0x2e2bd9?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3f2899){if(_0x3f2899===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3f2899));}['_notifyListenersIfCurrent'](_0x1c8acd){_0x1c8acd===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x3c8e38;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x522711=((_0x3c8e38=this['currentUser'])==null?void 0x0:_0x3c8e38['uid'])??null;this['lastNotifiedUid']!==_0x522711&&(this['lastNotifiedUid']=_0x522711,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x27fc04,_0x175b54,_0x1ff5fd,_0x535b7e){if(this['_deleted'])return()=>{};const _0x92161c=typeof _0x175b54=='function'?_0x175b54:_0x175b54['next']['bind'](_0x175b54);let _0x1720b0=!0x1;const _0x31b9e7=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x31b9e7,this,'internal-error'),_0x31b9e7['then'](()=>{_0x1720b0||_0x92161c(this['currentUser']);}),typeof _0x175b54=='function'){const _0x4d18fb=_0x27fc04['addObserver'](_0x175b54,_0x1ff5fd,_0x535b7e);return()=>{_0x1720b0=!0x0,_0x4d18fb();};}else{const _0x1a120d=_0x27fc04['addObserver'](_0x175b54);return()=>{_0x1720b0=!0x0,_0x1a120d();};}}async['directlySetCurrentUser'](_0xb9defa){this['currentUser']&&this['currentUser']!==_0xb9defa&&this['_currentUser']['_stopProactiveRefresh'](),_0xb9defa&&this['isProactiveRefreshEnabled']&&_0xb9defa['_startProactiveRefresh'](),this['currentUser']=_0xb9defa,_0xb9defa?await this['assertedPersistence']['setCurrentUser'](_0xb9defa):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3a8705){return this['operations']=this['operations']['then'](_0x3a8705,_0x3a8705),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x39ebdf){!_0x39ebdf||this['frameworks']['includes'](_0x39ebdf)||(this['frameworks']['push'](_0x39ebdf),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x416ddd;const _0x2a5d4d={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x2a5d4d['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x391d1a=await((_0x416ddd=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x416ddd['getHeartbeatsHeader']());_0x391d1a&&(_0x2a5d4d['X-Firebase-Client']=_0x391d1a);const _0x42f1b1=await this['_getAppCheckToken']();return _0x42f1b1&&(_0x2a5d4d['X-Firebase-AppCheck']=_0x42f1b1),_0x2a5d4d;}async['_getAppCheckToken'](){var _0x4baae4;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x648a84=await((_0x4baae4=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4baae4['getToken']());return _0x648a84!=null&&_0x648a84['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x648a84['error']),_0x648a84==null?void 0x0:_0x648a84['token'];}}function qe(_0x1ffb18){return k(_0x1ffb18);}class Tr{constructor(_0x2f17a1){this['auth']=_0x2f17a1,this['observer']=null,this['addObserver']=Ic(_0x47bbe3=>this['observer']=_0x47bbe3);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x53bf2a){zn=_0x53bf2a;}function Da(_0x418b81){return zn['loadJS'](_0x418b81);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x4303c6){return'__'+_0x4303c6+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x4e14bc){_0x4e14bc();}['execute'](_0x4e26b6,_0x3f9417){return Promise['resolve']('token');}['render'](_0x2e5bdb,_0xd9761c){return'';}}class Of{['ready'](_0x356d12){_0x356d12();}['execute'](_0x172362,_0x2f47df){return Promise['resolve']('token');}['render'](_0x124773,_0x133d2c){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x55fa66){this['type']=Df,this['auth']=qe(_0x55fa66);}async['verify'](_0x5e9412='verify',_0x23d588=!0x1){async function _0x5afded(_0x54ab49){if(!_0x23d588){if(_0x54ab49['tenantId']==null&&_0x54ab49['_agentRecaptchaConfig']!=null)return _0x54ab49['_agentRecaptchaConfig']['siteKey'];if(_0x54ab49['tenantId']!=null&&_0x54ab49['_tenantRecaptchaConfigs'][_0x54ab49['tenantId']]!==void 0x0)return _0x54ab49['_tenantRecaptchaConfigs'][_0x54ab49['tenantId']]['siteKey'];}return new Promise(async(_0x29d177,_0x3179cd)=>{uf(_0x54ab49,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x598d5d=>{if(_0x598d5d['recaptchaKey']===void 0x0)_0x3179cd(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4f0125=new hf(_0x598d5d);return _0x54ab49['tenantId']==null?_0x54ab49['_agentRecaptchaConfig']=_0x4f0125:_0x54ab49['_tenantRecaptchaConfigs'][_0x54ab49['tenantId']]=_0x4f0125,_0x29d177(_0x4f0125['siteKey']);}})['catch'](_0xaf4e45=>{_0x3179cd(_0xaf4e45);});});}function _0x3e2e98(_0x5182d3,_0x20b7fd,_0x361779){const _0x2a2341=window['grecaptcha'];vr(_0x2a2341)?_0x2a2341['enterprise']['ready'](()=>{_0x2a2341['enterprise']['execute'](_0x5182d3,{'action':_0x5e9412})['then'](_0x5808c8=>{_0x20b7fd(_0x5808c8);})['catch'](()=>{_0x20b7fd(Ma);});}):_0x361779(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x57433d,_0x1f123e)=>{_0x5afded(this['auth'])['then'](async _0x53316e=>{if(!_0x23d588&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x3e2e98(_0x53316e,_0x57433d,_0x1f123e);else{if(typeof window>'u'){_0x1f123e(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2ee9af=Af();_0x2ee9af['length']!==0x0&&(_0x2ee9af+=_0x53316e+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x3f9d7e;(_0x3f9d7e=le['scriptInjectionDeferred'])==null||_0x3f9d7e['resolve']();},Da(_0x2ee9af)['then'](()=>{var _0x18a030;return(_0x18a030=le['scriptInjectionDeferred'])==null?void 0x0:_0x18a030['promise'];})['then'](()=>{_0x3e2e98(_0x53316e,_0x57433d,_0x1f123e);})['catch'](_0x34bafc=>{_0x1f123e(_0x34bafc);});}})['catch'](_0x261061=>{_0x1f123e(_0x261061);});});}}le['scriptInjectionDeferred']=null;async function br(_0x312511,_0x171b12,_0x44fe37,_0x55572a=!0x1,_0x5d5899=!0x1){const _0x1bba8d=new le(_0x312511);let _0x16c00c;if(_0x5d5899)_0x16c00c=Ma;else try{_0x16c00c=await _0x1bba8d['verify'](_0x44fe37);}catch{_0x16c00c=await _0x1bba8d['verify'](_0x44fe37,!0x0);}const _0x3327dc={..._0x171b12};if(_0x44fe37==='mfaSmsEnrollment'||_0x44fe37==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3327dc){const _0x201acd=_0x3327dc['phoneEnrollmentInfo']['phoneNumber'],_0x53f3ca=_0x3327dc['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3327dc,{'phoneEnrollmentInfo':{'phoneNumber':_0x201acd,'recaptchaToken':_0x53f3ca,'captchaResponse':_0x16c00c,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3327dc){const _0x57d3c3=_0x3327dc['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3327dc,{'phoneSignInInfo':{'recaptchaToken':_0x57d3c3,'captchaResponse':_0x16c00c,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3327dc;}return _0x55572a?Object['assign'](_0x3327dc,{'captchaResp':_0x16c00c}):Object['assign'](_0x3327dc,{'captchaResponse':_0x16c00c}),Object['assign'](_0x3327dc,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3327dc,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3327dc;}async function Oi(_0xba0558,_0x54a979,_0x12a1ff,_0x38bd62,_0x392572){var _0x112128;if((_0x112128=_0xba0558['_getRecaptchaConfig']())!=null&&_0x112128['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xf16014=await br(_0xba0558,_0x54a979,_0x12a1ff,_0x12a1ff==='getOobCode');return _0x38bd62(_0xba0558,_0xf16014);}else return _0x38bd62(_0xba0558,_0x54a979)['catch'](async _0x423f35=>{if(_0x423f35['code']==='auth/missing-recaptcha-token'){console['log'](_0x12a1ff+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x54b758=await br(_0xba0558,_0x54a979,_0x12a1ff,_0x12a1ff==='getOobCode');return _0x38bd62(_0xba0558,_0x54b758);}else return Promise['reject'](_0x423f35);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x599562,_0x27971f){const _0xc67d9=Ui(_0x599562,'auth');if(_0xc67d9['isInitialized']()){const _0x1c6a37=_0xc67d9['getImmediate'](),_0x1e870c=_0xc67d9['getOptions']();if(De(_0x1e870c,_0x27971f??{}))return _0x1c6a37;K(_0x1c6a37,'already-initialized');}return _0xc67d9['initialize']({'options':_0x27971f});}function Lf(_0x3c3103,_0x3310d7){const _0x46dd80=(_0x3310d7==null?void 0x0:_0x3310d7['persistence'])||[],_0x2e2bd2=(Array['isArray'](_0x46dd80)?_0x46dd80:[_0x46dd80])['map'](ne);_0x3310d7!=null&&_0x3310d7['errorMap']&&_0x3c3103['_updateErrorMap'](_0x3310d7['errorMap']),_0x3c3103['_initializeWithPersistence'](_0x2e2bd2,_0x3310d7==null?void 0x0:_0x3310d7['popupRedirectResolver']);}function xf(_0x256cb7,_0x2f43e7,_0x5daede){const _0x7ea4bf=qe(_0x256cb7);m(/^https?:\/\//['test'](_0x2f43e7),_0x7ea4bf,'invalid-emulator-scheme');const _0x33af66=!0x1,_0x809ae9=La(_0x2f43e7),{host:_0x28eb2c,port:_0x2dab77}=Ff(_0x2f43e7),_0x351435=_0x2dab77===null?'':':'+_0x2dab77,_0x137604={'url':_0x809ae9+'//'+_0x28eb2c+_0x351435+'/'},_0x48440e=Object['freeze']({'host':_0x28eb2c,'port':_0x2dab77,'protocol':_0x809ae9['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x33af66})});if(!_0x7ea4bf['_canInitEmulator']){m(_0x7ea4bf['config']['emulator']&&_0x7ea4bf['emulatorConfig'],_0x7ea4bf,'emulator-config-failed'),m(De(_0x137604,_0x7ea4bf['config']['emulator'])&&De(_0x48440e,_0x7ea4bf['emulatorConfig']),_0x7ea4bf,'emulator-config-failed');return;}_0x7ea4bf['config']['emulator']=_0x137604,_0x7ea4bf['emulatorConfig']=_0x48440e,_0x7ea4bf['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x28eb2c)?jr(_0x809ae9+'//'+_0x28eb2c+_0x351435):Uf();}function La(_0x5cafa2){const _0x567a0f=_0x5cafa2['indexOf'](':');return _0x567a0f<0x0?'':_0x5cafa2['substr'](0x0,_0x567a0f+0x1);}function Ff(_0x4aacea){const _0x301d63=La(_0x4aacea),_0x1d8598=/(\/\/)?([^?#/]+)/['exec'](_0x4aacea['substr'](_0x301d63['length']));if(!_0x1d8598)return{'host':'','port':null};const _0x179436=_0x1d8598[0x2]['split']('@')['pop']()||'',_0x129afa=/^(\[[^\]]+\])(:|$)/['exec'](_0x179436);if(_0x129afa){const _0x28dafe=_0x129afa[0x1];return{'host':_0x28dafe,'port':Rr(_0x179436['substr'](_0x28dafe['length']+0x1))};}else{const [_0x2ea951,_0x3b0538]=_0x179436['split'](':');return{'host':_0x2ea951,'port':Rr(_0x3b0538)};}}function Rr(_0x690d81){if(!_0x690d81)return null;const _0x52203a=Number(_0x690d81);return isNaN(_0x52203a)?null:_0x52203a;}function Uf(){function _0x5b68b8(){const _0x390257=document['createElement']('p'),_0x4562eb=_0x390257['style'];_0x390257['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4562eb['position']='fixed',_0x4562eb['width']='100%',_0x4562eb['backgroundColor']='#ffffff',_0x4562eb['border']='.1em\x20solid\x20#000000',_0x4562eb['color']='#b50000',_0x4562eb['bottom']='0px',_0x4562eb['left']='0px',_0x4562eb['margin']='0px',_0x4562eb['zIndex']='10000',_0x4562eb['textAlign']='center',_0x390257['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x390257);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x5b68b8):_0x5b68b8());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x4418b9,_0x588d5b){this['providerId']=_0x4418b9,this['signInMethod']=_0x588d5b;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x59ab2d){return te('not\x20implemented');}['_linkToIdToken'](_0x4a752b,_0x9cae9f){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x2f5d3e){return te('not\x20implemented');}}async function Wf(_0x27e4bb,_0x94a405){return Ae(_0x27e4bb,'POST','/v1/accounts:signUp',_0x94a405);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x516bb1,_0x26a4cb){return Yt(_0x516bb1,'POST','/v1/accounts:signInWithPassword',Re(_0x516bb1,_0x26a4cb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x433325,_0x2a7d0e){return Yt(_0x433325,'POST','/v1/accounts:signInWithEmailLink',Re(_0x433325,_0x2a7d0e));}async function Hf(_0xbce288,_0x309954){return Yt(_0xbce288,'POST','/v1/accounts:signInWithEmailLink',Re(_0xbce288,_0x309954));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x90a469,_0x4bdc80,_0xdab543,_0x592bdc=null){super('password',_0xdab543),this['_email']=_0x90a469,this['_password']=_0x4bdc80,this['_tenantId']=_0x592bdc;}static['_fromEmailAndPassword'](_0x5edb53,_0x591e7a){return new Ft(_0x5edb53,_0x591e7a,'password');}static['_fromEmailAndCode'](_0x389f71,_0x31552c,_0x5063cb=null){return new Ft(_0x389f71,_0x31552c,'emailLink',_0x5063cb);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x128069){const _0x4c0c44=typeof _0x128069=='string'?JSON['parse'](_0x128069):_0x128069;if(_0x4c0c44!=null&&_0x4c0c44['email']&&(_0x4c0c44!=null&&_0x4c0c44['password'])){if(_0x4c0c44['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x4c0c44['email'],_0x4c0c44['password']);if(_0x4c0c44['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x4c0c44['email'],_0x4c0c44['password'],_0x4c0c44['tenantId']);}return null;}async['_getIdTokenResponse'](_0x248f16){switch(this['signInMethod']){case'password':const _0x1a5f61={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x248f16,_0x1a5f61,'signInWithPassword',Bf);case'emailLink':return Vf(_0x248f16,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x248f16,'internal-error');}}async['_linkToIdToken'](_0x4fa8f9,_0x819999){switch(this['signInMethod']){case'password':const _0x13918e={'idToken':_0x819999,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x4fa8f9,_0x13918e,'signUpPassword',Wf);case'emailLink':return Hf(_0x4fa8f9,{'idToken':_0x819999,'email':this['_email'],'oobCode':this['_password']});default:K(_0x4fa8f9,'internal-error');}}['_getReauthenticationResolver'](_0x20a4a3){return this['_getIdTokenResponse'](_0x20a4a3);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x23b7f7,_0x4366fa){return Yt(_0x23b7f7,'POST','/v1/accounts:signInWithIdp',Re(_0x23b7f7,_0x4366fa));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x234669){const _0x57e002=new We(_0x234669['providerId'],_0x234669['signInMethod']);return _0x234669['idToken']||_0x234669['accessToken']?(_0x234669['idToken']&&(_0x57e002['idToken']=_0x234669['idToken']),_0x234669['accessToken']&&(_0x57e002['accessToken']=_0x234669['accessToken']),_0x234669['nonce']&&!_0x234669['pendingToken']&&(_0x57e002['nonce']=_0x234669['nonce']),_0x234669['pendingToken']&&(_0x57e002['pendingToken']=_0x234669['pendingToken'])):_0x234669['oauthToken']&&_0x234669['oauthTokenSecret']?(_0x57e002['accessToken']=_0x234669['oauthToken'],_0x57e002['secret']=_0x234669['oauthTokenSecret']):K('argument-error'),_0x57e002;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3c26d9){const _0xd9524e=typeof _0x3c26d9=='string'?JSON['parse'](_0x3c26d9):_0x3c26d9,{providerId:_0x342207,signInMethod:_0x264784,..._0x22382a}=_0xd9524e;if(!_0x342207||!_0x264784)return null;const _0x13e504=new We(_0x342207,_0x264784);return _0x13e504['idToken']=_0x22382a['idToken']||void 0x0,_0x13e504['accessToken']=_0x22382a['accessToken']||void 0x0,_0x13e504['secret']=_0x22382a['secret'],_0x13e504['nonce']=_0x22382a['nonce'],_0x13e504['pendingToken']=_0x22382a['pendingToken']||null,_0x13e504;}['_getIdTokenResponse'](_0x42ed8f){const _0x300179=this['buildRequest']();return Ze(_0x42ed8f,_0x300179);}['_linkToIdToken'](_0x4ab797,_0x207a0d){const _0x45a99b=this['buildRequest']();return _0x45a99b['idToken']=_0x207a0d,Ze(_0x4ab797,_0x45a99b);}['_getReauthenticationResolver'](_0x13e3e6){const _0x3371dd=this['buildRequest']();return _0x3371dd['autoCreate']=!0x1,Ze(_0x13e3e6,_0x3371dd);}['buildRequest'](){const _0x2a540c={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x2a540c['pendingToken']=this['pendingToken'];else{const _0x18d8de={};this['idToken']&&(_0x18d8de['id_token']=this['idToken']),this['accessToken']&&(_0x18d8de['access_token']=this['accessToken']),this['secret']&&(_0x18d8de['oauth_token_secret']=this['secret']),_0x18d8de['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x18d8de['nonce']=this['nonce']),_0x2a540c['postBody']=at(_0x18d8de);}return _0x2a540c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x464fec){switch(_0x464fec){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x49ccc2){const _0x347e4b=yt(vt(_0x49ccc2))['link'],_0x40ed7a=_0x347e4b?yt(vt(_0x347e4b))['deep_link_id']:null,_0x16ad60=yt(vt(_0x49ccc2))['deep_link_id'];return(_0x16ad60?yt(vt(_0x16ad60))['link']:null)||_0x16ad60||_0x40ed7a||_0x347e4b||_0x49ccc2;}class Ss{constructor(_0x4f35e9){const _0x56ca1a=yt(vt(_0x4f35e9)),_0x2f7af0=_0x56ca1a['apiKey']??null,_0x34dc6d=_0x56ca1a['oobCode']??null,_0x539360=Gf(_0x56ca1a['mode']??null);m(_0x2f7af0&&_0x34dc6d&&_0x539360,'argument-error'),this['apiKey']=_0x2f7af0,this['operation']=_0x539360,this['code']=_0x34dc6d,this['continueUrl']=_0x56ca1a['continueUrl']??null,this['languageCode']=_0x56ca1a['lang']??null,this['tenantId']=_0x56ca1a['tenantId']??null;}static['parseLink'](_0x1a504d){const _0x53c477=qf(_0x1a504d);try{return new Ss(_0x53c477);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x514bee,_0xd8ce47){return Ft['_fromEmailAndPassword'](_0x514bee,_0xd8ce47);}static['credentialWithLink'](_0x1e5966,_0x448aa7){const _0x150a23=Ss['parseLink'](_0x448aa7);return m(_0x150a23,'argument-error'),Ft['_fromEmailAndCode'](_0x1e5966,_0x150a23['code'],_0x150a23['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x6cafbe){this['providerId']=_0x6cafbe,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0xa08f20){this['defaultLanguageCode']=_0xa08f20;}['setCustomParameters'](_0xa615e4){return this['customParameters']=_0xa615e4,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1edbec){return this['scopes']['includes'](_0x1edbec)||this['scopes']['push'](_0x1edbec),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0xa3af9c){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xa3af9c});}static['credentialFromResult'](_0x4d2138){return he['credentialFromTaggedObject'](_0x4d2138);}static['credentialFromError'](_0x223b8b){return he['credentialFromTaggedObject'](_0x223b8b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x507bd2}){if(!_0x507bd2||!('oauthAccessToken'in _0x507bd2)||!_0x507bd2['oauthAccessToken'])return null;try{return he['credential'](_0x507bd2['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3718ba,_0x591225){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3718ba,'accessToken':_0x591225});}static['credentialFromResult'](_0x254522){return ue['credentialFromTaggedObject'](_0x254522);}static['credentialFromError'](_0x321208){return ue['credentialFromTaggedObject'](_0x321208['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x188346}){if(!_0x188346)return null;const {oauthIdToken:_0x2c212c,oauthAccessToken:_0x3dd7b1}=_0x188346;if(!_0x2c212c&&!_0x3dd7b1)return null;try{return ue['credential'](_0x2c212c,_0x3dd7b1);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x5f32d2){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5f32d2});}static['credentialFromResult'](_0x20c137){return de['credentialFromTaggedObject'](_0x20c137);}static['credentialFromError'](_0x211c4c){return de['credentialFromTaggedObject'](_0x211c4c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3eb85c}){if(!_0x3eb85c||!('oauthAccessToken'in _0x3eb85c)||!_0x3eb85c['oauthAccessToken'])return null;try{return de['credential'](_0x3eb85c['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x594c22,_0x381bbf){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x594c22,'oauthTokenSecret':_0x381bbf});}static['credentialFromResult'](_0x446226){return fe['credentialFromTaggedObject'](_0x446226);}static['credentialFromError'](_0x2da60e){return fe['credentialFromTaggedObject'](_0x2da60e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x592223}){if(!_0x592223)return null;const {oauthAccessToken:_0x3e7f6e,oauthTokenSecret:_0x499e3b}=_0x592223;if(!_0x3e7f6e||!_0x499e3b)return null;try{return fe['credential'](_0x3e7f6e,_0x499e3b);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x2164cf,_0x58f24a){return Yt(_0x2164cf,'POST','/v1/accounts:signUp',Re(_0x2164cf,_0x58f24a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xf11531){this['user']=_0xf11531['user'],this['providerId']=_0xf11531['providerId'],this['_tokenResponse']=_0xf11531['_tokenResponse'],this['operationType']=_0xf11531['operationType'];}static async['_fromIdTokenResponse'](_0x5b1d63,_0x4192b5,_0x752532,_0x55f26=!0x1){const _0x182dca=await z['_fromIdTokenResponse'](_0x5b1d63,_0x752532,_0x55f26),_0x2678ad=Ar(_0x752532);return new Be({'user':_0x182dca,'providerId':_0x2678ad,'_tokenResponse':_0x752532,'operationType':_0x4192b5});}static async['_forOperation'](_0x29fecb,_0x1da6dd,_0x4b7c1b){await _0x29fecb['_updateTokensIfNecessary'](_0x4b7c1b,!0x0);const _0x7d9438=Ar(_0x4b7c1b);return new Be({'user':_0x29fecb,'providerId':_0x7d9438,'_tokenResponse':_0x4b7c1b,'operationType':_0x1da6dd});}}function Ar(_0x3d3e66){return _0x3d3e66['providerId']?_0x3d3e66['providerId']:'phoneNumber'in _0x3d3e66?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0xdb45fc,_0x321de6,_0x33ba0c,_0x14bc01){super(_0x321de6['code'],_0x321de6['message']),this['operationType']=_0x33ba0c,this['user']=_0x14bc01,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0xdb45fc['name'],'tenantId':_0xdb45fc['tenantId']??void 0x0,'_serverResponse':_0x321de6['customData']['_serverResponse'],'operationType':_0x33ba0c};}static['_fromErrorAndOperation'](_0xd62135,_0x1351cd,_0x3f0207,_0xc3b755){return new Rn(_0xd62135,_0x1351cd,_0x3f0207,_0xc3b755);}}function Fa(_0x41686d,_0x4406e1,_0x227a6a,_0x293548){return(_0x4406e1==='reauthenticate'?_0x227a6a['_getReauthenticationResolver'](_0x41686d):_0x227a6a['_getIdTokenResponse'](_0x41686d))['catch'](_0x36523f=>{throw _0x36523f['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x41686d,_0x36523f,_0x4406e1,_0x293548):_0x36523f;});}async function jf(_0x49d49e,_0x2e335d,_0x4c63d6=!0x1){const _0x3139e5=await xt(_0x49d49e,_0x2e335d['_linkToIdToken'](_0x49d49e['auth'],await _0x49d49e['getIdToken']()),_0x4c63d6);return Be['_forOperation'](_0x49d49e,'link',_0x3139e5);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x45c053,_0x3a0a35,_0x1c452a=!0x1){const {auth:_0x3d7400}=_0x45c053;if(H(_0x3d7400['app']))return Promise['reject'](se(_0x3d7400));const _0x4fb7ee='reauthenticate';try{const _0x5252c2=await xt(_0x45c053,Fa(_0x3d7400,_0x4fb7ee,_0x3a0a35,_0x45c053),_0x1c452a);m(_0x5252c2['idToken'],_0x3d7400,'internal-error');const _0xe2c044=ws(_0x5252c2['idToken']);m(_0xe2c044,_0x3d7400,'internal-error');const {sub:_0x278c6f}=_0xe2c044;return m(_0x45c053['uid']===_0x278c6f,_0x3d7400,'user-mismatch'),Be['_forOperation'](_0x45c053,_0x4fb7ee,_0x5252c2);}catch(_0x2567f9){throw(_0x2567f9==null?void 0x0:_0x2567f9['code'])==='auth/user-not-found'&&K(_0x3d7400,'user-mismatch'),_0x2567f9;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x51bb68,_0x243493,_0x11ff53=!0x1){if(H(_0x51bb68['app']))return Promise['reject'](se(_0x51bb68));const _0x23fdeb='signIn',_0x2c1d0c=await Fa(_0x51bb68,_0x23fdeb,_0x243493),_0x4eaa2e=await Be['_fromIdTokenResponse'](_0x51bb68,_0x23fdeb,_0x2c1d0c);return _0x11ff53||await _0x51bb68['_updateCurrentUser'](_0x4eaa2e['user']),_0x4eaa2e;}async function Yf(_0x190bcb,_0x269738){return Ua(qe(_0x190bcb),_0x269738);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x3345b8){const _0x1ef42c=qe(_0x3345b8);_0x1ef42c['_getPasswordPolicyInternal']()&&await _0x1ef42c['_updatePasswordPolicy']();}async function R_(_0x24fc9a,_0x145d55,_0x463f30){if(H(_0x24fc9a['app']))return Promise['reject'](se(_0x24fc9a));const _0x31b8ed=qe(_0x24fc9a),_0x5bdd74=await Oi(_0x31b8ed,{'returnSecureToken':!0x0,'email':_0x145d55,'password':_0x463f30,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x1b22b5=>{throw _0x1b22b5['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x24fc9a),_0x1b22b5;}),_0x343dde=await Be['_fromIdTokenResponse'](_0x31b8ed,'signIn',_0x5bdd74);return await _0x31b8ed['_updateCurrentUser'](_0x343dde['user']),_0x343dde;}function A_(_0x20d091,_0x27a830,_0x249125){return H(_0x20d091['app'])?Promise['reject'](se(_0x20d091)):Yf(k(_0x20d091),ft['credential'](_0x27a830,_0x249125))['catch'](async _0x43d5df=>{throw _0x43d5df['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x20d091),_0x43d5df;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x32b85a,_0x4af309){return k(_0x32b85a)['setPersistence'](_0x4af309);}function Qf(_0xa02955,_0x337aee,_0x4bbefc,_0x19e3c7){return k(_0xa02955)['onIdTokenChanged'](_0x337aee,_0x4bbefc,_0x19e3c7);}function Jf(_0x567d30,_0x1f5cd4,_0x311ed9){return k(_0x567d30)['beforeAuthStateChanged'](_0x1f5cd4,_0x311ed9);}function N_(_0x2740c6,_0x27cb53,_0x130855,_0x4d17a3){return k(_0x2740c6)['onAuthStateChanged'](_0x27cb53,_0x130855,_0x4d17a3);}function P_(_0x58833c){return k(_0x58833c)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x218006,_0x25d787){this['storageRetriever']=_0x218006,this['type']=_0x25d787;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x37b2aa,_0x33da8a){return this['storage']['setItem'](_0x37b2aa,JSON['stringify'](_0x33da8a)),Promise['resolve']();}['_get'](_0x22afd8){const _0x4df2eb=this['storage']['getItem'](_0x22afd8);return Promise['resolve'](_0x4df2eb?JSON['parse'](_0x4df2eb):null);}['_remove'](_0x28be67){return this['storage']['removeItem'](_0x28be67),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x55edcb,_0x32d482)=>this['onStorageEvent'](_0x55edcb,_0x32d482),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2052c6){for(const _0x5795be of Object['keys'](this['listeners'])){const _0x17224e=this['storage']['getItem'](_0x5795be),_0x26e345=this['localCache'][_0x5795be];_0x17224e!==_0x26e345&&_0x2052c6(_0x5795be,_0x26e345,_0x17224e);}}['onStorageEvent'](_0x4935db,_0x43e3c1=!0x1){if(!_0x4935db['key']){this['forAllChangedKeys']((_0x36c408,_0x2c0988,_0x30f6d9)=>{this['notifyListeners'](_0x36c408,_0x30f6d9);});return;}const _0x38580a=_0x4935db['key'];_0x43e3c1?this['detachListener']():this['stopPolling']();const _0x392325=()=>{const _0x499da6=this['storage']['getItem'](_0x38580a);!_0x43e3c1&&this['localCache'][_0x38580a]===_0x499da6||this['notifyListeners'](_0x38580a,_0x499da6);},_0x158100=this['storage']['getItem'](_0x38580a);If()&&_0x158100!==_0x4935db['newValue']&&_0x4935db['newValue']!==_0x4935db['oldValue']?setTimeout(_0x392325,Zf):_0x392325();}['notifyListeners'](_0x4d2e9c,_0x42d309){this['localCache'][_0x4d2e9c]=_0x42d309;const _0x1d8804=this['listeners'][_0x4d2e9c];if(_0x1d8804){for(const _0x34eaae of Array['from'](_0x1d8804))_0x34eaae(_0x42d309&&JSON['parse'](_0x42d309));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x39de1f,_0x30e918,_0x14b3a2)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x39de1f,'oldValue':_0x30e918,'newValue':_0x14b3a2}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x28f08c,_0xef3522){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x28f08c]||(this['listeners'][_0x28f08c]=new Set(),this['localCache'][_0x28f08c]=this['storage']['getItem'](_0x28f08c)),this['listeners'][_0x28f08c]['add'](_0xef3522);}['_removeListener'](_0x36271e,_0x611fc6){this['listeners'][_0x36271e]&&(this['listeners'][_0x36271e]['delete'](_0x611fc6),this['listeners'][_0x36271e]['size']===0x0&&delete this['listeners'][_0x36271e]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x445f6b,_0x5a83e5){await super['_set'](_0x445f6b,_0x5a83e5),this['localCache'][_0x445f6b]=JSON['stringify'](_0x5a83e5);}async['_get'](_0x18ca3f){const _0xcf19d3=await super['_get'](_0x18ca3f);return this['localCache'][_0x18ca3f]=JSON['stringify'](_0xcf19d3),_0xcf19d3;}async['_remove'](_0x47f18e){await super['_remove'](_0x47f18e),delete this['localCache'][_0x47f18e];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x34db4d,_0x404ddd){}['_removeListener'](_0x197c63,_0x55cc88){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x4bd7c9){return Promise['all'](_0x4bd7c9['map'](async _0x1469bd=>{try{return{'fulfilled':!0x0,'value':await _0x1469bd};}catch(_0x4d7222){return{'fulfilled':!0x1,'reason':_0x4d7222};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x4edc05){this['eventTarget']=_0x4edc05,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2fd1ab){const _0x2965cd=this['receivers']['find'](_0x40436d=>_0x40436d['isListeningto'](_0x2fd1ab));if(_0x2965cd)return _0x2965cd;const _0x5f4282=new jn(_0x2fd1ab);return this['receivers']['push'](_0x5f4282),_0x5f4282;}['isListeningto'](_0x446997){return this['eventTarget']===_0x446997;}async['handleEvent'](_0x7f28e6){const _0x2cede2=_0x7f28e6,{eventId:_0x151678,eventType:_0x42735b,data:_0x3b3c11}=_0x2cede2['data'],_0x384e10=this['handlersMap'][_0x42735b];if(!(_0x384e10!=null&&_0x384e10['size']))return;_0x2cede2['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x151678,'eventType':_0x42735b});const _0x4b96ef=Array['from'](_0x384e10)['map'](async _0x5d02b8=>_0x5d02b8(_0x2cede2['origin'],_0x3b3c11)),_0xa3117c=await tp(_0x4b96ef);_0x2cede2['ports'][0x0]['postMessage']({'status':'done','eventId':_0x151678,'eventType':_0x42735b,'response':_0xa3117c});}['_subscribe'](_0x1fc686,_0x51f484){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1fc686]||(this['handlersMap'][_0x1fc686]=new Set()),this['handlersMap'][_0x1fc686]['add'](_0x51f484);}['_unsubscribe'](_0x147166,_0x3ca82e){this['handlersMap'][_0x147166]&&_0x3ca82e&&this['handlersMap'][_0x147166]['delete'](_0x3ca82e),(!_0x3ca82e||this['handlersMap'][_0x147166]['size']===0x0)&&delete this['handlersMap'][_0x147166],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x307d7e='',_0x53d7fb=0xa){let _0x34cf7f='';for(let _0x567c5a=0x0;_0x567c5a<_0x53d7fb;_0x567c5a++)_0x34cf7f+=Math['floor'](Math['random']()*0xa);return _0x307d7e+_0x34cf7f;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x412983){this['target']=_0x412983,this['handlers']=new Set();}['removeMessageHandler'](_0x3ed25a){_0x3ed25a['messageChannel']&&(_0x3ed25a['messageChannel']['port1']['removeEventListener']('message',_0x3ed25a['onMessage']),_0x3ed25a['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3ed25a);}async['_send'](_0x4ca4ef,_0x28b509,_0x9a834d=0x32){const _0xf15bc6=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xf15bc6)throw new Error('connection_unavailable');let _0x1ba861,_0x1d5682;return new Promise((_0x4e12d2,_0x3cc5d4)=>{const _0x338d30=bs('',0x14);_0xf15bc6['port1']['start']();const _0x1a08a1=setTimeout(()=>{_0x3cc5d4(new Error('unsupported_event'));},_0x9a834d);_0x1d5682={'messageChannel':_0xf15bc6,'onMessage'(_0x2eb068){const _0x4efce0=_0x2eb068;if(_0x4efce0['data']['eventId']===_0x338d30)switch(_0x4efce0['data']['status']){case'ack':clearTimeout(_0x1a08a1),_0x1ba861=setTimeout(()=>{_0x3cc5d4(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1ba861),_0x4e12d2(_0x4efce0['data']['response']);break;default:clearTimeout(_0x1a08a1),clearTimeout(_0x1ba861),_0x3cc5d4(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x1d5682),_0xf15bc6['port1']['addEventListener']('message',_0x1d5682['onMessage']),this['target']['postMessage']({'eventType':_0x4ca4ef,'eventId':_0x338d30,'data':_0x28b509},[_0xf15bc6['port2']]);})['finally'](()=>{_0x1d5682&&this['removeMessageHandler'](_0x1d5682);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x492f7f){X()['location']['href']=_0x492f7f;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x3f41c2;return((_0x3f41c2=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3f41c2['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x9ae664){this['request']=_0x9ae664;}['toPromise'](){return new Promise((_0xd363c2,_0x3a9a57)=>{this['request']['addEventListener']('success',()=>{_0xd363c2(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3a9a57(this['request']['error']);});});}}function Kn(_0x1069d1,_0x12fb00){return _0x1069d1['transaction']([kn],_0x12fb00?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x4b607a=indexedDB['deleteDatabase'](qa);return new Jt(_0x4b607a)['toPromise']();}function ja(){const _0xa705b9=indexedDB['open'](qa,ap);return new Promise((_0x187dcf,_0x22a3f6)=>{_0xa705b9['addEventListener']('error',()=>{_0x22a3f6(_0xa705b9['error']);}),_0xa705b9['addEventListener']('upgradeneeded',()=>{const _0x276c2c=_0xa705b9['result'];try{_0x276c2c['createObjectStore'](kn,{'keyPath':za});}catch(_0x4d3344){_0x22a3f6(_0x4d3344);}}),_0xa705b9['addEventListener']('success',async()=>{const _0x1b2f27=_0xa705b9['result'];_0x1b2f27['objectStoreNames']['contains'](kn)?_0x187dcf(_0x1b2f27):(_0x1b2f27['close'](),await cp(),_0x187dcf(await ja()));});});}async function kr(_0x178cbe,_0x2cc7ac,_0x34a9db){const _0x32c403=Kn(_0x178cbe,!0x0)['put']({[za]:_0x2cc7ac,'value':_0x34a9db});return new Jt(_0x32c403)['toPromise']();}async function lp(_0xe303d3,_0x2ac2c1){const _0x3da55c=Kn(_0xe303d3,!0x1)['get'](_0x2ac2c1),_0x203efa=await new Jt(_0x3da55c)['toPromise']();return _0x203efa===void 0x0?null:_0x203efa['value'];}function Nr(_0x44fc0b,_0x20c29b){const _0x228374=Kn(_0x44fc0b,!0x0)['delete'](_0x20c29b);return new Jt(_0x228374)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x67df16){let _0x19dded=0x0;for(;;)try{const _0x241fa6=await this['_openDb']();return await _0x67df16(_0x241fa6);}catch(_0x28f6e3){if(_0x19dded++>up)throw _0x28f6e3;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x138103,_0x384f61)=>({'keyProcessed':(await this['_poll']())['includes'](_0x384f61['key'])})),this['receiver']['_subscribe']('ping',async(_0x1b46ea,_0x457869)=>['keyChanged']);}async['initializeSender'](){var _0x15222a,_0x522028;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x4b7c85=await this['sender']['_send']('ping',{},0x320);_0x4b7c85&&(_0x15222a=_0x4b7c85[0x0])!=null&&_0x15222a['fulfilled']&&(_0x522028=_0x4b7c85[0x0])!=null&&_0x522028['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x22397a){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x22397a},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x29cf63=>{await kr(_0x29cf63,An,'1'),await Nr(_0x29cf63,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x5221d0){this['pendingWrites']++;try{await _0x5221d0();}finally{this['pendingWrites']--;}}async['_set'](_0x1b2990,_0x315469){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x13a23f=>kr(_0x13a23f,_0x1b2990,_0x315469)),this['localCache'][_0x1b2990]=_0x315469,this['notifyServiceWorker'](_0x1b2990)));}async['_get'](_0x240722){const _0x5ec42c=await this['_withRetries'](_0x31ac5a=>lp(_0x31ac5a,_0x240722));return this['localCache'][_0x240722]=_0x5ec42c,_0x5ec42c;}async['_remove'](_0x218a42){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4569e9=>Nr(_0x4569e9,_0x218a42)),delete this['localCache'][_0x218a42],this['notifyServiceWorker'](_0x218a42)));}async['_poll'](){const _0xc4a61c=await this['_withRetries'](_0x4617f7=>{const _0x31e76f=Kn(_0x4617f7,!0x1)['getAll']();return new Jt(_0x31e76f)['toPromise']();});if(!_0xc4a61c)return[];if(this['pendingWrites']!==0x0)return[];const _0x2ec4c7=[],_0x47cbd8=new Set();if(_0xc4a61c['length']!==0x0){for(const {fbase_key:_0x4a097c,value:_0x1d5931}of _0xc4a61c)_0x47cbd8['add'](_0x4a097c),JSON['stringify'](this['localCache'][_0x4a097c])!==JSON['stringify'](_0x1d5931)&&(this['notifyListeners'](_0x4a097c,_0x1d5931),_0x2ec4c7['push'](_0x4a097c));}for(const _0x4b40d1 of Object['keys'](this['localCache']))this['localCache'][_0x4b40d1]&&!_0x47cbd8['has'](_0x4b40d1)&&(this['notifyListeners'](_0x4b40d1,null),_0x2ec4c7['push'](_0x4b40d1));return _0x2ec4c7;}['notifyListeners'](_0x1d9e70,_0x1451e0){this['localCache'][_0x1d9e70]=_0x1451e0;const _0x4982dd=this['listeners'][_0x1d9e70];if(_0x4982dd){for(const _0x3c9172 of Array['from'](_0x4982dd))_0x3c9172(_0x1451e0);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0xe62968,_0x4dbf11){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0xe62968]||(this['listeners'][_0xe62968]=new Set(),this['_get'](_0xe62968)),this['listeners'][_0xe62968]['add'](_0x4dbf11);}['_removeListener'](_0x871fd6,_0x152ad4){this['listeners'][_0x871fd6]&&(this['listeners'][_0x871fd6]['delete'](_0x152ad4),this['listeners'][_0x871fd6]['size']===0x0&&delete this['listeners'][_0x871fd6]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x33d32a,_0x3038c6){return _0x3038c6?ne(_0x3038c6):(m(_0x33d32a['_popupRedirectResolver'],_0x33d32a,'argument-error'),_0x33d32a['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x5e2a61){super('custom','custom'),this['params']=_0x5e2a61;}['_getIdTokenResponse'](_0x3a57f6){return Ze(_0x3a57f6,this['_buildIdpRequest']());}['_linkToIdToken'](_0xd7cadf,_0x29f37a){return Ze(_0xd7cadf,this['_buildIdpRequest'](_0x29f37a));}['_getReauthenticationResolver'](_0x214547){return Ze(_0x214547,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x203315){const _0x17af63={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x203315&&(_0x17af63['idToken']=_0x203315),_0x17af63;}}function pp(_0x4d36a9){return Ua(_0x4d36a9['auth'],new Rs(_0x4d36a9),_0x4d36a9['bypassAuthState']);}function _p(_0x193073){const {auth:_0x8538b3,user:_0x40bcf9}=_0x193073;return m(_0x40bcf9,_0x8538b3,'internal-error'),Kf(_0x40bcf9,new Rs(_0x193073),_0x193073['bypassAuthState']);}async function gp(_0x4ff748){const {auth:_0x3d30f6,user:_0x14f02e}=_0x4ff748;return m(_0x14f02e,_0x3d30f6,'internal-error'),jf(_0x14f02e,new Rs(_0x4ff748),_0x4ff748['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x52ee68,_0x3ca62b,_0x30bc64,_0x5e391d,_0x4a99ef=!0x1){this['auth']=_0x52ee68,this['resolver']=_0x30bc64,this['user']=_0x5e391d,this['bypassAuthState']=_0x4a99ef,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3ca62b)?_0x3ca62b:[_0x3ca62b];}['execute'](){return new Promise(async(_0x27130d,_0x58f372)=>{this['pendingPromise']={'resolve':_0x27130d,'reject':_0x58f372};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x58dfc5){this['reject'](_0x58dfc5);}});}async['onAuthEvent'](_0x223b52){const {urlResponse:_0x4b34fc,sessionId:_0x4865da,postBody:_0x395b7a,tenantId:_0xeec2a5,error:_0x4f9526,type:_0x5cd451}=_0x223b52;if(_0x4f9526){this['reject'](_0x4f9526);return;}const _0x417446={'auth':this['auth'],'requestUri':_0x4b34fc,'sessionId':_0x4865da,'tenantId':_0xeec2a5||void 0x0,'postBody':_0x395b7a||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5cd451)(_0x417446));}catch(_0x221d6e){this['reject'](_0x221d6e);}}['onError'](_0x3b967d){this['reject'](_0x3b967d);}['getIdpTask'](_0x49cf2a){switch(_0x49cf2a){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x464d4d){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x464d4d),this['unregisterAndCleanUp']();}['reject'](_0x211c6e){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x211c6e),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x13c991,_0x559b7f,_0x59993a,_0x1b79be,_0x144b84){super(_0x13c991,_0x559b7f,_0x1b79be,_0x144b84),this['provider']=_0x59993a,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x180ba6=await this['execute']();return m(_0x180ba6,this['auth'],'internal-error'),_0x180ba6;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4e123f=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4e123f),this['authWindow']['associatedEvent']=_0x4e123f,this['resolver']['_originValidation'](this['auth'])['catch'](_0x433d58=>{this['reject'](_0x433d58);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5dcbd9=>{_0x5dcbd9||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1575ee;return((_0x1575ee=this['authWindow'])==null?void 0x0:_0x1575ee['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2e3c17=()=>{var _0x3e2e90,_0x56a04c;if((_0x56a04c=(_0x3e2e90=this['authWindow'])==null?void 0x0:_0x3e2e90['window'])!=null&&_0x56a04c['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2e3c17,mp['get']());};_0x2e3c17();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x5c4710,_0x5538de,_0x293b36=!0x1){super(_0x5c4710,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5538de,void 0x0,_0x293b36),this['eventId']=null;}async['execute'](){let _0x5f0dc3=rn['get'](this['auth']['_key']());if(!_0x5f0dc3){try{const _0x59d8cd=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x5f0dc3=()=>Promise['resolve'](_0x59d8cd);}catch(_0x3aed15){_0x5f0dc3=()=>Promise['reject'](_0x3aed15);}rn['set'](this['auth']['_key'](),_0x5f0dc3);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5f0dc3();}async['onAuthEvent'](_0x4a674c){if(_0x4a674c['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4a674c);if(_0x4a674c['type']==='unknown'){this['resolve'](null);return;}if(_0x4a674c['eventId']){const _0x3befde=await this['auth']['_redirectUserForId'](_0x4a674c['eventId']);if(_0x3befde)return this['user']=_0x3befde,super['onAuthEvent'](_0x4a674c);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0xeb6216,_0x4ce334){const _0x9a2e04=Cp(_0x4ce334),_0x2222da=wp(_0xeb6216);if(!await _0x2222da['_isAvailable']())return!0x1;const _0x3b731d=await _0x2222da['_get'](_0x9a2e04)==='true';return await _0x2222da['_remove'](_0x9a2e04),_0x3b731d;}function Ip(_0x5a81da,_0x190fef){rn['set'](_0x5a81da['_key'](),_0x190fef);}function wp(_0x269a65){return ne(_0x269a65['_redirectPersistence']);}function Cp(_0x70b189){return sn(yp,_0x70b189['config']['apiKey'],_0x70b189['name']);}async function Tp(_0x257041,_0x198f70,_0x308260=!0x1){if(H(_0x257041['app']))return Promise['reject'](se(_0x257041));const _0x558330=qe(_0x257041),_0x3d3f8e=fp(_0x558330,_0x198f70),_0x2aad31=await new vp(_0x558330,_0x3d3f8e,_0x308260)['execute']();return _0x2aad31&&!_0x308260&&(delete _0x2aad31['user']['_redirectEventId'],await _0x558330['_persistUserIfCurrent'](_0x2aad31['user']),await _0x558330['_setRedirectUser'](null,_0x198f70)),_0x2aad31;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x1259be){this['auth']=_0x1259be,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3d56bd){this['consumers']['add'](_0x3d56bd),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3d56bd)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3d56bd),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x40417e){this['consumers']['delete'](_0x40417e);}['onEvent'](_0x1d3c35){if(this['hasEventBeenHandled'](_0x1d3c35))return!0x1;let _0x585b9e=!0x1;return this['consumers']['forEach'](_0x56a0d2=>{this['isEventForConsumer'](_0x1d3c35,_0x56a0d2)&&(_0x585b9e=!0x0,this['sendToConsumer'](_0x1d3c35,_0x56a0d2),this['saveEventToCache'](_0x1d3c35));}),this['hasHandledPotentialRedirect']||!Rp(_0x1d3c35)||(this['hasHandledPotentialRedirect']=!0x0,_0x585b9e||(this['queuedRedirectEvent']=_0x1d3c35,_0x585b9e=!0x0)),_0x585b9e;}['sendToConsumer'](_0x275213,_0x3d4424){var _0x168220;if(_0x275213['error']&&!Qa(_0x275213)){const _0x17cead=((_0x168220=_0x275213['error']['code'])==null?void 0x0:_0x168220['split']('auth/')[0x1])||'internal-error';_0x3d4424['onError'](J(this['auth'],_0x17cead));}else _0x3d4424['onAuthEvent'](_0x275213);}['isEventForConsumer'](_0x1c77a2,_0x5bc997){const _0x4b9ca7=_0x5bc997['eventId']===null||!!_0x1c77a2['eventId']&&_0x1c77a2['eventId']===_0x5bc997['eventId'];return _0x5bc997['filter']['includes'](_0x1c77a2['type'])&&_0x4b9ca7;}['hasEventBeenHandled'](_0x1a442c){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x1a442c));}['saveEventToCache'](_0x29d0f0){this['cachedEventUids']['add'](Pr(_0x29d0f0)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x34aaa5){return[_0x34aaa5['type'],_0x34aaa5['eventId'],_0x34aaa5['sessionId'],_0x34aaa5['tenantId']]['filter'](_0x6a7064=>_0x6a7064)['join']('-');}function Qa({type:_0x3fb431,error:_0x579b61}){return _0x3fb431==='unknown'&&(_0x579b61==null?void 0x0:_0x579b61['code'])==='auth/no-auth-event';}function Rp(_0x21c8c0){switch(_0x21c8c0['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x21c8c0);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x2fcd76,_0x4bbf02={}){return Ae(_0x2fcd76,'GET','/v1/projects',_0x4bbf02);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x14eb1a){if(_0x14eb1a['config']['emulator'])return;const {authorizedDomains:_0x129c09}=await Ap(_0x14eb1a);for(const _0xb14b2e of _0x129c09)try{if(Op(_0xb14b2e))return;}catch{}K(_0x14eb1a,'unauthorized-domain');}function Op(_0x2b2985){const _0x12d8fb=Ni(),{protocol:_0x31b151,hostname:_0x3c9e9c}=new URL(_0x12d8fb);if(_0x2b2985['startsWith']('chrome-extension://')){const _0x231045=new URL(_0x2b2985);return _0x231045['hostname']===''&&_0x3c9e9c===''?_0x31b151==='chrome-extension:'&&_0x2b2985['replace']('chrome-extension://','')===_0x12d8fb['replace']('chrome-extension://',''):_0x31b151==='chrome-extension:'&&_0x231045['hostname']===_0x3c9e9c;}if(!Np['test'](_0x31b151))return!0x1;if(kp['test'](_0x2b2985))return _0x3c9e9c===_0x2b2985;const _0x2a25f1=_0x2b2985['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2a25f1+'|'+_0x2a25f1+')$','i')['test'](_0x3c9e9c);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x9d35ae=X()['___jsl'];if(_0x9d35ae!=null&&_0x9d35ae['H']){for(const _0x557b13 of Object['keys'](_0x9d35ae['H']))if(_0x9d35ae['H'][_0x557b13]['r']=_0x9d35ae['H'][_0x557b13]['r']||[],_0x9d35ae['H'][_0x557b13]['L']=_0x9d35ae['H'][_0x557b13]['L']||[],_0x9d35ae['H'][_0x557b13]['r']=[..._0x9d35ae['H'][_0x557b13]['L']],_0x9d35ae['CP']){for(let _0x174915=0x0;_0x174915<_0x9d35ae['CP']['length'];_0x174915++)_0x9d35ae['CP'][_0x174915]=null;}}}function Mp(_0x58a1da){return new Promise((_0x4f3d73,_0x5c6f64)=>{var _0x43fe9e,_0xc44f94,_0x59a425;function _0x859351(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x4f3d73(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x5c6f64(J(_0x58a1da,'network-request-failed'));},'timeout':Dp['get']()});}if((_0xc44f94=(_0x43fe9e=X()['gapi'])==null?void 0x0:_0x43fe9e['iframes'])!=null&&_0xc44f94['Iframe'])_0x4f3d73(gapi['iframes']['getContext']());else{if((_0x59a425=X()['gapi'])!=null&&_0x59a425['load'])_0x859351();else{const _0x38cec9=Nf('iframefcb');return X()[_0x38cec9]=()=>{gapi['load']?_0x859351():_0x5c6f64(J(_0x58a1da,'network-request-failed'));},Da(kf()+'?onload='+_0x38cec9)['catch'](_0xfde0b5=>_0x5c6f64(_0xfde0b5));}}})['catch'](_0x12da8e=>{throw on=null,_0x12da8e;});}let on=null;function Lp(_0x4f9b59){return on=on||Mp(_0x4f9b59),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x4374cf){const _0x65b54a=_0x4374cf['config'];m(_0x65b54a['authDomain'],_0x4374cf,'auth-domain-config-required');const _0xf012c8=_0x65b54a['emulator']?Is(_0x65b54a,Up):'https://'+_0x4374cf['config']['authDomain']+'/'+Fp,_0x45499d={'apiKey':_0x65b54a['apiKey'],'appName':_0x4374cf['name'],'v':ct},_0x59e5a9=Bp['get'](_0x4374cf['config']['apiHost']);_0x59e5a9&&(_0x45499d['eid']=_0x59e5a9);const _0xcdce6d=_0x4374cf['_getFrameworks']();return _0xcdce6d['length']&&(_0x45499d['fw']=_0xcdce6d['join'](',')),_0xf012c8+'?'+at(_0x45499d)['slice'](0x1);}async function Hp(_0x4eb039){const _0x3b2289=await Lp(_0x4eb039),_0x541f2a=X()['gapi'];return m(_0x541f2a,_0x4eb039,'internal-error'),_0x3b2289['open']({'where':document['body'],'url':Vp(_0x4eb039),'messageHandlersFilter':_0x541f2a['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x264e5d=>new Promise(async(_0x181ed1,_0x16e52b)=>{await _0x264e5d['restyle']({'setHideOnLeave':!0x1});const _0x59acd2=J(_0x4eb039,'network-request-failed'),_0x2d42c8=X()['setTimeout'](()=>{_0x16e52b(_0x59acd2);},xp['get']());function _0x4a7eaa(){X()['clearTimeout'](_0x2d42c8),_0x181ed1(_0x264e5d);}_0x264e5d['ping'](_0x4a7eaa)['then'](_0x4a7eaa,()=>{_0x16e52b(_0x59acd2);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x44dcc3){this['window']=_0x44dcc3,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x1b4305,_0x251696,_0xf81dd5,_0x369af2=Gp,_0x55f845=qp){const _0x5bbf93=Math['max']((window['screen']['availHeight']-_0x55f845)/0x2,0x0)['toString'](),_0xc7303e=Math['max']((window['screen']['availWidth']-_0x369af2)/0x2,0x0)['toString']();let _0x24cda0='';const _0xea1dcc={...$p,'width':_0x369af2['toString'](),'height':_0x55f845['toString'](),'top':_0x5bbf93,'left':_0xc7303e},_0x55dde8=W()['toLowerCase']();_0xf81dd5&&(_0x24cda0=ba(_0x55dde8)?zp:_0xf81dd5),Ta(_0x55dde8)&&(_0x251696=_0x251696||jp,_0xea1dcc['scrollbars']='yes');const _0x5b7b81=Object['entries'](_0xea1dcc)['reduce']((_0x3f9f88,[_0x533d4c,_0x22e785])=>''+_0x3f9f88+_0x533d4c+'='+_0x22e785+',','');if(Ef(_0x55dde8)&&_0x24cda0!=='_self')return Yp(_0x251696||'',_0x24cda0),new Dr(null);const _0x314eb4=window['open'](_0x251696||'',_0x24cda0,_0x5b7b81);m(_0x314eb4,_0x1b4305,'popup-blocked');try{_0x314eb4['focus']();}catch{}return new Dr(_0x314eb4);}function Yp(_0x2534d8,_0x3038ca){const _0x311e9d=document['createElement']('a');_0x311e9d['href']=_0x2534d8,_0x311e9d['target']=_0x3038ca;const _0xdc7af1=document['createEvent']('MouseEvent');_0xdc7af1['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x311e9d['dispatchEvent'](_0xdc7af1);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x270934,_0x1a38f9,_0x52df7b,_0x3044f0,_0x2481b1,_0x3d2ed0){m(_0x270934['config']['authDomain'],_0x270934,'auth-domain-config-required'),m(_0x270934['config']['apiKey'],_0x270934,'invalid-api-key');const _0x3731f3={'apiKey':_0x270934['config']['apiKey'],'appName':_0x270934['name'],'authType':_0x52df7b,'redirectUrl':_0x3044f0,'v':ct,'eventId':_0x2481b1};if(_0x1a38f9 instanceof xa){_0x1a38f9['setDefaultLanguage'](_0x270934['languageCode']),_0x3731f3['providerId']=_0x1a38f9['providerId']||'',hi(_0x1a38f9['getCustomParameters']())||(_0x3731f3['customParameters']=JSON['stringify'](_0x1a38f9['getCustomParameters']()));for(const [_0x20cff8,_0x1cad15]of Object['entries']({}))_0x3731f3[_0x20cff8]=_0x1cad15;}if(_0x1a38f9 instanceof Qt){const _0x15a99f=_0x1a38f9['getScopes']()['filter'](_0x8061e9=>_0x8061e9!=='');_0x15a99f['length']>0x0&&(_0x3731f3['scopes']=_0x15a99f['join'](','));}_0x270934['tenantId']&&(_0x3731f3['tid']=_0x270934['tenantId']);const _0x1036fc=_0x3731f3;for(const _0x2a92ec of Object['keys'](_0x1036fc))_0x1036fc[_0x2a92ec]===void 0x0&&delete _0x1036fc[_0x2a92ec];const _0x38c14c=await _0x270934['_getAppCheckToken'](),_0xd6636=_0x38c14c?'#'+Xp+'='+encodeURIComponent(_0x38c14c):'';return Zp(_0x270934)+'?'+at(_0x1036fc)['slice'](0x1)+_0xd6636;}function Zp({config:_0x15a834}){return _0x15a834['emulator']?Is(_0x15a834,Jp):'https://'+_0x15a834['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x5d22ea,_0x508a48,_0x535538,_0x22464f){var _0x16acf5;ae((_0x16acf5=this['eventManagers'][_0x5d22ea['_key']()])==null?void 0x0:_0x16acf5['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4404df=await Mr(_0x5d22ea,_0x508a48,_0x535538,Ni(),_0x22464f);return Kp(_0x5d22ea,_0x4404df,bs());}async['_openRedirect'](_0x1821ee,_0x32de34,_0x1a2fb0,_0x4f46ca){await this['_originValidation'](_0x1821ee);const _0x3fba1c=await Mr(_0x1821ee,_0x32de34,_0x1a2fb0,Ni(),_0x4f46ca);return ip(_0x3fba1c),new Promise(()=>{});}['_initialize'](_0x42e58f){const _0x2b4958=_0x42e58f['_key']();if(this['eventManagers'][_0x2b4958]){const {manager:_0x193a85,promise:_0x436c45}=this['eventManagers'][_0x2b4958];return _0x193a85?Promise['resolve'](_0x193a85):(ae(_0x436c45,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x436c45);}const _0x35a803=this['initAndGetManager'](_0x42e58f);return this['eventManagers'][_0x2b4958]={'promise':_0x35a803},_0x35a803['catch'](()=>{delete this['eventManagers'][_0x2b4958];}),_0x35a803;}async['initAndGetManager'](_0xb204b0){const _0x48aa53=await Hp(_0xb204b0),_0x56fabd=new bp(_0xb204b0);return _0x48aa53['register']('authEvent',_0x196e60=>(m(_0x196e60==null?void 0x0:_0x196e60['authEvent'],_0xb204b0,'invalid-auth-event'),{'status':_0x56fabd['onEvent'](_0x196e60['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0xb204b0['_key']()]={'manager':_0x56fabd},this['iframes'][_0xb204b0['_key']()]=_0x48aa53,_0x56fabd;}['_isIframeWebStorageSupported'](_0x69b4da,_0x2616f5){this['iframes'][_0x69b4da['_key']()]['send'](li,{'type':li},_0x3323d8=>{var _0x28dfa4;const _0x24fba9=(_0x28dfa4=_0x3323d8==null?void 0x0:_0x3323d8[0x0])==null?void 0x0:_0x28dfa4[li];_0x24fba9!==void 0x0&&_0x2616f5(!!_0x24fba9),K(_0x69b4da,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x477945){const _0x317e7d=_0x477945['_key']();return this['originValidationPromises'][_0x317e7d]||(this['originValidationPromises'][_0x317e7d]=Pp(_0x477945)),this['originValidationPromises'][_0x317e7d];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0xeb89ad){this['auth']=_0xeb89ad,this['internalListeners']=new Map();}['getUid'](){var _0x2736da;return this['assertAuthConfigured'](),((_0x2736da=this['auth']['currentUser'])==null?void 0x0:_0x2736da['uid'])||null;}async['getToken'](_0x56ba16){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x56ba16)}:null;}['addAuthTokenListener'](_0xff35f5){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0xff35f5))return;const _0x3515de=this['auth']['onIdTokenChanged'](_0x11e145=>{_0xff35f5((_0x11e145==null?void 0x0:_0x11e145['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0xff35f5,_0x3515de),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x1e3a74){this['assertAuthConfigured']();const _0x2cab83=this['internalListeners']['get'](_0x1e3a74);_0x2cab83&&(this['internalListeners']['delete'](_0x1e3a74),_0x2cab83(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x4bd9f4){switch(_0x4bd9f4){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x26e46c){et(new Me('auth',(_0x46af7d,{options:_0x3243e5})=>{const _0x35c416=_0x46af7d['getProvider']('app')['getImmediate'](),_0x3de5e4=_0x46af7d['getProvider']('heartbeat'),_0x22fdae=_0x46af7d['getProvider']('app-check-internal'),{apiKey:_0x157f6a,authDomain:_0x249253}=_0x35c416['options'];m(_0x157f6a&&!_0x157f6a['includes'](':'),'invalid-api-key',{'appName':_0x35c416['name']});const _0xffb603={'apiKey':_0x157f6a,'authDomain':_0x249253,'clientPlatform':_0x26e46c,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x26e46c)},_0x331182=new bf(_0x35c416,_0x3de5e4,_0x22fdae,_0xffb603);return Lf(_0x331182,_0x3243e5),_0x331182;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x48161e,_0x45ecec,_0x478100)=>{_0x48161e['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x1274bb=>{const _0x199b4e=qe(_0x1274bb['getProvider']('auth')['getImmediate']());return(_0x26f978=>new n_(_0x26f978))(_0x199b4e);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x26e46c)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x1b115b=>async _0x148aad=>{const _0x20b176=_0x148aad&&await _0x148aad['getIdTokenResult'](),_0x37b938=_0x20b176&&(new Date()['getTime']()-Date['parse'](_0x20b176['issuedAtTime']))/0x3e8;if(_0x37b938&&_0x37b938>o_)return;const _0x42ab94=_0x20b176==null?void 0x0:_0x20b176['token'];Fr!==_0x42ab94&&(Fr=_0x42ab94,await fetch(_0x1b115b,{'method':_0x42ab94?'POST':'DELETE','headers':_0x42ab94?{'Authorization':'Bearer\x20'+_0x42ab94}:{}}));};function O_(_0xbaf6a2=Qr()){const _0x250aa=Ui(_0xbaf6a2,'auth');if(_0x250aa['isInitialized']())return _0x250aa['getImmediate']();const _0x4aada0=Mf(_0xbaf6a2,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x542ab5=Gr('authTokenSyncURL');if(_0x542ab5&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5b2e6f=new URL(_0x542ab5,location['origin']);if(location['origin']===_0x5b2e6f['origin']){const _0xc85711=a_(_0x5b2e6f['toString']());Jf(_0x4aada0,_0xc85711,()=>_0xc85711(_0x4aada0['currentUser'])),Qf(_0x4aada0,_0x25994f=>_0xc85711(_0x25994f));}}const _0x5e0c65=Hr('auth');return _0x5e0c65&&xf(_0x4aada0,'http://'+_0x5e0c65),_0x4aada0;}function c_(){var _0x4e5d47;return((_0x4e5d47=document['getElementsByTagName']('head'))==null?void 0x0:_0x4e5d47[0x0])??document;}Rf({'loadJS'(_0x2a26a2){return new Promise((_0x5c97c5,_0x496e64)=>{const _0x479f97=document['createElement']('script');_0x479f97['setAttribute']('src',_0x2a26a2),_0x479f97['onload']=_0x5c97c5,_0x479f97['onerror']=_0x45a730=>{const _0x3d345f=J('internal-error');_0x3d345f['customData']=_0x45a730,_0x496e64(_0x3d345f);},_0x479f97['type']='text/javascript',_0x479f97['charset']='UTF-8',c_()['appendChild'](_0x479f97);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};