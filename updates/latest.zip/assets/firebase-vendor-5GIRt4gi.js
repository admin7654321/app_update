const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x9cb391,_0x137a5c){if(!_0x9cb391)throw ot(_0x137a5c);},ot=function(_0x22ebd9){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x22ebd9);},Wr=function(_0x932f82){const _0x241539=[];let _0x44e356=0x0;for(let _0x33dca0=0x0;_0x33dca0<_0x932f82['length'];_0x33dca0++){let _0x3ccbe7=_0x932f82['charCodeAt'](_0x33dca0);_0x3ccbe7<0x80?_0x241539[_0x44e356++]=_0x3ccbe7:_0x3ccbe7<0x800?(_0x241539[_0x44e356++]=_0x3ccbe7>>0x6|0xc0,_0x241539[_0x44e356++]=_0x3ccbe7&0x3f|0x80):(_0x3ccbe7&0xfc00)===0xd800&&_0x33dca0+0x1<_0x932f82['length']&&(_0x932f82['charCodeAt'](_0x33dca0+0x1)&0xfc00)===0xdc00?(_0x3ccbe7=0x10000+((_0x3ccbe7&0x3ff)<<0xa)+(_0x932f82['charCodeAt'](++_0x33dca0)&0x3ff),_0x241539[_0x44e356++]=_0x3ccbe7>>0x12|0xf0,_0x241539[_0x44e356++]=_0x3ccbe7>>0xc&0x3f|0x80,_0x241539[_0x44e356++]=_0x3ccbe7>>0x6&0x3f|0x80,_0x241539[_0x44e356++]=_0x3ccbe7&0x3f|0x80):(_0x241539[_0x44e356++]=_0x3ccbe7>>0xc|0xe0,_0x241539[_0x44e356++]=_0x3ccbe7>>0x6&0x3f|0x80,_0x241539[_0x44e356++]=_0x3ccbe7&0x3f|0x80);}return _0x241539;},Za=function(_0x9006ed){const _0x22bda5=[];let _0x1469be=0x0,_0x24e9c5=0x0;for(;_0x1469be<_0x9006ed['length'];){const _0x2d7808=_0x9006ed[_0x1469be++];if(_0x2d7808<0x80)_0x22bda5[_0x24e9c5++]=String['fromCharCode'](_0x2d7808);else{if(_0x2d7808>0xbf&&_0x2d7808<0xe0){const _0x2bcaba=_0x9006ed[_0x1469be++];_0x22bda5[_0x24e9c5++]=String['fromCharCode']((_0x2d7808&0x1f)<<0x6|_0x2bcaba&0x3f);}else{if(_0x2d7808>0xef&&_0x2d7808<0x16d){const _0x53aa66=_0x9006ed[_0x1469be++],_0x55cc3a=_0x9006ed[_0x1469be++],_0x443fb0=_0x9006ed[_0x1469be++],_0x1b2d5e=((_0x2d7808&0x7)<<0x12|(_0x53aa66&0x3f)<<0xc|(_0x55cc3a&0x3f)<<0x6|_0x443fb0&0x3f)-0x10000;_0x22bda5[_0x24e9c5++]=String['fromCharCode'](0xd800+(_0x1b2d5e>>0xa)),_0x22bda5[_0x24e9c5++]=String['fromCharCode'](0xdc00+(_0x1b2d5e&0x3ff));}else{const _0x226cf0=_0x9006ed[_0x1469be++],_0x8b6960=_0x9006ed[_0x1469be++];_0x22bda5[_0x24e9c5++]=String['fromCharCode']((_0x2d7808&0xf)<<0xc|(_0x226cf0&0x3f)<<0x6|_0x8b6960&0x3f);}}}}return _0x22bda5['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x3a7bc8,_0x3b1fa8){if(!Array['isArray'](_0x3a7bc8))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x57a67d=_0x3b1fa8?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x2254bb=[];for(let _0x1db054=0x0;_0x1db054<_0x3a7bc8['length'];_0x1db054+=0x3){const _0x2d5a81=_0x3a7bc8[_0x1db054],_0x4cfc65=_0x1db054+0x1<_0x3a7bc8['length'],_0x5ae0c9=_0x4cfc65?_0x3a7bc8[_0x1db054+0x1]:0x0,_0x4bd51b=_0x1db054+0x2<_0x3a7bc8['length'],_0x1db5e3=_0x4bd51b?_0x3a7bc8[_0x1db054+0x2]:0x0,_0x2de355=_0x2d5a81>>0x2,_0x1d2c68=(_0x2d5a81&0x3)<<0x4|_0x5ae0c9>>0x4;let _0xe03a18=(_0x5ae0c9&0xf)<<0x2|_0x1db5e3>>0x6,_0x594de3=_0x1db5e3&0x3f;_0x4bd51b||(_0x594de3=0x40,_0x4cfc65||(_0xe03a18=0x40)),_0x2254bb['push'](_0x57a67d[_0x2de355],_0x57a67d[_0x1d2c68],_0x57a67d[_0xe03a18],_0x57a67d[_0x594de3]);}return _0x2254bb['join']('');},'encodeString'(_0x4b2330,_0x2603a0){return this['HAS_NATIVE_SUPPORT']&&!_0x2603a0?btoa(_0x4b2330):this['encodeByteArray'](Wr(_0x4b2330),_0x2603a0);},'decodeString'(_0x128329,_0x16298b){return this['HAS_NATIVE_SUPPORT']&&!_0x16298b?atob(_0x128329):Za(this['decodeStringToByteArray'](_0x128329,_0x16298b));},'decodeStringToByteArray'(_0x154050,_0x1ad11c){this['init_']();const _0x755746=_0x1ad11c?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0xf5268a=[];for(let _0x5ce466=0x0;_0x5ce466<_0x154050['length'];){const _0x35d3de=_0x755746[_0x154050['charAt'](_0x5ce466++)],_0x1a017b=_0x5ce466<_0x154050['length']?_0x755746[_0x154050['charAt'](_0x5ce466)]:0x0;++_0x5ce466;const _0xcc1d8e=_0x5ce466<_0x154050['length']?_0x755746[_0x154050['charAt'](_0x5ce466)]:0x40;++_0x5ce466;const _0x160529=_0x5ce466<_0x154050['length']?_0x755746[_0x154050['charAt'](_0x5ce466)]:0x40;if(++_0x5ce466,_0x35d3de==null||_0x1a017b==null||_0xcc1d8e==null||_0x160529==null)throw new ec();const _0x4c2c00=_0x35d3de<<0x2|_0x1a017b>>0x4;if(_0xf5268a['push'](_0x4c2c00),_0xcc1d8e!==0x40){const _0x2d749f=_0x1a017b<<0x4&0xf0|_0xcc1d8e>>0x2;if(_0xf5268a['push'](_0x2d749f),_0x160529!==0x40){const _0x5bdb6e=_0xcc1d8e<<0x6&0xc0|_0x160529;_0xf5268a['push'](_0x5bdb6e);}}}return _0xf5268a;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3beb63=0x0;_0x3beb63<this['ENCODED_VALS']['length'];_0x3beb63++)this['byteToCharMap_'][_0x3beb63]=this['ENCODED_VALS']['charAt'](_0x3beb63),this['charToByteMap_'][this['byteToCharMap_'][_0x3beb63]]=_0x3beb63,this['byteToCharMapWebSafe_'][_0x3beb63]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3beb63),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3beb63]]=_0x3beb63,_0x3beb63>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3beb63)]=_0x3beb63,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3beb63)]=_0x3beb63);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x4c3430){const _0x1905b0=Wr(_0x4c3430);return Di['encodeByteArray'](_0x1905b0,!0x0);},an=function(_0x550d68){return Br(_0x550d68)['replace'](/\./g,'');},cn=function(_0x1e0324){try{return Di['decodeString'](_0x1e0324,!0x0);}catch(_0xebe7ba){console['error']('base64Decode\x20failed:\x20',_0xebe7ba);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x337b77){return Vr(void 0x0,_0x337b77);}function Vr(_0x40bfcd,_0x1d196f){if(!(_0x1d196f instanceof Object))return _0x1d196f;switch(_0x1d196f['constructor']){case Date:const _0x50727b=_0x1d196f;return new Date(_0x50727b['getTime']());case Object:_0x40bfcd===void 0x0&&(_0x40bfcd={});break;case Array:_0x40bfcd=[];break;default:return _0x1d196f;}for(const _0x2b7144 in _0x1d196f)!_0x1d196f['hasOwnProperty'](_0x2b7144)||!nc(_0x2b7144)||(_0x40bfcd[_0x2b7144]=Vr(_0x40bfcd[_0x2b7144],_0x1d196f[_0x2b7144]));return _0x40bfcd;}function nc(_0x52a5b1){return _0x52a5b1!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x2f482e=As['__FIREBASE_DEFAULTS__'];if(_0x2f482e)return JSON['parse'](_0x2f482e);},oc=()=>{if(typeof document>'u')return;let _0x50c0de;try{_0x50c0de=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x32b6ac=_0x50c0de&&cn(_0x50c0de[0x1]);return _0x32b6ac&&JSON['parse'](_0x32b6ac);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4322d1){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4322d1);return;}},Hr=_0x46af65=>{var _0x19422b,_0x4d5044;return(_0x4d5044=(_0x19422b=Mi())==null?void 0x0:_0x19422b['emulatorHosts'])==null?void 0x0:_0x4d5044[_0x46af65];},ac=_0x4ba0f5=>{const _0x2266e0=Hr(_0x4ba0f5);if(!_0x2266e0)return;const _0x5a99a7=_0x2266e0['lastIndexOf'](':');if(_0x5a99a7<=0x0||_0x5a99a7+0x1===_0x2266e0['length'])throw new Error('Invalid\x20host\x20'+_0x2266e0+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x222220=parseInt(_0x2266e0['substring'](_0x5a99a7+0x1),0xa);return _0x2266e0[0x0]==='['?[_0x2266e0['substring'](0x1,_0x5a99a7-0x1),_0x222220]:[_0x2266e0['substring'](0x0,_0x5a99a7),_0x222220];},$r=()=>{var _0x20945d;return(_0x20945d=Mi())==null?void 0x0:_0x20945d['config'];},Gr=_0x499641=>{var _0x306797;return(_0x306797=Mi())==null?void 0x0:_0x306797['_'+_0x499641];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x22872a,_0xd487ad)=>{this['resolve']=_0x22872a,this['reject']=_0xd487ad;});}['wrapCallback'](_0x3894ff){return(_0x550c58,_0x35bd19)=>{_0x550c58?this['reject'](_0x550c58):this['resolve'](_0x35bd19),typeof _0x3894ff=='function'&&(this['promise']['catch'](()=>{}),_0x3894ff['length']===0x1?_0x3894ff(_0x550c58):_0x3894ff(_0x550c58,_0x35bd19));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x18bde3,_0x12c405){if(_0x18bde3['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x438e86={'alg':'none','type':'JWT'},_0x49ec6b=_0x12c405||'demo-project',_0x4fdb31=_0x18bde3['iat']||0x0,_0xb16256=_0x18bde3['sub']||_0x18bde3['user_id'];if(!_0xb16256)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1287c4={'iss':'https://securetoken.google.com/'+_0x49ec6b,'aud':_0x49ec6b,'iat':_0x4fdb31,'exp':_0x4fdb31+0xe10,'auth_time':_0x4fdb31,'sub':_0xb16256,'user_id':_0xb16256,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x18bde3};return[an(JSON['stringify'](_0x438e86)),an(JSON['stringify'](_0x1287c4)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x200d75=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x200d75=='object'&&_0x200d75['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x4a4c8b=W();return _0x4a4c8b['indexOf']('MSIE\x20')>=0x0||_0x4a4c8b['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x142183,_0x4d8b39)=>{try{let _0x33603c=!0x0;const _0x2627ee='validate-browser-context-for-indexeddb-analytics-module',_0x263d34=self['indexedDB']['open'](_0x2627ee);_0x263d34['onsuccess']=()=>{_0x263d34['result']['close'](),_0x33603c||self['indexedDB']['deleteDatabase'](_0x2627ee),_0x142183(!0x0);},_0x263d34['onupgradeneeded']=()=>{_0x33603c=!0x1;},_0x263d34['onerror']=()=>{var _0x479c3a;_0x4d8b39(((_0x479c3a=_0x263d34['error'])==null?void 0x0:_0x479c3a['message'])||'');};}catch(_0x100a74){_0x4d8b39(_0x100a74);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x103932,_0x35bee7,_0x13cb43){super(_0x35bee7),this['code']=_0x103932,this['customData']=_0x13cb43,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x179649,_0x56b64a,_0x253864){this['service']=_0x179649,this['serviceName']=_0x56b64a,this['errors']=_0x253864;}['create'](_0x4825f1,..._0x59ee79){const _0x15ad7c=_0x59ee79[0x0]||{},_0x5bc0bf=this['service']+'/'+_0x4825f1,_0x54edf6=this['errors'][_0x4825f1],_0x29c1de=_0x54edf6?gc(_0x54edf6,_0x15ad7c):'Error',_0x376149=this['serviceName']+':\x20'+_0x29c1de+'\x20('+_0x5bc0bf+').';return new Se(_0x5bc0bf,_0x376149,_0x15ad7c);}}function gc(_0x11ab5,_0x168493){return _0x11ab5['replace'](mc,(_0x30d771,_0x1c9d17)=>{const _0x561849=_0x168493[_0x1c9d17];return _0x561849!=null?String(_0x561849):'<'+_0x1c9d17+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x2b530d){return JSON['parse'](_0x2b530d);}function O(_0x3698b7){return JSON['stringify'](_0x3698b7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x10ecff){let _0x1ad365={},_0x1b7156={},_0x247b52={},_0x3ad587='';try{const _0x306756=_0x10ecff['split']('.');_0x1ad365=bt(cn(_0x306756[0x0])||''),_0x1b7156=bt(cn(_0x306756[0x1])||''),_0x3ad587=_0x306756[0x2],_0x247b52=_0x1b7156['d']||{},delete _0x1b7156['d'];}catch{}return{'header':_0x1ad365,'claims':_0x1b7156,'data':_0x247b52,'signature':_0x3ad587};},yc=function(_0x3bbbd8){const _0x276dd2=zr(_0x3bbbd8),_0x363c89=_0x276dd2['claims'];return!!_0x363c89&&typeof _0x363c89=='object'&&_0x363c89['hasOwnProperty']('iat');},vc=function(_0x1d1808){const _0x4c51a8=zr(_0x1d1808)['claims'];return typeof _0x4c51a8=='object'&&_0x4c51a8['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x5ecd13,_0xa77555){return Object['prototype']['hasOwnProperty']['call'](_0x5ecd13,_0xa77555);}function Oe(_0x3ebd1e,_0x36ceda){if(Object['prototype']['hasOwnProperty']['call'](_0x3ebd1e,_0x36ceda))return _0x3ebd1e[_0x36ceda];}function hi(_0x245af0){for(const _0x3d13cb in _0x245af0)if(Object['prototype']['hasOwnProperty']['call'](_0x245af0,_0x3d13cb))return!0x1;return!0x0;}function ln(_0x5ae607,_0x191660,_0x2000aa){const _0x6140c1={};for(const _0x2ac961 in _0x5ae607)Object['prototype']['hasOwnProperty']['call'](_0x5ae607,_0x2ac961)&&(_0x6140c1[_0x2ac961]=_0x191660['call'](_0x2000aa,_0x5ae607[_0x2ac961],_0x2ac961,_0x5ae607));return _0x6140c1;}function De(_0x3ea313,_0x5a9ca9){if(_0x3ea313===_0x5a9ca9)return!0x0;const _0x153438=Object['keys'](_0x3ea313),_0x5741f5=Object['keys'](_0x5a9ca9);for(const _0x4460cf of _0x153438){if(!_0x5741f5['includes'](_0x4460cf))return!0x1;const _0x154741=_0x3ea313[_0x4460cf],_0x42a4d5=_0x5a9ca9[_0x4460cf];if(ks(_0x154741)&&ks(_0x42a4d5)){if(!De(_0x154741,_0x42a4d5))return!0x1;}else{if(_0x154741!==_0x42a4d5)return!0x1;}}for(const _0x365788 of _0x5741f5)if(!_0x153438['includes'](_0x365788))return!0x1;return!0x0;}function ks(_0x35b566){return _0x35b566!==null&&typeof _0x35b566=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x526261){const _0x200e1f=[];for(const [_0x2ceac7,_0x2dc557]of Object['entries'](_0x526261))Array['isArray'](_0x2dc557)?_0x2dc557['forEach'](_0x45d4aa=>{_0x200e1f['push'](encodeURIComponent(_0x2ceac7)+'='+encodeURIComponent(_0x45d4aa));}):_0x200e1f['push'](encodeURIComponent(_0x2ceac7)+'='+encodeURIComponent(_0x2dc557));return _0x200e1f['length']?'&'+_0x200e1f['join']('&'):'';}function yt(_0x213e61){const _0x3f978e={};return _0x213e61['replace'](/^\?/,'')['split']('&')['forEach'](_0x58c4a3=>{if(_0x58c4a3){const [_0x17218,_0x257886]=_0x58c4a3['split']('=');_0x3f978e[decodeURIComponent(_0x17218)]=decodeURIComponent(_0x257886);}}),_0x3f978e;}function vt(_0x523f9e){const _0x2300b6=_0x523f9e['indexOf']('?');if(!_0x2300b6)return'';const _0x135397=_0x523f9e['indexOf']('#',_0x2300b6);return _0x523f9e['substring'](_0x2300b6,_0x135397>0x0?_0x135397:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3fc210=0x1;_0x3fc210<this['blockSize'];++_0x3fc210)this['pad_'][_0x3fc210]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x61b6a0,_0x6ce1b8){_0x6ce1b8||(_0x6ce1b8=0x0);const _0x161f0b=this['W_'];if(typeof _0x61b6a0=='string'){for(let _0x3e3872=0x0;_0x3e3872<0x10;_0x3e3872++)_0x161f0b[_0x3e3872]=_0x61b6a0['charCodeAt'](_0x6ce1b8)<<0x18|_0x61b6a0['charCodeAt'](_0x6ce1b8+0x1)<<0x10|_0x61b6a0['charCodeAt'](_0x6ce1b8+0x2)<<0x8|_0x61b6a0['charCodeAt'](_0x6ce1b8+0x3),_0x6ce1b8+=0x4;}else{for(let _0x252b5d=0x0;_0x252b5d<0x10;_0x252b5d++)_0x161f0b[_0x252b5d]=_0x61b6a0[_0x6ce1b8]<<0x18|_0x61b6a0[_0x6ce1b8+0x1]<<0x10|_0x61b6a0[_0x6ce1b8+0x2]<<0x8|_0x61b6a0[_0x6ce1b8+0x3],_0x6ce1b8+=0x4;}for(let _0x1ac7d2=0x10;_0x1ac7d2<0x50;_0x1ac7d2++){const _0x51e515=_0x161f0b[_0x1ac7d2-0x3]^_0x161f0b[_0x1ac7d2-0x8]^_0x161f0b[_0x1ac7d2-0xe]^_0x161f0b[_0x1ac7d2-0x10];_0x161f0b[_0x1ac7d2]=(_0x51e515<<0x1|_0x51e515>>>0x1f)&0xffffffff;}let _0x5e6211=this['chain_'][0x0],_0x14dfb4=this['chain_'][0x1],_0x52706b=this['chain_'][0x2],_0x5a70d5=this['chain_'][0x3],_0x5ed196=this['chain_'][0x4],_0x4d236a,_0x4985a4;for(let _0x4104d7=0x0;_0x4104d7<0x50;_0x4104d7++){_0x4104d7<0x28?_0x4104d7<0x14?(_0x4d236a=_0x5a70d5^_0x14dfb4&(_0x52706b^_0x5a70d5),_0x4985a4=0x5a827999):(_0x4d236a=_0x14dfb4^_0x52706b^_0x5a70d5,_0x4985a4=0x6ed9eba1):_0x4104d7<0x3c?(_0x4d236a=_0x14dfb4&_0x52706b|_0x5a70d5&(_0x14dfb4|_0x52706b),_0x4985a4=0x8f1bbcdc):(_0x4d236a=_0x14dfb4^_0x52706b^_0x5a70d5,_0x4985a4=0xca62c1d6);const _0x44ed7b=(_0x5e6211<<0x5|_0x5e6211>>>0x1b)+_0x4d236a+_0x5ed196+_0x4985a4+_0x161f0b[_0x4104d7]&0xffffffff;_0x5ed196=_0x5a70d5,_0x5a70d5=_0x52706b,_0x52706b=(_0x14dfb4<<0x1e|_0x14dfb4>>>0x2)&0xffffffff,_0x14dfb4=_0x5e6211,_0x5e6211=_0x44ed7b;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5e6211&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x14dfb4&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x52706b&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5a70d5&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5ed196&0xffffffff;}['update'](_0x45c69a,_0x19730d){if(_0x45c69a==null)return;_0x19730d===void 0x0&&(_0x19730d=_0x45c69a['length']);const _0x152b30=_0x19730d-this['blockSize'];let _0x109994=0x0;const _0x4d08e4=this['buf_'];let _0x27e7cd=this['inbuf_'];for(;_0x109994<_0x19730d;){if(_0x27e7cd===0x0){for(;_0x109994<=_0x152b30;)this['compress_'](_0x45c69a,_0x109994),_0x109994+=this['blockSize'];}if(typeof _0x45c69a=='string'){for(;_0x109994<_0x19730d;)if(_0x4d08e4[_0x27e7cd]=_0x45c69a['charCodeAt'](_0x109994),++_0x27e7cd,++_0x109994,_0x27e7cd===this['blockSize']){this['compress_'](_0x4d08e4),_0x27e7cd=0x0;break;}}else{for(;_0x109994<_0x19730d;)if(_0x4d08e4[_0x27e7cd]=_0x45c69a[_0x109994],++_0x27e7cd,++_0x109994,_0x27e7cd===this['blockSize']){this['compress_'](_0x4d08e4),_0x27e7cd=0x0;break;}}}this['inbuf_']=_0x27e7cd,this['total_']+=_0x19730d;}['digest'](){const _0x1f9e03=[];let _0x390d94=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x316b18=this['blockSize']-0x1;_0x316b18>=0x38;_0x316b18--)this['buf_'][_0x316b18]=_0x390d94&0xff,_0x390d94/=0x100;this['compress_'](this['buf_']);let _0xb9f272=0x0;for(let _0x16e887=0x0;_0x16e887<0x5;_0x16e887++)for(let _0x23ead4=0x18;_0x23ead4>=0x0;_0x23ead4-=0x8)_0x1f9e03[_0xb9f272]=this['chain_'][_0x16e887]>>_0x23ead4&0xff,++_0xb9f272;return _0x1f9e03;}}function Ic(_0x3afd00,_0x4411d2){const _0x4f41d0=new wc(_0x3afd00,_0x4411d2);return _0x4f41d0['subscribe']['bind'](_0x4f41d0);}class wc{constructor(_0x73427b,_0x52943f){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x52943f,this['task']['then'](()=>{_0x73427b(this);})['catch'](_0x1683a3=>{this['error'](_0x1683a3);});}['next'](_0x41fa18){this['forEachObserver'](_0x255758=>{_0x255758['next'](_0x41fa18);});}['error'](_0x1da08e){this['forEachObserver'](_0xa2f736=>{_0xa2f736['error'](_0x1da08e);}),this['close'](_0x1da08e);}['complete'](){this['forEachObserver'](_0x487e35=>{_0x487e35['complete']();}),this['close']();}['subscribe'](_0x4c6c13,_0x1041bd,_0x3ff2fb){let _0x1379a2;if(_0x4c6c13===void 0x0&&_0x1041bd===void 0x0&&_0x3ff2fb===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x4c6c13,['next','error','complete'])?_0x1379a2=_0x4c6c13:_0x1379a2={'next':_0x4c6c13,'error':_0x1041bd,'complete':_0x3ff2fb},_0x1379a2['next']===void 0x0&&(_0x1379a2['next']=Qn),_0x1379a2['error']===void 0x0&&(_0x1379a2['error']=Qn),_0x1379a2['complete']===void 0x0&&(_0x1379a2['complete']=Qn);const _0x5b26e3=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x1379a2['error'](this['finalError']):_0x1379a2['complete']();}catch{}}),this['observers']['push'](_0x1379a2),_0x5b26e3;}['unsubscribeOne'](_0x993b24){this['observers']===void 0x0||this['observers'][_0x993b24]===void 0x0||(delete this['observers'][_0x993b24],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x50b94c){if(!this['finalized']){for(let _0x3233d6=0x0;_0x3233d6<this['observers']['length'];_0x3233d6++)this['sendOne'](_0x3233d6,_0x50b94c);}}['sendOne'](_0x5aa03b,_0xe59dd2){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x5aa03b]!==void 0x0)try{_0xe59dd2(this['observers'][_0x5aa03b]);}catch(_0x571aaf){typeof console<'u'&&console['error']&&console['error'](_0x571aaf);}});}['close'](_0x13b356){this['finalized']||(this['finalized']=!0x0,_0x13b356!==void 0x0&&(this['finalError']=_0x13b356),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x17153c,_0x2d3fba){if(typeof _0x17153c!='object'||_0x17153c===null)return!0x1;for(const _0x39a7b5 of _0x2d3fba)if(_0x39a7b5 in _0x17153c&&typeof _0x17153c[_0x39a7b5]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x37d54f,_0x193a4b){return _0x37d54f+'\x20failed:\x20'+_0x193a4b+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x514b54){const _0x56e424=[];let _0xe7b496=0x0;for(let _0x406dec=0x0;_0x406dec<_0x514b54['length'];_0x406dec++){let _0x4c5fb0=_0x514b54['charCodeAt'](_0x406dec);if(_0x4c5fb0>=0xd800&&_0x4c5fb0<=0xdbff){const _0x3d69a6=_0x4c5fb0-0xd800;_0x406dec++,f(_0x406dec<_0x514b54['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3aa09f=_0x514b54['charCodeAt'](_0x406dec)-0xdc00;_0x4c5fb0=0x10000+(_0x3d69a6<<0xa)+_0x3aa09f;}_0x4c5fb0<0x80?_0x56e424[_0xe7b496++]=_0x4c5fb0:_0x4c5fb0<0x800?(_0x56e424[_0xe7b496++]=_0x4c5fb0>>0x6|0xc0,_0x56e424[_0xe7b496++]=_0x4c5fb0&0x3f|0x80):_0x4c5fb0<0x10000?(_0x56e424[_0xe7b496++]=_0x4c5fb0>>0xc|0xe0,_0x56e424[_0xe7b496++]=_0x4c5fb0>>0x6&0x3f|0x80,_0x56e424[_0xe7b496++]=_0x4c5fb0&0x3f|0x80):(_0x56e424[_0xe7b496++]=_0x4c5fb0>>0x12|0xf0,_0x56e424[_0xe7b496++]=_0x4c5fb0>>0xc&0x3f|0x80,_0x56e424[_0xe7b496++]=_0x4c5fb0>>0x6&0x3f|0x80,_0x56e424[_0xe7b496++]=_0x4c5fb0&0x3f|0x80);}return _0x56e424;},Pn=function(_0x213b97){let _0x466e56=0x0;for(let _0x11eb2d=0x0;_0x11eb2d<_0x213b97['length'];_0x11eb2d++){const _0x52e984=_0x213b97['charCodeAt'](_0x11eb2d);_0x52e984<0x80?_0x466e56++:_0x52e984<0x800?_0x466e56+=0x2:_0x52e984>=0xd800&&_0x52e984<=0xdbff?(_0x466e56+=0x4,_0x11eb2d++):_0x466e56+=0x3;}return _0x466e56;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x71bd6e){return _0x71bd6e&&_0x71bd6e['_delegate']?_0x71bd6e['_delegate']:_0x71bd6e;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0xe6d692){try{return(_0xe6d692['startsWith']('http://')||_0xe6d692['startsWith']('https://')?new URL(_0xe6d692)['hostname']:_0xe6d692)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x25cc02){return(await fetch(_0x25cc02,{'credentials':'include'}))['ok'];}class Me{constructor(_0x4b14b3,_0x54f9fb,_0x422cac){this['name']=_0x4b14b3,this['instanceFactory']=_0x54f9fb,this['type']=_0x422cac,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2558a7){return this['instantiationMode']=_0x2558a7,this;}['setMultipleInstances'](_0x1aa1b6){return this['multipleInstances']=_0x1aa1b6,this;}['setServiceProps'](_0x1c75ce){return this['serviceProps']=_0x1c75ce,this;}['setInstanceCreatedCallback'](_0x4eadc1){return this['onInstanceCreated']=_0x4eadc1,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0xe7707d,_0x22a60e){this['name']=_0xe7707d,this['container']=_0x22a60e,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x34b880){const _0x3ca34f=this['normalizeInstanceIdentifier'](_0x34b880);if(!this['instancesDeferred']['has'](_0x3ca34f)){const _0xf0cf6d=new Ve();if(this['instancesDeferred']['set'](_0x3ca34f,_0xf0cf6d),this['isInitialized'](_0x3ca34f)||this['shouldAutoInitialize']())try{const _0x59e0d1=this['getOrInitializeService']({'instanceIdentifier':_0x3ca34f});_0x59e0d1&&_0xf0cf6d['resolve'](_0x59e0d1);}catch{}}return this['instancesDeferred']['get'](_0x3ca34f)['promise'];}['getImmediate'](_0x36aebe){const _0x56c581=this['normalizeInstanceIdentifier'](_0x36aebe==null?void 0x0:_0x36aebe['identifier']),_0x21b070=(_0x36aebe==null?void 0x0:_0x36aebe['optional'])??!0x1;if(this['isInitialized'](_0x56c581)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x56c581});}catch(_0x172a41){if(_0x21b070)return null;throw _0x172a41;}else{if(_0x21b070)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x3ecb64){if(_0x3ecb64['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x3ecb64['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x3ecb64,!!this['shouldAutoInitialize']()){if(Rc(_0x3ecb64))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x4de275,_0x28fdcc]of this['instancesDeferred']['entries']()){const _0x5c78d7=this['normalizeInstanceIdentifier'](_0x4de275);try{const _0x3714c3=this['getOrInitializeService']({'instanceIdentifier':_0x5c78d7});_0x28fdcc['resolve'](_0x3714c3);}catch{}}}}['clearInstance'](_0xe6619b=ke){this['instancesDeferred']['delete'](_0xe6619b),this['instancesOptions']['delete'](_0xe6619b),this['instances']['delete'](_0xe6619b);}async['delete'](){const _0x2eeebf=Array['from'](this['instances']['values']());await Promise['all']([..._0x2eeebf['filter'](_0x4f6f75=>'INTERNAL'in _0x4f6f75)['map'](_0x21856d=>_0x21856d['INTERNAL']['delete']()),..._0x2eeebf['filter'](_0x28f80b=>'_delete'in _0x28f80b)['map'](_0x52cdc0=>_0x52cdc0['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x5e027c=ke){return this['instances']['has'](_0x5e027c);}['getOptions'](_0x54ef23=ke){return this['instancesOptions']['get'](_0x54ef23)||{};}['initialize'](_0x103295={}){const {options:_0x26f4f1={}}=_0x103295,_0x32bfa8=this['normalizeInstanceIdentifier'](_0x103295['instanceIdentifier']);if(this['isInitialized'](_0x32bfa8))throw Error(this['name']+'('+_0x32bfa8+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0xe4372e=this['getOrInitializeService']({'instanceIdentifier':_0x32bfa8,'options':_0x26f4f1});for(const [_0x59b082,_0x1ff62b]of this['instancesDeferred']['entries']()){const _0x48275b=this['normalizeInstanceIdentifier'](_0x59b082);_0x32bfa8===_0x48275b&&_0x1ff62b['resolve'](_0xe4372e);}return _0xe4372e;}['onInit'](_0xf55fa2,_0x3ce55e){const _0x3e6804=this['normalizeInstanceIdentifier'](_0x3ce55e),_0x10a978=this['onInitCallbacks']['get'](_0x3e6804)??new Set();_0x10a978['add'](_0xf55fa2),this['onInitCallbacks']['set'](_0x3e6804,_0x10a978);const _0x68c1b8=this['instances']['get'](_0x3e6804);return _0x68c1b8&&_0xf55fa2(_0x68c1b8,_0x3e6804),()=>{_0x10a978['delete'](_0xf55fa2);};}['invokeOnInitCallbacks'](_0x581f7b,_0x4521a7){const _0x58a22b=this['onInitCallbacks']['get'](_0x4521a7);if(_0x58a22b){for(const _0x4510e1 of _0x58a22b)try{_0x4510e1(_0x581f7b,_0x4521a7);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x240b9c,options:_0x2657c1={}}){let _0x16d5ec=this['instances']['get'](_0x240b9c);if(!_0x16d5ec&&this['component']&&(_0x16d5ec=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x240b9c),'options':_0x2657c1}),this['instances']['set'](_0x240b9c,_0x16d5ec),this['instancesOptions']['set'](_0x240b9c,_0x2657c1),this['invokeOnInitCallbacks'](_0x16d5ec,_0x240b9c),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x240b9c,_0x16d5ec);}catch{}return _0x16d5ec||null;}['normalizeInstanceIdentifier'](_0x45067b=ke){return this['component']?this['component']['multipleInstances']?_0x45067b:ke:_0x45067b;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x2c8a1f){return _0x2c8a1f===ke?void 0x0:_0x2c8a1f;}function Rc(_0x3cf5b3){return _0x3cf5b3['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x421db){this['name']=_0x421db,this['providers']=new Map();}['addComponent'](_0x2a0bf1){const _0x33652f=this['getProvider'](_0x2a0bf1['name']);if(_0x33652f['isComponentSet']())throw new Error('Component\x20'+_0x2a0bf1['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x33652f['setComponent'](_0x2a0bf1);}['addOrOverwriteComponent'](_0x373bd6){this['getProvider'](_0x373bd6['name'])['isComponentSet']()&&this['providers']['delete'](_0x373bd6['name']),this['addComponent'](_0x373bd6);}['getProvider'](_0x3b164e){if(this['providers']['has'](_0x3b164e))return this['providers']['get'](_0x3b164e);const _0x2c5fc4=new Sc(_0x3b164e,this);return this['providers']['set'](_0x3b164e,_0x2c5fc4),_0x2c5fc4;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x41ba40){_0x41ba40[_0x41ba40['DEBUG']=0x0]='DEBUG',_0x41ba40[_0x41ba40['VERBOSE']=0x1]='VERBOSE',_0x41ba40[_0x41ba40['INFO']=0x2]='INFO',_0x41ba40[_0x41ba40['WARN']=0x3]='WARN',_0x41ba40[_0x41ba40['ERROR']=0x4]='ERROR',_0x41ba40[_0x41ba40['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x3d8938,_0x342da5,..._0x53431e)=>{if(_0x342da5<_0x3d8938['logLevel'])return;const _0x529e77=new Date()['toISOString'](),_0x44dfce=Pc[_0x342da5];if(_0x44dfce)console[_0x44dfce]('['+_0x529e77+']\x20\x20'+_0x3d8938['name']+':',..._0x53431e);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x342da5+')');};class xi{constructor(_0x97ed9a){this['name']=_0x97ed9a,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x560b54){if(!(_0x560b54 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x560b54+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x560b54;}['setLogLevel'](_0x547406){this['_logLevel']=typeof _0x547406=='string'?kc[_0x547406]:_0x547406;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x317644){if(typeof _0x317644!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x317644;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2c73a2){this['_userLogHandler']=_0x2c73a2;}['debug'](..._0x3c24d6){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x3c24d6),this['_logHandler'](this,T['DEBUG'],..._0x3c24d6);}['log'](..._0x16b331){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x16b331),this['_logHandler'](this,T['VERBOSE'],..._0x16b331);}['info'](..._0x24d1be){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x24d1be),this['_logHandler'](this,T['INFO'],..._0x24d1be);}['warn'](..._0x227bae){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x227bae),this['_logHandler'](this,T['WARN'],..._0x227bae);}['error'](..._0x2a5771){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x2a5771),this['_logHandler'](this,T['ERROR'],..._0x2a5771);}}const Dc=(_0x369573,_0xda36bf)=>_0xda36bf['some'](_0x5b2c13=>_0x369573 instanceof _0x5b2c13);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x40fe6e){const _0x2879cc=new Promise((_0x579470,_0x98b8f3)=>{const _0x25d479=()=>{_0x40fe6e['removeEventListener']('success',_0x129b51),_0x40fe6e['removeEventListener']('error',_0x3aced1);},_0x129b51=()=>{_0x579470(_e(_0x40fe6e['result'])),_0x25d479();},_0x3aced1=()=>{_0x98b8f3(_0x40fe6e['error']),_0x25d479();};_0x40fe6e['addEventListener']('success',_0x129b51),_0x40fe6e['addEventListener']('error',_0x3aced1);});return _0x2879cc['then'](_0x4c9eda=>{_0x4c9eda instanceof IDBCursor&&Kr['set'](_0x4c9eda,_0x40fe6e);})['catch'](()=>{}),Fi['set'](_0x2879cc,_0x40fe6e),_0x2879cc;}function Fc(_0xa5ff47){if(ui['has'](_0xa5ff47))return;const _0xa1c779=new Promise((_0x5a26f3,_0x3ae121)=>{const _0x3f0689=()=>{_0xa5ff47['removeEventListener']('complete',_0x51501f),_0xa5ff47['removeEventListener']('error',_0x486a89),_0xa5ff47['removeEventListener']('abort',_0x486a89);},_0x51501f=()=>{_0x5a26f3(),_0x3f0689();},_0x486a89=()=>{_0x3ae121(_0xa5ff47['error']||new DOMException('AbortError','AbortError')),_0x3f0689();};_0xa5ff47['addEventListener']('complete',_0x51501f),_0xa5ff47['addEventListener']('error',_0x486a89),_0xa5ff47['addEventListener']('abort',_0x486a89);});ui['set'](_0xa5ff47,_0xa1c779);}let di={'get'(_0x463a62,_0x53a09c,_0x230249){if(_0x463a62 instanceof IDBTransaction){if(_0x53a09c==='done')return ui['get'](_0x463a62);if(_0x53a09c==='objectStoreNames')return _0x463a62['objectStoreNames']||Yr['get'](_0x463a62);if(_0x53a09c==='store')return _0x230249['objectStoreNames'][0x1]?void 0x0:_0x230249['objectStore'](_0x230249['objectStoreNames'][0x0]);}return _e(_0x463a62[_0x53a09c]);},'set'(_0x6c3d08,_0x2052f4,_0x44c38e){return _0x6c3d08[_0x2052f4]=_0x44c38e,!0x0;},'has'(_0x7c1766,_0xb86b0a){return _0x7c1766 instanceof IDBTransaction&&(_0xb86b0a==='done'||_0xb86b0a==='store')?!0x0:_0xb86b0a in _0x7c1766;}};function Uc(_0x37fc96){di=_0x37fc96(di);}function Wc(_0x59be1b){return _0x59be1b===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x435373,..._0x5ccff0){const _0x3d4e0c=_0x59be1b['call'](Xn(this),_0x435373,..._0x5ccff0);return Yr['set'](_0x3d4e0c,_0x435373['sort']?_0x435373['sort']():[_0x435373]),_e(_0x3d4e0c);}:Lc()['includes'](_0x59be1b)?function(..._0x449a81){return _0x59be1b['apply'](Xn(this),_0x449a81),_e(Kr['get'](this));}:function(..._0x34c506){return _e(_0x59be1b['apply'](Xn(this),_0x34c506));};}function Bc(_0x313c65){return typeof _0x313c65=='function'?Wc(_0x313c65):(_0x313c65 instanceof IDBTransaction&&Fc(_0x313c65),Dc(_0x313c65,Mc())?new Proxy(_0x313c65,di):_0x313c65);}function _e(_0x102be3){if(_0x102be3 instanceof IDBRequest)return xc(_0x102be3);if(Jn['has'](_0x102be3))return Jn['get'](_0x102be3);const _0x54c556=Bc(_0x102be3);return _0x54c556!==_0x102be3&&(Jn['set'](_0x102be3,_0x54c556),Fi['set'](_0x54c556,_0x102be3)),_0x54c556;}const Xn=_0x48abe2=>Fi['get'](_0x48abe2);function Vc(_0x118474,_0x5cd61f,{blocked:_0xeb86e8,upgrade:_0x36091a,blocking:_0x5a32c5,terminated:_0x40e5cb}={}){const _0x43d38f=indexedDB['open'](_0x118474,_0x5cd61f),_0x2fc763=_e(_0x43d38f);return _0x36091a&&_0x43d38f['addEventListener']('upgradeneeded',_0x48d97c=>{_0x36091a(_e(_0x43d38f['result']),_0x48d97c['oldVersion'],_0x48d97c['newVersion'],_e(_0x43d38f['transaction']),_0x48d97c);}),_0xeb86e8&&_0x43d38f['addEventListener']('blocked',_0x216d48=>_0xeb86e8(_0x216d48['oldVersion'],_0x216d48['newVersion'],_0x216d48)),_0x2fc763['then'](_0x35faa2=>{_0x40e5cb&&_0x35faa2['addEventListener']('close',()=>_0x40e5cb()),_0x5a32c5&&_0x35faa2['addEventListener']('versionchange',_0x5c42fb=>_0x5a32c5(_0x5c42fb['oldVersion'],_0x5c42fb['newVersion'],_0x5c42fb));})['catch'](()=>{}),_0x2fc763;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x2c71f6,_0x4e9259){if(!(_0x2c71f6 instanceof IDBDatabase&&!(_0x4e9259 in _0x2c71f6)&&typeof _0x4e9259=='string'))return;if(Zn['get'](_0x4e9259))return Zn['get'](_0x4e9259);const _0x57f662=_0x4e9259['replace'](/FromIndex$/,''),_0xe503cd=_0x4e9259!==_0x57f662,_0x2ab1b1=$c['includes'](_0x57f662);if(!(_0x57f662 in(_0xe503cd?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2ab1b1||Hc['includes'](_0x57f662)))return;const _0x1b43c0=async function(_0x5c4f6f,..._0x3f7e8b){const _0x32432d=this['transaction'](_0x5c4f6f,_0x2ab1b1?'readwrite':'readonly');let _0x4db33d=_0x32432d['store'];return _0xe503cd&&(_0x4db33d=_0x4db33d['index'](_0x3f7e8b['shift']())),(await Promise['all']([_0x4db33d[_0x57f662](..._0x3f7e8b),_0x2ab1b1&&_0x32432d['done']]))[0x0];};return Zn['set'](_0x4e9259,_0x1b43c0),_0x1b43c0;}Uc(_0x1ea130=>({..._0x1ea130,'get':(_0x5d8116,_0x5f5265,_0xb9cdfa)=>Os(_0x5d8116,_0x5f5265)||_0x1ea130['get'](_0x5d8116,_0x5f5265,_0xb9cdfa),'has':(_0x2892a8,_0x182828)=>!!Os(_0x2892a8,_0x182828)||_0x1ea130['has'](_0x2892a8,_0x182828)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x18af66){this['container']=_0x18af66;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5f0ed2=>{if(qc(_0x5f0ed2)){const _0x2b0da3=_0x5f0ed2['getImmediate']();return _0x2b0da3['library']+'/'+_0x2b0da3['version'];}else return null;})['filter'](_0x7cbcc2=>_0x7cbcc2)['join']('\x20');}}function qc(_0x549eb7){const _0x3b5da5=_0x549eb7['getComponent']();return(_0x3b5da5==null?void 0x0:_0x3b5da5['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x17cfdf,_0x401807){try{_0x17cfdf['container']['addComponent'](_0x401807);}catch(_0x5ea81c){re['debug']('Component\x20'+_0x401807['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x17cfdf['name'],_0x5ea81c);}}function et(_0x20aaae){const _0x34e3a6=_0x20aaae['name'];if(gi['has'](_0x34e3a6))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x34e3a6+'.'),!0x1;gi['set'](_0x34e3a6,_0x20aaae);for(const _0x557fdb of Le['values']())Ms(_0x557fdb,_0x20aaae);for(const _0x43c015 of _i['values']())Ms(_0x43c015,_0x20aaae);return!0x0;}function Ui(_0xda0cee,_0x4b3083){const _0x234663=_0xda0cee['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x234663&&_0x234663['triggerHeartbeat'](),_0xda0cee['container']['getProvider'](_0x4b3083);}function H(_0x103b85){return _0x103b85==null?!0x1:_0x103b85['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x460967,_0x2a125c,_0x3c5c9e){this['_isDeleted']=!0x1,this['_options']={..._0x460967},this['_config']={..._0x2a125c},this['_name']=_0x2a125c['name'],this['_automaticDataCollectionEnabled']=_0x2a125c['automaticDataCollectionEnabled'],this['_container']=_0x3c5c9e,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x285a94){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x285a94;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x19effe){this['_isDeleted']=_0x19effe;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x1d9852,_0xab462c={}){let _0x5a42df=_0x1d9852;typeof _0xab462c!='object'&&(_0xab462c={'name':_0xab462c});const _0x26855c={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0xab462c},_0x44d99e=_0x26855c['name'];if(typeof _0x44d99e!='string'||!_0x44d99e)throw ge['create']('bad-app-name',{'appName':String(_0x44d99e)});if(_0x5a42df||(_0x5a42df=$r()),!_0x5a42df)throw ge['create']('no-options');const _0x3610a9=Le['get'](_0x44d99e);if(_0x3610a9){if(De(_0x5a42df,_0x3610a9['options'])&&De(_0x26855c,_0x3610a9['config']))return _0x3610a9;throw ge['create']('duplicate-app',{'appName':_0x44d99e});}const _0x1f832a=new Ac(_0x44d99e);for(const _0x57b1ea of gi['values']())_0x1f832a['addComponent'](_0x57b1ea);const _0x1e7457=new Il(_0x5a42df,_0x26855c,_0x1f832a);return Le['set'](_0x44d99e,_0x1e7457),_0x1e7457;}function Qr(_0x955e71=pi){const _0x1e2b04=Le['get'](_0x955e71);if(!_0x1e2b04&&_0x955e71===pi&&$r())return wl();if(!_0x1e2b04)throw ge['create']('no-app',{'appName':_0x955e71});return _0x1e2b04;}function l_(){return Array['from'](Le['values']());}async function h_(_0x72fff6){let _0x238e51=!0x1;const _0x528966=_0x72fff6['name'];Le['has'](_0x528966)?(_0x238e51=!0x0,Le['delete'](_0x528966)):_i['has'](_0x528966)&&_0x72fff6['decRefCount']()<=0x0&&(_i['delete'](_0x528966),_0x238e51=!0x0),_0x238e51&&(await Promise['all'](_0x72fff6['container']['getProviders']()['map'](_0xf5c162=>_0xf5c162['delete']())),_0x72fff6['isDeleted']=!0x0);}function me(_0x3abc41,_0x3b958b,_0x4e8825){let _0x15be47=vl[_0x3abc41]??_0x3abc41;_0x4e8825&&(_0x15be47+='-'+_0x4e8825);const _0x194378=_0x15be47['match'](/\s|\//),_0x1c7ead=_0x3b958b['match'](/\s|\//);if(_0x194378||_0x1c7ead){const _0x297c59=['Unable\x20to\x20register\x20library\x20\x22'+_0x15be47+'\x22\x20with\x20version\x20\x22'+_0x3b958b+'\x22:'];_0x194378&&_0x297c59['push']('library\x20name\x20\x22'+_0x15be47+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x194378&&_0x1c7ead&&_0x297c59['push']('and'),_0x1c7ead&&_0x297c59['push']('version\x20name\x20\x22'+_0x3b958b+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x297c59['join']('\x20'));return;}et(new Me(_0x15be47+'-version',()=>({'library':_0x15be47,'version':_0x3b958b}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x40b9bf,_0x5e711f)=>{switch(_0x5e711f){case 0x0:try{_0x40b9bf['createObjectStore'](Rt);}catch(_0x4c3245){console['warn'](_0x4c3245);}}}})['catch'](_0x2a7408=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x2a7408['message']});})),ei;}async function Sl(_0x375fd4){try{const _0x44514b=(await Jr())['transaction'](Rt),_0x3f6d9b=await _0x44514b['objectStore'](Rt)['get'](Xr(_0x375fd4));return await _0x44514b['done'],_0x3f6d9b;}catch(_0x708011){if(_0x708011 instanceof Se)re['warn'](_0x708011['message']);else{const _0x1e9677=ge['create']('idb-get',{'originalErrorMessage':_0x708011==null?void 0x0:_0x708011['message']});re['warn'](_0x1e9677['message']);}}}async function Ls(_0x356bc8,_0x3b29ec){try{const _0x3d42d3=(await Jr())['transaction'](Rt,'readwrite');await _0x3d42d3['objectStore'](Rt)['put'](_0x3b29ec,Xr(_0x356bc8)),await _0x3d42d3['done'];}catch(_0x38e042){if(_0x38e042 instanceof Se)re['warn'](_0x38e042['message']);else{const _0x17b509=ge['create']('idb-set',{'originalErrorMessage':_0x38e042==null?void 0x0:_0x38e042['message']});re['warn'](_0x17b509['message']);}}}function Xr(_0x50ca1a){return _0x50ca1a['name']+'!'+_0x50ca1a['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x5e88ff){this['container']=_0x5e88ff,this['_heartbeatsCache']=null;const _0x580d76=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x580d76),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4f8084=>(this['_heartbeatsCache']=_0x4f8084,_0x4f8084));}async['triggerHeartbeat'](){var _0x4837b2,_0x494bf0;try{const _0x59bfb1=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xf755cc=xs();if(((_0x4837b2=this['_heartbeatsCache'])==null?void 0x0:_0x4837b2['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x494bf0=this['_heartbeatsCache'])==null?void 0x0:_0x494bf0['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xf755cc||this['_heartbeatsCache']['heartbeats']['some'](_0x1e9ee5=>_0x1e9ee5['date']===_0xf755cc))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xf755cc,'agent':_0x59bfb1}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x598031=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x598031,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5a5bda){re['warn'](_0x5a5bda);}}async['getHeartbeatsHeader'](){var _0x4c7fee;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4c7fee=this['_heartbeatsCache'])==null?void 0x0:_0x4c7fee['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x202535=xs(),{heartbeatsToSend:_0x227376,unsentEntries:_0x2d4a00}=kl(this['_heartbeatsCache']['heartbeats']),_0x2411e5=an(JSON['stringify']({'version':0x2,'heartbeats':_0x227376}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x202535,_0x2d4a00['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2d4a00,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2411e5;}catch(_0x337773){return re['warn'](_0x337773),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x1c9148,_0x25fd78=bl){const _0x4d125b=[];let _0x39cd1e=_0x1c9148['slice']();for(const _0x1950f8 of _0x1c9148){const _0x4032ae=_0x4d125b['find'](_0x520792=>_0x520792['agent']===_0x1950f8['agent']);if(_0x4032ae){if(_0x4032ae['dates']['push'](_0x1950f8['date']),Fs(_0x4d125b)>_0x25fd78){_0x4032ae['dates']['pop']();break;}}else{if(_0x4d125b['push']({'agent':_0x1950f8['agent'],'dates':[_0x1950f8['date']]}),Fs(_0x4d125b)>_0x25fd78){_0x4d125b['pop']();break;}}_0x39cd1e=_0x39cd1e['slice'](0x1);}return{'heartbeatsToSend':_0x4d125b,'unsentEntries':_0x39cd1e};}class Nl{constructor(_0x154972){this['app']=_0x154972,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2effe1=await Sl(this['app']);return _0x2effe1!=null&&_0x2effe1['heartbeats']?_0x2effe1:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x27515e){if(await this['_canUseIndexedDBPromise']){const _0x8b3d5a=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x27515e['lastSentHeartbeatDate']??_0x8b3d5a['lastSentHeartbeatDate'],'heartbeats':_0x27515e['heartbeats']});}else return;}async['add'](_0x2baa4b){if(await this['_canUseIndexedDBPromise']){const _0x1d52ac=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x2baa4b['lastSentHeartbeatDate']??_0x1d52ac['lastSentHeartbeatDate'],'heartbeats':[..._0x1d52ac['heartbeats'],..._0x2baa4b['heartbeats']]});}else return;}}function Fs(_0x38220f){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x38220f}))['length'];}function Pl(_0x24e3bd){if(_0x24e3bd['length']===0x0)return-0x1;let _0x2b1f50=0x0,_0x38907f=_0x24e3bd[0x0]['date'];for(let _0x17551d=0x1;_0x17551d<_0x24e3bd['length'];_0x17551d++)_0x24e3bd[_0x17551d]['date']<_0x38907f&&(_0x38907f=_0x24e3bd[_0x17551d]['date'],_0x2b1f50=_0x17551d);return _0x2b1f50;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x11d223){et(new Me('platform-logger',_0x3cb5bb=>new Gc(_0x3cb5bb),'PRIVATE')),et(new Me('heartbeat',_0x3ae5e3=>new Al(_0x3ae5e3),'PRIVATE')),me(fi,Ds,_0x11d223),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x3f7062){Zr=_0x3f7062;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x15bda4){this['domStorage_']=_0x15bda4,this['prefix_']='firebase:';}['set'](_0x390156,_0x5ac455){_0x5ac455==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x390156)):this['domStorage_']['setItem'](this['prefixedName_'](_0x390156),O(_0x5ac455));}['get'](_0xd7b063){const _0x13cd6a=this['domStorage_']['getItem'](this['prefixedName_'](_0xd7b063));return _0x13cd6a==null?null:bt(_0x13cd6a);}['remove'](_0xe90048){this['domStorage_']['removeItem'](this['prefixedName_'](_0xe90048));}['prefixedName_'](_0xefbdda){return this['prefix_']+_0xefbdda;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x30e692,_0x4f92ed){_0x4f92ed==null?delete this['cache_'][_0x30e692]:this['cache_'][_0x30e692]=_0x4f92ed;}['get'](_0xcaef26){return Y(this['cache_'],_0xcaef26)?this['cache_'][_0xcaef26]:null;}['remove'](_0x52373a){delete this['cache_'][_0x52373a];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x5a80c6){try{if(typeof window<'u'&&typeof window[_0x5a80c6]<'u'){const _0x321db7=window[_0x5a80c6];return _0x321db7['setItem']('firebase:sentinel','cache'),_0x321db7['removeItem']('firebase:sentinel'),new xl(_0x321db7);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x26db5d=0x1;return function(){return _0x26db5d++;};}()),no=function(_0x4de9b9){const _0x2a0f9f=Tc(_0x4de9b9),_0x4c098d=new Ec();_0x4c098d['update'](_0x2a0f9f);const _0x3c98d4=_0x4c098d['digest']();return Di['encodeByteArray'](_0x3c98d4);},Bt=function(..._0x40ad34){let _0x3468da='';for(let _0x1dbfd1=0x0;_0x1dbfd1<_0x40ad34['length'];_0x1dbfd1++){const _0x322120=_0x40ad34[_0x1dbfd1];Array['isArray'](_0x322120)||_0x322120&&typeof _0x322120=='object'&&typeof _0x322120['length']=='number'?_0x3468da+=Bt['apply'](null,_0x322120):typeof _0x322120=='object'?_0x3468da+=O(_0x322120):_0x3468da+=_0x322120,_0x3468da+='\x20';}return _0x3468da;};let Et=null,Vs=!0x0;const Wl=function(_0x115409,_0x55ec79){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x24df84){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x4bd149=Bt['apply'](null,_0x24df84);Et(_0x4bd149);}},Vt=function(_0x211ac3){return function(..._0x2811e1){L(_0x211ac3,..._0x2811e1);};},mi=function(..._0x3fa022){const _0x5d322e='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x3fa022);Qe['error'](_0x5d322e);},oe=function(..._0x203cc6){const _0xdb236e='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x203cc6);throw Qe['error'](_0xdb236e),new Error(_0xdb236e);},U=function(..._0x50e445){const _0x3cb04a='FIREBASE\x20WARNING:\x20'+Bt(..._0x50e445);Qe['warn'](_0x3cb04a);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x1cfca1){return typeof _0x1cfca1=='number'&&(_0x1cfca1!==_0x1cfca1||_0x1cfca1===Number['POSITIVE_INFINITY']||_0x1cfca1===Number['NEGATIVE_INFINITY']);},Vl=function(_0x70792f){if(document['readyState']==='complete')_0x70792f();else{let _0xf42a51=!0x1;const _0x746a44=function(){if(!document['body']){setTimeout(_0x746a44,Math['floor'](0xa));return;}_0xf42a51||(_0xf42a51=!0x0,_0x70792f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x746a44,!0x1),window['addEventListener']('load',_0x746a44,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x746a44();}),window['attachEvent']('onload',_0x746a44));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x47023c,_0x1a34bd){if(_0x47023c===_0x1a34bd)return 0x0;if(_0x47023c===xe||_0x1a34bd===Ie)return-0x1;if(_0x1a34bd===xe||_0x47023c===Ie)return 0x1;{const _0x2d9ff6=Hs(_0x47023c),_0x7660d0=Hs(_0x1a34bd);return _0x2d9ff6!==null?_0x7660d0!==null?_0x2d9ff6-_0x7660d0===0x0?_0x47023c['length']-_0x1a34bd['length']:_0x2d9ff6-_0x7660d0:-0x1:_0x7660d0!==null?0x1:_0x47023c<_0x1a34bd?-0x1:0x1;}},Hl=function(_0x3e3b13,_0x2cb68f){return _0x3e3b13===_0x2cb68f?0x0:_0x3e3b13<_0x2cb68f?-0x1:0x1;},pt=function(_0x58d0dc,_0x372f6d){if(_0x372f6d&&_0x58d0dc in _0x372f6d)return _0x372f6d[_0x58d0dc];throw new Error('Missing\x20required\x20key\x20('+_0x58d0dc+')\x20in\x20object:\x20'+O(_0x372f6d));},Bi=function(_0x4e7a4f){if(typeof _0x4e7a4f!='object'||_0x4e7a4f===null)return O(_0x4e7a4f);const _0x19f898=[];for(const _0x4d236c in _0x4e7a4f)_0x19f898['push'](_0x4d236c);_0x19f898['sort']();let _0x37dc5a='{';for(let _0x39a6ab=0x0;_0x39a6ab<_0x19f898['length'];_0x39a6ab++)_0x39a6ab!==0x0&&(_0x37dc5a+=','),_0x37dc5a+=O(_0x19f898[_0x39a6ab]),_0x37dc5a+=':',_0x37dc5a+=Bi(_0x4e7a4f[_0x19f898[_0x39a6ab]]);return _0x37dc5a+='}',_0x37dc5a;},io=function(_0x1200d7,_0x8c9e33){const _0x26d138=_0x1200d7['length'];if(_0x26d138<=_0x8c9e33)return[_0x1200d7];const _0x562345=[];for(let _0x521111=0x0;_0x521111<_0x26d138;_0x521111+=_0x8c9e33)_0x521111+_0x8c9e33>_0x26d138?_0x562345['push'](_0x1200d7['substring'](_0x521111,_0x26d138)):_0x562345['push'](_0x1200d7['substring'](_0x521111,_0x521111+_0x8c9e33));return _0x562345;};function x(_0x30422a,_0x17b4ba){for(const _0x55d3bf in _0x30422a)_0x30422a['hasOwnProperty'](_0x55d3bf)&&_0x17b4ba(_0x55d3bf,_0x30422a[_0x55d3bf]);}const so=function(_0x5b513f){f(!Wi(_0x5b513f),'Invalid\x20JSON\x20number');const _0x2d5b46=0xb,_0x5dcd90=0x34,_0x1a13c2=(0x1<<_0x2d5b46-0x1)-0x1;let _0x44a870,_0x55f6bd,_0xf920c0,_0x1a82a1,_0x2eb08b;_0x5b513f===0x0?(_0x55f6bd=0x0,_0xf920c0=0x0,_0x44a870=0x1/_0x5b513f===-0x1/0x0?0x1:0x0):(_0x44a870=_0x5b513f<0x0,_0x5b513f=Math['abs'](_0x5b513f),_0x5b513f>=Math['pow'](0x2,0x1-_0x1a13c2)?(_0x1a82a1=Math['min'](Math['floor'](Math['log'](_0x5b513f)/Math['LN2']),_0x1a13c2),_0x55f6bd=_0x1a82a1+_0x1a13c2,_0xf920c0=Math['round'](_0x5b513f*Math['pow'](0x2,_0x5dcd90-_0x1a82a1)-Math['pow'](0x2,_0x5dcd90))):(_0x55f6bd=0x0,_0xf920c0=Math['round'](_0x5b513f/Math['pow'](0x2,0x1-_0x1a13c2-_0x5dcd90))));const _0xa591ce=[];for(_0x2eb08b=_0x5dcd90;_0x2eb08b;_0x2eb08b-=0x1)_0xa591ce['push'](_0xf920c0%0x2?0x1:0x0),_0xf920c0=Math['floor'](_0xf920c0/0x2);for(_0x2eb08b=_0x2d5b46;_0x2eb08b;_0x2eb08b-=0x1)_0xa591ce['push'](_0x55f6bd%0x2?0x1:0x0),_0x55f6bd=Math['floor'](_0x55f6bd/0x2);_0xa591ce['push'](_0x44a870?0x1:0x0),_0xa591ce['reverse']();const _0xf156ce=_0xa591ce['join']('');let _0x42931d='';for(_0x2eb08b=0x0;_0x2eb08b<0x40;_0x2eb08b+=0x8){let _0x26c16f=parseInt(_0xf156ce['substr'](_0x2eb08b,0x8),0x2)['toString'](0x10);_0x26c16f['length']===0x1&&(_0x26c16f='0'+_0x26c16f),_0x42931d=_0x42931d+_0x26c16f;}return _0x42931d['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x34c08a,_0x3eea32){let _0x1ad51d='Unknown\x20Error';_0x34c08a==='too_big'?_0x1ad51d='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x34c08a==='permission_denied'?_0x1ad51d='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x34c08a==='unavailable'&&(_0x1ad51d='The\x20service\x20is\x20unavailable');const _0x3a6da1=new Error(_0x34c08a+'\x20at\x20'+_0x3eea32['_path']['toString']()+':\x20'+_0x1ad51d);return _0x3a6da1['code']=_0x34c08a['toUpperCase'](),_0x3a6da1;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x34de41){if(zl['test'](_0x34de41)){const _0x4e10c4=Number(_0x34de41);if(_0x4e10c4>=jl&&_0x4e10c4<=Kl)return _0x4e10c4;}return null;},lt=function(_0x23456c){try{_0x23456c();}catch(_0x4f1939){setTimeout(()=>{const _0x38f481=_0x4f1939['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x38f481),_0x4f1939;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x4917d2,_0x41e457){const _0x1490b6=setTimeout(_0x4917d2,_0x41e457);return typeof _0x1490b6=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1490b6):typeof _0x1490b6=='object'&&_0x1490b6['unref']&&_0x1490b6['unref'](),_0x1490b6;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0xbd592,_0x4249ff){this['appCheckProvider']=_0x4249ff,this['appName']=_0xbd592['name'],H(_0xbd592)&&_0xbd592['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xbd592['settings']['appCheckToken']),this['appCheck']=_0x4249ff==null?void 0x0:_0x4249ff['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4249ff==null||_0x4249ff['get']()['then'](_0x3bdfea=>this['appCheck']=_0x3bdfea);}['getToken'](_0x1859ea){if(this['serverAppAppCheckToken']){if(_0x1859ea)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1859ea):new Promise((_0x457565,_0x17504e)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1859ea)['then'](_0x457565,_0x17504e):_0x457565(null);},0x0);});}['addTokenChangeListener'](_0xd97ec2){var _0x359a60;(_0x359a60=this['appCheckProvider'])==null||_0x359a60['get']()['then'](_0x17eca5=>_0x17eca5['addTokenListener'](_0xd97ec2));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x41e595,_0x5b90f9,_0x18ddba){this['appName_']=_0x41e595,this['firebaseOptions_']=_0x5b90f9,this['authProvider_']=_0x18ddba,this['auth_']=null,this['auth_']=_0x18ddba['getImmediate']({'optional':!0x0}),this['auth_']||_0x18ddba['onInit'](_0x4ec0d2=>this['auth_']=_0x4ec0d2);}['getToken'](_0x132574){return this['auth_']?this['auth_']['getToken'](_0x132574)['catch'](_0x29bbe0=>_0x29bbe0&&_0x29bbe0['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x29bbe0)):new Promise((_0xc6963b,_0x266600)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x132574)['then'](_0xc6963b,_0x266600):_0xc6963b(null);},0x0);});}['addTokenChangeListener'](_0x56cc11){this['auth_']?this['auth_']['addAuthTokenListener'](_0x56cc11):this['authProvider_']['get']()['then'](_0x52489d=>_0x52489d['addAuthTokenListener'](_0x56cc11));}['removeTokenChangeListener'](_0xc588bd){this['authProvider_']['get']()['then'](_0x37eb8b=>_0x37eb8b['removeAuthTokenListener'](_0xc588bd));}['notifyForInvalidToken'](){let _0x4be586='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4be586+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4be586+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4be586+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4be586);}}class tn{constructor(_0x2b719f){this['accessToken']=_0x2b719f;}['getToken'](_0x5458dd){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x353bc9){_0x353bc9(this['accessToken']);}['removeTokenChangeListener'](_0x31eb01){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x4e1465,_0x4da9d9,_0x5be2d6,_0x371e18,_0x32f758=!0x1,_0x267702='',_0x331348=!0x1,_0x3c6392=!0x1,_0xdccc06=null){this['secure']=_0x4da9d9,this['namespace']=_0x5be2d6,this['webSocketOnly']=_0x371e18,this['nodeAdmin']=_0x32f758,this['persistenceKey']=_0x267702,this['includeNamespaceInQueryParams']=_0x331348,this['isUsingEmulator']=_0x3c6392,this['emulatorOptions']=_0xdccc06,this['_host']=_0x4e1465['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x4e1465)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4a014e){_0x4a014e!==this['internalHost']&&(this['internalHost']=_0x4a014e,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1bf0bf=this['toURLString']();return this['persistenceKey']&&(_0x1bf0bf+='<'+this['persistenceKey']+'>'),_0x1bf0bf;}['toURLString'](){const _0x3da539=this['secure']?'https://':'http://',_0x540f09=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3da539+this['host']+'/'+_0x540f09;}}function Xl(_0x22fe16){return _0x22fe16['host']!==_0x22fe16['internalHost']||_0x22fe16['isCustomHost']()||_0x22fe16['includeNamespaceInQueryParams'];}function go(_0x3da37a,_0x461bf8,_0x296103){f(typeof _0x461bf8=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x296103=='object','typeof\x20params\x20must\x20==\x20object');let _0x37a1b4;if(_0x461bf8===fo)_0x37a1b4=(_0x3da37a['secure']?'wss://':'ws://')+_0x3da37a['internalHost']+'/.ws?';else{if(_0x461bf8===po)_0x37a1b4=(_0x3da37a['secure']?'https://':'http://')+_0x3da37a['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x461bf8);}Xl(_0x3da37a)&&(_0x296103['ns']=_0x3da37a['namespace']);const _0x2dd44f=[];return x(_0x296103,(_0x43b128,_0x1a19a9)=>{_0x2dd44f['push'](_0x43b128+'='+_0x1a19a9);}),_0x37a1b4+_0x2dd44f['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x1741dd,_0x2a69c1=0x1){Y(this['counters_'],_0x1741dd)||(this['counters_'][_0x1741dd]=0x0),this['counters_'][_0x1741dd]+=_0x2a69c1;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x535712){const _0x1eb183=_0x535712['toString']();return ti[_0x1eb183]||(ti[_0x1eb183]=new Zl()),ti[_0x1eb183];}function eh(_0x474fd0,_0x4729cd){const _0x463962=_0x474fd0['toString']();return ni[_0x463962]||(ni[_0x463962]=_0x4729cd()),ni[_0x463962];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x36c2e2){this['onMessage_']=_0x36c2e2,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x4f6768,_0x3007b4){this['closeAfterResponse']=_0x4f6768,this['onClose']=_0x3007b4,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xce2355,_0x1f5ae0){for(this['pendingResponses'][_0xce2355]=_0x1f5ae0;this['pendingResponses'][this['currentResponseNum']];){const _0x4e5985=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3cc9a1=0x0;_0x3cc9a1<_0x4e5985['length'];++_0x3cc9a1)_0x4e5985[_0x3cc9a1]&&lt(()=>{this['onMessage_'](_0x4e5985[_0x3cc9a1]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x290d3f,_0x4961be,_0x124b3d,_0x136ca6,_0x24ca38,_0x2c057a,_0x1da841){this['connId']=_0x290d3f,this['repoInfo']=_0x4961be,this['applicationId']=_0x124b3d,this['appCheckToken']=_0x136ca6,this['authToken']=_0x24ca38,this['transportSessionId']=_0x2c057a,this['lastSessionId']=_0x1da841,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x290d3f),this['stats_']=Hi(_0x4961be),this['urlFn']=_0x1b07e0=>(this['appCheckToken']&&(_0x1b07e0[yi]=this['appCheckToken']),go(_0x4961be,po,_0x1b07e0));}['open'](_0x478820,_0x2ce56c){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2ce56c,this['myPacketOrderer']=new th(_0x478820),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x20a8b6)=>{const [_0xc2134,_0x3f2f69,_0x321484,_0x125692,_0x172c72]=_0x20a8b6;if(this['incrementIncomingBytes_'](_0x20a8b6),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0xc2134===$s)this['id']=_0x3f2f69,this['password']=_0x321484;else{if(_0xc2134===nh)_0x3f2f69?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3f2f69,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0xc2134);}}},(..._0x56147f)=>{const [_0x598f03,_0x4c767d]=_0x56147f;this['incrementIncomingBytes_'](_0x56147f),this['myPacketOrderer']['handleResponse'](_0x598f03,_0x4c767d);},()=>{this['onClosed_']();},this['urlFn']);const _0x40ef7f={};_0x40ef7f[$s]='t',_0x40ef7f[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x40ef7f[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x40ef7f[ro]=Vi,this['transportSessionId']&&(_0x40ef7f[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x40ef7f[ho]=this['lastSessionId']),this['applicationId']&&(_0x40ef7f[uo]=this['applicationId']),this['appCheckToken']&&(_0x40ef7f[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x40ef7f[ao]=co);const _0x5594f7=this['urlFn'](_0x40ef7f);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5594f7),this['scriptTagHolder']['addTag'](_0x5594f7,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5833f9){const _0x3e2fac=O(_0x5833f9);this['bytesSent']+=_0x3e2fac['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3e2fac['length']);const _0x1ab6f2=Br(_0x3e2fac),_0x5e458f=io(_0x1ab6f2,hh);for(let _0x1a000b=0x0;_0x1a000b<_0x5e458f['length'];_0x1a000b++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5e458f['length'],_0x5e458f[_0x1a000b]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x18d237,_0x4eed91){this['myDisconnFrame']=document['createElement']('iframe');const _0x11cb9f={};_0x11cb9f[lh]='t',_0x11cb9f[mo]=_0x18d237,_0x11cb9f[yo]=_0x4eed91,this['myDisconnFrame']['src']=this['urlFn'](_0x11cb9f),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x4c7cc8){const _0x39850d=O(_0x4c7cc8)['length'];this['bytesReceived']+=_0x39850d,this['stats_']['incrementCounter']('bytes_received',_0x39850d);}}class $i{constructor(_0xdd4df0,_0x2913d3,_0x4e2439,_0x3bb43b){this['onDisconnect']=_0x4e2439,this['urlFn']=_0x3bb43b,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0xdd4df0,window[sh+this['uniqueCallbackIdentifier']]=_0x2913d3,this['myIFrame']=$i['createIFrame_']();let _0x4585bd='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4585bd='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1b0a8e='<html><body>'+_0x4585bd+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1b0a8e),this['myIFrame']['doc']['close']();}catch(_0x35e59a){L('frame\x20writing\x20exception'),_0x35e59a['stack']&&L(_0x35e59a['stack']),L(_0x35e59a);}}}static['createIFrame_'](){const _0x488ca8=document['createElement']('iframe');if(_0x488ca8['style']['display']='none',document['body']){document['body']['appendChild'](_0x488ca8);try{_0x488ca8['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x4573dd=document['domain'];_0x488ca8['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x4573dd+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x488ca8['contentDocument']?_0x488ca8['doc']=_0x488ca8['contentDocument']:_0x488ca8['contentWindow']?_0x488ca8['doc']=_0x488ca8['contentWindow']['document']:_0x488ca8['document']&&(_0x488ca8['doc']=_0x488ca8['document']),_0x488ca8;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3e6209=this['onDisconnect'];_0x3e6209&&(this['onDisconnect']=null,_0x3e6209());}['startLongPoll'](_0x410260,_0xc0d7d8){for(this['myID']=_0x410260,this['myPW']=_0xc0d7d8,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x409627={};_0x409627[mo]=this['myID'],_0x409627[yo]=this['myPW'],_0x409627[vo]=this['currentSerial'];let _0x475c8d=this['urlFn'](_0x409627),_0x590ec1='',_0x5d2693=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x590ec1['length']<=Eo;){const _0x3cf448=this['pendingSegs']['shift']();_0x590ec1=_0x590ec1+'&'+oh+_0x5d2693+'='+_0x3cf448['seg']+'&'+ah+_0x5d2693+'='+_0x3cf448['ts']+'&'+ch+_0x5d2693+'='+_0x3cf448['d'],_0x5d2693++;}return _0x475c8d=_0x475c8d+_0x590ec1,this['addLongPollTag_'](_0x475c8d,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x4a3aa3,_0xd2d561,_0x4483f1){this['pendingSegs']['push']({'seg':_0x4a3aa3,'ts':_0xd2d561,'d':_0x4483f1}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x57e9b8,_0x5b55ec){this['outstandingRequests']['add'](_0x5b55ec);const _0x639ab9=()=>{this['outstandingRequests']['delete'](_0x5b55ec),this['newRequest_']();},_0x5d242a=setTimeout(_0x639ab9,Math['floor'](uh)),_0xde4d40=()=>{clearTimeout(_0x5d242a),_0x639ab9();};this['addTag'](_0x57e9b8,_0xde4d40);}['addTag'](_0x5a32fb,_0x37b0a0){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x24aa13=this['myIFrame']['doc']['createElement']('script');_0x24aa13['type']='text/javascript',_0x24aa13['async']=!0x0,_0x24aa13['src']=_0x5a32fb,_0x24aa13['onload']=_0x24aa13['onreadystatechange']=function(){const _0x2d4ba1=_0x24aa13['readyState'];(!_0x2d4ba1||_0x2d4ba1==='loaded'||_0x2d4ba1==='complete')&&(_0x24aa13['onload']=_0x24aa13['onreadystatechange']=null,_0x24aa13['parentNode']&&_0x24aa13['parentNode']['removeChild'](_0x24aa13),_0x37b0a0());},_0x24aa13['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5a32fb),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x24aa13);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x2f5202,_0x5e9cbe,_0x337f0b,_0x314c1f,_0x107c6f,_0x3f3518,_0x1a3667){this['connId']=_0x2f5202,this['applicationId']=_0x337f0b,this['appCheckToken']=_0x314c1f,this['authToken']=_0x107c6f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x5e9cbe),this['connURL']=G['connectionURL_'](_0x5e9cbe,_0x3f3518,_0x1a3667,_0x314c1f,_0x337f0b),this['nodeAdmin']=_0x5e9cbe['nodeAdmin'];}static['connectionURL_'](_0x581ad7,_0x360a6d,_0xf86017,_0x3808c9,_0x1715f3){const _0x4baacb={};return _0x4baacb[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4baacb[ao]=co),_0x360a6d&&(_0x4baacb[oo]=_0x360a6d),_0xf86017&&(_0x4baacb[ho]=_0xf86017),_0x3808c9&&(_0x4baacb[yi]=_0x3808c9),_0x1715f3&&(_0x4baacb[uo]=_0x1715f3),go(_0x581ad7,fo,_0x4baacb);}['open'](_0x1dbdba,_0x15259b){this['onDisconnect']=_0x15259b,this['onMessage']=_0x1dbdba,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x33de03;dc(),this['mySock']=new hn(this['connURL'],[],_0x33de03);}catch(_0x1ed9b9){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x28bce7=_0x1ed9b9['message']||_0x1ed9b9['data'];_0x28bce7&&this['log_'](_0x28bce7),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x496696=>{this['handleIncomingFrame'](_0x496696);},this['mySock']['onerror']=_0x1fe967=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x30e9ce=_0x1fe967['message']||_0x1fe967['data'];_0x30e9ce&&this['log_'](_0x30e9ce),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x52c5cb=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x369f41=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x20deb9=navigator['userAgent']['match'](_0x369f41);_0x20deb9&&_0x20deb9['length']>0x1&&parseFloat(_0x20deb9[0x1])<4.4&&(_0x52c5cb=!0x0);}return!_0x52c5cb&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x115ea1){if(this['frames']['push'](_0x115ea1),this['frames']['length']===this['totalFrames']){const _0x2118c7=this['frames']['join']('');this['frames']=null;const _0x1d64a8=bt(_0x2118c7);this['onMessage'](_0x1d64a8);}}['handleNewFrameCount_'](_0x336e33){this['totalFrames']=_0x336e33,this['frames']=[];}['extractFrameCount_'](_0x3e7a00){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x3e7a00['length']<=0x6){const _0x59495f=Number(_0x3e7a00);if(!isNaN(_0x59495f))return this['handleNewFrameCount_'](_0x59495f),null;}return this['handleNewFrameCount_'](0x1),_0x3e7a00;}['handleIncomingFrame'](_0xeb191d){if(this['mySock']===null)return;const _0x3da823=_0xeb191d['data'];if(this['bytesReceived']+=_0x3da823['length'],this['stats_']['incrementCounter']('bytes_received',_0x3da823['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x3da823);else{const _0x1109ee=this['extractFrameCount_'](_0x3da823);_0x1109ee!==null&&this['appendFrame_'](_0x1109ee);}}['send'](_0x5951df){this['resetKeepAlive']();const _0x23d90b=O(_0x5951df);this['bytesSent']+=_0x23d90b['length'],this['stats_']['incrementCounter']('bytes_sent',_0x23d90b['length']);const _0x3a3322=io(_0x23d90b,fh);_0x3a3322['length']>0x1&&this['sendString_'](String(_0x3a3322['length']));for(let _0x368390=0x0;_0x368390<_0x3a3322['length'];_0x368390++)this['sendString_'](_0x3a3322[_0x368390]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0xa72c){try{this['mySock']['send'](_0xa72c);}catch(_0x4bcb47){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4bcb47['message']||_0x4bcb47['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x566743){this['initTransports_'](_0x566743);}['initTransports_'](_0x481454){const _0x557327=G&&G['isAvailable']();let _0x14974f=_0x557327&&!G['previouslyFailed']();if(_0x481454['webSocketOnly']&&(_0x557327||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x14974f=!0x0),_0x14974f)this['transports_']=[G];else{const _0x169834=this['transports_']=[];for(const _0x40ae86 of At['ALL_TRANSPORTS'])_0x40ae86&&_0x40ae86['isAvailable']()&&_0x169834['push'](_0x40ae86);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x45539a,_0x42bab2,_0x139758,_0x850705,_0x1229fb,_0x544e92,_0x1b5c08,_0x5cc1f2,_0x565dda,_0x439f2a){this['id']=_0x45539a,this['repoInfo_']=_0x42bab2,this['applicationId_']=_0x139758,this['appCheckToken_']=_0x850705,this['authToken_']=_0x1229fb,this['onMessage_']=_0x544e92,this['onReady_']=_0x1b5c08,this['onDisconnect_']=_0x5cc1f2,this['onKill_']=_0x565dda,this['lastSessionId']=_0x439f2a,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x42bab2),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x699adf=this['transportManager_']['initialTransport']();this['conn_']=new _0x699adf(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x699adf['responsesRequiredToBeHealthy']||0x0;const _0x23d764=this['connReceiver_'](this['conn_']),_0x497ca2=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x23d764,_0x497ca2);},Math['floor'](0x0));const _0x13b978=_0x699adf['healthyTimeout']||0x0;_0x13b978>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x13b978)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1dd434){return _0x1088c1=>{_0x1dd434===this['conn_']?this['onConnectionLost_'](_0x1088c1):_0x1dd434===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3d8acf){return _0x53db58=>{this['state_']!==0x2&&(_0x3d8acf===this['rx_']?this['onPrimaryMessageReceived_'](_0x53db58):_0x3d8acf===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x53db58):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1e5a21){const _0x356874={'t':'d','d':_0x1e5a21};this['sendData_'](_0x356874);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x3d4529){if(ii in _0x3d4529){const _0xb8b20e=_0x3d4529[ii];_0xb8b20e===js?this['upgradeIfSecondaryHealthy_']():_0xb8b20e===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0xb8b20e===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x568daa){const _0x24bf4e=pt('t',_0x568daa),_0x1c1f49=pt('d',_0x568daa);if(_0x24bf4e==='c')this['onSecondaryControl_'](_0x1c1f49);else{if(_0x24bf4e==='d')this['pendingDataMessages']['push'](_0x1c1f49);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x24bf4e);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x1d2baa){const _0x3d5744=pt('t',_0x1d2baa),_0x55344f=pt('d',_0x1d2baa);_0x3d5744==='c'?this['onControl_'](_0x55344f):_0x3d5744==='d'&&this['onDataMessage_'](_0x55344f);}['onDataMessage_'](_0x46fd11){this['onPrimaryResponse_'](),this['onMessage_'](_0x46fd11);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x31a7bb){const _0x42fa66=pt(ii,_0x31a7bb);if(Gs in _0x31a7bb){const _0x4d229f=_0x31a7bb[Gs];if(_0x42fa66===Ih){const _0x444201={..._0x4d229f};this['repoInfo_']['isUsingEmulator']&&(_0x444201['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x444201);}else{if(_0x42fa66===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x16163e=0x0;_0x16163e<this['pendingDataMessages']['length'];++_0x16163e)this['onDataMessage_'](this['pendingDataMessages'][_0x16163e]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x42fa66===vh?this['onConnectionShutdown_'](_0x4d229f):_0x42fa66===qs?this['onReset_'](_0x4d229f):_0x42fa66===Eh?mi('Server\x20Error:\x20'+_0x4d229f):_0x42fa66===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x42fa66);}}}['onHandshake_'](_0x5b776a){const _0x2d6770=_0x5b776a['ts'],_0x16183d=_0x5b776a['v'],_0x4c6076=_0x5b776a['h'];this['sessionId']=_0x5b776a['s'],this['repoInfo_']['host']=_0x4c6076,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2d6770),Vi!==_0x16183d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1e85f0=this['transportManager_']['upgradeTransport']();_0x1e85f0&&this['startUpgrade_'](_0x1e85f0);}['startUpgrade_'](_0x2c7b1d){this['secondaryConn_']=new _0x2c7b1d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x2c7b1d['responsesRequiredToBeHealthy']||0x0;const _0x206f1a=this['connReceiver_'](this['secondaryConn_']),_0x289c4c=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x206f1a,_0x289c4c),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x2b0430){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2b0430),this['repoInfo_']['host']=_0x2b0430,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x2652e3,_0x305f2f){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x2652e3,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x305f2f,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2ac866=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2ac866||this['rx_']===_0x2ac866)&&this['close']();}['onConnectionLost_'](_0x4c3b53){this['conn_']=null,!_0x4c3b53&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x396bc8){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x396bc8),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x422124){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x422124);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x318723,_0x277231,_0x2799e5,_0x278e2b){}['merge'](_0x3d63f3,_0x48babd,_0x277406,_0x3fa24d){}['refreshAuthToken'](_0x564b09){}['refreshAppCheckToken'](_0x190bf0){}['onDisconnectPut'](_0x30e0ce,_0x4f4cee,_0x3dfa37){}['onDisconnectMerge'](_0x30c30c,_0x57dead,_0x3a30ed){}['onDisconnectCancel'](_0x49b584,_0x2780fd){}['reportStats'](_0x346224){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x21c3ff){this['allowedEvents_']=_0x21c3ff,this['listeners_']={},f(Array['isArray'](_0x21c3ff)&&_0x21c3ff['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5dd03a,..._0x12801b){if(Array['isArray'](this['listeners_'][_0x5dd03a])){const _0x5c5d1f=[...this['listeners_'][_0x5dd03a]];for(let _0x2b6c47=0x0;_0x2b6c47<_0x5c5d1f['length'];_0x2b6c47++)_0x5c5d1f[_0x2b6c47]['callback']['apply'](_0x5c5d1f[_0x2b6c47]['context'],_0x12801b);}}['on'](_0x33be01,_0x44795f,_0xc248bb){this['validateEventType_'](_0x33be01),this['listeners_'][_0x33be01]=this['listeners_'][_0x33be01]||[],this['listeners_'][_0x33be01]['push']({'callback':_0x44795f,'context':_0xc248bb});const _0x385c2f=this['getInitialEvent'](_0x33be01);_0x385c2f&&_0x44795f['apply'](_0xc248bb,_0x385c2f);}['off'](_0x46efe5,_0x17627c,_0x4cb0c1){this['validateEventType_'](_0x46efe5);const _0x42a64c=this['listeners_'][_0x46efe5]||[];for(let _0xcb10c3=0x0;_0xcb10c3<_0x42a64c['length'];_0xcb10c3++)if(_0x42a64c[_0xcb10c3]['callback']===_0x17627c&&(!_0x4cb0c1||_0x4cb0c1===_0x42a64c[_0xcb10c3]['context'])){_0x42a64c['splice'](_0xcb10c3,0x1);return;}}['validateEventType_'](_0x4d8ab8){f(this['allowedEvents_']['find'](_0x2cb5d5=>_0x2cb5d5===_0x4d8ab8),'Unknown\x20event:\x20'+_0x4d8ab8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1bfc76){return f(_0x1bfc76==='online','Unknown\x20event\x20type:\x20'+_0x1bfc76),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x532f05,_0x190c52){if(_0x190c52===void 0x0){this['pieces_']=_0x532f05['split']('/');let _0x180f50=0x0;for(let _0x4307a7=0x0;_0x4307a7<this['pieces_']['length'];_0x4307a7++)this['pieces_'][_0x4307a7]['length']>0x0&&(this['pieces_'][_0x180f50]=this['pieces_'][_0x4307a7],_0x180f50++);this['pieces_']['length']=_0x180f50,this['pieceNum_']=0x0;}else this['pieces_']=_0x532f05,this['pieceNum_']=_0x190c52;}['toString'](){let _0x3ed27c='';for(let _0x3fe81f=this['pieceNum_'];_0x3fe81f<this['pieces_']['length'];_0x3fe81f++)this['pieces_'][_0x3fe81f]!==''&&(_0x3ed27c+='/'+this['pieces_'][_0x3fe81f]);return _0x3ed27c||'/';}}function w(){return new C('');}function y(_0x16c001){return _0x16c001['pieceNum_']>=_0x16c001['pieces_']['length']?null:_0x16c001['pieces_'][_0x16c001['pieceNum_']];}function we(_0x5ae5fe){return _0x5ae5fe['pieces_']['length']-_0x5ae5fe['pieceNum_'];}function b(_0x5c5890){let _0x5a9863=_0x5c5890['pieceNum_'];return _0x5a9863<_0x5c5890['pieces_']['length']&&_0x5a9863++,new C(_0x5c5890['pieces_'],_0x5a9863);}function Gi(_0x3d6797){return _0x3d6797['pieceNum_']<_0x3d6797['pieces_']['length']?_0x3d6797['pieces_'][_0x3d6797['pieces_']['length']-0x1]:null;}function Ch(_0x136f7a){let _0x5c0a39='';for(let _0x1c31c8=_0x136f7a['pieceNum_'];_0x1c31c8<_0x136f7a['pieces_']['length'];_0x1c31c8++)_0x136f7a['pieces_'][_0x1c31c8]!==''&&(_0x5c0a39+='/'+encodeURIComponent(String(_0x136f7a['pieces_'][_0x1c31c8])));return _0x5c0a39||'/';}function kt(_0xc296e,_0x4772c2=0x0){return _0xc296e['pieces_']['slice'](_0xc296e['pieceNum_']+_0x4772c2);}function To(_0x212e11){if(_0x212e11['pieceNum_']>=_0x212e11['pieces_']['length'])return null;const _0xb3e4b2=[];for(let _0x4a8c8a=_0x212e11['pieceNum_'];_0x4a8c8a<_0x212e11['pieces_']['length']-0x1;_0x4a8c8a++)_0xb3e4b2['push'](_0x212e11['pieces_'][_0x4a8c8a]);return new C(_0xb3e4b2,0x0);}function A(_0x4411ad,_0x53b9f7){const _0x31d1b4=[];for(let _0x1dc0c7=_0x4411ad['pieceNum_'];_0x1dc0c7<_0x4411ad['pieces_']['length'];_0x1dc0c7++)_0x31d1b4['push'](_0x4411ad['pieces_'][_0x1dc0c7]);if(_0x53b9f7 instanceof C){for(let _0x3071c3=_0x53b9f7['pieceNum_'];_0x3071c3<_0x53b9f7['pieces_']['length'];_0x3071c3++)_0x31d1b4['push'](_0x53b9f7['pieces_'][_0x3071c3]);}else{const _0xafb7c2=_0x53b9f7['split']('/');for(let _0x3451ec=0x0;_0x3451ec<_0xafb7c2['length'];_0x3451ec++)_0xafb7c2[_0x3451ec]['length']>0x0&&_0x31d1b4['push'](_0xafb7c2[_0x3451ec]);}return new C(_0x31d1b4,0x0);}function v(_0x354690){return _0x354690['pieceNum_']>=_0x354690['pieces_']['length'];}function F(_0x28cb2c,_0x3d14f1){const _0x8d0317=y(_0x28cb2c),_0x327607=y(_0x3d14f1);if(_0x8d0317===null)return _0x3d14f1;if(_0x8d0317===_0x327607)return F(b(_0x28cb2c),b(_0x3d14f1));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3d14f1+')\x20is\x20not\x20within\x20outerPath\x20('+_0x28cb2c+')');}function Th(_0x40edd5,_0x11d095){const _0x1b9c6c=kt(_0x40edd5,0x0),_0x4a3f16=kt(_0x11d095,0x0);for(let _0x607aba=0x0;_0x607aba<_0x1b9c6c['length']&&_0x607aba<_0x4a3f16['length'];_0x607aba++){const _0x40631e=He(_0x1b9c6c[_0x607aba],_0x4a3f16[_0x607aba]);if(_0x40631e!==0x0)return _0x40631e;}return _0x1b9c6c['length']===_0x4a3f16['length']?0x0:_0x1b9c6c['length']<_0x4a3f16['length']?-0x1:0x1;}function qi(_0x3cbb60,_0x287c80){if(we(_0x3cbb60)!==we(_0x287c80))return!0x1;for(let _0x216e8c=_0x3cbb60['pieceNum_'],_0xad08e9=_0x287c80['pieceNum_'];_0x216e8c<=_0x3cbb60['pieces_']['length'];_0x216e8c++,_0xad08e9++)if(_0x3cbb60['pieces_'][_0x216e8c]!==_0x287c80['pieces_'][_0xad08e9])return!0x1;return!0x0;}function $(_0x5eeb7e,_0x32def9){let _0x66ec7c=_0x5eeb7e['pieceNum_'],_0x53b7bd=_0x32def9['pieceNum_'];if(we(_0x5eeb7e)>we(_0x32def9))return!0x1;for(;_0x66ec7c<_0x5eeb7e['pieces_']['length'];){if(_0x5eeb7e['pieces_'][_0x66ec7c]!==_0x32def9['pieces_'][_0x53b7bd])return!0x1;++_0x66ec7c,++_0x53b7bd;}return!0x0;}class Sh{constructor(_0xfb4c3c,_0xba9c48){this['errorPrefix_']=_0xba9c48,this['parts_']=kt(_0xfb4c3c,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x37f7c8=0x0;_0x37f7c8<this['parts_']['length'];_0x37f7c8++)this['byteLength_']+=Pn(this['parts_'][_0x37f7c8]);So(this);}}function bh(_0x28a9f5,_0x3fa159){_0x28a9f5['parts_']['length']>0x0&&(_0x28a9f5['byteLength_']+=0x1),_0x28a9f5['parts_']['push'](_0x3fa159),_0x28a9f5['byteLength_']+=Pn(_0x3fa159),So(_0x28a9f5);}function Rh(_0x5c800d){const _0x42d1e9=_0x5c800d['parts_']['pop']();_0x5c800d['byteLength_']-=Pn(_0x42d1e9),_0x5c800d['parts_']['length']>0x0&&(_0x5c800d['byteLength_']-=0x1);}function So(_0x4a7cd0){if(_0x4a7cd0['byteLength_']>Js)throw new Error(_0x4a7cd0['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x4a7cd0['byteLength_']+').');if(_0x4a7cd0['parts_']['length']>Qs)throw new Error(_0x4a7cd0['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x4a7cd0));}function Ne(_0x2929b4){return _0x2929b4['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2929b4['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x5dc28a,_0x2fe747;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2fe747='visibilitychange',_0x5dc28a='hidden'):typeof document['mozHidden']<'u'?(_0x2fe747='mozvisibilitychange',_0x5dc28a='mozHidden'):typeof document['msHidden']<'u'?(_0x2fe747='msvisibilitychange',_0x5dc28a='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2fe747='webkitvisibilitychange',_0x5dc28a='webkitHidden')),this['visible_']=!0x0,_0x2fe747&&document['addEventListener'](_0x2fe747,()=>{const _0x2b89cc=!document[_0x5dc28a];_0x2b89cc!==this['visible_']&&(this['visible_']=_0x2b89cc,this['trigger']('visible',_0x2b89cc));},!0x1);}['getInitialEvent'](_0x4b538b){return f(_0x4b538b==='visible','Unknown\x20event\x20type:\x20'+_0x4b538b),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x3ef761,_0x9f5b99,_0x5ee2b8,_0x4cb8ab,_0x26bb58,_0x4d38b9,_0x2d6c2a,_0x24586a){if(super(),this['repoInfo_']=_0x3ef761,this['applicationId_']=_0x9f5b99,this['onDataUpdate_']=_0x5ee2b8,this['onConnectStatus_']=_0x4cb8ab,this['onServerInfoUpdate_']=_0x26bb58,this['authTokenProvider_']=_0x4d38b9,this['appCheckTokenProvider_']=_0x2d6c2a,this['authOverride_']=_0x24586a,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x24586a)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3ef761['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x38b613,_0x125c69,_0x4d5106){const _0x3d897c=++this['requestNumber_'],_0x43022e={'r':_0x3d897c,'a':_0x38b613,'b':_0x125c69};this['log_'](O(_0x43022e)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x43022e),_0x4d5106&&(this['requestCBHash_'][_0x3d897c]=_0x4d5106);}['get'](_0x417083){this['initConnection_']();const _0x48e612=new Ve(),_0xa55a7a={'action':'g','request':{'p':_0x417083['_path']['toString'](),'q':_0x417083['_queryObject']},'onComplete':_0xcdf304=>{const _0xd3b2e6=_0xcdf304['d'];_0xcdf304['s']==='ok'?_0x48e612['resolve'](_0xd3b2e6):_0x48e612['reject'](_0xd3b2e6);}};this['outstandingGets_']['push'](_0xa55a7a),this['outstandingGetCount_']++;const _0x337027=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x337027),_0x48e612['promise'];}['listen'](_0x18d521,_0x52b32b,_0x1a396a,_0x5040e2){this['initConnection_']();const _0x43772c=_0x18d521['_queryIdentifier'],_0x6712f0=_0x18d521['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x6712f0+'\x20'+_0x43772c),this['listens']['has'](_0x6712f0)||this['listens']['set'](_0x6712f0,new Map()),f(_0x18d521['_queryParams']['isDefault']()||!_0x18d521['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x6712f0)['has'](_0x43772c),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0xff04b6={'onComplete':_0x5040e2,'hashFn':_0x52b32b,'query':_0x18d521,'tag':_0x1a396a};this['listens']['get'](_0x6712f0)['set'](_0x43772c,_0xff04b6),this['connected_']&&this['sendListen_'](_0xff04b6);}['sendGet_'](_0x702f25){const _0x42c537=this['outstandingGets_'][_0x702f25];this['sendRequest']('g',_0x42c537['request'],_0x48da1c=>{delete this['outstandingGets_'][_0x702f25],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x42c537['onComplete']&&_0x42c537['onComplete'](_0x48da1c);});}['sendListen_'](_0x3aabac){const _0x1bab42=_0x3aabac['query'],_0x1d0bc=_0x1bab42['_path']['toString'](),_0x530f17=_0x1bab42['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1d0bc+'\x20for\x20'+_0x530f17);const _0x4ecfc1={'p':_0x1d0bc},_0x3174b7='q';_0x3aabac['tag']&&(_0x4ecfc1['q']=_0x1bab42['_queryObject'],_0x4ecfc1['t']=_0x3aabac['tag']),_0x4ecfc1['h']=_0x3aabac['hashFn'](),this['sendRequest'](_0x3174b7,_0x4ecfc1,_0x1c8912=>{const _0x3881ab=_0x1c8912['d'],_0x2cb203=_0x1c8912['s'];ie['warnOnListenWarnings_'](_0x3881ab,_0x1bab42),(this['listens']['get'](_0x1d0bc)&&this['listens']['get'](_0x1d0bc)['get'](_0x530f17))===_0x3aabac&&(this['log_']('listen\x20response',_0x1c8912),_0x2cb203!=='ok'&&this['removeListen_'](_0x1d0bc,_0x530f17),_0x3aabac['onComplete']&&_0x3aabac['onComplete'](_0x2cb203,_0x3881ab));});}static['warnOnListenWarnings_'](_0x1e1018,_0x1f38c){if(_0x1e1018&&typeof _0x1e1018=='object'&&Y(_0x1e1018,'w')){const _0x4fbe40=Oe(_0x1e1018,'w');if(Array['isArray'](_0x4fbe40)&&~_0x4fbe40['indexOf']('no_index')){const _0x3ab920='\x22.indexOn\x22:\x20\x22'+_0x1f38c['_queryParams']['getIndex']()['toString']()+'\x22',_0x3d5677=_0x1f38c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3ab920+'\x20at\x20'+_0x3d5677+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x5ebf76){this['authToken_']=_0x5ebf76,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x5ebf76);}['reduceReconnectDelayIfAdminCredential_'](_0x12adc7){(_0x12adc7&&_0x12adc7['length']===0x28||vc(_0x12adc7))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x25a045){this['appCheckToken_']=_0x25a045,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x253903=this['authToken_'],_0x39ef98=yc(_0x253903)?'auth':'gauth',_0x5895de={'cred':_0x253903};this['authOverride_']===null?_0x5895de['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5895de['authvar']=this['authOverride_']),this['sendRequest'](_0x39ef98,_0x5895de,_0x107be6=>{const _0x153825=_0x107be6['s'],_0x327267=_0x107be6['d']||'error';this['authToken_']===_0x253903&&(_0x153825==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x153825,_0x327267));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2b81e4=>{const _0x1affb3=_0x2b81e4['s'],_0x197498=_0x2b81e4['d']||'error';_0x1affb3==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x1affb3,_0x197498);});}['unlisten'](_0x4fdddd,_0x2eade5){const _0x1be636=_0x4fdddd['_path']['toString'](),_0x5e4e45=_0x4fdddd['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1be636+'\x20'+_0x5e4e45),f(_0x4fdddd['_queryParams']['isDefault']()||!_0x4fdddd['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1be636,_0x5e4e45)&&this['connected_']&&this['sendUnlisten_'](_0x1be636,_0x5e4e45,_0x4fdddd['_queryObject'],_0x2eade5);}['sendUnlisten_'](_0x3edb92,_0x578870,_0x35e36b,_0x3cb7db){this['log_']('Unlisten\x20on\x20'+_0x3edb92+'\x20for\x20'+_0x578870);const _0x116f26={'p':_0x3edb92},_0x28e479='n';_0x3cb7db&&(_0x116f26['q']=_0x35e36b,_0x116f26['t']=_0x3cb7db),this['sendRequest'](_0x28e479,_0x116f26);}['onDisconnectPut'](_0x26b7cf,_0x2d6a92,_0x4d7f66){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x26b7cf,_0x2d6a92,_0x4d7f66):this['onDisconnectRequestQueue_']['push']({'pathString':_0x26b7cf,'action':'o','data':_0x2d6a92,'onComplete':_0x4d7f66});}['onDisconnectMerge'](_0x52bea6,_0x2b0200,_0x147898){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x52bea6,_0x2b0200,_0x147898):this['onDisconnectRequestQueue_']['push']({'pathString':_0x52bea6,'action':'om','data':_0x2b0200,'onComplete':_0x147898});}['onDisconnectCancel'](_0x3c007c,_0x1c3ce6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3c007c,null,_0x1c3ce6):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3c007c,'action':'oc','data':null,'onComplete':_0x1c3ce6});}['sendOnDisconnect_'](_0x480369,_0x560994,_0x1ede38,_0x18534a){const _0x4affc6={'p':_0x560994,'d':_0x1ede38};this['log_']('onDisconnect\x20'+_0x480369,_0x4affc6),this['sendRequest'](_0x480369,_0x4affc6,_0x3ba707=>{_0x18534a&&setTimeout(()=>{_0x18534a(_0x3ba707['s'],_0x3ba707['d']);},Math['floor'](0x0));});}['put'](_0x412f02,_0x410df1,_0x1e0fc1,_0x49a91c){this['putInternal']('p',_0x412f02,_0x410df1,_0x1e0fc1,_0x49a91c);}['merge'](_0x447dc6,_0x372c7c,_0x9d0f05,_0x3de69b){this['putInternal']('m',_0x447dc6,_0x372c7c,_0x9d0f05,_0x3de69b);}['putInternal'](_0x2e427b,_0x3655a1,_0x1f9f76,_0x354e4e,_0x24b4cd){this['initConnection_']();const _0x4de5be={'p':_0x3655a1,'d':_0x1f9f76};_0x24b4cd!==void 0x0&&(_0x4de5be['h']=_0x24b4cd),this['outstandingPuts_']['push']({'action':_0x2e427b,'request':_0x4de5be,'onComplete':_0x354e4e}),this['outstandingPutCount_']++;const _0x5a41e1=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x5a41e1):this['log_']('Buffering\x20put:\x20'+_0x3655a1);}['sendPut_'](_0x5653b4){const _0x116b28=this['outstandingPuts_'][_0x5653b4]['action'],_0x37834b=this['outstandingPuts_'][_0x5653b4]['request'],_0x24c44f=this['outstandingPuts_'][_0x5653b4]['onComplete'];this['outstandingPuts_'][_0x5653b4]['queued']=this['connected_'],this['sendRequest'](_0x116b28,_0x37834b,_0x1c3c59=>{this['log_'](_0x116b28+'\x20response',_0x1c3c59),delete this['outstandingPuts_'][_0x5653b4],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x24c44f&&_0x24c44f(_0x1c3c59['s'],_0x1c3c59['d']);});}['reportStats'](_0x2038b0){if(this['connected_']){const _0x5612cc={'c':_0x2038b0};this['log_']('reportStats',_0x5612cc),this['sendRequest']('s',_0x5612cc,_0x1bc297=>{if(_0x1bc297['s']!=='ok'){const _0x746cfb=_0x1bc297['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x746cfb);}});}}['onDataMessage_'](_0x36dcd4){if('r'in _0x36dcd4){this['log_']('from\x20server:\x20'+O(_0x36dcd4));const _0x3f15f8=_0x36dcd4['r'],_0x348c99=this['requestCBHash_'][_0x3f15f8];_0x348c99&&(delete this['requestCBHash_'][_0x3f15f8],_0x348c99(_0x36dcd4['b']));}else{if('error'in _0x36dcd4)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x36dcd4['error'];'a'in _0x36dcd4&&this['onDataPush_'](_0x36dcd4['a'],_0x36dcd4['b']);}}['onDataPush_'](_0x36ab83,_0x59b305){this['log_']('handleServerMessage',_0x36ab83,_0x59b305),_0x36ab83==='d'?this['onDataUpdate_'](_0x59b305['p'],_0x59b305['d'],!0x1,_0x59b305['t']):_0x36ab83==='m'?this['onDataUpdate_'](_0x59b305['p'],_0x59b305['d'],!0x0,_0x59b305['t']):_0x36ab83==='c'?this['onListenRevoked_'](_0x59b305['p'],_0x59b305['q']):_0x36ab83==='ac'?this['onAuthRevoked_'](_0x59b305['s'],_0x59b305['d']):_0x36ab83==='apc'?this['onAppCheckRevoked_'](_0x59b305['s'],_0x59b305['d']):_0x36ab83==='sd'?this['onSecurityDebugPacket_'](_0x59b305):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x36ab83)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x50f4cf,_0xd30a48){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x50f4cf),this['lastSessionId']=_0xd30a48,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x473aec){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x473aec));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1be196){_0x1be196&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1be196;}['onOnline_'](_0x2d5649){_0x2d5649?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x429a26=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x32bdb9=Math['max'](0x0,this['reconnectDelay_']-_0x429a26);_0x32bdb9=Math['random']()*_0x32bdb9,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x32bdb9+'ms'),this['scheduleConnect_'](_0x32bdb9),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x462004=this['onDataMessage_']['bind'](this),_0x3fcb33=this['onReady_']['bind'](this),_0x33a63c=this['onRealtimeDisconnect_']['bind'](this),_0x528b03=this['id']+':'+ie['nextConnectionId_']++,_0x110856=this['lastSessionId'];let _0x1e77fc=!0x1,_0x466184=null;const _0x5befa3=function(){_0x466184?_0x466184['close']():(_0x1e77fc=!0x0,_0x33a63c());},_0x43c20c=function(_0x1ad91f){f(_0x466184,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x466184['sendRequest'](_0x1ad91f);};this['realtime_']={'close':_0x5befa3,'sendRequest':_0x43c20c};const _0xa76069=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5b5afe,_0xb32a1]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xa76069),this['appCheckTokenProvider_']['getToken'](_0xa76069)]);_0x1e77fc?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5b5afe&&_0x5b5afe['accessToken'],this['appCheckToken_']=_0xb32a1&&_0xb32a1['token'],_0x466184=new wh(_0x528b03,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x462004,_0x3fcb33,_0x33a63c,_0x5e2c8d=>{U(_0x5e2c8d+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x110856));}catch(_0x10586e){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x10586e),_0x1e77fc||(this['repoInfo_']['nodeAdmin']&&U(_0x10586e),_0x5befa3());}}}['interrupt'](_0x273643){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x273643),this['interruptReasons_'][_0x273643]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x265e48){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x265e48),delete this['interruptReasons_'][_0x265e48],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x26a353){const _0xa7f054=_0x26a353-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0xa7f054});}['cancelSentTransactions_'](){for(let _0x5fda7b=0x0;_0x5fda7b<this['outstandingPuts_']['length'];_0x5fda7b++){const _0x3caefe=this['outstandingPuts_'][_0x5fda7b];_0x3caefe&&'h'in _0x3caefe['request']&&_0x3caefe['queued']&&(_0x3caefe['onComplete']&&_0x3caefe['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x5fda7b],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2f5768,_0xb6564f){let _0x3ec5cd;_0xb6564f?_0x3ec5cd=_0xb6564f['map'](_0x2ff8ae=>Bi(_0x2ff8ae))['join']('$'):_0x3ec5cd='default';const _0x178fe9=this['removeListen_'](_0x2f5768,_0x3ec5cd);_0x178fe9&&_0x178fe9['onComplete']&&_0x178fe9['onComplete']('permission_denied');}['removeListen_'](_0x430c13,_0x1687b2){const _0x4ca421=new C(_0x430c13)['toString']();let _0x39d5d;if(this['listens']['has'](_0x4ca421)){const _0x5dd63e=this['listens']['get'](_0x4ca421);_0x39d5d=_0x5dd63e['get'](_0x1687b2),_0x5dd63e['delete'](_0x1687b2),_0x5dd63e['size']===0x0&&this['listens']['delete'](_0x4ca421);}else _0x39d5d=void 0x0;return _0x39d5d;}['onAuthRevoked_'](_0x25b861,_0x3ce880){L('Auth\x20token\x20revoked:\x20'+_0x25b861+'/'+_0x3ce880),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x25b861==='invalid_token'||_0x25b861==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x57d5a7,_0x274ed7){L('App\x20check\x20token\x20revoked:\x20'+_0x57d5a7+'/'+_0x274ed7),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x57d5a7==='invalid_token'||_0x57d5a7==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x22466e){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x22466e):'msg'in _0x22466e&&console['log']('FIREBASE:\x20'+_0x22466e['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x43ad28 of this['listens']['values']())for(const _0x3a654c of _0x43ad28['values']())this['sendListen_'](_0x3a654c);for(let _0x2fcb94=0x0;_0x2fcb94<this['outstandingPuts_']['length'];_0x2fcb94++)this['outstandingPuts_'][_0x2fcb94]&&this['sendPut_'](_0x2fcb94);for(;this['onDisconnectRequestQueue_']['length'];){const _0x548f7c=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x548f7c['action'],_0x548f7c['pathString'],_0x548f7c['data'],_0x548f7c['onComplete']);}for(let _0xbf16a0=0x0;_0xbf16a0<this['outstandingGets_']['length'];_0xbf16a0++)this['outstandingGets_'][_0xbf16a0]&&this['sendGet_'](_0xbf16a0);}['sendConnectStats_'](){const _0x27e43e={};let _0x53a2ad='js';_0x27e43e['sdk.'+_0x53a2ad+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x27e43e['framework.cordova']=0x1:qr()&&(_0x27e43e['framework.reactnative']=0x1),this['reportStats'](_0x27e43e);}['shouldReconnect_'](){const _0xc55fe0=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0xc55fe0;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x30b41f,_0x2e7ae0){this['name']=_0x30b41f,this['node']=_0x2e7ae0;}static['Wrap'](_0xc6e254,_0x48cb11){return new E(_0xc6e254,_0x48cb11);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x27d786,_0x12826f){const _0x5a48bc=new E(xe,_0x27d786),_0x5ae3da=new E(xe,_0x12826f);return this['compare'](_0x5a48bc,_0x5ae3da)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x44cb2d){Xt=_0x44cb2d;}['compare'](_0x4b7bea,_0x37e7f7){return He(_0x4b7bea['name'],_0x37e7f7['name']);}['isDefinedOn'](_0x3bd5fb){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3fcfbd,_0x193eb9){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0xbfd948,_0x2d3076){return f(typeof _0xbfd948=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xbfd948,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x41af1a,_0x377916,_0x1c9eaa,_0x1f8552,_0x278a56=null){this['isReverse_']=_0x1f8552,this['resultGenerator_']=_0x278a56,this['nodeStack_']=[];let _0x3ac4da=0x1;for(;!_0x41af1a['isEmpty']();)if(_0x41af1a=_0x41af1a,_0x3ac4da=_0x377916?_0x1c9eaa(_0x41af1a['key'],_0x377916):0x1,_0x1f8552&&(_0x3ac4da*=-0x1),_0x3ac4da<0x0)this['isReverse_']?_0x41af1a=_0x41af1a['left']:_0x41af1a=_0x41af1a['right'];else{if(_0x3ac4da===0x0){this['nodeStack_']['push'](_0x41af1a);break;}else this['nodeStack_']['push'](_0x41af1a),this['isReverse_']?_0x41af1a=_0x41af1a['right']:_0x41af1a=_0x41af1a['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4d8d37=this['nodeStack_']['pop'](),_0x78e636;if(this['resultGenerator_']?_0x78e636=this['resultGenerator_'](_0x4d8d37['key'],_0x4d8d37['value']):_0x78e636={'key':_0x4d8d37['key'],'value':_0x4d8d37['value']},this['isReverse_']){for(_0x4d8d37=_0x4d8d37['left'];!_0x4d8d37['isEmpty']();)this['nodeStack_']['push'](_0x4d8d37),_0x4d8d37=_0x4d8d37['right'];}else{for(_0x4d8d37=_0x4d8d37['right'];!_0x4d8d37['isEmpty']();)this['nodeStack_']['push'](_0x4d8d37),_0x4d8d37=_0x4d8d37['left'];}return _0x78e636;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5a383f=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5a383f['key'],_0x5a383f['value']):{'key':_0x5a383f['key'],'value':_0x5a383f['value']};}}class M{constructor(_0x5ef0d8,_0x4e3c8e,_0x50a616,_0xfede87,_0x5ebbb2){this['key']=_0x5ef0d8,this['value']=_0x4e3c8e,this['color']=_0x50a616??M['RED'],this['left']=_0xfede87??B['EMPTY_NODE'],this['right']=_0x5ebbb2??B['EMPTY_NODE'];}['copy'](_0x66c5ae,_0x2be370,_0x58b8fe,_0x35f304,_0x4879dc){return new M(_0x66c5ae??this['key'],_0x2be370??this['value'],_0x58b8fe??this['color'],_0x35f304??this['left'],_0x4879dc??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x2346a5){return this['left']['inorderTraversal'](_0x2346a5)||!!_0x2346a5(this['key'],this['value'])||this['right']['inorderTraversal'](_0x2346a5);}['reverseTraversal'](_0x40639d){return this['right']['reverseTraversal'](_0x40639d)||_0x40639d(this['key'],this['value'])||this['left']['reverseTraversal'](_0x40639d);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x63b6ac,_0x1238f8,_0x533e69){let _0x36a127=this;const _0x1e380e=_0x533e69(_0x63b6ac,_0x36a127['key']);return _0x1e380e<0x0?_0x36a127=_0x36a127['copy'](null,null,null,_0x36a127['left']['insert'](_0x63b6ac,_0x1238f8,_0x533e69),null):_0x1e380e===0x0?_0x36a127=_0x36a127['copy'](null,_0x1238f8,null,null,null):_0x36a127=_0x36a127['copy'](null,null,null,null,_0x36a127['right']['insert'](_0x63b6ac,_0x1238f8,_0x533e69)),_0x36a127['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x37877a=this;return!_0x37877a['left']['isRed_']()&&!_0x37877a['left']['left']['isRed_']()&&(_0x37877a=_0x37877a['moveRedLeft_']()),_0x37877a=_0x37877a['copy'](null,null,null,_0x37877a['left']['removeMin_'](),null),_0x37877a['fixUp_']();}['remove'](_0x149a37,_0x207c10){let _0x3cf886,_0x78d503;if(_0x3cf886=this,_0x207c10(_0x149a37,_0x3cf886['key'])<0x0)!_0x3cf886['left']['isEmpty']()&&!_0x3cf886['left']['isRed_']()&&!_0x3cf886['left']['left']['isRed_']()&&(_0x3cf886=_0x3cf886['moveRedLeft_']()),_0x3cf886=_0x3cf886['copy'](null,null,null,_0x3cf886['left']['remove'](_0x149a37,_0x207c10),null);else{if(_0x3cf886['left']['isRed_']()&&(_0x3cf886=_0x3cf886['rotateRight_']()),!_0x3cf886['right']['isEmpty']()&&!_0x3cf886['right']['isRed_']()&&!_0x3cf886['right']['left']['isRed_']()&&(_0x3cf886=_0x3cf886['moveRedRight_']()),_0x207c10(_0x149a37,_0x3cf886['key'])===0x0){if(_0x3cf886['right']['isEmpty']())return B['EMPTY_NODE'];_0x78d503=_0x3cf886['right']['min_'](),_0x3cf886=_0x3cf886['copy'](_0x78d503['key'],_0x78d503['value'],null,null,_0x3cf886['right']['removeMin_']());}_0x3cf886=_0x3cf886['copy'](null,null,null,null,_0x3cf886['right']['remove'](_0x149a37,_0x207c10));}return _0x3cf886['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x11f4a9=this;return _0x11f4a9['right']['isRed_']()&&!_0x11f4a9['left']['isRed_']()&&(_0x11f4a9=_0x11f4a9['rotateLeft_']()),_0x11f4a9['left']['isRed_']()&&_0x11f4a9['left']['left']['isRed_']()&&(_0x11f4a9=_0x11f4a9['rotateRight_']()),_0x11f4a9['left']['isRed_']()&&_0x11f4a9['right']['isRed_']()&&(_0x11f4a9=_0x11f4a9['colorFlip_']()),_0x11f4a9;}['moveRedLeft_'](){let _0x2311d8=this['colorFlip_']();return _0x2311d8['right']['left']['isRed_']()&&(_0x2311d8=_0x2311d8['copy'](null,null,null,null,_0x2311d8['right']['rotateRight_']()),_0x2311d8=_0x2311d8['rotateLeft_'](),_0x2311d8=_0x2311d8['colorFlip_']()),_0x2311d8;}['moveRedRight_'](){let _0x197491=this['colorFlip_']();return _0x197491['left']['left']['isRed_']()&&(_0x197491=_0x197491['rotateRight_'](),_0x197491=_0x197491['colorFlip_']()),_0x197491;}['rotateLeft_'](){const _0x44a821=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x44a821,null);}['rotateRight_'](){const _0x90b0be=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x90b0be);}['colorFlip_'](){const _0x47d988=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x221e0a=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x47d988,_0x221e0a);}['checkMaxDepth_'](){const _0x94f2cb=this['check_']();return Math['pow'](0x2,_0x94f2cb)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x39d080=this['left']['check_']();if(_0x39d080!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x39d080+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x420772,_0x51d9a5,_0x3c18a7,_0x140a30,_0xd4fb93){return this;}['insert'](_0x38cfae,_0xde3835,_0x5c0d41){return new M(_0x38cfae,_0xde3835,null);}['remove'](_0x5568d1,_0x3e7a5e){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x303828){return!0x1;}['reverseTraversal'](_0x1c65ed){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x5c4a26,_0x5c93c1=B['EMPTY_NODE']){this['comparator_']=_0x5c4a26,this['root_']=_0x5c93c1;}['insert'](_0x2a0479,_0x3f350c){return new B(this['comparator_'],this['root_']['insert'](_0x2a0479,_0x3f350c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3bfb8a){return new B(this['comparator_'],this['root_']['remove'](_0x3bfb8a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0xc837bf){let _0x524afd,_0x50fd72=this['root_'];for(;!_0x50fd72['isEmpty']();){if(_0x524afd=this['comparator_'](_0xc837bf,_0x50fd72['key']),_0x524afd===0x0)return _0x50fd72['value'];_0x524afd<0x0?_0x50fd72=_0x50fd72['left']:_0x524afd>0x0&&(_0x50fd72=_0x50fd72['right']);}return null;}['getPredecessorKey'](_0x12339a){let _0x533c49,_0x4e6ae5=this['root_'],_0x24cb1d=null;for(;!_0x4e6ae5['isEmpty']();)if(_0x533c49=this['comparator_'](_0x12339a,_0x4e6ae5['key']),_0x533c49===0x0){if(_0x4e6ae5['left']['isEmpty']())return _0x24cb1d?_0x24cb1d['key']:null;for(_0x4e6ae5=_0x4e6ae5['left'];!_0x4e6ae5['right']['isEmpty']();)_0x4e6ae5=_0x4e6ae5['right'];return _0x4e6ae5['key'];}else _0x533c49<0x0?_0x4e6ae5=_0x4e6ae5['left']:_0x533c49>0x0&&(_0x24cb1d=_0x4e6ae5,_0x4e6ae5=_0x4e6ae5['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x3bafd0){return this['root_']['inorderTraversal'](_0x3bafd0);}['reverseTraversal'](_0x4d45fd){return this['root_']['reverseTraversal'](_0x4d45fd);}['getIterator'](_0x4a5ae9){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x4a5ae9);}['getIteratorFrom'](_0x1a0ed6,_0x2b8e5a){return new Zt(this['root_'],_0x1a0ed6,this['comparator_'],!0x1,_0x2b8e5a);}['getReverseIteratorFrom'](_0x244dfe,_0x263994){return new Zt(this['root_'],_0x244dfe,this['comparator_'],!0x0,_0x263994);}['getReverseIterator'](_0x208b66){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x208b66);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x3f575e,_0x2c9a4a){return He(_0x3f575e['name'],_0x2c9a4a['name']);}function ji(_0x2d95d5,_0x54a63a){return He(_0x2d95d5,_0x54a63a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x33703f){vi=_0x33703f;}const Ro=function(_0x1260c7){return typeof _0x1260c7=='number'?'number:'+so(_0x1260c7):'string:'+_0x1260c7;},Ao=function(_0x5064a1){if(_0x5064a1['isLeafNode']()){const _0x1c0652=_0x5064a1['val']();f(typeof _0x1c0652=='string'||typeof _0x1c0652=='number'||typeof _0x1c0652=='object'&&Y(_0x1c0652,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5064a1===vi||_0x5064a1['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5064a1===vi||_0x5064a1['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x5b7c0e){er=_0x5b7c0e;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x39f136,_0x3a40d4=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x39f136,this['priorityNode_']=_0x3a40d4,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1307c1){return new D(this['value_'],_0x1307c1);}['getImmediateChild'](_0x49a39f){return _0x49a39f==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x53cf5f){return v(_0x53cf5f)?this:y(_0x53cf5f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1b4737,_0x578209){return null;}['updateImmediateChild'](_0xccf6d6,_0x54e011){return _0xccf6d6==='.priority'?this['updatePriority'](_0x54e011):_0x54e011['isEmpty']()&&_0xccf6d6!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0xccf6d6,_0x54e011)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3faa7a,_0x2f219b){const _0x55edeb=y(_0x3faa7a);return _0x55edeb===null?_0x2f219b:_0x2f219b['isEmpty']()&&_0x55edeb!=='.priority'?this:(f(_0x55edeb!=='.priority'||we(_0x3faa7a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x55edeb,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x3faa7a),_0x2f219b)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5eced3,_0x350b8f){return!0x1;}['val'](_0x24af00){return _0x24af00&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2682d9='';this['priorityNode_']['isEmpty']()||(_0x2682d9+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x22df04=typeof this['value_'];_0x2682d9+=_0x22df04+':',_0x22df04==='number'?_0x2682d9+=so(this['value_']):_0x2682d9+=this['value_'],this['lazyHash_']=no(_0x2682d9);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x49b06){return _0x49b06===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x49b06 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x49b06['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x49b06));}['compareToLeafNode_'](_0x24e915){const _0x5b19da=typeof _0x24e915['value_'],_0x4b30bf=typeof this['value_'],_0x4e6e1a=D['VALUE_TYPE_ORDER']['indexOf'](_0x5b19da),_0x136197=D['VALUE_TYPE_ORDER']['indexOf'](_0x4b30bf);return f(_0x4e6e1a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5b19da),f(_0x136197>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4b30bf),_0x4e6e1a===_0x136197?_0x4b30bf==='object'?0x0:this['value_']<_0x24e915['value_']?-0x1:this['value_']===_0x24e915['value_']?0x0:0x1:_0x136197-_0x4e6e1a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x48ebe5){if(_0x48ebe5===this)return!0x0;if(_0x48ebe5['isLeafNode']()){const _0x162c88=_0x48ebe5;return this['value_']===_0x162c88['value_']&&this['priorityNode_']['equals'](_0x162c88['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x575bfa){ko=_0x575bfa;}function xh(_0x506a5d){No=_0x506a5d;}class Fh extends On{['compare'](_0xd1aeca,_0x539f39){const _0x1b5786=_0xd1aeca['node']['getPriority'](),_0xfda7c2=_0x539f39['node']['getPriority'](),_0x1d7df4=_0x1b5786['compareTo'](_0xfda7c2);return _0x1d7df4===0x0?He(_0xd1aeca['name'],_0x539f39['name']):_0x1d7df4;}['isDefinedOn'](_0x2481fe){return!_0x2481fe['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x36a234,_0xeea7ff){return!_0x36a234['getPriority']()['equals'](_0xeea7ff['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0xa56fe0,_0x5f1cc4){const _0x1cb146=ko(_0xa56fe0);return new E(_0x5f1cc4,new D('[PRIORITY-POST]',_0x1cb146));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x4a068c){const _0x3e84b1=_0x67d73e=>parseInt(Math['log'](_0x67d73e)/Uh,0xa),_0x38004a=_0x4af621=>parseInt(Array(_0x4af621+0x1)['join']('1'),0x2);this['count']=_0x3e84b1(_0x4a068c+0x1),this['current_']=this['count']-0x1;const _0x544b54=_0x38004a(this['count']);this['bits_']=_0x4a068c+0x1&_0x544b54;}['nextBitIsOne'](){const _0x2bc08a=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2bc08a;}}const dn=function(_0xd783c,_0xaeb4ab,_0x266842,_0x555864){_0xd783c['sort'](_0xaeb4ab);const _0x44bbf2=function(_0x5b5f80,_0x10b1f7){const _0x224b97=_0x10b1f7-_0x5b5f80;let _0x5f2b7a,_0x2b08ed;if(_0x224b97===0x0)return null;if(_0x224b97===0x1)return _0x5f2b7a=_0xd783c[_0x5b5f80],_0x2b08ed=_0x266842?_0x266842(_0x5f2b7a):_0x5f2b7a,new M(_0x2b08ed,_0x5f2b7a['node'],M['BLACK'],null,null);{const _0x141a7a=parseInt(_0x224b97/0x2,0xa)+_0x5b5f80,_0x385043=_0x44bbf2(_0x5b5f80,_0x141a7a),_0x56c4f9=_0x44bbf2(_0x141a7a+0x1,_0x10b1f7);return _0x5f2b7a=_0xd783c[_0x141a7a],_0x2b08ed=_0x266842?_0x266842(_0x5f2b7a):_0x5f2b7a,new M(_0x2b08ed,_0x5f2b7a['node'],M['BLACK'],_0x385043,_0x56c4f9);}},_0x642d70=function(_0x2fdbc6){let _0x27e600=null,_0x57aa05=null,_0xd4bfb6=_0xd783c['length'];const _0x37c888=function(_0x1a748a,_0x3b15ac){const _0x2bc35f=_0xd4bfb6-_0x1a748a,_0xdaf1c6=_0xd4bfb6;_0xd4bfb6-=_0x1a748a;const _0x358db1=_0x44bbf2(_0x2bc35f+0x1,_0xdaf1c6),_0x27cf0b=_0xd783c[_0x2bc35f],_0x21b3ee=_0x266842?_0x266842(_0x27cf0b):_0x27cf0b;_0x161a6e(new M(_0x21b3ee,_0x27cf0b['node'],_0x3b15ac,null,_0x358db1));},_0x161a6e=function(_0x11af82){_0x27e600?(_0x27e600['left']=_0x11af82,_0x27e600=_0x11af82):(_0x57aa05=_0x11af82,_0x27e600=_0x11af82);};for(let _0x47309c=0x0;_0x47309c<_0x2fdbc6['count'];++_0x47309c){const _0x25f284=_0x2fdbc6['nextBitIsOne'](),_0x218560=Math['pow'](0x2,_0x2fdbc6['count']-(_0x47309c+0x1));_0x25f284?_0x37c888(_0x218560,M['BLACK']):(_0x37c888(_0x218560,M['BLACK']),_0x37c888(_0x218560,M['RED']));}return _0x57aa05;},_0x2832cc=new Wh(_0xd783c['length']),_0x213938=_0x642d70(_0x2832cc);return new B(_0x555864||_0xaeb4ab,_0x213938);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x4acedc,_0x3f50cd){this['indexes_']=_0x4acedc,this['indexSet_']=_0x3f50cd;}['get'](_0x41b2de){const _0x97badf=Oe(this['indexes_'],_0x41b2de);if(!_0x97badf)throw new Error('No\x20index\x20defined\x20for\x20'+_0x41b2de);return _0x97badf instanceof B?_0x97badf:null;}['hasIndex'](_0x557220){return Y(this['indexSet_'],_0x557220['toString']());}['addIndex'](_0x4378f8,_0x52ebb4){f(_0x4378f8!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x93b10c=[];let _0x2fa589=!0x1;const _0x446cba=_0x52ebb4['getIterator'](E['Wrap']);let _0x3ee46f=_0x446cba['getNext']();for(;_0x3ee46f;)_0x2fa589=_0x2fa589||_0x4378f8['isDefinedOn'](_0x3ee46f['node']),_0x93b10c['push'](_0x3ee46f),_0x3ee46f=_0x446cba['getNext']();let _0x23c59f;_0x2fa589?_0x23c59f=dn(_0x93b10c,_0x4378f8['getCompare']()):_0x23c59f=je;const _0x29abd7=_0x4378f8['toString'](),_0x5b3782={...this['indexSet_']};_0x5b3782[_0x29abd7]=_0x4378f8;const _0x4ecd16={...this['indexes_']};return _0x4ecd16[_0x29abd7]=_0x23c59f,new ee(_0x4ecd16,_0x5b3782);}['addToIndexes'](_0x54f286,_0x270259){const _0x30d652=ln(this['indexes_'],(_0x519fb8,_0x38c2a5)=>{const _0x20127a=Oe(this['indexSet_'],_0x38c2a5);if(f(_0x20127a,'Missing\x20index\x20implementation\x20for\x20'+_0x38c2a5),_0x519fb8===je){if(_0x20127a['isDefinedOn'](_0x54f286['node'])){const _0x3d4cca=[],_0x368b68=_0x270259['getIterator'](E['Wrap']);let _0x431580=_0x368b68['getNext']();for(;_0x431580;)_0x431580['name']!==_0x54f286['name']&&_0x3d4cca['push'](_0x431580),_0x431580=_0x368b68['getNext']();return _0x3d4cca['push'](_0x54f286),dn(_0x3d4cca,_0x20127a['getCompare']());}else return je;}else{const _0x4f871f=_0x270259['get'](_0x54f286['name']);let _0x326f0f=_0x519fb8;return _0x4f871f&&(_0x326f0f=_0x326f0f['remove'](new E(_0x54f286['name'],_0x4f871f))),_0x326f0f['insert'](_0x54f286,_0x54f286['node']);}});return new ee(_0x30d652,this['indexSet_']);}['removeFromIndexes'](_0x43ae2b,_0x30f281){const _0x34c6e0=ln(this['indexes_'],_0x1bc345=>{if(_0x1bc345===je)return _0x1bc345;{const _0xe5592=_0x30f281['get'](_0x43ae2b['name']);return _0xe5592?_0x1bc345['remove'](new E(_0x43ae2b['name'],_0xe5592)):_0x1bc345;}});return new ee(_0x34c6e0,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x30f634,_0x31c85b,_0x54052a){this['children_']=_0x30f634,this['priorityNode_']=_0x31c85b,this['indexMap_']=_0x54052a,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x368520){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x368520,this['indexMap_']);}['getImmediateChild'](_0x42ac5a){if(_0x42ac5a==='.priority')return this['getPriority']();{const _0x34d19d=this['children_']['get'](_0x42ac5a);return _0x34d19d===null?gt:_0x34d19d;}}['getChild'](_0xf3a26c){const _0x3f4824=y(_0xf3a26c);return _0x3f4824===null?this:this['getImmediateChild'](_0x3f4824)['getChild'](b(_0xf3a26c));}['hasChild'](_0x3e40a1){return this['children_']['get'](_0x3e40a1)!==null;}['updateImmediateChild'](_0x11b7ee,_0x1ef239){if(f(_0x1ef239,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x11b7ee==='.priority')return this['updatePriority'](_0x1ef239);{const _0x54e810=new E(_0x11b7ee,_0x1ef239);let _0x52ebe0,_0x42d241;_0x1ef239['isEmpty']()?(_0x52ebe0=this['children_']['remove'](_0x11b7ee),_0x42d241=this['indexMap_']['removeFromIndexes'](_0x54e810,this['children_'])):(_0x52ebe0=this['children_']['insert'](_0x11b7ee,_0x1ef239),_0x42d241=this['indexMap_']['addToIndexes'](_0x54e810,this['children_']));const _0x1f1127=_0x52ebe0['isEmpty']()?gt:this['priorityNode_'];return new g(_0x52ebe0,_0x1f1127,_0x42d241);}}['updateChild'](_0x2383b8,_0x3de3c1){const _0x745fd8=y(_0x2383b8);if(_0x745fd8===null)return _0x3de3c1;{f(y(_0x2383b8)!=='.priority'||we(_0x2383b8)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2bc9b7=this['getImmediateChild'](_0x745fd8)['updateChild'](b(_0x2383b8),_0x3de3c1);return this['updateImmediateChild'](_0x745fd8,_0x2bc9b7);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x34c7b9){if(this['isEmpty']())return null;const _0x32053d={};let _0x3836ec=0x0,_0x39fcd5=0x0,_0x1c45ca=!0x0;if(this['forEachChild'](R,(_0x3bc1f0,_0xbb65ba)=>{_0x32053d[_0x3bc1f0]=_0xbb65ba['val'](_0x34c7b9),_0x3836ec++,_0x1c45ca&&g['INTEGER_REGEXP_']['test'](_0x3bc1f0)?_0x39fcd5=Math['max'](_0x39fcd5,Number(_0x3bc1f0)):_0x1c45ca=!0x1;}),!_0x34c7b9&&_0x1c45ca&&_0x39fcd5<0x2*_0x3836ec){const _0x2e2547=[];for(const _0x5177f9 in _0x32053d)_0x2e2547[_0x5177f9]=_0x32053d[_0x5177f9];return _0x2e2547;}else return _0x34c7b9&&!this['getPriority']()['isEmpty']()&&(_0x32053d['.priority']=this['getPriority']()['val']()),_0x32053d;}['hash'](){if(this['lazyHash_']===null){let _0x43ae1f='';this['getPriority']()['isEmpty']()||(_0x43ae1f+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x5f024e,_0x225638)=>{const _0x43c768=_0x225638['hash']();_0x43c768!==''&&(_0x43ae1f+=':'+_0x5f024e+':'+_0x43c768);}),this['lazyHash_']=_0x43ae1f===''?'':no(_0x43ae1f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x598d6a,_0x22936c,_0x4fa093){const _0x355230=this['resolveIndex_'](_0x4fa093);if(_0x355230){const _0x14fd0e=_0x355230['getPredecessorKey'](new E(_0x598d6a,_0x22936c));return _0x14fd0e?_0x14fd0e['name']:null;}else return this['children_']['getPredecessorKey'](_0x598d6a);}['getFirstChildName'](_0x1a13e4){const _0x145cad=this['resolveIndex_'](_0x1a13e4);if(_0x145cad){const _0x41d01f=_0x145cad['minKey']();return _0x41d01f&&_0x41d01f['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x573c38){const _0x5c0ed9=this['getFirstChildName'](_0x573c38);return _0x5c0ed9?new E(_0x5c0ed9,this['children_']['get'](_0x5c0ed9)):null;}['getLastChildName'](_0x36e225){const _0x1bdf01=this['resolveIndex_'](_0x36e225);if(_0x1bdf01){const _0x2f9d1e=_0x1bdf01['maxKey']();return _0x2f9d1e&&_0x2f9d1e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x7028f5){const _0x49e036=this['getLastChildName'](_0x7028f5);return _0x49e036?new E(_0x49e036,this['children_']['get'](_0x49e036)):null;}['forEachChild'](_0x21004f,_0x18ac65){const _0xb440ad=this['resolveIndex_'](_0x21004f);return _0xb440ad?_0xb440ad['inorderTraversal'](_0x470400=>_0x18ac65(_0x470400['name'],_0x470400['node'])):this['children_']['inorderTraversal'](_0x18ac65);}['getIterator'](_0x492597){return this['getIteratorFrom'](_0x492597['minPost'](),_0x492597);}['getIteratorFrom'](_0x2eb3e5,_0xa37b2){const _0x3d4ebb=this['resolveIndex_'](_0xa37b2);if(_0x3d4ebb)return _0x3d4ebb['getIteratorFrom'](_0x2eb3e5,_0x31443d=>_0x31443d);{const _0x2e7945=this['children_']['getIteratorFrom'](_0x2eb3e5['name'],E['Wrap']);let _0x2c9cbe=_0x2e7945['peek']();for(;_0x2c9cbe!=null&&_0xa37b2['compare'](_0x2c9cbe,_0x2eb3e5)<0x0;)_0x2e7945['getNext'](),_0x2c9cbe=_0x2e7945['peek']();return _0x2e7945;}}['getReverseIterator'](_0x2121f2){return this['getReverseIteratorFrom'](_0x2121f2['maxPost'](),_0x2121f2);}['getReverseIteratorFrom'](_0x4cd870,_0xd919f4){const _0x4e8fbb=this['resolveIndex_'](_0xd919f4);if(_0x4e8fbb)return _0x4e8fbb['getReverseIteratorFrom'](_0x4cd870,_0x4c2bad=>_0x4c2bad);{const _0x2fd0f7=this['children_']['getReverseIteratorFrom'](_0x4cd870['name'],E['Wrap']);let _0x353653=_0x2fd0f7['peek']();for(;_0x353653!=null&&_0xd919f4['compare'](_0x353653,_0x4cd870)>0x0;)_0x2fd0f7['getNext'](),_0x353653=_0x2fd0f7['peek']();return _0x2fd0f7;}}['compareTo'](_0x2cb959){return this['isEmpty']()?_0x2cb959['isEmpty']()?0x0:-0x1:_0x2cb959['isLeafNode']()||_0x2cb959['isEmpty']()?0x1:_0x2cb959===Ht?-0x1:0x0;}['withIndex'](_0x337af1){if(_0x337af1===ye||this['indexMap_']['hasIndex'](_0x337af1))return this;{const _0x1e9a22=this['indexMap_']['addIndex'](_0x337af1,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1e9a22);}}['isIndexed'](_0x59e68e){return _0x59e68e===ye||this['indexMap_']['hasIndex'](_0x59e68e);}['equals'](_0x4a6733){if(_0x4a6733===this)return!0x0;if(_0x4a6733['isLeafNode']())return!0x1;{const _0x5a90b6=_0x4a6733;if(this['getPriority']()['equals'](_0x5a90b6['getPriority']())){if(this['children_']['count']()===_0x5a90b6['children_']['count']()){const _0x1df265=this['getIterator'](R),_0x1d1dc9=_0x5a90b6['getIterator'](R);let _0x238f56=_0x1df265['getNext'](),_0x321c25=_0x1d1dc9['getNext']();for(;_0x238f56&&_0x321c25;){if(_0x238f56['name']!==_0x321c25['name']||!_0x238f56['node']['equals'](_0x321c25['node']))return!0x1;_0x238f56=_0x1df265['getNext'](),_0x321c25=_0x1d1dc9['getNext']();}return _0x238f56===null&&_0x321c25===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x92c6ba){return _0x92c6ba===ye?null:this['indexMap_']['get'](_0x92c6ba['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x1262b5){return _0x1262b5===this?0x0:0x1;}['equals'](_0x3bb4a3){return _0x3bb4a3===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1d399d){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x46cc63,_0x2fbd7e=null){if(_0x46cc63===null)return g['EMPTY_NODE'];if(typeof _0x46cc63=='object'&&'.priority'in _0x46cc63&&(_0x2fbd7e=_0x46cc63['.priority']),f(_0x2fbd7e===null||typeof _0x2fbd7e=='string'||typeof _0x2fbd7e=='number'||typeof _0x2fbd7e=='object'&&'.sv'in _0x2fbd7e,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x2fbd7e),typeof _0x46cc63=='object'&&'.value'in _0x46cc63&&_0x46cc63['.value']!==null&&(_0x46cc63=_0x46cc63['.value']),typeof _0x46cc63!='object'||'.sv'in _0x46cc63){const _0x5782b9=_0x46cc63;return new D(_0x5782b9,N(_0x2fbd7e));}if(!(_0x46cc63 instanceof Array)&&Vh){const _0x5a704c=[];let _0x29ff6b=!0x1;if(x(_0x46cc63,(_0xa80c12,_0x13fe0a)=>{if(_0xa80c12['substring'](0x0,0x1)!=='.'){const _0x24e9af=N(_0x13fe0a);_0x24e9af['isEmpty']()||(_0x29ff6b=_0x29ff6b||!_0x24e9af['getPriority']()['isEmpty'](),_0x5a704c['push'](new E(_0xa80c12,_0x24e9af)));}}),_0x5a704c['length']===0x0)return g['EMPTY_NODE'];const _0x4891fc=dn(_0x5a704c,Dh,_0x1b83b2=>_0x1b83b2['name'],ji);if(_0x29ff6b){const _0x17c398=dn(_0x5a704c,R['getCompare']());return new g(_0x4891fc,N(_0x2fbd7e),new ee({'.priority':_0x17c398},{'.priority':R}));}else return new g(_0x4891fc,N(_0x2fbd7e),ee['Default']);}else{let _0x26ec59=g['EMPTY_NODE'];return x(_0x46cc63,(_0x40ee75,_0x866d3e)=>{if(Y(_0x46cc63,_0x40ee75)&&_0x40ee75['substring'](0x0,0x1)!=='.'){const _0xd46702=N(_0x866d3e);(_0xd46702['isLeafNode']()||!_0xd46702['isEmpty']())&&(_0x26ec59=_0x26ec59['updateImmediateChild'](_0x40ee75,_0xd46702));}}),_0x26ec59['updatePriority'](N(_0x2fbd7e));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x4aef63){super(),this['indexPath_']=_0x4aef63,f(!v(_0x4aef63)&&y(_0x4aef63)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x3eca6d){return _0x3eca6d['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2ecd55){return!_0x2ecd55['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x57822c,_0x3d57dd){const _0x20f7d8=this['extractChild'](_0x57822c['node']),_0x17d96f=this['extractChild'](_0x3d57dd['node']),_0x16ecaf=_0x20f7d8['compareTo'](_0x17d96f);return _0x16ecaf===0x0?He(_0x57822c['name'],_0x3d57dd['name']):_0x16ecaf;}['makePost'](_0x20ff38,_0x3deaa7){const _0x30dc48=N(_0x20ff38),_0x16a00d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x30dc48);return new E(_0x3deaa7,_0x16a00d);}['maxPost'](){const _0x2b2d83=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x2b2d83);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x3a4d4e,_0x236c64){const _0x2b6d39=_0x3a4d4e['node']['compareTo'](_0x236c64['node']);return _0x2b6d39===0x0?He(_0x3a4d4e['name'],_0x236c64['name']):_0x2b6d39;}['isDefinedOn'](_0x31c62e){return!0x0;}['indexedValueChanged'](_0x34cefe,_0x1a4bd8){return!_0x34cefe['equals'](_0x1a4bd8);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3e27a4,_0xbf7524){const _0x35a401=N(_0x3e27a4);return new E(_0xbf7524,_0x35a401);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x55848a){return{'type':'value','snapshotNode':_0x55848a};}function tt(_0x4e81f8,_0x178fce){return{'type':'child_added','snapshotNode':_0x178fce,'childName':_0x4e81f8};}function Nt(_0x4a76ed,_0x26a555){return{'type':'child_removed','snapshotNode':_0x26a555,'childName':_0x4a76ed};}function Pt(_0x178985,_0x5318d9,_0x312d1d){return{'type':'child_changed','snapshotNode':_0x5318d9,'childName':_0x178985,'oldSnap':_0x312d1d};}function $h(_0x5e8c50,_0x49bed0){return{'type':'child_moved','snapshotNode':_0x49bed0,'childName':_0x5e8c50};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0xbdf517){this['index_']=_0xbdf517;}['updateChild'](_0x5dd56d,_0x4a420c,_0x2e496f,_0x5e7be9,_0x1ed183,_0x396688){f(_0x5dd56d['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x279867=_0x5dd56d['getImmediateChild'](_0x4a420c);return _0x279867['getChild'](_0x5e7be9)['equals'](_0x2e496f['getChild'](_0x5e7be9))&&_0x279867['isEmpty']()===_0x2e496f['isEmpty']()||(_0x396688!=null&&(_0x2e496f['isEmpty']()?_0x5dd56d['hasChild'](_0x4a420c)?_0x396688['trackChildChange'](Nt(_0x4a420c,_0x279867)):f(_0x5dd56d['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x279867['isEmpty']()?_0x396688['trackChildChange'](tt(_0x4a420c,_0x2e496f)):_0x396688['trackChildChange'](Pt(_0x4a420c,_0x2e496f,_0x279867))),_0x5dd56d['isLeafNode']()&&_0x2e496f['isEmpty']())?_0x5dd56d:_0x5dd56d['updateImmediateChild'](_0x4a420c,_0x2e496f)['withIndex'](this['index_']);}['updateFullNode'](_0x21c407,_0x9e3a61,_0x563912){return _0x563912!=null&&(_0x21c407['isLeafNode']()||_0x21c407['forEachChild'](R,(_0x2a79e4,_0x34b6a8)=>{_0x9e3a61['hasChild'](_0x2a79e4)||_0x563912['trackChildChange'](Nt(_0x2a79e4,_0x34b6a8));}),_0x9e3a61['isLeafNode']()||_0x9e3a61['forEachChild'](R,(_0x1c8c24,_0x265dc0)=>{if(_0x21c407['hasChild'](_0x1c8c24)){const _0x357354=_0x21c407['getImmediateChild'](_0x1c8c24);_0x357354['equals'](_0x265dc0)||_0x563912['trackChildChange'](Pt(_0x1c8c24,_0x265dc0,_0x357354));}else _0x563912['trackChildChange'](tt(_0x1c8c24,_0x265dc0));})),_0x9e3a61['withIndex'](this['index_']);}['updatePriority'](_0x2a3402,_0x33a1f2){return _0x2a3402['isEmpty']()?g['EMPTY_NODE']:_0x2a3402['updatePriority'](_0x33a1f2);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x269810){this['indexedFilter_']=new Yi(_0x269810['getIndex']()),this['index_']=_0x269810['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x269810),this['endPost_']=Ot['getEndPost_'](_0x269810),this['startIsInclusive_']=!_0x269810['startAfterSet_'],this['endIsInclusive_']=!_0x269810['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x2cf200){const _0x3f8f7c=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x2cf200)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x2cf200)<0x0,_0x36fa0b=this['endIsInclusive_']?this['index_']['compare'](_0x2cf200,this['getEndPost']())<=0x0:this['index_']['compare'](_0x2cf200,this['getEndPost']())<0x0;return _0x3f8f7c&&_0x36fa0b;}['updateChild'](_0x88f016,_0x5dad79,_0x2c8e9a,_0xde157b,_0x152ffc,_0x5e23fc){return this['matches'](new E(_0x5dad79,_0x2c8e9a))||(_0x2c8e9a=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x88f016,_0x5dad79,_0x2c8e9a,_0xde157b,_0x152ffc,_0x5e23fc);}['updateFullNode'](_0x4429d2,_0x1d1e3d,_0x1e2670){_0x1d1e3d['isLeafNode']()&&(_0x1d1e3d=g['EMPTY_NODE']);let _0x4f750e=_0x1d1e3d['withIndex'](this['index_']);_0x4f750e=_0x4f750e['updatePriority'](g['EMPTY_NODE']);const _0x9565d1=this;return _0x1d1e3d['forEachChild'](R,(_0x55ae77,_0x22b7c6)=>{_0x9565d1['matches'](new E(_0x55ae77,_0x22b7c6))||(_0x4f750e=_0x4f750e['updateImmediateChild'](_0x55ae77,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x4429d2,_0x4f750e,_0x1e2670);}['updatePriority'](_0x5a1a89,_0x150fd5){return _0x5a1a89;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x415bcc){if(_0x415bcc['hasStart']()){const _0x529aae=_0x415bcc['getIndexStartName']();return _0x415bcc['getIndex']()['makePost'](_0x415bcc['getIndexStartValue'](),_0x529aae);}else return _0x415bcc['getIndex']()['minPost']();}static['getEndPost_'](_0x2b7a1a){if(_0x2b7a1a['hasEnd']()){const _0x167ec2=_0x2b7a1a['getIndexEndName']();return _0x2b7a1a['getIndex']()['makePost'](_0x2b7a1a['getIndexEndValue'](),_0x167ec2);}else return _0x2b7a1a['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x3c2983){this['withinDirectionalStart']=_0x47d385=>this['reverse_']?this['withinEndPost'](_0x47d385):this['withinStartPost'](_0x47d385),this['withinDirectionalEnd']=_0x1e75f4=>this['reverse_']?this['withinStartPost'](_0x1e75f4):this['withinEndPost'](_0x1e75f4),this['withinStartPost']=_0x5af941=>{const _0x40ab7e=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5af941);return this['startIsInclusive_']?_0x40ab7e<=0x0:_0x40ab7e<0x0;},this['withinEndPost']=_0x97092a=>{const _0xcdb7f4=this['index_']['compare'](_0x97092a,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xcdb7f4<=0x0:_0xcdb7f4<0x0;},this['rangedFilter_']=new Ot(_0x3c2983),this['index_']=_0x3c2983['getIndex'](),this['limit_']=_0x3c2983['getLimit'](),this['reverse_']=!_0x3c2983['isViewFromLeft'](),this['startIsInclusive_']=!_0x3c2983['startAfterSet_'],this['endIsInclusive_']=!_0x3c2983['endBeforeSet_'];}['updateChild'](_0x44407c,_0x30b58a,_0x518d71,_0x2eb1db,_0x4a5075,_0x1815af){return this['rangedFilter_']['matches'](new E(_0x30b58a,_0x518d71))||(_0x518d71=g['EMPTY_NODE']),_0x44407c['getImmediateChild'](_0x30b58a)['equals'](_0x518d71)?_0x44407c:_0x44407c['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x44407c,_0x30b58a,_0x518d71,_0x2eb1db,_0x4a5075,_0x1815af):this['fullLimitUpdateChild_'](_0x44407c,_0x30b58a,_0x518d71,_0x4a5075,_0x1815af);}['updateFullNode'](_0x570cc1,_0x1844f6,_0x5771eb){let _0x395640;if(_0x1844f6['isLeafNode']()||_0x1844f6['isEmpty']())_0x395640=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1844f6['numChildren']()&&_0x1844f6['isIndexed'](this['index_'])){_0x395640=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x99a6de;this['reverse_']?_0x99a6de=_0x1844f6['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x99a6de=_0x1844f6['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x20fa90=0x0;for(;_0x99a6de['hasNext']()&&_0x20fa90<this['limit_'];){const _0x1fe6fb=_0x99a6de['getNext']();if(this['withinDirectionalStart'](_0x1fe6fb)){if(this['withinDirectionalEnd'](_0x1fe6fb))_0x395640=_0x395640['updateImmediateChild'](_0x1fe6fb['name'],_0x1fe6fb['node']),_0x20fa90++;else break;}else continue;}}else{_0x395640=_0x1844f6['withIndex'](this['index_']),_0x395640=_0x395640['updatePriority'](g['EMPTY_NODE']);let _0x42a2a9;this['reverse_']?_0x42a2a9=_0x395640['getReverseIterator'](this['index_']):_0x42a2a9=_0x395640['getIterator'](this['index_']);let _0x29b9cf=0x0;for(;_0x42a2a9['hasNext']();){const _0x5c5490=_0x42a2a9['getNext']();_0x29b9cf<this['limit_']&&this['withinDirectionalStart'](_0x5c5490)&&this['withinDirectionalEnd'](_0x5c5490)?_0x29b9cf++:_0x395640=_0x395640['updateImmediateChild'](_0x5c5490['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x570cc1,_0x395640,_0x5771eb);}['updatePriority'](_0x4b84eb,_0x9d4b7c){return _0x4b84eb;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x275be7,_0x47125d,_0x5dfbff,_0x4bbf2e,_0x208c55){let _0x4559bc;if(this['reverse_']){const _0x3267d5=this['index_']['getCompare']();_0x4559bc=(_0xc3de32,_0x3e8d0e)=>_0x3267d5(_0x3e8d0e,_0xc3de32);}else _0x4559bc=this['index_']['getCompare']();const _0x18f550=_0x275be7;f(_0x18f550['numChildren']()===this['limit_'],'');const _0x418343=new E(_0x47125d,_0x5dfbff),_0x37a655=this['reverse_']?_0x18f550['getFirstChild'](this['index_']):_0x18f550['getLastChild'](this['index_']),_0x33adf6=this['rangedFilter_']['matches'](_0x418343);if(_0x18f550['hasChild'](_0x47125d)){const _0xf8cca2=_0x18f550['getImmediateChild'](_0x47125d);let _0x21d603=_0x4bbf2e['getChildAfterChild'](this['index_'],_0x37a655,this['reverse_']);for(;_0x21d603!=null&&(_0x21d603['name']===_0x47125d||_0x18f550['hasChild'](_0x21d603['name']));)_0x21d603=_0x4bbf2e['getChildAfterChild'](this['index_'],_0x21d603,this['reverse_']);const _0x2dcd9d=_0x21d603==null?0x1:_0x4559bc(_0x21d603,_0x418343);if(_0x33adf6&&!_0x5dfbff['isEmpty']()&&_0x2dcd9d>=0x0)return _0x208c55!=null&&_0x208c55['trackChildChange'](Pt(_0x47125d,_0x5dfbff,_0xf8cca2)),_0x18f550['updateImmediateChild'](_0x47125d,_0x5dfbff);{_0x208c55!=null&&_0x208c55['trackChildChange'](Nt(_0x47125d,_0xf8cca2));const _0x24b203=_0x18f550['updateImmediateChild'](_0x47125d,g['EMPTY_NODE']);return _0x21d603!=null&&this['rangedFilter_']['matches'](_0x21d603)?(_0x208c55!=null&&_0x208c55['trackChildChange'](tt(_0x21d603['name'],_0x21d603['node'])),_0x24b203['updateImmediateChild'](_0x21d603['name'],_0x21d603['node'])):_0x24b203;}}else return _0x5dfbff['isEmpty']()?_0x275be7:_0x33adf6&&_0x4559bc(_0x37a655,_0x418343)>=0x0?(_0x208c55!=null&&(_0x208c55['trackChildChange'](Nt(_0x37a655['name'],_0x37a655['node'])),_0x208c55['trackChildChange'](tt(_0x47125d,_0x5dfbff))),_0x18f550['updateImmediateChild'](_0x47125d,_0x5dfbff)['updateImmediateChild'](_0x37a655['name'],g['EMPTY_NODE'])):_0x275be7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4780a3=new Qi();return _0x4780a3['limitSet_']=this['limitSet_'],_0x4780a3['limit_']=this['limit_'],_0x4780a3['startSet_']=this['startSet_'],_0x4780a3['startAfterSet_']=this['startAfterSet_'],_0x4780a3['indexStartValue_']=this['indexStartValue_'],_0x4780a3['startNameSet_']=this['startNameSet_'],_0x4780a3['indexStartName_']=this['indexStartName_'],_0x4780a3['endSet_']=this['endSet_'],_0x4780a3['endBeforeSet_']=this['endBeforeSet_'],_0x4780a3['indexEndValue_']=this['indexEndValue_'],_0x4780a3['endNameSet_']=this['endNameSet_'],_0x4780a3['indexEndName_']=this['indexEndName_'],_0x4780a3['index_']=this['index_'],_0x4780a3['viewFrom_']=this['viewFrom_'],_0x4780a3;}}function qh(_0x2bf3ad){return _0x2bf3ad['loadsAllData']()?new Yi(_0x2bf3ad['getIndex']()):_0x2bf3ad['hasLimit']()?new Gh(_0x2bf3ad):new Ot(_0x2bf3ad);}function zh(_0x3e6225,_0x3d111f){const _0x4af829=_0x3e6225['copy']();return _0x4af829['limitSet_']=!0x0,_0x4af829['limit_']=_0x3d111f,_0x4af829['viewFrom_']='l',_0x4af829;}function jh(_0x4e898b,_0x5830f7,_0x25f50c){const _0x3b2ece=_0x4e898b['copy']();return _0x3b2ece['startSet_']=!0x0,_0x5830f7===void 0x0&&(_0x5830f7=null),_0x3b2ece['indexStartValue_']=_0x5830f7,_0x25f50c!=null?(_0x3b2ece['startNameSet_']=!0x0,_0x3b2ece['indexStartName_']=_0x25f50c):(_0x3b2ece['startNameSet_']=!0x1,_0x3b2ece['indexStartName_']=''),_0x3b2ece;}function Kh(_0x271185,_0x637145,_0x19315d){const _0x2c31be=_0x271185['copy']();return _0x2c31be['endSet_']=!0x0,_0x637145===void 0x0&&(_0x637145=null),_0x2c31be['indexEndValue_']=_0x637145,_0x19315d!==void 0x0?(_0x2c31be['endNameSet_']=!0x0,_0x2c31be['indexEndName_']=_0x19315d):(_0x2c31be['endNameSet_']=!0x1,_0x2c31be['indexEndName_']=''),_0x2c31be;}function Do(_0x29a939,_0x34b042){const _0x2072a9=_0x29a939['copy']();return _0x2072a9['index_']=_0x34b042,_0x2072a9;}function tr(_0x17c631){const _0x6a3cba={};if(_0x17c631['isDefault']())return _0x6a3cba;let _0x344a3f;if(_0x17c631['index_']===R?_0x344a3f='$priority':_0x17c631['index_']===Po?_0x344a3f='$value':_0x17c631['index_']===ye?_0x344a3f='$key':(f(_0x17c631['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x344a3f=_0x17c631['index_']['toString']()),_0x6a3cba['orderBy']=O(_0x344a3f),_0x17c631['startSet_']){const _0x4697a6=_0x17c631['startAfterSet_']?'startAfter':'startAt';_0x6a3cba[_0x4697a6]=O(_0x17c631['indexStartValue_']),_0x17c631['startNameSet_']&&(_0x6a3cba[_0x4697a6]+=','+O(_0x17c631['indexStartName_']));}if(_0x17c631['endSet_']){const _0x3e91e6=_0x17c631['endBeforeSet_']?'endBefore':'endAt';_0x6a3cba[_0x3e91e6]=O(_0x17c631['indexEndValue_']),_0x17c631['endNameSet_']&&(_0x6a3cba[_0x3e91e6]+=','+O(_0x17c631['indexEndName_']));}return _0x17c631['limitSet_']&&(_0x17c631['isViewFromLeft']()?_0x6a3cba['limitToFirst']=_0x17c631['limit_']:_0x6a3cba['limitToLast']=_0x17c631['limit_']),_0x6a3cba;}function nr(_0x2f5c9d){const _0x1316a8={};if(_0x2f5c9d['startSet_']&&(_0x1316a8['sp']=_0x2f5c9d['indexStartValue_'],_0x2f5c9d['startNameSet_']&&(_0x1316a8['sn']=_0x2f5c9d['indexStartName_']),_0x1316a8['sin']=!_0x2f5c9d['startAfterSet_']),_0x2f5c9d['endSet_']&&(_0x1316a8['ep']=_0x2f5c9d['indexEndValue_'],_0x2f5c9d['endNameSet_']&&(_0x1316a8['en']=_0x2f5c9d['indexEndName_']),_0x1316a8['ein']=!_0x2f5c9d['endBeforeSet_']),_0x2f5c9d['limitSet_']){_0x1316a8['l']=_0x2f5c9d['limit_'];let _0x36a8f0=_0x2f5c9d['viewFrom_'];_0x36a8f0===''&&(_0x2f5c9d['isViewFromLeft']()?_0x36a8f0='l':_0x36a8f0='r'),_0x1316a8['vf']=_0x36a8f0;}return _0x2f5c9d['index_']!==R&&(_0x1316a8['i']=_0x2f5c9d['index_']['toString']()),_0x1316a8;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x57891d){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3d892a,_0xd39a31){return _0xd39a31!==void 0x0?'tag$'+_0xd39a31:(f(_0x3d892a['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3d892a['_path']['toString']());}constructor(_0x2fc538,_0x3856c2,_0x3de1d4,_0x5d172f){super(),this['repoInfo_']=_0x2fc538,this['onDataUpdate_']=_0x3856c2,this['authTokenProvider_']=_0x3de1d4,this['appCheckTokenProvider_']=_0x5d172f,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x432252,_0x336111,_0x1e04b4,_0x4934ad){const _0x35d828=_0x432252['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x35d828+'\x20'+_0x432252['_queryIdentifier']);const _0xb11e81=fn['getListenId_'](_0x432252,_0x1e04b4),_0x4ccdc0={};this['listens_'][_0xb11e81]=_0x4ccdc0;const _0x286b6d=tr(_0x432252['_queryParams']);this['restRequest_'](_0x35d828+'.json',_0x286b6d,(_0x4ed414,_0x481e0f)=>{let _0x4e0f31=_0x481e0f;if(_0x4ed414===0x194&&(_0x4e0f31=null,_0x4ed414=null),_0x4ed414===null&&this['onDataUpdate_'](_0x35d828,_0x4e0f31,!0x1,_0x1e04b4),Oe(this['listens_'],_0xb11e81)===_0x4ccdc0){let _0x5dcc67;_0x4ed414?_0x4ed414===0x191?_0x5dcc67='permission_denied':_0x5dcc67='rest_error:'+_0x4ed414:_0x5dcc67='ok',_0x4934ad(_0x5dcc67,null);}});}['unlisten'](_0x51e0b8,_0x496036){const _0x943935=fn['getListenId_'](_0x51e0b8,_0x496036);delete this['listens_'][_0x943935];}['get'](_0x2eeca9){const _0x174020=tr(_0x2eeca9['_queryParams']),_0xf094c2=_0x2eeca9['_path']['toString'](),_0x3bef60=new Ve();return this['restRequest_'](_0xf094c2+'.json',_0x174020,(_0x102983,_0x3b1c5c)=>{let _0x22b460=_0x3b1c5c;_0x102983===0x194&&(_0x22b460=null,_0x102983=null),_0x102983===null?(this['onDataUpdate_'](_0xf094c2,_0x22b460,!0x1,null),_0x3bef60['resolve'](_0x22b460)):_0x3bef60['reject'](new Error(_0x22b460));}),_0x3bef60['promise'];}['refreshAuthToken'](_0x581c1b){}['restRequest_'](_0x18d7a9,_0x1563ee={},_0x234152){return _0x1563ee['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5f08ee,_0x3aaee5])=>{_0x5f08ee&&_0x5f08ee['accessToken']&&(_0x1563ee['auth']=_0x5f08ee['accessToken']),_0x3aaee5&&_0x3aaee5['token']&&(_0x1563ee['ac']=_0x3aaee5['token']);const _0xd01575=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x18d7a9+'?ns='+this['repoInfo_']['namespace']+at(_0x1563ee);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xd01575);const _0x4b35f3=new XMLHttpRequest();_0x4b35f3['onreadystatechange']=()=>{if(_0x234152&&_0x4b35f3['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xd01575+'\x20received.\x20status:',_0x4b35f3['status'],'response:',_0x4b35f3['responseText']);let _0x4d4a8e=null;if(_0x4b35f3['status']>=0xc8&&_0x4b35f3['status']<0x12c){try{_0x4d4a8e=bt(_0x4b35f3['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xd01575+':\x20'+_0x4b35f3['responseText']);}_0x234152(null,_0x4d4a8e);}else _0x4b35f3['status']!==0x191&&_0x4b35f3['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xd01575+'\x20Status:\x20'+_0x4b35f3['status']),_0x234152(_0x4b35f3['status']);_0x234152=null;}},_0x4b35f3['open']('GET',_0xd01575,!0x0),_0x4b35f3['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x465466){return this['rootNode_']['getChild'](_0x465466);}['updateSnapshot'](_0x2c8530,_0x76c24b){this['rootNode_']=this['rootNode_']['updateChild'](_0x2c8530,_0x76c24b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x74ce3a,_0x353360,_0x3ed02c){if(v(_0x353360))_0x74ce3a['value']=_0x3ed02c,_0x74ce3a['children']['clear']();else{if(_0x74ce3a['value']!==null)_0x74ce3a['value']=_0x74ce3a['value']['updateChild'](_0x353360,_0x3ed02c);else{const _0x2b5704=y(_0x353360);_0x74ce3a['children']['has'](_0x2b5704)||_0x74ce3a['children']['set'](_0x2b5704,pn());const _0x3bd821=_0x74ce3a['children']['get'](_0x2b5704);_0x353360=b(_0x353360),Mo(_0x3bd821,_0x353360,_0x3ed02c);}}}function Ei(_0x43960d,_0x2ab275,_0x5812bd){_0x43960d['value']!==null?_0x5812bd(_0x2ab275,_0x43960d['value']):Qh(_0x43960d,(_0x29f129,_0x47183d)=>{const _0x25b276=new C(_0x2ab275['toString']()+'/'+_0x29f129);Ei(_0x47183d,_0x25b276,_0x5812bd);});}function Qh(_0xfd16c0,_0x424bd3){_0xfd16c0['children']['forEach']((_0xfecfd5,_0x1f7e21)=>{_0x424bd3(_0x1f7e21,_0xfecfd5);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x42cb0e){this['collection_']=_0x42cb0e,this['last_']=null;}['get'](){const _0x4172f8=this['collection_']['get'](),_0x417abd={..._0x4172f8};return this['last_']&&x(this['last_'],(_0x3bb057,_0x671824)=>{_0x417abd[_0x3bb057]=_0x417abd[_0x3bb057]-_0x671824;}),this['last_']=_0x4172f8,_0x417abd;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x7d3ba,_0x35dba8){this['server_']=_0x35dba8,this['statsToReport_']={},this['statsListener_']=new Jh(_0x7d3ba);const _0x31c2cd=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x31c2cd));}['reportStats_'](){const _0x13ff0c=this['statsListener_']['get'](),_0x3a5427={};let _0x213ee2=!0x1;x(_0x13ff0c,(_0x518666,_0x130b1f)=>{_0x130b1f>0x0&&Y(this['statsToReport_'],_0x518666)&&(_0x3a5427[_0x518666]=_0x130b1f,_0x213ee2=!0x0);}),_0x213ee2&&this['server_']['reportStats'](_0x3a5427),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0xb35a4){_0xb35a4[_0xb35a4['OVERWRITE']=0x0]='OVERWRITE',_0xb35a4[_0xb35a4['MERGE']=0x1]='MERGE',_0xb35a4[_0xb35a4['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xb35a4[_0xb35a4['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x3a7d7d){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x3a7d7d,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x3a08a4,_0x2fcf68,_0x356103){this['path']=_0x3a08a4,this['affectedTree']=_0x2fcf68,this['revert']=_0x356103,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x3cbbc1){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x439830=this['affectedTree']['subtree'](new C(_0x3cbbc1));return new _n(w(),_0x439830,this['revert']);}}else return f(y(this['path'])===_0x3cbbc1,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x31508e,_0x4e8c96){this['source']=_0x31508e,this['path']=_0x4e8c96,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x3f2166){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x37f031,_0x258538,_0xfa69d7){this['source']=_0x37f031,this['path']=_0x258538,this['snap']=_0xfa69d7,this['type']=q['OVERWRITE'];}['operationForChild'](_0x18d0bd){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x18d0bd)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0xf89464,_0x287ee2,_0x5d828d){this['source']=_0xf89464,this['path']=_0x287ee2,this['children']=_0x5d828d,this['type']=q['MERGE'];}['operationForChild'](_0x2e7d8f){if(v(this['path'])){const _0x1075b5=this['children']['subtree'](new C(_0x2e7d8f));return _0x1075b5['isEmpty']()?null:_0x1075b5['value']?new Fe(this['source'],w(),_0x1075b5['value']):new nt(this['source'],w(),_0x1075b5);}else return f(y(this['path'])===_0x2e7d8f,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x46fe3b,_0xe7da24,_0x3e84a9){this['node_']=_0x46fe3b,this['fullyInitialized_']=_0xe7da24,this['filtered_']=_0x3e84a9;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x5c337e){if(v(_0x5c337e))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5efc73=y(_0x5c337e);return this['isCompleteForChild'](_0x5efc73);}['isCompleteForChild'](_0x1505a7){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1505a7);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x2a168c){this['query_']=_0x2a168c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x1c7c71,_0xc22b55,_0x39ba36,_0x42cf3d){const _0x1c4243=[],_0x3937e8=[];return _0xc22b55['forEach'](_0x36200a=>{_0x36200a['type']==='child_changed'&&_0x1c7c71['index_']['indexedValueChanged'](_0x36200a['oldSnap'],_0x36200a['snapshotNode'])&&_0x3937e8['push']($h(_0x36200a['childName'],_0x36200a['snapshotNode']));}),mt(_0x1c7c71,_0x1c4243,'child_removed',_0xc22b55,_0x42cf3d,_0x39ba36),mt(_0x1c7c71,_0x1c4243,'child_added',_0xc22b55,_0x42cf3d,_0x39ba36),mt(_0x1c7c71,_0x1c4243,'child_moved',_0x3937e8,_0x42cf3d,_0x39ba36),mt(_0x1c7c71,_0x1c4243,'child_changed',_0xc22b55,_0x42cf3d,_0x39ba36),mt(_0x1c7c71,_0x1c4243,'value',_0xc22b55,_0x42cf3d,_0x39ba36),_0x1c4243;}function mt(_0x3e6ed3,_0xaac78b,_0x3d5486,_0x36f5e4,_0x443c12,_0x1c8ca1){const _0x28ba6b=_0x36f5e4['filter'](_0x225005=>_0x225005['type']===_0x3d5486);_0x28ba6b['sort']((_0x3fb1d6,_0x482548)=>su(_0x3e6ed3,_0x3fb1d6,_0x482548)),_0x28ba6b['forEach'](_0x50c049=>{const _0x2d3351=iu(_0x3e6ed3,_0x50c049,_0x1c8ca1);_0x443c12['forEach'](_0x2f5e1c=>{_0x2f5e1c['respondsTo'](_0x50c049['type'])&&_0xaac78b['push'](_0x2f5e1c['createEvent'](_0x2d3351,_0x3e6ed3['query_']));});});}function iu(_0x53b41c,_0x29d806,_0x4cdd69){return _0x29d806['type']==='value'||_0x29d806['type']==='child_removed'||(_0x29d806['prevName']=_0x4cdd69['getPredecessorChildName'](_0x29d806['childName'],_0x29d806['snapshotNode'],_0x53b41c['index_'])),_0x29d806;}function su(_0x5ea436,_0x3a82f6,_0x2fb045){if(_0x3a82f6['childName']==null||_0x2fb045['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x5ae9a7=new E(_0x3a82f6['childName'],_0x3a82f6['snapshotNode']),_0x143c5a=new E(_0x2fb045['childName'],_0x2fb045['snapshotNode']);return _0x5ea436['index_']['compare'](_0x5ae9a7,_0x143c5a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x4926c6,_0x2bd0e3){return{'eventCache':_0x4926c6,'serverCache':_0x2bd0e3};}function wt(_0x5d6a9e,_0xbe3735,_0x58d580,_0x27a6f9){return Dn(new Ce(_0xbe3735,_0x58d580,_0x27a6f9),_0x5d6a9e['serverCache']);}function Lo(_0x465dc3,_0x4891a7,_0x523ee9,_0x13cc4e){return Dn(_0x465dc3['eventCache'],new Ce(_0x4891a7,_0x523ee9,_0x13cc4e));}function gn(_0x3965e7){return _0x3965e7['eventCache']['isFullyInitialized']()?_0x3965e7['eventCache']['getNode']():null;}function Ue(_0x5ab1d2){return _0x5ab1d2['serverCache']['isFullyInitialized']()?_0x5ab1d2['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x6a312d){let _0x2c62cc=new S(null);return x(_0x6a312d,(_0x33ce3f,_0x32fef1)=>{_0x2c62cc=_0x2c62cc['set'](new C(_0x33ce3f),_0x32fef1);}),_0x2c62cc;}constructor(_0x3e8124,_0x25312b=ru()){this['value']=_0x3e8124,this['children']=_0x25312b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x18c82b,_0xf676a6){if(this['value']!=null&&_0xf676a6(this['value']))return{'path':w(),'value':this['value']};if(v(_0x18c82b))return null;{const _0x3a432a=y(_0x18c82b),_0x1c741a=this['children']['get'](_0x3a432a);if(_0x1c741a!==null){const _0x853eee=_0x1c741a['findRootMostMatchingPathAndValue'](b(_0x18c82b),_0xf676a6);return _0x853eee!=null?{'path':A(new C(_0x3a432a),_0x853eee['path']),'value':_0x853eee['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x503066){return this['findRootMostMatchingPathAndValue'](_0x503066,()=>!0x0);}['subtree'](_0x13e7db){if(v(_0x13e7db))return this;{const _0x13c793=y(_0x13e7db),_0x4daca0=this['children']['get'](_0x13c793);return _0x4daca0!==null?_0x4daca0['subtree'](b(_0x13e7db)):new S(null);}}['set'](_0x523154,_0x48a9c4){if(v(_0x523154))return new S(_0x48a9c4,this['children']);{const _0x444228=y(_0x523154),_0x2cff8b=(this['children']['get'](_0x444228)||new S(null))['set'](b(_0x523154),_0x48a9c4),_0x52a8a4=this['children']['insert'](_0x444228,_0x2cff8b);return new S(this['value'],_0x52a8a4);}}['remove'](_0x5a1063){if(v(_0x5a1063))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x147e4f=y(_0x5a1063),_0x1f8369=this['children']['get'](_0x147e4f);if(_0x1f8369){const _0x213b24=_0x1f8369['remove'](b(_0x5a1063));let _0x251662;return _0x213b24['isEmpty']()?_0x251662=this['children']['remove'](_0x147e4f):_0x251662=this['children']['insert'](_0x147e4f,_0x213b24),this['value']===null&&_0x251662['isEmpty']()?new S(null):new S(this['value'],_0x251662);}else return this;}}['get'](_0x2326ce){if(v(_0x2326ce))return this['value'];{const _0x543744=y(_0x2326ce),_0x53ce82=this['children']['get'](_0x543744);return _0x53ce82?_0x53ce82['get'](b(_0x2326ce)):null;}}['setTree'](_0x433de0,_0x400786){if(v(_0x433de0))return _0x400786;{const _0xe580cc=y(_0x433de0),_0x2c867e=(this['children']['get'](_0xe580cc)||new S(null))['setTree'](b(_0x433de0),_0x400786);let _0x4e9a33;return _0x2c867e['isEmpty']()?_0x4e9a33=this['children']['remove'](_0xe580cc):_0x4e9a33=this['children']['insert'](_0xe580cc,_0x2c867e),new S(this['value'],_0x4e9a33);}}['fold'](_0x2f4413){return this['fold_'](w(),_0x2f4413);}['fold_'](_0x431998,_0x4e196f){const _0x460eb1={};return this['children']['inorderTraversal']((_0x11655f,_0x3d0c56)=>{_0x460eb1[_0x11655f]=_0x3d0c56['fold_'](A(_0x431998,_0x11655f),_0x4e196f);}),_0x4e196f(_0x431998,this['value'],_0x460eb1);}['findOnPath'](_0xc7f4ab,_0x9bf679){return this['findOnPath_'](_0xc7f4ab,w(),_0x9bf679);}['findOnPath_'](_0x4b8221,_0x503187,_0x31b741){const _0x4f040a=this['value']?_0x31b741(_0x503187,this['value']):!0x1;if(_0x4f040a)return _0x4f040a;if(v(_0x4b8221))return null;{const _0x4bc0bf=y(_0x4b8221),_0x5f0352=this['children']['get'](_0x4bc0bf);return _0x5f0352?_0x5f0352['findOnPath_'](b(_0x4b8221),A(_0x503187,_0x4bc0bf),_0x31b741):null;}}['foreachOnPath'](_0x452ea9,_0x203906){return this['foreachOnPath_'](_0x452ea9,w(),_0x203906);}['foreachOnPath_'](_0x25b628,_0x55e21d,_0x55bee3){if(v(_0x25b628))return this;{this['value']&&_0x55bee3(_0x55e21d,this['value']);const _0x4a22e1=y(_0x25b628),_0x43df2c=this['children']['get'](_0x4a22e1);return _0x43df2c?_0x43df2c['foreachOnPath_'](b(_0x25b628),A(_0x55e21d,_0x4a22e1),_0x55bee3):new S(null);}}['foreach'](_0x4fa36d){this['foreach_'](w(),_0x4fa36d);}['foreach_'](_0x1ec94d,_0x3a7cb2){this['children']['inorderTraversal']((_0x48c56e,_0x3eb3ef)=>{_0x3eb3ef['foreach_'](A(_0x1ec94d,_0x48c56e),_0x3a7cb2);}),this['value']&&_0x3a7cb2(_0x1ec94d,this['value']);}['foreachChild'](_0xa5348a){this['children']['inorderTraversal']((_0x54172a,_0x4a632d)=>{_0x4a632d['value']&&_0xa5348a(_0x54172a,_0x4a632d['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x5db518){this['writeTree_']=_0x5db518;}static['empty'](){return new j(new S(null));}}function Ct(_0x5d4e69,_0x84388e,_0x3380b6){if(v(_0x84388e))return new j(new S(_0x3380b6));{const _0x356cef=_0x5d4e69['writeTree_']['findRootMostValueAndPath'](_0x84388e);if(_0x356cef!=null){const _0x3df740=_0x356cef['path'];let _0x50503d=_0x356cef['value'];const _0x30c847=F(_0x3df740,_0x84388e);return _0x50503d=_0x50503d['updateChild'](_0x30c847,_0x3380b6),new j(_0x5d4e69['writeTree_']['set'](_0x3df740,_0x50503d));}else{const _0x15de1c=new S(_0x3380b6),_0x296ed1=_0x5d4e69['writeTree_']['setTree'](_0x84388e,_0x15de1c);return new j(_0x296ed1);}}}function Ii(_0x3bc067,_0x40300e,_0x3544be){let _0x3b6ef2=_0x3bc067;return x(_0x3544be,(_0x2f50c1,_0x31e8af)=>{_0x3b6ef2=Ct(_0x3b6ef2,A(_0x40300e,_0x2f50c1),_0x31e8af);}),_0x3b6ef2;}function sr(_0x4c099a,_0x4eada8){if(v(_0x4eada8))return j['empty']();{const _0x455627=_0x4c099a['writeTree_']['setTree'](_0x4eada8,new S(null));return new j(_0x455627);}}function wi(_0x49812d,_0x509c25){return $e(_0x49812d,_0x509c25)!=null;}function $e(_0x2efb80,_0x40f8ae){const _0x2f64ed=_0x2efb80['writeTree_']['findRootMostValueAndPath'](_0x40f8ae);return _0x2f64ed!=null?_0x2efb80['writeTree_']['get'](_0x2f64ed['path'])['getChild'](F(_0x2f64ed['path'],_0x40f8ae)):null;}function rr(_0x15842a){const _0x2b51ec=[],_0x43e358=_0x15842a['writeTree_']['value'];return _0x43e358!=null?_0x43e358['isLeafNode']()||_0x43e358['forEachChild'](R,(_0x2dd77d,_0x40e928)=>{_0x2b51ec['push'](new E(_0x2dd77d,_0x40e928));}):_0x15842a['writeTree_']['children']['inorderTraversal']((_0x3ee55f,_0x78d94a)=>{_0x78d94a['value']!=null&&_0x2b51ec['push'](new E(_0x3ee55f,_0x78d94a['value']));}),_0x2b51ec;}function ve(_0x3233f2,_0x14f00c){if(v(_0x14f00c))return _0x3233f2;{const _0x9f67e1=$e(_0x3233f2,_0x14f00c);return _0x9f67e1!=null?new j(new S(_0x9f67e1)):new j(_0x3233f2['writeTree_']['subtree'](_0x14f00c));}}function Ci(_0x27c886){return _0x27c886['writeTree_']['isEmpty']();}function it(_0x543b6e,_0x452335){return xo(w(),_0x543b6e['writeTree_'],_0x452335);}function xo(_0x197b81,_0x10581a,_0x2cef97){if(_0x10581a['value']!=null)return _0x2cef97['updateChild'](_0x197b81,_0x10581a['value']);{let _0x2a5556=null;return _0x10581a['children']['inorderTraversal']((_0x178734,_0x1ecbdb)=>{_0x178734==='.priority'?(f(_0x1ecbdb['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2a5556=_0x1ecbdb['value']):_0x2cef97=xo(A(_0x197b81,_0x178734),_0x1ecbdb,_0x2cef97);}),!_0x2cef97['getChild'](_0x197b81)['isEmpty']()&&_0x2a5556!==null&&(_0x2cef97=_0x2cef97['updateChild'](A(_0x197b81,'.priority'),_0x2a5556)),_0x2cef97;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x5299a6,_0x29253e){return Bo(_0x29253e,_0x5299a6);}function ou(_0x2908f1,_0x35422a,_0x23c95f,_0x16f22a,_0x1294f5){f(_0x16f22a>_0x2908f1['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1294f5===void 0x0&&(_0x1294f5=!0x0),_0x2908f1['allWrites']['push']({'path':_0x35422a,'snap':_0x23c95f,'writeId':_0x16f22a,'visible':_0x1294f5}),_0x1294f5&&(_0x2908f1['visibleWrites']=Ct(_0x2908f1['visibleWrites'],_0x35422a,_0x23c95f)),_0x2908f1['lastWriteId']=_0x16f22a;}function au(_0x5dc130,_0x49b7b2,_0x594e5f,_0x123939){f(_0x123939>_0x5dc130['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5dc130['allWrites']['push']({'path':_0x49b7b2,'children':_0x594e5f,'writeId':_0x123939,'visible':!0x0}),_0x5dc130['visibleWrites']=Ii(_0x5dc130['visibleWrites'],_0x49b7b2,_0x594e5f),_0x5dc130['lastWriteId']=_0x123939;}function cu(_0x29583e,_0x6cc70c){for(let _0x2fd9de=0x0;_0x2fd9de<_0x29583e['allWrites']['length'];_0x2fd9de++){const _0x2b6e7a=_0x29583e['allWrites'][_0x2fd9de];if(_0x2b6e7a['writeId']===_0x6cc70c)return _0x2b6e7a;}return null;}function lu(_0x5d0972,_0x293e8f){const _0x538493=_0x5d0972['allWrites']['findIndex'](_0xb84bf2=>_0xb84bf2['writeId']===_0x293e8f);f(_0x538493>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1ed932=_0x5d0972['allWrites'][_0x538493];_0x5d0972['allWrites']['splice'](_0x538493,0x1);let _0x825200=_0x1ed932['visible'],_0xb3e03b=!0x1,_0x4b824e=_0x5d0972['allWrites']['length']-0x1;for(;_0x825200&&_0x4b824e>=0x0;){const _0xfcdad9=_0x5d0972['allWrites'][_0x4b824e];_0xfcdad9['visible']&&(_0x4b824e>=_0x538493&&hu(_0xfcdad9,_0x1ed932['path'])?_0x825200=!0x1:$(_0x1ed932['path'],_0xfcdad9['path'])&&(_0xb3e03b=!0x0)),_0x4b824e--;}if(_0x825200){if(_0xb3e03b)return uu(_0x5d0972),!0x0;if(_0x1ed932['snap'])_0x5d0972['visibleWrites']=sr(_0x5d0972['visibleWrites'],_0x1ed932['path']);else{const _0x1bb601=_0x1ed932['children'];x(_0x1bb601,_0x40d573=>{_0x5d0972['visibleWrites']=sr(_0x5d0972['visibleWrites'],A(_0x1ed932['path'],_0x40d573));});}return!0x0;}else return!0x1;}function hu(_0x248cf5,_0x2c4d55){if(_0x248cf5['snap'])return $(_0x248cf5['path'],_0x2c4d55);for(const _0x59b621 in _0x248cf5['children'])if(_0x248cf5['children']['hasOwnProperty'](_0x59b621)&&$(A(_0x248cf5['path'],_0x59b621),_0x2c4d55))return!0x0;return!0x1;}function uu(_0x273013){_0x273013['visibleWrites']=Fo(_0x273013['allWrites'],du,w()),_0x273013['allWrites']['length']>0x0?_0x273013['lastWriteId']=_0x273013['allWrites'][_0x273013['allWrites']['length']-0x1]['writeId']:_0x273013['lastWriteId']=-0x1;}function du(_0x48296c){return _0x48296c['visible'];}function Fo(_0x568ca3,_0x55ec90,_0x2f459){let _0x30b0b1=j['empty']();for(let _0x3ccae4=0x0;_0x3ccae4<_0x568ca3['length'];++_0x3ccae4){const _0x4b37f7=_0x568ca3[_0x3ccae4];if(_0x55ec90(_0x4b37f7)){const _0x516236=_0x4b37f7['path'];let _0x3668ff;if(_0x4b37f7['snap'])$(_0x2f459,_0x516236)?(_0x3668ff=F(_0x2f459,_0x516236),_0x30b0b1=Ct(_0x30b0b1,_0x3668ff,_0x4b37f7['snap'])):$(_0x516236,_0x2f459)&&(_0x3668ff=F(_0x516236,_0x2f459),_0x30b0b1=Ct(_0x30b0b1,w(),_0x4b37f7['snap']['getChild'](_0x3668ff)));else{if(_0x4b37f7['children']){if($(_0x2f459,_0x516236))_0x3668ff=F(_0x2f459,_0x516236),_0x30b0b1=Ii(_0x30b0b1,_0x3668ff,_0x4b37f7['children']);else{if($(_0x516236,_0x2f459)){if(_0x3668ff=F(_0x516236,_0x2f459),v(_0x3668ff))_0x30b0b1=Ii(_0x30b0b1,w(),_0x4b37f7['children']);else{const _0x41b7ff=Oe(_0x4b37f7['children'],y(_0x3668ff));if(_0x41b7ff){const _0xb10394=_0x41b7ff['getChild'](b(_0x3668ff));_0x30b0b1=Ct(_0x30b0b1,w(),_0xb10394);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x30b0b1;}function Uo(_0x4da44c,_0x11404c,_0x46d47a,_0x3df467,_0x1a31e2){if(!_0x3df467&&!_0x1a31e2){const _0x464da5=$e(_0x4da44c['visibleWrites'],_0x11404c);if(_0x464da5!=null)return _0x464da5;{const _0x35f4d3=ve(_0x4da44c['visibleWrites'],_0x11404c);if(Ci(_0x35f4d3))return _0x46d47a;if(_0x46d47a==null&&!wi(_0x35f4d3,w()))return null;{const _0x4129db=_0x46d47a||g['EMPTY_NODE'];return it(_0x35f4d3,_0x4129db);}}}else{const _0x400817=ve(_0x4da44c['visibleWrites'],_0x11404c);if(!_0x1a31e2&&Ci(_0x400817))return _0x46d47a;if(!_0x1a31e2&&_0x46d47a==null&&!wi(_0x400817,w()))return null;{const _0x587626=function(_0x27b59b){return(_0x27b59b['visible']||_0x1a31e2)&&(!_0x3df467||!~_0x3df467['indexOf'](_0x27b59b['writeId']))&&($(_0x27b59b['path'],_0x11404c)||$(_0x11404c,_0x27b59b['path']));},_0x573e65=Fo(_0x4da44c['allWrites'],_0x587626,_0x11404c),_0x49be79=_0x46d47a||g['EMPTY_NODE'];return it(_0x573e65,_0x49be79);}}}function fu(_0x41f187,_0x292b4a,_0x4da5d1){let _0x3b95d6=g['EMPTY_NODE'];const _0x33bf1a=$e(_0x41f187['visibleWrites'],_0x292b4a);if(_0x33bf1a)return _0x33bf1a['isLeafNode']()||_0x33bf1a['forEachChild'](R,(_0x2d979e,_0x1648fc)=>{_0x3b95d6=_0x3b95d6['updateImmediateChild'](_0x2d979e,_0x1648fc);}),_0x3b95d6;if(_0x4da5d1){const _0x5ea9c9=ve(_0x41f187['visibleWrites'],_0x292b4a);return _0x4da5d1['forEachChild'](R,(_0xd8966d,_0x54515e)=>{const _0x40155e=it(ve(_0x5ea9c9,new C(_0xd8966d)),_0x54515e);_0x3b95d6=_0x3b95d6['updateImmediateChild'](_0xd8966d,_0x40155e);}),rr(_0x5ea9c9)['forEach'](_0x5bbeb6=>{_0x3b95d6=_0x3b95d6['updateImmediateChild'](_0x5bbeb6['name'],_0x5bbeb6['node']);}),_0x3b95d6;}else{const _0x2e0e79=ve(_0x41f187['visibleWrites'],_0x292b4a);return rr(_0x2e0e79)['forEach'](_0x76aee9=>{_0x3b95d6=_0x3b95d6['updateImmediateChild'](_0x76aee9['name'],_0x76aee9['node']);}),_0x3b95d6;}}function pu(_0x33755b,_0x3cf1c8,_0x234f8d,_0x51ffa7,_0xc1749d){f(_0x51ffa7||_0xc1749d,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3d4731=A(_0x3cf1c8,_0x234f8d);if(wi(_0x33755b['visibleWrites'],_0x3d4731))return null;{const _0x4b1a52=ve(_0x33755b['visibleWrites'],_0x3d4731);return Ci(_0x4b1a52)?_0xc1749d['getChild'](_0x234f8d):it(_0x4b1a52,_0xc1749d['getChild'](_0x234f8d));}}function _u(_0x112c97,_0xd332a5,_0x132a9b,_0x19135c){const _0x5db6e4=A(_0xd332a5,_0x132a9b),_0x2e9e52=$e(_0x112c97['visibleWrites'],_0x5db6e4);if(_0x2e9e52!=null)return _0x2e9e52;if(_0x19135c['isCompleteForChild'](_0x132a9b)){const _0x596b4a=ve(_0x112c97['visibleWrites'],_0x5db6e4);return it(_0x596b4a,_0x19135c['getNode']()['getImmediateChild'](_0x132a9b));}else return null;}function gu(_0x313191,_0x21fac0){return $e(_0x313191['visibleWrites'],_0x21fac0);}function mu(_0x1851d2,_0x14a0b2,_0x33f11c,_0x2e3daf,_0x2b6478,_0x4a6bfe,_0x4b2efd){let _0x5a9a71;const _0x5ca9c3=ve(_0x1851d2['visibleWrites'],_0x14a0b2),_0x1d8ae5=$e(_0x5ca9c3,w());if(_0x1d8ae5!=null)_0x5a9a71=_0x1d8ae5;else{if(_0x33f11c!=null)_0x5a9a71=it(_0x5ca9c3,_0x33f11c);else return[];}if(_0x5a9a71=_0x5a9a71['withIndex'](_0x4b2efd),!_0x5a9a71['isEmpty']()&&!_0x5a9a71['isLeafNode']()){const _0xb61a65=[],_0x1f902b=_0x4b2efd['getCompare'](),_0x254e99=_0x4a6bfe?_0x5a9a71['getReverseIteratorFrom'](_0x2e3daf,_0x4b2efd):_0x5a9a71['getIteratorFrom'](_0x2e3daf,_0x4b2efd);let _0x534813=_0x254e99['getNext']();for(;_0x534813&&_0xb61a65['length']<_0x2b6478;)_0x1f902b(_0x534813,_0x2e3daf)!==0x0&&_0xb61a65['push'](_0x534813),_0x534813=_0x254e99['getNext']();return _0xb61a65;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x3e8327,_0x299ff1,_0x24c88b,_0x1393d4){return Uo(_0x3e8327['writeTree'],_0x3e8327['treePath'],_0x299ff1,_0x24c88b,_0x1393d4);}function es(_0x15c285,_0x1613c9){return fu(_0x15c285['writeTree'],_0x15c285['treePath'],_0x1613c9);}function or(_0x4b9ce6,_0xff734,_0x1f7989,_0x382ee5){return pu(_0x4b9ce6['writeTree'],_0x4b9ce6['treePath'],_0xff734,_0x1f7989,_0x382ee5);}function yn(_0x91fe31,_0x5159d2){return gu(_0x91fe31['writeTree'],A(_0x91fe31['treePath'],_0x5159d2));}function vu(_0x39e4db,_0xacfc60,_0x38f27e,_0x24af2b,_0xe39938,_0x356a63){return mu(_0x39e4db['writeTree'],_0x39e4db['treePath'],_0xacfc60,_0x38f27e,_0x24af2b,_0xe39938,_0x356a63);}function ts(_0xdf33bc,_0x553401,_0x156fee){return _u(_0xdf33bc['writeTree'],_0xdf33bc['treePath'],_0x553401,_0x156fee);}function Wo(_0x1800a4,_0x425e29){return Bo(A(_0x1800a4['treePath'],_0x425e29),_0x1800a4['writeTree']);}function Bo(_0x3c68bc,_0x5143ed){return{'treePath':_0x3c68bc,'writeTree':_0x5143ed};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3566cf){const _0x3f9ca9=_0x3566cf['type'],_0x54d4d7=_0x3566cf['childName'];f(_0x3f9ca9==='child_added'||_0x3f9ca9==='child_changed'||_0x3f9ca9==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x54d4d7!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x5f32cf=this['changeMap']['get'](_0x54d4d7);if(_0x5f32cf){const _0x4eb151=_0x5f32cf['type'];if(_0x3f9ca9==='child_added'&&_0x4eb151==='child_removed')this['changeMap']['set'](_0x54d4d7,Pt(_0x54d4d7,_0x3566cf['snapshotNode'],_0x5f32cf['snapshotNode']));else{if(_0x3f9ca9==='child_removed'&&_0x4eb151==='child_added')this['changeMap']['delete'](_0x54d4d7);else{if(_0x3f9ca9==='child_removed'&&_0x4eb151==='child_changed')this['changeMap']['set'](_0x54d4d7,Nt(_0x54d4d7,_0x5f32cf['oldSnap']));else{if(_0x3f9ca9==='child_changed'&&_0x4eb151==='child_added')this['changeMap']['set'](_0x54d4d7,tt(_0x54d4d7,_0x3566cf['snapshotNode']));else{if(_0x3f9ca9==='child_changed'&&_0x4eb151==='child_changed')this['changeMap']['set'](_0x54d4d7,Pt(_0x54d4d7,_0x3566cf['snapshotNode'],_0x5f32cf['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x3566cf+'\x20occurred\x20after\x20'+_0x5f32cf);}}}}}else this['changeMap']['set'](_0x54d4d7,_0x3566cf);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x30aa02){return null;}['getChildAfterChild'](_0x39fb6a,_0xd23823,_0x325f81){return null;}}const Vo=new Iu();class ns{constructor(_0x3cbd13,_0x3b29a5,_0x44220c=null){this['writes_']=_0x3cbd13,this['viewCache_']=_0x3b29a5,this['optCompleteServerCache_']=_0x44220c;}['getCompleteChild'](_0x3414a2){const _0x4360fd=this['viewCache_']['eventCache'];if(_0x4360fd['isCompleteForChild'](_0x3414a2))return _0x4360fd['getNode']()['getImmediateChild'](_0x3414a2);{const _0x4d37e6=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x3414a2,_0x4d37e6);}}['getChildAfterChild'](_0x48e1e6,_0x3a30d5,_0x5b2680){const _0x2e9d99=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x2fa500=vu(this['writes_'],_0x2e9d99,_0x3a30d5,0x1,_0x5b2680,_0x48e1e6);return _0x2fa500['length']===0x0?null:_0x2fa500[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x1b220d){return{'filter':_0x1b220d};}function Cu(_0x1fe5c9,_0x401ace){f(_0x401ace['eventCache']['getNode']()['isIndexed'](_0x1fe5c9['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x401ace['serverCache']['getNode']()['isIndexed'](_0x1fe5c9['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x762a48,_0x84a3df,_0x58ab40,_0x14c6a6,_0x40ef46){const _0x3c66ee=new Eu();let _0x2c193d,_0xb9655a;if(_0x58ab40['type']===q['OVERWRITE']){const _0x253588=_0x58ab40;_0x253588['source']['fromUser']?_0x2c193d=Ti(_0x762a48,_0x84a3df,_0x253588['path'],_0x253588['snap'],_0x14c6a6,_0x40ef46,_0x3c66ee):(f(_0x253588['source']['fromServer'],'Unknown\x20source.'),_0xb9655a=_0x253588['source']['tagged']||_0x84a3df['serverCache']['isFiltered']()&&!v(_0x253588['path']),_0x2c193d=vn(_0x762a48,_0x84a3df,_0x253588['path'],_0x253588['snap'],_0x14c6a6,_0x40ef46,_0xb9655a,_0x3c66ee));}else{if(_0x58ab40['type']===q['MERGE']){const _0x3a54f2=_0x58ab40;_0x3a54f2['source']['fromUser']?_0x2c193d=bu(_0x762a48,_0x84a3df,_0x3a54f2['path'],_0x3a54f2['children'],_0x14c6a6,_0x40ef46,_0x3c66ee):(f(_0x3a54f2['source']['fromServer'],'Unknown\x20source.'),_0xb9655a=_0x3a54f2['source']['tagged']||_0x84a3df['serverCache']['isFiltered'](),_0x2c193d=Si(_0x762a48,_0x84a3df,_0x3a54f2['path'],_0x3a54f2['children'],_0x14c6a6,_0x40ef46,_0xb9655a,_0x3c66ee));}else{if(_0x58ab40['type']===q['ACK_USER_WRITE']){const _0x25c395=_0x58ab40;_0x25c395['revert']?_0x2c193d=ku(_0x762a48,_0x84a3df,_0x25c395['path'],_0x14c6a6,_0x40ef46,_0x3c66ee):_0x2c193d=Ru(_0x762a48,_0x84a3df,_0x25c395['path'],_0x25c395['affectedTree'],_0x14c6a6,_0x40ef46,_0x3c66ee);}else{if(_0x58ab40['type']===q['LISTEN_COMPLETE'])_0x2c193d=Au(_0x762a48,_0x84a3df,_0x58ab40['path'],_0x14c6a6,_0x3c66ee);else throw ot('Unknown\x20operation\x20type:\x20'+_0x58ab40['type']);}}}const _0x1ea7c6=_0x3c66ee['getChanges']();return Su(_0x84a3df,_0x2c193d,_0x1ea7c6),{'viewCache':_0x2c193d,'changes':_0x1ea7c6};}function Su(_0x289a20,_0x3424d9,_0x1a418e){const _0x1a8934=_0x3424d9['eventCache'];if(_0x1a8934['isFullyInitialized']()){const _0x2277bf=_0x1a8934['getNode']()['isLeafNode']()||_0x1a8934['getNode']()['isEmpty'](),_0x3357cf=gn(_0x289a20);(_0x1a418e['length']>0x0||!_0x289a20['eventCache']['isFullyInitialized']()||_0x2277bf&&!_0x1a8934['getNode']()['equals'](_0x3357cf)||!_0x1a8934['getNode']()['getPriority']()['equals'](_0x3357cf['getPriority']()))&&_0x1a418e['push'](Oo(gn(_0x3424d9)));}}function Ho(_0x46bf2f,_0x30b7d7,_0x75db7f,_0x652886,_0x5a2422,_0x2be90b){const _0x203f35=_0x30b7d7['eventCache'];if(yn(_0x652886,_0x75db7f)!=null)return _0x30b7d7;{let _0x130145,_0x41b704;if(v(_0x75db7f)){if(f(_0x30b7d7['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x30b7d7['serverCache']['isFiltered']()){const _0x1fe321=Ue(_0x30b7d7),_0x5be6a5=_0x1fe321 instanceof g?_0x1fe321:g['EMPTY_NODE'],_0x59bde2=es(_0x652886,_0x5be6a5);_0x130145=_0x46bf2f['filter']['updateFullNode'](_0x30b7d7['eventCache']['getNode'](),_0x59bde2,_0x2be90b);}else{const _0x18d56d=mn(_0x652886,Ue(_0x30b7d7));_0x130145=_0x46bf2f['filter']['updateFullNode'](_0x30b7d7['eventCache']['getNode'](),_0x18d56d,_0x2be90b);}}else{const _0x2e3dac=y(_0x75db7f);if(_0x2e3dac==='.priority'){f(we(_0x75db7f)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x47f390=_0x203f35['getNode']();_0x41b704=_0x30b7d7['serverCache']['getNode']();const _0x44f677=or(_0x652886,_0x75db7f,_0x47f390,_0x41b704);_0x44f677!=null?_0x130145=_0x46bf2f['filter']['updatePriority'](_0x47f390,_0x44f677):_0x130145=_0x203f35['getNode']();}else{const _0x379bf4=b(_0x75db7f);let _0x3cc609;if(_0x203f35['isCompleteForChild'](_0x2e3dac)){_0x41b704=_0x30b7d7['serverCache']['getNode']();const _0x24bbbd=or(_0x652886,_0x75db7f,_0x203f35['getNode'](),_0x41b704);_0x24bbbd!=null?_0x3cc609=_0x203f35['getNode']()['getImmediateChild'](_0x2e3dac)['updateChild'](_0x379bf4,_0x24bbbd):_0x3cc609=_0x203f35['getNode']()['getImmediateChild'](_0x2e3dac);}else _0x3cc609=ts(_0x652886,_0x2e3dac,_0x30b7d7['serverCache']);_0x3cc609!=null?_0x130145=_0x46bf2f['filter']['updateChild'](_0x203f35['getNode'](),_0x2e3dac,_0x3cc609,_0x379bf4,_0x5a2422,_0x2be90b):_0x130145=_0x203f35['getNode']();}}return wt(_0x30b7d7,_0x130145,_0x203f35['isFullyInitialized']()||v(_0x75db7f),_0x46bf2f['filter']['filtersNodes']());}}function vn(_0xa1a677,_0xf132fa,_0x14080f,_0x4944a3,_0x121b86,_0x1c5722,_0x4323e8,_0x348af7){const _0x5a435d=_0xf132fa['serverCache'];let _0x5a06fb;const _0x15bb39=_0x4323e8?_0xa1a677['filter']:_0xa1a677['filter']['getIndexedFilter']();if(v(_0x14080f))_0x5a06fb=_0x15bb39['updateFullNode'](_0x5a435d['getNode'](),_0x4944a3,null);else{if(_0x15bb39['filtersNodes']()&&!_0x5a435d['isFiltered']()){const _0xa6b60d=_0x5a435d['getNode']()['updateChild'](_0x14080f,_0x4944a3);_0x5a06fb=_0x15bb39['updateFullNode'](_0x5a435d['getNode'](),_0xa6b60d,null);}else{const _0x144fe6=y(_0x14080f);if(!_0x5a435d['isCompleteForPath'](_0x14080f)&&we(_0x14080f)>0x1)return _0xf132fa;const _0x4a6b16=b(_0x14080f),_0x21bdff=_0x5a435d['getNode']()['getImmediateChild'](_0x144fe6)['updateChild'](_0x4a6b16,_0x4944a3);_0x144fe6==='.priority'?_0x5a06fb=_0x15bb39['updatePriority'](_0x5a435d['getNode'](),_0x21bdff):_0x5a06fb=_0x15bb39['updateChild'](_0x5a435d['getNode'](),_0x144fe6,_0x21bdff,_0x4a6b16,Vo,null);}}const _0x4a25cd=Lo(_0xf132fa,_0x5a06fb,_0x5a435d['isFullyInitialized']()||v(_0x14080f),_0x15bb39['filtersNodes']()),_0xd7b175=new ns(_0x121b86,_0x4a25cd,_0x1c5722);return Ho(_0xa1a677,_0x4a25cd,_0x14080f,_0x121b86,_0xd7b175,_0x348af7);}function Ti(_0x8a9628,_0x41bafa,_0x2990f6,_0x455a89,_0x4fa1b5,_0x2281f3,_0x320456){const _0x37a959=_0x41bafa['eventCache'];let _0x3cf83a,_0x42ac05;const _0x1a316b=new ns(_0x4fa1b5,_0x41bafa,_0x2281f3);if(v(_0x2990f6))_0x42ac05=_0x8a9628['filter']['updateFullNode'](_0x41bafa['eventCache']['getNode'](),_0x455a89,_0x320456),_0x3cf83a=wt(_0x41bafa,_0x42ac05,!0x0,_0x8a9628['filter']['filtersNodes']());else{const _0x293161=y(_0x2990f6);if(_0x293161==='.priority')_0x42ac05=_0x8a9628['filter']['updatePriority'](_0x41bafa['eventCache']['getNode'](),_0x455a89),_0x3cf83a=wt(_0x41bafa,_0x42ac05,_0x37a959['isFullyInitialized'](),_0x37a959['isFiltered']());else{const _0x3de95b=b(_0x2990f6),_0x2bc135=_0x37a959['getNode']()['getImmediateChild'](_0x293161);let _0x25df45;if(v(_0x3de95b))_0x25df45=_0x455a89;else{const _0x4fa939=_0x1a316b['getCompleteChild'](_0x293161);_0x4fa939!=null?Gi(_0x3de95b)==='.priority'&&_0x4fa939['getChild'](To(_0x3de95b))['isEmpty']()?_0x25df45=_0x4fa939:_0x25df45=_0x4fa939['updateChild'](_0x3de95b,_0x455a89):_0x25df45=g['EMPTY_NODE'];}if(_0x2bc135['equals'](_0x25df45))_0x3cf83a=_0x41bafa;else{const _0x7833aa=_0x8a9628['filter']['updateChild'](_0x37a959['getNode'](),_0x293161,_0x25df45,_0x3de95b,_0x1a316b,_0x320456);_0x3cf83a=wt(_0x41bafa,_0x7833aa,_0x37a959['isFullyInitialized'](),_0x8a9628['filter']['filtersNodes']());}}}return _0x3cf83a;}function ar(_0x155a0e,_0x3bf058){return _0x155a0e['eventCache']['isCompleteForChild'](_0x3bf058);}function bu(_0x329af0,_0x51aa66,_0x5f46f5,_0xd39056,_0x1cafd0,_0x4888c8,_0x4cf1f9){let _0x46aeef=_0x51aa66;return _0xd39056['foreach']((_0x196839,_0x118fa2)=>{const _0x5e3003=A(_0x5f46f5,_0x196839);ar(_0x51aa66,y(_0x5e3003))&&(_0x46aeef=Ti(_0x329af0,_0x46aeef,_0x5e3003,_0x118fa2,_0x1cafd0,_0x4888c8,_0x4cf1f9));}),_0xd39056['foreach']((_0x3c1eba,_0x33cd04)=>{const _0x1979aa=A(_0x5f46f5,_0x3c1eba);ar(_0x51aa66,y(_0x1979aa))||(_0x46aeef=Ti(_0x329af0,_0x46aeef,_0x1979aa,_0x33cd04,_0x1cafd0,_0x4888c8,_0x4cf1f9));}),_0x46aeef;}function cr(_0x229d27,_0x3071a6,_0x2b86f1){return _0x2b86f1['foreach']((_0x2fe183,_0x27b8c3)=>{_0x3071a6=_0x3071a6['updateChild'](_0x2fe183,_0x27b8c3);}),_0x3071a6;}function Si(_0x33e94d,_0x5aa016,_0x6ffc95,_0x1bc7d3,_0x1b66c3,_0x592457,_0x77816,_0x5c706e){if(_0x5aa016['serverCache']['getNode']()['isEmpty']()&&!_0x5aa016['serverCache']['isFullyInitialized']())return _0x5aa016;let _0x364575=_0x5aa016,_0x30b011;v(_0x6ffc95)?_0x30b011=_0x1bc7d3:_0x30b011=new S(null)['setTree'](_0x6ffc95,_0x1bc7d3);const _0x392c5e=_0x5aa016['serverCache']['getNode']();return _0x30b011['children']['inorderTraversal']((_0x3661b2,_0xb1403d)=>{if(_0x392c5e['hasChild'](_0x3661b2)){const _0x47432d=_0x5aa016['serverCache']['getNode']()['getImmediateChild'](_0x3661b2),_0x537779=cr(_0x33e94d,_0x47432d,_0xb1403d);_0x364575=vn(_0x33e94d,_0x364575,new C(_0x3661b2),_0x537779,_0x1b66c3,_0x592457,_0x77816,_0x5c706e);}}),_0x30b011['children']['inorderTraversal']((_0x513261,_0x192e79)=>{const _0x5ad85e=!_0x5aa016['serverCache']['isCompleteForChild'](_0x513261)&&_0x192e79['value']===null;if(!_0x392c5e['hasChild'](_0x513261)&&!_0x5ad85e){const _0x1c9072=_0x5aa016['serverCache']['getNode']()['getImmediateChild'](_0x513261),_0x3e3c61=cr(_0x33e94d,_0x1c9072,_0x192e79);_0x364575=vn(_0x33e94d,_0x364575,new C(_0x513261),_0x3e3c61,_0x1b66c3,_0x592457,_0x77816,_0x5c706e);}}),_0x364575;}function Ru(_0x32dd69,_0x42894a,_0x4edb4f,_0x56fbb3,_0x303f80,_0x144864,_0x1741fc){if(yn(_0x303f80,_0x4edb4f)!=null)return _0x42894a;const _0x336dea=_0x42894a['serverCache']['isFiltered'](),_0x4a3021=_0x42894a['serverCache'];if(_0x56fbb3['value']!=null){if(v(_0x4edb4f)&&_0x4a3021['isFullyInitialized']()||_0x4a3021['isCompleteForPath'](_0x4edb4f))return vn(_0x32dd69,_0x42894a,_0x4edb4f,_0x4a3021['getNode']()['getChild'](_0x4edb4f),_0x303f80,_0x144864,_0x336dea,_0x1741fc);if(v(_0x4edb4f)){let _0x5940aa=new S(null);return _0x4a3021['getNode']()['forEachChild'](ye,(_0x67f3c7,_0x293ba1)=>{_0x5940aa=_0x5940aa['set'](new C(_0x67f3c7),_0x293ba1);}),Si(_0x32dd69,_0x42894a,_0x4edb4f,_0x5940aa,_0x303f80,_0x144864,_0x336dea,_0x1741fc);}else return _0x42894a;}else{let _0x4f3ecb=new S(null);return _0x56fbb3['foreach']((_0xb6bf6b,_0x1e581d)=>{const _0x418cc3=A(_0x4edb4f,_0xb6bf6b);_0x4a3021['isCompleteForPath'](_0x418cc3)&&(_0x4f3ecb=_0x4f3ecb['set'](_0xb6bf6b,_0x4a3021['getNode']()['getChild'](_0x418cc3)));}),Si(_0x32dd69,_0x42894a,_0x4edb4f,_0x4f3ecb,_0x303f80,_0x144864,_0x336dea,_0x1741fc);}}function Au(_0x479057,_0x4ac57e,_0x33385c,_0x17b5c0,_0x234ba7){const _0x279f7c=_0x4ac57e['serverCache'],_0x5d21f6=Lo(_0x4ac57e,_0x279f7c['getNode'](),_0x279f7c['isFullyInitialized']()||v(_0x33385c),_0x279f7c['isFiltered']());return Ho(_0x479057,_0x5d21f6,_0x33385c,_0x17b5c0,Vo,_0x234ba7);}function ku(_0x4b4dc9,_0x365be6,_0x4caa01,_0x491361,_0x31fca2,_0x37ed40){let _0x194e34;if(yn(_0x491361,_0x4caa01)!=null)return _0x365be6;{const _0x55891f=new ns(_0x491361,_0x365be6,_0x31fca2),_0x50a865=_0x365be6['eventCache']['getNode']();let _0x2d8e0e;if(v(_0x4caa01)||y(_0x4caa01)==='.priority'){let _0x309636;if(_0x365be6['serverCache']['isFullyInitialized']())_0x309636=mn(_0x491361,Ue(_0x365be6));else{const _0x4f32d0=_0x365be6['serverCache']['getNode']();f(_0x4f32d0 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x309636=es(_0x491361,_0x4f32d0);}_0x309636=_0x309636,_0x2d8e0e=_0x4b4dc9['filter']['updateFullNode'](_0x50a865,_0x309636,_0x37ed40);}else{const _0x54970b=y(_0x4caa01);let _0x1f019a=ts(_0x491361,_0x54970b,_0x365be6['serverCache']);_0x1f019a==null&&_0x365be6['serverCache']['isCompleteForChild'](_0x54970b)&&(_0x1f019a=_0x50a865['getImmediateChild'](_0x54970b)),_0x1f019a!=null?_0x2d8e0e=_0x4b4dc9['filter']['updateChild'](_0x50a865,_0x54970b,_0x1f019a,b(_0x4caa01),_0x55891f,_0x37ed40):_0x365be6['eventCache']['getNode']()['hasChild'](_0x54970b)?_0x2d8e0e=_0x4b4dc9['filter']['updateChild'](_0x50a865,_0x54970b,g['EMPTY_NODE'],b(_0x4caa01),_0x55891f,_0x37ed40):_0x2d8e0e=_0x50a865,_0x2d8e0e['isEmpty']()&&_0x365be6['serverCache']['isFullyInitialized']()&&(_0x194e34=mn(_0x491361,Ue(_0x365be6)),_0x194e34['isLeafNode']()&&(_0x2d8e0e=_0x4b4dc9['filter']['updateFullNode'](_0x2d8e0e,_0x194e34,_0x37ed40)));}return _0x194e34=_0x365be6['serverCache']['isFullyInitialized']()||yn(_0x491361,w())!=null,wt(_0x365be6,_0x2d8e0e,_0x194e34,_0x4b4dc9['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x1d20e9,_0x419c97){this['query_']=_0x1d20e9,this['eventRegistrations_']=[];const _0x1cdad3=this['query_']['_queryParams'],_0x37e818=new Yi(_0x1cdad3['getIndex']()),_0x143afc=qh(_0x1cdad3);this['processor_']=wu(_0x143afc);const _0x25839a=_0x419c97['serverCache'],_0x2cfed1=_0x419c97['eventCache'],_0x20f8df=_0x37e818['updateFullNode'](g['EMPTY_NODE'],_0x25839a['getNode'](),null),_0x5ef128=_0x143afc['updateFullNode'](g['EMPTY_NODE'],_0x2cfed1['getNode'](),null),_0x7f5b44=new Ce(_0x20f8df,_0x25839a['isFullyInitialized'](),_0x37e818['filtersNodes']()),_0x577608=new Ce(_0x5ef128,_0x2cfed1['isFullyInitialized'](),_0x143afc['filtersNodes']());this['viewCache_']=Dn(_0x577608,_0x7f5b44),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x5b9851){return _0x5b9851['viewCache_']['serverCache']['getNode']();}function Ou(_0x2e83b4){return gn(_0x2e83b4['viewCache_']);}function Du(_0x2bf768,_0x5b26bf){const _0xe64674=Ue(_0x2bf768['viewCache_']);return _0xe64674&&(_0x2bf768['query']['_queryParams']['loadsAllData']()||!v(_0x5b26bf)&&!_0xe64674['getImmediateChild'](y(_0x5b26bf))['isEmpty']())?_0xe64674['getChild'](_0x5b26bf):null;}function lr(_0x510fec){return _0x510fec['eventRegistrations_']['length']===0x0;}function Mu(_0x3ffd79,_0x59aee3){_0x3ffd79['eventRegistrations_']['push'](_0x59aee3);}function hr(_0x56f73e,_0x3f183b,_0x46b177){const _0x315344=[];if(_0x46b177){f(_0x3f183b==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x5428f2=_0x56f73e['query']['_path'];_0x56f73e['eventRegistrations_']['forEach'](_0x3c545b=>{const _0x12f580=_0x3c545b['createCancelEvent'](_0x46b177,_0x5428f2);_0x12f580&&_0x315344['push'](_0x12f580);});}if(_0x3f183b){let _0x1e4093=[];for(let _0x1458ab=0x0;_0x1458ab<_0x56f73e['eventRegistrations_']['length'];++_0x1458ab){const _0x22d1d0=_0x56f73e['eventRegistrations_'][_0x1458ab];if(!_0x22d1d0['matches'](_0x3f183b))_0x1e4093['push'](_0x22d1d0);else{if(_0x3f183b['hasAnyCallback']()){_0x1e4093=_0x1e4093['concat'](_0x56f73e['eventRegistrations_']['slice'](_0x1458ab+0x1));break;}}}_0x56f73e['eventRegistrations_']=_0x1e4093;}else _0x56f73e['eventRegistrations_']=[];return _0x315344;}function ur(_0x31be50,_0x37ef69,_0x44e61f,_0x14a85c){_0x37ef69['type']===q['MERGE']&&_0x37ef69['source']['queryId']!==null&&(f(Ue(_0x31be50['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x31be50['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x91f9a9=_0x31be50['viewCache_'],_0x398ecf=Tu(_0x31be50['processor_'],_0x91f9a9,_0x37ef69,_0x44e61f,_0x14a85c);return Cu(_0x31be50['processor_'],_0x398ecf['viewCache']),f(_0x398ecf['viewCache']['serverCache']['isFullyInitialized']()||!_0x91f9a9['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x31be50['viewCache_']=_0x398ecf['viewCache'],$o(_0x31be50,_0x398ecf['changes'],_0x398ecf['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x30eb9f,_0x30d5c){const _0x20d62b=_0x30eb9f['viewCache_']['eventCache'],_0x162c9c=[];return _0x20d62b['getNode']()['isLeafNode']()||_0x20d62b['getNode']()['forEachChild'](R,(_0x2f24ae,_0x340a2e)=>{_0x162c9c['push'](tt(_0x2f24ae,_0x340a2e));}),_0x20d62b['isFullyInitialized']()&&_0x162c9c['push'](Oo(_0x20d62b['getNode']())),$o(_0x30eb9f,_0x162c9c,_0x20d62b['getNode'](),_0x30d5c);}function $o(_0x502f11,_0x5d5ac3,_0x35e987,_0x296f08){const _0x577170=_0x296f08?[_0x296f08]:_0x502f11['eventRegistrations_'];return nu(_0x502f11['eventGenerator_'],_0x5d5ac3,_0x35e987,_0x577170);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0xacdc8){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0xacdc8;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x34bdb3){return _0x34bdb3['views']['size']===0x0;}function is(_0x33d470,_0x3af0d7,_0x58f9db,_0x558d19){const _0x416d6e=_0x3af0d7['source']['queryId'];if(_0x416d6e!==null){const _0x11a8fa=_0x33d470['views']['get'](_0x416d6e);return f(_0x11a8fa!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x11a8fa,_0x3af0d7,_0x58f9db,_0x558d19);}else{let _0x5cef4e=[];for(const _0x1a9e2d of _0x33d470['views']['values']())_0x5cef4e=_0x5cef4e['concat'](ur(_0x1a9e2d,_0x3af0d7,_0x58f9db,_0x558d19));return _0x5cef4e;}}function qo(_0x4d05b5,_0x4b0622,_0xea82da,_0xb42edd,_0x4a661d){const _0x399ba9=_0x4b0622['_queryIdentifier'],_0x5b31db=_0x4d05b5['views']['get'](_0x399ba9);if(!_0x5b31db){let _0x1ea2af=mn(_0xea82da,_0x4a661d?_0xb42edd:null),_0x5f2a1d=!0x1;_0x1ea2af?_0x5f2a1d=!0x0:_0xb42edd instanceof g?(_0x1ea2af=es(_0xea82da,_0xb42edd),_0x5f2a1d=!0x1):(_0x1ea2af=g['EMPTY_NODE'],_0x5f2a1d=!0x1);const _0x327ef2=Dn(new Ce(_0x1ea2af,_0x5f2a1d,!0x1),new Ce(_0xb42edd,_0x4a661d,!0x1));return new Nu(_0x4b0622,_0x327ef2);}return _0x5b31db;}function Wu(_0x157ce9,_0x410c5d,_0x36dd30,_0x46e597,_0x592d46,_0x78a229){const _0x44130c=qo(_0x157ce9,_0x410c5d,_0x46e597,_0x592d46,_0x78a229);return _0x157ce9['views']['has'](_0x410c5d['_queryIdentifier'])||_0x157ce9['views']['set'](_0x410c5d['_queryIdentifier'],_0x44130c),Mu(_0x44130c,_0x36dd30),Lu(_0x44130c,_0x36dd30);}function Bu(_0x1b9feb,_0x4cefa6,_0x29fcea,_0x40616d){const _0x1cfe55=_0x4cefa6['_queryIdentifier'],_0x27d9a1=[];let _0x288029=[];const _0x3dc1f2=Te(_0x1b9feb);if(_0x1cfe55==='default'){for(const [_0x17b7ca,_0x174639]of _0x1b9feb['views']['entries']())_0x288029=_0x288029['concat'](hr(_0x174639,_0x29fcea,_0x40616d)),lr(_0x174639)&&(_0x1b9feb['views']['delete'](_0x17b7ca),_0x174639['query']['_queryParams']['loadsAllData']()||_0x27d9a1['push'](_0x174639['query']));}else{const _0x1fb63c=_0x1b9feb['views']['get'](_0x1cfe55);_0x1fb63c&&(_0x288029=_0x288029['concat'](hr(_0x1fb63c,_0x29fcea,_0x40616d)),lr(_0x1fb63c)&&(_0x1b9feb['views']['delete'](_0x1cfe55),_0x1fb63c['query']['_queryParams']['loadsAllData']()||_0x27d9a1['push'](_0x1fb63c['query'])));}return _0x3dc1f2&&!Te(_0x1b9feb)&&_0x27d9a1['push'](new(Fu())(_0x4cefa6['_repo'],_0x4cefa6['_path'])),{'removed':_0x27d9a1,'events':_0x288029};}function zo(_0x18408c){const _0x33bb4f=[];for(const _0x355a96 of _0x18408c['views']['values']())_0x355a96['query']['_queryParams']['loadsAllData']()||_0x33bb4f['push'](_0x355a96);return _0x33bb4f;}function Ee(_0x514383,_0x46b1d3){let _0x30e67b=null;for(const _0x8bfbe1 of _0x514383['views']['values']())_0x30e67b=_0x30e67b||Du(_0x8bfbe1,_0x46b1d3);return _0x30e67b;}function jo(_0x47f66c,_0x401c43){if(_0x401c43['_queryParams']['loadsAllData']())return Ln(_0x47f66c);{const _0x34ba26=_0x401c43['_queryIdentifier'];return _0x47f66c['views']['get'](_0x34ba26);}}function Ko(_0x3144af,_0x74c154){return jo(_0x3144af,_0x74c154)!=null;}function Te(_0x253505){return Ln(_0x253505)!=null;}function Ln(_0x34e05f){for(const _0x32cfd8 of _0x34e05f['views']['values']())if(_0x32cfd8['query']['_queryParams']['loadsAllData']())return _0x32cfd8;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x507305){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x507305;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x23f48c){this['listenProvider_']=_0x23f48c,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x223b4c,_0x511fa6,_0x1ca1b1,_0x1e897d,_0x119483){return ou(_0x223b4c['pendingWriteTree_'],_0x511fa6,_0x1ca1b1,_0x1e897d,_0x119483),_0x119483?ht(_0x223b4c,new Fe(Ji(),_0x511fa6,_0x1ca1b1)):[];}function Gu(_0x242de3,_0x511ae1,_0x111b64,_0x308218){au(_0x242de3['pendingWriteTree_'],_0x511ae1,_0x111b64,_0x308218);const _0x2e45fa=S['fromObject'](_0x111b64);return ht(_0x242de3,new nt(Ji(),_0x511ae1,_0x2e45fa));}function pe(_0x228c25,_0x4595fe,_0x2a8501=!0x1){const _0x569e2d=cu(_0x228c25['pendingWriteTree_'],_0x4595fe);if(lu(_0x228c25['pendingWriteTree_'],_0x4595fe)){let _0xb55461=new S(null);return _0x569e2d['snap']!=null?_0xb55461=_0xb55461['set'](w(),!0x0):x(_0x569e2d['children'],_0x27a29c=>{_0xb55461=_0xb55461['set'](new C(_0x27a29c),!0x0);}),ht(_0x228c25,new _n(_0x569e2d['path'],_0xb55461,_0x2a8501));}else return[];}function $t(_0x13e404,_0x2c4371,_0x145694){return ht(_0x13e404,new Fe(Xi(),_0x2c4371,_0x145694));}function qu(_0x3daca8,_0x25e519,_0x44a35c){const _0x110bd3=S['fromObject'](_0x44a35c);return ht(_0x3daca8,new nt(Xi(),_0x25e519,_0x110bd3));}function zu(_0xc51e9,_0x179ef1){return ht(_0xc51e9,new Dt(Xi(),_0x179ef1));}function ju(_0x5deff4,_0x350b70,_0x4479d9){const _0x1556bf=rs(_0x5deff4,_0x4479d9);if(_0x1556bf){const _0x355b71=os(_0x1556bf),_0x172392=_0x355b71['path'],_0x5583d9=_0x355b71['queryId'],_0x37d1a9=F(_0x172392,_0x350b70),_0x1efd15=new Dt(Zi(_0x5583d9),_0x37d1a9);return as(_0x5deff4,_0x172392,_0x1efd15);}else return[];}function wn(_0x128be4,_0xca562b,_0x5370ae,_0x1b1701,_0x5522c4=!0x1){const _0x13e73f=_0xca562b['_path'],_0x39f633=_0x128be4['syncPointTree_']['get'](_0x13e73f);let _0x17949d=[];if(_0x39f633&&(_0xca562b['_queryIdentifier']==='default'||Ko(_0x39f633,_0xca562b))){const _0x431573=Bu(_0x39f633,_0xca562b,_0x5370ae,_0x1b1701);Uu(_0x39f633)&&(_0x128be4['syncPointTree_']=_0x128be4['syncPointTree_']['remove'](_0x13e73f));const _0x46c759=_0x431573['removed'];if(_0x17949d=_0x431573['events'],!_0x5522c4){const _0x1f2958=_0x46c759['findIndex'](_0x69471f=>_0x69471f['_queryParams']['loadsAllData']())!==-0x1,_0x547ca4=_0x128be4['syncPointTree_']['findOnPath'](_0x13e73f,(_0x5e7de4,_0x288ce6)=>Te(_0x288ce6));if(_0x1f2958&&!_0x547ca4){const _0x110731=_0x128be4['syncPointTree_']['subtree'](_0x13e73f);if(!_0x110731['isEmpty']()){const _0x4d99c3=Qu(_0x110731);for(let _0x14c763=0x0;_0x14c763<_0x4d99c3['length'];++_0x14c763){const _0x49ac32=_0x4d99c3[_0x14c763],_0x152f12=_0x49ac32['query'],_0x181d50=Xo(_0x128be4,_0x49ac32);_0x128be4['listenProvider_']['startListening'](Tt(_0x152f12),Mt(_0x128be4,_0x152f12),_0x181d50['hashFn'],_0x181d50['onComplete']);}}}!_0x547ca4&&_0x46c759['length']>0x0&&!_0x1b1701&&(_0x1f2958?_0x128be4['listenProvider_']['stopListening'](Tt(_0xca562b),null):_0x46c759['forEach'](_0x4495c7=>{const _0x3de764=_0x128be4['queryToTagMap']['get'](Fn(_0x4495c7));_0x128be4['listenProvider_']['stopListening'](Tt(_0x4495c7),_0x3de764);}));}Ju(_0x128be4,_0x46c759);}return _0x17949d;}function Yo(_0x333ac9,_0x47cdee,_0x1f9c84,_0x1a910a){const _0x5e3742=rs(_0x333ac9,_0x1a910a);if(_0x5e3742!=null){const _0x573d3d=os(_0x5e3742),_0x2d7a25=_0x573d3d['path'],_0x51492c=_0x573d3d['queryId'],_0x4e21ac=F(_0x2d7a25,_0x47cdee),_0x13d27e=new Fe(Zi(_0x51492c),_0x4e21ac,_0x1f9c84);return as(_0x333ac9,_0x2d7a25,_0x13d27e);}else return[];}function Ku(_0xad6b9e,_0x51247b,_0x4e6e3c,_0x43a2cf){const _0x47ee67=rs(_0xad6b9e,_0x43a2cf);if(_0x47ee67){const _0x505df7=os(_0x47ee67),_0x539b1e=_0x505df7['path'],_0x3bbe9f=_0x505df7['queryId'],_0x108fce=F(_0x539b1e,_0x51247b),_0x6872be=S['fromObject'](_0x4e6e3c),_0x43b6bc=new nt(Zi(_0x3bbe9f),_0x108fce,_0x6872be);return as(_0xad6b9e,_0x539b1e,_0x43b6bc);}else return[];}function bi(_0x6bde42,_0x2266b3,_0x3eed70,_0x4b939c=!0x1){const _0x5b3c56=_0x2266b3['_path'];let _0x1ba73c=null,_0x5f4010=!0x1;_0x6bde42['syncPointTree_']['foreachOnPath'](_0x5b3c56,(_0x3d3899,_0x176cd0)=>{const _0x3ef2fc=F(_0x3d3899,_0x5b3c56);_0x1ba73c=_0x1ba73c||Ee(_0x176cd0,_0x3ef2fc),_0x5f4010=_0x5f4010||Te(_0x176cd0);});let _0x467454=_0x6bde42['syncPointTree_']['get'](_0x5b3c56);_0x467454?(_0x5f4010=_0x5f4010||Te(_0x467454),_0x1ba73c=_0x1ba73c||Ee(_0x467454,w())):(_0x467454=new Go(),_0x6bde42['syncPointTree_']=_0x6bde42['syncPointTree_']['set'](_0x5b3c56,_0x467454));let _0x49add7;_0x1ba73c!=null?_0x49add7=!0x0:(_0x49add7=!0x1,_0x1ba73c=g['EMPTY_NODE'],_0x6bde42['syncPointTree_']['subtree'](_0x5b3c56)['foreachChild']((_0xe82611,_0x2d263b)=>{const _0x2b96df=Ee(_0x2d263b,w());_0x2b96df&&(_0x1ba73c=_0x1ba73c['updateImmediateChild'](_0xe82611,_0x2b96df));}));const _0x29cdfb=Ko(_0x467454,_0x2266b3);if(!_0x29cdfb&&!_0x2266b3['_queryParams']['loadsAllData']()){const _0x34d802=Fn(_0x2266b3);f(!_0x6bde42['queryToTagMap']['has'](_0x34d802),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3e9220=Xu();_0x6bde42['queryToTagMap']['set'](_0x34d802,_0x3e9220),_0x6bde42['tagToQueryMap']['set'](_0x3e9220,_0x34d802);}const _0x75b75c=Mn(_0x6bde42['pendingWriteTree_'],_0x5b3c56);let _0x221218=Wu(_0x467454,_0x2266b3,_0x3eed70,_0x75b75c,_0x1ba73c,_0x49add7);if(!_0x29cdfb&&!_0x5f4010&&!_0x4b939c){const _0x1aa565=jo(_0x467454,_0x2266b3);_0x221218=_0x221218['concat'](Zu(_0x6bde42,_0x2266b3,_0x1aa565));}return _0x221218;}function xn(_0x5e0a15,_0x48abae,_0x29ffea){const _0x23fa34=_0x5e0a15['pendingWriteTree_'],_0x1d6793=_0x5e0a15['syncPointTree_']['findOnPath'](_0x48abae,(_0x1d238d,_0x14bd86)=>{const _0x14199b=F(_0x1d238d,_0x48abae),_0x30599b=Ee(_0x14bd86,_0x14199b);if(_0x30599b)return _0x30599b;});return Uo(_0x23fa34,_0x48abae,_0x1d6793,_0x29ffea,!0x0);}function Yu(_0x459e43,_0x5f3f19){const _0x38026a=_0x5f3f19['_path'];let _0x2882da=null;_0x459e43['syncPointTree_']['foreachOnPath'](_0x38026a,(_0x5e254a,_0x4533ea)=>{const _0x964302=F(_0x5e254a,_0x38026a);_0x2882da=_0x2882da||Ee(_0x4533ea,_0x964302);});let _0x5a465b=_0x459e43['syncPointTree_']['get'](_0x38026a);_0x5a465b?_0x2882da=_0x2882da||Ee(_0x5a465b,w()):(_0x5a465b=new Go(),_0x459e43['syncPointTree_']=_0x459e43['syncPointTree_']['set'](_0x38026a,_0x5a465b));const _0x5dc806=_0x2882da!=null,_0x106dd3=_0x5dc806?new Ce(_0x2882da,!0x0,!0x1):null,_0x4d3b91=Mn(_0x459e43['pendingWriteTree_'],_0x5f3f19['_path']),_0x2e0e8a=qo(_0x5a465b,_0x5f3f19,_0x4d3b91,_0x5dc806?_0x106dd3['getNode']():g['EMPTY_NODE'],_0x5dc806);return Ou(_0x2e0e8a);}function ht(_0x599fa4,_0x2723f0){return Qo(_0x2723f0,_0x599fa4['syncPointTree_'],null,Mn(_0x599fa4['pendingWriteTree_'],w()));}function Qo(_0x505500,_0x2211c2,_0x367b77,_0x515d53){if(v(_0x505500['path']))return Jo(_0x505500,_0x2211c2,_0x367b77,_0x515d53);{const _0x3c0c3c=_0x2211c2['get'](w());_0x367b77==null&&_0x3c0c3c!=null&&(_0x367b77=Ee(_0x3c0c3c,w()));let _0x2e4906=[];const _0x2384ee=y(_0x505500['path']),_0x40c450=_0x505500['operationForChild'](_0x2384ee),_0x260489=_0x2211c2['children']['get'](_0x2384ee);if(_0x260489&&_0x40c450){const _0x15613e=_0x367b77?_0x367b77['getImmediateChild'](_0x2384ee):null,_0x13d939=Wo(_0x515d53,_0x2384ee);_0x2e4906=_0x2e4906['concat'](Qo(_0x40c450,_0x260489,_0x15613e,_0x13d939));}return _0x3c0c3c&&(_0x2e4906=_0x2e4906['concat'](is(_0x3c0c3c,_0x505500,_0x515d53,_0x367b77))),_0x2e4906;}}function Jo(_0x3c9ccb,_0x1ec757,_0x4a6787,_0x58e257){const _0x1677dd=_0x1ec757['get'](w());_0x4a6787==null&&_0x1677dd!=null&&(_0x4a6787=Ee(_0x1677dd,w()));let _0x22df96=[];return _0x1ec757['children']['inorderTraversal']((_0x2f9f0a,_0x3b1bac)=>{const _0x387099=_0x4a6787?_0x4a6787['getImmediateChild'](_0x2f9f0a):null,_0x56f36b=Wo(_0x58e257,_0x2f9f0a),_0x4c673f=_0x3c9ccb['operationForChild'](_0x2f9f0a);_0x4c673f&&(_0x22df96=_0x22df96['concat'](Jo(_0x4c673f,_0x3b1bac,_0x387099,_0x56f36b)));}),_0x1677dd&&(_0x22df96=_0x22df96['concat'](is(_0x1677dd,_0x3c9ccb,_0x58e257,_0x4a6787))),_0x22df96;}function Xo(_0x2f4e55,_0x3c21e9){const _0x281be7=_0x3c21e9['query'],_0xbb4cda=Mt(_0x2f4e55,_0x281be7);return{'hashFn':()=>(Pu(_0x3c21e9)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x5e2bd0=>{if(_0x5e2bd0==='ok')return _0xbb4cda?ju(_0x2f4e55,_0x281be7['_path'],_0xbb4cda):zu(_0x2f4e55,_0x281be7['_path']);{const _0x548411=ql(_0x5e2bd0,_0x281be7);return wn(_0x2f4e55,_0x281be7,null,_0x548411);}}};}function Mt(_0x1f83d0,_0x16f330){const _0x22fe6b=Fn(_0x16f330);return _0x1f83d0['queryToTagMap']['get'](_0x22fe6b);}function Fn(_0x5d093c){return _0x5d093c['_path']['toString']()+'$'+_0x5d093c['_queryIdentifier'];}function rs(_0x4df362,_0xf7b057){return _0x4df362['tagToQueryMap']['get'](_0xf7b057);}function os(_0x3da834){const _0x538a32=_0x3da834['indexOf']('$');return f(_0x538a32!==-0x1&&_0x538a32<_0x3da834['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3da834['substr'](_0x538a32+0x1),'path':new C(_0x3da834['substr'](0x0,_0x538a32))};}function as(_0x1a6c3a,_0x5aeff9,_0x236d78){const _0x52056e=_0x1a6c3a['syncPointTree_']['get'](_0x5aeff9);f(_0x52056e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x152e34=Mn(_0x1a6c3a['pendingWriteTree_'],_0x5aeff9);return is(_0x52056e,_0x236d78,_0x152e34,null);}function Qu(_0x468fb4){return _0x468fb4['fold']((_0x4bebc9,_0x478f4e,_0x141fb4)=>{if(_0x478f4e&&Te(_0x478f4e))return[Ln(_0x478f4e)];{let _0x48b7a5=[];return _0x478f4e&&(_0x48b7a5=zo(_0x478f4e)),x(_0x141fb4,(_0xc6273d,_0x245ea8)=>{_0x48b7a5=_0x48b7a5['concat'](_0x245ea8);}),_0x48b7a5;}});}function Tt(_0x537be9){return _0x537be9['_queryParams']['loadsAllData']()&&!_0x537be9['_queryParams']['isDefault']()?new(Hu())(_0x537be9['_repo'],_0x537be9['_path']):_0x537be9;}function Ju(_0x110dd8,_0xe6d9aa){for(let _0x3af388=0x0;_0x3af388<_0xe6d9aa['length'];++_0x3af388){const _0x32b14e=_0xe6d9aa[_0x3af388];if(!_0x32b14e['_queryParams']['loadsAllData']()){const _0x49c7f2=Fn(_0x32b14e),_0x5be018=_0x110dd8['queryToTagMap']['get'](_0x49c7f2);_0x110dd8['queryToTagMap']['delete'](_0x49c7f2),_0x110dd8['tagToQueryMap']['delete'](_0x5be018);}}}function Xu(){return $u++;}function Zu(_0x4d8830,_0x424439,_0xea4dff){const _0x4c54c0=_0x424439['_path'],_0x2a1af9=Mt(_0x4d8830,_0x424439),_0x59359e=Xo(_0x4d8830,_0xea4dff),_0x4ca552=_0x4d8830['listenProvider_']['startListening'](Tt(_0x424439),_0x2a1af9,_0x59359e['hashFn'],_0x59359e['onComplete']),_0x4c6e27=_0x4d8830['syncPointTree_']['subtree'](_0x4c54c0);if(_0x2a1af9)f(!Te(_0x4c6e27['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x45a4ff=_0x4c6e27['fold']((_0x50641a,_0x46446b,_0x1cb397)=>{if(!v(_0x50641a)&&_0x46446b&&Te(_0x46446b))return[Ln(_0x46446b)['query']];{let _0x379573=[];return _0x46446b&&(_0x379573=_0x379573['concat'](zo(_0x46446b)['map'](_0x42468c=>_0x42468c['query']))),x(_0x1cb397,(_0x5183f6,_0x1124df)=>{_0x379573=_0x379573['concat'](_0x1124df);}),_0x379573;}});for(let _0x3f4272=0x0;_0x3f4272<_0x45a4ff['length'];++_0x3f4272){const _0x597e3c=_0x45a4ff[_0x3f4272];_0x4d8830['listenProvider_']['stopListening'](Tt(_0x597e3c),Mt(_0x4d8830,_0x597e3c));}}return _0x4ca552;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x344b94){this['node_']=_0x344b94;}['getImmediateChild'](_0x189f19){const _0x209316=this['node_']['getImmediateChild'](_0x189f19);return new cs(_0x209316);}['node'](){return this['node_'];}}class ls{constructor(_0x4e4b57,_0x46bd4f){this['syncTree_']=_0x4e4b57,this['path_']=_0x46bd4f;}['getImmediateChild'](_0x13c2c5){const _0x44935d=A(this['path_'],_0x13c2c5);return new ls(this['syncTree_'],_0x44935d);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x46bb78){return _0x46bb78=_0x46bb78||{},_0x46bb78['timestamp']=_0x46bb78['timestamp']||new Date()['getTime'](),_0x46bb78;},fr=function(_0x5125a5,_0x5a05a6,_0x241fed){if(!_0x5125a5||typeof _0x5125a5!='object')return _0x5125a5;if(f('.sv'in _0x5125a5,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5125a5['.sv']=='string')return td(_0x5125a5['.sv'],_0x5a05a6,_0x241fed);if(typeof _0x5125a5['.sv']=='object')return nd(_0x5125a5['.sv'],_0x5a05a6);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5125a5,null,0x2));},td=function(_0x4960d4,_0x9f0f5b,_0x1354e6){switch(_0x4960d4){case'timestamp':return _0x1354e6['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x4960d4);}},nd=function(_0x5be7bb,_0x41b0b7,_0x495ad6){_0x5be7bb['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5be7bb,null,0x2));const _0x4d65db=_0x5be7bb['increment'];typeof _0x4d65db!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4d65db);const _0x4c0e24=_0x41b0b7['node']();if(f(_0x4c0e24!==null&&typeof _0x4c0e24<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4c0e24['isLeafNode']())return _0x4d65db;const _0x4ccecd=_0x4c0e24['getValue']();return typeof _0x4ccecd!='number'?_0x4d65db:_0x4ccecd+_0x4d65db;},Zo=function(_0x2b6e65,_0xb7a565,_0x2be114,_0x1d6e77){return us(_0xb7a565,new ls(_0x2be114,_0x2b6e65),_0x1d6e77);},hs=function(_0xca09ff,_0xad3c18,_0x3dcc67){return us(_0xca09ff,new cs(_0xad3c18),_0x3dcc67);};function us(_0x2bbbd6,_0x183b6e,_0x2f0985){const _0x3cf367=_0x2bbbd6['getPriority']()['val'](),_0x2d2f31=fr(_0x3cf367,_0x183b6e['getImmediateChild']('.priority'),_0x2f0985);let _0x5230a7;if(_0x2bbbd6['isLeafNode']()){const _0xe2ba1c=_0x2bbbd6,_0x1d8af4=fr(_0xe2ba1c['getValue'](),_0x183b6e,_0x2f0985);return _0x1d8af4!==_0xe2ba1c['getValue']()||_0x2d2f31!==_0xe2ba1c['getPriority']()['val']()?new D(_0x1d8af4,N(_0x2d2f31)):_0x2bbbd6;}else{const _0x39d956=_0x2bbbd6;return _0x5230a7=_0x39d956,_0x2d2f31!==_0x39d956['getPriority']()['val']()&&(_0x5230a7=_0x5230a7['updatePriority'](new D(_0x2d2f31))),_0x39d956['forEachChild'](R,(_0x4e93ed,_0x3fb604)=>{const _0x27f448=us(_0x3fb604,_0x183b6e['getImmediateChild'](_0x4e93ed),_0x2f0985);_0x27f448!==_0x3fb604&&(_0x5230a7=_0x5230a7['updateImmediateChild'](_0x4e93ed,_0x27f448));}),_0x5230a7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x113f83='',_0x1d0a32=null,_0x4f481b={'children':{},'childCount':0x0}){this['name']=_0x113f83,this['parent']=_0x1d0a32,this['node']=_0x4f481b;}}function Un(_0x5ed809,_0x511ce2){let _0x11b97c=_0x511ce2 instanceof C?_0x511ce2:new C(_0x511ce2),_0x113977=_0x5ed809,_0x764363=y(_0x11b97c);for(;_0x764363!==null;){const _0x5e453b=Oe(_0x113977['node']['children'],_0x764363)||{'children':{},'childCount':0x0};_0x113977=new ds(_0x764363,_0x113977,_0x5e453b),_0x11b97c=b(_0x11b97c),_0x764363=y(_0x11b97c);}return _0x113977;}function Ge(_0x47b23b){return _0x47b23b['node']['value'];}function fs(_0x427019,_0x49495f){_0x427019['node']['value']=_0x49495f,Ri(_0x427019);}function ea(_0x108c30){return _0x108c30['node']['childCount']>0x0;}function id(_0x17c02c){return Ge(_0x17c02c)===void 0x0&&!ea(_0x17c02c);}function Wn(_0x560b32,_0x426af0){x(_0x560b32['node']['children'],(_0x147eff,_0x3a149c)=>{_0x426af0(new ds(_0x147eff,_0x560b32,_0x3a149c));});}function ta(_0x18a4e8,_0x514139,_0x3b160e,_0x4ae6df){_0x3b160e&&_0x514139(_0x18a4e8),Wn(_0x18a4e8,_0x29cc4b=>{ta(_0x29cc4b,_0x514139,!0x0);});}function sd(_0xd025e6,_0x84193,_0xd419c0){let _0x397b0b=_0xd025e6['parent'];for(;_0x397b0b!==null;){if(_0x84193(_0x397b0b))return!0x0;_0x397b0b=_0x397b0b['parent'];}return!0x1;}function Gt(_0x4fe089){return new C(_0x4fe089['parent']===null?_0x4fe089['name']:Gt(_0x4fe089['parent'])+'/'+_0x4fe089['name']);}function Ri(_0x371578){_0x371578['parent']!==null&&rd(_0x371578['parent'],_0x371578['name'],_0x371578);}function rd(_0x3bcd6e,_0x40f938,_0x58dfc7){const _0x4dbaff=id(_0x58dfc7),_0x511d63=Y(_0x3bcd6e['node']['children'],_0x40f938);_0x4dbaff&&_0x511d63?(delete _0x3bcd6e['node']['children'][_0x40f938],_0x3bcd6e['node']['childCount']--,Ri(_0x3bcd6e)):!_0x4dbaff&&!_0x511d63&&(_0x3bcd6e['node']['children'][_0x40f938]=_0x58dfc7['node'],_0x3bcd6e['node']['childCount']++,Ri(_0x3bcd6e));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x575a50){return typeof _0x575a50=='string'&&_0x575a50['length']!==0x0&&!od['test'](_0x575a50);},na=function(_0x4c6b1f){return typeof _0x4c6b1f=='string'&&_0x4c6b1f['length']!==0x0&&!ad['test'](_0x4c6b1f);},cd=function(_0x278c00){return _0x278c00&&(_0x278c00=_0x278c00['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x278c00);},Cn=function(_0x2f8d11){return _0x2f8d11===null||typeof _0x2f8d11=='string'||typeof _0x2f8d11=='number'&&!Wi(_0x2f8d11)||_0x2f8d11&&typeof _0x2f8d11=='object'&&Y(_0x2f8d11,'.sv');},qt=function(_0x303bcc,_0x36eecb,_0x3555c1,_0x47191f){_0x47191f&&_0x36eecb===void 0x0||zt(Nn(_0x303bcc,'value'),_0x36eecb,_0x3555c1);},zt=function(_0x5a3d7e,_0x2164ee,_0x56256f){const _0x1cc61a=_0x56256f instanceof C?new Sh(_0x56256f,_0x5a3d7e):_0x56256f;if(_0x2164ee===void 0x0)throw new Error(_0x5a3d7e+'contains\x20undefined\x20'+Ne(_0x1cc61a));if(typeof _0x2164ee=='function')throw new Error(_0x5a3d7e+'contains\x20a\x20function\x20'+Ne(_0x1cc61a)+'\x20with\x20contents\x20=\x20'+_0x2164ee['toString']());if(Wi(_0x2164ee))throw new Error(_0x5a3d7e+'contains\x20'+_0x2164ee['toString']()+'\x20'+Ne(_0x1cc61a));if(typeof _0x2164ee=='string'&&_0x2164ee['length']>oi/0x3&&Pn(_0x2164ee)>oi)throw new Error(_0x5a3d7e+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x1cc61a)+'\x20(\x27'+_0x2164ee['substring'](0x0,0x32)+'...\x27)');if(_0x2164ee&&typeof _0x2164ee=='object'){let _0x32b401=!0x1,_0x1ddbf2=!0x1;if(x(_0x2164ee,(_0x560e25,_0x1d86eb)=>{if(_0x560e25==='.value')_0x32b401=!0x0;else{if(_0x560e25!=='.priority'&&_0x560e25!=='.sv'&&(_0x1ddbf2=!0x0,!ps(_0x560e25)))throw new Error(_0x5a3d7e+'\x20contains\x20an\x20invalid\x20key\x20('+_0x560e25+')\x20'+Ne(_0x1cc61a)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x1cc61a,_0x560e25),zt(_0x5a3d7e,_0x1d86eb,_0x1cc61a),Rh(_0x1cc61a);}),_0x32b401&&_0x1ddbf2)throw new Error(_0x5a3d7e+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x1cc61a)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x1cebed,_0x35a269){let _0x1a049d,_0x1ec377;for(_0x1a049d=0x0;_0x1a049d<_0x35a269['length'];_0x1a049d++){_0x1ec377=_0x35a269[_0x1a049d];const _0x302353=kt(_0x1ec377);for(let _0x503e7c=0x0;_0x503e7c<_0x302353['length'];_0x503e7c++)if(!(_0x302353[_0x503e7c]==='.priority'&&_0x503e7c===_0x302353['length']-0x1)){if(!ps(_0x302353[_0x503e7c]))throw new Error(_0x1cebed+'contains\x20an\x20invalid\x20key\x20('+_0x302353[_0x503e7c]+')\x20in\x20path\x20'+_0x1ec377['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x35a269['sort'](Th);let _0x16251b=null;for(_0x1a049d=0x0;_0x1a049d<_0x35a269['length'];_0x1a049d++){if(_0x1ec377=_0x35a269[_0x1a049d],_0x16251b!==null&&$(_0x16251b,_0x1ec377))throw new Error(_0x1cebed+'contains\x20a\x20path\x20'+_0x16251b['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x1ec377['toString']());_0x16251b=_0x1ec377;}},hd=function(_0x4a397e,_0x18f458,_0x4385aa,_0x3ef40b){const _0x1f6505=Nn(_0x4a397e,'values');if(!(_0x18f458&&typeof _0x18f458=='object')||Array['isArray'](_0x18f458))throw new Error(_0x1f6505+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x18f6a8=[];x(_0x18f458,(_0x25ba53,_0x50c52e)=>{const _0x2f488a=new C(_0x25ba53);if(zt(_0x1f6505,_0x50c52e,A(_0x4385aa,_0x2f488a)),Gi(_0x2f488a)==='.priority'&&!Cn(_0x50c52e))throw new Error(_0x1f6505+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2f488a['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x18f6a8['push'](_0x2f488a);}),ld(_0x1f6505,_0x18f6a8);},_s=function(_0x56b04e,_0x3f077e,_0x3a6006,_0x246680){if(!na(_0x3a6006))throw new Error(Nn(_0x56b04e,_0x3f077e)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3a6006+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x56868f,_0x7ce170,_0x2dfd77,_0x5ebeb9){_0x2dfd77&&(_0x2dfd77=_0x2dfd77['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x56868f,_0x7ce170,_0x2dfd77);},gs=function(_0x52fa68,_0x4a3c53){if(y(_0x4a3c53)==='.info')throw new Error(_0x52fa68+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x51cc03,_0x213f63){const _0x3eda91=_0x213f63['path']['toString']();if(typeof _0x213f63['repoInfo']['host']!='string'||_0x213f63['repoInfo']['host']['length']===0x0||!ps(_0x213f63['repoInfo']['namespace'])&&_0x213f63['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x3eda91['length']!==0x0&&!cd(_0x3eda91))throw new Error(Nn(_0x51cc03,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x2071cc,_0x269b26){let _0x515f34=null;for(let _0x3e0b28=0x0;_0x3e0b28<_0x269b26['length'];_0x3e0b28++){const _0x55a80e=_0x269b26[_0x3e0b28],_0x23c6bf=_0x55a80e['getPath']();_0x515f34!==null&&!qi(_0x23c6bf,_0x515f34['path'])&&(_0x2071cc['eventLists_']['push'](_0x515f34),_0x515f34=null),_0x515f34===null&&(_0x515f34={'events':[],'path':_0x23c6bf}),_0x515f34['events']['push'](_0x55a80e);}_0x515f34&&_0x2071cc['eventLists_']['push'](_0x515f34);}function ia(_0x184212,_0x4628ba,_0x453885){Bn(_0x184212,_0x453885),sa(_0x184212,_0x5cfc08=>qi(_0x5cfc08,_0x4628ba));}function V(_0xe0fcf9,_0x4ec1c0,_0x24ed0d){Bn(_0xe0fcf9,_0x24ed0d),sa(_0xe0fcf9,_0x5d276c=>$(_0x5d276c,_0x4ec1c0)||$(_0x4ec1c0,_0x5d276c));}function sa(_0x660e4b,_0x5ddad2){_0x660e4b['recursionDepth_']++;let _0x4dab58=!0x0;for(let _0x414c70=0x0;_0x414c70<_0x660e4b['eventLists_']['length'];_0x414c70++){const _0x429278=_0x660e4b['eventLists_'][_0x414c70];if(_0x429278){const _0x3867f4=_0x429278['path'];_0x5ddad2(_0x3867f4)?(pd(_0x660e4b['eventLists_'][_0x414c70]),_0x660e4b['eventLists_'][_0x414c70]=null):_0x4dab58=!0x1;}}_0x4dab58&&(_0x660e4b['eventLists_']=[]),_0x660e4b['recursionDepth_']--;}function pd(_0x1b5ddc){for(let _0x2f035a=0x0;_0x2f035a<_0x1b5ddc['events']['length'];_0x2f035a++){const _0x778f5=_0x1b5ddc['events'][_0x2f035a];if(_0x778f5!==null){_0x1b5ddc['events'][_0x2f035a]=null;const _0x3af0fe=_0x778f5['getEventRunner']();Et&&L('event:\x20'+_0x778f5['toString']()),lt(_0x3af0fe);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x195173,_0x2ef8df,_0x28911b,_0x4d3ae6){this['repoInfo_']=_0x195173,this['forceRestClient_']=_0x2ef8df,this['authTokenProvider_']=_0x28911b,this['appCheckProvider_']=_0x4d3ae6,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x4fe6d9,_0x6d8cb3,_0xf3d763){if(_0x4fe6d9['stats_']=Hi(_0x4fe6d9['repoInfo_']),_0x4fe6d9['forceRestClient_']||Yl())_0x4fe6d9['server_']=new fn(_0x4fe6d9['repoInfo_'],(_0xc4d573,_0x156d0d,_0x222790,_0x233bb5)=>{pr(_0x4fe6d9,_0xc4d573,_0x156d0d,_0x222790,_0x233bb5);},_0x4fe6d9['authTokenProvider_'],_0x4fe6d9['appCheckProvider_']),setTimeout(()=>_r(_0x4fe6d9,!0x0),0x0);else{if(typeof _0xf3d763<'u'&&_0xf3d763!==null){if(typeof _0xf3d763!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xf3d763);}catch(_0x14d3b5){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x14d3b5);}}_0x4fe6d9['persistentConnection_']=new ie(_0x4fe6d9['repoInfo_'],_0x6d8cb3,(_0x21cc03,_0x7b7041,_0x40a0e2,_0x102b59)=>{pr(_0x4fe6d9,_0x21cc03,_0x7b7041,_0x40a0e2,_0x102b59);},_0x3aa62e=>{_r(_0x4fe6d9,_0x3aa62e);},_0x521488=>{yd(_0x4fe6d9,_0x521488);},_0x4fe6d9['authTokenProvider_'],_0x4fe6d9['appCheckProvider_'],_0xf3d763),_0x4fe6d9['server_']=_0x4fe6d9['persistentConnection_'];}_0x4fe6d9['authTokenProvider_']['addTokenChangeListener'](_0x2a16c2=>{_0x4fe6d9['server_']['refreshAuthToken'](_0x2a16c2);}),_0x4fe6d9['appCheckProvider_']['addTokenChangeListener'](_0xd48dc0=>{_0x4fe6d9['server_']['refreshAppCheckToken'](_0xd48dc0['token']);}),_0x4fe6d9['statsReporter_']=eh(_0x4fe6d9['repoInfo_'],()=>new eu(_0x4fe6d9['stats_'],_0x4fe6d9['server_'])),_0x4fe6d9['infoData_']=new Yh(),_0x4fe6d9['infoSyncTree_']=new dr({'startListening':(_0x2d14ca,_0xa8041c,_0xce8332,_0x25f801)=>{let _0x13d463=[];const _0x5e496d=_0x4fe6d9['infoData_']['getNode'](_0x2d14ca['_path']);return _0x5e496d['isEmpty']()||(_0x13d463=$t(_0x4fe6d9['infoSyncTree_'],_0x2d14ca['_path'],_0x5e496d),setTimeout(()=>{_0x25f801('ok');},0x0)),_0x13d463;},'stopListening':()=>{}}),ms(_0x4fe6d9,'connected',!0x1),_0x4fe6d9['serverSyncTree_']=new dr({'startListening':(_0x384993,_0x4e3775,_0x2fa087,_0x494ab9)=>(_0x4fe6d9['server_']['listen'](_0x384993,_0x2fa087,_0x4e3775,(_0x32ad1b,_0x4a6a1f)=>{const _0x5447f2=_0x494ab9(_0x32ad1b,_0x4a6a1f);V(_0x4fe6d9['eventQueue_'],_0x384993['_path'],_0x5447f2);}),[]),'stopListening':(_0x35024c,_0x52db61)=>{_0x4fe6d9['server_']['unlisten'](_0x35024c,_0x52db61);}});}function oa(_0x34ffbb){const _0x37fc9c=_0x34ffbb['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x37fc9c;}function jt(_0x5ebf77){return ed({'timestamp':oa(_0x5ebf77)});}function pr(_0x508910,_0x1ca090,_0x1ec01c,_0xeab08a,_0x2e016c){_0x508910['dataUpdateCount']++;const _0x242acd=new C(_0x1ca090);_0x1ec01c=_0x508910['interceptServerDataCallback_']?_0x508910['interceptServerDataCallback_'](_0x1ca090,_0x1ec01c):_0x1ec01c;let _0x385848=[];if(_0x2e016c){if(_0xeab08a){const _0x24c986=ln(_0x1ec01c,_0xb8386f=>N(_0xb8386f));_0x385848=Ku(_0x508910['serverSyncTree_'],_0x242acd,_0x24c986,_0x2e016c);}else{const _0x1d43e7=N(_0x1ec01c);_0x385848=Yo(_0x508910['serverSyncTree_'],_0x242acd,_0x1d43e7,_0x2e016c);}}else{if(_0xeab08a){const _0x41ed6d=ln(_0x1ec01c,_0x2df67e=>N(_0x2df67e));_0x385848=qu(_0x508910['serverSyncTree_'],_0x242acd,_0x41ed6d);}else{const _0x59aca3=N(_0x1ec01c);_0x385848=$t(_0x508910['serverSyncTree_'],_0x242acd,_0x59aca3);}}let _0x240e5e=_0x242acd;_0x385848['length']>0x0&&(_0x240e5e=st(_0x508910,_0x242acd)),V(_0x508910['eventQueue_'],_0x240e5e,_0x385848);}function _r(_0xa7e5ec,_0x4bf075){ms(_0xa7e5ec,'connected',_0x4bf075),_0x4bf075===!0x1&&wd(_0xa7e5ec);}function yd(_0x481efe,_0x34a3d2){x(_0x34a3d2,(_0x58a752,_0x351ac0)=>{ms(_0x481efe,_0x58a752,_0x351ac0);});}function ms(_0x2fdf51,_0x5aa572,_0x46f4ae){const _0x5d1d04=new C('/.info/'+_0x5aa572),_0xcd212b=N(_0x46f4ae);_0x2fdf51['infoData_']['updateSnapshot'](_0x5d1d04,_0xcd212b);const _0x24c310=$t(_0x2fdf51['infoSyncTree_'],_0x5d1d04,_0xcd212b);V(_0x2fdf51['eventQueue_'],_0x5d1d04,_0x24c310);}function Vn(_0x16df2f){return _0x16df2f['nextWriteId_']++;}function vd(_0x310121,_0x390d29,_0x316cab){const _0x23e50a=Yu(_0x310121['serverSyncTree_'],_0x390d29);return _0x23e50a!=null?Promise['resolve'](_0x23e50a):_0x310121['server_']['get'](_0x390d29)['then'](_0x54ada8=>{const _0x1aa899=N(_0x54ada8)['withIndex'](_0x390d29['_queryParams']['getIndex']());bi(_0x310121['serverSyncTree_'],_0x390d29,_0x316cab,!0x0);let _0x2f6c2a;if(_0x390d29['_queryParams']['loadsAllData']())_0x2f6c2a=$t(_0x310121['serverSyncTree_'],_0x390d29['_path'],_0x1aa899);else{const _0x16c335=Mt(_0x310121['serverSyncTree_'],_0x390d29);_0x2f6c2a=Yo(_0x310121['serverSyncTree_'],_0x390d29['_path'],_0x1aa899,_0x16c335);}return V(_0x310121['eventQueue_'],_0x390d29['_path'],_0x2f6c2a),wn(_0x310121['serverSyncTree_'],_0x390d29,_0x316cab,null,!0x0),_0x1aa899;},_0x569464=>(ut(_0x310121,'get\x20for\x20query\x20'+O(_0x390d29)+'\x20failed:\x20'+_0x569464),Promise['reject'](new Error(_0x569464))));}function Ed(_0x4078c3,_0x2164a4,_0x12997a,_0x2e436e,_0x4eedfa){ut(_0x4078c3,'set',{'path':_0x2164a4['toString'](),'value':_0x12997a,'priority':_0x2e436e});const _0x210325=jt(_0x4078c3),_0x1daeaa=N(_0x12997a,_0x2e436e),_0x13482e=xn(_0x4078c3['serverSyncTree_'],_0x2164a4),_0x25c374=hs(_0x1daeaa,_0x13482e,_0x210325),_0x58e2a0=Vn(_0x4078c3),_0x1ab89c=ss(_0x4078c3['serverSyncTree_'],_0x2164a4,_0x25c374,_0x58e2a0,!0x0);Bn(_0x4078c3['eventQueue_'],_0x1ab89c),_0x4078c3['server_']['put'](_0x2164a4['toString'](),_0x1daeaa['val'](!0x0),(_0x389f14,_0x2b1c3c)=>{const _0x1651c8=_0x389f14==='ok';_0x1651c8||U('set\x20at\x20'+_0x2164a4+'\x20failed:\x20'+_0x389f14);const _0x462e26=pe(_0x4078c3['serverSyncTree_'],_0x58e2a0,!_0x1651c8);V(_0x4078c3['eventQueue_'],_0x2164a4,_0x462e26),Ai(_0x4078c3,_0x4eedfa,_0x389f14,_0x2b1c3c);});const _0x1ce122=vs(_0x4078c3,_0x2164a4);st(_0x4078c3,_0x1ce122),V(_0x4078c3['eventQueue_'],_0x1ce122,[]);}function Id(_0xfc6e1a,_0x56ebd0,_0x3898ea,_0x1edea5){ut(_0xfc6e1a,'update',{'path':_0x56ebd0['toString'](),'value':_0x3898ea});let _0x2121f6=!0x0;const _0x36df6e=jt(_0xfc6e1a),_0xc24f95={};if(x(_0x3898ea,(_0x1acc1e,_0x51d175)=>{_0x2121f6=!0x1,_0xc24f95[_0x1acc1e]=Zo(A(_0x56ebd0,_0x1acc1e),N(_0x51d175),_0xfc6e1a['serverSyncTree_'],_0x36df6e);}),_0x2121f6)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0xfc6e1a,_0x1edea5,'ok',void 0x0);else{const _0x521c7a=Vn(_0xfc6e1a),_0x27f4dd=Gu(_0xfc6e1a['serverSyncTree_'],_0x56ebd0,_0xc24f95,_0x521c7a);Bn(_0xfc6e1a['eventQueue_'],_0x27f4dd),_0xfc6e1a['server_']['merge'](_0x56ebd0['toString'](),_0x3898ea,(_0x8a5436,_0x546205)=>{const _0x1af17a=_0x8a5436==='ok';_0x1af17a||U('update\x20at\x20'+_0x56ebd0+'\x20failed:\x20'+_0x8a5436);const _0x47ecb1=pe(_0xfc6e1a['serverSyncTree_'],_0x521c7a,!_0x1af17a),_0x2de2ee=_0x47ecb1['length']>0x0?st(_0xfc6e1a,_0x56ebd0):_0x56ebd0;V(_0xfc6e1a['eventQueue_'],_0x2de2ee,_0x47ecb1),Ai(_0xfc6e1a,_0x1edea5,_0x8a5436,_0x546205);}),x(_0x3898ea,_0x55c0c1=>{const _0x3f1445=vs(_0xfc6e1a,A(_0x56ebd0,_0x55c0c1));st(_0xfc6e1a,_0x3f1445);}),V(_0xfc6e1a['eventQueue_'],_0x56ebd0,[]);}}function wd(_0x111d74){ut(_0x111d74,'onDisconnectEvents');const _0x224bb5=jt(_0x111d74),_0x25bc79=pn();Ei(_0x111d74['onDisconnect_'],w(),(_0x5c898c,_0x240ab9)=>{const _0x1d5a64=Zo(_0x5c898c,_0x240ab9,_0x111d74['serverSyncTree_'],_0x224bb5);Mo(_0x25bc79,_0x5c898c,_0x1d5a64);});let _0x2916fb=[];Ei(_0x25bc79,w(),(_0x1837d4,_0x45aaaa)=>{_0x2916fb=_0x2916fb['concat']($t(_0x111d74['serverSyncTree_'],_0x1837d4,_0x45aaaa));const _0x2b419f=vs(_0x111d74,_0x1837d4);st(_0x111d74,_0x2b419f);}),_0x111d74['onDisconnect_']=pn(),V(_0x111d74['eventQueue_'],w(),_0x2916fb);}function Cd(_0x19fd3b,_0x42d329,_0x37ca2a){let _0xc4dfcc;y(_0x42d329['_path'])==='.info'?_0xc4dfcc=bi(_0x19fd3b['infoSyncTree_'],_0x42d329,_0x37ca2a):_0xc4dfcc=bi(_0x19fd3b['serverSyncTree_'],_0x42d329,_0x37ca2a),ia(_0x19fd3b['eventQueue_'],_0x42d329['_path'],_0xc4dfcc);}function Td(_0x5501a3,_0xe60094,_0x29a30a){let _0x27f71a;y(_0xe60094['_path'])==='.info'?_0x27f71a=wn(_0x5501a3['infoSyncTree_'],_0xe60094,_0x29a30a):_0x27f71a=wn(_0x5501a3['serverSyncTree_'],_0xe60094,_0x29a30a),ia(_0x5501a3['eventQueue_'],_0xe60094['_path'],_0x27f71a);}function aa(_0x4c1cfa){_0x4c1cfa['persistentConnection_']&&_0x4c1cfa['persistentConnection_']['interrupt'](ra);}function Sd(_0x3d1f51){_0x3d1f51['persistentConnection_']&&_0x3d1f51['persistentConnection_']['resume'](ra);}function ut(_0x22ac4d,..._0x2cf897){let _0x5d2567='';_0x22ac4d['persistentConnection_']&&(_0x5d2567=_0x22ac4d['persistentConnection_']['id']+':'),L(_0x5d2567,..._0x2cf897);}function Ai(_0x4d3392,_0x596e67,_0x3e39d,_0x56afe3){_0x596e67&&lt(()=>{if(_0x3e39d==='ok')_0x596e67(null);else{const _0x593684=(_0x3e39d||'error')['toUpperCase']();let _0x387c1d=_0x593684;_0x56afe3&&(_0x387c1d+=':\x20'+_0x56afe3);const _0x528406=new Error(_0x387c1d);_0x528406['code']=_0x593684,_0x596e67(_0x528406);}});}function bd(_0x65e10a,_0x2e79db,_0xcf5b36,_0x4a7b79,_0x3654b1,_0x249f6a){ut(_0x65e10a,'transaction\x20on\x20'+_0x2e79db);const _0x536397={'path':_0x2e79db,'update':_0xcf5b36,'onComplete':_0x4a7b79,'status':null,'order':to(),'applyLocally':_0x249f6a,'retryCount':0x0,'unwatcher':_0x3654b1,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x36e9c4=ys(_0x65e10a,_0x2e79db,void 0x0);_0x536397['currentInputSnapshot']=_0x36e9c4;const _0x1f465a=_0x536397['update'](_0x36e9c4['val']());if(_0x1f465a===void 0x0)_0x536397['unwatcher'](),_0x536397['currentOutputSnapshotRaw']=null,_0x536397['currentOutputSnapshotResolved']=null,_0x536397['onComplete']&&_0x536397['onComplete'](null,!0x1,_0x536397['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1f465a,_0x536397['path']),_0x536397['status']=0x0;const _0x48e3dd=Un(_0x65e10a['transactionQueueTree_'],_0x2e79db),_0x1696e1=Ge(_0x48e3dd)||[];_0x1696e1['push'](_0x536397),fs(_0x48e3dd,_0x1696e1);let _0x37fe3c;typeof _0x1f465a=='object'&&_0x1f465a!==null&&Y(_0x1f465a,'.priority')?(_0x37fe3c=Oe(_0x1f465a,'.priority'),f(Cn(_0x37fe3c),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x37fe3c=(xn(_0x65e10a['serverSyncTree_'],_0x2e79db)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xdc1906=jt(_0x65e10a),_0x76216a=N(_0x1f465a,_0x37fe3c),_0x15558f=hs(_0x76216a,_0x36e9c4,_0xdc1906);_0x536397['currentOutputSnapshotRaw']=_0x76216a,_0x536397['currentOutputSnapshotResolved']=_0x15558f,_0x536397['currentWriteId']=Vn(_0x65e10a);const _0x2a2cb0=ss(_0x65e10a['serverSyncTree_'],_0x2e79db,_0x15558f,_0x536397['currentWriteId'],_0x536397['applyLocally']);V(_0x65e10a['eventQueue_'],_0x2e79db,_0x2a2cb0),Hn(_0x65e10a,_0x65e10a['transactionQueueTree_']);}}function ys(_0x1ed090,_0x1e9b5d,_0x1c8b5b){return xn(_0x1ed090['serverSyncTree_'],_0x1e9b5d,_0x1c8b5b)||g['EMPTY_NODE'];}function Hn(_0x20308d,_0x43b986=_0x20308d['transactionQueueTree_']){if(_0x43b986||$n(_0x20308d,_0x43b986),Ge(_0x43b986)){const _0x2503af=la(_0x20308d,_0x43b986);f(_0x2503af['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2503af['every'](_0x4c5895=>_0x4c5895['status']===0x0)&&Rd(_0x20308d,Gt(_0x43b986),_0x2503af);}else ea(_0x43b986)&&Wn(_0x43b986,_0x14ee32=>{Hn(_0x20308d,_0x14ee32);});}function Rd(_0x20266b,_0x46a2c7,_0x558db6){const _0x204033=_0x558db6['map'](_0x1c6078=>_0x1c6078['currentWriteId']),_0x4175f4=ys(_0x20266b,_0x46a2c7,_0x204033);let _0x8be28e=_0x4175f4;const _0x2f2825=_0x4175f4['hash']();for(let _0x401106=0x0;_0x401106<_0x558db6['length'];_0x401106++){const _0x40b3a3=_0x558db6[_0x401106];f(_0x40b3a3['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x40b3a3['status']=0x1,_0x40b3a3['retryCount']++;const _0x171465=F(_0x46a2c7,_0x40b3a3['path']);_0x8be28e=_0x8be28e['updateChild'](_0x171465,_0x40b3a3['currentOutputSnapshotRaw']);}const _0x16eff8=_0x8be28e['val'](!0x0),_0x23f562=_0x46a2c7;_0x20266b['server_']['put'](_0x23f562['toString'](),_0x16eff8,_0x4025d9=>{ut(_0x20266b,'transaction\x20put\x20response',{'path':_0x23f562['toString'](),'status':_0x4025d9});let _0x1196b7=[];if(_0x4025d9==='ok'){const _0x4dc20f=[];for(let _0x57f7e7=0x0;_0x57f7e7<_0x558db6['length'];_0x57f7e7++)_0x558db6[_0x57f7e7]['status']=0x2,_0x1196b7=_0x1196b7['concat'](pe(_0x20266b['serverSyncTree_'],_0x558db6[_0x57f7e7]['currentWriteId'])),_0x558db6[_0x57f7e7]['onComplete']&&_0x4dc20f['push'](()=>_0x558db6[_0x57f7e7]['onComplete'](null,!0x0,_0x558db6[_0x57f7e7]['currentOutputSnapshotResolved'])),_0x558db6[_0x57f7e7]['unwatcher']();$n(_0x20266b,Un(_0x20266b['transactionQueueTree_'],_0x46a2c7)),Hn(_0x20266b,_0x20266b['transactionQueueTree_']),V(_0x20266b['eventQueue_'],_0x46a2c7,_0x1196b7);for(let _0x21c9d3=0x0;_0x21c9d3<_0x4dc20f['length'];_0x21c9d3++)lt(_0x4dc20f[_0x21c9d3]);}else{if(_0x4025d9==='datastale'){for(let _0x35de56=0x0;_0x35de56<_0x558db6['length'];_0x35de56++)_0x558db6[_0x35de56]['status']===0x3?_0x558db6[_0x35de56]['status']=0x4:_0x558db6[_0x35de56]['status']=0x0;}else{U('transaction\x20at\x20'+_0x23f562['toString']()+'\x20failed:\x20'+_0x4025d9);for(let _0x107070=0x0;_0x107070<_0x558db6['length'];_0x107070++)_0x558db6[_0x107070]['status']=0x4,_0x558db6[_0x107070]['abortReason']=_0x4025d9;}st(_0x20266b,_0x46a2c7);}},_0x2f2825);}function st(_0x3eada5,_0x431ec6){const _0x5d8db2=ca(_0x3eada5,_0x431ec6),_0x46b709=Gt(_0x5d8db2),_0xdf8d07=la(_0x3eada5,_0x5d8db2);return Ad(_0x3eada5,_0xdf8d07,_0x46b709),_0x46b709;}function Ad(_0x37ef77,_0x469e36,_0x59b3a7){if(_0x469e36['length']===0x0)return;const _0x2016a9=[];let _0x44f733=[];const _0x827101=_0x469e36['filter'](_0x58183d=>_0x58183d['status']===0x0)['map'](_0x5c5e9=>_0x5c5e9['currentWriteId']);for(let _0x13badb=0x0;_0x13badb<_0x469e36['length'];_0x13badb++){const _0x51e39b=_0x469e36[_0x13badb],_0x18f1e9=F(_0x59b3a7,_0x51e39b['path']);let _0x181861=!0x1,_0x3a2564;if(f(_0x18f1e9!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x51e39b['status']===0x4)_0x181861=!0x0,_0x3a2564=_0x51e39b['abortReason'],_0x44f733=_0x44f733['concat'](pe(_0x37ef77['serverSyncTree_'],_0x51e39b['currentWriteId'],!0x0));else{if(_0x51e39b['status']===0x0){if(_0x51e39b['retryCount']>=_d)_0x181861=!0x0,_0x3a2564='maxretry',_0x44f733=_0x44f733['concat'](pe(_0x37ef77['serverSyncTree_'],_0x51e39b['currentWriteId'],!0x0));else{const _0x332a53=ys(_0x37ef77,_0x51e39b['path'],_0x827101);_0x51e39b['currentInputSnapshot']=_0x332a53;const _0x6099ab=_0x469e36[_0x13badb]['update'](_0x332a53['val']());if(_0x6099ab!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x6099ab,_0x51e39b['path']);let _0x132e55=N(_0x6099ab);typeof _0x6099ab=='object'&&_0x6099ab!=null&&Y(_0x6099ab,'.priority')||(_0x132e55=_0x132e55['updatePriority'](_0x332a53['getPriority']()));const _0x54a4c8=_0x51e39b['currentWriteId'],_0x218089=jt(_0x37ef77),_0x944670=hs(_0x132e55,_0x332a53,_0x218089);_0x51e39b['currentOutputSnapshotRaw']=_0x132e55,_0x51e39b['currentOutputSnapshotResolved']=_0x944670,_0x51e39b['currentWriteId']=Vn(_0x37ef77),_0x827101['splice'](_0x827101['indexOf'](_0x54a4c8),0x1),_0x44f733=_0x44f733['concat'](ss(_0x37ef77['serverSyncTree_'],_0x51e39b['path'],_0x944670,_0x51e39b['currentWriteId'],_0x51e39b['applyLocally'])),_0x44f733=_0x44f733['concat'](pe(_0x37ef77['serverSyncTree_'],_0x54a4c8,!0x0));}else _0x181861=!0x0,_0x3a2564='nodata',_0x44f733=_0x44f733['concat'](pe(_0x37ef77['serverSyncTree_'],_0x51e39b['currentWriteId'],!0x0));}}}V(_0x37ef77['eventQueue_'],_0x59b3a7,_0x44f733),_0x44f733=[],_0x181861&&(_0x469e36[_0x13badb]['status']=0x2,function(_0x675d3d){setTimeout(_0x675d3d,Math['floor'](0x0));}(_0x469e36[_0x13badb]['unwatcher']),_0x469e36[_0x13badb]['onComplete']&&(_0x3a2564==='nodata'?_0x2016a9['push'](()=>_0x469e36[_0x13badb]['onComplete'](null,!0x1,_0x469e36[_0x13badb]['currentInputSnapshot'])):_0x2016a9['push'](()=>_0x469e36[_0x13badb]['onComplete'](new Error(_0x3a2564),!0x1,null))));}$n(_0x37ef77,_0x37ef77['transactionQueueTree_']);for(let _0x8c6e34=0x0;_0x8c6e34<_0x2016a9['length'];_0x8c6e34++)lt(_0x2016a9[_0x8c6e34]);Hn(_0x37ef77,_0x37ef77['transactionQueueTree_']);}function ca(_0xa1119e,_0x4ac534){let _0x33ed5d,_0xa474e1=_0xa1119e['transactionQueueTree_'];for(_0x33ed5d=y(_0x4ac534);_0x33ed5d!==null&&Ge(_0xa474e1)===void 0x0;)_0xa474e1=Un(_0xa474e1,_0x33ed5d),_0x4ac534=b(_0x4ac534),_0x33ed5d=y(_0x4ac534);return _0xa474e1;}function la(_0x3ce5ff,_0x27c704){const _0x4f8402=[];return ha(_0x3ce5ff,_0x27c704,_0x4f8402),_0x4f8402['sort']((_0x14f17c,_0x10cadd)=>_0x14f17c['order']-_0x10cadd['order']),_0x4f8402;}function ha(_0x17ea41,_0x5e7cbd,_0x44966a){const _0x119830=Ge(_0x5e7cbd);if(_0x119830){for(let _0x429a5e=0x0;_0x429a5e<_0x119830['length'];_0x429a5e++)_0x44966a['push'](_0x119830[_0x429a5e]);}Wn(_0x5e7cbd,_0x1294c4=>{ha(_0x17ea41,_0x1294c4,_0x44966a);});}function $n(_0x503e54,_0x271db9){const _0x4e2421=Ge(_0x271db9);if(_0x4e2421){let _0x14ec00=0x0;for(let _0x535374=0x0;_0x535374<_0x4e2421['length'];_0x535374++)_0x4e2421[_0x535374]['status']!==0x2&&(_0x4e2421[_0x14ec00]=_0x4e2421[_0x535374],_0x14ec00++);_0x4e2421['length']=_0x14ec00,fs(_0x271db9,_0x4e2421['length']>0x0?_0x4e2421:void 0x0);}Wn(_0x271db9,_0x6e3852=>{$n(_0x503e54,_0x6e3852);});}function vs(_0x3f0c75,_0x41941e){const _0x18f911=Gt(ca(_0x3f0c75,_0x41941e)),_0x4edc97=Un(_0x3f0c75['transactionQueueTree_'],_0x41941e);return sd(_0x4edc97,_0xee9c8f=>{ai(_0x3f0c75,_0xee9c8f);}),ai(_0x3f0c75,_0x4edc97),ta(_0x4edc97,_0x2029bf=>{ai(_0x3f0c75,_0x2029bf);}),_0x18f911;}function ai(_0x245a59,_0x463035){const _0x411447=Ge(_0x463035);if(_0x411447){const _0x378b8c=[];let _0x583583=[],_0x4d56c6=-0x1;for(let _0x10ea36=0x0;_0x10ea36<_0x411447['length'];_0x10ea36++)_0x411447[_0x10ea36]['status']===0x3||(_0x411447[_0x10ea36]['status']===0x1?(f(_0x4d56c6===_0x10ea36-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4d56c6=_0x10ea36,_0x411447[_0x10ea36]['status']=0x3,_0x411447[_0x10ea36]['abortReason']='set'):(f(_0x411447[_0x10ea36]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x411447[_0x10ea36]['unwatcher'](),_0x583583=_0x583583['concat'](pe(_0x245a59['serverSyncTree_'],_0x411447[_0x10ea36]['currentWriteId'],!0x0)),_0x411447[_0x10ea36]['onComplete']&&_0x378b8c['push'](_0x411447[_0x10ea36]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4d56c6===-0x1?fs(_0x463035,void 0x0):_0x411447['length']=_0x4d56c6+0x1,V(_0x245a59['eventQueue_'],Gt(_0x463035),_0x583583);for(let _0x25e600=0x0;_0x25e600<_0x378b8c['length'];_0x25e600++)lt(_0x378b8c[_0x25e600]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x5d0c17){let _0x21e8f9='';const _0x46f0db=_0x5d0c17['split']('/');for(let _0x4c1284=0x0;_0x4c1284<_0x46f0db['length'];_0x4c1284++)if(_0x46f0db[_0x4c1284]['length']>0x0){let _0x16a181=_0x46f0db[_0x4c1284];try{_0x16a181=decodeURIComponent(_0x16a181['replace'](/\+/g,'\x20'));}catch{}_0x21e8f9+='/'+_0x16a181;}return _0x21e8f9;}function Nd(_0x57ca0d){const _0x53b804={};_0x57ca0d['charAt'](0x0)==='?'&&(_0x57ca0d=_0x57ca0d['substring'](0x1));for(const _0xc093d3 of _0x57ca0d['split']('&')){if(_0xc093d3['length']===0x0)continue;const _0x549d36=_0xc093d3['split']('=');_0x549d36['length']===0x2?_0x53b804[decodeURIComponent(_0x549d36[0x0])]=decodeURIComponent(_0x549d36[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0xc093d3+'\x27\x20in\x20query\x20\x27'+_0x57ca0d+'\x27');}return _0x53b804;}const gr=function(_0x29273f,_0x3c51d1){const _0x2dbcbf=Pd(_0x29273f),_0x3c2767=_0x2dbcbf['namespace'];_0x2dbcbf['domain']==='firebase.com'&&oe(_0x2dbcbf['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3c2767||_0x3c2767==='undefined')&&_0x2dbcbf['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2dbcbf['secure']||Bl();const _0x587a5e=_0x2dbcbf['scheme']==='ws'||_0x2dbcbf['scheme']==='wss';return{'repoInfo':new _o(_0x2dbcbf['host'],_0x2dbcbf['secure'],_0x3c2767,_0x587a5e,_0x3c51d1,'',_0x3c2767!==_0x2dbcbf['subdomain']),'path':new C(_0x2dbcbf['pathString'])};},Pd=function(_0x512bbc){let _0x5ddc2c='',_0x3ccdc3='',_0x2caa1b='',_0x34a289='',_0x415adb='',_0x3d818d=!0x0,_0x118759='https',_0x554770=0x1bb;if(typeof _0x512bbc=='string'){let _0x892129=_0x512bbc['indexOf']('//');_0x892129>=0x0&&(_0x118759=_0x512bbc['substring'](0x0,_0x892129-0x1),_0x512bbc=_0x512bbc['substring'](_0x892129+0x2));let _0x144238=_0x512bbc['indexOf']('/');_0x144238===-0x1&&(_0x144238=_0x512bbc['length']);let _0xea9620=_0x512bbc['indexOf']('?');_0xea9620===-0x1&&(_0xea9620=_0x512bbc['length']),_0x5ddc2c=_0x512bbc['substring'](0x0,Math['min'](_0x144238,_0xea9620)),_0x144238<_0xea9620&&(_0x34a289=kd(_0x512bbc['substring'](_0x144238,_0xea9620)));const _0x228e1e=Nd(_0x512bbc['substring'](Math['min'](_0x512bbc['length'],_0xea9620)));_0x892129=_0x5ddc2c['indexOf'](':'),_0x892129>=0x0?(_0x3d818d=_0x118759==='https'||_0x118759==='wss',_0x554770=parseInt(_0x5ddc2c['substring'](_0x892129+0x1),0xa)):_0x892129=_0x5ddc2c['length'];const _0x47e4a2=_0x5ddc2c['slice'](0x0,_0x892129);if(_0x47e4a2['toLowerCase']()==='localhost')_0x3ccdc3='localhost';else{if(_0x47e4a2['split']('.')['length']<=0x2)_0x3ccdc3=_0x47e4a2;else{const _0xa868d0=_0x5ddc2c['indexOf']('.');_0x2caa1b=_0x5ddc2c['substring'](0x0,_0xa868d0)['toLowerCase'](),_0x3ccdc3=_0x5ddc2c['substring'](_0xa868d0+0x1),_0x415adb=_0x2caa1b;}}'ns'in _0x228e1e&&(_0x415adb=_0x228e1e['ns']);}return{'host':_0x5ddc2c,'port':_0x554770,'domain':_0x3ccdc3,'subdomain':_0x2caa1b,'secure':_0x3d818d,'scheme':_0x118759,'pathString':_0x34a289,'namespace':_0x415adb};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0xa808ee=0x0;const _0x36b7ce=[];return function(_0x1b9ac4){const _0x40ef39=_0x1b9ac4===_0xa808ee;_0xa808ee=_0x1b9ac4;let _0x50abcb;const _0x361de3=new Array(0x8);for(_0x50abcb=0x7;_0x50abcb>=0x0;_0x50abcb--)_0x361de3[_0x50abcb]=mr['charAt'](_0x1b9ac4%0x40),_0x1b9ac4=Math['floor'](_0x1b9ac4/0x40);f(_0x1b9ac4===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x24b9a0=_0x361de3['join']('');if(_0x40ef39){for(_0x50abcb=0xb;_0x50abcb>=0x0&&_0x36b7ce[_0x50abcb]===0x3f;_0x50abcb--)_0x36b7ce[_0x50abcb]=0x0;_0x36b7ce[_0x50abcb]++;}else{for(_0x50abcb=0x0;_0x50abcb<0xc;_0x50abcb++)_0x36b7ce[_0x50abcb]=Math['floor'](Math['random']()*0x40);}for(_0x50abcb=0x0;_0x50abcb<0xc;_0x50abcb++)_0x24b9a0+=mr['charAt'](_0x36b7ce[_0x50abcb]);return f(_0x24b9a0['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x24b9a0;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x47692b,_0x387e58,_0x51079f,_0x302872){this['eventType']=_0x47692b,this['eventRegistration']=_0x387e58,this['snapshot']=_0x51079f,this['prevName']=_0x302872;}['getPath'](){const _0x280db4=this['snapshot']['ref'];return this['eventType']==='value'?_0x280db4['_path']:_0x280db4['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x3d9acf,_0x584262,_0x4f11fd){this['eventRegistration']=_0x3d9acf,this['error']=_0x584262,this['path']=_0x4f11fd;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x348268,_0x26c297){this['snapshotCallback']=_0x348268,this['cancelCallback']=_0x26c297;}['onValue'](_0x257099,_0x2aadf2){this['snapshotCallback']['call'](null,_0x257099,_0x2aadf2);}['onCancel'](_0xd219b3){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0xd219b3);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x24c396){return this['snapshotCallback']===_0x24c396['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x24c396['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x24c396['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x47c4b9,_0x248e91,_0x52f697,_0x3ccdce){this['_repo']=_0x47c4b9,this['_path']=_0x248e91,this['_queryParams']=_0x52f697,this['_orderByCalled']=_0x3ccdce;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x41e89c=nr(this['_queryParams']),_0x1a73ac=Bi(_0x41e89c);return _0x1a73ac==='{}'?'default':_0x1a73ac;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x2c5cb5){if(_0x2c5cb5=k(_0x2c5cb5),!(_0x2c5cb5 instanceof be))return!0x1;const _0x5082be=this['_repo']===_0x2c5cb5['_repo'],_0x2e7ecd=qi(this['_path'],_0x2c5cb5['_path']),_0x58e8db=this['_queryIdentifier']===_0x2c5cb5['_queryIdentifier'];return _0x5082be&&_0x2e7ecd&&_0x58e8db;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0xf5f580,_0x14ba66){if(_0xf5f580['_orderByCalled']===!0x0)throw new Error(_0x14ba66+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x14b5f7){let _0x8411b0=null,_0x5a1f69=null;if(_0x14b5f7['hasStart']()&&(_0x8411b0=_0x14b5f7['getIndexStartValue']()),_0x14b5f7['hasEnd']()&&(_0x5a1f69=_0x14b5f7['getIndexEndValue']()),_0x14b5f7['getIndex']()===ye){const _0x3d4a9a='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x39963b='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x14b5f7['hasStart']()){if(_0x14b5f7['getIndexStartName']()!==xe)throw new Error(_0x3d4a9a);if(typeof _0x8411b0!='string')throw new Error(_0x39963b);}if(_0x14b5f7['hasEnd']()){if(_0x14b5f7['getIndexEndName']()!==Ie)throw new Error(_0x3d4a9a);if(typeof _0x5a1f69!='string')throw new Error(_0x39963b);}}else{if(_0x14b5f7['getIndex']()===R){if(_0x8411b0!=null&&!Cn(_0x8411b0)||_0x5a1f69!=null&&!Cn(_0x5a1f69))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x14b5f7['getIndex']()instanceof Ki||_0x14b5f7['getIndex']()===Po,'unknown\x20index\x20type.'),_0x8411b0!=null&&typeof _0x8411b0=='object'||_0x5a1f69!=null&&typeof _0x5a1f69=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x4b375e){if(_0x4b375e['hasStart']()&&_0x4b375e['hasEnd']()&&_0x4b375e['hasLimit']()&&!_0x4b375e['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x403e0b,_0x432e52){super(_0x403e0b,_0x432e52,new Qi(),!0x1);}get['parent'](){const _0x5c277a=To(this['_path']);return _0x5c277a===null?null:new Z(this['_repo'],_0x5c277a);}get['root'](){let _0x4fd883=this;for(;_0x4fd883['parent']!==null;)_0x4fd883=_0x4fd883['parent'];return _0x4fd883;}}class rt{constructor(_0x388969,_0x1cc54d,_0x2d2157){this['_node']=_0x388969,this['ref']=_0x1cc54d,this['_index']=_0x2d2157;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0xffd3f4){const _0x3c0f46=new C(_0xffd3f4),_0x5e09b1=Lt(this['ref'],_0xffd3f4);return new rt(this['_node']['getChild'](_0x3c0f46),_0x5e09b1,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4d123e){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x23aac4,_0x456242)=>_0x4d123e(new rt(_0x456242,Lt(this['ref'],_0x23aac4),R)));}['hasChild'](_0x13c2a4){const _0x345f13=new C(_0x13c2a4);return!this['_node']['getChild'](_0x345f13)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x1d5144,_0x41c1f8){return _0x1d5144=k(_0x1d5144),_0x1d5144['_checkNotDeleted']('ref'),_0x41c1f8!==void 0x0?Lt(_0x1d5144['_root'],_0x41c1f8):_0x1d5144['_root'];}function Lt(_0x2fcd9a,_0x2362d5){return _0x2fcd9a=k(_0x2fcd9a),y(_0x2fcd9a['_path'])===null?ud('child','path',_0x2362d5):_s('child','path',_0x2362d5),new Z(_0x2fcd9a['_repo'],A(_0x2fcd9a['_path'],_0x2362d5));}function d_(_0x43ddf1,_0x2e44b6){_0x43ddf1=k(_0x43ddf1),gs('push',_0x43ddf1['_path']),qt('push',_0x2e44b6,_0x43ddf1['_path'],!0x0);const _0x4a342c=oa(_0x43ddf1['_repo']),_0x300100=Od(_0x4a342c),_0x2ca98d=Lt(_0x43ddf1,_0x300100),_0x32b566=Lt(_0x43ddf1,_0x300100);let _0x2a01cc;return _0x2e44b6!=null?_0x2a01cc=Ld(_0x32b566,_0x2e44b6)['then'](()=>_0x32b566):_0x2a01cc=Promise['resolve'](_0x32b566),_0x2ca98d['then']=_0x2a01cc['then']['bind'](_0x2a01cc),_0x2ca98d['catch']=_0x2a01cc['then']['bind'](_0x2a01cc,void 0x0),_0x2ca98d;}function Ld(_0x2e701b,_0x49e98d){_0x2e701b=k(_0x2e701b),gs('set',_0x2e701b['_path']),qt('set',_0x49e98d,_0x2e701b['_path'],!0x1);const _0x494511=new Ve();return Ed(_0x2e701b['_repo'],_0x2e701b['_path'],_0x49e98d,null,_0x494511['wrapCallback'](()=>{})),_0x494511['promise'];}function f_(_0x5cf96d,_0x2b38f2){hd('update',_0x2b38f2,_0x5cf96d['_path']);const _0x21d353=new Ve();return Id(_0x5cf96d['_repo'],_0x5cf96d['_path'],_0x2b38f2,_0x21d353['wrapCallback'](()=>{})),_0x21d353['promise'];}function p_(_0x3ad12e){_0x3ad12e=k(_0x3ad12e);const _0x382c2c=new ua(()=>{}),_0x43673c=new qn(_0x382c2c);return vd(_0x3ad12e['_repo'],_0x3ad12e,_0x43673c)['then'](_0x13d3d1=>new rt(_0x13d3d1,new Z(_0x3ad12e['_repo'],_0x3ad12e['_path']),_0x3ad12e['_queryParams']['getIndex']()));}class qn{constructor(_0x5216f5){this['callbackContext']=_0x5216f5;}['respondsTo'](_0x4e596b){return _0x4e596b==='value';}['createEvent'](_0x2350d8,_0x28a656){const _0x134ae8=_0x28a656['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x2350d8['snapshotNode'],new Z(_0x28a656['_repo'],_0x28a656['_path']),_0x134ae8));}['getEventRunner'](_0x1bc3c2){return _0x1bc3c2['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1bc3c2['error']):()=>this['callbackContext']['onValue'](_0x1bc3c2['snapshot'],null);}['createCancelEvent'](_0x3ec4e6,_0x55632c){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x3ec4e6,_0x55632c):null;}['matches'](_0x21b4ef){return _0x21b4ef instanceof qn?!_0x21b4ef['callbackContext']||!this['callbackContext']?!0x0:_0x21b4ef['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x465046,_0x3d5c74,_0x596bde,_0x569cf3,_0x1ccf42){const _0x277b13=new ua(_0x596bde,void 0x0),_0x49221e=new qn(_0x277b13);return Cd(_0x465046['_repo'],_0x465046,_0x49221e),()=>Td(_0x465046['_repo'],_0x465046,_0x49221e);}function Fd(_0x439e64,_0x58ce16,_0x41256c,_0x3eb3db){return xd(_0x439e64,'value',_0x58ce16);}class dt{}class pa extends dt{constructor(_0x115d1d,_0x225427){super(),this['_value']=_0x115d1d,this['_key']=_0x225427,this['type']='endAt';}['_apply'](_0x2f9bac){qt('endAt',this['_value'],_0x2f9bac['_path'],!0x0);const _0x419dc6=Kh(_0x2f9bac['_queryParams'],this['_value'],this['_key']);if(fa(_0x419dc6),Gn(_0x419dc6),_0x2f9bac['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x2f9bac['_repo'],_0x2f9bac['_path'],_0x419dc6,_0x2f9bac['_orderByCalled']);}}function __(_0x2dd575,_0x442efd){return new pa(_0x2dd575,_0x442efd);}class _a extends dt{constructor(_0x1b572b,_0x8d1fc5){super(),this['_value']=_0x1b572b,this['_key']=_0x8d1fc5,this['type']='startAt';}['_apply'](_0x109d40){qt('startAt',this['_value'],_0x109d40['_path'],!0x0);const _0x1a08bf=jh(_0x109d40['_queryParams'],this['_value'],this['_key']);if(fa(_0x1a08bf),Gn(_0x1a08bf),_0x109d40['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x109d40['_repo'],_0x109d40['_path'],_0x1a08bf,_0x109d40['_orderByCalled']);}}function g_(_0x36887c=null,_0x203656){return new _a(_0x36887c,_0x203656);}class Ud extends dt{constructor(_0x35fb46){super(),this['_limit']=_0x35fb46,this['type']='limitToFirst';}['_apply'](_0xdb7ffe){if(_0xdb7ffe['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0xdb7ffe['_repo'],_0xdb7ffe['_path'],zh(_0xdb7ffe['_queryParams'],this['_limit']),_0xdb7ffe['_orderByCalled']);}}function m_(_0x28a8cb){if(Math['floor'](_0x28a8cb)!==_0x28a8cb||_0x28a8cb<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x28a8cb);}class Wd extends dt{constructor(_0x1e1952){super(),this['_path']=_0x1e1952,this['type']='orderByChild';}['_apply'](_0x32f614){da(_0x32f614,'orderByChild');const _0x4bd6c6=new C(this['_path']);if(v(_0x4bd6c6))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xb94b0a=new Ki(_0x4bd6c6),_0x3a03db=Do(_0x32f614['_queryParams'],_0xb94b0a);return Gn(_0x3a03db),new be(_0x32f614['_repo'],_0x32f614['_path'],_0x3a03db,!0x0);}}function y_(_0x2b3930){if(_0x2b3930==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2b3930==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2b3930==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x2b3930),new Wd(_0x2b3930);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2b19c0){da(_0x2b19c0,'orderByKey');const _0x5a964a=Do(_0x2b19c0['_queryParams'],ye);return Gn(_0x5a964a),new be(_0x2b19c0['_repo'],_0x2b19c0['_path'],_0x5a964a,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x4592cf,_0x36b1c2){super(),this['_value']=_0x4592cf,this['_key']=_0x36b1c2,this['type']='equalTo';}['_apply'](_0x142bda){if(qt('equalTo',this['_value'],_0x142bda['_path'],!0x1),_0x142bda['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x142bda['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x142bda));}}function E_(_0x5a24ff,_0x271117){return new Vd(_0x5a24ff,_0x271117);}function I_(_0x2e6b11,..._0x5a5b10){let _0x5de91c=k(_0x2e6b11);for(const _0x49026e of _0x5a5b10)_0x5de91c=_0x49026e['_apply'](_0x5de91c);return _0x5de91c;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x3e751c,_0x556e10,_0x5c620a,_0x4c6100){const _0x1b66a6=_0x556e10['lastIndexOf'](':'),_0x496b68=_0x556e10['substring'](0x0,_0x1b66a6),_0xb8be1d=Wt(_0x496b68);_0x3e751c['repoInfo_']=new _o(_0x556e10,_0xb8be1d,_0x3e751c['repoInfo_']['namespace'],_0x3e751c['repoInfo_']['webSocketOnly'],_0x3e751c['repoInfo_']['nodeAdmin'],_0x3e751c['repoInfo_']['persistenceKey'],_0x3e751c['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x5c620a),_0x4c6100&&(_0x3e751c['authTokenProvider_']=_0x4c6100);}function qd(_0x2b7d2f,_0x420ce0,_0x2fe6c7,_0x170ad9,_0xd69b39){let _0x2245cb=_0x170ad9||_0x2b7d2f['options']['databaseURL'];_0x2245cb===void 0x0&&(_0x2b7d2f['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2b7d2f['options']['projectId']),_0x2245cb=_0x2b7d2f['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x1ee682=gr(_0x2245cb,_0xd69b39),_0x4f68cb=_0x1ee682['repoInfo'],_0xe7e75e;typeof process<'u'&&Us&&(_0xe7e75e=Us[Hd]),_0xe7e75e?(_0x2245cb='http://'+_0xe7e75e+'?ns='+_0x4f68cb['namespace'],_0x1ee682=gr(_0x2245cb,_0xd69b39),_0x4f68cb=_0x1ee682['repoInfo']):_0x1ee682['repoInfo']['secure'];const _0x5311bf=new Jl(_0x2b7d2f['name'],_0x2b7d2f['options'],_0x420ce0);dd('Invalid\x20Firebase\x20Database\x20URL',_0x1ee682),v(_0x1ee682['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3c6607=jd(_0x4f68cb,_0x2b7d2f,_0x5311bf,new Ql(_0x2b7d2f,_0x2fe6c7));return new Kd(_0x3c6607,_0x2b7d2f);}function zd(_0x5a5c3b,_0x38e180){const _0x289a17=ki[_0x38e180];(!_0x289a17||_0x289a17[_0x5a5c3b['key']]!==_0x5a5c3b)&&oe('Database\x20'+_0x38e180+'('+_0x5a5c3b['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x5a5c3b),delete _0x289a17[_0x5a5c3b['key']];}function jd(_0x1d8576,_0x236506,_0x460628,_0x3cd684){let _0x172d07=ki[_0x236506['name']];_0x172d07||(_0x172d07={},ki[_0x236506['name']]=_0x172d07);let _0x3a6994=_0x172d07[_0x1d8576['toURLString']()];return _0x3a6994&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3a6994=new gd(_0x1d8576,$d,_0x460628,_0x3cd684),_0x172d07[_0x1d8576['toURLString']()]=_0x3a6994,_0x3a6994;}class Kd{constructor(_0x5cadad,_0x40625c){this['_repoInternal']=_0x5cadad,this['app']=_0x40625c,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4bbdd7){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x4bbdd7+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x5b651f=Qr(),_0x4d5e46){const _0x566958=Ui(_0x5b651f,'database')['getImmediate']({'identifier':_0x4d5e46});if(!_0x566958['_instanceStarted']){const _0x1efec4=ac('database');_0x1efec4&&Yd(_0x566958,..._0x1efec4);}return _0x566958;}function Yd(_0x5c3612,_0x1b9e78,_0x25f22c,_0x46c595={}){_0x5c3612=k(_0x5c3612),_0x5c3612['_checkNotDeleted']('useEmulator');const _0x171253=_0x1b9e78+':'+_0x25f22c,_0x1c064e=_0x5c3612['_repoInternal'];if(_0x5c3612['_instanceStarted']){if(_0x171253===_0x5c3612['_repoInternal']['repoInfo_']['host']&&De(_0x46c595,_0x1c064e['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4078cb;if(_0x1c064e['repoInfo_']['nodeAdmin'])_0x46c595['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4078cb=new tn(tn['OWNER']);else{if(_0x46c595['mockUserToken']){const _0x438ef0=typeof _0x46c595['mockUserToken']=='string'?_0x46c595['mockUserToken']:cc(_0x46c595['mockUserToken'],_0x5c3612['app']['options']['projectId']);_0x4078cb=new tn(_0x438ef0);}}Wt(_0x1b9e78)&&jr(_0x1b9e78),Gd(_0x1c064e,_0x171253,_0x46c595,_0x4078cb);}function C_(_0x49f2b5){_0x49f2b5=k(_0x49f2b5),_0x49f2b5['_checkNotDeleted']('goOffline'),aa(_0x49f2b5['_repo']);}function T_(_0x26b6c5){_0x26b6c5=k(_0x26b6c5),_0x26b6c5['_checkNotDeleted']('goOnline'),Sd(_0x26b6c5['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x4dfefd){Ll(ct),et(new Me('database',(_0x257522,{instanceIdentifier:_0x3a66fd})=>{const _0x5b9e02=_0x257522['getProvider']('app')['getImmediate'](),_0x19801e=_0x257522['getProvider']('auth-internal'),_0x52e72f=_0x257522['getProvider']('app-check-internal');return qd(_0x5b9e02,_0x19801e,_0x52e72f,_0x3a66fd);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x4dfefd),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x467d8e,_0x5eb635){this['committed']=_0x467d8e,this['snapshot']=_0x5eb635;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x359afa,_0x5d179a,_0xd1af4b){if(_0x359afa=k(_0x359afa),gs('Reference.transaction',_0x359afa['_path']),_0x359afa['key']==='.length'||_0x359afa['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x359afa['key']+'\x20is\x20a\x20read-only\x20object.';const _0x163301=!0x0,_0x3d7610=new Ve(),_0x578ba9=(_0x283b43,_0x388bc7,_0x3d4f99)=>{let _0x29af1f=null;_0x283b43?_0x3d7610['reject'](_0x283b43):(_0x29af1f=new rt(_0x3d4f99,new Z(_0x359afa['_repo'],_0x359afa['_path']),R),_0x3d7610['resolve'](new Xd(_0x388bc7,_0x29af1f)));},_0x580cd7=Fd(_0x359afa,()=>{});return bd(_0x359afa['_repo'],_0x359afa['_path'],_0x5d179a,_0x578ba9,_0x580cd7,_0x163301),_0x3d7610['promise'];}ie['prototype']['simpleListen']=function(_0x3dcbf6,_0x406b31){this['sendRequest']('q',{'p':_0x3dcbf6},_0x406b31);},ie['prototype']['echo']=function(_0x298855,_0xd53e2d){this['sendRequest']('echo',{'d':_0x298855},_0xd53e2d);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0xa88d9c,..._0x37cade){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0xa88d9c,..._0x37cade);}function nn(_0x1b8b89,..._0x154da3){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x1b8b89,..._0x154da3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x3b37a2,..._0x245142){throw Es(_0x3b37a2,..._0x245142);}function J(_0x4601ec,..._0x25b1dc){return Es(_0x4601ec,..._0x25b1dc);}function ya(_0x44e309,_0x50268f,_0x5ae350){const _0x4a0412={...Zd(),[_0x50268f]:_0x5ae350};return new Ut('auth','Firebase',_0x4a0412)['create'](_0x50268f,{'appName':_0x44e309['name']});}function se(_0x534979){return ya(_0x534979,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x2e535d,..._0x2a3dfa){if(typeof _0x2e535d!='string'){const _0x19df3b=_0x2a3dfa[0x0],_0x3d7910=[..._0x2a3dfa['slice'](0x1)];return _0x3d7910[0x0]&&(_0x3d7910[0x0]['appName']=_0x2e535d['name']),_0x2e535d['_errorFactory']['create'](_0x19df3b,..._0x3d7910);}return ma['create'](_0x2e535d,..._0x2a3dfa);}function m(_0x3795ef,_0x49f6b4,..._0x29e719){if(!_0x3795ef)throw Es(_0x49f6b4,..._0x29e719);}function te(_0x1812db){const _0x8b33ed='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1812db;throw nn(_0x8b33ed),new Error(_0x8b33ed);}function ae(_0x5b7752,_0x424a8c){_0x5b7752||te(_0x424a8c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x500681;return typeof self<'u'&&((_0x500681=self['location'])==null?void 0x0:_0x500681['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x1daa97;return typeof self<'u'&&((_0x1daa97=self['location'])==null?void 0x0:_0x1daa97['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x443bde=navigator;return _0x443bde['languages']&&_0x443bde['languages'][0x0]||_0x443bde['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x2cc47a,_0x1650e7){this['shortDelay']=_0x2cc47a,this['longDelay']=_0x1650e7,ae(_0x1650e7>_0x2cc47a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0xa24bc,_0x35c6c8){ae(_0xa24bc['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3db922}=_0xa24bc['emulator'];return _0x35c6c8?''+_0x3db922+(_0x35c6c8['startsWith']('/')?_0x35c6c8['slice'](0x1):_0x35c6c8):_0x3db922;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x3a480a,_0x12946b,_0x35c57f){this['fetchImpl']=_0x3a480a,_0x12946b&&(this['headersImpl']=_0x12946b),_0x35c57f&&(this['responseImpl']=_0x35c57f);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x1dc8e8,_0x85c9b6){return _0x1dc8e8['tenantId']&&!_0x85c9b6['tenantId']?{..._0x85c9b6,'tenantId':_0x1dc8e8['tenantId']}:_0x85c9b6;}async function Ae(_0x4b67f5,_0x2e63e9,_0x2c2142,_0x48e634,_0x2fb0e8={}){return Ea(_0x4b67f5,_0x2fb0e8,async()=>{let _0xc74905={},_0x1ca089={};_0x48e634&&(_0x2e63e9==='GET'?_0x1ca089=_0x48e634:_0xc74905={'body':JSON['stringify'](_0x48e634)});const _0x2c1b97=at({..._0x1ca089,'key':_0x4b67f5['config']['apiKey']})['slice'](0x1),_0x5611fe=await _0x4b67f5['_getAdditionalHeaders']();_0x5611fe['Content-Type']='application/json',_0x4b67f5['languageCode']&&(_0x5611fe['X-Firebase-Locale']=_0x4b67f5['languageCode']);const _0xb83894={'method':_0x2e63e9,'headers':_0x5611fe,..._0xc74905};return lc()||(_0xb83894['referrerPolicy']='strict-origin-when-cross-origin'),_0x4b67f5['emulatorConfig']&&Wt(_0x4b67f5['emulatorConfig']['host'])&&(_0xb83894['credentials']='include'),va['fetch']()(await Ia(_0x4b67f5,_0x4b67f5['config']['apiHost'],_0x2c2142,_0x2c1b97),_0xb83894);});}async function Ea(_0x281f04,_0x25c07f,_0x13488e){_0x281f04['_canInitEmulator']=!0x1;const _0x5eb0e0={...rf,..._0x25c07f};try{const _0x410f4b=new lf(_0x281f04),_0x3d4031=await Promise['race']([_0x13488e(),_0x410f4b['promise']]);_0x410f4b['clearNetworkTimeout']();const _0x287236=await _0x3d4031['json']();if('needConfirmation'in _0x287236)throw en(_0x281f04,'account-exists-with-different-credential',_0x287236);if(_0x3d4031['ok']&&!('errorMessage'in _0x287236))return _0x287236;{const _0x487a8c=_0x3d4031['ok']?_0x287236['errorMessage']:_0x287236['error']['message'],[_0x42a971,_0x377b65]=_0x487a8c['split']('\x20:\x20');if(_0x42a971==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x281f04,'credential-already-in-use',_0x287236);if(_0x42a971==='EMAIL_EXISTS')throw en(_0x281f04,'email-already-in-use',_0x287236);if(_0x42a971==='USER_DISABLED')throw en(_0x281f04,'user-disabled',_0x287236);const _0x45d3f5=_0x5eb0e0[_0x42a971]||_0x42a971['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x377b65)throw ya(_0x281f04,_0x45d3f5,_0x377b65);K(_0x281f04,_0x45d3f5);}}catch(_0x16c7b9){if(_0x16c7b9 instanceof Se)throw _0x16c7b9;K(_0x281f04,'network-request-failed',{'message':String(_0x16c7b9)});}}async function Yt(_0x35e943,_0xf734c1,_0x41b3ad,_0x44f67e,_0x4c5edd={}){const _0x2a534c=await Ae(_0x35e943,_0xf734c1,_0x41b3ad,_0x44f67e,_0x4c5edd);return'mfaPendingCredential'in _0x2a534c&&K(_0x35e943,'multi-factor-auth-required',{'_serverResponse':_0x2a534c}),_0x2a534c;}async function Ia(_0x474044,_0x168bcd,_0x4ef1e0,_0x590247){const _0x21b09b=''+_0x168bcd+_0x4ef1e0+'?'+_0x590247,_0x13a16b=_0x474044,_0x255fbb=_0x13a16b['config']['emulator']?Is(_0x474044['config'],_0x21b09b):_0x474044['config']['apiScheme']+'://'+_0x21b09b;return of['includes'](_0x4ef1e0)&&(await _0x13a16b['_persistenceManagerAvailable'],_0x13a16b['_getPersistenceType']()==='COOKIE')?_0x13a16b['_getPersistence']()['_getFinalTarget'](_0x255fbb)['toString']():_0x255fbb;}function cf(_0x5bf8e2){switch(_0x5bf8e2){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x13ddfb){this['auth']=_0x13ddfb,this['timer']=null,this['promise']=new Promise((_0x38a7bb,_0x53a472)=>{this['timer']=setTimeout(()=>_0x53a472(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x263663,_0x2a240f,_0x41f0b4){const _0x260a6b={'appName':_0x263663['name']};_0x41f0b4['email']&&(_0x260a6b['email']=_0x41f0b4['email']),_0x41f0b4['phoneNumber']&&(_0x260a6b['phoneNumber']=_0x41f0b4['phoneNumber']);const _0x307b41=J(_0x263663,_0x2a240f,_0x260a6b);return _0x307b41['customData']['_tokenResponse']=_0x41f0b4,_0x307b41;}function vr(_0x3140e0){return _0x3140e0!==void 0x0&&_0x3140e0['enterprise']!==void 0x0;}class hf{constructor(_0x5d6880){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5d6880['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5d6880['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5d6880['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4ef194){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3b4aa9 of this['recaptchaEnforcementState'])if(_0x3b4aa9['provider']&&_0x3b4aa9['provider']===_0x4ef194)return cf(_0x3b4aa9['enforcementState']);return null;}['isProviderEnabled'](_0x1363bb){return this['getProviderEnforcementState'](_0x1363bb)==='ENFORCE'||this['getProviderEnforcementState'](_0x1363bb)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x43e156,_0x28fd99){return Ae(_0x43e156,'GET','/v2/recaptchaConfig',Re(_0x43e156,_0x28fd99));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x5a37ce,_0x3abcaa){return Ae(_0x5a37ce,'POST','/v1/accounts:delete',_0x3abcaa);}async function Sn(_0x56604f,_0x403e63){return Ae(_0x56604f,'POST','/v1/accounts:lookup',_0x403e63);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x12aab1){if(_0x12aab1)try{const _0x38f266=new Date(Number(_0x12aab1));if(!isNaN(_0x38f266['getTime']()))return _0x38f266['toUTCString']();}catch{}}async function ff(_0x32525d,_0x4f1c67=!0x1){const _0x12a475=k(_0x32525d),_0x5cd654=await _0x12a475['getIdToken'](_0x4f1c67),_0x42aae5=ws(_0x5cd654);m(_0x42aae5&&_0x42aae5['exp']&&_0x42aae5['auth_time']&&_0x42aae5['iat'],_0x12a475['auth'],'internal-error');const _0x3a1589=typeof _0x42aae5['firebase']=='object'?_0x42aae5['firebase']:void 0x0,_0x5582e3=_0x3a1589==null?void 0x0:_0x3a1589['sign_in_provider'];return{'claims':_0x42aae5,'token':_0x5cd654,'authTime':St(ci(_0x42aae5['auth_time'])),'issuedAtTime':St(ci(_0x42aae5['iat'])),'expirationTime':St(ci(_0x42aae5['exp'])),'signInProvider':_0x5582e3||null,'signInSecondFactor':(_0x3a1589==null?void 0x0:_0x3a1589['sign_in_second_factor'])||null};}function ci(_0x1d8f08){return Number(_0x1d8f08)*0x3e8;}function ws(_0x287785){const [_0x83e95d,_0x2228e7,_0x15dd1b]=_0x287785['split']('.');if(_0x83e95d===void 0x0||_0x2228e7===void 0x0||_0x15dd1b===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x50ed6f=cn(_0x2228e7);return _0x50ed6f?JSON['parse'](_0x50ed6f):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5a706b){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5a706b==null?void 0x0:_0x5a706b['toString']()),null;}}function Er(_0x434e12){const _0x5e0a3e=ws(_0x434e12);return m(_0x5e0a3e,'internal-error'),m(typeof _0x5e0a3e['exp']<'u','internal-error'),m(typeof _0x5e0a3e['iat']<'u','internal-error'),Number(_0x5e0a3e['exp'])-Number(_0x5e0a3e['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x4af660,_0x3008f6,_0xf8dab1=!0x1){if(_0xf8dab1)return _0x3008f6;try{return await _0x3008f6;}catch(_0x4119f0){throw _0x4119f0 instanceof Se&&pf(_0x4119f0)&&_0x4af660['auth']['currentUser']===_0x4af660&&await _0x4af660['auth']['signOut'](),_0x4119f0;}}function pf({code:_0x59ac22}){return _0x59ac22==='auth/user-disabled'||_0x59ac22==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x11881e){this['user']=_0x11881e,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x13e735){if(_0x13e735){const _0x15bbfd=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x15bbfd;}else{this['errorBackoff']=0x7530;const _0x1e1279=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1e1279);}}['schedule'](_0x49f15b=!0x1){if(!this['isRunning'])return;const _0x392a70=this['getInterval'](_0x49f15b);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x392a70);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x4245e5){(_0x4245e5==null?void 0x0:_0x4245e5['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x4d2e2f,_0x589dd4){this['createdAt']=_0x4d2e2f,this['lastLoginAt']=_0x589dd4,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x543dd3){this['createdAt']=_0x543dd3['createdAt'],this['lastLoginAt']=_0x543dd3['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0xe2331d){var _0x282f8c;const _0xce4949=_0xe2331d['auth'],_0x28fddb=await _0xe2331d['getIdToken'](),_0x42a40b=await xt(_0xe2331d,Sn(_0xce4949,{'idToken':_0x28fddb}));m(_0x42a40b==null?void 0x0:_0x42a40b['users']['length'],_0xce4949,'internal-error');const _0x3eea34=_0x42a40b['users'][0x0];_0xe2331d['_notifyReloadListener'](_0x3eea34);const _0x12e91d=(_0x282f8c=_0x3eea34['providerUserInfo'])!=null&&_0x282f8c['length']?wa(_0x3eea34['providerUserInfo']):[],_0x505247=mf(_0xe2331d['providerData'],_0x12e91d),_0x2235ab=_0xe2331d['isAnonymous'],_0x4cc114=!(_0xe2331d['email']&&_0x3eea34['passwordHash'])&&!(_0x505247!=null&&_0x505247['length']),_0x1fc068=_0x2235ab?_0x4cc114:!0x1,_0x56e35e={'uid':_0x3eea34['localId'],'displayName':_0x3eea34['displayName']||null,'photoURL':_0x3eea34['photoUrl']||null,'email':_0x3eea34['email']||null,'emailVerified':_0x3eea34['emailVerified']||!0x1,'phoneNumber':_0x3eea34['phoneNumber']||null,'tenantId':_0x3eea34['tenantId']||null,'providerData':_0x505247,'metadata':new Pi(_0x3eea34['createdAt'],_0x3eea34['lastLoginAt']),'isAnonymous':_0x1fc068};Object['assign'](_0xe2331d,_0x56e35e);}async function gf(_0x1f7fbb){const _0xf125b0=k(_0x1f7fbb);await bn(_0xf125b0),await _0xf125b0['auth']['_persistUserIfCurrent'](_0xf125b0),_0xf125b0['auth']['_notifyListenersIfCurrent'](_0xf125b0);}function mf(_0x150e5f,_0x4b90ca){return[..._0x150e5f['filter'](_0x278ad1=>!_0x4b90ca['some'](_0x4d8753=>_0x4d8753['providerId']===_0x278ad1['providerId'])),..._0x4b90ca];}function wa(_0x449172){return _0x449172['map'](({providerId:_0x1430a4,..._0x1eb103})=>({'providerId':_0x1430a4,'uid':_0x1eb103['rawId']||'','displayName':_0x1eb103['displayName']||null,'email':_0x1eb103['email']||null,'phoneNumber':_0x1eb103['phoneNumber']||null,'photoURL':_0x1eb103['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x52716d,_0x3f9c92){const _0x55af7a=await Ea(_0x52716d,{},async()=>{const _0x51865c=at({'grant_type':'refresh_token','refresh_token':_0x3f9c92})['slice'](0x1),{tokenApiHost:_0x38283c,apiKey:_0x39535a}=_0x52716d['config'],_0x540560=await Ia(_0x52716d,_0x38283c,'/v1/token','key='+_0x39535a),_0x585241=await _0x52716d['_getAdditionalHeaders']();_0x585241['Content-Type']='application/x-www-form-urlencoded';const _0xd35400={'method':'POST','headers':_0x585241,'body':_0x51865c};return _0x52716d['emulatorConfig']&&Wt(_0x52716d['emulatorConfig']['host'])&&(_0xd35400['credentials']='include'),va['fetch']()(_0x540560,_0xd35400);});return{'accessToken':_0x55af7a['access_token'],'expiresIn':_0x55af7a['expires_in'],'refreshToken':_0x55af7a['refresh_token']};}async function vf(_0x23986d,_0x2c71c1){return Ae(_0x23986d,'POST','/v2/accounts:revokeToken',Re(_0x23986d,_0x2c71c1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x1727b7){m(_0x1727b7['idToken'],'internal-error'),m(typeof _0x1727b7['idToken']<'u','internal-error'),m(typeof _0x1727b7['refreshToken']<'u','internal-error');const _0x493829='expiresIn'in _0x1727b7&&typeof _0x1727b7['expiresIn']<'u'?Number(_0x1727b7['expiresIn']):Er(_0x1727b7['idToken']);this['updateTokensAndExpiration'](_0x1727b7['idToken'],_0x1727b7['refreshToken'],_0x493829);}['updateFromIdToken'](_0x41bbad){m(_0x41bbad['length']!==0x0,'internal-error');const _0x36fc68=Er(_0x41bbad);this['updateTokensAndExpiration'](_0x41bbad,null,_0x36fc68);}async['getToken'](_0x51956f,_0x7a074b=!0x1){return!_0x7a074b&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x51956f,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x51956f,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0xc8d181,_0x2cf208){const {accessToken:_0x10e77b,refreshToken:_0x3cb64a,expiresIn:_0x273441}=await yf(_0xc8d181,_0x2cf208);this['updateTokensAndExpiration'](_0x10e77b,_0x3cb64a,Number(_0x273441));}['updateTokensAndExpiration'](_0x4d58fb,_0x33dc86,_0x508e25){this['refreshToken']=_0x33dc86||null,this['accessToken']=_0x4d58fb||null,this['expirationTime']=Date['now']()+_0x508e25*0x3e8;}static['fromJSON'](_0x61979c,_0x34a7bd){const {refreshToken:_0x41c42c,accessToken:_0x4d73bd,expirationTime:_0x31b5d3}=_0x34a7bd,_0xd37c4f=new Je();return _0x41c42c&&(m(typeof _0x41c42c=='string','internal-error',{'appName':_0x61979c}),_0xd37c4f['refreshToken']=_0x41c42c),_0x4d73bd&&(m(typeof _0x4d73bd=='string','internal-error',{'appName':_0x61979c}),_0xd37c4f['accessToken']=_0x4d73bd),_0x31b5d3&&(m(typeof _0x31b5d3=='number','internal-error',{'appName':_0x61979c}),_0xd37c4f['expirationTime']=_0x31b5d3),_0xd37c4f;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x542ca5){this['accessToken']=_0x542ca5['accessToken'],this['refreshToken']=_0x542ca5['refreshToken'],this['expirationTime']=_0x542ca5['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x924a7a,_0x501f42){m(typeof _0x924a7a=='string'||typeof _0x924a7a>'u','internal-error',{'appName':_0x501f42});}class z{constructor({uid:_0x230959,auth:_0x13737b,stsTokenManager:_0x4a7eeb,..._0x5a07da}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x230959,this['auth']=_0x13737b,this['stsTokenManager']=_0x4a7eeb,this['accessToken']=_0x4a7eeb['accessToken'],this['displayName']=_0x5a07da['displayName']||null,this['email']=_0x5a07da['email']||null,this['emailVerified']=_0x5a07da['emailVerified']||!0x1,this['phoneNumber']=_0x5a07da['phoneNumber']||null,this['photoURL']=_0x5a07da['photoURL']||null,this['isAnonymous']=_0x5a07da['isAnonymous']||!0x1,this['tenantId']=_0x5a07da['tenantId']||null,this['providerData']=_0x5a07da['providerData']?[..._0x5a07da['providerData']]:[],this['metadata']=new Pi(_0x5a07da['createdAt']||void 0x0,_0x5a07da['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2770a3){const _0xc6d068=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x2770a3));return m(_0xc6d068,this['auth'],'internal-error'),this['accessToken']!==_0xc6d068&&(this['accessToken']=_0xc6d068,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0xc6d068;}['getIdTokenResult'](_0x2f4c14){return ff(this,_0x2f4c14);}['reload'](){return gf(this);}['_assign'](_0x557eab){this!==_0x557eab&&(m(this['uid']===_0x557eab['uid'],this['auth'],'internal-error'),this['displayName']=_0x557eab['displayName'],this['photoURL']=_0x557eab['photoURL'],this['email']=_0x557eab['email'],this['emailVerified']=_0x557eab['emailVerified'],this['phoneNumber']=_0x557eab['phoneNumber'],this['isAnonymous']=_0x557eab['isAnonymous'],this['tenantId']=_0x557eab['tenantId'],this['providerData']=_0x557eab['providerData']['map'](_0x2b35ac=>({..._0x2b35ac})),this['metadata']['_copy'](_0x557eab['metadata']),this['stsTokenManager']['_assign'](_0x557eab['stsTokenManager']));}['_clone'](_0x12c366){const _0x21afbf=new z({...this,'auth':_0x12c366,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x21afbf['metadata']['_copy'](this['metadata']),_0x21afbf;}['_onReload'](_0x930f17){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x930f17,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x321c93){this['reloadListener']?this['reloadListener'](_0x321c93):this['reloadUserInfo']=_0x321c93;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x12693f,_0x32a8ff=!0x1){let _0x4d6511=!0x1;_0x12693f['idToken']&&_0x12693f['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x12693f),_0x4d6511=!0x0),_0x32a8ff&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x4d6511&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x30cafa=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x30cafa})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2f1a59=>({..._0x2f1a59})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x1eee05,_0x474aed){const _0x2c6b89=_0x474aed['displayName']??void 0x0,_0x1080f4=_0x474aed['email']??void 0x0,_0x5e5f22=_0x474aed['phoneNumber']??void 0x0,_0x34ab97=_0x474aed['photoURL']??void 0x0,_0x3c67b5=_0x474aed['tenantId']??void 0x0,_0x4e44c5=_0x474aed['_redirectEventId']??void 0x0,_0x121f1b=_0x474aed['createdAt']??void 0x0,_0xbe10f7=_0x474aed['lastLoginAt']??void 0x0,{uid:_0x4f803d,emailVerified:_0x7d9a1d,isAnonymous:_0x4ffc4a,providerData:_0x1ceb29,stsTokenManager:_0x36724f}=_0x474aed;m(_0x4f803d&&_0x36724f,_0x1eee05,'internal-error');const _0x467fe9=Je['fromJSON'](this['name'],_0x36724f);m(typeof _0x4f803d=='string',_0x1eee05,'internal-error'),ce(_0x2c6b89,_0x1eee05['name']),ce(_0x1080f4,_0x1eee05['name']),m(typeof _0x7d9a1d=='boolean',_0x1eee05,'internal-error'),m(typeof _0x4ffc4a=='boolean',_0x1eee05,'internal-error'),ce(_0x5e5f22,_0x1eee05['name']),ce(_0x34ab97,_0x1eee05['name']),ce(_0x3c67b5,_0x1eee05['name']),ce(_0x4e44c5,_0x1eee05['name']),ce(_0x121f1b,_0x1eee05['name']),ce(_0xbe10f7,_0x1eee05['name']);const _0x25a9a5=new z({'uid':_0x4f803d,'auth':_0x1eee05,'email':_0x1080f4,'emailVerified':_0x7d9a1d,'displayName':_0x2c6b89,'isAnonymous':_0x4ffc4a,'photoURL':_0x34ab97,'phoneNumber':_0x5e5f22,'tenantId':_0x3c67b5,'stsTokenManager':_0x467fe9,'createdAt':_0x121f1b,'lastLoginAt':_0xbe10f7});return _0x1ceb29&&Array['isArray'](_0x1ceb29)&&(_0x25a9a5['providerData']=_0x1ceb29['map'](_0x133c10=>({..._0x133c10}))),_0x4e44c5&&(_0x25a9a5['_redirectEventId']=_0x4e44c5),_0x25a9a5;}static async['_fromIdTokenResponse'](_0x30d34f,_0x31edd5,_0x27ead2=!0x1){const _0xb1817b=new Je();_0xb1817b['updateFromServerResponse'](_0x31edd5);const _0x13e373=new z({'uid':_0x31edd5['localId'],'auth':_0x30d34f,'stsTokenManager':_0xb1817b,'isAnonymous':_0x27ead2});return await bn(_0x13e373),_0x13e373;}static async['_fromGetAccountInfoResponse'](_0x74ab8d,_0x1e66f2,_0x13173a){const _0x207c42=_0x1e66f2['users'][0x0];m(_0x207c42['localId']!==void 0x0,'internal-error');const _0x53b0f0=_0x207c42['providerUserInfo']!==void 0x0?wa(_0x207c42['providerUserInfo']):[],_0x448543=!(_0x207c42['email']&&_0x207c42['passwordHash'])&&!(_0x53b0f0!=null&&_0x53b0f0['length']),_0x50cd64=new Je();_0x50cd64['updateFromIdToken'](_0x13173a);const _0x11856d=new z({'uid':_0x207c42['localId'],'auth':_0x74ab8d,'stsTokenManager':_0x50cd64,'isAnonymous':_0x448543}),_0x3f2414={'uid':_0x207c42['localId'],'displayName':_0x207c42['displayName']||null,'photoURL':_0x207c42['photoUrl']||null,'email':_0x207c42['email']||null,'emailVerified':_0x207c42['emailVerified']||!0x1,'phoneNumber':_0x207c42['phoneNumber']||null,'tenantId':_0x207c42['tenantId']||null,'providerData':_0x53b0f0,'metadata':new Pi(_0x207c42['createdAt'],_0x207c42['lastLoginAt']),'isAnonymous':!(_0x207c42['email']&&_0x207c42['passwordHash'])&&!(_0x53b0f0!=null&&_0x53b0f0['length'])};return Object['assign'](_0x11856d,_0x3f2414),_0x11856d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x4465d1){ae(_0x4465d1 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x43127f=Ir['get'](_0x4465d1);return _0x43127f?(ae(_0x43127f instanceof _0x4465d1,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x43127f):(_0x43127f=new _0x4465d1(),Ir['set'](_0x4465d1,_0x43127f),_0x43127f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x4238da,_0x15dde7){this['storage'][_0x4238da]=_0x15dde7;}async['_get'](_0x2323ce){const _0x30a413=this['storage'][_0x2323ce];return _0x30a413===void 0x0?null:_0x30a413;}async['_remove'](_0x54b9f7){delete this['storage'][_0x54b9f7];}['_addListener'](_0x2d5ca1,_0x375b35){}['_removeListener'](_0x5acee6,_0x3da435){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x115302,_0x4c6a6b,_0x73793f){return'firebase:'+_0x115302+':'+_0x4c6a6b+':'+_0x73793f;}class Xe{constructor(_0x351425,_0x2ae2f0,_0x3668cf){this['persistence']=_0x351425,this['auth']=_0x2ae2f0,this['userKey']=_0x3668cf;const {config:_0x5dd883,name:_0x59011c}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x5dd883['apiKey'],_0x59011c),this['fullPersistenceKey']=sn('persistence',_0x5dd883['apiKey'],_0x59011c),this['boundEventHandler']=_0x2ae2f0['_onStorageEvent']['bind'](_0x2ae2f0),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x191e34){return this['persistence']['_set'](this['fullUserKey'],_0x191e34['toJSON']());}async['getCurrentUser'](){const _0x487a26=await this['persistence']['_get'](this['fullUserKey']);if(!_0x487a26)return null;if(typeof _0x487a26=='string'){const _0x35c905=await Sn(this['auth'],{'idToken':_0x487a26})['catch'](()=>{});return _0x35c905?z['_fromGetAccountInfoResponse'](this['auth'],_0x35c905,_0x487a26):null;}return z['_fromJSON'](this['auth'],_0x487a26);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1aed45){if(this['persistence']===_0x1aed45)return;const _0x4657eb=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1aed45,_0x4657eb)return this['setCurrentUser'](_0x4657eb);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4d651d,_0x11974c,_0x29be67='authUser'){if(!_0x11974c['length'])return new Xe(ne(wr),_0x4d651d,_0x29be67);const _0x5cd92e=(await Promise['all'](_0x11974c['map'](async _0x370557=>{if(await _0x370557['_isAvailable']())return _0x370557;})))['filter'](_0x3dbbc7=>_0x3dbbc7);let _0x18b572=_0x5cd92e[0x0]||ne(wr);const _0x5a2fea=sn(_0x29be67,_0x4d651d['config']['apiKey'],_0x4d651d['name']);let _0x5b7a6e=null;for(const _0x2fee02 of _0x11974c)try{const _0x135bd9=await _0x2fee02['_get'](_0x5a2fea);if(_0x135bd9){let _0x4e3000;if(typeof _0x135bd9=='string'){const _0x43c0e6=await Sn(_0x4d651d,{'idToken':_0x135bd9})['catch'](()=>{});if(!_0x43c0e6)break;_0x4e3000=await z['_fromGetAccountInfoResponse'](_0x4d651d,_0x43c0e6,_0x135bd9);}else _0x4e3000=z['_fromJSON'](_0x4d651d,_0x135bd9);_0x2fee02!==_0x18b572&&(_0x5b7a6e=_0x4e3000),_0x18b572=_0x2fee02;break;}}catch{}const _0x4cd5b5=_0x5cd92e['filter'](_0x322223=>_0x322223['_shouldAllowMigration']);return!_0x18b572['_shouldAllowMigration']||!_0x4cd5b5['length']?new Xe(_0x18b572,_0x4d651d,_0x29be67):(_0x18b572=_0x4cd5b5[0x0],_0x5b7a6e&&await _0x18b572['_set'](_0x5a2fea,_0x5b7a6e['toJSON']()),await Promise['all'](_0x11974c['map'](async _0xae276=>{if(_0xae276!==_0x18b572)try{await _0xae276['_remove'](_0x5a2fea);}catch{}})),new Xe(_0x18b572,_0x4d651d,_0x29be67));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x4959d3){const _0x441bba=_0x4959d3['toLowerCase']();if(_0x441bba['includes']('opera/')||_0x441bba['includes']('opr/')||_0x441bba['includes']('opios/'))return'Opera';if(Ra(_0x441bba))return'IEMobile';if(_0x441bba['includes']('msie')||_0x441bba['includes']('trident/'))return'IE';if(_0x441bba['includes']('edge/'))return'Edge';if(Ta(_0x441bba))return'Firefox';if(_0x441bba['includes']('silk/'))return'Silk';if(ka(_0x441bba))return'Blackberry';if(Na(_0x441bba))return'Webos';if(Sa(_0x441bba))return'Safari';if((_0x441bba['includes']('chrome/')||ba(_0x441bba))&&!_0x441bba['includes']('edge/'))return'Chrome';if(Aa(_0x441bba))return'Android';{const _0x3add8c=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4b1065=_0x4959d3['match'](_0x3add8c);if((_0x4b1065==null?void 0x0:_0x4b1065['length'])===0x2)return _0x4b1065[0x1];}return'Other';}function Ta(_0x5e7dce=W()){return/firefox\//i['test'](_0x5e7dce);}function Sa(_0x277fd6=W()){const _0x316274=_0x277fd6['toLowerCase']();return _0x316274['includes']('safari/')&&!_0x316274['includes']('chrome/')&&!_0x316274['includes']('crios/')&&!_0x316274['includes']('android');}function ba(_0x3568cb=W()){return/crios\//i['test'](_0x3568cb);}function Ra(_0x38cb4f=W()){return/iemobile/i['test'](_0x38cb4f);}function Aa(_0x4dc126=W()){return/android/i['test'](_0x4dc126);}function ka(_0xfcfae=W()){return/blackberry/i['test'](_0xfcfae);}function Na(_0x5f1d47=W()){return/webos/i['test'](_0x5f1d47);}function Cs(_0x360ffd=W()){return/iphone|ipad|ipod/i['test'](_0x360ffd)||/macintosh/i['test'](_0x360ffd)&&/mobile/i['test'](_0x360ffd);}function Ef(_0x3dc367=W()){var _0x4e4d5b;return Cs(_0x3dc367)&&!!((_0x4e4d5b=window['navigator'])!=null&&_0x4e4d5b['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x4ec09d=W()){return Cs(_0x4ec09d)||Aa(_0x4ec09d)||Na(_0x4ec09d)||ka(_0x4ec09d)||/windows phone/i['test'](_0x4ec09d)||Ra(_0x4ec09d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x410b27,_0x2e3690=[]){let _0x327d3c;switch(_0x410b27){case'Browser':_0x327d3c=Cr(W());break;case'Worker':_0x327d3c=Cr(W())+'-'+_0x410b27;break;default:_0x327d3c=_0x410b27;}const _0x21c89c=_0x2e3690['length']?_0x2e3690['join'](','):'FirebaseCore-web';return _0x327d3c+'/JsCore/'+ct+'/'+_0x21c89c;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x3b1f25){this['auth']=_0x3b1f25,this['queue']=[];}['pushCallback'](_0x40861f,_0x4e1c63){const _0xd76eef=_0x536182=>new Promise((_0x14f861,_0x2ec942)=>{try{const _0x13c19e=_0x40861f(_0x536182);_0x14f861(_0x13c19e);}catch(_0x461961){_0x2ec942(_0x461961);}});_0xd76eef['onAbort']=_0x4e1c63,this['queue']['push'](_0xd76eef);const _0x7fc860=this['queue']['length']-0x1;return()=>{this['queue'][_0x7fc860]=()=>Promise['resolve']();};}async['runMiddleware'](_0x245bc8){if(this['auth']['currentUser']===_0x245bc8)return;const _0x1a58af=[];try{for(const _0x61b3c0 of this['queue'])await _0x61b3c0(_0x245bc8),_0x61b3c0['onAbort']&&_0x1a58af['push'](_0x61b3c0['onAbort']);}catch(_0x3e8d27){_0x1a58af['reverse']();for(const _0x1505dc of _0x1a58af)try{_0x1505dc();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3e8d27==null?void 0x0:_0x3e8d27['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0xb9da11,_0x1fdcde={}){return Ae(_0xb9da11,'GET','/v2/passwordPolicy',Re(_0xb9da11,_0x1fdcde));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x5b949f){var _0x533d19;const _0x460083=_0x5b949f['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x460083['minPasswordLength']??Tf,_0x460083['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x460083['maxPasswordLength']),_0x460083['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x460083['containsLowercaseCharacter']),_0x460083['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x460083['containsUppercaseCharacter']),_0x460083['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x460083['containsNumericCharacter']),_0x460083['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x460083['containsNonAlphanumericCharacter']),this['enforcementState']=_0x5b949f['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x533d19=_0x5b949f['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x533d19['join'](''))??'',this['forceUpgradeOnSignin']=_0x5b949f['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x5b949f['schemaVersion'];}['validatePassword'](_0x405b71){const _0x5e1632={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x405b71,_0x5e1632),this['validatePasswordCharacterOptions'](_0x405b71,_0x5e1632),_0x5e1632['isValid']&&(_0x5e1632['isValid']=_0x5e1632['meetsMinPasswordLength']??!0x0),_0x5e1632['isValid']&&(_0x5e1632['isValid']=_0x5e1632['meetsMaxPasswordLength']??!0x0),_0x5e1632['isValid']&&(_0x5e1632['isValid']=_0x5e1632['containsLowercaseLetter']??!0x0),_0x5e1632['isValid']&&(_0x5e1632['isValid']=_0x5e1632['containsUppercaseLetter']??!0x0),_0x5e1632['isValid']&&(_0x5e1632['isValid']=_0x5e1632['containsNumericCharacter']??!0x0),_0x5e1632['isValid']&&(_0x5e1632['isValid']=_0x5e1632['containsNonAlphanumericCharacter']??!0x0),_0x5e1632;}['validatePasswordLengthOptions'](_0x42d7e3,_0xebc11f){const _0xc54ec7=this['customStrengthOptions']['minPasswordLength'],_0x340479=this['customStrengthOptions']['maxPasswordLength'];_0xc54ec7&&(_0xebc11f['meetsMinPasswordLength']=_0x42d7e3['length']>=_0xc54ec7),_0x340479&&(_0xebc11f['meetsMaxPasswordLength']=_0x42d7e3['length']<=_0x340479);}['validatePasswordCharacterOptions'](_0x56a232,_0xbd4620){this['updatePasswordCharacterOptionsStatuses'](_0xbd4620,!0x1,!0x1,!0x1,!0x1);let _0x498a65;for(let _0x4e7bc7=0x0;_0x4e7bc7<_0x56a232['length'];_0x4e7bc7++)_0x498a65=_0x56a232['charAt'](_0x4e7bc7),this['updatePasswordCharacterOptionsStatuses'](_0xbd4620,_0x498a65>='a'&&_0x498a65<='z',_0x498a65>='A'&&_0x498a65<='Z',_0x498a65>='0'&&_0x498a65<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x498a65));}['updatePasswordCharacterOptionsStatuses'](_0x5bc4fc,_0x1471ee,_0x4273ed,_0x1568ee,_0x1e7b1a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5bc4fc['containsLowercaseLetter']||(_0x5bc4fc['containsLowercaseLetter']=_0x1471ee)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5bc4fc['containsUppercaseLetter']||(_0x5bc4fc['containsUppercaseLetter']=_0x4273ed)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5bc4fc['containsNumericCharacter']||(_0x5bc4fc['containsNumericCharacter']=_0x1568ee)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5bc4fc['containsNonAlphanumericCharacter']||(_0x5bc4fc['containsNonAlphanumericCharacter']=_0x1e7b1a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x3e7c2a,_0x553248,_0x6820bc,_0x4b8f8c){this['app']=_0x3e7c2a,this['heartbeatServiceProvider']=_0x553248,this['appCheckServiceProvider']=_0x6820bc,this['config']=_0x4b8f8c,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3e7c2a['name'],this['clientVersion']=_0x4b8f8c['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2b2c92=>this['_resolvePersistenceManagerAvailable']=_0x2b2c92);}['_initializeWithPersistence'](_0x54f90c,_0x1c8718){return _0x1c8718&&(this['_popupRedirectResolver']=ne(_0x1c8718)),this['_initializationPromise']=this['queue'](async()=>{var _0x2bd8d1,_0xcdb77,_0x314204;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x54f90c),(_0x2bd8d1=this['_resolvePersistenceManagerAvailable'])==null||_0x2bd8d1['call'](this),!this['_deleted'])){if((_0xcdb77=this['_popupRedirectResolver'])!=null&&_0xcdb77['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1c8718),this['lastNotifiedUid']=((_0x314204=this['currentUser'])==null?void 0x0:_0x314204['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x499b30=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x499b30)){if(this['currentUser']&&_0x499b30&&this['currentUser']['uid']===_0x499b30['uid']){this['_currentUser']['_assign'](_0x499b30),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x499b30,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x20e2ff){try{const _0x4b7b31=await Sn(this,{'idToken':_0x20e2ff}),_0x4bd9fc=await z['_fromGetAccountInfoResponse'](this,_0x4b7b31,_0x20e2ff);await this['directlySetCurrentUser'](_0x4bd9fc);}catch(_0x5fa3a8){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x5fa3a8),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x36227a){var _0x5cb53f;if(H(this['app'])){const _0x28e920=this['app']['settings']['authIdToken'];return _0x28e920?new Promise(_0x436cf9=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x28e920)['then'](_0x436cf9,_0x436cf9));}):this['directlySetCurrentUser'](null);}const _0x1e1260=await this['assertedPersistence']['getCurrentUser']();let _0x5c03a2=_0x1e1260,_0x1db67e=!0x1;if(_0x36227a&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1dacf7=(_0x5cb53f=this['redirectUser'])==null?void 0x0:_0x5cb53f['_redirectEventId'],_0x352968=_0x5c03a2==null?void 0x0:_0x5c03a2['_redirectEventId'],_0x4006e8=await this['tryRedirectSignIn'](_0x36227a);(!_0x1dacf7||_0x1dacf7===_0x352968)&&(_0x4006e8!=null&&_0x4006e8['user'])&&(_0x5c03a2=_0x4006e8['user'],_0x1db67e=!0x0);}if(!_0x5c03a2)return this['directlySetCurrentUser'](null);if(!_0x5c03a2['_redirectEventId']){if(_0x1db67e)try{await this['beforeStateQueue']['runMiddleware'](_0x5c03a2);}catch(_0x5a776b){_0x5c03a2=_0x1e1260,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x5a776b));}return _0x5c03a2?this['reloadAndSetCurrentUserOrClear'](_0x5c03a2):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5c03a2['_redirectEventId']?this['directlySetCurrentUser'](_0x5c03a2):this['reloadAndSetCurrentUserOrClear'](_0x5c03a2);}async['tryRedirectSignIn'](_0x3df200){let _0x595bbb=null;try{_0x595bbb=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3df200,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x595bbb;}async['reloadAndSetCurrentUserOrClear'](_0xe3282a){try{await bn(_0xe3282a);}catch(_0x466f7d){if((_0x466f7d==null?void 0x0:_0x466f7d['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0xe3282a);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x45d79f){if(H(this['app']))return Promise['reject'](se(this));const _0x400e7b=_0x45d79f?k(_0x45d79f):null;return _0x400e7b&&m(_0x400e7b['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x400e7b&&_0x400e7b['_clone'](this));}async['_updateCurrentUser'](_0x406f2c,_0x10ab5c=!0x1){if(!this['_deleted'])return _0x406f2c&&m(this['tenantId']===_0x406f2c['tenantId'],this,'tenant-id-mismatch'),_0x10ab5c||await this['beforeStateQueue']['runMiddleware'](_0x406f2c),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x406f2c),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x57067d){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x57067d));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x4455c4){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x170471=this['_getPasswordPolicyInternal']();return _0x170471['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x170471['validatePassword'](_0x4455c4);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4ead79=await Cf(this),_0x489025=new Sf(_0x4ead79);this['tenantId']===null?this['_projectPasswordPolicy']=_0x489025:this['_tenantPasswordPolicies'][this['tenantId']]=_0x489025;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x5eae03){this['_errorFactory']=new Ut('auth','Firebase',_0x5eae03());}['onAuthStateChanged'](_0x5d9aa8,_0x3ce759,_0x49657f){return this['registerStateListener'](this['authStateSubscription'],_0x5d9aa8,_0x3ce759,_0x49657f);}['beforeAuthStateChanged'](_0xab8ae,_0x22fb95){return this['beforeStateQueue']['pushCallback'](_0xab8ae,_0x22fb95);}['onIdTokenChanged'](_0x3daa6b,_0x4cb6ed,_0xfbc40d){return this['registerStateListener'](this['idTokenSubscription'],_0x3daa6b,_0x4cb6ed,_0xfbc40d);}['authStateReady'](){return new Promise((_0x44ebd4,_0xcd8f7a)=>{if(this['currentUser'])_0x44ebd4();else{const _0x3a7c56=this['onAuthStateChanged'](()=>{_0x3a7c56(),_0x44ebd4();},_0xcd8f7a);}});}async['revokeAccessToken'](_0x9a3684){if(this['currentUser']){const _0x14f218=await this['currentUser']['getIdToken'](),_0x1b0867={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x9a3684,'idToken':_0x14f218};this['tenantId']!=null&&(_0x1b0867['tenantId']=this['tenantId']),await vf(this,_0x1b0867);}}['toJSON'](){var _0x3dc0ac;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3dc0ac=this['_currentUser'])==null?void 0x0:_0x3dc0ac['toJSON']()};}async['_setRedirectUser'](_0x4c8957,_0x5d89d3){const _0x511daa=await this['getOrInitRedirectPersistenceManager'](_0x5d89d3);return _0x4c8957===null?_0x511daa['removeCurrentUser']():_0x511daa['setCurrentUser'](_0x4c8957);}async['getOrInitRedirectPersistenceManager'](_0x32ef49){if(!this['redirectPersistenceManager']){const _0xf038ab=_0x32ef49&&ne(_0x32ef49)||this['_popupRedirectResolver'];m(_0xf038ab,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0xf038ab['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x5ece45){var _0x593784,_0x4fe603;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x593784=this['_currentUser'])==null?void 0x0:_0x593784['_redirectEventId'])===_0x5ece45?this['_currentUser']:((_0x4fe603=this['redirectUser'])==null?void 0x0:_0x4fe603['_redirectEventId'])===_0x5ece45?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x438d22){if(_0x438d22===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x438d22));}['_notifyListenersIfCurrent'](_0x577664){_0x577664===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x10221b;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x2e4e5e=((_0x10221b=this['currentUser'])==null?void 0x0:_0x10221b['uid'])??null;this['lastNotifiedUid']!==_0x2e4e5e&&(this['lastNotifiedUid']=_0x2e4e5e,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x37d904,_0x292177,_0x211c8e,_0x29b4fc){if(this['_deleted'])return()=>{};const _0x46e8cf=typeof _0x292177=='function'?_0x292177:_0x292177['next']['bind'](_0x292177);let _0x4c41a0=!0x1;const _0x378014=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x378014,this,'internal-error'),_0x378014['then'](()=>{_0x4c41a0||_0x46e8cf(this['currentUser']);}),typeof _0x292177=='function'){const _0x122cad=_0x37d904['addObserver'](_0x292177,_0x211c8e,_0x29b4fc);return()=>{_0x4c41a0=!0x0,_0x122cad();};}else{const _0x571630=_0x37d904['addObserver'](_0x292177);return()=>{_0x4c41a0=!0x0,_0x571630();};}}async['directlySetCurrentUser'](_0x4372e1){this['currentUser']&&this['currentUser']!==_0x4372e1&&this['_currentUser']['_stopProactiveRefresh'](),_0x4372e1&&this['isProactiveRefreshEnabled']&&_0x4372e1['_startProactiveRefresh'](),this['currentUser']=_0x4372e1,_0x4372e1?await this['assertedPersistence']['setCurrentUser'](_0x4372e1):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4182c2){return this['operations']=this['operations']['then'](_0x4182c2,_0x4182c2),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1c6fa8){!_0x1c6fa8||this['frameworks']['includes'](_0x1c6fa8)||(this['frameworks']['push'](_0x1c6fa8),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x49c3d9;const _0x29d5e6={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x29d5e6['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x21c520=await((_0x49c3d9=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x49c3d9['getHeartbeatsHeader']());_0x21c520&&(_0x29d5e6['X-Firebase-Client']=_0x21c520);const _0x3643d5=await this['_getAppCheckToken']();return _0x3643d5&&(_0x29d5e6['X-Firebase-AppCheck']=_0x3643d5),_0x29d5e6;}async['_getAppCheckToken'](){var _0x53fda7;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5616d7=await((_0x53fda7=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x53fda7['getToken']());return _0x5616d7!=null&&_0x5616d7['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5616d7['error']),_0x5616d7==null?void 0x0:_0x5616d7['token'];}}function qe(_0x12fa87){return k(_0x12fa87);}class Tr{constructor(_0x191f16){this['auth']=_0x191f16,this['observer']=null,this['addObserver']=Ic(_0x2ca864=>this['observer']=_0x2ca864);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x3ec781){zn=_0x3ec781;}function Da(_0x4b0bef){return zn['loadJS'](_0x4b0bef);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x10a0b0){return'__'+_0x10a0b0+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x3e6286){_0x3e6286();}['execute'](_0x652d3e,_0x590893){return Promise['resolve']('token');}['render'](_0x35bc43,_0x3530ed){return'';}}class Of{['ready'](_0x593db9){_0x593db9();}['execute'](_0x4d92e6,_0x52eb27){return Promise['resolve']('token');}['render'](_0x4b8145,_0x211d93){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0xe720b7){this['type']=Df,this['auth']=qe(_0xe720b7);}async['verify'](_0x5dfdbe='verify',_0x1ab9c7=!0x1){async function _0x99dcea(_0xdbd90d){if(!_0x1ab9c7){if(_0xdbd90d['tenantId']==null&&_0xdbd90d['_agentRecaptchaConfig']!=null)return _0xdbd90d['_agentRecaptchaConfig']['siteKey'];if(_0xdbd90d['tenantId']!=null&&_0xdbd90d['_tenantRecaptchaConfigs'][_0xdbd90d['tenantId']]!==void 0x0)return _0xdbd90d['_tenantRecaptchaConfigs'][_0xdbd90d['tenantId']]['siteKey'];}return new Promise(async(_0x18bce8,_0x38e9ca)=>{uf(_0xdbd90d,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x466d34=>{if(_0x466d34['recaptchaKey']===void 0x0)_0x38e9ca(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x57571d=new hf(_0x466d34);return _0xdbd90d['tenantId']==null?_0xdbd90d['_agentRecaptchaConfig']=_0x57571d:_0xdbd90d['_tenantRecaptchaConfigs'][_0xdbd90d['tenantId']]=_0x57571d,_0x18bce8(_0x57571d['siteKey']);}})['catch'](_0x52b926=>{_0x38e9ca(_0x52b926);});});}function _0x5588cc(_0x58cb75,_0x567b7a,_0x101540){const _0x24ea9a=window['grecaptcha'];vr(_0x24ea9a)?_0x24ea9a['enterprise']['ready'](()=>{_0x24ea9a['enterprise']['execute'](_0x58cb75,{'action':_0x5dfdbe})['then'](_0x4f825f=>{_0x567b7a(_0x4f825f);})['catch'](()=>{_0x567b7a(Ma);});}):_0x101540(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x166b0f,_0x3f7f44)=>{_0x99dcea(this['auth'])['then'](async _0xc3248c=>{if(!_0x1ab9c7&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x5588cc(_0xc3248c,_0x166b0f,_0x3f7f44);else{if(typeof window>'u'){_0x3f7f44(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x27609c=Af();_0x27609c['length']!==0x0&&(_0x27609c+=_0xc3248c+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x40398d;(_0x40398d=le['scriptInjectionDeferred'])==null||_0x40398d['resolve']();},Da(_0x27609c)['then'](()=>{var _0x5b99f3;return(_0x5b99f3=le['scriptInjectionDeferred'])==null?void 0x0:_0x5b99f3['promise'];})['then'](()=>{_0x5588cc(_0xc3248c,_0x166b0f,_0x3f7f44);})['catch'](_0x13a68a=>{_0x3f7f44(_0x13a68a);});}})['catch'](_0x3590b0=>{_0x3f7f44(_0x3590b0);});});}}le['scriptInjectionDeferred']=null;async function br(_0x38edc9,_0xb8f314,_0x2eb353,_0x53f5ed=!0x1,_0x3dbb0f=!0x1){const _0x2fd8ba=new le(_0x38edc9);let _0x36e51f;if(_0x3dbb0f)_0x36e51f=Ma;else try{_0x36e51f=await _0x2fd8ba['verify'](_0x2eb353);}catch{_0x36e51f=await _0x2fd8ba['verify'](_0x2eb353,!0x0);}const _0x5f3c4b={..._0xb8f314};if(_0x2eb353==='mfaSmsEnrollment'||_0x2eb353==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5f3c4b){const _0x3cdf61=_0x5f3c4b['phoneEnrollmentInfo']['phoneNumber'],_0x26577d=_0x5f3c4b['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5f3c4b,{'phoneEnrollmentInfo':{'phoneNumber':_0x3cdf61,'recaptchaToken':_0x26577d,'captchaResponse':_0x36e51f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5f3c4b){const _0x8624ed=_0x5f3c4b['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5f3c4b,{'phoneSignInInfo':{'recaptchaToken':_0x8624ed,'captchaResponse':_0x36e51f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5f3c4b;}return _0x53f5ed?Object['assign'](_0x5f3c4b,{'captchaResp':_0x36e51f}):Object['assign'](_0x5f3c4b,{'captchaResponse':_0x36e51f}),Object['assign'](_0x5f3c4b,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5f3c4b,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5f3c4b;}async function Oi(_0x25faca,_0x454cfa,_0x1b15e9,_0xa4da1f,_0x4bdea9){var _0x101a4c;if((_0x101a4c=_0x25faca['_getRecaptchaConfig']())!=null&&_0x101a4c['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xb61fa3=await br(_0x25faca,_0x454cfa,_0x1b15e9,_0x1b15e9==='getOobCode');return _0xa4da1f(_0x25faca,_0xb61fa3);}else return _0xa4da1f(_0x25faca,_0x454cfa)['catch'](async _0x4a61d8=>{if(_0x4a61d8['code']==='auth/missing-recaptcha-token'){console['log'](_0x1b15e9+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xff20f2=await br(_0x25faca,_0x454cfa,_0x1b15e9,_0x1b15e9==='getOobCode');return _0xa4da1f(_0x25faca,_0xff20f2);}else return Promise['reject'](_0x4a61d8);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x673cf0,_0x1b30f9){const _0x348fc2=Ui(_0x673cf0,'auth');if(_0x348fc2['isInitialized']()){const _0x192c11=_0x348fc2['getImmediate'](),_0x23831b=_0x348fc2['getOptions']();if(De(_0x23831b,_0x1b30f9??{}))return _0x192c11;K(_0x192c11,'already-initialized');}return _0x348fc2['initialize']({'options':_0x1b30f9});}function Lf(_0x3342f2,_0x547c20){const _0x48a3bf=(_0x547c20==null?void 0x0:_0x547c20['persistence'])||[],_0x1d64c3=(Array['isArray'](_0x48a3bf)?_0x48a3bf:[_0x48a3bf])['map'](ne);_0x547c20!=null&&_0x547c20['errorMap']&&_0x3342f2['_updateErrorMap'](_0x547c20['errorMap']),_0x3342f2['_initializeWithPersistence'](_0x1d64c3,_0x547c20==null?void 0x0:_0x547c20['popupRedirectResolver']);}function xf(_0x48571a,_0x28ebd5,_0x5b99ba){const _0x2902f8=qe(_0x48571a);m(/^https?:\/\//['test'](_0x28ebd5),_0x2902f8,'invalid-emulator-scheme');const _0x18e4ca=!0x1,_0x1d1aab=La(_0x28ebd5),{host:_0x4e44cc,port:_0x29198d}=Ff(_0x28ebd5),_0x1a0ec5=_0x29198d===null?'':':'+_0x29198d,_0x83e620={'url':_0x1d1aab+'//'+_0x4e44cc+_0x1a0ec5+'/'},_0x35005b=Object['freeze']({'host':_0x4e44cc,'port':_0x29198d,'protocol':_0x1d1aab['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x18e4ca})});if(!_0x2902f8['_canInitEmulator']){m(_0x2902f8['config']['emulator']&&_0x2902f8['emulatorConfig'],_0x2902f8,'emulator-config-failed'),m(De(_0x83e620,_0x2902f8['config']['emulator'])&&De(_0x35005b,_0x2902f8['emulatorConfig']),_0x2902f8,'emulator-config-failed');return;}_0x2902f8['config']['emulator']=_0x83e620,_0x2902f8['emulatorConfig']=_0x35005b,_0x2902f8['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x4e44cc)?jr(_0x1d1aab+'//'+_0x4e44cc+_0x1a0ec5):Uf();}function La(_0x25e10e){const _0xed69a6=_0x25e10e['indexOf'](':');return _0xed69a6<0x0?'':_0x25e10e['substr'](0x0,_0xed69a6+0x1);}function Ff(_0x478e9d){const _0x394d32=La(_0x478e9d),_0x553d08=/(\/\/)?([^?#/]+)/['exec'](_0x478e9d['substr'](_0x394d32['length']));if(!_0x553d08)return{'host':'','port':null};const _0x151a2d=_0x553d08[0x2]['split']('@')['pop']()||'',_0x5cb0d9=/^(\[[^\]]+\])(:|$)/['exec'](_0x151a2d);if(_0x5cb0d9){const _0x46f0b8=_0x5cb0d9[0x1];return{'host':_0x46f0b8,'port':Rr(_0x151a2d['substr'](_0x46f0b8['length']+0x1))};}else{const [_0xdc9408,_0x2a821d]=_0x151a2d['split'](':');return{'host':_0xdc9408,'port':Rr(_0x2a821d)};}}function Rr(_0x2b26dd){if(!_0x2b26dd)return null;const _0x3f615a=Number(_0x2b26dd);return isNaN(_0x3f615a)?null:_0x3f615a;}function Uf(){function _0xd20c4a(){const _0x412fd0=document['createElement']('p'),_0x273fdd=_0x412fd0['style'];_0x412fd0['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x273fdd['position']='fixed',_0x273fdd['width']='100%',_0x273fdd['backgroundColor']='#ffffff',_0x273fdd['border']='.1em\x20solid\x20#000000',_0x273fdd['color']='#b50000',_0x273fdd['bottom']='0px',_0x273fdd['left']='0px',_0x273fdd['margin']='0px',_0x273fdd['zIndex']='10000',_0x273fdd['textAlign']='center',_0x412fd0['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x412fd0);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xd20c4a):_0xd20c4a());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0xa2238b,_0x10a68c){this['providerId']=_0xa2238b,this['signInMethod']=_0x10a68c;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x4f43c8){return te('not\x20implemented');}['_linkToIdToken'](_0x1f1dd,_0x2a35b3){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x529fe6){return te('not\x20implemented');}}async function Wf(_0x5c0bfe,_0x1a24b6){return Ae(_0x5c0bfe,'POST','/v1/accounts:signUp',_0x1a24b6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x2128c8,_0xd5e09){return Yt(_0x2128c8,'POST','/v1/accounts:signInWithPassword',Re(_0x2128c8,_0xd5e09));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0xbb3248,_0x5c8e09){return Yt(_0xbb3248,'POST','/v1/accounts:signInWithEmailLink',Re(_0xbb3248,_0x5c8e09));}async function Hf(_0x5e0564,_0x13fa04){return Yt(_0x5e0564,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5e0564,_0x13fa04));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0xf367b3,_0x3681a2,_0x293a02,_0x194e6a=null){super('password',_0x293a02),this['_email']=_0xf367b3,this['_password']=_0x3681a2,this['_tenantId']=_0x194e6a;}static['_fromEmailAndPassword'](_0x1e3c2a,_0x327e2a){return new Ft(_0x1e3c2a,_0x327e2a,'password');}static['_fromEmailAndCode'](_0x358b55,_0x3e94a4,_0x575286=null){return new Ft(_0x358b55,_0x3e94a4,'emailLink',_0x575286);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x33a2aa){const _0x2b7995=typeof _0x33a2aa=='string'?JSON['parse'](_0x33a2aa):_0x33a2aa;if(_0x2b7995!=null&&_0x2b7995['email']&&(_0x2b7995!=null&&_0x2b7995['password'])){if(_0x2b7995['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2b7995['email'],_0x2b7995['password']);if(_0x2b7995['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2b7995['email'],_0x2b7995['password'],_0x2b7995['tenantId']);}return null;}async['_getIdTokenResponse'](_0x437732){switch(this['signInMethod']){case'password':const _0x46b63e={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x437732,_0x46b63e,'signInWithPassword',Bf);case'emailLink':return Vf(_0x437732,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x437732,'internal-error');}}async['_linkToIdToken'](_0x1a47af,_0x32a9a5){switch(this['signInMethod']){case'password':const _0x45b176={'idToken':_0x32a9a5,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x1a47af,_0x45b176,'signUpPassword',Wf);case'emailLink':return Hf(_0x1a47af,{'idToken':_0x32a9a5,'email':this['_email'],'oobCode':this['_password']});default:K(_0x1a47af,'internal-error');}}['_getReauthenticationResolver'](_0x3a39c9){return this['_getIdTokenResponse'](_0x3a39c9);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x3cdd80,_0xa55418){return Yt(_0x3cdd80,'POST','/v1/accounts:signInWithIdp',Re(_0x3cdd80,_0xa55418));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x24e646){const _0x5864b9=new We(_0x24e646['providerId'],_0x24e646['signInMethod']);return _0x24e646['idToken']||_0x24e646['accessToken']?(_0x24e646['idToken']&&(_0x5864b9['idToken']=_0x24e646['idToken']),_0x24e646['accessToken']&&(_0x5864b9['accessToken']=_0x24e646['accessToken']),_0x24e646['nonce']&&!_0x24e646['pendingToken']&&(_0x5864b9['nonce']=_0x24e646['nonce']),_0x24e646['pendingToken']&&(_0x5864b9['pendingToken']=_0x24e646['pendingToken'])):_0x24e646['oauthToken']&&_0x24e646['oauthTokenSecret']?(_0x5864b9['accessToken']=_0x24e646['oauthToken'],_0x5864b9['secret']=_0x24e646['oauthTokenSecret']):K('argument-error'),_0x5864b9;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x26218c){const _0x1e97fa=typeof _0x26218c=='string'?JSON['parse'](_0x26218c):_0x26218c,{providerId:_0x3d97d3,signInMethod:_0x483a4f,..._0x4cd66a}=_0x1e97fa;if(!_0x3d97d3||!_0x483a4f)return null;const _0x2865f3=new We(_0x3d97d3,_0x483a4f);return _0x2865f3['idToken']=_0x4cd66a['idToken']||void 0x0,_0x2865f3['accessToken']=_0x4cd66a['accessToken']||void 0x0,_0x2865f3['secret']=_0x4cd66a['secret'],_0x2865f3['nonce']=_0x4cd66a['nonce'],_0x2865f3['pendingToken']=_0x4cd66a['pendingToken']||null,_0x2865f3;}['_getIdTokenResponse'](_0x5b90f4){const _0x470bfa=this['buildRequest']();return Ze(_0x5b90f4,_0x470bfa);}['_linkToIdToken'](_0x16111b,_0xb9b94){const _0x1811b7=this['buildRequest']();return _0x1811b7['idToken']=_0xb9b94,Ze(_0x16111b,_0x1811b7);}['_getReauthenticationResolver'](_0x1891d1){const _0x5bd51e=this['buildRequest']();return _0x5bd51e['autoCreate']=!0x1,Ze(_0x1891d1,_0x5bd51e);}['buildRequest'](){const _0x1e502d={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1e502d['pendingToken']=this['pendingToken'];else{const _0x4dc45c={};this['idToken']&&(_0x4dc45c['id_token']=this['idToken']),this['accessToken']&&(_0x4dc45c['access_token']=this['accessToken']),this['secret']&&(_0x4dc45c['oauth_token_secret']=this['secret']),_0x4dc45c['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4dc45c['nonce']=this['nonce']),_0x1e502d['postBody']=at(_0x4dc45c);}return _0x1e502d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x18f59d){switch(_0x18f59d){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0xd6c9c8){const _0x32edce=yt(vt(_0xd6c9c8))['link'],_0x6e9380=_0x32edce?yt(vt(_0x32edce))['deep_link_id']:null,_0x348d74=yt(vt(_0xd6c9c8))['deep_link_id'];return(_0x348d74?yt(vt(_0x348d74))['link']:null)||_0x348d74||_0x6e9380||_0x32edce||_0xd6c9c8;}class Ss{constructor(_0x105e8f){const _0x129b6a=yt(vt(_0x105e8f)),_0x5c3570=_0x129b6a['apiKey']??null,_0x3e1ddc=_0x129b6a['oobCode']??null,_0x42c878=Gf(_0x129b6a['mode']??null);m(_0x5c3570&&_0x3e1ddc&&_0x42c878,'argument-error'),this['apiKey']=_0x5c3570,this['operation']=_0x42c878,this['code']=_0x3e1ddc,this['continueUrl']=_0x129b6a['continueUrl']??null,this['languageCode']=_0x129b6a['lang']??null,this['tenantId']=_0x129b6a['tenantId']??null;}static['parseLink'](_0x185617){const _0x2d32c5=qf(_0x185617);try{return new Ss(_0x2d32c5);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x570a9a,_0x5412db){return Ft['_fromEmailAndPassword'](_0x570a9a,_0x5412db);}static['credentialWithLink'](_0x245cb0,_0x131ce7){const _0x5db853=Ss['parseLink'](_0x131ce7);return m(_0x5db853,'argument-error'),Ft['_fromEmailAndCode'](_0x245cb0,_0x5db853['code'],_0x5db853['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x995cc4){this['providerId']=_0x995cc4,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x57af05){this['defaultLanguageCode']=_0x57af05;}['setCustomParameters'](_0x24aeb){return this['customParameters']=_0x24aeb,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x2d13bc){return this['scopes']['includes'](_0x2d13bc)||this['scopes']['push'](_0x2d13bc),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x263ae0){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x263ae0});}static['credentialFromResult'](_0x2ed59a){return he['credentialFromTaggedObject'](_0x2ed59a);}static['credentialFromError'](_0xaae09c){return he['credentialFromTaggedObject'](_0xaae09c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4b44c9}){if(!_0x4b44c9||!('oauthAccessToken'in _0x4b44c9)||!_0x4b44c9['oauthAccessToken'])return null;try{return he['credential'](_0x4b44c9['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x39b495,_0x4c70e6){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x39b495,'accessToken':_0x4c70e6});}static['credentialFromResult'](_0x25f62a){return ue['credentialFromTaggedObject'](_0x25f62a);}static['credentialFromError'](_0x1fc9ea){return ue['credentialFromTaggedObject'](_0x1fc9ea['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x17cea9}){if(!_0x17cea9)return null;const {oauthIdToken:_0x5e3460,oauthAccessToken:_0x3a991e}=_0x17cea9;if(!_0x5e3460&&!_0x3a991e)return null;try{return ue['credential'](_0x5e3460,_0x3a991e);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x2ce1de){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x2ce1de});}static['credentialFromResult'](_0x1e2332){return de['credentialFromTaggedObject'](_0x1e2332);}static['credentialFromError'](_0x3f003d){return de['credentialFromTaggedObject'](_0x3f003d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x57f970}){if(!_0x57f970||!('oauthAccessToken'in _0x57f970)||!_0x57f970['oauthAccessToken'])return null;try{return de['credential'](_0x57f970['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x513f84,_0xc3288a){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x513f84,'oauthTokenSecret':_0xc3288a});}static['credentialFromResult'](_0x55e503){return fe['credentialFromTaggedObject'](_0x55e503);}static['credentialFromError'](_0x4772dc){return fe['credentialFromTaggedObject'](_0x4772dc['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5c5a9b}){if(!_0x5c5a9b)return null;const {oauthAccessToken:_0x3751a1,oauthTokenSecret:_0x49239a}=_0x5c5a9b;if(!_0x3751a1||!_0x49239a)return null;try{return fe['credential'](_0x3751a1,_0x49239a);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x14140f,_0x169db8){return Yt(_0x14140f,'POST','/v1/accounts:signUp',Re(_0x14140f,_0x169db8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x11d6d4){this['user']=_0x11d6d4['user'],this['providerId']=_0x11d6d4['providerId'],this['_tokenResponse']=_0x11d6d4['_tokenResponse'],this['operationType']=_0x11d6d4['operationType'];}static async['_fromIdTokenResponse'](_0x2891ff,_0x4b618f,_0x853660,_0x3b2522=!0x1){const _0x7eab05=await z['_fromIdTokenResponse'](_0x2891ff,_0x853660,_0x3b2522),_0x4f17b7=Ar(_0x853660);return new Be({'user':_0x7eab05,'providerId':_0x4f17b7,'_tokenResponse':_0x853660,'operationType':_0x4b618f});}static async['_forOperation'](_0x5cf97f,_0xb5955b,_0x1f593a){await _0x5cf97f['_updateTokensIfNecessary'](_0x1f593a,!0x0);const _0x199e57=Ar(_0x1f593a);return new Be({'user':_0x5cf97f,'providerId':_0x199e57,'_tokenResponse':_0x1f593a,'operationType':_0xb5955b});}}function Ar(_0xfbf6ca){return _0xfbf6ca['providerId']?_0xfbf6ca['providerId']:'phoneNumber'in _0xfbf6ca?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x5b2d84,_0x503d17,_0x40140f,_0x23741c){super(_0x503d17['code'],_0x503d17['message']),this['operationType']=_0x40140f,this['user']=_0x23741c,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x5b2d84['name'],'tenantId':_0x5b2d84['tenantId']??void 0x0,'_serverResponse':_0x503d17['customData']['_serverResponse'],'operationType':_0x40140f};}static['_fromErrorAndOperation'](_0x520ff5,_0x576b97,_0x1a50c1,_0x181150){return new Rn(_0x520ff5,_0x576b97,_0x1a50c1,_0x181150);}}function Fa(_0x23dc11,_0x4f49d7,_0x30c6bf,_0x5a7694){return(_0x4f49d7==='reauthenticate'?_0x30c6bf['_getReauthenticationResolver'](_0x23dc11):_0x30c6bf['_getIdTokenResponse'](_0x23dc11))['catch'](_0x1be19d=>{throw _0x1be19d['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x23dc11,_0x1be19d,_0x4f49d7,_0x5a7694):_0x1be19d;});}async function jf(_0x489979,_0x2f48a1,_0x40abba=!0x1){const _0x459d61=await xt(_0x489979,_0x2f48a1['_linkToIdToken'](_0x489979['auth'],await _0x489979['getIdToken']()),_0x40abba);return Be['_forOperation'](_0x489979,'link',_0x459d61);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x5c4f62,_0xc24a14,_0x23a51e=!0x1){const {auth:_0x591b7f}=_0x5c4f62;if(H(_0x591b7f['app']))return Promise['reject'](se(_0x591b7f));const _0x99176d='reauthenticate';try{const _0x2e52f6=await xt(_0x5c4f62,Fa(_0x591b7f,_0x99176d,_0xc24a14,_0x5c4f62),_0x23a51e);m(_0x2e52f6['idToken'],_0x591b7f,'internal-error');const _0x56bed8=ws(_0x2e52f6['idToken']);m(_0x56bed8,_0x591b7f,'internal-error');const {sub:_0x460b22}=_0x56bed8;return m(_0x5c4f62['uid']===_0x460b22,_0x591b7f,'user-mismatch'),Be['_forOperation'](_0x5c4f62,_0x99176d,_0x2e52f6);}catch(_0x373364){throw(_0x373364==null?void 0x0:_0x373364['code'])==='auth/user-not-found'&&K(_0x591b7f,'user-mismatch'),_0x373364;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x2cda23,_0x53b121,_0x30bed7=!0x1){if(H(_0x2cda23['app']))return Promise['reject'](se(_0x2cda23));const _0x5e3302='signIn',_0x3cc701=await Fa(_0x2cda23,_0x5e3302,_0x53b121),_0x5bd2c5=await Be['_fromIdTokenResponse'](_0x2cda23,_0x5e3302,_0x3cc701);return _0x30bed7||await _0x2cda23['_updateCurrentUser'](_0x5bd2c5['user']),_0x5bd2c5;}async function Yf(_0x4d33e5,_0x25a512){return Ua(qe(_0x4d33e5),_0x25a512);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x1edcbc){const _0x40adcf=qe(_0x1edcbc);_0x40adcf['_getPasswordPolicyInternal']()&&await _0x40adcf['_updatePasswordPolicy']();}async function R_(_0x3bf720,_0x8cd235,_0x55eb85){if(H(_0x3bf720['app']))return Promise['reject'](se(_0x3bf720));const _0x24c74b=qe(_0x3bf720),_0x19434b=await Oi(_0x24c74b,{'returnSecureToken':!0x0,'email':_0x8cd235,'password':_0x55eb85,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x498798=>{throw _0x498798['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x3bf720),_0x498798;}),_0x55a92a=await Be['_fromIdTokenResponse'](_0x24c74b,'signIn',_0x19434b);return await _0x24c74b['_updateCurrentUser'](_0x55a92a['user']),_0x55a92a;}function A_(_0x3e1690,_0x44fddf,_0x45b349){return H(_0x3e1690['app'])?Promise['reject'](se(_0x3e1690)):Yf(k(_0x3e1690),ft['credential'](_0x44fddf,_0x45b349))['catch'](async _0x491c5e=>{throw _0x491c5e['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x3e1690),_0x491c5e;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x438a15,_0x38b016){return k(_0x438a15)['setPersistence'](_0x38b016);}function Qf(_0x3c64cd,_0x51ad0b,_0x253b65,_0x3e97f7){return k(_0x3c64cd)['onIdTokenChanged'](_0x51ad0b,_0x253b65,_0x3e97f7);}function Jf(_0x2ccb9c,_0xba1da6,_0x97dfcf){return k(_0x2ccb9c)['beforeAuthStateChanged'](_0xba1da6,_0x97dfcf);}function N_(_0x5aaf09,_0x476086,_0x4a4df7,_0x473835){return k(_0x5aaf09)['onAuthStateChanged'](_0x476086,_0x4a4df7,_0x473835);}function P_(_0x101346){return k(_0x101346)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x40b34f,_0xcac2ac){this['storageRetriever']=_0x40b34f,this['type']=_0xcac2ac;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x50a6a5,_0x478948){return this['storage']['setItem'](_0x50a6a5,JSON['stringify'](_0x478948)),Promise['resolve']();}['_get'](_0x1ee5a7){const _0x35fc8a=this['storage']['getItem'](_0x1ee5a7);return Promise['resolve'](_0x35fc8a?JSON['parse'](_0x35fc8a):null);}['_remove'](_0x5ba21a){return this['storage']['removeItem'](_0x5ba21a),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x99d65f,_0x371b14)=>this['onStorageEvent'](_0x99d65f,_0x371b14),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x24a159){for(const _0x39b5a8 of Object['keys'](this['listeners'])){const _0x2802f2=this['storage']['getItem'](_0x39b5a8),_0x1b75ac=this['localCache'][_0x39b5a8];_0x2802f2!==_0x1b75ac&&_0x24a159(_0x39b5a8,_0x1b75ac,_0x2802f2);}}['onStorageEvent'](_0x296678,_0x3c4d4f=!0x1){if(!_0x296678['key']){this['forAllChangedKeys']((_0x5cbd25,_0x181145,_0x557a41)=>{this['notifyListeners'](_0x5cbd25,_0x557a41);});return;}const _0x46b5d3=_0x296678['key'];_0x3c4d4f?this['detachListener']():this['stopPolling']();const _0x2f6d43=()=>{const _0x58fbd1=this['storage']['getItem'](_0x46b5d3);!_0x3c4d4f&&this['localCache'][_0x46b5d3]===_0x58fbd1||this['notifyListeners'](_0x46b5d3,_0x58fbd1);},_0x3c5d81=this['storage']['getItem'](_0x46b5d3);If()&&_0x3c5d81!==_0x296678['newValue']&&_0x296678['newValue']!==_0x296678['oldValue']?setTimeout(_0x2f6d43,Zf):_0x2f6d43();}['notifyListeners'](_0x4d1a8f,_0x30d1a5){this['localCache'][_0x4d1a8f]=_0x30d1a5;const _0x2823a3=this['listeners'][_0x4d1a8f];if(_0x2823a3){for(const _0x325c13 of Array['from'](_0x2823a3))_0x325c13(_0x30d1a5&&JSON['parse'](_0x30d1a5));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0xd2f9eb,_0xb0e0a4,_0xaf1dab)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0xd2f9eb,'oldValue':_0xb0e0a4,'newValue':_0xaf1dab}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x44856c,_0x5e5e33){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x44856c]||(this['listeners'][_0x44856c]=new Set(),this['localCache'][_0x44856c]=this['storage']['getItem'](_0x44856c)),this['listeners'][_0x44856c]['add'](_0x5e5e33);}['_removeListener'](_0x41c8e3,_0x350554){this['listeners'][_0x41c8e3]&&(this['listeners'][_0x41c8e3]['delete'](_0x350554),this['listeners'][_0x41c8e3]['size']===0x0&&delete this['listeners'][_0x41c8e3]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x31d24b,_0x205f8b){await super['_set'](_0x31d24b,_0x205f8b),this['localCache'][_0x31d24b]=JSON['stringify'](_0x205f8b);}async['_get'](_0x2358c4){const _0x4987d8=await super['_get'](_0x2358c4);return this['localCache'][_0x2358c4]=JSON['stringify'](_0x4987d8),_0x4987d8;}async['_remove'](_0x45b7c8){await super['_remove'](_0x45b7c8),delete this['localCache'][_0x45b7c8];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x40324b,_0x2a26c2){}['_removeListener'](_0x24afd8,_0x395e8a){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0xfeba3a){return Promise['all'](_0xfeba3a['map'](async _0x7a19a6=>{try{return{'fulfilled':!0x0,'value':await _0x7a19a6};}catch(_0x5a5538){return{'fulfilled':!0x1,'reason':_0x5a5538};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x1b5f46){this['eventTarget']=_0x1b5f46,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x155384){const _0x16b82a=this['receivers']['find'](_0x1f80c2=>_0x1f80c2['isListeningto'](_0x155384));if(_0x16b82a)return _0x16b82a;const _0x25d00e=new jn(_0x155384);return this['receivers']['push'](_0x25d00e),_0x25d00e;}['isListeningto'](_0x3701dd){return this['eventTarget']===_0x3701dd;}async['handleEvent'](_0x2d1d05){const _0x60eca1=_0x2d1d05,{eventId:_0x49cfee,eventType:_0x81a491,data:_0xa0771a}=_0x60eca1['data'],_0x35d793=this['handlersMap'][_0x81a491];if(!(_0x35d793!=null&&_0x35d793['size']))return;_0x60eca1['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x49cfee,'eventType':_0x81a491});const _0x3d77c1=Array['from'](_0x35d793)['map'](async _0x34a085=>_0x34a085(_0x60eca1['origin'],_0xa0771a)),_0x13dc00=await tp(_0x3d77c1);_0x60eca1['ports'][0x0]['postMessage']({'status':'done','eventId':_0x49cfee,'eventType':_0x81a491,'response':_0x13dc00});}['_subscribe'](_0xed16b4,_0x271d88){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0xed16b4]||(this['handlersMap'][_0xed16b4]=new Set()),this['handlersMap'][_0xed16b4]['add'](_0x271d88);}['_unsubscribe'](_0x3184a8,_0x21de85){this['handlersMap'][_0x3184a8]&&_0x21de85&&this['handlersMap'][_0x3184a8]['delete'](_0x21de85),(!_0x21de85||this['handlersMap'][_0x3184a8]['size']===0x0)&&delete this['handlersMap'][_0x3184a8],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x579396='',_0xf73172=0xa){let _0x317155='';for(let _0x1487db=0x0;_0x1487db<_0xf73172;_0x1487db++)_0x317155+=Math['floor'](Math['random']()*0xa);return _0x579396+_0x317155;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0xd42753){this['target']=_0xd42753,this['handlers']=new Set();}['removeMessageHandler'](_0x16cd3b){_0x16cd3b['messageChannel']&&(_0x16cd3b['messageChannel']['port1']['removeEventListener']('message',_0x16cd3b['onMessage']),_0x16cd3b['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x16cd3b);}async['_send'](_0x151ba3,_0x3bf1f6,_0x5857b1=0x32){const _0x1a4553=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1a4553)throw new Error('connection_unavailable');let _0x202fa1,_0x232b2f;return new Promise((_0x480ddc,_0x21538b)=>{const _0x49c6ca=bs('',0x14);_0x1a4553['port1']['start']();const _0x123497=setTimeout(()=>{_0x21538b(new Error('unsupported_event'));},_0x5857b1);_0x232b2f={'messageChannel':_0x1a4553,'onMessage'(_0x6839bc){const _0x5a96db=_0x6839bc;if(_0x5a96db['data']['eventId']===_0x49c6ca)switch(_0x5a96db['data']['status']){case'ack':clearTimeout(_0x123497),_0x202fa1=setTimeout(()=>{_0x21538b(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x202fa1),_0x480ddc(_0x5a96db['data']['response']);break;default:clearTimeout(_0x123497),clearTimeout(_0x202fa1),_0x21538b(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x232b2f),_0x1a4553['port1']['addEventListener']('message',_0x232b2f['onMessage']),this['target']['postMessage']({'eventType':_0x151ba3,'eventId':_0x49c6ca,'data':_0x3bf1f6},[_0x1a4553['port2']]);})['finally'](()=>{_0x232b2f&&this['removeMessageHandler'](_0x232b2f);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x10398e){X()['location']['href']=_0x10398e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x36ac55;return((_0x36ac55=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x36ac55['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x1c1a61){this['request']=_0x1c1a61;}['toPromise'](){return new Promise((_0x3093fb,_0x494438)=>{this['request']['addEventListener']('success',()=>{_0x3093fb(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x494438(this['request']['error']);});});}}function Kn(_0x3ea9d4,_0x2324ad){return _0x3ea9d4['transaction']([kn],_0x2324ad?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x3505ee=indexedDB['deleteDatabase'](qa);return new Jt(_0x3505ee)['toPromise']();}function ja(){const _0x36741b=indexedDB['open'](qa,ap);return new Promise((_0x4d7ce2,_0x1601c3)=>{_0x36741b['addEventListener']('error',()=>{_0x1601c3(_0x36741b['error']);}),_0x36741b['addEventListener']('upgradeneeded',()=>{const _0x497c1d=_0x36741b['result'];try{_0x497c1d['createObjectStore'](kn,{'keyPath':za});}catch(_0x497cb7){_0x1601c3(_0x497cb7);}}),_0x36741b['addEventListener']('success',async()=>{const _0x5261f2=_0x36741b['result'];_0x5261f2['objectStoreNames']['contains'](kn)?_0x4d7ce2(_0x5261f2):(_0x5261f2['close'](),await cp(),_0x4d7ce2(await ja()));});});}async function kr(_0x4b8bea,_0x4a4592,_0x50a387){const _0x456612=Kn(_0x4b8bea,!0x0)['put']({[za]:_0x4a4592,'value':_0x50a387});return new Jt(_0x456612)['toPromise']();}async function lp(_0x445f41,_0xaa5d9c){const _0x34b50a=Kn(_0x445f41,!0x1)['get'](_0xaa5d9c),_0x4b670e=await new Jt(_0x34b50a)['toPromise']();return _0x4b670e===void 0x0?null:_0x4b670e['value'];}function Nr(_0x44a016,_0x1c0bee){const _0x5090c2=Kn(_0x44a016,!0x0)['delete'](_0x1c0bee);return new Jt(_0x5090c2)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x24c194){let _0x28cd41=0x0;for(;;)try{const _0x5c5ec8=await this['_openDb']();return await _0x24c194(_0x5c5ec8);}catch(_0x3c0e65){if(_0x28cd41++>up)throw _0x3c0e65;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x4927dd,_0x3cda58)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3cda58['key'])})),this['receiver']['_subscribe']('ping',async(_0x522a5a,_0x230e38)=>['keyChanged']);}async['initializeSender'](){var _0x23ca53,_0x178b75;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x466cc5=await this['sender']['_send']('ping',{},0x320);_0x466cc5&&(_0x23ca53=_0x466cc5[0x0])!=null&&_0x23ca53['fulfilled']&&(_0x178b75=_0x466cc5[0x0])!=null&&_0x178b75['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x5da3d8){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x5da3d8},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2f1d72=>{await kr(_0x2f1d72,An,'1'),await Nr(_0x2f1d72,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2998d4){this['pendingWrites']++;try{await _0x2998d4();}finally{this['pendingWrites']--;}}async['_set'](_0x354a59,_0x5d1610){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2e6760=>kr(_0x2e6760,_0x354a59,_0x5d1610)),this['localCache'][_0x354a59]=_0x5d1610,this['notifyServiceWorker'](_0x354a59)));}async['_get'](_0x5e37a0){const _0x29f658=await this['_withRetries'](_0x2c5777=>lp(_0x2c5777,_0x5e37a0));return this['localCache'][_0x5e37a0]=_0x29f658,_0x29f658;}async['_remove'](_0x1f4006){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x57fc63=>Nr(_0x57fc63,_0x1f4006)),delete this['localCache'][_0x1f4006],this['notifyServiceWorker'](_0x1f4006)));}async['_poll'](){const _0x14f75c=await this['_withRetries'](_0x21cad6=>{const _0x42d016=Kn(_0x21cad6,!0x1)['getAll']();return new Jt(_0x42d016)['toPromise']();});if(!_0x14f75c)return[];if(this['pendingWrites']!==0x0)return[];const _0xa30b6d=[],_0x39abe9=new Set();if(_0x14f75c['length']!==0x0){for(const {fbase_key:_0x5339ec,value:_0x124684}of _0x14f75c)_0x39abe9['add'](_0x5339ec),JSON['stringify'](this['localCache'][_0x5339ec])!==JSON['stringify'](_0x124684)&&(this['notifyListeners'](_0x5339ec,_0x124684),_0xa30b6d['push'](_0x5339ec));}for(const _0x4f5a63 of Object['keys'](this['localCache']))this['localCache'][_0x4f5a63]&&!_0x39abe9['has'](_0x4f5a63)&&(this['notifyListeners'](_0x4f5a63,null),_0xa30b6d['push'](_0x4f5a63));return _0xa30b6d;}['notifyListeners'](_0x1de9bc,_0x562e55){this['localCache'][_0x1de9bc]=_0x562e55;const _0x1bbee6=this['listeners'][_0x1de9bc];if(_0x1bbee6){for(const _0x39f5fb of Array['from'](_0x1bbee6))_0x39f5fb(_0x562e55);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x39c2eb,_0x402012){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x39c2eb]||(this['listeners'][_0x39c2eb]=new Set(),this['_get'](_0x39c2eb)),this['listeners'][_0x39c2eb]['add'](_0x402012);}['_removeListener'](_0x5dfdec,_0x42fde3){this['listeners'][_0x5dfdec]&&(this['listeners'][_0x5dfdec]['delete'](_0x42fde3),this['listeners'][_0x5dfdec]['size']===0x0&&delete this['listeners'][_0x5dfdec]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x59f34c,_0x57eda1){return _0x57eda1?ne(_0x57eda1):(m(_0x59f34c['_popupRedirectResolver'],_0x59f34c,'argument-error'),_0x59f34c['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x1d6f2a){super('custom','custom'),this['params']=_0x1d6f2a;}['_getIdTokenResponse'](_0x1be7d0){return Ze(_0x1be7d0,this['_buildIdpRequest']());}['_linkToIdToken'](_0x271bff,_0xfa2833){return Ze(_0x271bff,this['_buildIdpRequest'](_0xfa2833));}['_getReauthenticationResolver'](_0x41b80b){return Ze(_0x41b80b,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x4f5834){const _0x5e73c1={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x4f5834&&(_0x5e73c1['idToken']=_0x4f5834),_0x5e73c1;}}function pp(_0x539438){return Ua(_0x539438['auth'],new Rs(_0x539438),_0x539438['bypassAuthState']);}function _p(_0x25cd8c){const {auth:_0x205ad7,user:_0x4031a5}=_0x25cd8c;return m(_0x4031a5,_0x205ad7,'internal-error'),Kf(_0x4031a5,new Rs(_0x25cd8c),_0x25cd8c['bypassAuthState']);}async function gp(_0x3d76b9){const {auth:_0x3844fb,user:_0x4397b2}=_0x3d76b9;return m(_0x4397b2,_0x3844fb,'internal-error'),jf(_0x4397b2,new Rs(_0x3d76b9),_0x3d76b9['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x27d181,_0x5d1d67,_0x214ba6,_0x3d38d5,_0x2666be=!0x1){this['auth']=_0x27d181,this['resolver']=_0x214ba6,this['user']=_0x3d38d5,this['bypassAuthState']=_0x2666be,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5d1d67)?_0x5d1d67:[_0x5d1d67];}['execute'](){return new Promise(async(_0x5d261e,_0x2552a0)=>{this['pendingPromise']={'resolve':_0x5d261e,'reject':_0x2552a0};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x22bd97){this['reject'](_0x22bd97);}});}async['onAuthEvent'](_0x497412){const {urlResponse:_0x6e2ab,sessionId:_0x3bd2a9,postBody:_0x165773,tenantId:_0x30165d,error:_0x4187f6,type:_0x25264d}=_0x497412;if(_0x4187f6){this['reject'](_0x4187f6);return;}const _0x42262e={'auth':this['auth'],'requestUri':_0x6e2ab,'sessionId':_0x3bd2a9,'tenantId':_0x30165d||void 0x0,'postBody':_0x165773||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x25264d)(_0x42262e));}catch(_0x288a3a){this['reject'](_0x288a3a);}}['onError'](_0x44260f){this['reject'](_0x44260f);}['getIdpTask'](_0x30fc26){switch(_0x30fc26){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x36d3a6){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x36d3a6),this['unregisterAndCleanUp']();}['reject'](_0x116e6c){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x116e6c),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x54d58a,_0x329b4b,_0x114f3f,_0x761cb0,_0x4f1bb9){super(_0x54d58a,_0x329b4b,_0x761cb0,_0x4f1bb9),this['provider']=_0x114f3f,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0xf0ee86=await this['execute']();return m(_0xf0ee86,this['auth'],'internal-error'),_0xf0ee86;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x374027=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x374027),this['authWindow']['associatedEvent']=_0x374027,this['resolver']['_originValidation'](this['auth'])['catch'](_0x183be0=>{this['reject'](_0x183be0);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x20867d=>{_0x20867d||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5a00ad;return((_0x5a00ad=this['authWindow'])==null?void 0x0:_0x5a00ad['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x47ed82=()=>{var _0x3bad53,_0x19f9d8;if((_0x19f9d8=(_0x3bad53=this['authWindow'])==null?void 0x0:_0x3bad53['window'])!=null&&_0x19f9d8['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x47ed82,mp['get']());};_0x47ed82();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x5c6429,_0x273d8d,_0x1d75f4=!0x1){super(_0x5c6429,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x273d8d,void 0x0,_0x1d75f4),this['eventId']=null;}async['execute'](){let _0x4db1e6=rn['get'](this['auth']['_key']());if(!_0x4db1e6){try{const _0x538841=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x4db1e6=()=>Promise['resolve'](_0x538841);}catch(_0x1b6725){_0x4db1e6=()=>Promise['reject'](_0x1b6725);}rn['set'](this['auth']['_key'](),_0x4db1e6);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4db1e6();}async['onAuthEvent'](_0x39b4d4){if(_0x39b4d4['type']==='signInViaRedirect')return super['onAuthEvent'](_0x39b4d4);if(_0x39b4d4['type']==='unknown'){this['resolve'](null);return;}if(_0x39b4d4['eventId']){const _0x261699=await this['auth']['_redirectUserForId'](_0x39b4d4['eventId']);if(_0x261699)return this['user']=_0x261699,super['onAuthEvent'](_0x39b4d4);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x950691,_0x5c4ad9){const _0x1da1ce=Cp(_0x5c4ad9),_0x503ecc=wp(_0x950691);if(!await _0x503ecc['_isAvailable']())return!0x1;const _0x374291=await _0x503ecc['_get'](_0x1da1ce)==='true';return await _0x503ecc['_remove'](_0x1da1ce),_0x374291;}function Ip(_0x4357ff,_0x1b3f94){rn['set'](_0x4357ff['_key'](),_0x1b3f94);}function wp(_0x157bb0){return ne(_0x157bb0['_redirectPersistence']);}function Cp(_0x1aa7da){return sn(yp,_0x1aa7da['config']['apiKey'],_0x1aa7da['name']);}async function Tp(_0x2c7fea,_0x101e01,_0x4079c7=!0x1){if(H(_0x2c7fea['app']))return Promise['reject'](se(_0x2c7fea));const _0x175f7f=qe(_0x2c7fea),_0x3b9d4b=fp(_0x175f7f,_0x101e01),_0x4293d6=await new vp(_0x175f7f,_0x3b9d4b,_0x4079c7)['execute']();return _0x4293d6&&!_0x4079c7&&(delete _0x4293d6['user']['_redirectEventId'],await _0x175f7f['_persistUserIfCurrent'](_0x4293d6['user']),await _0x175f7f['_setRedirectUser'](null,_0x101e01)),_0x4293d6;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0xb2bbbe){this['auth']=_0xb2bbbe,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4fa576){this['consumers']['add'](_0x4fa576),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4fa576)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4fa576),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1d0896){this['consumers']['delete'](_0x1d0896);}['onEvent'](_0x58c035){if(this['hasEventBeenHandled'](_0x58c035))return!0x1;let _0x11e330=!0x1;return this['consumers']['forEach'](_0x1a523f=>{this['isEventForConsumer'](_0x58c035,_0x1a523f)&&(_0x11e330=!0x0,this['sendToConsumer'](_0x58c035,_0x1a523f),this['saveEventToCache'](_0x58c035));}),this['hasHandledPotentialRedirect']||!Rp(_0x58c035)||(this['hasHandledPotentialRedirect']=!0x0,_0x11e330||(this['queuedRedirectEvent']=_0x58c035,_0x11e330=!0x0)),_0x11e330;}['sendToConsumer'](_0x1ba439,_0x15879d){var _0x14300e;if(_0x1ba439['error']&&!Qa(_0x1ba439)){const _0x36a3d1=((_0x14300e=_0x1ba439['error']['code'])==null?void 0x0:_0x14300e['split']('auth/')[0x1])||'internal-error';_0x15879d['onError'](J(this['auth'],_0x36a3d1));}else _0x15879d['onAuthEvent'](_0x1ba439);}['isEventForConsumer'](_0x2ab2cf,_0x3d3c3a){const _0x2c4a00=_0x3d3c3a['eventId']===null||!!_0x2ab2cf['eventId']&&_0x2ab2cf['eventId']===_0x3d3c3a['eventId'];return _0x3d3c3a['filter']['includes'](_0x2ab2cf['type'])&&_0x2c4a00;}['hasEventBeenHandled'](_0x27ceff){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x27ceff));}['saveEventToCache'](_0x2a1693){this['cachedEventUids']['add'](Pr(_0x2a1693)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x23f002){return[_0x23f002['type'],_0x23f002['eventId'],_0x23f002['sessionId'],_0x23f002['tenantId']]['filter'](_0x4b545f=>_0x4b545f)['join']('-');}function Qa({type:_0x3a1255,error:_0x252785}){return _0x3a1255==='unknown'&&(_0x252785==null?void 0x0:_0x252785['code'])==='auth/no-auth-event';}function Rp(_0x5a5128){switch(_0x5a5128['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x5a5128);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x38e681,_0x5214dc={}){return Ae(_0x38e681,'GET','/v1/projects',_0x5214dc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x330457){if(_0x330457['config']['emulator'])return;const {authorizedDomains:_0x1f13dc}=await Ap(_0x330457);for(const _0x5bc872 of _0x1f13dc)try{if(Op(_0x5bc872))return;}catch{}K(_0x330457,'unauthorized-domain');}function Op(_0x602686){const _0x162944=Ni(),{protocol:_0xf201aa,hostname:_0x250664}=new URL(_0x162944);if(_0x602686['startsWith']('chrome-extension://')){const _0x10b17d=new URL(_0x602686);return _0x10b17d['hostname']===''&&_0x250664===''?_0xf201aa==='chrome-extension:'&&_0x602686['replace']('chrome-extension://','')===_0x162944['replace']('chrome-extension://',''):_0xf201aa==='chrome-extension:'&&_0x10b17d['hostname']===_0x250664;}if(!Np['test'](_0xf201aa))return!0x1;if(kp['test'](_0x602686))return _0x250664===_0x602686;const _0x45a9b1=_0x602686['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x45a9b1+'|'+_0x45a9b1+')$','i')['test'](_0x250664);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x2a8270=X()['___jsl'];if(_0x2a8270!=null&&_0x2a8270['H']){for(const _0x46d77c of Object['keys'](_0x2a8270['H']))if(_0x2a8270['H'][_0x46d77c]['r']=_0x2a8270['H'][_0x46d77c]['r']||[],_0x2a8270['H'][_0x46d77c]['L']=_0x2a8270['H'][_0x46d77c]['L']||[],_0x2a8270['H'][_0x46d77c]['r']=[..._0x2a8270['H'][_0x46d77c]['L']],_0x2a8270['CP']){for(let _0x31d9e4=0x0;_0x31d9e4<_0x2a8270['CP']['length'];_0x31d9e4++)_0x2a8270['CP'][_0x31d9e4]=null;}}}function Mp(_0x6716cb){return new Promise((_0x314884,_0x432f56)=>{var _0x825969,_0x5f14a2,_0x11d598;function _0x4e27d5(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x314884(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x432f56(J(_0x6716cb,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x5f14a2=(_0x825969=X()['gapi'])==null?void 0x0:_0x825969['iframes'])!=null&&_0x5f14a2['Iframe'])_0x314884(gapi['iframes']['getContext']());else{if((_0x11d598=X()['gapi'])!=null&&_0x11d598['load'])_0x4e27d5();else{const _0x4e6211=Nf('iframefcb');return X()[_0x4e6211]=()=>{gapi['load']?_0x4e27d5():_0x432f56(J(_0x6716cb,'network-request-failed'));},Da(kf()+'?onload='+_0x4e6211)['catch'](_0x21fd00=>_0x432f56(_0x21fd00));}}})['catch'](_0x4d0106=>{throw on=null,_0x4d0106;});}let on=null;function Lp(_0x42017b){return on=on||Mp(_0x42017b),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x441f31){const _0x463fe8=_0x441f31['config'];m(_0x463fe8['authDomain'],_0x441f31,'auth-domain-config-required');const _0x8b4c27=_0x463fe8['emulator']?Is(_0x463fe8,Up):'https://'+_0x441f31['config']['authDomain']+'/'+Fp,_0xc16118={'apiKey':_0x463fe8['apiKey'],'appName':_0x441f31['name'],'v':ct},_0x1f363e=Bp['get'](_0x441f31['config']['apiHost']);_0x1f363e&&(_0xc16118['eid']=_0x1f363e);const _0x442df8=_0x441f31['_getFrameworks']();return _0x442df8['length']&&(_0xc16118['fw']=_0x442df8['join'](',')),_0x8b4c27+'?'+at(_0xc16118)['slice'](0x1);}async function Hp(_0x4aa230){const _0x50f75e=await Lp(_0x4aa230),_0x2b1fdc=X()['gapi'];return m(_0x2b1fdc,_0x4aa230,'internal-error'),_0x50f75e['open']({'where':document['body'],'url':Vp(_0x4aa230),'messageHandlersFilter':_0x2b1fdc['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x424dc2=>new Promise(async(_0x37fad7,_0x515c8a)=>{await _0x424dc2['restyle']({'setHideOnLeave':!0x1});const _0x3dddb1=J(_0x4aa230,'network-request-failed'),_0x2e3d52=X()['setTimeout'](()=>{_0x515c8a(_0x3dddb1);},xp['get']());function _0x3d329b(){X()['clearTimeout'](_0x2e3d52),_0x37fad7(_0x424dc2);}_0x424dc2['ping'](_0x3d329b)['then'](_0x3d329b,()=>{_0x515c8a(_0x3dddb1);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x5cc1e7){this['window']=_0x5cc1e7,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x23f6b9,_0x5967ac,_0x4d3d4a,_0x53b465=Gp,_0x35bbf9=qp){const _0x5a2116=Math['max']((window['screen']['availHeight']-_0x35bbf9)/0x2,0x0)['toString'](),_0x199ad9=Math['max']((window['screen']['availWidth']-_0x53b465)/0x2,0x0)['toString']();let _0x25bc74='';const _0x26f014={...$p,'width':_0x53b465['toString'](),'height':_0x35bbf9['toString'](),'top':_0x5a2116,'left':_0x199ad9},_0x32ea40=W()['toLowerCase']();_0x4d3d4a&&(_0x25bc74=ba(_0x32ea40)?zp:_0x4d3d4a),Ta(_0x32ea40)&&(_0x5967ac=_0x5967ac||jp,_0x26f014['scrollbars']='yes');const _0x251afe=Object['entries'](_0x26f014)['reduce']((_0x5771b3,[_0x30ae99,_0x2d0cdf])=>''+_0x5771b3+_0x30ae99+'='+_0x2d0cdf+',','');if(Ef(_0x32ea40)&&_0x25bc74!=='_self')return Yp(_0x5967ac||'',_0x25bc74),new Dr(null);const _0x452e5b=window['open'](_0x5967ac||'',_0x25bc74,_0x251afe);m(_0x452e5b,_0x23f6b9,'popup-blocked');try{_0x452e5b['focus']();}catch{}return new Dr(_0x452e5b);}function Yp(_0x1d5fdc,_0x9e181e){const _0x5c1a5=document['createElement']('a');_0x5c1a5['href']=_0x1d5fdc,_0x5c1a5['target']=_0x9e181e;const _0xf25941=document['createEvent']('MouseEvent');_0xf25941['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5c1a5['dispatchEvent'](_0xf25941);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x583b2c,_0x2c5a8e,_0x558590,_0x2d50ed,_0x2d7c36,_0x2c56ca){m(_0x583b2c['config']['authDomain'],_0x583b2c,'auth-domain-config-required'),m(_0x583b2c['config']['apiKey'],_0x583b2c,'invalid-api-key');const _0x56affa={'apiKey':_0x583b2c['config']['apiKey'],'appName':_0x583b2c['name'],'authType':_0x558590,'redirectUrl':_0x2d50ed,'v':ct,'eventId':_0x2d7c36};if(_0x2c5a8e instanceof xa){_0x2c5a8e['setDefaultLanguage'](_0x583b2c['languageCode']),_0x56affa['providerId']=_0x2c5a8e['providerId']||'',hi(_0x2c5a8e['getCustomParameters']())||(_0x56affa['customParameters']=JSON['stringify'](_0x2c5a8e['getCustomParameters']()));for(const [_0x473652,_0x2d9214]of Object['entries']({}))_0x56affa[_0x473652]=_0x2d9214;}if(_0x2c5a8e instanceof Qt){const _0x4e206a=_0x2c5a8e['getScopes']()['filter'](_0x5cdd2d=>_0x5cdd2d!=='');_0x4e206a['length']>0x0&&(_0x56affa['scopes']=_0x4e206a['join'](','));}_0x583b2c['tenantId']&&(_0x56affa['tid']=_0x583b2c['tenantId']);const _0x14fd4d=_0x56affa;for(const _0x593404 of Object['keys'](_0x14fd4d))_0x14fd4d[_0x593404]===void 0x0&&delete _0x14fd4d[_0x593404];const _0x3656a1=await _0x583b2c['_getAppCheckToken'](),_0x4a971e=_0x3656a1?'#'+Xp+'='+encodeURIComponent(_0x3656a1):'';return Zp(_0x583b2c)+'?'+at(_0x14fd4d)['slice'](0x1)+_0x4a971e;}function Zp({config:_0x2fe669}){return _0x2fe669['emulator']?Is(_0x2fe669,Jp):'https://'+_0x2fe669['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x1b6ea7,_0x5bc824,_0x441442,_0x59ae28){var _0x17c34d;ae((_0x17c34d=this['eventManagers'][_0x1b6ea7['_key']()])==null?void 0x0:_0x17c34d['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2e5b77=await Mr(_0x1b6ea7,_0x5bc824,_0x441442,Ni(),_0x59ae28);return Kp(_0x1b6ea7,_0x2e5b77,bs());}async['_openRedirect'](_0xc4e43,_0x171644,_0x5b0573,_0x4a7226){await this['_originValidation'](_0xc4e43);const _0x201d0f=await Mr(_0xc4e43,_0x171644,_0x5b0573,Ni(),_0x4a7226);return ip(_0x201d0f),new Promise(()=>{});}['_initialize'](_0x2c975b){const _0x24ee00=_0x2c975b['_key']();if(this['eventManagers'][_0x24ee00]){const {manager:_0x437208,promise:_0x1ca9bb}=this['eventManagers'][_0x24ee00];return _0x437208?Promise['resolve'](_0x437208):(ae(_0x1ca9bb,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1ca9bb);}const _0x193cbf=this['initAndGetManager'](_0x2c975b);return this['eventManagers'][_0x24ee00]={'promise':_0x193cbf},_0x193cbf['catch'](()=>{delete this['eventManagers'][_0x24ee00];}),_0x193cbf;}async['initAndGetManager'](_0x578cc2){const _0x2f73cc=await Hp(_0x578cc2),_0x45affe=new bp(_0x578cc2);return _0x2f73cc['register']('authEvent',_0x4e7632=>(m(_0x4e7632==null?void 0x0:_0x4e7632['authEvent'],_0x578cc2,'invalid-auth-event'),{'status':_0x45affe['onEvent'](_0x4e7632['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x578cc2['_key']()]={'manager':_0x45affe},this['iframes'][_0x578cc2['_key']()]=_0x2f73cc,_0x45affe;}['_isIframeWebStorageSupported'](_0x3112cf,_0x25151f){this['iframes'][_0x3112cf['_key']()]['send'](li,{'type':li},_0x394e25=>{var _0x3e95df;const _0xee9438=(_0x3e95df=_0x394e25==null?void 0x0:_0x394e25[0x0])==null?void 0x0:_0x3e95df[li];_0xee9438!==void 0x0&&_0x25151f(!!_0xee9438),K(_0x3112cf,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x61a6c2){const _0x841bb1=_0x61a6c2['_key']();return this['originValidationPromises'][_0x841bb1]||(this['originValidationPromises'][_0x841bb1]=Pp(_0x61a6c2)),this['originValidationPromises'][_0x841bb1];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x3d505d){this['auth']=_0x3d505d,this['internalListeners']=new Map();}['getUid'](){var _0x1902a2;return this['assertAuthConfigured'](),((_0x1902a2=this['auth']['currentUser'])==null?void 0x0:_0x1902a2['uid'])||null;}async['getToken'](_0x23ef24){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x23ef24)}:null;}['addAuthTokenListener'](_0x3376f7){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3376f7))return;const _0x2c4fa5=this['auth']['onIdTokenChanged'](_0x59baa0=>{_0x3376f7((_0x59baa0==null?void 0x0:_0x59baa0['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3376f7,_0x2c4fa5),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x7b1664){this['assertAuthConfigured']();const _0x1fa8d5=this['internalListeners']['get'](_0x7b1664);_0x1fa8d5&&(this['internalListeners']['delete'](_0x7b1664),_0x1fa8d5(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x38494e){switch(_0x38494e){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x35bb74){et(new Me('auth',(_0x3f5108,{options:_0x187af2})=>{const _0x3f50b8=_0x3f5108['getProvider']('app')['getImmediate'](),_0x40371e=_0x3f5108['getProvider']('heartbeat'),_0x40480d=_0x3f5108['getProvider']('app-check-internal'),{apiKey:_0x22f918,authDomain:_0x452ad}=_0x3f50b8['options'];m(_0x22f918&&!_0x22f918['includes'](':'),'invalid-api-key',{'appName':_0x3f50b8['name']});const _0x4b006a={'apiKey':_0x22f918,'authDomain':_0x452ad,'clientPlatform':_0x35bb74,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x35bb74)},_0x44172c=new bf(_0x3f50b8,_0x40371e,_0x40480d,_0x4b006a);return Lf(_0x44172c,_0x187af2),_0x44172c;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x107bf1,_0x1d2a68,_0x20dd85)=>{_0x107bf1['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x4f2fce=>{const _0x3c21ba=qe(_0x4f2fce['getProvider']('auth')['getImmediate']());return(_0x3e7fd6=>new n_(_0x3e7fd6))(_0x3c21ba);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x35bb74)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x34eaf0=>async _0x516b7b=>{const _0x5c7c6b=_0x516b7b&&await _0x516b7b['getIdTokenResult'](),_0x4b7fd3=_0x5c7c6b&&(new Date()['getTime']()-Date['parse'](_0x5c7c6b['issuedAtTime']))/0x3e8;if(_0x4b7fd3&&_0x4b7fd3>o_)return;const _0x4e3127=_0x5c7c6b==null?void 0x0:_0x5c7c6b['token'];Fr!==_0x4e3127&&(Fr=_0x4e3127,await fetch(_0x34eaf0,{'method':_0x4e3127?'POST':'DELETE','headers':_0x4e3127?{'Authorization':'Bearer\x20'+_0x4e3127}:{}}));};function O_(_0x288e9b=Qr()){const _0x5fa58f=Ui(_0x288e9b,'auth');if(_0x5fa58f['isInitialized']())return _0x5fa58f['getImmediate']();const _0x4a4a2a=Mf(_0x288e9b,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x4499f5=Gr('authTokenSyncURL');if(_0x4499f5&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x372162=new URL(_0x4499f5,location['origin']);if(location['origin']===_0x372162['origin']){const _0x142ad4=a_(_0x372162['toString']());Jf(_0x4a4a2a,_0x142ad4,()=>_0x142ad4(_0x4a4a2a['currentUser'])),Qf(_0x4a4a2a,_0x331301=>_0x142ad4(_0x331301));}}const _0x18782f=Hr('auth');return _0x18782f&&xf(_0x4a4a2a,'http://'+_0x18782f),_0x4a4a2a;}function c_(){var _0x5573e7;return((_0x5573e7=document['getElementsByTagName']('head'))==null?void 0x0:_0x5573e7[0x0])??document;}Rf({'loadJS'(_0x1fcc38){return new Promise((_0x18f270,_0x15114f)=>{const _0x414b48=document['createElement']('script');_0x414b48['setAttribute']('src',_0x1fcc38),_0x414b48['onload']=_0x18f270,_0x414b48['onerror']=_0x5521f2=>{const _0x3353a8=J('internal-error');_0x3353a8['customData']=_0x5521f2,_0x15114f(_0x3353a8);},_0x414b48['type']='text/javascript',_0x414b48['charset']='UTF-8',c_()['appendChild'](_0x414b48);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};