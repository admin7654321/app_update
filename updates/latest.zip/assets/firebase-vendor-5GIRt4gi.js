const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x458519,_0x2d8cae){if(!_0x458519)throw ot(_0x2d8cae);},ot=function(_0x45627f){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x45627f);},Wr=function(_0x9fe2ea){const _0x2d6ae7=[];let _0x2b8924=0x0;for(let _0x25fe02=0x0;_0x25fe02<_0x9fe2ea['length'];_0x25fe02++){let _0x2b1630=_0x9fe2ea['charCodeAt'](_0x25fe02);_0x2b1630<0x80?_0x2d6ae7[_0x2b8924++]=_0x2b1630:_0x2b1630<0x800?(_0x2d6ae7[_0x2b8924++]=_0x2b1630>>0x6|0xc0,_0x2d6ae7[_0x2b8924++]=_0x2b1630&0x3f|0x80):(_0x2b1630&0xfc00)===0xd800&&_0x25fe02+0x1<_0x9fe2ea['length']&&(_0x9fe2ea['charCodeAt'](_0x25fe02+0x1)&0xfc00)===0xdc00?(_0x2b1630=0x10000+((_0x2b1630&0x3ff)<<0xa)+(_0x9fe2ea['charCodeAt'](++_0x25fe02)&0x3ff),_0x2d6ae7[_0x2b8924++]=_0x2b1630>>0x12|0xf0,_0x2d6ae7[_0x2b8924++]=_0x2b1630>>0xc&0x3f|0x80,_0x2d6ae7[_0x2b8924++]=_0x2b1630>>0x6&0x3f|0x80,_0x2d6ae7[_0x2b8924++]=_0x2b1630&0x3f|0x80):(_0x2d6ae7[_0x2b8924++]=_0x2b1630>>0xc|0xe0,_0x2d6ae7[_0x2b8924++]=_0x2b1630>>0x6&0x3f|0x80,_0x2d6ae7[_0x2b8924++]=_0x2b1630&0x3f|0x80);}return _0x2d6ae7;},Za=function(_0x276402){const _0x5ba102=[];let _0x563781=0x0,_0x2a7ce0=0x0;for(;_0x563781<_0x276402['length'];){const _0x2d5aa7=_0x276402[_0x563781++];if(_0x2d5aa7<0x80)_0x5ba102[_0x2a7ce0++]=String['fromCharCode'](_0x2d5aa7);else{if(_0x2d5aa7>0xbf&&_0x2d5aa7<0xe0){const _0x56515b=_0x276402[_0x563781++];_0x5ba102[_0x2a7ce0++]=String['fromCharCode']((_0x2d5aa7&0x1f)<<0x6|_0x56515b&0x3f);}else{if(_0x2d5aa7>0xef&&_0x2d5aa7<0x16d){const _0x2dc649=_0x276402[_0x563781++],_0x10bcca=_0x276402[_0x563781++],_0x150f3a=_0x276402[_0x563781++],_0x1931be=((_0x2d5aa7&0x7)<<0x12|(_0x2dc649&0x3f)<<0xc|(_0x10bcca&0x3f)<<0x6|_0x150f3a&0x3f)-0x10000;_0x5ba102[_0x2a7ce0++]=String['fromCharCode'](0xd800+(_0x1931be>>0xa)),_0x5ba102[_0x2a7ce0++]=String['fromCharCode'](0xdc00+(_0x1931be&0x3ff));}else{const _0x52f1ec=_0x276402[_0x563781++],_0x35c9d5=_0x276402[_0x563781++];_0x5ba102[_0x2a7ce0++]=String['fromCharCode']((_0x2d5aa7&0xf)<<0xc|(_0x52f1ec&0x3f)<<0x6|_0x35c9d5&0x3f);}}}}return _0x5ba102['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xdfc16a,_0x4d15b9){if(!Array['isArray'](_0xdfc16a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x5adda5=_0x4d15b9?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x52de6c=[];for(let _0x5d8acd=0x0;_0x5d8acd<_0xdfc16a['length'];_0x5d8acd+=0x3){const _0x2bb626=_0xdfc16a[_0x5d8acd],_0x5c961d=_0x5d8acd+0x1<_0xdfc16a['length'],_0x3876db=_0x5c961d?_0xdfc16a[_0x5d8acd+0x1]:0x0,_0x4cf821=_0x5d8acd+0x2<_0xdfc16a['length'],_0x1298f6=_0x4cf821?_0xdfc16a[_0x5d8acd+0x2]:0x0,_0x57a027=_0x2bb626>>0x2,_0x3ce3ec=(_0x2bb626&0x3)<<0x4|_0x3876db>>0x4;let _0x17f7ce=(_0x3876db&0xf)<<0x2|_0x1298f6>>0x6,_0x5651d4=_0x1298f6&0x3f;_0x4cf821||(_0x5651d4=0x40,_0x5c961d||(_0x17f7ce=0x40)),_0x52de6c['push'](_0x5adda5[_0x57a027],_0x5adda5[_0x3ce3ec],_0x5adda5[_0x17f7ce],_0x5adda5[_0x5651d4]);}return _0x52de6c['join']('');},'encodeString'(_0x29fdb0,_0x3c2d99){return this['HAS_NATIVE_SUPPORT']&&!_0x3c2d99?btoa(_0x29fdb0):this['encodeByteArray'](Wr(_0x29fdb0),_0x3c2d99);},'decodeString'(_0x462e26,_0x58bb85){return this['HAS_NATIVE_SUPPORT']&&!_0x58bb85?atob(_0x462e26):Za(this['decodeStringToByteArray'](_0x462e26,_0x58bb85));},'decodeStringToByteArray'(_0x4e7762,_0xe74829){this['init_']();const _0x29f132=_0xe74829?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x1398a6=[];for(let _0x1e6652=0x0;_0x1e6652<_0x4e7762['length'];){const _0x56bd49=_0x29f132[_0x4e7762['charAt'](_0x1e6652++)],_0x35d0bb=_0x1e6652<_0x4e7762['length']?_0x29f132[_0x4e7762['charAt'](_0x1e6652)]:0x0;++_0x1e6652;const _0x2d243b=_0x1e6652<_0x4e7762['length']?_0x29f132[_0x4e7762['charAt'](_0x1e6652)]:0x40;++_0x1e6652;const _0x41ede5=_0x1e6652<_0x4e7762['length']?_0x29f132[_0x4e7762['charAt'](_0x1e6652)]:0x40;if(++_0x1e6652,_0x56bd49==null||_0x35d0bb==null||_0x2d243b==null||_0x41ede5==null)throw new ec();const _0x164a16=_0x56bd49<<0x2|_0x35d0bb>>0x4;if(_0x1398a6['push'](_0x164a16),_0x2d243b!==0x40){const _0xe9e5da=_0x35d0bb<<0x4&0xf0|_0x2d243b>>0x2;if(_0x1398a6['push'](_0xe9e5da),_0x41ede5!==0x40){const _0x33cb5f=_0x2d243b<<0x6&0xc0|_0x41ede5;_0x1398a6['push'](_0x33cb5f);}}}return _0x1398a6;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x37ba8b=0x0;_0x37ba8b<this['ENCODED_VALS']['length'];_0x37ba8b++)this['byteToCharMap_'][_0x37ba8b]=this['ENCODED_VALS']['charAt'](_0x37ba8b),this['charToByteMap_'][this['byteToCharMap_'][_0x37ba8b]]=_0x37ba8b,this['byteToCharMapWebSafe_'][_0x37ba8b]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x37ba8b),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x37ba8b]]=_0x37ba8b,_0x37ba8b>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x37ba8b)]=_0x37ba8b,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x37ba8b)]=_0x37ba8b);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x48d5ed){const _0x1a532c=Wr(_0x48d5ed);return Di['encodeByteArray'](_0x1a532c,!0x0);},an=function(_0x532f07){return Br(_0x532f07)['replace'](/\./g,'');},cn=function(_0x5802a3){try{return Di['decodeString'](_0x5802a3,!0x0);}catch(_0x250424){console['error']('base64Decode\x20failed:\x20',_0x250424);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x4c0334){return Vr(void 0x0,_0x4c0334);}function Vr(_0x153c35,_0x2807d8){if(!(_0x2807d8 instanceof Object))return _0x2807d8;switch(_0x2807d8['constructor']){case Date:const _0x53a955=_0x2807d8;return new Date(_0x53a955['getTime']());case Object:_0x153c35===void 0x0&&(_0x153c35={});break;case Array:_0x153c35=[];break;default:return _0x2807d8;}for(const _0x2ff469 in _0x2807d8)!_0x2807d8['hasOwnProperty'](_0x2ff469)||!nc(_0x2ff469)||(_0x153c35[_0x2ff469]=Vr(_0x153c35[_0x2ff469],_0x2807d8[_0x2ff469]));return _0x153c35;}function nc(_0x31c080){return _0x31c080!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x1ed45c=As['__FIREBASE_DEFAULTS__'];if(_0x1ed45c)return JSON['parse'](_0x1ed45c);},oc=()=>{if(typeof document>'u')return;let _0x479492;try{_0x479492=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x192d77=_0x479492&&cn(_0x479492[0x1]);return _0x192d77&&JSON['parse'](_0x192d77);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4ab5c4){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4ab5c4);return;}},Hr=_0x36fa64=>{var _0xbf1b18,_0x25e58e;return(_0x25e58e=(_0xbf1b18=Mi())==null?void 0x0:_0xbf1b18['emulatorHosts'])==null?void 0x0:_0x25e58e[_0x36fa64];},ac=_0x2bf7d1=>{const _0xd07ba3=Hr(_0x2bf7d1);if(!_0xd07ba3)return;const _0x424680=_0xd07ba3['lastIndexOf'](':');if(_0x424680<=0x0||_0x424680+0x1===_0xd07ba3['length'])throw new Error('Invalid\x20host\x20'+_0xd07ba3+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2a3e59=parseInt(_0xd07ba3['substring'](_0x424680+0x1),0xa);return _0xd07ba3[0x0]==='['?[_0xd07ba3['substring'](0x1,_0x424680-0x1),_0x2a3e59]:[_0xd07ba3['substring'](0x0,_0x424680),_0x2a3e59];},$r=()=>{var _0x32bcda;return(_0x32bcda=Mi())==null?void 0x0:_0x32bcda['config'];},Gr=_0x44fb8f=>{var _0x483a53;return(_0x483a53=Mi())==null?void 0x0:_0x483a53['_'+_0x44fb8f];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x518446,_0x261670)=>{this['resolve']=_0x518446,this['reject']=_0x261670;});}['wrapCallback'](_0x1991d7){return(_0x4753e8,_0x382787)=>{_0x4753e8?this['reject'](_0x4753e8):this['resolve'](_0x382787),typeof _0x1991d7=='function'&&(this['promise']['catch'](()=>{}),_0x1991d7['length']===0x1?_0x1991d7(_0x4753e8):_0x1991d7(_0x4753e8,_0x382787));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x18c63d,_0x504be9){if(_0x18c63d['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5e2794={'alg':'none','type':'JWT'},_0x5df8c5=_0x504be9||'demo-project',_0x39bf1a=_0x18c63d['iat']||0x0,_0x33fff9=_0x18c63d['sub']||_0x18c63d['user_id'];if(!_0x33fff9)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x19e7e2={'iss':'https://securetoken.google.com/'+_0x5df8c5,'aud':_0x5df8c5,'iat':_0x39bf1a,'exp':_0x39bf1a+0xe10,'auth_time':_0x39bf1a,'sub':_0x33fff9,'user_id':_0x33fff9,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x18c63d};return[an(JSON['stringify'](_0x5e2794)),an(JSON['stringify'](_0x19e7e2)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0xa69974=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0xa69974=='object'&&_0xa69974['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x328a09=W();return _0x328a09['indexOf']('MSIE\x20')>=0x0||_0x328a09['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x3abcbb,_0x2365e3)=>{try{let _0x59af69=!0x0;const _0x749573='validate-browser-context-for-indexeddb-analytics-module',_0x290fc5=self['indexedDB']['open'](_0x749573);_0x290fc5['onsuccess']=()=>{_0x290fc5['result']['close'](),_0x59af69||self['indexedDB']['deleteDatabase'](_0x749573),_0x3abcbb(!0x0);},_0x290fc5['onupgradeneeded']=()=>{_0x59af69=!0x1;},_0x290fc5['onerror']=()=>{var _0x479047;_0x2365e3(((_0x479047=_0x290fc5['error'])==null?void 0x0:_0x479047['message'])||'');};}catch(_0x1d858a){_0x2365e3(_0x1d858a);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x2ddcef,_0x2188c2,_0x2b2ab0){super(_0x2188c2),this['code']=_0x2ddcef,this['customData']=_0x2b2ab0,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0xb0ae31,_0x66507c,_0x3bc1f8){this['service']=_0xb0ae31,this['serviceName']=_0x66507c,this['errors']=_0x3bc1f8;}['create'](_0x5bd436,..._0x251285){const _0x550844=_0x251285[0x0]||{},_0x5eb56d=this['service']+'/'+_0x5bd436,_0x45025c=this['errors'][_0x5bd436],_0x277046=_0x45025c?gc(_0x45025c,_0x550844):'Error',_0x13531e=this['serviceName']+':\x20'+_0x277046+'\x20('+_0x5eb56d+').';return new Se(_0x5eb56d,_0x13531e,_0x550844);}}function gc(_0x4c0568,_0x1dc72f){return _0x4c0568['replace'](mc,(_0x30d446,_0x541ded)=>{const _0x37a093=_0x1dc72f[_0x541ded];return _0x37a093!=null?String(_0x37a093):'<'+_0x541ded+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x10640b){return JSON['parse'](_0x10640b);}function O(_0xdbe9f7){return JSON['stringify'](_0xdbe9f7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x537c9a){let _0x3f30ea={},_0x34e3b4={},_0xb5e2cb={},_0x18fa6c='';try{const _0x2203e7=_0x537c9a['split']('.');_0x3f30ea=bt(cn(_0x2203e7[0x0])||''),_0x34e3b4=bt(cn(_0x2203e7[0x1])||''),_0x18fa6c=_0x2203e7[0x2],_0xb5e2cb=_0x34e3b4['d']||{},delete _0x34e3b4['d'];}catch{}return{'header':_0x3f30ea,'claims':_0x34e3b4,'data':_0xb5e2cb,'signature':_0x18fa6c};},yc=function(_0x19b7f8){const _0x38581b=zr(_0x19b7f8),_0x3edfd3=_0x38581b['claims'];return!!_0x3edfd3&&typeof _0x3edfd3=='object'&&_0x3edfd3['hasOwnProperty']('iat');},vc=function(_0x1d748d){const _0x92fee2=zr(_0x1d748d)['claims'];return typeof _0x92fee2=='object'&&_0x92fee2['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x2ec94d,_0x3cbfd5){return Object['prototype']['hasOwnProperty']['call'](_0x2ec94d,_0x3cbfd5);}function Oe(_0x1ffa83,_0xf3c267){if(Object['prototype']['hasOwnProperty']['call'](_0x1ffa83,_0xf3c267))return _0x1ffa83[_0xf3c267];}function hi(_0x2a4d3d){for(const _0x45bcc4 in _0x2a4d3d)if(Object['prototype']['hasOwnProperty']['call'](_0x2a4d3d,_0x45bcc4))return!0x1;return!0x0;}function ln(_0x142a4f,_0x38671c,_0x3a8fd2){const _0x54532d={};for(const _0x275a08 in _0x142a4f)Object['prototype']['hasOwnProperty']['call'](_0x142a4f,_0x275a08)&&(_0x54532d[_0x275a08]=_0x38671c['call'](_0x3a8fd2,_0x142a4f[_0x275a08],_0x275a08,_0x142a4f));return _0x54532d;}function De(_0x4490d,_0x1e6cbe){if(_0x4490d===_0x1e6cbe)return!0x0;const _0x51602f=Object['keys'](_0x4490d),_0x4483b2=Object['keys'](_0x1e6cbe);for(const _0x43e341 of _0x51602f){if(!_0x4483b2['includes'](_0x43e341))return!0x1;const _0x57c77f=_0x4490d[_0x43e341],_0x4ed2a8=_0x1e6cbe[_0x43e341];if(ks(_0x57c77f)&&ks(_0x4ed2a8)){if(!De(_0x57c77f,_0x4ed2a8))return!0x1;}else{if(_0x57c77f!==_0x4ed2a8)return!0x1;}}for(const _0x36cc6a of _0x4483b2)if(!_0x51602f['includes'](_0x36cc6a))return!0x1;return!0x0;}function ks(_0x11c6a6){return _0x11c6a6!==null&&typeof _0x11c6a6=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x2a28c3){const _0x1f3ec6=[];for(const [_0x449b53,_0x1566a4]of Object['entries'](_0x2a28c3))Array['isArray'](_0x1566a4)?_0x1566a4['forEach'](_0x1cbeaf=>{_0x1f3ec6['push'](encodeURIComponent(_0x449b53)+'='+encodeURIComponent(_0x1cbeaf));}):_0x1f3ec6['push'](encodeURIComponent(_0x449b53)+'='+encodeURIComponent(_0x1566a4));return _0x1f3ec6['length']?'&'+_0x1f3ec6['join']('&'):'';}function yt(_0x34abee){const _0x1f9fea={};return _0x34abee['replace'](/^\?/,'')['split']('&')['forEach'](_0x448863=>{if(_0x448863){const [_0x50bb38,_0x1fd466]=_0x448863['split']('=');_0x1f9fea[decodeURIComponent(_0x50bb38)]=decodeURIComponent(_0x1fd466);}}),_0x1f9fea;}function vt(_0x212170){const _0x208bcc=_0x212170['indexOf']('?');if(!_0x208bcc)return'';const _0x55c245=_0x212170['indexOf']('#',_0x208bcc);return _0x212170['substring'](_0x208bcc,_0x55c245>0x0?_0x55c245:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x24d106=0x1;_0x24d106<this['blockSize'];++_0x24d106)this['pad_'][_0x24d106]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3d47f9,_0x58a789){_0x58a789||(_0x58a789=0x0);const _0x11a643=this['W_'];if(typeof _0x3d47f9=='string'){for(let _0x59e036=0x0;_0x59e036<0x10;_0x59e036++)_0x11a643[_0x59e036]=_0x3d47f9['charCodeAt'](_0x58a789)<<0x18|_0x3d47f9['charCodeAt'](_0x58a789+0x1)<<0x10|_0x3d47f9['charCodeAt'](_0x58a789+0x2)<<0x8|_0x3d47f9['charCodeAt'](_0x58a789+0x3),_0x58a789+=0x4;}else{for(let _0x49c205=0x0;_0x49c205<0x10;_0x49c205++)_0x11a643[_0x49c205]=_0x3d47f9[_0x58a789]<<0x18|_0x3d47f9[_0x58a789+0x1]<<0x10|_0x3d47f9[_0x58a789+0x2]<<0x8|_0x3d47f9[_0x58a789+0x3],_0x58a789+=0x4;}for(let _0x20e920=0x10;_0x20e920<0x50;_0x20e920++){const _0x2a34e2=_0x11a643[_0x20e920-0x3]^_0x11a643[_0x20e920-0x8]^_0x11a643[_0x20e920-0xe]^_0x11a643[_0x20e920-0x10];_0x11a643[_0x20e920]=(_0x2a34e2<<0x1|_0x2a34e2>>>0x1f)&0xffffffff;}let _0x39b833=this['chain_'][0x0],_0x1291b6=this['chain_'][0x1],_0x151f2c=this['chain_'][0x2],_0x2c5381=this['chain_'][0x3],_0x17a7e1=this['chain_'][0x4],_0x135bdf,_0x5c5a8b;for(let _0x40ee45=0x0;_0x40ee45<0x50;_0x40ee45++){_0x40ee45<0x28?_0x40ee45<0x14?(_0x135bdf=_0x2c5381^_0x1291b6&(_0x151f2c^_0x2c5381),_0x5c5a8b=0x5a827999):(_0x135bdf=_0x1291b6^_0x151f2c^_0x2c5381,_0x5c5a8b=0x6ed9eba1):_0x40ee45<0x3c?(_0x135bdf=_0x1291b6&_0x151f2c|_0x2c5381&(_0x1291b6|_0x151f2c),_0x5c5a8b=0x8f1bbcdc):(_0x135bdf=_0x1291b6^_0x151f2c^_0x2c5381,_0x5c5a8b=0xca62c1d6);const _0x4eedef=(_0x39b833<<0x5|_0x39b833>>>0x1b)+_0x135bdf+_0x17a7e1+_0x5c5a8b+_0x11a643[_0x40ee45]&0xffffffff;_0x17a7e1=_0x2c5381,_0x2c5381=_0x151f2c,_0x151f2c=(_0x1291b6<<0x1e|_0x1291b6>>>0x2)&0xffffffff,_0x1291b6=_0x39b833,_0x39b833=_0x4eedef;}this['chain_'][0x0]=this['chain_'][0x0]+_0x39b833&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1291b6&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x151f2c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2c5381&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x17a7e1&0xffffffff;}['update'](_0x13d1e6,_0x3fbd66){if(_0x13d1e6==null)return;_0x3fbd66===void 0x0&&(_0x3fbd66=_0x13d1e6['length']);const _0x430dc9=_0x3fbd66-this['blockSize'];let _0x54a863=0x0;const _0x27e79b=this['buf_'];let _0x196361=this['inbuf_'];for(;_0x54a863<_0x3fbd66;){if(_0x196361===0x0){for(;_0x54a863<=_0x430dc9;)this['compress_'](_0x13d1e6,_0x54a863),_0x54a863+=this['blockSize'];}if(typeof _0x13d1e6=='string'){for(;_0x54a863<_0x3fbd66;)if(_0x27e79b[_0x196361]=_0x13d1e6['charCodeAt'](_0x54a863),++_0x196361,++_0x54a863,_0x196361===this['blockSize']){this['compress_'](_0x27e79b),_0x196361=0x0;break;}}else{for(;_0x54a863<_0x3fbd66;)if(_0x27e79b[_0x196361]=_0x13d1e6[_0x54a863],++_0x196361,++_0x54a863,_0x196361===this['blockSize']){this['compress_'](_0x27e79b),_0x196361=0x0;break;}}}this['inbuf_']=_0x196361,this['total_']+=_0x3fbd66;}['digest'](){const _0x907e56=[];let _0x41b238=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x49e3fe=this['blockSize']-0x1;_0x49e3fe>=0x38;_0x49e3fe--)this['buf_'][_0x49e3fe]=_0x41b238&0xff,_0x41b238/=0x100;this['compress_'](this['buf_']);let _0xcbfd=0x0;for(let _0x5d3046=0x0;_0x5d3046<0x5;_0x5d3046++)for(let _0x337c6d=0x18;_0x337c6d>=0x0;_0x337c6d-=0x8)_0x907e56[_0xcbfd]=this['chain_'][_0x5d3046]>>_0x337c6d&0xff,++_0xcbfd;return _0x907e56;}}function Ic(_0x1b39e4,_0xa8e614){const _0x47c4a1=new wc(_0x1b39e4,_0xa8e614);return _0x47c4a1['subscribe']['bind'](_0x47c4a1);}class wc{constructor(_0x356e08,_0x2c65e8){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x2c65e8,this['task']['then'](()=>{_0x356e08(this);})['catch'](_0x4370dd=>{this['error'](_0x4370dd);});}['next'](_0x321c20){this['forEachObserver'](_0x5cbb08=>{_0x5cbb08['next'](_0x321c20);});}['error'](_0x539ef4){this['forEachObserver'](_0x43de19=>{_0x43de19['error'](_0x539ef4);}),this['close'](_0x539ef4);}['complete'](){this['forEachObserver'](_0x250fb6=>{_0x250fb6['complete']();}),this['close']();}['subscribe'](_0x4cf7cc,_0x1940fc,_0x152d79){let _0x1d585d;if(_0x4cf7cc===void 0x0&&_0x1940fc===void 0x0&&_0x152d79===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x4cf7cc,['next','error','complete'])?_0x1d585d=_0x4cf7cc:_0x1d585d={'next':_0x4cf7cc,'error':_0x1940fc,'complete':_0x152d79},_0x1d585d['next']===void 0x0&&(_0x1d585d['next']=Qn),_0x1d585d['error']===void 0x0&&(_0x1d585d['error']=Qn),_0x1d585d['complete']===void 0x0&&(_0x1d585d['complete']=Qn);const _0x2c6426=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x1d585d['error'](this['finalError']):_0x1d585d['complete']();}catch{}}),this['observers']['push'](_0x1d585d),_0x2c6426;}['unsubscribeOne'](_0x1dd3be){this['observers']===void 0x0||this['observers'][_0x1dd3be]===void 0x0||(delete this['observers'][_0x1dd3be],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x256202){if(!this['finalized']){for(let _0x518f32=0x0;_0x518f32<this['observers']['length'];_0x518f32++)this['sendOne'](_0x518f32,_0x256202);}}['sendOne'](_0x25be81,_0x25e976){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x25be81]!==void 0x0)try{_0x25e976(this['observers'][_0x25be81]);}catch(_0x179b16){typeof console<'u'&&console['error']&&console['error'](_0x179b16);}});}['close'](_0x538f8e){this['finalized']||(this['finalized']=!0x0,_0x538f8e!==void 0x0&&(this['finalError']=_0x538f8e),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x3a8474,_0x3c31dc){if(typeof _0x3a8474!='object'||_0x3a8474===null)return!0x1;for(const _0x5b0c2a of _0x3c31dc)if(_0x5b0c2a in _0x3a8474&&typeof _0x3a8474[_0x5b0c2a]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x361a0c,_0x1131fa){return _0x361a0c+'\x20failed:\x20'+_0x1131fa+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x589e1e){const _0x300e66=[];let _0x334846=0x0;for(let _0xa50bb5=0x0;_0xa50bb5<_0x589e1e['length'];_0xa50bb5++){let _0x65011d=_0x589e1e['charCodeAt'](_0xa50bb5);if(_0x65011d>=0xd800&&_0x65011d<=0xdbff){const _0x3bdfd9=_0x65011d-0xd800;_0xa50bb5++,f(_0xa50bb5<_0x589e1e['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2991a7=_0x589e1e['charCodeAt'](_0xa50bb5)-0xdc00;_0x65011d=0x10000+(_0x3bdfd9<<0xa)+_0x2991a7;}_0x65011d<0x80?_0x300e66[_0x334846++]=_0x65011d:_0x65011d<0x800?(_0x300e66[_0x334846++]=_0x65011d>>0x6|0xc0,_0x300e66[_0x334846++]=_0x65011d&0x3f|0x80):_0x65011d<0x10000?(_0x300e66[_0x334846++]=_0x65011d>>0xc|0xe0,_0x300e66[_0x334846++]=_0x65011d>>0x6&0x3f|0x80,_0x300e66[_0x334846++]=_0x65011d&0x3f|0x80):(_0x300e66[_0x334846++]=_0x65011d>>0x12|0xf0,_0x300e66[_0x334846++]=_0x65011d>>0xc&0x3f|0x80,_0x300e66[_0x334846++]=_0x65011d>>0x6&0x3f|0x80,_0x300e66[_0x334846++]=_0x65011d&0x3f|0x80);}return _0x300e66;},Pn=function(_0x3e56db){let _0x363ce6=0x0;for(let _0x16b4b6=0x0;_0x16b4b6<_0x3e56db['length'];_0x16b4b6++){const _0x1c85f2=_0x3e56db['charCodeAt'](_0x16b4b6);_0x1c85f2<0x80?_0x363ce6++:_0x1c85f2<0x800?_0x363ce6+=0x2:_0x1c85f2>=0xd800&&_0x1c85f2<=0xdbff?(_0x363ce6+=0x4,_0x16b4b6++):_0x363ce6+=0x3;}return _0x363ce6;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x252e18){return _0x252e18&&_0x252e18['_delegate']?_0x252e18['_delegate']:_0x252e18;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x5aedd0){try{return(_0x5aedd0['startsWith']('http://')||_0x5aedd0['startsWith']('https://')?new URL(_0x5aedd0)['hostname']:_0x5aedd0)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x2571e5){return(await fetch(_0x2571e5,{'credentials':'include'}))['ok'];}class Me{constructor(_0x2ecbf6,_0x59f7dc,_0x16ec87){this['name']=_0x2ecbf6,this['instanceFactory']=_0x59f7dc,this['type']=_0x16ec87,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x367323){return this['instantiationMode']=_0x367323,this;}['setMultipleInstances'](_0x3bb64e){return this['multipleInstances']=_0x3bb64e,this;}['setServiceProps'](_0x26b662){return this['serviceProps']=_0x26b662,this;}['setInstanceCreatedCallback'](_0x25ee0f){return this['onInstanceCreated']=_0x25ee0f,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x4d1776,_0x212944){this['name']=_0x4d1776,this['container']=_0x212944,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x34dc80){const _0x2184ac=this['normalizeInstanceIdentifier'](_0x34dc80);if(!this['instancesDeferred']['has'](_0x2184ac)){const _0x30d424=new Ve();if(this['instancesDeferred']['set'](_0x2184ac,_0x30d424),this['isInitialized'](_0x2184ac)||this['shouldAutoInitialize']())try{const _0x17a21a=this['getOrInitializeService']({'instanceIdentifier':_0x2184ac});_0x17a21a&&_0x30d424['resolve'](_0x17a21a);}catch{}}return this['instancesDeferred']['get'](_0x2184ac)['promise'];}['getImmediate'](_0x4e9f51){const _0x20f91d=this['normalizeInstanceIdentifier'](_0x4e9f51==null?void 0x0:_0x4e9f51['identifier']),_0x25a1cf=(_0x4e9f51==null?void 0x0:_0x4e9f51['optional'])??!0x1;if(this['isInitialized'](_0x20f91d)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x20f91d});}catch(_0x143569){if(_0x25a1cf)return null;throw _0x143569;}else{if(_0x25a1cf)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x336825){if(_0x336825['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x336825['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x336825,!!this['shouldAutoInitialize']()){if(Rc(_0x336825))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x4b8f74,_0x12b992]of this['instancesDeferred']['entries']()){const _0x3a04e5=this['normalizeInstanceIdentifier'](_0x4b8f74);try{const _0x9d1f36=this['getOrInitializeService']({'instanceIdentifier':_0x3a04e5});_0x12b992['resolve'](_0x9d1f36);}catch{}}}}['clearInstance'](_0x180dd3=ke){this['instancesDeferred']['delete'](_0x180dd3),this['instancesOptions']['delete'](_0x180dd3),this['instances']['delete'](_0x180dd3);}async['delete'](){const _0x46e53d=Array['from'](this['instances']['values']());await Promise['all']([..._0x46e53d['filter'](_0x14be2c=>'INTERNAL'in _0x14be2c)['map'](_0x20a5a2=>_0x20a5a2['INTERNAL']['delete']()),..._0x46e53d['filter'](_0x7f0f15=>'_delete'in _0x7f0f15)['map'](_0x56f28a=>_0x56f28a['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x450ddd=ke){return this['instances']['has'](_0x450ddd);}['getOptions'](_0x1aed7b=ke){return this['instancesOptions']['get'](_0x1aed7b)||{};}['initialize'](_0x372b2c={}){const {options:_0x2859b7={}}=_0x372b2c,_0x9d1248=this['normalizeInstanceIdentifier'](_0x372b2c['instanceIdentifier']);if(this['isInitialized'](_0x9d1248))throw Error(this['name']+'('+_0x9d1248+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x504f84=this['getOrInitializeService']({'instanceIdentifier':_0x9d1248,'options':_0x2859b7});for(const [_0x3fcba3,_0x549916]of this['instancesDeferred']['entries']()){const _0x516df1=this['normalizeInstanceIdentifier'](_0x3fcba3);_0x9d1248===_0x516df1&&_0x549916['resolve'](_0x504f84);}return _0x504f84;}['onInit'](_0x4ffb0a,_0x4ac898){const _0x5baf15=this['normalizeInstanceIdentifier'](_0x4ac898),_0x120095=this['onInitCallbacks']['get'](_0x5baf15)??new Set();_0x120095['add'](_0x4ffb0a),this['onInitCallbacks']['set'](_0x5baf15,_0x120095);const _0x17dd11=this['instances']['get'](_0x5baf15);return _0x17dd11&&_0x4ffb0a(_0x17dd11,_0x5baf15),()=>{_0x120095['delete'](_0x4ffb0a);};}['invokeOnInitCallbacks'](_0x3ad997,_0x9e6c0f){const _0x48ef51=this['onInitCallbacks']['get'](_0x9e6c0f);if(_0x48ef51){for(const _0x590c24 of _0x48ef51)try{_0x590c24(_0x3ad997,_0x9e6c0f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x151e4c,options:_0x172d8a={}}){let _0x2ead56=this['instances']['get'](_0x151e4c);if(!_0x2ead56&&this['component']&&(_0x2ead56=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x151e4c),'options':_0x172d8a}),this['instances']['set'](_0x151e4c,_0x2ead56),this['instancesOptions']['set'](_0x151e4c,_0x172d8a),this['invokeOnInitCallbacks'](_0x2ead56,_0x151e4c),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x151e4c,_0x2ead56);}catch{}return _0x2ead56||null;}['normalizeInstanceIdentifier'](_0x4c255f=ke){return this['component']?this['component']['multipleInstances']?_0x4c255f:ke:_0x4c255f;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x36c9c8){return _0x36c9c8===ke?void 0x0:_0x36c9c8;}function Rc(_0x131efa){return _0x131efa['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x22104c){this['name']=_0x22104c,this['providers']=new Map();}['addComponent'](_0x12c021){const _0x461cc1=this['getProvider'](_0x12c021['name']);if(_0x461cc1['isComponentSet']())throw new Error('Component\x20'+_0x12c021['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x461cc1['setComponent'](_0x12c021);}['addOrOverwriteComponent'](_0x3580df){this['getProvider'](_0x3580df['name'])['isComponentSet']()&&this['providers']['delete'](_0x3580df['name']),this['addComponent'](_0x3580df);}['getProvider'](_0x405f27){if(this['providers']['has'](_0x405f27))return this['providers']['get'](_0x405f27);const _0x498028=new Sc(_0x405f27,this);return this['providers']['set'](_0x405f27,_0x498028),_0x498028;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3d8744){_0x3d8744[_0x3d8744['DEBUG']=0x0]='DEBUG',_0x3d8744[_0x3d8744['VERBOSE']=0x1]='VERBOSE',_0x3d8744[_0x3d8744['INFO']=0x2]='INFO',_0x3d8744[_0x3d8744['WARN']=0x3]='WARN',_0x3d8744[_0x3d8744['ERROR']=0x4]='ERROR',_0x3d8744[_0x3d8744['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x375764,_0x8b1d50,..._0xca92a2)=>{if(_0x8b1d50<_0x375764['logLevel'])return;const _0x122bc9=new Date()['toISOString'](),_0x2c86a5=Pc[_0x8b1d50];if(_0x2c86a5)console[_0x2c86a5]('['+_0x122bc9+']\x20\x20'+_0x375764['name']+':',..._0xca92a2);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x8b1d50+')');};class xi{constructor(_0x3dfcd8){this['name']=_0x3dfcd8,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x2f8c1d){if(!(_0x2f8c1d in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x2f8c1d+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x2f8c1d;}['setLogLevel'](_0x4c2ee6){this['_logLevel']=typeof _0x4c2ee6=='string'?kc[_0x4c2ee6]:_0x4c2ee6;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4138dc){if(typeof _0x4138dc!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4138dc;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x9bf9eb){this['_userLogHandler']=_0x9bf9eb;}['debug'](..._0x3fdfc8){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x3fdfc8),this['_logHandler'](this,T['DEBUG'],..._0x3fdfc8);}['log'](..._0x57f532){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x57f532),this['_logHandler'](this,T['VERBOSE'],..._0x57f532);}['info'](..._0x120a7b){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x120a7b),this['_logHandler'](this,T['INFO'],..._0x120a7b);}['warn'](..._0x2c8e5f){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2c8e5f),this['_logHandler'](this,T['WARN'],..._0x2c8e5f);}['error'](..._0x4c08c1){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4c08c1),this['_logHandler'](this,T['ERROR'],..._0x4c08c1);}}const Dc=(_0x192ff2,_0x4e3e84)=>_0x4e3e84['some'](_0x22e3c0=>_0x192ff2 instanceof _0x22e3c0);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x24d8ed){const _0x453312=new Promise((_0x5bb1d0,_0x140d20)=>{const _0x212cd6=()=>{_0x24d8ed['removeEventListener']('success',_0x40db80),_0x24d8ed['removeEventListener']('error',_0x133b77);},_0x40db80=()=>{_0x5bb1d0(_e(_0x24d8ed['result'])),_0x212cd6();},_0x133b77=()=>{_0x140d20(_0x24d8ed['error']),_0x212cd6();};_0x24d8ed['addEventListener']('success',_0x40db80),_0x24d8ed['addEventListener']('error',_0x133b77);});return _0x453312['then'](_0x3711e2=>{_0x3711e2 instanceof IDBCursor&&Kr['set'](_0x3711e2,_0x24d8ed);})['catch'](()=>{}),Fi['set'](_0x453312,_0x24d8ed),_0x453312;}function Fc(_0x2de442){if(ui['has'](_0x2de442))return;const _0x7a6e83=new Promise((_0x338f77,_0x4859b9)=>{const _0x669c7e=()=>{_0x2de442['removeEventListener']('complete',_0x4906a3),_0x2de442['removeEventListener']('error',_0x1cf0f6),_0x2de442['removeEventListener']('abort',_0x1cf0f6);},_0x4906a3=()=>{_0x338f77(),_0x669c7e();},_0x1cf0f6=()=>{_0x4859b9(_0x2de442['error']||new DOMException('AbortError','AbortError')),_0x669c7e();};_0x2de442['addEventListener']('complete',_0x4906a3),_0x2de442['addEventListener']('error',_0x1cf0f6),_0x2de442['addEventListener']('abort',_0x1cf0f6);});ui['set'](_0x2de442,_0x7a6e83);}let di={'get'(_0x3f7c97,_0x1c6e13,_0x25c4c7){if(_0x3f7c97 instanceof IDBTransaction){if(_0x1c6e13==='done')return ui['get'](_0x3f7c97);if(_0x1c6e13==='objectStoreNames')return _0x3f7c97['objectStoreNames']||Yr['get'](_0x3f7c97);if(_0x1c6e13==='store')return _0x25c4c7['objectStoreNames'][0x1]?void 0x0:_0x25c4c7['objectStore'](_0x25c4c7['objectStoreNames'][0x0]);}return _e(_0x3f7c97[_0x1c6e13]);},'set'(_0x532401,_0x47977a,_0x137eb0){return _0x532401[_0x47977a]=_0x137eb0,!0x0;},'has'(_0x5ce4ff,_0x57f1d1){return _0x5ce4ff instanceof IDBTransaction&&(_0x57f1d1==='done'||_0x57f1d1==='store')?!0x0:_0x57f1d1 in _0x5ce4ff;}};function Uc(_0xd1165d){di=_0xd1165d(di);}function Wc(_0x905323){return _0x905323===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x21082d,..._0x2b8094){const _0x5dd3e3=_0x905323['call'](Xn(this),_0x21082d,..._0x2b8094);return Yr['set'](_0x5dd3e3,_0x21082d['sort']?_0x21082d['sort']():[_0x21082d]),_e(_0x5dd3e3);}:Lc()['includes'](_0x905323)?function(..._0x31c8fe){return _0x905323['apply'](Xn(this),_0x31c8fe),_e(Kr['get'](this));}:function(..._0x54ebf4){return _e(_0x905323['apply'](Xn(this),_0x54ebf4));};}function Bc(_0x3ca2fe){return typeof _0x3ca2fe=='function'?Wc(_0x3ca2fe):(_0x3ca2fe instanceof IDBTransaction&&Fc(_0x3ca2fe),Dc(_0x3ca2fe,Mc())?new Proxy(_0x3ca2fe,di):_0x3ca2fe);}function _e(_0x3366d2){if(_0x3366d2 instanceof IDBRequest)return xc(_0x3366d2);if(Jn['has'](_0x3366d2))return Jn['get'](_0x3366d2);const _0x56154d=Bc(_0x3366d2);return _0x56154d!==_0x3366d2&&(Jn['set'](_0x3366d2,_0x56154d),Fi['set'](_0x56154d,_0x3366d2)),_0x56154d;}const Xn=_0x306766=>Fi['get'](_0x306766);function Vc(_0x21c868,_0x23dc7a,{blocked:_0x4fdc10,upgrade:_0x34337d,blocking:_0x12b018,terminated:_0x1b9136}={}){const _0x705e90=indexedDB['open'](_0x21c868,_0x23dc7a),_0x10dee2=_e(_0x705e90);return _0x34337d&&_0x705e90['addEventListener']('upgradeneeded',_0x263558=>{_0x34337d(_e(_0x705e90['result']),_0x263558['oldVersion'],_0x263558['newVersion'],_e(_0x705e90['transaction']),_0x263558);}),_0x4fdc10&&_0x705e90['addEventListener']('blocked',_0x5b1adc=>_0x4fdc10(_0x5b1adc['oldVersion'],_0x5b1adc['newVersion'],_0x5b1adc)),_0x10dee2['then'](_0x4431bc=>{_0x1b9136&&_0x4431bc['addEventListener']('close',()=>_0x1b9136()),_0x12b018&&_0x4431bc['addEventListener']('versionchange',_0x2b10bc=>_0x12b018(_0x2b10bc['oldVersion'],_0x2b10bc['newVersion'],_0x2b10bc));})['catch'](()=>{}),_0x10dee2;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x1bec77,_0x1c6692){if(!(_0x1bec77 instanceof IDBDatabase&&!(_0x1c6692 in _0x1bec77)&&typeof _0x1c6692=='string'))return;if(Zn['get'](_0x1c6692))return Zn['get'](_0x1c6692);const _0x2a46ad=_0x1c6692['replace'](/FromIndex$/,''),_0x1ee177=_0x1c6692!==_0x2a46ad,_0x175c81=$c['includes'](_0x2a46ad);if(!(_0x2a46ad in(_0x1ee177?IDBIndex:IDBObjectStore)['prototype'])||!(_0x175c81||Hc['includes'](_0x2a46ad)))return;const _0x3fa5eb=async function(_0x277cbb,..._0x433e2a){const _0x2f7783=this['transaction'](_0x277cbb,_0x175c81?'readwrite':'readonly');let _0x290858=_0x2f7783['store'];return _0x1ee177&&(_0x290858=_0x290858['index'](_0x433e2a['shift']())),(await Promise['all']([_0x290858[_0x2a46ad](..._0x433e2a),_0x175c81&&_0x2f7783['done']]))[0x0];};return Zn['set'](_0x1c6692,_0x3fa5eb),_0x3fa5eb;}Uc(_0x435a9e=>({..._0x435a9e,'get':(_0x4a35b2,_0x32f2d4,_0x38e95e)=>Os(_0x4a35b2,_0x32f2d4)||_0x435a9e['get'](_0x4a35b2,_0x32f2d4,_0x38e95e),'has':(_0x567c0f,_0x235372)=>!!Os(_0x567c0f,_0x235372)||_0x435a9e['has'](_0x567c0f,_0x235372)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x5a23b2){this['container']=_0x5a23b2;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5ed7fa=>{if(qc(_0x5ed7fa)){const _0x2d8ea6=_0x5ed7fa['getImmediate']();return _0x2d8ea6['library']+'/'+_0x2d8ea6['version'];}else return null;})['filter'](_0x56b10b=>_0x56b10b)['join']('\x20');}}function qc(_0x4d3a61){const _0x10f0cb=_0x4d3a61['getComponent']();return(_0x10f0cb==null?void 0x0:_0x10f0cb['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x2dbe6d,_0x2ac9c4){try{_0x2dbe6d['container']['addComponent'](_0x2ac9c4);}catch(_0x14b6a1){re['debug']('Component\x20'+_0x2ac9c4['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2dbe6d['name'],_0x14b6a1);}}function et(_0x2f02a6){const _0x57afa5=_0x2f02a6['name'];if(gi['has'](_0x57afa5))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x57afa5+'.'),!0x1;gi['set'](_0x57afa5,_0x2f02a6);for(const _0x1ffee0 of Le['values']())Ms(_0x1ffee0,_0x2f02a6);for(const _0x5d1a20 of _i['values']())Ms(_0x5d1a20,_0x2f02a6);return!0x0;}function Ui(_0x6810fc,_0x21e322){const _0x242c93=_0x6810fc['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x242c93&&_0x242c93['triggerHeartbeat'](),_0x6810fc['container']['getProvider'](_0x21e322);}function H(_0x197550){return _0x197550==null?!0x1:_0x197550['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x169cb9,_0x962fbc,_0x45c226){this['_isDeleted']=!0x1,this['_options']={..._0x169cb9},this['_config']={..._0x962fbc},this['_name']=_0x962fbc['name'],this['_automaticDataCollectionEnabled']=_0x962fbc['automaticDataCollectionEnabled'],this['_container']=_0x45c226,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x14de50){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x14de50;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x330493){this['_isDeleted']=_0x330493;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x642456,_0x438a6d={}){let _0x2c8b9f=_0x642456;typeof _0x438a6d!='object'&&(_0x438a6d={'name':_0x438a6d});const _0x3f0dfe={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x438a6d},_0x1b56be=_0x3f0dfe['name'];if(typeof _0x1b56be!='string'||!_0x1b56be)throw ge['create']('bad-app-name',{'appName':String(_0x1b56be)});if(_0x2c8b9f||(_0x2c8b9f=$r()),!_0x2c8b9f)throw ge['create']('no-options');const _0x2d90e9=Le['get'](_0x1b56be);if(_0x2d90e9){if(De(_0x2c8b9f,_0x2d90e9['options'])&&De(_0x3f0dfe,_0x2d90e9['config']))return _0x2d90e9;throw ge['create']('duplicate-app',{'appName':_0x1b56be});}const _0x185e22=new Ac(_0x1b56be);for(const _0x2256e4 of gi['values']())_0x185e22['addComponent'](_0x2256e4);const _0x417d83=new Il(_0x2c8b9f,_0x3f0dfe,_0x185e22);return Le['set'](_0x1b56be,_0x417d83),_0x417d83;}function Qr(_0x4ab156=pi){const _0x1d55a2=Le['get'](_0x4ab156);if(!_0x1d55a2&&_0x4ab156===pi&&$r())return wl();if(!_0x1d55a2)throw ge['create']('no-app',{'appName':_0x4ab156});return _0x1d55a2;}function l_(){return Array['from'](Le['values']());}async function h_(_0xf9110c){let _0x38bd53=!0x1;const _0x52da3d=_0xf9110c['name'];Le['has'](_0x52da3d)?(_0x38bd53=!0x0,Le['delete'](_0x52da3d)):_i['has'](_0x52da3d)&&_0xf9110c['decRefCount']()<=0x0&&(_i['delete'](_0x52da3d),_0x38bd53=!0x0),_0x38bd53&&(await Promise['all'](_0xf9110c['container']['getProviders']()['map'](_0x5f13e7=>_0x5f13e7['delete']())),_0xf9110c['isDeleted']=!0x0);}function me(_0xf3dee6,_0x5164e4,_0x35c19f){let _0x1fcc73=vl[_0xf3dee6]??_0xf3dee6;_0x35c19f&&(_0x1fcc73+='-'+_0x35c19f);const _0x386127=_0x1fcc73['match'](/\s|\//),_0x2547ff=_0x5164e4['match'](/\s|\//);if(_0x386127||_0x2547ff){const _0x4b7ccc=['Unable\x20to\x20register\x20library\x20\x22'+_0x1fcc73+'\x22\x20with\x20version\x20\x22'+_0x5164e4+'\x22:'];_0x386127&&_0x4b7ccc['push']('library\x20name\x20\x22'+_0x1fcc73+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x386127&&_0x2547ff&&_0x4b7ccc['push']('and'),_0x2547ff&&_0x4b7ccc['push']('version\x20name\x20\x22'+_0x5164e4+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x4b7ccc['join']('\x20'));return;}et(new Me(_0x1fcc73+'-version',()=>({'library':_0x1fcc73,'version':_0x5164e4}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x50c510,_0x43b63)=>{switch(_0x43b63){case 0x0:try{_0x50c510['createObjectStore'](Rt);}catch(_0x1c4ad9){console['warn'](_0x1c4ad9);}}}})['catch'](_0x10111d=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x10111d['message']});})),ei;}async function Sl(_0x516632){try{const _0x37052a=(await Jr())['transaction'](Rt),_0x55aa2b=await _0x37052a['objectStore'](Rt)['get'](Xr(_0x516632));return await _0x37052a['done'],_0x55aa2b;}catch(_0x5c0b5f){if(_0x5c0b5f instanceof Se)re['warn'](_0x5c0b5f['message']);else{const _0x11efd5=ge['create']('idb-get',{'originalErrorMessage':_0x5c0b5f==null?void 0x0:_0x5c0b5f['message']});re['warn'](_0x11efd5['message']);}}}async function Ls(_0x59db65,_0x471211){try{const _0x452b1d=(await Jr())['transaction'](Rt,'readwrite');await _0x452b1d['objectStore'](Rt)['put'](_0x471211,Xr(_0x59db65)),await _0x452b1d['done'];}catch(_0x1f8a23){if(_0x1f8a23 instanceof Se)re['warn'](_0x1f8a23['message']);else{const _0x573b24=ge['create']('idb-set',{'originalErrorMessage':_0x1f8a23==null?void 0x0:_0x1f8a23['message']});re['warn'](_0x573b24['message']);}}}function Xr(_0x8679aa){return _0x8679aa['name']+'!'+_0x8679aa['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x363e6c){this['container']=_0x363e6c,this['_heartbeatsCache']=null;const _0x31eb39=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x31eb39),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2795b5=>(this['_heartbeatsCache']=_0x2795b5,_0x2795b5));}async['triggerHeartbeat'](){var _0x300d31,_0x26a0d0;try{const _0x3f59ca=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x31bb54=xs();if(((_0x300d31=this['_heartbeatsCache'])==null?void 0x0:_0x300d31['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x26a0d0=this['_heartbeatsCache'])==null?void 0x0:_0x26a0d0['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x31bb54||this['_heartbeatsCache']['heartbeats']['some'](_0x1bb51a=>_0x1bb51a['date']===_0x31bb54))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x31bb54,'agent':_0x3f59ca}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x11e522=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x11e522,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0xb33dfe){re['warn'](_0xb33dfe);}}async['getHeartbeatsHeader'](){var _0x473811;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x473811=this['_heartbeatsCache'])==null?void 0x0:_0x473811['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5746dc=xs(),{heartbeatsToSend:_0x2f9bbd,unsentEntries:_0x3318c1}=kl(this['_heartbeatsCache']['heartbeats']),_0x544d5f=an(JSON['stringify']({'version':0x2,'heartbeats':_0x2f9bbd}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5746dc,_0x3318c1['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3318c1,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x544d5f;}catch(_0x3a590e){return re['warn'](_0x3a590e),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x24ec60,_0x56c4b3=bl){const _0x423c18=[];let _0x4ecf26=_0x24ec60['slice']();for(const _0x2e7928 of _0x24ec60){const _0x2217d3=_0x423c18['find'](_0x54737f=>_0x54737f['agent']===_0x2e7928['agent']);if(_0x2217d3){if(_0x2217d3['dates']['push'](_0x2e7928['date']),Fs(_0x423c18)>_0x56c4b3){_0x2217d3['dates']['pop']();break;}}else{if(_0x423c18['push']({'agent':_0x2e7928['agent'],'dates':[_0x2e7928['date']]}),Fs(_0x423c18)>_0x56c4b3){_0x423c18['pop']();break;}}_0x4ecf26=_0x4ecf26['slice'](0x1);}return{'heartbeatsToSend':_0x423c18,'unsentEntries':_0x4ecf26};}class Nl{constructor(_0x428ebe){this['app']=_0x428ebe,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x249181=await Sl(this['app']);return _0x249181!=null&&_0x249181['heartbeats']?_0x249181:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1bd358){if(await this['_canUseIndexedDBPromise']){const _0x19b70c=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x1bd358['lastSentHeartbeatDate']??_0x19b70c['lastSentHeartbeatDate'],'heartbeats':_0x1bd358['heartbeats']});}else return;}async['add'](_0x24387b){if(await this['_canUseIndexedDBPromise']){const _0x262a76=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x24387b['lastSentHeartbeatDate']??_0x262a76['lastSentHeartbeatDate'],'heartbeats':[..._0x262a76['heartbeats'],..._0x24387b['heartbeats']]});}else return;}}function Fs(_0x465126){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x465126}))['length'];}function Pl(_0x4e3d8b){if(_0x4e3d8b['length']===0x0)return-0x1;let _0x5f1726=0x0,_0x483c19=_0x4e3d8b[0x0]['date'];for(let _0x10ac5d=0x1;_0x10ac5d<_0x4e3d8b['length'];_0x10ac5d++)_0x4e3d8b[_0x10ac5d]['date']<_0x483c19&&(_0x483c19=_0x4e3d8b[_0x10ac5d]['date'],_0x5f1726=_0x10ac5d);return _0x5f1726;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x3303d2){et(new Me('platform-logger',_0x437a36=>new Gc(_0x437a36),'PRIVATE')),et(new Me('heartbeat',_0x3f01e7=>new Al(_0x3f01e7),'PRIVATE')),me(fi,Ds,_0x3303d2),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x2175b4){Zr=_0x2175b4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x1da37c){this['domStorage_']=_0x1da37c,this['prefix_']='firebase:';}['set'](_0x580d17,_0x52f3b5){_0x52f3b5==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x580d17)):this['domStorage_']['setItem'](this['prefixedName_'](_0x580d17),O(_0x52f3b5));}['get'](_0x54721d){const _0x264e83=this['domStorage_']['getItem'](this['prefixedName_'](_0x54721d));return _0x264e83==null?null:bt(_0x264e83);}['remove'](_0x21e70a){this['domStorage_']['removeItem'](this['prefixedName_'](_0x21e70a));}['prefixedName_'](_0x235603){return this['prefix_']+_0x235603;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2c41b8,_0x286ce9){_0x286ce9==null?delete this['cache_'][_0x2c41b8]:this['cache_'][_0x2c41b8]=_0x286ce9;}['get'](_0x50932a){return Y(this['cache_'],_0x50932a)?this['cache_'][_0x50932a]:null;}['remove'](_0x10d3ee){delete this['cache_'][_0x10d3ee];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x548c57){try{if(typeof window<'u'&&typeof window[_0x548c57]<'u'){const _0xe0349e=window[_0x548c57];return _0xe0349e['setItem']('firebase:sentinel','cache'),_0xe0349e['removeItem']('firebase:sentinel'),new xl(_0xe0349e);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x5bfbd8=0x1;return function(){return _0x5bfbd8++;};}()),no=function(_0xd6341b){const _0x1acf64=Tc(_0xd6341b),_0x2c01ff=new Ec();_0x2c01ff['update'](_0x1acf64);const _0x5250a0=_0x2c01ff['digest']();return Di['encodeByteArray'](_0x5250a0);},Bt=function(..._0x5b6fd3){let _0x5be662='';for(let _0x405102=0x0;_0x405102<_0x5b6fd3['length'];_0x405102++){const _0x65d905=_0x5b6fd3[_0x405102];Array['isArray'](_0x65d905)||_0x65d905&&typeof _0x65d905=='object'&&typeof _0x65d905['length']=='number'?_0x5be662+=Bt['apply'](null,_0x65d905):typeof _0x65d905=='object'?_0x5be662+=O(_0x65d905):_0x5be662+=_0x65d905,_0x5be662+='\x20';}return _0x5be662;};let Et=null,Vs=!0x0;const Wl=function(_0x143b42,_0x576627){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x37d4a1){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x36f7f4=Bt['apply'](null,_0x37d4a1);Et(_0x36f7f4);}},Vt=function(_0x33183c){return function(..._0x4ba497){L(_0x33183c,..._0x4ba497);};},mi=function(..._0x22f991){const _0x3c53da='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x22f991);Qe['error'](_0x3c53da);},oe=function(..._0x5cc957){const _0x588733='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x5cc957);throw Qe['error'](_0x588733),new Error(_0x588733);},U=function(..._0x298daa){const _0xba2781='FIREBASE\x20WARNING:\x20'+Bt(..._0x298daa);Qe['warn'](_0xba2781);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x50996d){return typeof _0x50996d=='number'&&(_0x50996d!==_0x50996d||_0x50996d===Number['POSITIVE_INFINITY']||_0x50996d===Number['NEGATIVE_INFINITY']);},Vl=function(_0x5a5b1d){if(document['readyState']==='complete')_0x5a5b1d();else{let _0x5f11dd=!0x1;const _0x1785f3=function(){if(!document['body']){setTimeout(_0x1785f3,Math['floor'](0xa));return;}_0x5f11dd||(_0x5f11dd=!0x0,_0x5a5b1d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1785f3,!0x1),window['addEventListener']('load',_0x1785f3,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1785f3();}),window['attachEvent']('onload',_0x1785f3));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0xcf7777,_0x1e5c3e){if(_0xcf7777===_0x1e5c3e)return 0x0;if(_0xcf7777===xe||_0x1e5c3e===Ie)return-0x1;if(_0x1e5c3e===xe||_0xcf7777===Ie)return 0x1;{const _0xbebd41=Hs(_0xcf7777),_0x4072ba=Hs(_0x1e5c3e);return _0xbebd41!==null?_0x4072ba!==null?_0xbebd41-_0x4072ba===0x0?_0xcf7777['length']-_0x1e5c3e['length']:_0xbebd41-_0x4072ba:-0x1:_0x4072ba!==null?0x1:_0xcf7777<_0x1e5c3e?-0x1:0x1;}},Hl=function(_0xd16a64,_0x105ea8){return _0xd16a64===_0x105ea8?0x0:_0xd16a64<_0x105ea8?-0x1:0x1;},pt=function(_0x48da64,_0xb8575a){if(_0xb8575a&&_0x48da64 in _0xb8575a)return _0xb8575a[_0x48da64];throw new Error('Missing\x20required\x20key\x20('+_0x48da64+')\x20in\x20object:\x20'+O(_0xb8575a));},Bi=function(_0x533b29){if(typeof _0x533b29!='object'||_0x533b29===null)return O(_0x533b29);const _0x3136c0=[];for(const _0x15125a in _0x533b29)_0x3136c0['push'](_0x15125a);_0x3136c0['sort']();let _0x574e51='{';for(let _0x5a4f53=0x0;_0x5a4f53<_0x3136c0['length'];_0x5a4f53++)_0x5a4f53!==0x0&&(_0x574e51+=','),_0x574e51+=O(_0x3136c0[_0x5a4f53]),_0x574e51+=':',_0x574e51+=Bi(_0x533b29[_0x3136c0[_0x5a4f53]]);return _0x574e51+='}',_0x574e51;},io=function(_0x492889,_0x642ff6){const _0x483c3b=_0x492889['length'];if(_0x483c3b<=_0x642ff6)return[_0x492889];const _0x558b24=[];for(let _0x4ec8d4=0x0;_0x4ec8d4<_0x483c3b;_0x4ec8d4+=_0x642ff6)_0x4ec8d4+_0x642ff6>_0x483c3b?_0x558b24['push'](_0x492889['substring'](_0x4ec8d4,_0x483c3b)):_0x558b24['push'](_0x492889['substring'](_0x4ec8d4,_0x4ec8d4+_0x642ff6));return _0x558b24;};function x(_0x15c1f1,_0xa4414e){for(const _0x277204 in _0x15c1f1)_0x15c1f1['hasOwnProperty'](_0x277204)&&_0xa4414e(_0x277204,_0x15c1f1[_0x277204]);}const so=function(_0x5cba40){f(!Wi(_0x5cba40),'Invalid\x20JSON\x20number');const _0x19ee07=0xb,_0x3b3196=0x34,_0x1318af=(0x1<<_0x19ee07-0x1)-0x1;let _0x8d9f1f,_0x1ff2b4,_0x2cf2c0,_0x21b448,_0x21a305;_0x5cba40===0x0?(_0x1ff2b4=0x0,_0x2cf2c0=0x0,_0x8d9f1f=0x1/_0x5cba40===-0x1/0x0?0x1:0x0):(_0x8d9f1f=_0x5cba40<0x0,_0x5cba40=Math['abs'](_0x5cba40),_0x5cba40>=Math['pow'](0x2,0x1-_0x1318af)?(_0x21b448=Math['min'](Math['floor'](Math['log'](_0x5cba40)/Math['LN2']),_0x1318af),_0x1ff2b4=_0x21b448+_0x1318af,_0x2cf2c0=Math['round'](_0x5cba40*Math['pow'](0x2,_0x3b3196-_0x21b448)-Math['pow'](0x2,_0x3b3196))):(_0x1ff2b4=0x0,_0x2cf2c0=Math['round'](_0x5cba40/Math['pow'](0x2,0x1-_0x1318af-_0x3b3196))));const _0x193b15=[];for(_0x21a305=_0x3b3196;_0x21a305;_0x21a305-=0x1)_0x193b15['push'](_0x2cf2c0%0x2?0x1:0x0),_0x2cf2c0=Math['floor'](_0x2cf2c0/0x2);for(_0x21a305=_0x19ee07;_0x21a305;_0x21a305-=0x1)_0x193b15['push'](_0x1ff2b4%0x2?0x1:0x0),_0x1ff2b4=Math['floor'](_0x1ff2b4/0x2);_0x193b15['push'](_0x8d9f1f?0x1:0x0),_0x193b15['reverse']();const _0x3669ea=_0x193b15['join']('');let _0x5c1dfe='';for(_0x21a305=0x0;_0x21a305<0x40;_0x21a305+=0x8){let _0x151ae3=parseInt(_0x3669ea['substr'](_0x21a305,0x8),0x2)['toString'](0x10);_0x151ae3['length']===0x1&&(_0x151ae3='0'+_0x151ae3),_0x5c1dfe=_0x5c1dfe+_0x151ae3;}return _0x5c1dfe['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0xc9344b,_0x18dab4){let _0x45091e='Unknown\x20Error';_0xc9344b==='too_big'?_0x45091e='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0xc9344b==='permission_denied'?_0x45091e='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0xc9344b==='unavailable'&&(_0x45091e='The\x20service\x20is\x20unavailable');const _0x536d1c=new Error(_0xc9344b+'\x20at\x20'+_0x18dab4['_path']['toString']()+':\x20'+_0x45091e);return _0x536d1c['code']=_0xc9344b['toUpperCase'](),_0x536d1c;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x18e7b4){if(zl['test'](_0x18e7b4)){const _0x4cd68a=Number(_0x18e7b4);if(_0x4cd68a>=jl&&_0x4cd68a<=Kl)return _0x4cd68a;}return null;},lt=function(_0x1c134b){try{_0x1c134b();}catch(_0x27cfa4){setTimeout(()=>{const _0x4ebef7=_0x27cfa4['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4ebef7),_0x27cfa4;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x3b7617,_0x4f414b){const _0x3a76b9=setTimeout(_0x3b7617,_0x4f414b);return typeof _0x3a76b9=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3a76b9):typeof _0x3a76b9=='object'&&_0x3a76b9['unref']&&_0x3a76b9['unref'](),_0x3a76b9;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x136ff1,_0x5dc185){this['appCheckProvider']=_0x5dc185,this['appName']=_0x136ff1['name'],H(_0x136ff1)&&_0x136ff1['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x136ff1['settings']['appCheckToken']),this['appCheck']=_0x5dc185==null?void 0x0:_0x5dc185['getImmediate']({'optional':!0x0}),this['appCheck']||_0x5dc185==null||_0x5dc185['get']()['then'](_0x3caf4d=>this['appCheck']=_0x3caf4d);}['getToken'](_0x399ae4){if(this['serverAppAppCheckToken']){if(_0x399ae4)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x399ae4):new Promise((_0x38bfb2,_0x335663)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x399ae4)['then'](_0x38bfb2,_0x335663):_0x38bfb2(null);},0x0);});}['addTokenChangeListener'](_0x5a3ee0){var _0x50622e;(_0x50622e=this['appCheckProvider'])==null||_0x50622e['get']()['then'](_0x1af0e4=>_0x1af0e4['addTokenListener'](_0x5a3ee0));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x20350b,_0x57f8a7,_0x383446){this['appName_']=_0x20350b,this['firebaseOptions_']=_0x57f8a7,this['authProvider_']=_0x383446,this['auth_']=null,this['auth_']=_0x383446['getImmediate']({'optional':!0x0}),this['auth_']||_0x383446['onInit'](_0x3e1edc=>this['auth_']=_0x3e1edc);}['getToken'](_0x2b4cf2){return this['auth_']?this['auth_']['getToken'](_0x2b4cf2)['catch'](_0x1eaf68=>_0x1eaf68&&_0x1eaf68['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1eaf68)):new Promise((_0x30d254,_0x3ec3b3)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x2b4cf2)['then'](_0x30d254,_0x3ec3b3):_0x30d254(null);},0x0);});}['addTokenChangeListener'](_0x2e7951){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2e7951):this['authProvider_']['get']()['then'](_0x5b2a1f=>_0x5b2a1f['addAuthTokenListener'](_0x2e7951));}['removeTokenChangeListener'](_0x492f24){this['authProvider_']['get']()['then'](_0xf83c90=>_0xf83c90['removeAuthTokenListener'](_0x492f24));}['notifyForInvalidToken'](){let _0x3e1e19='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3e1e19+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3e1e19+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3e1e19+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3e1e19);}}class tn{constructor(_0x2e3bc9){this['accessToken']=_0x2e3bc9;}['getToken'](_0x1ce0c4){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x41da09){_0x41da09(this['accessToken']);}['removeTokenChangeListener'](_0x786c6b){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x94f084,_0x5141f0,_0x216536,_0xeb62b0,_0x3dbc82=!0x1,_0xe17962='',_0x1d73d6=!0x1,_0x15d96b=!0x1,_0x3b9b31=null){this['secure']=_0x5141f0,this['namespace']=_0x216536,this['webSocketOnly']=_0xeb62b0,this['nodeAdmin']=_0x3dbc82,this['persistenceKey']=_0xe17962,this['includeNamespaceInQueryParams']=_0x1d73d6,this['isUsingEmulator']=_0x15d96b,this['emulatorOptions']=_0x3b9b31,this['_host']=_0x94f084['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x94f084)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4f09c9){_0x4f09c9!==this['internalHost']&&(this['internalHost']=_0x4f09c9,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0xde61c4=this['toURLString']();return this['persistenceKey']&&(_0xde61c4+='<'+this['persistenceKey']+'>'),_0xde61c4;}['toURLString'](){const _0x5438ec=this['secure']?'https://':'http://',_0x20def7=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5438ec+this['host']+'/'+_0x20def7;}}function Xl(_0x494d1a){return _0x494d1a['host']!==_0x494d1a['internalHost']||_0x494d1a['isCustomHost']()||_0x494d1a['includeNamespaceInQueryParams'];}function go(_0x2ea789,_0x54d96c,_0x116460){f(typeof _0x54d96c=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x116460=='object','typeof\x20params\x20must\x20==\x20object');let _0x29dd26;if(_0x54d96c===fo)_0x29dd26=(_0x2ea789['secure']?'wss://':'ws://')+_0x2ea789['internalHost']+'/.ws?';else{if(_0x54d96c===po)_0x29dd26=(_0x2ea789['secure']?'https://':'http://')+_0x2ea789['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x54d96c);}Xl(_0x2ea789)&&(_0x116460['ns']=_0x2ea789['namespace']);const _0x90d20b=[];return x(_0x116460,(_0x252c9f,_0x328497)=>{_0x90d20b['push'](_0x252c9f+'='+_0x328497);}),_0x29dd26+_0x90d20b['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x47dddf,_0x48193a=0x1){Y(this['counters_'],_0x47dddf)||(this['counters_'][_0x47dddf]=0x0),this['counters_'][_0x47dddf]+=_0x48193a;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x16044d){const _0x427b7a=_0x16044d['toString']();return ti[_0x427b7a]||(ti[_0x427b7a]=new Zl()),ti[_0x427b7a];}function eh(_0x338b6e,_0x5d23a8){const _0x3c55ef=_0x338b6e['toString']();return ni[_0x3c55ef]||(ni[_0x3c55ef]=_0x5d23a8()),ni[_0x3c55ef];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x324c32){this['onMessage_']=_0x324c32,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2db495,_0x123c2c){this['closeAfterResponse']=_0x2db495,this['onClose']=_0x123c2c,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x5d35d5,_0x8bc1bf){for(this['pendingResponses'][_0x5d35d5]=_0x8bc1bf;this['pendingResponses'][this['currentResponseNum']];){const _0x1bc18a=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x2c7bc6=0x0;_0x2c7bc6<_0x1bc18a['length'];++_0x2c7bc6)_0x1bc18a[_0x2c7bc6]&&lt(()=>{this['onMessage_'](_0x1bc18a[_0x2c7bc6]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x3b2daa,_0x222af0,_0x2867f0,_0x5b23fc,_0x465d27,_0x5de850,_0x5ee10a){this['connId']=_0x3b2daa,this['repoInfo']=_0x222af0,this['applicationId']=_0x2867f0,this['appCheckToken']=_0x5b23fc,this['authToken']=_0x465d27,this['transportSessionId']=_0x5de850,this['lastSessionId']=_0x5ee10a,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x3b2daa),this['stats_']=Hi(_0x222af0),this['urlFn']=_0x2bf90c=>(this['appCheckToken']&&(_0x2bf90c[yi]=this['appCheckToken']),go(_0x222af0,po,_0x2bf90c));}['open'](_0x29c81b,_0x3641f1){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3641f1,this['myPacketOrderer']=new th(_0x29c81b),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x6fadff)=>{const [_0x28ca1f,_0x1cdc97,_0x2bed93,_0x1ef84f,_0x11cf4e]=_0x6fadff;if(this['incrementIncomingBytes_'](_0x6fadff),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x28ca1f===$s)this['id']=_0x1cdc97,this['password']=_0x2bed93;else{if(_0x28ca1f===nh)_0x1cdc97?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1cdc97,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x28ca1f);}}},(..._0x5715b7)=>{const [_0x44dffa,_0x268611]=_0x5715b7;this['incrementIncomingBytes_'](_0x5715b7),this['myPacketOrderer']['handleResponse'](_0x44dffa,_0x268611);},()=>{this['onClosed_']();},this['urlFn']);const _0x2bdfbb={};_0x2bdfbb[$s]='t',_0x2bdfbb[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x2bdfbb[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x2bdfbb[ro]=Vi,this['transportSessionId']&&(_0x2bdfbb[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x2bdfbb[ho]=this['lastSessionId']),this['applicationId']&&(_0x2bdfbb[uo]=this['applicationId']),this['appCheckToken']&&(_0x2bdfbb[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x2bdfbb[ao]=co);const _0x497a34=this['urlFn'](_0x2bdfbb);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x497a34),this['scriptTagHolder']['addTag'](_0x497a34,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2699a4){const _0x80a3b=O(_0x2699a4);this['bytesSent']+=_0x80a3b['length'],this['stats_']['incrementCounter']('bytes_sent',_0x80a3b['length']);const _0x52ae24=Br(_0x80a3b),_0x76bc68=io(_0x52ae24,hh);for(let _0x7b5f3e=0x0;_0x7b5f3e<_0x76bc68['length'];_0x7b5f3e++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x76bc68['length'],_0x76bc68[_0x7b5f3e]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1d9d22,_0x4003d8){this['myDisconnFrame']=document['createElement']('iframe');const _0x632e3e={};_0x632e3e[lh]='t',_0x632e3e[mo]=_0x1d9d22,_0x632e3e[yo]=_0x4003d8,this['myDisconnFrame']['src']=this['urlFn'](_0x632e3e),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1e137e){const _0x44af5e=O(_0x1e137e)['length'];this['bytesReceived']+=_0x44af5e,this['stats_']['incrementCounter']('bytes_received',_0x44af5e);}}class $i{constructor(_0x2c00dd,_0x3ea74c,_0x14c0f1,_0xd4a3a5){this['onDisconnect']=_0x14c0f1,this['urlFn']=_0xd4a3a5,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x2c00dd,window[sh+this['uniqueCallbackIdentifier']]=_0x3ea74c,this['myIFrame']=$i['createIFrame_']();let _0x5d3f63='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x5d3f63='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3baf25='<html><body>'+_0x5d3f63+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3baf25),this['myIFrame']['doc']['close']();}catch(_0x43b5cd){L('frame\x20writing\x20exception'),_0x43b5cd['stack']&&L(_0x43b5cd['stack']),L(_0x43b5cd);}}}static['createIFrame_'](){const _0x1971cd=document['createElement']('iframe');if(_0x1971cd['style']['display']='none',document['body']){document['body']['appendChild'](_0x1971cd);try{_0x1971cd['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x223eac=document['domain'];_0x1971cd['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x223eac+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1971cd['contentDocument']?_0x1971cd['doc']=_0x1971cd['contentDocument']:_0x1971cd['contentWindow']?_0x1971cd['doc']=_0x1971cd['contentWindow']['document']:_0x1971cd['document']&&(_0x1971cd['doc']=_0x1971cd['document']),_0x1971cd;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3da29c=this['onDisconnect'];_0x3da29c&&(this['onDisconnect']=null,_0x3da29c());}['startLongPoll'](_0x424eb7,_0xa52176){for(this['myID']=_0x424eb7,this['myPW']=_0xa52176,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x445d4a={};_0x445d4a[mo]=this['myID'],_0x445d4a[yo]=this['myPW'],_0x445d4a[vo]=this['currentSerial'];let _0x49a6ad=this['urlFn'](_0x445d4a),_0x1f00b6='',_0x5a1288=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x1f00b6['length']<=Eo;){const _0x3212ec=this['pendingSegs']['shift']();_0x1f00b6=_0x1f00b6+'&'+oh+_0x5a1288+'='+_0x3212ec['seg']+'&'+ah+_0x5a1288+'='+_0x3212ec['ts']+'&'+ch+_0x5a1288+'='+_0x3212ec['d'],_0x5a1288++;}return _0x49a6ad=_0x49a6ad+_0x1f00b6,this['addLongPollTag_'](_0x49a6ad,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x126392,_0x4d9adc,_0x4cd4e2){this['pendingSegs']['push']({'seg':_0x126392,'ts':_0x4d9adc,'d':_0x4cd4e2}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xa4b8bd,_0x43d6fc){this['outstandingRequests']['add'](_0x43d6fc);const _0x492351=()=>{this['outstandingRequests']['delete'](_0x43d6fc),this['newRequest_']();},_0x2b909b=setTimeout(_0x492351,Math['floor'](uh)),_0x48ecef=()=>{clearTimeout(_0x2b909b),_0x492351();};this['addTag'](_0xa4b8bd,_0x48ecef);}['addTag'](_0x4d426e,_0x26acbb){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x2888d8=this['myIFrame']['doc']['createElement']('script');_0x2888d8['type']='text/javascript',_0x2888d8['async']=!0x0,_0x2888d8['src']=_0x4d426e,_0x2888d8['onload']=_0x2888d8['onreadystatechange']=function(){const _0x3f0cbf=_0x2888d8['readyState'];(!_0x3f0cbf||_0x3f0cbf==='loaded'||_0x3f0cbf==='complete')&&(_0x2888d8['onload']=_0x2888d8['onreadystatechange']=null,_0x2888d8['parentNode']&&_0x2888d8['parentNode']['removeChild'](_0x2888d8),_0x26acbb());},_0x2888d8['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4d426e),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x2888d8);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x4849dd,_0x4cd5f8,_0x51b8f3,_0x245250,_0x4202c9,_0x30e427,_0x105536){this['connId']=_0x4849dd,this['applicationId']=_0x51b8f3,this['appCheckToken']=_0x245250,this['authToken']=_0x4202c9,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x4cd5f8),this['connURL']=G['connectionURL_'](_0x4cd5f8,_0x30e427,_0x105536,_0x245250,_0x51b8f3),this['nodeAdmin']=_0x4cd5f8['nodeAdmin'];}static['connectionURL_'](_0x1b28db,_0x58daed,_0x3acdd4,_0x5be8ca,_0x150217){const _0x2e4181={};return _0x2e4181[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x2e4181[ao]=co),_0x58daed&&(_0x2e4181[oo]=_0x58daed),_0x3acdd4&&(_0x2e4181[ho]=_0x3acdd4),_0x5be8ca&&(_0x2e4181[yi]=_0x5be8ca),_0x150217&&(_0x2e4181[uo]=_0x150217),go(_0x1b28db,fo,_0x2e4181);}['open'](_0x169c4e,_0x36175f){this['onDisconnect']=_0x36175f,this['onMessage']=_0x169c4e,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x437a27;dc(),this['mySock']=new hn(this['connURL'],[],_0x437a27);}catch(_0x4dda99){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x29971d=_0x4dda99['message']||_0x4dda99['data'];_0x29971d&&this['log_'](_0x29971d),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2766da=>{this['handleIncomingFrame'](_0x2766da);},this['mySock']['onerror']=_0x4be415=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2b9084=_0x4be415['message']||_0x4be415['data'];_0x2b9084&&this['log_'](_0x2b9084),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x124651=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x191fc4=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x273c1f=navigator['userAgent']['match'](_0x191fc4);_0x273c1f&&_0x273c1f['length']>0x1&&parseFloat(_0x273c1f[0x1])<4.4&&(_0x124651=!0x0);}return!_0x124651&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x395713){if(this['frames']['push'](_0x395713),this['frames']['length']===this['totalFrames']){const _0x3fd96f=this['frames']['join']('');this['frames']=null;const _0x1c9fad=bt(_0x3fd96f);this['onMessage'](_0x1c9fad);}}['handleNewFrameCount_'](_0x50d23b){this['totalFrames']=_0x50d23b,this['frames']=[];}['extractFrameCount_'](_0x2d29ea){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2d29ea['length']<=0x6){const _0x522e91=Number(_0x2d29ea);if(!isNaN(_0x522e91))return this['handleNewFrameCount_'](_0x522e91),null;}return this['handleNewFrameCount_'](0x1),_0x2d29ea;}['handleIncomingFrame'](_0x5ae780){if(this['mySock']===null)return;const _0x2ac672=_0x5ae780['data'];if(this['bytesReceived']+=_0x2ac672['length'],this['stats_']['incrementCounter']('bytes_received',_0x2ac672['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2ac672);else{const _0x883514=this['extractFrameCount_'](_0x2ac672);_0x883514!==null&&this['appendFrame_'](_0x883514);}}['send'](_0x1fc8b1){this['resetKeepAlive']();const _0x306e6b=O(_0x1fc8b1);this['bytesSent']+=_0x306e6b['length'],this['stats_']['incrementCounter']('bytes_sent',_0x306e6b['length']);const _0x1a3c21=io(_0x306e6b,fh);_0x1a3c21['length']>0x1&&this['sendString_'](String(_0x1a3c21['length']));for(let _0x510829=0x0;_0x510829<_0x1a3c21['length'];_0x510829++)this['sendString_'](_0x1a3c21[_0x510829]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x45f6e8){try{this['mySock']['send'](_0x45f6e8);}catch(_0x53fa48){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x53fa48['message']||_0x53fa48['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0xbe7a31){this['initTransports_'](_0xbe7a31);}['initTransports_'](_0x1dde0a){const _0x5abe82=G&&G['isAvailable']();let _0x11226d=_0x5abe82&&!G['previouslyFailed']();if(_0x1dde0a['webSocketOnly']&&(_0x5abe82||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x11226d=!0x0),_0x11226d)this['transports_']=[G];else{const _0x5225d8=this['transports_']=[];for(const _0x2a71bc of At['ALL_TRANSPORTS'])_0x2a71bc&&_0x2a71bc['isAvailable']()&&_0x5225d8['push'](_0x2a71bc);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x68eb1,_0x4f1a77,_0x452ed5,_0x491d6c,_0x759c34,_0x3454c1,_0x54107f,_0x5bcf4a,_0x4de35a,_0x2c2c54){this['id']=_0x68eb1,this['repoInfo_']=_0x4f1a77,this['applicationId_']=_0x452ed5,this['appCheckToken_']=_0x491d6c,this['authToken_']=_0x759c34,this['onMessage_']=_0x3454c1,this['onReady_']=_0x54107f,this['onDisconnect_']=_0x5bcf4a,this['onKill_']=_0x4de35a,this['lastSessionId']=_0x2c2c54,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x4f1a77),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x14f6c0=this['transportManager_']['initialTransport']();this['conn_']=new _0x14f6c0(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x14f6c0['responsesRequiredToBeHealthy']||0x0;const _0x526614=this['connReceiver_'](this['conn_']),_0x1cbc85=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x526614,_0x1cbc85);},Math['floor'](0x0));const _0x107b11=_0x14f6c0['healthyTimeout']||0x0;_0x107b11>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x107b11)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4d61f6){return _0x51cafe=>{_0x4d61f6===this['conn_']?this['onConnectionLost_'](_0x51cafe):_0x4d61f6===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x35f429){return _0x55e575=>{this['state_']!==0x2&&(_0x35f429===this['rx_']?this['onPrimaryMessageReceived_'](_0x55e575):_0x35f429===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x55e575):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xe04c34){const _0x3e0ab1={'t':'d','d':_0xe04c34};this['sendData_'](_0x3e0ab1);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x54b49a){if(ii in _0x54b49a){const _0x4865a9=_0x54b49a[ii];_0x4865a9===js?this['upgradeIfSecondaryHealthy_']():_0x4865a9===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4865a9===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x200e73){const _0x2e4538=pt('t',_0x200e73),_0x4b0a78=pt('d',_0x200e73);if(_0x2e4538==='c')this['onSecondaryControl_'](_0x4b0a78);else{if(_0x2e4538==='d')this['pendingDataMessages']['push'](_0x4b0a78);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x2e4538);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3fc102){const _0x57b84a=pt('t',_0x3fc102),_0x11f467=pt('d',_0x3fc102);_0x57b84a==='c'?this['onControl_'](_0x11f467):_0x57b84a==='d'&&this['onDataMessage_'](_0x11f467);}['onDataMessage_'](_0x1fc502){this['onPrimaryResponse_'](),this['onMessage_'](_0x1fc502);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4f2f37){const _0x5f2520=pt(ii,_0x4f2f37);if(Gs in _0x4f2f37){const _0x1844ff=_0x4f2f37[Gs];if(_0x5f2520===Ih){const _0x48f94f={..._0x1844ff};this['repoInfo_']['isUsingEmulator']&&(_0x48f94f['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x48f94f);}else{if(_0x5f2520===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4cbfaa=0x0;_0x4cbfaa<this['pendingDataMessages']['length'];++_0x4cbfaa)this['onDataMessage_'](this['pendingDataMessages'][_0x4cbfaa]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5f2520===vh?this['onConnectionShutdown_'](_0x1844ff):_0x5f2520===qs?this['onReset_'](_0x1844ff):_0x5f2520===Eh?mi('Server\x20Error:\x20'+_0x1844ff):_0x5f2520===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x5f2520);}}}['onHandshake_'](_0x2a576a){const _0x382673=_0x2a576a['ts'],_0x493b98=_0x2a576a['v'],_0x280b16=_0x2a576a['h'];this['sessionId']=_0x2a576a['s'],this['repoInfo_']['host']=_0x280b16,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x382673),Vi!==_0x493b98&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x258505=this['transportManager_']['upgradeTransport']();_0x258505&&this['startUpgrade_'](_0x258505);}['startUpgrade_'](_0x210b8e){this['secondaryConn_']=new _0x210b8e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x210b8e['responsesRequiredToBeHealthy']||0x0;const _0x3e1b93=this['connReceiver_'](this['secondaryConn_']),_0x47f238=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3e1b93,_0x47f238),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x436b45){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x436b45),this['repoInfo_']['host']=_0x436b45,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x46fbae,_0x17cca9){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x46fbae,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x17cca9,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3d9f19=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3d9f19||this['rx_']===_0x3d9f19)&&this['close']();}['onConnectionLost_'](_0x298191){this['conn_']=null,!_0x298191&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x38c054){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x38c054),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x258c41){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x258c41);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x2c66c0,_0x4e05c6,_0x4519e7,_0x5337f8){}['merge'](_0x5229d9,_0x1fda4c,_0x219b27,_0x528df0){}['refreshAuthToken'](_0x1ab0af){}['refreshAppCheckToken'](_0x428134){}['onDisconnectPut'](_0x560284,_0x424e4c,_0x19fa9d){}['onDisconnectMerge'](_0x260c9c,_0x199db5,_0x5ede64){}['onDisconnectCancel'](_0x41e503,_0x2c04ec){}['reportStats'](_0x14a946){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x15c902){this['allowedEvents_']=_0x15c902,this['listeners_']={},f(Array['isArray'](_0x15c902)&&_0x15c902['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x4460d,..._0x4640a7){if(Array['isArray'](this['listeners_'][_0x4460d])){const _0x2c01fd=[...this['listeners_'][_0x4460d]];for(let _0x3eb200=0x0;_0x3eb200<_0x2c01fd['length'];_0x3eb200++)_0x2c01fd[_0x3eb200]['callback']['apply'](_0x2c01fd[_0x3eb200]['context'],_0x4640a7);}}['on'](_0x40c626,_0x24a851,_0x268364){this['validateEventType_'](_0x40c626),this['listeners_'][_0x40c626]=this['listeners_'][_0x40c626]||[],this['listeners_'][_0x40c626]['push']({'callback':_0x24a851,'context':_0x268364});const _0x5663aa=this['getInitialEvent'](_0x40c626);_0x5663aa&&_0x24a851['apply'](_0x268364,_0x5663aa);}['off'](_0x3924b1,_0x32813a,_0xb384bc){this['validateEventType_'](_0x3924b1);const _0x33699c=this['listeners_'][_0x3924b1]||[];for(let _0x284d39=0x0;_0x284d39<_0x33699c['length'];_0x284d39++)if(_0x33699c[_0x284d39]['callback']===_0x32813a&&(!_0xb384bc||_0xb384bc===_0x33699c[_0x284d39]['context'])){_0x33699c['splice'](_0x284d39,0x1);return;}}['validateEventType_'](_0x59f5f9){f(this['allowedEvents_']['find'](_0x39e3a7=>_0x39e3a7===_0x59f5f9),'Unknown\x20event:\x20'+_0x59f5f9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x59c1fa){return f(_0x59c1fa==='online','Unknown\x20event\x20type:\x20'+_0x59c1fa),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x53af4d,_0x1d286){if(_0x1d286===void 0x0){this['pieces_']=_0x53af4d['split']('/');let _0x5462c4=0x0;for(let _0x4311e7=0x0;_0x4311e7<this['pieces_']['length'];_0x4311e7++)this['pieces_'][_0x4311e7]['length']>0x0&&(this['pieces_'][_0x5462c4]=this['pieces_'][_0x4311e7],_0x5462c4++);this['pieces_']['length']=_0x5462c4,this['pieceNum_']=0x0;}else this['pieces_']=_0x53af4d,this['pieceNum_']=_0x1d286;}['toString'](){let _0x2874cd='';for(let _0x1518cc=this['pieceNum_'];_0x1518cc<this['pieces_']['length'];_0x1518cc++)this['pieces_'][_0x1518cc]!==''&&(_0x2874cd+='/'+this['pieces_'][_0x1518cc]);return _0x2874cd||'/';}}function w(){return new C('');}function y(_0x50c216){return _0x50c216['pieceNum_']>=_0x50c216['pieces_']['length']?null:_0x50c216['pieces_'][_0x50c216['pieceNum_']];}function we(_0x18d7c2){return _0x18d7c2['pieces_']['length']-_0x18d7c2['pieceNum_'];}function b(_0x4d4a0e){let _0x317bf2=_0x4d4a0e['pieceNum_'];return _0x317bf2<_0x4d4a0e['pieces_']['length']&&_0x317bf2++,new C(_0x4d4a0e['pieces_'],_0x317bf2);}function Gi(_0x248349){return _0x248349['pieceNum_']<_0x248349['pieces_']['length']?_0x248349['pieces_'][_0x248349['pieces_']['length']-0x1]:null;}function Ch(_0x3dad87){let _0x2b2198='';for(let _0x2cf9d0=_0x3dad87['pieceNum_'];_0x2cf9d0<_0x3dad87['pieces_']['length'];_0x2cf9d0++)_0x3dad87['pieces_'][_0x2cf9d0]!==''&&(_0x2b2198+='/'+encodeURIComponent(String(_0x3dad87['pieces_'][_0x2cf9d0])));return _0x2b2198||'/';}function kt(_0x4701a9,_0x1e4b1f=0x0){return _0x4701a9['pieces_']['slice'](_0x4701a9['pieceNum_']+_0x1e4b1f);}function To(_0x30d4bd){if(_0x30d4bd['pieceNum_']>=_0x30d4bd['pieces_']['length'])return null;const _0x15a73d=[];for(let _0x3934b7=_0x30d4bd['pieceNum_'];_0x3934b7<_0x30d4bd['pieces_']['length']-0x1;_0x3934b7++)_0x15a73d['push'](_0x30d4bd['pieces_'][_0x3934b7]);return new C(_0x15a73d,0x0);}function A(_0x301c4,_0x2da19b){const _0x15f4dc=[];for(let _0x3704b8=_0x301c4['pieceNum_'];_0x3704b8<_0x301c4['pieces_']['length'];_0x3704b8++)_0x15f4dc['push'](_0x301c4['pieces_'][_0x3704b8]);if(_0x2da19b instanceof C){for(let _0x181366=_0x2da19b['pieceNum_'];_0x181366<_0x2da19b['pieces_']['length'];_0x181366++)_0x15f4dc['push'](_0x2da19b['pieces_'][_0x181366]);}else{const _0x27daa6=_0x2da19b['split']('/');for(let _0x12446c=0x0;_0x12446c<_0x27daa6['length'];_0x12446c++)_0x27daa6[_0x12446c]['length']>0x0&&_0x15f4dc['push'](_0x27daa6[_0x12446c]);}return new C(_0x15f4dc,0x0);}function v(_0x52596e){return _0x52596e['pieceNum_']>=_0x52596e['pieces_']['length'];}function F(_0x2a454f,_0x10ce41){const _0x25596b=y(_0x2a454f),_0x4fe4e2=y(_0x10ce41);if(_0x25596b===null)return _0x10ce41;if(_0x25596b===_0x4fe4e2)return F(b(_0x2a454f),b(_0x10ce41));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x10ce41+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2a454f+')');}function Th(_0x540313,_0x1dadc3){const _0x5152c9=kt(_0x540313,0x0),_0x327110=kt(_0x1dadc3,0x0);for(let _0x1c8224=0x0;_0x1c8224<_0x5152c9['length']&&_0x1c8224<_0x327110['length'];_0x1c8224++){const _0x3666e0=He(_0x5152c9[_0x1c8224],_0x327110[_0x1c8224]);if(_0x3666e0!==0x0)return _0x3666e0;}return _0x5152c9['length']===_0x327110['length']?0x0:_0x5152c9['length']<_0x327110['length']?-0x1:0x1;}function qi(_0x3a6ba6,_0x39c203){if(we(_0x3a6ba6)!==we(_0x39c203))return!0x1;for(let _0x5a1c2f=_0x3a6ba6['pieceNum_'],_0xcab3eb=_0x39c203['pieceNum_'];_0x5a1c2f<=_0x3a6ba6['pieces_']['length'];_0x5a1c2f++,_0xcab3eb++)if(_0x3a6ba6['pieces_'][_0x5a1c2f]!==_0x39c203['pieces_'][_0xcab3eb])return!0x1;return!0x0;}function $(_0x1f0219,_0x2cc911){let _0x1fa5d2=_0x1f0219['pieceNum_'],_0x324312=_0x2cc911['pieceNum_'];if(we(_0x1f0219)>we(_0x2cc911))return!0x1;for(;_0x1fa5d2<_0x1f0219['pieces_']['length'];){if(_0x1f0219['pieces_'][_0x1fa5d2]!==_0x2cc911['pieces_'][_0x324312])return!0x1;++_0x1fa5d2,++_0x324312;}return!0x0;}class Sh{constructor(_0x16f3ec,_0x3e28ce){this['errorPrefix_']=_0x3e28ce,this['parts_']=kt(_0x16f3ec,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3c2c86=0x0;_0x3c2c86<this['parts_']['length'];_0x3c2c86++)this['byteLength_']+=Pn(this['parts_'][_0x3c2c86]);So(this);}}function bh(_0xa3dadc,_0x59c159){_0xa3dadc['parts_']['length']>0x0&&(_0xa3dadc['byteLength_']+=0x1),_0xa3dadc['parts_']['push'](_0x59c159),_0xa3dadc['byteLength_']+=Pn(_0x59c159),So(_0xa3dadc);}function Rh(_0x5935be){const _0x222a61=_0x5935be['parts_']['pop']();_0x5935be['byteLength_']-=Pn(_0x222a61),_0x5935be['parts_']['length']>0x0&&(_0x5935be['byteLength_']-=0x1);}function So(_0x36914a){if(_0x36914a['byteLength_']>Js)throw new Error(_0x36914a['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x36914a['byteLength_']+').');if(_0x36914a['parts_']['length']>Qs)throw new Error(_0x36914a['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x36914a));}function Ne(_0x728592){return _0x728592['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x728592['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x2b3d55,_0x5e4c3b;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5e4c3b='visibilitychange',_0x2b3d55='hidden'):typeof document['mozHidden']<'u'?(_0x5e4c3b='mozvisibilitychange',_0x2b3d55='mozHidden'):typeof document['msHidden']<'u'?(_0x5e4c3b='msvisibilitychange',_0x2b3d55='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5e4c3b='webkitvisibilitychange',_0x2b3d55='webkitHidden')),this['visible_']=!0x0,_0x5e4c3b&&document['addEventListener'](_0x5e4c3b,()=>{const _0x39ceb7=!document[_0x2b3d55];_0x39ceb7!==this['visible_']&&(this['visible_']=_0x39ceb7,this['trigger']('visible',_0x39ceb7));},!0x1);}['getInitialEvent'](_0x36d7b9){return f(_0x36d7b9==='visible','Unknown\x20event\x20type:\x20'+_0x36d7b9),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x48a177,_0x44bcce,_0x51ac41,_0x3deb8c,_0x392049,_0x189cee,_0x5e1e9d,_0x3e8530){if(super(),this['repoInfo_']=_0x48a177,this['applicationId_']=_0x44bcce,this['onDataUpdate_']=_0x51ac41,this['onConnectStatus_']=_0x3deb8c,this['onServerInfoUpdate_']=_0x392049,this['authTokenProvider_']=_0x189cee,this['appCheckTokenProvider_']=_0x5e1e9d,this['authOverride_']=_0x3e8530,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x3e8530)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x48a177['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x493303,_0xf6aff6,_0x10b06b){const _0x33ce6b=++this['requestNumber_'],_0x509773={'r':_0x33ce6b,'a':_0x493303,'b':_0xf6aff6};this['log_'](O(_0x509773)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x509773),_0x10b06b&&(this['requestCBHash_'][_0x33ce6b]=_0x10b06b);}['get'](_0x2e31e9){this['initConnection_']();const _0x4184dd=new Ve(),_0x8fdd53={'action':'g','request':{'p':_0x2e31e9['_path']['toString'](),'q':_0x2e31e9['_queryObject']},'onComplete':_0x12985e=>{const _0x5104f5=_0x12985e['d'];_0x12985e['s']==='ok'?_0x4184dd['resolve'](_0x5104f5):_0x4184dd['reject'](_0x5104f5);}};this['outstandingGets_']['push'](_0x8fdd53),this['outstandingGetCount_']++;const _0x5df5bd=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5df5bd),_0x4184dd['promise'];}['listen'](_0x4e6162,_0x54c3e9,_0x5f3e1f,_0x1ba041){this['initConnection_']();const _0x4541d7=_0x4e6162['_queryIdentifier'],_0x49a48d=_0x4e6162['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x49a48d+'\x20'+_0x4541d7),this['listens']['has'](_0x49a48d)||this['listens']['set'](_0x49a48d,new Map()),f(_0x4e6162['_queryParams']['isDefault']()||!_0x4e6162['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x49a48d)['has'](_0x4541d7),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x545cb7={'onComplete':_0x1ba041,'hashFn':_0x54c3e9,'query':_0x4e6162,'tag':_0x5f3e1f};this['listens']['get'](_0x49a48d)['set'](_0x4541d7,_0x545cb7),this['connected_']&&this['sendListen_'](_0x545cb7);}['sendGet_'](_0x5a3e87){const _0x1e7e09=this['outstandingGets_'][_0x5a3e87];this['sendRequest']('g',_0x1e7e09['request'],_0x5f30f2=>{delete this['outstandingGets_'][_0x5a3e87],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1e7e09['onComplete']&&_0x1e7e09['onComplete'](_0x5f30f2);});}['sendListen_'](_0x389930){const _0x14ca8e=_0x389930['query'],_0x7f1ff3=_0x14ca8e['_path']['toString'](),_0x83d7ec=_0x14ca8e['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x7f1ff3+'\x20for\x20'+_0x83d7ec);const _0x899031={'p':_0x7f1ff3},_0x2b85c6='q';_0x389930['tag']&&(_0x899031['q']=_0x14ca8e['_queryObject'],_0x899031['t']=_0x389930['tag']),_0x899031['h']=_0x389930['hashFn'](),this['sendRequest'](_0x2b85c6,_0x899031,_0x5916b2=>{const _0x23fcdb=_0x5916b2['d'],_0xc951e1=_0x5916b2['s'];ie['warnOnListenWarnings_'](_0x23fcdb,_0x14ca8e),(this['listens']['get'](_0x7f1ff3)&&this['listens']['get'](_0x7f1ff3)['get'](_0x83d7ec))===_0x389930&&(this['log_']('listen\x20response',_0x5916b2),_0xc951e1!=='ok'&&this['removeListen_'](_0x7f1ff3,_0x83d7ec),_0x389930['onComplete']&&_0x389930['onComplete'](_0xc951e1,_0x23fcdb));});}static['warnOnListenWarnings_'](_0x2ad14c,_0x55aebe){if(_0x2ad14c&&typeof _0x2ad14c=='object'&&Y(_0x2ad14c,'w')){const _0x41a14d=Oe(_0x2ad14c,'w');if(Array['isArray'](_0x41a14d)&&~_0x41a14d['indexOf']('no_index')){const _0x5df995='\x22.indexOn\x22:\x20\x22'+_0x55aebe['_queryParams']['getIndex']()['toString']()+'\x22',_0x527440=_0x55aebe['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x5df995+'\x20at\x20'+_0x527440+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x483dd4){this['authToken_']=_0x483dd4,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x483dd4);}['reduceReconnectDelayIfAdminCredential_'](_0x24035b){(_0x24035b&&_0x24035b['length']===0x28||vc(_0x24035b))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x434c04){this['appCheckToken_']=_0x434c04,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x3c4d42=this['authToken_'],_0x2fa8d2=yc(_0x3c4d42)?'auth':'gauth',_0x112145={'cred':_0x3c4d42};this['authOverride_']===null?_0x112145['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x112145['authvar']=this['authOverride_']),this['sendRequest'](_0x2fa8d2,_0x112145,_0x440d33=>{const _0x475894=_0x440d33['s'],_0x5f9e8b=_0x440d33['d']||'error';this['authToken_']===_0x3c4d42&&(_0x475894==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x475894,_0x5f9e8b));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x4374c0=>{const _0x10a63a=_0x4374c0['s'],_0x298e02=_0x4374c0['d']||'error';_0x10a63a==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x10a63a,_0x298e02);});}['unlisten'](_0x1b2ea5,_0x3657cf){const _0x2fabbf=_0x1b2ea5['_path']['toString'](),_0x33857c=_0x1b2ea5['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x2fabbf+'\x20'+_0x33857c),f(_0x1b2ea5['_queryParams']['isDefault']()||!_0x1b2ea5['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x2fabbf,_0x33857c)&&this['connected_']&&this['sendUnlisten_'](_0x2fabbf,_0x33857c,_0x1b2ea5['_queryObject'],_0x3657cf);}['sendUnlisten_'](_0x42e68d,_0x21e76f,_0x16e3eb,_0x3f11bc){this['log_']('Unlisten\x20on\x20'+_0x42e68d+'\x20for\x20'+_0x21e76f);const _0x410ee2={'p':_0x42e68d},_0x48299c='n';_0x3f11bc&&(_0x410ee2['q']=_0x16e3eb,_0x410ee2['t']=_0x3f11bc),this['sendRequest'](_0x48299c,_0x410ee2);}['onDisconnectPut'](_0x4a500b,_0x4de265,_0x38b88e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4a500b,_0x4de265,_0x38b88e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4a500b,'action':'o','data':_0x4de265,'onComplete':_0x38b88e});}['onDisconnectMerge'](_0x17dd21,_0x3a3262,_0x40c7da){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x17dd21,_0x3a3262,_0x40c7da):this['onDisconnectRequestQueue_']['push']({'pathString':_0x17dd21,'action':'om','data':_0x3a3262,'onComplete':_0x40c7da});}['onDisconnectCancel'](_0x4c63c9,_0x4a59e1){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x4c63c9,null,_0x4a59e1):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4c63c9,'action':'oc','data':null,'onComplete':_0x4a59e1});}['sendOnDisconnect_'](_0xdb0990,_0x28ec8f,_0x425ff0,_0x4ad3c0){const _0x644880={'p':_0x28ec8f,'d':_0x425ff0};this['log_']('onDisconnect\x20'+_0xdb0990,_0x644880),this['sendRequest'](_0xdb0990,_0x644880,_0x22d716=>{_0x4ad3c0&&setTimeout(()=>{_0x4ad3c0(_0x22d716['s'],_0x22d716['d']);},Math['floor'](0x0));});}['put'](_0x4360ab,_0x253332,_0x2c26a8,_0x32f9e2){this['putInternal']('p',_0x4360ab,_0x253332,_0x2c26a8,_0x32f9e2);}['merge'](_0x132dc8,_0x226a3d,_0x33831b,_0x530647){this['putInternal']('m',_0x132dc8,_0x226a3d,_0x33831b,_0x530647);}['putInternal'](_0xa8d12f,_0x34177c,_0x497bd3,_0x5119a8,_0x43d59a){this['initConnection_']();const _0x3cb089={'p':_0x34177c,'d':_0x497bd3};_0x43d59a!==void 0x0&&(_0x3cb089['h']=_0x43d59a),this['outstandingPuts_']['push']({'action':_0xa8d12f,'request':_0x3cb089,'onComplete':_0x5119a8}),this['outstandingPutCount_']++;const _0xb85e41=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xb85e41):this['log_']('Buffering\x20put:\x20'+_0x34177c);}['sendPut_'](_0x12a1f4){const _0x1d12b1=this['outstandingPuts_'][_0x12a1f4]['action'],_0x15e17a=this['outstandingPuts_'][_0x12a1f4]['request'],_0x4d48ea=this['outstandingPuts_'][_0x12a1f4]['onComplete'];this['outstandingPuts_'][_0x12a1f4]['queued']=this['connected_'],this['sendRequest'](_0x1d12b1,_0x15e17a,_0x392d5c=>{this['log_'](_0x1d12b1+'\x20response',_0x392d5c),delete this['outstandingPuts_'][_0x12a1f4],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x4d48ea&&_0x4d48ea(_0x392d5c['s'],_0x392d5c['d']);});}['reportStats'](_0x10d276){if(this['connected_']){const _0x205988={'c':_0x10d276};this['log_']('reportStats',_0x205988),this['sendRequest']('s',_0x205988,_0x70b944=>{if(_0x70b944['s']!=='ok'){const _0x9848d=_0x70b944['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x9848d);}});}}['onDataMessage_'](_0x530d56){if('r'in _0x530d56){this['log_']('from\x20server:\x20'+O(_0x530d56));const _0x5d352e=_0x530d56['r'],_0x3082bf=this['requestCBHash_'][_0x5d352e];_0x3082bf&&(delete this['requestCBHash_'][_0x5d352e],_0x3082bf(_0x530d56['b']));}else{if('error'in _0x530d56)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x530d56['error'];'a'in _0x530d56&&this['onDataPush_'](_0x530d56['a'],_0x530d56['b']);}}['onDataPush_'](_0x3553c1,_0x13a2b3){this['log_']('handleServerMessage',_0x3553c1,_0x13a2b3),_0x3553c1==='d'?this['onDataUpdate_'](_0x13a2b3['p'],_0x13a2b3['d'],!0x1,_0x13a2b3['t']):_0x3553c1==='m'?this['onDataUpdate_'](_0x13a2b3['p'],_0x13a2b3['d'],!0x0,_0x13a2b3['t']):_0x3553c1==='c'?this['onListenRevoked_'](_0x13a2b3['p'],_0x13a2b3['q']):_0x3553c1==='ac'?this['onAuthRevoked_'](_0x13a2b3['s'],_0x13a2b3['d']):_0x3553c1==='apc'?this['onAppCheckRevoked_'](_0x13a2b3['s'],_0x13a2b3['d']):_0x3553c1==='sd'?this['onSecurityDebugPacket_'](_0x13a2b3):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3553c1)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x334cdf,_0x574a86){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x334cdf),this['lastSessionId']=_0x574a86,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x312fc3){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x312fc3));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x53374e){_0x53374e&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x53374e;}['onOnline_'](_0x19f757){_0x19f757?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2f3e2c=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x28e75c=Math['max'](0x0,this['reconnectDelay_']-_0x2f3e2c);_0x28e75c=Math['random']()*_0x28e75c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x28e75c+'ms'),this['scheduleConnect_'](_0x28e75c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x3391fe=this['onDataMessage_']['bind'](this),_0x134fea=this['onReady_']['bind'](this),_0x2c3dab=this['onRealtimeDisconnect_']['bind'](this),_0x1949d3=this['id']+':'+ie['nextConnectionId_']++,_0x250134=this['lastSessionId'];let _0x401d7b=!0x1,_0x4c7e69=null;const _0x193cb8=function(){_0x4c7e69?_0x4c7e69['close']():(_0x401d7b=!0x0,_0x2c3dab());},_0x213428=function(_0x1bd5b2){f(_0x4c7e69,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4c7e69['sendRequest'](_0x1bd5b2);};this['realtime_']={'close':_0x193cb8,'sendRequest':_0x213428};const _0x46f203=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5cbbb1,_0x3d26f6]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x46f203),this['appCheckTokenProvider_']['getToken'](_0x46f203)]);_0x401d7b?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5cbbb1&&_0x5cbbb1['accessToken'],this['appCheckToken_']=_0x3d26f6&&_0x3d26f6['token'],_0x4c7e69=new wh(_0x1949d3,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x3391fe,_0x134fea,_0x2c3dab,_0x585245=>{U(_0x585245+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x250134));}catch(_0x3eb9e3){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3eb9e3),_0x401d7b||(this['repoInfo_']['nodeAdmin']&&U(_0x3eb9e3),_0x193cb8());}}}['interrupt'](_0x4e8267){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x4e8267),this['interruptReasons_'][_0x4e8267]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x51af7f){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x51af7f),delete this['interruptReasons_'][_0x51af7f],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x352195){const _0x57fe2e=_0x352195-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x57fe2e});}['cancelSentTransactions_'](){for(let _0x1ef25f=0x0;_0x1ef25f<this['outstandingPuts_']['length'];_0x1ef25f++){const _0x1d44c2=this['outstandingPuts_'][_0x1ef25f];_0x1d44c2&&'h'in _0x1d44c2['request']&&_0x1d44c2['queued']&&(_0x1d44c2['onComplete']&&_0x1d44c2['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1ef25f],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x10e89f,_0x3df2a5){let _0x19d759;_0x3df2a5?_0x19d759=_0x3df2a5['map'](_0x55175c=>Bi(_0x55175c))['join']('$'):_0x19d759='default';const _0x3b39c0=this['removeListen_'](_0x10e89f,_0x19d759);_0x3b39c0&&_0x3b39c0['onComplete']&&_0x3b39c0['onComplete']('permission_denied');}['removeListen_'](_0x3a0b98,_0x5420a4){const _0x4383bc=new C(_0x3a0b98)['toString']();let _0xf05cf2;if(this['listens']['has'](_0x4383bc)){const _0x120991=this['listens']['get'](_0x4383bc);_0xf05cf2=_0x120991['get'](_0x5420a4),_0x120991['delete'](_0x5420a4),_0x120991['size']===0x0&&this['listens']['delete'](_0x4383bc);}else _0xf05cf2=void 0x0;return _0xf05cf2;}['onAuthRevoked_'](_0x455304,_0x53ae0d){L('Auth\x20token\x20revoked:\x20'+_0x455304+'/'+_0x53ae0d),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x455304==='invalid_token'||_0x455304==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x2b5494,_0x542dd0){L('App\x20check\x20token\x20revoked:\x20'+_0x2b5494+'/'+_0x542dd0),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x2b5494==='invalid_token'||_0x2b5494==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x59a99a){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x59a99a):'msg'in _0x59a99a&&console['log']('FIREBASE:\x20'+_0x59a99a['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x208248 of this['listens']['values']())for(const _0xdf72dd of _0x208248['values']())this['sendListen_'](_0xdf72dd);for(let _0x33adec=0x0;_0x33adec<this['outstandingPuts_']['length'];_0x33adec++)this['outstandingPuts_'][_0x33adec]&&this['sendPut_'](_0x33adec);for(;this['onDisconnectRequestQueue_']['length'];){const _0xc4469b=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xc4469b['action'],_0xc4469b['pathString'],_0xc4469b['data'],_0xc4469b['onComplete']);}for(let _0x97f04b=0x0;_0x97f04b<this['outstandingGets_']['length'];_0x97f04b++)this['outstandingGets_'][_0x97f04b]&&this['sendGet_'](_0x97f04b);}['sendConnectStats_'](){const _0x1c7459={};let _0x49bb04='js';_0x1c7459['sdk.'+_0x49bb04+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x1c7459['framework.cordova']=0x1:qr()&&(_0x1c7459['framework.reactnative']=0x1),this['reportStats'](_0x1c7459);}['shouldReconnect_'](){const _0x21da94=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x21da94;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4307b2,_0x2c82ac){this['name']=_0x4307b2,this['node']=_0x2c82ac;}static['Wrap'](_0x40e315,_0x32163b){return new E(_0x40e315,_0x32163b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3fc83a,_0x231129){const _0x295430=new E(xe,_0x3fc83a),_0x591fa8=new E(xe,_0x231129);return this['compare'](_0x295430,_0x591fa8)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x292337){Xt=_0x292337;}['compare'](_0x74ae78,_0x4cfccb){return He(_0x74ae78['name'],_0x4cfccb['name']);}['isDefinedOn'](_0x748b27){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x2f9c66,_0xfe85a2){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0xf9d8ee,_0x44fa62){return f(typeof _0xf9d8ee=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xf9d8ee,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x26cceb,_0x57844e,_0x425430,_0x5b3654,_0x5dfaa3=null){this['isReverse_']=_0x5b3654,this['resultGenerator_']=_0x5dfaa3,this['nodeStack_']=[];let _0x33d53e=0x1;for(;!_0x26cceb['isEmpty']();)if(_0x26cceb=_0x26cceb,_0x33d53e=_0x57844e?_0x425430(_0x26cceb['key'],_0x57844e):0x1,_0x5b3654&&(_0x33d53e*=-0x1),_0x33d53e<0x0)this['isReverse_']?_0x26cceb=_0x26cceb['left']:_0x26cceb=_0x26cceb['right'];else{if(_0x33d53e===0x0){this['nodeStack_']['push'](_0x26cceb);break;}else this['nodeStack_']['push'](_0x26cceb),this['isReverse_']?_0x26cceb=_0x26cceb['right']:_0x26cceb=_0x26cceb['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1f7d44=this['nodeStack_']['pop'](),_0xca792d;if(this['resultGenerator_']?_0xca792d=this['resultGenerator_'](_0x1f7d44['key'],_0x1f7d44['value']):_0xca792d={'key':_0x1f7d44['key'],'value':_0x1f7d44['value']},this['isReverse_']){for(_0x1f7d44=_0x1f7d44['left'];!_0x1f7d44['isEmpty']();)this['nodeStack_']['push'](_0x1f7d44),_0x1f7d44=_0x1f7d44['right'];}else{for(_0x1f7d44=_0x1f7d44['right'];!_0x1f7d44['isEmpty']();)this['nodeStack_']['push'](_0x1f7d44),_0x1f7d44=_0x1f7d44['left'];}return _0xca792d;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4bfc3c=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4bfc3c['key'],_0x4bfc3c['value']):{'key':_0x4bfc3c['key'],'value':_0x4bfc3c['value']};}}class M{constructor(_0x5b53b7,_0x32be9e,_0x54fc7e,_0x2fa422,_0xe3b170){this['key']=_0x5b53b7,this['value']=_0x32be9e,this['color']=_0x54fc7e??M['RED'],this['left']=_0x2fa422??B['EMPTY_NODE'],this['right']=_0xe3b170??B['EMPTY_NODE'];}['copy'](_0xe5580,_0x28f1d0,_0x1ab0a2,_0x2e289c,_0x4ef8d3){return new M(_0xe5580??this['key'],_0x28f1d0??this['value'],_0x1ab0a2??this['color'],_0x2e289c??this['left'],_0x4ef8d3??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x232cdf){return this['left']['inorderTraversal'](_0x232cdf)||!!_0x232cdf(this['key'],this['value'])||this['right']['inorderTraversal'](_0x232cdf);}['reverseTraversal'](_0xbc38f3){return this['right']['reverseTraversal'](_0xbc38f3)||_0xbc38f3(this['key'],this['value'])||this['left']['reverseTraversal'](_0xbc38f3);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2d023a,_0x56aaa1,_0x23a171){let _0x27b77b=this;const _0x526970=_0x23a171(_0x2d023a,_0x27b77b['key']);return _0x526970<0x0?_0x27b77b=_0x27b77b['copy'](null,null,null,_0x27b77b['left']['insert'](_0x2d023a,_0x56aaa1,_0x23a171),null):_0x526970===0x0?_0x27b77b=_0x27b77b['copy'](null,_0x56aaa1,null,null,null):_0x27b77b=_0x27b77b['copy'](null,null,null,null,_0x27b77b['right']['insert'](_0x2d023a,_0x56aaa1,_0x23a171)),_0x27b77b['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x18d04d=this;return!_0x18d04d['left']['isRed_']()&&!_0x18d04d['left']['left']['isRed_']()&&(_0x18d04d=_0x18d04d['moveRedLeft_']()),_0x18d04d=_0x18d04d['copy'](null,null,null,_0x18d04d['left']['removeMin_'](),null),_0x18d04d['fixUp_']();}['remove'](_0x355aa5,_0x3ffc18){let _0x465417,_0x11a54b;if(_0x465417=this,_0x3ffc18(_0x355aa5,_0x465417['key'])<0x0)!_0x465417['left']['isEmpty']()&&!_0x465417['left']['isRed_']()&&!_0x465417['left']['left']['isRed_']()&&(_0x465417=_0x465417['moveRedLeft_']()),_0x465417=_0x465417['copy'](null,null,null,_0x465417['left']['remove'](_0x355aa5,_0x3ffc18),null);else{if(_0x465417['left']['isRed_']()&&(_0x465417=_0x465417['rotateRight_']()),!_0x465417['right']['isEmpty']()&&!_0x465417['right']['isRed_']()&&!_0x465417['right']['left']['isRed_']()&&(_0x465417=_0x465417['moveRedRight_']()),_0x3ffc18(_0x355aa5,_0x465417['key'])===0x0){if(_0x465417['right']['isEmpty']())return B['EMPTY_NODE'];_0x11a54b=_0x465417['right']['min_'](),_0x465417=_0x465417['copy'](_0x11a54b['key'],_0x11a54b['value'],null,null,_0x465417['right']['removeMin_']());}_0x465417=_0x465417['copy'](null,null,null,null,_0x465417['right']['remove'](_0x355aa5,_0x3ffc18));}return _0x465417['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4e9be1=this;return _0x4e9be1['right']['isRed_']()&&!_0x4e9be1['left']['isRed_']()&&(_0x4e9be1=_0x4e9be1['rotateLeft_']()),_0x4e9be1['left']['isRed_']()&&_0x4e9be1['left']['left']['isRed_']()&&(_0x4e9be1=_0x4e9be1['rotateRight_']()),_0x4e9be1['left']['isRed_']()&&_0x4e9be1['right']['isRed_']()&&(_0x4e9be1=_0x4e9be1['colorFlip_']()),_0x4e9be1;}['moveRedLeft_'](){let _0x14d6c7=this['colorFlip_']();return _0x14d6c7['right']['left']['isRed_']()&&(_0x14d6c7=_0x14d6c7['copy'](null,null,null,null,_0x14d6c7['right']['rotateRight_']()),_0x14d6c7=_0x14d6c7['rotateLeft_'](),_0x14d6c7=_0x14d6c7['colorFlip_']()),_0x14d6c7;}['moveRedRight_'](){let _0x2f8a9b=this['colorFlip_']();return _0x2f8a9b['left']['left']['isRed_']()&&(_0x2f8a9b=_0x2f8a9b['rotateRight_'](),_0x2f8a9b=_0x2f8a9b['colorFlip_']()),_0x2f8a9b;}['rotateLeft_'](){const _0x4b8368=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4b8368,null);}['rotateRight_'](){const _0x1944da=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1944da);}['colorFlip_'](){const _0x42ee46=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x1de479=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x42ee46,_0x1de479);}['checkMaxDepth_'](){const _0x52b71f=this['check_']();return Math['pow'](0x2,_0x52b71f)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2d03d9=this['left']['check_']();if(_0x2d03d9!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2d03d9+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x140b70,_0xb71ed0,_0x3a7159,_0xfebeaf,_0x1e8abd){return this;}['insert'](_0x405c4a,_0x46be77,_0x38d679){return new M(_0x405c4a,_0x46be77,null);}['remove'](_0x489ce2,_0x1f93b5){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x74c3ba){return!0x1;}['reverseTraversal'](_0x35ebfc){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4cb85d,_0x62e83f=B['EMPTY_NODE']){this['comparator_']=_0x4cb85d,this['root_']=_0x62e83f;}['insert'](_0x20abc3,_0x3516d4){return new B(this['comparator_'],this['root_']['insert'](_0x20abc3,_0x3516d4,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x456693){return new B(this['comparator_'],this['root_']['remove'](_0x456693,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x864b94){let _0xe06ff6,_0x8c678a=this['root_'];for(;!_0x8c678a['isEmpty']();){if(_0xe06ff6=this['comparator_'](_0x864b94,_0x8c678a['key']),_0xe06ff6===0x0)return _0x8c678a['value'];_0xe06ff6<0x0?_0x8c678a=_0x8c678a['left']:_0xe06ff6>0x0&&(_0x8c678a=_0x8c678a['right']);}return null;}['getPredecessorKey'](_0x4e0447){let _0x5c4e3a,_0x26e557=this['root_'],_0x285a68=null;for(;!_0x26e557['isEmpty']();)if(_0x5c4e3a=this['comparator_'](_0x4e0447,_0x26e557['key']),_0x5c4e3a===0x0){if(_0x26e557['left']['isEmpty']())return _0x285a68?_0x285a68['key']:null;for(_0x26e557=_0x26e557['left'];!_0x26e557['right']['isEmpty']();)_0x26e557=_0x26e557['right'];return _0x26e557['key'];}else _0x5c4e3a<0x0?_0x26e557=_0x26e557['left']:_0x5c4e3a>0x0&&(_0x285a68=_0x26e557,_0x26e557=_0x26e557['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x3a0e55){return this['root_']['inorderTraversal'](_0x3a0e55);}['reverseTraversal'](_0x54db27){return this['root_']['reverseTraversal'](_0x54db27);}['getIterator'](_0x11aa73){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x11aa73);}['getIteratorFrom'](_0x8e3f64,_0xda615d){return new Zt(this['root_'],_0x8e3f64,this['comparator_'],!0x1,_0xda615d);}['getReverseIteratorFrom'](_0xbbc054,_0x33147e){return new Zt(this['root_'],_0xbbc054,this['comparator_'],!0x0,_0x33147e);}['getReverseIterator'](_0x1d97d4){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x1d97d4);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0xc45702,_0x438426){return He(_0xc45702['name'],_0x438426['name']);}function ji(_0x132851,_0x311661){return He(_0x132851,_0x311661);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x4449b2){vi=_0x4449b2;}const Ro=function(_0x2a145c){return typeof _0x2a145c=='number'?'number:'+so(_0x2a145c):'string:'+_0x2a145c;},Ao=function(_0x4b470f){if(_0x4b470f['isLeafNode']()){const _0x2f07bf=_0x4b470f['val']();f(typeof _0x2f07bf=='string'||typeof _0x2f07bf=='number'||typeof _0x2f07bf=='object'&&Y(_0x2f07bf,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4b470f===vi||_0x4b470f['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4b470f===vi||_0x4b470f['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x25eff5){er=_0x25eff5;}static get['__childrenNodeConstructor'](){return er;}constructor(_0xe2bb38,_0x5ea12d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xe2bb38,this['priorityNode_']=_0x5ea12d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x550beb){return new D(this['value_'],_0x550beb);}['getImmediateChild'](_0x1e4aa4){return _0x1e4aa4==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3af3bd){return v(_0x3af3bd)?this:y(_0x3af3bd)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x144791,_0x3709ef){return null;}['updateImmediateChild'](_0x483245,_0x343be0){return _0x483245==='.priority'?this['updatePriority'](_0x343be0):_0x343be0['isEmpty']()&&_0x483245!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x483245,_0x343be0)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x933809,_0x5376e6){const _0x25f764=y(_0x933809);return _0x25f764===null?_0x5376e6:_0x5376e6['isEmpty']()&&_0x25f764!=='.priority'?this:(f(_0x25f764!=='.priority'||we(_0x933809)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x25f764,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x933809),_0x5376e6)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4500b7,_0x34b43b){return!0x1;}['val'](_0x5e4051){return _0x5e4051&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3da846='';this['priorityNode_']['isEmpty']()||(_0x3da846+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x25fa3d=typeof this['value_'];_0x3da846+=_0x25fa3d+':',_0x25fa3d==='number'?_0x3da846+=so(this['value_']):_0x3da846+=this['value_'],this['lazyHash_']=no(_0x3da846);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x35842b){return _0x35842b===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x35842b instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x35842b['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x35842b));}['compareToLeafNode_'](_0x56673b){const _0x34860b=typeof _0x56673b['value_'],_0x488fc4=typeof this['value_'],_0x5ca628=D['VALUE_TYPE_ORDER']['indexOf'](_0x34860b),_0x2501c5=D['VALUE_TYPE_ORDER']['indexOf'](_0x488fc4);return f(_0x5ca628>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x34860b),f(_0x2501c5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x488fc4),_0x5ca628===_0x2501c5?_0x488fc4==='object'?0x0:this['value_']<_0x56673b['value_']?-0x1:this['value_']===_0x56673b['value_']?0x0:0x1:_0x2501c5-_0x5ca628;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x549b5c){if(_0x549b5c===this)return!0x0;if(_0x549b5c['isLeafNode']()){const _0x75941e=_0x549b5c;return this['value_']===_0x75941e['value_']&&this['priorityNode_']['equals'](_0x75941e['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x2783f5){ko=_0x2783f5;}function xh(_0x2a6bbe){No=_0x2a6bbe;}class Fh extends On{['compare'](_0x3d71ce,_0x2918be){const _0x534677=_0x3d71ce['node']['getPriority'](),_0x3080ad=_0x2918be['node']['getPriority'](),_0x332a2c=_0x534677['compareTo'](_0x3080ad);return _0x332a2c===0x0?He(_0x3d71ce['name'],_0x2918be['name']):_0x332a2c;}['isDefinedOn'](_0xb51d96){return!_0xb51d96['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x467e68,_0x36ee28){return!_0x467e68['getPriority']()['equals'](_0x36ee28['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x563e49,_0x18cd0b){const _0x5177f2=ko(_0x563e49);return new E(_0x18cd0b,new D('[PRIORITY-POST]',_0x5177f2));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x48a596){const _0x3d5ec3=_0x2b06cf=>parseInt(Math['log'](_0x2b06cf)/Uh,0xa),_0x559621=_0x1576ca=>parseInt(Array(_0x1576ca+0x1)['join']('1'),0x2);this['count']=_0x3d5ec3(_0x48a596+0x1),this['current_']=this['count']-0x1;const _0x1a4b92=_0x559621(this['count']);this['bits_']=_0x48a596+0x1&_0x1a4b92;}['nextBitIsOne'](){const _0x2ae252=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2ae252;}}const dn=function(_0x5e5bfd,_0x4c1685,_0x57a4ed,_0x37c54b){_0x5e5bfd['sort'](_0x4c1685);const _0x442aa0=function(_0xf59cb4,_0x302cbb){const _0x676d10=_0x302cbb-_0xf59cb4;let _0x4214f2,_0x5d011d;if(_0x676d10===0x0)return null;if(_0x676d10===0x1)return _0x4214f2=_0x5e5bfd[_0xf59cb4],_0x5d011d=_0x57a4ed?_0x57a4ed(_0x4214f2):_0x4214f2,new M(_0x5d011d,_0x4214f2['node'],M['BLACK'],null,null);{const _0x3c2223=parseInt(_0x676d10/0x2,0xa)+_0xf59cb4,_0x1bfa48=_0x442aa0(_0xf59cb4,_0x3c2223),_0x253ce9=_0x442aa0(_0x3c2223+0x1,_0x302cbb);return _0x4214f2=_0x5e5bfd[_0x3c2223],_0x5d011d=_0x57a4ed?_0x57a4ed(_0x4214f2):_0x4214f2,new M(_0x5d011d,_0x4214f2['node'],M['BLACK'],_0x1bfa48,_0x253ce9);}},_0x2f77e5=function(_0x48f5e0){let _0x19ff37=null,_0x22d199=null,_0x1d272d=_0x5e5bfd['length'];const _0x3ae4fb=function(_0x20551c,_0x4eaf2b){const _0x2cb365=_0x1d272d-_0x20551c,_0x7c2ec8=_0x1d272d;_0x1d272d-=_0x20551c;const _0xfca59a=_0x442aa0(_0x2cb365+0x1,_0x7c2ec8),_0x21657e=_0x5e5bfd[_0x2cb365],_0x2062d8=_0x57a4ed?_0x57a4ed(_0x21657e):_0x21657e;_0xc48272(new M(_0x2062d8,_0x21657e['node'],_0x4eaf2b,null,_0xfca59a));},_0xc48272=function(_0x2ac8e1){_0x19ff37?(_0x19ff37['left']=_0x2ac8e1,_0x19ff37=_0x2ac8e1):(_0x22d199=_0x2ac8e1,_0x19ff37=_0x2ac8e1);};for(let _0xbb66e4=0x0;_0xbb66e4<_0x48f5e0['count'];++_0xbb66e4){const _0x56b3d6=_0x48f5e0['nextBitIsOne'](),_0x4121de=Math['pow'](0x2,_0x48f5e0['count']-(_0xbb66e4+0x1));_0x56b3d6?_0x3ae4fb(_0x4121de,M['BLACK']):(_0x3ae4fb(_0x4121de,M['BLACK']),_0x3ae4fb(_0x4121de,M['RED']));}return _0x22d199;},_0x3e8dcc=new Wh(_0x5e5bfd['length']),_0x22d674=_0x2f77e5(_0x3e8dcc);return new B(_0x37c54b||_0x4c1685,_0x22d674);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x452f44,_0x4e5225){this['indexes_']=_0x452f44,this['indexSet_']=_0x4e5225;}['get'](_0x23bc85){const _0x26d50e=Oe(this['indexes_'],_0x23bc85);if(!_0x26d50e)throw new Error('No\x20index\x20defined\x20for\x20'+_0x23bc85);return _0x26d50e instanceof B?_0x26d50e:null;}['hasIndex'](_0xedd50d){return Y(this['indexSet_'],_0xedd50d['toString']());}['addIndex'](_0x424908,_0x515189){f(_0x424908!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1a9149=[];let _0x884069=!0x1;const _0x2d89a5=_0x515189['getIterator'](E['Wrap']);let _0x2694c3=_0x2d89a5['getNext']();for(;_0x2694c3;)_0x884069=_0x884069||_0x424908['isDefinedOn'](_0x2694c3['node']),_0x1a9149['push'](_0x2694c3),_0x2694c3=_0x2d89a5['getNext']();let _0xa75f37;_0x884069?_0xa75f37=dn(_0x1a9149,_0x424908['getCompare']()):_0xa75f37=je;const _0x14562f=_0x424908['toString'](),_0x1188ec={...this['indexSet_']};_0x1188ec[_0x14562f]=_0x424908;const _0x3d51de={...this['indexes_']};return _0x3d51de[_0x14562f]=_0xa75f37,new ee(_0x3d51de,_0x1188ec);}['addToIndexes'](_0x5c2704,_0x59488b){const _0x33e3d8=ln(this['indexes_'],(_0x18d1da,_0x5b8543)=>{const _0x31e7bf=Oe(this['indexSet_'],_0x5b8543);if(f(_0x31e7bf,'Missing\x20index\x20implementation\x20for\x20'+_0x5b8543),_0x18d1da===je){if(_0x31e7bf['isDefinedOn'](_0x5c2704['node'])){const _0x1327cb=[],_0x4604e9=_0x59488b['getIterator'](E['Wrap']);let _0x4a620e=_0x4604e9['getNext']();for(;_0x4a620e;)_0x4a620e['name']!==_0x5c2704['name']&&_0x1327cb['push'](_0x4a620e),_0x4a620e=_0x4604e9['getNext']();return _0x1327cb['push'](_0x5c2704),dn(_0x1327cb,_0x31e7bf['getCompare']());}else return je;}else{const _0x367472=_0x59488b['get'](_0x5c2704['name']);let _0x37a5cd=_0x18d1da;return _0x367472&&(_0x37a5cd=_0x37a5cd['remove'](new E(_0x5c2704['name'],_0x367472))),_0x37a5cd['insert'](_0x5c2704,_0x5c2704['node']);}});return new ee(_0x33e3d8,this['indexSet_']);}['removeFromIndexes'](_0x5704e4,_0x1fc3c4){const _0x35db04=ln(this['indexes_'],_0x4b4506=>{if(_0x4b4506===je)return _0x4b4506;{const _0x45da30=_0x1fc3c4['get'](_0x5704e4['name']);return _0x45da30?_0x4b4506['remove'](new E(_0x5704e4['name'],_0x45da30)):_0x4b4506;}});return new ee(_0x35db04,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x4540bd,_0x378a78,_0x361210){this['children_']=_0x4540bd,this['priorityNode_']=_0x378a78,this['indexMap_']=_0x361210,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x2af20c){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x2af20c,this['indexMap_']);}['getImmediateChild'](_0x1ad509){if(_0x1ad509==='.priority')return this['getPriority']();{const _0x1a7c06=this['children_']['get'](_0x1ad509);return _0x1a7c06===null?gt:_0x1a7c06;}}['getChild'](_0xfd7bb){const _0xaa96e1=y(_0xfd7bb);return _0xaa96e1===null?this:this['getImmediateChild'](_0xaa96e1)['getChild'](b(_0xfd7bb));}['hasChild'](_0x54c6fe){return this['children_']['get'](_0x54c6fe)!==null;}['updateImmediateChild'](_0x26099b,_0x514a25){if(f(_0x514a25,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x26099b==='.priority')return this['updatePriority'](_0x514a25);{const _0x1b6c4e=new E(_0x26099b,_0x514a25);let _0x360b8c,_0x43a4a7;_0x514a25['isEmpty']()?(_0x360b8c=this['children_']['remove'](_0x26099b),_0x43a4a7=this['indexMap_']['removeFromIndexes'](_0x1b6c4e,this['children_'])):(_0x360b8c=this['children_']['insert'](_0x26099b,_0x514a25),_0x43a4a7=this['indexMap_']['addToIndexes'](_0x1b6c4e,this['children_']));const _0x18d10a=_0x360b8c['isEmpty']()?gt:this['priorityNode_'];return new g(_0x360b8c,_0x18d10a,_0x43a4a7);}}['updateChild'](_0x5cd1d8,_0x8052c1){const _0x7807d8=y(_0x5cd1d8);if(_0x7807d8===null)return _0x8052c1;{f(y(_0x5cd1d8)!=='.priority'||we(_0x5cd1d8)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5b32be=this['getImmediateChild'](_0x7807d8)['updateChild'](b(_0x5cd1d8),_0x8052c1);return this['updateImmediateChild'](_0x7807d8,_0x5b32be);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x14fd13){if(this['isEmpty']())return null;const _0x312d80={};let _0x5465a7=0x0,_0x37f729=0x0,_0x33d90d=!0x0;if(this['forEachChild'](R,(_0x89c946,_0x288891)=>{_0x312d80[_0x89c946]=_0x288891['val'](_0x14fd13),_0x5465a7++,_0x33d90d&&g['INTEGER_REGEXP_']['test'](_0x89c946)?_0x37f729=Math['max'](_0x37f729,Number(_0x89c946)):_0x33d90d=!0x1;}),!_0x14fd13&&_0x33d90d&&_0x37f729<0x2*_0x5465a7){const _0x34077c=[];for(const _0x46c71e in _0x312d80)_0x34077c[_0x46c71e]=_0x312d80[_0x46c71e];return _0x34077c;}else return _0x14fd13&&!this['getPriority']()['isEmpty']()&&(_0x312d80['.priority']=this['getPriority']()['val']()),_0x312d80;}['hash'](){if(this['lazyHash_']===null){let _0x55e287='';this['getPriority']()['isEmpty']()||(_0x55e287+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x59c843,_0x37fa92)=>{const _0x1f1782=_0x37fa92['hash']();_0x1f1782!==''&&(_0x55e287+=':'+_0x59c843+':'+_0x1f1782);}),this['lazyHash_']=_0x55e287===''?'':no(_0x55e287);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4285f4,_0x20965,_0x532d68){const _0x58fe3d=this['resolveIndex_'](_0x532d68);if(_0x58fe3d){const _0x4bad75=_0x58fe3d['getPredecessorKey'](new E(_0x4285f4,_0x20965));return _0x4bad75?_0x4bad75['name']:null;}else return this['children_']['getPredecessorKey'](_0x4285f4);}['getFirstChildName'](_0x41143d){const _0x1e0d5a=this['resolveIndex_'](_0x41143d);if(_0x1e0d5a){const _0x2301aa=_0x1e0d5a['minKey']();return _0x2301aa&&_0x2301aa['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3e5053){const _0x120fd3=this['getFirstChildName'](_0x3e5053);return _0x120fd3?new E(_0x120fd3,this['children_']['get'](_0x120fd3)):null;}['getLastChildName'](_0x118581){const _0x3be8e9=this['resolveIndex_'](_0x118581);if(_0x3be8e9){const _0x3109cf=_0x3be8e9['maxKey']();return _0x3109cf&&_0x3109cf['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x12127c){const _0x58db6d=this['getLastChildName'](_0x12127c);return _0x58db6d?new E(_0x58db6d,this['children_']['get'](_0x58db6d)):null;}['forEachChild'](_0x5271e4,_0x3d7968){const _0xbf165a=this['resolveIndex_'](_0x5271e4);return _0xbf165a?_0xbf165a['inorderTraversal'](_0x5250e0=>_0x3d7968(_0x5250e0['name'],_0x5250e0['node'])):this['children_']['inorderTraversal'](_0x3d7968);}['getIterator'](_0x36a4fe){return this['getIteratorFrom'](_0x36a4fe['minPost'](),_0x36a4fe);}['getIteratorFrom'](_0x16161f,_0x353f9b){const _0x58252d=this['resolveIndex_'](_0x353f9b);if(_0x58252d)return _0x58252d['getIteratorFrom'](_0x16161f,_0x2db17d=>_0x2db17d);{const _0x2f5fb9=this['children_']['getIteratorFrom'](_0x16161f['name'],E['Wrap']);let _0x31cc23=_0x2f5fb9['peek']();for(;_0x31cc23!=null&&_0x353f9b['compare'](_0x31cc23,_0x16161f)<0x0;)_0x2f5fb9['getNext'](),_0x31cc23=_0x2f5fb9['peek']();return _0x2f5fb9;}}['getReverseIterator'](_0x2df92a){return this['getReverseIteratorFrom'](_0x2df92a['maxPost'](),_0x2df92a);}['getReverseIteratorFrom'](_0x425b49,_0x343eb6){const _0x1000af=this['resolveIndex_'](_0x343eb6);if(_0x1000af)return _0x1000af['getReverseIteratorFrom'](_0x425b49,_0x3433f3=>_0x3433f3);{const _0x24919e=this['children_']['getReverseIteratorFrom'](_0x425b49['name'],E['Wrap']);let _0x2e1e2b=_0x24919e['peek']();for(;_0x2e1e2b!=null&&_0x343eb6['compare'](_0x2e1e2b,_0x425b49)>0x0;)_0x24919e['getNext'](),_0x2e1e2b=_0x24919e['peek']();return _0x24919e;}}['compareTo'](_0xbdb71e){return this['isEmpty']()?_0xbdb71e['isEmpty']()?0x0:-0x1:_0xbdb71e['isLeafNode']()||_0xbdb71e['isEmpty']()?0x1:_0xbdb71e===Ht?-0x1:0x0;}['withIndex'](_0x34bd64){if(_0x34bd64===ye||this['indexMap_']['hasIndex'](_0x34bd64))return this;{const _0x567125=this['indexMap_']['addIndex'](_0x34bd64,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x567125);}}['isIndexed'](_0x8666e5){return _0x8666e5===ye||this['indexMap_']['hasIndex'](_0x8666e5);}['equals'](_0x48c761){if(_0x48c761===this)return!0x0;if(_0x48c761['isLeafNode']())return!0x1;{const _0xb7cae6=_0x48c761;if(this['getPriority']()['equals'](_0xb7cae6['getPriority']())){if(this['children_']['count']()===_0xb7cae6['children_']['count']()){const _0x2a977b=this['getIterator'](R),_0x5417e8=_0xb7cae6['getIterator'](R);let _0x594d86=_0x2a977b['getNext'](),_0x5f57c4=_0x5417e8['getNext']();for(;_0x594d86&&_0x5f57c4;){if(_0x594d86['name']!==_0x5f57c4['name']||!_0x594d86['node']['equals'](_0x5f57c4['node']))return!0x1;_0x594d86=_0x2a977b['getNext'](),_0x5f57c4=_0x5417e8['getNext']();}return _0x594d86===null&&_0x5f57c4===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x1fbbde){return _0x1fbbde===ye?null:this['indexMap_']['get'](_0x1fbbde['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x16e85f){return _0x16e85f===this?0x0:0x1;}['equals'](_0x5d0787){return _0x5d0787===this;}['getPriority'](){return this;}['getImmediateChild'](_0x519858){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x17b824,_0x1584f4=null){if(_0x17b824===null)return g['EMPTY_NODE'];if(typeof _0x17b824=='object'&&'.priority'in _0x17b824&&(_0x1584f4=_0x17b824['.priority']),f(_0x1584f4===null||typeof _0x1584f4=='string'||typeof _0x1584f4=='number'||typeof _0x1584f4=='object'&&'.sv'in _0x1584f4,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1584f4),typeof _0x17b824=='object'&&'.value'in _0x17b824&&_0x17b824['.value']!==null&&(_0x17b824=_0x17b824['.value']),typeof _0x17b824!='object'||'.sv'in _0x17b824){const _0x4478ea=_0x17b824;return new D(_0x4478ea,N(_0x1584f4));}if(!(_0x17b824 instanceof Array)&&Vh){const _0x5666e1=[];let _0xeed875=!0x1;if(x(_0x17b824,(_0x3acbeb,_0x21229a)=>{if(_0x3acbeb['substring'](0x0,0x1)!=='.'){const _0x54cc55=N(_0x21229a);_0x54cc55['isEmpty']()||(_0xeed875=_0xeed875||!_0x54cc55['getPriority']()['isEmpty'](),_0x5666e1['push'](new E(_0x3acbeb,_0x54cc55)));}}),_0x5666e1['length']===0x0)return g['EMPTY_NODE'];const _0x3ddf93=dn(_0x5666e1,Dh,_0x42f5f3=>_0x42f5f3['name'],ji);if(_0xeed875){const _0x4ca9b=dn(_0x5666e1,R['getCompare']());return new g(_0x3ddf93,N(_0x1584f4),new ee({'.priority':_0x4ca9b},{'.priority':R}));}else return new g(_0x3ddf93,N(_0x1584f4),ee['Default']);}else{let _0x57bb12=g['EMPTY_NODE'];return x(_0x17b824,(_0x151de7,_0x2043fc)=>{if(Y(_0x17b824,_0x151de7)&&_0x151de7['substring'](0x0,0x1)!=='.'){const _0x8446ad=N(_0x2043fc);(_0x8446ad['isLeafNode']()||!_0x8446ad['isEmpty']())&&(_0x57bb12=_0x57bb12['updateImmediateChild'](_0x151de7,_0x8446ad));}}),_0x57bb12['updatePriority'](N(_0x1584f4));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x12660e){super(),this['indexPath_']=_0x12660e,f(!v(_0x12660e)&&y(_0x12660e)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x579a74){return _0x579a74['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1f2ff6){return!_0x1f2ff6['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x133f3c,_0x9e03a8){const _0x2a4323=this['extractChild'](_0x133f3c['node']),_0x146d4f=this['extractChild'](_0x9e03a8['node']),_0x2c4f57=_0x2a4323['compareTo'](_0x146d4f);return _0x2c4f57===0x0?He(_0x133f3c['name'],_0x9e03a8['name']):_0x2c4f57;}['makePost'](_0xad9ec7,_0x414266){const _0x2afa29=N(_0xad9ec7),_0x443050=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2afa29);return new E(_0x414266,_0x443050);}['maxPost'](){const _0x423576=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x423576);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x216def,_0x3c07c1){const _0x146ae7=_0x216def['node']['compareTo'](_0x3c07c1['node']);return _0x146ae7===0x0?He(_0x216def['name'],_0x3c07c1['name']):_0x146ae7;}['isDefinedOn'](_0x5944fc){return!0x0;}['indexedValueChanged'](_0x578545,_0x4d18d2){return!_0x578545['equals'](_0x4d18d2);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x35fb70,_0x2170c1){const _0x579870=N(_0x35fb70);return new E(_0x2170c1,_0x579870);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x5bb91d){return{'type':'value','snapshotNode':_0x5bb91d};}function tt(_0x2de9ea,_0xcc6414){return{'type':'child_added','snapshotNode':_0xcc6414,'childName':_0x2de9ea};}function Nt(_0x9ce3f5,_0x2f6740){return{'type':'child_removed','snapshotNode':_0x2f6740,'childName':_0x9ce3f5};}function Pt(_0x2ce91f,_0x51ca01,_0x2e0212){return{'type':'child_changed','snapshotNode':_0x51ca01,'childName':_0x2ce91f,'oldSnap':_0x2e0212};}function $h(_0x5e536b,_0x5af453){return{'type':'child_moved','snapshotNode':_0x5af453,'childName':_0x5e536b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x29c641){this['index_']=_0x29c641;}['updateChild'](_0x10b24c,_0x38fd5d,_0x4ffe7d,_0x52adac,_0x15a3f8,_0x52ad0f){f(_0x10b24c['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2c2ce7=_0x10b24c['getImmediateChild'](_0x38fd5d);return _0x2c2ce7['getChild'](_0x52adac)['equals'](_0x4ffe7d['getChild'](_0x52adac))&&_0x2c2ce7['isEmpty']()===_0x4ffe7d['isEmpty']()||(_0x52ad0f!=null&&(_0x4ffe7d['isEmpty']()?_0x10b24c['hasChild'](_0x38fd5d)?_0x52ad0f['trackChildChange'](Nt(_0x38fd5d,_0x2c2ce7)):f(_0x10b24c['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2c2ce7['isEmpty']()?_0x52ad0f['trackChildChange'](tt(_0x38fd5d,_0x4ffe7d)):_0x52ad0f['trackChildChange'](Pt(_0x38fd5d,_0x4ffe7d,_0x2c2ce7))),_0x10b24c['isLeafNode']()&&_0x4ffe7d['isEmpty']())?_0x10b24c:_0x10b24c['updateImmediateChild'](_0x38fd5d,_0x4ffe7d)['withIndex'](this['index_']);}['updateFullNode'](_0xb7d6ea,_0x32b9e8,_0x216c34){return _0x216c34!=null&&(_0xb7d6ea['isLeafNode']()||_0xb7d6ea['forEachChild'](R,(_0x10f5b7,_0x49916d)=>{_0x32b9e8['hasChild'](_0x10f5b7)||_0x216c34['trackChildChange'](Nt(_0x10f5b7,_0x49916d));}),_0x32b9e8['isLeafNode']()||_0x32b9e8['forEachChild'](R,(_0x2150e4,_0x32b6e3)=>{if(_0xb7d6ea['hasChild'](_0x2150e4)){const _0x55f515=_0xb7d6ea['getImmediateChild'](_0x2150e4);_0x55f515['equals'](_0x32b6e3)||_0x216c34['trackChildChange'](Pt(_0x2150e4,_0x32b6e3,_0x55f515));}else _0x216c34['trackChildChange'](tt(_0x2150e4,_0x32b6e3));})),_0x32b9e8['withIndex'](this['index_']);}['updatePriority'](_0xf4de5d,_0x439d24){return _0xf4de5d['isEmpty']()?g['EMPTY_NODE']:_0xf4de5d['updatePriority'](_0x439d24);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x22e98c){this['indexedFilter_']=new Yi(_0x22e98c['getIndex']()),this['index_']=_0x22e98c['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x22e98c),this['endPost_']=Ot['getEndPost_'](_0x22e98c),this['startIsInclusive_']=!_0x22e98c['startAfterSet_'],this['endIsInclusive_']=!_0x22e98c['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x570172){const _0x1d9ac0=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x570172)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x570172)<0x0,_0x1526c4=this['endIsInclusive_']?this['index_']['compare'](_0x570172,this['getEndPost']())<=0x0:this['index_']['compare'](_0x570172,this['getEndPost']())<0x0;return _0x1d9ac0&&_0x1526c4;}['updateChild'](_0x96c168,_0x2be86b,_0x1097a7,_0xdc4999,_0x4ae0e0,_0x73f236){return this['matches'](new E(_0x2be86b,_0x1097a7))||(_0x1097a7=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x96c168,_0x2be86b,_0x1097a7,_0xdc4999,_0x4ae0e0,_0x73f236);}['updateFullNode'](_0xcbb661,_0x1f8356,_0x2b1849){_0x1f8356['isLeafNode']()&&(_0x1f8356=g['EMPTY_NODE']);let _0x169b26=_0x1f8356['withIndex'](this['index_']);_0x169b26=_0x169b26['updatePriority'](g['EMPTY_NODE']);const _0x28581b=this;return _0x1f8356['forEachChild'](R,(_0x22a764,_0xb1c99c)=>{_0x28581b['matches'](new E(_0x22a764,_0xb1c99c))||(_0x169b26=_0x169b26['updateImmediateChild'](_0x22a764,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0xcbb661,_0x169b26,_0x2b1849);}['updatePriority'](_0xe19521,_0x233272){return _0xe19521;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x23e50e){if(_0x23e50e['hasStart']()){const _0x1c0399=_0x23e50e['getIndexStartName']();return _0x23e50e['getIndex']()['makePost'](_0x23e50e['getIndexStartValue'](),_0x1c0399);}else return _0x23e50e['getIndex']()['minPost']();}static['getEndPost_'](_0xd33726){if(_0xd33726['hasEnd']()){const _0x52d4ea=_0xd33726['getIndexEndName']();return _0xd33726['getIndex']()['makePost'](_0xd33726['getIndexEndValue'](),_0x52d4ea);}else return _0xd33726['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x58f002){this['withinDirectionalStart']=_0xb3a64b=>this['reverse_']?this['withinEndPost'](_0xb3a64b):this['withinStartPost'](_0xb3a64b),this['withinDirectionalEnd']=_0x26bad1=>this['reverse_']?this['withinStartPost'](_0x26bad1):this['withinEndPost'](_0x26bad1),this['withinStartPost']=_0x57d8a6=>{const _0x187268=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x57d8a6);return this['startIsInclusive_']?_0x187268<=0x0:_0x187268<0x0;},this['withinEndPost']=_0x86ccf8=>{const _0x564b0a=this['index_']['compare'](_0x86ccf8,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x564b0a<=0x0:_0x564b0a<0x0;},this['rangedFilter_']=new Ot(_0x58f002),this['index_']=_0x58f002['getIndex'](),this['limit_']=_0x58f002['getLimit'](),this['reverse_']=!_0x58f002['isViewFromLeft'](),this['startIsInclusive_']=!_0x58f002['startAfterSet_'],this['endIsInclusive_']=!_0x58f002['endBeforeSet_'];}['updateChild'](_0x1a091f,_0x601a75,_0x3450ac,_0x4605ed,_0x5a70fb,_0x43e8a4){return this['rangedFilter_']['matches'](new E(_0x601a75,_0x3450ac))||(_0x3450ac=g['EMPTY_NODE']),_0x1a091f['getImmediateChild'](_0x601a75)['equals'](_0x3450ac)?_0x1a091f:_0x1a091f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1a091f,_0x601a75,_0x3450ac,_0x4605ed,_0x5a70fb,_0x43e8a4):this['fullLimitUpdateChild_'](_0x1a091f,_0x601a75,_0x3450ac,_0x5a70fb,_0x43e8a4);}['updateFullNode'](_0x354ca0,_0x1c27a7,_0x8b0286){let _0xbadb29;if(_0x1c27a7['isLeafNode']()||_0x1c27a7['isEmpty']())_0xbadb29=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1c27a7['numChildren']()&&_0x1c27a7['isIndexed'](this['index_'])){_0xbadb29=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x25faeb;this['reverse_']?_0x25faeb=_0x1c27a7['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x25faeb=_0x1c27a7['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x26a89e=0x0;for(;_0x25faeb['hasNext']()&&_0x26a89e<this['limit_'];){const _0x1a8a4b=_0x25faeb['getNext']();if(this['withinDirectionalStart'](_0x1a8a4b)){if(this['withinDirectionalEnd'](_0x1a8a4b))_0xbadb29=_0xbadb29['updateImmediateChild'](_0x1a8a4b['name'],_0x1a8a4b['node']),_0x26a89e++;else break;}else continue;}}else{_0xbadb29=_0x1c27a7['withIndex'](this['index_']),_0xbadb29=_0xbadb29['updatePriority'](g['EMPTY_NODE']);let _0x216d2a;this['reverse_']?_0x216d2a=_0xbadb29['getReverseIterator'](this['index_']):_0x216d2a=_0xbadb29['getIterator'](this['index_']);let _0x2e0a32=0x0;for(;_0x216d2a['hasNext']();){const _0x2ff09f=_0x216d2a['getNext']();_0x2e0a32<this['limit_']&&this['withinDirectionalStart'](_0x2ff09f)&&this['withinDirectionalEnd'](_0x2ff09f)?_0x2e0a32++:_0xbadb29=_0xbadb29['updateImmediateChild'](_0x2ff09f['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x354ca0,_0xbadb29,_0x8b0286);}['updatePriority'](_0x46791e,_0x3e18c4){return _0x46791e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2c8d8c,_0x2e5675,_0x2efbca,_0x538f8b,_0x32c8f9){let _0x330a14;if(this['reverse_']){const _0x207000=this['index_']['getCompare']();_0x330a14=(_0x311df4,_0x2c2e9c)=>_0x207000(_0x2c2e9c,_0x311df4);}else _0x330a14=this['index_']['getCompare']();const _0x187962=_0x2c8d8c;f(_0x187962['numChildren']()===this['limit_'],'');const _0x2889a6=new E(_0x2e5675,_0x2efbca),_0x29c81d=this['reverse_']?_0x187962['getFirstChild'](this['index_']):_0x187962['getLastChild'](this['index_']),_0x5d62ed=this['rangedFilter_']['matches'](_0x2889a6);if(_0x187962['hasChild'](_0x2e5675)){const _0x5f4daf=_0x187962['getImmediateChild'](_0x2e5675);let _0x19e224=_0x538f8b['getChildAfterChild'](this['index_'],_0x29c81d,this['reverse_']);for(;_0x19e224!=null&&(_0x19e224['name']===_0x2e5675||_0x187962['hasChild'](_0x19e224['name']));)_0x19e224=_0x538f8b['getChildAfterChild'](this['index_'],_0x19e224,this['reverse_']);const _0x4deff9=_0x19e224==null?0x1:_0x330a14(_0x19e224,_0x2889a6);if(_0x5d62ed&&!_0x2efbca['isEmpty']()&&_0x4deff9>=0x0)return _0x32c8f9!=null&&_0x32c8f9['trackChildChange'](Pt(_0x2e5675,_0x2efbca,_0x5f4daf)),_0x187962['updateImmediateChild'](_0x2e5675,_0x2efbca);{_0x32c8f9!=null&&_0x32c8f9['trackChildChange'](Nt(_0x2e5675,_0x5f4daf));const _0x1ee240=_0x187962['updateImmediateChild'](_0x2e5675,g['EMPTY_NODE']);return _0x19e224!=null&&this['rangedFilter_']['matches'](_0x19e224)?(_0x32c8f9!=null&&_0x32c8f9['trackChildChange'](tt(_0x19e224['name'],_0x19e224['node'])),_0x1ee240['updateImmediateChild'](_0x19e224['name'],_0x19e224['node'])):_0x1ee240;}}else return _0x2efbca['isEmpty']()?_0x2c8d8c:_0x5d62ed&&_0x330a14(_0x29c81d,_0x2889a6)>=0x0?(_0x32c8f9!=null&&(_0x32c8f9['trackChildChange'](Nt(_0x29c81d['name'],_0x29c81d['node'])),_0x32c8f9['trackChildChange'](tt(_0x2e5675,_0x2efbca))),_0x187962['updateImmediateChild'](_0x2e5675,_0x2efbca)['updateImmediateChild'](_0x29c81d['name'],g['EMPTY_NODE'])):_0x2c8d8c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4fd455=new Qi();return _0x4fd455['limitSet_']=this['limitSet_'],_0x4fd455['limit_']=this['limit_'],_0x4fd455['startSet_']=this['startSet_'],_0x4fd455['startAfterSet_']=this['startAfterSet_'],_0x4fd455['indexStartValue_']=this['indexStartValue_'],_0x4fd455['startNameSet_']=this['startNameSet_'],_0x4fd455['indexStartName_']=this['indexStartName_'],_0x4fd455['endSet_']=this['endSet_'],_0x4fd455['endBeforeSet_']=this['endBeforeSet_'],_0x4fd455['indexEndValue_']=this['indexEndValue_'],_0x4fd455['endNameSet_']=this['endNameSet_'],_0x4fd455['indexEndName_']=this['indexEndName_'],_0x4fd455['index_']=this['index_'],_0x4fd455['viewFrom_']=this['viewFrom_'],_0x4fd455;}}function qh(_0x4d6cd2){return _0x4d6cd2['loadsAllData']()?new Yi(_0x4d6cd2['getIndex']()):_0x4d6cd2['hasLimit']()?new Gh(_0x4d6cd2):new Ot(_0x4d6cd2);}function zh(_0x7f3e1d,_0x555ffa){const _0x347559=_0x7f3e1d['copy']();return _0x347559['limitSet_']=!0x0,_0x347559['limit_']=_0x555ffa,_0x347559['viewFrom_']='l',_0x347559;}function jh(_0x42977d,_0x5d57ab,_0x8d519f){const _0x412ab1=_0x42977d['copy']();return _0x412ab1['startSet_']=!0x0,_0x5d57ab===void 0x0&&(_0x5d57ab=null),_0x412ab1['indexStartValue_']=_0x5d57ab,_0x8d519f!=null?(_0x412ab1['startNameSet_']=!0x0,_0x412ab1['indexStartName_']=_0x8d519f):(_0x412ab1['startNameSet_']=!0x1,_0x412ab1['indexStartName_']=''),_0x412ab1;}function Kh(_0x53931c,_0x5cfda0,_0x46969b){const _0x53d695=_0x53931c['copy']();return _0x53d695['endSet_']=!0x0,_0x5cfda0===void 0x0&&(_0x5cfda0=null),_0x53d695['indexEndValue_']=_0x5cfda0,_0x46969b!==void 0x0?(_0x53d695['endNameSet_']=!0x0,_0x53d695['indexEndName_']=_0x46969b):(_0x53d695['endNameSet_']=!0x1,_0x53d695['indexEndName_']=''),_0x53d695;}function Do(_0x213361,_0x3aa1d4){const _0x3d6999=_0x213361['copy']();return _0x3d6999['index_']=_0x3aa1d4,_0x3d6999;}function tr(_0x58944b){const _0x327e83={};if(_0x58944b['isDefault']())return _0x327e83;let _0xfa5f5c;if(_0x58944b['index_']===R?_0xfa5f5c='$priority':_0x58944b['index_']===Po?_0xfa5f5c='$value':_0x58944b['index_']===ye?_0xfa5f5c='$key':(f(_0x58944b['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0xfa5f5c=_0x58944b['index_']['toString']()),_0x327e83['orderBy']=O(_0xfa5f5c),_0x58944b['startSet_']){const _0x511b15=_0x58944b['startAfterSet_']?'startAfter':'startAt';_0x327e83[_0x511b15]=O(_0x58944b['indexStartValue_']),_0x58944b['startNameSet_']&&(_0x327e83[_0x511b15]+=','+O(_0x58944b['indexStartName_']));}if(_0x58944b['endSet_']){const _0x4fb3fc=_0x58944b['endBeforeSet_']?'endBefore':'endAt';_0x327e83[_0x4fb3fc]=O(_0x58944b['indexEndValue_']),_0x58944b['endNameSet_']&&(_0x327e83[_0x4fb3fc]+=','+O(_0x58944b['indexEndName_']));}return _0x58944b['limitSet_']&&(_0x58944b['isViewFromLeft']()?_0x327e83['limitToFirst']=_0x58944b['limit_']:_0x327e83['limitToLast']=_0x58944b['limit_']),_0x327e83;}function nr(_0x800661){const _0x2bfa5d={};if(_0x800661['startSet_']&&(_0x2bfa5d['sp']=_0x800661['indexStartValue_'],_0x800661['startNameSet_']&&(_0x2bfa5d['sn']=_0x800661['indexStartName_']),_0x2bfa5d['sin']=!_0x800661['startAfterSet_']),_0x800661['endSet_']&&(_0x2bfa5d['ep']=_0x800661['indexEndValue_'],_0x800661['endNameSet_']&&(_0x2bfa5d['en']=_0x800661['indexEndName_']),_0x2bfa5d['ein']=!_0x800661['endBeforeSet_']),_0x800661['limitSet_']){_0x2bfa5d['l']=_0x800661['limit_'];let _0x4e917b=_0x800661['viewFrom_'];_0x4e917b===''&&(_0x800661['isViewFromLeft']()?_0x4e917b='l':_0x4e917b='r'),_0x2bfa5d['vf']=_0x4e917b;}return _0x800661['index_']!==R&&(_0x2bfa5d['i']=_0x800661['index_']['toString']()),_0x2bfa5d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x359ec2){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x1132ef,_0x15a249){return _0x15a249!==void 0x0?'tag$'+_0x15a249:(f(_0x1132ef['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x1132ef['_path']['toString']());}constructor(_0x4864c5,_0x597bb3,_0x20233c,_0x5b976f){super(),this['repoInfo_']=_0x4864c5,this['onDataUpdate_']=_0x597bb3,this['authTokenProvider_']=_0x20233c,this['appCheckTokenProvider_']=_0x5b976f,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x8da001,_0xeb36f7,_0x23a870,_0xe9f9ef){const _0x22da58=_0x8da001['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x22da58+'\x20'+_0x8da001['_queryIdentifier']);const _0x204695=fn['getListenId_'](_0x8da001,_0x23a870),_0x4a4b97={};this['listens_'][_0x204695]=_0x4a4b97;const _0x418827=tr(_0x8da001['_queryParams']);this['restRequest_'](_0x22da58+'.json',_0x418827,(_0xb5ba70,_0x4e49af)=>{let _0x3e44a4=_0x4e49af;if(_0xb5ba70===0x194&&(_0x3e44a4=null,_0xb5ba70=null),_0xb5ba70===null&&this['onDataUpdate_'](_0x22da58,_0x3e44a4,!0x1,_0x23a870),Oe(this['listens_'],_0x204695)===_0x4a4b97){let _0x26d4d5;_0xb5ba70?_0xb5ba70===0x191?_0x26d4d5='permission_denied':_0x26d4d5='rest_error:'+_0xb5ba70:_0x26d4d5='ok',_0xe9f9ef(_0x26d4d5,null);}});}['unlisten'](_0x2cb2c4,_0x51a35d){const _0x59b198=fn['getListenId_'](_0x2cb2c4,_0x51a35d);delete this['listens_'][_0x59b198];}['get'](_0x53f6c4){const _0x3ef4e6=tr(_0x53f6c4['_queryParams']),_0x21b96d=_0x53f6c4['_path']['toString'](),_0xca5d06=new Ve();return this['restRequest_'](_0x21b96d+'.json',_0x3ef4e6,(_0x1cb756,_0x2cafb8)=>{let _0x1576b1=_0x2cafb8;_0x1cb756===0x194&&(_0x1576b1=null,_0x1cb756=null),_0x1cb756===null?(this['onDataUpdate_'](_0x21b96d,_0x1576b1,!0x1,null),_0xca5d06['resolve'](_0x1576b1)):_0xca5d06['reject'](new Error(_0x1576b1));}),_0xca5d06['promise'];}['refreshAuthToken'](_0x4e11fe){}['restRequest_'](_0x110ff6,_0x10b6b7={},_0x38d571){return _0x10b6b7['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2837f9,_0x37dbc1])=>{_0x2837f9&&_0x2837f9['accessToken']&&(_0x10b6b7['auth']=_0x2837f9['accessToken']),_0x37dbc1&&_0x37dbc1['token']&&(_0x10b6b7['ac']=_0x37dbc1['token']);const _0x38599f=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x110ff6+'?ns='+this['repoInfo_']['namespace']+at(_0x10b6b7);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x38599f);const _0x3090e2=new XMLHttpRequest();_0x3090e2['onreadystatechange']=()=>{if(_0x38d571&&_0x3090e2['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x38599f+'\x20received.\x20status:',_0x3090e2['status'],'response:',_0x3090e2['responseText']);let _0x565871=null;if(_0x3090e2['status']>=0xc8&&_0x3090e2['status']<0x12c){try{_0x565871=bt(_0x3090e2['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x38599f+':\x20'+_0x3090e2['responseText']);}_0x38d571(null,_0x565871);}else _0x3090e2['status']!==0x191&&_0x3090e2['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x38599f+'\x20Status:\x20'+_0x3090e2['status']),_0x38d571(_0x3090e2['status']);_0x38d571=null;}},_0x3090e2['open']('GET',_0x38599f,!0x0),_0x3090e2['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x495b99){return this['rootNode_']['getChild'](_0x495b99);}['updateSnapshot'](_0x42017e,_0x1aa7b8){this['rootNode_']=this['rootNode_']['updateChild'](_0x42017e,_0x1aa7b8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x216f70,_0x4f043f,_0x140e97){if(v(_0x4f043f))_0x216f70['value']=_0x140e97,_0x216f70['children']['clear']();else{if(_0x216f70['value']!==null)_0x216f70['value']=_0x216f70['value']['updateChild'](_0x4f043f,_0x140e97);else{const _0x5629b0=y(_0x4f043f);_0x216f70['children']['has'](_0x5629b0)||_0x216f70['children']['set'](_0x5629b0,pn());const _0x57ab85=_0x216f70['children']['get'](_0x5629b0);_0x4f043f=b(_0x4f043f),Mo(_0x57ab85,_0x4f043f,_0x140e97);}}}function Ei(_0x38ac9c,_0x1984cd,_0x317eb3){_0x38ac9c['value']!==null?_0x317eb3(_0x1984cd,_0x38ac9c['value']):Qh(_0x38ac9c,(_0x5232f9,_0x3af00d)=>{const _0x1dac79=new C(_0x1984cd['toString']()+'/'+_0x5232f9);Ei(_0x3af00d,_0x1dac79,_0x317eb3);});}function Qh(_0x281dd7,_0x4d4f21){_0x281dd7['children']['forEach']((_0x1a16b1,_0x130f41)=>{_0x4d4f21(_0x130f41,_0x1a16b1);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x51d901){this['collection_']=_0x51d901,this['last_']=null;}['get'](){const _0x34c7b7=this['collection_']['get'](),_0x14d9e5={..._0x34c7b7};return this['last_']&&x(this['last_'],(_0x57385e,_0x56210c)=>{_0x14d9e5[_0x57385e]=_0x14d9e5[_0x57385e]-_0x56210c;}),this['last_']=_0x34c7b7,_0x14d9e5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x46641e,_0x79c3ed){this['server_']=_0x79c3ed,this['statsToReport_']={},this['statsListener_']=new Jh(_0x46641e);const _0x1c9825=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x1c9825));}['reportStats_'](){const _0x1d5e76=this['statsListener_']['get'](),_0x4b5c8a={};let _0x1330f8=!0x1;x(_0x1d5e76,(_0x1c76bf,_0x4c6270)=>{_0x4c6270>0x0&&Y(this['statsToReport_'],_0x1c76bf)&&(_0x4b5c8a[_0x1c76bf]=_0x4c6270,_0x1330f8=!0x0);}),_0x1330f8&&this['server_']['reportStats'](_0x4b5c8a),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x254b67){_0x254b67[_0x254b67['OVERWRITE']=0x0]='OVERWRITE',_0x254b67[_0x254b67['MERGE']=0x1]='MERGE',_0x254b67[_0x254b67['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x254b67[_0x254b67['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x230a50){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x230a50,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x3c1421,_0x34bcab,_0x39348f){this['path']=_0x3c1421,this['affectedTree']=_0x34bcab,this['revert']=_0x39348f,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x11bd55){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x24951d=this['affectedTree']['subtree'](new C(_0x11bd55));return new _n(w(),_0x24951d,this['revert']);}}else return f(y(this['path'])===_0x11bd55,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x2c5431,_0x2bb387){this['source']=_0x2c5431,this['path']=_0x2bb387,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x1dad61){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x4e1b26,_0x38132b,_0x1bed2d){this['source']=_0x4e1b26,this['path']=_0x38132b,this['snap']=_0x1bed2d,this['type']=q['OVERWRITE'];}['operationForChild'](_0x3cf8ef){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x3cf8ef)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x2c1dd2,_0x13d977,_0x29344c){this['source']=_0x2c1dd2,this['path']=_0x13d977,this['children']=_0x29344c,this['type']=q['MERGE'];}['operationForChild'](_0xf94ad8){if(v(this['path'])){const _0x566936=this['children']['subtree'](new C(_0xf94ad8));return _0x566936['isEmpty']()?null:_0x566936['value']?new Fe(this['source'],w(),_0x566936['value']):new nt(this['source'],w(),_0x566936);}else return f(y(this['path'])===_0xf94ad8,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x5e0784,_0x18665c,_0x2277a2){this['node_']=_0x5e0784,this['fullyInitialized_']=_0x18665c,this['filtered_']=_0x2277a2;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1c8435){if(v(_0x1c8435))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5d5c1f=y(_0x1c8435);return this['isCompleteForChild'](_0x5d5c1f);}['isCompleteForChild'](_0x404625){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x404625);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x20d822){this['query_']=_0x20d822,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x156966,_0x2bdeac,_0x3b0734,_0x526939){const _0x324289=[],_0xe45c16=[];return _0x2bdeac['forEach'](_0x3a81f2=>{_0x3a81f2['type']==='child_changed'&&_0x156966['index_']['indexedValueChanged'](_0x3a81f2['oldSnap'],_0x3a81f2['snapshotNode'])&&_0xe45c16['push']($h(_0x3a81f2['childName'],_0x3a81f2['snapshotNode']));}),mt(_0x156966,_0x324289,'child_removed',_0x2bdeac,_0x526939,_0x3b0734),mt(_0x156966,_0x324289,'child_added',_0x2bdeac,_0x526939,_0x3b0734),mt(_0x156966,_0x324289,'child_moved',_0xe45c16,_0x526939,_0x3b0734),mt(_0x156966,_0x324289,'child_changed',_0x2bdeac,_0x526939,_0x3b0734),mt(_0x156966,_0x324289,'value',_0x2bdeac,_0x526939,_0x3b0734),_0x324289;}function mt(_0x327aaa,_0x34c016,_0x2cc01b,_0x55b0a6,_0x586079,_0x4ddc97){const _0x23d308=_0x55b0a6['filter'](_0x1216da=>_0x1216da['type']===_0x2cc01b);_0x23d308['sort']((_0x36081c,_0x1fe5bd)=>su(_0x327aaa,_0x36081c,_0x1fe5bd)),_0x23d308['forEach'](_0x5d9536=>{const _0x452f96=iu(_0x327aaa,_0x5d9536,_0x4ddc97);_0x586079['forEach'](_0xb13a62=>{_0xb13a62['respondsTo'](_0x5d9536['type'])&&_0x34c016['push'](_0xb13a62['createEvent'](_0x452f96,_0x327aaa['query_']));});});}function iu(_0x388231,_0x1b4d61,_0x14ecae){return _0x1b4d61['type']==='value'||_0x1b4d61['type']==='child_removed'||(_0x1b4d61['prevName']=_0x14ecae['getPredecessorChildName'](_0x1b4d61['childName'],_0x1b4d61['snapshotNode'],_0x388231['index_'])),_0x1b4d61;}function su(_0x411794,_0x734819,_0x24aa27){if(_0x734819['childName']==null||_0x24aa27['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0xf3caed=new E(_0x734819['childName'],_0x734819['snapshotNode']),_0x410100=new E(_0x24aa27['childName'],_0x24aa27['snapshotNode']);return _0x411794['index_']['compare'](_0xf3caed,_0x410100);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0xe69d0e,_0x3335f2){return{'eventCache':_0xe69d0e,'serverCache':_0x3335f2};}function wt(_0x6efef9,_0x670f1d,_0x561b39,_0x219a83){return Dn(new Ce(_0x670f1d,_0x561b39,_0x219a83),_0x6efef9['serverCache']);}function Lo(_0x520259,_0x5839a6,_0x4e986d,_0x4021b){return Dn(_0x520259['eventCache'],new Ce(_0x5839a6,_0x4e986d,_0x4021b));}function gn(_0x442e12){return _0x442e12['eventCache']['isFullyInitialized']()?_0x442e12['eventCache']['getNode']():null;}function Ue(_0x243c68){return _0x243c68['serverCache']['isFullyInitialized']()?_0x243c68['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x2a200a){let _0xa4617=new S(null);return x(_0x2a200a,(_0x4c64e3,_0x40210b)=>{_0xa4617=_0xa4617['set'](new C(_0x4c64e3),_0x40210b);}),_0xa4617;}constructor(_0x27438d,_0x43442f=ru()){this['value']=_0x27438d,this['children']=_0x43442f;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x30630c,_0x4700e0){if(this['value']!=null&&_0x4700e0(this['value']))return{'path':w(),'value':this['value']};if(v(_0x30630c))return null;{const _0x5e8c39=y(_0x30630c),_0x2fee58=this['children']['get'](_0x5e8c39);if(_0x2fee58!==null){const _0x439e48=_0x2fee58['findRootMostMatchingPathAndValue'](b(_0x30630c),_0x4700e0);return _0x439e48!=null?{'path':A(new C(_0x5e8c39),_0x439e48['path']),'value':_0x439e48['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x42ef8d){return this['findRootMostMatchingPathAndValue'](_0x42ef8d,()=>!0x0);}['subtree'](_0x3501f0){if(v(_0x3501f0))return this;{const _0x2baac8=y(_0x3501f0),_0x1c6437=this['children']['get'](_0x2baac8);return _0x1c6437!==null?_0x1c6437['subtree'](b(_0x3501f0)):new S(null);}}['set'](_0x1b8041,_0x26ed70){if(v(_0x1b8041))return new S(_0x26ed70,this['children']);{const _0x338118=y(_0x1b8041),_0x1e80ee=(this['children']['get'](_0x338118)||new S(null))['set'](b(_0x1b8041),_0x26ed70),_0x4e128d=this['children']['insert'](_0x338118,_0x1e80ee);return new S(this['value'],_0x4e128d);}}['remove'](_0x4a3def){if(v(_0x4a3def))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x57029d=y(_0x4a3def),_0x3c396=this['children']['get'](_0x57029d);if(_0x3c396){const _0x4f9d65=_0x3c396['remove'](b(_0x4a3def));let _0xa17bdd;return _0x4f9d65['isEmpty']()?_0xa17bdd=this['children']['remove'](_0x57029d):_0xa17bdd=this['children']['insert'](_0x57029d,_0x4f9d65),this['value']===null&&_0xa17bdd['isEmpty']()?new S(null):new S(this['value'],_0xa17bdd);}else return this;}}['get'](_0x3cba0f){if(v(_0x3cba0f))return this['value'];{const _0x8e87e8=y(_0x3cba0f),_0x130b6f=this['children']['get'](_0x8e87e8);return _0x130b6f?_0x130b6f['get'](b(_0x3cba0f)):null;}}['setTree'](_0x5c601f,_0xbd37a8){if(v(_0x5c601f))return _0xbd37a8;{const _0x317a2e=y(_0x5c601f),_0x167baa=(this['children']['get'](_0x317a2e)||new S(null))['setTree'](b(_0x5c601f),_0xbd37a8);let _0x565739;return _0x167baa['isEmpty']()?_0x565739=this['children']['remove'](_0x317a2e):_0x565739=this['children']['insert'](_0x317a2e,_0x167baa),new S(this['value'],_0x565739);}}['fold'](_0x468410){return this['fold_'](w(),_0x468410);}['fold_'](_0x1a344a,_0x1ab3f5){const _0x5bfb59={};return this['children']['inorderTraversal']((_0x3108dc,_0x2897a2)=>{_0x5bfb59[_0x3108dc]=_0x2897a2['fold_'](A(_0x1a344a,_0x3108dc),_0x1ab3f5);}),_0x1ab3f5(_0x1a344a,this['value'],_0x5bfb59);}['findOnPath'](_0x5920ea,_0x4bacfc){return this['findOnPath_'](_0x5920ea,w(),_0x4bacfc);}['findOnPath_'](_0x574e47,_0x82ea0f,_0x454812){const _0x1e0f9e=this['value']?_0x454812(_0x82ea0f,this['value']):!0x1;if(_0x1e0f9e)return _0x1e0f9e;if(v(_0x574e47))return null;{const _0x4c8558=y(_0x574e47),_0x56808b=this['children']['get'](_0x4c8558);return _0x56808b?_0x56808b['findOnPath_'](b(_0x574e47),A(_0x82ea0f,_0x4c8558),_0x454812):null;}}['foreachOnPath'](_0x4afdb6,_0x39b713){return this['foreachOnPath_'](_0x4afdb6,w(),_0x39b713);}['foreachOnPath_'](_0x15e5f5,_0x5ae197,_0x100959){if(v(_0x15e5f5))return this;{this['value']&&_0x100959(_0x5ae197,this['value']);const _0xb80f05=y(_0x15e5f5),_0x1d0de3=this['children']['get'](_0xb80f05);return _0x1d0de3?_0x1d0de3['foreachOnPath_'](b(_0x15e5f5),A(_0x5ae197,_0xb80f05),_0x100959):new S(null);}}['foreach'](_0x391e20){this['foreach_'](w(),_0x391e20);}['foreach_'](_0x3a9445,_0x79be47){this['children']['inorderTraversal']((_0x5bb060,_0x59aba0)=>{_0x59aba0['foreach_'](A(_0x3a9445,_0x5bb060),_0x79be47);}),this['value']&&_0x79be47(_0x3a9445,this['value']);}['foreachChild'](_0x2c685b){this['children']['inorderTraversal']((_0x191947,_0x229eff)=>{_0x229eff['value']&&_0x2c685b(_0x191947,_0x229eff['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x4ef368){this['writeTree_']=_0x4ef368;}static['empty'](){return new j(new S(null));}}function Ct(_0x54c834,_0xdccaba,_0x3bdbb4){if(v(_0xdccaba))return new j(new S(_0x3bdbb4));{const _0x5f4759=_0x54c834['writeTree_']['findRootMostValueAndPath'](_0xdccaba);if(_0x5f4759!=null){const _0x2b56dc=_0x5f4759['path'];let _0xc03977=_0x5f4759['value'];const _0x3aa74e=F(_0x2b56dc,_0xdccaba);return _0xc03977=_0xc03977['updateChild'](_0x3aa74e,_0x3bdbb4),new j(_0x54c834['writeTree_']['set'](_0x2b56dc,_0xc03977));}else{const _0x36099e=new S(_0x3bdbb4),_0x1cc8f2=_0x54c834['writeTree_']['setTree'](_0xdccaba,_0x36099e);return new j(_0x1cc8f2);}}}function Ii(_0x18e9a6,_0x3ad0de,_0x1c6106){let _0xa82600=_0x18e9a6;return x(_0x1c6106,(_0x5e8b2b,_0x32af36)=>{_0xa82600=Ct(_0xa82600,A(_0x3ad0de,_0x5e8b2b),_0x32af36);}),_0xa82600;}function sr(_0x3f022e,_0x1cb86a){if(v(_0x1cb86a))return j['empty']();{const _0xe2279e=_0x3f022e['writeTree_']['setTree'](_0x1cb86a,new S(null));return new j(_0xe2279e);}}function wi(_0xc3751f,_0x415e55){return $e(_0xc3751f,_0x415e55)!=null;}function $e(_0x4583ec,_0x4eb758){const _0x5ee6e6=_0x4583ec['writeTree_']['findRootMostValueAndPath'](_0x4eb758);return _0x5ee6e6!=null?_0x4583ec['writeTree_']['get'](_0x5ee6e6['path'])['getChild'](F(_0x5ee6e6['path'],_0x4eb758)):null;}function rr(_0x1b6a17){const _0x4f242a=[],_0x55b333=_0x1b6a17['writeTree_']['value'];return _0x55b333!=null?_0x55b333['isLeafNode']()||_0x55b333['forEachChild'](R,(_0x4ebf33,_0x4e60f9)=>{_0x4f242a['push'](new E(_0x4ebf33,_0x4e60f9));}):_0x1b6a17['writeTree_']['children']['inorderTraversal']((_0x5790fc,_0x51f96c)=>{_0x51f96c['value']!=null&&_0x4f242a['push'](new E(_0x5790fc,_0x51f96c['value']));}),_0x4f242a;}function ve(_0xdc8c50,_0x41c133){if(v(_0x41c133))return _0xdc8c50;{const _0x1014be=$e(_0xdc8c50,_0x41c133);return _0x1014be!=null?new j(new S(_0x1014be)):new j(_0xdc8c50['writeTree_']['subtree'](_0x41c133));}}function Ci(_0x8901f2){return _0x8901f2['writeTree_']['isEmpty']();}function it(_0x20c124,_0x2ffb1f){return xo(w(),_0x20c124['writeTree_'],_0x2ffb1f);}function xo(_0x437cff,_0x543f36,_0x1f1724){if(_0x543f36['value']!=null)return _0x1f1724['updateChild'](_0x437cff,_0x543f36['value']);{let _0xbf7b4c=null;return _0x543f36['children']['inorderTraversal']((_0x2fff6a,_0x715db9)=>{_0x2fff6a==='.priority'?(f(_0x715db9['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xbf7b4c=_0x715db9['value']):_0x1f1724=xo(A(_0x437cff,_0x2fff6a),_0x715db9,_0x1f1724);}),!_0x1f1724['getChild'](_0x437cff)['isEmpty']()&&_0xbf7b4c!==null&&(_0x1f1724=_0x1f1724['updateChild'](A(_0x437cff,'.priority'),_0xbf7b4c)),_0x1f1724;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x533b65,_0x4b76eb){return Bo(_0x4b76eb,_0x533b65);}function ou(_0x2b9a01,_0x89b4ff,_0x50bb58,_0x4e7e86,_0xe4dfc9){f(_0x4e7e86>_0x2b9a01['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0xe4dfc9===void 0x0&&(_0xe4dfc9=!0x0),_0x2b9a01['allWrites']['push']({'path':_0x89b4ff,'snap':_0x50bb58,'writeId':_0x4e7e86,'visible':_0xe4dfc9}),_0xe4dfc9&&(_0x2b9a01['visibleWrites']=Ct(_0x2b9a01['visibleWrites'],_0x89b4ff,_0x50bb58)),_0x2b9a01['lastWriteId']=_0x4e7e86;}function au(_0xf0f410,_0x444cd0,_0x19b681,_0x3fc581){f(_0x3fc581>_0xf0f410['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0xf0f410['allWrites']['push']({'path':_0x444cd0,'children':_0x19b681,'writeId':_0x3fc581,'visible':!0x0}),_0xf0f410['visibleWrites']=Ii(_0xf0f410['visibleWrites'],_0x444cd0,_0x19b681),_0xf0f410['lastWriteId']=_0x3fc581;}function cu(_0x3baa04,_0x2a4321){for(let _0x4883da=0x0;_0x4883da<_0x3baa04['allWrites']['length'];_0x4883da++){const _0xf58515=_0x3baa04['allWrites'][_0x4883da];if(_0xf58515['writeId']===_0x2a4321)return _0xf58515;}return null;}function lu(_0x4ebddb,_0x4a45cf){const _0x54681e=_0x4ebddb['allWrites']['findIndex'](_0x35edb1=>_0x35edb1['writeId']===_0x4a45cf);f(_0x54681e>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4d0e42=_0x4ebddb['allWrites'][_0x54681e];_0x4ebddb['allWrites']['splice'](_0x54681e,0x1);let _0x477116=_0x4d0e42['visible'],_0x5148c1=!0x1,_0x2b506c=_0x4ebddb['allWrites']['length']-0x1;for(;_0x477116&&_0x2b506c>=0x0;){const _0x4ffeb6=_0x4ebddb['allWrites'][_0x2b506c];_0x4ffeb6['visible']&&(_0x2b506c>=_0x54681e&&hu(_0x4ffeb6,_0x4d0e42['path'])?_0x477116=!0x1:$(_0x4d0e42['path'],_0x4ffeb6['path'])&&(_0x5148c1=!0x0)),_0x2b506c--;}if(_0x477116){if(_0x5148c1)return uu(_0x4ebddb),!0x0;if(_0x4d0e42['snap'])_0x4ebddb['visibleWrites']=sr(_0x4ebddb['visibleWrites'],_0x4d0e42['path']);else{const _0x102803=_0x4d0e42['children'];x(_0x102803,_0x10df08=>{_0x4ebddb['visibleWrites']=sr(_0x4ebddb['visibleWrites'],A(_0x4d0e42['path'],_0x10df08));});}return!0x0;}else return!0x1;}function hu(_0x4addd5,_0xd0ff56){if(_0x4addd5['snap'])return $(_0x4addd5['path'],_0xd0ff56);for(const _0x352264 in _0x4addd5['children'])if(_0x4addd5['children']['hasOwnProperty'](_0x352264)&&$(A(_0x4addd5['path'],_0x352264),_0xd0ff56))return!0x0;return!0x1;}function uu(_0x4b67ba){_0x4b67ba['visibleWrites']=Fo(_0x4b67ba['allWrites'],du,w()),_0x4b67ba['allWrites']['length']>0x0?_0x4b67ba['lastWriteId']=_0x4b67ba['allWrites'][_0x4b67ba['allWrites']['length']-0x1]['writeId']:_0x4b67ba['lastWriteId']=-0x1;}function du(_0xe06d22){return _0xe06d22['visible'];}function Fo(_0x15569e,_0x283dc5,_0x15ab38){let _0x55f7fb=j['empty']();for(let _0x18aa65=0x0;_0x18aa65<_0x15569e['length'];++_0x18aa65){const _0x2d8f52=_0x15569e[_0x18aa65];if(_0x283dc5(_0x2d8f52)){const _0x2eb0fc=_0x2d8f52['path'];let _0x512e96;if(_0x2d8f52['snap'])$(_0x15ab38,_0x2eb0fc)?(_0x512e96=F(_0x15ab38,_0x2eb0fc),_0x55f7fb=Ct(_0x55f7fb,_0x512e96,_0x2d8f52['snap'])):$(_0x2eb0fc,_0x15ab38)&&(_0x512e96=F(_0x2eb0fc,_0x15ab38),_0x55f7fb=Ct(_0x55f7fb,w(),_0x2d8f52['snap']['getChild'](_0x512e96)));else{if(_0x2d8f52['children']){if($(_0x15ab38,_0x2eb0fc))_0x512e96=F(_0x15ab38,_0x2eb0fc),_0x55f7fb=Ii(_0x55f7fb,_0x512e96,_0x2d8f52['children']);else{if($(_0x2eb0fc,_0x15ab38)){if(_0x512e96=F(_0x2eb0fc,_0x15ab38),v(_0x512e96))_0x55f7fb=Ii(_0x55f7fb,w(),_0x2d8f52['children']);else{const _0x26f0d8=Oe(_0x2d8f52['children'],y(_0x512e96));if(_0x26f0d8){const _0x2293dc=_0x26f0d8['getChild'](b(_0x512e96));_0x55f7fb=Ct(_0x55f7fb,w(),_0x2293dc);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x55f7fb;}function Uo(_0x687c58,_0x5d4577,_0x1cc665,_0x472d17,_0x480fd9){if(!_0x472d17&&!_0x480fd9){const _0x52f732=$e(_0x687c58['visibleWrites'],_0x5d4577);if(_0x52f732!=null)return _0x52f732;{const _0x3fbb08=ve(_0x687c58['visibleWrites'],_0x5d4577);if(Ci(_0x3fbb08))return _0x1cc665;if(_0x1cc665==null&&!wi(_0x3fbb08,w()))return null;{const _0x4db7ce=_0x1cc665||g['EMPTY_NODE'];return it(_0x3fbb08,_0x4db7ce);}}}else{const _0x1e4af7=ve(_0x687c58['visibleWrites'],_0x5d4577);if(!_0x480fd9&&Ci(_0x1e4af7))return _0x1cc665;if(!_0x480fd9&&_0x1cc665==null&&!wi(_0x1e4af7,w()))return null;{const _0xcb0093=function(_0x200cd0){return(_0x200cd0['visible']||_0x480fd9)&&(!_0x472d17||!~_0x472d17['indexOf'](_0x200cd0['writeId']))&&($(_0x200cd0['path'],_0x5d4577)||$(_0x5d4577,_0x200cd0['path']));},_0x4cbf59=Fo(_0x687c58['allWrites'],_0xcb0093,_0x5d4577),_0x3642cf=_0x1cc665||g['EMPTY_NODE'];return it(_0x4cbf59,_0x3642cf);}}}function fu(_0x10b7eb,_0x2371cc,_0x35c55d){let _0x47b21a=g['EMPTY_NODE'];const _0x449145=$e(_0x10b7eb['visibleWrites'],_0x2371cc);if(_0x449145)return _0x449145['isLeafNode']()||_0x449145['forEachChild'](R,(_0x1c51f3,_0x4001b0)=>{_0x47b21a=_0x47b21a['updateImmediateChild'](_0x1c51f3,_0x4001b0);}),_0x47b21a;if(_0x35c55d){const _0xa920f9=ve(_0x10b7eb['visibleWrites'],_0x2371cc);return _0x35c55d['forEachChild'](R,(_0x21349b,_0x4f5f6d)=>{const _0x3c736f=it(ve(_0xa920f9,new C(_0x21349b)),_0x4f5f6d);_0x47b21a=_0x47b21a['updateImmediateChild'](_0x21349b,_0x3c736f);}),rr(_0xa920f9)['forEach'](_0x30119e=>{_0x47b21a=_0x47b21a['updateImmediateChild'](_0x30119e['name'],_0x30119e['node']);}),_0x47b21a;}else{const _0x593702=ve(_0x10b7eb['visibleWrites'],_0x2371cc);return rr(_0x593702)['forEach'](_0x42f2b0=>{_0x47b21a=_0x47b21a['updateImmediateChild'](_0x42f2b0['name'],_0x42f2b0['node']);}),_0x47b21a;}}function pu(_0x17c8ce,_0x5e6a48,_0x20b605,_0xe6b788,_0x6c049){f(_0xe6b788||_0x6c049,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5c8319=A(_0x5e6a48,_0x20b605);if(wi(_0x17c8ce['visibleWrites'],_0x5c8319))return null;{const _0x170719=ve(_0x17c8ce['visibleWrites'],_0x5c8319);return Ci(_0x170719)?_0x6c049['getChild'](_0x20b605):it(_0x170719,_0x6c049['getChild'](_0x20b605));}}function _u(_0x366f2a,_0x1fcd02,_0x7dd241,_0x5433c6){const _0x2449ea=A(_0x1fcd02,_0x7dd241),_0x51b07e=$e(_0x366f2a['visibleWrites'],_0x2449ea);if(_0x51b07e!=null)return _0x51b07e;if(_0x5433c6['isCompleteForChild'](_0x7dd241)){const _0x4e65b1=ve(_0x366f2a['visibleWrites'],_0x2449ea);return it(_0x4e65b1,_0x5433c6['getNode']()['getImmediateChild'](_0x7dd241));}else return null;}function gu(_0x494259,_0x473165){return $e(_0x494259['visibleWrites'],_0x473165);}function mu(_0x37b932,_0x16b6cf,_0x44148e,_0x988703,_0x3234f6,_0x190038,_0x1fdcb5){let _0x2174c3;const _0x399c74=ve(_0x37b932['visibleWrites'],_0x16b6cf),_0xf8b161=$e(_0x399c74,w());if(_0xf8b161!=null)_0x2174c3=_0xf8b161;else{if(_0x44148e!=null)_0x2174c3=it(_0x399c74,_0x44148e);else return[];}if(_0x2174c3=_0x2174c3['withIndex'](_0x1fdcb5),!_0x2174c3['isEmpty']()&&!_0x2174c3['isLeafNode']()){const _0x4d9e33=[],_0x587446=_0x1fdcb5['getCompare'](),_0x302764=_0x190038?_0x2174c3['getReverseIteratorFrom'](_0x988703,_0x1fdcb5):_0x2174c3['getIteratorFrom'](_0x988703,_0x1fdcb5);let _0x2b4215=_0x302764['getNext']();for(;_0x2b4215&&_0x4d9e33['length']<_0x3234f6;)_0x587446(_0x2b4215,_0x988703)!==0x0&&_0x4d9e33['push'](_0x2b4215),_0x2b4215=_0x302764['getNext']();return _0x4d9e33;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x41f5ae,_0x19797e,_0x2f14c7,_0x14129f){return Uo(_0x41f5ae['writeTree'],_0x41f5ae['treePath'],_0x19797e,_0x2f14c7,_0x14129f);}function es(_0x4de561,_0x15914e){return fu(_0x4de561['writeTree'],_0x4de561['treePath'],_0x15914e);}function or(_0x4d23c1,_0x129eb3,_0x5ab812,_0x47cba3){return pu(_0x4d23c1['writeTree'],_0x4d23c1['treePath'],_0x129eb3,_0x5ab812,_0x47cba3);}function yn(_0x387d0c,_0x1ffb8f){return gu(_0x387d0c['writeTree'],A(_0x387d0c['treePath'],_0x1ffb8f));}function vu(_0x48a43e,_0x18a7a2,_0x5b97aa,_0xc134a2,_0x1a7ef4,_0x1d4588){return mu(_0x48a43e['writeTree'],_0x48a43e['treePath'],_0x18a7a2,_0x5b97aa,_0xc134a2,_0x1a7ef4,_0x1d4588);}function ts(_0x318857,_0xfff216,_0x3e1205){return _u(_0x318857['writeTree'],_0x318857['treePath'],_0xfff216,_0x3e1205);}function Wo(_0x12005a,_0x2b82b2){return Bo(A(_0x12005a['treePath'],_0x2b82b2),_0x12005a['writeTree']);}function Bo(_0x14268d,_0x52e3cf){return{'treePath':_0x14268d,'writeTree':_0x52e3cf};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x14228f){const _0x578f3b=_0x14228f['type'],_0x241992=_0x14228f['childName'];f(_0x578f3b==='child_added'||_0x578f3b==='child_changed'||_0x578f3b==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x241992!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4a0cbc=this['changeMap']['get'](_0x241992);if(_0x4a0cbc){const _0x1b1a22=_0x4a0cbc['type'];if(_0x578f3b==='child_added'&&_0x1b1a22==='child_removed')this['changeMap']['set'](_0x241992,Pt(_0x241992,_0x14228f['snapshotNode'],_0x4a0cbc['snapshotNode']));else{if(_0x578f3b==='child_removed'&&_0x1b1a22==='child_added')this['changeMap']['delete'](_0x241992);else{if(_0x578f3b==='child_removed'&&_0x1b1a22==='child_changed')this['changeMap']['set'](_0x241992,Nt(_0x241992,_0x4a0cbc['oldSnap']));else{if(_0x578f3b==='child_changed'&&_0x1b1a22==='child_added')this['changeMap']['set'](_0x241992,tt(_0x241992,_0x14228f['snapshotNode']));else{if(_0x578f3b==='child_changed'&&_0x1b1a22==='child_changed')this['changeMap']['set'](_0x241992,Pt(_0x241992,_0x14228f['snapshotNode'],_0x4a0cbc['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x14228f+'\x20occurred\x20after\x20'+_0x4a0cbc);}}}}}else this['changeMap']['set'](_0x241992,_0x14228f);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x46d186){return null;}['getChildAfterChild'](_0x1b18de,_0x82a07c,_0x490f61){return null;}}const Vo=new Iu();class ns{constructor(_0x137405,_0x25ae3f,_0x44de9e=null){this['writes_']=_0x137405,this['viewCache_']=_0x25ae3f,this['optCompleteServerCache_']=_0x44de9e;}['getCompleteChild'](_0x4949c1){const _0x3c5ea6=this['viewCache_']['eventCache'];if(_0x3c5ea6['isCompleteForChild'](_0x4949c1))return _0x3c5ea6['getNode']()['getImmediateChild'](_0x4949c1);{const _0xd6bd67=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x4949c1,_0xd6bd67);}}['getChildAfterChild'](_0xa6956c,_0x4be62f,_0x2c6403){const _0x57f770=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x2b01a5=vu(this['writes_'],_0x57f770,_0x4be62f,0x1,_0x2c6403,_0xa6956c);return _0x2b01a5['length']===0x0?null:_0x2b01a5[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x185f14){return{'filter':_0x185f14};}function Cu(_0x234d50,_0x4adacc){f(_0x4adacc['eventCache']['getNode']()['isIndexed'](_0x234d50['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4adacc['serverCache']['getNode']()['isIndexed'](_0x234d50['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x5f3861,_0x239f66,_0x2f53ac,_0x3c1eb4,_0x5db695){const _0xd7c294=new Eu();let _0x2c95c0,_0x3560e7;if(_0x2f53ac['type']===q['OVERWRITE']){const _0x920146=_0x2f53ac;_0x920146['source']['fromUser']?_0x2c95c0=Ti(_0x5f3861,_0x239f66,_0x920146['path'],_0x920146['snap'],_0x3c1eb4,_0x5db695,_0xd7c294):(f(_0x920146['source']['fromServer'],'Unknown\x20source.'),_0x3560e7=_0x920146['source']['tagged']||_0x239f66['serverCache']['isFiltered']()&&!v(_0x920146['path']),_0x2c95c0=vn(_0x5f3861,_0x239f66,_0x920146['path'],_0x920146['snap'],_0x3c1eb4,_0x5db695,_0x3560e7,_0xd7c294));}else{if(_0x2f53ac['type']===q['MERGE']){const _0x4be1fa=_0x2f53ac;_0x4be1fa['source']['fromUser']?_0x2c95c0=bu(_0x5f3861,_0x239f66,_0x4be1fa['path'],_0x4be1fa['children'],_0x3c1eb4,_0x5db695,_0xd7c294):(f(_0x4be1fa['source']['fromServer'],'Unknown\x20source.'),_0x3560e7=_0x4be1fa['source']['tagged']||_0x239f66['serverCache']['isFiltered'](),_0x2c95c0=Si(_0x5f3861,_0x239f66,_0x4be1fa['path'],_0x4be1fa['children'],_0x3c1eb4,_0x5db695,_0x3560e7,_0xd7c294));}else{if(_0x2f53ac['type']===q['ACK_USER_WRITE']){const _0x3b2c90=_0x2f53ac;_0x3b2c90['revert']?_0x2c95c0=ku(_0x5f3861,_0x239f66,_0x3b2c90['path'],_0x3c1eb4,_0x5db695,_0xd7c294):_0x2c95c0=Ru(_0x5f3861,_0x239f66,_0x3b2c90['path'],_0x3b2c90['affectedTree'],_0x3c1eb4,_0x5db695,_0xd7c294);}else{if(_0x2f53ac['type']===q['LISTEN_COMPLETE'])_0x2c95c0=Au(_0x5f3861,_0x239f66,_0x2f53ac['path'],_0x3c1eb4,_0xd7c294);else throw ot('Unknown\x20operation\x20type:\x20'+_0x2f53ac['type']);}}}const _0x1a7412=_0xd7c294['getChanges']();return Su(_0x239f66,_0x2c95c0,_0x1a7412),{'viewCache':_0x2c95c0,'changes':_0x1a7412};}function Su(_0x11b2ba,_0x496bc0,_0xe457bf){const _0x176cff=_0x496bc0['eventCache'];if(_0x176cff['isFullyInitialized']()){const _0x460588=_0x176cff['getNode']()['isLeafNode']()||_0x176cff['getNode']()['isEmpty'](),_0xf7a783=gn(_0x11b2ba);(_0xe457bf['length']>0x0||!_0x11b2ba['eventCache']['isFullyInitialized']()||_0x460588&&!_0x176cff['getNode']()['equals'](_0xf7a783)||!_0x176cff['getNode']()['getPriority']()['equals'](_0xf7a783['getPriority']()))&&_0xe457bf['push'](Oo(gn(_0x496bc0)));}}function Ho(_0x464605,_0x296bec,_0x2495aa,_0x32e445,_0xf67ac0,_0x318f25){const _0x411084=_0x296bec['eventCache'];if(yn(_0x32e445,_0x2495aa)!=null)return _0x296bec;{let _0x2bc3db,_0x4450db;if(v(_0x2495aa)){if(f(_0x296bec['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x296bec['serverCache']['isFiltered']()){const _0x40aae0=Ue(_0x296bec),_0x22815f=_0x40aae0 instanceof g?_0x40aae0:g['EMPTY_NODE'],_0x19c3b4=es(_0x32e445,_0x22815f);_0x2bc3db=_0x464605['filter']['updateFullNode'](_0x296bec['eventCache']['getNode'](),_0x19c3b4,_0x318f25);}else{const _0x4b195b=mn(_0x32e445,Ue(_0x296bec));_0x2bc3db=_0x464605['filter']['updateFullNode'](_0x296bec['eventCache']['getNode'](),_0x4b195b,_0x318f25);}}else{const _0x4a1303=y(_0x2495aa);if(_0x4a1303==='.priority'){f(we(_0x2495aa)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2c8e2a=_0x411084['getNode']();_0x4450db=_0x296bec['serverCache']['getNode']();const _0x420d01=or(_0x32e445,_0x2495aa,_0x2c8e2a,_0x4450db);_0x420d01!=null?_0x2bc3db=_0x464605['filter']['updatePriority'](_0x2c8e2a,_0x420d01):_0x2bc3db=_0x411084['getNode']();}else{const _0x17dc2a=b(_0x2495aa);let _0x1ad635;if(_0x411084['isCompleteForChild'](_0x4a1303)){_0x4450db=_0x296bec['serverCache']['getNode']();const _0x6915ff=or(_0x32e445,_0x2495aa,_0x411084['getNode'](),_0x4450db);_0x6915ff!=null?_0x1ad635=_0x411084['getNode']()['getImmediateChild'](_0x4a1303)['updateChild'](_0x17dc2a,_0x6915ff):_0x1ad635=_0x411084['getNode']()['getImmediateChild'](_0x4a1303);}else _0x1ad635=ts(_0x32e445,_0x4a1303,_0x296bec['serverCache']);_0x1ad635!=null?_0x2bc3db=_0x464605['filter']['updateChild'](_0x411084['getNode'](),_0x4a1303,_0x1ad635,_0x17dc2a,_0xf67ac0,_0x318f25):_0x2bc3db=_0x411084['getNode']();}}return wt(_0x296bec,_0x2bc3db,_0x411084['isFullyInitialized']()||v(_0x2495aa),_0x464605['filter']['filtersNodes']());}}function vn(_0x58d628,_0x2bddc2,_0x47fa20,_0x16722e,_0x5eac,_0x1f6aea,_0x17a77c,_0x558a02){const _0x9532dd=_0x2bddc2['serverCache'];let _0x196444;const _0x3e4b61=_0x17a77c?_0x58d628['filter']:_0x58d628['filter']['getIndexedFilter']();if(v(_0x47fa20))_0x196444=_0x3e4b61['updateFullNode'](_0x9532dd['getNode'](),_0x16722e,null);else{if(_0x3e4b61['filtersNodes']()&&!_0x9532dd['isFiltered']()){const _0x83f720=_0x9532dd['getNode']()['updateChild'](_0x47fa20,_0x16722e);_0x196444=_0x3e4b61['updateFullNode'](_0x9532dd['getNode'](),_0x83f720,null);}else{const _0x2c4659=y(_0x47fa20);if(!_0x9532dd['isCompleteForPath'](_0x47fa20)&&we(_0x47fa20)>0x1)return _0x2bddc2;const _0x15cfd5=b(_0x47fa20),_0x572f9b=_0x9532dd['getNode']()['getImmediateChild'](_0x2c4659)['updateChild'](_0x15cfd5,_0x16722e);_0x2c4659==='.priority'?_0x196444=_0x3e4b61['updatePriority'](_0x9532dd['getNode'](),_0x572f9b):_0x196444=_0x3e4b61['updateChild'](_0x9532dd['getNode'](),_0x2c4659,_0x572f9b,_0x15cfd5,Vo,null);}}const _0x34e4fd=Lo(_0x2bddc2,_0x196444,_0x9532dd['isFullyInitialized']()||v(_0x47fa20),_0x3e4b61['filtersNodes']()),_0x404f25=new ns(_0x5eac,_0x34e4fd,_0x1f6aea);return Ho(_0x58d628,_0x34e4fd,_0x47fa20,_0x5eac,_0x404f25,_0x558a02);}function Ti(_0x31f4b1,_0x408dfc,_0x1222ab,_0x130a57,_0x54670a,_0x552848,_0x4cbbf8){const _0x55a6f1=_0x408dfc['eventCache'];let _0x526ed8,_0x252f61;const _0x1a92fe=new ns(_0x54670a,_0x408dfc,_0x552848);if(v(_0x1222ab))_0x252f61=_0x31f4b1['filter']['updateFullNode'](_0x408dfc['eventCache']['getNode'](),_0x130a57,_0x4cbbf8),_0x526ed8=wt(_0x408dfc,_0x252f61,!0x0,_0x31f4b1['filter']['filtersNodes']());else{const _0x1d682b=y(_0x1222ab);if(_0x1d682b==='.priority')_0x252f61=_0x31f4b1['filter']['updatePriority'](_0x408dfc['eventCache']['getNode'](),_0x130a57),_0x526ed8=wt(_0x408dfc,_0x252f61,_0x55a6f1['isFullyInitialized'](),_0x55a6f1['isFiltered']());else{const _0x361888=b(_0x1222ab),_0x324846=_0x55a6f1['getNode']()['getImmediateChild'](_0x1d682b);let _0x449fe7;if(v(_0x361888))_0x449fe7=_0x130a57;else{const _0x1c854b=_0x1a92fe['getCompleteChild'](_0x1d682b);_0x1c854b!=null?Gi(_0x361888)==='.priority'&&_0x1c854b['getChild'](To(_0x361888))['isEmpty']()?_0x449fe7=_0x1c854b:_0x449fe7=_0x1c854b['updateChild'](_0x361888,_0x130a57):_0x449fe7=g['EMPTY_NODE'];}if(_0x324846['equals'](_0x449fe7))_0x526ed8=_0x408dfc;else{const _0x9556d5=_0x31f4b1['filter']['updateChild'](_0x55a6f1['getNode'](),_0x1d682b,_0x449fe7,_0x361888,_0x1a92fe,_0x4cbbf8);_0x526ed8=wt(_0x408dfc,_0x9556d5,_0x55a6f1['isFullyInitialized'](),_0x31f4b1['filter']['filtersNodes']());}}}return _0x526ed8;}function ar(_0x5957d5,_0x59cd75){return _0x5957d5['eventCache']['isCompleteForChild'](_0x59cd75);}function bu(_0x469e8e,_0x4ad170,_0x13253f,_0x2465cf,_0x144c88,_0x167b77,_0x79618d){let _0x428fb6=_0x4ad170;return _0x2465cf['foreach']((_0x34aa68,_0x1f2d02)=>{const _0x370f86=A(_0x13253f,_0x34aa68);ar(_0x4ad170,y(_0x370f86))&&(_0x428fb6=Ti(_0x469e8e,_0x428fb6,_0x370f86,_0x1f2d02,_0x144c88,_0x167b77,_0x79618d));}),_0x2465cf['foreach']((_0x1a9890,_0xc92142)=>{const _0xb6f8bc=A(_0x13253f,_0x1a9890);ar(_0x4ad170,y(_0xb6f8bc))||(_0x428fb6=Ti(_0x469e8e,_0x428fb6,_0xb6f8bc,_0xc92142,_0x144c88,_0x167b77,_0x79618d));}),_0x428fb6;}function cr(_0x4c6a28,_0x4b1396,_0xc9db90){return _0xc9db90['foreach']((_0x2ef8bf,_0x3a8263)=>{_0x4b1396=_0x4b1396['updateChild'](_0x2ef8bf,_0x3a8263);}),_0x4b1396;}function Si(_0x1717ef,_0x3008a2,_0x23cfa8,_0x528d8d,_0x3f4ac9,_0xa7aaa9,_0x4bf82d,_0x432e92){if(_0x3008a2['serverCache']['getNode']()['isEmpty']()&&!_0x3008a2['serverCache']['isFullyInitialized']())return _0x3008a2;let _0x41ecac=_0x3008a2,_0x1ca210;v(_0x23cfa8)?_0x1ca210=_0x528d8d:_0x1ca210=new S(null)['setTree'](_0x23cfa8,_0x528d8d);const _0x2d0a1a=_0x3008a2['serverCache']['getNode']();return _0x1ca210['children']['inorderTraversal']((_0x2c56ec,_0x489b98)=>{if(_0x2d0a1a['hasChild'](_0x2c56ec)){const _0x2c31ab=_0x3008a2['serverCache']['getNode']()['getImmediateChild'](_0x2c56ec),_0x26ea4c=cr(_0x1717ef,_0x2c31ab,_0x489b98);_0x41ecac=vn(_0x1717ef,_0x41ecac,new C(_0x2c56ec),_0x26ea4c,_0x3f4ac9,_0xa7aaa9,_0x4bf82d,_0x432e92);}}),_0x1ca210['children']['inorderTraversal']((_0x18e795,_0x4c97ce)=>{const _0x301e89=!_0x3008a2['serverCache']['isCompleteForChild'](_0x18e795)&&_0x4c97ce['value']===null;if(!_0x2d0a1a['hasChild'](_0x18e795)&&!_0x301e89){const _0x5d6e97=_0x3008a2['serverCache']['getNode']()['getImmediateChild'](_0x18e795),_0x1e0337=cr(_0x1717ef,_0x5d6e97,_0x4c97ce);_0x41ecac=vn(_0x1717ef,_0x41ecac,new C(_0x18e795),_0x1e0337,_0x3f4ac9,_0xa7aaa9,_0x4bf82d,_0x432e92);}}),_0x41ecac;}function Ru(_0x552000,_0x804f89,_0x1b8e8c,_0x284f7c,_0x46d2e7,_0x4136c6,_0x166196){if(yn(_0x46d2e7,_0x1b8e8c)!=null)return _0x804f89;const _0x907b0=_0x804f89['serverCache']['isFiltered'](),_0x54987a=_0x804f89['serverCache'];if(_0x284f7c['value']!=null){if(v(_0x1b8e8c)&&_0x54987a['isFullyInitialized']()||_0x54987a['isCompleteForPath'](_0x1b8e8c))return vn(_0x552000,_0x804f89,_0x1b8e8c,_0x54987a['getNode']()['getChild'](_0x1b8e8c),_0x46d2e7,_0x4136c6,_0x907b0,_0x166196);if(v(_0x1b8e8c)){let _0x328432=new S(null);return _0x54987a['getNode']()['forEachChild'](ye,(_0x422f3a,_0x1850b9)=>{_0x328432=_0x328432['set'](new C(_0x422f3a),_0x1850b9);}),Si(_0x552000,_0x804f89,_0x1b8e8c,_0x328432,_0x46d2e7,_0x4136c6,_0x907b0,_0x166196);}else return _0x804f89;}else{let _0x17bbae=new S(null);return _0x284f7c['foreach']((_0x2b18ac,_0x481159)=>{const _0x36a8aa=A(_0x1b8e8c,_0x2b18ac);_0x54987a['isCompleteForPath'](_0x36a8aa)&&(_0x17bbae=_0x17bbae['set'](_0x2b18ac,_0x54987a['getNode']()['getChild'](_0x36a8aa)));}),Si(_0x552000,_0x804f89,_0x1b8e8c,_0x17bbae,_0x46d2e7,_0x4136c6,_0x907b0,_0x166196);}}function Au(_0x1a8d54,_0x23d930,_0x579224,_0x344c89,_0x4dc1fd){const _0x53e7f2=_0x23d930['serverCache'],_0x39488c=Lo(_0x23d930,_0x53e7f2['getNode'](),_0x53e7f2['isFullyInitialized']()||v(_0x579224),_0x53e7f2['isFiltered']());return Ho(_0x1a8d54,_0x39488c,_0x579224,_0x344c89,Vo,_0x4dc1fd);}function ku(_0x29a750,_0x2d89f5,_0x3c8d7b,_0x1dc460,_0x5ab103,_0x2558fa){let _0x3933e0;if(yn(_0x1dc460,_0x3c8d7b)!=null)return _0x2d89f5;{const _0x3b3e58=new ns(_0x1dc460,_0x2d89f5,_0x5ab103),_0x179086=_0x2d89f5['eventCache']['getNode']();let _0x215630;if(v(_0x3c8d7b)||y(_0x3c8d7b)==='.priority'){let _0x1ba37a;if(_0x2d89f5['serverCache']['isFullyInitialized']())_0x1ba37a=mn(_0x1dc460,Ue(_0x2d89f5));else{const _0x52e248=_0x2d89f5['serverCache']['getNode']();f(_0x52e248 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1ba37a=es(_0x1dc460,_0x52e248);}_0x1ba37a=_0x1ba37a,_0x215630=_0x29a750['filter']['updateFullNode'](_0x179086,_0x1ba37a,_0x2558fa);}else{const _0x3cc6ca=y(_0x3c8d7b);let _0x352aad=ts(_0x1dc460,_0x3cc6ca,_0x2d89f5['serverCache']);_0x352aad==null&&_0x2d89f5['serverCache']['isCompleteForChild'](_0x3cc6ca)&&(_0x352aad=_0x179086['getImmediateChild'](_0x3cc6ca)),_0x352aad!=null?_0x215630=_0x29a750['filter']['updateChild'](_0x179086,_0x3cc6ca,_0x352aad,b(_0x3c8d7b),_0x3b3e58,_0x2558fa):_0x2d89f5['eventCache']['getNode']()['hasChild'](_0x3cc6ca)?_0x215630=_0x29a750['filter']['updateChild'](_0x179086,_0x3cc6ca,g['EMPTY_NODE'],b(_0x3c8d7b),_0x3b3e58,_0x2558fa):_0x215630=_0x179086,_0x215630['isEmpty']()&&_0x2d89f5['serverCache']['isFullyInitialized']()&&(_0x3933e0=mn(_0x1dc460,Ue(_0x2d89f5)),_0x3933e0['isLeafNode']()&&(_0x215630=_0x29a750['filter']['updateFullNode'](_0x215630,_0x3933e0,_0x2558fa)));}return _0x3933e0=_0x2d89f5['serverCache']['isFullyInitialized']()||yn(_0x1dc460,w())!=null,wt(_0x2d89f5,_0x215630,_0x3933e0,_0x29a750['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x9255b6,_0x4f1308){this['query_']=_0x9255b6,this['eventRegistrations_']=[];const _0x21b657=this['query_']['_queryParams'],_0x3eab05=new Yi(_0x21b657['getIndex']()),_0x55dbac=qh(_0x21b657);this['processor_']=wu(_0x55dbac);const _0x3f9409=_0x4f1308['serverCache'],_0x1cf9d2=_0x4f1308['eventCache'],_0x2aceb0=_0x3eab05['updateFullNode'](g['EMPTY_NODE'],_0x3f9409['getNode'](),null),_0x210412=_0x55dbac['updateFullNode'](g['EMPTY_NODE'],_0x1cf9d2['getNode'](),null),_0xdc7d6e=new Ce(_0x2aceb0,_0x3f9409['isFullyInitialized'](),_0x3eab05['filtersNodes']()),_0x5c6b1f=new Ce(_0x210412,_0x1cf9d2['isFullyInitialized'](),_0x55dbac['filtersNodes']());this['viewCache_']=Dn(_0x5c6b1f,_0xdc7d6e),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x1e5715){return _0x1e5715['viewCache_']['serverCache']['getNode']();}function Ou(_0x2897ce){return gn(_0x2897ce['viewCache_']);}function Du(_0x5e6c11,_0x529374){const _0x12f64e=Ue(_0x5e6c11['viewCache_']);return _0x12f64e&&(_0x5e6c11['query']['_queryParams']['loadsAllData']()||!v(_0x529374)&&!_0x12f64e['getImmediateChild'](y(_0x529374))['isEmpty']())?_0x12f64e['getChild'](_0x529374):null;}function lr(_0x4d432e){return _0x4d432e['eventRegistrations_']['length']===0x0;}function Mu(_0x5449e6,_0x346683){_0x5449e6['eventRegistrations_']['push'](_0x346683);}function hr(_0x524bbf,_0x7df11f,_0xcf842){const _0x5058e3=[];if(_0xcf842){f(_0x7df11f==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0xf82575=_0x524bbf['query']['_path'];_0x524bbf['eventRegistrations_']['forEach'](_0x289a39=>{const _0x2efd43=_0x289a39['createCancelEvent'](_0xcf842,_0xf82575);_0x2efd43&&_0x5058e3['push'](_0x2efd43);});}if(_0x7df11f){let _0x3ea9a6=[];for(let _0x44689e=0x0;_0x44689e<_0x524bbf['eventRegistrations_']['length'];++_0x44689e){const _0x28c582=_0x524bbf['eventRegistrations_'][_0x44689e];if(!_0x28c582['matches'](_0x7df11f))_0x3ea9a6['push'](_0x28c582);else{if(_0x7df11f['hasAnyCallback']()){_0x3ea9a6=_0x3ea9a6['concat'](_0x524bbf['eventRegistrations_']['slice'](_0x44689e+0x1));break;}}}_0x524bbf['eventRegistrations_']=_0x3ea9a6;}else _0x524bbf['eventRegistrations_']=[];return _0x5058e3;}function ur(_0x2ee937,_0x423f78,_0x2656df,_0x298e4d){_0x423f78['type']===q['MERGE']&&_0x423f78['source']['queryId']!==null&&(f(Ue(_0x2ee937['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x2ee937['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x4aa281=_0x2ee937['viewCache_'],_0x4471e4=Tu(_0x2ee937['processor_'],_0x4aa281,_0x423f78,_0x2656df,_0x298e4d);return Cu(_0x2ee937['processor_'],_0x4471e4['viewCache']),f(_0x4471e4['viewCache']['serverCache']['isFullyInitialized']()||!_0x4aa281['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2ee937['viewCache_']=_0x4471e4['viewCache'],$o(_0x2ee937,_0x4471e4['changes'],_0x4471e4['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x4d1847,_0x487a59){const _0x52574e=_0x4d1847['viewCache_']['eventCache'],_0x545582=[];return _0x52574e['getNode']()['isLeafNode']()||_0x52574e['getNode']()['forEachChild'](R,(_0x4d330c,_0x577a00)=>{_0x545582['push'](tt(_0x4d330c,_0x577a00));}),_0x52574e['isFullyInitialized']()&&_0x545582['push'](Oo(_0x52574e['getNode']())),$o(_0x4d1847,_0x545582,_0x52574e['getNode'](),_0x487a59);}function $o(_0x4d1e00,_0xf0e981,_0x456fc7,_0x2dc29d){const _0x47ed0d=_0x2dc29d?[_0x2dc29d]:_0x4d1e00['eventRegistrations_'];return nu(_0x4d1e00['eventGenerator_'],_0xf0e981,_0x456fc7,_0x47ed0d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x3ab9fb){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x3ab9fb;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x1d955f){return _0x1d955f['views']['size']===0x0;}function is(_0x4b2bab,_0x1c05c3,_0x4c8496,_0x1b7d3f){const _0x262ebc=_0x1c05c3['source']['queryId'];if(_0x262ebc!==null){const _0xc22b16=_0x4b2bab['views']['get'](_0x262ebc);return f(_0xc22b16!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0xc22b16,_0x1c05c3,_0x4c8496,_0x1b7d3f);}else{let _0xa2088=[];for(const _0x315375 of _0x4b2bab['views']['values']())_0xa2088=_0xa2088['concat'](ur(_0x315375,_0x1c05c3,_0x4c8496,_0x1b7d3f));return _0xa2088;}}function qo(_0x47f33b,_0x446bc7,_0x15062b,_0x302f92,_0x5254e2){const _0x26cac9=_0x446bc7['_queryIdentifier'],_0x5c8fed=_0x47f33b['views']['get'](_0x26cac9);if(!_0x5c8fed){let _0x274575=mn(_0x15062b,_0x5254e2?_0x302f92:null),_0x54ab54=!0x1;_0x274575?_0x54ab54=!0x0:_0x302f92 instanceof g?(_0x274575=es(_0x15062b,_0x302f92),_0x54ab54=!0x1):(_0x274575=g['EMPTY_NODE'],_0x54ab54=!0x1);const _0xbb253b=Dn(new Ce(_0x274575,_0x54ab54,!0x1),new Ce(_0x302f92,_0x5254e2,!0x1));return new Nu(_0x446bc7,_0xbb253b);}return _0x5c8fed;}function Wu(_0x4a3d3e,_0x456976,_0x4aca50,_0x5681ed,_0x130e80,_0x5659f7){const _0x1c95ff=qo(_0x4a3d3e,_0x456976,_0x5681ed,_0x130e80,_0x5659f7);return _0x4a3d3e['views']['has'](_0x456976['_queryIdentifier'])||_0x4a3d3e['views']['set'](_0x456976['_queryIdentifier'],_0x1c95ff),Mu(_0x1c95ff,_0x4aca50),Lu(_0x1c95ff,_0x4aca50);}function Bu(_0x2096c1,_0x400e9c,_0x150a2e,_0x5d98c3){const _0x4b111c=_0x400e9c['_queryIdentifier'],_0x147625=[];let _0x487d40=[];const _0x309d9a=Te(_0x2096c1);if(_0x4b111c==='default'){for(const [_0x418675,_0x1f66a4]of _0x2096c1['views']['entries']())_0x487d40=_0x487d40['concat'](hr(_0x1f66a4,_0x150a2e,_0x5d98c3)),lr(_0x1f66a4)&&(_0x2096c1['views']['delete'](_0x418675),_0x1f66a4['query']['_queryParams']['loadsAllData']()||_0x147625['push'](_0x1f66a4['query']));}else{const _0x41df87=_0x2096c1['views']['get'](_0x4b111c);_0x41df87&&(_0x487d40=_0x487d40['concat'](hr(_0x41df87,_0x150a2e,_0x5d98c3)),lr(_0x41df87)&&(_0x2096c1['views']['delete'](_0x4b111c),_0x41df87['query']['_queryParams']['loadsAllData']()||_0x147625['push'](_0x41df87['query'])));}return _0x309d9a&&!Te(_0x2096c1)&&_0x147625['push'](new(Fu())(_0x400e9c['_repo'],_0x400e9c['_path'])),{'removed':_0x147625,'events':_0x487d40};}function zo(_0x138e1a){const _0x45d8a5=[];for(const _0x28e45a of _0x138e1a['views']['values']())_0x28e45a['query']['_queryParams']['loadsAllData']()||_0x45d8a5['push'](_0x28e45a);return _0x45d8a5;}function Ee(_0xc0c7d0,_0x219533){let _0x17afe4=null;for(const _0x575a21 of _0xc0c7d0['views']['values']())_0x17afe4=_0x17afe4||Du(_0x575a21,_0x219533);return _0x17afe4;}function jo(_0x598747,_0x3cbac0){if(_0x3cbac0['_queryParams']['loadsAllData']())return Ln(_0x598747);{const _0x3ecb92=_0x3cbac0['_queryIdentifier'];return _0x598747['views']['get'](_0x3ecb92);}}function Ko(_0x40095f,_0x3de088){return jo(_0x40095f,_0x3de088)!=null;}function Te(_0x63c84b){return Ln(_0x63c84b)!=null;}function Ln(_0x4ef61d){for(const _0x1343f of _0x4ef61d['views']['values']())if(_0x1343f['query']['_queryParams']['loadsAllData']())return _0x1343f;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x19fc43){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x19fc43;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x597fc5){this['listenProvider_']=_0x597fc5,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x4b52d2,_0x5381a5,_0x350201,_0x1934e6,_0x264a29){return ou(_0x4b52d2['pendingWriteTree_'],_0x5381a5,_0x350201,_0x1934e6,_0x264a29),_0x264a29?ht(_0x4b52d2,new Fe(Ji(),_0x5381a5,_0x350201)):[];}function Gu(_0x43069c,_0x7eefcf,_0x3117f9,_0x10f92f){au(_0x43069c['pendingWriteTree_'],_0x7eefcf,_0x3117f9,_0x10f92f);const _0x1c2369=S['fromObject'](_0x3117f9);return ht(_0x43069c,new nt(Ji(),_0x7eefcf,_0x1c2369));}function pe(_0x56b78d,_0x35e9fd,_0x22576b=!0x1){const _0x1b69a1=cu(_0x56b78d['pendingWriteTree_'],_0x35e9fd);if(lu(_0x56b78d['pendingWriteTree_'],_0x35e9fd)){let _0xbcb3ed=new S(null);return _0x1b69a1['snap']!=null?_0xbcb3ed=_0xbcb3ed['set'](w(),!0x0):x(_0x1b69a1['children'],_0x3f333d=>{_0xbcb3ed=_0xbcb3ed['set'](new C(_0x3f333d),!0x0);}),ht(_0x56b78d,new _n(_0x1b69a1['path'],_0xbcb3ed,_0x22576b));}else return[];}function $t(_0x184c9c,_0x1f2908,_0x22a001){return ht(_0x184c9c,new Fe(Xi(),_0x1f2908,_0x22a001));}function qu(_0x24b745,_0x19d5d0,_0x36a482){const _0x11a65a=S['fromObject'](_0x36a482);return ht(_0x24b745,new nt(Xi(),_0x19d5d0,_0x11a65a));}function zu(_0x5487ae,_0x4ca796){return ht(_0x5487ae,new Dt(Xi(),_0x4ca796));}function ju(_0x52f593,_0x3da2d2,_0xdbd84f){const _0x58ae47=rs(_0x52f593,_0xdbd84f);if(_0x58ae47){const _0x47c9e1=os(_0x58ae47),_0x5476f9=_0x47c9e1['path'],_0xda6daa=_0x47c9e1['queryId'],_0x54f986=F(_0x5476f9,_0x3da2d2),_0x2bb9d6=new Dt(Zi(_0xda6daa),_0x54f986);return as(_0x52f593,_0x5476f9,_0x2bb9d6);}else return[];}function wn(_0x559bf8,_0x176758,_0x27b48f,_0x5334a7,_0x19d341=!0x1){const _0x5d688f=_0x176758['_path'],_0x23583f=_0x559bf8['syncPointTree_']['get'](_0x5d688f);let _0x173c74=[];if(_0x23583f&&(_0x176758['_queryIdentifier']==='default'||Ko(_0x23583f,_0x176758))){const _0x309d04=Bu(_0x23583f,_0x176758,_0x27b48f,_0x5334a7);Uu(_0x23583f)&&(_0x559bf8['syncPointTree_']=_0x559bf8['syncPointTree_']['remove'](_0x5d688f));const _0xe2eeaa=_0x309d04['removed'];if(_0x173c74=_0x309d04['events'],!_0x19d341){const _0x4d94ae=_0xe2eeaa['findIndex'](_0x29d821=>_0x29d821['_queryParams']['loadsAllData']())!==-0x1,_0x3bd294=_0x559bf8['syncPointTree_']['findOnPath'](_0x5d688f,(_0x195f09,_0x2eec2a)=>Te(_0x2eec2a));if(_0x4d94ae&&!_0x3bd294){const _0x51844f=_0x559bf8['syncPointTree_']['subtree'](_0x5d688f);if(!_0x51844f['isEmpty']()){const _0x5c5ff5=Qu(_0x51844f);for(let _0x324ba4=0x0;_0x324ba4<_0x5c5ff5['length'];++_0x324ba4){const _0x9cd2d1=_0x5c5ff5[_0x324ba4],_0x586519=_0x9cd2d1['query'],_0x5cad25=Xo(_0x559bf8,_0x9cd2d1);_0x559bf8['listenProvider_']['startListening'](Tt(_0x586519),Mt(_0x559bf8,_0x586519),_0x5cad25['hashFn'],_0x5cad25['onComplete']);}}}!_0x3bd294&&_0xe2eeaa['length']>0x0&&!_0x5334a7&&(_0x4d94ae?_0x559bf8['listenProvider_']['stopListening'](Tt(_0x176758),null):_0xe2eeaa['forEach'](_0x591814=>{const _0x1b2365=_0x559bf8['queryToTagMap']['get'](Fn(_0x591814));_0x559bf8['listenProvider_']['stopListening'](Tt(_0x591814),_0x1b2365);}));}Ju(_0x559bf8,_0xe2eeaa);}return _0x173c74;}function Yo(_0x2b31f3,_0x3f5e61,_0x57619d,_0x113ffd){const _0x621dff=rs(_0x2b31f3,_0x113ffd);if(_0x621dff!=null){const _0x5241d2=os(_0x621dff),_0x366246=_0x5241d2['path'],_0x9fb412=_0x5241d2['queryId'],_0x2a93c3=F(_0x366246,_0x3f5e61),_0x590ef8=new Fe(Zi(_0x9fb412),_0x2a93c3,_0x57619d);return as(_0x2b31f3,_0x366246,_0x590ef8);}else return[];}function Ku(_0x29d386,_0x509179,_0x9fbd67,_0x13dc26){const _0x49c95e=rs(_0x29d386,_0x13dc26);if(_0x49c95e){const _0xbe2c70=os(_0x49c95e),_0x2efa7d=_0xbe2c70['path'],_0x283a86=_0xbe2c70['queryId'],_0x1d71c3=F(_0x2efa7d,_0x509179),_0x412e78=S['fromObject'](_0x9fbd67),_0x6ece76=new nt(Zi(_0x283a86),_0x1d71c3,_0x412e78);return as(_0x29d386,_0x2efa7d,_0x6ece76);}else return[];}function bi(_0x243f62,_0x7ed7a6,_0x46935d,_0x169997=!0x1){const _0x508721=_0x7ed7a6['_path'];let _0x5d05b4=null,_0x51cd60=!0x1;_0x243f62['syncPointTree_']['foreachOnPath'](_0x508721,(_0xcb3181,_0x57bb33)=>{const _0x20d7a5=F(_0xcb3181,_0x508721);_0x5d05b4=_0x5d05b4||Ee(_0x57bb33,_0x20d7a5),_0x51cd60=_0x51cd60||Te(_0x57bb33);});let _0x265dff=_0x243f62['syncPointTree_']['get'](_0x508721);_0x265dff?(_0x51cd60=_0x51cd60||Te(_0x265dff),_0x5d05b4=_0x5d05b4||Ee(_0x265dff,w())):(_0x265dff=new Go(),_0x243f62['syncPointTree_']=_0x243f62['syncPointTree_']['set'](_0x508721,_0x265dff));let _0x23e84b;_0x5d05b4!=null?_0x23e84b=!0x0:(_0x23e84b=!0x1,_0x5d05b4=g['EMPTY_NODE'],_0x243f62['syncPointTree_']['subtree'](_0x508721)['foreachChild']((_0x22b110,_0x1aaac9)=>{const _0x1cd977=Ee(_0x1aaac9,w());_0x1cd977&&(_0x5d05b4=_0x5d05b4['updateImmediateChild'](_0x22b110,_0x1cd977));}));const _0x44a856=Ko(_0x265dff,_0x7ed7a6);if(!_0x44a856&&!_0x7ed7a6['_queryParams']['loadsAllData']()){const _0x3e49cc=Fn(_0x7ed7a6);f(!_0x243f62['queryToTagMap']['has'](_0x3e49cc),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x39652a=Xu();_0x243f62['queryToTagMap']['set'](_0x3e49cc,_0x39652a),_0x243f62['tagToQueryMap']['set'](_0x39652a,_0x3e49cc);}const _0x3ca2ce=Mn(_0x243f62['pendingWriteTree_'],_0x508721);let _0x5291b6=Wu(_0x265dff,_0x7ed7a6,_0x46935d,_0x3ca2ce,_0x5d05b4,_0x23e84b);if(!_0x44a856&&!_0x51cd60&&!_0x169997){const _0x45dad9=jo(_0x265dff,_0x7ed7a6);_0x5291b6=_0x5291b6['concat'](Zu(_0x243f62,_0x7ed7a6,_0x45dad9));}return _0x5291b6;}function xn(_0x30eb7f,_0x169757,_0xacbcac){const _0x5738c4=_0x30eb7f['pendingWriteTree_'],_0x5e1561=_0x30eb7f['syncPointTree_']['findOnPath'](_0x169757,(_0x2ad3ca,_0x40e76c)=>{const _0x353831=F(_0x2ad3ca,_0x169757),_0x4b6f46=Ee(_0x40e76c,_0x353831);if(_0x4b6f46)return _0x4b6f46;});return Uo(_0x5738c4,_0x169757,_0x5e1561,_0xacbcac,!0x0);}function Yu(_0x2edeff,_0x19a4d4){const _0x338165=_0x19a4d4['_path'];let _0x1006eb=null;_0x2edeff['syncPointTree_']['foreachOnPath'](_0x338165,(_0x44050a,_0x2f39e1)=>{const _0x33b96b=F(_0x44050a,_0x338165);_0x1006eb=_0x1006eb||Ee(_0x2f39e1,_0x33b96b);});let _0x5dc747=_0x2edeff['syncPointTree_']['get'](_0x338165);_0x5dc747?_0x1006eb=_0x1006eb||Ee(_0x5dc747,w()):(_0x5dc747=new Go(),_0x2edeff['syncPointTree_']=_0x2edeff['syncPointTree_']['set'](_0x338165,_0x5dc747));const _0x35ed6d=_0x1006eb!=null,_0x455884=_0x35ed6d?new Ce(_0x1006eb,!0x0,!0x1):null,_0x4c0d8c=Mn(_0x2edeff['pendingWriteTree_'],_0x19a4d4['_path']),_0x4a3e63=qo(_0x5dc747,_0x19a4d4,_0x4c0d8c,_0x35ed6d?_0x455884['getNode']():g['EMPTY_NODE'],_0x35ed6d);return Ou(_0x4a3e63);}function ht(_0x11be1d,_0x1388bd){return Qo(_0x1388bd,_0x11be1d['syncPointTree_'],null,Mn(_0x11be1d['pendingWriteTree_'],w()));}function Qo(_0x2cdf5e,_0x5e2412,_0x46688d,_0x299e6c){if(v(_0x2cdf5e['path']))return Jo(_0x2cdf5e,_0x5e2412,_0x46688d,_0x299e6c);{const _0xec3e50=_0x5e2412['get'](w());_0x46688d==null&&_0xec3e50!=null&&(_0x46688d=Ee(_0xec3e50,w()));let _0x2e312b=[];const _0x135710=y(_0x2cdf5e['path']),_0x4b5be5=_0x2cdf5e['operationForChild'](_0x135710),_0x33dd0f=_0x5e2412['children']['get'](_0x135710);if(_0x33dd0f&&_0x4b5be5){const _0x1a2795=_0x46688d?_0x46688d['getImmediateChild'](_0x135710):null,_0x545ad1=Wo(_0x299e6c,_0x135710);_0x2e312b=_0x2e312b['concat'](Qo(_0x4b5be5,_0x33dd0f,_0x1a2795,_0x545ad1));}return _0xec3e50&&(_0x2e312b=_0x2e312b['concat'](is(_0xec3e50,_0x2cdf5e,_0x299e6c,_0x46688d))),_0x2e312b;}}function Jo(_0x41593f,_0x41c9b5,_0x2d1640,_0x4b4f19){const _0x49d3c2=_0x41c9b5['get'](w());_0x2d1640==null&&_0x49d3c2!=null&&(_0x2d1640=Ee(_0x49d3c2,w()));let _0x1c958c=[];return _0x41c9b5['children']['inorderTraversal']((_0x2e5f1f,_0x59c4b0)=>{const _0x51e1e5=_0x2d1640?_0x2d1640['getImmediateChild'](_0x2e5f1f):null,_0x3466ab=Wo(_0x4b4f19,_0x2e5f1f),_0x31b148=_0x41593f['operationForChild'](_0x2e5f1f);_0x31b148&&(_0x1c958c=_0x1c958c['concat'](Jo(_0x31b148,_0x59c4b0,_0x51e1e5,_0x3466ab)));}),_0x49d3c2&&(_0x1c958c=_0x1c958c['concat'](is(_0x49d3c2,_0x41593f,_0x4b4f19,_0x2d1640))),_0x1c958c;}function Xo(_0x5dd93e,_0x5008d7){const _0x49658c=_0x5008d7['query'],_0x22e2fe=Mt(_0x5dd93e,_0x49658c);return{'hashFn':()=>(Pu(_0x5008d7)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3ed3df=>{if(_0x3ed3df==='ok')return _0x22e2fe?ju(_0x5dd93e,_0x49658c['_path'],_0x22e2fe):zu(_0x5dd93e,_0x49658c['_path']);{const _0x4479cf=ql(_0x3ed3df,_0x49658c);return wn(_0x5dd93e,_0x49658c,null,_0x4479cf);}}};}function Mt(_0x2080a9,_0x197ba3){const _0x318e15=Fn(_0x197ba3);return _0x2080a9['queryToTagMap']['get'](_0x318e15);}function Fn(_0x3b52dd){return _0x3b52dd['_path']['toString']()+'$'+_0x3b52dd['_queryIdentifier'];}function rs(_0x26c778,_0x37cfa9){return _0x26c778['tagToQueryMap']['get'](_0x37cfa9);}function os(_0x560c73){const _0x3a6258=_0x560c73['indexOf']('$');return f(_0x3a6258!==-0x1&&_0x3a6258<_0x560c73['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x560c73['substr'](_0x3a6258+0x1),'path':new C(_0x560c73['substr'](0x0,_0x3a6258))};}function as(_0x363289,_0x399705,_0x2c2a38){const _0x13c35d=_0x363289['syncPointTree_']['get'](_0x399705);f(_0x13c35d,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x16234d=Mn(_0x363289['pendingWriteTree_'],_0x399705);return is(_0x13c35d,_0x2c2a38,_0x16234d,null);}function Qu(_0x2dbeca){return _0x2dbeca['fold']((_0xd8082e,_0xed895f,_0x134c37)=>{if(_0xed895f&&Te(_0xed895f))return[Ln(_0xed895f)];{let _0x441246=[];return _0xed895f&&(_0x441246=zo(_0xed895f)),x(_0x134c37,(_0x1dbb65,_0x17d717)=>{_0x441246=_0x441246['concat'](_0x17d717);}),_0x441246;}});}function Tt(_0x1cdaa9){return _0x1cdaa9['_queryParams']['loadsAllData']()&&!_0x1cdaa9['_queryParams']['isDefault']()?new(Hu())(_0x1cdaa9['_repo'],_0x1cdaa9['_path']):_0x1cdaa9;}function Ju(_0x587c56,_0x4122cc){for(let _0x24d7f2=0x0;_0x24d7f2<_0x4122cc['length'];++_0x24d7f2){const _0xcffb08=_0x4122cc[_0x24d7f2];if(!_0xcffb08['_queryParams']['loadsAllData']()){const _0x3a6546=Fn(_0xcffb08),_0x440386=_0x587c56['queryToTagMap']['get'](_0x3a6546);_0x587c56['queryToTagMap']['delete'](_0x3a6546),_0x587c56['tagToQueryMap']['delete'](_0x440386);}}}function Xu(){return $u++;}function Zu(_0x312a60,_0x553479,_0x402b89){const _0x232de7=_0x553479['_path'],_0x3059f4=Mt(_0x312a60,_0x553479),_0x108fa2=Xo(_0x312a60,_0x402b89),_0xcaa546=_0x312a60['listenProvider_']['startListening'](Tt(_0x553479),_0x3059f4,_0x108fa2['hashFn'],_0x108fa2['onComplete']),_0xe248fc=_0x312a60['syncPointTree_']['subtree'](_0x232de7);if(_0x3059f4)f(!Te(_0xe248fc['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x488b90=_0xe248fc['fold']((_0x449e04,_0x1d8b42,_0x3db1a3)=>{if(!v(_0x449e04)&&_0x1d8b42&&Te(_0x1d8b42))return[Ln(_0x1d8b42)['query']];{let _0xf5ce05=[];return _0x1d8b42&&(_0xf5ce05=_0xf5ce05['concat'](zo(_0x1d8b42)['map'](_0xbb1a70=>_0xbb1a70['query']))),x(_0x3db1a3,(_0x29e58f,_0x37275c)=>{_0xf5ce05=_0xf5ce05['concat'](_0x37275c);}),_0xf5ce05;}});for(let _0x52b5e3=0x0;_0x52b5e3<_0x488b90['length'];++_0x52b5e3){const _0x44fc9b=_0x488b90[_0x52b5e3];_0x312a60['listenProvider_']['stopListening'](Tt(_0x44fc9b),Mt(_0x312a60,_0x44fc9b));}}return _0xcaa546;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x346eb6){this['node_']=_0x346eb6;}['getImmediateChild'](_0x235595){const _0x21e78f=this['node_']['getImmediateChild'](_0x235595);return new cs(_0x21e78f);}['node'](){return this['node_'];}}class ls{constructor(_0x4ef604,_0x2e1598){this['syncTree_']=_0x4ef604,this['path_']=_0x2e1598;}['getImmediateChild'](_0x517e0d){const _0x50e9f9=A(this['path_'],_0x517e0d);return new ls(this['syncTree_'],_0x50e9f9);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x32abad){return _0x32abad=_0x32abad||{},_0x32abad['timestamp']=_0x32abad['timestamp']||new Date()['getTime'](),_0x32abad;},fr=function(_0x4fe335,_0x5688ad,_0x55cbe3){if(!_0x4fe335||typeof _0x4fe335!='object')return _0x4fe335;if(f('.sv'in _0x4fe335,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4fe335['.sv']=='string')return td(_0x4fe335['.sv'],_0x5688ad,_0x55cbe3);if(typeof _0x4fe335['.sv']=='object')return nd(_0x4fe335['.sv'],_0x5688ad);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4fe335,null,0x2));},td=function(_0x157033,_0x16bda2,_0x1eb50f){switch(_0x157033){case'timestamp':return _0x1eb50f['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x157033);}},nd=function(_0x43b54f,_0xffc55,_0x3a0b5d){_0x43b54f['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x43b54f,null,0x2));const _0x4e0806=_0x43b54f['increment'];typeof _0x4e0806!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4e0806);const _0x5dcfbe=_0xffc55['node']();if(f(_0x5dcfbe!==null&&typeof _0x5dcfbe<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5dcfbe['isLeafNode']())return _0x4e0806;const _0x51cd17=_0x5dcfbe['getValue']();return typeof _0x51cd17!='number'?_0x4e0806:_0x51cd17+_0x4e0806;},Zo=function(_0x3d1119,_0x31d6ce,_0x2e4a59,_0x2d63f5){return us(_0x31d6ce,new ls(_0x2e4a59,_0x3d1119),_0x2d63f5);},hs=function(_0xc28907,_0x4cfd50,_0x1c46f4){return us(_0xc28907,new cs(_0x4cfd50),_0x1c46f4);};function us(_0x339a75,_0x29bb8c,_0x3f4f12){const _0x8d370d=_0x339a75['getPriority']()['val'](),_0x1e34e6=fr(_0x8d370d,_0x29bb8c['getImmediateChild']('.priority'),_0x3f4f12);let _0x1b2129;if(_0x339a75['isLeafNode']()){const _0x2c4557=_0x339a75,_0xf95869=fr(_0x2c4557['getValue'](),_0x29bb8c,_0x3f4f12);return _0xf95869!==_0x2c4557['getValue']()||_0x1e34e6!==_0x2c4557['getPriority']()['val']()?new D(_0xf95869,N(_0x1e34e6)):_0x339a75;}else{const _0x5d6a0c=_0x339a75;return _0x1b2129=_0x5d6a0c,_0x1e34e6!==_0x5d6a0c['getPriority']()['val']()&&(_0x1b2129=_0x1b2129['updatePriority'](new D(_0x1e34e6))),_0x5d6a0c['forEachChild'](R,(_0x5cf9d5,_0x3f3f42)=>{const _0x315c2b=us(_0x3f3f42,_0x29bb8c['getImmediateChild'](_0x5cf9d5),_0x3f4f12);_0x315c2b!==_0x3f3f42&&(_0x1b2129=_0x1b2129['updateImmediateChild'](_0x5cf9d5,_0x315c2b));}),_0x1b2129;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x5c8e37='',_0x531fee=null,_0x330ca6={'children':{},'childCount':0x0}){this['name']=_0x5c8e37,this['parent']=_0x531fee,this['node']=_0x330ca6;}}function Un(_0x55aa97,_0x344210){let _0x452146=_0x344210 instanceof C?_0x344210:new C(_0x344210),_0x18e941=_0x55aa97,_0x2acdd4=y(_0x452146);for(;_0x2acdd4!==null;){const _0x20448c=Oe(_0x18e941['node']['children'],_0x2acdd4)||{'children':{},'childCount':0x0};_0x18e941=new ds(_0x2acdd4,_0x18e941,_0x20448c),_0x452146=b(_0x452146),_0x2acdd4=y(_0x452146);}return _0x18e941;}function Ge(_0x437bc7){return _0x437bc7['node']['value'];}function fs(_0x7b591a,_0x5531e6){_0x7b591a['node']['value']=_0x5531e6,Ri(_0x7b591a);}function ea(_0x19a765){return _0x19a765['node']['childCount']>0x0;}function id(_0x390a8d){return Ge(_0x390a8d)===void 0x0&&!ea(_0x390a8d);}function Wn(_0xf81b54,_0x54c088){x(_0xf81b54['node']['children'],(_0x53ad54,_0x1c7731)=>{_0x54c088(new ds(_0x53ad54,_0xf81b54,_0x1c7731));});}function ta(_0x39aab5,_0x244ebe,_0x5e94df,_0x465a8c){_0x5e94df&&_0x244ebe(_0x39aab5),Wn(_0x39aab5,_0x56b9f1=>{ta(_0x56b9f1,_0x244ebe,!0x0);});}function sd(_0x458aa2,_0x3ca9a6,_0x2df546){let _0xdbcdc4=_0x458aa2['parent'];for(;_0xdbcdc4!==null;){if(_0x3ca9a6(_0xdbcdc4))return!0x0;_0xdbcdc4=_0xdbcdc4['parent'];}return!0x1;}function Gt(_0x77970d){return new C(_0x77970d['parent']===null?_0x77970d['name']:Gt(_0x77970d['parent'])+'/'+_0x77970d['name']);}function Ri(_0x3b2a47){_0x3b2a47['parent']!==null&&rd(_0x3b2a47['parent'],_0x3b2a47['name'],_0x3b2a47);}function rd(_0x415172,_0x392259,_0x120e76){const _0x297921=id(_0x120e76),_0x4179a2=Y(_0x415172['node']['children'],_0x392259);_0x297921&&_0x4179a2?(delete _0x415172['node']['children'][_0x392259],_0x415172['node']['childCount']--,Ri(_0x415172)):!_0x297921&&!_0x4179a2&&(_0x415172['node']['children'][_0x392259]=_0x120e76['node'],_0x415172['node']['childCount']++,Ri(_0x415172));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x5d41c4){return typeof _0x5d41c4=='string'&&_0x5d41c4['length']!==0x0&&!od['test'](_0x5d41c4);},na=function(_0x3fbb96){return typeof _0x3fbb96=='string'&&_0x3fbb96['length']!==0x0&&!ad['test'](_0x3fbb96);},cd=function(_0x196fbe){return _0x196fbe&&(_0x196fbe=_0x196fbe['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x196fbe);},Cn=function(_0x5c7ef7){return _0x5c7ef7===null||typeof _0x5c7ef7=='string'||typeof _0x5c7ef7=='number'&&!Wi(_0x5c7ef7)||_0x5c7ef7&&typeof _0x5c7ef7=='object'&&Y(_0x5c7ef7,'.sv');},qt=function(_0x16e51c,_0x1efcce,_0x5d53d3,_0x27b4e1){_0x27b4e1&&_0x1efcce===void 0x0||zt(Nn(_0x16e51c,'value'),_0x1efcce,_0x5d53d3);},zt=function(_0x1d6aa8,_0x963f6f,_0x4506d9){const _0x26c539=_0x4506d9 instanceof C?new Sh(_0x4506d9,_0x1d6aa8):_0x4506d9;if(_0x963f6f===void 0x0)throw new Error(_0x1d6aa8+'contains\x20undefined\x20'+Ne(_0x26c539));if(typeof _0x963f6f=='function')throw new Error(_0x1d6aa8+'contains\x20a\x20function\x20'+Ne(_0x26c539)+'\x20with\x20contents\x20=\x20'+_0x963f6f['toString']());if(Wi(_0x963f6f))throw new Error(_0x1d6aa8+'contains\x20'+_0x963f6f['toString']()+'\x20'+Ne(_0x26c539));if(typeof _0x963f6f=='string'&&_0x963f6f['length']>oi/0x3&&Pn(_0x963f6f)>oi)throw new Error(_0x1d6aa8+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x26c539)+'\x20(\x27'+_0x963f6f['substring'](0x0,0x32)+'...\x27)');if(_0x963f6f&&typeof _0x963f6f=='object'){let _0x3a6d43=!0x1,_0x121d53=!0x1;if(x(_0x963f6f,(_0xf878d4,_0x4c0867)=>{if(_0xf878d4==='.value')_0x3a6d43=!0x0;else{if(_0xf878d4!=='.priority'&&_0xf878d4!=='.sv'&&(_0x121d53=!0x0,!ps(_0xf878d4)))throw new Error(_0x1d6aa8+'\x20contains\x20an\x20invalid\x20key\x20('+_0xf878d4+')\x20'+Ne(_0x26c539)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x26c539,_0xf878d4),zt(_0x1d6aa8,_0x4c0867,_0x26c539),Rh(_0x26c539);}),_0x3a6d43&&_0x121d53)throw new Error(_0x1d6aa8+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x26c539)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x1be065,_0x37b57e){let _0xc27c53,_0x191f8c;for(_0xc27c53=0x0;_0xc27c53<_0x37b57e['length'];_0xc27c53++){_0x191f8c=_0x37b57e[_0xc27c53];const _0x389701=kt(_0x191f8c);for(let _0x2db763=0x0;_0x2db763<_0x389701['length'];_0x2db763++)if(!(_0x389701[_0x2db763]==='.priority'&&_0x2db763===_0x389701['length']-0x1)){if(!ps(_0x389701[_0x2db763]))throw new Error(_0x1be065+'contains\x20an\x20invalid\x20key\x20('+_0x389701[_0x2db763]+')\x20in\x20path\x20'+_0x191f8c['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x37b57e['sort'](Th);let _0x48b918=null;for(_0xc27c53=0x0;_0xc27c53<_0x37b57e['length'];_0xc27c53++){if(_0x191f8c=_0x37b57e[_0xc27c53],_0x48b918!==null&&$(_0x48b918,_0x191f8c))throw new Error(_0x1be065+'contains\x20a\x20path\x20'+_0x48b918['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x191f8c['toString']());_0x48b918=_0x191f8c;}},hd=function(_0x410020,_0xc83166,_0x3c5d3d,_0x5ed0ec){const _0x276d4e=Nn(_0x410020,'values');if(!(_0xc83166&&typeof _0xc83166=='object')||Array['isArray'](_0xc83166))throw new Error(_0x276d4e+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2fa492=[];x(_0xc83166,(_0x2b5d63,_0x22eca9)=>{const _0x880f2a=new C(_0x2b5d63);if(zt(_0x276d4e,_0x22eca9,A(_0x3c5d3d,_0x880f2a)),Gi(_0x880f2a)==='.priority'&&!Cn(_0x22eca9))throw new Error(_0x276d4e+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x880f2a['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2fa492['push'](_0x880f2a);}),ld(_0x276d4e,_0x2fa492);},_s=function(_0x194628,_0x5a9bc4,_0x1c6af9,_0x191e8c){if(!na(_0x1c6af9))throw new Error(Nn(_0x194628,_0x5a9bc4)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1c6af9+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x23f1b4,_0x2ccb93,_0x2c467e,_0x31def5){_0x2c467e&&(_0x2c467e=_0x2c467e['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x23f1b4,_0x2ccb93,_0x2c467e);},gs=function(_0x4d680f,_0x25c182){if(y(_0x25c182)==='.info')throw new Error(_0x4d680f+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x4f014f,_0x289cc1){const _0x224d03=_0x289cc1['path']['toString']();if(typeof _0x289cc1['repoInfo']['host']!='string'||_0x289cc1['repoInfo']['host']['length']===0x0||!ps(_0x289cc1['repoInfo']['namespace'])&&_0x289cc1['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x224d03['length']!==0x0&&!cd(_0x224d03))throw new Error(Nn(_0x4f014f,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0xa13b05,_0x5ded9f){let _0x2ff2e0=null;for(let _0x34c956=0x0;_0x34c956<_0x5ded9f['length'];_0x34c956++){const _0x5bf61d=_0x5ded9f[_0x34c956],_0x13769b=_0x5bf61d['getPath']();_0x2ff2e0!==null&&!qi(_0x13769b,_0x2ff2e0['path'])&&(_0xa13b05['eventLists_']['push'](_0x2ff2e0),_0x2ff2e0=null),_0x2ff2e0===null&&(_0x2ff2e0={'events':[],'path':_0x13769b}),_0x2ff2e0['events']['push'](_0x5bf61d);}_0x2ff2e0&&_0xa13b05['eventLists_']['push'](_0x2ff2e0);}function ia(_0x36f172,_0x34a975,_0x3aefd6){Bn(_0x36f172,_0x3aefd6),sa(_0x36f172,_0x425bd9=>qi(_0x425bd9,_0x34a975));}function V(_0x2188c1,_0x577ceb,_0x39af15){Bn(_0x2188c1,_0x39af15),sa(_0x2188c1,_0x429e81=>$(_0x429e81,_0x577ceb)||$(_0x577ceb,_0x429e81));}function sa(_0x5c08ea,_0x41350f){_0x5c08ea['recursionDepth_']++;let _0x4bb678=!0x0;for(let _0x3ef00a=0x0;_0x3ef00a<_0x5c08ea['eventLists_']['length'];_0x3ef00a++){const _0x4bed89=_0x5c08ea['eventLists_'][_0x3ef00a];if(_0x4bed89){const _0x152fbf=_0x4bed89['path'];_0x41350f(_0x152fbf)?(pd(_0x5c08ea['eventLists_'][_0x3ef00a]),_0x5c08ea['eventLists_'][_0x3ef00a]=null):_0x4bb678=!0x1;}}_0x4bb678&&(_0x5c08ea['eventLists_']=[]),_0x5c08ea['recursionDepth_']--;}function pd(_0x306d2a){for(let _0x51c5ae=0x0;_0x51c5ae<_0x306d2a['events']['length'];_0x51c5ae++){const _0x7aabe4=_0x306d2a['events'][_0x51c5ae];if(_0x7aabe4!==null){_0x306d2a['events'][_0x51c5ae]=null;const _0xc33258=_0x7aabe4['getEventRunner']();Et&&L('event:\x20'+_0x7aabe4['toString']()),lt(_0xc33258);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x1af651,_0x195f52,_0x11a46a,_0x524fae){this['repoInfo_']=_0x1af651,this['forceRestClient_']=_0x195f52,this['authTokenProvider_']=_0x11a46a,this['appCheckProvider_']=_0x524fae,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0xbf29f0,_0x33d239,_0x3c010d){if(_0xbf29f0['stats_']=Hi(_0xbf29f0['repoInfo_']),_0xbf29f0['forceRestClient_']||Yl())_0xbf29f0['server_']=new fn(_0xbf29f0['repoInfo_'],(_0x33207e,_0x25ec85,_0xeb0a4a,_0x33b8df)=>{pr(_0xbf29f0,_0x33207e,_0x25ec85,_0xeb0a4a,_0x33b8df);},_0xbf29f0['authTokenProvider_'],_0xbf29f0['appCheckProvider_']),setTimeout(()=>_r(_0xbf29f0,!0x0),0x0);else{if(typeof _0x3c010d<'u'&&_0x3c010d!==null){if(typeof _0x3c010d!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x3c010d);}catch(_0x54ad5f){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x54ad5f);}}_0xbf29f0['persistentConnection_']=new ie(_0xbf29f0['repoInfo_'],_0x33d239,(_0x17718f,_0x5d6c70,_0x1a2ae8,_0x558249)=>{pr(_0xbf29f0,_0x17718f,_0x5d6c70,_0x1a2ae8,_0x558249);},_0x21ec80=>{_r(_0xbf29f0,_0x21ec80);},_0x44e6ae=>{yd(_0xbf29f0,_0x44e6ae);},_0xbf29f0['authTokenProvider_'],_0xbf29f0['appCheckProvider_'],_0x3c010d),_0xbf29f0['server_']=_0xbf29f0['persistentConnection_'];}_0xbf29f0['authTokenProvider_']['addTokenChangeListener'](_0x1ac2e6=>{_0xbf29f0['server_']['refreshAuthToken'](_0x1ac2e6);}),_0xbf29f0['appCheckProvider_']['addTokenChangeListener'](_0x21eb9c=>{_0xbf29f0['server_']['refreshAppCheckToken'](_0x21eb9c['token']);}),_0xbf29f0['statsReporter_']=eh(_0xbf29f0['repoInfo_'],()=>new eu(_0xbf29f0['stats_'],_0xbf29f0['server_'])),_0xbf29f0['infoData_']=new Yh(),_0xbf29f0['infoSyncTree_']=new dr({'startListening':(_0x3bf751,_0x472e7d,_0x30ae80,_0x3ab9e3)=>{let _0x5bc556=[];const _0xd2823f=_0xbf29f0['infoData_']['getNode'](_0x3bf751['_path']);return _0xd2823f['isEmpty']()||(_0x5bc556=$t(_0xbf29f0['infoSyncTree_'],_0x3bf751['_path'],_0xd2823f),setTimeout(()=>{_0x3ab9e3('ok');},0x0)),_0x5bc556;},'stopListening':()=>{}}),ms(_0xbf29f0,'connected',!0x1),_0xbf29f0['serverSyncTree_']=new dr({'startListening':(_0x39b0d4,_0x20c16d,_0x3b413e,_0x16a33f)=>(_0xbf29f0['server_']['listen'](_0x39b0d4,_0x3b413e,_0x20c16d,(_0x48c1fb,_0x44bd63)=>{const _0x547fde=_0x16a33f(_0x48c1fb,_0x44bd63);V(_0xbf29f0['eventQueue_'],_0x39b0d4['_path'],_0x547fde);}),[]),'stopListening':(_0x25528f,_0x214f2c)=>{_0xbf29f0['server_']['unlisten'](_0x25528f,_0x214f2c);}});}function oa(_0x68064b){const _0x24b2c7=_0x68064b['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x24b2c7;}function jt(_0x97e448){return ed({'timestamp':oa(_0x97e448)});}function pr(_0x2a4e31,_0x90265a,_0x29c3ca,_0x7c9cb2,_0x379da9){_0x2a4e31['dataUpdateCount']++;const _0x3d8a83=new C(_0x90265a);_0x29c3ca=_0x2a4e31['interceptServerDataCallback_']?_0x2a4e31['interceptServerDataCallback_'](_0x90265a,_0x29c3ca):_0x29c3ca;let _0x4a6527=[];if(_0x379da9){if(_0x7c9cb2){const _0x5d9caf=ln(_0x29c3ca,_0x282b5c=>N(_0x282b5c));_0x4a6527=Ku(_0x2a4e31['serverSyncTree_'],_0x3d8a83,_0x5d9caf,_0x379da9);}else{const _0x3eac17=N(_0x29c3ca);_0x4a6527=Yo(_0x2a4e31['serverSyncTree_'],_0x3d8a83,_0x3eac17,_0x379da9);}}else{if(_0x7c9cb2){const _0x991724=ln(_0x29c3ca,_0x443404=>N(_0x443404));_0x4a6527=qu(_0x2a4e31['serverSyncTree_'],_0x3d8a83,_0x991724);}else{const _0x2da0ed=N(_0x29c3ca);_0x4a6527=$t(_0x2a4e31['serverSyncTree_'],_0x3d8a83,_0x2da0ed);}}let _0x5e11e8=_0x3d8a83;_0x4a6527['length']>0x0&&(_0x5e11e8=st(_0x2a4e31,_0x3d8a83)),V(_0x2a4e31['eventQueue_'],_0x5e11e8,_0x4a6527);}function _r(_0x76f511,_0x2b2eb0){ms(_0x76f511,'connected',_0x2b2eb0),_0x2b2eb0===!0x1&&wd(_0x76f511);}function yd(_0x325117,_0x25ce26){x(_0x25ce26,(_0x33c4dc,_0x33a725)=>{ms(_0x325117,_0x33c4dc,_0x33a725);});}function ms(_0x4200d3,_0x210ec4,_0x1d47a7){const _0xb966aa=new C('/.info/'+_0x210ec4),_0x1d4d89=N(_0x1d47a7);_0x4200d3['infoData_']['updateSnapshot'](_0xb966aa,_0x1d4d89);const _0x456ec7=$t(_0x4200d3['infoSyncTree_'],_0xb966aa,_0x1d4d89);V(_0x4200d3['eventQueue_'],_0xb966aa,_0x456ec7);}function Vn(_0x567cf6){return _0x567cf6['nextWriteId_']++;}function vd(_0x3222cb,_0x58ea3c,_0x3e8c1e){const _0x2fcd19=Yu(_0x3222cb['serverSyncTree_'],_0x58ea3c);return _0x2fcd19!=null?Promise['resolve'](_0x2fcd19):_0x3222cb['server_']['get'](_0x58ea3c)['then'](_0x4d9231=>{const _0x120851=N(_0x4d9231)['withIndex'](_0x58ea3c['_queryParams']['getIndex']());bi(_0x3222cb['serverSyncTree_'],_0x58ea3c,_0x3e8c1e,!0x0);let _0x5ab854;if(_0x58ea3c['_queryParams']['loadsAllData']())_0x5ab854=$t(_0x3222cb['serverSyncTree_'],_0x58ea3c['_path'],_0x120851);else{const _0x4bbb28=Mt(_0x3222cb['serverSyncTree_'],_0x58ea3c);_0x5ab854=Yo(_0x3222cb['serverSyncTree_'],_0x58ea3c['_path'],_0x120851,_0x4bbb28);}return V(_0x3222cb['eventQueue_'],_0x58ea3c['_path'],_0x5ab854),wn(_0x3222cb['serverSyncTree_'],_0x58ea3c,_0x3e8c1e,null,!0x0),_0x120851;},_0x12a27a=>(ut(_0x3222cb,'get\x20for\x20query\x20'+O(_0x58ea3c)+'\x20failed:\x20'+_0x12a27a),Promise['reject'](new Error(_0x12a27a))));}function Ed(_0x5147f7,_0x4848e4,_0x574753,_0x2abbca,_0x29248a){ut(_0x5147f7,'set',{'path':_0x4848e4['toString'](),'value':_0x574753,'priority':_0x2abbca});const _0xb3e6be=jt(_0x5147f7),_0x504699=N(_0x574753,_0x2abbca),_0x604cb4=xn(_0x5147f7['serverSyncTree_'],_0x4848e4),_0x5400b7=hs(_0x504699,_0x604cb4,_0xb3e6be),_0x58dfb9=Vn(_0x5147f7),_0x2a25b8=ss(_0x5147f7['serverSyncTree_'],_0x4848e4,_0x5400b7,_0x58dfb9,!0x0);Bn(_0x5147f7['eventQueue_'],_0x2a25b8),_0x5147f7['server_']['put'](_0x4848e4['toString'](),_0x504699['val'](!0x0),(_0xf4b9fd,_0x435ba0)=>{const _0x1b06e6=_0xf4b9fd==='ok';_0x1b06e6||U('set\x20at\x20'+_0x4848e4+'\x20failed:\x20'+_0xf4b9fd);const _0x3f9706=pe(_0x5147f7['serverSyncTree_'],_0x58dfb9,!_0x1b06e6);V(_0x5147f7['eventQueue_'],_0x4848e4,_0x3f9706),Ai(_0x5147f7,_0x29248a,_0xf4b9fd,_0x435ba0);});const _0x5708b7=vs(_0x5147f7,_0x4848e4);st(_0x5147f7,_0x5708b7),V(_0x5147f7['eventQueue_'],_0x5708b7,[]);}function Id(_0x56eff6,_0x3ab61b,_0x195169,_0x1e36d4){ut(_0x56eff6,'update',{'path':_0x3ab61b['toString'](),'value':_0x195169});let _0x5ae4f8=!0x0;const _0x534901=jt(_0x56eff6),_0x4bcc05={};if(x(_0x195169,(_0x312a11,_0x25d8fe)=>{_0x5ae4f8=!0x1,_0x4bcc05[_0x312a11]=Zo(A(_0x3ab61b,_0x312a11),N(_0x25d8fe),_0x56eff6['serverSyncTree_'],_0x534901);}),_0x5ae4f8)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x56eff6,_0x1e36d4,'ok',void 0x0);else{const _0x1213ef=Vn(_0x56eff6),_0x2abfed=Gu(_0x56eff6['serverSyncTree_'],_0x3ab61b,_0x4bcc05,_0x1213ef);Bn(_0x56eff6['eventQueue_'],_0x2abfed),_0x56eff6['server_']['merge'](_0x3ab61b['toString'](),_0x195169,(_0x49e002,_0x257b7f)=>{const _0x4ed957=_0x49e002==='ok';_0x4ed957||U('update\x20at\x20'+_0x3ab61b+'\x20failed:\x20'+_0x49e002);const _0x57333f=pe(_0x56eff6['serverSyncTree_'],_0x1213ef,!_0x4ed957),_0x11a6b4=_0x57333f['length']>0x0?st(_0x56eff6,_0x3ab61b):_0x3ab61b;V(_0x56eff6['eventQueue_'],_0x11a6b4,_0x57333f),Ai(_0x56eff6,_0x1e36d4,_0x49e002,_0x257b7f);}),x(_0x195169,_0x198b50=>{const _0x52b2c0=vs(_0x56eff6,A(_0x3ab61b,_0x198b50));st(_0x56eff6,_0x52b2c0);}),V(_0x56eff6['eventQueue_'],_0x3ab61b,[]);}}function wd(_0x429d0e){ut(_0x429d0e,'onDisconnectEvents');const _0x376a41=jt(_0x429d0e),_0xb69085=pn();Ei(_0x429d0e['onDisconnect_'],w(),(_0x38dbda,_0x4f8aec)=>{const _0x5f49fd=Zo(_0x38dbda,_0x4f8aec,_0x429d0e['serverSyncTree_'],_0x376a41);Mo(_0xb69085,_0x38dbda,_0x5f49fd);});let _0x2dac96=[];Ei(_0xb69085,w(),(_0x10c707,_0x45190e)=>{_0x2dac96=_0x2dac96['concat']($t(_0x429d0e['serverSyncTree_'],_0x10c707,_0x45190e));const _0x77be8c=vs(_0x429d0e,_0x10c707);st(_0x429d0e,_0x77be8c);}),_0x429d0e['onDisconnect_']=pn(),V(_0x429d0e['eventQueue_'],w(),_0x2dac96);}function Cd(_0x27100f,_0x8809d8,_0x9251d3){let _0x4cb2e9;y(_0x8809d8['_path'])==='.info'?_0x4cb2e9=bi(_0x27100f['infoSyncTree_'],_0x8809d8,_0x9251d3):_0x4cb2e9=bi(_0x27100f['serverSyncTree_'],_0x8809d8,_0x9251d3),ia(_0x27100f['eventQueue_'],_0x8809d8['_path'],_0x4cb2e9);}function Td(_0x41ece7,_0x179ecf,_0x3e1a18){let _0x5a9a18;y(_0x179ecf['_path'])==='.info'?_0x5a9a18=wn(_0x41ece7['infoSyncTree_'],_0x179ecf,_0x3e1a18):_0x5a9a18=wn(_0x41ece7['serverSyncTree_'],_0x179ecf,_0x3e1a18),ia(_0x41ece7['eventQueue_'],_0x179ecf['_path'],_0x5a9a18);}function aa(_0x26ad03){_0x26ad03['persistentConnection_']&&_0x26ad03['persistentConnection_']['interrupt'](ra);}function Sd(_0xe6564){_0xe6564['persistentConnection_']&&_0xe6564['persistentConnection_']['resume'](ra);}function ut(_0x5903f4,..._0x18ea6a){let _0x27be8f='';_0x5903f4['persistentConnection_']&&(_0x27be8f=_0x5903f4['persistentConnection_']['id']+':'),L(_0x27be8f,..._0x18ea6a);}function Ai(_0x30ac77,_0xdf99c3,_0x4f4979,_0xa169da){_0xdf99c3&&lt(()=>{if(_0x4f4979==='ok')_0xdf99c3(null);else{const _0x3abf9b=(_0x4f4979||'error')['toUpperCase']();let _0x5ceecd=_0x3abf9b;_0xa169da&&(_0x5ceecd+=':\x20'+_0xa169da);const _0x388a4c=new Error(_0x5ceecd);_0x388a4c['code']=_0x3abf9b,_0xdf99c3(_0x388a4c);}});}function bd(_0x5a9691,_0x5ea2ee,_0xcb8855,_0x41c651,_0x1f4281,_0x3e5044){ut(_0x5a9691,'transaction\x20on\x20'+_0x5ea2ee);const _0x5a1149={'path':_0x5ea2ee,'update':_0xcb8855,'onComplete':_0x41c651,'status':null,'order':to(),'applyLocally':_0x3e5044,'retryCount':0x0,'unwatcher':_0x1f4281,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2bec0d=ys(_0x5a9691,_0x5ea2ee,void 0x0);_0x5a1149['currentInputSnapshot']=_0x2bec0d;const _0x30aee0=_0x5a1149['update'](_0x2bec0d['val']());if(_0x30aee0===void 0x0)_0x5a1149['unwatcher'](),_0x5a1149['currentOutputSnapshotRaw']=null,_0x5a1149['currentOutputSnapshotResolved']=null,_0x5a1149['onComplete']&&_0x5a1149['onComplete'](null,!0x1,_0x5a1149['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x30aee0,_0x5a1149['path']),_0x5a1149['status']=0x0;const _0x23adee=Un(_0x5a9691['transactionQueueTree_'],_0x5ea2ee),_0x464fe7=Ge(_0x23adee)||[];_0x464fe7['push'](_0x5a1149),fs(_0x23adee,_0x464fe7);let _0x1d766f;typeof _0x30aee0=='object'&&_0x30aee0!==null&&Y(_0x30aee0,'.priority')?(_0x1d766f=Oe(_0x30aee0,'.priority'),f(Cn(_0x1d766f),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1d766f=(xn(_0x5a9691['serverSyncTree_'],_0x5ea2ee)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xc0a128=jt(_0x5a9691),_0x14c19c=N(_0x30aee0,_0x1d766f),_0x18cefa=hs(_0x14c19c,_0x2bec0d,_0xc0a128);_0x5a1149['currentOutputSnapshotRaw']=_0x14c19c,_0x5a1149['currentOutputSnapshotResolved']=_0x18cefa,_0x5a1149['currentWriteId']=Vn(_0x5a9691);const _0x51b54e=ss(_0x5a9691['serverSyncTree_'],_0x5ea2ee,_0x18cefa,_0x5a1149['currentWriteId'],_0x5a1149['applyLocally']);V(_0x5a9691['eventQueue_'],_0x5ea2ee,_0x51b54e),Hn(_0x5a9691,_0x5a9691['transactionQueueTree_']);}}function ys(_0x28c91b,_0x30c95d,_0x299c13){return xn(_0x28c91b['serverSyncTree_'],_0x30c95d,_0x299c13)||g['EMPTY_NODE'];}function Hn(_0x3a8b21,_0x2b3374=_0x3a8b21['transactionQueueTree_']){if(_0x2b3374||$n(_0x3a8b21,_0x2b3374),Ge(_0x2b3374)){const _0x93ac9b=la(_0x3a8b21,_0x2b3374);f(_0x93ac9b['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x93ac9b['every'](_0x218a58=>_0x218a58['status']===0x0)&&Rd(_0x3a8b21,Gt(_0x2b3374),_0x93ac9b);}else ea(_0x2b3374)&&Wn(_0x2b3374,_0xddb3c9=>{Hn(_0x3a8b21,_0xddb3c9);});}function Rd(_0x46fa29,_0x52a120,_0x56ef9b){const _0x1431ee=_0x56ef9b['map'](_0x338080=>_0x338080['currentWriteId']),_0xfb696f=ys(_0x46fa29,_0x52a120,_0x1431ee);let _0xc16f26=_0xfb696f;const _0x365710=_0xfb696f['hash']();for(let _0x26748e=0x0;_0x26748e<_0x56ef9b['length'];_0x26748e++){const _0x4b74e8=_0x56ef9b[_0x26748e];f(_0x4b74e8['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4b74e8['status']=0x1,_0x4b74e8['retryCount']++;const _0x3c73ae=F(_0x52a120,_0x4b74e8['path']);_0xc16f26=_0xc16f26['updateChild'](_0x3c73ae,_0x4b74e8['currentOutputSnapshotRaw']);}const _0x218246=_0xc16f26['val'](!0x0),_0x5a9905=_0x52a120;_0x46fa29['server_']['put'](_0x5a9905['toString'](),_0x218246,_0xabf869=>{ut(_0x46fa29,'transaction\x20put\x20response',{'path':_0x5a9905['toString'](),'status':_0xabf869});let _0x5556e0=[];if(_0xabf869==='ok'){const _0x577301=[];for(let _0x28ed8c=0x0;_0x28ed8c<_0x56ef9b['length'];_0x28ed8c++)_0x56ef9b[_0x28ed8c]['status']=0x2,_0x5556e0=_0x5556e0['concat'](pe(_0x46fa29['serverSyncTree_'],_0x56ef9b[_0x28ed8c]['currentWriteId'])),_0x56ef9b[_0x28ed8c]['onComplete']&&_0x577301['push'](()=>_0x56ef9b[_0x28ed8c]['onComplete'](null,!0x0,_0x56ef9b[_0x28ed8c]['currentOutputSnapshotResolved'])),_0x56ef9b[_0x28ed8c]['unwatcher']();$n(_0x46fa29,Un(_0x46fa29['transactionQueueTree_'],_0x52a120)),Hn(_0x46fa29,_0x46fa29['transactionQueueTree_']),V(_0x46fa29['eventQueue_'],_0x52a120,_0x5556e0);for(let _0x4698e4=0x0;_0x4698e4<_0x577301['length'];_0x4698e4++)lt(_0x577301[_0x4698e4]);}else{if(_0xabf869==='datastale'){for(let _0x7982df=0x0;_0x7982df<_0x56ef9b['length'];_0x7982df++)_0x56ef9b[_0x7982df]['status']===0x3?_0x56ef9b[_0x7982df]['status']=0x4:_0x56ef9b[_0x7982df]['status']=0x0;}else{U('transaction\x20at\x20'+_0x5a9905['toString']()+'\x20failed:\x20'+_0xabf869);for(let _0x2f92f9=0x0;_0x2f92f9<_0x56ef9b['length'];_0x2f92f9++)_0x56ef9b[_0x2f92f9]['status']=0x4,_0x56ef9b[_0x2f92f9]['abortReason']=_0xabf869;}st(_0x46fa29,_0x52a120);}},_0x365710);}function st(_0x3b1e2c,_0x3f07c6){const _0x1bfb12=ca(_0x3b1e2c,_0x3f07c6),_0x3d6bf6=Gt(_0x1bfb12),_0x1863be=la(_0x3b1e2c,_0x1bfb12);return Ad(_0x3b1e2c,_0x1863be,_0x3d6bf6),_0x3d6bf6;}function Ad(_0x312bd9,_0x18ce2b,_0x47e2fe){if(_0x18ce2b['length']===0x0)return;const _0x315b14=[];let _0x466b18=[];const _0x3d737b=_0x18ce2b['filter'](_0x6bab70=>_0x6bab70['status']===0x0)['map'](_0x305afc=>_0x305afc['currentWriteId']);for(let _0x1cbc96=0x0;_0x1cbc96<_0x18ce2b['length'];_0x1cbc96++){const _0x17ed15=_0x18ce2b[_0x1cbc96],_0x42a2b7=F(_0x47e2fe,_0x17ed15['path']);let _0x19de5c=!0x1,_0x26d016;if(f(_0x42a2b7!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x17ed15['status']===0x4)_0x19de5c=!0x0,_0x26d016=_0x17ed15['abortReason'],_0x466b18=_0x466b18['concat'](pe(_0x312bd9['serverSyncTree_'],_0x17ed15['currentWriteId'],!0x0));else{if(_0x17ed15['status']===0x0){if(_0x17ed15['retryCount']>=_d)_0x19de5c=!0x0,_0x26d016='maxretry',_0x466b18=_0x466b18['concat'](pe(_0x312bd9['serverSyncTree_'],_0x17ed15['currentWriteId'],!0x0));else{const _0x149c3c=ys(_0x312bd9,_0x17ed15['path'],_0x3d737b);_0x17ed15['currentInputSnapshot']=_0x149c3c;const _0x2e96dc=_0x18ce2b[_0x1cbc96]['update'](_0x149c3c['val']());if(_0x2e96dc!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x2e96dc,_0x17ed15['path']);let _0x293bfd=N(_0x2e96dc);typeof _0x2e96dc=='object'&&_0x2e96dc!=null&&Y(_0x2e96dc,'.priority')||(_0x293bfd=_0x293bfd['updatePriority'](_0x149c3c['getPriority']()));const _0x4065ca=_0x17ed15['currentWriteId'],_0x4dced=jt(_0x312bd9),_0x5046ed=hs(_0x293bfd,_0x149c3c,_0x4dced);_0x17ed15['currentOutputSnapshotRaw']=_0x293bfd,_0x17ed15['currentOutputSnapshotResolved']=_0x5046ed,_0x17ed15['currentWriteId']=Vn(_0x312bd9),_0x3d737b['splice'](_0x3d737b['indexOf'](_0x4065ca),0x1),_0x466b18=_0x466b18['concat'](ss(_0x312bd9['serverSyncTree_'],_0x17ed15['path'],_0x5046ed,_0x17ed15['currentWriteId'],_0x17ed15['applyLocally'])),_0x466b18=_0x466b18['concat'](pe(_0x312bd9['serverSyncTree_'],_0x4065ca,!0x0));}else _0x19de5c=!0x0,_0x26d016='nodata',_0x466b18=_0x466b18['concat'](pe(_0x312bd9['serverSyncTree_'],_0x17ed15['currentWriteId'],!0x0));}}}V(_0x312bd9['eventQueue_'],_0x47e2fe,_0x466b18),_0x466b18=[],_0x19de5c&&(_0x18ce2b[_0x1cbc96]['status']=0x2,function(_0x377156){setTimeout(_0x377156,Math['floor'](0x0));}(_0x18ce2b[_0x1cbc96]['unwatcher']),_0x18ce2b[_0x1cbc96]['onComplete']&&(_0x26d016==='nodata'?_0x315b14['push'](()=>_0x18ce2b[_0x1cbc96]['onComplete'](null,!0x1,_0x18ce2b[_0x1cbc96]['currentInputSnapshot'])):_0x315b14['push'](()=>_0x18ce2b[_0x1cbc96]['onComplete'](new Error(_0x26d016),!0x1,null))));}$n(_0x312bd9,_0x312bd9['transactionQueueTree_']);for(let _0x454064=0x0;_0x454064<_0x315b14['length'];_0x454064++)lt(_0x315b14[_0x454064]);Hn(_0x312bd9,_0x312bd9['transactionQueueTree_']);}function ca(_0x294cf1,_0x37b4e5){let _0x450798,_0x4b99c3=_0x294cf1['transactionQueueTree_'];for(_0x450798=y(_0x37b4e5);_0x450798!==null&&Ge(_0x4b99c3)===void 0x0;)_0x4b99c3=Un(_0x4b99c3,_0x450798),_0x37b4e5=b(_0x37b4e5),_0x450798=y(_0x37b4e5);return _0x4b99c3;}function la(_0x94a34d,_0x2a890d){const _0x205cbe=[];return ha(_0x94a34d,_0x2a890d,_0x205cbe),_0x205cbe['sort']((_0x1cc2a0,_0x3139de)=>_0x1cc2a0['order']-_0x3139de['order']),_0x205cbe;}function ha(_0x5e70e1,_0x15048b,_0x40670e){const _0x3112c5=Ge(_0x15048b);if(_0x3112c5){for(let _0x372ebe=0x0;_0x372ebe<_0x3112c5['length'];_0x372ebe++)_0x40670e['push'](_0x3112c5[_0x372ebe]);}Wn(_0x15048b,_0x4c3963=>{ha(_0x5e70e1,_0x4c3963,_0x40670e);});}function $n(_0x59a90e,_0x472c77){const _0x33f412=Ge(_0x472c77);if(_0x33f412){let _0x3c0521=0x0;for(let _0x2b2354=0x0;_0x2b2354<_0x33f412['length'];_0x2b2354++)_0x33f412[_0x2b2354]['status']!==0x2&&(_0x33f412[_0x3c0521]=_0x33f412[_0x2b2354],_0x3c0521++);_0x33f412['length']=_0x3c0521,fs(_0x472c77,_0x33f412['length']>0x0?_0x33f412:void 0x0);}Wn(_0x472c77,_0x3d8552=>{$n(_0x59a90e,_0x3d8552);});}function vs(_0x388909,_0x1904fd){const _0x58cafa=Gt(ca(_0x388909,_0x1904fd)),_0x19e78d=Un(_0x388909['transactionQueueTree_'],_0x1904fd);return sd(_0x19e78d,_0x61a55d=>{ai(_0x388909,_0x61a55d);}),ai(_0x388909,_0x19e78d),ta(_0x19e78d,_0x157f1d=>{ai(_0x388909,_0x157f1d);}),_0x58cafa;}function ai(_0x24f38b,_0x6f1444){const _0x434ff8=Ge(_0x6f1444);if(_0x434ff8){const _0xe44d6b=[];let _0x39bfb9=[],_0x1c61d6=-0x1;for(let _0x333d07=0x0;_0x333d07<_0x434ff8['length'];_0x333d07++)_0x434ff8[_0x333d07]['status']===0x3||(_0x434ff8[_0x333d07]['status']===0x1?(f(_0x1c61d6===_0x333d07-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1c61d6=_0x333d07,_0x434ff8[_0x333d07]['status']=0x3,_0x434ff8[_0x333d07]['abortReason']='set'):(f(_0x434ff8[_0x333d07]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x434ff8[_0x333d07]['unwatcher'](),_0x39bfb9=_0x39bfb9['concat'](pe(_0x24f38b['serverSyncTree_'],_0x434ff8[_0x333d07]['currentWriteId'],!0x0)),_0x434ff8[_0x333d07]['onComplete']&&_0xe44d6b['push'](_0x434ff8[_0x333d07]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1c61d6===-0x1?fs(_0x6f1444,void 0x0):_0x434ff8['length']=_0x1c61d6+0x1,V(_0x24f38b['eventQueue_'],Gt(_0x6f1444),_0x39bfb9);for(let _0x209d49=0x0;_0x209d49<_0xe44d6b['length'];_0x209d49++)lt(_0xe44d6b[_0x209d49]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x116566){let _0x5723fc='';const _0x15ee33=_0x116566['split']('/');for(let _0x47aaa2=0x0;_0x47aaa2<_0x15ee33['length'];_0x47aaa2++)if(_0x15ee33[_0x47aaa2]['length']>0x0){let _0x171307=_0x15ee33[_0x47aaa2];try{_0x171307=decodeURIComponent(_0x171307['replace'](/\+/g,'\x20'));}catch{}_0x5723fc+='/'+_0x171307;}return _0x5723fc;}function Nd(_0x2e7fcb){const _0xb7caa5={};_0x2e7fcb['charAt'](0x0)==='?'&&(_0x2e7fcb=_0x2e7fcb['substring'](0x1));for(const _0x44d792 of _0x2e7fcb['split']('&')){if(_0x44d792['length']===0x0)continue;const _0x34a46f=_0x44d792['split']('=');_0x34a46f['length']===0x2?_0xb7caa5[decodeURIComponent(_0x34a46f[0x0])]=decodeURIComponent(_0x34a46f[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x44d792+'\x27\x20in\x20query\x20\x27'+_0x2e7fcb+'\x27');}return _0xb7caa5;}const gr=function(_0x1dbe96,_0xf0d573){const _0x283e02=Pd(_0x1dbe96),_0x3be2a6=_0x283e02['namespace'];_0x283e02['domain']==='firebase.com'&&oe(_0x283e02['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3be2a6||_0x3be2a6==='undefined')&&_0x283e02['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x283e02['secure']||Bl();const _0x4b30e3=_0x283e02['scheme']==='ws'||_0x283e02['scheme']==='wss';return{'repoInfo':new _o(_0x283e02['host'],_0x283e02['secure'],_0x3be2a6,_0x4b30e3,_0xf0d573,'',_0x3be2a6!==_0x283e02['subdomain']),'path':new C(_0x283e02['pathString'])};},Pd=function(_0x18c142){let _0x40e69e='',_0x38b879='',_0x22a78f='',_0x2492d2='',_0x10f6f6='',_0x16dcb3=!0x0,_0x1a6254='https',_0x134c20=0x1bb;if(typeof _0x18c142=='string'){let _0x79c6cf=_0x18c142['indexOf']('//');_0x79c6cf>=0x0&&(_0x1a6254=_0x18c142['substring'](0x0,_0x79c6cf-0x1),_0x18c142=_0x18c142['substring'](_0x79c6cf+0x2));let _0x1c5887=_0x18c142['indexOf']('/');_0x1c5887===-0x1&&(_0x1c5887=_0x18c142['length']);let _0x4168a6=_0x18c142['indexOf']('?');_0x4168a6===-0x1&&(_0x4168a6=_0x18c142['length']),_0x40e69e=_0x18c142['substring'](0x0,Math['min'](_0x1c5887,_0x4168a6)),_0x1c5887<_0x4168a6&&(_0x2492d2=kd(_0x18c142['substring'](_0x1c5887,_0x4168a6)));const _0x23f7b6=Nd(_0x18c142['substring'](Math['min'](_0x18c142['length'],_0x4168a6)));_0x79c6cf=_0x40e69e['indexOf'](':'),_0x79c6cf>=0x0?(_0x16dcb3=_0x1a6254==='https'||_0x1a6254==='wss',_0x134c20=parseInt(_0x40e69e['substring'](_0x79c6cf+0x1),0xa)):_0x79c6cf=_0x40e69e['length'];const _0x583c9b=_0x40e69e['slice'](0x0,_0x79c6cf);if(_0x583c9b['toLowerCase']()==='localhost')_0x38b879='localhost';else{if(_0x583c9b['split']('.')['length']<=0x2)_0x38b879=_0x583c9b;else{const _0x21f9a3=_0x40e69e['indexOf']('.');_0x22a78f=_0x40e69e['substring'](0x0,_0x21f9a3)['toLowerCase'](),_0x38b879=_0x40e69e['substring'](_0x21f9a3+0x1),_0x10f6f6=_0x22a78f;}}'ns'in _0x23f7b6&&(_0x10f6f6=_0x23f7b6['ns']);}return{'host':_0x40e69e,'port':_0x134c20,'domain':_0x38b879,'subdomain':_0x22a78f,'secure':_0x16dcb3,'scheme':_0x1a6254,'pathString':_0x2492d2,'namespace':_0x10f6f6};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x161280=0x0;const _0x12f539=[];return function(_0x3480be){const _0xb0949a=_0x3480be===_0x161280;_0x161280=_0x3480be;let _0x5419fa;const _0x1f3676=new Array(0x8);for(_0x5419fa=0x7;_0x5419fa>=0x0;_0x5419fa--)_0x1f3676[_0x5419fa]=mr['charAt'](_0x3480be%0x40),_0x3480be=Math['floor'](_0x3480be/0x40);f(_0x3480be===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x35feac=_0x1f3676['join']('');if(_0xb0949a){for(_0x5419fa=0xb;_0x5419fa>=0x0&&_0x12f539[_0x5419fa]===0x3f;_0x5419fa--)_0x12f539[_0x5419fa]=0x0;_0x12f539[_0x5419fa]++;}else{for(_0x5419fa=0x0;_0x5419fa<0xc;_0x5419fa++)_0x12f539[_0x5419fa]=Math['floor'](Math['random']()*0x40);}for(_0x5419fa=0x0;_0x5419fa<0xc;_0x5419fa++)_0x35feac+=mr['charAt'](_0x12f539[_0x5419fa]);return f(_0x35feac['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x35feac;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x8da808,_0x5af7dc,_0x1af27a,_0x58dbbd){this['eventType']=_0x8da808,this['eventRegistration']=_0x5af7dc,this['snapshot']=_0x1af27a,this['prevName']=_0x58dbbd;}['getPath'](){const _0x6495a5=this['snapshot']['ref'];return this['eventType']==='value'?_0x6495a5['_path']:_0x6495a5['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x3586d0,_0xbb8378,_0x15c9f1){this['eventRegistration']=_0x3586d0,this['error']=_0xbb8378,this['path']=_0x15c9f1;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x4b1b92,_0x2f2172){this['snapshotCallback']=_0x4b1b92,this['cancelCallback']=_0x2f2172;}['onValue'](_0x133e1f,_0x3dd39d){this['snapshotCallback']['call'](null,_0x133e1f,_0x3dd39d);}['onCancel'](_0x1dc039){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x1dc039);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x901c1e){return this['snapshotCallback']===_0x901c1e['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x901c1e['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x901c1e['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x48c471,_0x57f50a,_0x53286b,_0x27e044){this['_repo']=_0x48c471,this['_path']=_0x57f50a,this['_queryParams']=_0x53286b,this['_orderByCalled']=_0x27e044;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xe6d663=nr(this['_queryParams']),_0x26996a=Bi(_0xe6d663);return _0x26996a==='{}'?'default':_0x26996a;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x5112d9){if(_0x5112d9=k(_0x5112d9),!(_0x5112d9 instanceof be))return!0x1;const _0x1d01c6=this['_repo']===_0x5112d9['_repo'],_0x4ef618=qi(this['_path'],_0x5112d9['_path']),_0x2f00dc=this['_queryIdentifier']===_0x5112d9['_queryIdentifier'];return _0x1d01c6&&_0x4ef618&&_0x2f00dc;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x2455a5,_0x59bc30){if(_0x2455a5['_orderByCalled']===!0x0)throw new Error(_0x59bc30+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x1b280f){let _0x109782=null,_0xfaebae=null;if(_0x1b280f['hasStart']()&&(_0x109782=_0x1b280f['getIndexStartValue']()),_0x1b280f['hasEnd']()&&(_0xfaebae=_0x1b280f['getIndexEndValue']()),_0x1b280f['getIndex']()===ye){const _0xf62be6='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2d3390='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1b280f['hasStart']()){if(_0x1b280f['getIndexStartName']()!==xe)throw new Error(_0xf62be6);if(typeof _0x109782!='string')throw new Error(_0x2d3390);}if(_0x1b280f['hasEnd']()){if(_0x1b280f['getIndexEndName']()!==Ie)throw new Error(_0xf62be6);if(typeof _0xfaebae!='string')throw new Error(_0x2d3390);}}else{if(_0x1b280f['getIndex']()===R){if(_0x109782!=null&&!Cn(_0x109782)||_0xfaebae!=null&&!Cn(_0xfaebae))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1b280f['getIndex']()instanceof Ki||_0x1b280f['getIndex']()===Po,'unknown\x20index\x20type.'),_0x109782!=null&&typeof _0x109782=='object'||_0xfaebae!=null&&typeof _0xfaebae=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x3666d4){if(_0x3666d4['hasStart']()&&_0x3666d4['hasEnd']()&&_0x3666d4['hasLimit']()&&!_0x3666d4['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x6a8158,_0x1f8ebf){super(_0x6a8158,_0x1f8ebf,new Qi(),!0x1);}get['parent'](){const _0x20f4e7=To(this['_path']);return _0x20f4e7===null?null:new Z(this['_repo'],_0x20f4e7);}get['root'](){let _0x11dfe6=this;for(;_0x11dfe6['parent']!==null;)_0x11dfe6=_0x11dfe6['parent'];return _0x11dfe6;}}class rt{constructor(_0x39845c,_0x5cd963,_0x2ac3f2){this['_node']=_0x39845c,this['ref']=_0x5cd963,this['_index']=_0x2ac3f2;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4a214e){const _0x3a74c0=new C(_0x4a214e),_0x28940c=Lt(this['ref'],_0x4a214e);return new rt(this['_node']['getChild'](_0x3a74c0),_0x28940c,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x215c15){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x32ef21,_0x4f2972)=>_0x215c15(new rt(_0x4f2972,Lt(this['ref'],_0x32ef21),R)));}['hasChild'](_0x266b0c){const _0x1fce1a=new C(_0x266b0c);return!this['_node']['getChild'](_0x1fce1a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x18033c,_0xad7970){return _0x18033c=k(_0x18033c),_0x18033c['_checkNotDeleted']('ref'),_0xad7970!==void 0x0?Lt(_0x18033c['_root'],_0xad7970):_0x18033c['_root'];}function Lt(_0x25cd6c,_0x567164){return _0x25cd6c=k(_0x25cd6c),y(_0x25cd6c['_path'])===null?ud('child','path',_0x567164):_s('child','path',_0x567164),new Z(_0x25cd6c['_repo'],A(_0x25cd6c['_path'],_0x567164));}function d_(_0x4feb7a,_0x30268e){_0x4feb7a=k(_0x4feb7a),gs('push',_0x4feb7a['_path']),qt('push',_0x30268e,_0x4feb7a['_path'],!0x0);const _0x4dc0f8=oa(_0x4feb7a['_repo']),_0x3d5d93=Od(_0x4dc0f8),_0x20d71c=Lt(_0x4feb7a,_0x3d5d93),_0x59fbe3=Lt(_0x4feb7a,_0x3d5d93);let _0x44ca04;return _0x30268e!=null?_0x44ca04=Ld(_0x59fbe3,_0x30268e)['then'](()=>_0x59fbe3):_0x44ca04=Promise['resolve'](_0x59fbe3),_0x20d71c['then']=_0x44ca04['then']['bind'](_0x44ca04),_0x20d71c['catch']=_0x44ca04['then']['bind'](_0x44ca04,void 0x0),_0x20d71c;}function Ld(_0x37be0e,_0x11aa36){_0x37be0e=k(_0x37be0e),gs('set',_0x37be0e['_path']),qt('set',_0x11aa36,_0x37be0e['_path'],!0x1);const _0x25975b=new Ve();return Ed(_0x37be0e['_repo'],_0x37be0e['_path'],_0x11aa36,null,_0x25975b['wrapCallback'](()=>{})),_0x25975b['promise'];}function f_(_0x546504,_0x2b7cb2){hd('update',_0x2b7cb2,_0x546504['_path']);const _0x12628d=new Ve();return Id(_0x546504['_repo'],_0x546504['_path'],_0x2b7cb2,_0x12628d['wrapCallback'](()=>{})),_0x12628d['promise'];}function p_(_0x24d508){_0x24d508=k(_0x24d508);const _0x360790=new ua(()=>{}),_0x340759=new qn(_0x360790);return vd(_0x24d508['_repo'],_0x24d508,_0x340759)['then'](_0x3e988a=>new rt(_0x3e988a,new Z(_0x24d508['_repo'],_0x24d508['_path']),_0x24d508['_queryParams']['getIndex']()));}class qn{constructor(_0x1030e3){this['callbackContext']=_0x1030e3;}['respondsTo'](_0x2d3918){return _0x2d3918==='value';}['createEvent'](_0x52392d,_0x2fd41a){const _0x28221b=_0x2fd41a['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x52392d['snapshotNode'],new Z(_0x2fd41a['_repo'],_0x2fd41a['_path']),_0x28221b));}['getEventRunner'](_0x1b2910){return _0x1b2910['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1b2910['error']):()=>this['callbackContext']['onValue'](_0x1b2910['snapshot'],null);}['createCancelEvent'](_0x27aed2,_0x47fa4a){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x27aed2,_0x47fa4a):null;}['matches'](_0x46e5d6){return _0x46e5d6 instanceof qn?!_0x46e5d6['callbackContext']||!this['callbackContext']?!0x0:_0x46e5d6['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x153c77,_0x321cec,_0x1185bd,_0x510da3,_0x4f4dab){const _0x167520=new ua(_0x1185bd,void 0x0),_0x48c679=new qn(_0x167520);return Cd(_0x153c77['_repo'],_0x153c77,_0x48c679),()=>Td(_0x153c77['_repo'],_0x153c77,_0x48c679);}function Fd(_0x20428d,_0x30d194,_0x38e262,_0x30cd95){return xd(_0x20428d,'value',_0x30d194);}class dt{}class pa extends dt{constructor(_0x18b9b4,_0x3b5ad4){super(),this['_value']=_0x18b9b4,this['_key']=_0x3b5ad4,this['type']='endAt';}['_apply'](_0x110870){qt('endAt',this['_value'],_0x110870['_path'],!0x0);const _0xa8b064=Kh(_0x110870['_queryParams'],this['_value'],this['_key']);if(fa(_0xa8b064),Gn(_0xa8b064),_0x110870['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x110870['_repo'],_0x110870['_path'],_0xa8b064,_0x110870['_orderByCalled']);}}function __(_0x55e4cf,_0x258076){return new pa(_0x55e4cf,_0x258076);}class _a extends dt{constructor(_0x5ca618,_0x4dc238){super(),this['_value']=_0x5ca618,this['_key']=_0x4dc238,this['type']='startAt';}['_apply'](_0x4e0913){qt('startAt',this['_value'],_0x4e0913['_path'],!0x0);const _0x26e112=jh(_0x4e0913['_queryParams'],this['_value'],this['_key']);if(fa(_0x26e112),Gn(_0x26e112),_0x4e0913['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x4e0913['_repo'],_0x4e0913['_path'],_0x26e112,_0x4e0913['_orderByCalled']);}}function g_(_0x4bd6ce=null,_0x344cf5){return new _a(_0x4bd6ce,_0x344cf5);}class Ud extends dt{constructor(_0x3c1f32){super(),this['_limit']=_0x3c1f32,this['type']='limitToFirst';}['_apply'](_0x5e17ae){if(_0x5e17ae['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x5e17ae['_repo'],_0x5e17ae['_path'],zh(_0x5e17ae['_queryParams'],this['_limit']),_0x5e17ae['_orderByCalled']);}}function m_(_0x3cf13e){if(Math['floor'](_0x3cf13e)!==_0x3cf13e||_0x3cf13e<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x3cf13e);}class Wd extends dt{constructor(_0x5a9de8){super(),this['_path']=_0x5a9de8,this['type']='orderByChild';}['_apply'](_0x19fff1){da(_0x19fff1,'orderByChild');const _0x5834f7=new C(this['_path']);if(v(_0x5834f7))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x6e45c7=new Ki(_0x5834f7),_0xf1d810=Do(_0x19fff1['_queryParams'],_0x6e45c7);return Gn(_0xf1d810),new be(_0x19fff1['_repo'],_0x19fff1['_path'],_0xf1d810,!0x0);}}function y_(_0x397f44){if(_0x397f44==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x397f44==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x397f44==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x397f44),new Wd(_0x397f44);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x822781){da(_0x822781,'orderByKey');const _0x4daded=Do(_0x822781['_queryParams'],ye);return Gn(_0x4daded),new be(_0x822781['_repo'],_0x822781['_path'],_0x4daded,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x57ecd1,_0x251862){super(),this['_value']=_0x57ecd1,this['_key']=_0x251862,this['type']='equalTo';}['_apply'](_0x16dab2){if(qt('equalTo',this['_value'],_0x16dab2['_path'],!0x1),_0x16dab2['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x16dab2['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x16dab2));}}function E_(_0x2c5d53,_0x3b8f45){return new Vd(_0x2c5d53,_0x3b8f45);}function I_(_0x16d9e8,..._0x5b838f){let _0x352977=k(_0x16d9e8);for(const _0x279be2 of _0x5b838f)_0x352977=_0x279be2['_apply'](_0x352977);return _0x352977;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x248c8d,_0x24b9af,_0x3775fe,_0x23d27e){const _0x1c1d94=_0x24b9af['lastIndexOf'](':'),_0x259664=_0x24b9af['substring'](0x0,_0x1c1d94),_0x110451=Wt(_0x259664);_0x248c8d['repoInfo_']=new _o(_0x24b9af,_0x110451,_0x248c8d['repoInfo_']['namespace'],_0x248c8d['repoInfo_']['webSocketOnly'],_0x248c8d['repoInfo_']['nodeAdmin'],_0x248c8d['repoInfo_']['persistenceKey'],_0x248c8d['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x3775fe),_0x23d27e&&(_0x248c8d['authTokenProvider_']=_0x23d27e);}function qd(_0x143f8a,_0x8867f2,_0x325cc7,_0x2b9da0,_0x4636d6){let _0x1e3293=_0x2b9da0||_0x143f8a['options']['databaseURL'];_0x1e3293===void 0x0&&(_0x143f8a['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x143f8a['options']['projectId']),_0x1e3293=_0x143f8a['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x272187=gr(_0x1e3293,_0x4636d6),_0x558022=_0x272187['repoInfo'],_0x410cbf;typeof process<'u'&&Us&&(_0x410cbf=Us[Hd]),_0x410cbf?(_0x1e3293='http://'+_0x410cbf+'?ns='+_0x558022['namespace'],_0x272187=gr(_0x1e3293,_0x4636d6),_0x558022=_0x272187['repoInfo']):_0x272187['repoInfo']['secure'];const _0x8eb024=new Jl(_0x143f8a['name'],_0x143f8a['options'],_0x8867f2);dd('Invalid\x20Firebase\x20Database\x20URL',_0x272187),v(_0x272187['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x538d03=jd(_0x558022,_0x143f8a,_0x8eb024,new Ql(_0x143f8a,_0x325cc7));return new Kd(_0x538d03,_0x143f8a);}function zd(_0x220f7c,_0x14c6b5){const _0x4900cf=ki[_0x14c6b5];(!_0x4900cf||_0x4900cf[_0x220f7c['key']]!==_0x220f7c)&&oe('Database\x20'+_0x14c6b5+'('+_0x220f7c['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x220f7c),delete _0x4900cf[_0x220f7c['key']];}function jd(_0x3a65b6,_0x30a2fa,_0x9a10a2,_0x5072ee){let _0x43a1b8=ki[_0x30a2fa['name']];_0x43a1b8||(_0x43a1b8={},ki[_0x30a2fa['name']]=_0x43a1b8);let _0x4567b5=_0x43a1b8[_0x3a65b6['toURLString']()];return _0x4567b5&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4567b5=new gd(_0x3a65b6,$d,_0x9a10a2,_0x5072ee),_0x43a1b8[_0x3a65b6['toURLString']()]=_0x4567b5,_0x4567b5;}class Kd{constructor(_0x5aa915,_0x4dda7e){this['_repoInternal']=_0x5aa915,this['app']=_0x4dda7e,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x56cff9){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x56cff9+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x368c5d=Qr(),_0x44135e){const _0x33b42e=Ui(_0x368c5d,'database')['getImmediate']({'identifier':_0x44135e});if(!_0x33b42e['_instanceStarted']){const _0x5051a3=ac('database');_0x5051a3&&Yd(_0x33b42e,..._0x5051a3);}return _0x33b42e;}function Yd(_0x169f6c,_0x4e3741,_0x17d8e9,_0xfd407f={}){_0x169f6c=k(_0x169f6c),_0x169f6c['_checkNotDeleted']('useEmulator');const _0x486d19=_0x4e3741+':'+_0x17d8e9,_0x87f550=_0x169f6c['_repoInternal'];if(_0x169f6c['_instanceStarted']){if(_0x486d19===_0x169f6c['_repoInternal']['repoInfo_']['host']&&De(_0xfd407f,_0x87f550['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x257653;if(_0x87f550['repoInfo_']['nodeAdmin'])_0xfd407f['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x257653=new tn(tn['OWNER']);else{if(_0xfd407f['mockUserToken']){const _0x559a43=typeof _0xfd407f['mockUserToken']=='string'?_0xfd407f['mockUserToken']:cc(_0xfd407f['mockUserToken'],_0x169f6c['app']['options']['projectId']);_0x257653=new tn(_0x559a43);}}Wt(_0x4e3741)&&jr(_0x4e3741),Gd(_0x87f550,_0x486d19,_0xfd407f,_0x257653);}function C_(_0x3e92cf){_0x3e92cf=k(_0x3e92cf),_0x3e92cf['_checkNotDeleted']('goOffline'),aa(_0x3e92cf['_repo']);}function T_(_0x54e56e){_0x54e56e=k(_0x54e56e),_0x54e56e['_checkNotDeleted']('goOnline'),Sd(_0x54e56e['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x46a4e6){Ll(ct),et(new Me('database',(_0x46999a,{instanceIdentifier:_0x121ab4})=>{const _0xd087e2=_0x46999a['getProvider']('app')['getImmediate'](),_0xb6ac84=_0x46999a['getProvider']('auth-internal'),_0x224877=_0x46999a['getProvider']('app-check-internal');return qd(_0xd087e2,_0xb6ac84,_0x224877,_0x121ab4);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x46a4e6),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x55c364,_0x3d38e4){this['committed']=_0x55c364,this['snapshot']=_0x3d38e4;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x62f21,_0x23a714,_0x37ba37){if(_0x62f21=k(_0x62f21),gs('Reference.transaction',_0x62f21['_path']),_0x62f21['key']==='.length'||_0x62f21['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x62f21['key']+'\x20is\x20a\x20read-only\x20object.';const _0xaf83e6=!0x0,_0x5e7d43=new Ve(),_0xe8da9d=(_0x1fd71d,_0xa7e737,_0x42cc36)=>{let _0x16ba7f=null;_0x1fd71d?_0x5e7d43['reject'](_0x1fd71d):(_0x16ba7f=new rt(_0x42cc36,new Z(_0x62f21['_repo'],_0x62f21['_path']),R),_0x5e7d43['resolve'](new Xd(_0xa7e737,_0x16ba7f)));},_0x1308e6=Fd(_0x62f21,()=>{});return bd(_0x62f21['_repo'],_0x62f21['_path'],_0x23a714,_0xe8da9d,_0x1308e6,_0xaf83e6),_0x5e7d43['promise'];}ie['prototype']['simpleListen']=function(_0x432c23,_0x25219b){this['sendRequest']('q',{'p':_0x432c23},_0x25219b);},ie['prototype']['echo']=function(_0x6e84ab,_0x52a15c){this['sendRequest']('echo',{'d':_0x6e84ab},_0x52a15c);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x3f521b,..._0xb0ab8d){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x3f521b,..._0xb0ab8d);}function nn(_0xf29848,..._0x3e8b0f){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0xf29848,..._0x3e8b0f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x7bce0b,..._0x3576a4){throw Es(_0x7bce0b,..._0x3576a4);}function J(_0x5ce21a,..._0x164403){return Es(_0x5ce21a,..._0x164403);}function ya(_0x217a6c,_0xe6f1a2,_0x4ebbf5){const _0x4af043={...Zd(),[_0xe6f1a2]:_0x4ebbf5};return new Ut('auth','Firebase',_0x4af043)['create'](_0xe6f1a2,{'appName':_0x217a6c['name']});}function se(_0x29e74a){return ya(_0x29e74a,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x2f8ab2,..._0x139349){if(typeof _0x2f8ab2!='string'){const _0x28ca73=_0x139349[0x0],_0x2381dd=[..._0x139349['slice'](0x1)];return _0x2381dd[0x0]&&(_0x2381dd[0x0]['appName']=_0x2f8ab2['name']),_0x2f8ab2['_errorFactory']['create'](_0x28ca73,..._0x2381dd);}return ma['create'](_0x2f8ab2,..._0x139349);}function m(_0x5d7537,_0x4a5034,..._0x4ada2f){if(!_0x5d7537)throw Es(_0x4a5034,..._0x4ada2f);}function te(_0x4a1bd5){const _0x6e7ea7='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4a1bd5;throw nn(_0x6e7ea7),new Error(_0x6e7ea7);}function ae(_0x4907d6,_0x4e236d){_0x4907d6||te(_0x4e236d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x1f5d4e;return typeof self<'u'&&((_0x1f5d4e=self['location'])==null?void 0x0:_0x1f5d4e['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x524c33;return typeof self<'u'&&((_0x524c33=self['location'])==null?void 0x0:_0x524c33['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x34d169=navigator;return _0x34d169['languages']&&_0x34d169['languages'][0x0]||_0x34d169['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x2581df,_0x71cc38){this['shortDelay']=_0x2581df,this['longDelay']=_0x71cc38,ae(_0x71cc38>_0x2581df,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x52eea0,_0x57e2ea){ae(_0x52eea0['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x141383}=_0x52eea0['emulator'];return _0x57e2ea?''+_0x141383+(_0x57e2ea['startsWith']('/')?_0x57e2ea['slice'](0x1):_0x57e2ea):_0x141383;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x41a6ae,_0x17a7e9,_0x34e7d4){this['fetchImpl']=_0x41a6ae,_0x17a7e9&&(this['headersImpl']=_0x17a7e9),_0x34e7d4&&(this['responseImpl']=_0x34e7d4);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x1e5dd6,_0x20c5cc){return _0x1e5dd6['tenantId']&&!_0x20c5cc['tenantId']?{..._0x20c5cc,'tenantId':_0x1e5dd6['tenantId']}:_0x20c5cc;}async function Ae(_0x33b950,_0x187b0e,_0x45a563,_0x30ad60,_0x4d2e4d={}){return Ea(_0x33b950,_0x4d2e4d,async()=>{let _0x2d0245={},_0x151dd2={};_0x30ad60&&(_0x187b0e==='GET'?_0x151dd2=_0x30ad60:_0x2d0245={'body':JSON['stringify'](_0x30ad60)});const _0x6a57f0=at({..._0x151dd2,'key':_0x33b950['config']['apiKey']})['slice'](0x1),_0x556f7e=await _0x33b950['_getAdditionalHeaders']();_0x556f7e['Content-Type']='application/json',_0x33b950['languageCode']&&(_0x556f7e['X-Firebase-Locale']=_0x33b950['languageCode']);const _0x5aacc4={'method':_0x187b0e,'headers':_0x556f7e,..._0x2d0245};return lc()||(_0x5aacc4['referrerPolicy']='strict-origin-when-cross-origin'),_0x33b950['emulatorConfig']&&Wt(_0x33b950['emulatorConfig']['host'])&&(_0x5aacc4['credentials']='include'),va['fetch']()(await Ia(_0x33b950,_0x33b950['config']['apiHost'],_0x45a563,_0x6a57f0),_0x5aacc4);});}async function Ea(_0x18906c,_0xacd652,_0x4e985b){_0x18906c['_canInitEmulator']=!0x1;const _0x5daa3f={...rf,..._0xacd652};try{const _0x374168=new lf(_0x18906c),_0x4835d7=await Promise['race']([_0x4e985b(),_0x374168['promise']]);_0x374168['clearNetworkTimeout']();const _0x5c1115=await _0x4835d7['json']();if('needConfirmation'in _0x5c1115)throw en(_0x18906c,'account-exists-with-different-credential',_0x5c1115);if(_0x4835d7['ok']&&!('errorMessage'in _0x5c1115))return _0x5c1115;{const _0x3cc7e6=_0x4835d7['ok']?_0x5c1115['errorMessage']:_0x5c1115['error']['message'],[_0x5a3aed,_0xab570e]=_0x3cc7e6['split']('\x20:\x20');if(_0x5a3aed==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x18906c,'credential-already-in-use',_0x5c1115);if(_0x5a3aed==='EMAIL_EXISTS')throw en(_0x18906c,'email-already-in-use',_0x5c1115);if(_0x5a3aed==='USER_DISABLED')throw en(_0x18906c,'user-disabled',_0x5c1115);const _0x267845=_0x5daa3f[_0x5a3aed]||_0x5a3aed['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0xab570e)throw ya(_0x18906c,_0x267845,_0xab570e);K(_0x18906c,_0x267845);}}catch(_0x4c2614){if(_0x4c2614 instanceof Se)throw _0x4c2614;K(_0x18906c,'network-request-failed',{'message':String(_0x4c2614)});}}async function Yt(_0x2a6969,_0x1e4f56,_0x38e765,_0x345b9b,_0x351d00={}){const _0x313dd1=await Ae(_0x2a6969,_0x1e4f56,_0x38e765,_0x345b9b,_0x351d00);return'mfaPendingCredential'in _0x313dd1&&K(_0x2a6969,'multi-factor-auth-required',{'_serverResponse':_0x313dd1}),_0x313dd1;}async function Ia(_0x168587,_0x243938,_0x450390,_0x5d582c){const _0x84d8da=''+_0x243938+_0x450390+'?'+_0x5d582c,_0x3591c8=_0x168587,_0x2b54f8=_0x3591c8['config']['emulator']?Is(_0x168587['config'],_0x84d8da):_0x168587['config']['apiScheme']+'://'+_0x84d8da;return of['includes'](_0x450390)&&(await _0x3591c8['_persistenceManagerAvailable'],_0x3591c8['_getPersistenceType']()==='COOKIE')?_0x3591c8['_getPersistence']()['_getFinalTarget'](_0x2b54f8)['toString']():_0x2b54f8;}function cf(_0x24e1ad){switch(_0x24e1ad){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x135dac){this['auth']=_0x135dac,this['timer']=null,this['promise']=new Promise((_0x1da634,_0xb2ed7b)=>{this['timer']=setTimeout(()=>_0xb2ed7b(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x1b94dc,_0x2151d3,_0x51df1a){const _0x1d5a3d={'appName':_0x1b94dc['name']};_0x51df1a['email']&&(_0x1d5a3d['email']=_0x51df1a['email']),_0x51df1a['phoneNumber']&&(_0x1d5a3d['phoneNumber']=_0x51df1a['phoneNumber']);const _0xb513b6=J(_0x1b94dc,_0x2151d3,_0x1d5a3d);return _0xb513b6['customData']['_tokenResponse']=_0x51df1a,_0xb513b6;}function vr(_0x11e1be){return _0x11e1be!==void 0x0&&_0x11e1be['enterprise']!==void 0x0;}class hf{constructor(_0x3c1d85){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3c1d85['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3c1d85['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3c1d85['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2f994f){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3e8a27 of this['recaptchaEnforcementState'])if(_0x3e8a27['provider']&&_0x3e8a27['provider']===_0x2f994f)return cf(_0x3e8a27['enforcementState']);return null;}['isProviderEnabled'](_0x56f3e9){return this['getProviderEnforcementState'](_0x56f3e9)==='ENFORCE'||this['getProviderEnforcementState'](_0x56f3e9)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x2d05d2,_0x1ef2bb){return Ae(_0x2d05d2,'GET','/v2/recaptchaConfig',Re(_0x2d05d2,_0x1ef2bb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x4e222e,_0x98fe70){return Ae(_0x4e222e,'POST','/v1/accounts:delete',_0x98fe70);}async function Sn(_0xdf7ba0,_0x53ab7d){return Ae(_0xdf7ba0,'POST','/v1/accounts:lookup',_0x53ab7d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x42645b){if(_0x42645b)try{const _0x5dc4a9=new Date(Number(_0x42645b));if(!isNaN(_0x5dc4a9['getTime']()))return _0x5dc4a9['toUTCString']();}catch{}}async function ff(_0x460db7,_0x27d14d=!0x1){const _0x40b520=k(_0x460db7),_0x3cc894=await _0x40b520['getIdToken'](_0x27d14d),_0x172e4a=ws(_0x3cc894);m(_0x172e4a&&_0x172e4a['exp']&&_0x172e4a['auth_time']&&_0x172e4a['iat'],_0x40b520['auth'],'internal-error');const _0x431cbf=typeof _0x172e4a['firebase']=='object'?_0x172e4a['firebase']:void 0x0,_0x2d9d64=_0x431cbf==null?void 0x0:_0x431cbf['sign_in_provider'];return{'claims':_0x172e4a,'token':_0x3cc894,'authTime':St(ci(_0x172e4a['auth_time'])),'issuedAtTime':St(ci(_0x172e4a['iat'])),'expirationTime':St(ci(_0x172e4a['exp'])),'signInProvider':_0x2d9d64||null,'signInSecondFactor':(_0x431cbf==null?void 0x0:_0x431cbf['sign_in_second_factor'])||null};}function ci(_0x1c876c){return Number(_0x1c876c)*0x3e8;}function ws(_0x49fc37){const [_0x171ba6,_0x2b2543,_0x2221b5]=_0x49fc37['split']('.');if(_0x171ba6===void 0x0||_0x2b2543===void 0x0||_0x2221b5===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x14778f=cn(_0x2b2543);return _0x14778f?JSON['parse'](_0x14778f):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x14a2de){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x14a2de==null?void 0x0:_0x14a2de['toString']()),null;}}function Er(_0x5bab05){const _0x31378f=ws(_0x5bab05);return m(_0x31378f,'internal-error'),m(typeof _0x31378f['exp']<'u','internal-error'),m(typeof _0x31378f['iat']<'u','internal-error'),Number(_0x31378f['exp'])-Number(_0x31378f['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0xe1b144,_0x4dc4d7,_0x525996=!0x1){if(_0x525996)return _0x4dc4d7;try{return await _0x4dc4d7;}catch(_0x5ca871){throw _0x5ca871 instanceof Se&&pf(_0x5ca871)&&_0xe1b144['auth']['currentUser']===_0xe1b144&&await _0xe1b144['auth']['signOut'](),_0x5ca871;}}function pf({code:_0x24e83e}){return _0x24e83e==='auth/user-disabled'||_0x24e83e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x38e9cc){this['user']=_0x38e9cc,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x12d9c0){if(_0x12d9c0){const _0x22a70d=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x22a70d;}else{this['errorBackoff']=0x7530;const _0x11ae56=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x11ae56);}}['schedule'](_0x6b82b3=!0x1){if(!this['isRunning'])return;const _0x11bdee=this['getInterval'](_0x6b82b3);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x11bdee);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2740e6){(_0x2740e6==null?void 0x0:_0x2740e6['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5d6bed,_0x36a5d8){this['createdAt']=_0x5d6bed,this['lastLoginAt']=_0x36a5d8,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x45771d){this['createdAt']=_0x45771d['createdAt'],this['lastLoginAt']=_0x45771d['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x3595a9){var _0x1d1391;const _0x1caa33=_0x3595a9['auth'],_0x48d2e5=await _0x3595a9['getIdToken'](),_0x5d57ed=await xt(_0x3595a9,Sn(_0x1caa33,{'idToken':_0x48d2e5}));m(_0x5d57ed==null?void 0x0:_0x5d57ed['users']['length'],_0x1caa33,'internal-error');const _0xd7d6e1=_0x5d57ed['users'][0x0];_0x3595a9['_notifyReloadListener'](_0xd7d6e1);const _0x4f728e=(_0x1d1391=_0xd7d6e1['providerUserInfo'])!=null&&_0x1d1391['length']?wa(_0xd7d6e1['providerUserInfo']):[],_0x2f9b33=mf(_0x3595a9['providerData'],_0x4f728e),_0x4eaf50=_0x3595a9['isAnonymous'],_0x2af112=!(_0x3595a9['email']&&_0xd7d6e1['passwordHash'])&&!(_0x2f9b33!=null&&_0x2f9b33['length']),_0x17661b=_0x4eaf50?_0x2af112:!0x1,_0x5ca59e={'uid':_0xd7d6e1['localId'],'displayName':_0xd7d6e1['displayName']||null,'photoURL':_0xd7d6e1['photoUrl']||null,'email':_0xd7d6e1['email']||null,'emailVerified':_0xd7d6e1['emailVerified']||!0x1,'phoneNumber':_0xd7d6e1['phoneNumber']||null,'tenantId':_0xd7d6e1['tenantId']||null,'providerData':_0x2f9b33,'metadata':new Pi(_0xd7d6e1['createdAt'],_0xd7d6e1['lastLoginAt']),'isAnonymous':_0x17661b};Object['assign'](_0x3595a9,_0x5ca59e);}async function gf(_0x2e0cf9){const _0x573281=k(_0x2e0cf9);await bn(_0x573281),await _0x573281['auth']['_persistUserIfCurrent'](_0x573281),_0x573281['auth']['_notifyListenersIfCurrent'](_0x573281);}function mf(_0x412b5f,_0x38a879){return[..._0x412b5f['filter'](_0x4599a0=>!_0x38a879['some'](_0x41125c=>_0x41125c['providerId']===_0x4599a0['providerId'])),..._0x38a879];}function wa(_0x5366e6){return _0x5366e6['map'](({providerId:_0x27d017,..._0x41766c})=>({'providerId':_0x27d017,'uid':_0x41766c['rawId']||'','displayName':_0x41766c['displayName']||null,'email':_0x41766c['email']||null,'phoneNumber':_0x41766c['phoneNumber']||null,'photoURL':_0x41766c['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x61b0c3,_0x43f702){const _0x40a440=await Ea(_0x61b0c3,{},async()=>{const _0x25b01e=at({'grant_type':'refresh_token','refresh_token':_0x43f702})['slice'](0x1),{tokenApiHost:_0x16fd1f,apiKey:_0x35db5e}=_0x61b0c3['config'],_0x41ee34=await Ia(_0x61b0c3,_0x16fd1f,'/v1/token','key='+_0x35db5e),_0x4e594b=await _0x61b0c3['_getAdditionalHeaders']();_0x4e594b['Content-Type']='application/x-www-form-urlencoded';const _0x148a7b={'method':'POST','headers':_0x4e594b,'body':_0x25b01e};return _0x61b0c3['emulatorConfig']&&Wt(_0x61b0c3['emulatorConfig']['host'])&&(_0x148a7b['credentials']='include'),va['fetch']()(_0x41ee34,_0x148a7b);});return{'accessToken':_0x40a440['access_token'],'expiresIn':_0x40a440['expires_in'],'refreshToken':_0x40a440['refresh_token']};}async function vf(_0x478d15,_0x6ef90f){return Ae(_0x478d15,'POST','/v2/accounts:revokeToken',Re(_0x478d15,_0x6ef90f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x3d0c4a){m(_0x3d0c4a['idToken'],'internal-error'),m(typeof _0x3d0c4a['idToken']<'u','internal-error'),m(typeof _0x3d0c4a['refreshToken']<'u','internal-error');const _0x5d8725='expiresIn'in _0x3d0c4a&&typeof _0x3d0c4a['expiresIn']<'u'?Number(_0x3d0c4a['expiresIn']):Er(_0x3d0c4a['idToken']);this['updateTokensAndExpiration'](_0x3d0c4a['idToken'],_0x3d0c4a['refreshToken'],_0x5d8725);}['updateFromIdToken'](_0x242ddc){m(_0x242ddc['length']!==0x0,'internal-error');const _0xfd6a0a=Er(_0x242ddc);this['updateTokensAndExpiration'](_0x242ddc,null,_0xfd6a0a);}async['getToken'](_0x397b67,_0x59f9c2=!0x1){return!_0x59f9c2&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x397b67,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x397b67,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1c1c6a,_0xb29a65){const {accessToken:_0x35f776,refreshToken:_0x25f4e5,expiresIn:_0x20337d}=await yf(_0x1c1c6a,_0xb29a65);this['updateTokensAndExpiration'](_0x35f776,_0x25f4e5,Number(_0x20337d));}['updateTokensAndExpiration'](_0x92cb41,_0x4f380a,_0x2d4a68){this['refreshToken']=_0x4f380a||null,this['accessToken']=_0x92cb41||null,this['expirationTime']=Date['now']()+_0x2d4a68*0x3e8;}static['fromJSON'](_0x4ddf11,_0x40554c){const {refreshToken:_0x482026,accessToken:_0x50a7ed,expirationTime:_0x42ebc7}=_0x40554c,_0x2c740e=new Je();return _0x482026&&(m(typeof _0x482026=='string','internal-error',{'appName':_0x4ddf11}),_0x2c740e['refreshToken']=_0x482026),_0x50a7ed&&(m(typeof _0x50a7ed=='string','internal-error',{'appName':_0x4ddf11}),_0x2c740e['accessToken']=_0x50a7ed),_0x42ebc7&&(m(typeof _0x42ebc7=='number','internal-error',{'appName':_0x4ddf11}),_0x2c740e['expirationTime']=_0x42ebc7),_0x2c740e;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x35565f){this['accessToken']=_0x35565f['accessToken'],this['refreshToken']=_0x35565f['refreshToken'],this['expirationTime']=_0x35565f['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x5ded41,_0x3e551e){m(typeof _0x5ded41=='string'||typeof _0x5ded41>'u','internal-error',{'appName':_0x3e551e});}class z{constructor({uid:_0x5f082e,auth:_0xd8cf24,stsTokenManager:_0x1e0e28,..._0x4af114}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5f082e,this['auth']=_0xd8cf24,this['stsTokenManager']=_0x1e0e28,this['accessToken']=_0x1e0e28['accessToken'],this['displayName']=_0x4af114['displayName']||null,this['email']=_0x4af114['email']||null,this['emailVerified']=_0x4af114['emailVerified']||!0x1,this['phoneNumber']=_0x4af114['phoneNumber']||null,this['photoURL']=_0x4af114['photoURL']||null,this['isAnonymous']=_0x4af114['isAnonymous']||!0x1,this['tenantId']=_0x4af114['tenantId']||null,this['providerData']=_0x4af114['providerData']?[..._0x4af114['providerData']]:[],this['metadata']=new Pi(_0x4af114['createdAt']||void 0x0,_0x4af114['lastLoginAt']||void 0x0);}async['getIdToken'](_0x485e62){const _0x2804d4=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x485e62));return m(_0x2804d4,this['auth'],'internal-error'),this['accessToken']!==_0x2804d4&&(this['accessToken']=_0x2804d4,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2804d4;}['getIdTokenResult'](_0x3747ef){return ff(this,_0x3747ef);}['reload'](){return gf(this);}['_assign'](_0x5568dd){this!==_0x5568dd&&(m(this['uid']===_0x5568dd['uid'],this['auth'],'internal-error'),this['displayName']=_0x5568dd['displayName'],this['photoURL']=_0x5568dd['photoURL'],this['email']=_0x5568dd['email'],this['emailVerified']=_0x5568dd['emailVerified'],this['phoneNumber']=_0x5568dd['phoneNumber'],this['isAnonymous']=_0x5568dd['isAnonymous'],this['tenantId']=_0x5568dd['tenantId'],this['providerData']=_0x5568dd['providerData']['map'](_0x2baa85=>({..._0x2baa85})),this['metadata']['_copy'](_0x5568dd['metadata']),this['stsTokenManager']['_assign'](_0x5568dd['stsTokenManager']));}['_clone'](_0x13495a){const _0xc0cbd6=new z({...this,'auth':_0x13495a,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0xc0cbd6['metadata']['_copy'](this['metadata']),_0xc0cbd6;}['_onReload'](_0x5822e4){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x5822e4,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2aba4a){this['reloadListener']?this['reloadListener'](_0x2aba4a):this['reloadUserInfo']=_0x2aba4a;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x30781a,_0x432298=!0x1){let _0x4c181e=!0x1;_0x30781a['idToken']&&_0x30781a['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x30781a),_0x4c181e=!0x0),_0x432298&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x4c181e&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x13b44b=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x13b44b})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2842f1=>({..._0x2842f1})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5aacff,_0x4c397f){const _0x1459a9=_0x4c397f['displayName']??void 0x0,_0x45ea76=_0x4c397f['email']??void 0x0,_0x342222=_0x4c397f['phoneNumber']??void 0x0,_0x2b353c=_0x4c397f['photoURL']??void 0x0,_0x102a86=_0x4c397f['tenantId']??void 0x0,_0x14d85d=_0x4c397f['_redirectEventId']??void 0x0,_0x1767a6=_0x4c397f['createdAt']??void 0x0,_0x2d7699=_0x4c397f['lastLoginAt']??void 0x0,{uid:_0x205ff1,emailVerified:_0x540478,isAnonymous:_0x25acaa,providerData:_0x4cee08,stsTokenManager:_0x3b4f34}=_0x4c397f;m(_0x205ff1&&_0x3b4f34,_0x5aacff,'internal-error');const _0x515ef4=Je['fromJSON'](this['name'],_0x3b4f34);m(typeof _0x205ff1=='string',_0x5aacff,'internal-error'),ce(_0x1459a9,_0x5aacff['name']),ce(_0x45ea76,_0x5aacff['name']),m(typeof _0x540478=='boolean',_0x5aacff,'internal-error'),m(typeof _0x25acaa=='boolean',_0x5aacff,'internal-error'),ce(_0x342222,_0x5aacff['name']),ce(_0x2b353c,_0x5aacff['name']),ce(_0x102a86,_0x5aacff['name']),ce(_0x14d85d,_0x5aacff['name']),ce(_0x1767a6,_0x5aacff['name']),ce(_0x2d7699,_0x5aacff['name']);const _0x30271d=new z({'uid':_0x205ff1,'auth':_0x5aacff,'email':_0x45ea76,'emailVerified':_0x540478,'displayName':_0x1459a9,'isAnonymous':_0x25acaa,'photoURL':_0x2b353c,'phoneNumber':_0x342222,'tenantId':_0x102a86,'stsTokenManager':_0x515ef4,'createdAt':_0x1767a6,'lastLoginAt':_0x2d7699});return _0x4cee08&&Array['isArray'](_0x4cee08)&&(_0x30271d['providerData']=_0x4cee08['map'](_0x3c11f2=>({..._0x3c11f2}))),_0x14d85d&&(_0x30271d['_redirectEventId']=_0x14d85d),_0x30271d;}static async['_fromIdTokenResponse'](_0x2e7567,_0xb14512,_0x59a033=!0x1){const _0x1e4379=new Je();_0x1e4379['updateFromServerResponse'](_0xb14512);const _0x5483c8=new z({'uid':_0xb14512['localId'],'auth':_0x2e7567,'stsTokenManager':_0x1e4379,'isAnonymous':_0x59a033});return await bn(_0x5483c8),_0x5483c8;}static async['_fromGetAccountInfoResponse'](_0x4d4456,_0xb195d3,_0x1422dd){const _0x4c321a=_0xb195d3['users'][0x0];m(_0x4c321a['localId']!==void 0x0,'internal-error');const _0xbab0f7=_0x4c321a['providerUserInfo']!==void 0x0?wa(_0x4c321a['providerUserInfo']):[],_0x56b47d=!(_0x4c321a['email']&&_0x4c321a['passwordHash'])&&!(_0xbab0f7!=null&&_0xbab0f7['length']),_0x2ed048=new Je();_0x2ed048['updateFromIdToken'](_0x1422dd);const _0x21a2b2=new z({'uid':_0x4c321a['localId'],'auth':_0x4d4456,'stsTokenManager':_0x2ed048,'isAnonymous':_0x56b47d}),_0x390d82={'uid':_0x4c321a['localId'],'displayName':_0x4c321a['displayName']||null,'photoURL':_0x4c321a['photoUrl']||null,'email':_0x4c321a['email']||null,'emailVerified':_0x4c321a['emailVerified']||!0x1,'phoneNumber':_0x4c321a['phoneNumber']||null,'tenantId':_0x4c321a['tenantId']||null,'providerData':_0xbab0f7,'metadata':new Pi(_0x4c321a['createdAt'],_0x4c321a['lastLoginAt']),'isAnonymous':!(_0x4c321a['email']&&_0x4c321a['passwordHash'])&&!(_0xbab0f7!=null&&_0xbab0f7['length'])};return Object['assign'](_0x21a2b2,_0x390d82),_0x21a2b2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0xfc104c){ae(_0xfc104c instanceof Function,'Expected\x20a\x20class\x20definition');let _0x187629=Ir['get'](_0xfc104c);return _0x187629?(ae(_0x187629 instanceof _0xfc104c,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x187629):(_0x187629=new _0xfc104c(),Ir['set'](_0xfc104c,_0x187629),_0x187629);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x25f026,_0x2c699b){this['storage'][_0x25f026]=_0x2c699b;}async['_get'](_0x289f60){const _0x5527da=this['storage'][_0x289f60];return _0x5527da===void 0x0?null:_0x5527da;}async['_remove'](_0x235127){delete this['storage'][_0x235127];}['_addListener'](_0x38af84,_0x278cad){}['_removeListener'](_0x5c8d41,_0x54e3b1){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x3c6d63,_0x5a8ad6,_0xc8f0c2){return'firebase:'+_0x3c6d63+':'+_0x5a8ad6+':'+_0xc8f0c2;}class Xe{constructor(_0x884f4a,_0x2ccf8f,_0x5f27d9){this['persistence']=_0x884f4a,this['auth']=_0x2ccf8f,this['userKey']=_0x5f27d9;const {config:_0x40de51,name:_0x119841}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x40de51['apiKey'],_0x119841),this['fullPersistenceKey']=sn('persistence',_0x40de51['apiKey'],_0x119841),this['boundEventHandler']=_0x2ccf8f['_onStorageEvent']['bind'](_0x2ccf8f),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3d0110){return this['persistence']['_set'](this['fullUserKey'],_0x3d0110['toJSON']());}async['getCurrentUser'](){const _0x4f0b49=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4f0b49)return null;if(typeof _0x4f0b49=='string'){const _0x47a9d1=await Sn(this['auth'],{'idToken':_0x4f0b49})['catch'](()=>{});return _0x47a9d1?z['_fromGetAccountInfoResponse'](this['auth'],_0x47a9d1,_0x4f0b49):null;}return z['_fromJSON'](this['auth'],_0x4f0b49);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x58cfd0){if(this['persistence']===_0x58cfd0)return;const _0xb756ad=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x58cfd0,_0xb756ad)return this['setCurrentUser'](_0xb756ad);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5edbf8,_0x234122,_0x3587ea='authUser'){if(!_0x234122['length'])return new Xe(ne(wr),_0x5edbf8,_0x3587ea);const _0x16668d=(await Promise['all'](_0x234122['map'](async _0x424c1e=>{if(await _0x424c1e['_isAvailable']())return _0x424c1e;})))['filter'](_0x2fe35f=>_0x2fe35f);let _0x1d57b9=_0x16668d[0x0]||ne(wr);const _0x43f780=sn(_0x3587ea,_0x5edbf8['config']['apiKey'],_0x5edbf8['name']);let _0x54b9eb=null;for(const _0x231c98 of _0x234122)try{const _0x32d6bb=await _0x231c98['_get'](_0x43f780);if(_0x32d6bb){let _0x1bae06;if(typeof _0x32d6bb=='string'){const _0x5a00fa=await Sn(_0x5edbf8,{'idToken':_0x32d6bb})['catch'](()=>{});if(!_0x5a00fa)break;_0x1bae06=await z['_fromGetAccountInfoResponse'](_0x5edbf8,_0x5a00fa,_0x32d6bb);}else _0x1bae06=z['_fromJSON'](_0x5edbf8,_0x32d6bb);_0x231c98!==_0x1d57b9&&(_0x54b9eb=_0x1bae06),_0x1d57b9=_0x231c98;break;}}catch{}const _0xeddf19=_0x16668d['filter'](_0x38cd2c=>_0x38cd2c['_shouldAllowMigration']);return!_0x1d57b9['_shouldAllowMigration']||!_0xeddf19['length']?new Xe(_0x1d57b9,_0x5edbf8,_0x3587ea):(_0x1d57b9=_0xeddf19[0x0],_0x54b9eb&&await _0x1d57b9['_set'](_0x43f780,_0x54b9eb['toJSON']()),await Promise['all'](_0x234122['map'](async _0x3ab267=>{if(_0x3ab267!==_0x1d57b9)try{await _0x3ab267['_remove'](_0x43f780);}catch{}})),new Xe(_0x1d57b9,_0x5edbf8,_0x3587ea));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x5325e1){const _0x2a7bc8=_0x5325e1['toLowerCase']();if(_0x2a7bc8['includes']('opera/')||_0x2a7bc8['includes']('opr/')||_0x2a7bc8['includes']('opios/'))return'Opera';if(Ra(_0x2a7bc8))return'IEMobile';if(_0x2a7bc8['includes']('msie')||_0x2a7bc8['includes']('trident/'))return'IE';if(_0x2a7bc8['includes']('edge/'))return'Edge';if(Ta(_0x2a7bc8))return'Firefox';if(_0x2a7bc8['includes']('silk/'))return'Silk';if(ka(_0x2a7bc8))return'Blackberry';if(Na(_0x2a7bc8))return'Webos';if(Sa(_0x2a7bc8))return'Safari';if((_0x2a7bc8['includes']('chrome/')||ba(_0x2a7bc8))&&!_0x2a7bc8['includes']('edge/'))return'Chrome';if(Aa(_0x2a7bc8))return'Android';{const _0x278ec0=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x12c76e=_0x5325e1['match'](_0x278ec0);if((_0x12c76e==null?void 0x0:_0x12c76e['length'])===0x2)return _0x12c76e[0x1];}return'Other';}function Ta(_0x3912a4=W()){return/firefox\//i['test'](_0x3912a4);}function Sa(_0x2c1fde=W()){const _0x3e6d99=_0x2c1fde['toLowerCase']();return _0x3e6d99['includes']('safari/')&&!_0x3e6d99['includes']('chrome/')&&!_0x3e6d99['includes']('crios/')&&!_0x3e6d99['includes']('android');}function ba(_0x39d141=W()){return/crios\//i['test'](_0x39d141);}function Ra(_0x680b4a=W()){return/iemobile/i['test'](_0x680b4a);}function Aa(_0x42eea1=W()){return/android/i['test'](_0x42eea1);}function ka(_0x507240=W()){return/blackberry/i['test'](_0x507240);}function Na(_0x3cc267=W()){return/webos/i['test'](_0x3cc267);}function Cs(_0x12f22d=W()){return/iphone|ipad|ipod/i['test'](_0x12f22d)||/macintosh/i['test'](_0x12f22d)&&/mobile/i['test'](_0x12f22d);}function Ef(_0x4ce270=W()){var _0x196cee;return Cs(_0x4ce270)&&!!((_0x196cee=window['navigator'])!=null&&_0x196cee['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2ebfce=W()){return Cs(_0x2ebfce)||Aa(_0x2ebfce)||Na(_0x2ebfce)||ka(_0x2ebfce)||/windows phone/i['test'](_0x2ebfce)||Ra(_0x2ebfce);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x20d96b,_0x5e684f=[]){let _0xce0dc4;switch(_0x20d96b){case'Browser':_0xce0dc4=Cr(W());break;case'Worker':_0xce0dc4=Cr(W())+'-'+_0x20d96b;break;default:_0xce0dc4=_0x20d96b;}const _0x8fa199=_0x5e684f['length']?_0x5e684f['join'](','):'FirebaseCore-web';return _0xce0dc4+'/JsCore/'+ct+'/'+_0x8fa199;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x5ded1f){this['auth']=_0x5ded1f,this['queue']=[];}['pushCallback'](_0x49973d,_0x41406d){const _0x26b8ac=_0x5c8a9e=>new Promise((_0x2a0e37,_0x1113be)=>{try{const _0x1df9a7=_0x49973d(_0x5c8a9e);_0x2a0e37(_0x1df9a7);}catch(_0x1a3b9c){_0x1113be(_0x1a3b9c);}});_0x26b8ac['onAbort']=_0x41406d,this['queue']['push'](_0x26b8ac);const _0x25e79f=this['queue']['length']-0x1;return()=>{this['queue'][_0x25e79f]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1cfa03){if(this['auth']['currentUser']===_0x1cfa03)return;const _0x296571=[];try{for(const _0x442383 of this['queue'])await _0x442383(_0x1cfa03),_0x442383['onAbort']&&_0x296571['push'](_0x442383['onAbort']);}catch(_0x15cc26){_0x296571['reverse']();for(const _0xe3b5ff of _0x296571)try{_0xe3b5ff();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x15cc26==null?void 0x0:_0x15cc26['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x533dbb,_0xf87bc8={}){return Ae(_0x533dbb,'GET','/v2/passwordPolicy',Re(_0x533dbb,_0xf87bc8));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x380e87){var _0x1b51d4;const _0x5733fc=_0x380e87['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x5733fc['minPasswordLength']??Tf,_0x5733fc['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x5733fc['maxPasswordLength']),_0x5733fc['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x5733fc['containsLowercaseCharacter']),_0x5733fc['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x5733fc['containsUppercaseCharacter']),_0x5733fc['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x5733fc['containsNumericCharacter']),_0x5733fc['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x5733fc['containsNonAlphanumericCharacter']),this['enforcementState']=_0x380e87['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1b51d4=_0x380e87['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1b51d4['join'](''))??'',this['forceUpgradeOnSignin']=_0x380e87['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x380e87['schemaVersion'];}['validatePassword'](_0x1763ec){const _0x4cb911={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1763ec,_0x4cb911),this['validatePasswordCharacterOptions'](_0x1763ec,_0x4cb911),_0x4cb911['isValid']&&(_0x4cb911['isValid']=_0x4cb911['meetsMinPasswordLength']??!0x0),_0x4cb911['isValid']&&(_0x4cb911['isValid']=_0x4cb911['meetsMaxPasswordLength']??!0x0),_0x4cb911['isValid']&&(_0x4cb911['isValid']=_0x4cb911['containsLowercaseLetter']??!0x0),_0x4cb911['isValid']&&(_0x4cb911['isValid']=_0x4cb911['containsUppercaseLetter']??!0x0),_0x4cb911['isValid']&&(_0x4cb911['isValid']=_0x4cb911['containsNumericCharacter']??!0x0),_0x4cb911['isValid']&&(_0x4cb911['isValid']=_0x4cb911['containsNonAlphanumericCharacter']??!0x0),_0x4cb911;}['validatePasswordLengthOptions'](_0x38293c,_0x41a0c8){const _0x38d1f8=this['customStrengthOptions']['minPasswordLength'],_0x39a9cf=this['customStrengthOptions']['maxPasswordLength'];_0x38d1f8&&(_0x41a0c8['meetsMinPasswordLength']=_0x38293c['length']>=_0x38d1f8),_0x39a9cf&&(_0x41a0c8['meetsMaxPasswordLength']=_0x38293c['length']<=_0x39a9cf);}['validatePasswordCharacterOptions'](_0x438404,_0x3d559c){this['updatePasswordCharacterOptionsStatuses'](_0x3d559c,!0x1,!0x1,!0x1,!0x1);let _0x1aecb4;for(let _0x170352=0x0;_0x170352<_0x438404['length'];_0x170352++)_0x1aecb4=_0x438404['charAt'](_0x170352),this['updatePasswordCharacterOptionsStatuses'](_0x3d559c,_0x1aecb4>='a'&&_0x1aecb4<='z',_0x1aecb4>='A'&&_0x1aecb4<='Z',_0x1aecb4>='0'&&_0x1aecb4<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1aecb4));}['updatePasswordCharacterOptionsStatuses'](_0x98d3e,_0x97789f,_0x39945a,_0x59f189,_0x1fcea9){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x98d3e['containsLowercaseLetter']||(_0x98d3e['containsLowercaseLetter']=_0x97789f)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x98d3e['containsUppercaseLetter']||(_0x98d3e['containsUppercaseLetter']=_0x39945a)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x98d3e['containsNumericCharacter']||(_0x98d3e['containsNumericCharacter']=_0x59f189)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x98d3e['containsNonAlphanumericCharacter']||(_0x98d3e['containsNonAlphanumericCharacter']=_0x1fcea9));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x5d25be,_0x42527c,_0x5340df,_0x23ba6b){this['app']=_0x5d25be,this['heartbeatServiceProvider']=_0x42527c,this['appCheckServiceProvider']=_0x5340df,this['config']=_0x23ba6b,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5d25be['name'],this['clientVersion']=_0x23ba6b['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x396705=>this['_resolvePersistenceManagerAvailable']=_0x396705);}['_initializeWithPersistence'](_0x16da21,_0x7ae828){return _0x7ae828&&(this['_popupRedirectResolver']=ne(_0x7ae828)),this['_initializationPromise']=this['queue'](async()=>{var _0x3bc640,_0x41025b,_0x5de46e;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x16da21),(_0x3bc640=this['_resolvePersistenceManagerAvailable'])==null||_0x3bc640['call'](this),!this['_deleted'])){if((_0x41025b=this['_popupRedirectResolver'])!=null&&_0x41025b['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x7ae828),this['lastNotifiedUid']=((_0x5de46e=this['currentUser'])==null?void 0x0:_0x5de46e['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x340e94=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x340e94)){if(this['currentUser']&&_0x340e94&&this['currentUser']['uid']===_0x340e94['uid']){this['_currentUser']['_assign'](_0x340e94),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x340e94,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x264df6){try{const _0x46c2be=await Sn(this,{'idToken':_0x264df6}),_0x1b61ab=await z['_fromGetAccountInfoResponse'](this,_0x46c2be,_0x264df6);await this['directlySetCurrentUser'](_0x1b61ab);}catch(_0x43205f){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x43205f),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x116bbf){var _0x251c01;if(H(this['app'])){const _0x5040ca=this['app']['settings']['authIdToken'];return _0x5040ca?new Promise(_0x4bca89=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x5040ca)['then'](_0x4bca89,_0x4bca89));}):this['directlySetCurrentUser'](null);}const _0xa8d377=await this['assertedPersistence']['getCurrentUser']();let _0x4d527c=_0xa8d377,_0x29f89e=!0x1;if(_0x116bbf&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3d2efa=(_0x251c01=this['redirectUser'])==null?void 0x0:_0x251c01['_redirectEventId'],_0x1f0c79=_0x4d527c==null?void 0x0:_0x4d527c['_redirectEventId'],_0x59e20c=await this['tryRedirectSignIn'](_0x116bbf);(!_0x3d2efa||_0x3d2efa===_0x1f0c79)&&(_0x59e20c!=null&&_0x59e20c['user'])&&(_0x4d527c=_0x59e20c['user'],_0x29f89e=!0x0);}if(!_0x4d527c)return this['directlySetCurrentUser'](null);if(!_0x4d527c['_redirectEventId']){if(_0x29f89e)try{await this['beforeStateQueue']['runMiddleware'](_0x4d527c);}catch(_0x46cba8){_0x4d527c=_0xa8d377,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x46cba8));}return _0x4d527c?this['reloadAndSetCurrentUserOrClear'](_0x4d527c):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4d527c['_redirectEventId']?this['directlySetCurrentUser'](_0x4d527c):this['reloadAndSetCurrentUserOrClear'](_0x4d527c);}async['tryRedirectSignIn'](_0x552546){let _0x32b96f=null;try{_0x32b96f=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x552546,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x32b96f;}async['reloadAndSetCurrentUserOrClear'](_0x302f8c){try{await bn(_0x302f8c);}catch(_0x2e5d39){if((_0x2e5d39==null?void 0x0:_0x2e5d39['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x302f8c);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x38ae17){if(H(this['app']))return Promise['reject'](se(this));const _0x1f0537=_0x38ae17?k(_0x38ae17):null;return _0x1f0537&&m(_0x1f0537['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x1f0537&&_0x1f0537['_clone'](this));}async['_updateCurrentUser'](_0x23ccda,_0x2b7306=!0x1){if(!this['_deleted'])return _0x23ccda&&m(this['tenantId']===_0x23ccda['tenantId'],this,'tenant-id-mismatch'),_0x2b7306||await this['beforeStateQueue']['runMiddleware'](_0x23ccda),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x23ccda),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3d6f9f){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x3d6f9f));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x38fc40){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x26355e=this['_getPasswordPolicyInternal']();return _0x26355e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x26355e['validatePassword'](_0x38fc40);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0xed7a27=await Cf(this),_0x163be7=new Sf(_0xed7a27);this['tenantId']===null?this['_projectPasswordPolicy']=_0x163be7:this['_tenantPasswordPolicies'][this['tenantId']]=_0x163be7;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x462866){this['_errorFactory']=new Ut('auth','Firebase',_0x462866());}['onAuthStateChanged'](_0xb85c89,_0x1305e7,_0x446299){return this['registerStateListener'](this['authStateSubscription'],_0xb85c89,_0x1305e7,_0x446299);}['beforeAuthStateChanged'](_0x2a760c,_0x390a27){return this['beforeStateQueue']['pushCallback'](_0x2a760c,_0x390a27);}['onIdTokenChanged'](_0x39e9af,_0x451f6a,_0x5726e5){return this['registerStateListener'](this['idTokenSubscription'],_0x39e9af,_0x451f6a,_0x5726e5);}['authStateReady'](){return new Promise((_0x235171,_0x5c27f7)=>{if(this['currentUser'])_0x235171();else{const _0x3ce287=this['onAuthStateChanged'](()=>{_0x3ce287(),_0x235171();},_0x5c27f7);}});}async['revokeAccessToken'](_0x5c3f9a){if(this['currentUser']){const _0x34f08d=await this['currentUser']['getIdToken'](),_0x57a3cb={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x5c3f9a,'idToken':_0x34f08d};this['tenantId']!=null&&(_0x57a3cb['tenantId']=this['tenantId']),await vf(this,_0x57a3cb);}}['toJSON'](){var _0x4dba77;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x4dba77=this['_currentUser'])==null?void 0x0:_0x4dba77['toJSON']()};}async['_setRedirectUser'](_0x1ae167,_0x515d7b){const _0x55b99f=await this['getOrInitRedirectPersistenceManager'](_0x515d7b);return _0x1ae167===null?_0x55b99f['removeCurrentUser']():_0x55b99f['setCurrentUser'](_0x1ae167);}async['getOrInitRedirectPersistenceManager'](_0x4fbc0b){if(!this['redirectPersistenceManager']){const _0x3e9587=_0x4fbc0b&&ne(_0x4fbc0b)||this['_popupRedirectResolver'];m(_0x3e9587,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x3e9587['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1fb214){var _0x19da97,_0x96ec6b;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x19da97=this['_currentUser'])==null?void 0x0:_0x19da97['_redirectEventId'])===_0x1fb214?this['_currentUser']:((_0x96ec6b=this['redirectUser'])==null?void 0x0:_0x96ec6b['_redirectEventId'])===_0x1fb214?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x122a47){if(_0x122a47===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x122a47));}['_notifyListenersIfCurrent'](_0x381984){_0x381984===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x228b76;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0xdaaf9d=((_0x228b76=this['currentUser'])==null?void 0x0:_0x228b76['uid'])??null;this['lastNotifiedUid']!==_0xdaaf9d&&(this['lastNotifiedUid']=_0xdaaf9d,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1df86a,_0x52c32f,_0x54a8c3,_0x20b431){if(this['_deleted'])return()=>{};const _0x573fbb=typeof _0x52c32f=='function'?_0x52c32f:_0x52c32f['next']['bind'](_0x52c32f);let _0x3a6925=!0x1;const _0xbc9019=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xbc9019,this,'internal-error'),_0xbc9019['then'](()=>{_0x3a6925||_0x573fbb(this['currentUser']);}),typeof _0x52c32f=='function'){const _0x29a5dc=_0x1df86a['addObserver'](_0x52c32f,_0x54a8c3,_0x20b431);return()=>{_0x3a6925=!0x0,_0x29a5dc();};}else{const _0x4633d0=_0x1df86a['addObserver'](_0x52c32f);return()=>{_0x3a6925=!0x0,_0x4633d0();};}}async['directlySetCurrentUser'](_0x45f496){this['currentUser']&&this['currentUser']!==_0x45f496&&this['_currentUser']['_stopProactiveRefresh'](),_0x45f496&&this['isProactiveRefreshEnabled']&&_0x45f496['_startProactiveRefresh'](),this['currentUser']=_0x45f496,_0x45f496?await this['assertedPersistence']['setCurrentUser'](_0x45f496):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x400309){return this['operations']=this['operations']['then'](_0x400309,_0x400309),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x253cc6){!_0x253cc6||this['frameworks']['includes'](_0x253cc6)||(this['frameworks']['push'](_0x253cc6),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x569728;const _0x315418={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x315418['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4d20f8=await((_0x569728=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x569728['getHeartbeatsHeader']());_0x4d20f8&&(_0x315418['X-Firebase-Client']=_0x4d20f8);const _0x5a4a04=await this['_getAppCheckToken']();return _0x5a4a04&&(_0x315418['X-Firebase-AppCheck']=_0x5a4a04),_0x315418;}async['_getAppCheckToken'](){var _0x42992c;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x57ede7=await((_0x42992c=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x42992c['getToken']());return _0x57ede7!=null&&_0x57ede7['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x57ede7['error']),_0x57ede7==null?void 0x0:_0x57ede7['token'];}}function qe(_0x10f4d5){return k(_0x10f4d5);}class Tr{constructor(_0x3b7d5d){this['auth']=_0x3b7d5d,this['observer']=null,this['addObserver']=Ic(_0x32f159=>this['observer']=_0x32f159);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x3c5e93){zn=_0x3c5e93;}function Da(_0x4f3359){return zn['loadJS'](_0x4f3359);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x400a2c){return'__'+_0x400a2c+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x1de0d7){_0x1de0d7();}['execute'](_0x14ec23,_0x1e17b3){return Promise['resolve']('token');}['render'](_0xb53304,_0x2a3317){return'';}}class Of{['ready'](_0x33c74d){_0x33c74d();}['execute'](_0x2bfe05,_0x5cab33){return Promise['resolve']('token');}['render'](_0x5b6ba6,_0x261f6d){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x515147){this['type']=Df,this['auth']=qe(_0x515147);}async['verify'](_0x236738='verify',_0x481567=!0x1){async function _0x53d4ba(_0x59f08e){if(!_0x481567){if(_0x59f08e['tenantId']==null&&_0x59f08e['_agentRecaptchaConfig']!=null)return _0x59f08e['_agentRecaptchaConfig']['siteKey'];if(_0x59f08e['tenantId']!=null&&_0x59f08e['_tenantRecaptchaConfigs'][_0x59f08e['tenantId']]!==void 0x0)return _0x59f08e['_tenantRecaptchaConfigs'][_0x59f08e['tenantId']]['siteKey'];}return new Promise(async(_0x406e5f,_0x57fd2e)=>{uf(_0x59f08e,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1fc937=>{if(_0x1fc937['recaptchaKey']===void 0x0)_0x57fd2e(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x1d5418=new hf(_0x1fc937);return _0x59f08e['tenantId']==null?_0x59f08e['_agentRecaptchaConfig']=_0x1d5418:_0x59f08e['_tenantRecaptchaConfigs'][_0x59f08e['tenantId']]=_0x1d5418,_0x406e5f(_0x1d5418['siteKey']);}})['catch'](_0x4ef79e=>{_0x57fd2e(_0x4ef79e);});});}function _0x4c4355(_0x3eb5bc,_0x3932fe,_0x525b44){const _0x7634d9=window['grecaptcha'];vr(_0x7634d9)?_0x7634d9['enterprise']['ready'](()=>{_0x7634d9['enterprise']['execute'](_0x3eb5bc,{'action':_0x236738})['then'](_0x14a104=>{_0x3932fe(_0x14a104);})['catch'](()=>{_0x3932fe(Ma);});}):_0x525b44(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x365d62,_0x31d12c)=>{_0x53d4ba(this['auth'])['then'](async _0x4cfcc5=>{if(!_0x481567&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x4c4355(_0x4cfcc5,_0x365d62,_0x31d12c);else{if(typeof window>'u'){_0x31d12c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3cd9f3=Af();_0x3cd9f3['length']!==0x0&&(_0x3cd9f3+=_0x4cfcc5+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x9f15b7;(_0x9f15b7=le['scriptInjectionDeferred'])==null||_0x9f15b7['resolve']();},Da(_0x3cd9f3)['then'](()=>{var _0x4ac856;return(_0x4ac856=le['scriptInjectionDeferred'])==null?void 0x0:_0x4ac856['promise'];})['then'](()=>{_0x4c4355(_0x4cfcc5,_0x365d62,_0x31d12c);})['catch'](_0x4a8c6f=>{_0x31d12c(_0x4a8c6f);});}})['catch'](_0x439727=>{_0x31d12c(_0x439727);});});}}le['scriptInjectionDeferred']=null;async function br(_0x476b5f,_0x1724f8,_0x1252be,_0x146014=!0x1,_0x942ff6=!0x1){const _0x13aaf4=new le(_0x476b5f);let _0x552e40;if(_0x942ff6)_0x552e40=Ma;else try{_0x552e40=await _0x13aaf4['verify'](_0x1252be);}catch{_0x552e40=await _0x13aaf4['verify'](_0x1252be,!0x0);}const _0x107b15={..._0x1724f8};if(_0x1252be==='mfaSmsEnrollment'||_0x1252be==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x107b15){const _0xf0a294=_0x107b15['phoneEnrollmentInfo']['phoneNumber'],_0x246918=_0x107b15['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x107b15,{'phoneEnrollmentInfo':{'phoneNumber':_0xf0a294,'recaptchaToken':_0x246918,'captchaResponse':_0x552e40,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x107b15){const _0x41c38f=_0x107b15['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x107b15,{'phoneSignInInfo':{'recaptchaToken':_0x41c38f,'captchaResponse':_0x552e40,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x107b15;}return _0x146014?Object['assign'](_0x107b15,{'captchaResp':_0x552e40}):Object['assign'](_0x107b15,{'captchaResponse':_0x552e40}),Object['assign'](_0x107b15,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x107b15,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x107b15;}async function Oi(_0x1e490c,_0x345df1,_0xe48da1,_0x5b879e,_0xd94455){var _0x10fb68;if((_0x10fb68=_0x1e490c['_getRecaptchaConfig']())!=null&&_0x10fb68['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1e3c2d=await br(_0x1e490c,_0x345df1,_0xe48da1,_0xe48da1==='getOobCode');return _0x5b879e(_0x1e490c,_0x1e3c2d);}else return _0x5b879e(_0x1e490c,_0x345df1)['catch'](async _0x2f4c5d=>{if(_0x2f4c5d['code']==='auth/missing-recaptcha-token'){console['log'](_0xe48da1+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x518efe=await br(_0x1e490c,_0x345df1,_0xe48da1,_0xe48da1==='getOobCode');return _0x5b879e(_0x1e490c,_0x518efe);}else return Promise['reject'](_0x2f4c5d);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x51e383,_0x45a171){const _0x2beb23=Ui(_0x51e383,'auth');if(_0x2beb23['isInitialized']()){const _0x5b2374=_0x2beb23['getImmediate'](),_0x1625fc=_0x2beb23['getOptions']();if(De(_0x1625fc,_0x45a171??{}))return _0x5b2374;K(_0x5b2374,'already-initialized');}return _0x2beb23['initialize']({'options':_0x45a171});}function Lf(_0x2a0a65,_0x2cc740){const _0x43dab3=(_0x2cc740==null?void 0x0:_0x2cc740['persistence'])||[],_0x1e802d=(Array['isArray'](_0x43dab3)?_0x43dab3:[_0x43dab3])['map'](ne);_0x2cc740!=null&&_0x2cc740['errorMap']&&_0x2a0a65['_updateErrorMap'](_0x2cc740['errorMap']),_0x2a0a65['_initializeWithPersistence'](_0x1e802d,_0x2cc740==null?void 0x0:_0x2cc740['popupRedirectResolver']);}function xf(_0x444959,_0x1fc5c0,_0x569c60){const _0x42f902=qe(_0x444959);m(/^https?:\/\//['test'](_0x1fc5c0),_0x42f902,'invalid-emulator-scheme');const _0x2f4c3c=!0x1,_0x16f19a=La(_0x1fc5c0),{host:_0x8b18d2,port:_0x850c7b}=Ff(_0x1fc5c0),_0xcd3b46=_0x850c7b===null?'':':'+_0x850c7b,_0x5f4b47={'url':_0x16f19a+'//'+_0x8b18d2+_0xcd3b46+'/'},_0x3d3284=Object['freeze']({'host':_0x8b18d2,'port':_0x850c7b,'protocol':_0x16f19a['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2f4c3c})});if(!_0x42f902['_canInitEmulator']){m(_0x42f902['config']['emulator']&&_0x42f902['emulatorConfig'],_0x42f902,'emulator-config-failed'),m(De(_0x5f4b47,_0x42f902['config']['emulator'])&&De(_0x3d3284,_0x42f902['emulatorConfig']),_0x42f902,'emulator-config-failed');return;}_0x42f902['config']['emulator']=_0x5f4b47,_0x42f902['emulatorConfig']=_0x3d3284,_0x42f902['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x8b18d2)?jr(_0x16f19a+'//'+_0x8b18d2+_0xcd3b46):Uf();}function La(_0x3e32c7){const _0xffbff9=_0x3e32c7['indexOf'](':');return _0xffbff9<0x0?'':_0x3e32c7['substr'](0x0,_0xffbff9+0x1);}function Ff(_0x57ec12){const _0x4bf48a=La(_0x57ec12),_0x1ab3d5=/(\/\/)?([^?#/]+)/['exec'](_0x57ec12['substr'](_0x4bf48a['length']));if(!_0x1ab3d5)return{'host':'','port':null};const _0x204245=_0x1ab3d5[0x2]['split']('@')['pop']()||'',_0x5f3475=/^(\[[^\]]+\])(:|$)/['exec'](_0x204245);if(_0x5f3475){const _0x5dc475=_0x5f3475[0x1];return{'host':_0x5dc475,'port':Rr(_0x204245['substr'](_0x5dc475['length']+0x1))};}else{const [_0x43d864,_0x33869b]=_0x204245['split'](':');return{'host':_0x43d864,'port':Rr(_0x33869b)};}}function Rr(_0x42f112){if(!_0x42f112)return null;const _0x4d2d5e=Number(_0x42f112);return isNaN(_0x4d2d5e)?null:_0x4d2d5e;}function Uf(){function _0x1809b5(){const _0x474f7f=document['createElement']('p'),_0x2413de=_0x474f7f['style'];_0x474f7f['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2413de['position']='fixed',_0x2413de['width']='100%',_0x2413de['backgroundColor']='#ffffff',_0x2413de['border']='.1em\x20solid\x20#000000',_0x2413de['color']='#b50000',_0x2413de['bottom']='0px',_0x2413de['left']='0px',_0x2413de['margin']='0px',_0x2413de['zIndex']='10000',_0x2413de['textAlign']='center',_0x474f7f['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x474f7f);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1809b5):_0x1809b5());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x4ce3cc,_0x13c41a){this['providerId']=_0x4ce3cc,this['signInMethod']=_0x13c41a;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x15a959){return te('not\x20implemented');}['_linkToIdToken'](_0x2793f7,_0x3f2a8a){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x55092a){return te('not\x20implemented');}}async function Wf(_0x36534a,_0x5f2aff){return Ae(_0x36534a,'POST','/v1/accounts:signUp',_0x5f2aff);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x384c3e,_0x3322cf){return Yt(_0x384c3e,'POST','/v1/accounts:signInWithPassword',Re(_0x384c3e,_0x3322cf));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x2b21c1,_0x529163){return Yt(_0x2b21c1,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2b21c1,_0x529163));}async function Hf(_0x9e9e99,_0x134cba){return Yt(_0x9e9e99,'POST','/v1/accounts:signInWithEmailLink',Re(_0x9e9e99,_0x134cba));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x3c33c2,_0x435b33,_0x20236a,_0x235122=null){super('password',_0x20236a),this['_email']=_0x3c33c2,this['_password']=_0x435b33,this['_tenantId']=_0x235122;}static['_fromEmailAndPassword'](_0x511b72,_0x3ec064){return new Ft(_0x511b72,_0x3ec064,'password');}static['_fromEmailAndCode'](_0x481abc,_0x485b4f,_0x204ee5=null){return new Ft(_0x481abc,_0x485b4f,'emailLink',_0x204ee5);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x5d1956){const _0x2c9ff0=typeof _0x5d1956=='string'?JSON['parse'](_0x5d1956):_0x5d1956;if(_0x2c9ff0!=null&&_0x2c9ff0['email']&&(_0x2c9ff0!=null&&_0x2c9ff0['password'])){if(_0x2c9ff0['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2c9ff0['email'],_0x2c9ff0['password']);if(_0x2c9ff0['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2c9ff0['email'],_0x2c9ff0['password'],_0x2c9ff0['tenantId']);}return null;}async['_getIdTokenResponse'](_0x52a660){switch(this['signInMethod']){case'password':const _0x564fba={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x52a660,_0x564fba,'signInWithPassword',Bf);case'emailLink':return Vf(_0x52a660,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x52a660,'internal-error');}}async['_linkToIdToken'](_0x5bd4ae,_0x400ce3){switch(this['signInMethod']){case'password':const _0x13ff08={'idToken':_0x400ce3,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5bd4ae,_0x13ff08,'signUpPassword',Wf);case'emailLink':return Hf(_0x5bd4ae,{'idToken':_0x400ce3,'email':this['_email'],'oobCode':this['_password']});default:K(_0x5bd4ae,'internal-error');}}['_getReauthenticationResolver'](_0x11c299){return this['_getIdTokenResponse'](_0x11c299);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x542f74,_0x59f249){return Yt(_0x542f74,'POST','/v1/accounts:signInWithIdp',Re(_0x542f74,_0x59f249));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x10629d){const _0x34a7f6=new We(_0x10629d['providerId'],_0x10629d['signInMethod']);return _0x10629d['idToken']||_0x10629d['accessToken']?(_0x10629d['idToken']&&(_0x34a7f6['idToken']=_0x10629d['idToken']),_0x10629d['accessToken']&&(_0x34a7f6['accessToken']=_0x10629d['accessToken']),_0x10629d['nonce']&&!_0x10629d['pendingToken']&&(_0x34a7f6['nonce']=_0x10629d['nonce']),_0x10629d['pendingToken']&&(_0x34a7f6['pendingToken']=_0x10629d['pendingToken'])):_0x10629d['oauthToken']&&_0x10629d['oauthTokenSecret']?(_0x34a7f6['accessToken']=_0x10629d['oauthToken'],_0x34a7f6['secret']=_0x10629d['oauthTokenSecret']):K('argument-error'),_0x34a7f6;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3c1bb1){const _0x56b545=typeof _0x3c1bb1=='string'?JSON['parse'](_0x3c1bb1):_0x3c1bb1,{providerId:_0x44ddda,signInMethod:_0x41a89f,..._0x53569d}=_0x56b545;if(!_0x44ddda||!_0x41a89f)return null;const _0xcb5191=new We(_0x44ddda,_0x41a89f);return _0xcb5191['idToken']=_0x53569d['idToken']||void 0x0,_0xcb5191['accessToken']=_0x53569d['accessToken']||void 0x0,_0xcb5191['secret']=_0x53569d['secret'],_0xcb5191['nonce']=_0x53569d['nonce'],_0xcb5191['pendingToken']=_0x53569d['pendingToken']||null,_0xcb5191;}['_getIdTokenResponse'](_0x104808){const _0x207693=this['buildRequest']();return Ze(_0x104808,_0x207693);}['_linkToIdToken'](_0x503432,_0x3c76b6){const _0x3655a8=this['buildRequest']();return _0x3655a8['idToken']=_0x3c76b6,Ze(_0x503432,_0x3655a8);}['_getReauthenticationResolver'](_0x4d7b9f){const _0x3f8244=this['buildRequest']();return _0x3f8244['autoCreate']=!0x1,Ze(_0x4d7b9f,_0x3f8244);}['buildRequest'](){const _0x3d0b88={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3d0b88['pendingToken']=this['pendingToken'];else{const _0x299014={};this['idToken']&&(_0x299014['id_token']=this['idToken']),this['accessToken']&&(_0x299014['access_token']=this['accessToken']),this['secret']&&(_0x299014['oauth_token_secret']=this['secret']),_0x299014['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x299014['nonce']=this['nonce']),_0x3d0b88['postBody']=at(_0x299014);}return _0x3d0b88;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x3d4483){switch(_0x3d4483){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x303498){const _0x43042e=yt(vt(_0x303498))['link'],_0x14c6e7=_0x43042e?yt(vt(_0x43042e))['deep_link_id']:null,_0x589eb5=yt(vt(_0x303498))['deep_link_id'];return(_0x589eb5?yt(vt(_0x589eb5))['link']:null)||_0x589eb5||_0x14c6e7||_0x43042e||_0x303498;}class Ss{constructor(_0x3cbcfa){const _0x30bdc6=yt(vt(_0x3cbcfa)),_0x561c2d=_0x30bdc6['apiKey']??null,_0x1ff63c=_0x30bdc6['oobCode']??null,_0x3b59fe=Gf(_0x30bdc6['mode']??null);m(_0x561c2d&&_0x1ff63c&&_0x3b59fe,'argument-error'),this['apiKey']=_0x561c2d,this['operation']=_0x3b59fe,this['code']=_0x1ff63c,this['continueUrl']=_0x30bdc6['continueUrl']??null,this['languageCode']=_0x30bdc6['lang']??null,this['tenantId']=_0x30bdc6['tenantId']??null;}static['parseLink'](_0x209f42){const _0x4ea402=qf(_0x209f42);try{return new Ss(_0x4ea402);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x8b54de,_0x2661ed){return Ft['_fromEmailAndPassword'](_0x8b54de,_0x2661ed);}static['credentialWithLink'](_0x5550d6,_0x4427a5){const _0x14e76e=Ss['parseLink'](_0x4427a5);return m(_0x14e76e,'argument-error'),Ft['_fromEmailAndCode'](_0x5550d6,_0x14e76e['code'],_0x14e76e['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x4eda30){this['providerId']=_0x4eda30,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x116b5c){this['defaultLanguageCode']=_0x116b5c;}['setCustomParameters'](_0x119316){return this['customParameters']=_0x119316,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5b8dea){return this['scopes']['includes'](_0x5b8dea)||this['scopes']['push'](_0x5b8dea),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x238a64){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x238a64});}static['credentialFromResult'](_0x456409){return he['credentialFromTaggedObject'](_0x456409);}static['credentialFromError'](_0x3f816d){return he['credentialFromTaggedObject'](_0x3f816d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1894a6}){if(!_0x1894a6||!('oauthAccessToken'in _0x1894a6)||!_0x1894a6['oauthAccessToken'])return null;try{return he['credential'](_0x1894a6['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1435a9,_0x483d5f){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1435a9,'accessToken':_0x483d5f});}static['credentialFromResult'](_0x471d6d){return ue['credentialFromTaggedObject'](_0x471d6d);}static['credentialFromError'](_0x4a871e){return ue['credentialFromTaggedObject'](_0x4a871e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x415c83}){if(!_0x415c83)return null;const {oauthIdToken:_0x59ac12,oauthAccessToken:_0x1004ff}=_0x415c83;if(!_0x59ac12&&!_0x1004ff)return null;try{return ue['credential'](_0x59ac12,_0x1004ff);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x1fb0cb){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1fb0cb});}static['credentialFromResult'](_0x88f605){return de['credentialFromTaggedObject'](_0x88f605);}static['credentialFromError'](_0x358bdd){return de['credentialFromTaggedObject'](_0x358bdd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xfb6330}){if(!_0xfb6330||!('oauthAccessToken'in _0xfb6330)||!_0xfb6330['oauthAccessToken'])return null;try{return de['credential'](_0xfb6330['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x45b89c,_0x1763bb){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x45b89c,'oauthTokenSecret':_0x1763bb});}static['credentialFromResult'](_0x45effa){return fe['credentialFromTaggedObject'](_0x45effa);}static['credentialFromError'](_0x40d936){return fe['credentialFromTaggedObject'](_0x40d936['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x90e716}){if(!_0x90e716)return null;const {oauthAccessToken:_0x274030,oauthTokenSecret:_0x29b58f}=_0x90e716;if(!_0x274030||!_0x29b58f)return null;try{return fe['credential'](_0x274030,_0x29b58f);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x38e04d,_0x110f98){return Yt(_0x38e04d,'POST','/v1/accounts:signUp',Re(_0x38e04d,_0x110f98));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x25ba77){this['user']=_0x25ba77['user'],this['providerId']=_0x25ba77['providerId'],this['_tokenResponse']=_0x25ba77['_tokenResponse'],this['operationType']=_0x25ba77['operationType'];}static async['_fromIdTokenResponse'](_0x16b525,_0x61cdb3,_0x1ce1f0,_0x277159=!0x1){const _0x51851e=await z['_fromIdTokenResponse'](_0x16b525,_0x1ce1f0,_0x277159),_0x14fb1f=Ar(_0x1ce1f0);return new Be({'user':_0x51851e,'providerId':_0x14fb1f,'_tokenResponse':_0x1ce1f0,'operationType':_0x61cdb3});}static async['_forOperation'](_0x36361a,_0x325fbf,_0x370c11){await _0x36361a['_updateTokensIfNecessary'](_0x370c11,!0x0);const _0xe30e53=Ar(_0x370c11);return new Be({'user':_0x36361a,'providerId':_0xe30e53,'_tokenResponse':_0x370c11,'operationType':_0x325fbf});}}function Ar(_0x3b2db0){return _0x3b2db0['providerId']?_0x3b2db0['providerId']:'phoneNumber'in _0x3b2db0?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x39fb34,_0x34701f,_0x1ec318,_0x2ed723){super(_0x34701f['code'],_0x34701f['message']),this['operationType']=_0x1ec318,this['user']=_0x2ed723,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x39fb34['name'],'tenantId':_0x39fb34['tenantId']??void 0x0,'_serverResponse':_0x34701f['customData']['_serverResponse'],'operationType':_0x1ec318};}static['_fromErrorAndOperation'](_0x5c17c4,_0xe80480,_0x546bc5,_0x1ba1c7){return new Rn(_0x5c17c4,_0xe80480,_0x546bc5,_0x1ba1c7);}}function Fa(_0x52a859,_0x5d6e2d,_0x38996d,_0x1ec028){return(_0x5d6e2d==='reauthenticate'?_0x38996d['_getReauthenticationResolver'](_0x52a859):_0x38996d['_getIdTokenResponse'](_0x52a859))['catch'](_0x384983=>{throw _0x384983['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x52a859,_0x384983,_0x5d6e2d,_0x1ec028):_0x384983;});}async function jf(_0xebd032,_0x241cd2,_0x2531cd=!0x1){const _0xde95c0=await xt(_0xebd032,_0x241cd2['_linkToIdToken'](_0xebd032['auth'],await _0xebd032['getIdToken']()),_0x2531cd);return Be['_forOperation'](_0xebd032,'link',_0xde95c0);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x355542,_0x46bb83,_0xa174e8=!0x1){const {auth:_0x1cb2bb}=_0x355542;if(H(_0x1cb2bb['app']))return Promise['reject'](se(_0x1cb2bb));const _0x4f5869='reauthenticate';try{const _0x2805f2=await xt(_0x355542,Fa(_0x1cb2bb,_0x4f5869,_0x46bb83,_0x355542),_0xa174e8);m(_0x2805f2['idToken'],_0x1cb2bb,'internal-error');const _0xeb9f4e=ws(_0x2805f2['idToken']);m(_0xeb9f4e,_0x1cb2bb,'internal-error');const {sub:_0x2af2b9}=_0xeb9f4e;return m(_0x355542['uid']===_0x2af2b9,_0x1cb2bb,'user-mismatch'),Be['_forOperation'](_0x355542,_0x4f5869,_0x2805f2);}catch(_0xb76196){throw(_0xb76196==null?void 0x0:_0xb76196['code'])==='auth/user-not-found'&&K(_0x1cb2bb,'user-mismatch'),_0xb76196;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4d2138,_0x16915b,_0x321c90=!0x1){if(H(_0x4d2138['app']))return Promise['reject'](se(_0x4d2138));const _0x19c3b9='signIn',_0x282bdf=await Fa(_0x4d2138,_0x19c3b9,_0x16915b),_0xf3c5c9=await Be['_fromIdTokenResponse'](_0x4d2138,_0x19c3b9,_0x282bdf);return _0x321c90||await _0x4d2138['_updateCurrentUser'](_0xf3c5c9['user']),_0xf3c5c9;}async function Yf(_0x294c76,_0x5acee4){return Ua(qe(_0x294c76),_0x5acee4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x7b4ce2){const _0x5596fe=qe(_0x7b4ce2);_0x5596fe['_getPasswordPolicyInternal']()&&await _0x5596fe['_updatePasswordPolicy']();}async function R_(_0x24da88,_0x49a3df,_0x4afe29){if(H(_0x24da88['app']))return Promise['reject'](se(_0x24da88));const _0x530bb1=qe(_0x24da88),_0x2b984d=await Oi(_0x530bb1,{'returnSecureToken':!0x0,'email':_0x49a3df,'password':_0x4afe29,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x35f185=>{throw _0x35f185['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x24da88),_0x35f185;}),_0xbede5=await Be['_fromIdTokenResponse'](_0x530bb1,'signIn',_0x2b984d);return await _0x530bb1['_updateCurrentUser'](_0xbede5['user']),_0xbede5;}function A_(_0x1b9b50,_0x2a98f5,_0x18c405){return H(_0x1b9b50['app'])?Promise['reject'](se(_0x1b9b50)):Yf(k(_0x1b9b50),ft['credential'](_0x2a98f5,_0x18c405))['catch'](async _0x35fab6=>{throw _0x35fab6['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x1b9b50),_0x35fab6;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x11224c,_0xbb1bf1){return k(_0x11224c)['setPersistence'](_0xbb1bf1);}function Qf(_0x4563f6,_0x5c5e2b,_0x2756cc,_0x675bdf){return k(_0x4563f6)['onIdTokenChanged'](_0x5c5e2b,_0x2756cc,_0x675bdf);}function Jf(_0x286f27,_0xc8de9d,_0x394a6f){return k(_0x286f27)['beforeAuthStateChanged'](_0xc8de9d,_0x394a6f);}function N_(_0x30d4a1,_0x16dd1d,_0x5f1824,_0x4d6405){return k(_0x30d4a1)['onAuthStateChanged'](_0x16dd1d,_0x5f1824,_0x4d6405);}function P_(_0x47fa0d){return k(_0x47fa0d)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x453199,_0x20d428){this['storageRetriever']=_0x453199,this['type']=_0x20d428;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5bce5d,_0x759c87){return this['storage']['setItem'](_0x5bce5d,JSON['stringify'](_0x759c87)),Promise['resolve']();}['_get'](_0x3c8523){const _0xbb58b7=this['storage']['getItem'](_0x3c8523);return Promise['resolve'](_0xbb58b7?JSON['parse'](_0xbb58b7):null);}['_remove'](_0x2f177d){return this['storage']['removeItem'](_0x2f177d),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3cb6ba,_0x3c8a43)=>this['onStorageEvent'](_0x3cb6ba,_0x3c8a43),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x40d5a2){for(const _0x529773 of Object['keys'](this['listeners'])){const _0x94660e=this['storage']['getItem'](_0x529773),_0x35fc7f=this['localCache'][_0x529773];_0x94660e!==_0x35fc7f&&_0x40d5a2(_0x529773,_0x35fc7f,_0x94660e);}}['onStorageEvent'](_0x5cadea,_0x31912a=!0x1){if(!_0x5cadea['key']){this['forAllChangedKeys']((_0x14cb92,_0x5003cb,_0x2a9a6f)=>{this['notifyListeners'](_0x14cb92,_0x2a9a6f);});return;}const _0x4fe6fc=_0x5cadea['key'];_0x31912a?this['detachListener']():this['stopPolling']();const _0x56d694=()=>{const _0x4cc0d1=this['storage']['getItem'](_0x4fe6fc);!_0x31912a&&this['localCache'][_0x4fe6fc]===_0x4cc0d1||this['notifyListeners'](_0x4fe6fc,_0x4cc0d1);},_0x589b78=this['storage']['getItem'](_0x4fe6fc);If()&&_0x589b78!==_0x5cadea['newValue']&&_0x5cadea['newValue']!==_0x5cadea['oldValue']?setTimeout(_0x56d694,Zf):_0x56d694();}['notifyListeners'](_0x2c2f1b,_0x2310a2){this['localCache'][_0x2c2f1b]=_0x2310a2;const _0x508078=this['listeners'][_0x2c2f1b];if(_0x508078){for(const _0x413b85 of Array['from'](_0x508078))_0x413b85(_0x2310a2&&JSON['parse'](_0x2310a2));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3a3131,_0x51080a,_0x1c6ab9)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3a3131,'oldValue':_0x51080a,'newValue':_0x1c6ab9}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x1cd49f,_0x3bc2f3){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x1cd49f]||(this['listeners'][_0x1cd49f]=new Set(),this['localCache'][_0x1cd49f]=this['storage']['getItem'](_0x1cd49f)),this['listeners'][_0x1cd49f]['add'](_0x3bc2f3);}['_removeListener'](_0x30f8ce,_0x419177){this['listeners'][_0x30f8ce]&&(this['listeners'][_0x30f8ce]['delete'](_0x419177),this['listeners'][_0x30f8ce]['size']===0x0&&delete this['listeners'][_0x30f8ce]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4d484f,_0x5e5d87){await super['_set'](_0x4d484f,_0x5e5d87),this['localCache'][_0x4d484f]=JSON['stringify'](_0x5e5d87);}async['_get'](_0x320bf1){const _0x3adf35=await super['_get'](_0x320bf1);return this['localCache'][_0x320bf1]=JSON['stringify'](_0x3adf35),_0x3adf35;}async['_remove'](_0x1290a1){await super['_remove'](_0x1290a1),delete this['localCache'][_0x1290a1];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x39a9e8,_0x141ecb){}['_removeListener'](_0x5b88a5,_0x5be8d6){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x3ae940){return Promise['all'](_0x3ae940['map'](async _0x23bc77=>{try{return{'fulfilled':!0x0,'value':await _0x23bc77};}catch(_0x10b78a){return{'fulfilled':!0x1,'reason':_0x10b78a};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0xe15573){this['eventTarget']=_0xe15573,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2e0016){const _0x55df31=this['receivers']['find'](_0x2d6518=>_0x2d6518['isListeningto'](_0x2e0016));if(_0x55df31)return _0x55df31;const _0x699939=new jn(_0x2e0016);return this['receivers']['push'](_0x699939),_0x699939;}['isListeningto'](_0x228371){return this['eventTarget']===_0x228371;}async['handleEvent'](_0x13de83){const _0x127da2=_0x13de83,{eventId:_0x284557,eventType:_0x2010c5,data:_0xe92314}=_0x127da2['data'],_0x2fd0ea=this['handlersMap'][_0x2010c5];if(!(_0x2fd0ea!=null&&_0x2fd0ea['size']))return;_0x127da2['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x284557,'eventType':_0x2010c5});const _0x19f503=Array['from'](_0x2fd0ea)['map'](async _0x4e2d94=>_0x4e2d94(_0x127da2['origin'],_0xe92314)),_0x577f18=await tp(_0x19f503);_0x127da2['ports'][0x0]['postMessage']({'status':'done','eventId':_0x284557,'eventType':_0x2010c5,'response':_0x577f18});}['_subscribe'](_0x157e79,_0x52a6fd){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x157e79]||(this['handlersMap'][_0x157e79]=new Set()),this['handlersMap'][_0x157e79]['add'](_0x52a6fd);}['_unsubscribe'](_0x3df208,_0x23279a){this['handlersMap'][_0x3df208]&&_0x23279a&&this['handlersMap'][_0x3df208]['delete'](_0x23279a),(!_0x23279a||this['handlersMap'][_0x3df208]['size']===0x0)&&delete this['handlersMap'][_0x3df208],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x2e2e9d='',_0x5505f8=0xa){let _0xe3616d='';for(let _0x2f4f5f=0x0;_0x2f4f5f<_0x5505f8;_0x2f4f5f++)_0xe3616d+=Math['floor'](Math['random']()*0xa);return _0x2e2e9d+_0xe3616d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x231a5e){this['target']=_0x231a5e,this['handlers']=new Set();}['removeMessageHandler'](_0x47cf85){_0x47cf85['messageChannel']&&(_0x47cf85['messageChannel']['port1']['removeEventListener']('message',_0x47cf85['onMessage']),_0x47cf85['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x47cf85);}async['_send'](_0x395c96,_0x109558,_0x452ad5=0x32){const _0x3cb6ab=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3cb6ab)throw new Error('connection_unavailable');let _0x57a353,_0x116983;return new Promise((_0x4574cb,_0x30d0df)=>{const _0x133644=bs('',0x14);_0x3cb6ab['port1']['start']();const _0x236cdb=setTimeout(()=>{_0x30d0df(new Error('unsupported_event'));},_0x452ad5);_0x116983={'messageChannel':_0x3cb6ab,'onMessage'(_0x4e3018){const _0x449461=_0x4e3018;if(_0x449461['data']['eventId']===_0x133644)switch(_0x449461['data']['status']){case'ack':clearTimeout(_0x236cdb),_0x57a353=setTimeout(()=>{_0x30d0df(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x57a353),_0x4574cb(_0x449461['data']['response']);break;default:clearTimeout(_0x236cdb),clearTimeout(_0x57a353),_0x30d0df(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x116983),_0x3cb6ab['port1']['addEventListener']('message',_0x116983['onMessage']),this['target']['postMessage']({'eventType':_0x395c96,'eventId':_0x133644,'data':_0x109558},[_0x3cb6ab['port2']]);})['finally'](()=>{_0x116983&&this['removeMessageHandler'](_0x116983);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x32cdca){X()['location']['href']=_0x32cdca;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x53f3e1;return((_0x53f3e1=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x53f3e1['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x234888){this['request']=_0x234888;}['toPromise'](){return new Promise((_0x2993b5,_0x370df4)=>{this['request']['addEventListener']('success',()=>{_0x2993b5(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x370df4(this['request']['error']);});});}}function Kn(_0xc16aa4,_0x972256){return _0xc16aa4['transaction']([kn],_0x972256?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x8d06e4=indexedDB['deleteDatabase'](qa);return new Jt(_0x8d06e4)['toPromise']();}function ja(){const _0x4afed8=indexedDB['open'](qa,ap);return new Promise((_0x40fa9d,_0x13eaf7)=>{_0x4afed8['addEventListener']('error',()=>{_0x13eaf7(_0x4afed8['error']);}),_0x4afed8['addEventListener']('upgradeneeded',()=>{const _0x1d0530=_0x4afed8['result'];try{_0x1d0530['createObjectStore'](kn,{'keyPath':za});}catch(_0x4922e8){_0x13eaf7(_0x4922e8);}}),_0x4afed8['addEventListener']('success',async()=>{const _0x50e98b=_0x4afed8['result'];_0x50e98b['objectStoreNames']['contains'](kn)?_0x40fa9d(_0x50e98b):(_0x50e98b['close'](),await cp(),_0x40fa9d(await ja()));});});}async function kr(_0x1b8e4d,_0x25c01e,_0x377573){const _0x30d28a=Kn(_0x1b8e4d,!0x0)['put']({[za]:_0x25c01e,'value':_0x377573});return new Jt(_0x30d28a)['toPromise']();}async function lp(_0x3194c3,_0x1abeaa){const _0x46aa11=Kn(_0x3194c3,!0x1)['get'](_0x1abeaa),_0x380c09=await new Jt(_0x46aa11)['toPromise']();return _0x380c09===void 0x0?null:_0x380c09['value'];}function Nr(_0x3e4a5c,_0xd4a76a){const _0x3effdd=Kn(_0x3e4a5c,!0x0)['delete'](_0xd4a76a);return new Jt(_0x3effdd)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x3aa93c){let _0x44527b=0x0;for(;;)try{const _0x3006d6=await this['_openDb']();return await _0x3aa93c(_0x3006d6);}catch(_0x4053cc){if(_0x44527b++>up)throw _0x4053cc;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x1403d5,_0x105914)=>({'keyProcessed':(await this['_poll']())['includes'](_0x105914['key'])})),this['receiver']['_subscribe']('ping',async(_0xb50189,_0x12a32e)=>['keyChanged']);}async['initializeSender'](){var _0x181322,_0x2db668;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x302410=await this['sender']['_send']('ping',{},0x320);_0x302410&&(_0x181322=_0x302410[0x0])!=null&&_0x181322['fulfilled']&&(_0x2db668=_0x302410[0x0])!=null&&_0x2db668['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2fcc7c){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2fcc7c},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x221093=>{await kr(_0x221093,An,'1'),await Nr(_0x221093,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x1012a7){this['pendingWrites']++;try{await _0x1012a7();}finally{this['pendingWrites']--;}}async['_set'](_0x52e17c,_0x5b214f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1fc439=>kr(_0x1fc439,_0x52e17c,_0x5b214f)),this['localCache'][_0x52e17c]=_0x5b214f,this['notifyServiceWorker'](_0x52e17c)));}async['_get'](_0x3296fa){const _0x121536=await this['_withRetries'](_0x59b9bd=>lp(_0x59b9bd,_0x3296fa));return this['localCache'][_0x3296fa]=_0x121536,_0x121536;}async['_remove'](_0x129ac2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x15c17e=>Nr(_0x15c17e,_0x129ac2)),delete this['localCache'][_0x129ac2],this['notifyServiceWorker'](_0x129ac2)));}async['_poll'](){const _0x24f200=await this['_withRetries'](_0x104e75=>{const _0x391210=Kn(_0x104e75,!0x1)['getAll']();return new Jt(_0x391210)['toPromise']();});if(!_0x24f200)return[];if(this['pendingWrites']!==0x0)return[];const _0x32985a=[],_0x253eac=new Set();if(_0x24f200['length']!==0x0){for(const {fbase_key:_0x483586,value:_0x5527d9}of _0x24f200)_0x253eac['add'](_0x483586),JSON['stringify'](this['localCache'][_0x483586])!==JSON['stringify'](_0x5527d9)&&(this['notifyListeners'](_0x483586,_0x5527d9),_0x32985a['push'](_0x483586));}for(const _0x261c9e of Object['keys'](this['localCache']))this['localCache'][_0x261c9e]&&!_0x253eac['has'](_0x261c9e)&&(this['notifyListeners'](_0x261c9e,null),_0x32985a['push'](_0x261c9e));return _0x32985a;}['notifyListeners'](_0x1de0a2,_0x56744e){this['localCache'][_0x1de0a2]=_0x56744e;const _0x465326=this['listeners'][_0x1de0a2];if(_0x465326){for(const _0x480c2b of Array['from'](_0x465326))_0x480c2b(_0x56744e);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x1f21ad,_0x576e3d){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x1f21ad]||(this['listeners'][_0x1f21ad]=new Set(),this['_get'](_0x1f21ad)),this['listeners'][_0x1f21ad]['add'](_0x576e3d);}['_removeListener'](_0x5644cf,_0x106772){this['listeners'][_0x5644cf]&&(this['listeners'][_0x5644cf]['delete'](_0x106772),this['listeners'][_0x5644cf]['size']===0x0&&delete this['listeners'][_0x5644cf]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x11b424,_0x546c93){return _0x546c93?ne(_0x546c93):(m(_0x11b424['_popupRedirectResolver'],_0x11b424,'argument-error'),_0x11b424['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x525814){super('custom','custom'),this['params']=_0x525814;}['_getIdTokenResponse'](_0x23a622){return Ze(_0x23a622,this['_buildIdpRequest']());}['_linkToIdToken'](_0x262324,_0x1b3c55){return Ze(_0x262324,this['_buildIdpRequest'](_0x1b3c55));}['_getReauthenticationResolver'](_0x10c3fe){return Ze(_0x10c3fe,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x133ba9){const _0x1d8e33={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x133ba9&&(_0x1d8e33['idToken']=_0x133ba9),_0x1d8e33;}}function pp(_0x4f92fd){return Ua(_0x4f92fd['auth'],new Rs(_0x4f92fd),_0x4f92fd['bypassAuthState']);}function _p(_0x3a1a40){const {auth:_0x553ab,user:_0x3c10f8}=_0x3a1a40;return m(_0x3c10f8,_0x553ab,'internal-error'),Kf(_0x3c10f8,new Rs(_0x3a1a40),_0x3a1a40['bypassAuthState']);}async function gp(_0xa695e3){const {auth:_0xc3e242,user:_0x17c5b7}=_0xa695e3;return m(_0x17c5b7,_0xc3e242,'internal-error'),jf(_0x17c5b7,new Rs(_0xa695e3),_0xa695e3['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x17d7c4,_0x4a65c7,_0x2598d6,_0x15fbc2,_0x2d1865=!0x1){this['auth']=_0x17d7c4,this['resolver']=_0x2598d6,this['user']=_0x15fbc2,this['bypassAuthState']=_0x2d1865,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4a65c7)?_0x4a65c7:[_0x4a65c7];}['execute'](){return new Promise(async(_0x329598,_0x3112b2)=>{this['pendingPromise']={'resolve':_0x329598,'reject':_0x3112b2};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3e1a62){this['reject'](_0x3e1a62);}});}async['onAuthEvent'](_0x1ba82a){const {urlResponse:_0x29fe08,sessionId:_0x45d9c3,postBody:_0x4dfe8b,tenantId:_0x240c09,error:_0x345504,type:_0x5a7ba7}=_0x1ba82a;if(_0x345504){this['reject'](_0x345504);return;}const _0x2a17d5={'auth':this['auth'],'requestUri':_0x29fe08,'sessionId':_0x45d9c3,'tenantId':_0x240c09||void 0x0,'postBody':_0x4dfe8b||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5a7ba7)(_0x2a17d5));}catch(_0x4cdc5f){this['reject'](_0x4cdc5f);}}['onError'](_0x5b954b){this['reject'](_0x5b954b);}['getIdpTask'](_0x23f881){switch(_0x23f881){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x570387){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x570387),this['unregisterAndCleanUp']();}['reject'](_0x219de9){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x219de9),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x4b656d,_0x277db5,_0x2b938b,_0x1275c5,_0x4b7d8a){super(_0x4b656d,_0x277db5,_0x1275c5,_0x4b7d8a),this['provider']=_0x2b938b,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x52e774=await this['execute']();return m(_0x52e774,this['auth'],'internal-error'),_0x52e774;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3a8dcd=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3a8dcd),this['authWindow']['associatedEvent']=_0x3a8dcd,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1ca6f7=>{this['reject'](_0x1ca6f7);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x4529a3=>{_0x4529a3||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x39ec89;return((_0x39ec89=this['authWindow'])==null?void 0x0:_0x39ec89['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2dc8a0=()=>{var _0xdec986,_0x30a693;if((_0x30a693=(_0xdec986=this['authWindow'])==null?void 0x0:_0xdec986['window'])!=null&&_0x30a693['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2dc8a0,mp['get']());};_0x2dc8a0();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x430877,_0x1d93e7,_0x3cacce=!0x1){super(_0x430877,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x1d93e7,void 0x0,_0x3cacce),this['eventId']=null;}async['execute'](){let _0x4a6a5d=rn['get'](this['auth']['_key']());if(!_0x4a6a5d){try{const _0x1d4145=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x4a6a5d=()=>Promise['resolve'](_0x1d4145);}catch(_0x40e006){_0x4a6a5d=()=>Promise['reject'](_0x40e006);}rn['set'](this['auth']['_key'](),_0x4a6a5d);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4a6a5d();}async['onAuthEvent'](_0x1e16e4){if(_0x1e16e4['type']==='signInViaRedirect')return super['onAuthEvent'](_0x1e16e4);if(_0x1e16e4['type']==='unknown'){this['resolve'](null);return;}if(_0x1e16e4['eventId']){const _0x4378c5=await this['auth']['_redirectUserForId'](_0x1e16e4['eventId']);if(_0x4378c5)return this['user']=_0x4378c5,super['onAuthEvent'](_0x1e16e4);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x35bcec,_0x1d0739){const _0x1d2fe9=Cp(_0x1d0739),_0x256956=wp(_0x35bcec);if(!await _0x256956['_isAvailable']())return!0x1;const _0x2d2649=await _0x256956['_get'](_0x1d2fe9)==='true';return await _0x256956['_remove'](_0x1d2fe9),_0x2d2649;}function Ip(_0x3e3aae,_0x7856ff){rn['set'](_0x3e3aae['_key'](),_0x7856ff);}function wp(_0x515aa1){return ne(_0x515aa1['_redirectPersistence']);}function Cp(_0x587e01){return sn(yp,_0x587e01['config']['apiKey'],_0x587e01['name']);}async function Tp(_0x3fea7c,_0x2049d8,_0x36dd17=!0x1){if(H(_0x3fea7c['app']))return Promise['reject'](se(_0x3fea7c));const _0x479774=qe(_0x3fea7c),_0x58f643=fp(_0x479774,_0x2049d8),_0x30cc78=await new vp(_0x479774,_0x58f643,_0x36dd17)['execute']();return _0x30cc78&&!_0x36dd17&&(delete _0x30cc78['user']['_redirectEventId'],await _0x479774['_persistUserIfCurrent'](_0x30cc78['user']),await _0x479774['_setRedirectUser'](null,_0x2049d8)),_0x30cc78;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x3ede4e){this['auth']=_0x3ede4e,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x16baf5){this['consumers']['add'](_0x16baf5),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x16baf5)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x16baf5),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1b2be5){this['consumers']['delete'](_0x1b2be5);}['onEvent'](_0x40cf6a){if(this['hasEventBeenHandled'](_0x40cf6a))return!0x1;let _0x34135e=!0x1;return this['consumers']['forEach'](_0x278dea=>{this['isEventForConsumer'](_0x40cf6a,_0x278dea)&&(_0x34135e=!0x0,this['sendToConsumer'](_0x40cf6a,_0x278dea),this['saveEventToCache'](_0x40cf6a));}),this['hasHandledPotentialRedirect']||!Rp(_0x40cf6a)||(this['hasHandledPotentialRedirect']=!0x0,_0x34135e||(this['queuedRedirectEvent']=_0x40cf6a,_0x34135e=!0x0)),_0x34135e;}['sendToConsumer'](_0x279d7e,_0x3f284d){var _0x502d64;if(_0x279d7e['error']&&!Qa(_0x279d7e)){const _0x550b53=((_0x502d64=_0x279d7e['error']['code'])==null?void 0x0:_0x502d64['split']('auth/')[0x1])||'internal-error';_0x3f284d['onError'](J(this['auth'],_0x550b53));}else _0x3f284d['onAuthEvent'](_0x279d7e);}['isEventForConsumer'](_0x2097d4,_0x224782){const _0xfe3afa=_0x224782['eventId']===null||!!_0x2097d4['eventId']&&_0x2097d4['eventId']===_0x224782['eventId'];return _0x224782['filter']['includes'](_0x2097d4['type'])&&_0xfe3afa;}['hasEventBeenHandled'](_0x5101b2){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x5101b2));}['saveEventToCache'](_0x1e0c82){this['cachedEventUids']['add'](Pr(_0x1e0c82)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x38cc6a){return[_0x38cc6a['type'],_0x38cc6a['eventId'],_0x38cc6a['sessionId'],_0x38cc6a['tenantId']]['filter'](_0x449a26=>_0x449a26)['join']('-');}function Qa({type:_0x574fae,error:_0x243cc9}){return _0x574fae==='unknown'&&(_0x243cc9==null?void 0x0:_0x243cc9['code'])==='auth/no-auth-event';}function Rp(_0x4cda8e){switch(_0x4cda8e['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x4cda8e);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x2c5dc,_0x113794={}){return Ae(_0x2c5dc,'GET','/v1/projects',_0x113794);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x2b25e8){if(_0x2b25e8['config']['emulator'])return;const {authorizedDomains:_0x3387b9}=await Ap(_0x2b25e8);for(const _0xf8cf7a of _0x3387b9)try{if(Op(_0xf8cf7a))return;}catch{}K(_0x2b25e8,'unauthorized-domain');}function Op(_0x35e135){const _0x51616b=Ni(),{protocol:_0x15cec6,hostname:_0x2f26ad}=new URL(_0x51616b);if(_0x35e135['startsWith']('chrome-extension://')){const _0x23aa35=new URL(_0x35e135);return _0x23aa35['hostname']===''&&_0x2f26ad===''?_0x15cec6==='chrome-extension:'&&_0x35e135['replace']('chrome-extension://','')===_0x51616b['replace']('chrome-extension://',''):_0x15cec6==='chrome-extension:'&&_0x23aa35['hostname']===_0x2f26ad;}if(!Np['test'](_0x15cec6))return!0x1;if(kp['test'](_0x35e135))return _0x2f26ad===_0x35e135;const _0x1b7e1a=_0x35e135['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x1b7e1a+'|'+_0x1b7e1a+')$','i')['test'](_0x2f26ad);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x4230ab=X()['___jsl'];if(_0x4230ab!=null&&_0x4230ab['H']){for(const _0x4647fa of Object['keys'](_0x4230ab['H']))if(_0x4230ab['H'][_0x4647fa]['r']=_0x4230ab['H'][_0x4647fa]['r']||[],_0x4230ab['H'][_0x4647fa]['L']=_0x4230ab['H'][_0x4647fa]['L']||[],_0x4230ab['H'][_0x4647fa]['r']=[..._0x4230ab['H'][_0x4647fa]['L']],_0x4230ab['CP']){for(let _0x5aac4f=0x0;_0x5aac4f<_0x4230ab['CP']['length'];_0x5aac4f++)_0x4230ab['CP'][_0x5aac4f]=null;}}}function Mp(_0x488d15){return new Promise((_0x1e4a00,_0x1769c7)=>{var _0x5952bb,_0x58dfce,_0x5f0c32;function _0x28f159(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1e4a00(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x1769c7(J(_0x488d15,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x58dfce=(_0x5952bb=X()['gapi'])==null?void 0x0:_0x5952bb['iframes'])!=null&&_0x58dfce['Iframe'])_0x1e4a00(gapi['iframes']['getContext']());else{if((_0x5f0c32=X()['gapi'])!=null&&_0x5f0c32['load'])_0x28f159();else{const _0x2d87f6=Nf('iframefcb');return X()[_0x2d87f6]=()=>{gapi['load']?_0x28f159():_0x1769c7(J(_0x488d15,'network-request-failed'));},Da(kf()+'?onload='+_0x2d87f6)['catch'](_0x193b47=>_0x1769c7(_0x193b47));}}})['catch'](_0x1f13d7=>{throw on=null,_0x1f13d7;});}let on=null;function Lp(_0x603c9d){return on=on||Mp(_0x603c9d),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x3cae44){const _0x86260c=_0x3cae44['config'];m(_0x86260c['authDomain'],_0x3cae44,'auth-domain-config-required');const _0x2277bb=_0x86260c['emulator']?Is(_0x86260c,Up):'https://'+_0x3cae44['config']['authDomain']+'/'+Fp,_0x2e5e84={'apiKey':_0x86260c['apiKey'],'appName':_0x3cae44['name'],'v':ct},_0x55412b=Bp['get'](_0x3cae44['config']['apiHost']);_0x55412b&&(_0x2e5e84['eid']=_0x55412b);const _0xbbda21=_0x3cae44['_getFrameworks']();return _0xbbda21['length']&&(_0x2e5e84['fw']=_0xbbda21['join'](',')),_0x2277bb+'?'+at(_0x2e5e84)['slice'](0x1);}async function Hp(_0x5e631f){const _0x5d15a9=await Lp(_0x5e631f),_0x5c3489=X()['gapi'];return m(_0x5c3489,_0x5e631f,'internal-error'),_0x5d15a9['open']({'where':document['body'],'url':Vp(_0x5e631f),'messageHandlersFilter':_0x5c3489['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x68a8a2=>new Promise(async(_0x1f94cb,_0x194d4e)=>{await _0x68a8a2['restyle']({'setHideOnLeave':!0x1});const _0x1a139c=J(_0x5e631f,'network-request-failed'),_0x4cc816=X()['setTimeout'](()=>{_0x194d4e(_0x1a139c);},xp['get']());function _0x13f3c1(){X()['clearTimeout'](_0x4cc816),_0x1f94cb(_0x68a8a2);}_0x68a8a2['ping'](_0x13f3c1)['then'](_0x13f3c1,()=>{_0x194d4e(_0x1a139c);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x3b5940){this['window']=_0x3b5940,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x39bf3b,_0x5f386e,_0x278ed9,_0x2e23b8=Gp,_0x4966d6=qp){const _0x513319=Math['max']((window['screen']['availHeight']-_0x4966d6)/0x2,0x0)['toString'](),_0x431040=Math['max']((window['screen']['availWidth']-_0x2e23b8)/0x2,0x0)['toString']();let _0x4528b7='';const _0x3d45ad={...$p,'width':_0x2e23b8['toString'](),'height':_0x4966d6['toString'](),'top':_0x513319,'left':_0x431040},_0x266003=W()['toLowerCase']();_0x278ed9&&(_0x4528b7=ba(_0x266003)?zp:_0x278ed9),Ta(_0x266003)&&(_0x5f386e=_0x5f386e||jp,_0x3d45ad['scrollbars']='yes');const _0x522903=Object['entries'](_0x3d45ad)['reduce']((_0x19df1a,[_0x39fda7,_0x183e81])=>''+_0x19df1a+_0x39fda7+'='+_0x183e81+',','');if(Ef(_0x266003)&&_0x4528b7!=='_self')return Yp(_0x5f386e||'',_0x4528b7),new Dr(null);const _0x4790b4=window['open'](_0x5f386e||'',_0x4528b7,_0x522903);m(_0x4790b4,_0x39bf3b,'popup-blocked');try{_0x4790b4['focus']();}catch{}return new Dr(_0x4790b4);}function Yp(_0x1156d6,_0xbab519){const _0x36292d=document['createElement']('a');_0x36292d['href']=_0x1156d6,_0x36292d['target']=_0xbab519;const _0xbf8bf2=document['createEvent']('MouseEvent');_0xbf8bf2['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x36292d['dispatchEvent'](_0xbf8bf2);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x21382c,_0x5c7101,_0x3481bf,_0x1b0b8e,_0x28e0b7,_0x2d1228){m(_0x21382c['config']['authDomain'],_0x21382c,'auth-domain-config-required'),m(_0x21382c['config']['apiKey'],_0x21382c,'invalid-api-key');const _0x3bc09f={'apiKey':_0x21382c['config']['apiKey'],'appName':_0x21382c['name'],'authType':_0x3481bf,'redirectUrl':_0x1b0b8e,'v':ct,'eventId':_0x28e0b7};if(_0x5c7101 instanceof xa){_0x5c7101['setDefaultLanguage'](_0x21382c['languageCode']),_0x3bc09f['providerId']=_0x5c7101['providerId']||'',hi(_0x5c7101['getCustomParameters']())||(_0x3bc09f['customParameters']=JSON['stringify'](_0x5c7101['getCustomParameters']()));for(const [_0x3dcf4b,_0x190751]of Object['entries']({}))_0x3bc09f[_0x3dcf4b]=_0x190751;}if(_0x5c7101 instanceof Qt){const _0x504f79=_0x5c7101['getScopes']()['filter'](_0x4ea733=>_0x4ea733!=='');_0x504f79['length']>0x0&&(_0x3bc09f['scopes']=_0x504f79['join'](','));}_0x21382c['tenantId']&&(_0x3bc09f['tid']=_0x21382c['tenantId']);const _0x3a8f3d=_0x3bc09f;for(const _0x49034a of Object['keys'](_0x3a8f3d))_0x3a8f3d[_0x49034a]===void 0x0&&delete _0x3a8f3d[_0x49034a];const _0x55288b=await _0x21382c['_getAppCheckToken'](),_0x1629bb=_0x55288b?'#'+Xp+'='+encodeURIComponent(_0x55288b):'';return Zp(_0x21382c)+'?'+at(_0x3a8f3d)['slice'](0x1)+_0x1629bb;}function Zp({config:_0x4a492e}){return _0x4a492e['emulator']?Is(_0x4a492e,Jp):'https://'+_0x4a492e['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x3d129e,_0x5ceea4,_0x3b99ba,_0x2be890){var _0x4fa818;ae((_0x4fa818=this['eventManagers'][_0x3d129e['_key']()])==null?void 0x0:_0x4fa818['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x22923a=await Mr(_0x3d129e,_0x5ceea4,_0x3b99ba,Ni(),_0x2be890);return Kp(_0x3d129e,_0x22923a,bs());}async['_openRedirect'](_0x4ecd80,_0xb52fd8,_0x93ef07,_0x5c8989){await this['_originValidation'](_0x4ecd80);const _0x28b147=await Mr(_0x4ecd80,_0xb52fd8,_0x93ef07,Ni(),_0x5c8989);return ip(_0x28b147),new Promise(()=>{});}['_initialize'](_0x47d61f){const _0x2b4d9d=_0x47d61f['_key']();if(this['eventManagers'][_0x2b4d9d]){const {manager:_0x47c794,promise:_0x5edf82}=this['eventManagers'][_0x2b4d9d];return _0x47c794?Promise['resolve'](_0x47c794):(ae(_0x5edf82,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5edf82);}const _0x1cce5e=this['initAndGetManager'](_0x47d61f);return this['eventManagers'][_0x2b4d9d]={'promise':_0x1cce5e},_0x1cce5e['catch'](()=>{delete this['eventManagers'][_0x2b4d9d];}),_0x1cce5e;}async['initAndGetManager'](_0x390f4c){const _0x242bd1=await Hp(_0x390f4c),_0x29f53d=new bp(_0x390f4c);return _0x242bd1['register']('authEvent',_0x3997d4=>(m(_0x3997d4==null?void 0x0:_0x3997d4['authEvent'],_0x390f4c,'invalid-auth-event'),{'status':_0x29f53d['onEvent'](_0x3997d4['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x390f4c['_key']()]={'manager':_0x29f53d},this['iframes'][_0x390f4c['_key']()]=_0x242bd1,_0x29f53d;}['_isIframeWebStorageSupported'](_0x17a997,_0x4ab756){this['iframes'][_0x17a997['_key']()]['send'](li,{'type':li},_0x36a698=>{var _0x151278;const _0x5d5d4e=(_0x151278=_0x36a698==null?void 0x0:_0x36a698[0x0])==null?void 0x0:_0x151278[li];_0x5d5d4e!==void 0x0&&_0x4ab756(!!_0x5d5d4e),K(_0x17a997,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2c653f){const _0x3e239e=_0x2c653f['_key']();return this['originValidationPromises'][_0x3e239e]||(this['originValidationPromises'][_0x3e239e]=Pp(_0x2c653f)),this['originValidationPromises'][_0x3e239e];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x39e34d){this['auth']=_0x39e34d,this['internalListeners']=new Map();}['getUid'](){var _0x51b2a;return this['assertAuthConfigured'](),((_0x51b2a=this['auth']['currentUser'])==null?void 0x0:_0x51b2a['uid'])||null;}async['getToken'](_0x1f6001){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1f6001)}:null;}['addAuthTokenListener'](_0x2bdc9b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2bdc9b))return;const _0x468d3b=this['auth']['onIdTokenChanged'](_0x2bc0ff=>{_0x2bdc9b((_0x2bc0ff==null?void 0x0:_0x2bc0ff['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2bdc9b,_0x468d3b),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x42b5a6){this['assertAuthConfigured']();const _0x553f16=this['internalListeners']['get'](_0x42b5a6);_0x553f16&&(this['internalListeners']['delete'](_0x42b5a6),_0x553f16(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0xff4763){switch(_0xff4763){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x31d132){et(new Me('auth',(_0x529a81,{options:_0x40c697})=>{const _0x2da69d=_0x529a81['getProvider']('app')['getImmediate'](),_0x4ed5cd=_0x529a81['getProvider']('heartbeat'),_0x1e2cdb=_0x529a81['getProvider']('app-check-internal'),{apiKey:_0x238a71,authDomain:_0xc33eb6}=_0x2da69d['options'];m(_0x238a71&&!_0x238a71['includes'](':'),'invalid-api-key',{'appName':_0x2da69d['name']});const _0x305def={'apiKey':_0x238a71,'authDomain':_0xc33eb6,'clientPlatform':_0x31d132,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x31d132)},_0x3b83fa=new bf(_0x2da69d,_0x4ed5cd,_0x1e2cdb,_0x305def);return Lf(_0x3b83fa,_0x40c697),_0x3b83fa;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x54c3dd,_0x3a620f,_0x395d95)=>{_0x54c3dd['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x12b5f3=>{const _0x1e0cd2=qe(_0x12b5f3['getProvider']('auth')['getImmediate']());return(_0x4439be=>new n_(_0x4439be))(_0x1e0cd2);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x31d132)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0xe26de5=>async _0x42a007=>{const _0x54e258=_0x42a007&&await _0x42a007['getIdTokenResult'](),_0x1a6aa3=_0x54e258&&(new Date()['getTime']()-Date['parse'](_0x54e258['issuedAtTime']))/0x3e8;if(_0x1a6aa3&&_0x1a6aa3>o_)return;const _0x4b4883=_0x54e258==null?void 0x0:_0x54e258['token'];Fr!==_0x4b4883&&(Fr=_0x4b4883,await fetch(_0xe26de5,{'method':_0x4b4883?'POST':'DELETE','headers':_0x4b4883?{'Authorization':'Bearer\x20'+_0x4b4883}:{}}));};function O_(_0x3378f=Qr()){const _0x15dd63=Ui(_0x3378f,'auth');if(_0x15dd63['isInitialized']())return _0x15dd63['getImmediate']();const _0x22facb=Mf(_0x3378f,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x4ee8a6=Gr('authTokenSyncURL');if(_0x4ee8a6&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2b9ca8=new URL(_0x4ee8a6,location['origin']);if(location['origin']===_0x2b9ca8['origin']){const _0x53bbca=a_(_0x2b9ca8['toString']());Jf(_0x22facb,_0x53bbca,()=>_0x53bbca(_0x22facb['currentUser'])),Qf(_0x22facb,_0x314816=>_0x53bbca(_0x314816));}}const _0x3c1fb9=Hr('auth');return _0x3c1fb9&&xf(_0x22facb,'http://'+_0x3c1fb9),_0x22facb;}function c_(){var _0x176124;return((_0x176124=document['getElementsByTagName']('head'))==null?void 0x0:_0x176124[0x0])??document;}Rf({'loadJS'(_0x298165){return new Promise((_0x4ce99e,_0x56ee08)=>{const _0x3e6c82=document['createElement']('script');_0x3e6c82['setAttribute']('src',_0x298165),_0x3e6c82['onload']=_0x4ce99e,_0x3e6c82['onerror']=_0x28ac48=>{const _0x44ddf0=J('internal-error');_0x44ddf0['customData']=_0x28ac48,_0x56ee08(_0x44ddf0);},_0x3e6c82['type']='text/javascript',_0x3e6c82['charset']='UTF-8',c_()['appendChild'](_0x3e6c82);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};