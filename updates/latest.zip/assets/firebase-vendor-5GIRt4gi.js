const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x387470,_0x4311c7){if(!_0x387470)throw ot(_0x4311c7);},ot=function(_0x25538d){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x25538d);},Wr=function(_0x1a1883){const _0x3e5397=[];let _0x391fbc=0x0;for(let _0x5e7a8f=0x0;_0x5e7a8f<_0x1a1883['length'];_0x5e7a8f++){let _0x143c3f=_0x1a1883['charCodeAt'](_0x5e7a8f);_0x143c3f<0x80?_0x3e5397[_0x391fbc++]=_0x143c3f:_0x143c3f<0x800?(_0x3e5397[_0x391fbc++]=_0x143c3f>>0x6|0xc0,_0x3e5397[_0x391fbc++]=_0x143c3f&0x3f|0x80):(_0x143c3f&0xfc00)===0xd800&&_0x5e7a8f+0x1<_0x1a1883['length']&&(_0x1a1883['charCodeAt'](_0x5e7a8f+0x1)&0xfc00)===0xdc00?(_0x143c3f=0x10000+((_0x143c3f&0x3ff)<<0xa)+(_0x1a1883['charCodeAt'](++_0x5e7a8f)&0x3ff),_0x3e5397[_0x391fbc++]=_0x143c3f>>0x12|0xf0,_0x3e5397[_0x391fbc++]=_0x143c3f>>0xc&0x3f|0x80,_0x3e5397[_0x391fbc++]=_0x143c3f>>0x6&0x3f|0x80,_0x3e5397[_0x391fbc++]=_0x143c3f&0x3f|0x80):(_0x3e5397[_0x391fbc++]=_0x143c3f>>0xc|0xe0,_0x3e5397[_0x391fbc++]=_0x143c3f>>0x6&0x3f|0x80,_0x3e5397[_0x391fbc++]=_0x143c3f&0x3f|0x80);}return _0x3e5397;},Za=function(_0x2ce7c1){const _0x26f23b=[];let _0x10830b=0x0,_0x54f62d=0x0;for(;_0x10830b<_0x2ce7c1['length'];){const _0x2f1113=_0x2ce7c1[_0x10830b++];if(_0x2f1113<0x80)_0x26f23b[_0x54f62d++]=String['fromCharCode'](_0x2f1113);else{if(_0x2f1113>0xbf&&_0x2f1113<0xe0){const _0x3ef213=_0x2ce7c1[_0x10830b++];_0x26f23b[_0x54f62d++]=String['fromCharCode']((_0x2f1113&0x1f)<<0x6|_0x3ef213&0x3f);}else{if(_0x2f1113>0xef&&_0x2f1113<0x16d){const _0x392d81=_0x2ce7c1[_0x10830b++],_0xed3662=_0x2ce7c1[_0x10830b++],_0x141003=_0x2ce7c1[_0x10830b++],_0x5c85f8=((_0x2f1113&0x7)<<0x12|(_0x392d81&0x3f)<<0xc|(_0xed3662&0x3f)<<0x6|_0x141003&0x3f)-0x10000;_0x26f23b[_0x54f62d++]=String['fromCharCode'](0xd800+(_0x5c85f8>>0xa)),_0x26f23b[_0x54f62d++]=String['fromCharCode'](0xdc00+(_0x5c85f8&0x3ff));}else{const _0x12738b=_0x2ce7c1[_0x10830b++],_0xe452c2=_0x2ce7c1[_0x10830b++];_0x26f23b[_0x54f62d++]=String['fromCharCode']((_0x2f1113&0xf)<<0xc|(_0x12738b&0x3f)<<0x6|_0xe452c2&0x3f);}}}}return _0x26f23b['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x42dbb1,_0x2d9fd1){if(!Array['isArray'](_0x42dbb1))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x58b262=_0x2d9fd1?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x20475f=[];for(let _0x165adb=0x0;_0x165adb<_0x42dbb1['length'];_0x165adb+=0x3){const _0x3ebccb=_0x42dbb1[_0x165adb],_0x4a2df0=_0x165adb+0x1<_0x42dbb1['length'],_0x155af3=_0x4a2df0?_0x42dbb1[_0x165adb+0x1]:0x0,_0x2c699a=_0x165adb+0x2<_0x42dbb1['length'],_0x4e6bf7=_0x2c699a?_0x42dbb1[_0x165adb+0x2]:0x0,_0x207210=_0x3ebccb>>0x2,_0xc628f8=(_0x3ebccb&0x3)<<0x4|_0x155af3>>0x4;let _0x599265=(_0x155af3&0xf)<<0x2|_0x4e6bf7>>0x6,_0x3f46c6=_0x4e6bf7&0x3f;_0x2c699a||(_0x3f46c6=0x40,_0x4a2df0||(_0x599265=0x40)),_0x20475f['push'](_0x58b262[_0x207210],_0x58b262[_0xc628f8],_0x58b262[_0x599265],_0x58b262[_0x3f46c6]);}return _0x20475f['join']('');},'encodeString'(_0x5e70d3,_0x2489e3){return this['HAS_NATIVE_SUPPORT']&&!_0x2489e3?btoa(_0x5e70d3):this['encodeByteArray'](Wr(_0x5e70d3),_0x2489e3);},'decodeString'(_0x41ee0f,_0x428e31){return this['HAS_NATIVE_SUPPORT']&&!_0x428e31?atob(_0x41ee0f):Za(this['decodeStringToByteArray'](_0x41ee0f,_0x428e31));},'decodeStringToByteArray'(_0x5b2957,_0x30fc32){this['init_']();const _0x51711c=_0x30fc32?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x499857=[];for(let _0x2a1a35=0x0;_0x2a1a35<_0x5b2957['length'];){const _0x4a90e6=_0x51711c[_0x5b2957['charAt'](_0x2a1a35++)],_0x2197b8=_0x2a1a35<_0x5b2957['length']?_0x51711c[_0x5b2957['charAt'](_0x2a1a35)]:0x0;++_0x2a1a35;const _0x186b3d=_0x2a1a35<_0x5b2957['length']?_0x51711c[_0x5b2957['charAt'](_0x2a1a35)]:0x40;++_0x2a1a35;const _0xb68b11=_0x2a1a35<_0x5b2957['length']?_0x51711c[_0x5b2957['charAt'](_0x2a1a35)]:0x40;if(++_0x2a1a35,_0x4a90e6==null||_0x2197b8==null||_0x186b3d==null||_0xb68b11==null)throw new ec();const _0x7c4ec9=_0x4a90e6<<0x2|_0x2197b8>>0x4;if(_0x499857['push'](_0x7c4ec9),_0x186b3d!==0x40){const _0x271502=_0x2197b8<<0x4&0xf0|_0x186b3d>>0x2;if(_0x499857['push'](_0x271502),_0xb68b11!==0x40){const _0x59d3a1=_0x186b3d<<0x6&0xc0|_0xb68b11;_0x499857['push'](_0x59d3a1);}}}return _0x499857;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x4f5233=0x0;_0x4f5233<this['ENCODED_VALS']['length'];_0x4f5233++)this['byteToCharMap_'][_0x4f5233]=this['ENCODED_VALS']['charAt'](_0x4f5233),this['charToByteMap_'][this['byteToCharMap_'][_0x4f5233]]=_0x4f5233,this['byteToCharMapWebSafe_'][_0x4f5233]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4f5233),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x4f5233]]=_0x4f5233,_0x4f5233>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4f5233)]=_0x4f5233,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x4f5233)]=_0x4f5233);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x345afb){const _0x55e464=Wr(_0x345afb);return Di['encodeByteArray'](_0x55e464,!0x0);},an=function(_0x409f0e){return Br(_0x409f0e)['replace'](/\./g,'');},cn=function(_0x2137f0){try{return Di['decodeString'](_0x2137f0,!0x0);}catch(_0x3e6113){console['error']('base64Decode\x20failed:\x20',_0x3e6113);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x3ab205){return Vr(void 0x0,_0x3ab205);}function Vr(_0x1d71e6,_0x4d0c11){if(!(_0x4d0c11 instanceof Object))return _0x4d0c11;switch(_0x4d0c11['constructor']){case Date:const _0x2242c0=_0x4d0c11;return new Date(_0x2242c0['getTime']());case Object:_0x1d71e6===void 0x0&&(_0x1d71e6={});break;case Array:_0x1d71e6=[];break;default:return _0x4d0c11;}for(const _0x5304cb in _0x4d0c11)!_0x4d0c11['hasOwnProperty'](_0x5304cb)||!nc(_0x5304cb)||(_0x1d71e6[_0x5304cb]=Vr(_0x1d71e6[_0x5304cb],_0x4d0c11[_0x5304cb]));return _0x1d71e6;}function nc(_0x301930){return _0x301930!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x54ff38=As['__FIREBASE_DEFAULTS__'];if(_0x54ff38)return JSON['parse'](_0x54ff38);},oc=()=>{if(typeof document>'u')return;let _0x43401a;try{_0x43401a=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5eb7e1=_0x43401a&&cn(_0x43401a[0x1]);return _0x5eb7e1&&JSON['parse'](_0x5eb7e1);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0xaa4ac7){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xaa4ac7);return;}},Hr=_0x31f4aa=>{var _0x46a7bb,_0x32ed6e;return(_0x32ed6e=(_0x46a7bb=Mi())==null?void 0x0:_0x46a7bb['emulatorHosts'])==null?void 0x0:_0x32ed6e[_0x31f4aa];},ac=_0xac7e99=>{const _0x274d65=Hr(_0xac7e99);if(!_0x274d65)return;const _0x3172fa=_0x274d65['lastIndexOf'](':');if(_0x3172fa<=0x0||_0x3172fa+0x1===_0x274d65['length'])throw new Error('Invalid\x20host\x20'+_0x274d65+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4e8275=parseInt(_0x274d65['substring'](_0x3172fa+0x1),0xa);return _0x274d65[0x0]==='['?[_0x274d65['substring'](0x1,_0x3172fa-0x1),_0x4e8275]:[_0x274d65['substring'](0x0,_0x3172fa),_0x4e8275];},$r=()=>{var _0x1d9174;return(_0x1d9174=Mi())==null?void 0x0:_0x1d9174['config'];},Gr=_0x4e467f=>{var _0x2fd73e;return(_0x2fd73e=Mi())==null?void 0x0:_0x2fd73e['_'+_0x4e467f];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x14d15e,_0x5722c7)=>{this['resolve']=_0x14d15e,this['reject']=_0x5722c7;});}['wrapCallback'](_0x35ff1b){return(_0x2cf3e3,_0x1c9db9)=>{_0x2cf3e3?this['reject'](_0x2cf3e3):this['resolve'](_0x1c9db9),typeof _0x35ff1b=='function'&&(this['promise']['catch'](()=>{}),_0x35ff1b['length']===0x1?_0x35ff1b(_0x2cf3e3):_0x35ff1b(_0x2cf3e3,_0x1c9db9));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3e26c0,_0x22b7cf){if(_0x3e26c0['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xc6a1c0={'alg':'none','type':'JWT'},_0x5c8ead=_0x22b7cf||'demo-project',_0x1dc409=_0x3e26c0['iat']||0x0,_0x298b6e=_0x3e26c0['sub']||_0x3e26c0['user_id'];if(!_0x298b6e)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x571a2b={'iss':'https://securetoken.google.com/'+_0x5c8ead,'aud':_0x5c8ead,'iat':_0x1dc409,'exp':_0x1dc409+0xe10,'auth_time':_0x1dc409,'sub':_0x298b6e,'user_id':_0x298b6e,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3e26c0};return[an(JSON['stringify'](_0xc6a1c0)),an(JSON['stringify'](_0x571a2b)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x4e4bc7=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4e4bc7=='object'&&_0x4e4bc7['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x24914c=W();return _0x24914c['indexOf']('MSIE\x20')>=0x0||_0x24914c['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x322529,_0x42a1b9)=>{try{let _0x33b0fb=!0x0;const _0x1a1f3b='validate-browser-context-for-indexeddb-analytics-module',_0x1f826e=self['indexedDB']['open'](_0x1a1f3b);_0x1f826e['onsuccess']=()=>{_0x1f826e['result']['close'](),_0x33b0fb||self['indexedDB']['deleteDatabase'](_0x1a1f3b),_0x322529(!0x0);},_0x1f826e['onupgradeneeded']=()=>{_0x33b0fb=!0x1;},_0x1f826e['onerror']=()=>{var _0x424513;_0x42a1b9(((_0x424513=_0x1f826e['error'])==null?void 0x0:_0x424513['message'])||'');};}catch(_0x52a44d){_0x42a1b9(_0x52a44d);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x4198ca,_0x4e0388,_0x1765d2){super(_0x4e0388),this['code']=_0x4198ca,this['customData']=_0x1765d2,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x2c7ba4,_0x46841b,_0x5a49a6){this['service']=_0x2c7ba4,this['serviceName']=_0x46841b,this['errors']=_0x5a49a6;}['create'](_0x432df9,..._0x5644dd){const _0x565e82=_0x5644dd[0x0]||{},_0x224062=this['service']+'/'+_0x432df9,_0x18f658=this['errors'][_0x432df9],_0x50ac30=_0x18f658?gc(_0x18f658,_0x565e82):'Error',_0x3cf6d0=this['serviceName']+':\x20'+_0x50ac30+'\x20('+_0x224062+').';return new Se(_0x224062,_0x3cf6d0,_0x565e82);}}function gc(_0x8014f2,_0x4ab6f6){return _0x8014f2['replace'](mc,(_0x1c985b,_0x1abce3)=>{const _0x4792c8=_0x4ab6f6[_0x1abce3];return _0x4792c8!=null?String(_0x4792c8):'<'+_0x1abce3+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0xdb89e5){return JSON['parse'](_0xdb89e5);}function O(_0x1ef79d){return JSON['stringify'](_0x1ef79d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x3e9547){let _0x295ca1={},_0x10017b={},_0x31fbb6={},_0x1e6283='';try{const _0x19c95b=_0x3e9547['split']('.');_0x295ca1=bt(cn(_0x19c95b[0x0])||''),_0x10017b=bt(cn(_0x19c95b[0x1])||''),_0x1e6283=_0x19c95b[0x2],_0x31fbb6=_0x10017b['d']||{},delete _0x10017b['d'];}catch{}return{'header':_0x295ca1,'claims':_0x10017b,'data':_0x31fbb6,'signature':_0x1e6283};},yc=function(_0x89758a){const _0x806561=zr(_0x89758a),_0x5a6c1c=_0x806561['claims'];return!!_0x5a6c1c&&typeof _0x5a6c1c=='object'&&_0x5a6c1c['hasOwnProperty']('iat');},vc=function(_0x2e4b9f){const _0x299bc0=zr(_0x2e4b9f)['claims'];return typeof _0x299bc0=='object'&&_0x299bc0['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x126475,_0x137c40){return Object['prototype']['hasOwnProperty']['call'](_0x126475,_0x137c40);}function Oe(_0x3e0917,_0x1ec557){if(Object['prototype']['hasOwnProperty']['call'](_0x3e0917,_0x1ec557))return _0x3e0917[_0x1ec557];}function hi(_0x23647c){for(const _0x10ca02 in _0x23647c)if(Object['prototype']['hasOwnProperty']['call'](_0x23647c,_0x10ca02))return!0x1;return!0x0;}function ln(_0xc42fed,_0x4ff663,_0x50e614){const _0x427d9d={};for(const _0x2cf6c8 in _0xc42fed)Object['prototype']['hasOwnProperty']['call'](_0xc42fed,_0x2cf6c8)&&(_0x427d9d[_0x2cf6c8]=_0x4ff663['call'](_0x50e614,_0xc42fed[_0x2cf6c8],_0x2cf6c8,_0xc42fed));return _0x427d9d;}function De(_0x4c3d0a,_0x443959){if(_0x4c3d0a===_0x443959)return!0x0;const _0x5b2f76=Object['keys'](_0x4c3d0a),_0x3631d6=Object['keys'](_0x443959);for(const _0x4cde58 of _0x5b2f76){if(!_0x3631d6['includes'](_0x4cde58))return!0x1;const _0x46785d=_0x4c3d0a[_0x4cde58],_0x20b065=_0x443959[_0x4cde58];if(ks(_0x46785d)&&ks(_0x20b065)){if(!De(_0x46785d,_0x20b065))return!0x1;}else{if(_0x46785d!==_0x20b065)return!0x1;}}for(const _0x1d4395 of _0x3631d6)if(!_0x5b2f76['includes'](_0x1d4395))return!0x1;return!0x0;}function ks(_0x5992cd){return _0x5992cd!==null&&typeof _0x5992cd=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0xd3664f){const _0xbe395b=[];for(const [_0xbf4fa5,_0x2a2821]of Object['entries'](_0xd3664f))Array['isArray'](_0x2a2821)?_0x2a2821['forEach'](_0x10ee4d=>{_0xbe395b['push'](encodeURIComponent(_0xbf4fa5)+'='+encodeURIComponent(_0x10ee4d));}):_0xbe395b['push'](encodeURIComponent(_0xbf4fa5)+'='+encodeURIComponent(_0x2a2821));return _0xbe395b['length']?'&'+_0xbe395b['join']('&'):'';}function yt(_0x323c25){const _0x341cc3={};return _0x323c25['replace'](/^\?/,'')['split']('&')['forEach'](_0x5c689e=>{if(_0x5c689e){const [_0x1c5bfe,_0x431065]=_0x5c689e['split']('=');_0x341cc3[decodeURIComponent(_0x1c5bfe)]=decodeURIComponent(_0x431065);}}),_0x341cc3;}function vt(_0x595a30){const _0x1a1b59=_0x595a30['indexOf']('?');if(!_0x1a1b59)return'';const _0x2e4528=_0x595a30['indexOf']('#',_0x1a1b59);return _0x595a30['substring'](_0x1a1b59,_0x2e4528>0x0?_0x2e4528:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x409717=0x1;_0x409717<this['blockSize'];++_0x409717)this['pad_'][_0x409717]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1d81fa,_0x3876c7){_0x3876c7||(_0x3876c7=0x0);const _0x3f5ee5=this['W_'];if(typeof _0x1d81fa=='string'){for(let _0x44ed38=0x0;_0x44ed38<0x10;_0x44ed38++)_0x3f5ee5[_0x44ed38]=_0x1d81fa['charCodeAt'](_0x3876c7)<<0x18|_0x1d81fa['charCodeAt'](_0x3876c7+0x1)<<0x10|_0x1d81fa['charCodeAt'](_0x3876c7+0x2)<<0x8|_0x1d81fa['charCodeAt'](_0x3876c7+0x3),_0x3876c7+=0x4;}else{for(let _0x13687e=0x0;_0x13687e<0x10;_0x13687e++)_0x3f5ee5[_0x13687e]=_0x1d81fa[_0x3876c7]<<0x18|_0x1d81fa[_0x3876c7+0x1]<<0x10|_0x1d81fa[_0x3876c7+0x2]<<0x8|_0x1d81fa[_0x3876c7+0x3],_0x3876c7+=0x4;}for(let _0x4dcc38=0x10;_0x4dcc38<0x50;_0x4dcc38++){const _0x1b9ebd=_0x3f5ee5[_0x4dcc38-0x3]^_0x3f5ee5[_0x4dcc38-0x8]^_0x3f5ee5[_0x4dcc38-0xe]^_0x3f5ee5[_0x4dcc38-0x10];_0x3f5ee5[_0x4dcc38]=(_0x1b9ebd<<0x1|_0x1b9ebd>>>0x1f)&0xffffffff;}let _0x40ffb6=this['chain_'][0x0],_0x39c442=this['chain_'][0x1],_0x4ba522=this['chain_'][0x2],_0x5e4ff5=this['chain_'][0x3],_0x1dc4c7=this['chain_'][0x4],_0xcc5840,_0x576235;for(let _0x148155=0x0;_0x148155<0x50;_0x148155++){_0x148155<0x28?_0x148155<0x14?(_0xcc5840=_0x5e4ff5^_0x39c442&(_0x4ba522^_0x5e4ff5),_0x576235=0x5a827999):(_0xcc5840=_0x39c442^_0x4ba522^_0x5e4ff5,_0x576235=0x6ed9eba1):_0x148155<0x3c?(_0xcc5840=_0x39c442&_0x4ba522|_0x5e4ff5&(_0x39c442|_0x4ba522),_0x576235=0x8f1bbcdc):(_0xcc5840=_0x39c442^_0x4ba522^_0x5e4ff5,_0x576235=0xca62c1d6);const _0x202698=(_0x40ffb6<<0x5|_0x40ffb6>>>0x1b)+_0xcc5840+_0x1dc4c7+_0x576235+_0x3f5ee5[_0x148155]&0xffffffff;_0x1dc4c7=_0x5e4ff5,_0x5e4ff5=_0x4ba522,_0x4ba522=(_0x39c442<<0x1e|_0x39c442>>>0x2)&0xffffffff,_0x39c442=_0x40ffb6,_0x40ffb6=_0x202698;}this['chain_'][0x0]=this['chain_'][0x0]+_0x40ffb6&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x39c442&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4ba522&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5e4ff5&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1dc4c7&0xffffffff;}['update'](_0x3881f2,_0x44f459){if(_0x3881f2==null)return;_0x44f459===void 0x0&&(_0x44f459=_0x3881f2['length']);const _0x2edac9=_0x44f459-this['blockSize'];let _0x27cf50=0x0;const _0x27c619=this['buf_'];let _0x4b8a84=this['inbuf_'];for(;_0x27cf50<_0x44f459;){if(_0x4b8a84===0x0){for(;_0x27cf50<=_0x2edac9;)this['compress_'](_0x3881f2,_0x27cf50),_0x27cf50+=this['blockSize'];}if(typeof _0x3881f2=='string'){for(;_0x27cf50<_0x44f459;)if(_0x27c619[_0x4b8a84]=_0x3881f2['charCodeAt'](_0x27cf50),++_0x4b8a84,++_0x27cf50,_0x4b8a84===this['blockSize']){this['compress_'](_0x27c619),_0x4b8a84=0x0;break;}}else{for(;_0x27cf50<_0x44f459;)if(_0x27c619[_0x4b8a84]=_0x3881f2[_0x27cf50],++_0x4b8a84,++_0x27cf50,_0x4b8a84===this['blockSize']){this['compress_'](_0x27c619),_0x4b8a84=0x0;break;}}}this['inbuf_']=_0x4b8a84,this['total_']+=_0x44f459;}['digest'](){const _0x384d3d=[];let _0x55cea0=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x94d595=this['blockSize']-0x1;_0x94d595>=0x38;_0x94d595--)this['buf_'][_0x94d595]=_0x55cea0&0xff,_0x55cea0/=0x100;this['compress_'](this['buf_']);let _0xf99359=0x0;for(let _0x21fbbe=0x0;_0x21fbbe<0x5;_0x21fbbe++)for(let _0x20af52=0x18;_0x20af52>=0x0;_0x20af52-=0x8)_0x384d3d[_0xf99359]=this['chain_'][_0x21fbbe]>>_0x20af52&0xff,++_0xf99359;return _0x384d3d;}}function Ic(_0x4f2f81,_0xf22422){const _0x3ef404=new wc(_0x4f2f81,_0xf22422);return _0x3ef404['subscribe']['bind'](_0x3ef404);}class wc{constructor(_0x7152b5,_0x571f83){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x571f83,this['task']['then'](()=>{_0x7152b5(this);})['catch'](_0x625c0e=>{this['error'](_0x625c0e);});}['next'](_0x31a110){this['forEachObserver'](_0x5a1639=>{_0x5a1639['next'](_0x31a110);});}['error'](_0x4dabb7){this['forEachObserver'](_0x2de886=>{_0x2de886['error'](_0x4dabb7);}),this['close'](_0x4dabb7);}['complete'](){this['forEachObserver'](_0x274c28=>{_0x274c28['complete']();}),this['close']();}['subscribe'](_0x3e1403,_0x5b9130,_0xda550d){let _0x22940f;if(_0x3e1403===void 0x0&&_0x5b9130===void 0x0&&_0xda550d===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x3e1403,['next','error','complete'])?_0x22940f=_0x3e1403:_0x22940f={'next':_0x3e1403,'error':_0x5b9130,'complete':_0xda550d},_0x22940f['next']===void 0x0&&(_0x22940f['next']=Qn),_0x22940f['error']===void 0x0&&(_0x22940f['error']=Qn),_0x22940f['complete']===void 0x0&&(_0x22940f['complete']=Qn);const _0x45323f=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x22940f['error'](this['finalError']):_0x22940f['complete']();}catch{}}),this['observers']['push'](_0x22940f),_0x45323f;}['unsubscribeOne'](_0xdfa8ff){this['observers']===void 0x0||this['observers'][_0xdfa8ff]===void 0x0||(delete this['observers'][_0xdfa8ff],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x32ecaf){if(!this['finalized']){for(let _0x5d09a4=0x0;_0x5d09a4<this['observers']['length'];_0x5d09a4++)this['sendOne'](_0x5d09a4,_0x32ecaf);}}['sendOne'](_0x252fc2,_0x8e2857){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x252fc2]!==void 0x0)try{_0x8e2857(this['observers'][_0x252fc2]);}catch(_0x521f26){typeof console<'u'&&console['error']&&console['error'](_0x521f26);}});}['close'](_0x36195f){this['finalized']||(this['finalized']=!0x0,_0x36195f!==void 0x0&&(this['finalError']=_0x36195f),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x1229e3,_0x4e3aaf){if(typeof _0x1229e3!='object'||_0x1229e3===null)return!0x1;for(const _0x5df05d of _0x4e3aaf)if(_0x5df05d in _0x1229e3&&typeof _0x1229e3[_0x5df05d]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x3979c4,_0x5a50a2){return _0x3979c4+'\x20failed:\x20'+_0x5a50a2+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x22ddb4){const _0x434773=[];let _0x290007=0x0;for(let _0x2eab84=0x0;_0x2eab84<_0x22ddb4['length'];_0x2eab84++){let _0x3ee8e4=_0x22ddb4['charCodeAt'](_0x2eab84);if(_0x3ee8e4>=0xd800&&_0x3ee8e4<=0xdbff){const _0x445229=_0x3ee8e4-0xd800;_0x2eab84++,f(_0x2eab84<_0x22ddb4['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x41aa38=_0x22ddb4['charCodeAt'](_0x2eab84)-0xdc00;_0x3ee8e4=0x10000+(_0x445229<<0xa)+_0x41aa38;}_0x3ee8e4<0x80?_0x434773[_0x290007++]=_0x3ee8e4:_0x3ee8e4<0x800?(_0x434773[_0x290007++]=_0x3ee8e4>>0x6|0xc0,_0x434773[_0x290007++]=_0x3ee8e4&0x3f|0x80):_0x3ee8e4<0x10000?(_0x434773[_0x290007++]=_0x3ee8e4>>0xc|0xe0,_0x434773[_0x290007++]=_0x3ee8e4>>0x6&0x3f|0x80,_0x434773[_0x290007++]=_0x3ee8e4&0x3f|0x80):(_0x434773[_0x290007++]=_0x3ee8e4>>0x12|0xf0,_0x434773[_0x290007++]=_0x3ee8e4>>0xc&0x3f|0x80,_0x434773[_0x290007++]=_0x3ee8e4>>0x6&0x3f|0x80,_0x434773[_0x290007++]=_0x3ee8e4&0x3f|0x80);}return _0x434773;},Pn=function(_0x5277d7){let _0x325738=0x0;for(let _0x3dd29b=0x0;_0x3dd29b<_0x5277d7['length'];_0x3dd29b++){const _0xf6a1a=_0x5277d7['charCodeAt'](_0x3dd29b);_0xf6a1a<0x80?_0x325738++:_0xf6a1a<0x800?_0x325738+=0x2:_0xf6a1a>=0xd800&&_0xf6a1a<=0xdbff?(_0x325738+=0x4,_0x3dd29b++):_0x325738+=0x3;}return _0x325738;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x318fd4){return _0x318fd4&&_0x318fd4['_delegate']?_0x318fd4['_delegate']:_0x318fd4;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x418b86){try{return(_0x418b86['startsWith']('http://')||_0x418b86['startsWith']('https://')?new URL(_0x418b86)['hostname']:_0x418b86)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x3c890b){return(await fetch(_0x3c890b,{'credentials':'include'}))['ok'];}class Me{constructor(_0x278561,_0x250a0d,_0x44715b){this['name']=_0x278561,this['instanceFactory']=_0x250a0d,this['type']=_0x44715b,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x37982b){return this['instantiationMode']=_0x37982b,this;}['setMultipleInstances'](_0x51554b){return this['multipleInstances']=_0x51554b,this;}['setServiceProps'](_0x502d9b){return this['serviceProps']=_0x502d9b,this;}['setInstanceCreatedCallback'](_0x3690ef){return this['onInstanceCreated']=_0x3690ef,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x2077f0,_0x3fe557){this['name']=_0x2077f0,this['container']=_0x3fe557,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x3bb265){const _0xeb57a1=this['normalizeInstanceIdentifier'](_0x3bb265);if(!this['instancesDeferred']['has'](_0xeb57a1)){const _0x37ba82=new Ve();if(this['instancesDeferred']['set'](_0xeb57a1,_0x37ba82),this['isInitialized'](_0xeb57a1)||this['shouldAutoInitialize']())try{const _0x51fd6c=this['getOrInitializeService']({'instanceIdentifier':_0xeb57a1});_0x51fd6c&&_0x37ba82['resolve'](_0x51fd6c);}catch{}}return this['instancesDeferred']['get'](_0xeb57a1)['promise'];}['getImmediate'](_0x33b204){const _0xc2eaca=this['normalizeInstanceIdentifier'](_0x33b204==null?void 0x0:_0x33b204['identifier']),_0x12da9c=(_0x33b204==null?void 0x0:_0x33b204['optional'])??!0x1;if(this['isInitialized'](_0xc2eaca)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0xc2eaca});}catch(_0x53375e){if(_0x12da9c)return null;throw _0x53375e;}else{if(_0x12da9c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x164c53){if(_0x164c53['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x164c53['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x164c53,!!this['shouldAutoInitialize']()){if(Rc(_0x164c53))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x431868,_0xea27aa]of this['instancesDeferred']['entries']()){const _0x327db1=this['normalizeInstanceIdentifier'](_0x431868);try{const _0x39fb4c=this['getOrInitializeService']({'instanceIdentifier':_0x327db1});_0xea27aa['resolve'](_0x39fb4c);}catch{}}}}['clearInstance'](_0x8d86f8=ke){this['instancesDeferred']['delete'](_0x8d86f8),this['instancesOptions']['delete'](_0x8d86f8),this['instances']['delete'](_0x8d86f8);}async['delete'](){const _0x357058=Array['from'](this['instances']['values']());await Promise['all']([..._0x357058['filter'](_0x5e667c=>'INTERNAL'in _0x5e667c)['map'](_0xda1a5a=>_0xda1a5a['INTERNAL']['delete']()),..._0x357058['filter'](_0x1bc9d0=>'_delete'in _0x1bc9d0)['map'](_0x5bde9e=>_0x5bde9e['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2bd8b3=ke){return this['instances']['has'](_0x2bd8b3);}['getOptions'](_0x1aad08=ke){return this['instancesOptions']['get'](_0x1aad08)||{};}['initialize'](_0x20fc67={}){const {options:_0x228e09={}}=_0x20fc67,_0x38ea4a=this['normalizeInstanceIdentifier'](_0x20fc67['instanceIdentifier']);if(this['isInitialized'](_0x38ea4a))throw Error(this['name']+'('+_0x38ea4a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x34a17a=this['getOrInitializeService']({'instanceIdentifier':_0x38ea4a,'options':_0x228e09});for(const [_0x11678d,_0x3573f7]of this['instancesDeferred']['entries']()){const _0x5eb473=this['normalizeInstanceIdentifier'](_0x11678d);_0x38ea4a===_0x5eb473&&_0x3573f7['resolve'](_0x34a17a);}return _0x34a17a;}['onInit'](_0x3cb40c,_0x200496){const _0x854611=this['normalizeInstanceIdentifier'](_0x200496),_0x3b035a=this['onInitCallbacks']['get'](_0x854611)??new Set();_0x3b035a['add'](_0x3cb40c),this['onInitCallbacks']['set'](_0x854611,_0x3b035a);const _0x143b4c=this['instances']['get'](_0x854611);return _0x143b4c&&_0x3cb40c(_0x143b4c,_0x854611),()=>{_0x3b035a['delete'](_0x3cb40c);};}['invokeOnInitCallbacks'](_0x20e5e7,_0x22aaab){const _0x547448=this['onInitCallbacks']['get'](_0x22aaab);if(_0x547448){for(const _0x19bb00 of _0x547448)try{_0x19bb00(_0x20e5e7,_0x22aaab);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4d2bbb,options:_0x207280={}}){let _0x114c7a=this['instances']['get'](_0x4d2bbb);if(!_0x114c7a&&this['component']&&(_0x114c7a=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x4d2bbb),'options':_0x207280}),this['instances']['set'](_0x4d2bbb,_0x114c7a),this['instancesOptions']['set'](_0x4d2bbb,_0x207280),this['invokeOnInitCallbacks'](_0x114c7a,_0x4d2bbb),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4d2bbb,_0x114c7a);}catch{}return _0x114c7a||null;}['normalizeInstanceIdentifier'](_0x520843=ke){return this['component']?this['component']['multipleInstances']?_0x520843:ke:_0x520843;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x1eb50d){return _0x1eb50d===ke?void 0x0:_0x1eb50d;}function Rc(_0x25c918){return _0x25c918['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x12eade){this['name']=_0x12eade,this['providers']=new Map();}['addComponent'](_0x5e73e8){const _0x27259c=this['getProvider'](_0x5e73e8['name']);if(_0x27259c['isComponentSet']())throw new Error('Component\x20'+_0x5e73e8['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x27259c['setComponent'](_0x5e73e8);}['addOrOverwriteComponent'](_0x2044e1){this['getProvider'](_0x2044e1['name'])['isComponentSet']()&&this['providers']['delete'](_0x2044e1['name']),this['addComponent'](_0x2044e1);}['getProvider'](_0x1d41f2){if(this['providers']['has'](_0x1d41f2))return this['providers']['get'](_0x1d41f2);const _0x3625aa=new Sc(_0x1d41f2,this);return this['providers']['set'](_0x1d41f2,_0x3625aa),_0x3625aa;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x5c7d44){_0x5c7d44[_0x5c7d44['DEBUG']=0x0]='DEBUG',_0x5c7d44[_0x5c7d44['VERBOSE']=0x1]='VERBOSE',_0x5c7d44[_0x5c7d44['INFO']=0x2]='INFO',_0x5c7d44[_0x5c7d44['WARN']=0x3]='WARN',_0x5c7d44[_0x5c7d44['ERROR']=0x4]='ERROR',_0x5c7d44[_0x5c7d44['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x203b9d,_0x645dc,..._0x542ad5)=>{if(_0x645dc<_0x203b9d['logLevel'])return;const _0x4b8c34=new Date()['toISOString'](),_0x54d3dd=Pc[_0x645dc];if(_0x54d3dd)console[_0x54d3dd]('['+_0x4b8c34+']\x20\x20'+_0x203b9d['name']+':',..._0x542ad5);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x645dc+')');};class xi{constructor(_0x18148e){this['name']=_0x18148e,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x49b54d){if(!(_0x49b54d in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x49b54d+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x49b54d;}['setLogLevel'](_0x40317d){this['_logLevel']=typeof _0x40317d=='string'?kc[_0x40317d]:_0x40317d;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x441ec5){if(typeof _0x441ec5!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x441ec5;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2bd20b){this['_userLogHandler']=_0x2bd20b;}['debug'](..._0x2af8a0){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2af8a0),this['_logHandler'](this,T['DEBUG'],..._0x2af8a0);}['log'](..._0xc73d1d){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0xc73d1d),this['_logHandler'](this,T['VERBOSE'],..._0xc73d1d);}['info'](..._0x4af12e){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x4af12e),this['_logHandler'](this,T['INFO'],..._0x4af12e);}['warn'](..._0x2dbf37){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2dbf37),this['_logHandler'](this,T['WARN'],..._0x2dbf37);}['error'](..._0x594834){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x594834),this['_logHandler'](this,T['ERROR'],..._0x594834);}}const Dc=(_0x3c755f,_0x3f596e)=>_0x3f596e['some'](_0xba7244=>_0x3c755f instanceof _0xba7244);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x1859f3){const _0x45e75a=new Promise((_0x302168,_0x2e3c42)=>{const _0x5868c0=()=>{_0x1859f3['removeEventListener']('success',_0x5767c2),_0x1859f3['removeEventListener']('error',_0x1d4509);},_0x5767c2=()=>{_0x302168(_e(_0x1859f3['result'])),_0x5868c0();},_0x1d4509=()=>{_0x2e3c42(_0x1859f3['error']),_0x5868c0();};_0x1859f3['addEventListener']('success',_0x5767c2),_0x1859f3['addEventListener']('error',_0x1d4509);});return _0x45e75a['then'](_0x45fbd8=>{_0x45fbd8 instanceof IDBCursor&&Kr['set'](_0x45fbd8,_0x1859f3);})['catch'](()=>{}),Fi['set'](_0x45e75a,_0x1859f3),_0x45e75a;}function Fc(_0x7a9471){if(ui['has'](_0x7a9471))return;const _0x54f20d=new Promise((_0x864f82,_0x359e0b)=>{const _0x29495b=()=>{_0x7a9471['removeEventListener']('complete',_0x920ec1),_0x7a9471['removeEventListener']('error',_0x160097),_0x7a9471['removeEventListener']('abort',_0x160097);},_0x920ec1=()=>{_0x864f82(),_0x29495b();},_0x160097=()=>{_0x359e0b(_0x7a9471['error']||new DOMException('AbortError','AbortError')),_0x29495b();};_0x7a9471['addEventListener']('complete',_0x920ec1),_0x7a9471['addEventListener']('error',_0x160097),_0x7a9471['addEventListener']('abort',_0x160097);});ui['set'](_0x7a9471,_0x54f20d);}let di={'get'(_0x3715b6,_0x331619,_0x1862db){if(_0x3715b6 instanceof IDBTransaction){if(_0x331619==='done')return ui['get'](_0x3715b6);if(_0x331619==='objectStoreNames')return _0x3715b6['objectStoreNames']||Yr['get'](_0x3715b6);if(_0x331619==='store')return _0x1862db['objectStoreNames'][0x1]?void 0x0:_0x1862db['objectStore'](_0x1862db['objectStoreNames'][0x0]);}return _e(_0x3715b6[_0x331619]);},'set'(_0x4eba07,_0x2123b7,_0x313301){return _0x4eba07[_0x2123b7]=_0x313301,!0x0;},'has'(_0x36c5ed,_0x426212){return _0x36c5ed instanceof IDBTransaction&&(_0x426212==='done'||_0x426212==='store')?!0x0:_0x426212 in _0x36c5ed;}};function Uc(_0x5c37c){di=_0x5c37c(di);}function Wc(_0x3d86eb){return _0x3d86eb===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x17cd6e,..._0x513910){const _0x12b590=_0x3d86eb['call'](Xn(this),_0x17cd6e,..._0x513910);return Yr['set'](_0x12b590,_0x17cd6e['sort']?_0x17cd6e['sort']():[_0x17cd6e]),_e(_0x12b590);}:Lc()['includes'](_0x3d86eb)?function(..._0x23a598){return _0x3d86eb['apply'](Xn(this),_0x23a598),_e(Kr['get'](this));}:function(..._0x369edf){return _e(_0x3d86eb['apply'](Xn(this),_0x369edf));};}function Bc(_0x576a2c){return typeof _0x576a2c=='function'?Wc(_0x576a2c):(_0x576a2c instanceof IDBTransaction&&Fc(_0x576a2c),Dc(_0x576a2c,Mc())?new Proxy(_0x576a2c,di):_0x576a2c);}function _e(_0x28e6b8){if(_0x28e6b8 instanceof IDBRequest)return xc(_0x28e6b8);if(Jn['has'](_0x28e6b8))return Jn['get'](_0x28e6b8);const _0x31e787=Bc(_0x28e6b8);return _0x31e787!==_0x28e6b8&&(Jn['set'](_0x28e6b8,_0x31e787),Fi['set'](_0x31e787,_0x28e6b8)),_0x31e787;}const Xn=_0x3f44eb=>Fi['get'](_0x3f44eb);function Vc(_0x5e84b3,_0x3d821b,{blocked:_0x2684c7,upgrade:_0x383af2,blocking:_0x44aa17,terminated:_0x1062c4}={}){const _0x50f35b=indexedDB['open'](_0x5e84b3,_0x3d821b),_0x2bacd8=_e(_0x50f35b);return _0x383af2&&_0x50f35b['addEventListener']('upgradeneeded',_0x2fd31f=>{_0x383af2(_e(_0x50f35b['result']),_0x2fd31f['oldVersion'],_0x2fd31f['newVersion'],_e(_0x50f35b['transaction']),_0x2fd31f);}),_0x2684c7&&_0x50f35b['addEventListener']('blocked',_0x1c2239=>_0x2684c7(_0x1c2239['oldVersion'],_0x1c2239['newVersion'],_0x1c2239)),_0x2bacd8['then'](_0x38e3b3=>{_0x1062c4&&_0x38e3b3['addEventListener']('close',()=>_0x1062c4()),_0x44aa17&&_0x38e3b3['addEventListener']('versionchange',_0x5ec1b0=>_0x44aa17(_0x5ec1b0['oldVersion'],_0x5ec1b0['newVersion'],_0x5ec1b0));})['catch'](()=>{}),_0x2bacd8;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x58d866,_0x542882){if(!(_0x58d866 instanceof IDBDatabase&&!(_0x542882 in _0x58d866)&&typeof _0x542882=='string'))return;if(Zn['get'](_0x542882))return Zn['get'](_0x542882);const _0x255699=_0x542882['replace'](/FromIndex$/,''),_0x452133=_0x542882!==_0x255699,_0x505790=$c['includes'](_0x255699);if(!(_0x255699 in(_0x452133?IDBIndex:IDBObjectStore)['prototype'])||!(_0x505790||Hc['includes'](_0x255699)))return;const _0x5098ee=async function(_0x52d605,..._0x1506b8){const _0x33458c=this['transaction'](_0x52d605,_0x505790?'readwrite':'readonly');let _0x5c8e26=_0x33458c['store'];return _0x452133&&(_0x5c8e26=_0x5c8e26['index'](_0x1506b8['shift']())),(await Promise['all']([_0x5c8e26[_0x255699](..._0x1506b8),_0x505790&&_0x33458c['done']]))[0x0];};return Zn['set'](_0x542882,_0x5098ee),_0x5098ee;}Uc(_0x15559e=>({..._0x15559e,'get':(_0xc139a6,_0x322185,_0x127c9f)=>Os(_0xc139a6,_0x322185)||_0x15559e['get'](_0xc139a6,_0x322185,_0x127c9f),'has':(_0xf37f93,_0xc35e20)=>!!Os(_0xf37f93,_0xc35e20)||_0x15559e['has'](_0xf37f93,_0xc35e20)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x326728){this['container']=_0x326728;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x17a48a=>{if(qc(_0x17a48a)){const _0x337a73=_0x17a48a['getImmediate']();return _0x337a73['library']+'/'+_0x337a73['version'];}else return null;})['filter'](_0x4336f8=>_0x4336f8)['join']('\x20');}}function qc(_0x1d04c6){const _0x137753=_0x1d04c6['getComponent']();return(_0x137753==null?void 0x0:_0x137753['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x14719e,_0x267b34){try{_0x14719e['container']['addComponent'](_0x267b34);}catch(_0x461e32){re['debug']('Component\x20'+_0x267b34['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x14719e['name'],_0x461e32);}}function et(_0x2d0147){const _0x52c093=_0x2d0147['name'];if(gi['has'](_0x52c093))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x52c093+'.'),!0x1;gi['set'](_0x52c093,_0x2d0147);for(const _0x3cb4d4 of Le['values']())Ms(_0x3cb4d4,_0x2d0147);for(const _0x3f820e of _i['values']())Ms(_0x3f820e,_0x2d0147);return!0x0;}function Ui(_0x330d94,_0x2d7c49){const _0x3a4015=_0x330d94['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3a4015&&_0x3a4015['triggerHeartbeat'](),_0x330d94['container']['getProvider'](_0x2d7c49);}function H(_0x375d23){return _0x375d23==null?!0x1:_0x375d23['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x2dae70,_0xe56c24,_0x1810e8){this['_isDeleted']=!0x1,this['_options']={..._0x2dae70},this['_config']={..._0xe56c24},this['_name']=_0xe56c24['name'],this['_automaticDataCollectionEnabled']=_0xe56c24['automaticDataCollectionEnabled'],this['_container']=_0x1810e8,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x162bac){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x162bac;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x3b8264){this['_isDeleted']=_0x3b8264;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x6316f7,_0x39c7c0={}){let _0x20e331=_0x6316f7;typeof _0x39c7c0!='object'&&(_0x39c7c0={'name':_0x39c7c0});const _0x442a7a={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x39c7c0},_0x16e47b=_0x442a7a['name'];if(typeof _0x16e47b!='string'||!_0x16e47b)throw ge['create']('bad-app-name',{'appName':String(_0x16e47b)});if(_0x20e331||(_0x20e331=$r()),!_0x20e331)throw ge['create']('no-options');const _0x16fee2=Le['get'](_0x16e47b);if(_0x16fee2){if(De(_0x20e331,_0x16fee2['options'])&&De(_0x442a7a,_0x16fee2['config']))return _0x16fee2;throw ge['create']('duplicate-app',{'appName':_0x16e47b});}const _0x26e193=new Ac(_0x16e47b);for(const _0x3eef86 of gi['values']())_0x26e193['addComponent'](_0x3eef86);const _0x1e56aa=new Il(_0x20e331,_0x442a7a,_0x26e193);return Le['set'](_0x16e47b,_0x1e56aa),_0x1e56aa;}function Qr(_0xe665bd=pi){const _0x10b21b=Le['get'](_0xe665bd);if(!_0x10b21b&&_0xe665bd===pi&&$r())return wl();if(!_0x10b21b)throw ge['create']('no-app',{'appName':_0xe665bd});return _0x10b21b;}function l_(){return Array['from'](Le['values']());}async function h_(_0x188f9b){let _0x302687=!0x1;const _0x4cb49a=_0x188f9b['name'];Le['has'](_0x4cb49a)?(_0x302687=!0x0,Le['delete'](_0x4cb49a)):_i['has'](_0x4cb49a)&&_0x188f9b['decRefCount']()<=0x0&&(_i['delete'](_0x4cb49a),_0x302687=!0x0),_0x302687&&(await Promise['all'](_0x188f9b['container']['getProviders']()['map'](_0x105625=>_0x105625['delete']())),_0x188f9b['isDeleted']=!0x0);}function me(_0x12049c,_0x3a46aa,_0x9ab3f3){let _0x3d5c96=vl[_0x12049c]??_0x12049c;_0x9ab3f3&&(_0x3d5c96+='-'+_0x9ab3f3);const _0x3f7a60=_0x3d5c96['match'](/\s|\//),_0x2a99e7=_0x3a46aa['match'](/\s|\//);if(_0x3f7a60||_0x2a99e7){const _0x3c56e5=['Unable\x20to\x20register\x20library\x20\x22'+_0x3d5c96+'\x22\x20with\x20version\x20\x22'+_0x3a46aa+'\x22:'];_0x3f7a60&&_0x3c56e5['push']('library\x20name\x20\x22'+_0x3d5c96+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3f7a60&&_0x2a99e7&&_0x3c56e5['push']('and'),_0x2a99e7&&_0x3c56e5['push']('version\x20name\x20\x22'+_0x3a46aa+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3c56e5['join']('\x20'));return;}et(new Me(_0x3d5c96+'-version',()=>({'library':_0x3d5c96,'version':_0x3a46aa}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x52ba7a,_0x463c4f)=>{switch(_0x463c4f){case 0x0:try{_0x52ba7a['createObjectStore'](Rt);}catch(_0x3d4514){console['warn'](_0x3d4514);}}}})['catch'](_0x46f3e5=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x46f3e5['message']});})),ei;}async function Sl(_0x733926){try{const _0x1d84fc=(await Jr())['transaction'](Rt),_0x17d335=await _0x1d84fc['objectStore'](Rt)['get'](Xr(_0x733926));return await _0x1d84fc['done'],_0x17d335;}catch(_0xa12d7b){if(_0xa12d7b instanceof Se)re['warn'](_0xa12d7b['message']);else{const _0x522886=ge['create']('idb-get',{'originalErrorMessage':_0xa12d7b==null?void 0x0:_0xa12d7b['message']});re['warn'](_0x522886['message']);}}}async function Ls(_0x29e8b4,_0x252b8d){try{const _0x65db33=(await Jr())['transaction'](Rt,'readwrite');await _0x65db33['objectStore'](Rt)['put'](_0x252b8d,Xr(_0x29e8b4)),await _0x65db33['done'];}catch(_0x218ff2){if(_0x218ff2 instanceof Se)re['warn'](_0x218ff2['message']);else{const _0x53bd33=ge['create']('idb-set',{'originalErrorMessage':_0x218ff2==null?void 0x0:_0x218ff2['message']});re['warn'](_0x53bd33['message']);}}}function Xr(_0x10ff55){return _0x10ff55['name']+'!'+_0x10ff55['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x325309){this['container']=_0x325309,this['_heartbeatsCache']=null;const _0x5ce9aa=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x5ce9aa),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x547758=>(this['_heartbeatsCache']=_0x547758,_0x547758));}async['triggerHeartbeat'](){var _0x5ec970,_0x152816;try{const _0x4edcc1=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x36e21c=xs();if(((_0x5ec970=this['_heartbeatsCache'])==null?void 0x0:_0x5ec970['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x152816=this['_heartbeatsCache'])==null?void 0x0:_0x152816['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x36e21c||this['_heartbeatsCache']['heartbeats']['some'](_0x75d8db=>_0x75d8db['date']===_0x36e21c))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x36e21c,'agent':_0x4edcc1}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x5adfac=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5adfac,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x43b2fe){re['warn'](_0x43b2fe);}}async['getHeartbeatsHeader'](){var _0x82840;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x82840=this['_heartbeatsCache'])==null?void 0x0:_0x82840['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5da1a3=xs(),{heartbeatsToSend:_0x3a7d13,unsentEntries:_0x381922}=kl(this['_heartbeatsCache']['heartbeats']),_0x4b3437=an(JSON['stringify']({'version':0x2,'heartbeats':_0x3a7d13}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5da1a3,_0x381922['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x381922,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4b3437;}catch(_0x5d00b9){return re['warn'](_0x5d00b9),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x2e6926,_0x1a8c8e=bl){const _0x1e6253=[];let _0x245a38=_0x2e6926['slice']();for(const _0x352bda of _0x2e6926){const _0x1a539c=_0x1e6253['find'](_0x40c074=>_0x40c074['agent']===_0x352bda['agent']);if(_0x1a539c){if(_0x1a539c['dates']['push'](_0x352bda['date']),Fs(_0x1e6253)>_0x1a8c8e){_0x1a539c['dates']['pop']();break;}}else{if(_0x1e6253['push']({'agent':_0x352bda['agent'],'dates':[_0x352bda['date']]}),Fs(_0x1e6253)>_0x1a8c8e){_0x1e6253['pop']();break;}}_0x245a38=_0x245a38['slice'](0x1);}return{'heartbeatsToSend':_0x1e6253,'unsentEntries':_0x245a38};}class Nl{constructor(_0x41bbc6){this['app']=_0x41bbc6,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x525ea4=await Sl(this['app']);return _0x525ea4!=null&&_0x525ea4['heartbeats']?_0x525ea4:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x20ee8b){if(await this['_canUseIndexedDBPromise']){const _0x74381a=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x20ee8b['lastSentHeartbeatDate']??_0x74381a['lastSentHeartbeatDate'],'heartbeats':_0x20ee8b['heartbeats']});}else return;}async['add'](_0x558adb){if(await this['_canUseIndexedDBPromise']){const _0x346c0b=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x558adb['lastSentHeartbeatDate']??_0x346c0b['lastSentHeartbeatDate'],'heartbeats':[..._0x346c0b['heartbeats'],..._0x558adb['heartbeats']]});}else return;}}function Fs(_0x41301a){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x41301a}))['length'];}function Pl(_0x544202){if(_0x544202['length']===0x0)return-0x1;let _0x5f54e2=0x0,_0x165472=_0x544202[0x0]['date'];for(let _0x4ed7ea=0x1;_0x4ed7ea<_0x544202['length'];_0x4ed7ea++)_0x544202[_0x4ed7ea]['date']<_0x165472&&(_0x165472=_0x544202[_0x4ed7ea]['date'],_0x5f54e2=_0x4ed7ea);return _0x5f54e2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x129a5e){et(new Me('platform-logger',_0x5955b3=>new Gc(_0x5955b3),'PRIVATE')),et(new Me('heartbeat',_0x43a164=>new Al(_0x43a164),'PRIVATE')),me(fi,Ds,_0x129a5e),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x5c6245){Zr=_0x5c6245;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x44f919){this['domStorage_']=_0x44f919,this['prefix_']='firebase:';}['set'](_0x5a7714,_0x2f93f8){_0x2f93f8==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5a7714)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5a7714),O(_0x2f93f8));}['get'](_0x532d95){const _0x5c590c=this['domStorage_']['getItem'](this['prefixedName_'](_0x532d95));return _0x5c590c==null?null:bt(_0x5c590c);}['remove'](_0x14db5a){this['domStorage_']['removeItem'](this['prefixedName_'](_0x14db5a));}['prefixedName_'](_0x3d058a){return this['prefix_']+_0x3d058a;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x28b726,_0x525ca0){_0x525ca0==null?delete this['cache_'][_0x28b726]:this['cache_'][_0x28b726]=_0x525ca0;}['get'](_0x10874a){return Y(this['cache_'],_0x10874a)?this['cache_'][_0x10874a]:null;}['remove'](_0x2475b3){delete this['cache_'][_0x2475b3];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x58b206){try{if(typeof window<'u'&&typeof window[_0x58b206]<'u'){const _0x4702f5=window[_0x58b206];return _0x4702f5['setItem']('firebase:sentinel','cache'),_0x4702f5['removeItem']('firebase:sentinel'),new xl(_0x4702f5);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x146731=0x1;return function(){return _0x146731++;};}()),no=function(_0x5c5fd2){const _0xb4ba2e=Tc(_0x5c5fd2),_0x265d38=new Ec();_0x265d38['update'](_0xb4ba2e);const _0x4f06b5=_0x265d38['digest']();return Di['encodeByteArray'](_0x4f06b5);},Bt=function(..._0x34c92b){let _0xec83b6='';for(let _0x38967d=0x0;_0x38967d<_0x34c92b['length'];_0x38967d++){const _0xf40235=_0x34c92b[_0x38967d];Array['isArray'](_0xf40235)||_0xf40235&&typeof _0xf40235=='object'&&typeof _0xf40235['length']=='number'?_0xec83b6+=Bt['apply'](null,_0xf40235):typeof _0xf40235=='object'?_0xec83b6+=O(_0xf40235):_0xec83b6+=_0xf40235,_0xec83b6+='\x20';}return _0xec83b6;};let Et=null,Vs=!0x0;const Wl=function(_0x59927b,_0x21d7cd){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x589abb){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x5daff7=Bt['apply'](null,_0x589abb);Et(_0x5daff7);}},Vt=function(_0x1bdf1c){return function(..._0x130aba){L(_0x1bdf1c,..._0x130aba);};},mi=function(..._0x4b2cf9){const _0x557e8c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x4b2cf9);Qe['error'](_0x557e8c);},oe=function(..._0xd5147b){const _0x484235='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0xd5147b);throw Qe['error'](_0x484235),new Error(_0x484235);},U=function(..._0x3f10e6){const _0x3d146c='FIREBASE\x20WARNING:\x20'+Bt(..._0x3f10e6);Qe['warn'](_0x3d146c);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x1b921a){return typeof _0x1b921a=='number'&&(_0x1b921a!==_0x1b921a||_0x1b921a===Number['POSITIVE_INFINITY']||_0x1b921a===Number['NEGATIVE_INFINITY']);},Vl=function(_0x79e6c9){if(document['readyState']==='complete')_0x79e6c9();else{let _0x34214e=!0x1;const _0x37563b=function(){if(!document['body']){setTimeout(_0x37563b,Math['floor'](0xa));return;}_0x34214e||(_0x34214e=!0x0,_0x79e6c9());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x37563b,!0x1),window['addEventListener']('load',_0x37563b,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x37563b();}),window['attachEvent']('onload',_0x37563b));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x14c261,_0x5dbd55){if(_0x14c261===_0x5dbd55)return 0x0;if(_0x14c261===xe||_0x5dbd55===Ie)return-0x1;if(_0x5dbd55===xe||_0x14c261===Ie)return 0x1;{const _0x4f58ab=Hs(_0x14c261),_0x24fb68=Hs(_0x5dbd55);return _0x4f58ab!==null?_0x24fb68!==null?_0x4f58ab-_0x24fb68===0x0?_0x14c261['length']-_0x5dbd55['length']:_0x4f58ab-_0x24fb68:-0x1:_0x24fb68!==null?0x1:_0x14c261<_0x5dbd55?-0x1:0x1;}},Hl=function(_0x10afec,_0x7f1a54){return _0x10afec===_0x7f1a54?0x0:_0x10afec<_0x7f1a54?-0x1:0x1;},pt=function(_0x3eca4a,_0x13a39e){if(_0x13a39e&&_0x3eca4a in _0x13a39e)return _0x13a39e[_0x3eca4a];throw new Error('Missing\x20required\x20key\x20('+_0x3eca4a+')\x20in\x20object:\x20'+O(_0x13a39e));},Bi=function(_0x23ca77){if(typeof _0x23ca77!='object'||_0x23ca77===null)return O(_0x23ca77);const _0x319db1=[];for(const _0xfb70e1 in _0x23ca77)_0x319db1['push'](_0xfb70e1);_0x319db1['sort']();let _0x5a4f57='{';for(let _0x314ae8=0x0;_0x314ae8<_0x319db1['length'];_0x314ae8++)_0x314ae8!==0x0&&(_0x5a4f57+=','),_0x5a4f57+=O(_0x319db1[_0x314ae8]),_0x5a4f57+=':',_0x5a4f57+=Bi(_0x23ca77[_0x319db1[_0x314ae8]]);return _0x5a4f57+='}',_0x5a4f57;},io=function(_0x57cfe5,_0x1f00ef){const _0xf417b6=_0x57cfe5['length'];if(_0xf417b6<=_0x1f00ef)return[_0x57cfe5];const _0x20b1ef=[];for(let _0x4fd967=0x0;_0x4fd967<_0xf417b6;_0x4fd967+=_0x1f00ef)_0x4fd967+_0x1f00ef>_0xf417b6?_0x20b1ef['push'](_0x57cfe5['substring'](_0x4fd967,_0xf417b6)):_0x20b1ef['push'](_0x57cfe5['substring'](_0x4fd967,_0x4fd967+_0x1f00ef));return _0x20b1ef;};function x(_0x2bdc5e,_0x13e22f){for(const _0x2d51ea in _0x2bdc5e)_0x2bdc5e['hasOwnProperty'](_0x2d51ea)&&_0x13e22f(_0x2d51ea,_0x2bdc5e[_0x2d51ea]);}const so=function(_0x1ec61e){f(!Wi(_0x1ec61e),'Invalid\x20JSON\x20number');const _0x5ed5fe=0xb,_0x2ddcec=0x34,_0x47c3d6=(0x1<<_0x5ed5fe-0x1)-0x1;let _0x3675b1,_0x110ebc,_0x4c1261,_0x27f9a4,_0x2fb5e5;_0x1ec61e===0x0?(_0x110ebc=0x0,_0x4c1261=0x0,_0x3675b1=0x1/_0x1ec61e===-0x1/0x0?0x1:0x0):(_0x3675b1=_0x1ec61e<0x0,_0x1ec61e=Math['abs'](_0x1ec61e),_0x1ec61e>=Math['pow'](0x2,0x1-_0x47c3d6)?(_0x27f9a4=Math['min'](Math['floor'](Math['log'](_0x1ec61e)/Math['LN2']),_0x47c3d6),_0x110ebc=_0x27f9a4+_0x47c3d6,_0x4c1261=Math['round'](_0x1ec61e*Math['pow'](0x2,_0x2ddcec-_0x27f9a4)-Math['pow'](0x2,_0x2ddcec))):(_0x110ebc=0x0,_0x4c1261=Math['round'](_0x1ec61e/Math['pow'](0x2,0x1-_0x47c3d6-_0x2ddcec))));const _0x10d852=[];for(_0x2fb5e5=_0x2ddcec;_0x2fb5e5;_0x2fb5e5-=0x1)_0x10d852['push'](_0x4c1261%0x2?0x1:0x0),_0x4c1261=Math['floor'](_0x4c1261/0x2);for(_0x2fb5e5=_0x5ed5fe;_0x2fb5e5;_0x2fb5e5-=0x1)_0x10d852['push'](_0x110ebc%0x2?0x1:0x0),_0x110ebc=Math['floor'](_0x110ebc/0x2);_0x10d852['push'](_0x3675b1?0x1:0x0),_0x10d852['reverse']();const _0x10ee5b=_0x10d852['join']('');let _0xe282df='';for(_0x2fb5e5=0x0;_0x2fb5e5<0x40;_0x2fb5e5+=0x8){let _0x2707a5=parseInt(_0x10ee5b['substr'](_0x2fb5e5,0x8),0x2)['toString'](0x10);_0x2707a5['length']===0x1&&(_0x2707a5='0'+_0x2707a5),_0xe282df=_0xe282df+_0x2707a5;}return _0xe282df['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x374d39,_0x5a2f46){let _0x27d4c6='Unknown\x20Error';_0x374d39==='too_big'?_0x27d4c6='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x374d39==='permission_denied'?_0x27d4c6='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x374d39==='unavailable'&&(_0x27d4c6='The\x20service\x20is\x20unavailable');const _0x7d04e3=new Error(_0x374d39+'\x20at\x20'+_0x5a2f46['_path']['toString']()+':\x20'+_0x27d4c6);return _0x7d04e3['code']=_0x374d39['toUpperCase'](),_0x7d04e3;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x596a4d){if(zl['test'](_0x596a4d)){const _0x3077c9=Number(_0x596a4d);if(_0x3077c9>=jl&&_0x3077c9<=Kl)return _0x3077c9;}return null;},lt=function(_0x4ea638){try{_0x4ea638();}catch(_0x21880b){setTimeout(()=>{const _0x30d793=_0x21880b['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x30d793),_0x21880b;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x37f138,_0x3f7264){const _0x1fe25e=setTimeout(_0x37f138,_0x3f7264);return typeof _0x1fe25e=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1fe25e):typeof _0x1fe25e=='object'&&_0x1fe25e['unref']&&_0x1fe25e['unref'](),_0x1fe25e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x3950e1,_0x1b23a8){this['appCheckProvider']=_0x1b23a8,this['appName']=_0x3950e1['name'],H(_0x3950e1)&&_0x3950e1['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3950e1['settings']['appCheckToken']),this['appCheck']=_0x1b23a8==null?void 0x0:_0x1b23a8['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1b23a8==null||_0x1b23a8['get']()['then'](_0x4ba63c=>this['appCheck']=_0x4ba63c);}['getToken'](_0x11fb41){if(this['serverAppAppCheckToken']){if(_0x11fb41)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x11fb41):new Promise((_0x216330,_0x488eee)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x11fb41)['then'](_0x216330,_0x488eee):_0x216330(null);},0x0);});}['addTokenChangeListener'](_0x3b2346){var _0xfa12f8;(_0xfa12f8=this['appCheckProvider'])==null||_0xfa12f8['get']()['then'](_0x162cbc=>_0x162cbc['addTokenListener'](_0x3b2346));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x483d80,_0x2a134f,_0x2d15df){this['appName_']=_0x483d80,this['firebaseOptions_']=_0x2a134f,this['authProvider_']=_0x2d15df,this['auth_']=null,this['auth_']=_0x2d15df['getImmediate']({'optional':!0x0}),this['auth_']||_0x2d15df['onInit'](_0xa30eb4=>this['auth_']=_0xa30eb4);}['getToken'](_0x3a8456){return this['auth_']?this['auth_']['getToken'](_0x3a8456)['catch'](_0x40f8f0=>_0x40f8f0&&_0x40f8f0['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x40f8f0)):new Promise((_0x4ffa60,_0xdeeff4)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3a8456)['then'](_0x4ffa60,_0xdeeff4):_0x4ffa60(null);},0x0);});}['addTokenChangeListener'](_0x4da008){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4da008):this['authProvider_']['get']()['then'](_0x41cbfe=>_0x41cbfe['addAuthTokenListener'](_0x4da008));}['removeTokenChangeListener'](_0x539781){this['authProvider_']['get']()['then'](_0x513b56=>_0x513b56['removeAuthTokenListener'](_0x539781));}['notifyForInvalidToken'](){let _0x2b4295='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2b4295+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2b4295+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2b4295+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2b4295);}}class tn{constructor(_0x16b34b){this['accessToken']=_0x16b34b;}['getToken'](_0x93632e){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x590a64){_0x590a64(this['accessToken']);}['removeTokenChangeListener'](_0x268819){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x4815d6,_0x50ef26,_0x10173b,_0x5e7b13,_0x2dd42a=!0x1,_0x1947bd='',_0x2895e6=!0x1,_0xac3292=!0x1,_0x3e490a=null){this['secure']=_0x50ef26,this['namespace']=_0x10173b,this['webSocketOnly']=_0x5e7b13,this['nodeAdmin']=_0x2dd42a,this['persistenceKey']=_0x1947bd,this['includeNamespaceInQueryParams']=_0x2895e6,this['isUsingEmulator']=_0xac3292,this['emulatorOptions']=_0x3e490a,this['_host']=_0x4815d6['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x4815d6)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1229a2){_0x1229a2!==this['internalHost']&&(this['internalHost']=_0x1229a2,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3922ff=this['toURLString']();return this['persistenceKey']&&(_0x3922ff+='<'+this['persistenceKey']+'>'),_0x3922ff;}['toURLString'](){const _0x41f076=this['secure']?'https://':'http://',_0x28337e=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x41f076+this['host']+'/'+_0x28337e;}}function Xl(_0x55a613){return _0x55a613['host']!==_0x55a613['internalHost']||_0x55a613['isCustomHost']()||_0x55a613['includeNamespaceInQueryParams'];}function go(_0x19f535,_0x100c27,_0x2602e7){f(typeof _0x100c27=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2602e7=='object','typeof\x20params\x20must\x20==\x20object');let _0x816200;if(_0x100c27===fo)_0x816200=(_0x19f535['secure']?'wss://':'ws://')+_0x19f535['internalHost']+'/.ws?';else{if(_0x100c27===po)_0x816200=(_0x19f535['secure']?'https://':'http://')+_0x19f535['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x100c27);}Xl(_0x19f535)&&(_0x2602e7['ns']=_0x19f535['namespace']);const _0x4d124d=[];return x(_0x2602e7,(_0x171afc,_0x1bf646)=>{_0x4d124d['push'](_0x171afc+'='+_0x1bf646);}),_0x816200+_0x4d124d['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x4f5b6e,_0x16e0e0=0x1){Y(this['counters_'],_0x4f5b6e)||(this['counters_'][_0x4f5b6e]=0x0),this['counters_'][_0x4f5b6e]+=_0x16e0e0;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x48d7a8){const _0x2ba81a=_0x48d7a8['toString']();return ti[_0x2ba81a]||(ti[_0x2ba81a]=new Zl()),ti[_0x2ba81a];}function eh(_0x576c0e,_0x283fe4){const _0x245d7a=_0x576c0e['toString']();return ni[_0x245d7a]||(ni[_0x245d7a]=_0x283fe4()),ni[_0x245d7a];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x5253a3){this['onMessage_']=_0x5253a3,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x133bff,_0xa37cd9){this['closeAfterResponse']=_0x133bff,this['onClose']=_0xa37cd9,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3f12b5,_0x9d5b3f){for(this['pendingResponses'][_0x3f12b5]=_0x9d5b3f;this['pendingResponses'][this['currentResponseNum']];){const _0x113474=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5e1a98=0x0;_0x5e1a98<_0x113474['length'];++_0x5e1a98)_0x113474[_0x5e1a98]&&lt(()=>{this['onMessage_'](_0x113474[_0x5e1a98]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x2f86c0,_0x1b18c9,_0x597362,_0x4a4ba0,_0x494f48,_0xa244d,_0x5a64ba){this['connId']=_0x2f86c0,this['repoInfo']=_0x1b18c9,this['applicationId']=_0x597362,this['appCheckToken']=_0x4a4ba0,this['authToken']=_0x494f48,this['transportSessionId']=_0xa244d,this['lastSessionId']=_0x5a64ba,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x2f86c0),this['stats_']=Hi(_0x1b18c9),this['urlFn']=_0x3c5d97=>(this['appCheckToken']&&(_0x3c5d97[yi]=this['appCheckToken']),go(_0x1b18c9,po,_0x3c5d97));}['open'](_0x4f86f3,_0x220403){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x220403,this['myPacketOrderer']=new th(_0x4f86f3),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x3bf725)=>{const [_0x3758eb,_0x5ed3ab,_0x4e83a6,_0x2a2875,_0x59ae4b]=_0x3bf725;if(this['incrementIncomingBytes_'](_0x3bf725),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3758eb===$s)this['id']=_0x5ed3ab,this['password']=_0x4e83a6;else{if(_0x3758eb===nh)_0x5ed3ab?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5ed3ab,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3758eb);}}},(..._0x178f97)=>{const [_0x87a699,_0x155143]=_0x178f97;this['incrementIncomingBytes_'](_0x178f97),this['myPacketOrderer']['handleResponse'](_0x87a699,_0x155143);},()=>{this['onClosed_']();},this['urlFn']);const _0x4c0655={};_0x4c0655[$s]='t',_0x4c0655[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4c0655[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4c0655[ro]=Vi,this['transportSessionId']&&(_0x4c0655[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x4c0655[ho]=this['lastSessionId']),this['applicationId']&&(_0x4c0655[uo]=this['applicationId']),this['appCheckToken']&&(_0x4c0655[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4c0655[ao]=co);const _0x21acf9=this['urlFn'](_0x4c0655);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x21acf9),this['scriptTagHolder']['addTag'](_0x21acf9,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x47687a){const _0x462405=O(_0x47687a);this['bytesSent']+=_0x462405['length'],this['stats_']['incrementCounter']('bytes_sent',_0x462405['length']);const _0x3b4c31=Br(_0x462405),_0x304298=io(_0x3b4c31,hh);for(let _0x31a991=0x0;_0x31a991<_0x304298['length'];_0x31a991++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x304298['length'],_0x304298[_0x31a991]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x185594,_0x36b649){this['myDisconnFrame']=document['createElement']('iframe');const _0x3a5790={};_0x3a5790[lh]='t',_0x3a5790[mo]=_0x185594,_0x3a5790[yo]=_0x36b649,this['myDisconnFrame']['src']=this['urlFn'](_0x3a5790),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2d21a7){const _0x50edf8=O(_0x2d21a7)['length'];this['bytesReceived']+=_0x50edf8,this['stats_']['incrementCounter']('bytes_received',_0x50edf8);}}class $i{constructor(_0x5d3c6a,_0x52b67a,_0x50b34f,_0x47f9f8){this['onDisconnect']=_0x50b34f,this['urlFn']=_0x47f9f8,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x5d3c6a,window[sh+this['uniqueCallbackIdentifier']]=_0x52b67a,this['myIFrame']=$i['createIFrame_']();let _0x7aeae9='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x7aeae9='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x5ceda9='<html><body>'+_0x7aeae9+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x5ceda9),this['myIFrame']['doc']['close']();}catch(_0x561e38){L('frame\x20writing\x20exception'),_0x561e38['stack']&&L(_0x561e38['stack']),L(_0x561e38);}}}static['createIFrame_'](){const _0x442f58=document['createElement']('iframe');if(_0x442f58['style']['display']='none',document['body']){document['body']['appendChild'](_0x442f58);try{_0x442f58['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x175b42=document['domain'];_0x442f58['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x175b42+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x442f58['contentDocument']?_0x442f58['doc']=_0x442f58['contentDocument']:_0x442f58['contentWindow']?_0x442f58['doc']=_0x442f58['contentWindow']['document']:_0x442f58['document']&&(_0x442f58['doc']=_0x442f58['document']),_0x442f58;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x54fe59=this['onDisconnect'];_0x54fe59&&(this['onDisconnect']=null,_0x54fe59());}['startLongPoll'](_0xa0e2df,_0xecc7ba){for(this['myID']=_0xa0e2df,this['myPW']=_0xecc7ba,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x223e97={};_0x223e97[mo]=this['myID'],_0x223e97[yo]=this['myPW'],_0x223e97[vo]=this['currentSerial'];let _0x44acb6=this['urlFn'](_0x223e97),_0x153ddc='',_0x58a4fe=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x153ddc['length']<=Eo;){const _0x22e9d0=this['pendingSegs']['shift']();_0x153ddc=_0x153ddc+'&'+oh+_0x58a4fe+'='+_0x22e9d0['seg']+'&'+ah+_0x58a4fe+'='+_0x22e9d0['ts']+'&'+ch+_0x58a4fe+'='+_0x22e9d0['d'],_0x58a4fe++;}return _0x44acb6=_0x44acb6+_0x153ddc,this['addLongPollTag_'](_0x44acb6,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x46b34d,_0x1fb324,_0x57e236){this['pendingSegs']['push']({'seg':_0x46b34d,'ts':_0x1fb324,'d':_0x57e236}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4effac,_0x427fbf){this['outstandingRequests']['add'](_0x427fbf);const _0x1b8da3=()=>{this['outstandingRequests']['delete'](_0x427fbf),this['newRequest_']();},_0x34b2f8=setTimeout(_0x1b8da3,Math['floor'](uh)),_0x213607=()=>{clearTimeout(_0x34b2f8),_0x1b8da3();};this['addTag'](_0x4effac,_0x213607);}['addTag'](_0x217cc8,_0x1029e7){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3ff159=this['myIFrame']['doc']['createElement']('script');_0x3ff159['type']='text/javascript',_0x3ff159['async']=!0x0,_0x3ff159['src']=_0x217cc8,_0x3ff159['onload']=_0x3ff159['onreadystatechange']=function(){const _0x52188f=_0x3ff159['readyState'];(!_0x52188f||_0x52188f==='loaded'||_0x52188f==='complete')&&(_0x3ff159['onload']=_0x3ff159['onreadystatechange']=null,_0x3ff159['parentNode']&&_0x3ff159['parentNode']['removeChild'](_0x3ff159),_0x1029e7());},_0x3ff159['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x217cc8),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3ff159);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x372bb0,_0x4ab227,_0x2d6654,_0x4e6bce,_0x287538,_0xd93d3d,_0x26879a){this['connId']=_0x372bb0,this['applicationId']=_0x2d6654,this['appCheckToken']=_0x4e6bce,this['authToken']=_0x287538,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x4ab227),this['connURL']=G['connectionURL_'](_0x4ab227,_0xd93d3d,_0x26879a,_0x4e6bce,_0x2d6654),this['nodeAdmin']=_0x4ab227['nodeAdmin'];}static['connectionURL_'](_0x4c2a97,_0x3b9174,_0x1041be,_0x2356e9,_0x27616b){const _0x27beed={};return _0x27beed[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x27beed[ao]=co),_0x3b9174&&(_0x27beed[oo]=_0x3b9174),_0x1041be&&(_0x27beed[ho]=_0x1041be),_0x2356e9&&(_0x27beed[yi]=_0x2356e9),_0x27616b&&(_0x27beed[uo]=_0x27616b),go(_0x4c2a97,fo,_0x27beed);}['open'](_0x24f04b,_0x8dda15){this['onDisconnect']=_0x8dda15,this['onMessage']=_0x24f04b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x5de6e0;dc(),this['mySock']=new hn(this['connURL'],[],_0x5de6e0);}catch(_0x5aba5c){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x5a09c1=_0x5aba5c['message']||_0x5aba5c['data'];_0x5a09c1&&this['log_'](_0x5a09c1),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x15ef94=>{this['handleIncomingFrame'](_0x15ef94);},this['mySock']['onerror']=_0x3ba6bd=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5c834a=_0x3ba6bd['message']||_0x3ba6bd['data'];_0x5c834a&&this['log_'](_0x5c834a),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x42e887=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x59ca39=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5317bd=navigator['userAgent']['match'](_0x59ca39);_0x5317bd&&_0x5317bd['length']>0x1&&parseFloat(_0x5317bd[0x1])<4.4&&(_0x42e887=!0x0);}return!_0x42e887&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x5cac1d){if(this['frames']['push'](_0x5cac1d),this['frames']['length']===this['totalFrames']){const _0x20b8f5=this['frames']['join']('');this['frames']=null;const _0x26a859=bt(_0x20b8f5);this['onMessage'](_0x26a859);}}['handleNewFrameCount_'](_0x37c681){this['totalFrames']=_0x37c681,this['frames']=[];}['extractFrameCount_'](_0x1d3bc7){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x1d3bc7['length']<=0x6){const _0x3f92ca=Number(_0x1d3bc7);if(!isNaN(_0x3f92ca))return this['handleNewFrameCount_'](_0x3f92ca),null;}return this['handleNewFrameCount_'](0x1),_0x1d3bc7;}['handleIncomingFrame'](_0x4b2f35){if(this['mySock']===null)return;const _0xcc97d1=_0x4b2f35['data'];if(this['bytesReceived']+=_0xcc97d1['length'],this['stats_']['incrementCounter']('bytes_received',_0xcc97d1['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0xcc97d1);else{const _0x1e16d2=this['extractFrameCount_'](_0xcc97d1);_0x1e16d2!==null&&this['appendFrame_'](_0x1e16d2);}}['send'](_0x27d0c6){this['resetKeepAlive']();const _0x32cc2d=O(_0x27d0c6);this['bytesSent']+=_0x32cc2d['length'],this['stats_']['incrementCounter']('bytes_sent',_0x32cc2d['length']);const _0x24025d=io(_0x32cc2d,fh);_0x24025d['length']>0x1&&this['sendString_'](String(_0x24025d['length']));for(let _0x4ee558=0x0;_0x4ee558<_0x24025d['length'];_0x4ee558++)this['sendString_'](_0x24025d[_0x4ee558]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x357a8f){try{this['mySock']['send'](_0x357a8f);}catch(_0x221d1f){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x221d1f['message']||_0x221d1f['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4d0248){this['initTransports_'](_0x4d0248);}['initTransports_'](_0x795189){const _0x5bec9e=G&&G['isAvailable']();let _0x5ecf04=_0x5bec9e&&!G['previouslyFailed']();if(_0x795189['webSocketOnly']&&(_0x5bec9e||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5ecf04=!0x0),_0x5ecf04)this['transports_']=[G];else{const _0x5984a4=this['transports_']=[];for(const _0x4170 of At['ALL_TRANSPORTS'])_0x4170&&_0x4170['isAvailable']()&&_0x5984a4['push'](_0x4170);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x1f153f,_0x298c18,_0x3acc29,_0x163a37,_0x2d8636,_0x13e340,_0x2ec46a,_0x3d6345,_0x32c2df,_0x5ec14e){this['id']=_0x1f153f,this['repoInfo_']=_0x298c18,this['applicationId_']=_0x3acc29,this['appCheckToken_']=_0x163a37,this['authToken_']=_0x2d8636,this['onMessage_']=_0x13e340,this['onReady_']=_0x2ec46a,this['onDisconnect_']=_0x3d6345,this['onKill_']=_0x32c2df,this['lastSessionId']=_0x5ec14e,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x298c18),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4118da=this['transportManager_']['initialTransport']();this['conn_']=new _0x4118da(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4118da['responsesRequiredToBeHealthy']||0x0;const _0x4fea63=this['connReceiver_'](this['conn_']),_0x33d248=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x4fea63,_0x33d248);},Math['floor'](0x0));const _0x3abb67=_0x4118da['healthyTimeout']||0x0;_0x3abb67>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3abb67)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x70309a){return _0x4bb6ce=>{_0x70309a===this['conn_']?this['onConnectionLost_'](_0x4bb6ce):_0x70309a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xcad7e0){return _0x79867b=>{this['state_']!==0x2&&(_0xcad7e0===this['rx_']?this['onPrimaryMessageReceived_'](_0x79867b):_0xcad7e0===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x79867b):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3ac6d2){const _0x3fb5ca={'t':'d','d':_0x3ac6d2};this['sendData_'](_0x3fb5ca);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x962926){if(ii in _0x962926){const _0x5a0053=_0x962926[ii];_0x5a0053===js?this['upgradeIfSecondaryHealthy_']():_0x5a0053===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5a0053===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x45fd2b){const _0x3fca84=pt('t',_0x45fd2b),_0x82ca00=pt('d',_0x45fd2b);if(_0x3fca84==='c')this['onSecondaryControl_'](_0x82ca00);else{if(_0x3fca84==='d')this['pendingDataMessages']['push'](_0x82ca00);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3fca84);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2c9f6a){const _0x57418a=pt('t',_0x2c9f6a),_0x27a2c6=pt('d',_0x2c9f6a);_0x57418a==='c'?this['onControl_'](_0x27a2c6):_0x57418a==='d'&&this['onDataMessage_'](_0x27a2c6);}['onDataMessage_'](_0x3166b7){this['onPrimaryResponse_'](),this['onMessage_'](_0x3166b7);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x32b7be){const _0x29f557=pt(ii,_0x32b7be);if(Gs in _0x32b7be){const _0x46f280=_0x32b7be[Gs];if(_0x29f557===Ih){const _0xf2830c={..._0x46f280};this['repoInfo_']['isUsingEmulator']&&(_0xf2830c['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xf2830c);}else{if(_0x29f557===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x264b89=0x0;_0x264b89<this['pendingDataMessages']['length'];++_0x264b89)this['onDataMessage_'](this['pendingDataMessages'][_0x264b89]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x29f557===vh?this['onConnectionShutdown_'](_0x46f280):_0x29f557===qs?this['onReset_'](_0x46f280):_0x29f557===Eh?mi('Server\x20Error:\x20'+_0x46f280):_0x29f557===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x29f557);}}}['onHandshake_'](_0x9779fe){const _0x4e517d=_0x9779fe['ts'],_0x597b03=_0x9779fe['v'],_0x2d93ac=_0x9779fe['h'];this['sessionId']=_0x9779fe['s'],this['repoInfo_']['host']=_0x2d93ac,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x4e517d),Vi!==_0x597b03&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x4cfc1b=this['transportManager_']['upgradeTransport']();_0x4cfc1b&&this['startUpgrade_'](_0x4cfc1b);}['startUpgrade_'](_0x138858){this['secondaryConn_']=new _0x138858(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x138858['responsesRequiredToBeHealthy']||0x0;const _0x5954c7=this['connReceiver_'](this['secondaryConn_']),_0x34ef30=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x5954c7,_0x34ef30),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0xf70029){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xf70029),this['repoInfo_']['host']=_0xf70029,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3279d6,_0x28d3a6){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3279d6,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x28d3a6,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x429b4f=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x429b4f||this['rx_']===_0x429b4f)&&this['close']();}['onConnectionLost_'](_0x511f48){this['conn_']=null,!_0x511f48&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3f8db7){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3f8db7),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x42545f){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x42545f);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x45fbd2,_0x2df915,_0x33d6d7,_0x4793c6){}['merge'](_0x2f48ec,_0x40b422,_0x419430,_0x1b8753){}['refreshAuthToken'](_0x1cd28c){}['refreshAppCheckToken'](_0x1cc647){}['onDisconnectPut'](_0x1a1865,_0x2e3bcc,_0x50e0ca){}['onDisconnectMerge'](_0x5ab4cb,_0x12ac86,_0x3d7f5e){}['onDisconnectCancel'](_0x2774b6,_0x1c6ca4){}['reportStats'](_0x20f904){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x1d887c){this['allowedEvents_']=_0x1d887c,this['listeners_']={},f(Array['isArray'](_0x1d887c)&&_0x1d887c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5819e7,..._0x29aa67){if(Array['isArray'](this['listeners_'][_0x5819e7])){const _0x62a1b0=[...this['listeners_'][_0x5819e7]];for(let _0x292f5d=0x0;_0x292f5d<_0x62a1b0['length'];_0x292f5d++)_0x62a1b0[_0x292f5d]['callback']['apply'](_0x62a1b0[_0x292f5d]['context'],_0x29aa67);}}['on'](_0x13d724,_0x53e409,_0x428e46){this['validateEventType_'](_0x13d724),this['listeners_'][_0x13d724]=this['listeners_'][_0x13d724]||[],this['listeners_'][_0x13d724]['push']({'callback':_0x53e409,'context':_0x428e46});const _0x5394a6=this['getInitialEvent'](_0x13d724);_0x5394a6&&_0x53e409['apply'](_0x428e46,_0x5394a6);}['off'](_0x1f6d2d,_0x42ee11,_0x143118){this['validateEventType_'](_0x1f6d2d);const _0x5f04b1=this['listeners_'][_0x1f6d2d]||[];for(let _0x1583b6=0x0;_0x1583b6<_0x5f04b1['length'];_0x1583b6++)if(_0x5f04b1[_0x1583b6]['callback']===_0x42ee11&&(!_0x143118||_0x143118===_0x5f04b1[_0x1583b6]['context'])){_0x5f04b1['splice'](_0x1583b6,0x1);return;}}['validateEventType_'](_0x5d9791){f(this['allowedEvents_']['find'](_0x2317c1=>_0x2317c1===_0x5d9791),'Unknown\x20event:\x20'+_0x5d9791);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x38f6cb){return f(_0x38f6cb==='online','Unknown\x20event\x20type:\x20'+_0x38f6cb),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x49bbf0,_0x52faf5){if(_0x52faf5===void 0x0){this['pieces_']=_0x49bbf0['split']('/');let _0x16171d=0x0;for(let _0x512a7f=0x0;_0x512a7f<this['pieces_']['length'];_0x512a7f++)this['pieces_'][_0x512a7f]['length']>0x0&&(this['pieces_'][_0x16171d]=this['pieces_'][_0x512a7f],_0x16171d++);this['pieces_']['length']=_0x16171d,this['pieceNum_']=0x0;}else this['pieces_']=_0x49bbf0,this['pieceNum_']=_0x52faf5;}['toString'](){let _0x2e46e4='';for(let _0x24df2d=this['pieceNum_'];_0x24df2d<this['pieces_']['length'];_0x24df2d++)this['pieces_'][_0x24df2d]!==''&&(_0x2e46e4+='/'+this['pieces_'][_0x24df2d]);return _0x2e46e4||'/';}}function w(){return new C('');}function y(_0x3b8817){return _0x3b8817['pieceNum_']>=_0x3b8817['pieces_']['length']?null:_0x3b8817['pieces_'][_0x3b8817['pieceNum_']];}function we(_0x5a2553){return _0x5a2553['pieces_']['length']-_0x5a2553['pieceNum_'];}function b(_0xec255f){let _0x4e201b=_0xec255f['pieceNum_'];return _0x4e201b<_0xec255f['pieces_']['length']&&_0x4e201b++,new C(_0xec255f['pieces_'],_0x4e201b);}function Gi(_0x3a5361){return _0x3a5361['pieceNum_']<_0x3a5361['pieces_']['length']?_0x3a5361['pieces_'][_0x3a5361['pieces_']['length']-0x1]:null;}function Ch(_0x5cec45){let _0x1cdaef='';for(let _0x217e29=_0x5cec45['pieceNum_'];_0x217e29<_0x5cec45['pieces_']['length'];_0x217e29++)_0x5cec45['pieces_'][_0x217e29]!==''&&(_0x1cdaef+='/'+encodeURIComponent(String(_0x5cec45['pieces_'][_0x217e29])));return _0x1cdaef||'/';}function kt(_0x564ddc,_0x3f9c6f=0x0){return _0x564ddc['pieces_']['slice'](_0x564ddc['pieceNum_']+_0x3f9c6f);}function To(_0x84f037){if(_0x84f037['pieceNum_']>=_0x84f037['pieces_']['length'])return null;const _0x4dfd0d=[];for(let _0x69b604=_0x84f037['pieceNum_'];_0x69b604<_0x84f037['pieces_']['length']-0x1;_0x69b604++)_0x4dfd0d['push'](_0x84f037['pieces_'][_0x69b604]);return new C(_0x4dfd0d,0x0);}function A(_0x7eb46b,_0x39324f){const _0x953a2a=[];for(let _0x1ac26=_0x7eb46b['pieceNum_'];_0x1ac26<_0x7eb46b['pieces_']['length'];_0x1ac26++)_0x953a2a['push'](_0x7eb46b['pieces_'][_0x1ac26]);if(_0x39324f instanceof C){for(let _0x2fb623=_0x39324f['pieceNum_'];_0x2fb623<_0x39324f['pieces_']['length'];_0x2fb623++)_0x953a2a['push'](_0x39324f['pieces_'][_0x2fb623]);}else{const _0x4de8ed=_0x39324f['split']('/');for(let _0x15e7d1=0x0;_0x15e7d1<_0x4de8ed['length'];_0x15e7d1++)_0x4de8ed[_0x15e7d1]['length']>0x0&&_0x953a2a['push'](_0x4de8ed[_0x15e7d1]);}return new C(_0x953a2a,0x0);}function v(_0x3a3716){return _0x3a3716['pieceNum_']>=_0x3a3716['pieces_']['length'];}function F(_0x496848,_0x3f0bc8){const _0x138062=y(_0x496848),_0x5eb472=y(_0x3f0bc8);if(_0x138062===null)return _0x3f0bc8;if(_0x138062===_0x5eb472)return F(b(_0x496848),b(_0x3f0bc8));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3f0bc8+')\x20is\x20not\x20within\x20outerPath\x20('+_0x496848+')');}function Th(_0x6ad842,_0x58e079){const _0x209e5a=kt(_0x6ad842,0x0),_0x4e72d0=kt(_0x58e079,0x0);for(let _0x231d36=0x0;_0x231d36<_0x209e5a['length']&&_0x231d36<_0x4e72d0['length'];_0x231d36++){const _0x310b83=He(_0x209e5a[_0x231d36],_0x4e72d0[_0x231d36]);if(_0x310b83!==0x0)return _0x310b83;}return _0x209e5a['length']===_0x4e72d0['length']?0x0:_0x209e5a['length']<_0x4e72d0['length']?-0x1:0x1;}function qi(_0x35fe9e,_0x4742c8){if(we(_0x35fe9e)!==we(_0x4742c8))return!0x1;for(let _0x59cb0b=_0x35fe9e['pieceNum_'],_0x449b82=_0x4742c8['pieceNum_'];_0x59cb0b<=_0x35fe9e['pieces_']['length'];_0x59cb0b++,_0x449b82++)if(_0x35fe9e['pieces_'][_0x59cb0b]!==_0x4742c8['pieces_'][_0x449b82])return!0x1;return!0x0;}function $(_0x4aca6f,_0x2d5287){let _0x27dccd=_0x4aca6f['pieceNum_'],_0x459162=_0x2d5287['pieceNum_'];if(we(_0x4aca6f)>we(_0x2d5287))return!0x1;for(;_0x27dccd<_0x4aca6f['pieces_']['length'];){if(_0x4aca6f['pieces_'][_0x27dccd]!==_0x2d5287['pieces_'][_0x459162])return!0x1;++_0x27dccd,++_0x459162;}return!0x0;}class Sh{constructor(_0xf6a02f,_0x25f1f2){this['errorPrefix_']=_0x25f1f2,this['parts_']=kt(_0xf6a02f,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0xf26e19=0x0;_0xf26e19<this['parts_']['length'];_0xf26e19++)this['byteLength_']+=Pn(this['parts_'][_0xf26e19]);So(this);}}function bh(_0x118b91,_0x389e22){_0x118b91['parts_']['length']>0x0&&(_0x118b91['byteLength_']+=0x1),_0x118b91['parts_']['push'](_0x389e22),_0x118b91['byteLength_']+=Pn(_0x389e22),So(_0x118b91);}function Rh(_0x3f5d7a){const _0x50f3e0=_0x3f5d7a['parts_']['pop']();_0x3f5d7a['byteLength_']-=Pn(_0x50f3e0),_0x3f5d7a['parts_']['length']>0x0&&(_0x3f5d7a['byteLength_']-=0x1);}function So(_0x5b7236){if(_0x5b7236['byteLength_']>Js)throw new Error(_0x5b7236['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x5b7236['byteLength_']+').');if(_0x5b7236['parts_']['length']>Qs)throw new Error(_0x5b7236['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x5b7236));}function Ne(_0x19cfe6){return _0x19cfe6['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x19cfe6['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x172253,_0xecb747;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xecb747='visibilitychange',_0x172253='hidden'):typeof document['mozHidden']<'u'?(_0xecb747='mozvisibilitychange',_0x172253='mozHidden'):typeof document['msHidden']<'u'?(_0xecb747='msvisibilitychange',_0x172253='msHidden'):typeof document['webkitHidden']<'u'&&(_0xecb747='webkitvisibilitychange',_0x172253='webkitHidden')),this['visible_']=!0x0,_0xecb747&&document['addEventListener'](_0xecb747,()=>{const _0x28a473=!document[_0x172253];_0x28a473!==this['visible_']&&(this['visible_']=_0x28a473,this['trigger']('visible',_0x28a473));},!0x1);}['getInitialEvent'](_0x334344){return f(_0x334344==='visible','Unknown\x20event\x20type:\x20'+_0x334344),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x3090ba,_0x5d87a6,_0x2521d5,_0x100bc6,_0x2c6718,_0xf9cb5d,_0x3f07d0,_0x2cfe25){if(super(),this['repoInfo_']=_0x3090ba,this['applicationId_']=_0x5d87a6,this['onDataUpdate_']=_0x2521d5,this['onConnectStatus_']=_0x100bc6,this['onServerInfoUpdate_']=_0x2c6718,this['authTokenProvider_']=_0xf9cb5d,this['appCheckTokenProvider_']=_0x3f07d0,this['authOverride_']=_0x2cfe25,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x2cfe25)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3090ba['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x252e7c,_0x341ec7,_0x2466da){const _0x550c41=++this['requestNumber_'],_0x901bfd={'r':_0x550c41,'a':_0x252e7c,'b':_0x341ec7};this['log_'](O(_0x901bfd)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x901bfd),_0x2466da&&(this['requestCBHash_'][_0x550c41]=_0x2466da);}['get'](_0x5442c4){this['initConnection_']();const _0x3990c8=new Ve(),_0x41e017={'action':'g','request':{'p':_0x5442c4['_path']['toString'](),'q':_0x5442c4['_queryObject']},'onComplete':_0x3e8ede=>{const _0x4810d1=_0x3e8ede['d'];_0x3e8ede['s']==='ok'?_0x3990c8['resolve'](_0x4810d1):_0x3990c8['reject'](_0x4810d1);}};this['outstandingGets_']['push'](_0x41e017),this['outstandingGetCount_']++;const _0x376263=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x376263),_0x3990c8['promise'];}['listen'](_0xbbf1e8,_0x44e73f,_0x4a90c8,_0x249a47){this['initConnection_']();const _0x23a228=_0xbbf1e8['_queryIdentifier'],_0x592f74=_0xbbf1e8['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x592f74+'\x20'+_0x23a228),this['listens']['has'](_0x592f74)||this['listens']['set'](_0x592f74,new Map()),f(_0xbbf1e8['_queryParams']['isDefault']()||!_0xbbf1e8['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x592f74)['has'](_0x23a228),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x498f78={'onComplete':_0x249a47,'hashFn':_0x44e73f,'query':_0xbbf1e8,'tag':_0x4a90c8};this['listens']['get'](_0x592f74)['set'](_0x23a228,_0x498f78),this['connected_']&&this['sendListen_'](_0x498f78);}['sendGet_'](_0x44e968){const _0xf3de26=this['outstandingGets_'][_0x44e968];this['sendRequest']('g',_0xf3de26['request'],_0x55c0b0=>{delete this['outstandingGets_'][_0x44e968],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xf3de26['onComplete']&&_0xf3de26['onComplete'](_0x55c0b0);});}['sendListen_'](_0x1c7211){const _0x4d5377=_0x1c7211['query'],_0x6f817a=_0x4d5377['_path']['toString'](),_0x97d9d4=_0x4d5377['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x6f817a+'\x20for\x20'+_0x97d9d4);const _0x301753={'p':_0x6f817a},_0x8d37f9='q';_0x1c7211['tag']&&(_0x301753['q']=_0x4d5377['_queryObject'],_0x301753['t']=_0x1c7211['tag']),_0x301753['h']=_0x1c7211['hashFn'](),this['sendRequest'](_0x8d37f9,_0x301753,_0x20d9b8=>{const _0x23f99c=_0x20d9b8['d'],_0x3d8787=_0x20d9b8['s'];ie['warnOnListenWarnings_'](_0x23f99c,_0x4d5377),(this['listens']['get'](_0x6f817a)&&this['listens']['get'](_0x6f817a)['get'](_0x97d9d4))===_0x1c7211&&(this['log_']('listen\x20response',_0x20d9b8),_0x3d8787!=='ok'&&this['removeListen_'](_0x6f817a,_0x97d9d4),_0x1c7211['onComplete']&&_0x1c7211['onComplete'](_0x3d8787,_0x23f99c));});}static['warnOnListenWarnings_'](_0x465fbb,_0x258769){if(_0x465fbb&&typeof _0x465fbb=='object'&&Y(_0x465fbb,'w')){const _0xf5eb58=Oe(_0x465fbb,'w');if(Array['isArray'](_0xf5eb58)&&~_0xf5eb58['indexOf']('no_index')){const _0x3b28ac='\x22.indexOn\x22:\x20\x22'+_0x258769['_queryParams']['getIndex']()['toString']()+'\x22',_0x3fba09=_0x258769['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3b28ac+'\x20at\x20'+_0x3fba09+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x22397b){this['authToken_']=_0x22397b,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x22397b);}['reduceReconnectDelayIfAdminCredential_'](_0x5ec5dc){(_0x5ec5dc&&_0x5ec5dc['length']===0x28||vc(_0x5ec5dc))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x23cc28){this['appCheckToken_']=_0x23cc28,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x354ac2=this['authToken_'],_0x3c2c3a=yc(_0x354ac2)?'auth':'gauth',_0x5ee982={'cred':_0x354ac2};this['authOverride_']===null?_0x5ee982['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5ee982['authvar']=this['authOverride_']),this['sendRequest'](_0x3c2c3a,_0x5ee982,_0x4fc00b=>{const _0x1b3c4b=_0x4fc00b['s'],_0x9ff61d=_0x4fc00b['d']||'error';this['authToken_']===_0x354ac2&&(_0x1b3c4b==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x1b3c4b,_0x9ff61d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3d1a1d=>{const _0x49a119=_0x3d1a1d['s'],_0x235b2b=_0x3d1a1d['d']||'error';_0x49a119==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x49a119,_0x235b2b);});}['unlisten'](_0x28f6b2,_0x55ddd2){const _0x1f4845=_0x28f6b2['_path']['toString'](),_0x301d2e=_0x28f6b2['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1f4845+'\x20'+_0x301d2e),f(_0x28f6b2['_queryParams']['isDefault']()||!_0x28f6b2['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1f4845,_0x301d2e)&&this['connected_']&&this['sendUnlisten_'](_0x1f4845,_0x301d2e,_0x28f6b2['_queryObject'],_0x55ddd2);}['sendUnlisten_'](_0x34dc58,_0x17a388,_0x1f5caf,_0x56aa82){this['log_']('Unlisten\x20on\x20'+_0x34dc58+'\x20for\x20'+_0x17a388);const _0x29b2a7={'p':_0x34dc58},_0x3fbbd1='n';_0x56aa82&&(_0x29b2a7['q']=_0x1f5caf,_0x29b2a7['t']=_0x56aa82),this['sendRequest'](_0x3fbbd1,_0x29b2a7);}['onDisconnectPut'](_0x54af1a,_0x50e1e0,_0x431db4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x54af1a,_0x50e1e0,_0x431db4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x54af1a,'action':'o','data':_0x50e1e0,'onComplete':_0x431db4});}['onDisconnectMerge'](_0x2fcaa3,_0x512b45,_0x56c5c6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2fcaa3,_0x512b45,_0x56c5c6):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2fcaa3,'action':'om','data':_0x512b45,'onComplete':_0x56c5c6});}['onDisconnectCancel'](_0x41fd21,_0xcfb3d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x41fd21,null,_0xcfb3d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x41fd21,'action':'oc','data':null,'onComplete':_0xcfb3d});}['sendOnDisconnect_'](_0x44be89,_0x5d8d32,_0x201c65,_0x3d4ffa){const _0x4f73aa={'p':_0x5d8d32,'d':_0x201c65};this['log_']('onDisconnect\x20'+_0x44be89,_0x4f73aa),this['sendRequest'](_0x44be89,_0x4f73aa,_0x3fb526=>{_0x3d4ffa&&setTimeout(()=>{_0x3d4ffa(_0x3fb526['s'],_0x3fb526['d']);},Math['floor'](0x0));});}['put'](_0x3af557,_0x370ea4,_0x39d753,_0x599e95){this['putInternal']('p',_0x3af557,_0x370ea4,_0x39d753,_0x599e95);}['merge'](_0x2ac05e,_0x29442f,_0x5c4bd3,_0x194a25){this['putInternal']('m',_0x2ac05e,_0x29442f,_0x5c4bd3,_0x194a25);}['putInternal'](_0x18c899,_0x34397e,_0xb1ae46,_0x227c68,_0x32957b){this['initConnection_']();const _0x3c5e6c={'p':_0x34397e,'d':_0xb1ae46};_0x32957b!==void 0x0&&(_0x3c5e6c['h']=_0x32957b),this['outstandingPuts_']['push']({'action':_0x18c899,'request':_0x3c5e6c,'onComplete':_0x227c68}),this['outstandingPutCount_']++;const _0x2aae71=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2aae71):this['log_']('Buffering\x20put:\x20'+_0x34397e);}['sendPut_'](_0x4a29c3){const _0xb7f9a0=this['outstandingPuts_'][_0x4a29c3]['action'],_0x112889=this['outstandingPuts_'][_0x4a29c3]['request'],_0x21f923=this['outstandingPuts_'][_0x4a29c3]['onComplete'];this['outstandingPuts_'][_0x4a29c3]['queued']=this['connected_'],this['sendRequest'](_0xb7f9a0,_0x112889,_0x311f96=>{this['log_'](_0xb7f9a0+'\x20response',_0x311f96),delete this['outstandingPuts_'][_0x4a29c3],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x21f923&&_0x21f923(_0x311f96['s'],_0x311f96['d']);});}['reportStats'](_0x3e7d88){if(this['connected_']){const _0x5409b8={'c':_0x3e7d88};this['log_']('reportStats',_0x5409b8),this['sendRequest']('s',_0x5409b8,_0x22d150=>{if(_0x22d150['s']!=='ok'){const _0x344ba3=_0x22d150['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x344ba3);}});}}['onDataMessage_'](_0x314a0c){if('r'in _0x314a0c){this['log_']('from\x20server:\x20'+O(_0x314a0c));const _0x55cb57=_0x314a0c['r'],_0x2b58dd=this['requestCBHash_'][_0x55cb57];_0x2b58dd&&(delete this['requestCBHash_'][_0x55cb57],_0x2b58dd(_0x314a0c['b']));}else{if('error'in _0x314a0c)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x314a0c['error'];'a'in _0x314a0c&&this['onDataPush_'](_0x314a0c['a'],_0x314a0c['b']);}}['onDataPush_'](_0x32698d,_0x28870e){this['log_']('handleServerMessage',_0x32698d,_0x28870e),_0x32698d==='d'?this['onDataUpdate_'](_0x28870e['p'],_0x28870e['d'],!0x1,_0x28870e['t']):_0x32698d==='m'?this['onDataUpdate_'](_0x28870e['p'],_0x28870e['d'],!0x0,_0x28870e['t']):_0x32698d==='c'?this['onListenRevoked_'](_0x28870e['p'],_0x28870e['q']):_0x32698d==='ac'?this['onAuthRevoked_'](_0x28870e['s'],_0x28870e['d']):_0x32698d==='apc'?this['onAppCheckRevoked_'](_0x28870e['s'],_0x28870e['d']):_0x32698d==='sd'?this['onSecurityDebugPacket_'](_0x28870e):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x32698d)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x141f42,_0xc41dab){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x141f42),this['lastSessionId']=_0xc41dab,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0xa27ee3){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0xa27ee3));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x59aa7d){_0x59aa7d&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x59aa7d;}['onOnline_'](_0x2bf49f){_0x2bf49f?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x32ff80=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x363d4c=Math['max'](0x0,this['reconnectDelay_']-_0x32ff80);_0x363d4c=Math['random']()*_0x363d4c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x363d4c+'ms'),this['scheduleConnect_'](_0x363d4c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0xc65ca8=this['onDataMessage_']['bind'](this),_0xd1e52=this['onReady_']['bind'](this),_0x5c0afd=this['onRealtimeDisconnect_']['bind'](this),_0x48d58d=this['id']+':'+ie['nextConnectionId_']++,_0x5a7e09=this['lastSessionId'];let _0x2ad2d2=!0x1,_0x6d95d1=null;const _0x183410=function(){_0x6d95d1?_0x6d95d1['close']():(_0x2ad2d2=!0x0,_0x5c0afd());},_0x533a6b=function(_0x1c3dca){f(_0x6d95d1,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x6d95d1['sendRequest'](_0x1c3dca);};this['realtime_']={'close':_0x183410,'sendRequest':_0x533a6b};const _0x1db819=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x387b1f,_0xb9fcf2]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x1db819),this['appCheckTokenProvider_']['getToken'](_0x1db819)]);_0x2ad2d2?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x387b1f&&_0x387b1f['accessToken'],this['appCheckToken_']=_0xb9fcf2&&_0xb9fcf2['token'],_0x6d95d1=new wh(_0x48d58d,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0xc65ca8,_0xd1e52,_0x5c0afd,_0x508cb7=>{U(_0x508cb7+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x5a7e09));}catch(_0xc0d5ff){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0xc0d5ff),_0x2ad2d2||(this['repoInfo_']['nodeAdmin']&&U(_0xc0d5ff),_0x183410());}}}['interrupt'](_0x3af4e5){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3af4e5),this['interruptReasons_'][_0x3af4e5]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x34966e){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x34966e),delete this['interruptReasons_'][_0x34966e],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2b7a68){const _0x297df0=_0x2b7a68-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x297df0});}['cancelSentTransactions_'](){for(let _0x5e95c7=0x0;_0x5e95c7<this['outstandingPuts_']['length'];_0x5e95c7++){const _0xf894f1=this['outstandingPuts_'][_0x5e95c7];_0xf894f1&&'h'in _0xf894f1['request']&&_0xf894f1['queued']&&(_0xf894f1['onComplete']&&_0xf894f1['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x5e95c7],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x49687e,_0xa5c760){let _0x500681;_0xa5c760?_0x500681=_0xa5c760['map'](_0x1f2223=>Bi(_0x1f2223))['join']('$'):_0x500681='default';const _0x4d1b9d=this['removeListen_'](_0x49687e,_0x500681);_0x4d1b9d&&_0x4d1b9d['onComplete']&&_0x4d1b9d['onComplete']('permission_denied');}['removeListen_'](_0x1fa7fb,_0x2ff097){const _0x2b9a0a=new C(_0x1fa7fb)['toString']();let _0x5f50ca;if(this['listens']['has'](_0x2b9a0a)){const _0x12b161=this['listens']['get'](_0x2b9a0a);_0x5f50ca=_0x12b161['get'](_0x2ff097),_0x12b161['delete'](_0x2ff097),_0x12b161['size']===0x0&&this['listens']['delete'](_0x2b9a0a);}else _0x5f50ca=void 0x0;return _0x5f50ca;}['onAuthRevoked_'](_0x2c85ea,_0x59dc8b){L('Auth\x20token\x20revoked:\x20'+_0x2c85ea+'/'+_0x59dc8b),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2c85ea==='invalid_token'||_0x2c85ea==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x3bc59f,_0x3fc3af){L('App\x20check\x20token\x20revoked:\x20'+_0x3bc59f+'/'+_0x3fc3af),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x3bc59f==='invalid_token'||_0x3bc59f==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4c4038){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4c4038):'msg'in _0x4c4038&&console['log']('FIREBASE:\x20'+_0x4c4038['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5c0f78 of this['listens']['values']())for(const _0x940912 of _0x5c0f78['values']())this['sendListen_'](_0x940912);for(let _0x1e876a=0x0;_0x1e876a<this['outstandingPuts_']['length'];_0x1e876a++)this['outstandingPuts_'][_0x1e876a]&&this['sendPut_'](_0x1e876a);for(;this['onDisconnectRequestQueue_']['length'];){const _0x47f747=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x47f747['action'],_0x47f747['pathString'],_0x47f747['data'],_0x47f747['onComplete']);}for(let _0x591f04=0x0;_0x591f04<this['outstandingGets_']['length'];_0x591f04++)this['outstandingGets_'][_0x591f04]&&this['sendGet_'](_0x591f04);}['sendConnectStats_'](){const _0x1a944a={};let _0x38461f='js';_0x1a944a['sdk.'+_0x38461f+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x1a944a['framework.cordova']=0x1:qr()&&(_0x1a944a['framework.reactnative']=0x1),this['reportStats'](_0x1a944a);}['shouldReconnect_'](){const _0x16c37f=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x16c37f;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x33f4ed,_0x2f5a35){this['name']=_0x33f4ed,this['node']=_0x2f5a35;}static['Wrap'](_0x5bfa9e,_0x4bf5ed){return new E(_0x5bfa9e,_0x4bf5ed);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x14b15f,_0x17497a){const _0x651cf2=new E(xe,_0x14b15f),_0x599d22=new E(xe,_0x17497a);return this['compare'](_0x651cf2,_0x599d22)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0xba2a98){Xt=_0xba2a98;}['compare'](_0x12795c,_0x253b6d){return He(_0x12795c['name'],_0x253b6d['name']);}['isDefinedOn'](_0x4d3397){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4f2eba,_0x291fbf){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x3fe062,_0x37287c){return f(typeof _0x3fe062=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3fe062,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4b17bb,_0x38acb4,_0x257f21,_0x1ff4cb,_0x2cbfa7=null){this['isReverse_']=_0x1ff4cb,this['resultGenerator_']=_0x2cbfa7,this['nodeStack_']=[];let _0x5ceebf=0x1;for(;!_0x4b17bb['isEmpty']();)if(_0x4b17bb=_0x4b17bb,_0x5ceebf=_0x38acb4?_0x257f21(_0x4b17bb['key'],_0x38acb4):0x1,_0x1ff4cb&&(_0x5ceebf*=-0x1),_0x5ceebf<0x0)this['isReverse_']?_0x4b17bb=_0x4b17bb['left']:_0x4b17bb=_0x4b17bb['right'];else{if(_0x5ceebf===0x0){this['nodeStack_']['push'](_0x4b17bb);break;}else this['nodeStack_']['push'](_0x4b17bb),this['isReverse_']?_0x4b17bb=_0x4b17bb['right']:_0x4b17bb=_0x4b17bb['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x30cc34=this['nodeStack_']['pop'](),_0x61d7d3;if(this['resultGenerator_']?_0x61d7d3=this['resultGenerator_'](_0x30cc34['key'],_0x30cc34['value']):_0x61d7d3={'key':_0x30cc34['key'],'value':_0x30cc34['value']},this['isReverse_']){for(_0x30cc34=_0x30cc34['left'];!_0x30cc34['isEmpty']();)this['nodeStack_']['push'](_0x30cc34),_0x30cc34=_0x30cc34['right'];}else{for(_0x30cc34=_0x30cc34['right'];!_0x30cc34['isEmpty']();)this['nodeStack_']['push'](_0x30cc34),_0x30cc34=_0x30cc34['left'];}return _0x61d7d3;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1ad28f=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1ad28f['key'],_0x1ad28f['value']):{'key':_0x1ad28f['key'],'value':_0x1ad28f['value']};}}class M{constructor(_0xa428ab,_0x2c34ce,_0x434f9d,_0x1021bd,_0x38cc7a){this['key']=_0xa428ab,this['value']=_0x2c34ce,this['color']=_0x434f9d??M['RED'],this['left']=_0x1021bd??B['EMPTY_NODE'],this['right']=_0x38cc7a??B['EMPTY_NODE'];}['copy'](_0x4f8cf8,_0x434534,_0x565ea5,_0x1c685e,_0x1c397d){return new M(_0x4f8cf8??this['key'],_0x434534??this['value'],_0x565ea5??this['color'],_0x1c685e??this['left'],_0x1c397d??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x31a511){return this['left']['inorderTraversal'](_0x31a511)||!!_0x31a511(this['key'],this['value'])||this['right']['inorderTraversal'](_0x31a511);}['reverseTraversal'](_0x1d54d3){return this['right']['reverseTraversal'](_0x1d54d3)||_0x1d54d3(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1d54d3);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x17ca4c,_0x6f384f,_0x18606a){let _0x18ce5f=this;const _0x5aa946=_0x18606a(_0x17ca4c,_0x18ce5f['key']);return _0x5aa946<0x0?_0x18ce5f=_0x18ce5f['copy'](null,null,null,_0x18ce5f['left']['insert'](_0x17ca4c,_0x6f384f,_0x18606a),null):_0x5aa946===0x0?_0x18ce5f=_0x18ce5f['copy'](null,_0x6f384f,null,null,null):_0x18ce5f=_0x18ce5f['copy'](null,null,null,null,_0x18ce5f['right']['insert'](_0x17ca4c,_0x6f384f,_0x18606a)),_0x18ce5f['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x441d81=this;return!_0x441d81['left']['isRed_']()&&!_0x441d81['left']['left']['isRed_']()&&(_0x441d81=_0x441d81['moveRedLeft_']()),_0x441d81=_0x441d81['copy'](null,null,null,_0x441d81['left']['removeMin_'](),null),_0x441d81['fixUp_']();}['remove'](_0x449954,_0x21ea79){let _0x2eadc,_0x2ab37f;if(_0x2eadc=this,_0x21ea79(_0x449954,_0x2eadc['key'])<0x0)!_0x2eadc['left']['isEmpty']()&&!_0x2eadc['left']['isRed_']()&&!_0x2eadc['left']['left']['isRed_']()&&(_0x2eadc=_0x2eadc['moveRedLeft_']()),_0x2eadc=_0x2eadc['copy'](null,null,null,_0x2eadc['left']['remove'](_0x449954,_0x21ea79),null);else{if(_0x2eadc['left']['isRed_']()&&(_0x2eadc=_0x2eadc['rotateRight_']()),!_0x2eadc['right']['isEmpty']()&&!_0x2eadc['right']['isRed_']()&&!_0x2eadc['right']['left']['isRed_']()&&(_0x2eadc=_0x2eadc['moveRedRight_']()),_0x21ea79(_0x449954,_0x2eadc['key'])===0x0){if(_0x2eadc['right']['isEmpty']())return B['EMPTY_NODE'];_0x2ab37f=_0x2eadc['right']['min_'](),_0x2eadc=_0x2eadc['copy'](_0x2ab37f['key'],_0x2ab37f['value'],null,null,_0x2eadc['right']['removeMin_']());}_0x2eadc=_0x2eadc['copy'](null,null,null,null,_0x2eadc['right']['remove'](_0x449954,_0x21ea79));}return _0x2eadc['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x474c0a=this;return _0x474c0a['right']['isRed_']()&&!_0x474c0a['left']['isRed_']()&&(_0x474c0a=_0x474c0a['rotateLeft_']()),_0x474c0a['left']['isRed_']()&&_0x474c0a['left']['left']['isRed_']()&&(_0x474c0a=_0x474c0a['rotateRight_']()),_0x474c0a['left']['isRed_']()&&_0x474c0a['right']['isRed_']()&&(_0x474c0a=_0x474c0a['colorFlip_']()),_0x474c0a;}['moveRedLeft_'](){let _0x1f1742=this['colorFlip_']();return _0x1f1742['right']['left']['isRed_']()&&(_0x1f1742=_0x1f1742['copy'](null,null,null,null,_0x1f1742['right']['rotateRight_']()),_0x1f1742=_0x1f1742['rotateLeft_'](),_0x1f1742=_0x1f1742['colorFlip_']()),_0x1f1742;}['moveRedRight_'](){let _0x6e3a8c=this['colorFlip_']();return _0x6e3a8c['left']['left']['isRed_']()&&(_0x6e3a8c=_0x6e3a8c['rotateRight_'](),_0x6e3a8c=_0x6e3a8c['colorFlip_']()),_0x6e3a8c;}['rotateLeft_'](){const _0x3c6d26=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3c6d26,null);}['rotateRight_'](){const _0x40b7d1=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x40b7d1);}['colorFlip_'](){const _0x53c3ac=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x10a4ea=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x53c3ac,_0x10a4ea);}['checkMaxDepth_'](){const _0x1abb44=this['check_']();return Math['pow'](0x2,_0x1abb44)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x142a6e=this['left']['check_']();if(_0x142a6e!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x142a6e+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x190ce5,_0x5befcf,_0x3e9037,_0x4c3b05,_0x48de63){return this;}['insert'](_0x2cb170,_0x7cbb81,_0x25d612){return new M(_0x2cb170,_0x7cbb81,null);}['remove'](_0x466b73,_0x4edf70){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x592ee1){return!0x1;}['reverseTraversal'](_0x4bd8be){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x44c14e,_0x2297ca=B['EMPTY_NODE']){this['comparator_']=_0x44c14e,this['root_']=_0x2297ca;}['insert'](_0x27878a,_0x1b9988){return new B(this['comparator_'],this['root_']['insert'](_0x27878a,_0x1b9988,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x19ce6c){return new B(this['comparator_'],this['root_']['remove'](_0x19ce6c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0xcc5c09){let _0x2cdebd,_0xc826d1=this['root_'];for(;!_0xc826d1['isEmpty']();){if(_0x2cdebd=this['comparator_'](_0xcc5c09,_0xc826d1['key']),_0x2cdebd===0x0)return _0xc826d1['value'];_0x2cdebd<0x0?_0xc826d1=_0xc826d1['left']:_0x2cdebd>0x0&&(_0xc826d1=_0xc826d1['right']);}return null;}['getPredecessorKey'](_0x413f4d){let _0x18b691,_0x2395d7=this['root_'],_0x37cf4d=null;for(;!_0x2395d7['isEmpty']();)if(_0x18b691=this['comparator_'](_0x413f4d,_0x2395d7['key']),_0x18b691===0x0){if(_0x2395d7['left']['isEmpty']())return _0x37cf4d?_0x37cf4d['key']:null;for(_0x2395d7=_0x2395d7['left'];!_0x2395d7['right']['isEmpty']();)_0x2395d7=_0x2395d7['right'];return _0x2395d7['key'];}else _0x18b691<0x0?_0x2395d7=_0x2395d7['left']:_0x18b691>0x0&&(_0x37cf4d=_0x2395d7,_0x2395d7=_0x2395d7['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2b50be){return this['root_']['inorderTraversal'](_0x2b50be);}['reverseTraversal'](_0x5029c0){return this['root_']['reverseTraversal'](_0x5029c0);}['getIterator'](_0x216ece){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x216ece);}['getIteratorFrom'](_0x464be4,_0x506664){return new Zt(this['root_'],_0x464be4,this['comparator_'],!0x1,_0x506664);}['getReverseIteratorFrom'](_0x218a64,_0x3484fe){return new Zt(this['root_'],_0x218a64,this['comparator_'],!0x0,_0x3484fe);}['getReverseIterator'](_0x3a740a){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x3a740a);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x58a56e,_0x1d81fc){return He(_0x58a56e['name'],_0x1d81fc['name']);}function ji(_0x578f91,_0x23c9df){return He(_0x578f91,_0x23c9df);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x3b15bc){vi=_0x3b15bc;}const Ro=function(_0x2c8959){return typeof _0x2c8959=='number'?'number:'+so(_0x2c8959):'string:'+_0x2c8959;},Ao=function(_0x177ed1){if(_0x177ed1['isLeafNode']()){const _0xac32b0=_0x177ed1['val']();f(typeof _0xac32b0=='string'||typeof _0xac32b0=='number'||typeof _0xac32b0=='object'&&Y(_0xac32b0,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x177ed1===vi||_0x177ed1['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x177ed1===vi||_0x177ed1['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x139699){er=_0x139699;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x12fd9f,_0x42e832=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x12fd9f,this['priorityNode_']=_0x42e832,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x22a759){return new D(this['value_'],_0x22a759);}['getImmediateChild'](_0x322a76){return _0x322a76==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3100d2){return v(_0x3100d2)?this:y(_0x3100d2)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4d557a,_0x5c654a){return null;}['updateImmediateChild'](_0x14646e,_0x664a24){return _0x14646e==='.priority'?this['updatePriority'](_0x664a24):_0x664a24['isEmpty']()&&_0x14646e!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x14646e,_0x664a24)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4a051e,_0x3c7685){const _0x535e96=y(_0x4a051e);return _0x535e96===null?_0x3c7685:_0x3c7685['isEmpty']()&&_0x535e96!=='.priority'?this:(f(_0x535e96!=='.priority'||we(_0x4a051e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x535e96,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x4a051e),_0x3c7685)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3907d0,_0x4e52c7){return!0x1;}['val'](_0x57fd59){return _0x57fd59&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x12b163='';this['priorityNode_']['isEmpty']()||(_0x12b163+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x57bbdc=typeof this['value_'];_0x12b163+=_0x57bbdc+':',_0x57bbdc==='number'?_0x12b163+=so(this['value_']):_0x12b163+=this['value_'],this['lazyHash_']=no(_0x12b163);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x4ef5c0){return _0x4ef5c0===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x4ef5c0 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x4ef5c0['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x4ef5c0));}['compareToLeafNode_'](_0x1b222d){const _0x5a0934=typeof _0x1b222d['value_'],_0x448320=typeof this['value_'],_0x35263e=D['VALUE_TYPE_ORDER']['indexOf'](_0x5a0934),_0x5021ec=D['VALUE_TYPE_ORDER']['indexOf'](_0x448320);return f(_0x35263e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5a0934),f(_0x5021ec>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x448320),_0x35263e===_0x5021ec?_0x448320==='object'?0x0:this['value_']<_0x1b222d['value_']?-0x1:this['value_']===_0x1b222d['value_']?0x0:0x1:_0x5021ec-_0x35263e;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1138c4){if(_0x1138c4===this)return!0x0;if(_0x1138c4['isLeafNode']()){const _0x4ecb33=_0x1138c4;return this['value_']===_0x4ecb33['value_']&&this['priorityNode_']['equals'](_0x4ecb33['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x564db4){ko=_0x564db4;}function xh(_0x8ed75b){No=_0x8ed75b;}class Fh extends On{['compare'](_0x16bef1,_0x5ad227){const _0x1d0c6d=_0x16bef1['node']['getPriority'](),_0x3ac214=_0x5ad227['node']['getPriority'](),_0x588d76=_0x1d0c6d['compareTo'](_0x3ac214);return _0x588d76===0x0?He(_0x16bef1['name'],_0x5ad227['name']):_0x588d76;}['isDefinedOn'](_0x3fa3cd){return!_0x3fa3cd['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x515883,_0x2ba0fe){return!_0x515883['getPriority']()['equals'](_0x2ba0fe['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x3e287f,_0x35d6f1){const _0x174416=ko(_0x3e287f);return new E(_0x35d6f1,new D('[PRIORITY-POST]',_0x174416));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x292250){const _0x282695=_0x4a9ecf=>parseInt(Math['log'](_0x4a9ecf)/Uh,0xa),_0x32a109=_0x2d4922=>parseInt(Array(_0x2d4922+0x1)['join']('1'),0x2);this['count']=_0x282695(_0x292250+0x1),this['current_']=this['count']-0x1;const _0x531005=_0x32a109(this['count']);this['bits_']=_0x292250+0x1&_0x531005;}['nextBitIsOne'](){const _0x557d1f=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x557d1f;}}const dn=function(_0x2c771d,_0x4e35d4,_0x2c4aca,_0x389518){_0x2c771d['sort'](_0x4e35d4);const _0x1331f4=function(_0x5b21d6,_0x8b8752){const _0x30f0e7=_0x8b8752-_0x5b21d6;let _0x1dde1b,_0x50fb9a;if(_0x30f0e7===0x0)return null;if(_0x30f0e7===0x1)return _0x1dde1b=_0x2c771d[_0x5b21d6],_0x50fb9a=_0x2c4aca?_0x2c4aca(_0x1dde1b):_0x1dde1b,new M(_0x50fb9a,_0x1dde1b['node'],M['BLACK'],null,null);{const _0x43cf3a=parseInt(_0x30f0e7/0x2,0xa)+_0x5b21d6,_0x2a0bf9=_0x1331f4(_0x5b21d6,_0x43cf3a),_0x13e87c=_0x1331f4(_0x43cf3a+0x1,_0x8b8752);return _0x1dde1b=_0x2c771d[_0x43cf3a],_0x50fb9a=_0x2c4aca?_0x2c4aca(_0x1dde1b):_0x1dde1b,new M(_0x50fb9a,_0x1dde1b['node'],M['BLACK'],_0x2a0bf9,_0x13e87c);}},_0xb29a12=function(_0x292b60){let _0x375502=null,_0x1acf01=null,_0x1117af=_0x2c771d['length'];const _0x58f978=function(_0x21d4be,_0x519db5){const _0x370007=_0x1117af-_0x21d4be,_0x21bcb3=_0x1117af;_0x1117af-=_0x21d4be;const _0x5734e3=_0x1331f4(_0x370007+0x1,_0x21bcb3),_0x585f1e=_0x2c771d[_0x370007],_0x2b5f72=_0x2c4aca?_0x2c4aca(_0x585f1e):_0x585f1e;_0x507a20(new M(_0x2b5f72,_0x585f1e['node'],_0x519db5,null,_0x5734e3));},_0x507a20=function(_0x376713){_0x375502?(_0x375502['left']=_0x376713,_0x375502=_0x376713):(_0x1acf01=_0x376713,_0x375502=_0x376713);};for(let _0x1231d7=0x0;_0x1231d7<_0x292b60['count'];++_0x1231d7){const _0x1b17b4=_0x292b60['nextBitIsOne'](),_0x5ad1c4=Math['pow'](0x2,_0x292b60['count']-(_0x1231d7+0x1));_0x1b17b4?_0x58f978(_0x5ad1c4,M['BLACK']):(_0x58f978(_0x5ad1c4,M['BLACK']),_0x58f978(_0x5ad1c4,M['RED']));}return _0x1acf01;},_0x2e0bc1=new Wh(_0x2c771d['length']),_0x2c8ef1=_0xb29a12(_0x2e0bc1);return new B(_0x389518||_0x4e35d4,_0x2c8ef1);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x41e6b7,_0x4d44c1){this['indexes_']=_0x41e6b7,this['indexSet_']=_0x4d44c1;}['get'](_0x551efa){const _0x2f9425=Oe(this['indexes_'],_0x551efa);if(!_0x2f9425)throw new Error('No\x20index\x20defined\x20for\x20'+_0x551efa);return _0x2f9425 instanceof B?_0x2f9425:null;}['hasIndex'](_0x31cbc8){return Y(this['indexSet_'],_0x31cbc8['toString']());}['addIndex'](_0x221b2f,_0x1c13bd){f(_0x221b2f!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x23b745=[];let _0x34646a=!0x1;const _0x28178b=_0x1c13bd['getIterator'](E['Wrap']);let _0x3eae0a=_0x28178b['getNext']();for(;_0x3eae0a;)_0x34646a=_0x34646a||_0x221b2f['isDefinedOn'](_0x3eae0a['node']),_0x23b745['push'](_0x3eae0a),_0x3eae0a=_0x28178b['getNext']();let _0x55ab28;_0x34646a?_0x55ab28=dn(_0x23b745,_0x221b2f['getCompare']()):_0x55ab28=je;const _0xbf4f53=_0x221b2f['toString'](),_0x4a7948={...this['indexSet_']};_0x4a7948[_0xbf4f53]=_0x221b2f;const _0x3fbd36={...this['indexes_']};return _0x3fbd36[_0xbf4f53]=_0x55ab28,new ee(_0x3fbd36,_0x4a7948);}['addToIndexes'](_0x30c4f1,_0x1087cf){const _0x538e82=ln(this['indexes_'],(_0x4c9c3f,_0x313b5b)=>{const _0x74bbeb=Oe(this['indexSet_'],_0x313b5b);if(f(_0x74bbeb,'Missing\x20index\x20implementation\x20for\x20'+_0x313b5b),_0x4c9c3f===je){if(_0x74bbeb['isDefinedOn'](_0x30c4f1['node'])){const _0x344328=[],_0x52e0a5=_0x1087cf['getIterator'](E['Wrap']);let _0x10b0e7=_0x52e0a5['getNext']();for(;_0x10b0e7;)_0x10b0e7['name']!==_0x30c4f1['name']&&_0x344328['push'](_0x10b0e7),_0x10b0e7=_0x52e0a5['getNext']();return _0x344328['push'](_0x30c4f1),dn(_0x344328,_0x74bbeb['getCompare']());}else return je;}else{const _0xd7c065=_0x1087cf['get'](_0x30c4f1['name']);let _0x3c3f9e=_0x4c9c3f;return _0xd7c065&&(_0x3c3f9e=_0x3c3f9e['remove'](new E(_0x30c4f1['name'],_0xd7c065))),_0x3c3f9e['insert'](_0x30c4f1,_0x30c4f1['node']);}});return new ee(_0x538e82,this['indexSet_']);}['removeFromIndexes'](_0x3b41f0,_0x43c43f){const _0x2be400=ln(this['indexes_'],_0x5e8409=>{if(_0x5e8409===je)return _0x5e8409;{const _0x749476=_0x43c43f['get'](_0x3b41f0['name']);return _0x749476?_0x5e8409['remove'](new E(_0x3b41f0['name'],_0x749476)):_0x5e8409;}});return new ee(_0x2be400,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x192f90,_0x4af2af,_0x4ea912){this['children_']=_0x192f90,this['priorityNode_']=_0x4af2af,this['indexMap_']=_0x4ea912,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x335144){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x335144,this['indexMap_']);}['getImmediateChild'](_0x579dfd){if(_0x579dfd==='.priority')return this['getPriority']();{const _0x36a782=this['children_']['get'](_0x579dfd);return _0x36a782===null?gt:_0x36a782;}}['getChild'](_0x130382){const _0x8ad807=y(_0x130382);return _0x8ad807===null?this:this['getImmediateChild'](_0x8ad807)['getChild'](b(_0x130382));}['hasChild'](_0x5301d3){return this['children_']['get'](_0x5301d3)!==null;}['updateImmediateChild'](_0x36ab8c,_0x3ced56){if(f(_0x3ced56,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x36ab8c==='.priority')return this['updatePriority'](_0x3ced56);{const _0x13c498=new E(_0x36ab8c,_0x3ced56);let _0x51c66a,_0x302d8f;_0x3ced56['isEmpty']()?(_0x51c66a=this['children_']['remove'](_0x36ab8c),_0x302d8f=this['indexMap_']['removeFromIndexes'](_0x13c498,this['children_'])):(_0x51c66a=this['children_']['insert'](_0x36ab8c,_0x3ced56),_0x302d8f=this['indexMap_']['addToIndexes'](_0x13c498,this['children_']));const _0x519848=_0x51c66a['isEmpty']()?gt:this['priorityNode_'];return new g(_0x51c66a,_0x519848,_0x302d8f);}}['updateChild'](_0x36fe25,_0x230941){const _0x56f58b=y(_0x36fe25);if(_0x56f58b===null)return _0x230941;{f(y(_0x36fe25)!=='.priority'||we(_0x36fe25)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x431cb5=this['getImmediateChild'](_0x56f58b)['updateChild'](b(_0x36fe25),_0x230941);return this['updateImmediateChild'](_0x56f58b,_0x431cb5);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2046e8){if(this['isEmpty']())return null;const _0x5b8bb5={};let _0x24ddb1=0x0,_0x49eb27=0x0,_0x29a696=!0x0;if(this['forEachChild'](R,(_0x26827d,_0x3a8917)=>{_0x5b8bb5[_0x26827d]=_0x3a8917['val'](_0x2046e8),_0x24ddb1++,_0x29a696&&g['INTEGER_REGEXP_']['test'](_0x26827d)?_0x49eb27=Math['max'](_0x49eb27,Number(_0x26827d)):_0x29a696=!0x1;}),!_0x2046e8&&_0x29a696&&_0x49eb27<0x2*_0x24ddb1){const _0x321b12=[];for(const _0x393f05 in _0x5b8bb5)_0x321b12[_0x393f05]=_0x5b8bb5[_0x393f05];return _0x321b12;}else return _0x2046e8&&!this['getPriority']()['isEmpty']()&&(_0x5b8bb5['.priority']=this['getPriority']()['val']()),_0x5b8bb5;}['hash'](){if(this['lazyHash_']===null){let _0x21f22f='';this['getPriority']()['isEmpty']()||(_0x21f22f+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x465c0b,_0x4adc2b)=>{const _0xa70d9c=_0x4adc2b['hash']();_0xa70d9c!==''&&(_0x21f22f+=':'+_0x465c0b+':'+_0xa70d9c);}),this['lazyHash_']=_0x21f22f===''?'':no(_0x21f22f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x631a58,_0x19a2ba,_0x2ea50f){const _0x42af81=this['resolveIndex_'](_0x2ea50f);if(_0x42af81){const _0x404d7c=_0x42af81['getPredecessorKey'](new E(_0x631a58,_0x19a2ba));return _0x404d7c?_0x404d7c['name']:null;}else return this['children_']['getPredecessorKey'](_0x631a58);}['getFirstChildName'](_0xb1da4a){const _0x33956e=this['resolveIndex_'](_0xb1da4a);if(_0x33956e){const _0x67fa5c=_0x33956e['minKey']();return _0x67fa5c&&_0x67fa5c['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x4cb811){const _0x5dea42=this['getFirstChildName'](_0x4cb811);return _0x5dea42?new E(_0x5dea42,this['children_']['get'](_0x5dea42)):null;}['getLastChildName'](_0x258ed8){const _0x56a393=this['resolveIndex_'](_0x258ed8);if(_0x56a393){const _0x4faf1e=_0x56a393['maxKey']();return _0x4faf1e&&_0x4faf1e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1511ac){const _0x3613b3=this['getLastChildName'](_0x1511ac);return _0x3613b3?new E(_0x3613b3,this['children_']['get'](_0x3613b3)):null;}['forEachChild'](_0x4380b0,_0x31b495){const _0x336d6f=this['resolveIndex_'](_0x4380b0);return _0x336d6f?_0x336d6f['inorderTraversal'](_0x5a8191=>_0x31b495(_0x5a8191['name'],_0x5a8191['node'])):this['children_']['inorderTraversal'](_0x31b495);}['getIterator'](_0xc2d379){return this['getIteratorFrom'](_0xc2d379['minPost'](),_0xc2d379);}['getIteratorFrom'](_0x3e1686,_0x102b0f){const _0x1d58e2=this['resolveIndex_'](_0x102b0f);if(_0x1d58e2)return _0x1d58e2['getIteratorFrom'](_0x3e1686,_0x1f01b2=>_0x1f01b2);{const _0x3aa881=this['children_']['getIteratorFrom'](_0x3e1686['name'],E['Wrap']);let _0x28d6ad=_0x3aa881['peek']();for(;_0x28d6ad!=null&&_0x102b0f['compare'](_0x28d6ad,_0x3e1686)<0x0;)_0x3aa881['getNext'](),_0x28d6ad=_0x3aa881['peek']();return _0x3aa881;}}['getReverseIterator'](_0x2194df){return this['getReverseIteratorFrom'](_0x2194df['maxPost'](),_0x2194df);}['getReverseIteratorFrom'](_0x4821ad,_0x4c79b1){const _0x18cc85=this['resolveIndex_'](_0x4c79b1);if(_0x18cc85)return _0x18cc85['getReverseIteratorFrom'](_0x4821ad,_0x11f697=>_0x11f697);{const _0x57595a=this['children_']['getReverseIteratorFrom'](_0x4821ad['name'],E['Wrap']);let _0x453306=_0x57595a['peek']();for(;_0x453306!=null&&_0x4c79b1['compare'](_0x453306,_0x4821ad)>0x0;)_0x57595a['getNext'](),_0x453306=_0x57595a['peek']();return _0x57595a;}}['compareTo'](_0x391a34){return this['isEmpty']()?_0x391a34['isEmpty']()?0x0:-0x1:_0x391a34['isLeafNode']()||_0x391a34['isEmpty']()?0x1:_0x391a34===Ht?-0x1:0x0;}['withIndex'](_0x318b08){if(_0x318b08===ye||this['indexMap_']['hasIndex'](_0x318b08))return this;{const _0x10f4c5=this['indexMap_']['addIndex'](_0x318b08,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x10f4c5);}}['isIndexed'](_0x409a24){return _0x409a24===ye||this['indexMap_']['hasIndex'](_0x409a24);}['equals'](_0x4ddebc){if(_0x4ddebc===this)return!0x0;if(_0x4ddebc['isLeafNode']())return!0x1;{const _0x45e01e=_0x4ddebc;if(this['getPriority']()['equals'](_0x45e01e['getPriority']())){if(this['children_']['count']()===_0x45e01e['children_']['count']()){const _0x5e2177=this['getIterator'](R),_0x1b2352=_0x45e01e['getIterator'](R);let _0x1d6a82=_0x5e2177['getNext'](),_0x65bb1d=_0x1b2352['getNext']();for(;_0x1d6a82&&_0x65bb1d;){if(_0x1d6a82['name']!==_0x65bb1d['name']||!_0x1d6a82['node']['equals'](_0x65bb1d['node']))return!0x1;_0x1d6a82=_0x5e2177['getNext'](),_0x65bb1d=_0x1b2352['getNext']();}return _0x1d6a82===null&&_0x65bb1d===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xc6ba5e){return _0xc6ba5e===ye?null:this['indexMap_']['get'](_0xc6ba5e['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x61f913){return _0x61f913===this?0x0:0x1;}['equals'](_0xc31cfe){return _0xc31cfe===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5d6e8b){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x35befa,_0xb8fc08=null){if(_0x35befa===null)return g['EMPTY_NODE'];if(typeof _0x35befa=='object'&&'.priority'in _0x35befa&&(_0xb8fc08=_0x35befa['.priority']),f(_0xb8fc08===null||typeof _0xb8fc08=='string'||typeof _0xb8fc08=='number'||typeof _0xb8fc08=='object'&&'.sv'in _0xb8fc08,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0xb8fc08),typeof _0x35befa=='object'&&'.value'in _0x35befa&&_0x35befa['.value']!==null&&(_0x35befa=_0x35befa['.value']),typeof _0x35befa!='object'||'.sv'in _0x35befa){const _0x5a8a14=_0x35befa;return new D(_0x5a8a14,N(_0xb8fc08));}if(!(_0x35befa instanceof Array)&&Vh){const _0x50f56a=[];let _0x5e9525=!0x1;if(x(_0x35befa,(_0x67e55a,_0x2109aa)=>{if(_0x67e55a['substring'](0x0,0x1)!=='.'){const _0x1b4ce5=N(_0x2109aa);_0x1b4ce5['isEmpty']()||(_0x5e9525=_0x5e9525||!_0x1b4ce5['getPriority']()['isEmpty'](),_0x50f56a['push'](new E(_0x67e55a,_0x1b4ce5)));}}),_0x50f56a['length']===0x0)return g['EMPTY_NODE'];const _0x45740f=dn(_0x50f56a,Dh,_0x3007a8=>_0x3007a8['name'],ji);if(_0x5e9525){const _0x381069=dn(_0x50f56a,R['getCompare']());return new g(_0x45740f,N(_0xb8fc08),new ee({'.priority':_0x381069},{'.priority':R}));}else return new g(_0x45740f,N(_0xb8fc08),ee['Default']);}else{let _0x4b229c=g['EMPTY_NODE'];return x(_0x35befa,(_0x3666ec,_0x3881ef)=>{if(Y(_0x35befa,_0x3666ec)&&_0x3666ec['substring'](0x0,0x1)!=='.'){const _0x103305=N(_0x3881ef);(_0x103305['isLeafNode']()||!_0x103305['isEmpty']())&&(_0x4b229c=_0x4b229c['updateImmediateChild'](_0x3666ec,_0x103305));}}),_0x4b229c['updatePriority'](N(_0xb8fc08));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x329268){super(),this['indexPath_']=_0x329268,f(!v(_0x329268)&&y(_0x329268)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2f9680){return _0x2f9680['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2539f0){return!_0x2539f0['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x379959,_0x1931ac){const _0x41f699=this['extractChild'](_0x379959['node']),_0x2ab8d0=this['extractChild'](_0x1931ac['node']),_0x12376b=_0x41f699['compareTo'](_0x2ab8d0);return _0x12376b===0x0?He(_0x379959['name'],_0x1931ac['name']):_0x12376b;}['makePost'](_0x1a611c,_0x4ca4a4){const _0x39ca79=N(_0x1a611c),_0x46bc70=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x39ca79);return new E(_0x4ca4a4,_0x46bc70);}['maxPost'](){const _0x5bcf1b=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x5bcf1b);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x335d69,_0x1b2947){const _0x1fed12=_0x335d69['node']['compareTo'](_0x1b2947['node']);return _0x1fed12===0x0?He(_0x335d69['name'],_0x1b2947['name']):_0x1fed12;}['isDefinedOn'](_0x55d113){return!0x0;}['indexedValueChanged'](_0x1628ff,_0x20f8e){return!_0x1628ff['equals'](_0x20f8e);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x301762,_0x4c909e){const _0x295bac=N(_0x301762);return new E(_0x4c909e,_0x295bac);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x392891){return{'type':'value','snapshotNode':_0x392891};}function tt(_0x5aaa8f,_0x53419c){return{'type':'child_added','snapshotNode':_0x53419c,'childName':_0x5aaa8f};}function Nt(_0x51c900,_0x1ea17d){return{'type':'child_removed','snapshotNode':_0x1ea17d,'childName':_0x51c900};}function Pt(_0x30e273,_0x2c4dc3,_0x397d15){return{'type':'child_changed','snapshotNode':_0x2c4dc3,'childName':_0x30e273,'oldSnap':_0x397d15};}function $h(_0x54f382,_0xfd4d7a){return{'type':'child_moved','snapshotNode':_0xfd4d7a,'childName':_0x54f382};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x4d7fe6){this['index_']=_0x4d7fe6;}['updateChild'](_0x13d64d,_0x1fb5d7,_0x5be192,_0x983add,_0x57afa5,_0x28393a){f(_0x13d64d['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x300d13=_0x13d64d['getImmediateChild'](_0x1fb5d7);return _0x300d13['getChild'](_0x983add)['equals'](_0x5be192['getChild'](_0x983add))&&_0x300d13['isEmpty']()===_0x5be192['isEmpty']()||(_0x28393a!=null&&(_0x5be192['isEmpty']()?_0x13d64d['hasChild'](_0x1fb5d7)?_0x28393a['trackChildChange'](Nt(_0x1fb5d7,_0x300d13)):f(_0x13d64d['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x300d13['isEmpty']()?_0x28393a['trackChildChange'](tt(_0x1fb5d7,_0x5be192)):_0x28393a['trackChildChange'](Pt(_0x1fb5d7,_0x5be192,_0x300d13))),_0x13d64d['isLeafNode']()&&_0x5be192['isEmpty']())?_0x13d64d:_0x13d64d['updateImmediateChild'](_0x1fb5d7,_0x5be192)['withIndex'](this['index_']);}['updateFullNode'](_0x189e50,_0x4d7c2a,_0x345731){return _0x345731!=null&&(_0x189e50['isLeafNode']()||_0x189e50['forEachChild'](R,(_0x319b46,_0x582452)=>{_0x4d7c2a['hasChild'](_0x319b46)||_0x345731['trackChildChange'](Nt(_0x319b46,_0x582452));}),_0x4d7c2a['isLeafNode']()||_0x4d7c2a['forEachChild'](R,(_0x1419bf,_0x22891b)=>{if(_0x189e50['hasChild'](_0x1419bf)){const _0x371c71=_0x189e50['getImmediateChild'](_0x1419bf);_0x371c71['equals'](_0x22891b)||_0x345731['trackChildChange'](Pt(_0x1419bf,_0x22891b,_0x371c71));}else _0x345731['trackChildChange'](tt(_0x1419bf,_0x22891b));})),_0x4d7c2a['withIndex'](this['index_']);}['updatePriority'](_0x5cfc6b,_0x3d814e){return _0x5cfc6b['isEmpty']()?g['EMPTY_NODE']:_0x5cfc6b['updatePriority'](_0x3d814e);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x437139){this['indexedFilter_']=new Yi(_0x437139['getIndex']()),this['index_']=_0x437139['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x437139),this['endPost_']=Ot['getEndPost_'](_0x437139),this['startIsInclusive_']=!_0x437139['startAfterSet_'],this['endIsInclusive_']=!_0x437139['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x2bcb6d){const _0x27f154=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x2bcb6d)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x2bcb6d)<0x0,_0xe57260=this['endIsInclusive_']?this['index_']['compare'](_0x2bcb6d,this['getEndPost']())<=0x0:this['index_']['compare'](_0x2bcb6d,this['getEndPost']())<0x0;return _0x27f154&&_0xe57260;}['updateChild'](_0x261a6e,_0x2dc0b0,_0x1c62d6,_0x5c6231,_0x3f71ee,_0x1d4544){return this['matches'](new E(_0x2dc0b0,_0x1c62d6))||(_0x1c62d6=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x261a6e,_0x2dc0b0,_0x1c62d6,_0x5c6231,_0x3f71ee,_0x1d4544);}['updateFullNode'](_0xaa72ae,_0x310a0a,_0xec52f0){_0x310a0a['isLeafNode']()&&(_0x310a0a=g['EMPTY_NODE']);let _0x281f01=_0x310a0a['withIndex'](this['index_']);_0x281f01=_0x281f01['updatePriority'](g['EMPTY_NODE']);const _0x5a643b=this;return _0x310a0a['forEachChild'](R,(_0x3d8d7a,_0x1bc4df)=>{_0x5a643b['matches'](new E(_0x3d8d7a,_0x1bc4df))||(_0x281f01=_0x281f01['updateImmediateChild'](_0x3d8d7a,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0xaa72ae,_0x281f01,_0xec52f0);}['updatePriority'](_0xfb3724,_0x1119bd){return _0xfb3724;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x5d5218){if(_0x5d5218['hasStart']()){const _0x45a035=_0x5d5218['getIndexStartName']();return _0x5d5218['getIndex']()['makePost'](_0x5d5218['getIndexStartValue'](),_0x45a035);}else return _0x5d5218['getIndex']()['minPost']();}static['getEndPost_'](_0x18087b){if(_0x18087b['hasEnd']()){const _0x3b449b=_0x18087b['getIndexEndName']();return _0x18087b['getIndex']()['makePost'](_0x18087b['getIndexEndValue'](),_0x3b449b);}else return _0x18087b['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x25df19){this['withinDirectionalStart']=_0x17a734=>this['reverse_']?this['withinEndPost'](_0x17a734):this['withinStartPost'](_0x17a734),this['withinDirectionalEnd']=_0x543443=>this['reverse_']?this['withinStartPost'](_0x543443):this['withinEndPost'](_0x543443),this['withinStartPost']=_0x250c62=>{const _0x5eea2b=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x250c62);return this['startIsInclusive_']?_0x5eea2b<=0x0:_0x5eea2b<0x0;},this['withinEndPost']=_0x2d4e8b=>{const _0xf56f03=this['index_']['compare'](_0x2d4e8b,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xf56f03<=0x0:_0xf56f03<0x0;},this['rangedFilter_']=new Ot(_0x25df19),this['index_']=_0x25df19['getIndex'](),this['limit_']=_0x25df19['getLimit'](),this['reverse_']=!_0x25df19['isViewFromLeft'](),this['startIsInclusive_']=!_0x25df19['startAfterSet_'],this['endIsInclusive_']=!_0x25df19['endBeforeSet_'];}['updateChild'](_0x25e9b5,_0x1ca0ef,_0x3d4ba3,_0x36dfe7,_0x57b584,_0x1ac7a5){return this['rangedFilter_']['matches'](new E(_0x1ca0ef,_0x3d4ba3))||(_0x3d4ba3=g['EMPTY_NODE']),_0x25e9b5['getImmediateChild'](_0x1ca0ef)['equals'](_0x3d4ba3)?_0x25e9b5:_0x25e9b5['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x25e9b5,_0x1ca0ef,_0x3d4ba3,_0x36dfe7,_0x57b584,_0x1ac7a5):this['fullLimitUpdateChild_'](_0x25e9b5,_0x1ca0ef,_0x3d4ba3,_0x57b584,_0x1ac7a5);}['updateFullNode'](_0x58566d,_0x2eea29,_0x444934){let _0x172966;if(_0x2eea29['isLeafNode']()||_0x2eea29['isEmpty']())_0x172966=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2eea29['numChildren']()&&_0x2eea29['isIndexed'](this['index_'])){_0x172966=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x567f4e;this['reverse_']?_0x567f4e=_0x2eea29['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x567f4e=_0x2eea29['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xeb0258=0x0;for(;_0x567f4e['hasNext']()&&_0xeb0258<this['limit_'];){const _0x53952c=_0x567f4e['getNext']();if(this['withinDirectionalStart'](_0x53952c)){if(this['withinDirectionalEnd'](_0x53952c))_0x172966=_0x172966['updateImmediateChild'](_0x53952c['name'],_0x53952c['node']),_0xeb0258++;else break;}else continue;}}else{_0x172966=_0x2eea29['withIndex'](this['index_']),_0x172966=_0x172966['updatePriority'](g['EMPTY_NODE']);let _0x461b41;this['reverse_']?_0x461b41=_0x172966['getReverseIterator'](this['index_']):_0x461b41=_0x172966['getIterator'](this['index_']);let _0x14a891=0x0;for(;_0x461b41['hasNext']();){const _0x1c2000=_0x461b41['getNext']();_0x14a891<this['limit_']&&this['withinDirectionalStart'](_0x1c2000)&&this['withinDirectionalEnd'](_0x1c2000)?_0x14a891++:_0x172966=_0x172966['updateImmediateChild'](_0x1c2000['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x58566d,_0x172966,_0x444934);}['updatePriority'](_0x20c750,_0x4a75f8){return _0x20c750;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x4a3618,_0x56fe60,_0x3c95d8,_0x210287,_0x1bc67c){let _0x22ac65;if(this['reverse_']){const _0x31ef61=this['index_']['getCompare']();_0x22ac65=(_0x49e3f2,_0x5ddcb7)=>_0x31ef61(_0x5ddcb7,_0x49e3f2);}else _0x22ac65=this['index_']['getCompare']();const _0x2df28a=_0x4a3618;f(_0x2df28a['numChildren']()===this['limit_'],'');const _0x4c7c23=new E(_0x56fe60,_0x3c95d8),_0x4f3e57=this['reverse_']?_0x2df28a['getFirstChild'](this['index_']):_0x2df28a['getLastChild'](this['index_']),_0x4a6ad8=this['rangedFilter_']['matches'](_0x4c7c23);if(_0x2df28a['hasChild'](_0x56fe60)){const _0xb0e96d=_0x2df28a['getImmediateChild'](_0x56fe60);let _0x5485eb=_0x210287['getChildAfterChild'](this['index_'],_0x4f3e57,this['reverse_']);for(;_0x5485eb!=null&&(_0x5485eb['name']===_0x56fe60||_0x2df28a['hasChild'](_0x5485eb['name']));)_0x5485eb=_0x210287['getChildAfterChild'](this['index_'],_0x5485eb,this['reverse_']);const _0xd7031b=_0x5485eb==null?0x1:_0x22ac65(_0x5485eb,_0x4c7c23);if(_0x4a6ad8&&!_0x3c95d8['isEmpty']()&&_0xd7031b>=0x0)return _0x1bc67c!=null&&_0x1bc67c['trackChildChange'](Pt(_0x56fe60,_0x3c95d8,_0xb0e96d)),_0x2df28a['updateImmediateChild'](_0x56fe60,_0x3c95d8);{_0x1bc67c!=null&&_0x1bc67c['trackChildChange'](Nt(_0x56fe60,_0xb0e96d));const _0x387541=_0x2df28a['updateImmediateChild'](_0x56fe60,g['EMPTY_NODE']);return _0x5485eb!=null&&this['rangedFilter_']['matches'](_0x5485eb)?(_0x1bc67c!=null&&_0x1bc67c['trackChildChange'](tt(_0x5485eb['name'],_0x5485eb['node'])),_0x387541['updateImmediateChild'](_0x5485eb['name'],_0x5485eb['node'])):_0x387541;}}else return _0x3c95d8['isEmpty']()?_0x4a3618:_0x4a6ad8&&_0x22ac65(_0x4f3e57,_0x4c7c23)>=0x0?(_0x1bc67c!=null&&(_0x1bc67c['trackChildChange'](Nt(_0x4f3e57['name'],_0x4f3e57['node'])),_0x1bc67c['trackChildChange'](tt(_0x56fe60,_0x3c95d8))),_0x2df28a['updateImmediateChild'](_0x56fe60,_0x3c95d8)['updateImmediateChild'](_0x4f3e57['name'],g['EMPTY_NODE'])):_0x4a3618;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3e021f=new Qi();return _0x3e021f['limitSet_']=this['limitSet_'],_0x3e021f['limit_']=this['limit_'],_0x3e021f['startSet_']=this['startSet_'],_0x3e021f['startAfterSet_']=this['startAfterSet_'],_0x3e021f['indexStartValue_']=this['indexStartValue_'],_0x3e021f['startNameSet_']=this['startNameSet_'],_0x3e021f['indexStartName_']=this['indexStartName_'],_0x3e021f['endSet_']=this['endSet_'],_0x3e021f['endBeforeSet_']=this['endBeforeSet_'],_0x3e021f['indexEndValue_']=this['indexEndValue_'],_0x3e021f['endNameSet_']=this['endNameSet_'],_0x3e021f['indexEndName_']=this['indexEndName_'],_0x3e021f['index_']=this['index_'],_0x3e021f['viewFrom_']=this['viewFrom_'],_0x3e021f;}}function qh(_0x24c896){return _0x24c896['loadsAllData']()?new Yi(_0x24c896['getIndex']()):_0x24c896['hasLimit']()?new Gh(_0x24c896):new Ot(_0x24c896);}function zh(_0x5096a6,_0x2d4d28){const _0x49e1ed=_0x5096a6['copy']();return _0x49e1ed['limitSet_']=!0x0,_0x49e1ed['limit_']=_0x2d4d28,_0x49e1ed['viewFrom_']='l',_0x49e1ed;}function jh(_0x25ca1a,_0x5330f3,_0x5867ba){const _0x37a5ab=_0x25ca1a['copy']();return _0x37a5ab['startSet_']=!0x0,_0x5330f3===void 0x0&&(_0x5330f3=null),_0x37a5ab['indexStartValue_']=_0x5330f3,_0x5867ba!=null?(_0x37a5ab['startNameSet_']=!0x0,_0x37a5ab['indexStartName_']=_0x5867ba):(_0x37a5ab['startNameSet_']=!0x1,_0x37a5ab['indexStartName_']=''),_0x37a5ab;}function Kh(_0x39d57a,_0x563cc9,_0x2d2a39){const _0x39deb7=_0x39d57a['copy']();return _0x39deb7['endSet_']=!0x0,_0x563cc9===void 0x0&&(_0x563cc9=null),_0x39deb7['indexEndValue_']=_0x563cc9,_0x2d2a39!==void 0x0?(_0x39deb7['endNameSet_']=!0x0,_0x39deb7['indexEndName_']=_0x2d2a39):(_0x39deb7['endNameSet_']=!0x1,_0x39deb7['indexEndName_']=''),_0x39deb7;}function Do(_0x30efc0,_0x361585){const _0x3ed49b=_0x30efc0['copy']();return _0x3ed49b['index_']=_0x361585,_0x3ed49b;}function tr(_0x70c8e6){const _0x388acd={};if(_0x70c8e6['isDefault']())return _0x388acd;let _0x40f437;if(_0x70c8e6['index_']===R?_0x40f437='$priority':_0x70c8e6['index_']===Po?_0x40f437='$value':_0x70c8e6['index_']===ye?_0x40f437='$key':(f(_0x70c8e6['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x40f437=_0x70c8e6['index_']['toString']()),_0x388acd['orderBy']=O(_0x40f437),_0x70c8e6['startSet_']){const _0x4873be=_0x70c8e6['startAfterSet_']?'startAfter':'startAt';_0x388acd[_0x4873be]=O(_0x70c8e6['indexStartValue_']),_0x70c8e6['startNameSet_']&&(_0x388acd[_0x4873be]+=','+O(_0x70c8e6['indexStartName_']));}if(_0x70c8e6['endSet_']){const _0x245e4d=_0x70c8e6['endBeforeSet_']?'endBefore':'endAt';_0x388acd[_0x245e4d]=O(_0x70c8e6['indexEndValue_']),_0x70c8e6['endNameSet_']&&(_0x388acd[_0x245e4d]+=','+O(_0x70c8e6['indexEndName_']));}return _0x70c8e6['limitSet_']&&(_0x70c8e6['isViewFromLeft']()?_0x388acd['limitToFirst']=_0x70c8e6['limit_']:_0x388acd['limitToLast']=_0x70c8e6['limit_']),_0x388acd;}function nr(_0xd8eaf1){const _0xbd442e={};if(_0xd8eaf1['startSet_']&&(_0xbd442e['sp']=_0xd8eaf1['indexStartValue_'],_0xd8eaf1['startNameSet_']&&(_0xbd442e['sn']=_0xd8eaf1['indexStartName_']),_0xbd442e['sin']=!_0xd8eaf1['startAfterSet_']),_0xd8eaf1['endSet_']&&(_0xbd442e['ep']=_0xd8eaf1['indexEndValue_'],_0xd8eaf1['endNameSet_']&&(_0xbd442e['en']=_0xd8eaf1['indexEndName_']),_0xbd442e['ein']=!_0xd8eaf1['endBeforeSet_']),_0xd8eaf1['limitSet_']){_0xbd442e['l']=_0xd8eaf1['limit_'];let _0x3202df=_0xd8eaf1['viewFrom_'];_0x3202df===''&&(_0xd8eaf1['isViewFromLeft']()?_0x3202df='l':_0x3202df='r'),_0xbd442e['vf']=_0x3202df;}return _0xd8eaf1['index_']!==R&&(_0xbd442e['i']=_0xd8eaf1['index_']['toString']()),_0xbd442e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x16be33){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x40f4e8,_0x23cfcd){return _0x23cfcd!==void 0x0?'tag$'+_0x23cfcd:(f(_0x40f4e8['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x40f4e8['_path']['toString']());}constructor(_0x19a591,_0x5ee2a8,_0x138da0,_0x2f1deb){super(),this['repoInfo_']=_0x19a591,this['onDataUpdate_']=_0x5ee2a8,this['authTokenProvider_']=_0x138da0,this['appCheckTokenProvider_']=_0x2f1deb,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x21244d,_0x190f0c,_0x55ce73,_0x1f6ca9){const _0x3ed557=_0x21244d['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3ed557+'\x20'+_0x21244d['_queryIdentifier']);const _0x214185=fn['getListenId_'](_0x21244d,_0x55ce73),_0x32b923={};this['listens_'][_0x214185]=_0x32b923;const _0x171017=tr(_0x21244d['_queryParams']);this['restRequest_'](_0x3ed557+'.json',_0x171017,(_0xfc6f1f,_0x28152c)=>{let _0x30565e=_0x28152c;if(_0xfc6f1f===0x194&&(_0x30565e=null,_0xfc6f1f=null),_0xfc6f1f===null&&this['onDataUpdate_'](_0x3ed557,_0x30565e,!0x1,_0x55ce73),Oe(this['listens_'],_0x214185)===_0x32b923){let _0x5ee62f;_0xfc6f1f?_0xfc6f1f===0x191?_0x5ee62f='permission_denied':_0x5ee62f='rest_error:'+_0xfc6f1f:_0x5ee62f='ok',_0x1f6ca9(_0x5ee62f,null);}});}['unlisten'](_0x3abe3b,_0x19be5d){const _0x1fa162=fn['getListenId_'](_0x3abe3b,_0x19be5d);delete this['listens_'][_0x1fa162];}['get'](_0x4c2db6){const _0x8851a=tr(_0x4c2db6['_queryParams']),_0x44209e=_0x4c2db6['_path']['toString'](),_0x230e98=new Ve();return this['restRequest_'](_0x44209e+'.json',_0x8851a,(_0x588bf0,_0x1b09be)=>{let _0x1dc954=_0x1b09be;_0x588bf0===0x194&&(_0x1dc954=null,_0x588bf0=null),_0x588bf0===null?(this['onDataUpdate_'](_0x44209e,_0x1dc954,!0x1,null),_0x230e98['resolve'](_0x1dc954)):_0x230e98['reject'](new Error(_0x1dc954));}),_0x230e98['promise'];}['refreshAuthToken'](_0x20e512){}['restRequest_'](_0x5e0eee,_0x279eff={},_0x3e176d){return _0x279eff['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5d0150,_0x417e52])=>{_0x5d0150&&_0x5d0150['accessToken']&&(_0x279eff['auth']=_0x5d0150['accessToken']),_0x417e52&&_0x417e52['token']&&(_0x279eff['ac']=_0x417e52['token']);const _0x35c9db=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5e0eee+'?ns='+this['repoInfo_']['namespace']+at(_0x279eff);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x35c9db);const _0x35d03c=new XMLHttpRequest();_0x35d03c['onreadystatechange']=()=>{if(_0x3e176d&&_0x35d03c['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x35c9db+'\x20received.\x20status:',_0x35d03c['status'],'response:',_0x35d03c['responseText']);let _0x4e58eb=null;if(_0x35d03c['status']>=0xc8&&_0x35d03c['status']<0x12c){try{_0x4e58eb=bt(_0x35d03c['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x35c9db+':\x20'+_0x35d03c['responseText']);}_0x3e176d(null,_0x4e58eb);}else _0x35d03c['status']!==0x191&&_0x35d03c['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x35c9db+'\x20Status:\x20'+_0x35d03c['status']),_0x3e176d(_0x35d03c['status']);_0x3e176d=null;}},_0x35d03c['open']('GET',_0x35c9db,!0x0),_0x35d03c['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x370a03){return this['rootNode_']['getChild'](_0x370a03);}['updateSnapshot'](_0x4c7bbe,_0x684d91){this['rootNode_']=this['rootNode_']['updateChild'](_0x4c7bbe,_0x684d91);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x1eb395,_0xe382c1,_0x9d7aa){if(v(_0xe382c1))_0x1eb395['value']=_0x9d7aa,_0x1eb395['children']['clear']();else{if(_0x1eb395['value']!==null)_0x1eb395['value']=_0x1eb395['value']['updateChild'](_0xe382c1,_0x9d7aa);else{const _0x2c4910=y(_0xe382c1);_0x1eb395['children']['has'](_0x2c4910)||_0x1eb395['children']['set'](_0x2c4910,pn());const _0xc20769=_0x1eb395['children']['get'](_0x2c4910);_0xe382c1=b(_0xe382c1),Mo(_0xc20769,_0xe382c1,_0x9d7aa);}}}function Ei(_0x33c64b,_0x94402e,_0x57621b){_0x33c64b['value']!==null?_0x57621b(_0x94402e,_0x33c64b['value']):Qh(_0x33c64b,(_0x197072,_0x32e1f1)=>{const _0x134cca=new C(_0x94402e['toString']()+'/'+_0x197072);Ei(_0x32e1f1,_0x134cca,_0x57621b);});}function Qh(_0xdb80f,_0x498f5a){_0xdb80f['children']['forEach']((_0x197fee,_0x26a0bc)=>{_0x498f5a(_0x26a0bc,_0x197fee);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x236517){this['collection_']=_0x236517,this['last_']=null;}['get'](){const _0x586309=this['collection_']['get'](),_0x193e24={..._0x586309};return this['last_']&&x(this['last_'],(_0x539306,_0x1c78a)=>{_0x193e24[_0x539306]=_0x193e24[_0x539306]-_0x1c78a;}),this['last_']=_0x586309,_0x193e24;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0xcb6cd7,_0x3fb8fb){this['server_']=_0x3fb8fb,this['statsToReport_']={},this['statsListener_']=new Jh(_0xcb6cd7);const _0x2949a0=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x2949a0));}['reportStats_'](){const _0x52280c=this['statsListener_']['get'](),_0x56acb5={};let _0x58cb5d=!0x1;x(_0x52280c,(_0x404cdf,_0x57edff)=>{_0x57edff>0x0&&Y(this['statsToReport_'],_0x404cdf)&&(_0x56acb5[_0x404cdf]=_0x57edff,_0x58cb5d=!0x0);}),_0x58cb5d&&this['server_']['reportStats'](_0x56acb5),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x18c5b9){_0x18c5b9[_0x18c5b9['OVERWRITE']=0x0]='OVERWRITE',_0x18c5b9[_0x18c5b9['MERGE']=0x1]='MERGE',_0x18c5b9[_0x18c5b9['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x18c5b9[_0x18c5b9['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x858c93){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x858c93,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x3cd4ac,_0x36271f,_0x251063){this['path']=_0x3cd4ac,this['affectedTree']=_0x36271f,this['revert']=_0x251063,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x50b01b){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x17089a=this['affectedTree']['subtree'](new C(_0x50b01b));return new _n(w(),_0x17089a,this['revert']);}}else return f(y(this['path'])===_0x50b01b,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x350300,_0x1fd6e4){this['source']=_0x350300,this['path']=_0x1fd6e4,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x49141e){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x3230d5,_0x21c46a,_0x3c0e3b){this['source']=_0x3230d5,this['path']=_0x21c46a,this['snap']=_0x3c0e3b,this['type']=q['OVERWRITE'];}['operationForChild'](_0x16c964){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x16c964)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x162146,_0x30dde6,_0x476bea){this['source']=_0x162146,this['path']=_0x30dde6,this['children']=_0x476bea,this['type']=q['MERGE'];}['operationForChild'](_0x4bc5b6){if(v(this['path'])){const _0x53c142=this['children']['subtree'](new C(_0x4bc5b6));return _0x53c142['isEmpty']()?null:_0x53c142['value']?new Fe(this['source'],w(),_0x53c142['value']):new nt(this['source'],w(),_0x53c142);}else return f(y(this['path'])===_0x4bc5b6,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x27077a,_0x581a27,_0xf16fc7){this['node_']=_0x27077a,this['fullyInitialized_']=_0x581a27,this['filtered_']=_0xf16fc7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1d6288){if(v(_0x1d6288))return this['isFullyInitialized']()&&!this['filtered_'];const _0x456b67=y(_0x1d6288);return this['isCompleteForChild'](_0x456b67);}['isCompleteForChild'](_0x3bf3ef){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3bf3ef);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x30b2ba){this['query_']=_0x30b2ba,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x118e24,_0x142198,_0x208973,_0x15f949){const _0x58b4ac=[],_0xad9125=[];return _0x142198['forEach'](_0x5ae315=>{_0x5ae315['type']==='child_changed'&&_0x118e24['index_']['indexedValueChanged'](_0x5ae315['oldSnap'],_0x5ae315['snapshotNode'])&&_0xad9125['push']($h(_0x5ae315['childName'],_0x5ae315['snapshotNode']));}),mt(_0x118e24,_0x58b4ac,'child_removed',_0x142198,_0x15f949,_0x208973),mt(_0x118e24,_0x58b4ac,'child_added',_0x142198,_0x15f949,_0x208973),mt(_0x118e24,_0x58b4ac,'child_moved',_0xad9125,_0x15f949,_0x208973),mt(_0x118e24,_0x58b4ac,'child_changed',_0x142198,_0x15f949,_0x208973),mt(_0x118e24,_0x58b4ac,'value',_0x142198,_0x15f949,_0x208973),_0x58b4ac;}function mt(_0xb34b9a,_0x25fff7,_0x10b953,_0x32808d,_0x22b04d,_0x4904d5){const _0x485b61=_0x32808d['filter'](_0x52110d=>_0x52110d['type']===_0x10b953);_0x485b61['sort']((_0x2bd1c7,_0x40cd6a)=>su(_0xb34b9a,_0x2bd1c7,_0x40cd6a)),_0x485b61['forEach'](_0x51aae9=>{const _0x5b28cd=iu(_0xb34b9a,_0x51aae9,_0x4904d5);_0x22b04d['forEach'](_0x53d15a=>{_0x53d15a['respondsTo'](_0x51aae9['type'])&&_0x25fff7['push'](_0x53d15a['createEvent'](_0x5b28cd,_0xb34b9a['query_']));});});}function iu(_0x1a245c,_0x50e91a,_0x248848){return _0x50e91a['type']==='value'||_0x50e91a['type']==='child_removed'||(_0x50e91a['prevName']=_0x248848['getPredecessorChildName'](_0x50e91a['childName'],_0x50e91a['snapshotNode'],_0x1a245c['index_'])),_0x50e91a;}function su(_0x4a1728,_0x58920d,_0xdad7a9){if(_0x58920d['childName']==null||_0xdad7a9['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x450332=new E(_0x58920d['childName'],_0x58920d['snapshotNode']),_0x597659=new E(_0xdad7a9['childName'],_0xdad7a9['snapshotNode']);return _0x4a1728['index_']['compare'](_0x450332,_0x597659);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0xe4f820,_0x3c5051){return{'eventCache':_0xe4f820,'serverCache':_0x3c5051};}function wt(_0x57e21b,_0x851cd2,_0x468640,_0x1009ac){return Dn(new Ce(_0x851cd2,_0x468640,_0x1009ac),_0x57e21b['serverCache']);}function Lo(_0x293ef3,_0x4cee93,_0x14c411,_0x5588fd){return Dn(_0x293ef3['eventCache'],new Ce(_0x4cee93,_0x14c411,_0x5588fd));}function gn(_0xdf4757){return _0xdf4757['eventCache']['isFullyInitialized']()?_0xdf4757['eventCache']['getNode']():null;}function Ue(_0xb14467){return _0xb14467['serverCache']['isFullyInitialized']()?_0xb14467['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x223d7e){let _0xe425cf=new S(null);return x(_0x223d7e,(_0x2ec505,_0x18d1e3)=>{_0xe425cf=_0xe425cf['set'](new C(_0x2ec505),_0x18d1e3);}),_0xe425cf;}constructor(_0x3854da,_0xdffc01=ru()){this['value']=_0x3854da,this['children']=_0xdffc01;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5d7adf,_0x54bbc9){if(this['value']!=null&&_0x54bbc9(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5d7adf))return null;{const _0x548cd5=y(_0x5d7adf),_0x28cb5d=this['children']['get'](_0x548cd5);if(_0x28cb5d!==null){const _0x4b15a3=_0x28cb5d['findRootMostMatchingPathAndValue'](b(_0x5d7adf),_0x54bbc9);return _0x4b15a3!=null?{'path':A(new C(_0x548cd5),_0x4b15a3['path']),'value':_0x4b15a3['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4a74c7){return this['findRootMostMatchingPathAndValue'](_0x4a74c7,()=>!0x0);}['subtree'](_0xf7970){if(v(_0xf7970))return this;{const _0x32bdbf=y(_0xf7970),_0x2a7ed7=this['children']['get'](_0x32bdbf);return _0x2a7ed7!==null?_0x2a7ed7['subtree'](b(_0xf7970)):new S(null);}}['set'](_0x426f62,_0x5f40c9){if(v(_0x426f62))return new S(_0x5f40c9,this['children']);{const _0x2b2ab9=y(_0x426f62),_0x221002=(this['children']['get'](_0x2b2ab9)||new S(null))['set'](b(_0x426f62),_0x5f40c9),_0x476613=this['children']['insert'](_0x2b2ab9,_0x221002);return new S(this['value'],_0x476613);}}['remove'](_0x29fb31){if(v(_0x29fb31))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x1120a0=y(_0x29fb31),_0x10fce6=this['children']['get'](_0x1120a0);if(_0x10fce6){const _0x56898f=_0x10fce6['remove'](b(_0x29fb31));let _0x5919f9;return _0x56898f['isEmpty']()?_0x5919f9=this['children']['remove'](_0x1120a0):_0x5919f9=this['children']['insert'](_0x1120a0,_0x56898f),this['value']===null&&_0x5919f9['isEmpty']()?new S(null):new S(this['value'],_0x5919f9);}else return this;}}['get'](_0x106eba){if(v(_0x106eba))return this['value'];{const _0xa35a7f=y(_0x106eba),_0xc1f660=this['children']['get'](_0xa35a7f);return _0xc1f660?_0xc1f660['get'](b(_0x106eba)):null;}}['setTree'](_0xc85a45,_0x3806d4){if(v(_0xc85a45))return _0x3806d4;{const _0x586100=y(_0xc85a45),_0x3bc633=(this['children']['get'](_0x586100)||new S(null))['setTree'](b(_0xc85a45),_0x3806d4);let _0x21b568;return _0x3bc633['isEmpty']()?_0x21b568=this['children']['remove'](_0x586100):_0x21b568=this['children']['insert'](_0x586100,_0x3bc633),new S(this['value'],_0x21b568);}}['fold'](_0x5ac403){return this['fold_'](w(),_0x5ac403);}['fold_'](_0x17f156,_0xea0842){const _0x2f26b3={};return this['children']['inorderTraversal']((_0x2aa6bf,_0x58d70b)=>{_0x2f26b3[_0x2aa6bf]=_0x58d70b['fold_'](A(_0x17f156,_0x2aa6bf),_0xea0842);}),_0xea0842(_0x17f156,this['value'],_0x2f26b3);}['findOnPath'](_0x532898,_0x497058){return this['findOnPath_'](_0x532898,w(),_0x497058);}['findOnPath_'](_0xa219b2,_0x56c860,_0x280944){const _0x35d48d=this['value']?_0x280944(_0x56c860,this['value']):!0x1;if(_0x35d48d)return _0x35d48d;if(v(_0xa219b2))return null;{const _0x1a98c3=y(_0xa219b2),_0x374b84=this['children']['get'](_0x1a98c3);return _0x374b84?_0x374b84['findOnPath_'](b(_0xa219b2),A(_0x56c860,_0x1a98c3),_0x280944):null;}}['foreachOnPath'](_0x860dc0,_0x451cf4){return this['foreachOnPath_'](_0x860dc0,w(),_0x451cf4);}['foreachOnPath_'](_0x245f48,_0x3ec921,_0x1782f4){if(v(_0x245f48))return this;{this['value']&&_0x1782f4(_0x3ec921,this['value']);const _0x3fd0e1=y(_0x245f48),_0x30d5dc=this['children']['get'](_0x3fd0e1);return _0x30d5dc?_0x30d5dc['foreachOnPath_'](b(_0x245f48),A(_0x3ec921,_0x3fd0e1),_0x1782f4):new S(null);}}['foreach'](_0x481d55){this['foreach_'](w(),_0x481d55);}['foreach_'](_0x34291c,_0x4c100a){this['children']['inorderTraversal']((_0x1dbb2f,_0x33cf85)=>{_0x33cf85['foreach_'](A(_0x34291c,_0x1dbb2f),_0x4c100a);}),this['value']&&_0x4c100a(_0x34291c,this['value']);}['foreachChild'](_0x246b4a){this['children']['inorderTraversal']((_0x2e7be9,_0x4af847)=>{_0x4af847['value']&&_0x246b4a(_0x2e7be9,_0x4af847['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x30ea40){this['writeTree_']=_0x30ea40;}static['empty'](){return new j(new S(null));}}function Ct(_0x334cd3,_0x2230be,_0x4f15d2){if(v(_0x2230be))return new j(new S(_0x4f15d2));{const _0x434fa2=_0x334cd3['writeTree_']['findRootMostValueAndPath'](_0x2230be);if(_0x434fa2!=null){const _0x3a1746=_0x434fa2['path'];let _0x2f1092=_0x434fa2['value'];const _0x1cbdf5=F(_0x3a1746,_0x2230be);return _0x2f1092=_0x2f1092['updateChild'](_0x1cbdf5,_0x4f15d2),new j(_0x334cd3['writeTree_']['set'](_0x3a1746,_0x2f1092));}else{const _0x51cf6a=new S(_0x4f15d2),_0x3a123c=_0x334cd3['writeTree_']['setTree'](_0x2230be,_0x51cf6a);return new j(_0x3a123c);}}}function Ii(_0x3d94f1,_0x335879,_0x37ca6d){let _0xce9308=_0x3d94f1;return x(_0x37ca6d,(_0x66cfaa,_0x4a5a00)=>{_0xce9308=Ct(_0xce9308,A(_0x335879,_0x66cfaa),_0x4a5a00);}),_0xce9308;}function sr(_0x34e2e4,_0x227d10){if(v(_0x227d10))return j['empty']();{const _0x50ea97=_0x34e2e4['writeTree_']['setTree'](_0x227d10,new S(null));return new j(_0x50ea97);}}function wi(_0x15197d,_0x2eb7c9){return $e(_0x15197d,_0x2eb7c9)!=null;}function $e(_0x63de5e,_0xae9ffd){const _0x3bdc6b=_0x63de5e['writeTree_']['findRootMostValueAndPath'](_0xae9ffd);return _0x3bdc6b!=null?_0x63de5e['writeTree_']['get'](_0x3bdc6b['path'])['getChild'](F(_0x3bdc6b['path'],_0xae9ffd)):null;}function rr(_0x5867e5){const _0x491cc0=[],_0x4a8b5a=_0x5867e5['writeTree_']['value'];return _0x4a8b5a!=null?_0x4a8b5a['isLeafNode']()||_0x4a8b5a['forEachChild'](R,(_0x3a2a73,_0x236e1b)=>{_0x491cc0['push'](new E(_0x3a2a73,_0x236e1b));}):_0x5867e5['writeTree_']['children']['inorderTraversal']((_0x559ad6,_0x3f3765)=>{_0x3f3765['value']!=null&&_0x491cc0['push'](new E(_0x559ad6,_0x3f3765['value']));}),_0x491cc0;}function ve(_0x18db9b,_0x378dae){if(v(_0x378dae))return _0x18db9b;{const _0x208e78=$e(_0x18db9b,_0x378dae);return _0x208e78!=null?new j(new S(_0x208e78)):new j(_0x18db9b['writeTree_']['subtree'](_0x378dae));}}function Ci(_0x41426f){return _0x41426f['writeTree_']['isEmpty']();}function it(_0x92a7d9,_0x47f1e1){return xo(w(),_0x92a7d9['writeTree_'],_0x47f1e1);}function xo(_0x8ca85a,_0x27dac5,_0x1c1afa){if(_0x27dac5['value']!=null)return _0x1c1afa['updateChild'](_0x8ca85a,_0x27dac5['value']);{let _0x5e9fe1=null;return _0x27dac5['children']['inorderTraversal']((_0x4ebd54,_0x56de7e)=>{_0x4ebd54==='.priority'?(f(_0x56de7e['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5e9fe1=_0x56de7e['value']):_0x1c1afa=xo(A(_0x8ca85a,_0x4ebd54),_0x56de7e,_0x1c1afa);}),!_0x1c1afa['getChild'](_0x8ca85a)['isEmpty']()&&_0x5e9fe1!==null&&(_0x1c1afa=_0x1c1afa['updateChild'](A(_0x8ca85a,'.priority'),_0x5e9fe1)),_0x1c1afa;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x545d9e,_0x1ef695){return Bo(_0x1ef695,_0x545d9e);}function ou(_0x2f419f,_0x2edca1,_0x3bf726,_0x578868,_0x34ca4c){f(_0x578868>_0x2f419f['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x34ca4c===void 0x0&&(_0x34ca4c=!0x0),_0x2f419f['allWrites']['push']({'path':_0x2edca1,'snap':_0x3bf726,'writeId':_0x578868,'visible':_0x34ca4c}),_0x34ca4c&&(_0x2f419f['visibleWrites']=Ct(_0x2f419f['visibleWrites'],_0x2edca1,_0x3bf726)),_0x2f419f['lastWriteId']=_0x578868;}function au(_0x44afbb,_0x50efb8,_0xcbb920,_0x130d70){f(_0x130d70>_0x44afbb['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x44afbb['allWrites']['push']({'path':_0x50efb8,'children':_0xcbb920,'writeId':_0x130d70,'visible':!0x0}),_0x44afbb['visibleWrites']=Ii(_0x44afbb['visibleWrites'],_0x50efb8,_0xcbb920),_0x44afbb['lastWriteId']=_0x130d70;}function cu(_0x35660b,_0x2509ec){for(let _0x11ec51=0x0;_0x11ec51<_0x35660b['allWrites']['length'];_0x11ec51++){const _0x2e0ffd=_0x35660b['allWrites'][_0x11ec51];if(_0x2e0ffd['writeId']===_0x2509ec)return _0x2e0ffd;}return null;}function lu(_0x52ec8c,_0x173153){const _0x48fafc=_0x52ec8c['allWrites']['findIndex'](_0x1b1b44=>_0x1b1b44['writeId']===_0x173153);f(_0x48fafc>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x5ef6d9=_0x52ec8c['allWrites'][_0x48fafc];_0x52ec8c['allWrites']['splice'](_0x48fafc,0x1);let _0x3e4bc2=_0x5ef6d9['visible'],_0x20a82b=!0x1,_0x8ef3ba=_0x52ec8c['allWrites']['length']-0x1;for(;_0x3e4bc2&&_0x8ef3ba>=0x0;){const _0x306bd3=_0x52ec8c['allWrites'][_0x8ef3ba];_0x306bd3['visible']&&(_0x8ef3ba>=_0x48fafc&&hu(_0x306bd3,_0x5ef6d9['path'])?_0x3e4bc2=!0x1:$(_0x5ef6d9['path'],_0x306bd3['path'])&&(_0x20a82b=!0x0)),_0x8ef3ba--;}if(_0x3e4bc2){if(_0x20a82b)return uu(_0x52ec8c),!0x0;if(_0x5ef6d9['snap'])_0x52ec8c['visibleWrites']=sr(_0x52ec8c['visibleWrites'],_0x5ef6d9['path']);else{const _0x484bf8=_0x5ef6d9['children'];x(_0x484bf8,_0x7b4361=>{_0x52ec8c['visibleWrites']=sr(_0x52ec8c['visibleWrites'],A(_0x5ef6d9['path'],_0x7b4361));});}return!0x0;}else return!0x1;}function hu(_0x5595fd,_0x43c146){if(_0x5595fd['snap'])return $(_0x5595fd['path'],_0x43c146);for(const _0x4e2d72 in _0x5595fd['children'])if(_0x5595fd['children']['hasOwnProperty'](_0x4e2d72)&&$(A(_0x5595fd['path'],_0x4e2d72),_0x43c146))return!0x0;return!0x1;}function uu(_0x24a374){_0x24a374['visibleWrites']=Fo(_0x24a374['allWrites'],du,w()),_0x24a374['allWrites']['length']>0x0?_0x24a374['lastWriteId']=_0x24a374['allWrites'][_0x24a374['allWrites']['length']-0x1]['writeId']:_0x24a374['lastWriteId']=-0x1;}function du(_0x555f59){return _0x555f59['visible'];}function Fo(_0x2809ed,_0x5bc03d,_0x2650d5){let _0x5c5c33=j['empty']();for(let _0x1bb2e2=0x0;_0x1bb2e2<_0x2809ed['length'];++_0x1bb2e2){const _0x19b956=_0x2809ed[_0x1bb2e2];if(_0x5bc03d(_0x19b956)){const _0x4f1534=_0x19b956['path'];let _0x4fc075;if(_0x19b956['snap'])$(_0x2650d5,_0x4f1534)?(_0x4fc075=F(_0x2650d5,_0x4f1534),_0x5c5c33=Ct(_0x5c5c33,_0x4fc075,_0x19b956['snap'])):$(_0x4f1534,_0x2650d5)&&(_0x4fc075=F(_0x4f1534,_0x2650d5),_0x5c5c33=Ct(_0x5c5c33,w(),_0x19b956['snap']['getChild'](_0x4fc075)));else{if(_0x19b956['children']){if($(_0x2650d5,_0x4f1534))_0x4fc075=F(_0x2650d5,_0x4f1534),_0x5c5c33=Ii(_0x5c5c33,_0x4fc075,_0x19b956['children']);else{if($(_0x4f1534,_0x2650d5)){if(_0x4fc075=F(_0x4f1534,_0x2650d5),v(_0x4fc075))_0x5c5c33=Ii(_0x5c5c33,w(),_0x19b956['children']);else{const _0x2976c9=Oe(_0x19b956['children'],y(_0x4fc075));if(_0x2976c9){const _0x4fa786=_0x2976c9['getChild'](b(_0x4fc075));_0x5c5c33=Ct(_0x5c5c33,w(),_0x4fa786);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5c5c33;}function Uo(_0x94a9a2,_0x300bce,_0x2c78a6,_0x3df628,_0x261cf2){if(!_0x3df628&&!_0x261cf2){const _0x3b042f=$e(_0x94a9a2['visibleWrites'],_0x300bce);if(_0x3b042f!=null)return _0x3b042f;{const _0x19b0e8=ve(_0x94a9a2['visibleWrites'],_0x300bce);if(Ci(_0x19b0e8))return _0x2c78a6;if(_0x2c78a6==null&&!wi(_0x19b0e8,w()))return null;{const _0xc8990a=_0x2c78a6||g['EMPTY_NODE'];return it(_0x19b0e8,_0xc8990a);}}}else{const _0x133462=ve(_0x94a9a2['visibleWrites'],_0x300bce);if(!_0x261cf2&&Ci(_0x133462))return _0x2c78a6;if(!_0x261cf2&&_0x2c78a6==null&&!wi(_0x133462,w()))return null;{const _0x17b8cf=function(_0x140991){return(_0x140991['visible']||_0x261cf2)&&(!_0x3df628||!~_0x3df628['indexOf'](_0x140991['writeId']))&&($(_0x140991['path'],_0x300bce)||$(_0x300bce,_0x140991['path']));},_0x27d381=Fo(_0x94a9a2['allWrites'],_0x17b8cf,_0x300bce),_0x1e69a8=_0x2c78a6||g['EMPTY_NODE'];return it(_0x27d381,_0x1e69a8);}}}function fu(_0x21abf0,_0x250ebb,_0x11ed81){let _0x9a093a=g['EMPTY_NODE'];const _0x126e67=$e(_0x21abf0['visibleWrites'],_0x250ebb);if(_0x126e67)return _0x126e67['isLeafNode']()||_0x126e67['forEachChild'](R,(_0x5f7b8a,_0x16aa8c)=>{_0x9a093a=_0x9a093a['updateImmediateChild'](_0x5f7b8a,_0x16aa8c);}),_0x9a093a;if(_0x11ed81){const _0x317289=ve(_0x21abf0['visibleWrites'],_0x250ebb);return _0x11ed81['forEachChild'](R,(_0x24e41a,_0xb0e67a)=>{const _0x4f755c=it(ve(_0x317289,new C(_0x24e41a)),_0xb0e67a);_0x9a093a=_0x9a093a['updateImmediateChild'](_0x24e41a,_0x4f755c);}),rr(_0x317289)['forEach'](_0x5474d5=>{_0x9a093a=_0x9a093a['updateImmediateChild'](_0x5474d5['name'],_0x5474d5['node']);}),_0x9a093a;}else{const _0x43aac0=ve(_0x21abf0['visibleWrites'],_0x250ebb);return rr(_0x43aac0)['forEach'](_0x73f00b=>{_0x9a093a=_0x9a093a['updateImmediateChild'](_0x73f00b['name'],_0x73f00b['node']);}),_0x9a093a;}}function pu(_0x8cc4b3,_0x3c8a62,_0x4b469f,_0x3810a1,_0x3c20fb){f(_0x3810a1||_0x3c20fb,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x27acbc=A(_0x3c8a62,_0x4b469f);if(wi(_0x8cc4b3['visibleWrites'],_0x27acbc))return null;{const _0x146513=ve(_0x8cc4b3['visibleWrites'],_0x27acbc);return Ci(_0x146513)?_0x3c20fb['getChild'](_0x4b469f):it(_0x146513,_0x3c20fb['getChild'](_0x4b469f));}}function _u(_0x240fe9,_0x1beb70,_0x427954,_0x4a3f97){const _0x5d25f7=A(_0x1beb70,_0x427954),_0x67ca5e=$e(_0x240fe9['visibleWrites'],_0x5d25f7);if(_0x67ca5e!=null)return _0x67ca5e;if(_0x4a3f97['isCompleteForChild'](_0x427954)){const _0x143620=ve(_0x240fe9['visibleWrites'],_0x5d25f7);return it(_0x143620,_0x4a3f97['getNode']()['getImmediateChild'](_0x427954));}else return null;}function gu(_0x5cceda,_0x55cf03){return $e(_0x5cceda['visibleWrites'],_0x55cf03);}function mu(_0x595dc2,_0x551d8c,_0xca95bc,_0x466f1d,_0x3d2783,_0x2c4368,_0x514b74){let _0x397b26;const _0x30b5a7=ve(_0x595dc2['visibleWrites'],_0x551d8c),_0x21821d=$e(_0x30b5a7,w());if(_0x21821d!=null)_0x397b26=_0x21821d;else{if(_0xca95bc!=null)_0x397b26=it(_0x30b5a7,_0xca95bc);else return[];}if(_0x397b26=_0x397b26['withIndex'](_0x514b74),!_0x397b26['isEmpty']()&&!_0x397b26['isLeafNode']()){const _0xf280ea=[],_0x4d7d68=_0x514b74['getCompare'](),_0x171507=_0x2c4368?_0x397b26['getReverseIteratorFrom'](_0x466f1d,_0x514b74):_0x397b26['getIteratorFrom'](_0x466f1d,_0x514b74);let _0x15dab1=_0x171507['getNext']();for(;_0x15dab1&&_0xf280ea['length']<_0x3d2783;)_0x4d7d68(_0x15dab1,_0x466f1d)!==0x0&&_0xf280ea['push'](_0x15dab1),_0x15dab1=_0x171507['getNext']();return _0xf280ea;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0xccdb4d,_0x117d6e,_0x3544de,_0x3cf97d){return Uo(_0xccdb4d['writeTree'],_0xccdb4d['treePath'],_0x117d6e,_0x3544de,_0x3cf97d);}function es(_0x5e07f5,_0x1ecd6a){return fu(_0x5e07f5['writeTree'],_0x5e07f5['treePath'],_0x1ecd6a);}function or(_0x350196,_0x572d96,_0x1b4050,_0x410881){return pu(_0x350196['writeTree'],_0x350196['treePath'],_0x572d96,_0x1b4050,_0x410881);}function yn(_0x1b9ed2,_0x599eaf){return gu(_0x1b9ed2['writeTree'],A(_0x1b9ed2['treePath'],_0x599eaf));}function vu(_0x540c86,_0x3ab16f,_0x247634,_0x24f129,_0x1ef2e9,_0x3168fa){return mu(_0x540c86['writeTree'],_0x540c86['treePath'],_0x3ab16f,_0x247634,_0x24f129,_0x1ef2e9,_0x3168fa);}function ts(_0x4893cf,_0x334ffe,_0x169b3b){return _u(_0x4893cf['writeTree'],_0x4893cf['treePath'],_0x334ffe,_0x169b3b);}function Wo(_0x532c1b,_0x44feaf){return Bo(A(_0x532c1b['treePath'],_0x44feaf),_0x532c1b['writeTree']);}function Bo(_0xdadbc7,_0x1a7446){return{'treePath':_0xdadbc7,'writeTree':_0x1a7446};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x2786eb){const _0x2db5cc=_0x2786eb['type'],_0x2278a9=_0x2786eb['childName'];f(_0x2db5cc==='child_added'||_0x2db5cc==='child_changed'||_0x2db5cc==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2278a9!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x57af26=this['changeMap']['get'](_0x2278a9);if(_0x57af26){const _0x5c0d0f=_0x57af26['type'];if(_0x2db5cc==='child_added'&&_0x5c0d0f==='child_removed')this['changeMap']['set'](_0x2278a9,Pt(_0x2278a9,_0x2786eb['snapshotNode'],_0x57af26['snapshotNode']));else{if(_0x2db5cc==='child_removed'&&_0x5c0d0f==='child_added')this['changeMap']['delete'](_0x2278a9);else{if(_0x2db5cc==='child_removed'&&_0x5c0d0f==='child_changed')this['changeMap']['set'](_0x2278a9,Nt(_0x2278a9,_0x57af26['oldSnap']));else{if(_0x2db5cc==='child_changed'&&_0x5c0d0f==='child_added')this['changeMap']['set'](_0x2278a9,tt(_0x2278a9,_0x2786eb['snapshotNode']));else{if(_0x2db5cc==='child_changed'&&_0x5c0d0f==='child_changed')this['changeMap']['set'](_0x2278a9,Pt(_0x2278a9,_0x2786eb['snapshotNode'],_0x57af26['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x2786eb+'\x20occurred\x20after\x20'+_0x57af26);}}}}}else this['changeMap']['set'](_0x2278a9,_0x2786eb);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x8e3491){return null;}['getChildAfterChild'](_0x15f913,_0x1926e8,_0x5b3258){return null;}}const Vo=new Iu();class ns{constructor(_0x4657c9,_0x43a28e,_0x186e7c=null){this['writes_']=_0x4657c9,this['viewCache_']=_0x43a28e,this['optCompleteServerCache_']=_0x186e7c;}['getCompleteChild'](_0x41c0da){const _0x489bb5=this['viewCache_']['eventCache'];if(_0x489bb5['isCompleteForChild'](_0x41c0da))return _0x489bb5['getNode']()['getImmediateChild'](_0x41c0da);{const _0x3f5bab=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x41c0da,_0x3f5bab);}}['getChildAfterChild'](_0x1ab42c,_0x313b55,_0x22a038){const _0x26ce5d=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x3841d1=vu(this['writes_'],_0x26ce5d,_0x313b55,0x1,_0x22a038,_0x1ab42c);return _0x3841d1['length']===0x0?null:_0x3841d1[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x57c803){return{'filter':_0x57c803};}function Cu(_0x4c625f,_0x4dcc44){f(_0x4dcc44['eventCache']['getNode']()['isIndexed'](_0x4c625f['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4dcc44['serverCache']['getNode']()['isIndexed'](_0x4c625f['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x150b5c,_0x2d3c09,_0x1d052e,_0x57afe9,_0x1dcf05){const _0x4d4a08=new Eu();let _0x3c0972,_0xf236a7;if(_0x1d052e['type']===q['OVERWRITE']){const _0x46c5b3=_0x1d052e;_0x46c5b3['source']['fromUser']?_0x3c0972=Ti(_0x150b5c,_0x2d3c09,_0x46c5b3['path'],_0x46c5b3['snap'],_0x57afe9,_0x1dcf05,_0x4d4a08):(f(_0x46c5b3['source']['fromServer'],'Unknown\x20source.'),_0xf236a7=_0x46c5b3['source']['tagged']||_0x2d3c09['serverCache']['isFiltered']()&&!v(_0x46c5b3['path']),_0x3c0972=vn(_0x150b5c,_0x2d3c09,_0x46c5b3['path'],_0x46c5b3['snap'],_0x57afe9,_0x1dcf05,_0xf236a7,_0x4d4a08));}else{if(_0x1d052e['type']===q['MERGE']){const _0x33cc11=_0x1d052e;_0x33cc11['source']['fromUser']?_0x3c0972=bu(_0x150b5c,_0x2d3c09,_0x33cc11['path'],_0x33cc11['children'],_0x57afe9,_0x1dcf05,_0x4d4a08):(f(_0x33cc11['source']['fromServer'],'Unknown\x20source.'),_0xf236a7=_0x33cc11['source']['tagged']||_0x2d3c09['serverCache']['isFiltered'](),_0x3c0972=Si(_0x150b5c,_0x2d3c09,_0x33cc11['path'],_0x33cc11['children'],_0x57afe9,_0x1dcf05,_0xf236a7,_0x4d4a08));}else{if(_0x1d052e['type']===q['ACK_USER_WRITE']){const _0xa4ebdb=_0x1d052e;_0xa4ebdb['revert']?_0x3c0972=ku(_0x150b5c,_0x2d3c09,_0xa4ebdb['path'],_0x57afe9,_0x1dcf05,_0x4d4a08):_0x3c0972=Ru(_0x150b5c,_0x2d3c09,_0xa4ebdb['path'],_0xa4ebdb['affectedTree'],_0x57afe9,_0x1dcf05,_0x4d4a08);}else{if(_0x1d052e['type']===q['LISTEN_COMPLETE'])_0x3c0972=Au(_0x150b5c,_0x2d3c09,_0x1d052e['path'],_0x57afe9,_0x4d4a08);else throw ot('Unknown\x20operation\x20type:\x20'+_0x1d052e['type']);}}}const _0x42076e=_0x4d4a08['getChanges']();return Su(_0x2d3c09,_0x3c0972,_0x42076e),{'viewCache':_0x3c0972,'changes':_0x42076e};}function Su(_0x34f4db,_0x1e2ace,_0x5e54fe){const _0x4d18cc=_0x1e2ace['eventCache'];if(_0x4d18cc['isFullyInitialized']()){const _0x991146=_0x4d18cc['getNode']()['isLeafNode']()||_0x4d18cc['getNode']()['isEmpty'](),_0x15de9d=gn(_0x34f4db);(_0x5e54fe['length']>0x0||!_0x34f4db['eventCache']['isFullyInitialized']()||_0x991146&&!_0x4d18cc['getNode']()['equals'](_0x15de9d)||!_0x4d18cc['getNode']()['getPriority']()['equals'](_0x15de9d['getPriority']()))&&_0x5e54fe['push'](Oo(gn(_0x1e2ace)));}}function Ho(_0x1f575c,_0x338aad,_0x35ad83,_0x276153,_0x49f318,_0x5bad09){const _0x187826=_0x338aad['eventCache'];if(yn(_0x276153,_0x35ad83)!=null)return _0x338aad;{let _0x42aa96,_0x5d7fb5;if(v(_0x35ad83)){if(f(_0x338aad['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x338aad['serverCache']['isFiltered']()){const _0x47d258=Ue(_0x338aad),_0x3d73fa=_0x47d258 instanceof g?_0x47d258:g['EMPTY_NODE'],_0x2d28dd=es(_0x276153,_0x3d73fa);_0x42aa96=_0x1f575c['filter']['updateFullNode'](_0x338aad['eventCache']['getNode'](),_0x2d28dd,_0x5bad09);}else{const _0x235970=mn(_0x276153,Ue(_0x338aad));_0x42aa96=_0x1f575c['filter']['updateFullNode'](_0x338aad['eventCache']['getNode'](),_0x235970,_0x5bad09);}}else{const _0x1f9727=y(_0x35ad83);if(_0x1f9727==='.priority'){f(we(_0x35ad83)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x274e0c=_0x187826['getNode']();_0x5d7fb5=_0x338aad['serverCache']['getNode']();const _0x1e7655=or(_0x276153,_0x35ad83,_0x274e0c,_0x5d7fb5);_0x1e7655!=null?_0x42aa96=_0x1f575c['filter']['updatePriority'](_0x274e0c,_0x1e7655):_0x42aa96=_0x187826['getNode']();}else{const _0x165d88=b(_0x35ad83);let _0x409368;if(_0x187826['isCompleteForChild'](_0x1f9727)){_0x5d7fb5=_0x338aad['serverCache']['getNode']();const _0x531fd8=or(_0x276153,_0x35ad83,_0x187826['getNode'](),_0x5d7fb5);_0x531fd8!=null?_0x409368=_0x187826['getNode']()['getImmediateChild'](_0x1f9727)['updateChild'](_0x165d88,_0x531fd8):_0x409368=_0x187826['getNode']()['getImmediateChild'](_0x1f9727);}else _0x409368=ts(_0x276153,_0x1f9727,_0x338aad['serverCache']);_0x409368!=null?_0x42aa96=_0x1f575c['filter']['updateChild'](_0x187826['getNode'](),_0x1f9727,_0x409368,_0x165d88,_0x49f318,_0x5bad09):_0x42aa96=_0x187826['getNode']();}}return wt(_0x338aad,_0x42aa96,_0x187826['isFullyInitialized']()||v(_0x35ad83),_0x1f575c['filter']['filtersNodes']());}}function vn(_0xce1976,_0x4d501a,_0x2378e2,_0xb37a16,_0x5dcaa9,_0x2eff0a,_0x1a5219,_0x57a069){const _0x1679eb=_0x4d501a['serverCache'];let _0xb548dc;const _0x297c9e=_0x1a5219?_0xce1976['filter']:_0xce1976['filter']['getIndexedFilter']();if(v(_0x2378e2))_0xb548dc=_0x297c9e['updateFullNode'](_0x1679eb['getNode'](),_0xb37a16,null);else{if(_0x297c9e['filtersNodes']()&&!_0x1679eb['isFiltered']()){const _0x16e5c4=_0x1679eb['getNode']()['updateChild'](_0x2378e2,_0xb37a16);_0xb548dc=_0x297c9e['updateFullNode'](_0x1679eb['getNode'](),_0x16e5c4,null);}else{const _0x559ba3=y(_0x2378e2);if(!_0x1679eb['isCompleteForPath'](_0x2378e2)&&we(_0x2378e2)>0x1)return _0x4d501a;const _0x56967a=b(_0x2378e2),_0x54da0b=_0x1679eb['getNode']()['getImmediateChild'](_0x559ba3)['updateChild'](_0x56967a,_0xb37a16);_0x559ba3==='.priority'?_0xb548dc=_0x297c9e['updatePriority'](_0x1679eb['getNode'](),_0x54da0b):_0xb548dc=_0x297c9e['updateChild'](_0x1679eb['getNode'](),_0x559ba3,_0x54da0b,_0x56967a,Vo,null);}}const _0x4ecad2=Lo(_0x4d501a,_0xb548dc,_0x1679eb['isFullyInitialized']()||v(_0x2378e2),_0x297c9e['filtersNodes']()),_0x4d98a7=new ns(_0x5dcaa9,_0x4ecad2,_0x2eff0a);return Ho(_0xce1976,_0x4ecad2,_0x2378e2,_0x5dcaa9,_0x4d98a7,_0x57a069);}function Ti(_0x2cde46,_0x18e9ec,_0x555089,_0x3e2c3e,_0x5f1acd,_0x5788af,_0x44b13f){const _0x3b9032=_0x18e9ec['eventCache'];let _0x1826b9,_0x4e4fa5;const _0xcaf415=new ns(_0x5f1acd,_0x18e9ec,_0x5788af);if(v(_0x555089))_0x4e4fa5=_0x2cde46['filter']['updateFullNode'](_0x18e9ec['eventCache']['getNode'](),_0x3e2c3e,_0x44b13f),_0x1826b9=wt(_0x18e9ec,_0x4e4fa5,!0x0,_0x2cde46['filter']['filtersNodes']());else{const _0x11226f=y(_0x555089);if(_0x11226f==='.priority')_0x4e4fa5=_0x2cde46['filter']['updatePriority'](_0x18e9ec['eventCache']['getNode'](),_0x3e2c3e),_0x1826b9=wt(_0x18e9ec,_0x4e4fa5,_0x3b9032['isFullyInitialized'](),_0x3b9032['isFiltered']());else{const _0x2a6076=b(_0x555089),_0x4e9320=_0x3b9032['getNode']()['getImmediateChild'](_0x11226f);let _0x4eb978;if(v(_0x2a6076))_0x4eb978=_0x3e2c3e;else{const _0x1e5fcf=_0xcaf415['getCompleteChild'](_0x11226f);_0x1e5fcf!=null?Gi(_0x2a6076)==='.priority'&&_0x1e5fcf['getChild'](To(_0x2a6076))['isEmpty']()?_0x4eb978=_0x1e5fcf:_0x4eb978=_0x1e5fcf['updateChild'](_0x2a6076,_0x3e2c3e):_0x4eb978=g['EMPTY_NODE'];}if(_0x4e9320['equals'](_0x4eb978))_0x1826b9=_0x18e9ec;else{const _0x246617=_0x2cde46['filter']['updateChild'](_0x3b9032['getNode'](),_0x11226f,_0x4eb978,_0x2a6076,_0xcaf415,_0x44b13f);_0x1826b9=wt(_0x18e9ec,_0x246617,_0x3b9032['isFullyInitialized'](),_0x2cde46['filter']['filtersNodes']());}}}return _0x1826b9;}function ar(_0x11866e,_0x8d2080){return _0x11866e['eventCache']['isCompleteForChild'](_0x8d2080);}function bu(_0x53ed9e,_0xab4096,_0x4f022d,_0x20a714,_0x1bf91f,_0x2566b9,_0x52eece){let _0x2df04c=_0xab4096;return _0x20a714['foreach']((_0x551253,_0x37e72d)=>{const _0x5e90c7=A(_0x4f022d,_0x551253);ar(_0xab4096,y(_0x5e90c7))&&(_0x2df04c=Ti(_0x53ed9e,_0x2df04c,_0x5e90c7,_0x37e72d,_0x1bf91f,_0x2566b9,_0x52eece));}),_0x20a714['foreach']((_0xf275d9,_0x422fa3)=>{const _0x27d529=A(_0x4f022d,_0xf275d9);ar(_0xab4096,y(_0x27d529))||(_0x2df04c=Ti(_0x53ed9e,_0x2df04c,_0x27d529,_0x422fa3,_0x1bf91f,_0x2566b9,_0x52eece));}),_0x2df04c;}function cr(_0x560d68,_0x17e448,_0x4ffc37){return _0x4ffc37['foreach']((_0x54d88d,_0x45ac9f)=>{_0x17e448=_0x17e448['updateChild'](_0x54d88d,_0x45ac9f);}),_0x17e448;}function Si(_0x466c19,_0x4ad175,_0x55b685,_0x332543,_0xd3611f,_0x4fd17e,_0x20fbaa,_0x502368){if(_0x4ad175['serverCache']['getNode']()['isEmpty']()&&!_0x4ad175['serverCache']['isFullyInitialized']())return _0x4ad175;let _0x3ccfdd=_0x4ad175,_0x420f45;v(_0x55b685)?_0x420f45=_0x332543:_0x420f45=new S(null)['setTree'](_0x55b685,_0x332543);const _0x1c3e73=_0x4ad175['serverCache']['getNode']();return _0x420f45['children']['inorderTraversal']((_0x3b9257,_0x2e868b)=>{if(_0x1c3e73['hasChild'](_0x3b9257)){const _0x3f9834=_0x4ad175['serverCache']['getNode']()['getImmediateChild'](_0x3b9257),_0x2e1df6=cr(_0x466c19,_0x3f9834,_0x2e868b);_0x3ccfdd=vn(_0x466c19,_0x3ccfdd,new C(_0x3b9257),_0x2e1df6,_0xd3611f,_0x4fd17e,_0x20fbaa,_0x502368);}}),_0x420f45['children']['inorderTraversal']((_0x17d01f,_0x769f5d)=>{const _0x45a52b=!_0x4ad175['serverCache']['isCompleteForChild'](_0x17d01f)&&_0x769f5d['value']===null;if(!_0x1c3e73['hasChild'](_0x17d01f)&&!_0x45a52b){const _0x3285c3=_0x4ad175['serverCache']['getNode']()['getImmediateChild'](_0x17d01f),_0x4c8d80=cr(_0x466c19,_0x3285c3,_0x769f5d);_0x3ccfdd=vn(_0x466c19,_0x3ccfdd,new C(_0x17d01f),_0x4c8d80,_0xd3611f,_0x4fd17e,_0x20fbaa,_0x502368);}}),_0x3ccfdd;}function Ru(_0x30624f,_0x1f9218,_0x7722a,_0x4b5d1d,_0x549daf,_0x57da84,_0x302213){if(yn(_0x549daf,_0x7722a)!=null)return _0x1f9218;const _0x360e8c=_0x1f9218['serverCache']['isFiltered'](),_0x5c31a1=_0x1f9218['serverCache'];if(_0x4b5d1d['value']!=null){if(v(_0x7722a)&&_0x5c31a1['isFullyInitialized']()||_0x5c31a1['isCompleteForPath'](_0x7722a))return vn(_0x30624f,_0x1f9218,_0x7722a,_0x5c31a1['getNode']()['getChild'](_0x7722a),_0x549daf,_0x57da84,_0x360e8c,_0x302213);if(v(_0x7722a)){let _0x4a8112=new S(null);return _0x5c31a1['getNode']()['forEachChild'](ye,(_0x29a751,_0x4702eb)=>{_0x4a8112=_0x4a8112['set'](new C(_0x29a751),_0x4702eb);}),Si(_0x30624f,_0x1f9218,_0x7722a,_0x4a8112,_0x549daf,_0x57da84,_0x360e8c,_0x302213);}else return _0x1f9218;}else{let _0x74742b=new S(null);return _0x4b5d1d['foreach']((_0x36d5fb,_0x1cbae5)=>{const _0x4cea14=A(_0x7722a,_0x36d5fb);_0x5c31a1['isCompleteForPath'](_0x4cea14)&&(_0x74742b=_0x74742b['set'](_0x36d5fb,_0x5c31a1['getNode']()['getChild'](_0x4cea14)));}),Si(_0x30624f,_0x1f9218,_0x7722a,_0x74742b,_0x549daf,_0x57da84,_0x360e8c,_0x302213);}}function Au(_0x3500f8,_0x5f413c,_0x93d470,_0x21955d,_0x3f3906){const _0x21f7b0=_0x5f413c['serverCache'],_0x163856=Lo(_0x5f413c,_0x21f7b0['getNode'](),_0x21f7b0['isFullyInitialized']()||v(_0x93d470),_0x21f7b0['isFiltered']());return Ho(_0x3500f8,_0x163856,_0x93d470,_0x21955d,Vo,_0x3f3906);}function ku(_0x1864a8,_0x3e02e2,_0x224583,_0x3cbf41,_0x19adbb,_0x39900c){let _0x1a27c1;if(yn(_0x3cbf41,_0x224583)!=null)return _0x3e02e2;{const _0xdf366c=new ns(_0x3cbf41,_0x3e02e2,_0x19adbb),_0xe45583=_0x3e02e2['eventCache']['getNode']();let _0x5c680b;if(v(_0x224583)||y(_0x224583)==='.priority'){let _0x157c2d;if(_0x3e02e2['serverCache']['isFullyInitialized']())_0x157c2d=mn(_0x3cbf41,Ue(_0x3e02e2));else{const _0x12cd93=_0x3e02e2['serverCache']['getNode']();f(_0x12cd93 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x157c2d=es(_0x3cbf41,_0x12cd93);}_0x157c2d=_0x157c2d,_0x5c680b=_0x1864a8['filter']['updateFullNode'](_0xe45583,_0x157c2d,_0x39900c);}else{const _0x32b4b6=y(_0x224583);let _0x280922=ts(_0x3cbf41,_0x32b4b6,_0x3e02e2['serverCache']);_0x280922==null&&_0x3e02e2['serverCache']['isCompleteForChild'](_0x32b4b6)&&(_0x280922=_0xe45583['getImmediateChild'](_0x32b4b6)),_0x280922!=null?_0x5c680b=_0x1864a8['filter']['updateChild'](_0xe45583,_0x32b4b6,_0x280922,b(_0x224583),_0xdf366c,_0x39900c):_0x3e02e2['eventCache']['getNode']()['hasChild'](_0x32b4b6)?_0x5c680b=_0x1864a8['filter']['updateChild'](_0xe45583,_0x32b4b6,g['EMPTY_NODE'],b(_0x224583),_0xdf366c,_0x39900c):_0x5c680b=_0xe45583,_0x5c680b['isEmpty']()&&_0x3e02e2['serverCache']['isFullyInitialized']()&&(_0x1a27c1=mn(_0x3cbf41,Ue(_0x3e02e2)),_0x1a27c1['isLeafNode']()&&(_0x5c680b=_0x1864a8['filter']['updateFullNode'](_0x5c680b,_0x1a27c1,_0x39900c)));}return _0x1a27c1=_0x3e02e2['serverCache']['isFullyInitialized']()||yn(_0x3cbf41,w())!=null,wt(_0x3e02e2,_0x5c680b,_0x1a27c1,_0x1864a8['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x33f3bc,_0x3357e3){this['query_']=_0x33f3bc,this['eventRegistrations_']=[];const _0x3efc50=this['query_']['_queryParams'],_0x11eddd=new Yi(_0x3efc50['getIndex']()),_0x3f18cf=qh(_0x3efc50);this['processor_']=wu(_0x3f18cf);const _0x3a91d8=_0x3357e3['serverCache'],_0xd85f34=_0x3357e3['eventCache'],_0x2da73c=_0x11eddd['updateFullNode'](g['EMPTY_NODE'],_0x3a91d8['getNode'](),null),_0x27fa56=_0x3f18cf['updateFullNode'](g['EMPTY_NODE'],_0xd85f34['getNode'](),null),_0x5b2559=new Ce(_0x2da73c,_0x3a91d8['isFullyInitialized'](),_0x11eddd['filtersNodes']()),_0x49fc33=new Ce(_0x27fa56,_0xd85f34['isFullyInitialized'](),_0x3f18cf['filtersNodes']());this['viewCache_']=Dn(_0x49fc33,_0x5b2559),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x5c00de){return _0x5c00de['viewCache_']['serverCache']['getNode']();}function Ou(_0x54a854){return gn(_0x54a854['viewCache_']);}function Du(_0x1ac49a,_0x290cf3){const _0xb837c4=Ue(_0x1ac49a['viewCache_']);return _0xb837c4&&(_0x1ac49a['query']['_queryParams']['loadsAllData']()||!v(_0x290cf3)&&!_0xb837c4['getImmediateChild'](y(_0x290cf3))['isEmpty']())?_0xb837c4['getChild'](_0x290cf3):null;}function lr(_0x50fed6){return _0x50fed6['eventRegistrations_']['length']===0x0;}function Mu(_0x2c78d9,_0x61e8c2){_0x2c78d9['eventRegistrations_']['push'](_0x61e8c2);}function hr(_0x52303d,_0x3f7ad5,_0x459f45){const _0x2b4d94=[];if(_0x459f45){f(_0x3f7ad5==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x38f93f=_0x52303d['query']['_path'];_0x52303d['eventRegistrations_']['forEach'](_0x56a7cf=>{const _0x2796b3=_0x56a7cf['createCancelEvent'](_0x459f45,_0x38f93f);_0x2796b3&&_0x2b4d94['push'](_0x2796b3);});}if(_0x3f7ad5){let _0x58cf18=[];for(let _0x5992da=0x0;_0x5992da<_0x52303d['eventRegistrations_']['length'];++_0x5992da){const _0x262069=_0x52303d['eventRegistrations_'][_0x5992da];if(!_0x262069['matches'](_0x3f7ad5))_0x58cf18['push'](_0x262069);else{if(_0x3f7ad5['hasAnyCallback']()){_0x58cf18=_0x58cf18['concat'](_0x52303d['eventRegistrations_']['slice'](_0x5992da+0x1));break;}}}_0x52303d['eventRegistrations_']=_0x58cf18;}else _0x52303d['eventRegistrations_']=[];return _0x2b4d94;}function ur(_0x29329f,_0x4cba89,_0x245978,_0x482100){_0x4cba89['type']===q['MERGE']&&_0x4cba89['source']['queryId']!==null&&(f(Ue(_0x29329f['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x29329f['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x419a00=_0x29329f['viewCache_'],_0x4d24a9=Tu(_0x29329f['processor_'],_0x419a00,_0x4cba89,_0x245978,_0x482100);return Cu(_0x29329f['processor_'],_0x4d24a9['viewCache']),f(_0x4d24a9['viewCache']['serverCache']['isFullyInitialized']()||!_0x419a00['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x29329f['viewCache_']=_0x4d24a9['viewCache'],$o(_0x29329f,_0x4d24a9['changes'],_0x4d24a9['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x50b064,_0x580f49){const _0x52de3d=_0x50b064['viewCache_']['eventCache'],_0x4835dc=[];return _0x52de3d['getNode']()['isLeafNode']()||_0x52de3d['getNode']()['forEachChild'](R,(_0x5161e6,_0x4302a8)=>{_0x4835dc['push'](tt(_0x5161e6,_0x4302a8));}),_0x52de3d['isFullyInitialized']()&&_0x4835dc['push'](Oo(_0x52de3d['getNode']())),$o(_0x50b064,_0x4835dc,_0x52de3d['getNode'](),_0x580f49);}function $o(_0x43e561,_0x3748f3,_0x310735,_0x2c89c7){const _0x113d59=_0x2c89c7?[_0x2c89c7]:_0x43e561['eventRegistrations_'];return nu(_0x43e561['eventGenerator_'],_0x3748f3,_0x310735,_0x113d59);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0xd22d56){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0xd22d56;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x405949){return _0x405949['views']['size']===0x0;}function is(_0xa2330e,_0x469608,_0x878fa5,_0xcd29e0){const _0x2b3238=_0x469608['source']['queryId'];if(_0x2b3238!==null){const _0x2d4dab=_0xa2330e['views']['get'](_0x2b3238);return f(_0x2d4dab!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x2d4dab,_0x469608,_0x878fa5,_0xcd29e0);}else{let _0x2f5473=[];for(const _0x142c95 of _0xa2330e['views']['values']())_0x2f5473=_0x2f5473['concat'](ur(_0x142c95,_0x469608,_0x878fa5,_0xcd29e0));return _0x2f5473;}}function qo(_0x3ffc4d,_0xc7cdae,_0x203dc4,_0x314564,_0x25e996){const _0x556231=_0xc7cdae['_queryIdentifier'],_0x3a22ae=_0x3ffc4d['views']['get'](_0x556231);if(!_0x3a22ae){let _0x19b5d8=mn(_0x203dc4,_0x25e996?_0x314564:null),_0x4e58fe=!0x1;_0x19b5d8?_0x4e58fe=!0x0:_0x314564 instanceof g?(_0x19b5d8=es(_0x203dc4,_0x314564),_0x4e58fe=!0x1):(_0x19b5d8=g['EMPTY_NODE'],_0x4e58fe=!0x1);const _0x4340a6=Dn(new Ce(_0x19b5d8,_0x4e58fe,!0x1),new Ce(_0x314564,_0x25e996,!0x1));return new Nu(_0xc7cdae,_0x4340a6);}return _0x3a22ae;}function Wu(_0x12eaf7,_0x3f6060,_0x53086d,_0x4711f6,_0x86d336,_0x1a4c01){const _0x44a3fd=qo(_0x12eaf7,_0x3f6060,_0x4711f6,_0x86d336,_0x1a4c01);return _0x12eaf7['views']['has'](_0x3f6060['_queryIdentifier'])||_0x12eaf7['views']['set'](_0x3f6060['_queryIdentifier'],_0x44a3fd),Mu(_0x44a3fd,_0x53086d),Lu(_0x44a3fd,_0x53086d);}function Bu(_0x229a4c,_0x18ca76,_0x40c975,_0x52abe3){const _0x196876=_0x18ca76['_queryIdentifier'],_0xfebb4b=[];let _0x78dbc1=[];const _0x485ba4=Te(_0x229a4c);if(_0x196876==='default'){for(const [_0x2e591a,_0x1f9e25]of _0x229a4c['views']['entries']())_0x78dbc1=_0x78dbc1['concat'](hr(_0x1f9e25,_0x40c975,_0x52abe3)),lr(_0x1f9e25)&&(_0x229a4c['views']['delete'](_0x2e591a),_0x1f9e25['query']['_queryParams']['loadsAllData']()||_0xfebb4b['push'](_0x1f9e25['query']));}else{const _0x2d0f4b=_0x229a4c['views']['get'](_0x196876);_0x2d0f4b&&(_0x78dbc1=_0x78dbc1['concat'](hr(_0x2d0f4b,_0x40c975,_0x52abe3)),lr(_0x2d0f4b)&&(_0x229a4c['views']['delete'](_0x196876),_0x2d0f4b['query']['_queryParams']['loadsAllData']()||_0xfebb4b['push'](_0x2d0f4b['query'])));}return _0x485ba4&&!Te(_0x229a4c)&&_0xfebb4b['push'](new(Fu())(_0x18ca76['_repo'],_0x18ca76['_path'])),{'removed':_0xfebb4b,'events':_0x78dbc1};}function zo(_0x371a61){const _0x2ec7a5=[];for(const _0x4fd33f of _0x371a61['views']['values']())_0x4fd33f['query']['_queryParams']['loadsAllData']()||_0x2ec7a5['push'](_0x4fd33f);return _0x2ec7a5;}function Ee(_0x5f3f22,_0x51bb80){let _0x48353a=null;for(const _0x4dd477 of _0x5f3f22['views']['values']())_0x48353a=_0x48353a||Du(_0x4dd477,_0x51bb80);return _0x48353a;}function jo(_0x8631dc,_0x1cf162){if(_0x1cf162['_queryParams']['loadsAllData']())return Ln(_0x8631dc);{const _0x35b200=_0x1cf162['_queryIdentifier'];return _0x8631dc['views']['get'](_0x35b200);}}function Ko(_0x14f43d,_0x14eca1){return jo(_0x14f43d,_0x14eca1)!=null;}function Te(_0x406244){return Ln(_0x406244)!=null;}function Ln(_0x36fee4){for(const _0x3c6241 of _0x36fee4['views']['values']())if(_0x3c6241['query']['_queryParams']['loadsAllData']())return _0x3c6241;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x233c3c){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x233c3c;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x290fa5){this['listenProvider_']=_0x290fa5,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x34b1e6,_0x2e1d18,_0x5bf7c3,_0xa2ca36,_0x60baa4){return ou(_0x34b1e6['pendingWriteTree_'],_0x2e1d18,_0x5bf7c3,_0xa2ca36,_0x60baa4),_0x60baa4?ht(_0x34b1e6,new Fe(Ji(),_0x2e1d18,_0x5bf7c3)):[];}function Gu(_0x463ac2,_0x450d98,_0x270368,_0x256b6e){au(_0x463ac2['pendingWriteTree_'],_0x450d98,_0x270368,_0x256b6e);const _0x589951=S['fromObject'](_0x270368);return ht(_0x463ac2,new nt(Ji(),_0x450d98,_0x589951));}function pe(_0x4d42d4,_0x54d66b,_0x51e16b=!0x1){const _0xd86f0b=cu(_0x4d42d4['pendingWriteTree_'],_0x54d66b);if(lu(_0x4d42d4['pendingWriteTree_'],_0x54d66b)){let _0x25b952=new S(null);return _0xd86f0b['snap']!=null?_0x25b952=_0x25b952['set'](w(),!0x0):x(_0xd86f0b['children'],_0xa772f2=>{_0x25b952=_0x25b952['set'](new C(_0xa772f2),!0x0);}),ht(_0x4d42d4,new _n(_0xd86f0b['path'],_0x25b952,_0x51e16b));}else return[];}function $t(_0x13604d,_0x5da9ee,_0x5b3d38){return ht(_0x13604d,new Fe(Xi(),_0x5da9ee,_0x5b3d38));}function qu(_0x4507d1,_0x5f1fab,_0x2543f4){const _0x373ce6=S['fromObject'](_0x2543f4);return ht(_0x4507d1,new nt(Xi(),_0x5f1fab,_0x373ce6));}function zu(_0x3b60af,_0xf0924e){return ht(_0x3b60af,new Dt(Xi(),_0xf0924e));}function ju(_0x1440e0,_0x1180c1,_0x41fa66){const _0x26a2ac=rs(_0x1440e0,_0x41fa66);if(_0x26a2ac){const _0x22cbdb=os(_0x26a2ac),_0x4a1529=_0x22cbdb['path'],_0x14f467=_0x22cbdb['queryId'],_0x5378c8=F(_0x4a1529,_0x1180c1),_0x1a9bfb=new Dt(Zi(_0x14f467),_0x5378c8);return as(_0x1440e0,_0x4a1529,_0x1a9bfb);}else return[];}function wn(_0x4577bd,_0x5d0b87,_0xebeb9c,_0x100792,_0x414474=!0x1){const _0xcf4915=_0x5d0b87['_path'],_0x4d18a5=_0x4577bd['syncPointTree_']['get'](_0xcf4915);let _0x20e75d=[];if(_0x4d18a5&&(_0x5d0b87['_queryIdentifier']==='default'||Ko(_0x4d18a5,_0x5d0b87))){const _0x528df6=Bu(_0x4d18a5,_0x5d0b87,_0xebeb9c,_0x100792);Uu(_0x4d18a5)&&(_0x4577bd['syncPointTree_']=_0x4577bd['syncPointTree_']['remove'](_0xcf4915));const _0xe4413d=_0x528df6['removed'];if(_0x20e75d=_0x528df6['events'],!_0x414474){const _0x57197b=_0xe4413d['findIndex'](_0x23040c=>_0x23040c['_queryParams']['loadsAllData']())!==-0x1,_0x4b9344=_0x4577bd['syncPointTree_']['findOnPath'](_0xcf4915,(_0x22ce39,_0x4b05c0)=>Te(_0x4b05c0));if(_0x57197b&&!_0x4b9344){const _0x40d64f=_0x4577bd['syncPointTree_']['subtree'](_0xcf4915);if(!_0x40d64f['isEmpty']()){const _0x21efbe=Qu(_0x40d64f);for(let _0x5afb61=0x0;_0x5afb61<_0x21efbe['length'];++_0x5afb61){const _0x389714=_0x21efbe[_0x5afb61],_0x202b23=_0x389714['query'],_0x97f60c=Xo(_0x4577bd,_0x389714);_0x4577bd['listenProvider_']['startListening'](Tt(_0x202b23),Mt(_0x4577bd,_0x202b23),_0x97f60c['hashFn'],_0x97f60c['onComplete']);}}}!_0x4b9344&&_0xe4413d['length']>0x0&&!_0x100792&&(_0x57197b?_0x4577bd['listenProvider_']['stopListening'](Tt(_0x5d0b87),null):_0xe4413d['forEach'](_0x13d963=>{const _0x4e17ae=_0x4577bd['queryToTagMap']['get'](Fn(_0x13d963));_0x4577bd['listenProvider_']['stopListening'](Tt(_0x13d963),_0x4e17ae);}));}Ju(_0x4577bd,_0xe4413d);}return _0x20e75d;}function Yo(_0x2ee287,_0x199ffa,_0xc15974,_0x26bfe4){const _0x27815d=rs(_0x2ee287,_0x26bfe4);if(_0x27815d!=null){const _0x41dd71=os(_0x27815d),_0x525edb=_0x41dd71['path'],_0x1dd2ea=_0x41dd71['queryId'],_0x2f145d=F(_0x525edb,_0x199ffa),_0x3d2d44=new Fe(Zi(_0x1dd2ea),_0x2f145d,_0xc15974);return as(_0x2ee287,_0x525edb,_0x3d2d44);}else return[];}function Ku(_0x402404,_0x40e932,_0x24e845,_0x3f5b88){const _0xc79ba8=rs(_0x402404,_0x3f5b88);if(_0xc79ba8){const _0x4d7287=os(_0xc79ba8),_0x5c8ed6=_0x4d7287['path'],_0x390df=_0x4d7287['queryId'],_0x14d406=F(_0x5c8ed6,_0x40e932),_0x47f00e=S['fromObject'](_0x24e845),_0xef9c62=new nt(Zi(_0x390df),_0x14d406,_0x47f00e);return as(_0x402404,_0x5c8ed6,_0xef9c62);}else return[];}function bi(_0xadeaf3,_0x5118e5,_0x3a3cd8,_0x1e2041=!0x1){const _0x52441c=_0x5118e5['_path'];let _0x51ab0d=null,_0x24313a=!0x1;_0xadeaf3['syncPointTree_']['foreachOnPath'](_0x52441c,(_0x38bf99,_0x251915)=>{const _0x4ed2b9=F(_0x38bf99,_0x52441c);_0x51ab0d=_0x51ab0d||Ee(_0x251915,_0x4ed2b9),_0x24313a=_0x24313a||Te(_0x251915);});let _0xd2a1df=_0xadeaf3['syncPointTree_']['get'](_0x52441c);_0xd2a1df?(_0x24313a=_0x24313a||Te(_0xd2a1df),_0x51ab0d=_0x51ab0d||Ee(_0xd2a1df,w())):(_0xd2a1df=new Go(),_0xadeaf3['syncPointTree_']=_0xadeaf3['syncPointTree_']['set'](_0x52441c,_0xd2a1df));let _0x377ba6;_0x51ab0d!=null?_0x377ba6=!0x0:(_0x377ba6=!0x1,_0x51ab0d=g['EMPTY_NODE'],_0xadeaf3['syncPointTree_']['subtree'](_0x52441c)['foreachChild']((_0x599a95,_0x53d176)=>{const _0x7dd86c=Ee(_0x53d176,w());_0x7dd86c&&(_0x51ab0d=_0x51ab0d['updateImmediateChild'](_0x599a95,_0x7dd86c));}));const _0xd0f936=Ko(_0xd2a1df,_0x5118e5);if(!_0xd0f936&&!_0x5118e5['_queryParams']['loadsAllData']()){const _0x5b6505=Fn(_0x5118e5);f(!_0xadeaf3['queryToTagMap']['has'](_0x5b6505),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x5b356c=Xu();_0xadeaf3['queryToTagMap']['set'](_0x5b6505,_0x5b356c),_0xadeaf3['tagToQueryMap']['set'](_0x5b356c,_0x5b6505);}const _0x4bf8f9=Mn(_0xadeaf3['pendingWriteTree_'],_0x52441c);let _0x50b29c=Wu(_0xd2a1df,_0x5118e5,_0x3a3cd8,_0x4bf8f9,_0x51ab0d,_0x377ba6);if(!_0xd0f936&&!_0x24313a&&!_0x1e2041){const _0x4afab2=jo(_0xd2a1df,_0x5118e5);_0x50b29c=_0x50b29c['concat'](Zu(_0xadeaf3,_0x5118e5,_0x4afab2));}return _0x50b29c;}function xn(_0x31f815,_0x4b8c8a,_0x1be679){const _0x2c93cc=_0x31f815['pendingWriteTree_'],_0x179dc3=_0x31f815['syncPointTree_']['findOnPath'](_0x4b8c8a,(_0x475137,_0x1e67e6)=>{const _0x5008ec=F(_0x475137,_0x4b8c8a),_0x473beb=Ee(_0x1e67e6,_0x5008ec);if(_0x473beb)return _0x473beb;});return Uo(_0x2c93cc,_0x4b8c8a,_0x179dc3,_0x1be679,!0x0);}function Yu(_0x320ce8,_0x2319e6){const _0x290a8e=_0x2319e6['_path'];let _0x49c6da=null;_0x320ce8['syncPointTree_']['foreachOnPath'](_0x290a8e,(_0x7bf628,_0x440df0)=>{const _0x48cd02=F(_0x7bf628,_0x290a8e);_0x49c6da=_0x49c6da||Ee(_0x440df0,_0x48cd02);});let _0x996745=_0x320ce8['syncPointTree_']['get'](_0x290a8e);_0x996745?_0x49c6da=_0x49c6da||Ee(_0x996745,w()):(_0x996745=new Go(),_0x320ce8['syncPointTree_']=_0x320ce8['syncPointTree_']['set'](_0x290a8e,_0x996745));const _0x286d7b=_0x49c6da!=null,_0x53997c=_0x286d7b?new Ce(_0x49c6da,!0x0,!0x1):null,_0x29e6e7=Mn(_0x320ce8['pendingWriteTree_'],_0x2319e6['_path']),_0x10bcb1=qo(_0x996745,_0x2319e6,_0x29e6e7,_0x286d7b?_0x53997c['getNode']():g['EMPTY_NODE'],_0x286d7b);return Ou(_0x10bcb1);}function ht(_0x4fe287,_0x13c580){return Qo(_0x13c580,_0x4fe287['syncPointTree_'],null,Mn(_0x4fe287['pendingWriteTree_'],w()));}function Qo(_0x314f55,_0x211e63,_0x139f22,_0x37890e){if(v(_0x314f55['path']))return Jo(_0x314f55,_0x211e63,_0x139f22,_0x37890e);{const _0x22de68=_0x211e63['get'](w());_0x139f22==null&&_0x22de68!=null&&(_0x139f22=Ee(_0x22de68,w()));let _0x230b44=[];const _0x318bb7=y(_0x314f55['path']),_0x2ed9a3=_0x314f55['operationForChild'](_0x318bb7),_0x549a77=_0x211e63['children']['get'](_0x318bb7);if(_0x549a77&&_0x2ed9a3){const _0x3fd800=_0x139f22?_0x139f22['getImmediateChild'](_0x318bb7):null,_0x4b16ab=Wo(_0x37890e,_0x318bb7);_0x230b44=_0x230b44['concat'](Qo(_0x2ed9a3,_0x549a77,_0x3fd800,_0x4b16ab));}return _0x22de68&&(_0x230b44=_0x230b44['concat'](is(_0x22de68,_0x314f55,_0x37890e,_0x139f22))),_0x230b44;}}function Jo(_0xfe130c,_0x52c1fb,_0x498d57,_0x40581a){const _0x4f498f=_0x52c1fb['get'](w());_0x498d57==null&&_0x4f498f!=null&&(_0x498d57=Ee(_0x4f498f,w()));let _0x53b193=[];return _0x52c1fb['children']['inorderTraversal']((_0x3c761b,_0x4e37f9)=>{const _0xdaeb49=_0x498d57?_0x498d57['getImmediateChild'](_0x3c761b):null,_0x1ef64c=Wo(_0x40581a,_0x3c761b),_0x483b6c=_0xfe130c['operationForChild'](_0x3c761b);_0x483b6c&&(_0x53b193=_0x53b193['concat'](Jo(_0x483b6c,_0x4e37f9,_0xdaeb49,_0x1ef64c)));}),_0x4f498f&&(_0x53b193=_0x53b193['concat'](is(_0x4f498f,_0xfe130c,_0x40581a,_0x498d57))),_0x53b193;}function Xo(_0x374023,_0x442cbb){const _0x125b7e=_0x442cbb['query'],_0x2659bb=Mt(_0x374023,_0x125b7e);return{'hashFn':()=>(Pu(_0x442cbb)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x57f3bb=>{if(_0x57f3bb==='ok')return _0x2659bb?ju(_0x374023,_0x125b7e['_path'],_0x2659bb):zu(_0x374023,_0x125b7e['_path']);{const _0x5c479a=ql(_0x57f3bb,_0x125b7e);return wn(_0x374023,_0x125b7e,null,_0x5c479a);}}};}function Mt(_0x337683,_0x4348be){const _0x196bee=Fn(_0x4348be);return _0x337683['queryToTagMap']['get'](_0x196bee);}function Fn(_0x58f535){return _0x58f535['_path']['toString']()+'$'+_0x58f535['_queryIdentifier'];}function rs(_0xa0706b,_0x406a71){return _0xa0706b['tagToQueryMap']['get'](_0x406a71);}function os(_0x107880){const _0x260f9c=_0x107880['indexOf']('$');return f(_0x260f9c!==-0x1&&_0x260f9c<_0x107880['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x107880['substr'](_0x260f9c+0x1),'path':new C(_0x107880['substr'](0x0,_0x260f9c))};}function as(_0x2a5269,_0x4ae034,_0x34c8b2){const _0x17ac39=_0x2a5269['syncPointTree_']['get'](_0x4ae034);f(_0x17ac39,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4cfa34=Mn(_0x2a5269['pendingWriteTree_'],_0x4ae034);return is(_0x17ac39,_0x34c8b2,_0x4cfa34,null);}function Qu(_0x393143){return _0x393143['fold']((_0x40a7d3,_0x3dd348,_0x703ae0)=>{if(_0x3dd348&&Te(_0x3dd348))return[Ln(_0x3dd348)];{let _0x35d548=[];return _0x3dd348&&(_0x35d548=zo(_0x3dd348)),x(_0x703ae0,(_0x23c1c0,_0x29dbd4)=>{_0x35d548=_0x35d548['concat'](_0x29dbd4);}),_0x35d548;}});}function Tt(_0x5c406e){return _0x5c406e['_queryParams']['loadsAllData']()&&!_0x5c406e['_queryParams']['isDefault']()?new(Hu())(_0x5c406e['_repo'],_0x5c406e['_path']):_0x5c406e;}function Ju(_0x36d61c,_0x376fdf){for(let _0x304116=0x0;_0x304116<_0x376fdf['length'];++_0x304116){const _0x1326a4=_0x376fdf[_0x304116];if(!_0x1326a4['_queryParams']['loadsAllData']()){const _0x52a0d2=Fn(_0x1326a4),_0x57ac3a=_0x36d61c['queryToTagMap']['get'](_0x52a0d2);_0x36d61c['queryToTagMap']['delete'](_0x52a0d2),_0x36d61c['tagToQueryMap']['delete'](_0x57ac3a);}}}function Xu(){return $u++;}function Zu(_0x398676,_0x35d584,_0x19dc8d){const _0x46c049=_0x35d584['_path'],_0x356673=Mt(_0x398676,_0x35d584),_0x1bddee=Xo(_0x398676,_0x19dc8d),_0x437246=_0x398676['listenProvider_']['startListening'](Tt(_0x35d584),_0x356673,_0x1bddee['hashFn'],_0x1bddee['onComplete']),_0x1ecf4d=_0x398676['syncPointTree_']['subtree'](_0x46c049);if(_0x356673)f(!Te(_0x1ecf4d['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x96da32=_0x1ecf4d['fold']((_0x298a4a,_0x38e062,_0x10444f)=>{if(!v(_0x298a4a)&&_0x38e062&&Te(_0x38e062))return[Ln(_0x38e062)['query']];{let _0x4069ab=[];return _0x38e062&&(_0x4069ab=_0x4069ab['concat'](zo(_0x38e062)['map'](_0x5503a5=>_0x5503a5['query']))),x(_0x10444f,(_0x16daf3,_0xff031c)=>{_0x4069ab=_0x4069ab['concat'](_0xff031c);}),_0x4069ab;}});for(let _0x4fc208=0x0;_0x4fc208<_0x96da32['length'];++_0x4fc208){const _0x3eb4a7=_0x96da32[_0x4fc208];_0x398676['listenProvider_']['stopListening'](Tt(_0x3eb4a7),Mt(_0x398676,_0x3eb4a7));}}return _0x437246;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x232a3c){this['node_']=_0x232a3c;}['getImmediateChild'](_0x4d9bc4){const _0x41eeb8=this['node_']['getImmediateChild'](_0x4d9bc4);return new cs(_0x41eeb8);}['node'](){return this['node_'];}}class ls{constructor(_0x301677,_0x417311){this['syncTree_']=_0x301677,this['path_']=_0x417311;}['getImmediateChild'](_0x1887c2){const _0x6c7b1f=A(this['path_'],_0x1887c2);return new ls(this['syncTree_'],_0x6c7b1f);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x53d1b3){return _0x53d1b3=_0x53d1b3||{},_0x53d1b3['timestamp']=_0x53d1b3['timestamp']||new Date()['getTime'](),_0x53d1b3;},fr=function(_0x699434,_0x59a464,_0x4b5e83){if(!_0x699434||typeof _0x699434!='object')return _0x699434;if(f('.sv'in _0x699434,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x699434['.sv']=='string')return td(_0x699434['.sv'],_0x59a464,_0x4b5e83);if(typeof _0x699434['.sv']=='object')return nd(_0x699434['.sv'],_0x59a464);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x699434,null,0x2));},td=function(_0x2a5663,_0x2b63b7,_0x42c156){switch(_0x2a5663){case'timestamp':return _0x42c156['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2a5663);}},nd=function(_0x29fb92,_0x4e4f07,_0x25b7db){_0x29fb92['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x29fb92,null,0x2));const _0xe8042=_0x29fb92['increment'];typeof _0xe8042!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0xe8042);const _0x45c1a8=_0x4e4f07['node']();if(f(_0x45c1a8!==null&&typeof _0x45c1a8<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x45c1a8['isLeafNode']())return _0xe8042;const _0x4a6918=_0x45c1a8['getValue']();return typeof _0x4a6918!='number'?_0xe8042:_0x4a6918+_0xe8042;},Zo=function(_0x33e0f5,_0x2a1070,_0x26770f,_0x49d6ac){return us(_0x2a1070,new ls(_0x26770f,_0x33e0f5),_0x49d6ac);},hs=function(_0x10ea7f,_0x235565,_0x1c84bc){return us(_0x10ea7f,new cs(_0x235565),_0x1c84bc);};function us(_0x1a3c80,_0x595208,_0x3acbdd){const _0x567681=_0x1a3c80['getPriority']()['val'](),_0x238200=fr(_0x567681,_0x595208['getImmediateChild']('.priority'),_0x3acbdd);let _0xebda05;if(_0x1a3c80['isLeafNode']()){const _0x3251a9=_0x1a3c80,_0x370917=fr(_0x3251a9['getValue'](),_0x595208,_0x3acbdd);return _0x370917!==_0x3251a9['getValue']()||_0x238200!==_0x3251a9['getPriority']()['val']()?new D(_0x370917,N(_0x238200)):_0x1a3c80;}else{const _0x5b6709=_0x1a3c80;return _0xebda05=_0x5b6709,_0x238200!==_0x5b6709['getPriority']()['val']()&&(_0xebda05=_0xebda05['updatePriority'](new D(_0x238200))),_0x5b6709['forEachChild'](R,(_0x43d420,_0x36d3df)=>{const _0x3dc6f5=us(_0x36d3df,_0x595208['getImmediateChild'](_0x43d420),_0x3acbdd);_0x3dc6f5!==_0x36d3df&&(_0xebda05=_0xebda05['updateImmediateChild'](_0x43d420,_0x3dc6f5));}),_0xebda05;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0xced468='',_0x8becab=null,_0x5cbf2d={'children':{},'childCount':0x0}){this['name']=_0xced468,this['parent']=_0x8becab,this['node']=_0x5cbf2d;}}function Un(_0x315866,_0x2a304f){let _0x3fe041=_0x2a304f instanceof C?_0x2a304f:new C(_0x2a304f),_0x10c843=_0x315866,_0x3e8410=y(_0x3fe041);for(;_0x3e8410!==null;){const _0xa30ede=Oe(_0x10c843['node']['children'],_0x3e8410)||{'children':{},'childCount':0x0};_0x10c843=new ds(_0x3e8410,_0x10c843,_0xa30ede),_0x3fe041=b(_0x3fe041),_0x3e8410=y(_0x3fe041);}return _0x10c843;}function Ge(_0x3ee1a4){return _0x3ee1a4['node']['value'];}function fs(_0x542bcc,_0x1f3a44){_0x542bcc['node']['value']=_0x1f3a44,Ri(_0x542bcc);}function ea(_0xcfdffc){return _0xcfdffc['node']['childCount']>0x0;}function id(_0x4830fe){return Ge(_0x4830fe)===void 0x0&&!ea(_0x4830fe);}function Wn(_0x23d59d,_0x3b4ab7){x(_0x23d59d['node']['children'],(_0x5ebd00,_0xc692b0)=>{_0x3b4ab7(new ds(_0x5ebd00,_0x23d59d,_0xc692b0));});}function ta(_0x75935b,_0x51b467,_0x35e3f3,_0x2742d8){_0x35e3f3&&_0x51b467(_0x75935b),Wn(_0x75935b,_0x40ee02=>{ta(_0x40ee02,_0x51b467,!0x0);});}function sd(_0x20d6ba,_0x1ad705,_0x57de78){let _0x3d3190=_0x20d6ba['parent'];for(;_0x3d3190!==null;){if(_0x1ad705(_0x3d3190))return!0x0;_0x3d3190=_0x3d3190['parent'];}return!0x1;}function Gt(_0x3fcbf){return new C(_0x3fcbf['parent']===null?_0x3fcbf['name']:Gt(_0x3fcbf['parent'])+'/'+_0x3fcbf['name']);}function Ri(_0x4dbaf2){_0x4dbaf2['parent']!==null&&rd(_0x4dbaf2['parent'],_0x4dbaf2['name'],_0x4dbaf2);}function rd(_0x583489,_0x54b099,_0x3e18a9){const _0x2c2a9c=id(_0x3e18a9),_0x4798ad=Y(_0x583489['node']['children'],_0x54b099);_0x2c2a9c&&_0x4798ad?(delete _0x583489['node']['children'][_0x54b099],_0x583489['node']['childCount']--,Ri(_0x583489)):!_0x2c2a9c&&!_0x4798ad&&(_0x583489['node']['children'][_0x54b099]=_0x3e18a9['node'],_0x583489['node']['childCount']++,Ri(_0x583489));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x28604a){return typeof _0x28604a=='string'&&_0x28604a['length']!==0x0&&!od['test'](_0x28604a);},na=function(_0x514bb2){return typeof _0x514bb2=='string'&&_0x514bb2['length']!==0x0&&!ad['test'](_0x514bb2);},cd=function(_0x2a5031){return _0x2a5031&&(_0x2a5031=_0x2a5031['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x2a5031);},Cn=function(_0x24d526){return _0x24d526===null||typeof _0x24d526=='string'||typeof _0x24d526=='number'&&!Wi(_0x24d526)||_0x24d526&&typeof _0x24d526=='object'&&Y(_0x24d526,'.sv');},qt=function(_0x59be95,_0x38f54c,_0x2a0d05,_0x3edffa){_0x3edffa&&_0x38f54c===void 0x0||zt(Nn(_0x59be95,'value'),_0x38f54c,_0x2a0d05);},zt=function(_0x34eee0,_0x37ada0,_0x29b711){const _0x1c9ed2=_0x29b711 instanceof C?new Sh(_0x29b711,_0x34eee0):_0x29b711;if(_0x37ada0===void 0x0)throw new Error(_0x34eee0+'contains\x20undefined\x20'+Ne(_0x1c9ed2));if(typeof _0x37ada0=='function')throw new Error(_0x34eee0+'contains\x20a\x20function\x20'+Ne(_0x1c9ed2)+'\x20with\x20contents\x20=\x20'+_0x37ada0['toString']());if(Wi(_0x37ada0))throw new Error(_0x34eee0+'contains\x20'+_0x37ada0['toString']()+'\x20'+Ne(_0x1c9ed2));if(typeof _0x37ada0=='string'&&_0x37ada0['length']>oi/0x3&&Pn(_0x37ada0)>oi)throw new Error(_0x34eee0+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x1c9ed2)+'\x20(\x27'+_0x37ada0['substring'](0x0,0x32)+'...\x27)');if(_0x37ada0&&typeof _0x37ada0=='object'){let _0x8a590c=!0x1,_0x1e6461=!0x1;if(x(_0x37ada0,(_0x95f87f,_0x27adf1)=>{if(_0x95f87f==='.value')_0x8a590c=!0x0;else{if(_0x95f87f!=='.priority'&&_0x95f87f!=='.sv'&&(_0x1e6461=!0x0,!ps(_0x95f87f)))throw new Error(_0x34eee0+'\x20contains\x20an\x20invalid\x20key\x20('+_0x95f87f+')\x20'+Ne(_0x1c9ed2)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x1c9ed2,_0x95f87f),zt(_0x34eee0,_0x27adf1,_0x1c9ed2),Rh(_0x1c9ed2);}),_0x8a590c&&_0x1e6461)throw new Error(_0x34eee0+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x1c9ed2)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x19cdb0,_0x5eb64d){let _0x16bdd6,_0x4b5f9d;for(_0x16bdd6=0x0;_0x16bdd6<_0x5eb64d['length'];_0x16bdd6++){_0x4b5f9d=_0x5eb64d[_0x16bdd6];const _0x460c7=kt(_0x4b5f9d);for(let _0x5e2c93=0x0;_0x5e2c93<_0x460c7['length'];_0x5e2c93++)if(!(_0x460c7[_0x5e2c93]==='.priority'&&_0x5e2c93===_0x460c7['length']-0x1)){if(!ps(_0x460c7[_0x5e2c93]))throw new Error(_0x19cdb0+'contains\x20an\x20invalid\x20key\x20('+_0x460c7[_0x5e2c93]+')\x20in\x20path\x20'+_0x4b5f9d['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5eb64d['sort'](Th);let _0x15c47c=null;for(_0x16bdd6=0x0;_0x16bdd6<_0x5eb64d['length'];_0x16bdd6++){if(_0x4b5f9d=_0x5eb64d[_0x16bdd6],_0x15c47c!==null&&$(_0x15c47c,_0x4b5f9d))throw new Error(_0x19cdb0+'contains\x20a\x20path\x20'+_0x15c47c['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4b5f9d['toString']());_0x15c47c=_0x4b5f9d;}},hd=function(_0x4e02a7,_0x56a929,_0x3968ef,_0x1bc400){const _0x441fa6=Nn(_0x4e02a7,'values');if(!(_0x56a929&&typeof _0x56a929=='object')||Array['isArray'](_0x56a929))throw new Error(_0x441fa6+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5e1d38=[];x(_0x56a929,(_0x135d23,_0x257b75)=>{const _0x2447bb=new C(_0x135d23);if(zt(_0x441fa6,_0x257b75,A(_0x3968ef,_0x2447bb)),Gi(_0x2447bb)==='.priority'&&!Cn(_0x257b75))throw new Error(_0x441fa6+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2447bb['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5e1d38['push'](_0x2447bb);}),ld(_0x441fa6,_0x5e1d38);},_s=function(_0x449eac,_0x53fdda,_0x1795df,_0x536e57){if(!na(_0x1795df))throw new Error(Nn(_0x449eac,_0x53fdda)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1795df+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x5af528,_0x480209,_0x306021,_0x38b1e5){_0x306021&&(_0x306021=_0x306021['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x5af528,_0x480209,_0x306021);},gs=function(_0x56f63c,_0x53d80b){if(y(_0x53d80b)==='.info')throw new Error(_0x56f63c+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x4e3413,_0x4937cb){const _0x591314=_0x4937cb['path']['toString']();if(typeof _0x4937cb['repoInfo']['host']!='string'||_0x4937cb['repoInfo']['host']['length']===0x0||!ps(_0x4937cb['repoInfo']['namespace'])&&_0x4937cb['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x591314['length']!==0x0&&!cd(_0x591314))throw new Error(Nn(_0x4e3413,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x396107,_0x1351a1){let _0x4309ba=null;for(let _0x4c689e=0x0;_0x4c689e<_0x1351a1['length'];_0x4c689e++){const _0x5a70df=_0x1351a1[_0x4c689e],_0x502919=_0x5a70df['getPath']();_0x4309ba!==null&&!qi(_0x502919,_0x4309ba['path'])&&(_0x396107['eventLists_']['push'](_0x4309ba),_0x4309ba=null),_0x4309ba===null&&(_0x4309ba={'events':[],'path':_0x502919}),_0x4309ba['events']['push'](_0x5a70df);}_0x4309ba&&_0x396107['eventLists_']['push'](_0x4309ba);}function ia(_0x58bf17,_0x27f24a,_0x569aea){Bn(_0x58bf17,_0x569aea),sa(_0x58bf17,_0x39e82f=>qi(_0x39e82f,_0x27f24a));}function V(_0x25dcce,_0x11afc6,_0x440acb){Bn(_0x25dcce,_0x440acb),sa(_0x25dcce,_0x45d469=>$(_0x45d469,_0x11afc6)||$(_0x11afc6,_0x45d469));}function sa(_0x3fe5be,_0x15387b){_0x3fe5be['recursionDepth_']++;let _0x4edecc=!0x0;for(let _0x46a810=0x0;_0x46a810<_0x3fe5be['eventLists_']['length'];_0x46a810++){const _0x2d0239=_0x3fe5be['eventLists_'][_0x46a810];if(_0x2d0239){const _0x5e9df=_0x2d0239['path'];_0x15387b(_0x5e9df)?(pd(_0x3fe5be['eventLists_'][_0x46a810]),_0x3fe5be['eventLists_'][_0x46a810]=null):_0x4edecc=!0x1;}}_0x4edecc&&(_0x3fe5be['eventLists_']=[]),_0x3fe5be['recursionDepth_']--;}function pd(_0x267881){for(let _0x33e3c8=0x0;_0x33e3c8<_0x267881['events']['length'];_0x33e3c8++){const _0xfc58d=_0x267881['events'][_0x33e3c8];if(_0xfc58d!==null){_0x267881['events'][_0x33e3c8]=null;const _0x188587=_0xfc58d['getEventRunner']();Et&&L('event:\x20'+_0xfc58d['toString']()),lt(_0x188587);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x1bbcdb,_0x30646a,_0x5eaf3b,_0x3b7c0a){this['repoInfo_']=_0x1bbcdb,this['forceRestClient_']=_0x30646a,this['authTokenProvider_']=_0x5eaf3b,this['appCheckProvider_']=_0x3b7c0a,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x3b64dc,_0x107dab,_0xa46428){if(_0x3b64dc['stats_']=Hi(_0x3b64dc['repoInfo_']),_0x3b64dc['forceRestClient_']||Yl())_0x3b64dc['server_']=new fn(_0x3b64dc['repoInfo_'],(_0x508161,_0x2f01ef,_0x3a4edf,_0x4291ba)=>{pr(_0x3b64dc,_0x508161,_0x2f01ef,_0x3a4edf,_0x4291ba);},_0x3b64dc['authTokenProvider_'],_0x3b64dc['appCheckProvider_']),setTimeout(()=>_r(_0x3b64dc,!0x0),0x0);else{if(typeof _0xa46428<'u'&&_0xa46428!==null){if(typeof _0xa46428!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xa46428);}catch(_0x52c0ab){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x52c0ab);}}_0x3b64dc['persistentConnection_']=new ie(_0x3b64dc['repoInfo_'],_0x107dab,(_0x527b28,_0x241625,_0x305c9b,_0x138647)=>{pr(_0x3b64dc,_0x527b28,_0x241625,_0x305c9b,_0x138647);},_0x41b0e2=>{_r(_0x3b64dc,_0x41b0e2);},_0x4a0407=>{yd(_0x3b64dc,_0x4a0407);},_0x3b64dc['authTokenProvider_'],_0x3b64dc['appCheckProvider_'],_0xa46428),_0x3b64dc['server_']=_0x3b64dc['persistentConnection_'];}_0x3b64dc['authTokenProvider_']['addTokenChangeListener'](_0x138b71=>{_0x3b64dc['server_']['refreshAuthToken'](_0x138b71);}),_0x3b64dc['appCheckProvider_']['addTokenChangeListener'](_0x944bed=>{_0x3b64dc['server_']['refreshAppCheckToken'](_0x944bed['token']);}),_0x3b64dc['statsReporter_']=eh(_0x3b64dc['repoInfo_'],()=>new eu(_0x3b64dc['stats_'],_0x3b64dc['server_'])),_0x3b64dc['infoData_']=new Yh(),_0x3b64dc['infoSyncTree_']=new dr({'startListening':(_0x4cac68,_0x5413d4,_0x43d2da,_0x59d450)=>{let _0x33d4be=[];const _0x1a6a50=_0x3b64dc['infoData_']['getNode'](_0x4cac68['_path']);return _0x1a6a50['isEmpty']()||(_0x33d4be=$t(_0x3b64dc['infoSyncTree_'],_0x4cac68['_path'],_0x1a6a50),setTimeout(()=>{_0x59d450('ok');},0x0)),_0x33d4be;},'stopListening':()=>{}}),ms(_0x3b64dc,'connected',!0x1),_0x3b64dc['serverSyncTree_']=new dr({'startListening':(_0x578547,_0x11ede0,_0x53ad29,_0x31086b)=>(_0x3b64dc['server_']['listen'](_0x578547,_0x53ad29,_0x11ede0,(_0x321163,_0x234af6)=>{const _0x589196=_0x31086b(_0x321163,_0x234af6);V(_0x3b64dc['eventQueue_'],_0x578547['_path'],_0x589196);}),[]),'stopListening':(_0x2b0817,_0x567c19)=>{_0x3b64dc['server_']['unlisten'](_0x2b0817,_0x567c19);}});}function oa(_0x5ce23d){const _0x3b4764=_0x5ce23d['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x3b4764;}function jt(_0x55d974){return ed({'timestamp':oa(_0x55d974)});}function pr(_0x3cc5a1,_0x57e0ca,_0x5516c0,_0x29dd31,_0x4f757d){_0x3cc5a1['dataUpdateCount']++;const _0x3d46e9=new C(_0x57e0ca);_0x5516c0=_0x3cc5a1['interceptServerDataCallback_']?_0x3cc5a1['interceptServerDataCallback_'](_0x57e0ca,_0x5516c0):_0x5516c0;let _0x47f7e5=[];if(_0x4f757d){if(_0x29dd31){const _0x1a51e6=ln(_0x5516c0,_0x3a9feb=>N(_0x3a9feb));_0x47f7e5=Ku(_0x3cc5a1['serverSyncTree_'],_0x3d46e9,_0x1a51e6,_0x4f757d);}else{const _0x5c07f5=N(_0x5516c0);_0x47f7e5=Yo(_0x3cc5a1['serverSyncTree_'],_0x3d46e9,_0x5c07f5,_0x4f757d);}}else{if(_0x29dd31){const _0x273240=ln(_0x5516c0,_0x1cc851=>N(_0x1cc851));_0x47f7e5=qu(_0x3cc5a1['serverSyncTree_'],_0x3d46e9,_0x273240);}else{const _0xa4a72b=N(_0x5516c0);_0x47f7e5=$t(_0x3cc5a1['serverSyncTree_'],_0x3d46e9,_0xa4a72b);}}let _0x3514b9=_0x3d46e9;_0x47f7e5['length']>0x0&&(_0x3514b9=st(_0x3cc5a1,_0x3d46e9)),V(_0x3cc5a1['eventQueue_'],_0x3514b9,_0x47f7e5);}function _r(_0x4a64cd,_0x23c1ce){ms(_0x4a64cd,'connected',_0x23c1ce),_0x23c1ce===!0x1&&wd(_0x4a64cd);}function yd(_0x28c3ca,_0x42c583){x(_0x42c583,(_0x4ca5a8,_0x4a1196)=>{ms(_0x28c3ca,_0x4ca5a8,_0x4a1196);});}function ms(_0x3619da,_0x2e9c27,_0x258556){const _0x369946=new C('/.info/'+_0x2e9c27),_0x4cba9d=N(_0x258556);_0x3619da['infoData_']['updateSnapshot'](_0x369946,_0x4cba9d);const _0x1e23bb=$t(_0x3619da['infoSyncTree_'],_0x369946,_0x4cba9d);V(_0x3619da['eventQueue_'],_0x369946,_0x1e23bb);}function Vn(_0x51ab20){return _0x51ab20['nextWriteId_']++;}function vd(_0x5dac7d,_0x2e7232,_0x40bf8e){const _0x2b86f6=Yu(_0x5dac7d['serverSyncTree_'],_0x2e7232);return _0x2b86f6!=null?Promise['resolve'](_0x2b86f6):_0x5dac7d['server_']['get'](_0x2e7232)['then'](_0x1911a1=>{const _0x322590=N(_0x1911a1)['withIndex'](_0x2e7232['_queryParams']['getIndex']());bi(_0x5dac7d['serverSyncTree_'],_0x2e7232,_0x40bf8e,!0x0);let _0x1ee368;if(_0x2e7232['_queryParams']['loadsAllData']())_0x1ee368=$t(_0x5dac7d['serverSyncTree_'],_0x2e7232['_path'],_0x322590);else{const _0x56c8c0=Mt(_0x5dac7d['serverSyncTree_'],_0x2e7232);_0x1ee368=Yo(_0x5dac7d['serverSyncTree_'],_0x2e7232['_path'],_0x322590,_0x56c8c0);}return V(_0x5dac7d['eventQueue_'],_0x2e7232['_path'],_0x1ee368),wn(_0x5dac7d['serverSyncTree_'],_0x2e7232,_0x40bf8e,null,!0x0),_0x322590;},_0x1cbe19=>(ut(_0x5dac7d,'get\x20for\x20query\x20'+O(_0x2e7232)+'\x20failed:\x20'+_0x1cbe19),Promise['reject'](new Error(_0x1cbe19))));}function Ed(_0x53e973,_0x6308ef,_0x28a3d9,_0x14f721,_0x2042c3){ut(_0x53e973,'set',{'path':_0x6308ef['toString'](),'value':_0x28a3d9,'priority':_0x14f721});const _0x50e939=jt(_0x53e973),_0x4a1630=N(_0x28a3d9,_0x14f721),_0x4ad40b=xn(_0x53e973['serverSyncTree_'],_0x6308ef),_0x34248d=hs(_0x4a1630,_0x4ad40b,_0x50e939),_0x1df282=Vn(_0x53e973),_0x1abb85=ss(_0x53e973['serverSyncTree_'],_0x6308ef,_0x34248d,_0x1df282,!0x0);Bn(_0x53e973['eventQueue_'],_0x1abb85),_0x53e973['server_']['put'](_0x6308ef['toString'](),_0x4a1630['val'](!0x0),(_0x211437,_0x554b4d)=>{const _0x52c35e=_0x211437==='ok';_0x52c35e||U('set\x20at\x20'+_0x6308ef+'\x20failed:\x20'+_0x211437);const _0x276852=pe(_0x53e973['serverSyncTree_'],_0x1df282,!_0x52c35e);V(_0x53e973['eventQueue_'],_0x6308ef,_0x276852),Ai(_0x53e973,_0x2042c3,_0x211437,_0x554b4d);});const _0x2ae9b3=vs(_0x53e973,_0x6308ef);st(_0x53e973,_0x2ae9b3),V(_0x53e973['eventQueue_'],_0x2ae9b3,[]);}function Id(_0x5ad497,_0x4f147a,_0x194ab1,_0x3f5237){ut(_0x5ad497,'update',{'path':_0x4f147a['toString'](),'value':_0x194ab1});let _0x1a99c7=!0x0;const _0x358602=jt(_0x5ad497),_0x36cc18={};if(x(_0x194ab1,(_0x38f9b3,_0x1b8c4d)=>{_0x1a99c7=!0x1,_0x36cc18[_0x38f9b3]=Zo(A(_0x4f147a,_0x38f9b3),N(_0x1b8c4d),_0x5ad497['serverSyncTree_'],_0x358602);}),_0x1a99c7)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x5ad497,_0x3f5237,'ok',void 0x0);else{const _0x3c83f9=Vn(_0x5ad497),_0x4e7298=Gu(_0x5ad497['serverSyncTree_'],_0x4f147a,_0x36cc18,_0x3c83f9);Bn(_0x5ad497['eventQueue_'],_0x4e7298),_0x5ad497['server_']['merge'](_0x4f147a['toString'](),_0x194ab1,(_0x26a137,_0x5d6bf5)=>{const _0x314367=_0x26a137==='ok';_0x314367||U('update\x20at\x20'+_0x4f147a+'\x20failed:\x20'+_0x26a137);const _0x32f482=pe(_0x5ad497['serverSyncTree_'],_0x3c83f9,!_0x314367),_0x161cfd=_0x32f482['length']>0x0?st(_0x5ad497,_0x4f147a):_0x4f147a;V(_0x5ad497['eventQueue_'],_0x161cfd,_0x32f482),Ai(_0x5ad497,_0x3f5237,_0x26a137,_0x5d6bf5);}),x(_0x194ab1,_0x5d03b0=>{const _0x4a5a6c=vs(_0x5ad497,A(_0x4f147a,_0x5d03b0));st(_0x5ad497,_0x4a5a6c);}),V(_0x5ad497['eventQueue_'],_0x4f147a,[]);}}function wd(_0x5a8b36){ut(_0x5a8b36,'onDisconnectEvents');const _0x363b2c=jt(_0x5a8b36),_0xbd1148=pn();Ei(_0x5a8b36['onDisconnect_'],w(),(_0x2e5f6c,_0x2ddbe6)=>{const _0x2e4ca7=Zo(_0x2e5f6c,_0x2ddbe6,_0x5a8b36['serverSyncTree_'],_0x363b2c);Mo(_0xbd1148,_0x2e5f6c,_0x2e4ca7);});let _0x4d9dac=[];Ei(_0xbd1148,w(),(_0x3a3a20,_0x23af5f)=>{_0x4d9dac=_0x4d9dac['concat']($t(_0x5a8b36['serverSyncTree_'],_0x3a3a20,_0x23af5f));const _0x288102=vs(_0x5a8b36,_0x3a3a20);st(_0x5a8b36,_0x288102);}),_0x5a8b36['onDisconnect_']=pn(),V(_0x5a8b36['eventQueue_'],w(),_0x4d9dac);}function Cd(_0x3e2899,_0x5a4193,_0x1e1f80){let _0x445e67;y(_0x5a4193['_path'])==='.info'?_0x445e67=bi(_0x3e2899['infoSyncTree_'],_0x5a4193,_0x1e1f80):_0x445e67=bi(_0x3e2899['serverSyncTree_'],_0x5a4193,_0x1e1f80),ia(_0x3e2899['eventQueue_'],_0x5a4193['_path'],_0x445e67);}function Td(_0xf5b1fd,_0x1be5a0,_0x4d98a3){let _0x18686e;y(_0x1be5a0['_path'])==='.info'?_0x18686e=wn(_0xf5b1fd['infoSyncTree_'],_0x1be5a0,_0x4d98a3):_0x18686e=wn(_0xf5b1fd['serverSyncTree_'],_0x1be5a0,_0x4d98a3),ia(_0xf5b1fd['eventQueue_'],_0x1be5a0['_path'],_0x18686e);}function aa(_0x184660){_0x184660['persistentConnection_']&&_0x184660['persistentConnection_']['interrupt'](ra);}function Sd(_0x14301a){_0x14301a['persistentConnection_']&&_0x14301a['persistentConnection_']['resume'](ra);}function ut(_0x308ddd,..._0x2683ad){let _0x21324f='';_0x308ddd['persistentConnection_']&&(_0x21324f=_0x308ddd['persistentConnection_']['id']+':'),L(_0x21324f,..._0x2683ad);}function Ai(_0x5ee3c6,_0x43c29f,_0x1207f0,_0x40a194){_0x43c29f&&lt(()=>{if(_0x1207f0==='ok')_0x43c29f(null);else{const _0x844e62=(_0x1207f0||'error')['toUpperCase']();let _0x319f54=_0x844e62;_0x40a194&&(_0x319f54+=':\x20'+_0x40a194);const _0x9854a3=new Error(_0x319f54);_0x9854a3['code']=_0x844e62,_0x43c29f(_0x9854a3);}});}function bd(_0x1aaa81,_0x4cfa41,_0x4b360b,_0x4ad35b,_0x832870,_0x56090a){ut(_0x1aaa81,'transaction\x20on\x20'+_0x4cfa41);const _0x508be2={'path':_0x4cfa41,'update':_0x4b360b,'onComplete':_0x4ad35b,'status':null,'order':to(),'applyLocally':_0x56090a,'retryCount':0x0,'unwatcher':_0x832870,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x34babd=ys(_0x1aaa81,_0x4cfa41,void 0x0);_0x508be2['currentInputSnapshot']=_0x34babd;const _0x24738e=_0x508be2['update'](_0x34babd['val']());if(_0x24738e===void 0x0)_0x508be2['unwatcher'](),_0x508be2['currentOutputSnapshotRaw']=null,_0x508be2['currentOutputSnapshotResolved']=null,_0x508be2['onComplete']&&_0x508be2['onComplete'](null,!0x1,_0x508be2['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x24738e,_0x508be2['path']),_0x508be2['status']=0x0;const _0x2edc4b=Un(_0x1aaa81['transactionQueueTree_'],_0x4cfa41),_0x7a2f47=Ge(_0x2edc4b)||[];_0x7a2f47['push'](_0x508be2),fs(_0x2edc4b,_0x7a2f47);let _0x459be1;typeof _0x24738e=='object'&&_0x24738e!==null&&Y(_0x24738e,'.priority')?(_0x459be1=Oe(_0x24738e,'.priority'),f(Cn(_0x459be1),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x459be1=(xn(_0x1aaa81['serverSyncTree_'],_0x4cfa41)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x2b453c=jt(_0x1aaa81),_0x1a2e2c=N(_0x24738e,_0x459be1),_0x2be701=hs(_0x1a2e2c,_0x34babd,_0x2b453c);_0x508be2['currentOutputSnapshotRaw']=_0x1a2e2c,_0x508be2['currentOutputSnapshotResolved']=_0x2be701,_0x508be2['currentWriteId']=Vn(_0x1aaa81);const _0x46c1df=ss(_0x1aaa81['serverSyncTree_'],_0x4cfa41,_0x2be701,_0x508be2['currentWriteId'],_0x508be2['applyLocally']);V(_0x1aaa81['eventQueue_'],_0x4cfa41,_0x46c1df),Hn(_0x1aaa81,_0x1aaa81['transactionQueueTree_']);}}function ys(_0xfab877,_0x42c3d1,_0x517aaa){return xn(_0xfab877['serverSyncTree_'],_0x42c3d1,_0x517aaa)||g['EMPTY_NODE'];}function Hn(_0x219454,_0x236929=_0x219454['transactionQueueTree_']){if(_0x236929||$n(_0x219454,_0x236929),Ge(_0x236929)){const _0x19656a=la(_0x219454,_0x236929);f(_0x19656a['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x19656a['every'](_0x5cc2cd=>_0x5cc2cd['status']===0x0)&&Rd(_0x219454,Gt(_0x236929),_0x19656a);}else ea(_0x236929)&&Wn(_0x236929,_0x49cac6=>{Hn(_0x219454,_0x49cac6);});}function Rd(_0x405265,_0x132128,_0x164999){const _0x2e2d51=_0x164999['map'](_0x91fc2f=>_0x91fc2f['currentWriteId']),_0x242ea2=ys(_0x405265,_0x132128,_0x2e2d51);let _0x3a5e81=_0x242ea2;const _0x881f4e=_0x242ea2['hash']();for(let _0x5645a3=0x0;_0x5645a3<_0x164999['length'];_0x5645a3++){const _0x4edd1b=_0x164999[_0x5645a3];f(_0x4edd1b['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4edd1b['status']=0x1,_0x4edd1b['retryCount']++;const _0xe5bd3e=F(_0x132128,_0x4edd1b['path']);_0x3a5e81=_0x3a5e81['updateChild'](_0xe5bd3e,_0x4edd1b['currentOutputSnapshotRaw']);}const _0x5bc467=_0x3a5e81['val'](!0x0),_0x1d8765=_0x132128;_0x405265['server_']['put'](_0x1d8765['toString'](),_0x5bc467,_0x1774b6=>{ut(_0x405265,'transaction\x20put\x20response',{'path':_0x1d8765['toString'](),'status':_0x1774b6});let _0x55a92a=[];if(_0x1774b6==='ok'){const _0xc4385f=[];for(let _0x2fdee0=0x0;_0x2fdee0<_0x164999['length'];_0x2fdee0++)_0x164999[_0x2fdee0]['status']=0x2,_0x55a92a=_0x55a92a['concat'](pe(_0x405265['serverSyncTree_'],_0x164999[_0x2fdee0]['currentWriteId'])),_0x164999[_0x2fdee0]['onComplete']&&_0xc4385f['push'](()=>_0x164999[_0x2fdee0]['onComplete'](null,!0x0,_0x164999[_0x2fdee0]['currentOutputSnapshotResolved'])),_0x164999[_0x2fdee0]['unwatcher']();$n(_0x405265,Un(_0x405265['transactionQueueTree_'],_0x132128)),Hn(_0x405265,_0x405265['transactionQueueTree_']),V(_0x405265['eventQueue_'],_0x132128,_0x55a92a);for(let _0x33d494=0x0;_0x33d494<_0xc4385f['length'];_0x33d494++)lt(_0xc4385f[_0x33d494]);}else{if(_0x1774b6==='datastale'){for(let _0x3847cb=0x0;_0x3847cb<_0x164999['length'];_0x3847cb++)_0x164999[_0x3847cb]['status']===0x3?_0x164999[_0x3847cb]['status']=0x4:_0x164999[_0x3847cb]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1d8765['toString']()+'\x20failed:\x20'+_0x1774b6);for(let _0x28fe01=0x0;_0x28fe01<_0x164999['length'];_0x28fe01++)_0x164999[_0x28fe01]['status']=0x4,_0x164999[_0x28fe01]['abortReason']=_0x1774b6;}st(_0x405265,_0x132128);}},_0x881f4e);}function st(_0x4e5ad7,_0x36a311){const _0x38b8aa=ca(_0x4e5ad7,_0x36a311),_0x2ce8f6=Gt(_0x38b8aa),_0x2dec62=la(_0x4e5ad7,_0x38b8aa);return Ad(_0x4e5ad7,_0x2dec62,_0x2ce8f6),_0x2ce8f6;}function Ad(_0xa72e60,_0x58ea9f,_0xf7e9cb){if(_0x58ea9f['length']===0x0)return;const _0x18896a=[];let _0xde8c5a=[];const _0x1f64d2=_0x58ea9f['filter'](_0x89d984=>_0x89d984['status']===0x0)['map'](_0x432881=>_0x432881['currentWriteId']);for(let _0x4e53bb=0x0;_0x4e53bb<_0x58ea9f['length'];_0x4e53bb++){const _0xadd918=_0x58ea9f[_0x4e53bb],_0x334644=F(_0xf7e9cb,_0xadd918['path']);let _0x43ae92=!0x1,_0x750db5;if(f(_0x334644!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xadd918['status']===0x4)_0x43ae92=!0x0,_0x750db5=_0xadd918['abortReason'],_0xde8c5a=_0xde8c5a['concat'](pe(_0xa72e60['serverSyncTree_'],_0xadd918['currentWriteId'],!0x0));else{if(_0xadd918['status']===0x0){if(_0xadd918['retryCount']>=_d)_0x43ae92=!0x0,_0x750db5='maxretry',_0xde8c5a=_0xde8c5a['concat'](pe(_0xa72e60['serverSyncTree_'],_0xadd918['currentWriteId'],!0x0));else{const _0x4487e2=ys(_0xa72e60,_0xadd918['path'],_0x1f64d2);_0xadd918['currentInputSnapshot']=_0x4487e2;const _0x3c59be=_0x58ea9f[_0x4e53bb]['update'](_0x4487e2['val']());if(_0x3c59be!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x3c59be,_0xadd918['path']);let _0x31175e=N(_0x3c59be);typeof _0x3c59be=='object'&&_0x3c59be!=null&&Y(_0x3c59be,'.priority')||(_0x31175e=_0x31175e['updatePriority'](_0x4487e2['getPriority']()));const _0xbb8f5d=_0xadd918['currentWriteId'],_0x908250=jt(_0xa72e60),_0xc585e=hs(_0x31175e,_0x4487e2,_0x908250);_0xadd918['currentOutputSnapshotRaw']=_0x31175e,_0xadd918['currentOutputSnapshotResolved']=_0xc585e,_0xadd918['currentWriteId']=Vn(_0xa72e60),_0x1f64d2['splice'](_0x1f64d2['indexOf'](_0xbb8f5d),0x1),_0xde8c5a=_0xde8c5a['concat'](ss(_0xa72e60['serverSyncTree_'],_0xadd918['path'],_0xc585e,_0xadd918['currentWriteId'],_0xadd918['applyLocally'])),_0xde8c5a=_0xde8c5a['concat'](pe(_0xa72e60['serverSyncTree_'],_0xbb8f5d,!0x0));}else _0x43ae92=!0x0,_0x750db5='nodata',_0xde8c5a=_0xde8c5a['concat'](pe(_0xa72e60['serverSyncTree_'],_0xadd918['currentWriteId'],!0x0));}}}V(_0xa72e60['eventQueue_'],_0xf7e9cb,_0xde8c5a),_0xde8c5a=[],_0x43ae92&&(_0x58ea9f[_0x4e53bb]['status']=0x2,function(_0x530ad6){setTimeout(_0x530ad6,Math['floor'](0x0));}(_0x58ea9f[_0x4e53bb]['unwatcher']),_0x58ea9f[_0x4e53bb]['onComplete']&&(_0x750db5==='nodata'?_0x18896a['push'](()=>_0x58ea9f[_0x4e53bb]['onComplete'](null,!0x1,_0x58ea9f[_0x4e53bb]['currentInputSnapshot'])):_0x18896a['push'](()=>_0x58ea9f[_0x4e53bb]['onComplete'](new Error(_0x750db5),!0x1,null))));}$n(_0xa72e60,_0xa72e60['transactionQueueTree_']);for(let _0x12d1bd=0x0;_0x12d1bd<_0x18896a['length'];_0x12d1bd++)lt(_0x18896a[_0x12d1bd]);Hn(_0xa72e60,_0xa72e60['transactionQueueTree_']);}function ca(_0x40aabd,_0x36e5ea){let _0x39969,_0x450ef7=_0x40aabd['transactionQueueTree_'];for(_0x39969=y(_0x36e5ea);_0x39969!==null&&Ge(_0x450ef7)===void 0x0;)_0x450ef7=Un(_0x450ef7,_0x39969),_0x36e5ea=b(_0x36e5ea),_0x39969=y(_0x36e5ea);return _0x450ef7;}function la(_0x44c538,_0x1f10a7){const _0x260e95=[];return ha(_0x44c538,_0x1f10a7,_0x260e95),_0x260e95['sort']((_0x193d3d,_0x7cd714)=>_0x193d3d['order']-_0x7cd714['order']),_0x260e95;}function ha(_0x4ba1ad,_0x596d2f,_0x16199f){const _0x1aa7ef=Ge(_0x596d2f);if(_0x1aa7ef){for(let _0x25deaa=0x0;_0x25deaa<_0x1aa7ef['length'];_0x25deaa++)_0x16199f['push'](_0x1aa7ef[_0x25deaa]);}Wn(_0x596d2f,_0x29f95f=>{ha(_0x4ba1ad,_0x29f95f,_0x16199f);});}function $n(_0x52872e,_0x76648){const _0x3205ad=Ge(_0x76648);if(_0x3205ad){let _0x37a49e=0x0;for(let _0xc613a5=0x0;_0xc613a5<_0x3205ad['length'];_0xc613a5++)_0x3205ad[_0xc613a5]['status']!==0x2&&(_0x3205ad[_0x37a49e]=_0x3205ad[_0xc613a5],_0x37a49e++);_0x3205ad['length']=_0x37a49e,fs(_0x76648,_0x3205ad['length']>0x0?_0x3205ad:void 0x0);}Wn(_0x76648,_0x2441ab=>{$n(_0x52872e,_0x2441ab);});}function vs(_0x3ee715,_0x3828ea){const _0x36a83d=Gt(ca(_0x3ee715,_0x3828ea)),_0x2d7e5f=Un(_0x3ee715['transactionQueueTree_'],_0x3828ea);return sd(_0x2d7e5f,_0x2ff761=>{ai(_0x3ee715,_0x2ff761);}),ai(_0x3ee715,_0x2d7e5f),ta(_0x2d7e5f,_0x28f79e=>{ai(_0x3ee715,_0x28f79e);}),_0x36a83d;}function ai(_0x5cdbe9,_0x4018e1){const _0x465c9f=Ge(_0x4018e1);if(_0x465c9f){const _0x484bcb=[];let _0x1bdb94=[],_0x46edd2=-0x1;for(let _0x110aee=0x0;_0x110aee<_0x465c9f['length'];_0x110aee++)_0x465c9f[_0x110aee]['status']===0x3||(_0x465c9f[_0x110aee]['status']===0x1?(f(_0x46edd2===_0x110aee-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x46edd2=_0x110aee,_0x465c9f[_0x110aee]['status']=0x3,_0x465c9f[_0x110aee]['abortReason']='set'):(f(_0x465c9f[_0x110aee]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x465c9f[_0x110aee]['unwatcher'](),_0x1bdb94=_0x1bdb94['concat'](pe(_0x5cdbe9['serverSyncTree_'],_0x465c9f[_0x110aee]['currentWriteId'],!0x0)),_0x465c9f[_0x110aee]['onComplete']&&_0x484bcb['push'](_0x465c9f[_0x110aee]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x46edd2===-0x1?fs(_0x4018e1,void 0x0):_0x465c9f['length']=_0x46edd2+0x1,V(_0x5cdbe9['eventQueue_'],Gt(_0x4018e1),_0x1bdb94);for(let _0x2814b7=0x0;_0x2814b7<_0x484bcb['length'];_0x2814b7++)lt(_0x484bcb[_0x2814b7]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x558afe){let _0x3fd4c7='';const _0x513222=_0x558afe['split']('/');for(let _0x47a46e=0x0;_0x47a46e<_0x513222['length'];_0x47a46e++)if(_0x513222[_0x47a46e]['length']>0x0){let _0x3db7eb=_0x513222[_0x47a46e];try{_0x3db7eb=decodeURIComponent(_0x3db7eb['replace'](/\+/g,'\x20'));}catch{}_0x3fd4c7+='/'+_0x3db7eb;}return _0x3fd4c7;}function Nd(_0x10b088){const _0x1a1550={};_0x10b088['charAt'](0x0)==='?'&&(_0x10b088=_0x10b088['substring'](0x1));for(const _0x4052ce of _0x10b088['split']('&')){if(_0x4052ce['length']===0x0)continue;const _0x163582=_0x4052ce['split']('=');_0x163582['length']===0x2?_0x1a1550[decodeURIComponent(_0x163582[0x0])]=decodeURIComponent(_0x163582[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4052ce+'\x27\x20in\x20query\x20\x27'+_0x10b088+'\x27');}return _0x1a1550;}const gr=function(_0x3f295c,_0xf75908){const _0x200172=Pd(_0x3f295c),_0x5c9d74=_0x200172['namespace'];_0x200172['domain']==='firebase.com'&&oe(_0x200172['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5c9d74||_0x5c9d74==='undefined')&&_0x200172['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x200172['secure']||Bl();const _0x23f792=_0x200172['scheme']==='ws'||_0x200172['scheme']==='wss';return{'repoInfo':new _o(_0x200172['host'],_0x200172['secure'],_0x5c9d74,_0x23f792,_0xf75908,'',_0x5c9d74!==_0x200172['subdomain']),'path':new C(_0x200172['pathString'])};},Pd=function(_0x5a3eac){let _0x206bfb='',_0xb67f1a='',_0x1fc4b8='',_0x1f1682='',_0x10d625='',_0x8390cc=!0x0,_0x54b523='https',_0x2c0bf8=0x1bb;if(typeof _0x5a3eac=='string'){let _0x179fe9=_0x5a3eac['indexOf']('//');_0x179fe9>=0x0&&(_0x54b523=_0x5a3eac['substring'](0x0,_0x179fe9-0x1),_0x5a3eac=_0x5a3eac['substring'](_0x179fe9+0x2));let _0x4279b3=_0x5a3eac['indexOf']('/');_0x4279b3===-0x1&&(_0x4279b3=_0x5a3eac['length']);let _0x50563a=_0x5a3eac['indexOf']('?');_0x50563a===-0x1&&(_0x50563a=_0x5a3eac['length']),_0x206bfb=_0x5a3eac['substring'](0x0,Math['min'](_0x4279b3,_0x50563a)),_0x4279b3<_0x50563a&&(_0x1f1682=kd(_0x5a3eac['substring'](_0x4279b3,_0x50563a)));const _0x372987=Nd(_0x5a3eac['substring'](Math['min'](_0x5a3eac['length'],_0x50563a)));_0x179fe9=_0x206bfb['indexOf'](':'),_0x179fe9>=0x0?(_0x8390cc=_0x54b523==='https'||_0x54b523==='wss',_0x2c0bf8=parseInt(_0x206bfb['substring'](_0x179fe9+0x1),0xa)):_0x179fe9=_0x206bfb['length'];const _0x4487c1=_0x206bfb['slice'](0x0,_0x179fe9);if(_0x4487c1['toLowerCase']()==='localhost')_0xb67f1a='localhost';else{if(_0x4487c1['split']('.')['length']<=0x2)_0xb67f1a=_0x4487c1;else{const _0x13fe14=_0x206bfb['indexOf']('.');_0x1fc4b8=_0x206bfb['substring'](0x0,_0x13fe14)['toLowerCase'](),_0xb67f1a=_0x206bfb['substring'](_0x13fe14+0x1),_0x10d625=_0x1fc4b8;}}'ns'in _0x372987&&(_0x10d625=_0x372987['ns']);}return{'host':_0x206bfb,'port':_0x2c0bf8,'domain':_0xb67f1a,'subdomain':_0x1fc4b8,'secure':_0x8390cc,'scheme':_0x54b523,'pathString':_0x1f1682,'namespace':_0x10d625};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x4b6816=0x0;const _0x4ee186=[];return function(_0x3c2b39){const _0x17c7d6=_0x3c2b39===_0x4b6816;_0x4b6816=_0x3c2b39;let _0x39ed88;const _0x13f123=new Array(0x8);for(_0x39ed88=0x7;_0x39ed88>=0x0;_0x39ed88--)_0x13f123[_0x39ed88]=mr['charAt'](_0x3c2b39%0x40),_0x3c2b39=Math['floor'](_0x3c2b39/0x40);f(_0x3c2b39===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x34d54c=_0x13f123['join']('');if(_0x17c7d6){for(_0x39ed88=0xb;_0x39ed88>=0x0&&_0x4ee186[_0x39ed88]===0x3f;_0x39ed88--)_0x4ee186[_0x39ed88]=0x0;_0x4ee186[_0x39ed88]++;}else{for(_0x39ed88=0x0;_0x39ed88<0xc;_0x39ed88++)_0x4ee186[_0x39ed88]=Math['floor'](Math['random']()*0x40);}for(_0x39ed88=0x0;_0x39ed88<0xc;_0x39ed88++)_0x34d54c+=mr['charAt'](_0x4ee186[_0x39ed88]);return f(_0x34d54c['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x34d54c;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x1b7f91,_0x1694aa,_0x542184,_0x2ade5e){this['eventType']=_0x1b7f91,this['eventRegistration']=_0x1694aa,this['snapshot']=_0x542184,this['prevName']=_0x2ade5e;}['getPath'](){const _0x1d3ae7=this['snapshot']['ref'];return this['eventType']==='value'?_0x1d3ae7['_path']:_0x1d3ae7['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x361a1e,_0x1c1011,_0xc73af2){this['eventRegistration']=_0x361a1e,this['error']=_0x1c1011,this['path']=_0xc73af2;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x53a9ab,_0x5dbdbf){this['snapshotCallback']=_0x53a9ab,this['cancelCallback']=_0x5dbdbf;}['onValue'](_0x3390c8,_0x5a13b5){this['snapshotCallback']['call'](null,_0x3390c8,_0x5a13b5);}['onCancel'](_0xce03f7){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0xce03f7);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x511c32){return this['snapshotCallback']===_0x511c32['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x511c32['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x511c32['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x273e52,_0x2cc23e,_0x23e0ea,_0x65877c){this['_repo']=_0x273e52,this['_path']=_0x2cc23e,this['_queryParams']=_0x23e0ea,this['_orderByCalled']=_0x65877c;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4b3c1f=nr(this['_queryParams']),_0x4209c5=Bi(_0x4b3c1f);return _0x4209c5==='{}'?'default':_0x4209c5;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x4f84a2){if(_0x4f84a2=k(_0x4f84a2),!(_0x4f84a2 instanceof be))return!0x1;const _0x1474da=this['_repo']===_0x4f84a2['_repo'],_0x44d560=qi(this['_path'],_0x4f84a2['_path']),_0x48e201=this['_queryIdentifier']===_0x4f84a2['_queryIdentifier'];return _0x1474da&&_0x44d560&&_0x48e201;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x35b708,_0x4914ed){if(_0x35b708['_orderByCalled']===!0x0)throw new Error(_0x4914ed+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x375663){let _0x47d6d3=null,_0x5cb4d6=null;if(_0x375663['hasStart']()&&(_0x47d6d3=_0x375663['getIndexStartValue']()),_0x375663['hasEnd']()&&(_0x5cb4d6=_0x375663['getIndexEndValue']()),_0x375663['getIndex']()===ye){const _0x536332='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x5d6b12='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x375663['hasStart']()){if(_0x375663['getIndexStartName']()!==xe)throw new Error(_0x536332);if(typeof _0x47d6d3!='string')throw new Error(_0x5d6b12);}if(_0x375663['hasEnd']()){if(_0x375663['getIndexEndName']()!==Ie)throw new Error(_0x536332);if(typeof _0x5cb4d6!='string')throw new Error(_0x5d6b12);}}else{if(_0x375663['getIndex']()===R){if(_0x47d6d3!=null&&!Cn(_0x47d6d3)||_0x5cb4d6!=null&&!Cn(_0x5cb4d6))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x375663['getIndex']()instanceof Ki||_0x375663['getIndex']()===Po,'unknown\x20index\x20type.'),_0x47d6d3!=null&&typeof _0x47d6d3=='object'||_0x5cb4d6!=null&&typeof _0x5cb4d6=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x466dc2){if(_0x466dc2['hasStart']()&&_0x466dc2['hasEnd']()&&_0x466dc2['hasLimit']()&&!_0x466dc2['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x147350,_0x208e14){super(_0x147350,_0x208e14,new Qi(),!0x1);}get['parent'](){const _0x1b7593=To(this['_path']);return _0x1b7593===null?null:new Z(this['_repo'],_0x1b7593);}get['root'](){let _0x54c8cc=this;for(;_0x54c8cc['parent']!==null;)_0x54c8cc=_0x54c8cc['parent'];return _0x54c8cc;}}class rt{constructor(_0x117724,_0x5607bc,_0x66e965){this['_node']=_0x117724,this['ref']=_0x5607bc,this['_index']=_0x66e965;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0xaf10d1){const _0x43db12=new C(_0xaf10d1),_0xa731d7=Lt(this['ref'],_0xaf10d1);return new rt(this['_node']['getChild'](_0x43db12),_0xa731d7,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x514b8e){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x143cfd,_0x422fd1)=>_0x514b8e(new rt(_0x422fd1,Lt(this['ref'],_0x143cfd),R)));}['hasChild'](_0x473679){const _0x567fdc=new C(_0x473679);return!this['_node']['getChild'](_0x567fdc)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x59de80,_0x93486a){return _0x59de80=k(_0x59de80),_0x59de80['_checkNotDeleted']('ref'),_0x93486a!==void 0x0?Lt(_0x59de80['_root'],_0x93486a):_0x59de80['_root'];}function Lt(_0x58eb8f,_0x236d97){return _0x58eb8f=k(_0x58eb8f),y(_0x58eb8f['_path'])===null?ud('child','path',_0x236d97):_s('child','path',_0x236d97),new Z(_0x58eb8f['_repo'],A(_0x58eb8f['_path'],_0x236d97));}function d_(_0x2e4db0,_0x599f11){_0x2e4db0=k(_0x2e4db0),gs('push',_0x2e4db0['_path']),qt('push',_0x599f11,_0x2e4db0['_path'],!0x0);const _0x5e7104=oa(_0x2e4db0['_repo']),_0x4d889b=Od(_0x5e7104),_0x5d8bd1=Lt(_0x2e4db0,_0x4d889b),_0x11b220=Lt(_0x2e4db0,_0x4d889b);let _0x3c216b;return _0x599f11!=null?_0x3c216b=Ld(_0x11b220,_0x599f11)['then'](()=>_0x11b220):_0x3c216b=Promise['resolve'](_0x11b220),_0x5d8bd1['then']=_0x3c216b['then']['bind'](_0x3c216b),_0x5d8bd1['catch']=_0x3c216b['then']['bind'](_0x3c216b,void 0x0),_0x5d8bd1;}function Ld(_0x23d6e7,_0x24dd83){_0x23d6e7=k(_0x23d6e7),gs('set',_0x23d6e7['_path']),qt('set',_0x24dd83,_0x23d6e7['_path'],!0x1);const _0x1fb43b=new Ve();return Ed(_0x23d6e7['_repo'],_0x23d6e7['_path'],_0x24dd83,null,_0x1fb43b['wrapCallback'](()=>{})),_0x1fb43b['promise'];}function f_(_0x388a56,_0x380740){hd('update',_0x380740,_0x388a56['_path']);const _0x1d7453=new Ve();return Id(_0x388a56['_repo'],_0x388a56['_path'],_0x380740,_0x1d7453['wrapCallback'](()=>{})),_0x1d7453['promise'];}function p_(_0x1b9483){_0x1b9483=k(_0x1b9483);const _0x1c9c3b=new ua(()=>{}),_0x255cf0=new qn(_0x1c9c3b);return vd(_0x1b9483['_repo'],_0x1b9483,_0x255cf0)['then'](_0x244a90=>new rt(_0x244a90,new Z(_0x1b9483['_repo'],_0x1b9483['_path']),_0x1b9483['_queryParams']['getIndex']()));}class qn{constructor(_0x1616cb){this['callbackContext']=_0x1616cb;}['respondsTo'](_0x300338){return _0x300338==='value';}['createEvent'](_0xb1f54f,_0x27c7fb){const _0x198a80=_0x27c7fb['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0xb1f54f['snapshotNode'],new Z(_0x27c7fb['_repo'],_0x27c7fb['_path']),_0x198a80));}['getEventRunner'](_0xb14915){return _0xb14915['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0xb14915['error']):()=>this['callbackContext']['onValue'](_0xb14915['snapshot'],null);}['createCancelEvent'](_0x155785,_0x15b323){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x155785,_0x15b323):null;}['matches'](_0x529ce2){return _0x529ce2 instanceof qn?!_0x529ce2['callbackContext']||!this['callbackContext']?!0x0:_0x529ce2['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x2a740d,_0x1ff017,_0x3618f0,_0x2620ea,_0x5df307){const _0x4e2906=new ua(_0x3618f0,void 0x0),_0x5d7336=new qn(_0x4e2906);return Cd(_0x2a740d['_repo'],_0x2a740d,_0x5d7336),()=>Td(_0x2a740d['_repo'],_0x2a740d,_0x5d7336);}function Fd(_0x2ea704,_0x3f55e1,_0x46acdc,_0x4aad63){return xd(_0x2ea704,'value',_0x3f55e1);}class dt{}class pa extends dt{constructor(_0x18a597,_0x38d6a7){super(),this['_value']=_0x18a597,this['_key']=_0x38d6a7,this['type']='endAt';}['_apply'](_0x1336e3){qt('endAt',this['_value'],_0x1336e3['_path'],!0x0);const _0x3d68ba=Kh(_0x1336e3['_queryParams'],this['_value'],this['_key']);if(fa(_0x3d68ba),Gn(_0x3d68ba),_0x1336e3['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x1336e3['_repo'],_0x1336e3['_path'],_0x3d68ba,_0x1336e3['_orderByCalled']);}}function __(_0x1e1b31,_0x3d4505){return new pa(_0x1e1b31,_0x3d4505);}class _a extends dt{constructor(_0x53ce67,_0x5deb9c){super(),this['_value']=_0x53ce67,this['_key']=_0x5deb9c,this['type']='startAt';}['_apply'](_0x577c44){qt('startAt',this['_value'],_0x577c44['_path'],!0x0);const _0x7a0ea=jh(_0x577c44['_queryParams'],this['_value'],this['_key']);if(fa(_0x7a0ea),Gn(_0x7a0ea),_0x577c44['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x577c44['_repo'],_0x577c44['_path'],_0x7a0ea,_0x577c44['_orderByCalled']);}}function g_(_0x3d2732=null,_0x40f300){return new _a(_0x3d2732,_0x40f300);}class Ud extends dt{constructor(_0x405971){super(),this['_limit']=_0x405971,this['type']='limitToFirst';}['_apply'](_0x1f7b83){if(_0x1f7b83['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x1f7b83['_repo'],_0x1f7b83['_path'],zh(_0x1f7b83['_queryParams'],this['_limit']),_0x1f7b83['_orderByCalled']);}}function m_(_0x24870c){if(Math['floor'](_0x24870c)!==_0x24870c||_0x24870c<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x24870c);}class Wd extends dt{constructor(_0x2781fd){super(),this['_path']=_0x2781fd,this['type']='orderByChild';}['_apply'](_0x461f82){da(_0x461f82,'orderByChild');const _0x1d42c6=new C(this['_path']);if(v(_0x1d42c6))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x529046=new Ki(_0x1d42c6),_0x2cd33a=Do(_0x461f82['_queryParams'],_0x529046);return Gn(_0x2cd33a),new be(_0x461f82['_repo'],_0x461f82['_path'],_0x2cd33a,!0x0);}}function y_(_0x28d887){if(_0x28d887==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x28d887==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x28d887==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x28d887),new Wd(_0x28d887);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5841a0){da(_0x5841a0,'orderByKey');const _0x566371=Do(_0x5841a0['_queryParams'],ye);return Gn(_0x566371),new be(_0x5841a0['_repo'],_0x5841a0['_path'],_0x566371,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x4f2325,_0x26342e){super(),this['_value']=_0x4f2325,this['_key']=_0x26342e,this['type']='equalTo';}['_apply'](_0x26fa20){if(qt('equalTo',this['_value'],_0x26fa20['_path'],!0x1),_0x26fa20['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x26fa20['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x26fa20));}}function E_(_0x2068b3,_0x280dd6){return new Vd(_0x2068b3,_0x280dd6);}function I_(_0x474f13,..._0x4add62){let _0x105e4b=k(_0x474f13);for(const _0x1c42ad of _0x4add62)_0x105e4b=_0x1c42ad['_apply'](_0x105e4b);return _0x105e4b;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x2b251a,_0x96a70,_0x4894b7,_0x3ba46d){const _0xc3a621=_0x96a70['lastIndexOf'](':'),_0x1bb0a2=_0x96a70['substring'](0x0,_0xc3a621),_0x113abc=Wt(_0x1bb0a2);_0x2b251a['repoInfo_']=new _o(_0x96a70,_0x113abc,_0x2b251a['repoInfo_']['namespace'],_0x2b251a['repoInfo_']['webSocketOnly'],_0x2b251a['repoInfo_']['nodeAdmin'],_0x2b251a['repoInfo_']['persistenceKey'],_0x2b251a['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x4894b7),_0x3ba46d&&(_0x2b251a['authTokenProvider_']=_0x3ba46d);}function qd(_0x55ae13,_0x1dc9de,_0x4c19f6,_0x1d1d88,_0xb41748){let _0x361ec0=_0x1d1d88||_0x55ae13['options']['databaseURL'];_0x361ec0===void 0x0&&(_0x55ae13['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x55ae13['options']['projectId']),_0x361ec0=_0x55ae13['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x528b8e=gr(_0x361ec0,_0xb41748),_0x2a02c=_0x528b8e['repoInfo'],_0xa828b5;typeof process<'u'&&Us&&(_0xa828b5=Us[Hd]),_0xa828b5?(_0x361ec0='http://'+_0xa828b5+'?ns='+_0x2a02c['namespace'],_0x528b8e=gr(_0x361ec0,_0xb41748),_0x2a02c=_0x528b8e['repoInfo']):_0x528b8e['repoInfo']['secure'];const _0x54dd1c=new Jl(_0x55ae13['name'],_0x55ae13['options'],_0x1dc9de);dd('Invalid\x20Firebase\x20Database\x20URL',_0x528b8e),v(_0x528b8e['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x329c66=jd(_0x2a02c,_0x55ae13,_0x54dd1c,new Ql(_0x55ae13,_0x4c19f6));return new Kd(_0x329c66,_0x55ae13);}function zd(_0x944954,_0x3d16bb){const _0x57bc87=ki[_0x3d16bb];(!_0x57bc87||_0x57bc87[_0x944954['key']]!==_0x944954)&&oe('Database\x20'+_0x3d16bb+'('+_0x944954['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x944954),delete _0x57bc87[_0x944954['key']];}function jd(_0xc27a08,_0x34ae0b,_0x1007ad,_0x20a88d){let _0x656961=ki[_0x34ae0b['name']];_0x656961||(_0x656961={},ki[_0x34ae0b['name']]=_0x656961);let _0x1cbcc1=_0x656961[_0xc27a08['toURLString']()];return _0x1cbcc1&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1cbcc1=new gd(_0xc27a08,$d,_0x1007ad,_0x20a88d),_0x656961[_0xc27a08['toURLString']()]=_0x1cbcc1,_0x1cbcc1;}class Kd{constructor(_0x2fe0bd,_0x281ccd){this['_repoInternal']=_0x2fe0bd,this['app']=_0x281ccd,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x1e7115){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x1e7115+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x393c33=Qr(),_0x41ddfc){const _0x280d03=Ui(_0x393c33,'database')['getImmediate']({'identifier':_0x41ddfc});if(!_0x280d03['_instanceStarted']){const _0x3a4264=ac('database');_0x3a4264&&Yd(_0x280d03,..._0x3a4264);}return _0x280d03;}function Yd(_0x146675,_0x2debc4,_0x1d46a9,_0x53f392={}){_0x146675=k(_0x146675),_0x146675['_checkNotDeleted']('useEmulator');const _0x19fb1b=_0x2debc4+':'+_0x1d46a9,_0x26f6d8=_0x146675['_repoInternal'];if(_0x146675['_instanceStarted']){if(_0x19fb1b===_0x146675['_repoInternal']['repoInfo_']['host']&&De(_0x53f392,_0x26f6d8['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x27e75f;if(_0x26f6d8['repoInfo_']['nodeAdmin'])_0x53f392['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x27e75f=new tn(tn['OWNER']);else{if(_0x53f392['mockUserToken']){const _0x1b679b=typeof _0x53f392['mockUserToken']=='string'?_0x53f392['mockUserToken']:cc(_0x53f392['mockUserToken'],_0x146675['app']['options']['projectId']);_0x27e75f=new tn(_0x1b679b);}}Wt(_0x2debc4)&&jr(_0x2debc4),Gd(_0x26f6d8,_0x19fb1b,_0x53f392,_0x27e75f);}function C_(_0x2096d9){_0x2096d9=k(_0x2096d9),_0x2096d9['_checkNotDeleted']('goOffline'),aa(_0x2096d9['_repo']);}function T_(_0xa29697){_0xa29697=k(_0xa29697),_0xa29697['_checkNotDeleted']('goOnline'),Sd(_0xa29697['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x44d960){Ll(ct),et(new Me('database',(_0x5b865c,{instanceIdentifier:_0x3668e6})=>{const _0x238cf8=_0x5b865c['getProvider']('app')['getImmediate'](),_0x49826d=_0x5b865c['getProvider']('auth-internal'),_0x5ad5a=_0x5b865c['getProvider']('app-check-internal');return qd(_0x238cf8,_0x49826d,_0x5ad5a,_0x3668e6);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x44d960),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0xcaf297,_0x1365ab){this['committed']=_0xcaf297,this['snapshot']=_0x1365ab;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x3c4baa,_0x231e07,_0x517010){if(_0x3c4baa=k(_0x3c4baa),gs('Reference.transaction',_0x3c4baa['_path']),_0x3c4baa['key']==='.length'||_0x3c4baa['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3c4baa['key']+'\x20is\x20a\x20read-only\x20object.';const _0x33b628=!0x0,_0x49e2fc=new Ve(),_0xfd0b=(_0x15af1f,_0x54a96b,_0x251aa6)=>{let _0x5fba09=null;_0x15af1f?_0x49e2fc['reject'](_0x15af1f):(_0x5fba09=new rt(_0x251aa6,new Z(_0x3c4baa['_repo'],_0x3c4baa['_path']),R),_0x49e2fc['resolve'](new Xd(_0x54a96b,_0x5fba09)));},_0x540438=Fd(_0x3c4baa,()=>{});return bd(_0x3c4baa['_repo'],_0x3c4baa['_path'],_0x231e07,_0xfd0b,_0x540438,_0x33b628),_0x49e2fc['promise'];}ie['prototype']['simpleListen']=function(_0x135e86,_0x54bf41){this['sendRequest']('q',{'p':_0x135e86},_0x54bf41);},ie['prototype']['echo']=function(_0x3194ea,_0x41c590){this['sendRequest']('echo',{'d':_0x3194ea},_0x41c590);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x114181,..._0x4c584c){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x114181,..._0x4c584c);}function nn(_0x5a7b0f,..._0x586dc0){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x5a7b0f,..._0x586dc0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x5ec5f8,..._0x370222){throw Es(_0x5ec5f8,..._0x370222);}function J(_0x5bc20b,..._0x4f3575){return Es(_0x5bc20b,..._0x4f3575);}function ya(_0x3a9492,_0x54b167,_0x27fc2e){const _0x1b2dfa={...Zd(),[_0x54b167]:_0x27fc2e};return new Ut('auth','Firebase',_0x1b2dfa)['create'](_0x54b167,{'appName':_0x3a9492['name']});}function se(_0xc3ae1){return ya(_0xc3ae1,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x1fcb04,..._0x9d76f5){if(typeof _0x1fcb04!='string'){const _0x18eac8=_0x9d76f5[0x0],_0x1964ff=[..._0x9d76f5['slice'](0x1)];return _0x1964ff[0x0]&&(_0x1964ff[0x0]['appName']=_0x1fcb04['name']),_0x1fcb04['_errorFactory']['create'](_0x18eac8,..._0x1964ff);}return ma['create'](_0x1fcb04,..._0x9d76f5);}function m(_0x1babf2,_0x3d657b,..._0x3272d1){if(!_0x1babf2)throw Es(_0x3d657b,..._0x3272d1);}function te(_0x2d0fd6){const _0x190ada='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x2d0fd6;throw nn(_0x190ada),new Error(_0x190ada);}function ae(_0x35fada,_0x129e5b){_0x35fada||te(_0x129e5b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x469fbd;return typeof self<'u'&&((_0x469fbd=self['location'])==null?void 0x0:_0x469fbd['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x15c61a;return typeof self<'u'&&((_0x15c61a=self['location'])==null?void 0x0:_0x15c61a['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x3c96bd=navigator;return _0x3c96bd['languages']&&_0x3c96bd['languages'][0x0]||_0x3c96bd['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x2d43b5,_0x2a0f6d){this['shortDelay']=_0x2d43b5,this['longDelay']=_0x2a0f6d,ae(_0x2a0f6d>_0x2d43b5,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x53bb80,_0x455114){ae(_0x53bb80['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3c9d45}=_0x53bb80['emulator'];return _0x455114?''+_0x3c9d45+(_0x455114['startsWith']('/')?_0x455114['slice'](0x1):_0x455114):_0x3c9d45;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x4fe3fe,_0x98f37f,_0x38730b){this['fetchImpl']=_0x4fe3fe,_0x98f37f&&(this['headersImpl']=_0x98f37f),_0x38730b&&(this['responseImpl']=_0x38730b);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x5a3493,_0x42b1ad){return _0x5a3493['tenantId']&&!_0x42b1ad['tenantId']?{..._0x42b1ad,'tenantId':_0x5a3493['tenantId']}:_0x42b1ad;}async function Ae(_0x2a4459,_0x54ac2a,_0x4cc59c,_0x13c743,_0x27e07e={}){return Ea(_0x2a4459,_0x27e07e,async()=>{let _0x1c551c={},_0x33c87c={};_0x13c743&&(_0x54ac2a==='GET'?_0x33c87c=_0x13c743:_0x1c551c={'body':JSON['stringify'](_0x13c743)});const _0x53e3a3=at({..._0x33c87c,'key':_0x2a4459['config']['apiKey']})['slice'](0x1),_0x5aae13=await _0x2a4459['_getAdditionalHeaders']();_0x5aae13['Content-Type']='application/json',_0x2a4459['languageCode']&&(_0x5aae13['X-Firebase-Locale']=_0x2a4459['languageCode']);const _0x59ebe6={'method':_0x54ac2a,'headers':_0x5aae13,..._0x1c551c};return lc()||(_0x59ebe6['referrerPolicy']='strict-origin-when-cross-origin'),_0x2a4459['emulatorConfig']&&Wt(_0x2a4459['emulatorConfig']['host'])&&(_0x59ebe6['credentials']='include'),va['fetch']()(await Ia(_0x2a4459,_0x2a4459['config']['apiHost'],_0x4cc59c,_0x53e3a3),_0x59ebe6);});}async function Ea(_0x5d1cc4,_0x389d36,_0x2a9ac1){_0x5d1cc4['_canInitEmulator']=!0x1;const _0x1a9738={...rf,..._0x389d36};try{const _0xa4aa7c=new lf(_0x5d1cc4),_0x225b9c=await Promise['race']([_0x2a9ac1(),_0xa4aa7c['promise']]);_0xa4aa7c['clearNetworkTimeout']();const _0x5a3048=await _0x225b9c['json']();if('needConfirmation'in _0x5a3048)throw en(_0x5d1cc4,'account-exists-with-different-credential',_0x5a3048);if(_0x225b9c['ok']&&!('errorMessage'in _0x5a3048))return _0x5a3048;{const _0x52fe66=_0x225b9c['ok']?_0x5a3048['errorMessage']:_0x5a3048['error']['message'],[_0x358a3d,_0x4be32c]=_0x52fe66['split']('\x20:\x20');if(_0x358a3d==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x5d1cc4,'credential-already-in-use',_0x5a3048);if(_0x358a3d==='EMAIL_EXISTS')throw en(_0x5d1cc4,'email-already-in-use',_0x5a3048);if(_0x358a3d==='USER_DISABLED')throw en(_0x5d1cc4,'user-disabled',_0x5a3048);const _0x3f2bd4=_0x1a9738[_0x358a3d]||_0x358a3d['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4be32c)throw ya(_0x5d1cc4,_0x3f2bd4,_0x4be32c);K(_0x5d1cc4,_0x3f2bd4);}}catch(_0x4c45f3){if(_0x4c45f3 instanceof Se)throw _0x4c45f3;K(_0x5d1cc4,'network-request-failed',{'message':String(_0x4c45f3)});}}async function Yt(_0x3d8ad1,_0x4cb615,_0x3da39c,_0x3dbb42,_0x764d2c={}){const _0x1b9861=await Ae(_0x3d8ad1,_0x4cb615,_0x3da39c,_0x3dbb42,_0x764d2c);return'mfaPendingCredential'in _0x1b9861&&K(_0x3d8ad1,'multi-factor-auth-required',{'_serverResponse':_0x1b9861}),_0x1b9861;}async function Ia(_0x3a23de,_0x52940b,_0x3af84b,_0x4dd5ea){const _0x294511=''+_0x52940b+_0x3af84b+'?'+_0x4dd5ea,_0x27a932=_0x3a23de,_0x55aa64=_0x27a932['config']['emulator']?Is(_0x3a23de['config'],_0x294511):_0x3a23de['config']['apiScheme']+'://'+_0x294511;return of['includes'](_0x3af84b)&&(await _0x27a932['_persistenceManagerAvailable'],_0x27a932['_getPersistenceType']()==='COOKIE')?_0x27a932['_getPersistence']()['_getFinalTarget'](_0x55aa64)['toString']():_0x55aa64;}function cf(_0x56bdd5){switch(_0x56bdd5){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x309d39){this['auth']=_0x309d39,this['timer']=null,this['promise']=new Promise((_0x44b4a4,_0x5f1180)=>{this['timer']=setTimeout(()=>_0x5f1180(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x48b4c0,_0x23630a,_0x3d324c){const _0x16523a={'appName':_0x48b4c0['name']};_0x3d324c['email']&&(_0x16523a['email']=_0x3d324c['email']),_0x3d324c['phoneNumber']&&(_0x16523a['phoneNumber']=_0x3d324c['phoneNumber']);const _0x1f7430=J(_0x48b4c0,_0x23630a,_0x16523a);return _0x1f7430['customData']['_tokenResponse']=_0x3d324c,_0x1f7430;}function vr(_0x181d81){return _0x181d81!==void 0x0&&_0x181d81['enterprise']!==void 0x0;}class hf{constructor(_0x151653){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x151653['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x151653['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x151653['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x48f4f3){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5a3eb4 of this['recaptchaEnforcementState'])if(_0x5a3eb4['provider']&&_0x5a3eb4['provider']===_0x48f4f3)return cf(_0x5a3eb4['enforcementState']);return null;}['isProviderEnabled'](_0x5cbc4b){return this['getProviderEnforcementState'](_0x5cbc4b)==='ENFORCE'||this['getProviderEnforcementState'](_0x5cbc4b)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x1578f8,_0x117736){return Ae(_0x1578f8,'GET','/v2/recaptchaConfig',Re(_0x1578f8,_0x117736));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x51bd2f,_0x3c738a){return Ae(_0x51bd2f,'POST','/v1/accounts:delete',_0x3c738a);}async function Sn(_0x2b190e,_0x30de5c){return Ae(_0x2b190e,'POST','/v1/accounts:lookup',_0x30de5c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x569c23){if(_0x569c23)try{const _0x4e3154=new Date(Number(_0x569c23));if(!isNaN(_0x4e3154['getTime']()))return _0x4e3154['toUTCString']();}catch{}}async function ff(_0x17cf06,_0x3b06f0=!0x1){const _0x118742=k(_0x17cf06),_0x322994=await _0x118742['getIdToken'](_0x3b06f0),_0x567a02=ws(_0x322994);m(_0x567a02&&_0x567a02['exp']&&_0x567a02['auth_time']&&_0x567a02['iat'],_0x118742['auth'],'internal-error');const _0x429fbe=typeof _0x567a02['firebase']=='object'?_0x567a02['firebase']:void 0x0,_0x18b6f1=_0x429fbe==null?void 0x0:_0x429fbe['sign_in_provider'];return{'claims':_0x567a02,'token':_0x322994,'authTime':St(ci(_0x567a02['auth_time'])),'issuedAtTime':St(ci(_0x567a02['iat'])),'expirationTime':St(ci(_0x567a02['exp'])),'signInProvider':_0x18b6f1||null,'signInSecondFactor':(_0x429fbe==null?void 0x0:_0x429fbe['sign_in_second_factor'])||null};}function ci(_0x40e90e){return Number(_0x40e90e)*0x3e8;}function ws(_0x464f4f){const [_0x3f207a,_0x1dac11,_0x5de651]=_0x464f4f['split']('.');if(_0x3f207a===void 0x0||_0x1dac11===void 0x0||_0x5de651===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x51132a=cn(_0x1dac11);return _0x51132a?JSON['parse'](_0x51132a):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x595d3a){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x595d3a==null?void 0x0:_0x595d3a['toString']()),null;}}function Er(_0x5a6aa7){const _0x44f885=ws(_0x5a6aa7);return m(_0x44f885,'internal-error'),m(typeof _0x44f885['exp']<'u','internal-error'),m(typeof _0x44f885['iat']<'u','internal-error'),Number(_0x44f885['exp'])-Number(_0x44f885['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x59efcb,_0x3ce139,_0x42c2f8=!0x1){if(_0x42c2f8)return _0x3ce139;try{return await _0x3ce139;}catch(_0x5e4053){throw _0x5e4053 instanceof Se&&pf(_0x5e4053)&&_0x59efcb['auth']['currentUser']===_0x59efcb&&await _0x59efcb['auth']['signOut'](),_0x5e4053;}}function pf({code:_0x2ce506}){return _0x2ce506==='auth/user-disabled'||_0x2ce506==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0xae010f){this['user']=_0xae010f,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x478361){if(_0x478361){const _0x100768=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x100768;}else{this['errorBackoff']=0x7530;const _0x3d4aab=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3d4aab);}}['schedule'](_0x2c0a93=!0x1){if(!this['isRunning'])return;const _0x1a95af=this['getInterval'](_0x2c0a93);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1a95af);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5c1b7b){(_0x5c1b7b==null?void 0x0:_0x5c1b7b['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x351ad9,_0x314ac4){this['createdAt']=_0x351ad9,this['lastLoginAt']=_0x314ac4,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0xbd110d){this['createdAt']=_0xbd110d['createdAt'],this['lastLoginAt']=_0xbd110d['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x5df973){var _0x10aae9;const _0x519677=_0x5df973['auth'],_0x3c18c6=await _0x5df973['getIdToken'](),_0x1c7572=await xt(_0x5df973,Sn(_0x519677,{'idToken':_0x3c18c6}));m(_0x1c7572==null?void 0x0:_0x1c7572['users']['length'],_0x519677,'internal-error');const _0x189bfe=_0x1c7572['users'][0x0];_0x5df973['_notifyReloadListener'](_0x189bfe);const _0x443e6b=(_0x10aae9=_0x189bfe['providerUserInfo'])!=null&&_0x10aae9['length']?wa(_0x189bfe['providerUserInfo']):[],_0x14f8bd=mf(_0x5df973['providerData'],_0x443e6b),_0x2b6aa8=_0x5df973['isAnonymous'],_0x388c14=!(_0x5df973['email']&&_0x189bfe['passwordHash'])&&!(_0x14f8bd!=null&&_0x14f8bd['length']),_0x386904=_0x2b6aa8?_0x388c14:!0x1,_0x73a1e4={'uid':_0x189bfe['localId'],'displayName':_0x189bfe['displayName']||null,'photoURL':_0x189bfe['photoUrl']||null,'email':_0x189bfe['email']||null,'emailVerified':_0x189bfe['emailVerified']||!0x1,'phoneNumber':_0x189bfe['phoneNumber']||null,'tenantId':_0x189bfe['tenantId']||null,'providerData':_0x14f8bd,'metadata':new Pi(_0x189bfe['createdAt'],_0x189bfe['lastLoginAt']),'isAnonymous':_0x386904};Object['assign'](_0x5df973,_0x73a1e4);}async function gf(_0x39ae45){const _0x574f38=k(_0x39ae45);await bn(_0x574f38),await _0x574f38['auth']['_persistUserIfCurrent'](_0x574f38),_0x574f38['auth']['_notifyListenersIfCurrent'](_0x574f38);}function mf(_0x21562c,_0xb4b444){return[..._0x21562c['filter'](_0x5a07f1=>!_0xb4b444['some'](_0x229060=>_0x229060['providerId']===_0x5a07f1['providerId'])),..._0xb4b444];}function wa(_0x2aabe8){return _0x2aabe8['map'](({providerId:_0x2cf04e,..._0xc1ad67})=>({'providerId':_0x2cf04e,'uid':_0xc1ad67['rawId']||'','displayName':_0xc1ad67['displayName']||null,'email':_0xc1ad67['email']||null,'phoneNumber':_0xc1ad67['phoneNumber']||null,'photoURL':_0xc1ad67['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x198027,_0x543b66){const _0x29c90e=await Ea(_0x198027,{},async()=>{const _0x2da2b5=at({'grant_type':'refresh_token','refresh_token':_0x543b66})['slice'](0x1),{tokenApiHost:_0x3b648a,apiKey:_0x23fc1d}=_0x198027['config'],_0x3f677c=await Ia(_0x198027,_0x3b648a,'/v1/token','key='+_0x23fc1d),_0x260dfa=await _0x198027['_getAdditionalHeaders']();_0x260dfa['Content-Type']='application/x-www-form-urlencoded';const _0xa00e4f={'method':'POST','headers':_0x260dfa,'body':_0x2da2b5};return _0x198027['emulatorConfig']&&Wt(_0x198027['emulatorConfig']['host'])&&(_0xa00e4f['credentials']='include'),va['fetch']()(_0x3f677c,_0xa00e4f);});return{'accessToken':_0x29c90e['access_token'],'expiresIn':_0x29c90e['expires_in'],'refreshToken':_0x29c90e['refresh_token']};}async function vf(_0x189737,_0x840b70){return Ae(_0x189737,'POST','/v2/accounts:revokeToken',Re(_0x189737,_0x840b70));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4ad2a0){m(_0x4ad2a0['idToken'],'internal-error'),m(typeof _0x4ad2a0['idToken']<'u','internal-error'),m(typeof _0x4ad2a0['refreshToken']<'u','internal-error');const _0x536cd1='expiresIn'in _0x4ad2a0&&typeof _0x4ad2a0['expiresIn']<'u'?Number(_0x4ad2a0['expiresIn']):Er(_0x4ad2a0['idToken']);this['updateTokensAndExpiration'](_0x4ad2a0['idToken'],_0x4ad2a0['refreshToken'],_0x536cd1);}['updateFromIdToken'](_0x5bdb52){m(_0x5bdb52['length']!==0x0,'internal-error');const _0x61368=Er(_0x5bdb52);this['updateTokensAndExpiration'](_0x5bdb52,null,_0x61368);}async['getToken'](_0x54afe2,_0xd9c1c0=!0x1){return!_0xd9c1c0&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x54afe2,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x54afe2,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x5c71cd,_0xaeb18f){const {accessToken:_0x32f48b,refreshToken:_0x2d6a55,expiresIn:_0x2cba1b}=await yf(_0x5c71cd,_0xaeb18f);this['updateTokensAndExpiration'](_0x32f48b,_0x2d6a55,Number(_0x2cba1b));}['updateTokensAndExpiration'](_0x3c12fb,_0xa2b0e9,_0x338bfb){this['refreshToken']=_0xa2b0e9||null,this['accessToken']=_0x3c12fb||null,this['expirationTime']=Date['now']()+_0x338bfb*0x3e8;}static['fromJSON'](_0x109796,_0x208586){const {refreshToken:_0x5a361e,accessToken:_0x72c93,expirationTime:_0x151b19}=_0x208586,_0x1580ea=new Je();return _0x5a361e&&(m(typeof _0x5a361e=='string','internal-error',{'appName':_0x109796}),_0x1580ea['refreshToken']=_0x5a361e),_0x72c93&&(m(typeof _0x72c93=='string','internal-error',{'appName':_0x109796}),_0x1580ea['accessToken']=_0x72c93),_0x151b19&&(m(typeof _0x151b19=='number','internal-error',{'appName':_0x109796}),_0x1580ea['expirationTime']=_0x151b19),_0x1580ea;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4b6a88){this['accessToken']=_0x4b6a88['accessToken'],this['refreshToken']=_0x4b6a88['refreshToken'],this['expirationTime']=_0x4b6a88['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x18edd7,_0x5eb589){m(typeof _0x18edd7=='string'||typeof _0x18edd7>'u','internal-error',{'appName':_0x5eb589});}class z{constructor({uid:_0x551d18,auth:_0x56608c,stsTokenManager:_0x21df0d,..._0x75e20f}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x551d18,this['auth']=_0x56608c,this['stsTokenManager']=_0x21df0d,this['accessToken']=_0x21df0d['accessToken'],this['displayName']=_0x75e20f['displayName']||null,this['email']=_0x75e20f['email']||null,this['emailVerified']=_0x75e20f['emailVerified']||!0x1,this['phoneNumber']=_0x75e20f['phoneNumber']||null,this['photoURL']=_0x75e20f['photoURL']||null,this['isAnonymous']=_0x75e20f['isAnonymous']||!0x1,this['tenantId']=_0x75e20f['tenantId']||null,this['providerData']=_0x75e20f['providerData']?[..._0x75e20f['providerData']]:[],this['metadata']=new Pi(_0x75e20f['createdAt']||void 0x0,_0x75e20f['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5da921){const _0x54541e=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x5da921));return m(_0x54541e,this['auth'],'internal-error'),this['accessToken']!==_0x54541e&&(this['accessToken']=_0x54541e,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x54541e;}['getIdTokenResult'](_0x2c4343){return ff(this,_0x2c4343);}['reload'](){return gf(this);}['_assign'](_0x44a8e8){this!==_0x44a8e8&&(m(this['uid']===_0x44a8e8['uid'],this['auth'],'internal-error'),this['displayName']=_0x44a8e8['displayName'],this['photoURL']=_0x44a8e8['photoURL'],this['email']=_0x44a8e8['email'],this['emailVerified']=_0x44a8e8['emailVerified'],this['phoneNumber']=_0x44a8e8['phoneNumber'],this['isAnonymous']=_0x44a8e8['isAnonymous'],this['tenantId']=_0x44a8e8['tenantId'],this['providerData']=_0x44a8e8['providerData']['map'](_0x9449be=>({..._0x9449be})),this['metadata']['_copy'](_0x44a8e8['metadata']),this['stsTokenManager']['_assign'](_0x44a8e8['stsTokenManager']));}['_clone'](_0x89aa66){const _0x444dca=new z({...this,'auth':_0x89aa66,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x444dca['metadata']['_copy'](this['metadata']),_0x444dca;}['_onReload'](_0x1cea8d){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1cea8d,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x200c4f){this['reloadListener']?this['reloadListener'](_0x200c4f):this['reloadUserInfo']=_0x200c4f;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5eaeef,_0xec5245=!0x1){let _0x5f0b3a=!0x1;_0x5eaeef['idToken']&&_0x5eaeef['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5eaeef),_0x5f0b3a=!0x0),_0xec5245&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5f0b3a&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x298de0=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x298de0})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x114269=>({..._0x114269})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x61b470,_0x3b7096){const _0x48afcc=_0x3b7096['displayName']??void 0x0,_0x3d1db9=_0x3b7096['email']??void 0x0,_0x108e21=_0x3b7096['phoneNumber']??void 0x0,_0x154d6a=_0x3b7096['photoURL']??void 0x0,_0x1f68a7=_0x3b7096['tenantId']??void 0x0,_0x23966d=_0x3b7096['_redirectEventId']??void 0x0,_0x9c828d=_0x3b7096['createdAt']??void 0x0,_0x20bfb4=_0x3b7096['lastLoginAt']??void 0x0,{uid:_0x42ca44,emailVerified:_0x257e1f,isAnonymous:_0x2b4d4e,providerData:_0x369975,stsTokenManager:_0x5afca6}=_0x3b7096;m(_0x42ca44&&_0x5afca6,_0x61b470,'internal-error');const _0x1ca258=Je['fromJSON'](this['name'],_0x5afca6);m(typeof _0x42ca44=='string',_0x61b470,'internal-error'),ce(_0x48afcc,_0x61b470['name']),ce(_0x3d1db9,_0x61b470['name']),m(typeof _0x257e1f=='boolean',_0x61b470,'internal-error'),m(typeof _0x2b4d4e=='boolean',_0x61b470,'internal-error'),ce(_0x108e21,_0x61b470['name']),ce(_0x154d6a,_0x61b470['name']),ce(_0x1f68a7,_0x61b470['name']),ce(_0x23966d,_0x61b470['name']),ce(_0x9c828d,_0x61b470['name']),ce(_0x20bfb4,_0x61b470['name']);const _0x27b64f=new z({'uid':_0x42ca44,'auth':_0x61b470,'email':_0x3d1db9,'emailVerified':_0x257e1f,'displayName':_0x48afcc,'isAnonymous':_0x2b4d4e,'photoURL':_0x154d6a,'phoneNumber':_0x108e21,'tenantId':_0x1f68a7,'stsTokenManager':_0x1ca258,'createdAt':_0x9c828d,'lastLoginAt':_0x20bfb4});return _0x369975&&Array['isArray'](_0x369975)&&(_0x27b64f['providerData']=_0x369975['map'](_0x23da4c=>({..._0x23da4c}))),_0x23966d&&(_0x27b64f['_redirectEventId']=_0x23966d),_0x27b64f;}static async['_fromIdTokenResponse'](_0x51ebb0,_0x436704,_0x4a6d9a=!0x1){const _0x7f0e6c=new Je();_0x7f0e6c['updateFromServerResponse'](_0x436704);const _0x3b2b92=new z({'uid':_0x436704['localId'],'auth':_0x51ebb0,'stsTokenManager':_0x7f0e6c,'isAnonymous':_0x4a6d9a});return await bn(_0x3b2b92),_0x3b2b92;}static async['_fromGetAccountInfoResponse'](_0x7e2d42,_0x2b1a45,_0xe419c9){const _0x300d07=_0x2b1a45['users'][0x0];m(_0x300d07['localId']!==void 0x0,'internal-error');const _0x155b53=_0x300d07['providerUserInfo']!==void 0x0?wa(_0x300d07['providerUserInfo']):[],_0x2791c5=!(_0x300d07['email']&&_0x300d07['passwordHash'])&&!(_0x155b53!=null&&_0x155b53['length']),_0x21704b=new Je();_0x21704b['updateFromIdToken'](_0xe419c9);const _0x2ba571=new z({'uid':_0x300d07['localId'],'auth':_0x7e2d42,'stsTokenManager':_0x21704b,'isAnonymous':_0x2791c5}),_0x1fab31={'uid':_0x300d07['localId'],'displayName':_0x300d07['displayName']||null,'photoURL':_0x300d07['photoUrl']||null,'email':_0x300d07['email']||null,'emailVerified':_0x300d07['emailVerified']||!0x1,'phoneNumber':_0x300d07['phoneNumber']||null,'tenantId':_0x300d07['tenantId']||null,'providerData':_0x155b53,'metadata':new Pi(_0x300d07['createdAt'],_0x300d07['lastLoginAt']),'isAnonymous':!(_0x300d07['email']&&_0x300d07['passwordHash'])&&!(_0x155b53!=null&&_0x155b53['length'])};return Object['assign'](_0x2ba571,_0x1fab31),_0x2ba571;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0xd8dcb2){ae(_0xd8dcb2 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3bd43c=Ir['get'](_0xd8dcb2);return _0x3bd43c?(ae(_0x3bd43c instanceof _0xd8dcb2,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3bd43c):(_0x3bd43c=new _0xd8dcb2(),Ir['set'](_0xd8dcb2,_0x3bd43c),_0x3bd43c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x101bd9,_0x2d0303){this['storage'][_0x101bd9]=_0x2d0303;}async['_get'](_0x168ea9){const _0x4c3dfa=this['storage'][_0x168ea9];return _0x4c3dfa===void 0x0?null:_0x4c3dfa;}async['_remove'](_0x579022){delete this['storage'][_0x579022];}['_addListener'](_0x12751b,_0x2663c1){}['_removeListener'](_0xe90572,_0x3816c9){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x486053,_0x4c891d,_0x181365){return'firebase:'+_0x486053+':'+_0x4c891d+':'+_0x181365;}class Xe{constructor(_0x2e4093,_0xde4af7,_0x596865){this['persistence']=_0x2e4093,this['auth']=_0xde4af7,this['userKey']=_0x596865;const {config:_0xac9545,name:_0x508b13}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0xac9545['apiKey'],_0x508b13),this['fullPersistenceKey']=sn('persistence',_0xac9545['apiKey'],_0x508b13),this['boundEventHandler']=_0xde4af7['_onStorageEvent']['bind'](_0xde4af7),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x48bdc5){return this['persistence']['_set'](this['fullUserKey'],_0x48bdc5['toJSON']());}async['getCurrentUser'](){const _0x3c65ad=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3c65ad)return null;if(typeof _0x3c65ad=='string'){const _0x11cd98=await Sn(this['auth'],{'idToken':_0x3c65ad})['catch'](()=>{});return _0x11cd98?z['_fromGetAccountInfoResponse'](this['auth'],_0x11cd98,_0x3c65ad):null;}return z['_fromJSON'](this['auth'],_0x3c65ad);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x16c8ae){if(this['persistence']===_0x16c8ae)return;const _0xa3df3b=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x16c8ae,_0xa3df3b)return this['setCurrentUser'](_0xa3df3b);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2e7e2e,_0x29706c,_0x48cebe='authUser'){if(!_0x29706c['length'])return new Xe(ne(wr),_0x2e7e2e,_0x48cebe);const _0x1d9eaa=(await Promise['all'](_0x29706c['map'](async _0x13b8b3=>{if(await _0x13b8b3['_isAvailable']())return _0x13b8b3;})))['filter'](_0x49206c=>_0x49206c);let _0x35ce86=_0x1d9eaa[0x0]||ne(wr);const _0x4b38b8=sn(_0x48cebe,_0x2e7e2e['config']['apiKey'],_0x2e7e2e['name']);let _0x1a640e=null;for(const _0x35bbb3 of _0x29706c)try{const _0x1f5c2c=await _0x35bbb3['_get'](_0x4b38b8);if(_0x1f5c2c){let _0x70201e;if(typeof _0x1f5c2c=='string'){const _0x52878d=await Sn(_0x2e7e2e,{'idToken':_0x1f5c2c})['catch'](()=>{});if(!_0x52878d)break;_0x70201e=await z['_fromGetAccountInfoResponse'](_0x2e7e2e,_0x52878d,_0x1f5c2c);}else _0x70201e=z['_fromJSON'](_0x2e7e2e,_0x1f5c2c);_0x35bbb3!==_0x35ce86&&(_0x1a640e=_0x70201e),_0x35ce86=_0x35bbb3;break;}}catch{}const _0x595e91=_0x1d9eaa['filter'](_0x118e57=>_0x118e57['_shouldAllowMigration']);return!_0x35ce86['_shouldAllowMigration']||!_0x595e91['length']?new Xe(_0x35ce86,_0x2e7e2e,_0x48cebe):(_0x35ce86=_0x595e91[0x0],_0x1a640e&&await _0x35ce86['_set'](_0x4b38b8,_0x1a640e['toJSON']()),await Promise['all'](_0x29706c['map'](async _0xa6782e=>{if(_0xa6782e!==_0x35ce86)try{await _0xa6782e['_remove'](_0x4b38b8);}catch{}})),new Xe(_0x35ce86,_0x2e7e2e,_0x48cebe));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x3d9400){const _0x5e9f9d=_0x3d9400['toLowerCase']();if(_0x5e9f9d['includes']('opera/')||_0x5e9f9d['includes']('opr/')||_0x5e9f9d['includes']('opios/'))return'Opera';if(Ra(_0x5e9f9d))return'IEMobile';if(_0x5e9f9d['includes']('msie')||_0x5e9f9d['includes']('trident/'))return'IE';if(_0x5e9f9d['includes']('edge/'))return'Edge';if(Ta(_0x5e9f9d))return'Firefox';if(_0x5e9f9d['includes']('silk/'))return'Silk';if(ka(_0x5e9f9d))return'Blackberry';if(Na(_0x5e9f9d))return'Webos';if(Sa(_0x5e9f9d))return'Safari';if((_0x5e9f9d['includes']('chrome/')||ba(_0x5e9f9d))&&!_0x5e9f9d['includes']('edge/'))return'Chrome';if(Aa(_0x5e9f9d))return'Android';{const _0x2d52fc=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x513cd5=_0x3d9400['match'](_0x2d52fc);if((_0x513cd5==null?void 0x0:_0x513cd5['length'])===0x2)return _0x513cd5[0x1];}return'Other';}function Ta(_0x21716e=W()){return/firefox\//i['test'](_0x21716e);}function Sa(_0x453357=W()){const _0x226ab0=_0x453357['toLowerCase']();return _0x226ab0['includes']('safari/')&&!_0x226ab0['includes']('chrome/')&&!_0x226ab0['includes']('crios/')&&!_0x226ab0['includes']('android');}function ba(_0x1238c9=W()){return/crios\//i['test'](_0x1238c9);}function Ra(_0x359df6=W()){return/iemobile/i['test'](_0x359df6);}function Aa(_0x441a89=W()){return/android/i['test'](_0x441a89);}function ka(_0x9259ea=W()){return/blackberry/i['test'](_0x9259ea);}function Na(_0x1552cc=W()){return/webos/i['test'](_0x1552cc);}function Cs(_0x20c4d5=W()){return/iphone|ipad|ipod/i['test'](_0x20c4d5)||/macintosh/i['test'](_0x20c4d5)&&/mobile/i['test'](_0x20c4d5);}function Ef(_0x1bd03b=W()){var _0x12c1e9;return Cs(_0x1bd03b)&&!!((_0x12c1e9=window['navigator'])!=null&&_0x12c1e9['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x4314ea=W()){return Cs(_0x4314ea)||Aa(_0x4314ea)||Na(_0x4314ea)||ka(_0x4314ea)||/windows phone/i['test'](_0x4314ea)||Ra(_0x4314ea);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x207b1b,_0x37016a=[]){let _0x39af53;switch(_0x207b1b){case'Browser':_0x39af53=Cr(W());break;case'Worker':_0x39af53=Cr(W())+'-'+_0x207b1b;break;default:_0x39af53=_0x207b1b;}const _0x81f79d=_0x37016a['length']?_0x37016a['join'](','):'FirebaseCore-web';return _0x39af53+'/JsCore/'+ct+'/'+_0x81f79d;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x1a5309){this['auth']=_0x1a5309,this['queue']=[];}['pushCallback'](_0x3fd29d,_0x405692){const _0x407509=_0x243685=>new Promise((_0x2360a3,_0x5905d9)=>{try{const _0x148f2d=_0x3fd29d(_0x243685);_0x2360a3(_0x148f2d);}catch(_0x1a876d){_0x5905d9(_0x1a876d);}});_0x407509['onAbort']=_0x405692,this['queue']['push'](_0x407509);const _0x4af8dc=this['queue']['length']-0x1;return()=>{this['queue'][_0x4af8dc]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3bdbd4){if(this['auth']['currentUser']===_0x3bdbd4)return;const _0x3c42ac=[];try{for(const _0x1005d0 of this['queue'])await _0x1005d0(_0x3bdbd4),_0x1005d0['onAbort']&&_0x3c42ac['push'](_0x1005d0['onAbort']);}catch(_0x11bc33){_0x3c42ac['reverse']();for(const _0x186c48 of _0x3c42ac)try{_0x186c48();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x11bc33==null?void 0x0:_0x11bc33['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x375c4d,_0x5c9d79={}){return Ae(_0x375c4d,'GET','/v2/passwordPolicy',Re(_0x375c4d,_0x5c9d79));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x8ac771){var _0x24c890;const _0x32eb07=_0x8ac771['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x32eb07['minPasswordLength']??Tf,_0x32eb07['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x32eb07['maxPasswordLength']),_0x32eb07['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x32eb07['containsLowercaseCharacter']),_0x32eb07['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x32eb07['containsUppercaseCharacter']),_0x32eb07['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x32eb07['containsNumericCharacter']),_0x32eb07['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x32eb07['containsNonAlphanumericCharacter']),this['enforcementState']=_0x8ac771['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x24c890=_0x8ac771['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x24c890['join'](''))??'',this['forceUpgradeOnSignin']=_0x8ac771['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x8ac771['schemaVersion'];}['validatePassword'](_0x405e9f){const _0x9ec7a6={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x405e9f,_0x9ec7a6),this['validatePasswordCharacterOptions'](_0x405e9f,_0x9ec7a6),_0x9ec7a6['isValid']&&(_0x9ec7a6['isValid']=_0x9ec7a6['meetsMinPasswordLength']??!0x0),_0x9ec7a6['isValid']&&(_0x9ec7a6['isValid']=_0x9ec7a6['meetsMaxPasswordLength']??!0x0),_0x9ec7a6['isValid']&&(_0x9ec7a6['isValid']=_0x9ec7a6['containsLowercaseLetter']??!0x0),_0x9ec7a6['isValid']&&(_0x9ec7a6['isValid']=_0x9ec7a6['containsUppercaseLetter']??!0x0),_0x9ec7a6['isValid']&&(_0x9ec7a6['isValid']=_0x9ec7a6['containsNumericCharacter']??!0x0),_0x9ec7a6['isValid']&&(_0x9ec7a6['isValid']=_0x9ec7a6['containsNonAlphanumericCharacter']??!0x0),_0x9ec7a6;}['validatePasswordLengthOptions'](_0xd82c0e,_0x1aa24b){const _0xe191f3=this['customStrengthOptions']['minPasswordLength'],_0x30fed1=this['customStrengthOptions']['maxPasswordLength'];_0xe191f3&&(_0x1aa24b['meetsMinPasswordLength']=_0xd82c0e['length']>=_0xe191f3),_0x30fed1&&(_0x1aa24b['meetsMaxPasswordLength']=_0xd82c0e['length']<=_0x30fed1);}['validatePasswordCharacterOptions'](_0x2a53cf,_0x30ceda){this['updatePasswordCharacterOptionsStatuses'](_0x30ceda,!0x1,!0x1,!0x1,!0x1);let _0x1a664e;for(let _0x5a54e7=0x0;_0x5a54e7<_0x2a53cf['length'];_0x5a54e7++)_0x1a664e=_0x2a53cf['charAt'](_0x5a54e7),this['updatePasswordCharacterOptionsStatuses'](_0x30ceda,_0x1a664e>='a'&&_0x1a664e<='z',_0x1a664e>='A'&&_0x1a664e<='Z',_0x1a664e>='0'&&_0x1a664e<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1a664e));}['updatePasswordCharacterOptionsStatuses'](_0x49ab77,_0x1f19c8,_0x4ee898,_0x453e14,_0x596a8e){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x49ab77['containsLowercaseLetter']||(_0x49ab77['containsLowercaseLetter']=_0x1f19c8)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x49ab77['containsUppercaseLetter']||(_0x49ab77['containsUppercaseLetter']=_0x4ee898)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x49ab77['containsNumericCharacter']||(_0x49ab77['containsNumericCharacter']=_0x453e14)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x49ab77['containsNonAlphanumericCharacter']||(_0x49ab77['containsNonAlphanumericCharacter']=_0x596a8e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x1e56f5,_0x5f3bf6,_0x18dd6c,_0x4af49b){this['app']=_0x1e56f5,this['heartbeatServiceProvider']=_0x5f3bf6,this['appCheckServiceProvider']=_0x18dd6c,this['config']=_0x4af49b,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1e56f5['name'],this['clientVersion']=_0x4af49b['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x3fce70=>this['_resolvePersistenceManagerAvailable']=_0x3fce70);}['_initializeWithPersistence'](_0x3b57a5,_0x8bbae7){return _0x8bbae7&&(this['_popupRedirectResolver']=ne(_0x8bbae7)),this['_initializationPromise']=this['queue'](async()=>{var _0x531c88,_0x478535,_0x5b4846;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x3b57a5),(_0x531c88=this['_resolvePersistenceManagerAvailable'])==null||_0x531c88['call'](this),!this['_deleted'])){if((_0x478535=this['_popupRedirectResolver'])!=null&&_0x478535['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x8bbae7),this['lastNotifiedUid']=((_0x5b4846=this['currentUser'])==null?void 0x0:_0x5b4846['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x200c6d=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x200c6d)){if(this['currentUser']&&_0x200c6d&&this['currentUser']['uid']===_0x200c6d['uid']){this['_currentUser']['_assign'](_0x200c6d),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x200c6d,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x139de5){try{const _0x429618=await Sn(this,{'idToken':_0x139de5}),_0x4fc567=await z['_fromGetAccountInfoResponse'](this,_0x429618,_0x139de5);await this['directlySetCurrentUser'](_0x4fc567);}catch(_0x524b7d){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x524b7d),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xd3e0d9){var _0x458c9e;if(H(this['app'])){const _0xea1982=this['app']['settings']['authIdToken'];return _0xea1982?new Promise(_0x1e3bce=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0xea1982)['then'](_0x1e3bce,_0x1e3bce));}):this['directlySetCurrentUser'](null);}const _0x49888f=await this['assertedPersistence']['getCurrentUser']();let _0x4b40c5=_0x49888f,_0x162a20=!0x1;if(_0xd3e0d9&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x4e0930=(_0x458c9e=this['redirectUser'])==null?void 0x0:_0x458c9e['_redirectEventId'],_0x580833=_0x4b40c5==null?void 0x0:_0x4b40c5['_redirectEventId'],_0x313654=await this['tryRedirectSignIn'](_0xd3e0d9);(!_0x4e0930||_0x4e0930===_0x580833)&&(_0x313654!=null&&_0x313654['user'])&&(_0x4b40c5=_0x313654['user'],_0x162a20=!0x0);}if(!_0x4b40c5)return this['directlySetCurrentUser'](null);if(!_0x4b40c5['_redirectEventId']){if(_0x162a20)try{await this['beforeStateQueue']['runMiddleware'](_0x4b40c5);}catch(_0x3b1bee){_0x4b40c5=_0x49888f,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3b1bee));}return _0x4b40c5?this['reloadAndSetCurrentUserOrClear'](_0x4b40c5):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4b40c5['_redirectEventId']?this['directlySetCurrentUser'](_0x4b40c5):this['reloadAndSetCurrentUserOrClear'](_0x4b40c5);}async['tryRedirectSignIn'](_0x2da4ce){let _0x18441b=null;try{_0x18441b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2da4ce,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x18441b;}async['reloadAndSetCurrentUserOrClear'](_0x175c02){try{await bn(_0x175c02);}catch(_0x2c5221){if((_0x2c5221==null?void 0x0:_0x2c5221['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x175c02);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0xa27ef0){if(H(this['app']))return Promise['reject'](se(this));const _0x5cdb52=_0xa27ef0?k(_0xa27ef0):null;return _0x5cdb52&&m(_0x5cdb52['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5cdb52&&_0x5cdb52['_clone'](this));}async['_updateCurrentUser'](_0x25ba4c,_0x323b5f=!0x1){if(!this['_deleted'])return _0x25ba4c&&m(this['tenantId']===_0x25ba4c['tenantId'],this,'tenant-id-mismatch'),_0x323b5f||await this['beforeStateQueue']['runMiddleware'](_0x25ba4c),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x25ba4c),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x58a192){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x58a192));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3ca8c8){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2cb919=this['_getPasswordPolicyInternal']();return _0x2cb919['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2cb919['validatePassword'](_0x3ca8c8);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x1a723b=await Cf(this),_0x1a707b=new Sf(_0x1a723b);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1a707b:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1a707b;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x5625d0){this['_errorFactory']=new Ut('auth','Firebase',_0x5625d0());}['onAuthStateChanged'](_0xb98712,_0x275ded,_0x61b4f7){return this['registerStateListener'](this['authStateSubscription'],_0xb98712,_0x275ded,_0x61b4f7);}['beforeAuthStateChanged'](_0x12176c,_0x3fe502){return this['beforeStateQueue']['pushCallback'](_0x12176c,_0x3fe502);}['onIdTokenChanged'](_0x149bf8,_0x10094a,_0x1d4da3){return this['registerStateListener'](this['idTokenSubscription'],_0x149bf8,_0x10094a,_0x1d4da3);}['authStateReady'](){return new Promise((_0x5eb1a2,_0x314b4a)=>{if(this['currentUser'])_0x5eb1a2();else{const _0x1d4661=this['onAuthStateChanged'](()=>{_0x1d4661(),_0x5eb1a2();},_0x314b4a);}});}async['revokeAccessToken'](_0x19f15b){if(this['currentUser']){const _0x2b549a=await this['currentUser']['getIdToken'](),_0x352541={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x19f15b,'idToken':_0x2b549a};this['tenantId']!=null&&(_0x352541['tenantId']=this['tenantId']),await vf(this,_0x352541);}}['toJSON'](){var _0x2b8d86;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2b8d86=this['_currentUser'])==null?void 0x0:_0x2b8d86['toJSON']()};}async['_setRedirectUser'](_0x2f4168,_0x90bbf1){const _0x2111ae=await this['getOrInitRedirectPersistenceManager'](_0x90bbf1);return _0x2f4168===null?_0x2111ae['removeCurrentUser']():_0x2111ae['setCurrentUser'](_0x2f4168);}async['getOrInitRedirectPersistenceManager'](_0x4c2105){if(!this['redirectPersistenceManager']){const _0x2f2cde=_0x4c2105&&ne(_0x4c2105)||this['_popupRedirectResolver'];m(_0x2f2cde,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x2f2cde['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x8e6ff2){var _0x2adff2,_0x3da367;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2adff2=this['_currentUser'])==null?void 0x0:_0x2adff2['_redirectEventId'])===_0x8e6ff2?this['_currentUser']:((_0x3da367=this['redirectUser'])==null?void 0x0:_0x3da367['_redirectEventId'])===_0x8e6ff2?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x41d581){if(_0x41d581===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x41d581));}['_notifyListenersIfCurrent'](_0x4518e4){_0x4518e4===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x26377d;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x586f0f=((_0x26377d=this['currentUser'])==null?void 0x0:_0x26377d['uid'])??null;this['lastNotifiedUid']!==_0x586f0f&&(this['lastNotifiedUid']=_0x586f0f,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3f7920,_0x21fb67,_0x514860,_0x2cb3c6){if(this['_deleted'])return()=>{};const _0x14b476=typeof _0x21fb67=='function'?_0x21fb67:_0x21fb67['next']['bind'](_0x21fb67);let _0x35b6fb=!0x1;const _0x5ae0d2=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x5ae0d2,this,'internal-error'),_0x5ae0d2['then'](()=>{_0x35b6fb||_0x14b476(this['currentUser']);}),typeof _0x21fb67=='function'){const _0x5edbb5=_0x3f7920['addObserver'](_0x21fb67,_0x514860,_0x2cb3c6);return()=>{_0x35b6fb=!0x0,_0x5edbb5();};}else{const _0x568a9e=_0x3f7920['addObserver'](_0x21fb67);return()=>{_0x35b6fb=!0x0,_0x568a9e();};}}async['directlySetCurrentUser'](_0x464da9){this['currentUser']&&this['currentUser']!==_0x464da9&&this['_currentUser']['_stopProactiveRefresh'](),_0x464da9&&this['isProactiveRefreshEnabled']&&_0x464da9['_startProactiveRefresh'](),this['currentUser']=_0x464da9,_0x464da9?await this['assertedPersistence']['setCurrentUser'](_0x464da9):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2b7c3a){return this['operations']=this['operations']['then'](_0x2b7c3a,_0x2b7c3a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4a4cef){!_0x4a4cef||this['frameworks']['includes'](_0x4a4cef)||(this['frameworks']['push'](_0x4a4cef),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x11cc1d;const _0x42ee35={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x42ee35['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x19f7e4=await((_0x11cc1d=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x11cc1d['getHeartbeatsHeader']());_0x19f7e4&&(_0x42ee35['X-Firebase-Client']=_0x19f7e4);const _0x1ccc24=await this['_getAppCheckToken']();return _0x1ccc24&&(_0x42ee35['X-Firebase-AppCheck']=_0x1ccc24),_0x42ee35;}async['_getAppCheckToken'](){var _0x42bb97;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x46db72=await((_0x42bb97=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x42bb97['getToken']());return _0x46db72!=null&&_0x46db72['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x46db72['error']),_0x46db72==null?void 0x0:_0x46db72['token'];}}function qe(_0x25f485){return k(_0x25f485);}class Tr{constructor(_0x481c99){this['auth']=_0x481c99,this['observer']=null,this['addObserver']=Ic(_0x537907=>this['observer']=_0x537907);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0xb5e237){zn=_0xb5e237;}function Da(_0x336a21){return zn['loadJS'](_0x336a21);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x29b12a){return'__'+_0x29b12a+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0xf3e3d4){_0xf3e3d4();}['execute'](_0xbc4e7b,_0x5b228d){return Promise['resolve']('token');}['render'](_0xbc559e,_0x29f984){return'';}}class Of{['ready'](_0x4e080b){_0x4e080b();}['execute'](_0x4814c2,_0x5e94aa){return Promise['resolve']('token');}['render'](_0xb27ed0,_0x4fb167){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x373b76){this['type']=Df,this['auth']=qe(_0x373b76);}async['verify'](_0x54a81d='verify',_0x28d852=!0x1){async function _0xb85d9(_0x102afc){if(!_0x28d852){if(_0x102afc['tenantId']==null&&_0x102afc['_agentRecaptchaConfig']!=null)return _0x102afc['_agentRecaptchaConfig']['siteKey'];if(_0x102afc['tenantId']!=null&&_0x102afc['_tenantRecaptchaConfigs'][_0x102afc['tenantId']]!==void 0x0)return _0x102afc['_tenantRecaptchaConfigs'][_0x102afc['tenantId']]['siteKey'];}return new Promise(async(_0x3d325e,_0x51fca3)=>{uf(_0x102afc,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4c010c=>{if(_0x4c010c['recaptchaKey']===void 0x0)_0x51fca3(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x456754=new hf(_0x4c010c);return _0x102afc['tenantId']==null?_0x102afc['_agentRecaptchaConfig']=_0x456754:_0x102afc['_tenantRecaptchaConfigs'][_0x102afc['tenantId']]=_0x456754,_0x3d325e(_0x456754['siteKey']);}})['catch'](_0x1132cd=>{_0x51fca3(_0x1132cd);});});}function _0x3eb027(_0x408d29,_0x2fc75b,_0x2724dd){const _0x2e005b=window['grecaptcha'];vr(_0x2e005b)?_0x2e005b['enterprise']['ready'](()=>{_0x2e005b['enterprise']['execute'](_0x408d29,{'action':_0x54a81d})['then'](_0x2fd456=>{_0x2fc75b(_0x2fd456);})['catch'](()=>{_0x2fc75b(Ma);});}):_0x2724dd(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1dc256,_0x5cae39)=>{_0xb85d9(this['auth'])['then'](async _0xf70014=>{if(!_0x28d852&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x3eb027(_0xf70014,_0x1dc256,_0x5cae39);else{if(typeof window>'u'){_0x5cae39(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x33b1d0=Af();_0x33b1d0['length']!==0x0&&(_0x33b1d0+=_0xf70014+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x197401;(_0x197401=le['scriptInjectionDeferred'])==null||_0x197401['resolve']();},Da(_0x33b1d0)['then'](()=>{var _0x462187;return(_0x462187=le['scriptInjectionDeferred'])==null?void 0x0:_0x462187['promise'];})['then'](()=>{_0x3eb027(_0xf70014,_0x1dc256,_0x5cae39);})['catch'](_0x16b613=>{_0x5cae39(_0x16b613);});}})['catch'](_0x5de617=>{_0x5cae39(_0x5de617);});});}}le['scriptInjectionDeferred']=null;async function br(_0x432aab,_0x173c46,_0x3cbb73,_0x227295=!0x1,_0xec8779=!0x1){const _0x57610b=new le(_0x432aab);let _0x1fceb0;if(_0xec8779)_0x1fceb0=Ma;else try{_0x1fceb0=await _0x57610b['verify'](_0x3cbb73);}catch{_0x1fceb0=await _0x57610b['verify'](_0x3cbb73,!0x0);}const _0x45701f={..._0x173c46};if(_0x3cbb73==='mfaSmsEnrollment'||_0x3cbb73==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x45701f){const _0x502ecb=_0x45701f['phoneEnrollmentInfo']['phoneNumber'],_0x3f1d3b=_0x45701f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x45701f,{'phoneEnrollmentInfo':{'phoneNumber':_0x502ecb,'recaptchaToken':_0x3f1d3b,'captchaResponse':_0x1fceb0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x45701f){const _0x27bf16=_0x45701f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x45701f,{'phoneSignInInfo':{'recaptchaToken':_0x27bf16,'captchaResponse':_0x1fceb0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x45701f;}return _0x227295?Object['assign'](_0x45701f,{'captchaResp':_0x1fceb0}):Object['assign'](_0x45701f,{'captchaResponse':_0x1fceb0}),Object['assign'](_0x45701f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x45701f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x45701f;}async function Oi(_0x2126cc,_0x100990,_0x3241bf,_0x4799a9,_0x1f2b42){var _0x2a4d11;if((_0x2a4d11=_0x2126cc['_getRecaptchaConfig']())!=null&&_0x2a4d11['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x55610f=await br(_0x2126cc,_0x100990,_0x3241bf,_0x3241bf==='getOobCode');return _0x4799a9(_0x2126cc,_0x55610f);}else return _0x4799a9(_0x2126cc,_0x100990)['catch'](async _0x2038bc=>{if(_0x2038bc['code']==='auth/missing-recaptcha-token'){console['log'](_0x3241bf+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x140949=await br(_0x2126cc,_0x100990,_0x3241bf,_0x3241bf==='getOobCode');return _0x4799a9(_0x2126cc,_0x140949);}else return Promise['reject'](_0x2038bc);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x3d7a10,_0x35434f){const _0x58194a=Ui(_0x3d7a10,'auth');if(_0x58194a['isInitialized']()){const _0x34190f=_0x58194a['getImmediate'](),_0x35f3c7=_0x58194a['getOptions']();if(De(_0x35f3c7,_0x35434f??{}))return _0x34190f;K(_0x34190f,'already-initialized');}return _0x58194a['initialize']({'options':_0x35434f});}function Lf(_0x373d78,_0x4ad474){const _0x35c0f4=(_0x4ad474==null?void 0x0:_0x4ad474['persistence'])||[],_0x47679b=(Array['isArray'](_0x35c0f4)?_0x35c0f4:[_0x35c0f4])['map'](ne);_0x4ad474!=null&&_0x4ad474['errorMap']&&_0x373d78['_updateErrorMap'](_0x4ad474['errorMap']),_0x373d78['_initializeWithPersistence'](_0x47679b,_0x4ad474==null?void 0x0:_0x4ad474['popupRedirectResolver']);}function xf(_0x3581b9,_0x445b80,_0x318992){const _0x4ea2f7=qe(_0x3581b9);m(/^https?:\/\//['test'](_0x445b80),_0x4ea2f7,'invalid-emulator-scheme');const _0x2adfd2=!0x1,_0xb69a11=La(_0x445b80),{host:_0x28ae16,port:_0x22e980}=Ff(_0x445b80),_0x4d7c27=_0x22e980===null?'':':'+_0x22e980,_0x11a556={'url':_0xb69a11+'//'+_0x28ae16+_0x4d7c27+'/'},_0x42484e=Object['freeze']({'host':_0x28ae16,'port':_0x22e980,'protocol':_0xb69a11['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2adfd2})});if(!_0x4ea2f7['_canInitEmulator']){m(_0x4ea2f7['config']['emulator']&&_0x4ea2f7['emulatorConfig'],_0x4ea2f7,'emulator-config-failed'),m(De(_0x11a556,_0x4ea2f7['config']['emulator'])&&De(_0x42484e,_0x4ea2f7['emulatorConfig']),_0x4ea2f7,'emulator-config-failed');return;}_0x4ea2f7['config']['emulator']=_0x11a556,_0x4ea2f7['emulatorConfig']=_0x42484e,_0x4ea2f7['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x28ae16)?jr(_0xb69a11+'//'+_0x28ae16+_0x4d7c27):Uf();}function La(_0x1a752d){const _0x237e47=_0x1a752d['indexOf'](':');return _0x237e47<0x0?'':_0x1a752d['substr'](0x0,_0x237e47+0x1);}function Ff(_0x2617f9){const _0x4bee9c=La(_0x2617f9),_0x118fe0=/(\/\/)?([^?#/]+)/['exec'](_0x2617f9['substr'](_0x4bee9c['length']));if(!_0x118fe0)return{'host':'','port':null};const _0x199d46=_0x118fe0[0x2]['split']('@')['pop']()||'',_0x359e5d=/^(\[[^\]]+\])(:|$)/['exec'](_0x199d46);if(_0x359e5d){const _0x14fe2d=_0x359e5d[0x1];return{'host':_0x14fe2d,'port':Rr(_0x199d46['substr'](_0x14fe2d['length']+0x1))};}else{const [_0x2bf66b,_0x50e076]=_0x199d46['split'](':');return{'host':_0x2bf66b,'port':Rr(_0x50e076)};}}function Rr(_0x3b0cf6){if(!_0x3b0cf6)return null;const _0x5ad3be=Number(_0x3b0cf6);return isNaN(_0x5ad3be)?null:_0x5ad3be;}function Uf(){function _0x4a334f(){const _0x271e99=document['createElement']('p'),_0x5a2a16=_0x271e99['style'];_0x271e99['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5a2a16['position']='fixed',_0x5a2a16['width']='100%',_0x5a2a16['backgroundColor']='#ffffff',_0x5a2a16['border']='.1em\x20solid\x20#000000',_0x5a2a16['color']='#b50000',_0x5a2a16['bottom']='0px',_0x5a2a16['left']='0px',_0x5a2a16['margin']='0px',_0x5a2a16['zIndex']='10000',_0x5a2a16['textAlign']='center',_0x271e99['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x271e99);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x4a334f):_0x4a334f());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x2ff947,_0x1497f6){this['providerId']=_0x2ff947,this['signInMethod']=_0x1497f6;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x5ad5c4){return te('not\x20implemented');}['_linkToIdToken'](_0x5dff1f,_0x308138){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x502c12){return te('not\x20implemented');}}async function Wf(_0x50b5f0,_0x2a3b79){return Ae(_0x50b5f0,'POST','/v1/accounts:signUp',_0x2a3b79);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x2854b4,_0x2ffc59){return Yt(_0x2854b4,'POST','/v1/accounts:signInWithPassword',Re(_0x2854b4,_0x2ffc59));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0xccb936,_0x3514cb){return Yt(_0xccb936,'POST','/v1/accounts:signInWithEmailLink',Re(_0xccb936,_0x3514cb));}async function Hf(_0x42dc48,_0xee00bd){return Yt(_0x42dc48,'POST','/v1/accounts:signInWithEmailLink',Re(_0x42dc48,_0xee00bd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x235aaf,_0x10cc7e,_0x2711fc,_0x30d807=null){super('password',_0x2711fc),this['_email']=_0x235aaf,this['_password']=_0x10cc7e,this['_tenantId']=_0x30d807;}static['_fromEmailAndPassword'](_0x27b294,_0x3afb8c){return new Ft(_0x27b294,_0x3afb8c,'password');}static['_fromEmailAndCode'](_0x48982f,_0xe42f9f,_0x5cefc7=null){return new Ft(_0x48982f,_0xe42f9f,'emailLink',_0x5cefc7);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x20dfbb){const _0x45a916=typeof _0x20dfbb=='string'?JSON['parse'](_0x20dfbb):_0x20dfbb;if(_0x45a916!=null&&_0x45a916['email']&&(_0x45a916!=null&&_0x45a916['password'])){if(_0x45a916['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x45a916['email'],_0x45a916['password']);if(_0x45a916['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x45a916['email'],_0x45a916['password'],_0x45a916['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4b40c6){switch(this['signInMethod']){case'password':const _0x4726a7={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x4b40c6,_0x4726a7,'signInWithPassword',Bf);case'emailLink':return Vf(_0x4b40c6,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x4b40c6,'internal-error');}}async['_linkToIdToken'](_0x342463,_0x735033){switch(this['signInMethod']){case'password':const _0x4a5c54={'idToken':_0x735033,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x342463,_0x4a5c54,'signUpPassword',Wf);case'emailLink':return Hf(_0x342463,{'idToken':_0x735033,'email':this['_email'],'oobCode':this['_password']});default:K(_0x342463,'internal-error');}}['_getReauthenticationResolver'](_0x29223d){return this['_getIdTokenResponse'](_0x29223d);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x45c4cb,_0x1385f8){return Yt(_0x45c4cb,'POST','/v1/accounts:signInWithIdp',Re(_0x45c4cb,_0x1385f8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x27e336){const _0x2bfb51=new We(_0x27e336['providerId'],_0x27e336['signInMethod']);return _0x27e336['idToken']||_0x27e336['accessToken']?(_0x27e336['idToken']&&(_0x2bfb51['idToken']=_0x27e336['idToken']),_0x27e336['accessToken']&&(_0x2bfb51['accessToken']=_0x27e336['accessToken']),_0x27e336['nonce']&&!_0x27e336['pendingToken']&&(_0x2bfb51['nonce']=_0x27e336['nonce']),_0x27e336['pendingToken']&&(_0x2bfb51['pendingToken']=_0x27e336['pendingToken'])):_0x27e336['oauthToken']&&_0x27e336['oauthTokenSecret']?(_0x2bfb51['accessToken']=_0x27e336['oauthToken'],_0x2bfb51['secret']=_0x27e336['oauthTokenSecret']):K('argument-error'),_0x2bfb51;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x20033e){const _0x3ae53c=typeof _0x20033e=='string'?JSON['parse'](_0x20033e):_0x20033e,{providerId:_0x59cdbc,signInMethod:_0x49359c,..._0x149824}=_0x3ae53c;if(!_0x59cdbc||!_0x49359c)return null;const _0x51bd76=new We(_0x59cdbc,_0x49359c);return _0x51bd76['idToken']=_0x149824['idToken']||void 0x0,_0x51bd76['accessToken']=_0x149824['accessToken']||void 0x0,_0x51bd76['secret']=_0x149824['secret'],_0x51bd76['nonce']=_0x149824['nonce'],_0x51bd76['pendingToken']=_0x149824['pendingToken']||null,_0x51bd76;}['_getIdTokenResponse'](_0xf85325){const _0x46bdb1=this['buildRequest']();return Ze(_0xf85325,_0x46bdb1);}['_linkToIdToken'](_0x445775,_0x3c15d4){const _0x43c5b8=this['buildRequest']();return _0x43c5b8['idToken']=_0x3c15d4,Ze(_0x445775,_0x43c5b8);}['_getReauthenticationResolver'](_0x1094f8){const _0x45c455=this['buildRequest']();return _0x45c455['autoCreate']=!0x1,Ze(_0x1094f8,_0x45c455);}['buildRequest'](){const _0x54f258={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x54f258['pendingToken']=this['pendingToken'];else{const _0x246721={};this['idToken']&&(_0x246721['id_token']=this['idToken']),this['accessToken']&&(_0x246721['access_token']=this['accessToken']),this['secret']&&(_0x246721['oauth_token_secret']=this['secret']),_0x246721['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x246721['nonce']=this['nonce']),_0x54f258['postBody']=at(_0x246721);}return _0x54f258;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0xa1a77c){switch(_0xa1a77c){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x2c3875){const _0x447be3=yt(vt(_0x2c3875))['link'],_0x54f438=_0x447be3?yt(vt(_0x447be3))['deep_link_id']:null,_0x3b8339=yt(vt(_0x2c3875))['deep_link_id'];return(_0x3b8339?yt(vt(_0x3b8339))['link']:null)||_0x3b8339||_0x54f438||_0x447be3||_0x2c3875;}class Ss{constructor(_0x1e5084){const _0x348852=yt(vt(_0x1e5084)),_0x2ca930=_0x348852['apiKey']??null,_0xbbe5c5=_0x348852['oobCode']??null,_0x2753c7=Gf(_0x348852['mode']??null);m(_0x2ca930&&_0xbbe5c5&&_0x2753c7,'argument-error'),this['apiKey']=_0x2ca930,this['operation']=_0x2753c7,this['code']=_0xbbe5c5,this['continueUrl']=_0x348852['continueUrl']??null,this['languageCode']=_0x348852['lang']??null,this['tenantId']=_0x348852['tenantId']??null;}static['parseLink'](_0xe16dcd){const _0x556332=qf(_0xe16dcd);try{return new Ss(_0x556332);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x158083,_0x17a896){return Ft['_fromEmailAndPassword'](_0x158083,_0x17a896);}static['credentialWithLink'](_0x46f9b1,_0x16db36){const _0x122aff=Ss['parseLink'](_0x16db36);return m(_0x122aff,'argument-error'),Ft['_fromEmailAndCode'](_0x46f9b1,_0x122aff['code'],_0x122aff['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x143663){this['providerId']=_0x143663,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x277955){this['defaultLanguageCode']=_0x277955;}['setCustomParameters'](_0x4fbc2d){return this['customParameters']=_0x4fbc2d,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x8f7bb8){return this['scopes']['includes'](_0x8f7bb8)||this['scopes']['push'](_0x8f7bb8),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x301287){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x301287});}static['credentialFromResult'](_0x3b986d){return he['credentialFromTaggedObject'](_0x3b986d);}static['credentialFromError'](_0x3a9dd1){return he['credentialFromTaggedObject'](_0x3a9dd1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x38dc1b}){if(!_0x38dc1b||!('oauthAccessToken'in _0x38dc1b)||!_0x38dc1b['oauthAccessToken'])return null;try{return he['credential'](_0x38dc1b['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3a0aea,_0x3aa8d3){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3a0aea,'accessToken':_0x3aa8d3});}static['credentialFromResult'](_0x3f6640){return ue['credentialFromTaggedObject'](_0x3f6640);}static['credentialFromError'](_0x24822a){return ue['credentialFromTaggedObject'](_0x24822a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x518b4e}){if(!_0x518b4e)return null;const {oauthIdToken:_0x3c7e88,oauthAccessToken:_0x481434}=_0x518b4e;if(!_0x3c7e88&&!_0x481434)return null;try{return ue['credential'](_0x3c7e88,_0x481434);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x3693dc){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3693dc});}static['credentialFromResult'](_0x3b846f){return de['credentialFromTaggedObject'](_0x3b846f);}static['credentialFromError'](_0x1156c2){return de['credentialFromTaggedObject'](_0x1156c2['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xf04a03}){if(!_0xf04a03||!('oauthAccessToken'in _0xf04a03)||!_0xf04a03['oauthAccessToken'])return null;try{return de['credential'](_0xf04a03['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x43ee7f,_0x161fa7){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x43ee7f,'oauthTokenSecret':_0x161fa7});}static['credentialFromResult'](_0x3ab552){return fe['credentialFromTaggedObject'](_0x3ab552);}static['credentialFromError'](_0x58d688){return fe['credentialFromTaggedObject'](_0x58d688['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3d4c20}){if(!_0x3d4c20)return null;const {oauthAccessToken:_0x443984,oauthTokenSecret:_0x1c55ba}=_0x3d4c20;if(!_0x443984||!_0x1c55ba)return null;try{return fe['credential'](_0x443984,_0x1c55ba);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x37cb9f,_0x537dc3){return Yt(_0x37cb9f,'POST','/v1/accounts:signUp',Re(_0x37cb9f,_0x537dc3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x2d7590){this['user']=_0x2d7590['user'],this['providerId']=_0x2d7590['providerId'],this['_tokenResponse']=_0x2d7590['_tokenResponse'],this['operationType']=_0x2d7590['operationType'];}static async['_fromIdTokenResponse'](_0x43b9db,_0x2cfc2d,_0x3695e4,_0x50784e=!0x1){const _0x3aa147=await z['_fromIdTokenResponse'](_0x43b9db,_0x3695e4,_0x50784e),_0x439ba5=Ar(_0x3695e4);return new Be({'user':_0x3aa147,'providerId':_0x439ba5,'_tokenResponse':_0x3695e4,'operationType':_0x2cfc2d});}static async['_forOperation'](_0x29ea10,_0x195eaa,_0x28dee6){await _0x29ea10['_updateTokensIfNecessary'](_0x28dee6,!0x0);const _0x2b20f1=Ar(_0x28dee6);return new Be({'user':_0x29ea10,'providerId':_0x2b20f1,'_tokenResponse':_0x28dee6,'operationType':_0x195eaa});}}function Ar(_0x597d6e){return _0x597d6e['providerId']?_0x597d6e['providerId']:'phoneNumber'in _0x597d6e?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x45c167,_0x4b4435,_0x32ec81,_0x4886af){super(_0x4b4435['code'],_0x4b4435['message']),this['operationType']=_0x32ec81,this['user']=_0x4886af,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x45c167['name'],'tenantId':_0x45c167['tenantId']??void 0x0,'_serverResponse':_0x4b4435['customData']['_serverResponse'],'operationType':_0x32ec81};}static['_fromErrorAndOperation'](_0x54d7f9,_0x46b389,_0x220a75,_0x2840e7){return new Rn(_0x54d7f9,_0x46b389,_0x220a75,_0x2840e7);}}function Fa(_0x149d6e,_0x5dc860,_0x21a719,_0xc4f37f){return(_0x5dc860==='reauthenticate'?_0x21a719['_getReauthenticationResolver'](_0x149d6e):_0x21a719['_getIdTokenResponse'](_0x149d6e))['catch'](_0xc7790c=>{throw _0xc7790c['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x149d6e,_0xc7790c,_0x5dc860,_0xc4f37f):_0xc7790c;});}async function jf(_0x4e44f4,_0x510643,_0x398e7a=!0x1){const _0x31ae28=await xt(_0x4e44f4,_0x510643['_linkToIdToken'](_0x4e44f4['auth'],await _0x4e44f4['getIdToken']()),_0x398e7a);return Be['_forOperation'](_0x4e44f4,'link',_0x31ae28);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xef1948,_0x3c4da2,_0x59f53e=!0x1){const {auth:_0x991eac}=_0xef1948;if(H(_0x991eac['app']))return Promise['reject'](se(_0x991eac));const _0x446d10='reauthenticate';try{const _0x33a054=await xt(_0xef1948,Fa(_0x991eac,_0x446d10,_0x3c4da2,_0xef1948),_0x59f53e);m(_0x33a054['idToken'],_0x991eac,'internal-error');const _0x1697f7=ws(_0x33a054['idToken']);m(_0x1697f7,_0x991eac,'internal-error');const {sub:_0x57fa0f}=_0x1697f7;return m(_0xef1948['uid']===_0x57fa0f,_0x991eac,'user-mismatch'),Be['_forOperation'](_0xef1948,_0x446d10,_0x33a054);}catch(_0x27bc0a){throw(_0x27bc0a==null?void 0x0:_0x27bc0a['code'])==='auth/user-not-found'&&K(_0x991eac,'user-mismatch'),_0x27bc0a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x2594bc,_0x1aac49,_0x548304=!0x1){if(H(_0x2594bc['app']))return Promise['reject'](se(_0x2594bc));const _0x561fd2='signIn',_0x335e7d=await Fa(_0x2594bc,_0x561fd2,_0x1aac49),_0xdf92b3=await Be['_fromIdTokenResponse'](_0x2594bc,_0x561fd2,_0x335e7d);return _0x548304||await _0x2594bc['_updateCurrentUser'](_0xdf92b3['user']),_0xdf92b3;}async function Yf(_0x517f71,_0x4b4f00){return Ua(qe(_0x517f71),_0x4b4f00);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x3e4907){const _0x4af6c6=qe(_0x3e4907);_0x4af6c6['_getPasswordPolicyInternal']()&&await _0x4af6c6['_updatePasswordPolicy']();}async function R_(_0x1d0ba5,_0x176c49,_0x34fb16){if(H(_0x1d0ba5['app']))return Promise['reject'](se(_0x1d0ba5));const _0xd28a1f=qe(_0x1d0ba5),_0x5c0a29=await Oi(_0xd28a1f,{'returnSecureToken':!0x0,'email':_0x176c49,'password':_0x34fb16,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x3d264f=>{throw _0x3d264f['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x1d0ba5),_0x3d264f;}),_0x5b6d0d=await Be['_fromIdTokenResponse'](_0xd28a1f,'signIn',_0x5c0a29);return await _0xd28a1f['_updateCurrentUser'](_0x5b6d0d['user']),_0x5b6d0d;}function A_(_0x2733eb,_0x4ebd30,_0x2b5527){return H(_0x2733eb['app'])?Promise['reject'](se(_0x2733eb)):Yf(k(_0x2733eb),ft['credential'](_0x4ebd30,_0x2b5527))['catch'](async _0x538f3a=>{throw _0x538f3a['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x2733eb),_0x538f3a;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x3547d5,_0x46a2b8){return k(_0x3547d5)['setPersistence'](_0x46a2b8);}function Qf(_0x275c01,_0x4ff64f,_0x459534,_0x2a4b81){return k(_0x275c01)['onIdTokenChanged'](_0x4ff64f,_0x459534,_0x2a4b81);}function Jf(_0x327899,_0x2ac656,_0x53c2ca){return k(_0x327899)['beforeAuthStateChanged'](_0x2ac656,_0x53c2ca);}function N_(_0x409afe,_0x4890db,_0x5f6a64,_0x18b244){return k(_0x409afe)['onAuthStateChanged'](_0x4890db,_0x5f6a64,_0x18b244);}function P_(_0x1ad882){return k(_0x1ad882)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x18e734,_0x5658ee){this['storageRetriever']=_0x18e734,this['type']=_0x5658ee;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x30b04a,_0x461413){return this['storage']['setItem'](_0x30b04a,JSON['stringify'](_0x461413)),Promise['resolve']();}['_get'](_0x15f553){const _0x234bdf=this['storage']['getItem'](_0x15f553);return Promise['resolve'](_0x234bdf?JSON['parse'](_0x234bdf):null);}['_remove'](_0x481a0c){return this['storage']['removeItem'](_0x481a0c),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x16d37d,_0x220223)=>this['onStorageEvent'](_0x16d37d,_0x220223),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x19b24c){for(const _0x1f4186 of Object['keys'](this['listeners'])){const _0xb0f350=this['storage']['getItem'](_0x1f4186),_0x235c26=this['localCache'][_0x1f4186];_0xb0f350!==_0x235c26&&_0x19b24c(_0x1f4186,_0x235c26,_0xb0f350);}}['onStorageEvent'](_0x9d9ee3,_0x259c11=!0x1){if(!_0x9d9ee3['key']){this['forAllChangedKeys']((_0xf16c1b,_0x2485dd,_0x557180)=>{this['notifyListeners'](_0xf16c1b,_0x557180);});return;}const _0x57c225=_0x9d9ee3['key'];_0x259c11?this['detachListener']():this['stopPolling']();const _0x19e137=()=>{const _0x541b57=this['storage']['getItem'](_0x57c225);!_0x259c11&&this['localCache'][_0x57c225]===_0x541b57||this['notifyListeners'](_0x57c225,_0x541b57);},_0x20b917=this['storage']['getItem'](_0x57c225);If()&&_0x20b917!==_0x9d9ee3['newValue']&&_0x9d9ee3['newValue']!==_0x9d9ee3['oldValue']?setTimeout(_0x19e137,Zf):_0x19e137();}['notifyListeners'](_0x51e5d3,_0x2f9916){this['localCache'][_0x51e5d3]=_0x2f9916;const _0x22b412=this['listeners'][_0x51e5d3];if(_0x22b412){for(const _0x24bb6e of Array['from'](_0x22b412))_0x24bb6e(_0x2f9916&&JSON['parse'](_0x2f9916));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4eb3e1,_0x1c3ad1,_0x61b0db)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4eb3e1,'oldValue':_0x1c3ad1,'newValue':_0x61b0db}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x52703c,_0x203668){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x52703c]||(this['listeners'][_0x52703c]=new Set(),this['localCache'][_0x52703c]=this['storage']['getItem'](_0x52703c)),this['listeners'][_0x52703c]['add'](_0x203668);}['_removeListener'](_0x387774,_0x4793f9){this['listeners'][_0x387774]&&(this['listeners'][_0x387774]['delete'](_0x4793f9),this['listeners'][_0x387774]['size']===0x0&&delete this['listeners'][_0x387774]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x36a6fc,_0x7003d5){await super['_set'](_0x36a6fc,_0x7003d5),this['localCache'][_0x36a6fc]=JSON['stringify'](_0x7003d5);}async['_get'](_0xdb8d2b){const _0x1ddc39=await super['_get'](_0xdb8d2b);return this['localCache'][_0xdb8d2b]=JSON['stringify'](_0x1ddc39),_0x1ddc39;}async['_remove'](_0x3a6a9d){await super['_remove'](_0x3a6a9d),delete this['localCache'][_0x3a6a9d];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xfa1d77,_0x42ebf9){}['_removeListener'](_0x4466d4,_0x3a5679){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x123a69){return Promise['all'](_0x123a69['map'](async _0x2ade97=>{try{return{'fulfilled':!0x0,'value':await _0x2ade97};}catch(_0x348e2a){return{'fulfilled':!0x1,'reason':_0x348e2a};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x3adaa6){this['eventTarget']=_0x3adaa6,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2e3c2e){const _0x38d933=this['receivers']['find'](_0x4e9fab=>_0x4e9fab['isListeningto'](_0x2e3c2e));if(_0x38d933)return _0x38d933;const _0x2040c8=new jn(_0x2e3c2e);return this['receivers']['push'](_0x2040c8),_0x2040c8;}['isListeningto'](_0x3f0915){return this['eventTarget']===_0x3f0915;}async['handleEvent'](_0x55e91a){const _0x534b59=_0x55e91a,{eventId:_0x5f4dfc,eventType:_0x145bae,data:_0x4a6218}=_0x534b59['data'],_0xbd2a82=this['handlersMap'][_0x145bae];if(!(_0xbd2a82!=null&&_0xbd2a82['size']))return;_0x534b59['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x5f4dfc,'eventType':_0x145bae});const _0x466e9a=Array['from'](_0xbd2a82)['map'](async _0x59c073=>_0x59c073(_0x534b59['origin'],_0x4a6218)),_0x442020=await tp(_0x466e9a);_0x534b59['ports'][0x0]['postMessage']({'status':'done','eventId':_0x5f4dfc,'eventType':_0x145bae,'response':_0x442020});}['_subscribe'](_0x31af34,_0x290122){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x31af34]||(this['handlersMap'][_0x31af34]=new Set()),this['handlersMap'][_0x31af34]['add'](_0x290122);}['_unsubscribe'](_0x47b477,_0xcce65d){this['handlersMap'][_0x47b477]&&_0xcce65d&&this['handlersMap'][_0x47b477]['delete'](_0xcce65d),(!_0xcce65d||this['handlersMap'][_0x47b477]['size']===0x0)&&delete this['handlersMap'][_0x47b477],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x24896b='',_0x3156b6=0xa){let _0x246b8f='';for(let _0x42d985=0x0;_0x42d985<_0x3156b6;_0x42d985++)_0x246b8f+=Math['floor'](Math['random']()*0xa);return _0x24896b+_0x246b8f;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x2f828e){this['target']=_0x2f828e,this['handlers']=new Set();}['removeMessageHandler'](_0x1c53ca){_0x1c53ca['messageChannel']&&(_0x1c53ca['messageChannel']['port1']['removeEventListener']('message',_0x1c53ca['onMessage']),_0x1c53ca['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1c53ca);}async['_send'](_0xbb6fd4,_0x2ce821,_0x1bb546=0x32){const _0x1ca2e4=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1ca2e4)throw new Error('connection_unavailable');let _0x5eb569,_0x957bd4;return new Promise((_0x28d704,_0x1705d4)=>{const _0x126677=bs('',0x14);_0x1ca2e4['port1']['start']();const _0x127214=setTimeout(()=>{_0x1705d4(new Error('unsupported_event'));},_0x1bb546);_0x957bd4={'messageChannel':_0x1ca2e4,'onMessage'(_0x4061bb){const _0x388825=_0x4061bb;if(_0x388825['data']['eventId']===_0x126677)switch(_0x388825['data']['status']){case'ack':clearTimeout(_0x127214),_0x5eb569=setTimeout(()=>{_0x1705d4(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5eb569),_0x28d704(_0x388825['data']['response']);break;default:clearTimeout(_0x127214),clearTimeout(_0x5eb569),_0x1705d4(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x957bd4),_0x1ca2e4['port1']['addEventListener']('message',_0x957bd4['onMessage']),this['target']['postMessage']({'eventType':_0xbb6fd4,'eventId':_0x126677,'data':_0x2ce821},[_0x1ca2e4['port2']]);})['finally'](()=>{_0x957bd4&&this['removeMessageHandler'](_0x957bd4);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x9884d1){X()['location']['href']=_0x9884d1;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x4cd75d;return((_0x4cd75d=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4cd75d['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x3223bb){this['request']=_0x3223bb;}['toPromise'](){return new Promise((_0x453741,_0xc25dd2)=>{this['request']['addEventListener']('success',()=>{_0x453741(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xc25dd2(this['request']['error']);});});}}function Kn(_0x507116,_0x59cbb6){return _0x507116['transaction']([kn],_0x59cbb6?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x1c87b9=indexedDB['deleteDatabase'](qa);return new Jt(_0x1c87b9)['toPromise']();}function ja(){const _0x327556=indexedDB['open'](qa,ap);return new Promise((_0xa6d9e9,_0x31dce1)=>{_0x327556['addEventListener']('error',()=>{_0x31dce1(_0x327556['error']);}),_0x327556['addEventListener']('upgradeneeded',()=>{const _0x53271d=_0x327556['result'];try{_0x53271d['createObjectStore'](kn,{'keyPath':za});}catch(_0x104002){_0x31dce1(_0x104002);}}),_0x327556['addEventListener']('success',async()=>{const _0x369b45=_0x327556['result'];_0x369b45['objectStoreNames']['contains'](kn)?_0xa6d9e9(_0x369b45):(_0x369b45['close'](),await cp(),_0xa6d9e9(await ja()));});});}async function kr(_0x2d5aa6,_0x4ab737,_0x45c5d7){const _0x48aabf=Kn(_0x2d5aa6,!0x0)['put']({[za]:_0x4ab737,'value':_0x45c5d7});return new Jt(_0x48aabf)['toPromise']();}async function lp(_0x2e53cf,_0xd769b4){const _0x3d3418=Kn(_0x2e53cf,!0x1)['get'](_0xd769b4),_0x1c978e=await new Jt(_0x3d3418)['toPromise']();return _0x1c978e===void 0x0?null:_0x1c978e['value'];}function Nr(_0x2bf80d,_0x29040b){const _0x411f5c=Kn(_0x2bf80d,!0x0)['delete'](_0x29040b);return new Jt(_0x411f5c)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x24a0c7){let _0xc03e48=0x0;for(;;)try{const _0x565de6=await this['_openDb']();return await _0x24a0c7(_0x565de6);}catch(_0x278d38){if(_0xc03e48++>up)throw _0x278d38;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x53201a,_0x551a90)=>({'keyProcessed':(await this['_poll']())['includes'](_0x551a90['key'])})),this['receiver']['_subscribe']('ping',async(_0x5d1388,_0x59df87)=>['keyChanged']);}async['initializeSender'](){var _0x3f82c4,_0x106846;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x1cc27a=await this['sender']['_send']('ping',{},0x320);_0x1cc27a&&(_0x3f82c4=_0x1cc27a[0x0])!=null&&_0x3f82c4['fulfilled']&&(_0x106846=_0x1cc27a[0x0])!=null&&_0x106846['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x8ecf5b){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x8ecf5b},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2243db=>{await kr(_0x2243db,An,'1'),await Nr(_0x2243db,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x5ccdcb){this['pendingWrites']++;try{await _0x5ccdcb();}finally{this['pendingWrites']--;}}async['_set'](_0xbf4f4a,_0x5618d7){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x48d185=>kr(_0x48d185,_0xbf4f4a,_0x5618d7)),this['localCache'][_0xbf4f4a]=_0x5618d7,this['notifyServiceWorker'](_0xbf4f4a)));}async['_get'](_0x347de0){const _0x5452ae=await this['_withRetries'](_0x5e30ce=>lp(_0x5e30ce,_0x347de0));return this['localCache'][_0x347de0]=_0x5452ae,_0x5452ae;}async['_remove'](_0x633d5b){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xd837a6=>Nr(_0xd837a6,_0x633d5b)),delete this['localCache'][_0x633d5b],this['notifyServiceWorker'](_0x633d5b)));}async['_poll'](){const _0x3221ca=await this['_withRetries'](_0x43106d=>{const _0x55bdc0=Kn(_0x43106d,!0x1)['getAll']();return new Jt(_0x55bdc0)['toPromise']();});if(!_0x3221ca)return[];if(this['pendingWrites']!==0x0)return[];const _0x3138d0=[],_0x1b8c26=new Set();if(_0x3221ca['length']!==0x0){for(const {fbase_key:_0xa3b3b6,value:_0xff59a5}of _0x3221ca)_0x1b8c26['add'](_0xa3b3b6),JSON['stringify'](this['localCache'][_0xa3b3b6])!==JSON['stringify'](_0xff59a5)&&(this['notifyListeners'](_0xa3b3b6,_0xff59a5),_0x3138d0['push'](_0xa3b3b6));}for(const _0xf91853 of Object['keys'](this['localCache']))this['localCache'][_0xf91853]&&!_0x1b8c26['has'](_0xf91853)&&(this['notifyListeners'](_0xf91853,null),_0x3138d0['push'](_0xf91853));return _0x3138d0;}['notifyListeners'](_0x478770,_0x5c78fe){this['localCache'][_0x478770]=_0x5c78fe;const _0x4b9170=this['listeners'][_0x478770];if(_0x4b9170){for(const _0x334d14 of Array['from'](_0x4b9170))_0x334d14(_0x5c78fe);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3ad91d,_0x235b07){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3ad91d]||(this['listeners'][_0x3ad91d]=new Set(),this['_get'](_0x3ad91d)),this['listeners'][_0x3ad91d]['add'](_0x235b07);}['_removeListener'](_0x17506f,_0x547ad0){this['listeners'][_0x17506f]&&(this['listeners'][_0x17506f]['delete'](_0x547ad0),this['listeners'][_0x17506f]['size']===0x0&&delete this['listeners'][_0x17506f]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x51156a,_0x28c92b){return _0x28c92b?ne(_0x28c92b):(m(_0x51156a['_popupRedirectResolver'],_0x51156a,'argument-error'),_0x51156a['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x227ee0){super('custom','custom'),this['params']=_0x227ee0;}['_getIdTokenResponse'](_0x50270b){return Ze(_0x50270b,this['_buildIdpRequest']());}['_linkToIdToken'](_0xe52d67,_0x2be2ae){return Ze(_0xe52d67,this['_buildIdpRequest'](_0x2be2ae));}['_getReauthenticationResolver'](_0x33c004){return Ze(_0x33c004,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x4ae2a5){const _0x37b6f1={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x4ae2a5&&(_0x37b6f1['idToken']=_0x4ae2a5),_0x37b6f1;}}function pp(_0x1c32f1){return Ua(_0x1c32f1['auth'],new Rs(_0x1c32f1),_0x1c32f1['bypassAuthState']);}function _p(_0x408ebf){const {auth:_0x42abee,user:_0x260ec5}=_0x408ebf;return m(_0x260ec5,_0x42abee,'internal-error'),Kf(_0x260ec5,new Rs(_0x408ebf),_0x408ebf['bypassAuthState']);}async function gp(_0x5803fd){const {auth:_0x373fe5,user:_0xac96d4}=_0x5803fd;return m(_0xac96d4,_0x373fe5,'internal-error'),jf(_0xac96d4,new Rs(_0x5803fd),_0x5803fd['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x27dc2d,_0xbaf020,_0x398967,_0x4e0f41,_0x478323=!0x1){this['auth']=_0x27dc2d,this['resolver']=_0x398967,this['user']=_0x4e0f41,this['bypassAuthState']=_0x478323,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0xbaf020)?_0xbaf020:[_0xbaf020];}['execute'](){return new Promise(async(_0x20bb91,_0x3db2f5)=>{this['pendingPromise']={'resolve':_0x20bb91,'reject':_0x3db2f5};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xe9428e){this['reject'](_0xe9428e);}});}async['onAuthEvent'](_0xb2abb4){const {urlResponse:_0xdf8784,sessionId:_0x250afd,postBody:_0x421a35,tenantId:_0x58403b,error:_0x4f9018,type:_0x2a0bfc}=_0xb2abb4;if(_0x4f9018){this['reject'](_0x4f9018);return;}const _0x570f3d={'auth':this['auth'],'requestUri':_0xdf8784,'sessionId':_0x250afd,'tenantId':_0x58403b||void 0x0,'postBody':_0x421a35||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2a0bfc)(_0x570f3d));}catch(_0x1a6ec6){this['reject'](_0x1a6ec6);}}['onError'](_0x52af23){this['reject'](_0x52af23);}['getIdpTask'](_0x5290cd){switch(_0x5290cd){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x1ab750){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1ab750),this['unregisterAndCleanUp']();}['reject'](_0x2ddea6){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2ddea6),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x431d56,_0x32fd3e,_0x2894e1,_0x42612a,_0x5b41a1){super(_0x431d56,_0x32fd3e,_0x42612a,_0x5b41a1),this['provider']=_0x2894e1,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x502a2a=await this['execute']();return m(_0x502a2a,this['auth'],'internal-error'),_0x502a2a;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3e2461=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3e2461),this['authWindow']['associatedEvent']=_0x3e2461,this['resolver']['_originValidation'](this['auth'])['catch'](_0x5c7818=>{this['reject'](_0x5c7818);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1eff40=>{_0x1eff40||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x30cfec;return((_0x30cfec=this['authWindow'])==null?void 0x0:_0x30cfec['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x39e4d0=()=>{var _0xba4ff8,_0x2417dd;if((_0x2417dd=(_0xba4ff8=this['authWindow'])==null?void 0x0:_0xba4ff8['window'])!=null&&_0x2417dd['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x39e4d0,mp['get']());};_0x39e4d0();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x3bfe6a,_0x37943e,_0x35a4df=!0x1){super(_0x3bfe6a,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x37943e,void 0x0,_0x35a4df),this['eventId']=null;}async['execute'](){let _0x3118d8=rn['get'](this['auth']['_key']());if(!_0x3118d8){try{const _0x2d42a1=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x3118d8=()=>Promise['resolve'](_0x2d42a1);}catch(_0x31e798){_0x3118d8=()=>Promise['reject'](_0x31e798);}rn['set'](this['auth']['_key'](),_0x3118d8);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3118d8();}async['onAuthEvent'](_0x4850e8){if(_0x4850e8['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4850e8);if(_0x4850e8['type']==='unknown'){this['resolve'](null);return;}if(_0x4850e8['eventId']){const _0x105f00=await this['auth']['_redirectUserForId'](_0x4850e8['eventId']);if(_0x105f00)return this['user']=_0x105f00,super['onAuthEvent'](_0x4850e8);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0xc9e669,_0x255486){const _0xce5d4b=Cp(_0x255486),_0x50356f=wp(_0xc9e669);if(!await _0x50356f['_isAvailable']())return!0x1;const _0x52ed68=await _0x50356f['_get'](_0xce5d4b)==='true';return await _0x50356f['_remove'](_0xce5d4b),_0x52ed68;}function Ip(_0x769e,_0xc8b8ab){rn['set'](_0x769e['_key'](),_0xc8b8ab);}function wp(_0x24b1e7){return ne(_0x24b1e7['_redirectPersistence']);}function Cp(_0x31c9eb){return sn(yp,_0x31c9eb['config']['apiKey'],_0x31c9eb['name']);}async function Tp(_0x2891fa,_0x20b4d6,_0x4f5f7f=!0x1){if(H(_0x2891fa['app']))return Promise['reject'](se(_0x2891fa));const _0x3f642d=qe(_0x2891fa),_0x2fcfea=fp(_0x3f642d,_0x20b4d6),_0x57b2b1=await new vp(_0x3f642d,_0x2fcfea,_0x4f5f7f)['execute']();return _0x57b2b1&&!_0x4f5f7f&&(delete _0x57b2b1['user']['_redirectEventId'],await _0x3f642d['_persistUserIfCurrent'](_0x57b2b1['user']),await _0x3f642d['_setRedirectUser'](null,_0x20b4d6)),_0x57b2b1;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x55eaae){this['auth']=_0x55eaae,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x11e6b6){this['consumers']['add'](_0x11e6b6),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x11e6b6)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x11e6b6),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x50e37c){this['consumers']['delete'](_0x50e37c);}['onEvent'](_0x21fa0c){if(this['hasEventBeenHandled'](_0x21fa0c))return!0x1;let _0x39a502=!0x1;return this['consumers']['forEach'](_0x20a6af=>{this['isEventForConsumer'](_0x21fa0c,_0x20a6af)&&(_0x39a502=!0x0,this['sendToConsumer'](_0x21fa0c,_0x20a6af),this['saveEventToCache'](_0x21fa0c));}),this['hasHandledPotentialRedirect']||!Rp(_0x21fa0c)||(this['hasHandledPotentialRedirect']=!0x0,_0x39a502||(this['queuedRedirectEvent']=_0x21fa0c,_0x39a502=!0x0)),_0x39a502;}['sendToConsumer'](_0x4e9165,_0x1a823b){var _0x285d59;if(_0x4e9165['error']&&!Qa(_0x4e9165)){const _0x31ae7c=((_0x285d59=_0x4e9165['error']['code'])==null?void 0x0:_0x285d59['split']('auth/')[0x1])||'internal-error';_0x1a823b['onError'](J(this['auth'],_0x31ae7c));}else _0x1a823b['onAuthEvent'](_0x4e9165);}['isEventForConsumer'](_0x1dd703,_0x3a76a1){const _0x820103=_0x3a76a1['eventId']===null||!!_0x1dd703['eventId']&&_0x1dd703['eventId']===_0x3a76a1['eventId'];return _0x3a76a1['filter']['includes'](_0x1dd703['type'])&&_0x820103;}['hasEventBeenHandled'](_0x31a970){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x31a970));}['saveEventToCache'](_0x7fa30a){this['cachedEventUids']['add'](Pr(_0x7fa30a)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x5df7ad){return[_0x5df7ad['type'],_0x5df7ad['eventId'],_0x5df7ad['sessionId'],_0x5df7ad['tenantId']]['filter'](_0x258e7c=>_0x258e7c)['join']('-');}function Qa({type:_0x5a8ab6,error:_0x19fb93}){return _0x5a8ab6==='unknown'&&(_0x19fb93==null?void 0x0:_0x19fb93['code'])==='auth/no-auth-event';}function Rp(_0x5df2cc){switch(_0x5df2cc['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x5df2cc);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x4d8ab5,_0x2b3978={}){return Ae(_0x4d8ab5,'GET','/v1/projects',_0x2b3978);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x4a6d15){if(_0x4a6d15['config']['emulator'])return;const {authorizedDomains:_0x38447c}=await Ap(_0x4a6d15);for(const _0x414b01 of _0x38447c)try{if(Op(_0x414b01))return;}catch{}K(_0x4a6d15,'unauthorized-domain');}function Op(_0x45c8fb){const _0x4999d3=Ni(),{protocol:_0x329fc2,hostname:_0x440980}=new URL(_0x4999d3);if(_0x45c8fb['startsWith']('chrome-extension://')){const _0x133989=new URL(_0x45c8fb);return _0x133989['hostname']===''&&_0x440980===''?_0x329fc2==='chrome-extension:'&&_0x45c8fb['replace']('chrome-extension://','')===_0x4999d3['replace']('chrome-extension://',''):_0x329fc2==='chrome-extension:'&&_0x133989['hostname']===_0x440980;}if(!Np['test'](_0x329fc2))return!0x1;if(kp['test'](_0x45c8fb))return _0x440980===_0x45c8fb;const _0x4fadda=_0x45c8fb['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x4fadda+'|'+_0x4fadda+')$','i')['test'](_0x440980);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x2fdbef=X()['___jsl'];if(_0x2fdbef!=null&&_0x2fdbef['H']){for(const _0x3d15f5 of Object['keys'](_0x2fdbef['H']))if(_0x2fdbef['H'][_0x3d15f5]['r']=_0x2fdbef['H'][_0x3d15f5]['r']||[],_0x2fdbef['H'][_0x3d15f5]['L']=_0x2fdbef['H'][_0x3d15f5]['L']||[],_0x2fdbef['H'][_0x3d15f5]['r']=[..._0x2fdbef['H'][_0x3d15f5]['L']],_0x2fdbef['CP']){for(let _0x139a81=0x0;_0x139a81<_0x2fdbef['CP']['length'];_0x139a81++)_0x2fdbef['CP'][_0x139a81]=null;}}}function Mp(_0x4f8949){return new Promise((_0xb795c3,_0x121ded)=>{var _0x304987,_0xbd7059,_0x27858f;function _0x2a3f45(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0xb795c3(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x121ded(J(_0x4f8949,'network-request-failed'));},'timeout':Dp['get']()});}if((_0xbd7059=(_0x304987=X()['gapi'])==null?void 0x0:_0x304987['iframes'])!=null&&_0xbd7059['Iframe'])_0xb795c3(gapi['iframes']['getContext']());else{if((_0x27858f=X()['gapi'])!=null&&_0x27858f['load'])_0x2a3f45();else{const _0x53c46f=Nf('iframefcb');return X()[_0x53c46f]=()=>{gapi['load']?_0x2a3f45():_0x121ded(J(_0x4f8949,'network-request-failed'));},Da(kf()+'?onload='+_0x53c46f)['catch'](_0x49df7f=>_0x121ded(_0x49df7f));}}})['catch'](_0x9205d3=>{throw on=null,_0x9205d3;});}let on=null;function Lp(_0x23faf9){return on=on||Mp(_0x23faf9),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x156ef9){const _0x203b35=_0x156ef9['config'];m(_0x203b35['authDomain'],_0x156ef9,'auth-domain-config-required');const _0x5828e6=_0x203b35['emulator']?Is(_0x203b35,Up):'https://'+_0x156ef9['config']['authDomain']+'/'+Fp,_0x49ebc9={'apiKey':_0x203b35['apiKey'],'appName':_0x156ef9['name'],'v':ct},_0x3492ee=Bp['get'](_0x156ef9['config']['apiHost']);_0x3492ee&&(_0x49ebc9['eid']=_0x3492ee);const _0x3cdb6a=_0x156ef9['_getFrameworks']();return _0x3cdb6a['length']&&(_0x49ebc9['fw']=_0x3cdb6a['join'](',')),_0x5828e6+'?'+at(_0x49ebc9)['slice'](0x1);}async function Hp(_0x4e37df){const _0x454f59=await Lp(_0x4e37df),_0x4f677b=X()['gapi'];return m(_0x4f677b,_0x4e37df,'internal-error'),_0x454f59['open']({'where':document['body'],'url':Vp(_0x4e37df),'messageHandlersFilter':_0x4f677b['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x3075e6=>new Promise(async(_0x4ba956,_0x335a21)=>{await _0x3075e6['restyle']({'setHideOnLeave':!0x1});const _0x28ee8c=J(_0x4e37df,'network-request-failed'),_0x19b3ba=X()['setTimeout'](()=>{_0x335a21(_0x28ee8c);},xp['get']());function _0x40d0a7(){X()['clearTimeout'](_0x19b3ba),_0x4ba956(_0x3075e6);}_0x3075e6['ping'](_0x40d0a7)['then'](_0x40d0a7,()=>{_0x335a21(_0x28ee8c);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x451e30){this['window']=_0x451e30,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x496586,_0x3597e9,_0xa380be,_0x172031=Gp,_0x41c049=qp){const _0x464446=Math['max']((window['screen']['availHeight']-_0x41c049)/0x2,0x0)['toString'](),_0xc873b6=Math['max']((window['screen']['availWidth']-_0x172031)/0x2,0x0)['toString']();let _0x12a5cd='';const _0x2b5cdc={...$p,'width':_0x172031['toString'](),'height':_0x41c049['toString'](),'top':_0x464446,'left':_0xc873b6},_0x43dc45=W()['toLowerCase']();_0xa380be&&(_0x12a5cd=ba(_0x43dc45)?zp:_0xa380be),Ta(_0x43dc45)&&(_0x3597e9=_0x3597e9||jp,_0x2b5cdc['scrollbars']='yes');const _0x8da859=Object['entries'](_0x2b5cdc)['reduce']((_0x135644,[_0x4d0d18,_0x29b647])=>''+_0x135644+_0x4d0d18+'='+_0x29b647+',','');if(Ef(_0x43dc45)&&_0x12a5cd!=='_self')return Yp(_0x3597e9||'',_0x12a5cd),new Dr(null);const _0x5b668e=window['open'](_0x3597e9||'',_0x12a5cd,_0x8da859);m(_0x5b668e,_0x496586,'popup-blocked');try{_0x5b668e['focus']();}catch{}return new Dr(_0x5b668e);}function Yp(_0xb1bbd2,_0x24cb5c){const _0x4500e5=document['createElement']('a');_0x4500e5['href']=_0xb1bbd2,_0x4500e5['target']=_0x24cb5c;const _0x18be82=document['createEvent']('MouseEvent');_0x18be82['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x4500e5['dispatchEvent'](_0x18be82);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x8d1453,_0x3911d8,_0x240a01,_0x2b9b77,_0x5c72a3,_0x566113){m(_0x8d1453['config']['authDomain'],_0x8d1453,'auth-domain-config-required'),m(_0x8d1453['config']['apiKey'],_0x8d1453,'invalid-api-key');const _0x44075c={'apiKey':_0x8d1453['config']['apiKey'],'appName':_0x8d1453['name'],'authType':_0x240a01,'redirectUrl':_0x2b9b77,'v':ct,'eventId':_0x5c72a3};if(_0x3911d8 instanceof xa){_0x3911d8['setDefaultLanguage'](_0x8d1453['languageCode']),_0x44075c['providerId']=_0x3911d8['providerId']||'',hi(_0x3911d8['getCustomParameters']())||(_0x44075c['customParameters']=JSON['stringify'](_0x3911d8['getCustomParameters']()));for(const [_0x1c0744,_0x4c971c]of Object['entries']({}))_0x44075c[_0x1c0744]=_0x4c971c;}if(_0x3911d8 instanceof Qt){const _0x3f1a35=_0x3911d8['getScopes']()['filter'](_0x5655f2=>_0x5655f2!=='');_0x3f1a35['length']>0x0&&(_0x44075c['scopes']=_0x3f1a35['join'](','));}_0x8d1453['tenantId']&&(_0x44075c['tid']=_0x8d1453['tenantId']);const _0x56224a=_0x44075c;for(const _0x3b5c7f of Object['keys'](_0x56224a))_0x56224a[_0x3b5c7f]===void 0x0&&delete _0x56224a[_0x3b5c7f];const _0x2ec4be=await _0x8d1453['_getAppCheckToken'](),_0x34f6ae=_0x2ec4be?'#'+Xp+'='+encodeURIComponent(_0x2ec4be):'';return Zp(_0x8d1453)+'?'+at(_0x56224a)['slice'](0x1)+_0x34f6ae;}function Zp({config:_0x220aac}){return _0x220aac['emulator']?Is(_0x220aac,Jp):'https://'+_0x220aac['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x267b50,_0x13cc14,_0x48b2c0,_0x12fc45){var _0x3d4cb1;ae((_0x3d4cb1=this['eventManagers'][_0x267b50['_key']()])==null?void 0x0:_0x3d4cb1['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2efcc5=await Mr(_0x267b50,_0x13cc14,_0x48b2c0,Ni(),_0x12fc45);return Kp(_0x267b50,_0x2efcc5,bs());}async['_openRedirect'](_0x3b0a74,_0x6ffd45,_0x1a2876,_0x448569){await this['_originValidation'](_0x3b0a74);const _0x4a7093=await Mr(_0x3b0a74,_0x6ffd45,_0x1a2876,Ni(),_0x448569);return ip(_0x4a7093),new Promise(()=>{});}['_initialize'](_0xe7271a){const _0x4ccf36=_0xe7271a['_key']();if(this['eventManagers'][_0x4ccf36]){const {manager:_0x58b2de,promise:_0x5c4214}=this['eventManagers'][_0x4ccf36];return _0x58b2de?Promise['resolve'](_0x58b2de):(ae(_0x5c4214,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5c4214);}const _0x4911b8=this['initAndGetManager'](_0xe7271a);return this['eventManagers'][_0x4ccf36]={'promise':_0x4911b8},_0x4911b8['catch'](()=>{delete this['eventManagers'][_0x4ccf36];}),_0x4911b8;}async['initAndGetManager'](_0x484980){const _0x586975=await Hp(_0x484980),_0x4ebcac=new bp(_0x484980);return _0x586975['register']('authEvent',_0x36fed1=>(m(_0x36fed1==null?void 0x0:_0x36fed1['authEvent'],_0x484980,'invalid-auth-event'),{'status':_0x4ebcac['onEvent'](_0x36fed1['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x484980['_key']()]={'manager':_0x4ebcac},this['iframes'][_0x484980['_key']()]=_0x586975,_0x4ebcac;}['_isIframeWebStorageSupported'](_0x551eb5,_0x204d4e){this['iframes'][_0x551eb5['_key']()]['send'](li,{'type':li},_0x11d849=>{var _0x3c9464;const _0x526f33=(_0x3c9464=_0x11d849==null?void 0x0:_0x11d849[0x0])==null?void 0x0:_0x3c9464[li];_0x526f33!==void 0x0&&_0x204d4e(!!_0x526f33),K(_0x551eb5,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1e9d42){const _0x309707=_0x1e9d42['_key']();return this['originValidationPromises'][_0x309707]||(this['originValidationPromises'][_0x309707]=Pp(_0x1e9d42)),this['originValidationPromises'][_0x309707];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x15a79e){this['auth']=_0x15a79e,this['internalListeners']=new Map();}['getUid'](){var _0x47df13;return this['assertAuthConfigured'](),((_0x47df13=this['auth']['currentUser'])==null?void 0x0:_0x47df13['uid'])||null;}async['getToken'](_0x2aac63){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2aac63)}:null;}['addAuthTokenListener'](_0x520df2){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x520df2))return;const _0x512860=this['auth']['onIdTokenChanged'](_0x26a069=>{_0x520df2((_0x26a069==null?void 0x0:_0x26a069['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x520df2,_0x512860),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x32f881){this['assertAuthConfigured']();const _0x1b7518=this['internalListeners']['get'](_0x32f881);_0x1b7518&&(this['internalListeners']['delete'](_0x32f881),_0x1b7518(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x8dee74){switch(_0x8dee74){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x359d07){et(new Me('auth',(_0x69e6e1,{options:_0x53ccbb})=>{const _0x2ea2bb=_0x69e6e1['getProvider']('app')['getImmediate'](),_0x35b8a5=_0x69e6e1['getProvider']('heartbeat'),_0x5cac28=_0x69e6e1['getProvider']('app-check-internal'),{apiKey:_0x431783,authDomain:_0x43652d}=_0x2ea2bb['options'];m(_0x431783&&!_0x431783['includes'](':'),'invalid-api-key',{'appName':_0x2ea2bb['name']});const _0x1570b0={'apiKey':_0x431783,'authDomain':_0x43652d,'clientPlatform':_0x359d07,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x359d07)},_0x15f616=new bf(_0x2ea2bb,_0x35b8a5,_0x5cac28,_0x1570b0);return Lf(_0x15f616,_0x53ccbb),_0x15f616;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0xcebd17,_0x3c2567,_0x5dd1c3)=>{_0xcebd17['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x1fc751=>{const _0x1d0a30=qe(_0x1fc751['getProvider']('auth')['getImmediate']());return(_0x21bdfd=>new n_(_0x21bdfd))(_0x1d0a30);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x359d07)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x521972=>async _0x31698e=>{const _0x593e69=_0x31698e&&await _0x31698e['getIdTokenResult'](),_0x5ad8f8=_0x593e69&&(new Date()['getTime']()-Date['parse'](_0x593e69['issuedAtTime']))/0x3e8;if(_0x5ad8f8&&_0x5ad8f8>o_)return;const _0x2a2685=_0x593e69==null?void 0x0:_0x593e69['token'];Fr!==_0x2a2685&&(Fr=_0x2a2685,await fetch(_0x521972,{'method':_0x2a2685?'POST':'DELETE','headers':_0x2a2685?{'Authorization':'Bearer\x20'+_0x2a2685}:{}}));};function O_(_0x1efbc5=Qr()){const _0x2c464f=Ui(_0x1efbc5,'auth');if(_0x2c464f['isInitialized']())return _0x2c464f['getImmediate']();const _0x83d798=Mf(_0x1efbc5,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x1041a8=Gr('authTokenSyncURL');if(_0x1041a8&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x51bdf6=new URL(_0x1041a8,location['origin']);if(location['origin']===_0x51bdf6['origin']){const _0xad55a1=a_(_0x51bdf6['toString']());Jf(_0x83d798,_0xad55a1,()=>_0xad55a1(_0x83d798['currentUser'])),Qf(_0x83d798,_0x14ab7c=>_0xad55a1(_0x14ab7c));}}const _0xaca1a3=Hr('auth');return _0xaca1a3&&xf(_0x83d798,'http://'+_0xaca1a3),_0x83d798;}function c_(){var _0x542794;return((_0x542794=document['getElementsByTagName']('head'))==null?void 0x0:_0x542794[0x0])??document;}Rf({'loadJS'(_0x2fb908){return new Promise((_0x4bf08c,_0x2019a5)=>{const _0x3bfa60=document['createElement']('script');_0x3bfa60['setAttribute']('src',_0x2fb908),_0x3bfa60['onload']=_0x4bf08c,_0x3bfa60['onerror']=_0x1a1894=>{const _0x548ae2=J('internal-error');_0x548ae2['customData']=_0x1a1894,_0x2019a5(_0x548ae2);},_0x3bfa60['type']='text/javascript',_0x3bfa60['charset']='UTF-8',c_()['appendChild'](_0x3bfa60);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};