const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4ec5ca,_0x2f8873){if(!_0x4ec5ca)throw ot(_0x2f8873);},ot=function(_0x277494){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x277494);},Wr=function(_0x2430b0){const _0x417e1c=[];let _0x130164=0x0;for(let _0x28cfd5=0x0;_0x28cfd5<_0x2430b0['length'];_0x28cfd5++){let _0x1a39ca=_0x2430b0['charCodeAt'](_0x28cfd5);_0x1a39ca<0x80?_0x417e1c[_0x130164++]=_0x1a39ca:_0x1a39ca<0x800?(_0x417e1c[_0x130164++]=_0x1a39ca>>0x6|0xc0,_0x417e1c[_0x130164++]=_0x1a39ca&0x3f|0x80):(_0x1a39ca&0xfc00)===0xd800&&_0x28cfd5+0x1<_0x2430b0['length']&&(_0x2430b0['charCodeAt'](_0x28cfd5+0x1)&0xfc00)===0xdc00?(_0x1a39ca=0x10000+((_0x1a39ca&0x3ff)<<0xa)+(_0x2430b0['charCodeAt'](++_0x28cfd5)&0x3ff),_0x417e1c[_0x130164++]=_0x1a39ca>>0x12|0xf0,_0x417e1c[_0x130164++]=_0x1a39ca>>0xc&0x3f|0x80,_0x417e1c[_0x130164++]=_0x1a39ca>>0x6&0x3f|0x80,_0x417e1c[_0x130164++]=_0x1a39ca&0x3f|0x80):(_0x417e1c[_0x130164++]=_0x1a39ca>>0xc|0xe0,_0x417e1c[_0x130164++]=_0x1a39ca>>0x6&0x3f|0x80,_0x417e1c[_0x130164++]=_0x1a39ca&0x3f|0x80);}return _0x417e1c;},Za=function(_0x5ed743){const _0x3b66b9=[];let _0x2db7f7=0x0,_0x4aabbd=0x0;for(;_0x2db7f7<_0x5ed743['length'];){const _0x3d2063=_0x5ed743[_0x2db7f7++];if(_0x3d2063<0x80)_0x3b66b9[_0x4aabbd++]=String['fromCharCode'](_0x3d2063);else{if(_0x3d2063>0xbf&&_0x3d2063<0xe0){const _0x3f89d8=_0x5ed743[_0x2db7f7++];_0x3b66b9[_0x4aabbd++]=String['fromCharCode']((_0x3d2063&0x1f)<<0x6|_0x3f89d8&0x3f);}else{if(_0x3d2063>0xef&&_0x3d2063<0x16d){const _0x336bc0=_0x5ed743[_0x2db7f7++],_0x309576=_0x5ed743[_0x2db7f7++],_0x11c2f1=_0x5ed743[_0x2db7f7++],_0x4c2cbe=((_0x3d2063&0x7)<<0x12|(_0x336bc0&0x3f)<<0xc|(_0x309576&0x3f)<<0x6|_0x11c2f1&0x3f)-0x10000;_0x3b66b9[_0x4aabbd++]=String['fromCharCode'](0xd800+(_0x4c2cbe>>0xa)),_0x3b66b9[_0x4aabbd++]=String['fromCharCode'](0xdc00+(_0x4c2cbe&0x3ff));}else{const _0x29e69e=_0x5ed743[_0x2db7f7++],_0x1cdb45=_0x5ed743[_0x2db7f7++];_0x3b66b9[_0x4aabbd++]=String['fromCharCode']((_0x3d2063&0xf)<<0xc|(_0x29e69e&0x3f)<<0x6|_0x1cdb45&0x3f);}}}}return _0x3b66b9['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x294f3a,_0x5d2dc8){if(!Array['isArray'](_0x294f3a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1f8045=_0x5d2dc8?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3e013b=[];for(let _0x2383cc=0x0;_0x2383cc<_0x294f3a['length'];_0x2383cc+=0x3){const _0x43301d=_0x294f3a[_0x2383cc],_0x5c39b4=_0x2383cc+0x1<_0x294f3a['length'],_0x30a6ec=_0x5c39b4?_0x294f3a[_0x2383cc+0x1]:0x0,_0x4a8282=_0x2383cc+0x2<_0x294f3a['length'],_0x510881=_0x4a8282?_0x294f3a[_0x2383cc+0x2]:0x0,_0x1c52b6=_0x43301d>>0x2,_0x2c0f21=(_0x43301d&0x3)<<0x4|_0x30a6ec>>0x4;let _0xf782e1=(_0x30a6ec&0xf)<<0x2|_0x510881>>0x6,_0x36c2f9=_0x510881&0x3f;_0x4a8282||(_0x36c2f9=0x40,_0x5c39b4||(_0xf782e1=0x40)),_0x3e013b['push'](_0x1f8045[_0x1c52b6],_0x1f8045[_0x2c0f21],_0x1f8045[_0xf782e1],_0x1f8045[_0x36c2f9]);}return _0x3e013b['join']('');},'encodeString'(_0x34f83b,_0x462893){return this['HAS_NATIVE_SUPPORT']&&!_0x462893?btoa(_0x34f83b):this['encodeByteArray'](Wr(_0x34f83b),_0x462893);},'decodeString'(_0x4ada18,_0x48f3d6){return this['HAS_NATIVE_SUPPORT']&&!_0x48f3d6?atob(_0x4ada18):Za(this['decodeStringToByteArray'](_0x4ada18,_0x48f3d6));},'decodeStringToByteArray'(_0x16fbbd,_0xd8c64d){this['init_']();const _0x37c958=_0xd8c64d?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x52bfb6=[];for(let _0x340599=0x0;_0x340599<_0x16fbbd['length'];){const _0x1e0a2c=_0x37c958[_0x16fbbd['charAt'](_0x340599++)],_0x20ad5d=_0x340599<_0x16fbbd['length']?_0x37c958[_0x16fbbd['charAt'](_0x340599)]:0x0;++_0x340599;const _0x47f434=_0x340599<_0x16fbbd['length']?_0x37c958[_0x16fbbd['charAt'](_0x340599)]:0x40;++_0x340599;const _0xada1b0=_0x340599<_0x16fbbd['length']?_0x37c958[_0x16fbbd['charAt'](_0x340599)]:0x40;if(++_0x340599,_0x1e0a2c==null||_0x20ad5d==null||_0x47f434==null||_0xada1b0==null)throw new ec();const _0x2fe14c=_0x1e0a2c<<0x2|_0x20ad5d>>0x4;if(_0x52bfb6['push'](_0x2fe14c),_0x47f434!==0x40){const _0x4dfaa4=_0x20ad5d<<0x4&0xf0|_0x47f434>>0x2;if(_0x52bfb6['push'](_0x4dfaa4),_0xada1b0!==0x40){const _0x3fe1a6=_0x47f434<<0x6&0xc0|_0xada1b0;_0x52bfb6['push'](_0x3fe1a6);}}}return _0x52bfb6;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x30a179=0x0;_0x30a179<this['ENCODED_VALS']['length'];_0x30a179++)this['byteToCharMap_'][_0x30a179]=this['ENCODED_VALS']['charAt'](_0x30a179),this['charToByteMap_'][this['byteToCharMap_'][_0x30a179]]=_0x30a179,this['byteToCharMapWebSafe_'][_0x30a179]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x30a179),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x30a179]]=_0x30a179,_0x30a179>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x30a179)]=_0x30a179,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x30a179)]=_0x30a179);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0xdd583d){const _0x58cfbb=Wr(_0xdd583d);return Di['encodeByteArray'](_0x58cfbb,!0x0);},an=function(_0x5bb291){return Br(_0x5bb291)['replace'](/\./g,'');},cn=function(_0x3efe99){try{return Di['decodeString'](_0x3efe99,!0x0);}catch(_0x136fcd){console['error']('base64Decode\x20failed:\x20',_0x136fcd);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x4d376b){return Vr(void 0x0,_0x4d376b);}function Vr(_0xb8a0c5,_0x5dc58d){if(!(_0x5dc58d instanceof Object))return _0x5dc58d;switch(_0x5dc58d['constructor']){case Date:const _0x364d72=_0x5dc58d;return new Date(_0x364d72['getTime']());case Object:_0xb8a0c5===void 0x0&&(_0xb8a0c5={});break;case Array:_0xb8a0c5=[];break;default:return _0x5dc58d;}for(const _0x2b55a0 in _0x5dc58d)!_0x5dc58d['hasOwnProperty'](_0x2b55a0)||!nc(_0x2b55a0)||(_0xb8a0c5[_0x2b55a0]=Vr(_0xb8a0c5[_0x2b55a0],_0x5dc58d[_0x2b55a0]));return _0xb8a0c5;}function nc(_0x4cdafb){return _0x4cdafb!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x1ff6fa=As['__FIREBASE_DEFAULTS__'];if(_0x1ff6fa)return JSON['parse'](_0x1ff6fa);},oc=()=>{if(typeof document>'u')return;let _0x3a74b2;try{_0x3a74b2=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x33267=_0x3a74b2&&cn(_0x3a74b2[0x1]);return _0x33267&&JSON['parse'](_0x33267);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x252179){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x252179);return;}},Hr=_0x4aae82=>{var _0x13bba4,_0x15fa4b;return(_0x15fa4b=(_0x13bba4=Mi())==null?void 0x0:_0x13bba4['emulatorHosts'])==null?void 0x0:_0x15fa4b[_0x4aae82];},ac=_0x42c1a9=>{const _0x3954d7=Hr(_0x42c1a9);if(!_0x3954d7)return;const _0x2807ed=_0x3954d7['lastIndexOf'](':');if(_0x2807ed<=0x0||_0x2807ed+0x1===_0x3954d7['length'])throw new Error('Invalid\x20host\x20'+_0x3954d7+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x439135=parseInt(_0x3954d7['substring'](_0x2807ed+0x1),0xa);return _0x3954d7[0x0]==='['?[_0x3954d7['substring'](0x1,_0x2807ed-0x1),_0x439135]:[_0x3954d7['substring'](0x0,_0x2807ed),_0x439135];},$r=()=>{var _0x2f5523;return(_0x2f5523=Mi())==null?void 0x0:_0x2f5523['config'];},Gr=_0x5df9cc=>{var _0x137978;return(_0x137978=Mi())==null?void 0x0:_0x137978['_'+_0x5df9cc];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3b155a,_0x3c9674)=>{this['resolve']=_0x3b155a,this['reject']=_0x3c9674;});}['wrapCallback'](_0x342aea){return(_0x4eb456,_0x573aa1)=>{_0x4eb456?this['reject'](_0x4eb456):this['resolve'](_0x573aa1),typeof _0x342aea=='function'&&(this['promise']['catch'](()=>{}),_0x342aea['length']===0x1?_0x342aea(_0x4eb456):_0x342aea(_0x4eb456,_0x573aa1));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0xc138b5,_0x38dd72){if(_0xc138b5['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x342c14={'alg':'none','type':'JWT'},_0xaf2516=_0x38dd72||'demo-project',_0x290551=_0xc138b5['iat']||0x0,_0x105b03=_0xc138b5['sub']||_0xc138b5['user_id'];if(!_0x105b03)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x4fdc89={'iss':'https://securetoken.google.com/'+_0xaf2516,'aud':_0xaf2516,'iat':_0x290551,'exp':_0x290551+0xe10,'auth_time':_0x290551,'sub':_0x105b03,'user_id':_0x105b03,'firebase':{'sign_in_provider':'custom','identities':{}},..._0xc138b5};return[an(JSON['stringify'](_0x342c14)),an(JSON['stringify'](_0x4fdc89)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x449cd6=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x449cd6=='object'&&_0x449cd6['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x2fd2aa=W();return _0x2fd2aa['indexOf']('MSIE\x20')>=0x0||_0x2fd2aa['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x81d0d8,_0x288550)=>{try{let _0x5a8a1c=!0x0;const _0x3d4014='validate-browser-context-for-indexeddb-analytics-module',_0x37c156=self['indexedDB']['open'](_0x3d4014);_0x37c156['onsuccess']=()=>{_0x37c156['result']['close'](),_0x5a8a1c||self['indexedDB']['deleteDatabase'](_0x3d4014),_0x81d0d8(!0x0);},_0x37c156['onupgradeneeded']=()=>{_0x5a8a1c=!0x1;},_0x37c156['onerror']=()=>{var _0x4dc8f0;_0x288550(((_0x4dc8f0=_0x37c156['error'])==null?void 0x0:_0x4dc8f0['message'])||'');};}catch(_0x1d1d1a){_0x288550(_0x1d1d1a);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x51fbb6,_0x1525ff,_0x2c9d73){super(_0x1525ff),this['code']=_0x51fbb6,this['customData']=_0x2c9d73,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x33cb39,_0x105f2f,_0x3b6c83){this['service']=_0x33cb39,this['serviceName']=_0x105f2f,this['errors']=_0x3b6c83;}['create'](_0x1090a2,..._0x5ce3e8){const _0x40b46d=_0x5ce3e8[0x0]||{},_0x1a2e7b=this['service']+'/'+_0x1090a2,_0x415e74=this['errors'][_0x1090a2],_0x51b3b3=_0x415e74?gc(_0x415e74,_0x40b46d):'Error',_0x1fc121=this['serviceName']+':\x20'+_0x51b3b3+'\x20('+_0x1a2e7b+').';return new Se(_0x1a2e7b,_0x1fc121,_0x40b46d);}}function gc(_0x32da56,_0x56f214){return _0x32da56['replace'](mc,(_0x2f568e,_0x3d54a7)=>{const _0x76d2b7=_0x56f214[_0x3d54a7];return _0x76d2b7!=null?String(_0x76d2b7):'<'+_0x3d54a7+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x70e12f){return JSON['parse'](_0x70e12f);}function O(_0x59cf0b){return JSON['stringify'](_0x59cf0b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x55e283){let _0xd88b5d={},_0x2854a3={},_0x280f7d={},_0x45e726='';try{const _0xea0d06=_0x55e283['split']('.');_0xd88b5d=bt(cn(_0xea0d06[0x0])||''),_0x2854a3=bt(cn(_0xea0d06[0x1])||''),_0x45e726=_0xea0d06[0x2],_0x280f7d=_0x2854a3['d']||{},delete _0x2854a3['d'];}catch{}return{'header':_0xd88b5d,'claims':_0x2854a3,'data':_0x280f7d,'signature':_0x45e726};},yc=function(_0x5d2ac8){const _0x46faf1=zr(_0x5d2ac8),_0x194d52=_0x46faf1['claims'];return!!_0x194d52&&typeof _0x194d52=='object'&&_0x194d52['hasOwnProperty']('iat');},vc=function(_0x3ce1a3){const _0x43828c=zr(_0x3ce1a3)['claims'];return typeof _0x43828c=='object'&&_0x43828c['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x56c8ea,_0xf15a5b){return Object['prototype']['hasOwnProperty']['call'](_0x56c8ea,_0xf15a5b);}function Oe(_0x3c15f7,_0x5171ec){if(Object['prototype']['hasOwnProperty']['call'](_0x3c15f7,_0x5171ec))return _0x3c15f7[_0x5171ec];}function hi(_0x31ab13){for(const _0x3fe90f in _0x31ab13)if(Object['prototype']['hasOwnProperty']['call'](_0x31ab13,_0x3fe90f))return!0x1;return!0x0;}function ln(_0x20ab97,_0xe58c0f,_0x36b36d){const _0x2d60dd={};for(const _0xca06a in _0x20ab97)Object['prototype']['hasOwnProperty']['call'](_0x20ab97,_0xca06a)&&(_0x2d60dd[_0xca06a]=_0xe58c0f['call'](_0x36b36d,_0x20ab97[_0xca06a],_0xca06a,_0x20ab97));return _0x2d60dd;}function De(_0x5893af,_0x3f0686){if(_0x5893af===_0x3f0686)return!0x0;const _0x19d25f=Object['keys'](_0x5893af),_0x21fa32=Object['keys'](_0x3f0686);for(const _0x1f1885 of _0x19d25f){if(!_0x21fa32['includes'](_0x1f1885))return!0x1;const _0x5bb3ce=_0x5893af[_0x1f1885],_0x84feed=_0x3f0686[_0x1f1885];if(ks(_0x5bb3ce)&&ks(_0x84feed)){if(!De(_0x5bb3ce,_0x84feed))return!0x1;}else{if(_0x5bb3ce!==_0x84feed)return!0x1;}}for(const _0x58f503 of _0x21fa32)if(!_0x19d25f['includes'](_0x58f503))return!0x1;return!0x0;}function ks(_0x4ee04a){return _0x4ee04a!==null&&typeof _0x4ee04a=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5893f3){const _0x5775bd=[];for(const [_0x5d2ddf,_0x32b4df]of Object['entries'](_0x5893f3))Array['isArray'](_0x32b4df)?_0x32b4df['forEach'](_0x8e44a8=>{_0x5775bd['push'](encodeURIComponent(_0x5d2ddf)+'='+encodeURIComponent(_0x8e44a8));}):_0x5775bd['push'](encodeURIComponent(_0x5d2ddf)+'='+encodeURIComponent(_0x32b4df));return _0x5775bd['length']?'&'+_0x5775bd['join']('&'):'';}function yt(_0x133b90){const _0x45f6bf={};return _0x133b90['replace'](/^\?/,'')['split']('&')['forEach'](_0x10bb8a=>{if(_0x10bb8a){const [_0x3a87c8,_0x5be35d]=_0x10bb8a['split']('=');_0x45f6bf[decodeURIComponent(_0x3a87c8)]=decodeURIComponent(_0x5be35d);}}),_0x45f6bf;}function vt(_0x559075){const _0x17b96f=_0x559075['indexOf']('?');if(!_0x17b96f)return'';const _0x18ee60=_0x559075['indexOf']('#',_0x17b96f);return _0x559075['substring'](_0x17b96f,_0x18ee60>0x0?_0x18ee60:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xf85e43=0x1;_0xf85e43<this['blockSize'];++_0xf85e43)this['pad_'][_0xf85e43]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x10c6c8,_0x5a159d){_0x5a159d||(_0x5a159d=0x0);const _0x51dbc3=this['W_'];if(typeof _0x10c6c8=='string'){for(let _0xefc51d=0x0;_0xefc51d<0x10;_0xefc51d++)_0x51dbc3[_0xefc51d]=_0x10c6c8['charCodeAt'](_0x5a159d)<<0x18|_0x10c6c8['charCodeAt'](_0x5a159d+0x1)<<0x10|_0x10c6c8['charCodeAt'](_0x5a159d+0x2)<<0x8|_0x10c6c8['charCodeAt'](_0x5a159d+0x3),_0x5a159d+=0x4;}else{for(let _0xb42619=0x0;_0xb42619<0x10;_0xb42619++)_0x51dbc3[_0xb42619]=_0x10c6c8[_0x5a159d]<<0x18|_0x10c6c8[_0x5a159d+0x1]<<0x10|_0x10c6c8[_0x5a159d+0x2]<<0x8|_0x10c6c8[_0x5a159d+0x3],_0x5a159d+=0x4;}for(let _0x5c1523=0x10;_0x5c1523<0x50;_0x5c1523++){const _0x56160b=_0x51dbc3[_0x5c1523-0x3]^_0x51dbc3[_0x5c1523-0x8]^_0x51dbc3[_0x5c1523-0xe]^_0x51dbc3[_0x5c1523-0x10];_0x51dbc3[_0x5c1523]=(_0x56160b<<0x1|_0x56160b>>>0x1f)&0xffffffff;}let _0x5ad0ff=this['chain_'][0x0],_0x4d789e=this['chain_'][0x1],_0xb5a69e=this['chain_'][0x2],_0x2053bc=this['chain_'][0x3],_0x1451e3=this['chain_'][0x4],_0x44be26,_0x2d5ff2;for(let _0x17a8c6=0x0;_0x17a8c6<0x50;_0x17a8c6++){_0x17a8c6<0x28?_0x17a8c6<0x14?(_0x44be26=_0x2053bc^_0x4d789e&(_0xb5a69e^_0x2053bc),_0x2d5ff2=0x5a827999):(_0x44be26=_0x4d789e^_0xb5a69e^_0x2053bc,_0x2d5ff2=0x6ed9eba1):_0x17a8c6<0x3c?(_0x44be26=_0x4d789e&_0xb5a69e|_0x2053bc&(_0x4d789e|_0xb5a69e),_0x2d5ff2=0x8f1bbcdc):(_0x44be26=_0x4d789e^_0xb5a69e^_0x2053bc,_0x2d5ff2=0xca62c1d6);const _0x4ac72d=(_0x5ad0ff<<0x5|_0x5ad0ff>>>0x1b)+_0x44be26+_0x1451e3+_0x2d5ff2+_0x51dbc3[_0x17a8c6]&0xffffffff;_0x1451e3=_0x2053bc,_0x2053bc=_0xb5a69e,_0xb5a69e=(_0x4d789e<<0x1e|_0x4d789e>>>0x2)&0xffffffff,_0x4d789e=_0x5ad0ff,_0x5ad0ff=_0x4ac72d;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5ad0ff&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x4d789e&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xb5a69e&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2053bc&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1451e3&0xffffffff;}['update'](_0x5da2db,_0x51b090){if(_0x5da2db==null)return;_0x51b090===void 0x0&&(_0x51b090=_0x5da2db['length']);const _0x59be08=_0x51b090-this['blockSize'];let _0x5c56dd=0x0;const _0x17af66=this['buf_'];let _0x1b42c7=this['inbuf_'];for(;_0x5c56dd<_0x51b090;){if(_0x1b42c7===0x0){for(;_0x5c56dd<=_0x59be08;)this['compress_'](_0x5da2db,_0x5c56dd),_0x5c56dd+=this['blockSize'];}if(typeof _0x5da2db=='string'){for(;_0x5c56dd<_0x51b090;)if(_0x17af66[_0x1b42c7]=_0x5da2db['charCodeAt'](_0x5c56dd),++_0x1b42c7,++_0x5c56dd,_0x1b42c7===this['blockSize']){this['compress_'](_0x17af66),_0x1b42c7=0x0;break;}}else{for(;_0x5c56dd<_0x51b090;)if(_0x17af66[_0x1b42c7]=_0x5da2db[_0x5c56dd],++_0x1b42c7,++_0x5c56dd,_0x1b42c7===this['blockSize']){this['compress_'](_0x17af66),_0x1b42c7=0x0;break;}}}this['inbuf_']=_0x1b42c7,this['total_']+=_0x51b090;}['digest'](){const _0x1066d4=[];let _0x1f97ce=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x261b65=this['blockSize']-0x1;_0x261b65>=0x38;_0x261b65--)this['buf_'][_0x261b65]=_0x1f97ce&0xff,_0x1f97ce/=0x100;this['compress_'](this['buf_']);let _0x211286=0x0;for(let _0x3fb585=0x0;_0x3fb585<0x5;_0x3fb585++)for(let _0x58fb1d=0x18;_0x58fb1d>=0x0;_0x58fb1d-=0x8)_0x1066d4[_0x211286]=this['chain_'][_0x3fb585]>>_0x58fb1d&0xff,++_0x211286;return _0x1066d4;}}function Ic(_0x2a5faa,_0x18fb78){const _0x25cf97=new wc(_0x2a5faa,_0x18fb78);return _0x25cf97['subscribe']['bind'](_0x25cf97);}class wc{constructor(_0x2d0466,_0x5dc03d){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x5dc03d,this['task']['then'](()=>{_0x2d0466(this);})['catch'](_0x928c1d=>{this['error'](_0x928c1d);});}['next'](_0x1c8cd4){this['forEachObserver'](_0x46b489=>{_0x46b489['next'](_0x1c8cd4);});}['error'](_0x38448c){this['forEachObserver'](_0xa98066=>{_0xa98066['error'](_0x38448c);}),this['close'](_0x38448c);}['complete'](){this['forEachObserver'](_0x37bdbd=>{_0x37bdbd['complete']();}),this['close']();}['subscribe'](_0x3ffd1f,_0x5d7000,_0x1c4c60){let _0x40ccb4;if(_0x3ffd1f===void 0x0&&_0x5d7000===void 0x0&&_0x1c4c60===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x3ffd1f,['next','error','complete'])?_0x40ccb4=_0x3ffd1f:_0x40ccb4={'next':_0x3ffd1f,'error':_0x5d7000,'complete':_0x1c4c60},_0x40ccb4['next']===void 0x0&&(_0x40ccb4['next']=Qn),_0x40ccb4['error']===void 0x0&&(_0x40ccb4['error']=Qn),_0x40ccb4['complete']===void 0x0&&(_0x40ccb4['complete']=Qn);const _0x5bd7fd=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x40ccb4['error'](this['finalError']):_0x40ccb4['complete']();}catch{}}),this['observers']['push'](_0x40ccb4),_0x5bd7fd;}['unsubscribeOne'](_0x406567){this['observers']===void 0x0||this['observers'][_0x406567]===void 0x0||(delete this['observers'][_0x406567],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x268068){if(!this['finalized']){for(let _0x5ef417=0x0;_0x5ef417<this['observers']['length'];_0x5ef417++)this['sendOne'](_0x5ef417,_0x268068);}}['sendOne'](_0x1942e7,_0x4f4eff){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x1942e7]!==void 0x0)try{_0x4f4eff(this['observers'][_0x1942e7]);}catch(_0x572d9e){typeof console<'u'&&console['error']&&console['error'](_0x572d9e);}});}['close'](_0x220f89){this['finalized']||(this['finalized']=!0x0,_0x220f89!==void 0x0&&(this['finalError']=_0x220f89),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x315aa1,_0x274a3a){if(typeof _0x315aa1!='object'||_0x315aa1===null)return!0x1;for(const _0x239ce7 of _0x274a3a)if(_0x239ce7 in _0x315aa1&&typeof _0x315aa1[_0x239ce7]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0xe83e00,_0x58e4cb){return _0xe83e00+'\x20failed:\x20'+_0x58e4cb+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x557654){const _0x2d6296=[];let _0x57ce59=0x0;for(let _0x4c266f=0x0;_0x4c266f<_0x557654['length'];_0x4c266f++){let _0x2542dd=_0x557654['charCodeAt'](_0x4c266f);if(_0x2542dd>=0xd800&&_0x2542dd<=0xdbff){const _0x26f41d=_0x2542dd-0xd800;_0x4c266f++,f(_0x4c266f<_0x557654['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x35025d=_0x557654['charCodeAt'](_0x4c266f)-0xdc00;_0x2542dd=0x10000+(_0x26f41d<<0xa)+_0x35025d;}_0x2542dd<0x80?_0x2d6296[_0x57ce59++]=_0x2542dd:_0x2542dd<0x800?(_0x2d6296[_0x57ce59++]=_0x2542dd>>0x6|0xc0,_0x2d6296[_0x57ce59++]=_0x2542dd&0x3f|0x80):_0x2542dd<0x10000?(_0x2d6296[_0x57ce59++]=_0x2542dd>>0xc|0xe0,_0x2d6296[_0x57ce59++]=_0x2542dd>>0x6&0x3f|0x80,_0x2d6296[_0x57ce59++]=_0x2542dd&0x3f|0x80):(_0x2d6296[_0x57ce59++]=_0x2542dd>>0x12|0xf0,_0x2d6296[_0x57ce59++]=_0x2542dd>>0xc&0x3f|0x80,_0x2d6296[_0x57ce59++]=_0x2542dd>>0x6&0x3f|0x80,_0x2d6296[_0x57ce59++]=_0x2542dd&0x3f|0x80);}return _0x2d6296;},Pn=function(_0xa93028){let _0x1fe649=0x0;for(let _0x2a82c8=0x0;_0x2a82c8<_0xa93028['length'];_0x2a82c8++){const _0x516f4e=_0xa93028['charCodeAt'](_0x2a82c8);_0x516f4e<0x80?_0x1fe649++:_0x516f4e<0x800?_0x1fe649+=0x2:_0x516f4e>=0xd800&&_0x516f4e<=0xdbff?(_0x1fe649+=0x4,_0x2a82c8++):_0x1fe649+=0x3;}return _0x1fe649;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x111e53){return _0x111e53&&_0x111e53['_delegate']?_0x111e53['_delegate']:_0x111e53;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x326102){try{return(_0x326102['startsWith']('http://')||_0x326102['startsWith']('https://')?new URL(_0x326102)['hostname']:_0x326102)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x4f05c5){return(await fetch(_0x4f05c5,{'credentials':'include'}))['ok'];}class Me{constructor(_0x5d5ba1,_0x7ec00c,_0x39270d){this['name']=_0x5d5ba1,this['instanceFactory']=_0x7ec00c,this['type']=_0x39270d,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x8f1f96){return this['instantiationMode']=_0x8f1f96,this;}['setMultipleInstances'](_0x3c146f){return this['multipleInstances']=_0x3c146f,this;}['setServiceProps'](_0xc59232){return this['serviceProps']=_0xc59232,this;}['setInstanceCreatedCallback'](_0x2ff4ed){return this['onInstanceCreated']=_0x2ff4ed,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x1334db,_0x55b86d){this['name']=_0x1334db,this['container']=_0x55b86d,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x15eca8){const _0x1b396e=this['normalizeInstanceIdentifier'](_0x15eca8);if(!this['instancesDeferred']['has'](_0x1b396e)){const _0x324dda=new Ve();if(this['instancesDeferred']['set'](_0x1b396e,_0x324dda),this['isInitialized'](_0x1b396e)||this['shouldAutoInitialize']())try{const _0x794f2c=this['getOrInitializeService']({'instanceIdentifier':_0x1b396e});_0x794f2c&&_0x324dda['resolve'](_0x794f2c);}catch{}}return this['instancesDeferred']['get'](_0x1b396e)['promise'];}['getImmediate'](_0x4f46b2){const _0x4372fd=this['normalizeInstanceIdentifier'](_0x4f46b2==null?void 0x0:_0x4f46b2['identifier']),_0x353439=(_0x4f46b2==null?void 0x0:_0x4f46b2['optional'])??!0x1;if(this['isInitialized'](_0x4372fd)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4372fd});}catch(_0x551de7){if(_0x353439)return null;throw _0x551de7;}else{if(_0x353439)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0xb245ff){if(_0xb245ff['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0xb245ff['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0xb245ff,!!this['shouldAutoInitialize']()){if(Rc(_0xb245ff))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x22008b,_0x5be515]of this['instancesDeferred']['entries']()){const _0x5edd07=this['normalizeInstanceIdentifier'](_0x22008b);try{const _0x5a73f=this['getOrInitializeService']({'instanceIdentifier':_0x5edd07});_0x5be515['resolve'](_0x5a73f);}catch{}}}}['clearInstance'](_0x33fbfa=ke){this['instancesDeferred']['delete'](_0x33fbfa),this['instancesOptions']['delete'](_0x33fbfa),this['instances']['delete'](_0x33fbfa);}async['delete'](){const _0x5edb46=Array['from'](this['instances']['values']());await Promise['all']([..._0x5edb46['filter'](_0x4477e2=>'INTERNAL'in _0x4477e2)['map'](_0x10ecb8=>_0x10ecb8['INTERNAL']['delete']()),..._0x5edb46['filter'](_0x190bec=>'_delete'in _0x190bec)['map'](_0x5ddb0c=>_0x5ddb0c['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x152008=ke){return this['instances']['has'](_0x152008);}['getOptions'](_0x1858c9=ke){return this['instancesOptions']['get'](_0x1858c9)||{};}['initialize'](_0x29e510={}){const {options:_0xa98b1a={}}=_0x29e510,_0x4a1c23=this['normalizeInstanceIdentifier'](_0x29e510['instanceIdentifier']);if(this['isInitialized'](_0x4a1c23))throw Error(this['name']+'('+_0x4a1c23+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x448118=this['getOrInitializeService']({'instanceIdentifier':_0x4a1c23,'options':_0xa98b1a});for(const [_0x4d1267,_0x59c064]of this['instancesDeferred']['entries']()){const _0x1489e9=this['normalizeInstanceIdentifier'](_0x4d1267);_0x4a1c23===_0x1489e9&&_0x59c064['resolve'](_0x448118);}return _0x448118;}['onInit'](_0xf40f2,_0x1c039b){const _0x178864=this['normalizeInstanceIdentifier'](_0x1c039b),_0x108a88=this['onInitCallbacks']['get'](_0x178864)??new Set();_0x108a88['add'](_0xf40f2),this['onInitCallbacks']['set'](_0x178864,_0x108a88);const _0x98c061=this['instances']['get'](_0x178864);return _0x98c061&&_0xf40f2(_0x98c061,_0x178864),()=>{_0x108a88['delete'](_0xf40f2);};}['invokeOnInitCallbacks'](_0xee2a80,_0x5c1ef1){const _0x4eafe1=this['onInitCallbacks']['get'](_0x5c1ef1);if(_0x4eafe1){for(const _0x30fc5f of _0x4eafe1)try{_0x30fc5f(_0xee2a80,_0x5c1ef1);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xc8fc64,options:_0x271387={}}){let _0x45f98c=this['instances']['get'](_0xc8fc64);if(!_0x45f98c&&this['component']&&(_0x45f98c=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0xc8fc64),'options':_0x271387}),this['instances']['set'](_0xc8fc64,_0x45f98c),this['instancesOptions']['set'](_0xc8fc64,_0x271387),this['invokeOnInitCallbacks'](_0x45f98c,_0xc8fc64),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xc8fc64,_0x45f98c);}catch{}return _0x45f98c||null;}['normalizeInstanceIdentifier'](_0x47df84=ke){return this['component']?this['component']['multipleInstances']?_0x47df84:ke:_0x47df84;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x42b175){return _0x42b175===ke?void 0x0:_0x42b175;}function Rc(_0x368d11){return _0x368d11['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x525aed){this['name']=_0x525aed,this['providers']=new Map();}['addComponent'](_0x616e18){const _0x393aca=this['getProvider'](_0x616e18['name']);if(_0x393aca['isComponentSet']())throw new Error('Component\x20'+_0x616e18['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x393aca['setComponent'](_0x616e18);}['addOrOverwriteComponent'](_0x5db2a9){this['getProvider'](_0x5db2a9['name'])['isComponentSet']()&&this['providers']['delete'](_0x5db2a9['name']),this['addComponent'](_0x5db2a9);}['getProvider'](_0x3dea7e){if(this['providers']['has'](_0x3dea7e))return this['providers']['get'](_0x3dea7e);const _0xf94e9e=new Sc(_0x3dea7e,this);return this['providers']['set'](_0x3dea7e,_0xf94e9e),_0xf94e9e;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x52ac2a){_0x52ac2a[_0x52ac2a['DEBUG']=0x0]='DEBUG',_0x52ac2a[_0x52ac2a['VERBOSE']=0x1]='VERBOSE',_0x52ac2a[_0x52ac2a['INFO']=0x2]='INFO',_0x52ac2a[_0x52ac2a['WARN']=0x3]='WARN',_0x52ac2a[_0x52ac2a['ERROR']=0x4]='ERROR',_0x52ac2a[_0x52ac2a['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x4f48fd,_0x2696ea,..._0x432408)=>{if(_0x2696ea<_0x4f48fd['logLevel'])return;const _0x4ff485=new Date()['toISOString'](),_0x34cdf0=Pc[_0x2696ea];if(_0x34cdf0)console[_0x34cdf0]('['+_0x4ff485+']\x20\x20'+_0x4f48fd['name']+':',..._0x432408);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2696ea+')');};class xi{constructor(_0x2042fe){this['name']=_0x2042fe,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x536429){if(!(_0x536429 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x536429+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x536429;}['setLogLevel'](_0x2e4fa6){this['_logLevel']=typeof _0x2e4fa6=='string'?kc[_0x2e4fa6]:_0x2e4fa6;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x130785){if(typeof _0x130785!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x130785;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5c2c4a){this['_userLogHandler']=_0x5c2c4a;}['debug'](..._0xaf5300){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0xaf5300),this['_logHandler'](this,T['DEBUG'],..._0xaf5300);}['log'](..._0x2974c8){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2974c8),this['_logHandler'](this,T['VERBOSE'],..._0x2974c8);}['info'](..._0x5be9a8){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5be9a8),this['_logHandler'](this,T['INFO'],..._0x5be9a8);}['warn'](..._0x1b98ad){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1b98ad),this['_logHandler'](this,T['WARN'],..._0x1b98ad);}['error'](..._0x5d9ab6){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5d9ab6),this['_logHandler'](this,T['ERROR'],..._0x5d9ab6);}}const Dc=(_0x503b43,_0x11d1bf)=>_0x11d1bf['some'](_0x490f64=>_0x503b43 instanceof _0x490f64);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x7a8bff){const _0x3bdf41=new Promise((_0x5e8f3d,_0x8d197b)=>{const _0x59cb4e=()=>{_0x7a8bff['removeEventListener']('success',_0x233370),_0x7a8bff['removeEventListener']('error',_0x3d75a2);},_0x233370=()=>{_0x5e8f3d(_e(_0x7a8bff['result'])),_0x59cb4e();},_0x3d75a2=()=>{_0x8d197b(_0x7a8bff['error']),_0x59cb4e();};_0x7a8bff['addEventListener']('success',_0x233370),_0x7a8bff['addEventListener']('error',_0x3d75a2);});return _0x3bdf41['then'](_0x274dad=>{_0x274dad instanceof IDBCursor&&Kr['set'](_0x274dad,_0x7a8bff);})['catch'](()=>{}),Fi['set'](_0x3bdf41,_0x7a8bff),_0x3bdf41;}function Fc(_0x3ec40f){if(ui['has'](_0x3ec40f))return;const _0x2f74b9=new Promise((_0x7f804e,_0x48f569)=>{const _0x5323b9=()=>{_0x3ec40f['removeEventListener']('complete',_0x9fbdf9),_0x3ec40f['removeEventListener']('error',_0x253658),_0x3ec40f['removeEventListener']('abort',_0x253658);},_0x9fbdf9=()=>{_0x7f804e(),_0x5323b9();},_0x253658=()=>{_0x48f569(_0x3ec40f['error']||new DOMException('AbortError','AbortError')),_0x5323b9();};_0x3ec40f['addEventListener']('complete',_0x9fbdf9),_0x3ec40f['addEventListener']('error',_0x253658),_0x3ec40f['addEventListener']('abort',_0x253658);});ui['set'](_0x3ec40f,_0x2f74b9);}let di={'get'(_0x3282b6,_0x18fbd5,_0x5baabe){if(_0x3282b6 instanceof IDBTransaction){if(_0x18fbd5==='done')return ui['get'](_0x3282b6);if(_0x18fbd5==='objectStoreNames')return _0x3282b6['objectStoreNames']||Yr['get'](_0x3282b6);if(_0x18fbd5==='store')return _0x5baabe['objectStoreNames'][0x1]?void 0x0:_0x5baabe['objectStore'](_0x5baabe['objectStoreNames'][0x0]);}return _e(_0x3282b6[_0x18fbd5]);},'set'(_0x281ff2,_0x54d0e6,_0x3dd4be){return _0x281ff2[_0x54d0e6]=_0x3dd4be,!0x0;},'has'(_0x2b8e27,_0x52f34d){return _0x2b8e27 instanceof IDBTransaction&&(_0x52f34d==='done'||_0x52f34d==='store')?!0x0:_0x52f34d in _0x2b8e27;}};function Uc(_0xc1b5c1){di=_0xc1b5c1(di);}function Wc(_0x56597e){return _0x56597e===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x18a2b8,..._0x2ed2fa){const _0x46e800=_0x56597e['call'](Xn(this),_0x18a2b8,..._0x2ed2fa);return Yr['set'](_0x46e800,_0x18a2b8['sort']?_0x18a2b8['sort']():[_0x18a2b8]),_e(_0x46e800);}:Lc()['includes'](_0x56597e)?function(..._0x49b814){return _0x56597e['apply'](Xn(this),_0x49b814),_e(Kr['get'](this));}:function(..._0x222893){return _e(_0x56597e['apply'](Xn(this),_0x222893));};}function Bc(_0xbe1ba1){return typeof _0xbe1ba1=='function'?Wc(_0xbe1ba1):(_0xbe1ba1 instanceof IDBTransaction&&Fc(_0xbe1ba1),Dc(_0xbe1ba1,Mc())?new Proxy(_0xbe1ba1,di):_0xbe1ba1);}function _e(_0x57eb6f){if(_0x57eb6f instanceof IDBRequest)return xc(_0x57eb6f);if(Jn['has'](_0x57eb6f))return Jn['get'](_0x57eb6f);const _0x438019=Bc(_0x57eb6f);return _0x438019!==_0x57eb6f&&(Jn['set'](_0x57eb6f,_0x438019),Fi['set'](_0x438019,_0x57eb6f)),_0x438019;}const Xn=_0x231b77=>Fi['get'](_0x231b77);function Vc(_0x2ad32e,_0x3a37a2,{blocked:_0x4bccd4,upgrade:_0x17917a,blocking:_0x1bb237,terminated:_0x36f2ef}={}){const _0x5249de=indexedDB['open'](_0x2ad32e,_0x3a37a2),_0x2db1dd=_e(_0x5249de);return _0x17917a&&_0x5249de['addEventListener']('upgradeneeded',_0x4e709f=>{_0x17917a(_e(_0x5249de['result']),_0x4e709f['oldVersion'],_0x4e709f['newVersion'],_e(_0x5249de['transaction']),_0x4e709f);}),_0x4bccd4&&_0x5249de['addEventListener']('blocked',_0x154079=>_0x4bccd4(_0x154079['oldVersion'],_0x154079['newVersion'],_0x154079)),_0x2db1dd['then'](_0x53abdc=>{_0x36f2ef&&_0x53abdc['addEventListener']('close',()=>_0x36f2ef()),_0x1bb237&&_0x53abdc['addEventListener']('versionchange',_0x4e3686=>_0x1bb237(_0x4e3686['oldVersion'],_0x4e3686['newVersion'],_0x4e3686));})['catch'](()=>{}),_0x2db1dd;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x12dd52,_0x1a3a97){if(!(_0x12dd52 instanceof IDBDatabase&&!(_0x1a3a97 in _0x12dd52)&&typeof _0x1a3a97=='string'))return;if(Zn['get'](_0x1a3a97))return Zn['get'](_0x1a3a97);const _0x57360a=_0x1a3a97['replace'](/FromIndex$/,''),_0x47405d=_0x1a3a97!==_0x57360a,_0x13ace7=$c['includes'](_0x57360a);if(!(_0x57360a in(_0x47405d?IDBIndex:IDBObjectStore)['prototype'])||!(_0x13ace7||Hc['includes'](_0x57360a)))return;const _0x540504=async function(_0x2a22ea,..._0x42c5c4){const _0x38336a=this['transaction'](_0x2a22ea,_0x13ace7?'readwrite':'readonly');let _0x304d44=_0x38336a['store'];return _0x47405d&&(_0x304d44=_0x304d44['index'](_0x42c5c4['shift']())),(await Promise['all']([_0x304d44[_0x57360a](..._0x42c5c4),_0x13ace7&&_0x38336a['done']]))[0x0];};return Zn['set'](_0x1a3a97,_0x540504),_0x540504;}Uc(_0x2861fc=>({..._0x2861fc,'get':(_0x327db4,_0x20f3b3,_0x54a935)=>Os(_0x327db4,_0x20f3b3)||_0x2861fc['get'](_0x327db4,_0x20f3b3,_0x54a935),'has':(_0x412f11,_0x3c2234)=>!!Os(_0x412f11,_0x3c2234)||_0x2861fc['has'](_0x412f11,_0x3c2234)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x89be5c){this['container']=_0x89be5c;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x4e531c=>{if(qc(_0x4e531c)){const _0x313b6d=_0x4e531c['getImmediate']();return _0x313b6d['library']+'/'+_0x313b6d['version'];}else return null;})['filter'](_0x509170=>_0x509170)['join']('\x20');}}function qc(_0xa7b30d){const _0x418288=_0xa7b30d['getComponent']();return(_0x418288==null?void 0x0:_0x418288['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x1dd4aa,_0x2f3713){try{_0x1dd4aa['container']['addComponent'](_0x2f3713);}catch(_0x1376d2){re['debug']('Component\x20'+_0x2f3713['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1dd4aa['name'],_0x1376d2);}}function et(_0x6d9787){const _0x50a7c4=_0x6d9787['name'];if(gi['has'](_0x50a7c4))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x50a7c4+'.'),!0x1;gi['set'](_0x50a7c4,_0x6d9787);for(const _0x24cb0d of Le['values']())Ms(_0x24cb0d,_0x6d9787);for(const _0x2b7ba0 of _i['values']())Ms(_0x2b7ba0,_0x6d9787);return!0x0;}function Ui(_0x242c22,_0x3db0ff){const _0x20af7d=_0x242c22['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x20af7d&&_0x20af7d['triggerHeartbeat'](),_0x242c22['container']['getProvider'](_0x3db0ff);}function H(_0x3d93d5){return _0x3d93d5==null?!0x1:_0x3d93d5['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x3f6c53,_0x11003d,_0x582211){this['_isDeleted']=!0x1,this['_options']={..._0x3f6c53},this['_config']={..._0x11003d},this['_name']=_0x11003d['name'],this['_automaticDataCollectionEnabled']=_0x11003d['automaticDataCollectionEnabled'],this['_container']=_0x582211,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x5cb345){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x5cb345;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x1ffed9){this['_isDeleted']=_0x1ffed9;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x120d27,_0x364c61={}){let _0x272947=_0x120d27;typeof _0x364c61!='object'&&(_0x364c61={'name':_0x364c61});const _0x43c834={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x364c61},_0x4991fb=_0x43c834['name'];if(typeof _0x4991fb!='string'||!_0x4991fb)throw ge['create']('bad-app-name',{'appName':String(_0x4991fb)});if(_0x272947||(_0x272947=$r()),!_0x272947)throw ge['create']('no-options');const _0x58b303=Le['get'](_0x4991fb);if(_0x58b303){if(De(_0x272947,_0x58b303['options'])&&De(_0x43c834,_0x58b303['config']))return _0x58b303;throw ge['create']('duplicate-app',{'appName':_0x4991fb});}const _0xcac407=new Ac(_0x4991fb);for(const _0x353436 of gi['values']())_0xcac407['addComponent'](_0x353436);const _0x195a98=new Il(_0x272947,_0x43c834,_0xcac407);return Le['set'](_0x4991fb,_0x195a98),_0x195a98;}function Qr(_0x3eb51e=pi){const _0x46753f=Le['get'](_0x3eb51e);if(!_0x46753f&&_0x3eb51e===pi&&$r())return wl();if(!_0x46753f)throw ge['create']('no-app',{'appName':_0x3eb51e});return _0x46753f;}function l_(){return Array['from'](Le['values']());}async function h_(_0x59f51d){let _0x5821a5=!0x1;const _0x2b1c07=_0x59f51d['name'];Le['has'](_0x2b1c07)?(_0x5821a5=!0x0,Le['delete'](_0x2b1c07)):_i['has'](_0x2b1c07)&&_0x59f51d['decRefCount']()<=0x0&&(_i['delete'](_0x2b1c07),_0x5821a5=!0x0),_0x5821a5&&(await Promise['all'](_0x59f51d['container']['getProviders']()['map'](_0x2f4bd3=>_0x2f4bd3['delete']())),_0x59f51d['isDeleted']=!0x0);}function me(_0x36bfcd,_0x514321,_0x51fde6){let _0xe11557=vl[_0x36bfcd]??_0x36bfcd;_0x51fde6&&(_0xe11557+='-'+_0x51fde6);const _0x2dfe7b=_0xe11557['match'](/\s|\//),_0x38de06=_0x514321['match'](/\s|\//);if(_0x2dfe7b||_0x38de06){const _0x12d8aa=['Unable\x20to\x20register\x20library\x20\x22'+_0xe11557+'\x22\x20with\x20version\x20\x22'+_0x514321+'\x22:'];_0x2dfe7b&&_0x12d8aa['push']('library\x20name\x20\x22'+_0xe11557+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2dfe7b&&_0x38de06&&_0x12d8aa['push']('and'),_0x38de06&&_0x12d8aa['push']('version\x20name\x20\x22'+_0x514321+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x12d8aa['join']('\x20'));return;}et(new Me(_0xe11557+'-version',()=>({'library':_0xe11557,'version':_0x514321}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x4af2e1,_0x5f19c6)=>{switch(_0x5f19c6){case 0x0:try{_0x4af2e1['createObjectStore'](Rt);}catch(_0x19083d){console['warn'](_0x19083d);}}}})['catch'](_0x3f7eab=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x3f7eab['message']});})),ei;}async function Sl(_0x39b215){try{const _0x19f240=(await Jr())['transaction'](Rt),_0x3f2823=await _0x19f240['objectStore'](Rt)['get'](Xr(_0x39b215));return await _0x19f240['done'],_0x3f2823;}catch(_0x39342b){if(_0x39342b instanceof Se)re['warn'](_0x39342b['message']);else{const _0x13c584=ge['create']('idb-get',{'originalErrorMessage':_0x39342b==null?void 0x0:_0x39342b['message']});re['warn'](_0x13c584['message']);}}}async function Ls(_0x5747d7,_0x5c3b56){try{const _0x3ba3c2=(await Jr())['transaction'](Rt,'readwrite');await _0x3ba3c2['objectStore'](Rt)['put'](_0x5c3b56,Xr(_0x5747d7)),await _0x3ba3c2['done'];}catch(_0x1d3dfd){if(_0x1d3dfd instanceof Se)re['warn'](_0x1d3dfd['message']);else{const _0x17b285=ge['create']('idb-set',{'originalErrorMessage':_0x1d3dfd==null?void 0x0:_0x1d3dfd['message']});re['warn'](_0x17b285['message']);}}}function Xr(_0x1d43b6){return _0x1d43b6['name']+'!'+_0x1d43b6['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x4e6e1b){this['container']=_0x4e6e1b,this['_heartbeatsCache']=null;const _0x46d4f0=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x46d4f0),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1ea353=>(this['_heartbeatsCache']=_0x1ea353,_0x1ea353));}async['triggerHeartbeat'](){var _0x4196ec,_0x3bea15;try{const _0x35ae51=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x4369b0=xs();if(((_0x4196ec=this['_heartbeatsCache'])==null?void 0x0:_0x4196ec['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3bea15=this['_heartbeatsCache'])==null?void 0x0:_0x3bea15['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x4369b0||this['_heartbeatsCache']['heartbeats']['some'](_0x142f55=>_0x142f55['date']===_0x4369b0))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x4369b0,'agent':_0x35ae51}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x34ebca=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x34ebca,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4eb135){re['warn'](_0x4eb135);}}async['getHeartbeatsHeader'](){var _0x28e51d;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x28e51d=this['_heartbeatsCache'])==null?void 0x0:_0x28e51d['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4b02d6=xs(),{heartbeatsToSend:_0x427e6c,unsentEntries:_0x3e22fa}=kl(this['_heartbeatsCache']['heartbeats']),_0x27ca72=an(JSON['stringify']({'version':0x2,'heartbeats':_0x427e6c}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4b02d6,_0x3e22fa['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3e22fa,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x27ca72;}catch(_0x508eb1){return re['warn'](_0x508eb1),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x345c79,_0xb9ac60=bl){const _0x9aeae9=[];let _0x455776=_0x345c79['slice']();for(const _0xad48f8 of _0x345c79){const _0x122a8f=_0x9aeae9['find'](_0x39a988=>_0x39a988['agent']===_0xad48f8['agent']);if(_0x122a8f){if(_0x122a8f['dates']['push'](_0xad48f8['date']),Fs(_0x9aeae9)>_0xb9ac60){_0x122a8f['dates']['pop']();break;}}else{if(_0x9aeae9['push']({'agent':_0xad48f8['agent'],'dates':[_0xad48f8['date']]}),Fs(_0x9aeae9)>_0xb9ac60){_0x9aeae9['pop']();break;}}_0x455776=_0x455776['slice'](0x1);}return{'heartbeatsToSend':_0x9aeae9,'unsentEntries':_0x455776};}class Nl{constructor(_0x4d4648){this['app']=_0x4d4648,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x48fab3=await Sl(this['app']);return _0x48fab3!=null&&_0x48fab3['heartbeats']?_0x48fab3:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x599ab8){if(await this['_canUseIndexedDBPromise']){const _0x51e3e0=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x599ab8['lastSentHeartbeatDate']??_0x51e3e0['lastSentHeartbeatDate'],'heartbeats':_0x599ab8['heartbeats']});}else return;}async['add'](_0x44682f){if(await this['_canUseIndexedDBPromise']){const _0x35a0aa=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x44682f['lastSentHeartbeatDate']??_0x35a0aa['lastSentHeartbeatDate'],'heartbeats':[..._0x35a0aa['heartbeats'],..._0x44682f['heartbeats']]});}else return;}}function Fs(_0x2a1bf5){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x2a1bf5}))['length'];}function Pl(_0x30a264){if(_0x30a264['length']===0x0)return-0x1;let _0x5c9e64=0x0,_0xb862ee=_0x30a264[0x0]['date'];for(let _0x11557e=0x1;_0x11557e<_0x30a264['length'];_0x11557e++)_0x30a264[_0x11557e]['date']<_0xb862ee&&(_0xb862ee=_0x30a264[_0x11557e]['date'],_0x5c9e64=_0x11557e);return _0x5c9e64;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x35b623){et(new Me('platform-logger',_0x525a09=>new Gc(_0x525a09),'PRIVATE')),et(new Me('heartbeat',_0x20ce22=>new Al(_0x20ce22),'PRIVATE')),me(fi,Ds,_0x35b623),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x50de11){Zr=_0x50de11;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0xc28ada){this['domStorage_']=_0xc28ada,this['prefix_']='firebase:';}['set'](_0x1cd952,_0x4bf9c2){_0x4bf9c2==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1cd952)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1cd952),O(_0x4bf9c2));}['get'](_0x3389e7){const _0x273ae4=this['domStorage_']['getItem'](this['prefixedName_'](_0x3389e7));return _0x273ae4==null?null:bt(_0x273ae4);}['remove'](_0x3f96f0){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3f96f0));}['prefixedName_'](_0x5d4b75){return this['prefix_']+_0x5d4b75;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x53905a,_0x101531){_0x101531==null?delete this['cache_'][_0x53905a]:this['cache_'][_0x53905a]=_0x101531;}['get'](_0x2e4312){return Y(this['cache_'],_0x2e4312)?this['cache_'][_0x2e4312]:null;}['remove'](_0x547cc6){delete this['cache_'][_0x547cc6];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x256eca){try{if(typeof window<'u'&&typeof window[_0x256eca]<'u'){const _0x3866b3=window[_0x256eca];return _0x3866b3['setItem']('firebase:sentinel','cache'),_0x3866b3['removeItem']('firebase:sentinel'),new xl(_0x3866b3);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x2d3b5b=0x1;return function(){return _0x2d3b5b++;};}()),no=function(_0x150461){const _0xdae1b9=Tc(_0x150461),_0x1d90cb=new Ec();_0x1d90cb['update'](_0xdae1b9);const _0x15c5d9=_0x1d90cb['digest']();return Di['encodeByteArray'](_0x15c5d9);},Bt=function(..._0x55a99c){let _0x3cb3b4='';for(let _0x44eb96=0x0;_0x44eb96<_0x55a99c['length'];_0x44eb96++){const _0x1da8d7=_0x55a99c[_0x44eb96];Array['isArray'](_0x1da8d7)||_0x1da8d7&&typeof _0x1da8d7=='object'&&typeof _0x1da8d7['length']=='number'?_0x3cb3b4+=Bt['apply'](null,_0x1da8d7):typeof _0x1da8d7=='object'?_0x3cb3b4+=O(_0x1da8d7):_0x3cb3b4+=_0x1da8d7,_0x3cb3b4+='\x20';}return _0x3cb3b4;};let Et=null,Vs=!0x0;const Wl=function(_0x3d52b3,_0x23eb99){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x5b6684){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x470765=Bt['apply'](null,_0x5b6684);Et(_0x470765);}},Vt=function(_0x532785){return function(..._0xb74fc4){L(_0x532785,..._0xb74fc4);};},mi=function(..._0x48cead){const _0xe4b65f='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x48cead);Qe['error'](_0xe4b65f);},oe=function(..._0x29fa9c){const _0x344c14='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x29fa9c);throw Qe['error'](_0x344c14),new Error(_0x344c14);},U=function(..._0x151fc6){const _0x199994='FIREBASE\x20WARNING:\x20'+Bt(..._0x151fc6);Qe['warn'](_0x199994);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x38bdaa){return typeof _0x38bdaa=='number'&&(_0x38bdaa!==_0x38bdaa||_0x38bdaa===Number['POSITIVE_INFINITY']||_0x38bdaa===Number['NEGATIVE_INFINITY']);},Vl=function(_0x41fec0){if(document['readyState']==='complete')_0x41fec0();else{let _0x57bce8=!0x1;const _0x1c1693=function(){if(!document['body']){setTimeout(_0x1c1693,Math['floor'](0xa));return;}_0x57bce8||(_0x57bce8=!0x0,_0x41fec0());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1c1693,!0x1),window['addEventListener']('load',_0x1c1693,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1c1693();}),window['attachEvent']('onload',_0x1c1693));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x11a709,_0x45b1f2){if(_0x11a709===_0x45b1f2)return 0x0;if(_0x11a709===xe||_0x45b1f2===Ie)return-0x1;if(_0x45b1f2===xe||_0x11a709===Ie)return 0x1;{const _0x1e452e=Hs(_0x11a709),_0x261bbb=Hs(_0x45b1f2);return _0x1e452e!==null?_0x261bbb!==null?_0x1e452e-_0x261bbb===0x0?_0x11a709['length']-_0x45b1f2['length']:_0x1e452e-_0x261bbb:-0x1:_0x261bbb!==null?0x1:_0x11a709<_0x45b1f2?-0x1:0x1;}},Hl=function(_0x8d4bab,_0x44bfd2){return _0x8d4bab===_0x44bfd2?0x0:_0x8d4bab<_0x44bfd2?-0x1:0x1;},pt=function(_0x44cce4,_0x64f655){if(_0x64f655&&_0x44cce4 in _0x64f655)return _0x64f655[_0x44cce4];throw new Error('Missing\x20required\x20key\x20('+_0x44cce4+')\x20in\x20object:\x20'+O(_0x64f655));},Bi=function(_0x4a02eb){if(typeof _0x4a02eb!='object'||_0x4a02eb===null)return O(_0x4a02eb);const _0x169d25=[];for(const _0xfdc641 in _0x4a02eb)_0x169d25['push'](_0xfdc641);_0x169d25['sort']();let _0xbe9d61='{';for(let _0x19045d=0x0;_0x19045d<_0x169d25['length'];_0x19045d++)_0x19045d!==0x0&&(_0xbe9d61+=','),_0xbe9d61+=O(_0x169d25[_0x19045d]),_0xbe9d61+=':',_0xbe9d61+=Bi(_0x4a02eb[_0x169d25[_0x19045d]]);return _0xbe9d61+='}',_0xbe9d61;},io=function(_0x1b532f,_0x575e34){const _0x2c9c15=_0x1b532f['length'];if(_0x2c9c15<=_0x575e34)return[_0x1b532f];const _0x8322b6=[];for(let _0x2e1e03=0x0;_0x2e1e03<_0x2c9c15;_0x2e1e03+=_0x575e34)_0x2e1e03+_0x575e34>_0x2c9c15?_0x8322b6['push'](_0x1b532f['substring'](_0x2e1e03,_0x2c9c15)):_0x8322b6['push'](_0x1b532f['substring'](_0x2e1e03,_0x2e1e03+_0x575e34));return _0x8322b6;};function x(_0x197ec8,_0x5cb28a){for(const _0x391538 in _0x197ec8)_0x197ec8['hasOwnProperty'](_0x391538)&&_0x5cb28a(_0x391538,_0x197ec8[_0x391538]);}const so=function(_0x12a06c){f(!Wi(_0x12a06c),'Invalid\x20JSON\x20number');const _0x18911c=0xb,_0x2962f1=0x34,_0x65c2f1=(0x1<<_0x18911c-0x1)-0x1;let _0x4a76f9,_0x5a21e7,_0x2d1178,_0x4029f0,_0x4fb26b;_0x12a06c===0x0?(_0x5a21e7=0x0,_0x2d1178=0x0,_0x4a76f9=0x1/_0x12a06c===-0x1/0x0?0x1:0x0):(_0x4a76f9=_0x12a06c<0x0,_0x12a06c=Math['abs'](_0x12a06c),_0x12a06c>=Math['pow'](0x2,0x1-_0x65c2f1)?(_0x4029f0=Math['min'](Math['floor'](Math['log'](_0x12a06c)/Math['LN2']),_0x65c2f1),_0x5a21e7=_0x4029f0+_0x65c2f1,_0x2d1178=Math['round'](_0x12a06c*Math['pow'](0x2,_0x2962f1-_0x4029f0)-Math['pow'](0x2,_0x2962f1))):(_0x5a21e7=0x0,_0x2d1178=Math['round'](_0x12a06c/Math['pow'](0x2,0x1-_0x65c2f1-_0x2962f1))));const _0x589716=[];for(_0x4fb26b=_0x2962f1;_0x4fb26b;_0x4fb26b-=0x1)_0x589716['push'](_0x2d1178%0x2?0x1:0x0),_0x2d1178=Math['floor'](_0x2d1178/0x2);for(_0x4fb26b=_0x18911c;_0x4fb26b;_0x4fb26b-=0x1)_0x589716['push'](_0x5a21e7%0x2?0x1:0x0),_0x5a21e7=Math['floor'](_0x5a21e7/0x2);_0x589716['push'](_0x4a76f9?0x1:0x0),_0x589716['reverse']();const _0x579099=_0x589716['join']('');let _0x475217='';for(_0x4fb26b=0x0;_0x4fb26b<0x40;_0x4fb26b+=0x8){let _0x3e4ebc=parseInt(_0x579099['substr'](_0x4fb26b,0x8),0x2)['toString'](0x10);_0x3e4ebc['length']===0x1&&(_0x3e4ebc='0'+_0x3e4ebc),_0x475217=_0x475217+_0x3e4ebc;}return _0x475217['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x7d0c5a,_0x2ebc7f){let _0x87518d='Unknown\x20Error';_0x7d0c5a==='too_big'?_0x87518d='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x7d0c5a==='permission_denied'?_0x87518d='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x7d0c5a==='unavailable'&&(_0x87518d='The\x20service\x20is\x20unavailable');const _0xf1bc57=new Error(_0x7d0c5a+'\x20at\x20'+_0x2ebc7f['_path']['toString']()+':\x20'+_0x87518d);return _0xf1bc57['code']=_0x7d0c5a['toUpperCase'](),_0xf1bc57;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x2eab40){if(zl['test'](_0x2eab40)){const _0x5d5cc7=Number(_0x2eab40);if(_0x5d5cc7>=jl&&_0x5d5cc7<=Kl)return _0x5d5cc7;}return null;},lt=function(_0x377755){try{_0x377755();}catch(_0x3c35ed){setTimeout(()=>{const _0x5964a1=_0x3c35ed['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5964a1),_0x3c35ed;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x31cc7a,_0x851598){const _0x478b82=setTimeout(_0x31cc7a,_0x851598);return typeof _0x478b82=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x478b82):typeof _0x478b82=='object'&&_0x478b82['unref']&&_0x478b82['unref'](),_0x478b82;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x516352,_0x49af3b){this['appCheckProvider']=_0x49af3b,this['appName']=_0x516352['name'],H(_0x516352)&&_0x516352['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x516352['settings']['appCheckToken']),this['appCheck']=_0x49af3b==null?void 0x0:_0x49af3b['getImmediate']({'optional':!0x0}),this['appCheck']||_0x49af3b==null||_0x49af3b['get']()['then'](_0x2fad5d=>this['appCheck']=_0x2fad5d);}['getToken'](_0x44cd6b){if(this['serverAppAppCheckToken']){if(_0x44cd6b)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x44cd6b):new Promise((_0x20b535,_0x507331)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x44cd6b)['then'](_0x20b535,_0x507331):_0x20b535(null);},0x0);});}['addTokenChangeListener'](_0x273469){var _0x65b4f4;(_0x65b4f4=this['appCheckProvider'])==null||_0x65b4f4['get']()['then'](_0x29d45e=>_0x29d45e['addTokenListener'](_0x273469));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x5a0925,_0x23e938,_0x29b65f){this['appName_']=_0x5a0925,this['firebaseOptions_']=_0x23e938,this['authProvider_']=_0x29b65f,this['auth_']=null,this['auth_']=_0x29b65f['getImmediate']({'optional':!0x0}),this['auth_']||_0x29b65f['onInit'](_0xede73e=>this['auth_']=_0xede73e);}['getToken'](_0x2f0023){return this['auth_']?this['auth_']['getToken'](_0x2f0023)['catch'](_0x3a99c5=>_0x3a99c5&&_0x3a99c5['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x3a99c5)):new Promise((_0x359e53,_0x472971)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x2f0023)['then'](_0x359e53,_0x472971):_0x359e53(null);},0x0);});}['addTokenChangeListener'](_0x53a97e){this['auth_']?this['auth_']['addAuthTokenListener'](_0x53a97e):this['authProvider_']['get']()['then'](_0x3edc62=>_0x3edc62['addAuthTokenListener'](_0x53a97e));}['removeTokenChangeListener'](_0x362890){this['authProvider_']['get']()['then'](_0x17cd40=>_0x17cd40['removeAuthTokenListener'](_0x362890));}['notifyForInvalidToken'](){let _0x4e74e1='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4e74e1+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4e74e1+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4e74e1+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4e74e1);}}class tn{constructor(_0xf38038){this['accessToken']=_0xf38038;}['getToken'](_0x49e99c){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x6c7154){_0x6c7154(this['accessToken']);}['removeTokenChangeListener'](_0x52f627){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x4d2ea7,_0x72cb39,_0x1e497f,_0x1a630c,_0x34b731=!0x1,_0x666b71='',_0x5833b1=!0x1,_0x538af6=!0x1,_0x10c140=null){this['secure']=_0x72cb39,this['namespace']=_0x1e497f,this['webSocketOnly']=_0x1a630c,this['nodeAdmin']=_0x34b731,this['persistenceKey']=_0x666b71,this['includeNamespaceInQueryParams']=_0x5833b1,this['isUsingEmulator']=_0x538af6,this['emulatorOptions']=_0x10c140,this['_host']=_0x4d2ea7['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x4d2ea7)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1c4362){_0x1c4362!==this['internalHost']&&(this['internalHost']=_0x1c4362,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1b5e64=this['toURLString']();return this['persistenceKey']&&(_0x1b5e64+='<'+this['persistenceKey']+'>'),_0x1b5e64;}['toURLString'](){const _0x432950=this['secure']?'https://':'http://',_0x37fe65=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x432950+this['host']+'/'+_0x37fe65;}}function Xl(_0x5e8c45){return _0x5e8c45['host']!==_0x5e8c45['internalHost']||_0x5e8c45['isCustomHost']()||_0x5e8c45['includeNamespaceInQueryParams'];}function go(_0x103325,_0x1cd78b,_0x50072c){f(typeof _0x1cd78b=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x50072c=='object','typeof\x20params\x20must\x20==\x20object');let _0x44b480;if(_0x1cd78b===fo)_0x44b480=(_0x103325['secure']?'wss://':'ws://')+_0x103325['internalHost']+'/.ws?';else{if(_0x1cd78b===po)_0x44b480=(_0x103325['secure']?'https://':'http://')+_0x103325['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1cd78b);}Xl(_0x103325)&&(_0x50072c['ns']=_0x103325['namespace']);const _0x158571=[];return x(_0x50072c,(_0xaab253,_0x181eb8)=>{_0x158571['push'](_0xaab253+'='+_0x181eb8);}),_0x44b480+_0x158571['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x2a4ca0,_0x4b296d=0x1){Y(this['counters_'],_0x2a4ca0)||(this['counters_'][_0x2a4ca0]=0x0),this['counters_'][_0x2a4ca0]+=_0x4b296d;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x4c88cd){const _0xaf06a0=_0x4c88cd['toString']();return ti[_0xaf06a0]||(ti[_0xaf06a0]=new Zl()),ti[_0xaf06a0];}function eh(_0x4378e3,_0x20058b){const _0x241f96=_0x4378e3['toString']();return ni[_0x241f96]||(ni[_0x241f96]=_0x20058b()),ni[_0x241f96];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x14ec6f){this['onMessage_']=_0x14ec6f,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3d6ce8,_0x5d1514){this['closeAfterResponse']=_0x3d6ce8,this['onClose']=_0x5d1514,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xd5de87,_0x32fdf7){for(this['pendingResponses'][_0xd5de87]=_0x32fdf7;this['pendingResponses'][this['currentResponseNum']];){const _0x407228=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x40f2eb=0x0;_0x40f2eb<_0x407228['length'];++_0x40f2eb)_0x407228[_0x40f2eb]&&lt(()=>{this['onMessage_'](_0x407228[_0x40f2eb]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x13b02c,_0x36dc21,_0x6e6865,_0x3e3eec,_0x53d705,_0x2787dc,_0x24e01c){this['connId']=_0x13b02c,this['repoInfo']=_0x36dc21,this['applicationId']=_0x6e6865,this['appCheckToken']=_0x3e3eec,this['authToken']=_0x53d705,this['transportSessionId']=_0x2787dc,this['lastSessionId']=_0x24e01c,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x13b02c),this['stats_']=Hi(_0x36dc21),this['urlFn']=_0x45dc8a=>(this['appCheckToken']&&(_0x45dc8a[yi]=this['appCheckToken']),go(_0x36dc21,po,_0x45dc8a));}['open'](_0xc36691,_0x117e7f){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x117e7f,this['myPacketOrderer']=new th(_0xc36691),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x43117e)=>{const [_0x247562,_0x3500e4,_0x5956ce,_0x1efe9c,_0x1122d4]=_0x43117e;if(this['incrementIncomingBytes_'](_0x43117e),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x247562===$s)this['id']=_0x3500e4,this['password']=_0x5956ce;else{if(_0x247562===nh)_0x3500e4?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3500e4,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x247562);}}},(..._0x5b179d)=>{const [_0x3192c7,_0x5be240]=_0x5b179d;this['incrementIncomingBytes_'](_0x5b179d),this['myPacketOrderer']['handleResponse'](_0x3192c7,_0x5be240);},()=>{this['onClosed_']();},this['urlFn']);const _0x39bd09={};_0x39bd09[$s]='t',_0x39bd09[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x39bd09[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x39bd09[ro]=Vi,this['transportSessionId']&&(_0x39bd09[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x39bd09[ho]=this['lastSessionId']),this['applicationId']&&(_0x39bd09[uo]=this['applicationId']),this['appCheckToken']&&(_0x39bd09[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x39bd09[ao]=co);const _0x464620=this['urlFn'](_0x39bd09);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x464620),this['scriptTagHolder']['addTag'](_0x464620,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x14ddc1){const _0x220c2a=O(_0x14ddc1);this['bytesSent']+=_0x220c2a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x220c2a['length']);const _0x50dbc3=Br(_0x220c2a),_0x3f58f3=io(_0x50dbc3,hh);for(let _0x112174=0x0;_0x112174<_0x3f58f3['length'];_0x112174++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3f58f3['length'],_0x3f58f3[_0x112174]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xcbb75a,_0x16e85d){this['myDisconnFrame']=document['createElement']('iframe');const _0x7525b9={};_0x7525b9[lh]='t',_0x7525b9[mo]=_0xcbb75a,_0x7525b9[yo]=_0x16e85d,this['myDisconnFrame']['src']=this['urlFn'](_0x7525b9),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2a7ebe){const _0x3ee76e=O(_0x2a7ebe)['length'];this['bytesReceived']+=_0x3ee76e,this['stats_']['incrementCounter']('bytes_received',_0x3ee76e);}}class $i{constructor(_0x1700de,_0x49207d,_0x1a6b5a,_0x2c6a73){this['onDisconnect']=_0x1a6b5a,this['urlFn']=_0x2c6a73,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x1700de,window[sh+this['uniqueCallbackIdentifier']]=_0x49207d,this['myIFrame']=$i['createIFrame_']();let _0x2eaac7='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2eaac7='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x5261d0='<html><body>'+_0x2eaac7+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x5261d0),this['myIFrame']['doc']['close']();}catch(_0x1b4d44){L('frame\x20writing\x20exception'),_0x1b4d44['stack']&&L(_0x1b4d44['stack']),L(_0x1b4d44);}}}static['createIFrame_'](){const _0x152204=document['createElement']('iframe');if(_0x152204['style']['display']='none',document['body']){document['body']['appendChild'](_0x152204);try{_0x152204['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x29f75f=document['domain'];_0x152204['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x29f75f+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x152204['contentDocument']?_0x152204['doc']=_0x152204['contentDocument']:_0x152204['contentWindow']?_0x152204['doc']=_0x152204['contentWindow']['document']:_0x152204['document']&&(_0x152204['doc']=_0x152204['document']),_0x152204;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x208352=this['onDisconnect'];_0x208352&&(this['onDisconnect']=null,_0x208352());}['startLongPoll'](_0x584272,_0x12f08e){for(this['myID']=_0x584272,this['myPW']=_0x12f08e,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0xb31788={};_0xb31788[mo]=this['myID'],_0xb31788[yo]=this['myPW'],_0xb31788[vo]=this['currentSerial'];let _0x24a90a=this['urlFn'](_0xb31788),_0x5069dc='',_0x34123d=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x5069dc['length']<=Eo;){const _0x5f5808=this['pendingSegs']['shift']();_0x5069dc=_0x5069dc+'&'+oh+_0x34123d+'='+_0x5f5808['seg']+'&'+ah+_0x34123d+'='+_0x5f5808['ts']+'&'+ch+_0x34123d+'='+_0x5f5808['d'],_0x34123d++;}return _0x24a90a=_0x24a90a+_0x5069dc,this['addLongPollTag_'](_0x24a90a,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x5b42aa,_0x4cfb22,_0x4f527e){this['pendingSegs']['push']({'seg':_0x5b42aa,'ts':_0x4cfb22,'d':_0x4f527e}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2391fb,_0x1fbd6a){this['outstandingRequests']['add'](_0x1fbd6a);const _0x1850eb=()=>{this['outstandingRequests']['delete'](_0x1fbd6a),this['newRequest_']();},_0x262303=setTimeout(_0x1850eb,Math['floor'](uh)),_0x1ab438=()=>{clearTimeout(_0x262303),_0x1850eb();};this['addTag'](_0x2391fb,_0x1ab438);}['addTag'](_0x2ea540,_0x77c5f9){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x38bb99=this['myIFrame']['doc']['createElement']('script');_0x38bb99['type']='text/javascript',_0x38bb99['async']=!0x0,_0x38bb99['src']=_0x2ea540,_0x38bb99['onload']=_0x38bb99['onreadystatechange']=function(){const _0x22761b=_0x38bb99['readyState'];(!_0x22761b||_0x22761b==='loaded'||_0x22761b==='complete')&&(_0x38bb99['onload']=_0x38bb99['onreadystatechange']=null,_0x38bb99['parentNode']&&_0x38bb99['parentNode']['removeChild'](_0x38bb99),_0x77c5f9());},_0x38bb99['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2ea540),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x38bb99);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x8401e6,_0x55f357,_0x20a338,_0x4b686b,_0x25106f,_0x21241e,_0x1debdb){this['connId']=_0x8401e6,this['applicationId']=_0x20a338,this['appCheckToken']=_0x4b686b,this['authToken']=_0x25106f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x55f357),this['connURL']=G['connectionURL_'](_0x55f357,_0x21241e,_0x1debdb,_0x4b686b,_0x20a338),this['nodeAdmin']=_0x55f357['nodeAdmin'];}static['connectionURL_'](_0x4d8cdb,_0x3cb1e3,_0x4ec62a,_0x36e53c,_0x1e84b2){const _0x163464={};return _0x163464[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x163464[ao]=co),_0x3cb1e3&&(_0x163464[oo]=_0x3cb1e3),_0x4ec62a&&(_0x163464[ho]=_0x4ec62a),_0x36e53c&&(_0x163464[yi]=_0x36e53c),_0x1e84b2&&(_0x163464[uo]=_0x1e84b2),go(_0x4d8cdb,fo,_0x163464);}['open'](_0x6b3df0,_0x768e5f){this['onDisconnect']=_0x768e5f,this['onMessage']=_0x6b3df0,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x2da5b4;dc(),this['mySock']=new hn(this['connURL'],[],_0x2da5b4);}catch(_0x9a85d8){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x129ec0=_0x9a85d8['message']||_0x9a85d8['data'];_0x129ec0&&this['log_'](_0x129ec0),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x238909=>{this['handleIncomingFrame'](_0x238909);},this['mySock']['onerror']=_0x1b832d=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2bfe53=_0x1b832d['message']||_0x1b832d['data'];_0x2bfe53&&this['log_'](_0x2bfe53),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x4ec8bf=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x221dc7=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3fde54=navigator['userAgent']['match'](_0x221dc7);_0x3fde54&&_0x3fde54['length']>0x1&&parseFloat(_0x3fde54[0x1])<4.4&&(_0x4ec8bf=!0x0);}return!_0x4ec8bf&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x141e9b){if(this['frames']['push'](_0x141e9b),this['frames']['length']===this['totalFrames']){const _0x4c140b=this['frames']['join']('');this['frames']=null;const _0x43e3e4=bt(_0x4c140b);this['onMessage'](_0x43e3e4);}}['handleNewFrameCount_'](_0x4baeb2){this['totalFrames']=_0x4baeb2,this['frames']=[];}['extractFrameCount_'](_0x121746){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x121746['length']<=0x6){const _0x337fe9=Number(_0x121746);if(!isNaN(_0x337fe9))return this['handleNewFrameCount_'](_0x337fe9),null;}return this['handleNewFrameCount_'](0x1),_0x121746;}['handleIncomingFrame'](_0x1f0c96){if(this['mySock']===null)return;const _0x4cd3de=_0x1f0c96['data'];if(this['bytesReceived']+=_0x4cd3de['length'],this['stats_']['incrementCounter']('bytes_received',_0x4cd3de['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4cd3de);else{const _0x2ed3d5=this['extractFrameCount_'](_0x4cd3de);_0x2ed3d5!==null&&this['appendFrame_'](_0x2ed3d5);}}['send'](_0x1897af){this['resetKeepAlive']();const _0x2e6688=O(_0x1897af);this['bytesSent']+=_0x2e6688['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2e6688['length']);const _0x2d9d36=io(_0x2e6688,fh);_0x2d9d36['length']>0x1&&this['sendString_'](String(_0x2d9d36['length']));for(let _0xae30b5=0x0;_0xae30b5<_0x2d9d36['length'];_0xae30b5++)this['sendString_'](_0x2d9d36[_0xae30b5]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x3b6664){try{this['mySock']['send'](_0x3b6664);}catch(_0x9c68f9){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x9c68f9['message']||_0x9c68f9['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x21e140){this['initTransports_'](_0x21e140);}['initTransports_'](_0x170e83){const _0x326cce=G&&G['isAvailable']();let _0x320325=_0x326cce&&!G['previouslyFailed']();if(_0x170e83['webSocketOnly']&&(_0x326cce||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x320325=!0x0),_0x320325)this['transports_']=[G];else{const _0x28c919=this['transports_']=[];for(const _0x26f17e of At['ALL_TRANSPORTS'])_0x26f17e&&_0x26f17e['isAvailable']()&&_0x28c919['push'](_0x26f17e);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x370106,_0x2ce413,_0x100d3f,_0x3d3ad5,_0x2dc949,_0xeffe77,_0x388e00,_0x37e632,_0xd378aa,_0x2881ff){this['id']=_0x370106,this['repoInfo_']=_0x2ce413,this['applicationId_']=_0x100d3f,this['appCheckToken_']=_0x3d3ad5,this['authToken_']=_0x2dc949,this['onMessage_']=_0xeffe77,this['onReady_']=_0x388e00,this['onDisconnect_']=_0x37e632,this['onKill_']=_0xd378aa,this['lastSessionId']=_0x2881ff,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x2ce413),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x190273=this['transportManager_']['initialTransport']();this['conn_']=new _0x190273(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x190273['responsesRequiredToBeHealthy']||0x0;const _0x517127=this['connReceiver_'](this['conn_']),_0x3feffb=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x517127,_0x3feffb);},Math['floor'](0x0));const _0xb60bb3=_0x190273['healthyTimeout']||0x0;_0xb60bb3>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xb60bb3)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5e99fe){return _0x4423b0=>{_0x5e99fe===this['conn_']?this['onConnectionLost_'](_0x4423b0):_0x5e99fe===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x5351f0){return _0x40bf0a=>{this['state_']!==0x2&&(_0x5351f0===this['rx_']?this['onPrimaryMessageReceived_'](_0x40bf0a):_0x5351f0===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x40bf0a):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x14afa2){const _0x206df2={'t':'d','d':_0x14afa2};this['sendData_'](_0x206df2);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1f88b9){if(ii in _0x1f88b9){const _0x40a365=_0x1f88b9[ii];_0x40a365===js?this['upgradeIfSecondaryHealthy_']():_0x40a365===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x40a365===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0xcf586e){const _0x11ba23=pt('t',_0xcf586e),_0x4c4a60=pt('d',_0xcf586e);if(_0x11ba23==='c')this['onSecondaryControl_'](_0x4c4a60);else{if(_0x11ba23==='d')this['pendingDataMessages']['push'](_0x4c4a60);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x11ba23);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4dc715){const _0x46a2ae=pt('t',_0x4dc715),_0x1682fd=pt('d',_0x4dc715);_0x46a2ae==='c'?this['onControl_'](_0x1682fd):_0x46a2ae==='d'&&this['onDataMessage_'](_0x1682fd);}['onDataMessage_'](_0x1a0f41){this['onPrimaryResponse_'](),this['onMessage_'](_0x1a0f41);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x283c0e){const _0x5c97ca=pt(ii,_0x283c0e);if(Gs in _0x283c0e){const _0x2c41e3=_0x283c0e[Gs];if(_0x5c97ca===Ih){const _0x1409ec={..._0x2c41e3};this['repoInfo_']['isUsingEmulator']&&(_0x1409ec['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1409ec);}else{if(_0x5c97ca===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x41f770=0x0;_0x41f770<this['pendingDataMessages']['length'];++_0x41f770)this['onDataMessage_'](this['pendingDataMessages'][_0x41f770]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5c97ca===vh?this['onConnectionShutdown_'](_0x2c41e3):_0x5c97ca===qs?this['onReset_'](_0x2c41e3):_0x5c97ca===Eh?mi('Server\x20Error:\x20'+_0x2c41e3):_0x5c97ca===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x5c97ca);}}}['onHandshake_'](_0x1f1da9){const _0x4f2d19=_0x1f1da9['ts'],_0x1bce03=_0x1f1da9['v'],_0x231867=_0x1f1da9['h'];this['sessionId']=_0x1f1da9['s'],this['repoInfo_']['host']=_0x231867,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x4f2d19),Vi!==_0x1bce03&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x29fef6=this['transportManager_']['upgradeTransport']();_0x29fef6&&this['startUpgrade_'](_0x29fef6);}['startUpgrade_'](_0x37aa19){this['secondaryConn_']=new _0x37aa19(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x37aa19['responsesRequiredToBeHealthy']||0x0;const _0x27f77d=this['connReceiver_'](this['secondaryConn_']),_0x1ce305=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x27f77d,_0x1ce305),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x43bd29){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x43bd29),this['repoInfo_']['host']=_0x43bd29,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4addd3,_0x602d2f){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4addd3,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x602d2f,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x13d099=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x13d099||this['rx_']===_0x13d099)&&this['close']();}['onConnectionLost_'](_0xfc6665){this['conn_']=null,!_0xfc6665&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0xf1646f){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0xf1646f),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x466a7d){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x466a7d);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x5ed63b,_0x13dbfa,_0x2aca3e,_0x531a80){}['merge'](_0x109e6c,_0x4499d4,_0x4aed31,_0x2ee1b6){}['refreshAuthToken'](_0x388d69){}['refreshAppCheckToken'](_0xa6298a){}['onDisconnectPut'](_0x16c180,_0xf730fb,_0x51d2b4){}['onDisconnectMerge'](_0x5a9dd9,_0xdf7468,_0x56866d){}['onDisconnectCancel'](_0x399a88,_0x2c3c4d){}['reportStats'](_0x378153){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x4ac39b){this['allowedEvents_']=_0x4ac39b,this['listeners_']={},f(Array['isArray'](_0x4ac39b)&&_0x4ac39b['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x2e70cd,..._0x15e3b4){if(Array['isArray'](this['listeners_'][_0x2e70cd])){const _0x1f3ced=[...this['listeners_'][_0x2e70cd]];for(let _0x1ad23d=0x0;_0x1ad23d<_0x1f3ced['length'];_0x1ad23d++)_0x1f3ced[_0x1ad23d]['callback']['apply'](_0x1f3ced[_0x1ad23d]['context'],_0x15e3b4);}}['on'](_0x5f302c,_0xbaeb9a,_0x46975b){this['validateEventType_'](_0x5f302c),this['listeners_'][_0x5f302c]=this['listeners_'][_0x5f302c]||[],this['listeners_'][_0x5f302c]['push']({'callback':_0xbaeb9a,'context':_0x46975b});const _0x29cd04=this['getInitialEvent'](_0x5f302c);_0x29cd04&&_0xbaeb9a['apply'](_0x46975b,_0x29cd04);}['off'](_0x14f7de,_0x513fe1,_0x4b8264){this['validateEventType_'](_0x14f7de);const _0x1b711e=this['listeners_'][_0x14f7de]||[];for(let _0x1fb3c4=0x0;_0x1fb3c4<_0x1b711e['length'];_0x1fb3c4++)if(_0x1b711e[_0x1fb3c4]['callback']===_0x513fe1&&(!_0x4b8264||_0x4b8264===_0x1b711e[_0x1fb3c4]['context'])){_0x1b711e['splice'](_0x1fb3c4,0x1);return;}}['validateEventType_'](_0x1d81f1){f(this['allowedEvents_']['find'](_0x139276=>_0x139276===_0x1d81f1),'Unknown\x20event:\x20'+_0x1d81f1);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x105966){return f(_0x105966==='online','Unknown\x20event\x20type:\x20'+_0x105966),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x500926,_0x43bacd){if(_0x43bacd===void 0x0){this['pieces_']=_0x500926['split']('/');let _0x17738f=0x0;for(let _0x3a0393=0x0;_0x3a0393<this['pieces_']['length'];_0x3a0393++)this['pieces_'][_0x3a0393]['length']>0x0&&(this['pieces_'][_0x17738f]=this['pieces_'][_0x3a0393],_0x17738f++);this['pieces_']['length']=_0x17738f,this['pieceNum_']=0x0;}else this['pieces_']=_0x500926,this['pieceNum_']=_0x43bacd;}['toString'](){let _0x444826='';for(let _0x22f0d9=this['pieceNum_'];_0x22f0d9<this['pieces_']['length'];_0x22f0d9++)this['pieces_'][_0x22f0d9]!==''&&(_0x444826+='/'+this['pieces_'][_0x22f0d9]);return _0x444826||'/';}}function w(){return new C('');}function y(_0x3d7569){return _0x3d7569['pieceNum_']>=_0x3d7569['pieces_']['length']?null:_0x3d7569['pieces_'][_0x3d7569['pieceNum_']];}function we(_0x3072e3){return _0x3072e3['pieces_']['length']-_0x3072e3['pieceNum_'];}function b(_0x9e806f){let _0xeabfee=_0x9e806f['pieceNum_'];return _0xeabfee<_0x9e806f['pieces_']['length']&&_0xeabfee++,new C(_0x9e806f['pieces_'],_0xeabfee);}function Gi(_0x20d5fc){return _0x20d5fc['pieceNum_']<_0x20d5fc['pieces_']['length']?_0x20d5fc['pieces_'][_0x20d5fc['pieces_']['length']-0x1]:null;}function Ch(_0x2f50e3){let _0x12bb7a='';for(let _0x3f751a=_0x2f50e3['pieceNum_'];_0x3f751a<_0x2f50e3['pieces_']['length'];_0x3f751a++)_0x2f50e3['pieces_'][_0x3f751a]!==''&&(_0x12bb7a+='/'+encodeURIComponent(String(_0x2f50e3['pieces_'][_0x3f751a])));return _0x12bb7a||'/';}function kt(_0x3bd2a2,_0x1a3833=0x0){return _0x3bd2a2['pieces_']['slice'](_0x3bd2a2['pieceNum_']+_0x1a3833);}function To(_0x289130){if(_0x289130['pieceNum_']>=_0x289130['pieces_']['length'])return null;const _0x5e3583=[];for(let _0x5198c5=_0x289130['pieceNum_'];_0x5198c5<_0x289130['pieces_']['length']-0x1;_0x5198c5++)_0x5e3583['push'](_0x289130['pieces_'][_0x5198c5]);return new C(_0x5e3583,0x0);}function A(_0x44256d,_0x122ff0){const _0x49a814=[];for(let _0x518606=_0x44256d['pieceNum_'];_0x518606<_0x44256d['pieces_']['length'];_0x518606++)_0x49a814['push'](_0x44256d['pieces_'][_0x518606]);if(_0x122ff0 instanceof C){for(let _0x1faceb=_0x122ff0['pieceNum_'];_0x1faceb<_0x122ff0['pieces_']['length'];_0x1faceb++)_0x49a814['push'](_0x122ff0['pieces_'][_0x1faceb]);}else{const _0x570f7a=_0x122ff0['split']('/');for(let _0x33126d=0x0;_0x33126d<_0x570f7a['length'];_0x33126d++)_0x570f7a[_0x33126d]['length']>0x0&&_0x49a814['push'](_0x570f7a[_0x33126d]);}return new C(_0x49a814,0x0);}function v(_0x5bd995){return _0x5bd995['pieceNum_']>=_0x5bd995['pieces_']['length'];}function F(_0x1744ac,_0x3c538c){const _0x278f34=y(_0x1744ac),_0x471f74=y(_0x3c538c);if(_0x278f34===null)return _0x3c538c;if(_0x278f34===_0x471f74)return F(b(_0x1744ac),b(_0x3c538c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3c538c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1744ac+')');}function Th(_0x191067,_0x134ab1){const _0x3a5138=kt(_0x191067,0x0),_0xdff19e=kt(_0x134ab1,0x0);for(let _0x541cfa=0x0;_0x541cfa<_0x3a5138['length']&&_0x541cfa<_0xdff19e['length'];_0x541cfa++){const _0x5d2c42=He(_0x3a5138[_0x541cfa],_0xdff19e[_0x541cfa]);if(_0x5d2c42!==0x0)return _0x5d2c42;}return _0x3a5138['length']===_0xdff19e['length']?0x0:_0x3a5138['length']<_0xdff19e['length']?-0x1:0x1;}function qi(_0x5b6ba9,_0x1070c9){if(we(_0x5b6ba9)!==we(_0x1070c9))return!0x1;for(let _0x1f3eb0=_0x5b6ba9['pieceNum_'],_0x48e580=_0x1070c9['pieceNum_'];_0x1f3eb0<=_0x5b6ba9['pieces_']['length'];_0x1f3eb0++,_0x48e580++)if(_0x5b6ba9['pieces_'][_0x1f3eb0]!==_0x1070c9['pieces_'][_0x48e580])return!0x1;return!0x0;}function $(_0x357ccc,_0x139145){let _0x42f1ab=_0x357ccc['pieceNum_'],_0x5b5309=_0x139145['pieceNum_'];if(we(_0x357ccc)>we(_0x139145))return!0x1;for(;_0x42f1ab<_0x357ccc['pieces_']['length'];){if(_0x357ccc['pieces_'][_0x42f1ab]!==_0x139145['pieces_'][_0x5b5309])return!0x1;++_0x42f1ab,++_0x5b5309;}return!0x0;}class Sh{constructor(_0x59fa47,_0x8f14fc){this['errorPrefix_']=_0x8f14fc,this['parts_']=kt(_0x59fa47,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x20755b=0x0;_0x20755b<this['parts_']['length'];_0x20755b++)this['byteLength_']+=Pn(this['parts_'][_0x20755b]);So(this);}}function bh(_0x1c371c,_0x673998){_0x1c371c['parts_']['length']>0x0&&(_0x1c371c['byteLength_']+=0x1),_0x1c371c['parts_']['push'](_0x673998),_0x1c371c['byteLength_']+=Pn(_0x673998),So(_0x1c371c);}function Rh(_0x40b61d){const _0x2c148b=_0x40b61d['parts_']['pop']();_0x40b61d['byteLength_']-=Pn(_0x2c148b),_0x40b61d['parts_']['length']>0x0&&(_0x40b61d['byteLength_']-=0x1);}function So(_0x568d67){if(_0x568d67['byteLength_']>Js)throw new Error(_0x568d67['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x568d67['byteLength_']+').');if(_0x568d67['parts_']['length']>Qs)throw new Error(_0x568d67['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x568d67));}function Ne(_0x1d8349){return _0x1d8349['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1d8349['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x48fffa,_0x23a7f7;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x23a7f7='visibilitychange',_0x48fffa='hidden'):typeof document['mozHidden']<'u'?(_0x23a7f7='mozvisibilitychange',_0x48fffa='mozHidden'):typeof document['msHidden']<'u'?(_0x23a7f7='msvisibilitychange',_0x48fffa='msHidden'):typeof document['webkitHidden']<'u'&&(_0x23a7f7='webkitvisibilitychange',_0x48fffa='webkitHidden')),this['visible_']=!0x0,_0x23a7f7&&document['addEventListener'](_0x23a7f7,()=>{const _0x2bc3dc=!document[_0x48fffa];_0x2bc3dc!==this['visible_']&&(this['visible_']=_0x2bc3dc,this['trigger']('visible',_0x2bc3dc));},!0x1);}['getInitialEvent'](_0x4581db){return f(_0x4581db==='visible','Unknown\x20event\x20type:\x20'+_0x4581db),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x293fd5,_0x5ef90b,_0x22cea3,_0x4830fb,_0x12d22a,_0x10f9b7,_0x407e3e,_0x18c9d7){if(super(),this['repoInfo_']=_0x293fd5,this['applicationId_']=_0x5ef90b,this['onDataUpdate_']=_0x22cea3,this['onConnectStatus_']=_0x4830fb,this['onServerInfoUpdate_']=_0x12d22a,this['authTokenProvider_']=_0x10f9b7,this['appCheckTokenProvider_']=_0x407e3e,this['authOverride_']=_0x18c9d7,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x18c9d7)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x293fd5['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x13bf27,_0x566397,_0x15b98c){const _0x45f2cc=++this['requestNumber_'],_0x20511a={'r':_0x45f2cc,'a':_0x13bf27,'b':_0x566397};this['log_'](O(_0x20511a)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x20511a),_0x15b98c&&(this['requestCBHash_'][_0x45f2cc]=_0x15b98c);}['get'](_0x3d5d30){this['initConnection_']();const _0x1cd938=new Ve(),_0x37ae2b={'action':'g','request':{'p':_0x3d5d30['_path']['toString'](),'q':_0x3d5d30['_queryObject']},'onComplete':_0x5725a2=>{const _0x6d1ea0=_0x5725a2['d'];_0x5725a2['s']==='ok'?_0x1cd938['resolve'](_0x6d1ea0):_0x1cd938['reject'](_0x6d1ea0);}};this['outstandingGets_']['push'](_0x37ae2b),this['outstandingGetCount_']++;const _0xa94b2d=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0xa94b2d),_0x1cd938['promise'];}['listen'](_0x547eab,_0x3fe454,_0x26a095,_0x48168c){this['initConnection_']();const _0x2bf3e0=_0x547eab['_queryIdentifier'],_0x4cc1e2=_0x547eab['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4cc1e2+'\x20'+_0x2bf3e0),this['listens']['has'](_0x4cc1e2)||this['listens']['set'](_0x4cc1e2,new Map()),f(_0x547eab['_queryParams']['isDefault']()||!_0x547eab['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4cc1e2)['has'](_0x2bf3e0),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x32947c={'onComplete':_0x48168c,'hashFn':_0x3fe454,'query':_0x547eab,'tag':_0x26a095};this['listens']['get'](_0x4cc1e2)['set'](_0x2bf3e0,_0x32947c),this['connected_']&&this['sendListen_'](_0x32947c);}['sendGet_'](_0x32983d){const _0x4dd5aa=this['outstandingGets_'][_0x32983d];this['sendRequest']('g',_0x4dd5aa['request'],_0x2628b4=>{delete this['outstandingGets_'][_0x32983d],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x4dd5aa['onComplete']&&_0x4dd5aa['onComplete'](_0x2628b4);});}['sendListen_'](_0xc820a3){const _0x207ca0=_0xc820a3['query'],_0x4fad73=_0x207ca0['_path']['toString'](),_0x5dc382=_0x207ca0['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x4fad73+'\x20for\x20'+_0x5dc382);const _0x315ad2={'p':_0x4fad73},_0xa1692d='q';_0xc820a3['tag']&&(_0x315ad2['q']=_0x207ca0['_queryObject'],_0x315ad2['t']=_0xc820a3['tag']),_0x315ad2['h']=_0xc820a3['hashFn'](),this['sendRequest'](_0xa1692d,_0x315ad2,_0xab00e3=>{const _0x370597=_0xab00e3['d'],_0x5d7eec=_0xab00e3['s'];ie['warnOnListenWarnings_'](_0x370597,_0x207ca0),(this['listens']['get'](_0x4fad73)&&this['listens']['get'](_0x4fad73)['get'](_0x5dc382))===_0xc820a3&&(this['log_']('listen\x20response',_0xab00e3),_0x5d7eec!=='ok'&&this['removeListen_'](_0x4fad73,_0x5dc382),_0xc820a3['onComplete']&&_0xc820a3['onComplete'](_0x5d7eec,_0x370597));});}static['warnOnListenWarnings_'](_0x1fb510,_0x5bb1e8){if(_0x1fb510&&typeof _0x1fb510=='object'&&Y(_0x1fb510,'w')){const _0x4fcff9=Oe(_0x1fb510,'w');if(Array['isArray'](_0x4fcff9)&&~_0x4fcff9['indexOf']('no_index')){const _0x26f620='\x22.indexOn\x22:\x20\x22'+_0x5bb1e8['_queryParams']['getIndex']()['toString']()+'\x22',_0x2a16f4=_0x5bb1e8['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x26f620+'\x20at\x20'+_0x2a16f4+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x288bb6){this['authToken_']=_0x288bb6,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x288bb6);}['reduceReconnectDelayIfAdminCredential_'](_0x51a081){(_0x51a081&&_0x51a081['length']===0x28||vc(_0x51a081))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0xf339aa){this['appCheckToken_']=_0xf339aa,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xc95547=this['authToken_'],_0x21d38b=yc(_0xc95547)?'auth':'gauth',_0x6f0c18={'cred':_0xc95547};this['authOverride_']===null?_0x6f0c18['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x6f0c18['authvar']=this['authOverride_']),this['sendRequest'](_0x21d38b,_0x6f0c18,_0x2b82f3=>{const _0x2a0012=_0x2b82f3['s'],_0x90c68f=_0x2b82f3['d']||'error';this['authToken_']===_0xc95547&&(_0x2a0012==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2a0012,_0x90c68f));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0xa7f901=>{const _0x11560b=_0xa7f901['s'],_0x3aa27c=_0xa7f901['d']||'error';_0x11560b==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x11560b,_0x3aa27c);});}['unlisten'](_0x36240b,_0x1367af){const _0x4bddd3=_0x36240b['_path']['toString'](),_0x595c90=_0x36240b['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x4bddd3+'\x20'+_0x595c90),f(_0x36240b['_queryParams']['isDefault']()||!_0x36240b['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x4bddd3,_0x595c90)&&this['connected_']&&this['sendUnlisten_'](_0x4bddd3,_0x595c90,_0x36240b['_queryObject'],_0x1367af);}['sendUnlisten_'](_0x51ac4c,_0x61d1d0,_0x68c4c7,_0x5a53e1){this['log_']('Unlisten\x20on\x20'+_0x51ac4c+'\x20for\x20'+_0x61d1d0);const _0x3ec132={'p':_0x51ac4c},_0x4c4306='n';_0x5a53e1&&(_0x3ec132['q']=_0x68c4c7,_0x3ec132['t']=_0x5a53e1),this['sendRequest'](_0x4c4306,_0x3ec132);}['onDisconnectPut'](_0x1011c7,_0x334065,_0x18a736){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1011c7,_0x334065,_0x18a736):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1011c7,'action':'o','data':_0x334065,'onComplete':_0x18a736});}['onDisconnectMerge'](_0x31a20b,_0x5ae0f2,_0x216b23){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x31a20b,_0x5ae0f2,_0x216b23):this['onDisconnectRequestQueue_']['push']({'pathString':_0x31a20b,'action':'om','data':_0x5ae0f2,'onComplete':_0x216b23});}['onDisconnectCancel'](_0x31f1b1,_0x477739){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x31f1b1,null,_0x477739):this['onDisconnectRequestQueue_']['push']({'pathString':_0x31f1b1,'action':'oc','data':null,'onComplete':_0x477739});}['sendOnDisconnect_'](_0xa83b95,_0xa5d6d5,_0x5ef4c5,_0x2440de){const _0x2c4851={'p':_0xa5d6d5,'d':_0x5ef4c5};this['log_']('onDisconnect\x20'+_0xa83b95,_0x2c4851),this['sendRequest'](_0xa83b95,_0x2c4851,_0x5b6a7d=>{_0x2440de&&setTimeout(()=>{_0x2440de(_0x5b6a7d['s'],_0x5b6a7d['d']);},Math['floor'](0x0));});}['put'](_0x2f5ed1,_0x4db223,_0x3dff7d,_0x415348){this['putInternal']('p',_0x2f5ed1,_0x4db223,_0x3dff7d,_0x415348);}['merge'](_0x10be5b,_0x1c5aa8,_0x55b792,_0x575460){this['putInternal']('m',_0x10be5b,_0x1c5aa8,_0x55b792,_0x575460);}['putInternal'](_0x265cb9,_0x43e337,_0x1408f3,_0x18d1b1,_0x3d03dd){this['initConnection_']();const _0x362de6={'p':_0x43e337,'d':_0x1408f3};_0x3d03dd!==void 0x0&&(_0x362de6['h']=_0x3d03dd),this['outstandingPuts_']['push']({'action':_0x265cb9,'request':_0x362de6,'onComplete':_0x18d1b1}),this['outstandingPutCount_']++;const _0x317ba5=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x317ba5):this['log_']('Buffering\x20put:\x20'+_0x43e337);}['sendPut_'](_0x55d0d4){const _0x56b11e=this['outstandingPuts_'][_0x55d0d4]['action'],_0x1277fd=this['outstandingPuts_'][_0x55d0d4]['request'],_0x2e0ed7=this['outstandingPuts_'][_0x55d0d4]['onComplete'];this['outstandingPuts_'][_0x55d0d4]['queued']=this['connected_'],this['sendRequest'](_0x56b11e,_0x1277fd,_0x49d41d=>{this['log_'](_0x56b11e+'\x20response',_0x49d41d),delete this['outstandingPuts_'][_0x55d0d4],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2e0ed7&&_0x2e0ed7(_0x49d41d['s'],_0x49d41d['d']);});}['reportStats'](_0x150460){if(this['connected_']){const _0x413f6f={'c':_0x150460};this['log_']('reportStats',_0x413f6f),this['sendRequest']('s',_0x413f6f,_0x5629b7=>{if(_0x5629b7['s']!=='ok'){const _0x572a52=_0x5629b7['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x572a52);}});}}['onDataMessage_'](_0x14c014){if('r'in _0x14c014){this['log_']('from\x20server:\x20'+O(_0x14c014));const _0x16b17f=_0x14c014['r'],_0x423af6=this['requestCBHash_'][_0x16b17f];_0x423af6&&(delete this['requestCBHash_'][_0x16b17f],_0x423af6(_0x14c014['b']));}else{if('error'in _0x14c014)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x14c014['error'];'a'in _0x14c014&&this['onDataPush_'](_0x14c014['a'],_0x14c014['b']);}}['onDataPush_'](_0x1a44d1,_0x962a67){this['log_']('handleServerMessage',_0x1a44d1,_0x962a67),_0x1a44d1==='d'?this['onDataUpdate_'](_0x962a67['p'],_0x962a67['d'],!0x1,_0x962a67['t']):_0x1a44d1==='m'?this['onDataUpdate_'](_0x962a67['p'],_0x962a67['d'],!0x0,_0x962a67['t']):_0x1a44d1==='c'?this['onListenRevoked_'](_0x962a67['p'],_0x962a67['q']):_0x1a44d1==='ac'?this['onAuthRevoked_'](_0x962a67['s'],_0x962a67['d']):_0x1a44d1==='apc'?this['onAppCheckRevoked_'](_0x962a67['s'],_0x962a67['d']):_0x1a44d1==='sd'?this['onSecurityDebugPacket_'](_0x962a67):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x1a44d1)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3192b3,_0x980864){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3192b3),this['lastSessionId']=_0x980864,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4d86fa){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4d86fa));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5345b1){_0x5345b1&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5345b1;}['onOnline_'](_0xcdc8b7){_0xcdc8b7?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x9c591c=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x2abce5=Math['max'](0x0,this['reconnectDelay_']-_0x9c591c);_0x2abce5=Math['random']()*_0x2abce5,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x2abce5+'ms'),this['scheduleConnect_'](_0x2abce5),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2ea46a=this['onDataMessage_']['bind'](this),_0x21e8ac=this['onReady_']['bind'](this),_0x4f0abe=this['onRealtimeDisconnect_']['bind'](this),_0x113dce=this['id']+':'+ie['nextConnectionId_']++,_0x28c477=this['lastSessionId'];let _0x1758b2=!0x1,_0x198512=null;const _0x5561e2=function(){_0x198512?_0x198512['close']():(_0x1758b2=!0x0,_0x4f0abe());},_0x22bf0a=function(_0x2e667c){f(_0x198512,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x198512['sendRequest'](_0x2e667c);};this['realtime_']={'close':_0x5561e2,'sendRequest':_0x22bf0a};const _0x468b44=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x443d63,_0xca8a29]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x468b44),this['appCheckTokenProvider_']['getToken'](_0x468b44)]);_0x1758b2?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x443d63&&_0x443d63['accessToken'],this['appCheckToken_']=_0xca8a29&&_0xca8a29['token'],_0x198512=new wh(_0x113dce,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2ea46a,_0x21e8ac,_0x4f0abe,_0x261558=>{U(_0x261558+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x28c477));}catch(_0x4c630f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4c630f),_0x1758b2||(this['repoInfo_']['nodeAdmin']&&U(_0x4c630f),_0x5561e2());}}}['interrupt'](_0x35cc9b){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x35cc9b),this['interruptReasons_'][_0x35cc9b]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x22fbe8){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x22fbe8),delete this['interruptReasons_'][_0x22fbe8],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x397fd5){const _0x1079fd=_0x397fd5-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1079fd});}['cancelSentTransactions_'](){for(let _0x19d2d2=0x0;_0x19d2d2<this['outstandingPuts_']['length'];_0x19d2d2++){const _0x58cc74=this['outstandingPuts_'][_0x19d2d2];_0x58cc74&&'h'in _0x58cc74['request']&&_0x58cc74['queued']&&(_0x58cc74['onComplete']&&_0x58cc74['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x19d2d2],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x39028e,_0x2c3c31){let _0x188ff5;_0x2c3c31?_0x188ff5=_0x2c3c31['map'](_0x54639f=>Bi(_0x54639f))['join']('$'):_0x188ff5='default';const _0x256ed4=this['removeListen_'](_0x39028e,_0x188ff5);_0x256ed4&&_0x256ed4['onComplete']&&_0x256ed4['onComplete']('permission_denied');}['removeListen_'](_0x8dae97,_0x142ec8){const _0x34b723=new C(_0x8dae97)['toString']();let _0x50fd3a;if(this['listens']['has'](_0x34b723)){const _0x3d22df=this['listens']['get'](_0x34b723);_0x50fd3a=_0x3d22df['get'](_0x142ec8),_0x3d22df['delete'](_0x142ec8),_0x3d22df['size']===0x0&&this['listens']['delete'](_0x34b723);}else _0x50fd3a=void 0x0;return _0x50fd3a;}['onAuthRevoked_'](_0x520e1d,_0x276744){L('Auth\x20token\x20revoked:\x20'+_0x520e1d+'/'+_0x276744),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x520e1d==='invalid_token'||_0x520e1d==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x158759,_0x1732b3){L('App\x20check\x20token\x20revoked:\x20'+_0x158759+'/'+_0x1732b3),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x158759==='invalid_token'||_0x158759==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x11df27){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x11df27):'msg'in _0x11df27&&console['log']('FIREBASE:\x20'+_0x11df27['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x308719 of this['listens']['values']())for(const _0x5a59b1 of _0x308719['values']())this['sendListen_'](_0x5a59b1);for(let _0x234ef6=0x0;_0x234ef6<this['outstandingPuts_']['length'];_0x234ef6++)this['outstandingPuts_'][_0x234ef6]&&this['sendPut_'](_0x234ef6);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2630cd=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2630cd['action'],_0x2630cd['pathString'],_0x2630cd['data'],_0x2630cd['onComplete']);}for(let _0x928495=0x0;_0x928495<this['outstandingGets_']['length'];_0x928495++)this['outstandingGets_'][_0x928495]&&this['sendGet_'](_0x928495);}['sendConnectStats_'](){const _0x675e04={};let _0x194ee3='js';_0x675e04['sdk.'+_0x194ee3+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x675e04['framework.cordova']=0x1:qr()&&(_0x675e04['framework.reactnative']=0x1),this['reportStats'](_0x675e04);}['shouldReconnect_'](){const _0x33c1f3=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x33c1f3;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3daf51,_0x2686c8){this['name']=_0x3daf51,this['node']=_0x2686c8;}static['Wrap'](_0x5bb63c,_0x2a6f83){return new E(_0x5bb63c,_0x2a6f83);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3d95b0,_0xde4ec9){const _0x37c9b3=new E(xe,_0x3d95b0),_0x3e01c5=new E(xe,_0xde4ec9);return this['compare'](_0x37c9b3,_0x3e01c5)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x1b877c){Xt=_0x1b877c;}['compare'](_0x384adc,_0x5c693c){return He(_0x384adc['name'],_0x5c693c['name']);}['isDefinedOn'](_0x1ea616){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4b4c7f,_0x3feb8c){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x28e216,_0x296643){return f(typeof _0x28e216=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x28e216,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x25f133,_0x3ac555,_0x36afc3,_0x426a59,_0x151ac7=null){this['isReverse_']=_0x426a59,this['resultGenerator_']=_0x151ac7,this['nodeStack_']=[];let _0x296f0a=0x1;for(;!_0x25f133['isEmpty']();)if(_0x25f133=_0x25f133,_0x296f0a=_0x3ac555?_0x36afc3(_0x25f133['key'],_0x3ac555):0x1,_0x426a59&&(_0x296f0a*=-0x1),_0x296f0a<0x0)this['isReverse_']?_0x25f133=_0x25f133['left']:_0x25f133=_0x25f133['right'];else{if(_0x296f0a===0x0){this['nodeStack_']['push'](_0x25f133);break;}else this['nodeStack_']['push'](_0x25f133),this['isReverse_']?_0x25f133=_0x25f133['right']:_0x25f133=_0x25f133['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x50aaef=this['nodeStack_']['pop'](),_0x2bd20a;if(this['resultGenerator_']?_0x2bd20a=this['resultGenerator_'](_0x50aaef['key'],_0x50aaef['value']):_0x2bd20a={'key':_0x50aaef['key'],'value':_0x50aaef['value']},this['isReverse_']){for(_0x50aaef=_0x50aaef['left'];!_0x50aaef['isEmpty']();)this['nodeStack_']['push'](_0x50aaef),_0x50aaef=_0x50aaef['right'];}else{for(_0x50aaef=_0x50aaef['right'];!_0x50aaef['isEmpty']();)this['nodeStack_']['push'](_0x50aaef),_0x50aaef=_0x50aaef['left'];}return _0x2bd20a;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xb8f552=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xb8f552['key'],_0xb8f552['value']):{'key':_0xb8f552['key'],'value':_0xb8f552['value']};}}class M{constructor(_0x165b91,_0x194ac6,_0x3d53ae,_0x3a7d33,_0x2bd4d2){this['key']=_0x165b91,this['value']=_0x194ac6,this['color']=_0x3d53ae??M['RED'],this['left']=_0x3a7d33??B['EMPTY_NODE'],this['right']=_0x2bd4d2??B['EMPTY_NODE'];}['copy'](_0x4f07fb,_0x12aa7c,_0x3dbcc8,_0x4c2e61,_0x2a260a){return new M(_0x4f07fb??this['key'],_0x12aa7c??this['value'],_0x3dbcc8??this['color'],_0x4c2e61??this['left'],_0x2a260a??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x49a53e){return this['left']['inorderTraversal'](_0x49a53e)||!!_0x49a53e(this['key'],this['value'])||this['right']['inorderTraversal'](_0x49a53e);}['reverseTraversal'](_0x2ccf6a){return this['right']['reverseTraversal'](_0x2ccf6a)||_0x2ccf6a(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2ccf6a);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2a7516,_0x14ab4a,_0x52578f){let _0x3b050d=this;const _0x562ea9=_0x52578f(_0x2a7516,_0x3b050d['key']);return _0x562ea9<0x0?_0x3b050d=_0x3b050d['copy'](null,null,null,_0x3b050d['left']['insert'](_0x2a7516,_0x14ab4a,_0x52578f),null):_0x562ea9===0x0?_0x3b050d=_0x3b050d['copy'](null,_0x14ab4a,null,null,null):_0x3b050d=_0x3b050d['copy'](null,null,null,null,_0x3b050d['right']['insert'](_0x2a7516,_0x14ab4a,_0x52578f)),_0x3b050d['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1ec26c=this;return!_0x1ec26c['left']['isRed_']()&&!_0x1ec26c['left']['left']['isRed_']()&&(_0x1ec26c=_0x1ec26c['moveRedLeft_']()),_0x1ec26c=_0x1ec26c['copy'](null,null,null,_0x1ec26c['left']['removeMin_'](),null),_0x1ec26c['fixUp_']();}['remove'](_0x1155db,_0x3f4c39){let _0x53993d,_0x581e21;if(_0x53993d=this,_0x3f4c39(_0x1155db,_0x53993d['key'])<0x0)!_0x53993d['left']['isEmpty']()&&!_0x53993d['left']['isRed_']()&&!_0x53993d['left']['left']['isRed_']()&&(_0x53993d=_0x53993d['moveRedLeft_']()),_0x53993d=_0x53993d['copy'](null,null,null,_0x53993d['left']['remove'](_0x1155db,_0x3f4c39),null);else{if(_0x53993d['left']['isRed_']()&&(_0x53993d=_0x53993d['rotateRight_']()),!_0x53993d['right']['isEmpty']()&&!_0x53993d['right']['isRed_']()&&!_0x53993d['right']['left']['isRed_']()&&(_0x53993d=_0x53993d['moveRedRight_']()),_0x3f4c39(_0x1155db,_0x53993d['key'])===0x0){if(_0x53993d['right']['isEmpty']())return B['EMPTY_NODE'];_0x581e21=_0x53993d['right']['min_'](),_0x53993d=_0x53993d['copy'](_0x581e21['key'],_0x581e21['value'],null,null,_0x53993d['right']['removeMin_']());}_0x53993d=_0x53993d['copy'](null,null,null,null,_0x53993d['right']['remove'](_0x1155db,_0x3f4c39));}return _0x53993d['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4bc81b=this;return _0x4bc81b['right']['isRed_']()&&!_0x4bc81b['left']['isRed_']()&&(_0x4bc81b=_0x4bc81b['rotateLeft_']()),_0x4bc81b['left']['isRed_']()&&_0x4bc81b['left']['left']['isRed_']()&&(_0x4bc81b=_0x4bc81b['rotateRight_']()),_0x4bc81b['left']['isRed_']()&&_0x4bc81b['right']['isRed_']()&&(_0x4bc81b=_0x4bc81b['colorFlip_']()),_0x4bc81b;}['moveRedLeft_'](){let _0x31c372=this['colorFlip_']();return _0x31c372['right']['left']['isRed_']()&&(_0x31c372=_0x31c372['copy'](null,null,null,null,_0x31c372['right']['rotateRight_']()),_0x31c372=_0x31c372['rotateLeft_'](),_0x31c372=_0x31c372['colorFlip_']()),_0x31c372;}['moveRedRight_'](){let _0x4c01db=this['colorFlip_']();return _0x4c01db['left']['left']['isRed_']()&&(_0x4c01db=_0x4c01db['rotateRight_'](),_0x4c01db=_0x4c01db['colorFlip_']()),_0x4c01db;}['rotateLeft_'](){const _0x360280=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x360280,null);}['rotateRight_'](){const _0x27c37=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x27c37);}['colorFlip_'](){const _0x1d67d6=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x23a22e=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1d67d6,_0x23a22e);}['checkMaxDepth_'](){const _0x5d676e=this['check_']();return Math['pow'](0x2,_0x5d676e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x242529=this['left']['check_']();if(_0x242529!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x242529+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x20c70a,_0x25166f,_0x1dc0f3,_0x44e1de,_0x351352){return this;}['insert'](_0x395970,_0x1c61f4,_0x5c11ca){return new M(_0x395970,_0x1c61f4,null);}['remove'](_0x45f735,_0x537dac){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4870d4){return!0x1;}['reverseTraversal'](_0x591162){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x196063,_0x402178=B['EMPTY_NODE']){this['comparator_']=_0x196063,this['root_']=_0x402178;}['insert'](_0x3e6a98,_0x4334cb){return new B(this['comparator_'],this['root_']['insert'](_0x3e6a98,_0x4334cb,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x453e24){return new B(this['comparator_'],this['root_']['remove'](_0x453e24,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x21c849){let _0x796554,_0x3a3322=this['root_'];for(;!_0x3a3322['isEmpty']();){if(_0x796554=this['comparator_'](_0x21c849,_0x3a3322['key']),_0x796554===0x0)return _0x3a3322['value'];_0x796554<0x0?_0x3a3322=_0x3a3322['left']:_0x796554>0x0&&(_0x3a3322=_0x3a3322['right']);}return null;}['getPredecessorKey'](_0x5113bb){let _0x15aa5a,_0x159d45=this['root_'],_0x23a9a1=null;for(;!_0x159d45['isEmpty']();)if(_0x15aa5a=this['comparator_'](_0x5113bb,_0x159d45['key']),_0x15aa5a===0x0){if(_0x159d45['left']['isEmpty']())return _0x23a9a1?_0x23a9a1['key']:null;for(_0x159d45=_0x159d45['left'];!_0x159d45['right']['isEmpty']();)_0x159d45=_0x159d45['right'];return _0x159d45['key'];}else _0x15aa5a<0x0?_0x159d45=_0x159d45['left']:_0x15aa5a>0x0&&(_0x23a9a1=_0x159d45,_0x159d45=_0x159d45['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x3492b7){return this['root_']['inorderTraversal'](_0x3492b7);}['reverseTraversal'](_0x4366d8){return this['root_']['reverseTraversal'](_0x4366d8);}['getIterator'](_0x4804bb){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x4804bb);}['getIteratorFrom'](_0x52e185,_0x24cabe){return new Zt(this['root_'],_0x52e185,this['comparator_'],!0x1,_0x24cabe);}['getReverseIteratorFrom'](_0x303020,_0x40911c){return new Zt(this['root_'],_0x303020,this['comparator_'],!0x0,_0x40911c);}['getReverseIterator'](_0x15cba4){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x15cba4);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x52a6c8,_0x223c10){return He(_0x52a6c8['name'],_0x223c10['name']);}function ji(_0x3df925,_0x54a4ad){return He(_0x3df925,_0x54a4ad);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x1ccd92){vi=_0x1ccd92;}const Ro=function(_0x121390){return typeof _0x121390=='number'?'number:'+so(_0x121390):'string:'+_0x121390;},Ao=function(_0x3074c4){if(_0x3074c4['isLeafNode']()){const _0xf6211f=_0x3074c4['val']();f(typeof _0xf6211f=='string'||typeof _0xf6211f=='number'||typeof _0xf6211f=='object'&&Y(_0xf6211f,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3074c4===vi||_0x3074c4['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3074c4===vi||_0x3074c4['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x5d6ac2){er=_0x5d6ac2;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x3a559f,_0x354576=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3a559f,this['priorityNode_']=_0x354576,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1d5491){return new D(this['value_'],_0x1d5491);}['getImmediateChild'](_0x82cfbc){return _0x82cfbc==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x468c3a){return v(_0x468c3a)?this:y(_0x468c3a)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x22bfe6,_0x10ca80){return null;}['updateImmediateChild'](_0x3764fc,_0x3ffb81){return _0x3764fc==='.priority'?this['updatePriority'](_0x3ffb81):_0x3ffb81['isEmpty']()&&_0x3764fc!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x3764fc,_0x3ffb81)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x29a40b,_0x412518){const _0x3a3253=y(_0x29a40b);return _0x3a3253===null?_0x412518:_0x412518['isEmpty']()&&_0x3a3253!=='.priority'?this:(f(_0x3a3253!=='.priority'||we(_0x29a40b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3a3253,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x29a40b),_0x412518)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x18b92e,_0x25955e){return!0x1;}['val'](_0x1106e2){return _0x1106e2&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x583ca4='';this['priorityNode_']['isEmpty']()||(_0x583ca4+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x53970a=typeof this['value_'];_0x583ca4+=_0x53970a+':',_0x53970a==='number'?_0x583ca4+=so(this['value_']):_0x583ca4+=this['value_'],this['lazyHash_']=no(_0x583ca4);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x297754){return _0x297754===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x297754 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x297754['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x297754));}['compareToLeafNode_'](_0x5d6a7c){const _0x275487=typeof _0x5d6a7c['value_'],_0x12247c=typeof this['value_'],_0x463eed=D['VALUE_TYPE_ORDER']['indexOf'](_0x275487),_0x4f3089=D['VALUE_TYPE_ORDER']['indexOf'](_0x12247c);return f(_0x463eed>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x275487),f(_0x4f3089>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x12247c),_0x463eed===_0x4f3089?_0x12247c==='object'?0x0:this['value_']<_0x5d6a7c['value_']?-0x1:this['value_']===_0x5d6a7c['value_']?0x0:0x1:_0x4f3089-_0x463eed;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4321a7){if(_0x4321a7===this)return!0x0;if(_0x4321a7['isLeafNode']()){const _0x3b7c47=_0x4321a7;return this['value_']===_0x3b7c47['value_']&&this['priorityNode_']['equals'](_0x3b7c47['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x2825d2){ko=_0x2825d2;}function xh(_0x43ccc0){No=_0x43ccc0;}class Fh extends On{['compare'](_0x5a2443,_0x2d8620){const _0x338766=_0x5a2443['node']['getPriority'](),_0x61fad6=_0x2d8620['node']['getPriority'](),_0x428c33=_0x338766['compareTo'](_0x61fad6);return _0x428c33===0x0?He(_0x5a2443['name'],_0x2d8620['name']):_0x428c33;}['isDefinedOn'](_0x302b10){return!_0x302b10['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3d280f,_0x11b9f7){return!_0x3d280f['getPriority']()['equals'](_0x11b9f7['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0xcf283d,_0xeabdb7){const _0x2e237b=ko(_0xcf283d);return new E(_0xeabdb7,new D('[PRIORITY-POST]',_0x2e237b));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0xb79184){const _0x95809b=_0x538958=>parseInt(Math['log'](_0x538958)/Uh,0xa),_0x244ce8=_0x3555d6=>parseInt(Array(_0x3555d6+0x1)['join']('1'),0x2);this['count']=_0x95809b(_0xb79184+0x1),this['current_']=this['count']-0x1;const _0x3eae82=_0x244ce8(this['count']);this['bits_']=_0xb79184+0x1&_0x3eae82;}['nextBitIsOne'](){const _0x4c2af9=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4c2af9;}}const dn=function(_0x4d87a4,_0x3b42ab,_0x26a9ed,_0x3c5d8a){_0x4d87a4['sort'](_0x3b42ab);const _0x3057de=function(_0x4c0b80,_0x3ca662){const _0x587064=_0x3ca662-_0x4c0b80;let _0xa9bb28,_0x50d2a8;if(_0x587064===0x0)return null;if(_0x587064===0x1)return _0xa9bb28=_0x4d87a4[_0x4c0b80],_0x50d2a8=_0x26a9ed?_0x26a9ed(_0xa9bb28):_0xa9bb28,new M(_0x50d2a8,_0xa9bb28['node'],M['BLACK'],null,null);{const _0x374240=parseInt(_0x587064/0x2,0xa)+_0x4c0b80,_0x267fbf=_0x3057de(_0x4c0b80,_0x374240),_0x43419e=_0x3057de(_0x374240+0x1,_0x3ca662);return _0xa9bb28=_0x4d87a4[_0x374240],_0x50d2a8=_0x26a9ed?_0x26a9ed(_0xa9bb28):_0xa9bb28,new M(_0x50d2a8,_0xa9bb28['node'],M['BLACK'],_0x267fbf,_0x43419e);}},_0x226ed5=function(_0x244be2){let _0x45efb4=null,_0x26233a=null,_0x15eef5=_0x4d87a4['length'];const _0x18789a=function(_0x17fe02,_0x6d57ce){const _0x343c1b=_0x15eef5-_0x17fe02,_0x38210a=_0x15eef5;_0x15eef5-=_0x17fe02;const _0xabb1b=_0x3057de(_0x343c1b+0x1,_0x38210a),_0x361d64=_0x4d87a4[_0x343c1b],_0x3ecbfe=_0x26a9ed?_0x26a9ed(_0x361d64):_0x361d64;_0x2cc73d(new M(_0x3ecbfe,_0x361d64['node'],_0x6d57ce,null,_0xabb1b));},_0x2cc73d=function(_0x271d25){_0x45efb4?(_0x45efb4['left']=_0x271d25,_0x45efb4=_0x271d25):(_0x26233a=_0x271d25,_0x45efb4=_0x271d25);};for(let _0x48c61e=0x0;_0x48c61e<_0x244be2['count'];++_0x48c61e){const _0x49ff82=_0x244be2['nextBitIsOne'](),_0x1bf6e7=Math['pow'](0x2,_0x244be2['count']-(_0x48c61e+0x1));_0x49ff82?_0x18789a(_0x1bf6e7,M['BLACK']):(_0x18789a(_0x1bf6e7,M['BLACK']),_0x18789a(_0x1bf6e7,M['RED']));}return _0x26233a;},_0x296321=new Wh(_0x4d87a4['length']),_0x54ad4a=_0x226ed5(_0x296321);return new B(_0x3c5d8a||_0x3b42ab,_0x54ad4a);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x340a00,_0x108870){this['indexes_']=_0x340a00,this['indexSet_']=_0x108870;}['get'](_0x4b5273){const _0x113dcd=Oe(this['indexes_'],_0x4b5273);if(!_0x113dcd)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4b5273);return _0x113dcd instanceof B?_0x113dcd:null;}['hasIndex'](_0x1cf6d4){return Y(this['indexSet_'],_0x1cf6d4['toString']());}['addIndex'](_0x15b787,_0x43c3d1){f(_0x15b787!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4b1253=[];let _0x246a2a=!0x1;const _0xa57e82=_0x43c3d1['getIterator'](E['Wrap']);let _0x5e775e=_0xa57e82['getNext']();for(;_0x5e775e;)_0x246a2a=_0x246a2a||_0x15b787['isDefinedOn'](_0x5e775e['node']),_0x4b1253['push'](_0x5e775e),_0x5e775e=_0xa57e82['getNext']();let _0x409c05;_0x246a2a?_0x409c05=dn(_0x4b1253,_0x15b787['getCompare']()):_0x409c05=je;const _0x10a32a=_0x15b787['toString'](),_0x14bc06={...this['indexSet_']};_0x14bc06[_0x10a32a]=_0x15b787;const _0x36b8d4={...this['indexes_']};return _0x36b8d4[_0x10a32a]=_0x409c05,new ee(_0x36b8d4,_0x14bc06);}['addToIndexes'](_0x3c2681,_0xdf765c){const _0x47d568=ln(this['indexes_'],(_0x52a9b6,_0xe45226)=>{const _0x15f5de=Oe(this['indexSet_'],_0xe45226);if(f(_0x15f5de,'Missing\x20index\x20implementation\x20for\x20'+_0xe45226),_0x52a9b6===je){if(_0x15f5de['isDefinedOn'](_0x3c2681['node'])){const _0x15174d=[],_0x3a717f=_0xdf765c['getIterator'](E['Wrap']);let _0x2f7a6e=_0x3a717f['getNext']();for(;_0x2f7a6e;)_0x2f7a6e['name']!==_0x3c2681['name']&&_0x15174d['push'](_0x2f7a6e),_0x2f7a6e=_0x3a717f['getNext']();return _0x15174d['push'](_0x3c2681),dn(_0x15174d,_0x15f5de['getCompare']());}else return je;}else{const _0x21f307=_0xdf765c['get'](_0x3c2681['name']);let _0x3a08aa=_0x52a9b6;return _0x21f307&&(_0x3a08aa=_0x3a08aa['remove'](new E(_0x3c2681['name'],_0x21f307))),_0x3a08aa['insert'](_0x3c2681,_0x3c2681['node']);}});return new ee(_0x47d568,this['indexSet_']);}['removeFromIndexes'](_0x169f3b,_0x401555){const _0x133534=ln(this['indexes_'],_0x24fa32=>{if(_0x24fa32===je)return _0x24fa32;{const _0x27844b=_0x401555['get'](_0x169f3b['name']);return _0x27844b?_0x24fa32['remove'](new E(_0x169f3b['name'],_0x27844b)):_0x24fa32;}});return new ee(_0x133534,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x421145,_0x475a4b,_0x3eafc2){this['children_']=_0x421145,this['priorityNode_']=_0x475a4b,this['indexMap_']=_0x3eafc2,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x3aac54){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x3aac54,this['indexMap_']);}['getImmediateChild'](_0x5404e6){if(_0x5404e6==='.priority')return this['getPriority']();{const _0x26b5a4=this['children_']['get'](_0x5404e6);return _0x26b5a4===null?gt:_0x26b5a4;}}['getChild'](_0x4ccfe2){const _0x34d3b1=y(_0x4ccfe2);return _0x34d3b1===null?this:this['getImmediateChild'](_0x34d3b1)['getChild'](b(_0x4ccfe2));}['hasChild'](_0x504ec7){return this['children_']['get'](_0x504ec7)!==null;}['updateImmediateChild'](_0x3974ac,_0x18d765){if(f(_0x18d765,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3974ac==='.priority')return this['updatePriority'](_0x18d765);{const _0x575b4a=new E(_0x3974ac,_0x18d765);let _0x47ceb6,_0x5b292f;_0x18d765['isEmpty']()?(_0x47ceb6=this['children_']['remove'](_0x3974ac),_0x5b292f=this['indexMap_']['removeFromIndexes'](_0x575b4a,this['children_'])):(_0x47ceb6=this['children_']['insert'](_0x3974ac,_0x18d765),_0x5b292f=this['indexMap_']['addToIndexes'](_0x575b4a,this['children_']));const _0x5e2464=_0x47ceb6['isEmpty']()?gt:this['priorityNode_'];return new g(_0x47ceb6,_0x5e2464,_0x5b292f);}}['updateChild'](_0x2998ae,_0x10f6ec){const _0xecc035=y(_0x2998ae);if(_0xecc035===null)return _0x10f6ec;{f(y(_0x2998ae)!=='.priority'||we(_0x2998ae)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x55ec5b=this['getImmediateChild'](_0xecc035)['updateChild'](b(_0x2998ae),_0x10f6ec);return this['updateImmediateChild'](_0xecc035,_0x55ec5b);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x518907){if(this['isEmpty']())return null;const _0x359859={};let _0x2b9546=0x0,_0x450cf8=0x0,_0x420ad7=!0x0;if(this['forEachChild'](R,(_0x24ae6b,_0x375aea)=>{_0x359859[_0x24ae6b]=_0x375aea['val'](_0x518907),_0x2b9546++,_0x420ad7&&g['INTEGER_REGEXP_']['test'](_0x24ae6b)?_0x450cf8=Math['max'](_0x450cf8,Number(_0x24ae6b)):_0x420ad7=!0x1;}),!_0x518907&&_0x420ad7&&_0x450cf8<0x2*_0x2b9546){const _0x588bbd=[];for(const _0x286298 in _0x359859)_0x588bbd[_0x286298]=_0x359859[_0x286298];return _0x588bbd;}else return _0x518907&&!this['getPriority']()['isEmpty']()&&(_0x359859['.priority']=this['getPriority']()['val']()),_0x359859;}['hash'](){if(this['lazyHash_']===null){let _0x17a83e='';this['getPriority']()['isEmpty']()||(_0x17a83e+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2632b7,_0x2edc7c)=>{const _0x386c0d=_0x2edc7c['hash']();_0x386c0d!==''&&(_0x17a83e+=':'+_0x2632b7+':'+_0x386c0d);}),this['lazyHash_']=_0x17a83e===''?'':no(_0x17a83e);}return this['lazyHash_'];}['getPredecessorChildName'](_0x532307,_0x330935,_0x4ad4f0){const _0x50ee54=this['resolveIndex_'](_0x4ad4f0);if(_0x50ee54){const _0x4c41db=_0x50ee54['getPredecessorKey'](new E(_0x532307,_0x330935));return _0x4c41db?_0x4c41db['name']:null;}else return this['children_']['getPredecessorKey'](_0x532307);}['getFirstChildName'](_0x48dd64){const _0x47c0d8=this['resolveIndex_'](_0x48dd64);if(_0x47c0d8){const _0x2afd0e=_0x47c0d8['minKey']();return _0x2afd0e&&_0x2afd0e['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x2d280f){const _0x941fa8=this['getFirstChildName'](_0x2d280f);return _0x941fa8?new E(_0x941fa8,this['children_']['get'](_0x941fa8)):null;}['getLastChildName'](_0x183dbc){const _0x5201f1=this['resolveIndex_'](_0x183dbc);if(_0x5201f1){const _0x23ee2c=_0x5201f1['maxKey']();return _0x23ee2c&&_0x23ee2c['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3c33b9){const _0x4dc760=this['getLastChildName'](_0x3c33b9);return _0x4dc760?new E(_0x4dc760,this['children_']['get'](_0x4dc760)):null;}['forEachChild'](_0x1d4c17,_0x1a8b50){const _0xe276c7=this['resolveIndex_'](_0x1d4c17);return _0xe276c7?_0xe276c7['inorderTraversal'](_0x56b347=>_0x1a8b50(_0x56b347['name'],_0x56b347['node'])):this['children_']['inorderTraversal'](_0x1a8b50);}['getIterator'](_0x22c118){return this['getIteratorFrom'](_0x22c118['minPost'](),_0x22c118);}['getIteratorFrom'](_0x1004cc,_0x3b3765){const _0x5e621b=this['resolveIndex_'](_0x3b3765);if(_0x5e621b)return _0x5e621b['getIteratorFrom'](_0x1004cc,_0x15b906=>_0x15b906);{const _0x16dcdb=this['children_']['getIteratorFrom'](_0x1004cc['name'],E['Wrap']);let _0x3c9714=_0x16dcdb['peek']();for(;_0x3c9714!=null&&_0x3b3765['compare'](_0x3c9714,_0x1004cc)<0x0;)_0x16dcdb['getNext'](),_0x3c9714=_0x16dcdb['peek']();return _0x16dcdb;}}['getReverseIterator'](_0x18c212){return this['getReverseIteratorFrom'](_0x18c212['maxPost'](),_0x18c212);}['getReverseIteratorFrom'](_0x597d11,_0x325515){const _0x96aa5a=this['resolveIndex_'](_0x325515);if(_0x96aa5a)return _0x96aa5a['getReverseIteratorFrom'](_0x597d11,_0x3122ad=>_0x3122ad);{const _0x5302a1=this['children_']['getReverseIteratorFrom'](_0x597d11['name'],E['Wrap']);let _0x3c59b3=_0x5302a1['peek']();for(;_0x3c59b3!=null&&_0x325515['compare'](_0x3c59b3,_0x597d11)>0x0;)_0x5302a1['getNext'](),_0x3c59b3=_0x5302a1['peek']();return _0x5302a1;}}['compareTo'](_0x3d2820){return this['isEmpty']()?_0x3d2820['isEmpty']()?0x0:-0x1:_0x3d2820['isLeafNode']()||_0x3d2820['isEmpty']()?0x1:_0x3d2820===Ht?-0x1:0x0;}['withIndex'](_0x5c349b){if(_0x5c349b===ye||this['indexMap_']['hasIndex'](_0x5c349b))return this;{const _0x2e61f7=this['indexMap_']['addIndex'](_0x5c349b,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2e61f7);}}['isIndexed'](_0x243ce7){return _0x243ce7===ye||this['indexMap_']['hasIndex'](_0x243ce7);}['equals'](_0x5068d7){if(_0x5068d7===this)return!0x0;if(_0x5068d7['isLeafNode']())return!0x1;{const _0x15e6e7=_0x5068d7;if(this['getPriority']()['equals'](_0x15e6e7['getPriority']())){if(this['children_']['count']()===_0x15e6e7['children_']['count']()){const _0x2d3cee=this['getIterator'](R),_0x3e95e2=_0x15e6e7['getIterator'](R);let _0x363186=_0x2d3cee['getNext'](),_0x3211a2=_0x3e95e2['getNext']();for(;_0x363186&&_0x3211a2;){if(_0x363186['name']!==_0x3211a2['name']||!_0x363186['node']['equals'](_0x3211a2['node']))return!0x1;_0x363186=_0x2d3cee['getNext'](),_0x3211a2=_0x3e95e2['getNext']();}return _0x363186===null&&_0x3211a2===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3792e4){return _0x3792e4===ye?null:this['indexMap_']['get'](_0x3792e4['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x32c8fd){return _0x32c8fd===this?0x0:0x1;}['equals'](_0x455cc7){return _0x455cc7===this;}['getPriority'](){return this;}['getImmediateChild'](_0x23f755){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x438ce9,_0xc6ffc1=null){if(_0x438ce9===null)return g['EMPTY_NODE'];if(typeof _0x438ce9=='object'&&'.priority'in _0x438ce9&&(_0xc6ffc1=_0x438ce9['.priority']),f(_0xc6ffc1===null||typeof _0xc6ffc1=='string'||typeof _0xc6ffc1=='number'||typeof _0xc6ffc1=='object'&&'.sv'in _0xc6ffc1,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0xc6ffc1),typeof _0x438ce9=='object'&&'.value'in _0x438ce9&&_0x438ce9['.value']!==null&&(_0x438ce9=_0x438ce9['.value']),typeof _0x438ce9!='object'||'.sv'in _0x438ce9){const _0x28a2fa=_0x438ce9;return new D(_0x28a2fa,N(_0xc6ffc1));}if(!(_0x438ce9 instanceof Array)&&Vh){const _0x333a7f=[];let _0x327f0e=!0x1;if(x(_0x438ce9,(_0x4ce9d8,_0x1387ba)=>{if(_0x4ce9d8['substring'](0x0,0x1)!=='.'){const _0x371a76=N(_0x1387ba);_0x371a76['isEmpty']()||(_0x327f0e=_0x327f0e||!_0x371a76['getPriority']()['isEmpty'](),_0x333a7f['push'](new E(_0x4ce9d8,_0x371a76)));}}),_0x333a7f['length']===0x0)return g['EMPTY_NODE'];const _0x43e574=dn(_0x333a7f,Dh,_0x32dd5a=>_0x32dd5a['name'],ji);if(_0x327f0e){const _0x33c2f6=dn(_0x333a7f,R['getCompare']());return new g(_0x43e574,N(_0xc6ffc1),new ee({'.priority':_0x33c2f6},{'.priority':R}));}else return new g(_0x43e574,N(_0xc6ffc1),ee['Default']);}else{let _0x4a6f54=g['EMPTY_NODE'];return x(_0x438ce9,(_0x37009a,_0x140be8)=>{if(Y(_0x438ce9,_0x37009a)&&_0x37009a['substring'](0x0,0x1)!=='.'){const _0x2d45f7=N(_0x140be8);(_0x2d45f7['isLeafNode']()||!_0x2d45f7['isEmpty']())&&(_0x4a6f54=_0x4a6f54['updateImmediateChild'](_0x37009a,_0x2d45f7));}}),_0x4a6f54['updatePriority'](N(_0xc6ffc1));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x47f65f){super(),this['indexPath_']=_0x47f65f,f(!v(_0x47f65f)&&y(_0x47f65f)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x34fef2){return _0x34fef2['getChild'](this['indexPath_']);}['isDefinedOn'](_0x423e1a){return!_0x423e1a['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x395baf,_0x3d253f){const _0x4b163e=this['extractChild'](_0x395baf['node']),_0x4775ee=this['extractChild'](_0x3d253f['node']),_0x1befcf=_0x4b163e['compareTo'](_0x4775ee);return _0x1befcf===0x0?He(_0x395baf['name'],_0x3d253f['name']):_0x1befcf;}['makePost'](_0x6efbc6,_0x1c2feb){const _0x43c09a=N(_0x6efbc6),_0x588090=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x43c09a);return new E(_0x1c2feb,_0x588090);}['maxPost'](){const _0x1f4fc1=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x1f4fc1);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x5d6651,_0xda34ba){const _0x201fac=_0x5d6651['node']['compareTo'](_0xda34ba['node']);return _0x201fac===0x0?He(_0x5d6651['name'],_0xda34ba['name']):_0x201fac;}['isDefinedOn'](_0x5c40ab){return!0x0;}['indexedValueChanged'](_0x3b695b,_0x1363b4){return!_0x3b695b['equals'](_0x1363b4);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4eea63,_0xbfb90f){const _0x1ecdda=N(_0x4eea63);return new E(_0xbfb90f,_0x1ecdda);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x5b3151){return{'type':'value','snapshotNode':_0x5b3151};}function tt(_0x3d0efa,_0x585c18){return{'type':'child_added','snapshotNode':_0x585c18,'childName':_0x3d0efa};}function Nt(_0xb41313,_0x277a3a){return{'type':'child_removed','snapshotNode':_0x277a3a,'childName':_0xb41313};}function Pt(_0x126166,_0xcefc00,_0x34b107){return{'type':'child_changed','snapshotNode':_0xcefc00,'childName':_0x126166,'oldSnap':_0x34b107};}function $h(_0x579c70,_0x58381d){return{'type':'child_moved','snapshotNode':_0x58381d,'childName':_0x579c70};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x3b9615){this['index_']=_0x3b9615;}['updateChild'](_0x25977d,_0x4ff9c9,_0x5cb76d,_0x22e20c,_0x58f241,_0x128718){f(_0x25977d['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0xe48366=_0x25977d['getImmediateChild'](_0x4ff9c9);return _0xe48366['getChild'](_0x22e20c)['equals'](_0x5cb76d['getChild'](_0x22e20c))&&_0xe48366['isEmpty']()===_0x5cb76d['isEmpty']()||(_0x128718!=null&&(_0x5cb76d['isEmpty']()?_0x25977d['hasChild'](_0x4ff9c9)?_0x128718['trackChildChange'](Nt(_0x4ff9c9,_0xe48366)):f(_0x25977d['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0xe48366['isEmpty']()?_0x128718['trackChildChange'](tt(_0x4ff9c9,_0x5cb76d)):_0x128718['trackChildChange'](Pt(_0x4ff9c9,_0x5cb76d,_0xe48366))),_0x25977d['isLeafNode']()&&_0x5cb76d['isEmpty']())?_0x25977d:_0x25977d['updateImmediateChild'](_0x4ff9c9,_0x5cb76d)['withIndex'](this['index_']);}['updateFullNode'](_0x3f9f55,_0xf655d,_0x243c3c){return _0x243c3c!=null&&(_0x3f9f55['isLeafNode']()||_0x3f9f55['forEachChild'](R,(_0x5d8133,_0x195231)=>{_0xf655d['hasChild'](_0x5d8133)||_0x243c3c['trackChildChange'](Nt(_0x5d8133,_0x195231));}),_0xf655d['isLeafNode']()||_0xf655d['forEachChild'](R,(_0x3fec9d,_0x55bed4)=>{if(_0x3f9f55['hasChild'](_0x3fec9d)){const _0x26b7af=_0x3f9f55['getImmediateChild'](_0x3fec9d);_0x26b7af['equals'](_0x55bed4)||_0x243c3c['trackChildChange'](Pt(_0x3fec9d,_0x55bed4,_0x26b7af));}else _0x243c3c['trackChildChange'](tt(_0x3fec9d,_0x55bed4));})),_0xf655d['withIndex'](this['index_']);}['updatePriority'](_0x10c3e8,_0x39d281){return _0x10c3e8['isEmpty']()?g['EMPTY_NODE']:_0x10c3e8['updatePriority'](_0x39d281);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x4b48db){this['indexedFilter_']=new Yi(_0x4b48db['getIndex']()),this['index_']=_0x4b48db['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x4b48db),this['endPost_']=Ot['getEndPost_'](_0x4b48db),this['startIsInclusive_']=!_0x4b48db['startAfterSet_'],this['endIsInclusive_']=!_0x4b48db['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x121c06){const _0xb74d7e=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x121c06)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x121c06)<0x0,_0x48cd36=this['endIsInclusive_']?this['index_']['compare'](_0x121c06,this['getEndPost']())<=0x0:this['index_']['compare'](_0x121c06,this['getEndPost']())<0x0;return _0xb74d7e&&_0x48cd36;}['updateChild'](_0x31d121,_0x5971a1,_0x6194a0,_0xf0fb12,_0x4f1b20,_0x2d14d3){return this['matches'](new E(_0x5971a1,_0x6194a0))||(_0x6194a0=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x31d121,_0x5971a1,_0x6194a0,_0xf0fb12,_0x4f1b20,_0x2d14d3);}['updateFullNode'](_0x2902d2,_0x41e3fa,_0x54c316){_0x41e3fa['isLeafNode']()&&(_0x41e3fa=g['EMPTY_NODE']);let _0x56631e=_0x41e3fa['withIndex'](this['index_']);_0x56631e=_0x56631e['updatePriority'](g['EMPTY_NODE']);const _0x546023=this;return _0x41e3fa['forEachChild'](R,(_0x616135,_0x2cb7de)=>{_0x546023['matches'](new E(_0x616135,_0x2cb7de))||(_0x56631e=_0x56631e['updateImmediateChild'](_0x616135,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x2902d2,_0x56631e,_0x54c316);}['updatePriority'](_0x321e69,_0x29bd84){return _0x321e69;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x455be7){if(_0x455be7['hasStart']()){const _0x1d7771=_0x455be7['getIndexStartName']();return _0x455be7['getIndex']()['makePost'](_0x455be7['getIndexStartValue'](),_0x1d7771);}else return _0x455be7['getIndex']()['minPost']();}static['getEndPost_'](_0x26634f){if(_0x26634f['hasEnd']()){const _0x239046=_0x26634f['getIndexEndName']();return _0x26634f['getIndex']()['makePost'](_0x26634f['getIndexEndValue'](),_0x239046);}else return _0x26634f['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x44db63){this['withinDirectionalStart']=_0x528fa6=>this['reverse_']?this['withinEndPost'](_0x528fa6):this['withinStartPost'](_0x528fa6),this['withinDirectionalEnd']=_0x4e5239=>this['reverse_']?this['withinStartPost'](_0x4e5239):this['withinEndPost'](_0x4e5239),this['withinStartPost']=_0x11d08d=>{const _0x195983=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x11d08d);return this['startIsInclusive_']?_0x195983<=0x0:_0x195983<0x0;},this['withinEndPost']=_0x1cd6fd=>{const _0x4740ca=this['index_']['compare'](_0x1cd6fd,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4740ca<=0x0:_0x4740ca<0x0;},this['rangedFilter_']=new Ot(_0x44db63),this['index_']=_0x44db63['getIndex'](),this['limit_']=_0x44db63['getLimit'](),this['reverse_']=!_0x44db63['isViewFromLeft'](),this['startIsInclusive_']=!_0x44db63['startAfterSet_'],this['endIsInclusive_']=!_0x44db63['endBeforeSet_'];}['updateChild'](_0x464b5a,_0x208809,_0x441cdb,_0x5d8c99,_0x3bbc2b,_0x38f3d5){return this['rangedFilter_']['matches'](new E(_0x208809,_0x441cdb))||(_0x441cdb=g['EMPTY_NODE']),_0x464b5a['getImmediateChild'](_0x208809)['equals'](_0x441cdb)?_0x464b5a:_0x464b5a['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x464b5a,_0x208809,_0x441cdb,_0x5d8c99,_0x3bbc2b,_0x38f3d5):this['fullLimitUpdateChild_'](_0x464b5a,_0x208809,_0x441cdb,_0x3bbc2b,_0x38f3d5);}['updateFullNode'](_0x31530a,_0x389389,_0x338d68){let _0x53b165;if(_0x389389['isLeafNode']()||_0x389389['isEmpty']())_0x53b165=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x389389['numChildren']()&&_0x389389['isIndexed'](this['index_'])){_0x53b165=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x22ad2d;this['reverse_']?_0x22ad2d=_0x389389['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x22ad2d=_0x389389['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x5cab44=0x0;for(;_0x22ad2d['hasNext']()&&_0x5cab44<this['limit_'];){const _0x1ce07f=_0x22ad2d['getNext']();if(this['withinDirectionalStart'](_0x1ce07f)){if(this['withinDirectionalEnd'](_0x1ce07f))_0x53b165=_0x53b165['updateImmediateChild'](_0x1ce07f['name'],_0x1ce07f['node']),_0x5cab44++;else break;}else continue;}}else{_0x53b165=_0x389389['withIndex'](this['index_']),_0x53b165=_0x53b165['updatePriority'](g['EMPTY_NODE']);let _0x26c94a;this['reverse_']?_0x26c94a=_0x53b165['getReverseIterator'](this['index_']):_0x26c94a=_0x53b165['getIterator'](this['index_']);let _0x20c412=0x0;for(;_0x26c94a['hasNext']();){const _0x42e657=_0x26c94a['getNext']();_0x20c412<this['limit_']&&this['withinDirectionalStart'](_0x42e657)&&this['withinDirectionalEnd'](_0x42e657)?_0x20c412++:_0x53b165=_0x53b165['updateImmediateChild'](_0x42e657['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x31530a,_0x53b165,_0x338d68);}['updatePriority'](_0x169b8b,_0x51771c){return _0x169b8b;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x325e13,_0x9116f,_0xf627e0,_0x3ec81b,_0x46c390){let _0x3e5d39;if(this['reverse_']){const _0xb60dd1=this['index_']['getCompare']();_0x3e5d39=(_0x4c2eca,_0x259d0a)=>_0xb60dd1(_0x259d0a,_0x4c2eca);}else _0x3e5d39=this['index_']['getCompare']();const _0x1dd791=_0x325e13;f(_0x1dd791['numChildren']()===this['limit_'],'');const _0x3c7042=new E(_0x9116f,_0xf627e0),_0x2b3848=this['reverse_']?_0x1dd791['getFirstChild'](this['index_']):_0x1dd791['getLastChild'](this['index_']),_0xaf54a4=this['rangedFilter_']['matches'](_0x3c7042);if(_0x1dd791['hasChild'](_0x9116f)){const _0x513718=_0x1dd791['getImmediateChild'](_0x9116f);let _0x27ce02=_0x3ec81b['getChildAfterChild'](this['index_'],_0x2b3848,this['reverse_']);for(;_0x27ce02!=null&&(_0x27ce02['name']===_0x9116f||_0x1dd791['hasChild'](_0x27ce02['name']));)_0x27ce02=_0x3ec81b['getChildAfterChild'](this['index_'],_0x27ce02,this['reverse_']);const _0x246bc6=_0x27ce02==null?0x1:_0x3e5d39(_0x27ce02,_0x3c7042);if(_0xaf54a4&&!_0xf627e0['isEmpty']()&&_0x246bc6>=0x0)return _0x46c390!=null&&_0x46c390['trackChildChange'](Pt(_0x9116f,_0xf627e0,_0x513718)),_0x1dd791['updateImmediateChild'](_0x9116f,_0xf627e0);{_0x46c390!=null&&_0x46c390['trackChildChange'](Nt(_0x9116f,_0x513718));const _0x551dc6=_0x1dd791['updateImmediateChild'](_0x9116f,g['EMPTY_NODE']);return _0x27ce02!=null&&this['rangedFilter_']['matches'](_0x27ce02)?(_0x46c390!=null&&_0x46c390['trackChildChange'](tt(_0x27ce02['name'],_0x27ce02['node'])),_0x551dc6['updateImmediateChild'](_0x27ce02['name'],_0x27ce02['node'])):_0x551dc6;}}else return _0xf627e0['isEmpty']()?_0x325e13:_0xaf54a4&&_0x3e5d39(_0x2b3848,_0x3c7042)>=0x0?(_0x46c390!=null&&(_0x46c390['trackChildChange'](Nt(_0x2b3848['name'],_0x2b3848['node'])),_0x46c390['trackChildChange'](tt(_0x9116f,_0xf627e0))),_0x1dd791['updateImmediateChild'](_0x9116f,_0xf627e0)['updateImmediateChild'](_0x2b3848['name'],g['EMPTY_NODE'])):_0x325e13;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x357498=new Qi();return _0x357498['limitSet_']=this['limitSet_'],_0x357498['limit_']=this['limit_'],_0x357498['startSet_']=this['startSet_'],_0x357498['startAfterSet_']=this['startAfterSet_'],_0x357498['indexStartValue_']=this['indexStartValue_'],_0x357498['startNameSet_']=this['startNameSet_'],_0x357498['indexStartName_']=this['indexStartName_'],_0x357498['endSet_']=this['endSet_'],_0x357498['endBeforeSet_']=this['endBeforeSet_'],_0x357498['indexEndValue_']=this['indexEndValue_'],_0x357498['endNameSet_']=this['endNameSet_'],_0x357498['indexEndName_']=this['indexEndName_'],_0x357498['index_']=this['index_'],_0x357498['viewFrom_']=this['viewFrom_'],_0x357498;}}function qh(_0x172ffb){return _0x172ffb['loadsAllData']()?new Yi(_0x172ffb['getIndex']()):_0x172ffb['hasLimit']()?new Gh(_0x172ffb):new Ot(_0x172ffb);}function zh(_0x536a96,_0x3425e7){const _0xb45e0=_0x536a96['copy']();return _0xb45e0['limitSet_']=!0x0,_0xb45e0['limit_']=_0x3425e7,_0xb45e0['viewFrom_']='l',_0xb45e0;}function jh(_0x5c4d8c,_0x56671b,_0x33db43){const _0xa3d9b8=_0x5c4d8c['copy']();return _0xa3d9b8['startSet_']=!0x0,_0x56671b===void 0x0&&(_0x56671b=null),_0xa3d9b8['indexStartValue_']=_0x56671b,_0x33db43!=null?(_0xa3d9b8['startNameSet_']=!0x0,_0xa3d9b8['indexStartName_']=_0x33db43):(_0xa3d9b8['startNameSet_']=!0x1,_0xa3d9b8['indexStartName_']=''),_0xa3d9b8;}function Kh(_0x5a7589,_0x368cd2,_0x457b81){const _0x2b63fc=_0x5a7589['copy']();return _0x2b63fc['endSet_']=!0x0,_0x368cd2===void 0x0&&(_0x368cd2=null),_0x2b63fc['indexEndValue_']=_0x368cd2,_0x457b81!==void 0x0?(_0x2b63fc['endNameSet_']=!0x0,_0x2b63fc['indexEndName_']=_0x457b81):(_0x2b63fc['endNameSet_']=!0x1,_0x2b63fc['indexEndName_']=''),_0x2b63fc;}function Do(_0x297e65,_0x2ec7e8){const _0x4ce22b=_0x297e65['copy']();return _0x4ce22b['index_']=_0x2ec7e8,_0x4ce22b;}function tr(_0x2cd36f){const _0x49e9b9={};if(_0x2cd36f['isDefault']())return _0x49e9b9;let _0x9872d0;if(_0x2cd36f['index_']===R?_0x9872d0='$priority':_0x2cd36f['index_']===Po?_0x9872d0='$value':_0x2cd36f['index_']===ye?_0x9872d0='$key':(f(_0x2cd36f['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x9872d0=_0x2cd36f['index_']['toString']()),_0x49e9b9['orderBy']=O(_0x9872d0),_0x2cd36f['startSet_']){const _0xe3af0c=_0x2cd36f['startAfterSet_']?'startAfter':'startAt';_0x49e9b9[_0xe3af0c]=O(_0x2cd36f['indexStartValue_']),_0x2cd36f['startNameSet_']&&(_0x49e9b9[_0xe3af0c]+=','+O(_0x2cd36f['indexStartName_']));}if(_0x2cd36f['endSet_']){const _0x15bff1=_0x2cd36f['endBeforeSet_']?'endBefore':'endAt';_0x49e9b9[_0x15bff1]=O(_0x2cd36f['indexEndValue_']),_0x2cd36f['endNameSet_']&&(_0x49e9b9[_0x15bff1]+=','+O(_0x2cd36f['indexEndName_']));}return _0x2cd36f['limitSet_']&&(_0x2cd36f['isViewFromLeft']()?_0x49e9b9['limitToFirst']=_0x2cd36f['limit_']:_0x49e9b9['limitToLast']=_0x2cd36f['limit_']),_0x49e9b9;}function nr(_0x133030){const _0x3e28c8={};if(_0x133030['startSet_']&&(_0x3e28c8['sp']=_0x133030['indexStartValue_'],_0x133030['startNameSet_']&&(_0x3e28c8['sn']=_0x133030['indexStartName_']),_0x3e28c8['sin']=!_0x133030['startAfterSet_']),_0x133030['endSet_']&&(_0x3e28c8['ep']=_0x133030['indexEndValue_'],_0x133030['endNameSet_']&&(_0x3e28c8['en']=_0x133030['indexEndName_']),_0x3e28c8['ein']=!_0x133030['endBeforeSet_']),_0x133030['limitSet_']){_0x3e28c8['l']=_0x133030['limit_'];let _0x4f5bee=_0x133030['viewFrom_'];_0x4f5bee===''&&(_0x133030['isViewFromLeft']()?_0x4f5bee='l':_0x4f5bee='r'),_0x3e28c8['vf']=_0x4f5bee;}return _0x133030['index_']!==R&&(_0x3e28c8['i']=_0x133030['index_']['toString']()),_0x3e28c8;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x36cff0){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x209fbd,_0x1eaca9){return _0x1eaca9!==void 0x0?'tag$'+_0x1eaca9:(f(_0x209fbd['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x209fbd['_path']['toString']());}constructor(_0x407a02,_0x5b7626,_0x104149,_0xee7d5){super(),this['repoInfo_']=_0x407a02,this['onDataUpdate_']=_0x5b7626,this['authTokenProvider_']=_0x104149,this['appCheckTokenProvider_']=_0xee7d5,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x83f000,_0x4e9cd8,_0x243f5f,_0x48097b){const _0x23233f=_0x83f000['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x23233f+'\x20'+_0x83f000['_queryIdentifier']);const _0x5a308a=fn['getListenId_'](_0x83f000,_0x243f5f),_0x4eb896={};this['listens_'][_0x5a308a]=_0x4eb896;const _0x3b091e=tr(_0x83f000['_queryParams']);this['restRequest_'](_0x23233f+'.json',_0x3b091e,(_0x26bd1a,_0x1c91bc)=>{let _0x32b2fe=_0x1c91bc;if(_0x26bd1a===0x194&&(_0x32b2fe=null,_0x26bd1a=null),_0x26bd1a===null&&this['onDataUpdate_'](_0x23233f,_0x32b2fe,!0x1,_0x243f5f),Oe(this['listens_'],_0x5a308a)===_0x4eb896){let _0x413030;_0x26bd1a?_0x26bd1a===0x191?_0x413030='permission_denied':_0x413030='rest_error:'+_0x26bd1a:_0x413030='ok',_0x48097b(_0x413030,null);}});}['unlisten'](_0x19d286,_0x12516e){const _0x369f85=fn['getListenId_'](_0x19d286,_0x12516e);delete this['listens_'][_0x369f85];}['get'](_0x96c42a){const _0x334340=tr(_0x96c42a['_queryParams']),_0x132689=_0x96c42a['_path']['toString'](),_0x48336a=new Ve();return this['restRequest_'](_0x132689+'.json',_0x334340,(_0x186359,_0x365775)=>{let _0x32f4f0=_0x365775;_0x186359===0x194&&(_0x32f4f0=null,_0x186359=null),_0x186359===null?(this['onDataUpdate_'](_0x132689,_0x32f4f0,!0x1,null),_0x48336a['resolve'](_0x32f4f0)):_0x48336a['reject'](new Error(_0x32f4f0));}),_0x48336a['promise'];}['refreshAuthToken'](_0x28d79d){}['restRequest_'](_0x5148d0,_0x362343={},_0x5904e2){return _0x362343['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1f877c,_0x15d46d])=>{_0x1f877c&&_0x1f877c['accessToken']&&(_0x362343['auth']=_0x1f877c['accessToken']),_0x15d46d&&_0x15d46d['token']&&(_0x362343['ac']=_0x15d46d['token']);const _0x25b326=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5148d0+'?ns='+this['repoInfo_']['namespace']+at(_0x362343);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x25b326);const _0x398d38=new XMLHttpRequest();_0x398d38['onreadystatechange']=()=>{if(_0x5904e2&&_0x398d38['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x25b326+'\x20received.\x20status:',_0x398d38['status'],'response:',_0x398d38['responseText']);let _0x10c7d8=null;if(_0x398d38['status']>=0xc8&&_0x398d38['status']<0x12c){try{_0x10c7d8=bt(_0x398d38['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x25b326+':\x20'+_0x398d38['responseText']);}_0x5904e2(null,_0x10c7d8);}else _0x398d38['status']!==0x191&&_0x398d38['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x25b326+'\x20Status:\x20'+_0x398d38['status']),_0x5904e2(_0x398d38['status']);_0x5904e2=null;}},_0x398d38['open']('GET',_0x25b326,!0x0),_0x398d38['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x25243b){return this['rootNode_']['getChild'](_0x25243b);}['updateSnapshot'](_0x5303c4,_0x6ff2c0){this['rootNode_']=this['rootNode_']['updateChild'](_0x5303c4,_0x6ff2c0);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x389b95,_0x50f966,_0x5c80a1){if(v(_0x50f966))_0x389b95['value']=_0x5c80a1,_0x389b95['children']['clear']();else{if(_0x389b95['value']!==null)_0x389b95['value']=_0x389b95['value']['updateChild'](_0x50f966,_0x5c80a1);else{const _0x2b7e8a=y(_0x50f966);_0x389b95['children']['has'](_0x2b7e8a)||_0x389b95['children']['set'](_0x2b7e8a,pn());const _0x44ae46=_0x389b95['children']['get'](_0x2b7e8a);_0x50f966=b(_0x50f966),Mo(_0x44ae46,_0x50f966,_0x5c80a1);}}}function Ei(_0x10dd41,_0x54cc75,_0x1e239b){_0x10dd41['value']!==null?_0x1e239b(_0x54cc75,_0x10dd41['value']):Qh(_0x10dd41,(_0x237dcc,_0x1c2d46)=>{const _0x3b0539=new C(_0x54cc75['toString']()+'/'+_0x237dcc);Ei(_0x1c2d46,_0x3b0539,_0x1e239b);});}function Qh(_0x5e6ee2,_0x35ac7d){_0x5e6ee2['children']['forEach']((_0x49e7f0,_0x30f62c)=>{_0x35ac7d(_0x30f62c,_0x49e7f0);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x5f4023){this['collection_']=_0x5f4023,this['last_']=null;}['get'](){const _0x1eb1d5=this['collection_']['get'](),_0x3895a9={..._0x1eb1d5};return this['last_']&&x(this['last_'],(_0x580c2b,_0x2c7a0c)=>{_0x3895a9[_0x580c2b]=_0x3895a9[_0x580c2b]-_0x2c7a0c;}),this['last_']=_0x1eb1d5,_0x3895a9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x3c4884,_0x461f46){this['server_']=_0x461f46,this['statsToReport_']={},this['statsListener_']=new Jh(_0x3c4884);const _0x225700=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x225700));}['reportStats_'](){const _0x41f6c6=this['statsListener_']['get'](),_0x2b2cbc={};let _0x8e0982=!0x1;x(_0x41f6c6,(_0x55cd9b,_0x1eac28)=>{_0x1eac28>0x0&&Y(this['statsToReport_'],_0x55cd9b)&&(_0x2b2cbc[_0x55cd9b]=_0x1eac28,_0x8e0982=!0x0);}),_0x8e0982&&this['server_']['reportStats'](_0x2b2cbc),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x25c21e){_0x25c21e[_0x25c21e['OVERWRITE']=0x0]='OVERWRITE',_0x25c21e[_0x25c21e['MERGE']=0x1]='MERGE',_0x25c21e[_0x25c21e['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x25c21e[_0x25c21e['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x529bfb){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x529bfb,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0xa2ceed,_0x135548,_0x1c8781){this['path']=_0xa2ceed,this['affectedTree']=_0x135548,this['revert']=_0x1c8781,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x2b694a){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3a263e=this['affectedTree']['subtree'](new C(_0x2b694a));return new _n(w(),_0x3a263e,this['revert']);}}else return f(y(this['path'])===_0x2b694a,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x952004,_0x27e119){this['source']=_0x952004,this['path']=_0x27e119,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x51dc1c){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x829bcb,_0x2c55c9,_0x3d7f2a){this['source']=_0x829bcb,this['path']=_0x2c55c9,this['snap']=_0x3d7f2a,this['type']=q['OVERWRITE'];}['operationForChild'](_0x1f4569){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x1f4569)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x56b967,_0x3062c3,_0x76986b){this['source']=_0x56b967,this['path']=_0x3062c3,this['children']=_0x76986b,this['type']=q['MERGE'];}['operationForChild'](_0x2560e2){if(v(this['path'])){const _0x3739a5=this['children']['subtree'](new C(_0x2560e2));return _0x3739a5['isEmpty']()?null:_0x3739a5['value']?new Fe(this['source'],w(),_0x3739a5['value']):new nt(this['source'],w(),_0x3739a5);}else return f(y(this['path'])===_0x2560e2,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x410619,_0x457168,_0x587c0d){this['node_']=_0x410619,this['fullyInitialized_']=_0x457168,this['filtered_']=_0x587c0d;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x2774ee){if(v(_0x2774ee))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5bcb1d=y(_0x2774ee);return this['isCompleteForChild'](_0x5bcb1d);}['isCompleteForChild'](_0x35195a){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x35195a);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x2fada5){this['query_']=_0x2fada5,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x511e39,_0x1cfe7a,_0x3543c2,_0x5122c0){const _0x19f270=[],_0x2ad105=[];return _0x1cfe7a['forEach'](_0x877fd1=>{_0x877fd1['type']==='child_changed'&&_0x511e39['index_']['indexedValueChanged'](_0x877fd1['oldSnap'],_0x877fd1['snapshotNode'])&&_0x2ad105['push']($h(_0x877fd1['childName'],_0x877fd1['snapshotNode']));}),mt(_0x511e39,_0x19f270,'child_removed',_0x1cfe7a,_0x5122c0,_0x3543c2),mt(_0x511e39,_0x19f270,'child_added',_0x1cfe7a,_0x5122c0,_0x3543c2),mt(_0x511e39,_0x19f270,'child_moved',_0x2ad105,_0x5122c0,_0x3543c2),mt(_0x511e39,_0x19f270,'child_changed',_0x1cfe7a,_0x5122c0,_0x3543c2),mt(_0x511e39,_0x19f270,'value',_0x1cfe7a,_0x5122c0,_0x3543c2),_0x19f270;}function mt(_0x10ec2a,_0xb875c6,_0x516492,_0x4e7845,_0x41c9c0,_0x10753c){const _0xbaf8f0=_0x4e7845['filter'](_0x55f757=>_0x55f757['type']===_0x516492);_0xbaf8f0['sort']((_0x206da5,_0x157113)=>su(_0x10ec2a,_0x206da5,_0x157113)),_0xbaf8f0['forEach'](_0x18b1e7=>{const _0x1aeea3=iu(_0x10ec2a,_0x18b1e7,_0x10753c);_0x41c9c0['forEach'](_0x2d5c84=>{_0x2d5c84['respondsTo'](_0x18b1e7['type'])&&_0xb875c6['push'](_0x2d5c84['createEvent'](_0x1aeea3,_0x10ec2a['query_']));});});}function iu(_0x3ce44c,_0x2226a0,_0xc06c7c){return _0x2226a0['type']==='value'||_0x2226a0['type']==='child_removed'||(_0x2226a0['prevName']=_0xc06c7c['getPredecessorChildName'](_0x2226a0['childName'],_0x2226a0['snapshotNode'],_0x3ce44c['index_'])),_0x2226a0;}function su(_0x8c333d,_0xd6cb0e,_0x1c3b0e){if(_0xd6cb0e['childName']==null||_0x1c3b0e['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x2ec292=new E(_0xd6cb0e['childName'],_0xd6cb0e['snapshotNode']),_0x2a7f8b=new E(_0x1c3b0e['childName'],_0x1c3b0e['snapshotNode']);return _0x8c333d['index_']['compare'](_0x2ec292,_0x2a7f8b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x367054,_0x4f712f){return{'eventCache':_0x367054,'serverCache':_0x4f712f};}function wt(_0xd2ac50,_0x1b739c,_0x104f93,_0x3c4991){return Dn(new Ce(_0x1b739c,_0x104f93,_0x3c4991),_0xd2ac50['serverCache']);}function Lo(_0x508865,_0x5230db,_0x5ccf98,_0x5c432d){return Dn(_0x508865['eventCache'],new Ce(_0x5230db,_0x5ccf98,_0x5c432d));}function gn(_0x4a97b2){return _0x4a97b2['eventCache']['isFullyInitialized']()?_0x4a97b2['eventCache']['getNode']():null;}function Ue(_0x331b16){return _0x331b16['serverCache']['isFullyInitialized']()?_0x331b16['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x19c871){let _0x4fb3e1=new S(null);return x(_0x19c871,(_0x5736d0,_0x5b0d42)=>{_0x4fb3e1=_0x4fb3e1['set'](new C(_0x5736d0),_0x5b0d42);}),_0x4fb3e1;}constructor(_0xf51918,_0x2f6ab6=ru()){this['value']=_0xf51918,this['children']=_0x2f6ab6;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1667c0,_0x3c9eef){if(this['value']!=null&&_0x3c9eef(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1667c0))return null;{const _0x531bea=y(_0x1667c0),_0x56e902=this['children']['get'](_0x531bea);if(_0x56e902!==null){const _0xa3a1a3=_0x56e902['findRootMostMatchingPathAndValue'](b(_0x1667c0),_0x3c9eef);return _0xa3a1a3!=null?{'path':A(new C(_0x531bea),_0xa3a1a3['path']),'value':_0xa3a1a3['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x39aac8){return this['findRootMostMatchingPathAndValue'](_0x39aac8,()=>!0x0);}['subtree'](_0x18da55){if(v(_0x18da55))return this;{const _0x29411b=y(_0x18da55),_0x407ff9=this['children']['get'](_0x29411b);return _0x407ff9!==null?_0x407ff9['subtree'](b(_0x18da55)):new S(null);}}['set'](_0x5c5258,_0x55b9fe){if(v(_0x5c5258))return new S(_0x55b9fe,this['children']);{const _0x5b1b6c=y(_0x5c5258),_0x177f79=(this['children']['get'](_0x5b1b6c)||new S(null))['set'](b(_0x5c5258),_0x55b9fe),_0x5c6f96=this['children']['insert'](_0x5b1b6c,_0x177f79);return new S(this['value'],_0x5c6f96);}}['remove'](_0xef558e){if(v(_0xef558e))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x3caccd=y(_0xef558e),_0x46402d=this['children']['get'](_0x3caccd);if(_0x46402d){const _0x162ad7=_0x46402d['remove'](b(_0xef558e));let _0x222f08;return _0x162ad7['isEmpty']()?_0x222f08=this['children']['remove'](_0x3caccd):_0x222f08=this['children']['insert'](_0x3caccd,_0x162ad7),this['value']===null&&_0x222f08['isEmpty']()?new S(null):new S(this['value'],_0x222f08);}else return this;}}['get'](_0x4cc857){if(v(_0x4cc857))return this['value'];{const _0x49152d=y(_0x4cc857),_0x448bb3=this['children']['get'](_0x49152d);return _0x448bb3?_0x448bb3['get'](b(_0x4cc857)):null;}}['setTree'](_0x3ff51b,_0x35cde0){if(v(_0x3ff51b))return _0x35cde0;{const _0x14f258=y(_0x3ff51b),_0x1022d0=(this['children']['get'](_0x14f258)||new S(null))['setTree'](b(_0x3ff51b),_0x35cde0);let _0xb4b3a7;return _0x1022d0['isEmpty']()?_0xb4b3a7=this['children']['remove'](_0x14f258):_0xb4b3a7=this['children']['insert'](_0x14f258,_0x1022d0),new S(this['value'],_0xb4b3a7);}}['fold'](_0x1dc03e){return this['fold_'](w(),_0x1dc03e);}['fold_'](_0x295bfc,_0x3e8f78){const _0x514be9={};return this['children']['inorderTraversal']((_0x2798d7,_0x5c20fb)=>{_0x514be9[_0x2798d7]=_0x5c20fb['fold_'](A(_0x295bfc,_0x2798d7),_0x3e8f78);}),_0x3e8f78(_0x295bfc,this['value'],_0x514be9);}['findOnPath'](_0xef61f,_0x2a9d12){return this['findOnPath_'](_0xef61f,w(),_0x2a9d12);}['findOnPath_'](_0x584d83,_0x403004,_0x4c3441){const _0x16f2d7=this['value']?_0x4c3441(_0x403004,this['value']):!0x1;if(_0x16f2d7)return _0x16f2d7;if(v(_0x584d83))return null;{const _0x4d650a=y(_0x584d83),_0x1e3e66=this['children']['get'](_0x4d650a);return _0x1e3e66?_0x1e3e66['findOnPath_'](b(_0x584d83),A(_0x403004,_0x4d650a),_0x4c3441):null;}}['foreachOnPath'](_0x4e9bfc,_0x35ae73){return this['foreachOnPath_'](_0x4e9bfc,w(),_0x35ae73);}['foreachOnPath_'](_0x20585b,_0xa18dd8,_0x16207a){if(v(_0x20585b))return this;{this['value']&&_0x16207a(_0xa18dd8,this['value']);const _0x433157=y(_0x20585b),_0xca9bb9=this['children']['get'](_0x433157);return _0xca9bb9?_0xca9bb9['foreachOnPath_'](b(_0x20585b),A(_0xa18dd8,_0x433157),_0x16207a):new S(null);}}['foreach'](_0x3b9a6f){this['foreach_'](w(),_0x3b9a6f);}['foreach_'](_0x2256b3,_0x3c117a){this['children']['inorderTraversal']((_0x911c51,_0x5550c0)=>{_0x5550c0['foreach_'](A(_0x2256b3,_0x911c51),_0x3c117a);}),this['value']&&_0x3c117a(_0x2256b3,this['value']);}['foreachChild'](_0xde9812){this['children']['inorderTraversal']((_0x1d8b65,_0x5b53d8)=>{_0x5b53d8['value']&&_0xde9812(_0x1d8b65,_0x5b53d8['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x2dc8b4){this['writeTree_']=_0x2dc8b4;}static['empty'](){return new j(new S(null));}}function Ct(_0x43aea7,_0x5a8e32,_0xd49b62){if(v(_0x5a8e32))return new j(new S(_0xd49b62));{const _0x316cc4=_0x43aea7['writeTree_']['findRootMostValueAndPath'](_0x5a8e32);if(_0x316cc4!=null){const _0x2b28e6=_0x316cc4['path'];let _0x6a69a0=_0x316cc4['value'];const _0x169b26=F(_0x2b28e6,_0x5a8e32);return _0x6a69a0=_0x6a69a0['updateChild'](_0x169b26,_0xd49b62),new j(_0x43aea7['writeTree_']['set'](_0x2b28e6,_0x6a69a0));}else{const _0x4dc88d=new S(_0xd49b62),_0x1eb0b1=_0x43aea7['writeTree_']['setTree'](_0x5a8e32,_0x4dc88d);return new j(_0x1eb0b1);}}}function Ii(_0x4203e8,_0xadc804,_0x222f2a){let _0x1ab157=_0x4203e8;return x(_0x222f2a,(_0x41d5a6,_0x51f425)=>{_0x1ab157=Ct(_0x1ab157,A(_0xadc804,_0x41d5a6),_0x51f425);}),_0x1ab157;}function sr(_0x1ed698,_0x2dda70){if(v(_0x2dda70))return j['empty']();{const _0x32d625=_0x1ed698['writeTree_']['setTree'](_0x2dda70,new S(null));return new j(_0x32d625);}}function wi(_0x785be5,_0x3129f4){return $e(_0x785be5,_0x3129f4)!=null;}function $e(_0x33a9b6,_0x50d066){const _0xbdf672=_0x33a9b6['writeTree_']['findRootMostValueAndPath'](_0x50d066);return _0xbdf672!=null?_0x33a9b6['writeTree_']['get'](_0xbdf672['path'])['getChild'](F(_0xbdf672['path'],_0x50d066)):null;}function rr(_0x416ebf){const _0x329a44=[],_0x24c34a=_0x416ebf['writeTree_']['value'];return _0x24c34a!=null?_0x24c34a['isLeafNode']()||_0x24c34a['forEachChild'](R,(_0x1d08a1,_0x26d30b)=>{_0x329a44['push'](new E(_0x1d08a1,_0x26d30b));}):_0x416ebf['writeTree_']['children']['inorderTraversal']((_0x41dd43,_0x540eb8)=>{_0x540eb8['value']!=null&&_0x329a44['push'](new E(_0x41dd43,_0x540eb8['value']));}),_0x329a44;}function ve(_0x568abb,_0x2f15e6){if(v(_0x2f15e6))return _0x568abb;{const _0x3f942d=$e(_0x568abb,_0x2f15e6);return _0x3f942d!=null?new j(new S(_0x3f942d)):new j(_0x568abb['writeTree_']['subtree'](_0x2f15e6));}}function Ci(_0x32dcbf){return _0x32dcbf['writeTree_']['isEmpty']();}function it(_0x347699,_0x444828){return xo(w(),_0x347699['writeTree_'],_0x444828);}function xo(_0x515f49,_0x133da0,_0x5e99b1){if(_0x133da0['value']!=null)return _0x5e99b1['updateChild'](_0x515f49,_0x133da0['value']);{let _0x38ad34=null;return _0x133da0['children']['inorderTraversal']((_0x15d165,_0x5a9f80)=>{_0x15d165==='.priority'?(f(_0x5a9f80['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x38ad34=_0x5a9f80['value']):_0x5e99b1=xo(A(_0x515f49,_0x15d165),_0x5a9f80,_0x5e99b1);}),!_0x5e99b1['getChild'](_0x515f49)['isEmpty']()&&_0x38ad34!==null&&(_0x5e99b1=_0x5e99b1['updateChild'](A(_0x515f49,'.priority'),_0x38ad34)),_0x5e99b1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x32cbb4,_0x13945c){return Bo(_0x13945c,_0x32cbb4);}function ou(_0x43a10b,_0x12d302,_0x138db0,_0x5bc524,_0x387e9e){f(_0x5bc524>_0x43a10b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x387e9e===void 0x0&&(_0x387e9e=!0x0),_0x43a10b['allWrites']['push']({'path':_0x12d302,'snap':_0x138db0,'writeId':_0x5bc524,'visible':_0x387e9e}),_0x387e9e&&(_0x43a10b['visibleWrites']=Ct(_0x43a10b['visibleWrites'],_0x12d302,_0x138db0)),_0x43a10b['lastWriteId']=_0x5bc524;}function au(_0xcd695e,_0x9ece4d,_0xa7a170,_0x1660af){f(_0x1660af>_0xcd695e['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0xcd695e['allWrites']['push']({'path':_0x9ece4d,'children':_0xa7a170,'writeId':_0x1660af,'visible':!0x0}),_0xcd695e['visibleWrites']=Ii(_0xcd695e['visibleWrites'],_0x9ece4d,_0xa7a170),_0xcd695e['lastWriteId']=_0x1660af;}function cu(_0x163fd3,_0x1bc2e7){for(let _0x16c8c3=0x0;_0x16c8c3<_0x163fd3['allWrites']['length'];_0x16c8c3++){const _0x3a347b=_0x163fd3['allWrites'][_0x16c8c3];if(_0x3a347b['writeId']===_0x1bc2e7)return _0x3a347b;}return null;}function lu(_0x214f04,_0x1af7f7){const _0x28ed50=_0x214f04['allWrites']['findIndex'](_0xe4cb2c=>_0xe4cb2c['writeId']===_0x1af7f7);f(_0x28ed50>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x3d0137=_0x214f04['allWrites'][_0x28ed50];_0x214f04['allWrites']['splice'](_0x28ed50,0x1);let _0x35b2ff=_0x3d0137['visible'],_0x496051=!0x1,_0x4f1ccb=_0x214f04['allWrites']['length']-0x1;for(;_0x35b2ff&&_0x4f1ccb>=0x0;){const _0x11f931=_0x214f04['allWrites'][_0x4f1ccb];_0x11f931['visible']&&(_0x4f1ccb>=_0x28ed50&&hu(_0x11f931,_0x3d0137['path'])?_0x35b2ff=!0x1:$(_0x3d0137['path'],_0x11f931['path'])&&(_0x496051=!0x0)),_0x4f1ccb--;}if(_0x35b2ff){if(_0x496051)return uu(_0x214f04),!0x0;if(_0x3d0137['snap'])_0x214f04['visibleWrites']=sr(_0x214f04['visibleWrites'],_0x3d0137['path']);else{const _0x1a84fa=_0x3d0137['children'];x(_0x1a84fa,_0x5ba434=>{_0x214f04['visibleWrites']=sr(_0x214f04['visibleWrites'],A(_0x3d0137['path'],_0x5ba434));});}return!0x0;}else return!0x1;}function hu(_0x317bb9,_0x5bb06d){if(_0x317bb9['snap'])return $(_0x317bb9['path'],_0x5bb06d);for(const _0x3d060e in _0x317bb9['children'])if(_0x317bb9['children']['hasOwnProperty'](_0x3d060e)&&$(A(_0x317bb9['path'],_0x3d060e),_0x5bb06d))return!0x0;return!0x1;}function uu(_0x2d717b){_0x2d717b['visibleWrites']=Fo(_0x2d717b['allWrites'],du,w()),_0x2d717b['allWrites']['length']>0x0?_0x2d717b['lastWriteId']=_0x2d717b['allWrites'][_0x2d717b['allWrites']['length']-0x1]['writeId']:_0x2d717b['lastWriteId']=-0x1;}function du(_0x1636d5){return _0x1636d5['visible'];}function Fo(_0x2e390c,_0x4a3e30,_0x17354e){let _0x363f43=j['empty']();for(let _0x251b0e=0x0;_0x251b0e<_0x2e390c['length'];++_0x251b0e){const _0x20c42b=_0x2e390c[_0x251b0e];if(_0x4a3e30(_0x20c42b)){const _0x177b0d=_0x20c42b['path'];let _0x221a45;if(_0x20c42b['snap'])$(_0x17354e,_0x177b0d)?(_0x221a45=F(_0x17354e,_0x177b0d),_0x363f43=Ct(_0x363f43,_0x221a45,_0x20c42b['snap'])):$(_0x177b0d,_0x17354e)&&(_0x221a45=F(_0x177b0d,_0x17354e),_0x363f43=Ct(_0x363f43,w(),_0x20c42b['snap']['getChild'](_0x221a45)));else{if(_0x20c42b['children']){if($(_0x17354e,_0x177b0d))_0x221a45=F(_0x17354e,_0x177b0d),_0x363f43=Ii(_0x363f43,_0x221a45,_0x20c42b['children']);else{if($(_0x177b0d,_0x17354e)){if(_0x221a45=F(_0x177b0d,_0x17354e),v(_0x221a45))_0x363f43=Ii(_0x363f43,w(),_0x20c42b['children']);else{const _0x146a81=Oe(_0x20c42b['children'],y(_0x221a45));if(_0x146a81){const _0x289a68=_0x146a81['getChild'](b(_0x221a45));_0x363f43=Ct(_0x363f43,w(),_0x289a68);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x363f43;}function Uo(_0x4a850a,_0x5bc59a,_0x1accfb,_0x24eac8,_0x42b100){if(!_0x24eac8&&!_0x42b100){const _0x5b60a5=$e(_0x4a850a['visibleWrites'],_0x5bc59a);if(_0x5b60a5!=null)return _0x5b60a5;{const _0x2007fd=ve(_0x4a850a['visibleWrites'],_0x5bc59a);if(Ci(_0x2007fd))return _0x1accfb;if(_0x1accfb==null&&!wi(_0x2007fd,w()))return null;{const _0x35bea1=_0x1accfb||g['EMPTY_NODE'];return it(_0x2007fd,_0x35bea1);}}}else{const _0x325a7b=ve(_0x4a850a['visibleWrites'],_0x5bc59a);if(!_0x42b100&&Ci(_0x325a7b))return _0x1accfb;if(!_0x42b100&&_0x1accfb==null&&!wi(_0x325a7b,w()))return null;{const _0x343eaf=function(_0x21fc80){return(_0x21fc80['visible']||_0x42b100)&&(!_0x24eac8||!~_0x24eac8['indexOf'](_0x21fc80['writeId']))&&($(_0x21fc80['path'],_0x5bc59a)||$(_0x5bc59a,_0x21fc80['path']));},_0x2b8104=Fo(_0x4a850a['allWrites'],_0x343eaf,_0x5bc59a),_0x1d7dd6=_0x1accfb||g['EMPTY_NODE'];return it(_0x2b8104,_0x1d7dd6);}}}function fu(_0x32b170,_0x1a25e6,_0x370322){let _0x2ea5f4=g['EMPTY_NODE'];const _0x531e7b=$e(_0x32b170['visibleWrites'],_0x1a25e6);if(_0x531e7b)return _0x531e7b['isLeafNode']()||_0x531e7b['forEachChild'](R,(_0x1e8c89,_0x2205a8)=>{_0x2ea5f4=_0x2ea5f4['updateImmediateChild'](_0x1e8c89,_0x2205a8);}),_0x2ea5f4;if(_0x370322){const _0x1b3693=ve(_0x32b170['visibleWrites'],_0x1a25e6);return _0x370322['forEachChild'](R,(_0x2e12bc,_0x561450)=>{const _0x24be61=it(ve(_0x1b3693,new C(_0x2e12bc)),_0x561450);_0x2ea5f4=_0x2ea5f4['updateImmediateChild'](_0x2e12bc,_0x24be61);}),rr(_0x1b3693)['forEach'](_0x4e6b72=>{_0x2ea5f4=_0x2ea5f4['updateImmediateChild'](_0x4e6b72['name'],_0x4e6b72['node']);}),_0x2ea5f4;}else{const _0x4f1e23=ve(_0x32b170['visibleWrites'],_0x1a25e6);return rr(_0x4f1e23)['forEach'](_0x2db013=>{_0x2ea5f4=_0x2ea5f4['updateImmediateChild'](_0x2db013['name'],_0x2db013['node']);}),_0x2ea5f4;}}function pu(_0x23b9da,_0x3db408,_0x4e54ef,_0x4032ac,_0x296ac6){f(_0x4032ac||_0x296ac6,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1fdf98=A(_0x3db408,_0x4e54ef);if(wi(_0x23b9da['visibleWrites'],_0x1fdf98))return null;{const _0x2364bd=ve(_0x23b9da['visibleWrites'],_0x1fdf98);return Ci(_0x2364bd)?_0x296ac6['getChild'](_0x4e54ef):it(_0x2364bd,_0x296ac6['getChild'](_0x4e54ef));}}function _u(_0x12201c,_0x3bc713,_0x261978,_0x1b61f0){const _0x2eb9be=A(_0x3bc713,_0x261978),_0x2869d3=$e(_0x12201c['visibleWrites'],_0x2eb9be);if(_0x2869d3!=null)return _0x2869d3;if(_0x1b61f0['isCompleteForChild'](_0x261978)){const _0x7c5551=ve(_0x12201c['visibleWrites'],_0x2eb9be);return it(_0x7c5551,_0x1b61f0['getNode']()['getImmediateChild'](_0x261978));}else return null;}function gu(_0x4e3ce6,_0x136d08){return $e(_0x4e3ce6['visibleWrites'],_0x136d08);}function mu(_0x2109bd,_0x342296,_0x4cb4f2,_0x5befe7,_0x5b7074,_0x22628d,_0x2e6224){let _0x4f74b5;const _0x2376bd=ve(_0x2109bd['visibleWrites'],_0x342296),_0x5674fe=$e(_0x2376bd,w());if(_0x5674fe!=null)_0x4f74b5=_0x5674fe;else{if(_0x4cb4f2!=null)_0x4f74b5=it(_0x2376bd,_0x4cb4f2);else return[];}if(_0x4f74b5=_0x4f74b5['withIndex'](_0x2e6224),!_0x4f74b5['isEmpty']()&&!_0x4f74b5['isLeafNode']()){const _0x4321e6=[],_0x4f40d1=_0x2e6224['getCompare'](),_0x2fac08=_0x22628d?_0x4f74b5['getReverseIteratorFrom'](_0x5befe7,_0x2e6224):_0x4f74b5['getIteratorFrom'](_0x5befe7,_0x2e6224);let _0x77b371=_0x2fac08['getNext']();for(;_0x77b371&&_0x4321e6['length']<_0x5b7074;)_0x4f40d1(_0x77b371,_0x5befe7)!==0x0&&_0x4321e6['push'](_0x77b371),_0x77b371=_0x2fac08['getNext']();return _0x4321e6;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x4ba84c,_0x53e490,_0x2689c2,_0x3b4b65){return Uo(_0x4ba84c['writeTree'],_0x4ba84c['treePath'],_0x53e490,_0x2689c2,_0x3b4b65);}function es(_0x41ab2f,_0x418662){return fu(_0x41ab2f['writeTree'],_0x41ab2f['treePath'],_0x418662);}function or(_0x5f0657,_0x38c0b8,_0x5f3cbc,_0x1713f3){return pu(_0x5f0657['writeTree'],_0x5f0657['treePath'],_0x38c0b8,_0x5f3cbc,_0x1713f3);}function yn(_0x2195b1,_0x54b203){return gu(_0x2195b1['writeTree'],A(_0x2195b1['treePath'],_0x54b203));}function vu(_0x42d3b5,_0x413701,_0x4650eb,_0x25fd06,_0x3cdb41,_0x13627f){return mu(_0x42d3b5['writeTree'],_0x42d3b5['treePath'],_0x413701,_0x4650eb,_0x25fd06,_0x3cdb41,_0x13627f);}function ts(_0x3c194e,_0x4844fb,_0x2c7ef1){return _u(_0x3c194e['writeTree'],_0x3c194e['treePath'],_0x4844fb,_0x2c7ef1);}function Wo(_0x32ecbd,_0x4f5f07){return Bo(A(_0x32ecbd['treePath'],_0x4f5f07),_0x32ecbd['writeTree']);}function Bo(_0x1543c9,_0x196369){return{'treePath':_0x1543c9,'writeTree':_0x196369};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1e1a3a){const _0x192808=_0x1e1a3a['type'],_0x5d4c87=_0x1e1a3a['childName'];f(_0x192808==='child_added'||_0x192808==='child_changed'||_0x192808==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5d4c87!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x180782=this['changeMap']['get'](_0x5d4c87);if(_0x180782){const _0x528bb0=_0x180782['type'];if(_0x192808==='child_added'&&_0x528bb0==='child_removed')this['changeMap']['set'](_0x5d4c87,Pt(_0x5d4c87,_0x1e1a3a['snapshotNode'],_0x180782['snapshotNode']));else{if(_0x192808==='child_removed'&&_0x528bb0==='child_added')this['changeMap']['delete'](_0x5d4c87);else{if(_0x192808==='child_removed'&&_0x528bb0==='child_changed')this['changeMap']['set'](_0x5d4c87,Nt(_0x5d4c87,_0x180782['oldSnap']));else{if(_0x192808==='child_changed'&&_0x528bb0==='child_added')this['changeMap']['set'](_0x5d4c87,tt(_0x5d4c87,_0x1e1a3a['snapshotNode']));else{if(_0x192808==='child_changed'&&_0x528bb0==='child_changed')this['changeMap']['set'](_0x5d4c87,Pt(_0x5d4c87,_0x1e1a3a['snapshotNode'],_0x180782['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x1e1a3a+'\x20occurred\x20after\x20'+_0x180782);}}}}}else this['changeMap']['set'](_0x5d4c87,_0x1e1a3a);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x4eaab9){return null;}['getChildAfterChild'](_0x2a37ff,_0x29c5c9,_0x67b711){return null;}}const Vo=new Iu();class ns{constructor(_0x25e225,_0x49ffa6,_0x17b9c7=null){this['writes_']=_0x25e225,this['viewCache_']=_0x49ffa6,this['optCompleteServerCache_']=_0x17b9c7;}['getCompleteChild'](_0x1d18b2){const _0x56d802=this['viewCache_']['eventCache'];if(_0x56d802['isCompleteForChild'](_0x1d18b2))return _0x56d802['getNode']()['getImmediateChild'](_0x1d18b2);{const _0x203aef=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x1d18b2,_0x203aef);}}['getChildAfterChild'](_0x38b082,_0x407216,_0x56c80e){const _0x323195=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x2b9d65=vu(this['writes_'],_0x323195,_0x407216,0x1,_0x56c80e,_0x38b082);return _0x2b9d65['length']===0x0?null:_0x2b9d65[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x49d7c1){return{'filter':_0x49d7c1};}function Cu(_0x153684,_0x3cae0c){f(_0x3cae0c['eventCache']['getNode']()['isIndexed'](_0x153684['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3cae0c['serverCache']['getNode']()['isIndexed'](_0x153684['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0xa34ffd,_0x146bff,_0xf81368,_0x5e8382,_0x3e68f8){const _0xee966c=new Eu();let _0x24f9ae,_0x576d39;if(_0xf81368['type']===q['OVERWRITE']){const _0x2c9aff=_0xf81368;_0x2c9aff['source']['fromUser']?_0x24f9ae=Ti(_0xa34ffd,_0x146bff,_0x2c9aff['path'],_0x2c9aff['snap'],_0x5e8382,_0x3e68f8,_0xee966c):(f(_0x2c9aff['source']['fromServer'],'Unknown\x20source.'),_0x576d39=_0x2c9aff['source']['tagged']||_0x146bff['serverCache']['isFiltered']()&&!v(_0x2c9aff['path']),_0x24f9ae=vn(_0xa34ffd,_0x146bff,_0x2c9aff['path'],_0x2c9aff['snap'],_0x5e8382,_0x3e68f8,_0x576d39,_0xee966c));}else{if(_0xf81368['type']===q['MERGE']){const _0x1234b6=_0xf81368;_0x1234b6['source']['fromUser']?_0x24f9ae=bu(_0xa34ffd,_0x146bff,_0x1234b6['path'],_0x1234b6['children'],_0x5e8382,_0x3e68f8,_0xee966c):(f(_0x1234b6['source']['fromServer'],'Unknown\x20source.'),_0x576d39=_0x1234b6['source']['tagged']||_0x146bff['serverCache']['isFiltered'](),_0x24f9ae=Si(_0xa34ffd,_0x146bff,_0x1234b6['path'],_0x1234b6['children'],_0x5e8382,_0x3e68f8,_0x576d39,_0xee966c));}else{if(_0xf81368['type']===q['ACK_USER_WRITE']){const _0x356bb2=_0xf81368;_0x356bb2['revert']?_0x24f9ae=ku(_0xa34ffd,_0x146bff,_0x356bb2['path'],_0x5e8382,_0x3e68f8,_0xee966c):_0x24f9ae=Ru(_0xa34ffd,_0x146bff,_0x356bb2['path'],_0x356bb2['affectedTree'],_0x5e8382,_0x3e68f8,_0xee966c);}else{if(_0xf81368['type']===q['LISTEN_COMPLETE'])_0x24f9ae=Au(_0xa34ffd,_0x146bff,_0xf81368['path'],_0x5e8382,_0xee966c);else throw ot('Unknown\x20operation\x20type:\x20'+_0xf81368['type']);}}}const _0x32441e=_0xee966c['getChanges']();return Su(_0x146bff,_0x24f9ae,_0x32441e),{'viewCache':_0x24f9ae,'changes':_0x32441e};}function Su(_0x12557b,_0x43afc3,_0x3136d1){const _0x532699=_0x43afc3['eventCache'];if(_0x532699['isFullyInitialized']()){const _0xbd943e=_0x532699['getNode']()['isLeafNode']()||_0x532699['getNode']()['isEmpty'](),_0x9edd7e=gn(_0x12557b);(_0x3136d1['length']>0x0||!_0x12557b['eventCache']['isFullyInitialized']()||_0xbd943e&&!_0x532699['getNode']()['equals'](_0x9edd7e)||!_0x532699['getNode']()['getPriority']()['equals'](_0x9edd7e['getPriority']()))&&_0x3136d1['push'](Oo(gn(_0x43afc3)));}}function Ho(_0xd54a3d,_0x3498c1,_0x43c77a,_0x1075fd,_0x5b7eb4,_0x17b3a0){const _0x45145d=_0x3498c1['eventCache'];if(yn(_0x1075fd,_0x43c77a)!=null)return _0x3498c1;{let _0x3b5d2d,_0x29ecdd;if(v(_0x43c77a)){if(f(_0x3498c1['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3498c1['serverCache']['isFiltered']()){const _0x11835a=Ue(_0x3498c1),_0x5a25be=_0x11835a instanceof g?_0x11835a:g['EMPTY_NODE'],_0x463804=es(_0x1075fd,_0x5a25be);_0x3b5d2d=_0xd54a3d['filter']['updateFullNode'](_0x3498c1['eventCache']['getNode'](),_0x463804,_0x17b3a0);}else{const _0x275f3e=mn(_0x1075fd,Ue(_0x3498c1));_0x3b5d2d=_0xd54a3d['filter']['updateFullNode'](_0x3498c1['eventCache']['getNode'](),_0x275f3e,_0x17b3a0);}}else{const _0x45b914=y(_0x43c77a);if(_0x45b914==='.priority'){f(we(_0x43c77a)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x619403=_0x45145d['getNode']();_0x29ecdd=_0x3498c1['serverCache']['getNode']();const _0x8b2ff5=or(_0x1075fd,_0x43c77a,_0x619403,_0x29ecdd);_0x8b2ff5!=null?_0x3b5d2d=_0xd54a3d['filter']['updatePriority'](_0x619403,_0x8b2ff5):_0x3b5d2d=_0x45145d['getNode']();}else{const _0xfdbf1=b(_0x43c77a);let _0x85266d;if(_0x45145d['isCompleteForChild'](_0x45b914)){_0x29ecdd=_0x3498c1['serverCache']['getNode']();const _0x48d262=or(_0x1075fd,_0x43c77a,_0x45145d['getNode'](),_0x29ecdd);_0x48d262!=null?_0x85266d=_0x45145d['getNode']()['getImmediateChild'](_0x45b914)['updateChild'](_0xfdbf1,_0x48d262):_0x85266d=_0x45145d['getNode']()['getImmediateChild'](_0x45b914);}else _0x85266d=ts(_0x1075fd,_0x45b914,_0x3498c1['serverCache']);_0x85266d!=null?_0x3b5d2d=_0xd54a3d['filter']['updateChild'](_0x45145d['getNode'](),_0x45b914,_0x85266d,_0xfdbf1,_0x5b7eb4,_0x17b3a0):_0x3b5d2d=_0x45145d['getNode']();}}return wt(_0x3498c1,_0x3b5d2d,_0x45145d['isFullyInitialized']()||v(_0x43c77a),_0xd54a3d['filter']['filtersNodes']());}}function vn(_0x505cfd,_0x5078ac,_0x51498f,_0xf97562,_0x3dfa43,_0x199ef6,_0x40cdbc,_0x1f5539){const _0x5e0629=_0x5078ac['serverCache'];let _0x5960a4;const _0x551137=_0x40cdbc?_0x505cfd['filter']:_0x505cfd['filter']['getIndexedFilter']();if(v(_0x51498f))_0x5960a4=_0x551137['updateFullNode'](_0x5e0629['getNode'](),_0xf97562,null);else{if(_0x551137['filtersNodes']()&&!_0x5e0629['isFiltered']()){const _0x15f812=_0x5e0629['getNode']()['updateChild'](_0x51498f,_0xf97562);_0x5960a4=_0x551137['updateFullNode'](_0x5e0629['getNode'](),_0x15f812,null);}else{const _0x4f60fc=y(_0x51498f);if(!_0x5e0629['isCompleteForPath'](_0x51498f)&&we(_0x51498f)>0x1)return _0x5078ac;const _0x3fe503=b(_0x51498f),_0x5b5d66=_0x5e0629['getNode']()['getImmediateChild'](_0x4f60fc)['updateChild'](_0x3fe503,_0xf97562);_0x4f60fc==='.priority'?_0x5960a4=_0x551137['updatePriority'](_0x5e0629['getNode'](),_0x5b5d66):_0x5960a4=_0x551137['updateChild'](_0x5e0629['getNode'](),_0x4f60fc,_0x5b5d66,_0x3fe503,Vo,null);}}const _0x4d8ace=Lo(_0x5078ac,_0x5960a4,_0x5e0629['isFullyInitialized']()||v(_0x51498f),_0x551137['filtersNodes']()),_0x2e5bf8=new ns(_0x3dfa43,_0x4d8ace,_0x199ef6);return Ho(_0x505cfd,_0x4d8ace,_0x51498f,_0x3dfa43,_0x2e5bf8,_0x1f5539);}function Ti(_0xf20c46,_0x44c968,_0x358943,_0x8a1494,_0x277fb0,_0x26cd53,_0x59111e){const _0xea8c02=_0x44c968['eventCache'];let _0x464330,_0x453c4e;const _0x287682=new ns(_0x277fb0,_0x44c968,_0x26cd53);if(v(_0x358943))_0x453c4e=_0xf20c46['filter']['updateFullNode'](_0x44c968['eventCache']['getNode'](),_0x8a1494,_0x59111e),_0x464330=wt(_0x44c968,_0x453c4e,!0x0,_0xf20c46['filter']['filtersNodes']());else{const _0x210852=y(_0x358943);if(_0x210852==='.priority')_0x453c4e=_0xf20c46['filter']['updatePriority'](_0x44c968['eventCache']['getNode'](),_0x8a1494),_0x464330=wt(_0x44c968,_0x453c4e,_0xea8c02['isFullyInitialized'](),_0xea8c02['isFiltered']());else{const _0x1dc5bb=b(_0x358943),_0x2a1bc0=_0xea8c02['getNode']()['getImmediateChild'](_0x210852);let _0x456c6d;if(v(_0x1dc5bb))_0x456c6d=_0x8a1494;else{const _0x39e121=_0x287682['getCompleteChild'](_0x210852);_0x39e121!=null?Gi(_0x1dc5bb)==='.priority'&&_0x39e121['getChild'](To(_0x1dc5bb))['isEmpty']()?_0x456c6d=_0x39e121:_0x456c6d=_0x39e121['updateChild'](_0x1dc5bb,_0x8a1494):_0x456c6d=g['EMPTY_NODE'];}if(_0x2a1bc0['equals'](_0x456c6d))_0x464330=_0x44c968;else{const _0x14fcee=_0xf20c46['filter']['updateChild'](_0xea8c02['getNode'](),_0x210852,_0x456c6d,_0x1dc5bb,_0x287682,_0x59111e);_0x464330=wt(_0x44c968,_0x14fcee,_0xea8c02['isFullyInitialized'](),_0xf20c46['filter']['filtersNodes']());}}}return _0x464330;}function ar(_0x2eb4cd,_0x3e8049){return _0x2eb4cd['eventCache']['isCompleteForChild'](_0x3e8049);}function bu(_0x4d9a8b,_0x56adb0,_0x383740,_0x126bbc,_0x5f2a4b,_0x2db759,_0x572458){let _0xce2969=_0x56adb0;return _0x126bbc['foreach']((_0x2efc78,_0x56b442)=>{const _0x549b7b=A(_0x383740,_0x2efc78);ar(_0x56adb0,y(_0x549b7b))&&(_0xce2969=Ti(_0x4d9a8b,_0xce2969,_0x549b7b,_0x56b442,_0x5f2a4b,_0x2db759,_0x572458));}),_0x126bbc['foreach']((_0x3cd91e,_0x3cecf1)=>{const _0x5c3162=A(_0x383740,_0x3cd91e);ar(_0x56adb0,y(_0x5c3162))||(_0xce2969=Ti(_0x4d9a8b,_0xce2969,_0x5c3162,_0x3cecf1,_0x5f2a4b,_0x2db759,_0x572458));}),_0xce2969;}function cr(_0x5884fe,_0x328b8c,_0x3176c8){return _0x3176c8['foreach']((_0x319fec,_0x50ce1e)=>{_0x328b8c=_0x328b8c['updateChild'](_0x319fec,_0x50ce1e);}),_0x328b8c;}function Si(_0x4bda2c,_0x3ba91d,_0x53801c,_0x12c53a,_0x5b952a,_0x34e7ad,_0x5cadc6,_0x402f38){if(_0x3ba91d['serverCache']['getNode']()['isEmpty']()&&!_0x3ba91d['serverCache']['isFullyInitialized']())return _0x3ba91d;let _0x19fa86=_0x3ba91d,_0x23fbf3;v(_0x53801c)?_0x23fbf3=_0x12c53a:_0x23fbf3=new S(null)['setTree'](_0x53801c,_0x12c53a);const _0x83001d=_0x3ba91d['serverCache']['getNode']();return _0x23fbf3['children']['inorderTraversal']((_0x1035da,_0x420167)=>{if(_0x83001d['hasChild'](_0x1035da)){const _0x9be48a=_0x3ba91d['serverCache']['getNode']()['getImmediateChild'](_0x1035da),_0x2ca5d6=cr(_0x4bda2c,_0x9be48a,_0x420167);_0x19fa86=vn(_0x4bda2c,_0x19fa86,new C(_0x1035da),_0x2ca5d6,_0x5b952a,_0x34e7ad,_0x5cadc6,_0x402f38);}}),_0x23fbf3['children']['inorderTraversal']((_0x28eba7,_0x207f96)=>{const _0x5cc83f=!_0x3ba91d['serverCache']['isCompleteForChild'](_0x28eba7)&&_0x207f96['value']===null;if(!_0x83001d['hasChild'](_0x28eba7)&&!_0x5cc83f){const _0x54297f=_0x3ba91d['serverCache']['getNode']()['getImmediateChild'](_0x28eba7),_0x36cbc5=cr(_0x4bda2c,_0x54297f,_0x207f96);_0x19fa86=vn(_0x4bda2c,_0x19fa86,new C(_0x28eba7),_0x36cbc5,_0x5b952a,_0x34e7ad,_0x5cadc6,_0x402f38);}}),_0x19fa86;}function Ru(_0x254a6d,_0x2a7031,_0xba72b5,_0x659016,_0x2971a8,_0x5c8589,_0x20a9a7){if(yn(_0x2971a8,_0xba72b5)!=null)return _0x2a7031;const _0x1ff058=_0x2a7031['serverCache']['isFiltered'](),_0x38779e=_0x2a7031['serverCache'];if(_0x659016['value']!=null){if(v(_0xba72b5)&&_0x38779e['isFullyInitialized']()||_0x38779e['isCompleteForPath'](_0xba72b5))return vn(_0x254a6d,_0x2a7031,_0xba72b5,_0x38779e['getNode']()['getChild'](_0xba72b5),_0x2971a8,_0x5c8589,_0x1ff058,_0x20a9a7);if(v(_0xba72b5)){let _0x23ac9b=new S(null);return _0x38779e['getNode']()['forEachChild'](ye,(_0x1dda1e,_0x58fd87)=>{_0x23ac9b=_0x23ac9b['set'](new C(_0x1dda1e),_0x58fd87);}),Si(_0x254a6d,_0x2a7031,_0xba72b5,_0x23ac9b,_0x2971a8,_0x5c8589,_0x1ff058,_0x20a9a7);}else return _0x2a7031;}else{let _0x3eb9f1=new S(null);return _0x659016['foreach']((_0x31d7ce,_0x527f1b)=>{const _0x39799a=A(_0xba72b5,_0x31d7ce);_0x38779e['isCompleteForPath'](_0x39799a)&&(_0x3eb9f1=_0x3eb9f1['set'](_0x31d7ce,_0x38779e['getNode']()['getChild'](_0x39799a)));}),Si(_0x254a6d,_0x2a7031,_0xba72b5,_0x3eb9f1,_0x2971a8,_0x5c8589,_0x1ff058,_0x20a9a7);}}function Au(_0x31ec13,_0x1f16aa,_0x240097,_0x3eb87a,_0x181b44){const _0x5d1954=_0x1f16aa['serverCache'],_0x1c22d4=Lo(_0x1f16aa,_0x5d1954['getNode'](),_0x5d1954['isFullyInitialized']()||v(_0x240097),_0x5d1954['isFiltered']());return Ho(_0x31ec13,_0x1c22d4,_0x240097,_0x3eb87a,Vo,_0x181b44);}function ku(_0x3d9b84,_0x12ee85,_0x40705b,_0x4f5c07,_0x4ae5cd,_0x5b2068){let _0x5aeea8;if(yn(_0x4f5c07,_0x40705b)!=null)return _0x12ee85;{const _0x339d4c=new ns(_0x4f5c07,_0x12ee85,_0x4ae5cd),_0x213972=_0x12ee85['eventCache']['getNode']();let _0x1bf07f;if(v(_0x40705b)||y(_0x40705b)==='.priority'){let _0xc75011;if(_0x12ee85['serverCache']['isFullyInitialized']())_0xc75011=mn(_0x4f5c07,Ue(_0x12ee85));else{const _0x16c079=_0x12ee85['serverCache']['getNode']();f(_0x16c079 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0xc75011=es(_0x4f5c07,_0x16c079);}_0xc75011=_0xc75011,_0x1bf07f=_0x3d9b84['filter']['updateFullNode'](_0x213972,_0xc75011,_0x5b2068);}else{const _0x12ca65=y(_0x40705b);let _0x180cae=ts(_0x4f5c07,_0x12ca65,_0x12ee85['serverCache']);_0x180cae==null&&_0x12ee85['serverCache']['isCompleteForChild'](_0x12ca65)&&(_0x180cae=_0x213972['getImmediateChild'](_0x12ca65)),_0x180cae!=null?_0x1bf07f=_0x3d9b84['filter']['updateChild'](_0x213972,_0x12ca65,_0x180cae,b(_0x40705b),_0x339d4c,_0x5b2068):_0x12ee85['eventCache']['getNode']()['hasChild'](_0x12ca65)?_0x1bf07f=_0x3d9b84['filter']['updateChild'](_0x213972,_0x12ca65,g['EMPTY_NODE'],b(_0x40705b),_0x339d4c,_0x5b2068):_0x1bf07f=_0x213972,_0x1bf07f['isEmpty']()&&_0x12ee85['serverCache']['isFullyInitialized']()&&(_0x5aeea8=mn(_0x4f5c07,Ue(_0x12ee85)),_0x5aeea8['isLeafNode']()&&(_0x1bf07f=_0x3d9b84['filter']['updateFullNode'](_0x1bf07f,_0x5aeea8,_0x5b2068)));}return _0x5aeea8=_0x12ee85['serverCache']['isFullyInitialized']()||yn(_0x4f5c07,w())!=null,wt(_0x12ee85,_0x1bf07f,_0x5aeea8,_0x3d9b84['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x4b3f1b,_0x28dd2f){this['query_']=_0x4b3f1b,this['eventRegistrations_']=[];const _0x305789=this['query_']['_queryParams'],_0x5bb12e=new Yi(_0x305789['getIndex']()),_0x223467=qh(_0x305789);this['processor_']=wu(_0x223467);const _0x29f551=_0x28dd2f['serverCache'],_0xf59df0=_0x28dd2f['eventCache'],_0x43b572=_0x5bb12e['updateFullNode'](g['EMPTY_NODE'],_0x29f551['getNode'](),null),_0x4310a1=_0x223467['updateFullNode'](g['EMPTY_NODE'],_0xf59df0['getNode'](),null),_0x9d890c=new Ce(_0x43b572,_0x29f551['isFullyInitialized'](),_0x5bb12e['filtersNodes']()),_0x4ef1c9=new Ce(_0x4310a1,_0xf59df0['isFullyInitialized'](),_0x223467['filtersNodes']());this['viewCache_']=Dn(_0x4ef1c9,_0x9d890c),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x5a13d3){return _0x5a13d3['viewCache_']['serverCache']['getNode']();}function Ou(_0x53df4c){return gn(_0x53df4c['viewCache_']);}function Du(_0x39ee4b,_0x1c59a3){const _0x5ae337=Ue(_0x39ee4b['viewCache_']);return _0x5ae337&&(_0x39ee4b['query']['_queryParams']['loadsAllData']()||!v(_0x1c59a3)&&!_0x5ae337['getImmediateChild'](y(_0x1c59a3))['isEmpty']())?_0x5ae337['getChild'](_0x1c59a3):null;}function lr(_0x1e5214){return _0x1e5214['eventRegistrations_']['length']===0x0;}function Mu(_0xd30595,_0x2be380){_0xd30595['eventRegistrations_']['push'](_0x2be380);}function hr(_0x3150b8,_0x4ded4f,_0x4366c8){const _0x4b5dec=[];if(_0x4366c8){f(_0x4ded4f==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1b0846=_0x3150b8['query']['_path'];_0x3150b8['eventRegistrations_']['forEach'](_0x384a2d=>{const _0x141ecd=_0x384a2d['createCancelEvent'](_0x4366c8,_0x1b0846);_0x141ecd&&_0x4b5dec['push'](_0x141ecd);});}if(_0x4ded4f){let _0x1b98eb=[];for(let _0x2d8812=0x0;_0x2d8812<_0x3150b8['eventRegistrations_']['length'];++_0x2d8812){const _0x4a1a3e=_0x3150b8['eventRegistrations_'][_0x2d8812];if(!_0x4a1a3e['matches'](_0x4ded4f))_0x1b98eb['push'](_0x4a1a3e);else{if(_0x4ded4f['hasAnyCallback']()){_0x1b98eb=_0x1b98eb['concat'](_0x3150b8['eventRegistrations_']['slice'](_0x2d8812+0x1));break;}}}_0x3150b8['eventRegistrations_']=_0x1b98eb;}else _0x3150b8['eventRegistrations_']=[];return _0x4b5dec;}function ur(_0x5c32f4,_0x8a1676,_0x127547,_0x1640f1){_0x8a1676['type']===q['MERGE']&&_0x8a1676['source']['queryId']!==null&&(f(Ue(_0x5c32f4['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x5c32f4['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x247c44=_0x5c32f4['viewCache_'],_0x2fd0ed=Tu(_0x5c32f4['processor_'],_0x247c44,_0x8a1676,_0x127547,_0x1640f1);return Cu(_0x5c32f4['processor_'],_0x2fd0ed['viewCache']),f(_0x2fd0ed['viewCache']['serverCache']['isFullyInitialized']()||!_0x247c44['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5c32f4['viewCache_']=_0x2fd0ed['viewCache'],$o(_0x5c32f4,_0x2fd0ed['changes'],_0x2fd0ed['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x5dc0c1,_0x286685){const _0x2f461c=_0x5dc0c1['viewCache_']['eventCache'],_0x2899a8=[];return _0x2f461c['getNode']()['isLeafNode']()||_0x2f461c['getNode']()['forEachChild'](R,(_0x171525,_0x495883)=>{_0x2899a8['push'](tt(_0x171525,_0x495883));}),_0x2f461c['isFullyInitialized']()&&_0x2899a8['push'](Oo(_0x2f461c['getNode']())),$o(_0x5dc0c1,_0x2899a8,_0x2f461c['getNode'](),_0x286685);}function $o(_0x3deac4,_0x25b3b6,_0x44bbe5,_0x4b3815){const _0x3cd2c5=_0x4b3815?[_0x4b3815]:_0x3deac4['eventRegistrations_'];return nu(_0x3deac4['eventGenerator_'],_0x25b3b6,_0x44bbe5,_0x3cd2c5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x537212){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x537212;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x7e3bb7){return _0x7e3bb7['views']['size']===0x0;}function is(_0x2f7762,_0xb6f8d6,_0x3c2a91,_0x437284){const _0x21706d=_0xb6f8d6['source']['queryId'];if(_0x21706d!==null){const _0x314599=_0x2f7762['views']['get'](_0x21706d);return f(_0x314599!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x314599,_0xb6f8d6,_0x3c2a91,_0x437284);}else{let _0xe7e8a7=[];for(const _0x197702 of _0x2f7762['views']['values']())_0xe7e8a7=_0xe7e8a7['concat'](ur(_0x197702,_0xb6f8d6,_0x3c2a91,_0x437284));return _0xe7e8a7;}}function qo(_0x4662d3,_0x15f651,_0x36bc75,_0x3cf942,_0x57986f){const _0x57e6bb=_0x15f651['_queryIdentifier'],_0x423bce=_0x4662d3['views']['get'](_0x57e6bb);if(!_0x423bce){let _0x318daf=mn(_0x36bc75,_0x57986f?_0x3cf942:null),_0xeba2d7=!0x1;_0x318daf?_0xeba2d7=!0x0:_0x3cf942 instanceof g?(_0x318daf=es(_0x36bc75,_0x3cf942),_0xeba2d7=!0x1):(_0x318daf=g['EMPTY_NODE'],_0xeba2d7=!0x1);const _0x18b704=Dn(new Ce(_0x318daf,_0xeba2d7,!0x1),new Ce(_0x3cf942,_0x57986f,!0x1));return new Nu(_0x15f651,_0x18b704);}return _0x423bce;}function Wu(_0x57110f,_0x2c3bb3,_0x459b0b,_0x21b46e,_0x192f7b,_0x22ddac){const _0x1851af=qo(_0x57110f,_0x2c3bb3,_0x21b46e,_0x192f7b,_0x22ddac);return _0x57110f['views']['has'](_0x2c3bb3['_queryIdentifier'])||_0x57110f['views']['set'](_0x2c3bb3['_queryIdentifier'],_0x1851af),Mu(_0x1851af,_0x459b0b),Lu(_0x1851af,_0x459b0b);}function Bu(_0x4433f9,_0x5c0735,_0xe5bd40,_0x45ee59){const _0x69f635=_0x5c0735['_queryIdentifier'],_0x1ebd7a=[];let _0x229f93=[];const _0x48ed28=Te(_0x4433f9);if(_0x69f635==='default'){for(const [_0x2e2101,_0x1b4363]of _0x4433f9['views']['entries']())_0x229f93=_0x229f93['concat'](hr(_0x1b4363,_0xe5bd40,_0x45ee59)),lr(_0x1b4363)&&(_0x4433f9['views']['delete'](_0x2e2101),_0x1b4363['query']['_queryParams']['loadsAllData']()||_0x1ebd7a['push'](_0x1b4363['query']));}else{const _0x50e862=_0x4433f9['views']['get'](_0x69f635);_0x50e862&&(_0x229f93=_0x229f93['concat'](hr(_0x50e862,_0xe5bd40,_0x45ee59)),lr(_0x50e862)&&(_0x4433f9['views']['delete'](_0x69f635),_0x50e862['query']['_queryParams']['loadsAllData']()||_0x1ebd7a['push'](_0x50e862['query'])));}return _0x48ed28&&!Te(_0x4433f9)&&_0x1ebd7a['push'](new(Fu())(_0x5c0735['_repo'],_0x5c0735['_path'])),{'removed':_0x1ebd7a,'events':_0x229f93};}function zo(_0x4a91a6){const _0x2d9fca=[];for(const _0xc0f740 of _0x4a91a6['views']['values']())_0xc0f740['query']['_queryParams']['loadsAllData']()||_0x2d9fca['push'](_0xc0f740);return _0x2d9fca;}function Ee(_0x218195,_0x502e40){let _0x5a797d=null;for(const _0x3d0778 of _0x218195['views']['values']())_0x5a797d=_0x5a797d||Du(_0x3d0778,_0x502e40);return _0x5a797d;}function jo(_0x585eca,_0x265ebd){if(_0x265ebd['_queryParams']['loadsAllData']())return Ln(_0x585eca);{const _0x85d530=_0x265ebd['_queryIdentifier'];return _0x585eca['views']['get'](_0x85d530);}}function Ko(_0x498d48,_0x18f47f){return jo(_0x498d48,_0x18f47f)!=null;}function Te(_0x5d9084){return Ln(_0x5d9084)!=null;}function Ln(_0x4c385c){for(const _0x46f97d of _0x4c385c['views']['values']())if(_0x46f97d['query']['_queryParams']['loadsAllData']())return _0x46f97d;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x3c4b35){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x3c4b35;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x16835a){this['listenProvider_']=_0x16835a,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x282c0c,_0x5cd2df,_0x94070,_0xf4f799,_0x3051b7){return ou(_0x282c0c['pendingWriteTree_'],_0x5cd2df,_0x94070,_0xf4f799,_0x3051b7),_0x3051b7?ht(_0x282c0c,new Fe(Ji(),_0x5cd2df,_0x94070)):[];}function Gu(_0x1d86f3,_0x1ed005,_0x3ca620,_0x9bf145){au(_0x1d86f3['pendingWriteTree_'],_0x1ed005,_0x3ca620,_0x9bf145);const _0x419af1=S['fromObject'](_0x3ca620);return ht(_0x1d86f3,new nt(Ji(),_0x1ed005,_0x419af1));}function pe(_0x3bca37,_0x617970,_0x5ad8da=!0x1){const _0x3de193=cu(_0x3bca37['pendingWriteTree_'],_0x617970);if(lu(_0x3bca37['pendingWriteTree_'],_0x617970)){let _0x53714e=new S(null);return _0x3de193['snap']!=null?_0x53714e=_0x53714e['set'](w(),!0x0):x(_0x3de193['children'],_0x47c8d5=>{_0x53714e=_0x53714e['set'](new C(_0x47c8d5),!0x0);}),ht(_0x3bca37,new _n(_0x3de193['path'],_0x53714e,_0x5ad8da));}else return[];}function $t(_0x4d4818,_0x334d99,_0x3383c8){return ht(_0x4d4818,new Fe(Xi(),_0x334d99,_0x3383c8));}function qu(_0x419078,_0x55b20d,_0x5bab42){const _0xbe78d6=S['fromObject'](_0x5bab42);return ht(_0x419078,new nt(Xi(),_0x55b20d,_0xbe78d6));}function zu(_0x3aa24f,_0x1ffbde){return ht(_0x3aa24f,new Dt(Xi(),_0x1ffbde));}function ju(_0x3e9d39,_0x2a8ebb,_0x101dbc){const _0x491e98=rs(_0x3e9d39,_0x101dbc);if(_0x491e98){const _0x5e6db2=os(_0x491e98),_0x53e21f=_0x5e6db2['path'],_0x321a66=_0x5e6db2['queryId'],_0x53ac5d=F(_0x53e21f,_0x2a8ebb),_0x1f170f=new Dt(Zi(_0x321a66),_0x53ac5d);return as(_0x3e9d39,_0x53e21f,_0x1f170f);}else return[];}function wn(_0x547d88,_0x4687b3,_0x2d8e7e,_0x37ebc2,_0x52c6b0=!0x1){const _0x51f7aa=_0x4687b3['_path'],_0x3980b0=_0x547d88['syncPointTree_']['get'](_0x51f7aa);let _0x3d8c03=[];if(_0x3980b0&&(_0x4687b3['_queryIdentifier']==='default'||Ko(_0x3980b0,_0x4687b3))){const _0x10b0cc=Bu(_0x3980b0,_0x4687b3,_0x2d8e7e,_0x37ebc2);Uu(_0x3980b0)&&(_0x547d88['syncPointTree_']=_0x547d88['syncPointTree_']['remove'](_0x51f7aa));const _0x175052=_0x10b0cc['removed'];if(_0x3d8c03=_0x10b0cc['events'],!_0x52c6b0){const _0x18f680=_0x175052['findIndex'](_0x55a036=>_0x55a036['_queryParams']['loadsAllData']())!==-0x1,_0x4adc35=_0x547d88['syncPointTree_']['findOnPath'](_0x51f7aa,(_0x2e7eb2,_0x5d2fc8)=>Te(_0x5d2fc8));if(_0x18f680&&!_0x4adc35){const _0x55a679=_0x547d88['syncPointTree_']['subtree'](_0x51f7aa);if(!_0x55a679['isEmpty']()){const _0x1d3b93=Qu(_0x55a679);for(let _0x4f7129=0x0;_0x4f7129<_0x1d3b93['length'];++_0x4f7129){const _0x575553=_0x1d3b93[_0x4f7129],_0x1930c1=_0x575553['query'],_0x607c5e=Xo(_0x547d88,_0x575553);_0x547d88['listenProvider_']['startListening'](Tt(_0x1930c1),Mt(_0x547d88,_0x1930c1),_0x607c5e['hashFn'],_0x607c5e['onComplete']);}}}!_0x4adc35&&_0x175052['length']>0x0&&!_0x37ebc2&&(_0x18f680?_0x547d88['listenProvider_']['stopListening'](Tt(_0x4687b3),null):_0x175052['forEach'](_0x22e039=>{const _0xd13a44=_0x547d88['queryToTagMap']['get'](Fn(_0x22e039));_0x547d88['listenProvider_']['stopListening'](Tt(_0x22e039),_0xd13a44);}));}Ju(_0x547d88,_0x175052);}return _0x3d8c03;}function Yo(_0x56dd36,_0x221063,_0x118101,_0x42905d){const _0x3bf804=rs(_0x56dd36,_0x42905d);if(_0x3bf804!=null){const _0x1085a6=os(_0x3bf804),_0x4508f8=_0x1085a6['path'],_0x385d6c=_0x1085a6['queryId'],_0x50cacb=F(_0x4508f8,_0x221063),_0x4b5f02=new Fe(Zi(_0x385d6c),_0x50cacb,_0x118101);return as(_0x56dd36,_0x4508f8,_0x4b5f02);}else return[];}function Ku(_0x641a67,_0x14e6d7,_0x433e25,_0x24a9ec){const _0x56b5bd=rs(_0x641a67,_0x24a9ec);if(_0x56b5bd){const _0xc68f45=os(_0x56b5bd),_0x43536e=_0xc68f45['path'],_0x2b6e35=_0xc68f45['queryId'],_0x2b16ba=F(_0x43536e,_0x14e6d7),_0x1a5abd=S['fromObject'](_0x433e25),_0x2af6e6=new nt(Zi(_0x2b6e35),_0x2b16ba,_0x1a5abd);return as(_0x641a67,_0x43536e,_0x2af6e6);}else return[];}function bi(_0xa679e0,_0x287cd0,_0x2b5658,_0x9462eb=!0x1){const _0x9c5c03=_0x287cd0['_path'];let _0x5f52ce=null,_0x2ac5dc=!0x1;_0xa679e0['syncPointTree_']['foreachOnPath'](_0x9c5c03,(_0x11f59e,_0x31cc3e)=>{const _0x463ee5=F(_0x11f59e,_0x9c5c03);_0x5f52ce=_0x5f52ce||Ee(_0x31cc3e,_0x463ee5),_0x2ac5dc=_0x2ac5dc||Te(_0x31cc3e);});let _0x2b442f=_0xa679e0['syncPointTree_']['get'](_0x9c5c03);_0x2b442f?(_0x2ac5dc=_0x2ac5dc||Te(_0x2b442f),_0x5f52ce=_0x5f52ce||Ee(_0x2b442f,w())):(_0x2b442f=new Go(),_0xa679e0['syncPointTree_']=_0xa679e0['syncPointTree_']['set'](_0x9c5c03,_0x2b442f));let _0x2e6a27;_0x5f52ce!=null?_0x2e6a27=!0x0:(_0x2e6a27=!0x1,_0x5f52ce=g['EMPTY_NODE'],_0xa679e0['syncPointTree_']['subtree'](_0x9c5c03)['foreachChild']((_0x37880d,_0x12f8fe)=>{const _0x9b7c42=Ee(_0x12f8fe,w());_0x9b7c42&&(_0x5f52ce=_0x5f52ce['updateImmediateChild'](_0x37880d,_0x9b7c42));}));const _0x4f3eaf=Ko(_0x2b442f,_0x287cd0);if(!_0x4f3eaf&&!_0x287cd0['_queryParams']['loadsAllData']()){const _0x3e862f=Fn(_0x287cd0);f(!_0xa679e0['queryToTagMap']['has'](_0x3e862f),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2805b0=Xu();_0xa679e0['queryToTagMap']['set'](_0x3e862f,_0x2805b0),_0xa679e0['tagToQueryMap']['set'](_0x2805b0,_0x3e862f);}const _0x4fe4bc=Mn(_0xa679e0['pendingWriteTree_'],_0x9c5c03);let _0x138ffb=Wu(_0x2b442f,_0x287cd0,_0x2b5658,_0x4fe4bc,_0x5f52ce,_0x2e6a27);if(!_0x4f3eaf&&!_0x2ac5dc&&!_0x9462eb){const _0x280501=jo(_0x2b442f,_0x287cd0);_0x138ffb=_0x138ffb['concat'](Zu(_0xa679e0,_0x287cd0,_0x280501));}return _0x138ffb;}function xn(_0x559067,_0xc980aa,_0x3fe55c){const _0x7c4694=_0x559067['pendingWriteTree_'],_0x5600d8=_0x559067['syncPointTree_']['findOnPath'](_0xc980aa,(_0x31fa96,_0x4c4c8c)=>{const _0xa2ad99=F(_0x31fa96,_0xc980aa),_0x7f5f7c=Ee(_0x4c4c8c,_0xa2ad99);if(_0x7f5f7c)return _0x7f5f7c;});return Uo(_0x7c4694,_0xc980aa,_0x5600d8,_0x3fe55c,!0x0);}function Yu(_0x50ab7e,_0x5d3c62){const _0x486413=_0x5d3c62['_path'];let _0x437509=null;_0x50ab7e['syncPointTree_']['foreachOnPath'](_0x486413,(_0x388a11,_0x48684c)=>{const _0x3076b6=F(_0x388a11,_0x486413);_0x437509=_0x437509||Ee(_0x48684c,_0x3076b6);});let _0x6814b4=_0x50ab7e['syncPointTree_']['get'](_0x486413);_0x6814b4?_0x437509=_0x437509||Ee(_0x6814b4,w()):(_0x6814b4=new Go(),_0x50ab7e['syncPointTree_']=_0x50ab7e['syncPointTree_']['set'](_0x486413,_0x6814b4));const _0x5f0bfe=_0x437509!=null,_0xe6fcc3=_0x5f0bfe?new Ce(_0x437509,!0x0,!0x1):null,_0x3174a5=Mn(_0x50ab7e['pendingWriteTree_'],_0x5d3c62['_path']),_0x1811bf=qo(_0x6814b4,_0x5d3c62,_0x3174a5,_0x5f0bfe?_0xe6fcc3['getNode']():g['EMPTY_NODE'],_0x5f0bfe);return Ou(_0x1811bf);}function ht(_0x5a55d9,_0x4226a3){return Qo(_0x4226a3,_0x5a55d9['syncPointTree_'],null,Mn(_0x5a55d9['pendingWriteTree_'],w()));}function Qo(_0x3633c9,_0x57c1a4,_0x144ad9,_0x30fc07){if(v(_0x3633c9['path']))return Jo(_0x3633c9,_0x57c1a4,_0x144ad9,_0x30fc07);{const _0x583e41=_0x57c1a4['get'](w());_0x144ad9==null&&_0x583e41!=null&&(_0x144ad9=Ee(_0x583e41,w()));let _0x385f15=[];const _0x284390=y(_0x3633c9['path']),_0x5e1aa7=_0x3633c9['operationForChild'](_0x284390),_0x468b71=_0x57c1a4['children']['get'](_0x284390);if(_0x468b71&&_0x5e1aa7){const _0x4dcef3=_0x144ad9?_0x144ad9['getImmediateChild'](_0x284390):null,_0x94abfc=Wo(_0x30fc07,_0x284390);_0x385f15=_0x385f15['concat'](Qo(_0x5e1aa7,_0x468b71,_0x4dcef3,_0x94abfc));}return _0x583e41&&(_0x385f15=_0x385f15['concat'](is(_0x583e41,_0x3633c9,_0x30fc07,_0x144ad9))),_0x385f15;}}function Jo(_0x2cd359,_0x40042c,_0x2727c7,_0x171fb1){const _0x2790ee=_0x40042c['get'](w());_0x2727c7==null&&_0x2790ee!=null&&(_0x2727c7=Ee(_0x2790ee,w()));let _0x34385a=[];return _0x40042c['children']['inorderTraversal']((_0x974666,_0x537deb)=>{const _0x25b10b=_0x2727c7?_0x2727c7['getImmediateChild'](_0x974666):null,_0x471af9=Wo(_0x171fb1,_0x974666),_0x47572f=_0x2cd359['operationForChild'](_0x974666);_0x47572f&&(_0x34385a=_0x34385a['concat'](Jo(_0x47572f,_0x537deb,_0x25b10b,_0x471af9)));}),_0x2790ee&&(_0x34385a=_0x34385a['concat'](is(_0x2790ee,_0x2cd359,_0x171fb1,_0x2727c7))),_0x34385a;}function Xo(_0x8ff439,_0x218556){const _0x4c3001=_0x218556['query'],_0x5ea900=Mt(_0x8ff439,_0x4c3001);return{'hashFn':()=>(Pu(_0x218556)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x4fbe64=>{if(_0x4fbe64==='ok')return _0x5ea900?ju(_0x8ff439,_0x4c3001['_path'],_0x5ea900):zu(_0x8ff439,_0x4c3001['_path']);{const _0xb2e571=ql(_0x4fbe64,_0x4c3001);return wn(_0x8ff439,_0x4c3001,null,_0xb2e571);}}};}function Mt(_0x2930f4,_0x465f87){const _0x40b40=Fn(_0x465f87);return _0x2930f4['queryToTagMap']['get'](_0x40b40);}function Fn(_0x3b58c1){return _0x3b58c1['_path']['toString']()+'$'+_0x3b58c1['_queryIdentifier'];}function rs(_0x48c88c,_0x64c81a){return _0x48c88c['tagToQueryMap']['get'](_0x64c81a);}function os(_0x4497c0){const _0x2e65c7=_0x4497c0['indexOf']('$');return f(_0x2e65c7!==-0x1&&_0x2e65c7<_0x4497c0['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4497c0['substr'](_0x2e65c7+0x1),'path':new C(_0x4497c0['substr'](0x0,_0x2e65c7))};}function as(_0x5b531b,_0x1cd179,_0x21c992){const _0x38fb73=_0x5b531b['syncPointTree_']['get'](_0x1cd179);f(_0x38fb73,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0xc70098=Mn(_0x5b531b['pendingWriteTree_'],_0x1cd179);return is(_0x38fb73,_0x21c992,_0xc70098,null);}function Qu(_0x1fba86){return _0x1fba86['fold']((_0x554658,_0x110e87,_0x55eacf)=>{if(_0x110e87&&Te(_0x110e87))return[Ln(_0x110e87)];{let _0x26e7ab=[];return _0x110e87&&(_0x26e7ab=zo(_0x110e87)),x(_0x55eacf,(_0x4dd0f2,_0x2dc09b)=>{_0x26e7ab=_0x26e7ab['concat'](_0x2dc09b);}),_0x26e7ab;}});}function Tt(_0x1b3349){return _0x1b3349['_queryParams']['loadsAllData']()&&!_0x1b3349['_queryParams']['isDefault']()?new(Hu())(_0x1b3349['_repo'],_0x1b3349['_path']):_0x1b3349;}function Ju(_0x3aa0b0,_0x1ed7b4){for(let _0x3d4368=0x0;_0x3d4368<_0x1ed7b4['length'];++_0x3d4368){const _0x28a454=_0x1ed7b4[_0x3d4368];if(!_0x28a454['_queryParams']['loadsAllData']()){const _0x37305c=Fn(_0x28a454),_0x3e0f59=_0x3aa0b0['queryToTagMap']['get'](_0x37305c);_0x3aa0b0['queryToTagMap']['delete'](_0x37305c),_0x3aa0b0['tagToQueryMap']['delete'](_0x3e0f59);}}}function Xu(){return $u++;}function Zu(_0x133af,_0x272e8c,_0x259c16){const _0x234045=_0x272e8c['_path'],_0x946aee=Mt(_0x133af,_0x272e8c),_0x433f6d=Xo(_0x133af,_0x259c16),_0xaaadb=_0x133af['listenProvider_']['startListening'](Tt(_0x272e8c),_0x946aee,_0x433f6d['hashFn'],_0x433f6d['onComplete']),_0x47bba0=_0x133af['syncPointTree_']['subtree'](_0x234045);if(_0x946aee)f(!Te(_0x47bba0['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x44c052=_0x47bba0['fold']((_0xfbef8,_0x5af514,_0x29fd26)=>{if(!v(_0xfbef8)&&_0x5af514&&Te(_0x5af514))return[Ln(_0x5af514)['query']];{let _0x3db9f1=[];return _0x5af514&&(_0x3db9f1=_0x3db9f1['concat'](zo(_0x5af514)['map'](_0x539eea=>_0x539eea['query']))),x(_0x29fd26,(_0x2b2b0c,_0x4f3ad0)=>{_0x3db9f1=_0x3db9f1['concat'](_0x4f3ad0);}),_0x3db9f1;}});for(let _0x5548fc=0x0;_0x5548fc<_0x44c052['length'];++_0x5548fc){const _0x1aed60=_0x44c052[_0x5548fc];_0x133af['listenProvider_']['stopListening'](Tt(_0x1aed60),Mt(_0x133af,_0x1aed60));}}return _0xaaadb;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x4882aa){this['node_']=_0x4882aa;}['getImmediateChild'](_0x1248cc){const _0x508137=this['node_']['getImmediateChild'](_0x1248cc);return new cs(_0x508137);}['node'](){return this['node_'];}}class ls{constructor(_0x784e54,_0x527d14){this['syncTree_']=_0x784e54,this['path_']=_0x527d14;}['getImmediateChild'](_0x2fd64b){const _0x57be6c=A(this['path_'],_0x2fd64b);return new ls(this['syncTree_'],_0x57be6c);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x476a08){return _0x476a08=_0x476a08||{},_0x476a08['timestamp']=_0x476a08['timestamp']||new Date()['getTime'](),_0x476a08;},fr=function(_0x15ea2f,_0x218d7e,_0x49ee98){if(!_0x15ea2f||typeof _0x15ea2f!='object')return _0x15ea2f;if(f('.sv'in _0x15ea2f,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x15ea2f['.sv']=='string')return td(_0x15ea2f['.sv'],_0x218d7e,_0x49ee98);if(typeof _0x15ea2f['.sv']=='object')return nd(_0x15ea2f['.sv'],_0x218d7e);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x15ea2f,null,0x2));},td=function(_0x1ab426,_0x429522,_0x54c6af){switch(_0x1ab426){case'timestamp':return _0x54c6af['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1ab426);}},nd=function(_0x425cf4,_0x3472b0,_0x8cbe9){_0x425cf4['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x425cf4,null,0x2));const _0x114d3a=_0x425cf4['increment'];typeof _0x114d3a!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x114d3a);const _0x2960f7=_0x3472b0['node']();if(f(_0x2960f7!==null&&typeof _0x2960f7<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x2960f7['isLeafNode']())return _0x114d3a;const _0x4e8f57=_0x2960f7['getValue']();return typeof _0x4e8f57!='number'?_0x114d3a:_0x4e8f57+_0x114d3a;},Zo=function(_0x4e9ec1,_0x11130d,_0x5a1575,_0x348194){return us(_0x11130d,new ls(_0x5a1575,_0x4e9ec1),_0x348194);},hs=function(_0x561aa6,_0x577726,_0x2f6b12){return us(_0x561aa6,new cs(_0x577726),_0x2f6b12);};function us(_0x1d55f3,_0x4a7397,_0x1d795b){const _0x266082=_0x1d55f3['getPriority']()['val'](),_0x542b44=fr(_0x266082,_0x4a7397['getImmediateChild']('.priority'),_0x1d795b);let _0x48ecd8;if(_0x1d55f3['isLeafNode']()){const _0x503054=_0x1d55f3,_0xd24630=fr(_0x503054['getValue'](),_0x4a7397,_0x1d795b);return _0xd24630!==_0x503054['getValue']()||_0x542b44!==_0x503054['getPriority']()['val']()?new D(_0xd24630,N(_0x542b44)):_0x1d55f3;}else{const _0x364af7=_0x1d55f3;return _0x48ecd8=_0x364af7,_0x542b44!==_0x364af7['getPriority']()['val']()&&(_0x48ecd8=_0x48ecd8['updatePriority'](new D(_0x542b44))),_0x364af7['forEachChild'](R,(_0x22f5bb,_0x4514a6)=>{const _0x2da1f5=us(_0x4514a6,_0x4a7397['getImmediateChild'](_0x22f5bb),_0x1d795b);_0x2da1f5!==_0x4514a6&&(_0x48ecd8=_0x48ecd8['updateImmediateChild'](_0x22f5bb,_0x2da1f5));}),_0x48ecd8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x4d4cb0='',_0x3d4e5c=null,_0x521839={'children':{},'childCount':0x0}){this['name']=_0x4d4cb0,this['parent']=_0x3d4e5c,this['node']=_0x521839;}}function Un(_0x2f1b16,_0x32e9ab){let _0x14d07d=_0x32e9ab instanceof C?_0x32e9ab:new C(_0x32e9ab),_0x2d635f=_0x2f1b16,_0x5381e3=y(_0x14d07d);for(;_0x5381e3!==null;){const _0x59680e=Oe(_0x2d635f['node']['children'],_0x5381e3)||{'children':{},'childCount':0x0};_0x2d635f=new ds(_0x5381e3,_0x2d635f,_0x59680e),_0x14d07d=b(_0x14d07d),_0x5381e3=y(_0x14d07d);}return _0x2d635f;}function Ge(_0x1ec2fc){return _0x1ec2fc['node']['value'];}function fs(_0x2da042,_0x9b5fc5){_0x2da042['node']['value']=_0x9b5fc5,Ri(_0x2da042);}function ea(_0x51dbd1){return _0x51dbd1['node']['childCount']>0x0;}function id(_0x4be2af){return Ge(_0x4be2af)===void 0x0&&!ea(_0x4be2af);}function Wn(_0x558ddb,_0x52e022){x(_0x558ddb['node']['children'],(_0x1674d6,_0xe97e97)=>{_0x52e022(new ds(_0x1674d6,_0x558ddb,_0xe97e97));});}function ta(_0x4ff141,_0x1cc164,_0x5d9871,_0x2ee46d){_0x5d9871&&_0x1cc164(_0x4ff141),Wn(_0x4ff141,_0x1fe6b2=>{ta(_0x1fe6b2,_0x1cc164,!0x0);});}function sd(_0x57229f,_0x5d3a25,_0x2b886c){let _0x329421=_0x57229f['parent'];for(;_0x329421!==null;){if(_0x5d3a25(_0x329421))return!0x0;_0x329421=_0x329421['parent'];}return!0x1;}function Gt(_0x533c7f){return new C(_0x533c7f['parent']===null?_0x533c7f['name']:Gt(_0x533c7f['parent'])+'/'+_0x533c7f['name']);}function Ri(_0x572966){_0x572966['parent']!==null&&rd(_0x572966['parent'],_0x572966['name'],_0x572966);}function rd(_0x29f29b,_0xfaac6c,_0x35528b){const _0x139a23=id(_0x35528b),_0x2159ff=Y(_0x29f29b['node']['children'],_0xfaac6c);_0x139a23&&_0x2159ff?(delete _0x29f29b['node']['children'][_0xfaac6c],_0x29f29b['node']['childCount']--,Ri(_0x29f29b)):!_0x139a23&&!_0x2159ff&&(_0x29f29b['node']['children'][_0xfaac6c]=_0x35528b['node'],_0x29f29b['node']['childCount']++,Ri(_0x29f29b));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x756f79){return typeof _0x756f79=='string'&&_0x756f79['length']!==0x0&&!od['test'](_0x756f79);},na=function(_0x4ac108){return typeof _0x4ac108=='string'&&_0x4ac108['length']!==0x0&&!ad['test'](_0x4ac108);},cd=function(_0x3aebfd){return _0x3aebfd&&(_0x3aebfd=_0x3aebfd['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x3aebfd);},Cn=function(_0x1754fc){return _0x1754fc===null||typeof _0x1754fc=='string'||typeof _0x1754fc=='number'&&!Wi(_0x1754fc)||_0x1754fc&&typeof _0x1754fc=='object'&&Y(_0x1754fc,'.sv');},qt=function(_0xbb4917,_0x180ab8,_0x48f499,_0x4dde6c){_0x4dde6c&&_0x180ab8===void 0x0||zt(Nn(_0xbb4917,'value'),_0x180ab8,_0x48f499);},zt=function(_0x4374d3,_0xcd83e,_0x3b813e){const _0x57870e=_0x3b813e instanceof C?new Sh(_0x3b813e,_0x4374d3):_0x3b813e;if(_0xcd83e===void 0x0)throw new Error(_0x4374d3+'contains\x20undefined\x20'+Ne(_0x57870e));if(typeof _0xcd83e=='function')throw new Error(_0x4374d3+'contains\x20a\x20function\x20'+Ne(_0x57870e)+'\x20with\x20contents\x20=\x20'+_0xcd83e['toString']());if(Wi(_0xcd83e))throw new Error(_0x4374d3+'contains\x20'+_0xcd83e['toString']()+'\x20'+Ne(_0x57870e));if(typeof _0xcd83e=='string'&&_0xcd83e['length']>oi/0x3&&Pn(_0xcd83e)>oi)throw new Error(_0x4374d3+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x57870e)+'\x20(\x27'+_0xcd83e['substring'](0x0,0x32)+'...\x27)');if(_0xcd83e&&typeof _0xcd83e=='object'){let _0x6b8eee=!0x1,_0x2dfba6=!0x1;if(x(_0xcd83e,(_0x8a7a0b,_0x391592)=>{if(_0x8a7a0b==='.value')_0x6b8eee=!0x0;else{if(_0x8a7a0b!=='.priority'&&_0x8a7a0b!=='.sv'&&(_0x2dfba6=!0x0,!ps(_0x8a7a0b)))throw new Error(_0x4374d3+'\x20contains\x20an\x20invalid\x20key\x20('+_0x8a7a0b+')\x20'+Ne(_0x57870e)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x57870e,_0x8a7a0b),zt(_0x4374d3,_0x391592,_0x57870e),Rh(_0x57870e);}),_0x6b8eee&&_0x2dfba6)throw new Error(_0x4374d3+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x57870e)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x3a66f9,_0x586774){let _0x34cada,_0x59d5f5;for(_0x34cada=0x0;_0x34cada<_0x586774['length'];_0x34cada++){_0x59d5f5=_0x586774[_0x34cada];const _0x2f42ab=kt(_0x59d5f5);for(let _0x421b4e=0x0;_0x421b4e<_0x2f42ab['length'];_0x421b4e++)if(!(_0x2f42ab[_0x421b4e]==='.priority'&&_0x421b4e===_0x2f42ab['length']-0x1)){if(!ps(_0x2f42ab[_0x421b4e]))throw new Error(_0x3a66f9+'contains\x20an\x20invalid\x20key\x20('+_0x2f42ab[_0x421b4e]+')\x20in\x20path\x20'+_0x59d5f5['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x586774['sort'](Th);let _0x4d6d09=null;for(_0x34cada=0x0;_0x34cada<_0x586774['length'];_0x34cada++){if(_0x59d5f5=_0x586774[_0x34cada],_0x4d6d09!==null&&$(_0x4d6d09,_0x59d5f5))throw new Error(_0x3a66f9+'contains\x20a\x20path\x20'+_0x4d6d09['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x59d5f5['toString']());_0x4d6d09=_0x59d5f5;}},hd=function(_0x1ac62d,_0x2fd5ec,_0x38c739,_0x33546b){const _0x1a8e9d=Nn(_0x1ac62d,'values');if(!(_0x2fd5ec&&typeof _0x2fd5ec=='object')||Array['isArray'](_0x2fd5ec))throw new Error(_0x1a8e9d+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xa28f3f=[];x(_0x2fd5ec,(_0x10918c,_0x13ac20)=>{const _0x2d3f60=new C(_0x10918c);if(zt(_0x1a8e9d,_0x13ac20,A(_0x38c739,_0x2d3f60)),Gi(_0x2d3f60)==='.priority'&&!Cn(_0x13ac20))throw new Error(_0x1a8e9d+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2d3f60['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xa28f3f['push'](_0x2d3f60);}),ld(_0x1a8e9d,_0xa28f3f);},_s=function(_0x38a6bf,_0x1f083e,_0x2d403d,_0x242725){if(!na(_0x2d403d))throw new Error(Nn(_0x38a6bf,_0x1f083e)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2d403d+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x6defed,_0x5513e6,_0x1ce5f4,_0x558b80){_0x1ce5f4&&(_0x1ce5f4=_0x1ce5f4['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x6defed,_0x5513e6,_0x1ce5f4);},gs=function(_0x36108a,_0x3f54eb){if(y(_0x3f54eb)==='.info')throw new Error(_0x36108a+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x27da01,_0x40d967){const _0x14fa89=_0x40d967['path']['toString']();if(typeof _0x40d967['repoInfo']['host']!='string'||_0x40d967['repoInfo']['host']['length']===0x0||!ps(_0x40d967['repoInfo']['namespace'])&&_0x40d967['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x14fa89['length']!==0x0&&!cd(_0x14fa89))throw new Error(Nn(_0x27da01,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x5f400b,_0x46f4fc){let _0x2e3ebb=null;for(let _0x433531=0x0;_0x433531<_0x46f4fc['length'];_0x433531++){const _0xf67cf3=_0x46f4fc[_0x433531],_0x2872a5=_0xf67cf3['getPath']();_0x2e3ebb!==null&&!qi(_0x2872a5,_0x2e3ebb['path'])&&(_0x5f400b['eventLists_']['push'](_0x2e3ebb),_0x2e3ebb=null),_0x2e3ebb===null&&(_0x2e3ebb={'events':[],'path':_0x2872a5}),_0x2e3ebb['events']['push'](_0xf67cf3);}_0x2e3ebb&&_0x5f400b['eventLists_']['push'](_0x2e3ebb);}function ia(_0xd9eb7e,_0x54fb3f,_0xbd2a0e){Bn(_0xd9eb7e,_0xbd2a0e),sa(_0xd9eb7e,_0x24821d=>qi(_0x24821d,_0x54fb3f));}function V(_0x409551,_0x34a555,_0x558f20){Bn(_0x409551,_0x558f20),sa(_0x409551,_0x2cc393=>$(_0x2cc393,_0x34a555)||$(_0x34a555,_0x2cc393));}function sa(_0x587728,_0x520e5f){_0x587728['recursionDepth_']++;let _0x48d228=!0x0;for(let _0x2a01d0=0x0;_0x2a01d0<_0x587728['eventLists_']['length'];_0x2a01d0++){const _0x4d77ba=_0x587728['eventLists_'][_0x2a01d0];if(_0x4d77ba){const _0x5d5191=_0x4d77ba['path'];_0x520e5f(_0x5d5191)?(pd(_0x587728['eventLists_'][_0x2a01d0]),_0x587728['eventLists_'][_0x2a01d0]=null):_0x48d228=!0x1;}}_0x48d228&&(_0x587728['eventLists_']=[]),_0x587728['recursionDepth_']--;}function pd(_0x450ed0){for(let _0x234ec9=0x0;_0x234ec9<_0x450ed0['events']['length'];_0x234ec9++){const _0x3a1a01=_0x450ed0['events'][_0x234ec9];if(_0x3a1a01!==null){_0x450ed0['events'][_0x234ec9]=null;const _0x3eee04=_0x3a1a01['getEventRunner']();Et&&L('event:\x20'+_0x3a1a01['toString']()),lt(_0x3eee04);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x45390d,_0x3049e9,_0x863b65,_0x364330){this['repoInfo_']=_0x45390d,this['forceRestClient_']=_0x3049e9,this['authTokenProvider_']=_0x863b65,this['appCheckProvider_']=_0x364330,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x1f1b49,_0x41e4c1,_0x3e7227){if(_0x1f1b49['stats_']=Hi(_0x1f1b49['repoInfo_']),_0x1f1b49['forceRestClient_']||Yl())_0x1f1b49['server_']=new fn(_0x1f1b49['repoInfo_'],(_0x37f956,_0x324aed,_0x55adae,_0x57f7dd)=>{pr(_0x1f1b49,_0x37f956,_0x324aed,_0x55adae,_0x57f7dd);},_0x1f1b49['authTokenProvider_'],_0x1f1b49['appCheckProvider_']),setTimeout(()=>_r(_0x1f1b49,!0x0),0x0);else{if(typeof _0x3e7227<'u'&&_0x3e7227!==null){if(typeof _0x3e7227!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x3e7227);}catch(_0x2d2097){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x2d2097);}}_0x1f1b49['persistentConnection_']=new ie(_0x1f1b49['repoInfo_'],_0x41e4c1,(_0x44b26f,_0x31a43b,_0x362786,_0x1e7dc1)=>{pr(_0x1f1b49,_0x44b26f,_0x31a43b,_0x362786,_0x1e7dc1);},_0x213b8e=>{_r(_0x1f1b49,_0x213b8e);},_0xfe9f3d=>{yd(_0x1f1b49,_0xfe9f3d);},_0x1f1b49['authTokenProvider_'],_0x1f1b49['appCheckProvider_'],_0x3e7227),_0x1f1b49['server_']=_0x1f1b49['persistentConnection_'];}_0x1f1b49['authTokenProvider_']['addTokenChangeListener'](_0x3f0837=>{_0x1f1b49['server_']['refreshAuthToken'](_0x3f0837);}),_0x1f1b49['appCheckProvider_']['addTokenChangeListener'](_0x3be1ea=>{_0x1f1b49['server_']['refreshAppCheckToken'](_0x3be1ea['token']);}),_0x1f1b49['statsReporter_']=eh(_0x1f1b49['repoInfo_'],()=>new eu(_0x1f1b49['stats_'],_0x1f1b49['server_'])),_0x1f1b49['infoData_']=new Yh(),_0x1f1b49['infoSyncTree_']=new dr({'startListening':(_0x4d6d53,_0x9eab22,_0x4dadb4,_0x29b205)=>{let _0x50d0e1=[];const _0x36f745=_0x1f1b49['infoData_']['getNode'](_0x4d6d53['_path']);return _0x36f745['isEmpty']()||(_0x50d0e1=$t(_0x1f1b49['infoSyncTree_'],_0x4d6d53['_path'],_0x36f745),setTimeout(()=>{_0x29b205('ok');},0x0)),_0x50d0e1;},'stopListening':()=>{}}),ms(_0x1f1b49,'connected',!0x1),_0x1f1b49['serverSyncTree_']=new dr({'startListening':(_0x461ee4,_0x15e40a,_0x32af36,_0x3a9823)=>(_0x1f1b49['server_']['listen'](_0x461ee4,_0x32af36,_0x15e40a,(_0x285893,_0x4c77bc)=>{const _0x5e826d=_0x3a9823(_0x285893,_0x4c77bc);V(_0x1f1b49['eventQueue_'],_0x461ee4['_path'],_0x5e826d);}),[]),'stopListening':(_0x44ab7b,_0x189b61)=>{_0x1f1b49['server_']['unlisten'](_0x44ab7b,_0x189b61);}});}function oa(_0x2a1271){const _0x2e922d=_0x2a1271['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x2e922d;}function jt(_0x893776){return ed({'timestamp':oa(_0x893776)});}function pr(_0x338c3f,_0x81d74b,_0x5792c9,_0x1a2664,_0x37f62a){_0x338c3f['dataUpdateCount']++;const _0x3312a3=new C(_0x81d74b);_0x5792c9=_0x338c3f['interceptServerDataCallback_']?_0x338c3f['interceptServerDataCallback_'](_0x81d74b,_0x5792c9):_0x5792c9;let _0x420817=[];if(_0x37f62a){if(_0x1a2664){const _0x503fa7=ln(_0x5792c9,_0xab3451=>N(_0xab3451));_0x420817=Ku(_0x338c3f['serverSyncTree_'],_0x3312a3,_0x503fa7,_0x37f62a);}else{const _0x5e045a=N(_0x5792c9);_0x420817=Yo(_0x338c3f['serverSyncTree_'],_0x3312a3,_0x5e045a,_0x37f62a);}}else{if(_0x1a2664){const _0x197d82=ln(_0x5792c9,_0x412182=>N(_0x412182));_0x420817=qu(_0x338c3f['serverSyncTree_'],_0x3312a3,_0x197d82);}else{const _0x974aba=N(_0x5792c9);_0x420817=$t(_0x338c3f['serverSyncTree_'],_0x3312a3,_0x974aba);}}let _0x32106f=_0x3312a3;_0x420817['length']>0x0&&(_0x32106f=st(_0x338c3f,_0x3312a3)),V(_0x338c3f['eventQueue_'],_0x32106f,_0x420817);}function _r(_0x377223,_0x4f5c93){ms(_0x377223,'connected',_0x4f5c93),_0x4f5c93===!0x1&&wd(_0x377223);}function yd(_0x253606,_0x58aaec){x(_0x58aaec,(_0x13a9ac,_0x2fed04)=>{ms(_0x253606,_0x13a9ac,_0x2fed04);});}function ms(_0x996741,_0x1e5519,_0xa2b127){const _0x9e587e=new C('/.info/'+_0x1e5519),_0x3cb8c3=N(_0xa2b127);_0x996741['infoData_']['updateSnapshot'](_0x9e587e,_0x3cb8c3);const _0xb31559=$t(_0x996741['infoSyncTree_'],_0x9e587e,_0x3cb8c3);V(_0x996741['eventQueue_'],_0x9e587e,_0xb31559);}function Vn(_0x3e5fcd){return _0x3e5fcd['nextWriteId_']++;}function vd(_0x461b1b,_0x34ce16,_0x4c8eed){const _0x5c7d33=Yu(_0x461b1b['serverSyncTree_'],_0x34ce16);return _0x5c7d33!=null?Promise['resolve'](_0x5c7d33):_0x461b1b['server_']['get'](_0x34ce16)['then'](_0x47b570=>{const _0x4f8448=N(_0x47b570)['withIndex'](_0x34ce16['_queryParams']['getIndex']());bi(_0x461b1b['serverSyncTree_'],_0x34ce16,_0x4c8eed,!0x0);let _0x34d2bf;if(_0x34ce16['_queryParams']['loadsAllData']())_0x34d2bf=$t(_0x461b1b['serverSyncTree_'],_0x34ce16['_path'],_0x4f8448);else{const _0x2c14b1=Mt(_0x461b1b['serverSyncTree_'],_0x34ce16);_0x34d2bf=Yo(_0x461b1b['serverSyncTree_'],_0x34ce16['_path'],_0x4f8448,_0x2c14b1);}return V(_0x461b1b['eventQueue_'],_0x34ce16['_path'],_0x34d2bf),wn(_0x461b1b['serverSyncTree_'],_0x34ce16,_0x4c8eed,null,!0x0),_0x4f8448;},_0x33a2e7=>(ut(_0x461b1b,'get\x20for\x20query\x20'+O(_0x34ce16)+'\x20failed:\x20'+_0x33a2e7),Promise['reject'](new Error(_0x33a2e7))));}function Ed(_0x15214d,_0x54ce24,_0x15abb4,_0x16e6e4,_0x18e127){ut(_0x15214d,'set',{'path':_0x54ce24['toString'](),'value':_0x15abb4,'priority':_0x16e6e4});const _0x2e243d=jt(_0x15214d),_0x4db444=N(_0x15abb4,_0x16e6e4),_0x147c53=xn(_0x15214d['serverSyncTree_'],_0x54ce24),_0xe72913=hs(_0x4db444,_0x147c53,_0x2e243d),_0x2c90ca=Vn(_0x15214d),_0x3ebc38=ss(_0x15214d['serverSyncTree_'],_0x54ce24,_0xe72913,_0x2c90ca,!0x0);Bn(_0x15214d['eventQueue_'],_0x3ebc38),_0x15214d['server_']['put'](_0x54ce24['toString'](),_0x4db444['val'](!0x0),(_0x396fe5,_0x403385)=>{const _0x3aefc3=_0x396fe5==='ok';_0x3aefc3||U('set\x20at\x20'+_0x54ce24+'\x20failed:\x20'+_0x396fe5);const _0x285d79=pe(_0x15214d['serverSyncTree_'],_0x2c90ca,!_0x3aefc3);V(_0x15214d['eventQueue_'],_0x54ce24,_0x285d79),Ai(_0x15214d,_0x18e127,_0x396fe5,_0x403385);});const _0xb752da=vs(_0x15214d,_0x54ce24);st(_0x15214d,_0xb752da),V(_0x15214d['eventQueue_'],_0xb752da,[]);}function Id(_0x5a15aa,_0x554895,_0x46e054,_0x1311a3){ut(_0x5a15aa,'update',{'path':_0x554895['toString'](),'value':_0x46e054});let _0x4e0b15=!0x0;const _0x1afc98=jt(_0x5a15aa),_0x3d1540={};if(x(_0x46e054,(_0x27b023,_0x5cf854)=>{_0x4e0b15=!0x1,_0x3d1540[_0x27b023]=Zo(A(_0x554895,_0x27b023),N(_0x5cf854),_0x5a15aa['serverSyncTree_'],_0x1afc98);}),_0x4e0b15)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x5a15aa,_0x1311a3,'ok',void 0x0);else{const _0x41f33d=Vn(_0x5a15aa),_0x1e9437=Gu(_0x5a15aa['serverSyncTree_'],_0x554895,_0x3d1540,_0x41f33d);Bn(_0x5a15aa['eventQueue_'],_0x1e9437),_0x5a15aa['server_']['merge'](_0x554895['toString'](),_0x46e054,(_0x1f693e,_0x3f8a86)=>{const _0x282809=_0x1f693e==='ok';_0x282809||U('update\x20at\x20'+_0x554895+'\x20failed:\x20'+_0x1f693e);const _0x1de898=pe(_0x5a15aa['serverSyncTree_'],_0x41f33d,!_0x282809),_0x4d3431=_0x1de898['length']>0x0?st(_0x5a15aa,_0x554895):_0x554895;V(_0x5a15aa['eventQueue_'],_0x4d3431,_0x1de898),Ai(_0x5a15aa,_0x1311a3,_0x1f693e,_0x3f8a86);}),x(_0x46e054,_0x29bb60=>{const _0x34ec5e=vs(_0x5a15aa,A(_0x554895,_0x29bb60));st(_0x5a15aa,_0x34ec5e);}),V(_0x5a15aa['eventQueue_'],_0x554895,[]);}}function wd(_0x9de77d){ut(_0x9de77d,'onDisconnectEvents');const _0x4fbeed=jt(_0x9de77d),_0x3bb023=pn();Ei(_0x9de77d['onDisconnect_'],w(),(_0x1f4f9f,_0x1aa8ac)=>{const _0x12f0a4=Zo(_0x1f4f9f,_0x1aa8ac,_0x9de77d['serverSyncTree_'],_0x4fbeed);Mo(_0x3bb023,_0x1f4f9f,_0x12f0a4);});let _0x162b80=[];Ei(_0x3bb023,w(),(_0x2e932e,_0x4ffb8c)=>{_0x162b80=_0x162b80['concat']($t(_0x9de77d['serverSyncTree_'],_0x2e932e,_0x4ffb8c));const _0x264fdb=vs(_0x9de77d,_0x2e932e);st(_0x9de77d,_0x264fdb);}),_0x9de77d['onDisconnect_']=pn(),V(_0x9de77d['eventQueue_'],w(),_0x162b80);}function Cd(_0x905196,_0x3d9ad4,_0x48d308){let _0x4d07fe;y(_0x3d9ad4['_path'])==='.info'?_0x4d07fe=bi(_0x905196['infoSyncTree_'],_0x3d9ad4,_0x48d308):_0x4d07fe=bi(_0x905196['serverSyncTree_'],_0x3d9ad4,_0x48d308),ia(_0x905196['eventQueue_'],_0x3d9ad4['_path'],_0x4d07fe);}function Td(_0x484950,_0x4d57fe,_0x438460){let _0x22248c;y(_0x4d57fe['_path'])==='.info'?_0x22248c=wn(_0x484950['infoSyncTree_'],_0x4d57fe,_0x438460):_0x22248c=wn(_0x484950['serverSyncTree_'],_0x4d57fe,_0x438460),ia(_0x484950['eventQueue_'],_0x4d57fe['_path'],_0x22248c);}function aa(_0x312222){_0x312222['persistentConnection_']&&_0x312222['persistentConnection_']['interrupt'](ra);}function Sd(_0xc3fde1){_0xc3fde1['persistentConnection_']&&_0xc3fde1['persistentConnection_']['resume'](ra);}function ut(_0x16e47b,..._0x563b82){let _0x145ff4='';_0x16e47b['persistentConnection_']&&(_0x145ff4=_0x16e47b['persistentConnection_']['id']+':'),L(_0x145ff4,..._0x563b82);}function Ai(_0x338192,_0x257321,_0x3be0a0,_0x29325c){_0x257321&&lt(()=>{if(_0x3be0a0==='ok')_0x257321(null);else{const _0xbb7786=(_0x3be0a0||'error')['toUpperCase']();let _0xc08ed=_0xbb7786;_0x29325c&&(_0xc08ed+=':\x20'+_0x29325c);const _0x3b97d6=new Error(_0xc08ed);_0x3b97d6['code']=_0xbb7786,_0x257321(_0x3b97d6);}});}function bd(_0x53d4c9,_0x5bc46a,_0x3b9c42,_0x5ec506,_0x43c3d5,_0x51a310){ut(_0x53d4c9,'transaction\x20on\x20'+_0x5bc46a);const _0x5a17e6={'path':_0x5bc46a,'update':_0x3b9c42,'onComplete':_0x5ec506,'status':null,'order':to(),'applyLocally':_0x51a310,'retryCount':0x0,'unwatcher':_0x43c3d5,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x49c0da=ys(_0x53d4c9,_0x5bc46a,void 0x0);_0x5a17e6['currentInputSnapshot']=_0x49c0da;const _0x49b03c=_0x5a17e6['update'](_0x49c0da['val']());if(_0x49b03c===void 0x0)_0x5a17e6['unwatcher'](),_0x5a17e6['currentOutputSnapshotRaw']=null,_0x5a17e6['currentOutputSnapshotResolved']=null,_0x5a17e6['onComplete']&&_0x5a17e6['onComplete'](null,!0x1,_0x5a17e6['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x49b03c,_0x5a17e6['path']),_0x5a17e6['status']=0x0;const _0x5b57d6=Un(_0x53d4c9['transactionQueueTree_'],_0x5bc46a),_0x4cb399=Ge(_0x5b57d6)||[];_0x4cb399['push'](_0x5a17e6),fs(_0x5b57d6,_0x4cb399);let _0x50ab1d;typeof _0x49b03c=='object'&&_0x49b03c!==null&&Y(_0x49b03c,'.priority')?(_0x50ab1d=Oe(_0x49b03c,'.priority'),f(Cn(_0x50ab1d),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x50ab1d=(xn(_0x53d4c9['serverSyncTree_'],_0x5bc46a)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3a1daf=jt(_0x53d4c9),_0xd6cd60=N(_0x49b03c,_0x50ab1d),_0x1a408f=hs(_0xd6cd60,_0x49c0da,_0x3a1daf);_0x5a17e6['currentOutputSnapshotRaw']=_0xd6cd60,_0x5a17e6['currentOutputSnapshotResolved']=_0x1a408f,_0x5a17e6['currentWriteId']=Vn(_0x53d4c9);const _0x8f6cca=ss(_0x53d4c9['serverSyncTree_'],_0x5bc46a,_0x1a408f,_0x5a17e6['currentWriteId'],_0x5a17e6['applyLocally']);V(_0x53d4c9['eventQueue_'],_0x5bc46a,_0x8f6cca),Hn(_0x53d4c9,_0x53d4c9['transactionQueueTree_']);}}function ys(_0x1387a1,_0x1c11ec,_0x374bda){return xn(_0x1387a1['serverSyncTree_'],_0x1c11ec,_0x374bda)||g['EMPTY_NODE'];}function Hn(_0xbdbb52,_0x582e5b=_0xbdbb52['transactionQueueTree_']){if(_0x582e5b||$n(_0xbdbb52,_0x582e5b),Ge(_0x582e5b)){const _0x599522=la(_0xbdbb52,_0x582e5b);f(_0x599522['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x599522['every'](_0x3a4247=>_0x3a4247['status']===0x0)&&Rd(_0xbdbb52,Gt(_0x582e5b),_0x599522);}else ea(_0x582e5b)&&Wn(_0x582e5b,_0xb96c8=>{Hn(_0xbdbb52,_0xb96c8);});}function Rd(_0x1d987b,_0x30bf89,_0xad5dec){const _0x2d65e6=_0xad5dec['map'](_0x32db41=>_0x32db41['currentWriteId']),_0x230518=ys(_0x1d987b,_0x30bf89,_0x2d65e6);let _0x5aa98e=_0x230518;const _0x15da24=_0x230518['hash']();for(let _0x448004=0x0;_0x448004<_0xad5dec['length'];_0x448004++){const _0x1d6cfe=_0xad5dec[_0x448004];f(_0x1d6cfe['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x1d6cfe['status']=0x1,_0x1d6cfe['retryCount']++;const _0x57d907=F(_0x30bf89,_0x1d6cfe['path']);_0x5aa98e=_0x5aa98e['updateChild'](_0x57d907,_0x1d6cfe['currentOutputSnapshotRaw']);}const _0x239db1=_0x5aa98e['val'](!0x0),_0x1de4a9=_0x30bf89;_0x1d987b['server_']['put'](_0x1de4a9['toString'](),_0x239db1,_0x3cc54e=>{ut(_0x1d987b,'transaction\x20put\x20response',{'path':_0x1de4a9['toString'](),'status':_0x3cc54e});let _0x1b2c4c=[];if(_0x3cc54e==='ok'){const _0x2080a3=[];for(let _0x5d51db=0x0;_0x5d51db<_0xad5dec['length'];_0x5d51db++)_0xad5dec[_0x5d51db]['status']=0x2,_0x1b2c4c=_0x1b2c4c['concat'](pe(_0x1d987b['serverSyncTree_'],_0xad5dec[_0x5d51db]['currentWriteId'])),_0xad5dec[_0x5d51db]['onComplete']&&_0x2080a3['push'](()=>_0xad5dec[_0x5d51db]['onComplete'](null,!0x0,_0xad5dec[_0x5d51db]['currentOutputSnapshotResolved'])),_0xad5dec[_0x5d51db]['unwatcher']();$n(_0x1d987b,Un(_0x1d987b['transactionQueueTree_'],_0x30bf89)),Hn(_0x1d987b,_0x1d987b['transactionQueueTree_']),V(_0x1d987b['eventQueue_'],_0x30bf89,_0x1b2c4c);for(let _0x5ad6e3=0x0;_0x5ad6e3<_0x2080a3['length'];_0x5ad6e3++)lt(_0x2080a3[_0x5ad6e3]);}else{if(_0x3cc54e==='datastale'){for(let _0x4af353=0x0;_0x4af353<_0xad5dec['length'];_0x4af353++)_0xad5dec[_0x4af353]['status']===0x3?_0xad5dec[_0x4af353]['status']=0x4:_0xad5dec[_0x4af353]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1de4a9['toString']()+'\x20failed:\x20'+_0x3cc54e);for(let _0x596f06=0x0;_0x596f06<_0xad5dec['length'];_0x596f06++)_0xad5dec[_0x596f06]['status']=0x4,_0xad5dec[_0x596f06]['abortReason']=_0x3cc54e;}st(_0x1d987b,_0x30bf89);}},_0x15da24);}function st(_0x585a52,_0x42a96d){const _0x1153cb=ca(_0x585a52,_0x42a96d),_0x3470d2=Gt(_0x1153cb),_0x16d338=la(_0x585a52,_0x1153cb);return Ad(_0x585a52,_0x16d338,_0x3470d2),_0x3470d2;}function Ad(_0xb2bf01,_0x125a04,_0x17977d){if(_0x125a04['length']===0x0)return;const _0x4594a4=[];let _0x2185f4=[];const _0x40ee96=_0x125a04['filter'](_0x1f9743=>_0x1f9743['status']===0x0)['map'](_0x1217f0=>_0x1217f0['currentWriteId']);for(let _0x1109fb=0x0;_0x1109fb<_0x125a04['length'];_0x1109fb++){const _0x10e5f4=_0x125a04[_0x1109fb],_0x3e80ef=F(_0x17977d,_0x10e5f4['path']);let _0x443638=!0x1,_0x5d0a06;if(f(_0x3e80ef!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x10e5f4['status']===0x4)_0x443638=!0x0,_0x5d0a06=_0x10e5f4['abortReason'],_0x2185f4=_0x2185f4['concat'](pe(_0xb2bf01['serverSyncTree_'],_0x10e5f4['currentWriteId'],!0x0));else{if(_0x10e5f4['status']===0x0){if(_0x10e5f4['retryCount']>=_d)_0x443638=!0x0,_0x5d0a06='maxretry',_0x2185f4=_0x2185f4['concat'](pe(_0xb2bf01['serverSyncTree_'],_0x10e5f4['currentWriteId'],!0x0));else{const _0x5ab6b7=ys(_0xb2bf01,_0x10e5f4['path'],_0x40ee96);_0x10e5f4['currentInputSnapshot']=_0x5ab6b7;const _0x3e487b=_0x125a04[_0x1109fb]['update'](_0x5ab6b7['val']());if(_0x3e487b!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x3e487b,_0x10e5f4['path']);let _0x45115c=N(_0x3e487b);typeof _0x3e487b=='object'&&_0x3e487b!=null&&Y(_0x3e487b,'.priority')||(_0x45115c=_0x45115c['updatePriority'](_0x5ab6b7['getPriority']()));const _0x43bccc=_0x10e5f4['currentWriteId'],_0x26a445=jt(_0xb2bf01),_0x3b098a=hs(_0x45115c,_0x5ab6b7,_0x26a445);_0x10e5f4['currentOutputSnapshotRaw']=_0x45115c,_0x10e5f4['currentOutputSnapshotResolved']=_0x3b098a,_0x10e5f4['currentWriteId']=Vn(_0xb2bf01),_0x40ee96['splice'](_0x40ee96['indexOf'](_0x43bccc),0x1),_0x2185f4=_0x2185f4['concat'](ss(_0xb2bf01['serverSyncTree_'],_0x10e5f4['path'],_0x3b098a,_0x10e5f4['currentWriteId'],_0x10e5f4['applyLocally'])),_0x2185f4=_0x2185f4['concat'](pe(_0xb2bf01['serverSyncTree_'],_0x43bccc,!0x0));}else _0x443638=!0x0,_0x5d0a06='nodata',_0x2185f4=_0x2185f4['concat'](pe(_0xb2bf01['serverSyncTree_'],_0x10e5f4['currentWriteId'],!0x0));}}}V(_0xb2bf01['eventQueue_'],_0x17977d,_0x2185f4),_0x2185f4=[],_0x443638&&(_0x125a04[_0x1109fb]['status']=0x2,function(_0x23dc8f){setTimeout(_0x23dc8f,Math['floor'](0x0));}(_0x125a04[_0x1109fb]['unwatcher']),_0x125a04[_0x1109fb]['onComplete']&&(_0x5d0a06==='nodata'?_0x4594a4['push'](()=>_0x125a04[_0x1109fb]['onComplete'](null,!0x1,_0x125a04[_0x1109fb]['currentInputSnapshot'])):_0x4594a4['push'](()=>_0x125a04[_0x1109fb]['onComplete'](new Error(_0x5d0a06),!0x1,null))));}$n(_0xb2bf01,_0xb2bf01['transactionQueueTree_']);for(let _0x79d472=0x0;_0x79d472<_0x4594a4['length'];_0x79d472++)lt(_0x4594a4[_0x79d472]);Hn(_0xb2bf01,_0xb2bf01['transactionQueueTree_']);}function ca(_0x508dba,_0xe8874d){let _0xeebeb4,_0x3b42ae=_0x508dba['transactionQueueTree_'];for(_0xeebeb4=y(_0xe8874d);_0xeebeb4!==null&&Ge(_0x3b42ae)===void 0x0;)_0x3b42ae=Un(_0x3b42ae,_0xeebeb4),_0xe8874d=b(_0xe8874d),_0xeebeb4=y(_0xe8874d);return _0x3b42ae;}function la(_0x2a3f25,_0x3d01ce){const _0x11676c=[];return ha(_0x2a3f25,_0x3d01ce,_0x11676c),_0x11676c['sort']((_0x3e28cf,_0x531691)=>_0x3e28cf['order']-_0x531691['order']),_0x11676c;}function ha(_0x50b39d,_0x1f7f6c,_0x25324d){const _0x2f0bc9=Ge(_0x1f7f6c);if(_0x2f0bc9){for(let _0x6e834a=0x0;_0x6e834a<_0x2f0bc9['length'];_0x6e834a++)_0x25324d['push'](_0x2f0bc9[_0x6e834a]);}Wn(_0x1f7f6c,_0x42a162=>{ha(_0x50b39d,_0x42a162,_0x25324d);});}function $n(_0xae9886,_0x3b5767){const _0x1c9411=Ge(_0x3b5767);if(_0x1c9411){let _0x64861c=0x0;for(let _0x1ce6a9=0x0;_0x1ce6a9<_0x1c9411['length'];_0x1ce6a9++)_0x1c9411[_0x1ce6a9]['status']!==0x2&&(_0x1c9411[_0x64861c]=_0x1c9411[_0x1ce6a9],_0x64861c++);_0x1c9411['length']=_0x64861c,fs(_0x3b5767,_0x1c9411['length']>0x0?_0x1c9411:void 0x0);}Wn(_0x3b5767,_0x456871=>{$n(_0xae9886,_0x456871);});}function vs(_0x553d42,_0x112f83){const _0xa06d3e=Gt(ca(_0x553d42,_0x112f83)),_0x37808c=Un(_0x553d42['transactionQueueTree_'],_0x112f83);return sd(_0x37808c,_0x3682ea=>{ai(_0x553d42,_0x3682ea);}),ai(_0x553d42,_0x37808c),ta(_0x37808c,_0x19d45a=>{ai(_0x553d42,_0x19d45a);}),_0xa06d3e;}function ai(_0x3b0a49,_0x591453){const _0xfcedd9=Ge(_0x591453);if(_0xfcedd9){const _0x33b5e4=[];let _0x1adefd=[],_0x5620c3=-0x1;for(let _0x514eaa=0x0;_0x514eaa<_0xfcedd9['length'];_0x514eaa++)_0xfcedd9[_0x514eaa]['status']===0x3||(_0xfcedd9[_0x514eaa]['status']===0x1?(f(_0x5620c3===_0x514eaa-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x5620c3=_0x514eaa,_0xfcedd9[_0x514eaa]['status']=0x3,_0xfcedd9[_0x514eaa]['abortReason']='set'):(f(_0xfcedd9[_0x514eaa]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0xfcedd9[_0x514eaa]['unwatcher'](),_0x1adefd=_0x1adefd['concat'](pe(_0x3b0a49['serverSyncTree_'],_0xfcedd9[_0x514eaa]['currentWriteId'],!0x0)),_0xfcedd9[_0x514eaa]['onComplete']&&_0x33b5e4['push'](_0xfcedd9[_0x514eaa]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x5620c3===-0x1?fs(_0x591453,void 0x0):_0xfcedd9['length']=_0x5620c3+0x1,V(_0x3b0a49['eventQueue_'],Gt(_0x591453),_0x1adefd);for(let _0x1f2b8e=0x0;_0x1f2b8e<_0x33b5e4['length'];_0x1f2b8e++)lt(_0x33b5e4[_0x1f2b8e]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x134bab){let _0x326e99='';const _0x3de842=_0x134bab['split']('/');for(let _0x160c50=0x0;_0x160c50<_0x3de842['length'];_0x160c50++)if(_0x3de842[_0x160c50]['length']>0x0){let _0x5ee7c4=_0x3de842[_0x160c50];try{_0x5ee7c4=decodeURIComponent(_0x5ee7c4['replace'](/\+/g,'\x20'));}catch{}_0x326e99+='/'+_0x5ee7c4;}return _0x326e99;}function Nd(_0x46db68){const _0x1c3ecd={};_0x46db68['charAt'](0x0)==='?'&&(_0x46db68=_0x46db68['substring'](0x1));for(const _0x48aa8f of _0x46db68['split']('&')){if(_0x48aa8f['length']===0x0)continue;const _0x5c9a9c=_0x48aa8f['split']('=');_0x5c9a9c['length']===0x2?_0x1c3ecd[decodeURIComponent(_0x5c9a9c[0x0])]=decodeURIComponent(_0x5c9a9c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x48aa8f+'\x27\x20in\x20query\x20\x27'+_0x46db68+'\x27');}return _0x1c3ecd;}const gr=function(_0x1578bf,_0x1295f1){const _0x584d18=Pd(_0x1578bf),_0x4e3564=_0x584d18['namespace'];_0x584d18['domain']==='firebase.com'&&oe(_0x584d18['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4e3564||_0x4e3564==='undefined')&&_0x584d18['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x584d18['secure']||Bl();const _0x2bcc03=_0x584d18['scheme']==='ws'||_0x584d18['scheme']==='wss';return{'repoInfo':new _o(_0x584d18['host'],_0x584d18['secure'],_0x4e3564,_0x2bcc03,_0x1295f1,'',_0x4e3564!==_0x584d18['subdomain']),'path':new C(_0x584d18['pathString'])};},Pd=function(_0x1df956){let _0x5f18c4='',_0x408701='',_0x190b32='',_0x1252d3='',_0x4385c8='',_0x3116ce=!0x0,_0x525c44='https',_0x2bffc1=0x1bb;if(typeof _0x1df956=='string'){let _0x45bd3a=_0x1df956['indexOf']('//');_0x45bd3a>=0x0&&(_0x525c44=_0x1df956['substring'](0x0,_0x45bd3a-0x1),_0x1df956=_0x1df956['substring'](_0x45bd3a+0x2));let _0x184ab3=_0x1df956['indexOf']('/');_0x184ab3===-0x1&&(_0x184ab3=_0x1df956['length']);let _0x2c6338=_0x1df956['indexOf']('?');_0x2c6338===-0x1&&(_0x2c6338=_0x1df956['length']),_0x5f18c4=_0x1df956['substring'](0x0,Math['min'](_0x184ab3,_0x2c6338)),_0x184ab3<_0x2c6338&&(_0x1252d3=kd(_0x1df956['substring'](_0x184ab3,_0x2c6338)));const _0x48887b=Nd(_0x1df956['substring'](Math['min'](_0x1df956['length'],_0x2c6338)));_0x45bd3a=_0x5f18c4['indexOf'](':'),_0x45bd3a>=0x0?(_0x3116ce=_0x525c44==='https'||_0x525c44==='wss',_0x2bffc1=parseInt(_0x5f18c4['substring'](_0x45bd3a+0x1),0xa)):_0x45bd3a=_0x5f18c4['length'];const _0x56f730=_0x5f18c4['slice'](0x0,_0x45bd3a);if(_0x56f730['toLowerCase']()==='localhost')_0x408701='localhost';else{if(_0x56f730['split']('.')['length']<=0x2)_0x408701=_0x56f730;else{const _0x3588dd=_0x5f18c4['indexOf']('.');_0x190b32=_0x5f18c4['substring'](0x0,_0x3588dd)['toLowerCase'](),_0x408701=_0x5f18c4['substring'](_0x3588dd+0x1),_0x4385c8=_0x190b32;}}'ns'in _0x48887b&&(_0x4385c8=_0x48887b['ns']);}return{'host':_0x5f18c4,'port':_0x2bffc1,'domain':_0x408701,'subdomain':_0x190b32,'secure':_0x3116ce,'scheme':_0x525c44,'pathString':_0x1252d3,'namespace':_0x4385c8};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x494408=0x0;const _0x68cbac=[];return function(_0x15943b){const _0x170c54=_0x15943b===_0x494408;_0x494408=_0x15943b;let _0x323071;const _0x588ee5=new Array(0x8);for(_0x323071=0x7;_0x323071>=0x0;_0x323071--)_0x588ee5[_0x323071]=mr['charAt'](_0x15943b%0x40),_0x15943b=Math['floor'](_0x15943b/0x40);f(_0x15943b===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x319243=_0x588ee5['join']('');if(_0x170c54){for(_0x323071=0xb;_0x323071>=0x0&&_0x68cbac[_0x323071]===0x3f;_0x323071--)_0x68cbac[_0x323071]=0x0;_0x68cbac[_0x323071]++;}else{for(_0x323071=0x0;_0x323071<0xc;_0x323071++)_0x68cbac[_0x323071]=Math['floor'](Math['random']()*0x40);}for(_0x323071=0x0;_0x323071<0xc;_0x323071++)_0x319243+=mr['charAt'](_0x68cbac[_0x323071]);return f(_0x319243['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x319243;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x54ee3c,_0x57ba0d,_0x1090aa,_0x4c7d61){this['eventType']=_0x54ee3c,this['eventRegistration']=_0x57ba0d,this['snapshot']=_0x1090aa,this['prevName']=_0x4c7d61;}['getPath'](){const _0x256731=this['snapshot']['ref'];return this['eventType']==='value'?_0x256731['_path']:_0x256731['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x54c700,_0x328d7b,_0x3282f5){this['eventRegistration']=_0x54c700,this['error']=_0x328d7b,this['path']=_0x3282f5;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x30c4db,_0x449ce3){this['snapshotCallback']=_0x30c4db,this['cancelCallback']=_0x449ce3;}['onValue'](_0x4183e0,_0x2c3d2c){this['snapshotCallback']['call'](null,_0x4183e0,_0x2c3d2c);}['onCancel'](_0x9822dd){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x9822dd);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x12376d){return this['snapshotCallback']===_0x12376d['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x12376d['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x12376d['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x47e6cc,_0x3b1615,_0x3fc50a,_0x44fbc4){this['_repo']=_0x47e6cc,this['_path']=_0x3b1615,this['_queryParams']=_0x3fc50a,this['_orderByCalled']=_0x44fbc4;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4caa03=nr(this['_queryParams']),_0x5a7a79=Bi(_0x4caa03);return _0x5a7a79==='{}'?'default':_0x5a7a79;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x27f94){if(_0x27f94=k(_0x27f94),!(_0x27f94 instanceof be))return!0x1;const _0x3e73be=this['_repo']===_0x27f94['_repo'],_0x5d0665=qi(this['_path'],_0x27f94['_path']),_0x54625a=this['_queryIdentifier']===_0x27f94['_queryIdentifier'];return _0x3e73be&&_0x5d0665&&_0x54625a;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x196b4b,_0x26fb0a){if(_0x196b4b['_orderByCalled']===!0x0)throw new Error(_0x26fb0a+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x1d524d){let _0xa56967=null,_0x3d564c=null;if(_0x1d524d['hasStart']()&&(_0xa56967=_0x1d524d['getIndexStartValue']()),_0x1d524d['hasEnd']()&&(_0x3d564c=_0x1d524d['getIndexEndValue']()),_0x1d524d['getIndex']()===ye){const _0x5f4231='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2d662f='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1d524d['hasStart']()){if(_0x1d524d['getIndexStartName']()!==xe)throw new Error(_0x5f4231);if(typeof _0xa56967!='string')throw new Error(_0x2d662f);}if(_0x1d524d['hasEnd']()){if(_0x1d524d['getIndexEndName']()!==Ie)throw new Error(_0x5f4231);if(typeof _0x3d564c!='string')throw new Error(_0x2d662f);}}else{if(_0x1d524d['getIndex']()===R){if(_0xa56967!=null&&!Cn(_0xa56967)||_0x3d564c!=null&&!Cn(_0x3d564c))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1d524d['getIndex']()instanceof Ki||_0x1d524d['getIndex']()===Po,'unknown\x20index\x20type.'),_0xa56967!=null&&typeof _0xa56967=='object'||_0x3d564c!=null&&typeof _0x3d564c=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x4cb74a){if(_0x4cb74a['hasStart']()&&_0x4cb74a['hasEnd']()&&_0x4cb74a['hasLimit']()&&!_0x4cb74a['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x4fe92a,_0x50d2ca){super(_0x4fe92a,_0x50d2ca,new Qi(),!0x1);}get['parent'](){const _0x1dd1ad=To(this['_path']);return _0x1dd1ad===null?null:new Z(this['_repo'],_0x1dd1ad);}get['root'](){let _0x942b47=this;for(;_0x942b47['parent']!==null;)_0x942b47=_0x942b47['parent'];return _0x942b47;}}class rt{constructor(_0x4a2455,_0x1d6ef0,_0x4441c4){this['_node']=_0x4a2455,this['ref']=_0x1d6ef0,this['_index']=_0x4441c4;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x31e16b){const _0x2f6b2c=new C(_0x31e16b),_0x3bdc42=Lt(this['ref'],_0x31e16b);return new rt(this['_node']['getChild'](_0x2f6b2c),_0x3bdc42,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1f56e9){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x990f97,_0x2ee20a)=>_0x1f56e9(new rt(_0x2ee20a,Lt(this['ref'],_0x990f97),R)));}['hasChild'](_0x3f26e6){const _0x49ee55=new C(_0x3f26e6);return!this['_node']['getChild'](_0x49ee55)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x59a719,_0x15c371){return _0x59a719=k(_0x59a719),_0x59a719['_checkNotDeleted']('ref'),_0x15c371!==void 0x0?Lt(_0x59a719['_root'],_0x15c371):_0x59a719['_root'];}function Lt(_0x474318,_0x594cad){return _0x474318=k(_0x474318),y(_0x474318['_path'])===null?ud('child','path',_0x594cad):_s('child','path',_0x594cad),new Z(_0x474318['_repo'],A(_0x474318['_path'],_0x594cad));}function d_(_0x4f545f,_0x3acdac){_0x4f545f=k(_0x4f545f),gs('push',_0x4f545f['_path']),qt('push',_0x3acdac,_0x4f545f['_path'],!0x0);const _0x17d338=oa(_0x4f545f['_repo']),_0x20d708=Od(_0x17d338),_0x44acc0=Lt(_0x4f545f,_0x20d708),_0x3fbc3d=Lt(_0x4f545f,_0x20d708);let _0x3f2eb5;return _0x3acdac!=null?_0x3f2eb5=Ld(_0x3fbc3d,_0x3acdac)['then'](()=>_0x3fbc3d):_0x3f2eb5=Promise['resolve'](_0x3fbc3d),_0x44acc0['then']=_0x3f2eb5['then']['bind'](_0x3f2eb5),_0x44acc0['catch']=_0x3f2eb5['then']['bind'](_0x3f2eb5,void 0x0),_0x44acc0;}function Ld(_0x3e6fe0,_0x1dab07){_0x3e6fe0=k(_0x3e6fe0),gs('set',_0x3e6fe0['_path']),qt('set',_0x1dab07,_0x3e6fe0['_path'],!0x1);const _0x13e793=new Ve();return Ed(_0x3e6fe0['_repo'],_0x3e6fe0['_path'],_0x1dab07,null,_0x13e793['wrapCallback'](()=>{})),_0x13e793['promise'];}function f_(_0x438626,_0x343bcf){hd('update',_0x343bcf,_0x438626['_path']);const _0x33e352=new Ve();return Id(_0x438626['_repo'],_0x438626['_path'],_0x343bcf,_0x33e352['wrapCallback'](()=>{})),_0x33e352['promise'];}function p_(_0x33ea2e){_0x33ea2e=k(_0x33ea2e);const _0x256aa7=new ua(()=>{}),_0x4a5b49=new qn(_0x256aa7);return vd(_0x33ea2e['_repo'],_0x33ea2e,_0x4a5b49)['then'](_0x50066e=>new rt(_0x50066e,new Z(_0x33ea2e['_repo'],_0x33ea2e['_path']),_0x33ea2e['_queryParams']['getIndex']()));}class qn{constructor(_0x1bbeb6){this['callbackContext']=_0x1bbeb6;}['respondsTo'](_0x28b31f){return _0x28b31f==='value';}['createEvent'](_0x4c7a2d,_0x2d756b){const _0x4605cd=_0x2d756b['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x4c7a2d['snapshotNode'],new Z(_0x2d756b['_repo'],_0x2d756b['_path']),_0x4605cd));}['getEventRunner'](_0x189b65){return _0x189b65['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x189b65['error']):()=>this['callbackContext']['onValue'](_0x189b65['snapshot'],null);}['createCancelEvent'](_0x4d2e32,_0x57ea5d){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x4d2e32,_0x57ea5d):null;}['matches'](_0x3c28d4){return _0x3c28d4 instanceof qn?!_0x3c28d4['callbackContext']||!this['callbackContext']?!0x0:_0x3c28d4['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x175ff4,_0x1482e3,_0x1ba79d,_0x22f323,_0x49c83f){const _0x2a44b7=new ua(_0x1ba79d,void 0x0),_0x203dd8=new qn(_0x2a44b7);return Cd(_0x175ff4['_repo'],_0x175ff4,_0x203dd8),()=>Td(_0x175ff4['_repo'],_0x175ff4,_0x203dd8);}function Fd(_0x481488,_0xff44e9,_0x5926b0,_0x573e6a){return xd(_0x481488,'value',_0xff44e9);}class dt{}class pa extends dt{constructor(_0x1679c7,_0x3fe3e8){super(),this['_value']=_0x1679c7,this['_key']=_0x3fe3e8,this['type']='endAt';}['_apply'](_0x23fcfc){qt('endAt',this['_value'],_0x23fcfc['_path'],!0x0);const _0x22f2ef=Kh(_0x23fcfc['_queryParams'],this['_value'],this['_key']);if(fa(_0x22f2ef),Gn(_0x22f2ef),_0x23fcfc['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x23fcfc['_repo'],_0x23fcfc['_path'],_0x22f2ef,_0x23fcfc['_orderByCalled']);}}function __(_0x3dffb4,_0x520bd3){return new pa(_0x3dffb4,_0x520bd3);}class _a extends dt{constructor(_0x13d84b,_0x29080c){super(),this['_value']=_0x13d84b,this['_key']=_0x29080c,this['type']='startAt';}['_apply'](_0x3dd04a){qt('startAt',this['_value'],_0x3dd04a['_path'],!0x0);const _0x59d994=jh(_0x3dd04a['_queryParams'],this['_value'],this['_key']);if(fa(_0x59d994),Gn(_0x59d994),_0x3dd04a['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x3dd04a['_repo'],_0x3dd04a['_path'],_0x59d994,_0x3dd04a['_orderByCalled']);}}function g_(_0x1c880d=null,_0x51f745){return new _a(_0x1c880d,_0x51f745);}class Ud extends dt{constructor(_0x2381a2){super(),this['_limit']=_0x2381a2,this['type']='limitToFirst';}['_apply'](_0x2e99ab){if(_0x2e99ab['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x2e99ab['_repo'],_0x2e99ab['_path'],zh(_0x2e99ab['_queryParams'],this['_limit']),_0x2e99ab['_orderByCalled']);}}function m_(_0x17e188){if(Math['floor'](_0x17e188)!==_0x17e188||_0x17e188<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x17e188);}class Wd extends dt{constructor(_0xa4b8dc){super(),this['_path']=_0xa4b8dc,this['type']='orderByChild';}['_apply'](_0x4a9ac6){da(_0x4a9ac6,'orderByChild');const _0x59c9d8=new C(this['_path']);if(v(_0x59c9d8))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xbdd9d5=new Ki(_0x59c9d8),_0x2797aa=Do(_0x4a9ac6['_queryParams'],_0xbdd9d5);return Gn(_0x2797aa),new be(_0x4a9ac6['_repo'],_0x4a9ac6['_path'],_0x2797aa,!0x0);}}function y_(_0x2d6f4a){if(_0x2d6f4a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2d6f4a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2d6f4a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x2d6f4a),new Wd(_0x2d6f4a);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x4f3012){da(_0x4f3012,'orderByKey');const _0x660817=Do(_0x4f3012['_queryParams'],ye);return Gn(_0x660817),new be(_0x4f3012['_repo'],_0x4f3012['_path'],_0x660817,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x2059cc,_0x11d93a){super(),this['_value']=_0x2059cc,this['_key']=_0x11d93a,this['type']='equalTo';}['_apply'](_0x308149){if(qt('equalTo',this['_value'],_0x308149['_path'],!0x1),_0x308149['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x308149['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x308149));}}function E_(_0x13e268,_0x7eb26d){return new Vd(_0x13e268,_0x7eb26d);}function I_(_0x15f455,..._0x2a2aac){let _0x374a85=k(_0x15f455);for(const _0x35d828 of _0x2a2aac)_0x374a85=_0x35d828['_apply'](_0x374a85);return _0x374a85;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x475b68,_0x38f4e4,_0xcfbe5,_0x3e95e6){const _0x1cba8f=_0x38f4e4['lastIndexOf'](':'),_0x33fc2b=_0x38f4e4['substring'](0x0,_0x1cba8f),_0x925e06=Wt(_0x33fc2b);_0x475b68['repoInfo_']=new _o(_0x38f4e4,_0x925e06,_0x475b68['repoInfo_']['namespace'],_0x475b68['repoInfo_']['webSocketOnly'],_0x475b68['repoInfo_']['nodeAdmin'],_0x475b68['repoInfo_']['persistenceKey'],_0x475b68['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0xcfbe5),_0x3e95e6&&(_0x475b68['authTokenProvider_']=_0x3e95e6);}function qd(_0x48aaa0,_0x38ec91,_0xde1722,_0x543d64,_0x44782b){let _0x571283=_0x543d64||_0x48aaa0['options']['databaseURL'];_0x571283===void 0x0&&(_0x48aaa0['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x48aaa0['options']['projectId']),_0x571283=_0x48aaa0['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x54c6c9=gr(_0x571283,_0x44782b),_0x37f202=_0x54c6c9['repoInfo'],_0x37e70e;typeof process<'u'&&Us&&(_0x37e70e=Us[Hd]),_0x37e70e?(_0x571283='http://'+_0x37e70e+'?ns='+_0x37f202['namespace'],_0x54c6c9=gr(_0x571283,_0x44782b),_0x37f202=_0x54c6c9['repoInfo']):_0x54c6c9['repoInfo']['secure'];const _0x9031=new Jl(_0x48aaa0['name'],_0x48aaa0['options'],_0x38ec91);dd('Invalid\x20Firebase\x20Database\x20URL',_0x54c6c9),v(_0x54c6c9['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x38c12d=jd(_0x37f202,_0x48aaa0,_0x9031,new Ql(_0x48aaa0,_0xde1722));return new Kd(_0x38c12d,_0x48aaa0);}function zd(_0x4aca85,_0x297258){const _0x57a0cc=ki[_0x297258];(!_0x57a0cc||_0x57a0cc[_0x4aca85['key']]!==_0x4aca85)&&oe('Database\x20'+_0x297258+'('+_0x4aca85['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x4aca85),delete _0x57a0cc[_0x4aca85['key']];}function jd(_0x2079e7,_0xe94c22,_0x352584,_0x570703){let _0x831c64=ki[_0xe94c22['name']];_0x831c64||(_0x831c64={},ki[_0xe94c22['name']]=_0x831c64);let _0x561074=_0x831c64[_0x2079e7['toURLString']()];return _0x561074&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x561074=new gd(_0x2079e7,$d,_0x352584,_0x570703),_0x831c64[_0x2079e7['toURLString']()]=_0x561074,_0x561074;}class Kd{constructor(_0x57a6a3,_0x560a2e){this['_repoInternal']=_0x57a6a3,this['app']=_0x560a2e,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x2cb83f){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x2cb83f+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x14fe56=Qr(),_0x5d9630){const _0x51ed66=Ui(_0x14fe56,'database')['getImmediate']({'identifier':_0x5d9630});if(!_0x51ed66['_instanceStarted']){const _0x4818f5=ac('database');_0x4818f5&&Yd(_0x51ed66,..._0x4818f5);}return _0x51ed66;}function Yd(_0x1937b5,_0x4bfcc9,_0x31b1b9,_0x18ac9e={}){_0x1937b5=k(_0x1937b5),_0x1937b5['_checkNotDeleted']('useEmulator');const _0x48941a=_0x4bfcc9+':'+_0x31b1b9,_0x2799b4=_0x1937b5['_repoInternal'];if(_0x1937b5['_instanceStarted']){if(_0x48941a===_0x1937b5['_repoInternal']['repoInfo_']['host']&&De(_0x18ac9e,_0x2799b4['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4fde97;if(_0x2799b4['repoInfo_']['nodeAdmin'])_0x18ac9e['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4fde97=new tn(tn['OWNER']);else{if(_0x18ac9e['mockUserToken']){const _0x18a786=typeof _0x18ac9e['mockUserToken']=='string'?_0x18ac9e['mockUserToken']:cc(_0x18ac9e['mockUserToken'],_0x1937b5['app']['options']['projectId']);_0x4fde97=new tn(_0x18a786);}}Wt(_0x4bfcc9)&&jr(_0x4bfcc9),Gd(_0x2799b4,_0x48941a,_0x18ac9e,_0x4fde97);}function C_(_0x5bb988){_0x5bb988=k(_0x5bb988),_0x5bb988['_checkNotDeleted']('goOffline'),aa(_0x5bb988['_repo']);}function T_(_0x952940){_0x952940=k(_0x952940),_0x952940['_checkNotDeleted']('goOnline'),Sd(_0x952940['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x367cc1){Ll(ct),et(new Me('database',(_0x300928,{instanceIdentifier:_0x1bd84f})=>{const _0x385dd1=_0x300928['getProvider']('app')['getImmediate'](),_0x99f45f=_0x300928['getProvider']('auth-internal'),_0x36284e=_0x300928['getProvider']('app-check-internal');return qd(_0x385dd1,_0x99f45f,_0x36284e,_0x1bd84f);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x367cc1),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x5d022e,_0x18dea7){this['committed']=_0x5d022e,this['snapshot']=_0x18dea7;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x3a4586,_0x3c923b,_0x3180d7){if(_0x3a4586=k(_0x3a4586),gs('Reference.transaction',_0x3a4586['_path']),_0x3a4586['key']==='.length'||_0x3a4586['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3a4586['key']+'\x20is\x20a\x20read-only\x20object.';const _0x418b75=!0x0,_0x90edb=new Ve(),_0x48e6ef=(_0x42f21a,_0x72937,_0xeb9b06)=>{let _0x40617f=null;_0x42f21a?_0x90edb['reject'](_0x42f21a):(_0x40617f=new rt(_0xeb9b06,new Z(_0x3a4586['_repo'],_0x3a4586['_path']),R),_0x90edb['resolve'](new Xd(_0x72937,_0x40617f)));},_0x5ecc8d=Fd(_0x3a4586,()=>{});return bd(_0x3a4586['_repo'],_0x3a4586['_path'],_0x3c923b,_0x48e6ef,_0x5ecc8d,_0x418b75),_0x90edb['promise'];}ie['prototype']['simpleListen']=function(_0x90bee5,_0x52fc33){this['sendRequest']('q',{'p':_0x90bee5},_0x52fc33);},ie['prototype']['echo']=function(_0x38170c,_0x48fbf6){this['sendRequest']('echo',{'d':_0x38170c},_0x48fbf6);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x1d17ad,..._0xae56ec){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x1d17ad,..._0xae56ec);}function nn(_0x173ff3,..._0x328ca7){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x173ff3,..._0x328ca7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x176670,..._0x12aabe){throw Es(_0x176670,..._0x12aabe);}function J(_0x52348e,..._0x3b7fe3){return Es(_0x52348e,..._0x3b7fe3);}function ya(_0x13350d,_0x43c0cc,_0x2bf09d){const _0x4b8150={...Zd(),[_0x43c0cc]:_0x2bf09d};return new Ut('auth','Firebase',_0x4b8150)['create'](_0x43c0cc,{'appName':_0x13350d['name']});}function se(_0x28f58f){return ya(_0x28f58f,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x34a69c,..._0xf83f4e){if(typeof _0x34a69c!='string'){const _0x5d21ad=_0xf83f4e[0x0],_0xd430c5=[..._0xf83f4e['slice'](0x1)];return _0xd430c5[0x0]&&(_0xd430c5[0x0]['appName']=_0x34a69c['name']),_0x34a69c['_errorFactory']['create'](_0x5d21ad,..._0xd430c5);}return ma['create'](_0x34a69c,..._0xf83f4e);}function m(_0x224780,_0x1e1a6c,..._0x27def6){if(!_0x224780)throw Es(_0x1e1a6c,..._0x27def6);}function te(_0x1c5c8c){const _0x531b7a='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1c5c8c;throw nn(_0x531b7a),new Error(_0x531b7a);}function ae(_0x59ec6f,_0x42474a){_0x59ec6f||te(_0x42474a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x1c9a28;return typeof self<'u'&&((_0x1c9a28=self['location'])==null?void 0x0:_0x1c9a28['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x268b71;return typeof self<'u'&&((_0x268b71=self['location'])==null?void 0x0:_0x268b71['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x302962=navigator;return _0x302962['languages']&&_0x302962['languages'][0x0]||_0x302962['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x468bc2,_0x4d7dfc){this['shortDelay']=_0x468bc2,this['longDelay']=_0x4d7dfc,ae(_0x4d7dfc>_0x468bc2,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x212839,_0x225191){ae(_0x212839['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x47809f}=_0x212839['emulator'];return _0x225191?''+_0x47809f+(_0x225191['startsWith']('/')?_0x225191['slice'](0x1):_0x225191):_0x47809f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0xfb31b0,_0x48064d,_0xc57bea){this['fetchImpl']=_0xfb31b0,_0x48064d&&(this['headersImpl']=_0x48064d),_0xc57bea&&(this['responseImpl']=_0xc57bea);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x471fd6,_0x822f71){return _0x471fd6['tenantId']&&!_0x822f71['tenantId']?{..._0x822f71,'tenantId':_0x471fd6['tenantId']}:_0x822f71;}async function Ae(_0x9e706d,_0x739730,_0x49742f,_0x559853,_0x9976de={}){return Ea(_0x9e706d,_0x9976de,async()=>{let _0x1b3cd4={},_0x4761bc={};_0x559853&&(_0x739730==='GET'?_0x4761bc=_0x559853:_0x1b3cd4={'body':JSON['stringify'](_0x559853)});const _0x32cae4=at({..._0x4761bc,'key':_0x9e706d['config']['apiKey']})['slice'](0x1),_0x1e21ca=await _0x9e706d['_getAdditionalHeaders']();_0x1e21ca['Content-Type']='application/json',_0x9e706d['languageCode']&&(_0x1e21ca['X-Firebase-Locale']=_0x9e706d['languageCode']);const _0x19b49f={'method':_0x739730,'headers':_0x1e21ca,..._0x1b3cd4};return lc()||(_0x19b49f['referrerPolicy']='strict-origin-when-cross-origin'),_0x9e706d['emulatorConfig']&&Wt(_0x9e706d['emulatorConfig']['host'])&&(_0x19b49f['credentials']='include'),va['fetch']()(await Ia(_0x9e706d,_0x9e706d['config']['apiHost'],_0x49742f,_0x32cae4),_0x19b49f);});}async function Ea(_0x4bced2,_0x3cf8c9,_0x3f3030){_0x4bced2['_canInitEmulator']=!0x1;const _0x3d2ad2={...rf,..._0x3cf8c9};try{const _0x3a3cd2=new lf(_0x4bced2),_0x58f6ba=await Promise['race']([_0x3f3030(),_0x3a3cd2['promise']]);_0x3a3cd2['clearNetworkTimeout']();const _0x956ff4=await _0x58f6ba['json']();if('needConfirmation'in _0x956ff4)throw en(_0x4bced2,'account-exists-with-different-credential',_0x956ff4);if(_0x58f6ba['ok']&&!('errorMessage'in _0x956ff4))return _0x956ff4;{const _0x85751c=_0x58f6ba['ok']?_0x956ff4['errorMessage']:_0x956ff4['error']['message'],[_0x30ef83,_0x80bb7d]=_0x85751c['split']('\x20:\x20');if(_0x30ef83==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x4bced2,'credential-already-in-use',_0x956ff4);if(_0x30ef83==='EMAIL_EXISTS')throw en(_0x4bced2,'email-already-in-use',_0x956ff4);if(_0x30ef83==='USER_DISABLED')throw en(_0x4bced2,'user-disabled',_0x956ff4);const _0x38226f=_0x3d2ad2[_0x30ef83]||_0x30ef83['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x80bb7d)throw ya(_0x4bced2,_0x38226f,_0x80bb7d);K(_0x4bced2,_0x38226f);}}catch(_0x4f87f2){if(_0x4f87f2 instanceof Se)throw _0x4f87f2;K(_0x4bced2,'network-request-failed',{'message':String(_0x4f87f2)});}}async function Yt(_0x1a1edd,_0x1312f2,_0x3a15cc,_0x22ec38,_0x39f1f5={}){const _0x4c58e2=await Ae(_0x1a1edd,_0x1312f2,_0x3a15cc,_0x22ec38,_0x39f1f5);return'mfaPendingCredential'in _0x4c58e2&&K(_0x1a1edd,'multi-factor-auth-required',{'_serverResponse':_0x4c58e2}),_0x4c58e2;}async function Ia(_0x45ea88,_0x3c5297,_0x2928a2,_0x132b7f){const _0x382b74=''+_0x3c5297+_0x2928a2+'?'+_0x132b7f,_0x389088=_0x45ea88,_0x8ddab=_0x389088['config']['emulator']?Is(_0x45ea88['config'],_0x382b74):_0x45ea88['config']['apiScheme']+'://'+_0x382b74;return of['includes'](_0x2928a2)&&(await _0x389088['_persistenceManagerAvailable'],_0x389088['_getPersistenceType']()==='COOKIE')?_0x389088['_getPersistence']()['_getFinalTarget'](_0x8ddab)['toString']():_0x8ddab;}function cf(_0x56f7ca){switch(_0x56f7ca){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3d335c){this['auth']=_0x3d335c,this['timer']=null,this['promise']=new Promise((_0x4ee3f9,_0x2beb06)=>{this['timer']=setTimeout(()=>_0x2beb06(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x263c0d,_0x138c09,_0x3e2121){const _0x4e924c={'appName':_0x263c0d['name']};_0x3e2121['email']&&(_0x4e924c['email']=_0x3e2121['email']),_0x3e2121['phoneNumber']&&(_0x4e924c['phoneNumber']=_0x3e2121['phoneNumber']);const _0x45d8c5=J(_0x263c0d,_0x138c09,_0x4e924c);return _0x45d8c5['customData']['_tokenResponse']=_0x3e2121,_0x45d8c5;}function vr(_0x294e50){return _0x294e50!==void 0x0&&_0x294e50['enterprise']!==void 0x0;}class hf{constructor(_0x59d5ed){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x59d5ed['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x59d5ed['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x59d5ed['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2fcac4){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x258c04 of this['recaptchaEnforcementState'])if(_0x258c04['provider']&&_0x258c04['provider']===_0x2fcac4)return cf(_0x258c04['enforcementState']);return null;}['isProviderEnabled'](_0x1d10b2){return this['getProviderEnforcementState'](_0x1d10b2)==='ENFORCE'||this['getProviderEnforcementState'](_0x1d10b2)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x49b6e9,_0x361126){return Ae(_0x49b6e9,'GET','/v2/recaptchaConfig',Re(_0x49b6e9,_0x361126));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x4be985,_0x2308a0){return Ae(_0x4be985,'POST','/v1/accounts:delete',_0x2308a0);}async function Sn(_0x492f0e,_0x3ae364){return Ae(_0x492f0e,'POST','/v1/accounts:lookup',_0x3ae364);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x469e3e){if(_0x469e3e)try{const _0x314f00=new Date(Number(_0x469e3e));if(!isNaN(_0x314f00['getTime']()))return _0x314f00['toUTCString']();}catch{}}async function ff(_0x1ca0e8,_0x30b4f8=!0x1){const _0x2ddd33=k(_0x1ca0e8),_0xb2d957=await _0x2ddd33['getIdToken'](_0x30b4f8),_0x348789=ws(_0xb2d957);m(_0x348789&&_0x348789['exp']&&_0x348789['auth_time']&&_0x348789['iat'],_0x2ddd33['auth'],'internal-error');const _0x2fae33=typeof _0x348789['firebase']=='object'?_0x348789['firebase']:void 0x0,_0x188217=_0x2fae33==null?void 0x0:_0x2fae33['sign_in_provider'];return{'claims':_0x348789,'token':_0xb2d957,'authTime':St(ci(_0x348789['auth_time'])),'issuedAtTime':St(ci(_0x348789['iat'])),'expirationTime':St(ci(_0x348789['exp'])),'signInProvider':_0x188217||null,'signInSecondFactor':(_0x2fae33==null?void 0x0:_0x2fae33['sign_in_second_factor'])||null};}function ci(_0x2ba619){return Number(_0x2ba619)*0x3e8;}function ws(_0x1c03c7){const [_0x3fa217,_0x182c79,_0x5d2482]=_0x1c03c7['split']('.');if(_0x3fa217===void 0x0||_0x182c79===void 0x0||_0x5d2482===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x1c72f6=cn(_0x182c79);return _0x1c72f6?JSON['parse'](_0x1c72f6):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4cc0cb){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4cc0cb==null?void 0x0:_0x4cc0cb['toString']()),null;}}function Er(_0x1ed09a){const _0x12c87b=ws(_0x1ed09a);return m(_0x12c87b,'internal-error'),m(typeof _0x12c87b['exp']<'u','internal-error'),m(typeof _0x12c87b['iat']<'u','internal-error'),Number(_0x12c87b['exp'])-Number(_0x12c87b['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x147de1,_0x40ed29,_0x2caa9a=!0x1){if(_0x2caa9a)return _0x40ed29;try{return await _0x40ed29;}catch(_0x42b67a){throw _0x42b67a instanceof Se&&pf(_0x42b67a)&&_0x147de1['auth']['currentUser']===_0x147de1&&await _0x147de1['auth']['signOut'](),_0x42b67a;}}function pf({code:_0x3cc42b}){return _0x3cc42b==='auth/user-disabled'||_0x3cc42b==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x303a78){this['user']=_0x303a78,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x3dd060){if(_0x3dd060){const _0x3e7093=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x3e7093;}else{this['errorBackoff']=0x7530;const _0x141e5f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x141e5f);}}['schedule'](_0x539fde=!0x1){if(!this['isRunning'])return;const _0x47f730=this['getInterval'](_0x539fde);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x47f730);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5eea98){(_0x5eea98==null?void 0x0:_0x5eea98['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x2c0d2e,_0x528b55){this['createdAt']=_0x2c0d2e,this['lastLoginAt']=_0x528b55,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x6d0218){this['createdAt']=_0x6d0218['createdAt'],this['lastLoginAt']=_0x6d0218['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x2b76f8){var _0x6f123c;const _0x150cc5=_0x2b76f8['auth'],_0x9ba1ca=await _0x2b76f8['getIdToken'](),_0x4b5b43=await xt(_0x2b76f8,Sn(_0x150cc5,{'idToken':_0x9ba1ca}));m(_0x4b5b43==null?void 0x0:_0x4b5b43['users']['length'],_0x150cc5,'internal-error');const _0x3aa6d3=_0x4b5b43['users'][0x0];_0x2b76f8['_notifyReloadListener'](_0x3aa6d3);const _0x110dd2=(_0x6f123c=_0x3aa6d3['providerUserInfo'])!=null&&_0x6f123c['length']?wa(_0x3aa6d3['providerUserInfo']):[],_0x2540e8=mf(_0x2b76f8['providerData'],_0x110dd2),_0x25dbc=_0x2b76f8['isAnonymous'],_0x445a7d=!(_0x2b76f8['email']&&_0x3aa6d3['passwordHash'])&&!(_0x2540e8!=null&&_0x2540e8['length']),_0x3ec3a2=_0x25dbc?_0x445a7d:!0x1,_0x6c3cc3={'uid':_0x3aa6d3['localId'],'displayName':_0x3aa6d3['displayName']||null,'photoURL':_0x3aa6d3['photoUrl']||null,'email':_0x3aa6d3['email']||null,'emailVerified':_0x3aa6d3['emailVerified']||!0x1,'phoneNumber':_0x3aa6d3['phoneNumber']||null,'tenantId':_0x3aa6d3['tenantId']||null,'providerData':_0x2540e8,'metadata':new Pi(_0x3aa6d3['createdAt'],_0x3aa6d3['lastLoginAt']),'isAnonymous':_0x3ec3a2};Object['assign'](_0x2b76f8,_0x6c3cc3);}async function gf(_0x34a873){const _0x3ae3ef=k(_0x34a873);await bn(_0x3ae3ef),await _0x3ae3ef['auth']['_persistUserIfCurrent'](_0x3ae3ef),_0x3ae3ef['auth']['_notifyListenersIfCurrent'](_0x3ae3ef);}function mf(_0x1552b5,_0x23608b){return[..._0x1552b5['filter'](_0x425049=>!_0x23608b['some'](_0x57e664=>_0x57e664['providerId']===_0x425049['providerId'])),..._0x23608b];}function wa(_0x4d659a){return _0x4d659a['map'](({providerId:_0xd89c22,..._0x8ff4c3})=>({'providerId':_0xd89c22,'uid':_0x8ff4c3['rawId']||'','displayName':_0x8ff4c3['displayName']||null,'email':_0x8ff4c3['email']||null,'phoneNumber':_0x8ff4c3['phoneNumber']||null,'photoURL':_0x8ff4c3['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x495f61,_0x3b5e52){const _0x352ef7=await Ea(_0x495f61,{},async()=>{const _0x3fb9e4=at({'grant_type':'refresh_token','refresh_token':_0x3b5e52})['slice'](0x1),{tokenApiHost:_0xcca158,apiKey:_0x3675e2}=_0x495f61['config'],_0x1cd1b9=await Ia(_0x495f61,_0xcca158,'/v1/token','key='+_0x3675e2),_0x1d372f=await _0x495f61['_getAdditionalHeaders']();_0x1d372f['Content-Type']='application/x-www-form-urlencoded';const _0x42ff1e={'method':'POST','headers':_0x1d372f,'body':_0x3fb9e4};return _0x495f61['emulatorConfig']&&Wt(_0x495f61['emulatorConfig']['host'])&&(_0x42ff1e['credentials']='include'),va['fetch']()(_0x1cd1b9,_0x42ff1e);});return{'accessToken':_0x352ef7['access_token'],'expiresIn':_0x352ef7['expires_in'],'refreshToken':_0x352ef7['refresh_token']};}async function vf(_0xf05829,_0x485637){return Ae(_0xf05829,'POST','/v2/accounts:revokeToken',Re(_0xf05829,_0x485637));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xa8c37d){m(_0xa8c37d['idToken'],'internal-error'),m(typeof _0xa8c37d['idToken']<'u','internal-error'),m(typeof _0xa8c37d['refreshToken']<'u','internal-error');const _0x7fda3e='expiresIn'in _0xa8c37d&&typeof _0xa8c37d['expiresIn']<'u'?Number(_0xa8c37d['expiresIn']):Er(_0xa8c37d['idToken']);this['updateTokensAndExpiration'](_0xa8c37d['idToken'],_0xa8c37d['refreshToken'],_0x7fda3e);}['updateFromIdToken'](_0x161fb5){m(_0x161fb5['length']!==0x0,'internal-error');const _0x54ad05=Er(_0x161fb5);this['updateTokensAndExpiration'](_0x161fb5,null,_0x54ad05);}async['getToken'](_0x4af205,_0x1c51c6=!0x1){return!_0x1c51c6&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4af205,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4af205,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x40a90f,_0x4f33ea){const {accessToken:_0x3fc85e,refreshToken:_0x2e7f67,expiresIn:_0x347d38}=await yf(_0x40a90f,_0x4f33ea);this['updateTokensAndExpiration'](_0x3fc85e,_0x2e7f67,Number(_0x347d38));}['updateTokensAndExpiration'](_0x2b9e17,_0x1ab6f3,_0x336123){this['refreshToken']=_0x1ab6f3||null,this['accessToken']=_0x2b9e17||null,this['expirationTime']=Date['now']()+_0x336123*0x3e8;}static['fromJSON'](_0x44c435,_0x4f77fb){const {refreshToken:_0x33c307,accessToken:_0x102c35,expirationTime:_0x27b752}=_0x4f77fb,_0x2f2a4c=new Je();return _0x33c307&&(m(typeof _0x33c307=='string','internal-error',{'appName':_0x44c435}),_0x2f2a4c['refreshToken']=_0x33c307),_0x102c35&&(m(typeof _0x102c35=='string','internal-error',{'appName':_0x44c435}),_0x2f2a4c['accessToken']=_0x102c35),_0x27b752&&(m(typeof _0x27b752=='number','internal-error',{'appName':_0x44c435}),_0x2f2a4c['expirationTime']=_0x27b752),_0x2f2a4c;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3afbb9){this['accessToken']=_0x3afbb9['accessToken'],this['refreshToken']=_0x3afbb9['refreshToken'],this['expirationTime']=_0x3afbb9['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x1fb545,_0x5499ca){m(typeof _0x1fb545=='string'||typeof _0x1fb545>'u','internal-error',{'appName':_0x5499ca});}class z{constructor({uid:_0x28d5bc,auth:_0x487d24,stsTokenManager:_0x21c3d7,..._0x443553}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x28d5bc,this['auth']=_0x487d24,this['stsTokenManager']=_0x21c3d7,this['accessToken']=_0x21c3d7['accessToken'],this['displayName']=_0x443553['displayName']||null,this['email']=_0x443553['email']||null,this['emailVerified']=_0x443553['emailVerified']||!0x1,this['phoneNumber']=_0x443553['phoneNumber']||null,this['photoURL']=_0x443553['photoURL']||null,this['isAnonymous']=_0x443553['isAnonymous']||!0x1,this['tenantId']=_0x443553['tenantId']||null,this['providerData']=_0x443553['providerData']?[..._0x443553['providerData']]:[],this['metadata']=new Pi(_0x443553['createdAt']||void 0x0,_0x443553['lastLoginAt']||void 0x0);}async['getIdToken'](_0x14815f){const _0x21192f=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x14815f));return m(_0x21192f,this['auth'],'internal-error'),this['accessToken']!==_0x21192f&&(this['accessToken']=_0x21192f,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x21192f;}['getIdTokenResult'](_0x2c06ab){return ff(this,_0x2c06ab);}['reload'](){return gf(this);}['_assign'](_0x1fa45e){this!==_0x1fa45e&&(m(this['uid']===_0x1fa45e['uid'],this['auth'],'internal-error'),this['displayName']=_0x1fa45e['displayName'],this['photoURL']=_0x1fa45e['photoURL'],this['email']=_0x1fa45e['email'],this['emailVerified']=_0x1fa45e['emailVerified'],this['phoneNumber']=_0x1fa45e['phoneNumber'],this['isAnonymous']=_0x1fa45e['isAnonymous'],this['tenantId']=_0x1fa45e['tenantId'],this['providerData']=_0x1fa45e['providerData']['map'](_0x5f5bbd=>({..._0x5f5bbd})),this['metadata']['_copy'](_0x1fa45e['metadata']),this['stsTokenManager']['_assign'](_0x1fa45e['stsTokenManager']));}['_clone'](_0x5bd284){const _0x2f988e=new z({...this,'auth':_0x5bd284,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x2f988e['metadata']['_copy'](this['metadata']),_0x2f988e;}['_onReload'](_0x44b733){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x44b733,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4c1b1b){this['reloadListener']?this['reloadListener'](_0x4c1b1b):this['reloadUserInfo']=_0x4c1b1b;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4fed32,_0x4b27fe=!0x1){let _0x3e4aa8=!0x1;_0x4fed32['idToken']&&_0x4fed32['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4fed32),_0x3e4aa8=!0x0),_0x4b27fe&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3e4aa8&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x307a85=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x307a85})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0xe50a03=>({..._0xe50a03})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x2fcb3e,_0x2b87be){const _0x50b6b4=_0x2b87be['displayName']??void 0x0,_0x2fac35=_0x2b87be['email']??void 0x0,_0x411a63=_0x2b87be['phoneNumber']??void 0x0,_0x4d0dc7=_0x2b87be['photoURL']??void 0x0,_0x44bd21=_0x2b87be['tenantId']??void 0x0,_0x108839=_0x2b87be['_redirectEventId']??void 0x0,_0x18ea23=_0x2b87be['createdAt']??void 0x0,_0x469bb2=_0x2b87be['lastLoginAt']??void 0x0,{uid:_0x3a97d6,emailVerified:_0x149a87,isAnonymous:_0x10b078,providerData:_0x1eeeec,stsTokenManager:_0x24f59b}=_0x2b87be;m(_0x3a97d6&&_0x24f59b,_0x2fcb3e,'internal-error');const _0x5d60de=Je['fromJSON'](this['name'],_0x24f59b);m(typeof _0x3a97d6=='string',_0x2fcb3e,'internal-error'),ce(_0x50b6b4,_0x2fcb3e['name']),ce(_0x2fac35,_0x2fcb3e['name']),m(typeof _0x149a87=='boolean',_0x2fcb3e,'internal-error'),m(typeof _0x10b078=='boolean',_0x2fcb3e,'internal-error'),ce(_0x411a63,_0x2fcb3e['name']),ce(_0x4d0dc7,_0x2fcb3e['name']),ce(_0x44bd21,_0x2fcb3e['name']),ce(_0x108839,_0x2fcb3e['name']),ce(_0x18ea23,_0x2fcb3e['name']),ce(_0x469bb2,_0x2fcb3e['name']);const _0x1df6c0=new z({'uid':_0x3a97d6,'auth':_0x2fcb3e,'email':_0x2fac35,'emailVerified':_0x149a87,'displayName':_0x50b6b4,'isAnonymous':_0x10b078,'photoURL':_0x4d0dc7,'phoneNumber':_0x411a63,'tenantId':_0x44bd21,'stsTokenManager':_0x5d60de,'createdAt':_0x18ea23,'lastLoginAt':_0x469bb2});return _0x1eeeec&&Array['isArray'](_0x1eeeec)&&(_0x1df6c0['providerData']=_0x1eeeec['map'](_0x1155f0=>({..._0x1155f0}))),_0x108839&&(_0x1df6c0['_redirectEventId']=_0x108839),_0x1df6c0;}static async['_fromIdTokenResponse'](_0x582440,_0x5264c2,_0x4bd8e7=!0x1){const _0x279273=new Je();_0x279273['updateFromServerResponse'](_0x5264c2);const _0x385e27=new z({'uid':_0x5264c2['localId'],'auth':_0x582440,'stsTokenManager':_0x279273,'isAnonymous':_0x4bd8e7});return await bn(_0x385e27),_0x385e27;}static async['_fromGetAccountInfoResponse'](_0x400720,_0x2654b3,_0x2070b7){const _0x18c68b=_0x2654b3['users'][0x0];m(_0x18c68b['localId']!==void 0x0,'internal-error');const _0x5cb868=_0x18c68b['providerUserInfo']!==void 0x0?wa(_0x18c68b['providerUserInfo']):[],_0x309bb7=!(_0x18c68b['email']&&_0x18c68b['passwordHash'])&&!(_0x5cb868!=null&&_0x5cb868['length']),_0x753d57=new Je();_0x753d57['updateFromIdToken'](_0x2070b7);const _0x548479=new z({'uid':_0x18c68b['localId'],'auth':_0x400720,'stsTokenManager':_0x753d57,'isAnonymous':_0x309bb7}),_0x2a704b={'uid':_0x18c68b['localId'],'displayName':_0x18c68b['displayName']||null,'photoURL':_0x18c68b['photoUrl']||null,'email':_0x18c68b['email']||null,'emailVerified':_0x18c68b['emailVerified']||!0x1,'phoneNumber':_0x18c68b['phoneNumber']||null,'tenantId':_0x18c68b['tenantId']||null,'providerData':_0x5cb868,'metadata':new Pi(_0x18c68b['createdAt'],_0x18c68b['lastLoginAt']),'isAnonymous':!(_0x18c68b['email']&&_0x18c68b['passwordHash'])&&!(_0x5cb868!=null&&_0x5cb868['length'])};return Object['assign'](_0x548479,_0x2a704b),_0x548479;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x1fd8c4){ae(_0x1fd8c4 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x72541=Ir['get'](_0x1fd8c4);return _0x72541?(ae(_0x72541 instanceof _0x1fd8c4,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x72541):(_0x72541=new _0x1fd8c4(),Ir['set'](_0x1fd8c4,_0x72541),_0x72541);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x493de0,_0x17edf0){this['storage'][_0x493de0]=_0x17edf0;}async['_get'](_0x291204){const _0x29147b=this['storage'][_0x291204];return _0x29147b===void 0x0?null:_0x29147b;}async['_remove'](_0x2c319e){delete this['storage'][_0x2c319e];}['_addListener'](_0x3b6cad,_0x285ed3){}['_removeListener'](_0xb936e1,_0x45d41c){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x147c9b,_0x502917,_0x4ed08c){return'firebase:'+_0x147c9b+':'+_0x502917+':'+_0x4ed08c;}class Xe{constructor(_0xc594fa,_0x2cdf20,_0x2404fe){this['persistence']=_0xc594fa,this['auth']=_0x2cdf20,this['userKey']=_0x2404fe;const {config:_0x3ebf52,name:_0x58cc6a}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x3ebf52['apiKey'],_0x58cc6a),this['fullPersistenceKey']=sn('persistence',_0x3ebf52['apiKey'],_0x58cc6a),this['boundEventHandler']=_0x2cdf20['_onStorageEvent']['bind'](_0x2cdf20),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1ecaaf){return this['persistence']['_set'](this['fullUserKey'],_0x1ecaaf['toJSON']());}async['getCurrentUser'](){const _0x16245a=await this['persistence']['_get'](this['fullUserKey']);if(!_0x16245a)return null;if(typeof _0x16245a=='string'){const _0x3879a0=await Sn(this['auth'],{'idToken':_0x16245a})['catch'](()=>{});return _0x3879a0?z['_fromGetAccountInfoResponse'](this['auth'],_0x3879a0,_0x16245a):null;}return z['_fromJSON'](this['auth'],_0x16245a);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1432f8){if(this['persistence']===_0x1432f8)return;const _0x2d0f60=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1432f8,_0x2d0f60)return this['setCurrentUser'](_0x2d0f60);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x274771,_0x4e368e,_0x1051b8='authUser'){if(!_0x4e368e['length'])return new Xe(ne(wr),_0x274771,_0x1051b8);const _0x19f6a3=(await Promise['all'](_0x4e368e['map'](async _0x42e88c=>{if(await _0x42e88c['_isAvailable']())return _0x42e88c;})))['filter'](_0x48d2ae=>_0x48d2ae);let _0x486156=_0x19f6a3[0x0]||ne(wr);const _0x30c3f3=sn(_0x1051b8,_0x274771['config']['apiKey'],_0x274771['name']);let _0x1c584c=null;for(const _0x1322f9 of _0x4e368e)try{const _0x4bd38b=await _0x1322f9['_get'](_0x30c3f3);if(_0x4bd38b){let _0x265f4a;if(typeof _0x4bd38b=='string'){const _0x25b0b0=await Sn(_0x274771,{'idToken':_0x4bd38b})['catch'](()=>{});if(!_0x25b0b0)break;_0x265f4a=await z['_fromGetAccountInfoResponse'](_0x274771,_0x25b0b0,_0x4bd38b);}else _0x265f4a=z['_fromJSON'](_0x274771,_0x4bd38b);_0x1322f9!==_0x486156&&(_0x1c584c=_0x265f4a),_0x486156=_0x1322f9;break;}}catch{}const _0x216541=_0x19f6a3['filter'](_0x2a0507=>_0x2a0507['_shouldAllowMigration']);return!_0x486156['_shouldAllowMigration']||!_0x216541['length']?new Xe(_0x486156,_0x274771,_0x1051b8):(_0x486156=_0x216541[0x0],_0x1c584c&&await _0x486156['_set'](_0x30c3f3,_0x1c584c['toJSON']()),await Promise['all'](_0x4e368e['map'](async _0x4ea548=>{if(_0x4ea548!==_0x486156)try{await _0x4ea548['_remove'](_0x30c3f3);}catch{}})),new Xe(_0x486156,_0x274771,_0x1051b8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x3f5b2a){const _0x399142=_0x3f5b2a['toLowerCase']();if(_0x399142['includes']('opera/')||_0x399142['includes']('opr/')||_0x399142['includes']('opios/'))return'Opera';if(Ra(_0x399142))return'IEMobile';if(_0x399142['includes']('msie')||_0x399142['includes']('trident/'))return'IE';if(_0x399142['includes']('edge/'))return'Edge';if(Ta(_0x399142))return'Firefox';if(_0x399142['includes']('silk/'))return'Silk';if(ka(_0x399142))return'Blackberry';if(Na(_0x399142))return'Webos';if(Sa(_0x399142))return'Safari';if((_0x399142['includes']('chrome/')||ba(_0x399142))&&!_0x399142['includes']('edge/'))return'Chrome';if(Aa(_0x399142))return'Android';{const _0x19a8be=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x598e8c=_0x3f5b2a['match'](_0x19a8be);if((_0x598e8c==null?void 0x0:_0x598e8c['length'])===0x2)return _0x598e8c[0x1];}return'Other';}function Ta(_0x31b2d5=W()){return/firefox\//i['test'](_0x31b2d5);}function Sa(_0x22434e=W()){const _0x31627b=_0x22434e['toLowerCase']();return _0x31627b['includes']('safari/')&&!_0x31627b['includes']('chrome/')&&!_0x31627b['includes']('crios/')&&!_0x31627b['includes']('android');}function ba(_0x187012=W()){return/crios\//i['test'](_0x187012);}function Ra(_0xdf214b=W()){return/iemobile/i['test'](_0xdf214b);}function Aa(_0x115ade=W()){return/android/i['test'](_0x115ade);}function ka(_0x14a90d=W()){return/blackberry/i['test'](_0x14a90d);}function Na(_0x2db99f=W()){return/webos/i['test'](_0x2db99f);}function Cs(_0x37e699=W()){return/iphone|ipad|ipod/i['test'](_0x37e699)||/macintosh/i['test'](_0x37e699)&&/mobile/i['test'](_0x37e699);}function Ef(_0x2cb242=W()){var _0x1647bb;return Cs(_0x2cb242)&&!!((_0x1647bb=window['navigator'])!=null&&_0x1647bb['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x5183e2=W()){return Cs(_0x5183e2)||Aa(_0x5183e2)||Na(_0x5183e2)||ka(_0x5183e2)||/windows phone/i['test'](_0x5183e2)||Ra(_0x5183e2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x5436ae,_0x31942a=[]){let _0x2225ef;switch(_0x5436ae){case'Browser':_0x2225ef=Cr(W());break;case'Worker':_0x2225ef=Cr(W())+'-'+_0x5436ae;break;default:_0x2225ef=_0x5436ae;}const _0xf9d3e7=_0x31942a['length']?_0x31942a['join'](','):'FirebaseCore-web';return _0x2225ef+'/JsCore/'+ct+'/'+_0xf9d3e7;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x462847){this['auth']=_0x462847,this['queue']=[];}['pushCallback'](_0x3a620a,_0x4f6e7b){const _0x21926c=_0x53eee6=>new Promise((_0x1f87de,_0x4ce3c6)=>{try{const _0x4ae263=_0x3a620a(_0x53eee6);_0x1f87de(_0x4ae263);}catch(_0x5799c3){_0x4ce3c6(_0x5799c3);}});_0x21926c['onAbort']=_0x4f6e7b,this['queue']['push'](_0x21926c);const _0xb87c75=this['queue']['length']-0x1;return()=>{this['queue'][_0xb87c75]=()=>Promise['resolve']();};}async['runMiddleware'](_0x344ce1){if(this['auth']['currentUser']===_0x344ce1)return;const _0x52c87a=[];try{for(const _0x138bd9 of this['queue'])await _0x138bd9(_0x344ce1),_0x138bd9['onAbort']&&_0x52c87a['push'](_0x138bd9['onAbort']);}catch(_0xe34baa){_0x52c87a['reverse']();for(const _0x5a07ff of _0x52c87a)try{_0x5a07ff();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xe34baa==null?void 0x0:_0xe34baa['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x4c2bf2,_0x33f227={}){return Ae(_0x4c2bf2,'GET','/v2/passwordPolicy',Re(_0x4c2bf2,_0x33f227));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x2b9dd7){var _0x52e2b9;const _0x106ed8=_0x2b9dd7['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x106ed8['minPasswordLength']??Tf,_0x106ed8['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x106ed8['maxPasswordLength']),_0x106ed8['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x106ed8['containsLowercaseCharacter']),_0x106ed8['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x106ed8['containsUppercaseCharacter']),_0x106ed8['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x106ed8['containsNumericCharacter']),_0x106ed8['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x106ed8['containsNonAlphanumericCharacter']),this['enforcementState']=_0x2b9dd7['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x52e2b9=_0x2b9dd7['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x52e2b9['join'](''))??'',this['forceUpgradeOnSignin']=_0x2b9dd7['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x2b9dd7['schemaVersion'];}['validatePassword'](_0x1c081c){const _0x415d91={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1c081c,_0x415d91),this['validatePasswordCharacterOptions'](_0x1c081c,_0x415d91),_0x415d91['isValid']&&(_0x415d91['isValid']=_0x415d91['meetsMinPasswordLength']??!0x0),_0x415d91['isValid']&&(_0x415d91['isValid']=_0x415d91['meetsMaxPasswordLength']??!0x0),_0x415d91['isValid']&&(_0x415d91['isValid']=_0x415d91['containsLowercaseLetter']??!0x0),_0x415d91['isValid']&&(_0x415d91['isValid']=_0x415d91['containsUppercaseLetter']??!0x0),_0x415d91['isValid']&&(_0x415d91['isValid']=_0x415d91['containsNumericCharacter']??!0x0),_0x415d91['isValid']&&(_0x415d91['isValid']=_0x415d91['containsNonAlphanumericCharacter']??!0x0),_0x415d91;}['validatePasswordLengthOptions'](_0x16398a,_0xbaa778){const _0x519c95=this['customStrengthOptions']['minPasswordLength'],_0x59231b=this['customStrengthOptions']['maxPasswordLength'];_0x519c95&&(_0xbaa778['meetsMinPasswordLength']=_0x16398a['length']>=_0x519c95),_0x59231b&&(_0xbaa778['meetsMaxPasswordLength']=_0x16398a['length']<=_0x59231b);}['validatePasswordCharacterOptions'](_0x55d550,_0xfe706d){this['updatePasswordCharacterOptionsStatuses'](_0xfe706d,!0x1,!0x1,!0x1,!0x1);let _0x415b66;for(let _0x91ccb3=0x0;_0x91ccb3<_0x55d550['length'];_0x91ccb3++)_0x415b66=_0x55d550['charAt'](_0x91ccb3),this['updatePasswordCharacterOptionsStatuses'](_0xfe706d,_0x415b66>='a'&&_0x415b66<='z',_0x415b66>='A'&&_0x415b66<='Z',_0x415b66>='0'&&_0x415b66<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x415b66));}['updatePasswordCharacterOptionsStatuses'](_0x52d170,_0xa2295f,_0x5df531,_0x1a27cb,_0x2c7670){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x52d170['containsLowercaseLetter']||(_0x52d170['containsLowercaseLetter']=_0xa2295f)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x52d170['containsUppercaseLetter']||(_0x52d170['containsUppercaseLetter']=_0x5df531)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x52d170['containsNumericCharacter']||(_0x52d170['containsNumericCharacter']=_0x1a27cb)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x52d170['containsNonAlphanumericCharacter']||(_0x52d170['containsNonAlphanumericCharacter']=_0x2c7670));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x11e61a,_0x481184,_0x139d59,_0x131516){this['app']=_0x11e61a,this['heartbeatServiceProvider']=_0x481184,this['appCheckServiceProvider']=_0x139d59,this['config']=_0x131516,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x11e61a['name'],this['clientVersion']=_0x131516['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5596c3=>this['_resolvePersistenceManagerAvailable']=_0x5596c3);}['_initializeWithPersistence'](_0x4d7e6a,_0x5157bf){return _0x5157bf&&(this['_popupRedirectResolver']=ne(_0x5157bf)),this['_initializationPromise']=this['queue'](async()=>{var _0x3c3a0b,_0x153c51,_0x51461a;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x4d7e6a),(_0x3c3a0b=this['_resolvePersistenceManagerAvailable'])==null||_0x3c3a0b['call'](this),!this['_deleted'])){if((_0x153c51=this['_popupRedirectResolver'])!=null&&_0x153c51['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5157bf),this['lastNotifiedUid']=((_0x51461a=this['currentUser'])==null?void 0x0:_0x51461a['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3c6c33=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3c6c33)){if(this['currentUser']&&_0x3c6c33&&this['currentUser']['uid']===_0x3c6c33['uid']){this['_currentUser']['_assign'](_0x3c6c33),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3c6c33,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x118ad6){try{const _0x486925=await Sn(this,{'idToken':_0x118ad6}),_0x37bf52=await z['_fromGetAccountInfoResponse'](this,_0x486925,_0x118ad6);await this['directlySetCurrentUser'](_0x37bf52);}catch(_0x1c92f8){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1c92f8),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x30d89e){var _0x1e2c23;if(H(this['app'])){const _0x4edfa6=this['app']['settings']['authIdToken'];return _0x4edfa6?new Promise(_0x2dac2e=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4edfa6)['then'](_0x2dac2e,_0x2dac2e));}):this['directlySetCurrentUser'](null);}const _0x332e22=await this['assertedPersistence']['getCurrentUser']();let _0x1a868e=_0x332e22,_0x20f5af=!0x1;if(_0x30d89e&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0xb4f405=(_0x1e2c23=this['redirectUser'])==null?void 0x0:_0x1e2c23['_redirectEventId'],_0x4ef988=_0x1a868e==null?void 0x0:_0x1a868e['_redirectEventId'],_0x2ec9c1=await this['tryRedirectSignIn'](_0x30d89e);(!_0xb4f405||_0xb4f405===_0x4ef988)&&(_0x2ec9c1!=null&&_0x2ec9c1['user'])&&(_0x1a868e=_0x2ec9c1['user'],_0x20f5af=!0x0);}if(!_0x1a868e)return this['directlySetCurrentUser'](null);if(!_0x1a868e['_redirectEventId']){if(_0x20f5af)try{await this['beforeStateQueue']['runMiddleware'](_0x1a868e);}catch(_0x51167a){_0x1a868e=_0x332e22,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x51167a));}return _0x1a868e?this['reloadAndSetCurrentUserOrClear'](_0x1a868e):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1a868e['_redirectEventId']?this['directlySetCurrentUser'](_0x1a868e):this['reloadAndSetCurrentUserOrClear'](_0x1a868e);}async['tryRedirectSignIn'](_0x298fc4){let _0x23f377=null;try{_0x23f377=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x298fc4,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x23f377;}async['reloadAndSetCurrentUserOrClear'](_0x2e8f70){try{await bn(_0x2e8f70);}catch(_0x764c4c){if((_0x764c4c==null?void 0x0:_0x764c4c['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2e8f70);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x4fbc35){if(H(this['app']))return Promise['reject'](se(this));const _0x4dd5fb=_0x4fbc35?k(_0x4fbc35):null;return _0x4dd5fb&&m(_0x4dd5fb['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4dd5fb&&_0x4dd5fb['_clone'](this));}async['_updateCurrentUser'](_0x44e8d3,_0x57d4f8=!0x1){if(!this['_deleted'])return _0x44e8d3&&m(this['tenantId']===_0x44e8d3['tenantId'],this,'tenant-id-mismatch'),_0x57d4f8||await this['beforeStateQueue']['runMiddleware'](_0x44e8d3),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x44e8d3),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2bce9a){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x2bce9a));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x163a9e){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5c5d0d=this['_getPasswordPolicyInternal']();return _0x5c5d0d['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5c5d0d['validatePassword'](_0x163a9e);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x45c387=await Cf(this),_0x39334e=new Sf(_0x45c387);this['tenantId']===null?this['_projectPasswordPolicy']=_0x39334e:this['_tenantPasswordPolicies'][this['tenantId']]=_0x39334e;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x18946d){this['_errorFactory']=new Ut('auth','Firebase',_0x18946d());}['onAuthStateChanged'](_0x4909bd,_0x3eee7a,_0x355728){return this['registerStateListener'](this['authStateSubscription'],_0x4909bd,_0x3eee7a,_0x355728);}['beforeAuthStateChanged'](_0x47ddd4,_0x5ed74d){return this['beforeStateQueue']['pushCallback'](_0x47ddd4,_0x5ed74d);}['onIdTokenChanged'](_0x3c3acd,_0x57da7f,_0x40d8ec){return this['registerStateListener'](this['idTokenSubscription'],_0x3c3acd,_0x57da7f,_0x40d8ec);}['authStateReady'](){return new Promise((_0x1903f,_0x58ef46)=>{if(this['currentUser'])_0x1903f();else{const _0x5e05b9=this['onAuthStateChanged'](()=>{_0x5e05b9(),_0x1903f();},_0x58ef46);}});}async['revokeAccessToken'](_0x3890b0){if(this['currentUser']){const _0x2c333b=await this['currentUser']['getIdToken'](),_0x483134={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3890b0,'idToken':_0x2c333b};this['tenantId']!=null&&(_0x483134['tenantId']=this['tenantId']),await vf(this,_0x483134);}}['toJSON'](){var _0x549241;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x549241=this['_currentUser'])==null?void 0x0:_0x549241['toJSON']()};}async['_setRedirectUser'](_0x108724,_0x4417d8){const _0x5f3065=await this['getOrInitRedirectPersistenceManager'](_0x4417d8);return _0x108724===null?_0x5f3065['removeCurrentUser']():_0x5f3065['setCurrentUser'](_0x108724);}async['getOrInitRedirectPersistenceManager'](_0x45513d){if(!this['redirectPersistenceManager']){const _0x3a8d03=_0x45513d&&ne(_0x45513d)||this['_popupRedirectResolver'];m(_0x3a8d03,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x3a8d03['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x5947db){var _0x215745,_0x3a118a;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x215745=this['_currentUser'])==null?void 0x0:_0x215745['_redirectEventId'])===_0x5947db?this['_currentUser']:((_0x3a118a=this['redirectUser'])==null?void 0x0:_0x3a118a['_redirectEventId'])===_0x5947db?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2df973){if(_0x2df973===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2df973));}['_notifyListenersIfCurrent'](_0x50ba31){_0x50ba31===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x444713;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x58d842=((_0x444713=this['currentUser'])==null?void 0x0:_0x444713['uid'])??null;this['lastNotifiedUid']!==_0x58d842&&(this['lastNotifiedUid']=_0x58d842,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x4ebf9f,_0x27c289,_0x5fc520,_0x2d562e){if(this['_deleted'])return()=>{};const _0x37f2d1=typeof _0x27c289=='function'?_0x27c289:_0x27c289['next']['bind'](_0x27c289);let _0x319981=!0x1;const _0xb02f71=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xb02f71,this,'internal-error'),_0xb02f71['then'](()=>{_0x319981||_0x37f2d1(this['currentUser']);}),typeof _0x27c289=='function'){const _0x5506fb=_0x4ebf9f['addObserver'](_0x27c289,_0x5fc520,_0x2d562e);return()=>{_0x319981=!0x0,_0x5506fb();};}else{const _0x745637=_0x4ebf9f['addObserver'](_0x27c289);return()=>{_0x319981=!0x0,_0x745637();};}}async['directlySetCurrentUser'](_0x44c9a4){this['currentUser']&&this['currentUser']!==_0x44c9a4&&this['_currentUser']['_stopProactiveRefresh'](),_0x44c9a4&&this['isProactiveRefreshEnabled']&&_0x44c9a4['_startProactiveRefresh'](),this['currentUser']=_0x44c9a4,_0x44c9a4?await this['assertedPersistence']['setCurrentUser'](_0x44c9a4):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x21f878){return this['operations']=this['operations']['then'](_0x21f878,_0x21f878),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5dd1e7){!_0x5dd1e7||this['frameworks']['includes'](_0x5dd1e7)||(this['frameworks']['push'](_0x5dd1e7),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1c2819;const _0x25f3b7={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x25f3b7['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x414abc=await((_0x1c2819=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1c2819['getHeartbeatsHeader']());_0x414abc&&(_0x25f3b7['X-Firebase-Client']=_0x414abc);const _0x450f43=await this['_getAppCheckToken']();return _0x450f43&&(_0x25f3b7['X-Firebase-AppCheck']=_0x450f43),_0x25f3b7;}async['_getAppCheckToken'](){var _0x39e3d4;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x14392f=await((_0x39e3d4=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x39e3d4['getToken']());return _0x14392f!=null&&_0x14392f['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x14392f['error']),_0x14392f==null?void 0x0:_0x14392f['token'];}}function qe(_0x2d0526){return k(_0x2d0526);}class Tr{constructor(_0x372599){this['auth']=_0x372599,this['observer']=null,this['addObserver']=Ic(_0x38f9eb=>this['observer']=_0x38f9eb);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x1175bf){zn=_0x1175bf;}function Da(_0x385518){return zn['loadJS'](_0x385518);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x1b265e){return'__'+_0x1b265e+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x2c347c){_0x2c347c();}['execute'](_0x5d779a,_0xd8a92a){return Promise['resolve']('token');}['render'](_0x28b92c,_0x38e28d){return'';}}class Of{['ready'](_0x5a1fba){_0x5a1fba();}['execute'](_0x458e60,_0x53db59){return Promise['resolve']('token');}['render'](_0x580ed4,_0x3f5896){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x2fe7ae){this['type']=Df,this['auth']=qe(_0x2fe7ae);}async['verify'](_0x34efac='verify',_0x308e7d=!0x1){async function _0xba6e76(_0x564469){if(!_0x308e7d){if(_0x564469['tenantId']==null&&_0x564469['_agentRecaptchaConfig']!=null)return _0x564469['_agentRecaptchaConfig']['siteKey'];if(_0x564469['tenantId']!=null&&_0x564469['_tenantRecaptchaConfigs'][_0x564469['tenantId']]!==void 0x0)return _0x564469['_tenantRecaptchaConfigs'][_0x564469['tenantId']]['siteKey'];}return new Promise(async(_0x2d1828,_0x14c219)=>{uf(_0x564469,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x419b02=>{if(_0x419b02['recaptchaKey']===void 0x0)_0x14c219(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x270ab0=new hf(_0x419b02);return _0x564469['tenantId']==null?_0x564469['_agentRecaptchaConfig']=_0x270ab0:_0x564469['_tenantRecaptchaConfigs'][_0x564469['tenantId']]=_0x270ab0,_0x2d1828(_0x270ab0['siteKey']);}})['catch'](_0x4f927a=>{_0x14c219(_0x4f927a);});});}function _0x17738b(_0x3801d2,_0x18c813,_0x3ae131){const _0x36de01=window['grecaptcha'];vr(_0x36de01)?_0x36de01['enterprise']['ready'](()=>{_0x36de01['enterprise']['execute'](_0x3801d2,{'action':_0x34efac})['then'](_0x322b11=>{_0x18c813(_0x322b11);})['catch'](()=>{_0x18c813(Ma);});}):_0x3ae131(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x24cc93,_0x162c29)=>{_0xba6e76(this['auth'])['then'](async _0x425d34=>{if(!_0x308e7d&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x17738b(_0x425d34,_0x24cc93,_0x162c29);else{if(typeof window>'u'){_0x162c29(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2037f2=Af();_0x2037f2['length']!==0x0&&(_0x2037f2+=_0x425d34+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x41ac51;(_0x41ac51=le['scriptInjectionDeferred'])==null||_0x41ac51['resolve']();},Da(_0x2037f2)['then'](()=>{var _0x1c2c43;return(_0x1c2c43=le['scriptInjectionDeferred'])==null?void 0x0:_0x1c2c43['promise'];})['then'](()=>{_0x17738b(_0x425d34,_0x24cc93,_0x162c29);})['catch'](_0x4d0dbc=>{_0x162c29(_0x4d0dbc);});}})['catch'](_0x3f8d07=>{_0x162c29(_0x3f8d07);});});}}le['scriptInjectionDeferred']=null;async function br(_0x2052de,_0x412ba5,_0x38283f,_0x519852=!0x1,_0x640984=!0x1){const _0x30e0e7=new le(_0x2052de);let _0x3eef22;if(_0x640984)_0x3eef22=Ma;else try{_0x3eef22=await _0x30e0e7['verify'](_0x38283f);}catch{_0x3eef22=await _0x30e0e7['verify'](_0x38283f,!0x0);}const _0x425c78={..._0x412ba5};if(_0x38283f==='mfaSmsEnrollment'||_0x38283f==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x425c78){const _0x25264a=_0x425c78['phoneEnrollmentInfo']['phoneNumber'],_0x3be320=_0x425c78['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x425c78,{'phoneEnrollmentInfo':{'phoneNumber':_0x25264a,'recaptchaToken':_0x3be320,'captchaResponse':_0x3eef22,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x425c78){const _0x40504d=_0x425c78['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x425c78,{'phoneSignInInfo':{'recaptchaToken':_0x40504d,'captchaResponse':_0x3eef22,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x425c78;}return _0x519852?Object['assign'](_0x425c78,{'captchaResp':_0x3eef22}):Object['assign'](_0x425c78,{'captchaResponse':_0x3eef22}),Object['assign'](_0x425c78,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x425c78,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x425c78;}async function Oi(_0xe8f4bb,_0x56724c,_0x2eb116,_0x108f37,_0x45dd2e){var _0x278cb0;if((_0x278cb0=_0xe8f4bb['_getRecaptchaConfig']())!=null&&_0x278cb0['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x19931e=await br(_0xe8f4bb,_0x56724c,_0x2eb116,_0x2eb116==='getOobCode');return _0x108f37(_0xe8f4bb,_0x19931e);}else return _0x108f37(_0xe8f4bb,_0x56724c)['catch'](async _0x1220a1=>{if(_0x1220a1['code']==='auth/missing-recaptcha-token'){console['log'](_0x2eb116+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1d7ed7=await br(_0xe8f4bb,_0x56724c,_0x2eb116,_0x2eb116==='getOobCode');return _0x108f37(_0xe8f4bb,_0x1d7ed7);}else return Promise['reject'](_0x1220a1);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x5c42dc,_0x16530b){const _0x5c1b3f=Ui(_0x5c42dc,'auth');if(_0x5c1b3f['isInitialized']()){const _0x29cc2a=_0x5c1b3f['getImmediate'](),_0x3cf9e9=_0x5c1b3f['getOptions']();if(De(_0x3cf9e9,_0x16530b??{}))return _0x29cc2a;K(_0x29cc2a,'already-initialized');}return _0x5c1b3f['initialize']({'options':_0x16530b});}function Lf(_0x349ce6,_0x45524b){const _0x5320ab=(_0x45524b==null?void 0x0:_0x45524b['persistence'])||[],_0x2a7d21=(Array['isArray'](_0x5320ab)?_0x5320ab:[_0x5320ab])['map'](ne);_0x45524b!=null&&_0x45524b['errorMap']&&_0x349ce6['_updateErrorMap'](_0x45524b['errorMap']),_0x349ce6['_initializeWithPersistence'](_0x2a7d21,_0x45524b==null?void 0x0:_0x45524b['popupRedirectResolver']);}function xf(_0x8ac0cd,_0x446bcc,_0x3868ba){const _0x57f1c6=qe(_0x8ac0cd);m(/^https?:\/\//['test'](_0x446bcc),_0x57f1c6,'invalid-emulator-scheme');const _0x1a3c17=!0x1,_0x5d60af=La(_0x446bcc),{host:_0x19828c,port:_0xe27f51}=Ff(_0x446bcc),_0x3ff435=_0xe27f51===null?'':':'+_0xe27f51,_0x4bd0ba={'url':_0x5d60af+'//'+_0x19828c+_0x3ff435+'/'},_0x4c21cb=Object['freeze']({'host':_0x19828c,'port':_0xe27f51,'protocol':_0x5d60af['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x1a3c17})});if(!_0x57f1c6['_canInitEmulator']){m(_0x57f1c6['config']['emulator']&&_0x57f1c6['emulatorConfig'],_0x57f1c6,'emulator-config-failed'),m(De(_0x4bd0ba,_0x57f1c6['config']['emulator'])&&De(_0x4c21cb,_0x57f1c6['emulatorConfig']),_0x57f1c6,'emulator-config-failed');return;}_0x57f1c6['config']['emulator']=_0x4bd0ba,_0x57f1c6['emulatorConfig']=_0x4c21cb,_0x57f1c6['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x19828c)?jr(_0x5d60af+'//'+_0x19828c+_0x3ff435):Uf();}function La(_0xc4da0f){const _0x17e9df=_0xc4da0f['indexOf'](':');return _0x17e9df<0x0?'':_0xc4da0f['substr'](0x0,_0x17e9df+0x1);}function Ff(_0x23c612){const _0xbed057=La(_0x23c612),_0x4e9043=/(\/\/)?([^?#/]+)/['exec'](_0x23c612['substr'](_0xbed057['length']));if(!_0x4e9043)return{'host':'','port':null};const _0x138d81=_0x4e9043[0x2]['split']('@')['pop']()||'',_0x1dd30a=/^(\[[^\]]+\])(:|$)/['exec'](_0x138d81);if(_0x1dd30a){const _0x52487c=_0x1dd30a[0x1];return{'host':_0x52487c,'port':Rr(_0x138d81['substr'](_0x52487c['length']+0x1))};}else{const [_0x1d6df1,_0x2d9a16]=_0x138d81['split'](':');return{'host':_0x1d6df1,'port':Rr(_0x2d9a16)};}}function Rr(_0x34109a){if(!_0x34109a)return null;const _0xa325ef=Number(_0x34109a);return isNaN(_0xa325ef)?null:_0xa325ef;}function Uf(){function _0x36789b(){const _0x4f492f=document['createElement']('p'),_0x27771a=_0x4f492f['style'];_0x4f492f['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x27771a['position']='fixed',_0x27771a['width']='100%',_0x27771a['backgroundColor']='#ffffff',_0x27771a['border']='.1em\x20solid\x20#000000',_0x27771a['color']='#b50000',_0x27771a['bottom']='0px',_0x27771a['left']='0px',_0x27771a['margin']='0px',_0x27771a['zIndex']='10000',_0x27771a['textAlign']='center',_0x4f492f['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4f492f);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x36789b):_0x36789b());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x26f1e8,_0x3a8541){this['providerId']=_0x26f1e8,this['signInMethod']=_0x3a8541;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x278d50){return te('not\x20implemented');}['_linkToIdToken'](_0x52fce4,_0x542556){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x2b7158){return te('not\x20implemented');}}async function Wf(_0xa7cca0,_0x198f41){return Ae(_0xa7cca0,'POST','/v1/accounts:signUp',_0x198f41);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x279fdc,_0x314539){return Yt(_0x279fdc,'POST','/v1/accounts:signInWithPassword',Re(_0x279fdc,_0x314539));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x12e14a,_0x204d61){return Yt(_0x12e14a,'POST','/v1/accounts:signInWithEmailLink',Re(_0x12e14a,_0x204d61));}async function Hf(_0x5e4dc1,_0x27bbaa){return Yt(_0x5e4dc1,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5e4dc1,_0x27bbaa));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x1489c4,_0x3fab7c,_0x4d77cf,_0x2eb1ea=null){super('password',_0x4d77cf),this['_email']=_0x1489c4,this['_password']=_0x3fab7c,this['_tenantId']=_0x2eb1ea;}static['_fromEmailAndPassword'](_0x31d43c,_0x553566){return new Ft(_0x31d43c,_0x553566,'password');}static['_fromEmailAndCode'](_0x2d1a39,_0x583810,_0x44cb32=null){return new Ft(_0x2d1a39,_0x583810,'emailLink',_0x44cb32);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2de128){const _0x446023=typeof _0x2de128=='string'?JSON['parse'](_0x2de128):_0x2de128;if(_0x446023!=null&&_0x446023['email']&&(_0x446023!=null&&_0x446023['password'])){if(_0x446023['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x446023['email'],_0x446023['password']);if(_0x446023['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x446023['email'],_0x446023['password'],_0x446023['tenantId']);}return null;}async['_getIdTokenResponse'](_0x927812){switch(this['signInMethod']){case'password':const _0x277734={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x927812,_0x277734,'signInWithPassword',Bf);case'emailLink':return Vf(_0x927812,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x927812,'internal-error');}}async['_linkToIdToken'](_0x58204b,_0x575ec9){switch(this['signInMethod']){case'password':const _0x4d0475={'idToken':_0x575ec9,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x58204b,_0x4d0475,'signUpPassword',Wf);case'emailLink':return Hf(_0x58204b,{'idToken':_0x575ec9,'email':this['_email'],'oobCode':this['_password']});default:K(_0x58204b,'internal-error');}}['_getReauthenticationResolver'](_0x286f49){return this['_getIdTokenResponse'](_0x286f49);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x4a4a7d,_0x61bb26){return Yt(_0x4a4a7d,'POST','/v1/accounts:signInWithIdp',Re(_0x4a4a7d,_0x61bb26));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2e5f47){const _0x2a3f1b=new We(_0x2e5f47['providerId'],_0x2e5f47['signInMethod']);return _0x2e5f47['idToken']||_0x2e5f47['accessToken']?(_0x2e5f47['idToken']&&(_0x2a3f1b['idToken']=_0x2e5f47['idToken']),_0x2e5f47['accessToken']&&(_0x2a3f1b['accessToken']=_0x2e5f47['accessToken']),_0x2e5f47['nonce']&&!_0x2e5f47['pendingToken']&&(_0x2a3f1b['nonce']=_0x2e5f47['nonce']),_0x2e5f47['pendingToken']&&(_0x2a3f1b['pendingToken']=_0x2e5f47['pendingToken'])):_0x2e5f47['oauthToken']&&_0x2e5f47['oauthTokenSecret']?(_0x2a3f1b['accessToken']=_0x2e5f47['oauthToken'],_0x2a3f1b['secret']=_0x2e5f47['oauthTokenSecret']):K('argument-error'),_0x2a3f1b;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x11e596){const _0xe62975=typeof _0x11e596=='string'?JSON['parse'](_0x11e596):_0x11e596,{providerId:_0x112199,signInMethod:_0x5f1ef2,..._0x44ea50}=_0xe62975;if(!_0x112199||!_0x5f1ef2)return null;const _0x4096ee=new We(_0x112199,_0x5f1ef2);return _0x4096ee['idToken']=_0x44ea50['idToken']||void 0x0,_0x4096ee['accessToken']=_0x44ea50['accessToken']||void 0x0,_0x4096ee['secret']=_0x44ea50['secret'],_0x4096ee['nonce']=_0x44ea50['nonce'],_0x4096ee['pendingToken']=_0x44ea50['pendingToken']||null,_0x4096ee;}['_getIdTokenResponse'](_0x4f1268){const _0x592110=this['buildRequest']();return Ze(_0x4f1268,_0x592110);}['_linkToIdToken'](_0x19745b,_0x24e0a5){const _0xe9374=this['buildRequest']();return _0xe9374['idToken']=_0x24e0a5,Ze(_0x19745b,_0xe9374);}['_getReauthenticationResolver'](_0xdcf140){const _0x1eb8ac=this['buildRequest']();return _0x1eb8ac['autoCreate']=!0x1,Ze(_0xdcf140,_0x1eb8ac);}['buildRequest'](){const _0x1c42a2={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1c42a2['pendingToken']=this['pendingToken'];else{const _0x2947a4={};this['idToken']&&(_0x2947a4['id_token']=this['idToken']),this['accessToken']&&(_0x2947a4['access_token']=this['accessToken']),this['secret']&&(_0x2947a4['oauth_token_secret']=this['secret']),_0x2947a4['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x2947a4['nonce']=this['nonce']),_0x1c42a2['postBody']=at(_0x2947a4);}return _0x1c42a2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x5c7a3b){switch(_0x5c7a3b){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x2d2a19){const _0x53c9ca=yt(vt(_0x2d2a19))['link'],_0x4ed566=_0x53c9ca?yt(vt(_0x53c9ca))['deep_link_id']:null,_0x1969b1=yt(vt(_0x2d2a19))['deep_link_id'];return(_0x1969b1?yt(vt(_0x1969b1))['link']:null)||_0x1969b1||_0x4ed566||_0x53c9ca||_0x2d2a19;}class Ss{constructor(_0x24aabe){const _0x11aca7=yt(vt(_0x24aabe)),_0x38d388=_0x11aca7['apiKey']??null,_0x3d6bff=_0x11aca7['oobCode']??null,_0x55c7ad=Gf(_0x11aca7['mode']??null);m(_0x38d388&&_0x3d6bff&&_0x55c7ad,'argument-error'),this['apiKey']=_0x38d388,this['operation']=_0x55c7ad,this['code']=_0x3d6bff,this['continueUrl']=_0x11aca7['continueUrl']??null,this['languageCode']=_0x11aca7['lang']??null,this['tenantId']=_0x11aca7['tenantId']??null;}static['parseLink'](_0x201615){const _0x43a818=qf(_0x201615);try{return new Ss(_0x43a818);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x526717,_0x767dd3){return Ft['_fromEmailAndPassword'](_0x526717,_0x767dd3);}static['credentialWithLink'](_0x5f434a,_0x5e82eb){const _0x1454ba=Ss['parseLink'](_0x5e82eb);return m(_0x1454ba,'argument-error'),Ft['_fromEmailAndCode'](_0x5f434a,_0x1454ba['code'],_0x1454ba['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x50a3be){this['providerId']=_0x50a3be,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x84ea6f){this['defaultLanguageCode']=_0x84ea6f;}['setCustomParameters'](_0x26aa3a){return this['customParameters']=_0x26aa3a,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5e0603){return this['scopes']['includes'](_0x5e0603)||this['scopes']['push'](_0x5e0603),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x44557b){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x44557b});}static['credentialFromResult'](_0x27c92c){return he['credentialFromTaggedObject'](_0x27c92c);}static['credentialFromError'](_0x12a8ec){return he['credentialFromTaggedObject'](_0x12a8ec['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1b10c6}){if(!_0x1b10c6||!('oauthAccessToken'in _0x1b10c6)||!_0x1b10c6['oauthAccessToken'])return null;try{return he['credential'](_0x1b10c6['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1ea757,_0x50353d){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1ea757,'accessToken':_0x50353d});}static['credentialFromResult'](_0xd92b65){return ue['credentialFromTaggedObject'](_0xd92b65);}static['credentialFromError'](_0x4be5e6){return ue['credentialFromTaggedObject'](_0x4be5e6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3f2dba}){if(!_0x3f2dba)return null;const {oauthIdToken:_0x55505d,oauthAccessToken:_0x393688}=_0x3f2dba;if(!_0x55505d&&!_0x393688)return null;try{return ue['credential'](_0x55505d,_0x393688);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0xe77af6){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xe77af6});}static['credentialFromResult'](_0x5bae2c){return de['credentialFromTaggedObject'](_0x5bae2c);}static['credentialFromError'](_0x2e755a){return de['credentialFromTaggedObject'](_0x2e755a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x309267}){if(!_0x309267||!('oauthAccessToken'in _0x309267)||!_0x309267['oauthAccessToken'])return null;try{return de['credential'](_0x309267['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x1359e6,_0x24b63f){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1359e6,'oauthTokenSecret':_0x24b63f});}static['credentialFromResult'](_0x1c24a5){return fe['credentialFromTaggedObject'](_0x1c24a5);}static['credentialFromError'](_0x4f875b){return fe['credentialFromTaggedObject'](_0x4f875b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x322ca6}){if(!_0x322ca6)return null;const {oauthAccessToken:_0x5abb01,oauthTokenSecret:_0x24bd7c}=_0x322ca6;if(!_0x5abb01||!_0x24bd7c)return null;try{return fe['credential'](_0x5abb01,_0x24bd7c);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x4dd85c,_0x412e54){return Yt(_0x4dd85c,'POST','/v1/accounts:signUp',Re(_0x4dd85c,_0x412e54));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x1ab4b3){this['user']=_0x1ab4b3['user'],this['providerId']=_0x1ab4b3['providerId'],this['_tokenResponse']=_0x1ab4b3['_tokenResponse'],this['operationType']=_0x1ab4b3['operationType'];}static async['_fromIdTokenResponse'](_0xbbe5b8,_0x452144,_0x2863d3,_0x2d0442=!0x1){const _0x39321c=await z['_fromIdTokenResponse'](_0xbbe5b8,_0x2863d3,_0x2d0442),_0x47bc65=Ar(_0x2863d3);return new Be({'user':_0x39321c,'providerId':_0x47bc65,'_tokenResponse':_0x2863d3,'operationType':_0x452144});}static async['_forOperation'](_0x5657ab,_0x521482,_0x43d030){await _0x5657ab['_updateTokensIfNecessary'](_0x43d030,!0x0);const _0x3111e3=Ar(_0x43d030);return new Be({'user':_0x5657ab,'providerId':_0x3111e3,'_tokenResponse':_0x43d030,'operationType':_0x521482});}}function Ar(_0x2ae47c){return _0x2ae47c['providerId']?_0x2ae47c['providerId']:'phoneNumber'in _0x2ae47c?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x30c615,_0x393884,_0x41daf2,_0x20cf14){super(_0x393884['code'],_0x393884['message']),this['operationType']=_0x41daf2,this['user']=_0x20cf14,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x30c615['name'],'tenantId':_0x30c615['tenantId']??void 0x0,'_serverResponse':_0x393884['customData']['_serverResponse'],'operationType':_0x41daf2};}static['_fromErrorAndOperation'](_0x10c001,_0x4f2838,_0x16e0f1,_0x47d688){return new Rn(_0x10c001,_0x4f2838,_0x16e0f1,_0x47d688);}}function Fa(_0x3caa2f,_0x259422,_0x3a9509,_0x1449bb){return(_0x259422==='reauthenticate'?_0x3a9509['_getReauthenticationResolver'](_0x3caa2f):_0x3a9509['_getIdTokenResponse'](_0x3caa2f))['catch'](_0x14daff=>{throw _0x14daff['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x3caa2f,_0x14daff,_0x259422,_0x1449bb):_0x14daff;});}async function jf(_0x4e429f,_0x2ae39d,_0x3c6eba=!0x1){const _0x4c05a1=await xt(_0x4e429f,_0x2ae39d['_linkToIdToken'](_0x4e429f['auth'],await _0x4e429f['getIdToken']()),_0x3c6eba);return Be['_forOperation'](_0x4e429f,'link',_0x4c05a1);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x5d6557,_0x4eca7c,_0x401660=!0x1){const {auth:_0x1adf60}=_0x5d6557;if(H(_0x1adf60['app']))return Promise['reject'](se(_0x1adf60));const _0x5493dd='reauthenticate';try{const _0x334832=await xt(_0x5d6557,Fa(_0x1adf60,_0x5493dd,_0x4eca7c,_0x5d6557),_0x401660);m(_0x334832['idToken'],_0x1adf60,'internal-error');const _0x411e5e=ws(_0x334832['idToken']);m(_0x411e5e,_0x1adf60,'internal-error');const {sub:_0x125602}=_0x411e5e;return m(_0x5d6557['uid']===_0x125602,_0x1adf60,'user-mismatch'),Be['_forOperation'](_0x5d6557,_0x5493dd,_0x334832);}catch(_0x1b930c){throw(_0x1b930c==null?void 0x0:_0x1b930c['code'])==='auth/user-not-found'&&K(_0x1adf60,'user-mismatch'),_0x1b930c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4bb32c,_0x1e05cb,_0x285e97=!0x1){if(H(_0x4bb32c['app']))return Promise['reject'](se(_0x4bb32c));const _0x3698c9='signIn',_0x35aa11=await Fa(_0x4bb32c,_0x3698c9,_0x1e05cb),_0xd74843=await Be['_fromIdTokenResponse'](_0x4bb32c,_0x3698c9,_0x35aa11);return _0x285e97||await _0x4bb32c['_updateCurrentUser'](_0xd74843['user']),_0xd74843;}async function Yf(_0x4674b7,_0x2900a2){return Ua(qe(_0x4674b7),_0x2900a2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x338325){const _0x28b218=qe(_0x338325);_0x28b218['_getPasswordPolicyInternal']()&&await _0x28b218['_updatePasswordPolicy']();}async function R_(_0x73a0f0,_0x1bd220,_0x4ce02a){if(H(_0x73a0f0['app']))return Promise['reject'](se(_0x73a0f0));const _0x24c59f=qe(_0x73a0f0),_0x2d3dc1=await Oi(_0x24c59f,{'returnSecureToken':!0x0,'email':_0x1bd220,'password':_0x4ce02a,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x9ee75e=>{throw _0x9ee75e['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x73a0f0),_0x9ee75e;}),_0x10379a=await Be['_fromIdTokenResponse'](_0x24c59f,'signIn',_0x2d3dc1);return await _0x24c59f['_updateCurrentUser'](_0x10379a['user']),_0x10379a;}function A_(_0x55cebd,_0x305cf1,_0x3094e1){return H(_0x55cebd['app'])?Promise['reject'](se(_0x55cebd)):Yf(k(_0x55cebd),ft['credential'](_0x305cf1,_0x3094e1))['catch'](async _0x4a08b4=>{throw _0x4a08b4['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x55cebd),_0x4a08b4;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x7df8d7,_0x308795){return k(_0x7df8d7)['setPersistence'](_0x308795);}function Qf(_0x3ed3d4,_0xfc921b,_0x539d68,_0x24cdff){return k(_0x3ed3d4)['onIdTokenChanged'](_0xfc921b,_0x539d68,_0x24cdff);}function Jf(_0x148deb,_0x17ba2d,_0x4d3b04){return k(_0x148deb)['beforeAuthStateChanged'](_0x17ba2d,_0x4d3b04);}function N_(_0x49310c,_0x1fbaaf,_0x121652,_0x252a46){return k(_0x49310c)['onAuthStateChanged'](_0x1fbaaf,_0x121652,_0x252a46);}function P_(_0x4456ee){return k(_0x4456ee)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x3089ef,_0x3211cc){this['storageRetriever']=_0x3089ef,this['type']=_0x3211cc;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x37e03f,_0x1eaee0){return this['storage']['setItem'](_0x37e03f,JSON['stringify'](_0x1eaee0)),Promise['resolve']();}['_get'](_0x5afd64){const _0x4891cd=this['storage']['getItem'](_0x5afd64);return Promise['resolve'](_0x4891cd?JSON['parse'](_0x4891cd):null);}['_remove'](_0x5f3bbd){return this['storage']['removeItem'](_0x5f3bbd),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x39f748,_0x4101c4)=>this['onStorageEvent'](_0x39f748,_0x4101c4),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x82a750){for(const _0x4d3c80 of Object['keys'](this['listeners'])){const _0x4fbbff=this['storage']['getItem'](_0x4d3c80),_0x4a11b7=this['localCache'][_0x4d3c80];_0x4fbbff!==_0x4a11b7&&_0x82a750(_0x4d3c80,_0x4a11b7,_0x4fbbff);}}['onStorageEvent'](_0x536a65,_0x41503e=!0x1){if(!_0x536a65['key']){this['forAllChangedKeys']((_0x82abc6,_0x5cfb91,_0x57100f)=>{this['notifyListeners'](_0x82abc6,_0x57100f);});return;}const _0x1c440c=_0x536a65['key'];_0x41503e?this['detachListener']():this['stopPolling']();const _0x503803=()=>{const _0x492edc=this['storage']['getItem'](_0x1c440c);!_0x41503e&&this['localCache'][_0x1c440c]===_0x492edc||this['notifyListeners'](_0x1c440c,_0x492edc);},_0xd96c2a=this['storage']['getItem'](_0x1c440c);If()&&_0xd96c2a!==_0x536a65['newValue']&&_0x536a65['newValue']!==_0x536a65['oldValue']?setTimeout(_0x503803,Zf):_0x503803();}['notifyListeners'](_0x1616da,_0x36e836){this['localCache'][_0x1616da]=_0x36e836;const _0x121019=this['listeners'][_0x1616da];if(_0x121019){for(const _0xbe5f5d of Array['from'](_0x121019))_0xbe5f5d(_0x36e836&&JSON['parse'](_0x36e836));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3a618c,_0x237e6f,_0x172cd3)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3a618c,'oldValue':_0x237e6f,'newValue':_0x172cd3}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x1bdbde,_0x364fa7){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x1bdbde]||(this['listeners'][_0x1bdbde]=new Set(),this['localCache'][_0x1bdbde]=this['storage']['getItem'](_0x1bdbde)),this['listeners'][_0x1bdbde]['add'](_0x364fa7);}['_removeListener'](_0x4db937,_0x31cdce){this['listeners'][_0x4db937]&&(this['listeners'][_0x4db937]['delete'](_0x31cdce),this['listeners'][_0x4db937]['size']===0x0&&delete this['listeners'][_0x4db937]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x54e7ac,_0x57b15d){await super['_set'](_0x54e7ac,_0x57b15d),this['localCache'][_0x54e7ac]=JSON['stringify'](_0x57b15d);}async['_get'](_0x6bf9cd){const _0x43320b=await super['_get'](_0x6bf9cd);return this['localCache'][_0x6bf9cd]=JSON['stringify'](_0x43320b),_0x43320b;}async['_remove'](_0x203753){await super['_remove'](_0x203753),delete this['localCache'][_0x203753];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3c5c01,_0x2fb1cd){}['_removeListener'](_0x178534,_0x58ea80){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x4f1838){return Promise['all'](_0x4f1838['map'](async _0x12e9a8=>{try{return{'fulfilled':!0x0,'value':await _0x12e9a8};}catch(_0xe47e52){return{'fulfilled':!0x1,'reason':_0xe47e52};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x2e85cb){this['eventTarget']=_0x2e85cb,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x4c8c05){const _0x2316c2=this['receivers']['find'](_0x983e88=>_0x983e88['isListeningto'](_0x4c8c05));if(_0x2316c2)return _0x2316c2;const _0x382a83=new jn(_0x4c8c05);return this['receivers']['push'](_0x382a83),_0x382a83;}['isListeningto'](_0xcb3f74){return this['eventTarget']===_0xcb3f74;}async['handleEvent'](_0x2787fe){const _0x33ab04=_0x2787fe,{eventId:_0x36d085,eventType:_0x210d53,data:_0x3cefd8}=_0x33ab04['data'],_0x5e3f60=this['handlersMap'][_0x210d53];if(!(_0x5e3f60!=null&&_0x5e3f60['size']))return;_0x33ab04['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x36d085,'eventType':_0x210d53});const _0x2d0d7d=Array['from'](_0x5e3f60)['map'](async _0x3c1e03=>_0x3c1e03(_0x33ab04['origin'],_0x3cefd8)),_0x13eff6=await tp(_0x2d0d7d);_0x33ab04['ports'][0x0]['postMessage']({'status':'done','eventId':_0x36d085,'eventType':_0x210d53,'response':_0x13eff6});}['_subscribe'](_0x8da4dc,_0x2fde24){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x8da4dc]||(this['handlersMap'][_0x8da4dc]=new Set()),this['handlersMap'][_0x8da4dc]['add'](_0x2fde24);}['_unsubscribe'](_0x165722,_0x410e23){this['handlersMap'][_0x165722]&&_0x410e23&&this['handlersMap'][_0x165722]['delete'](_0x410e23),(!_0x410e23||this['handlersMap'][_0x165722]['size']===0x0)&&delete this['handlersMap'][_0x165722],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x551dfc='',_0x421ef2=0xa){let _0x16a8b2='';for(let _0x954d6b=0x0;_0x954d6b<_0x421ef2;_0x954d6b++)_0x16a8b2+=Math['floor'](Math['random']()*0xa);return _0x551dfc+_0x16a8b2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x38d8c2){this['target']=_0x38d8c2,this['handlers']=new Set();}['removeMessageHandler'](_0x21263d){_0x21263d['messageChannel']&&(_0x21263d['messageChannel']['port1']['removeEventListener']('message',_0x21263d['onMessage']),_0x21263d['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x21263d);}async['_send'](_0x3d21fb,_0x5b302b,_0x158b49=0x32){const _0x2087b6=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x2087b6)throw new Error('connection_unavailable');let _0x47f802,_0x23f880;return new Promise((_0x386afa,_0x1c1347)=>{const _0x2e6375=bs('',0x14);_0x2087b6['port1']['start']();const _0x5a3648=setTimeout(()=>{_0x1c1347(new Error('unsupported_event'));},_0x158b49);_0x23f880={'messageChannel':_0x2087b6,'onMessage'(_0x45024c){const _0x380aca=_0x45024c;if(_0x380aca['data']['eventId']===_0x2e6375)switch(_0x380aca['data']['status']){case'ack':clearTimeout(_0x5a3648),_0x47f802=setTimeout(()=>{_0x1c1347(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x47f802),_0x386afa(_0x380aca['data']['response']);break;default:clearTimeout(_0x5a3648),clearTimeout(_0x47f802),_0x1c1347(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x23f880),_0x2087b6['port1']['addEventListener']('message',_0x23f880['onMessage']),this['target']['postMessage']({'eventType':_0x3d21fb,'eventId':_0x2e6375,'data':_0x5b302b},[_0x2087b6['port2']]);})['finally'](()=>{_0x23f880&&this['removeMessageHandler'](_0x23f880);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x569dc6){X()['location']['href']=_0x569dc6;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x462d06;return((_0x462d06=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x462d06['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x5dc27f){this['request']=_0x5dc27f;}['toPromise'](){return new Promise((_0x1402b1,_0x28cd21)=>{this['request']['addEventListener']('success',()=>{_0x1402b1(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x28cd21(this['request']['error']);});});}}function Kn(_0x433716,_0x28e1c8){return _0x433716['transaction']([kn],_0x28e1c8?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x5e43a7=indexedDB['deleteDatabase'](qa);return new Jt(_0x5e43a7)['toPromise']();}function ja(){const _0x4b95f6=indexedDB['open'](qa,ap);return new Promise((_0x970b6e,_0x4e469b)=>{_0x4b95f6['addEventListener']('error',()=>{_0x4e469b(_0x4b95f6['error']);}),_0x4b95f6['addEventListener']('upgradeneeded',()=>{const _0x401ae6=_0x4b95f6['result'];try{_0x401ae6['createObjectStore'](kn,{'keyPath':za});}catch(_0x4b2d77){_0x4e469b(_0x4b2d77);}}),_0x4b95f6['addEventListener']('success',async()=>{const _0x19dcac=_0x4b95f6['result'];_0x19dcac['objectStoreNames']['contains'](kn)?_0x970b6e(_0x19dcac):(_0x19dcac['close'](),await cp(),_0x970b6e(await ja()));});});}async function kr(_0x55ee83,_0x26cdd1,_0x453582){const _0x497917=Kn(_0x55ee83,!0x0)['put']({[za]:_0x26cdd1,'value':_0x453582});return new Jt(_0x497917)['toPromise']();}async function lp(_0x3a5d49,_0x425afb){const _0x1c737b=Kn(_0x3a5d49,!0x1)['get'](_0x425afb),_0x299860=await new Jt(_0x1c737b)['toPromise']();return _0x299860===void 0x0?null:_0x299860['value'];}function Nr(_0x2b6f22,_0x33218c){const _0x192f80=Kn(_0x2b6f22,!0x0)['delete'](_0x33218c);return new Jt(_0x192f80)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x559752){let _0x37542d=0x0;for(;;)try{const _0x55929e=await this['_openDb']();return await _0x559752(_0x55929e);}catch(_0x256104){if(_0x37542d++>up)throw _0x256104;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0xd6c1d4,_0x23fcf8)=>({'keyProcessed':(await this['_poll']())['includes'](_0x23fcf8['key'])})),this['receiver']['_subscribe']('ping',async(_0x4fd86e,_0x18e47c)=>['keyChanged']);}async['initializeSender'](){var _0xd41af8,_0x4a688f;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x1c1760=await this['sender']['_send']('ping',{},0x320);_0x1c1760&&(_0xd41af8=_0x1c1760[0x0])!=null&&_0xd41af8['fulfilled']&&(_0x4a688f=_0x1c1760[0x0])!=null&&_0x4a688f['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x56fa17){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x56fa17},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x35ad2e=>{await kr(_0x35ad2e,An,'1'),await Nr(_0x35ad2e,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x1bac06){this['pendingWrites']++;try{await _0x1bac06();}finally{this['pendingWrites']--;}}async['_set'](_0x54d394,_0x463d26){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xd788ff=>kr(_0xd788ff,_0x54d394,_0x463d26)),this['localCache'][_0x54d394]=_0x463d26,this['notifyServiceWorker'](_0x54d394)));}async['_get'](_0x53b915){const _0x48126a=await this['_withRetries'](_0xf44fd4=>lp(_0xf44fd4,_0x53b915));return this['localCache'][_0x53b915]=_0x48126a,_0x48126a;}async['_remove'](_0x1176b6){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x39435c=>Nr(_0x39435c,_0x1176b6)),delete this['localCache'][_0x1176b6],this['notifyServiceWorker'](_0x1176b6)));}async['_poll'](){const _0x46e088=await this['_withRetries'](_0x28917a=>{const _0x92ba1b=Kn(_0x28917a,!0x1)['getAll']();return new Jt(_0x92ba1b)['toPromise']();});if(!_0x46e088)return[];if(this['pendingWrites']!==0x0)return[];const _0x1e5aff=[],_0x556dc1=new Set();if(_0x46e088['length']!==0x0){for(const {fbase_key:_0x23b180,value:_0x5c934d}of _0x46e088)_0x556dc1['add'](_0x23b180),JSON['stringify'](this['localCache'][_0x23b180])!==JSON['stringify'](_0x5c934d)&&(this['notifyListeners'](_0x23b180,_0x5c934d),_0x1e5aff['push'](_0x23b180));}for(const _0xaccd35 of Object['keys'](this['localCache']))this['localCache'][_0xaccd35]&&!_0x556dc1['has'](_0xaccd35)&&(this['notifyListeners'](_0xaccd35,null),_0x1e5aff['push'](_0xaccd35));return _0x1e5aff;}['notifyListeners'](_0x339dcf,_0x452f60){this['localCache'][_0x339dcf]=_0x452f60;const _0x32865f=this['listeners'][_0x339dcf];if(_0x32865f){for(const _0x492caf of Array['from'](_0x32865f))_0x492caf(_0x452f60);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x90dc11,_0x1012f5){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x90dc11]||(this['listeners'][_0x90dc11]=new Set(),this['_get'](_0x90dc11)),this['listeners'][_0x90dc11]['add'](_0x1012f5);}['_removeListener'](_0x13fef5,_0x5dcaff){this['listeners'][_0x13fef5]&&(this['listeners'][_0x13fef5]['delete'](_0x5dcaff),this['listeners'][_0x13fef5]['size']===0x0&&delete this['listeners'][_0x13fef5]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x51b134,_0x181690){return _0x181690?ne(_0x181690):(m(_0x51b134['_popupRedirectResolver'],_0x51b134,'argument-error'),_0x51b134['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x4cc9a9){super('custom','custom'),this['params']=_0x4cc9a9;}['_getIdTokenResponse'](_0x47fb40){return Ze(_0x47fb40,this['_buildIdpRequest']());}['_linkToIdToken'](_0x41c6fc,_0x3a951a){return Ze(_0x41c6fc,this['_buildIdpRequest'](_0x3a951a));}['_getReauthenticationResolver'](_0x1cfa32){return Ze(_0x1cfa32,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x11749c){const _0x56f811={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x11749c&&(_0x56f811['idToken']=_0x11749c),_0x56f811;}}function pp(_0x21b871){return Ua(_0x21b871['auth'],new Rs(_0x21b871),_0x21b871['bypassAuthState']);}function _p(_0x172a15){const {auth:_0x2d0c05,user:_0x299875}=_0x172a15;return m(_0x299875,_0x2d0c05,'internal-error'),Kf(_0x299875,new Rs(_0x172a15),_0x172a15['bypassAuthState']);}async function gp(_0x1f4324){const {auth:_0x4ef1f0,user:_0x20a02f}=_0x1f4324;return m(_0x20a02f,_0x4ef1f0,'internal-error'),jf(_0x20a02f,new Rs(_0x1f4324),_0x1f4324['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x439bca,_0x26770a,_0x1616b2,_0x51260e,_0x16a4f2=!0x1){this['auth']=_0x439bca,this['resolver']=_0x1616b2,this['user']=_0x51260e,this['bypassAuthState']=_0x16a4f2,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x26770a)?_0x26770a:[_0x26770a];}['execute'](){return new Promise(async(_0x457ac4,_0x391f2b)=>{this['pendingPromise']={'resolve':_0x457ac4,'reject':_0x391f2b};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2b48df){this['reject'](_0x2b48df);}});}async['onAuthEvent'](_0x57d2e6){const {urlResponse:_0x438aaa,sessionId:_0x26f3c4,postBody:_0xd999b1,tenantId:_0x4b193c,error:_0x577dc8,type:_0x458b9d}=_0x57d2e6;if(_0x577dc8){this['reject'](_0x577dc8);return;}const _0x121ace={'auth':this['auth'],'requestUri':_0x438aaa,'sessionId':_0x26f3c4,'tenantId':_0x4b193c||void 0x0,'postBody':_0xd999b1||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x458b9d)(_0x121ace));}catch(_0x429c8c){this['reject'](_0x429c8c);}}['onError'](_0x195c13){this['reject'](_0x195c13);}['getIdpTask'](_0xf7e049){switch(_0xf7e049){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x3493ea){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3493ea),this['unregisterAndCleanUp']();}['reject'](_0x2d8ef2){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2d8ef2),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x1b3db6,_0x2060ee,_0x153fa4,_0x18357e,_0x3db5ad){super(_0x1b3db6,_0x2060ee,_0x18357e,_0x3db5ad),this['provider']=_0x153fa4,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0xcdac10=await this['execute']();return m(_0xcdac10,this['auth'],'internal-error'),_0xcdac10;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x37298e=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x37298e),this['authWindow']['associatedEvent']=_0x37298e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x18f0cf=>{this['reject'](_0x18f0cf);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x44bc0c=>{_0x44bc0c||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x409757;return((_0x409757=this['authWindow'])==null?void 0x0:_0x409757['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x5848e0=()=>{var _0x11bd19,_0x250f00;if((_0x250f00=(_0x11bd19=this['authWindow'])==null?void 0x0:_0x11bd19['window'])!=null&&_0x250f00['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x5848e0,mp['get']());};_0x5848e0();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x339f5a,_0x37685b,_0x398492=!0x1){super(_0x339f5a,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x37685b,void 0x0,_0x398492),this['eventId']=null;}async['execute'](){let _0x274ae1=rn['get'](this['auth']['_key']());if(!_0x274ae1){try{const _0x358c06=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x274ae1=()=>Promise['resolve'](_0x358c06);}catch(_0x4e4046){_0x274ae1=()=>Promise['reject'](_0x4e4046);}rn['set'](this['auth']['_key'](),_0x274ae1);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x274ae1();}async['onAuthEvent'](_0x20314e){if(_0x20314e['type']==='signInViaRedirect')return super['onAuthEvent'](_0x20314e);if(_0x20314e['type']==='unknown'){this['resolve'](null);return;}if(_0x20314e['eventId']){const _0x9120c8=await this['auth']['_redirectUserForId'](_0x20314e['eventId']);if(_0x9120c8)return this['user']=_0x9120c8,super['onAuthEvent'](_0x20314e);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x3d9b1c,_0x20050e){const _0x2dceb7=Cp(_0x20050e),_0x97c37a=wp(_0x3d9b1c);if(!await _0x97c37a['_isAvailable']())return!0x1;const _0x47598c=await _0x97c37a['_get'](_0x2dceb7)==='true';return await _0x97c37a['_remove'](_0x2dceb7),_0x47598c;}function Ip(_0x12ee63,_0x46a235){rn['set'](_0x12ee63['_key'](),_0x46a235);}function wp(_0x54be0e){return ne(_0x54be0e['_redirectPersistence']);}function Cp(_0x421c15){return sn(yp,_0x421c15['config']['apiKey'],_0x421c15['name']);}async function Tp(_0x390cd6,_0x2d711f,_0x57bdf6=!0x1){if(H(_0x390cd6['app']))return Promise['reject'](se(_0x390cd6));const _0x17e473=qe(_0x390cd6),_0x31e874=fp(_0x17e473,_0x2d711f),_0x1ff630=await new vp(_0x17e473,_0x31e874,_0x57bdf6)['execute']();return _0x1ff630&&!_0x57bdf6&&(delete _0x1ff630['user']['_redirectEventId'],await _0x17e473['_persistUserIfCurrent'](_0x1ff630['user']),await _0x17e473['_setRedirectUser'](null,_0x2d711f)),_0x1ff630;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x54e928){this['auth']=_0x54e928,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x2d11a6){this['consumers']['add'](_0x2d11a6),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x2d11a6)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x2d11a6),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2453bc){this['consumers']['delete'](_0x2453bc);}['onEvent'](_0x58739b){if(this['hasEventBeenHandled'](_0x58739b))return!0x1;let _0x499de8=!0x1;return this['consumers']['forEach'](_0x228a53=>{this['isEventForConsumer'](_0x58739b,_0x228a53)&&(_0x499de8=!0x0,this['sendToConsumer'](_0x58739b,_0x228a53),this['saveEventToCache'](_0x58739b));}),this['hasHandledPotentialRedirect']||!Rp(_0x58739b)||(this['hasHandledPotentialRedirect']=!0x0,_0x499de8||(this['queuedRedirectEvent']=_0x58739b,_0x499de8=!0x0)),_0x499de8;}['sendToConsumer'](_0x5bf66e,_0x31be7a){var _0x595379;if(_0x5bf66e['error']&&!Qa(_0x5bf66e)){const _0x3268ba=((_0x595379=_0x5bf66e['error']['code'])==null?void 0x0:_0x595379['split']('auth/')[0x1])||'internal-error';_0x31be7a['onError'](J(this['auth'],_0x3268ba));}else _0x31be7a['onAuthEvent'](_0x5bf66e);}['isEventForConsumer'](_0x4305d4,_0x29eba7){const _0x106270=_0x29eba7['eventId']===null||!!_0x4305d4['eventId']&&_0x4305d4['eventId']===_0x29eba7['eventId'];return _0x29eba7['filter']['includes'](_0x4305d4['type'])&&_0x106270;}['hasEventBeenHandled'](_0x4f7a58){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x4f7a58));}['saveEventToCache'](_0x51ece9){this['cachedEventUids']['add'](Pr(_0x51ece9)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x32bb58){return[_0x32bb58['type'],_0x32bb58['eventId'],_0x32bb58['sessionId'],_0x32bb58['tenantId']]['filter'](_0x13b8fd=>_0x13b8fd)['join']('-');}function Qa({type:_0x5d6d85,error:_0x35d6df}){return _0x5d6d85==='unknown'&&(_0x35d6df==null?void 0x0:_0x35d6df['code'])==='auth/no-auth-event';}function Rp(_0x3a149a){switch(_0x3a149a['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x3a149a);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x48fb52,_0x482534={}){return Ae(_0x48fb52,'GET','/v1/projects',_0x482534);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x4ea0e4){if(_0x4ea0e4['config']['emulator'])return;const {authorizedDomains:_0x318549}=await Ap(_0x4ea0e4);for(const _0x2c5b38 of _0x318549)try{if(Op(_0x2c5b38))return;}catch{}K(_0x4ea0e4,'unauthorized-domain');}function Op(_0x37666f){const _0xbe8e7b=Ni(),{protocol:_0x11e349,hostname:_0x4c2250}=new URL(_0xbe8e7b);if(_0x37666f['startsWith']('chrome-extension://')){const _0x547850=new URL(_0x37666f);return _0x547850['hostname']===''&&_0x4c2250===''?_0x11e349==='chrome-extension:'&&_0x37666f['replace']('chrome-extension://','')===_0xbe8e7b['replace']('chrome-extension://',''):_0x11e349==='chrome-extension:'&&_0x547850['hostname']===_0x4c2250;}if(!Np['test'](_0x11e349))return!0x1;if(kp['test'](_0x37666f))return _0x4c2250===_0x37666f;const _0x1dc74a=_0x37666f['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x1dc74a+'|'+_0x1dc74a+')$','i')['test'](_0x4c2250);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x47cc78=X()['___jsl'];if(_0x47cc78!=null&&_0x47cc78['H']){for(const _0x142b37 of Object['keys'](_0x47cc78['H']))if(_0x47cc78['H'][_0x142b37]['r']=_0x47cc78['H'][_0x142b37]['r']||[],_0x47cc78['H'][_0x142b37]['L']=_0x47cc78['H'][_0x142b37]['L']||[],_0x47cc78['H'][_0x142b37]['r']=[..._0x47cc78['H'][_0x142b37]['L']],_0x47cc78['CP']){for(let _0x80e421=0x0;_0x80e421<_0x47cc78['CP']['length'];_0x80e421++)_0x47cc78['CP'][_0x80e421]=null;}}}function Mp(_0x5d7afa){return new Promise((_0xbe2496,_0x34e7e9)=>{var _0x5427b6,_0x14c6f6,_0x5e239f;function _0x230d58(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0xbe2496(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x34e7e9(J(_0x5d7afa,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x14c6f6=(_0x5427b6=X()['gapi'])==null?void 0x0:_0x5427b6['iframes'])!=null&&_0x14c6f6['Iframe'])_0xbe2496(gapi['iframes']['getContext']());else{if((_0x5e239f=X()['gapi'])!=null&&_0x5e239f['load'])_0x230d58();else{const _0x2be3e0=Nf('iframefcb');return X()[_0x2be3e0]=()=>{gapi['load']?_0x230d58():_0x34e7e9(J(_0x5d7afa,'network-request-failed'));},Da(kf()+'?onload='+_0x2be3e0)['catch'](_0x5a8ae2=>_0x34e7e9(_0x5a8ae2));}}})['catch'](_0x356de5=>{throw on=null,_0x356de5;});}let on=null;function Lp(_0xf75185){return on=on||Mp(_0xf75185),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x5a9e4a){const _0x2837cd=_0x5a9e4a['config'];m(_0x2837cd['authDomain'],_0x5a9e4a,'auth-domain-config-required');const _0x2d6e62=_0x2837cd['emulator']?Is(_0x2837cd,Up):'https://'+_0x5a9e4a['config']['authDomain']+'/'+Fp,_0x8318b4={'apiKey':_0x2837cd['apiKey'],'appName':_0x5a9e4a['name'],'v':ct},_0x5eec9b=Bp['get'](_0x5a9e4a['config']['apiHost']);_0x5eec9b&&(_0x8318b4['eid']=_0x5eec9b);const _0x22a9e9=_0x5a9e4a['_getFrameworks']();return _0x22a9e9['length']&&(_0x8318b4['fw']=_0x22a9e9['join'](',')),_0x2d6e62+'?'+at(_0x8318b4)['slice'](0x1);}async function Hp(_0x3e40b8){const _0x2dd318=await Lp(_0x3e40b8),_0x20558a=X()['gapi'];return m(_0x20558a,_0x3e40b8,'internal-error'),_0x2dd318['open']({'where':document['body'],'url':Vp(_0x3e40b8),'messageHandlersFilter':_0x20558a['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x5b1337=>new Promise(async(_0x546658,_0x51140a)=>{await _0x5b1337['restyle']({'setHideOnLeave':!0x1});const _0x1b04d5=J(_0x3e40b8,'network-request-failed'),_0x53feaa=X()['setTimeout'](()=>{_0x51140a(_0x1b04d5);},xp['get']());function _0x38238b(){X()['clearTimeout'](_0x53feaa),_0x546658(_0x5b1337);}_0x5b1337['ping'](_0x38238b)['then'](_0x38238b,()=>{_0x51140a(_0x1b04d5);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x1e02b1){this['window']=_0x1e02b1,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x4b5d15,_0x3f3a73,_0x10bc56,_0x59e971=Gp,_0x275033=qp){const _0x19ecff=Math['max']((window['screen']['availHeight']-_0x275033)/0x2,0x0)['toString'](),_0x35c22a=Math['max']((window['screen']['availWidth']-_0x59e971)/0x2,0x0)['toString']();let _0x5fb830='';const _0x246bc5={...$p,'width':_0x59e971['toString'](),'height':_0x275033['toString'](),'top':_0x19ecff,'left':_0x35c22a},_0x269f86=W()['toLowerCase']();_0x10bc56&&(_0x5fb830=ba(_0x269f86)?zp:_0x10bc56),Ta(_0x269f86)&&(_0x3f3a73=_0x3f3a73||jp,_0x246bc5['scrollbars']='yes');const _0x45c880=Object['entries'](_0x246bc5)['reduce']((_0x10a013,[_0x4fc45f,_0x47af7d])=>''+_0x10a013+_0x4fc45f+'='+_0x47af7d+',','');if(Ef(_0x269f86)&&_0x5fb830!=='_self')return Yp(_0x3f3a73||'',_0x5fb830),new Dr(null);const _0x46df20=window['open'](_0x3f3a73||'',_0x5fb830,_0x45c880);m(_0x46df20,_0x4b5d15,'popup-blocked');try{_0x46df20['focus']();}catch{}return new Dr(_0x46df20);}function Yp(_0x1b3033,_0x4fdfe1){const _0xdd2b7c=document['createElement']('a');_0xdd2b7c['href']=_0x1b3033,_0xdd2b7c['target']=_0x4fdfe1;const _0x3a6422=document['createEvent']('MouseEvent');_0x3a6422['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0xdd2b7c['dispatchEvent'](_0x3a6422);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x1aaeea,_0x12940e,_0x5c26de,_0x4c2ae4,_0x243707,_0x2c911f){m(_0x1aaeea['config']['authDomain'],_0x1aaeea,'auth-domain-config-required'),m(_0x1aaeea['config']['apiKey'],_0x1aaeea,'invalid-api-key');const _0x46bc31={'apiKey':_0x1aaeea['config']['apiKey'],'appName':_0x1aaeea['name'],'authType':_0x5c26de,'redirectUrl':_0x4c2ae4,'v':ct,'eventId':_0x243707};if(_0x12940e instanceof xa){_0x12940e['setDefaultLanguage'](_0x1aaeea['languageCode']),_0x46bc31['providerId']=_0x12940e['providerId']||'',hi(_0x12940e['getCustomParameters']())||(_0x46bc31['customParameters']=JSON['stringify'](_0x12940e['getCustomParameters']()));for(const [_0x45f890,_0x1cd31c]of Object['entries']({}))_0x46bc31[_0x45f890]=_0x1cd31c;}if(_0x12940e instanceof Qt){const _0x3a1ef3=_0x12940e['getScopes']()['filter'](_0x412b8b=>_0x412b8b!=='');_0x3a1ef3['length']>0x0&&(_0x46bc31['scopes']=_0x3a1ef3['join'](','));}_0x1aaeea['tenantId']&&(_0x46bc31['tid']=_0x1aaeea['tenantId']);const _0x54b8f3=_0x46bc31;for(const _0x4c341e of Object['keys'](_0x54b8f3))_0x54b8f3[_0x4c341e]===void 0x0&&delete _0x54b8f3[_0x4c341e];const _0x3d41f9=await _0x1aaeea['_getAppCheckToken'](),_0x18f92e=_0x3d41f9?'#'+Xp+'='+encodeURIComponent(_0x3d41f9):'';return Zp(_0x1aaeea)+'?'+at(_0x54b8f3)['slice'](0x1)+_0x18f92e;}function Zp({config:_0x1f37f1}){return _0x1f37f1['emulator']?Is(_0x1f37f1,Jp):'https://'+_0x1f37f1['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x5395dc,_0x182d18,_0x216135,_0x3aa3fe){var _0x289d46;ae((_0x289d46=this['eventManagers'][_0x5395dc['_key']()])==null?void 0x0:_0x289d46['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2c76d6=await Mr(_0x5395dc,_0x182d18,_0x216135,Ni(),_0x3aa3fe);return Kp(_0x5395dc,_0x2c76d6,bs());}async['_openRedirect'](_0x236956,_0x2ba9a3,_0x3ecb72,_0x850d8c){await this['_originValidation'](_0x236956);const _0x561da7=await Mr(_0x236956,_0x2ba9a3,_0x3ecb72,Ni(),_0x850d8c);return ip(_0x561da7),new Promise(()=>{});}['_initialize'](_0xa788b9){const _0x390216=_0xa788b9['_key']();if(this['eventManagers'][_0x390216]){const {manager:_0x2e8ac3,promise:_0x3d7f51}=this['eventManagers'][_0x390216];return _0x2e8ac3?Promise['resolve'](_0x2e8ac3):(ae(_0x3d7f51,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3d7f51);}const _0x24784a=this['initAndGetManager'](_0xa788b9);return this['eventManagers'][_0x390216]={'promise':_0x24784a},_0x24784a['catch'](()=>{delete this['eventManagers'][_0x390216];}),_0x24784a;}async['initAndGetManager'](_0x5c178f){const _0x440a4e=await Hp(_0x5c178f),_0x1e043f=new bp(_0x5c178f);return _0x440a4e['register']('authEvent',_0x4e438d=>(m(_0x4e438d==null?void 0x0:_0x4e438d['authEvent'],_0x5c178f,'invalid-auth-event'),{'status':_0x1e043f['onEvent'](_0x4e438d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x5c178f['_key']()]={'manager':_0x1e043f},this['iframes'][_0x5c178f['_key']()]=_0x440a4e,_0x1e043f;}['_isIframeWebStorageSupported'](_0x44af81,_0x4dacbb){this['iframes'][_0x44af81['_key']()]['send'](li,{'type':li},_0x2b3656=>{var _0x59e6f8;const _0x38b812=(_0x59e6f8=_0x2b3656==null?void 0x0:_0x2b3656[0x0])==null?void 0x0:_0x59e6f8[li];_0x38b812!==void 0x0&&_0x4dacbb(!!_0x38b812),K(_0x44af81,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x14c28c){const _0x407609=_0x14c28c['_key']();return this['originValidationPromises'][_0x407609]||(this['originValidationPromises'][_0x407609]=Pp(_0x14c28c)),this['originValidationPromises'][_0x407609];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x5e3037){this['auth']=_0x5e3037,this['internalListeners']=new Map();}['getUid'](){var _0x2991ea;return this['assertAuthConfigured'](),((_0x2991ea=this['auth']['currentUser'])==null?void 0x0:_0x2991ea['uid'])||null;}async['getToken'](_0x2ccc7a){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2ccc7a)}:null;}['addAuthTokenListener'](_0x2a3fde){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2a3fde))return;const _0x87392f=this['auth']['onIdTokenChanged'](_0x2f471e=>{_0x2a3fde((_0x2f471e==null?void 0x0:_0x2f471e['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2a3fde,_0x87392f),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2951b0){this['assertAuthConfigured']();const _0xf4791b=this['internalListeners']['get'](_0x2951b0);_0xf4791b&&(this['internalListeners']['delete'](_0x2951b0),_0xf4791b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x44f7f3){switch(_0x44f7f3){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x295d64){et(new Me('auth',(_0x512917,{options:_0x1ced9b})=>{const _0x5856dd=_0x512917['getProvider']('app')['getImmediate'](),_0x80f4a=_0x512917['getProvider']('heartbeat'),_0x167261=_0x512917['getProvider']('app-check-internal'),{apiKey:_0x51c71d,authDomain:_0x368d73}=_0x5856dd['options'];m(_0x51c71d&&!_0x51c71d['includes'](':'),'invalid-api-key',{'appName':_0x5856dd['name']});const _0x13ad34={'apiKey':_0x51c71d,'authDomain':_0x368d73,'clientPlatform':_0x295d64,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x295d64)},_0x341875=new bf(_0x5856dd,_0x80f4a,_0x167261,_0x13ad34);return Lf(_0x341875,_0x1ced9b),_0x341875;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x41ffe4,_0x1e5d28,_0x4da30e)=>{_0x41ffe4['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x3d7338=>{const _0x2fae69=qe(_0x3d7338['getProvider']('auth')['getImmediate']());return(_0x4ca03e=>new n_(_0x4ca03e))(_0x2fae69);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x295d64)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x4d381d=>async _0x10d7a2=>{const _0x48de04=_0x10d7a2&&await _0x10d7a2['getIdTokenResult'](),_0x115ec8=_0x48de04&&(new Date()['getTime']()-Date['parse'](_0x48de04['issuedAtTime']))/0x3e8;if(_0x115ec8&&_0x115ec8>o_)return;const _0x3aceaa=_0x48de04==null?void 0x0:_0x48de04['token'];Fr!==_0x3aceaa&&(Fr=_0x3aceaa,await fetch(_0x4d381d,{'method':_0x3aceaa?'POST':'DELETE','headers':_0x3aceaa?{'Authorization':'Bearer\x20'+_0x3aceaa}:{}}));};function O_(_0x2204ac=Qr()){const _0x5864fc=Ui(_0x2204ac,'auth');if(_0x5864fc['isInitialized']())return _0x5864fc['getImmediate']();const _0x22cf87=Mf(_0x2204ac,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x2646be=Gr('authTokenSyncURL');if(_0x2646be&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2c27bb=new URL(_0x2646be,location['origin']);if(location['origin']===_0x2c27bb['origin']){const _0x35e039=a_(_0x2c27bb['toString']());Jf(_0x22cf87,_0x35e039,()=>_0x35e039(_0x22cf87['currentUser'])),Qf(_0x22cf87,_0x149164=>_0x35e039(_0x149164));}}const _0x203dfd=Hr('auth');return _0x203dfd&&xf(_0x22cf87,'http://'+_0x203dfd),_0x22cf87;}function c_(){var _0x1bc7b8;return((_0x1bc7b8=document['getElementsByTagName']('head'))==null?void 0x0:_0x1bc7b8[0x0])??document;}Rf({'loadJS'(_0x3dcce4){return new Promise((_0x39e425,_0x34177f)=>{const _0x17c4a9=document['createElement']('script');_0x17c4a9['setAttribute']('src',_0x3dcce4),_0x17c4a9['onload']=_0x39e425,_0x17c4a9['onerror']=_0x872298=>{const _0x18cd5c=J('internal-error');_0x18cd5c['customData']=_0x872298,_0x34177f(_0x18cd5c);},_0x17c4a9['type']='text/javascript',_0x17c4a9['charset']='UTF-8',c_()['appendChild'](_0x17c4a9);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};